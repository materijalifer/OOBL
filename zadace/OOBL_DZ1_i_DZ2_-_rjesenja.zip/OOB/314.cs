﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         // stock error
         private const string ErrorStockInit = "ERROR init stock";
         private const string ErrorStockExist = "ERROR exist stock";
         private const string ErrorStockNotExist = "ERROR not exist stock";
         private const string ErrorStockTime = "ERROR time stock";

         // index error
         private const string ErrorIndexInit = "ERROR init index";
         private const string ErrorIndexExist = "ERROR exist index";
         private const string ErrorIndexNotExist = "ERROR not exist index";
         private const string ErrorStockInIndex = "ERROR stock in index";
         private const string ErrorStockNotInIndex = "ERROR stock not in index";

         // portfolio error
         private const string ErrorPortfolioExist = "ERROR exist portfolio";
         private const string ErrorPortfolioNotExist = "ERROR not exist portfolio";
         private const string ErrorStockInPortfolio = "ERROR stock in portfolio";
         private const string ErrorNumOfSharesInStock = "ERROR number of shares in stock";

         // data
         private DataMarketPlace _dataMarketPlace = new DataMarketPlace();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!((inNumberOfShares > 0) && (inInitialPrice > 0)))
                 throw new StockExchangeException(ErrorStockInit);
             else if (StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockExist);
             else
             {
                 Stock stock = new Stock(inStockName, inNumberOfShares, inTimeStamp, inInitialPrice);
                 _dataMarketPlace.ListStock.Add(stock);
             }
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (IsStockPartOfPortfolio(portfolio.GetPorfolioID, inStockName))
                         RemoveStockFromPortfolio(portfolio.GetPorfolioID, inStockName);
                 }
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if(IsStockPartOfIndex(index.GetIndexName, inStockName))
                         RemoveStockFromIndex(index.GetIndexName, inStockName);
                 }
                 foreach (Stock stock in _dataMarketPlace.ListStock)
                 {
                     if (stock.GetStockName == inStockName.ToUpper())
                     {
                         _dataMarketPlace.ListStock.Remove(stock);
                         break;
                     }
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             bool stockExist = false;
             foreach (Stock stock in _dataMarketPlace.ListStock)
             {
                 if (stock.GetStockName == inStockName.ToUpper())
                 {
                     stockExist = true;
                     break;
                 }
             }
             return stockExist;
         }

         public int NumberOfStocks()
         {
             int numOfStocks = _dataMarketPlace.ListStock.Count;
             return numOfStocks;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!(inStockValue > 0))
                 throw new StockExchangeException(ErrorStockInit);
             else
             {
                 foreach (Stock stock in _dataMarketPlace.ListStock)
                 {
                     if (stock.GetStockName == inStockName.ToUpper())
                     {
                         stock.SetItemDatePrice(inTimeStamp, inStockValue);
                         break;
                     }
                 }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Decimal price = 0;

             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else
             {
                 foreach (Stock stock in _dataMarketPlace.ListStock)
                 {
                     if (stock.GetStockName == inStockName.ToUpper())
                     {
                         foreach (KeyValuePair<DateTime, Decimal> item in stock.GetItemDatePrice)
                         {
                             if (item.Key > inTimeStamp)
                                 break;
                             price = item.Value;
                         }
                     }
                 }
             }

             if (price == 0)
                 throw new StockExchangeException(ErrorStockTime);
             else
                return price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Decimal price = 0;
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else
             {
                 foreach (Stock stock in _dataMarketPlace.ListStock)
                 {
                     if (stock.GetStockName == inStockName.ToUpper())
                     {
                         price = stock.GetItemDatePrice.Values.First();
                         break;
                     }
                 }
             }
             return price;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Decimal price = 0;
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else
             {
                 foreach (Stock stock in _dataMarketPlace.ListStock)
                 {
                     if (stock.GetStockName == inStockName.ToUpper())
                     {
                         price = stock.GetItemDatePrice.Values.Last();
                         break;
                     }
                 }
             }
             return price;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexExist);
             else if(!((inIndexType == IndexTypes.AVERAGE) || (inIndexType == IndexTypes.WEIGHTED)))
                 throw new StockExchangeException(ErrorIndexInit);
             else
             {
                 Index index = new Index(inIndexName, inIndexType);
                 _dataMarketPlace.ListIndex.Add(index);
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexNotExist);
             else if (IsStockPartOfIndex(inIndexName, inStockName))
                 throw new StockExchangeException(ErrorStockInIndex);
             else
             {
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if (index.GetIndexName == inIndexName.ToUpper())
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 index.AddStockToList(stock);
                                 break;
                             }
                         }
                     }

                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexNotExist);
             else if (!IsStockPartOfIndex(inIndexName, inStockName))
                 throw new StockExchangeException(ErrorStockNotInIndex);
             else
             {
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if (index.GetIndexName == inIndexName.ToUpper())
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 index.RemoveStockFromList(stock);
                                 break;
                             }
                         }
                     }

                 }
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool find = false;
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexNotExist);
             else
             {
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if (index.GetIndexName == inIndexName.ToUpper())
                     {
                         foreach (Stock stock in index.GetStockList)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 find = true;
                                 break;
                             }
                         }
                         break;
                     }
                 }
             }
             return find;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Decimal price = 0;

             if (!IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexNotExist);
             else
             {
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if (index.GetIndexName == inIndexName.ToUpper())
                     {
                         if (index.GetIndexType == IndexTypes.AVERAGE)
                         {
                             price = GetIndexValueOfAverage(index, inTimeStamp);
                         }
                         else
                         {
                             price = GetIndexValueOfWeight(index, inTimeStamp);
                         }
                         break;
                     }
                 }
             }

             return Math.Round(price, 3);
         }

         private decimal GetIndexValueOfAverage(Index index, DateTime inTimeStamp)
         {
             decimal price = 0;

             decimal sumOfStocks = 0;

             foreach (Stock stock in index.GetStockList)
             {
                 decimal valueOfStock = GetStockPrice(stock.GetStockName, inTimeStamp);
                 sumOfStocks += valueOfStock;
             }

             decimal numOfStocks = NumberOfStocksInIndex(index.GetIndexName);

             if (numOfStocks != 0)
                price = sumOfStocks/numOfStocks;

             return price;
         }

         private decimal GetIndexValueOfWeight(Index index, DateTime inTimeStamp)
         {
             decimal price = 0;

             decimal weightSumOfStocks = 0;

             foreach (Stock stock in index.GetStockList)
             {
                 decimal valueOfStock = GetStockPrice(stock.GetStockName, inTimeStamp);
                 long numOfShares = stock.GetNumberOfShares;
                 weightSumOfStocks += numOfShares * valueOfStock;
             }

             foreach (Stock stock in index.GetStockList)
             {
                 decimal valueOfStock = GetStockPrice(stock.GetStockName, inTimeStamp);
                 long numOfShares = stock.GetNumberOfShares;
                 price += (numOfShares * valueOfStock * valueOfStock / weightSumOfStocks);
             }

             return price;
         }

         public bool IndexExists(string inIndexName)
         {
             bool indexExist = false;
             foreach (Index index in _dataMarketPlace.ListIndex)
             {
                 if (index.GetIndexName == inIndexName.ToUpper())
                 {
                     indexExist = true;
                     break;
                 }
             }
             return indexExist;
         }

         public int NumberOfIndices()
         {
             int numberOfIndices = _dataMarketPlace.ListIndex.Count;
             return numberOfIndices;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int numberOfStocksInIndex = 0;
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException(ErrorIndexNotExist);
             else
             {
                 foreach (Index index in _dataMarketPlace.ListIndex)
                 {
                     if (index.GetIndexName == inIndexName.ToUpper())
                     {
                         foreach (Stock stock in index.GetStockList)
                         {
                             numberOfStocksInIndex++;
                         }
                         break;
                     }
                 }
             }
             return numberOfStocksInIndex;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioExist);
             else
             {
                 Portfolio porfolio = new Portfolio(inPortfolioID);
                 _dataMarketPlace.ListPortfolio.Add(porfolio);
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!(numberOfShares > 0))
                 throw new StockExchangeException(ErrorStockInit);
             else if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 if (!portfolio.AddExistItemToDictionary(stock, numberOfShares))
                                     throw new StockExchangeException(ErrorNumOfSharesInStock);
                                 else
                                    break;
                             }
                         }
                         break;
                     }
                 }
             }
             else if (!okNumOfSharesInStocks(inStockName, numberOfShares))
                 throw new StockExchangeException(ErrorNumOfSharesInStock);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 portfolio.AddItemToDictionary(stock, numberOfShares);
                                 break;
                             }
                         }
                         break;
                     }
                 }
             }
         }

         private bool okNumOfSharesInStocks(string inStockName, int numberOfShares)
         {
             bool OK = false;

             foreach (Stock stock in _dataMarketPlace.ListStock)
             {
                 if (stock.GetStockName == inStockName.ToUpper())
                 {
                     if (stock.GetNumberOfShares >= numberOfShares)
                     {
                         OK = true;
                         break;
                     }
                 }
             }

             return OK;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException(ErrorStockInPortfolio);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 if (!portfolio.RemoveSomeSharesFromDictionary(stock, numberOfShares))
                                     throw new StockExchangeException(ErrorNumOfSharesInStock);
                                 else
                                     break;
                             }
                         }
                         break;
                     }
                 }
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException(ErrorStockInPortfolio);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (Stock stock in _dataMarketPlace.ListStock)
                         {
                             if (stock.GetStockName == inStockName.ToUpper())
                             {
                                 portfolio.RemoveItemFromDictionary(stock);
                                 break;
                             }
                         }
                         break;
                     }
                 }
             }
         }

         public int NumberOfPortfolios()
         {
             int numberOfPortfolios = _dataMarketPlace.ListPortfolio.Count;
             return numberOfPortfolios;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int numberOfStocksInPortfolio = 0;
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         numberOfStocksInPortfolio = portfolio.GetItemDictionary.Count;
                         break;
                     }
                 }
             }
             return numberOfStocksInPortfolio;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool portfolioExist = false;
             foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
             {
                 if (portfolio.GetPorfolioID == inPortfolioID)
                 {
                     portfolioExist = true;
                     break;
                 }
             }
             return portfolioExist;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool isStockPartOfPortfolio = false;

             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (KeyValuePair<Stock,int> item in portfolio.GetItemDictionary)
                         {
                             if (item.Key.GetStockName == inStockName.ToUpper())
                             {
                                 isStockPartOfPortfolio = true;
                                 break;
                             }
                         }
                     }
                 }
             }

             return isStockPartOfPortfolio;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int numberOfSharesOfStockInPortfolio = 0;
             if (!StockExists(inStockName))
                 throw new StockExchangeException(ErrorStockNotExist);
             else if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (KeyValuePair<Stock, int> item in portfolio.GetItemDictionary)
                         {
                             if (item.Key.GetStockName == inStockName.ToUpper())
                             {
                                 numberOfSharesOfStockInPortfolio = item.Value;
                                 break;
                             }
                         }
                     }
                 }
             }
             return numberOfSharesOfStockInPortfolio;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal value = 0;

             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else
             {
                 foreach (Portfolio portfolio in _dataMarketPlace.ListPortfolio)
                 {
                     if (portfolio.GetPorfolioID == inPortfolioID)
                     {
                         foreach (KeyValuePair<Stock, int> dictionary in portfolio.GetItemDictionary)
                         {
                             value += (GetStockPrice(dictionary.Key.GetStockName, timeStamp) * dictionary.Value);
                         }
                         break;
                     }
                 }
             }

             return Math.Round(value, 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal change = 0;

             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException(ErrorPortfolioNotExist);
             else if (!(NumberOfStocksInPortfolio(inPortfolioID) > 0))
                 return change;
             else
             {
                 decimal start = 0;
                 decimal end = 0;

                 DateTime startDate = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                 DateTime endDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

                 start = GetPortfolioValue(inPortfolioID, startDate);
                 end = GetPortfolioValue(inPortfolioID, endDate);

                 change = ((end / start) - 1 ) * 100;
             }

             return Math.Round(change, 3);
         }


     }

    class Stock
    {
        private string name;
        public string GetStockName
        {
            get { return name; }
        }

        private long numberOfShares;
        public long GetNumberOfShares
        {
            get { return numberOfShares; }
        }

        private Dictionary<DateTime, Decimal> itemDatePrice = new Dictionary<DateTime, decimal>();
        public Dictionary<DateTime, Decimal> GetItemDatePrice
        {
            get { return itemDatePrice; }
        }
        public void SetItemDatePrice(DateTime date, Decimal price)
        {
            itemDatePrice.Add(date, price);
        }

        public Stock(string name, long numberOfShares, DateTime date, Decimal price)
        {
            this.name = name.ToUpper();
            this.numberOfShares = numberOfShares;
            SetItemDatePrice(date, price);
        }
    }

    class Index
    {
        private string name;
        public string GetIndexName
        {
            get { return name; }
        }

        private IndexTypes indexType;
        public IndexTypes GetIndexType
        {
            get { return indexType; }
        }

        public Index(string name, IndexTypes indexType)
        {
            this.name = name.ToUpper();
            this.indexType = indexType;
        }

        private List<Stock> stockList = new List<Stock>();
        public List<Stock> GetStockList
        {
            get { return stockList; }
        }
        public void AddStockToList(Stock stock)
        {
            stockList.Add(stock);
        }
        public void RemoveStockFromList(Stock stock)
        {
            stockList.Remove(stock);
        }
    }

    class Portfolio
    {
        private string ID;
        public string GetPorfolioID
        {
            get { return ID; }
        }

        public Portfolio(string ID)
        {
            this.ID = ID;
        }

        Dictionary<Stock, int> itemStockNumber = new Dictionary<Stock, int>();
        public Dictionary<Stock, int> GetItemDictionary
        {
            get { return itemStockNumber; }
        }
        public void AddItemToDictionary(Stock stock, int numberOfShares)
        {
            itemStockNumber.Add(stock, numberOfShares);
        }
        public void RemoveItemFromDictionary(Stock stock)
        {
            itemStockNumber.Remove(stock);
        }
        public bool AddExistItemToDictionary(Stock stock, int numOfShares)
        {
            int num = numOfShares + itemStockNumber[stock];
            if (num > stock.GetNumberOfShares)
                return false;
            else
            {
                RemoveItemFromDictionary(stock);
                AddItemToDictionary(stock, num);
            }
            return true;
        }
        public bool RemoveSomeSharesFromDictionary(Stock stock, int numOfShares)
        {
            int num = itemStockNumber[stock] - numOfShares;
            if (num < 0)
                return false;
            else if (num == 0)
            {
                RemoveItemFromDictionary(stock);
            }
            else
            {
                RemoveItemFromDictionary(stock);
                AddItemToDictionary(stock, num);
            }
            return true;
        }
    }

    class DataMarketPlace
    {
        public List<Stock> ListStock = new List<Stock>();
        public List<Index> ListIndex = new List<Index>();
        public List<Portfolio> ListPortfolio = new List<Portfolio>();
    }
}
