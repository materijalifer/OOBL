﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    /// <summary>
    /// Programska izvedba kalkulatora.
    /// Kalkulator je kompletno izveden u klasi Calculator.
    /// Obrada pojedinih učitanih znakova je delegirana na pojedine metode.
    /// PUNO BOLJE bi bilo da je program oblikovan korištenjem nekih oblikovinih
    /// obrazaca poput npr. Command ili State patterna, no to je prekasno uočeno.
    /// </summary>
    public class Calculator : ICalculator
    {
        private char[] unarniOperatori = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I', '=' };
        private char[] binarniOperatori = { '+', '-', '*', '/' };
        private char[] control = { 'P', 'G', 'C', 'O' };
        private string display;
        private double value;
        private double buffer;
        private double storedValue;
        private char lastOperator;
        private bool bufferState; // false - buffer nismo punili
        private bool errorFlag;
        private bool wasLastUnar;
        private double decimalState;

        public Calculator()
        {
            storedValue = 0.0;
            value = 0.0;
            lastOperator = ' ';
            clearDisplay();
        }

        public void clearDisplay()
        {
            display = "0";
            buffer = 0.0;
            decimalState = 1.0;
            bufferState = false;
            errorFlag = false;
            wasLastUnar = false;
        }

        public void updateDisplay()
        {
            if (errorFlag)
            {
                display = "-E-";
                return;
            }
            if (!bufferState)
            {
                value = round(value);
                display = value.ToString();
            }
            else
            {
                buffer = round(buffer);
                display = buffer.ToString();
            }
        }

        public bool hasDigitOverflow(double number)
        {
            int n = 0;
            string numString = number.ToString();
            for (int i = 0; i < numString.Length; i++)
            {
                if (numString[i] == '-') continue;
                if (Char.IsDigit(numString[i]))
                    n++;
            }
            if (n > 10)
            {
                return true;
            }
            return false;
        }

        public int numberOfWholeDigits(double number)
        {
            int n = 0;
            string numString = number.ToString();
            for (int i = 0; i < numString.Length; i++)
            {
                if (numString[i] == '-')
                    continue;
                if (Char.IsDigit(numString[i]))
                    n++;
                if (numString[i] == ',')
                    break;
            }
            return n;
        }

        public double round(double n)
        {
            if (!hasDigitOverflow(n))   // ako ima manje od 10 znamenaka
            {
                return n;
            }
            if (numberOfWholeDigits(n) > 10)    // ne stanu sve cjelobrojne znamenke na ekran
            {
                errorFlag = true;
            }
            int positive = n >= 0 ? 1 : -1;
            long g = (long)(n * (long)Math.Pow(10, 11 - numberOfWholeDigits(n))) * positive;
            int posljednja = (int)(g % 10);
            if (posljednja >= 5)
            {
                g += 10;
            }
            g -= posljednja;
            double z = g / Math.Pow(10, 11 - numberOfWholeDigits(n));
            return z * positive;
        }

        public void unarUpdate(char unar)
        {
            if (!bufferState)
            {   // izvodi se +=, -= *= ili /= 
                buffer = value;
                bufferState = true;
            }
            switch (unar)
            {
                case 'M':
                    buffer *= -1;
                    break;
                case 'S':
                    buffer = Math.Sin(buffer);
                    break;
                case 'K':
                    buffer = Math.Cos(buffer);
                    break;
                case 'T':
                    buffer = Math.Tan(buffer);
                    break;
                case 'Q':
                    buffer *= buffer;
                    break;
                case 'R':
                    buffer = Math.Sqrt(buffer);
                    break;
                case 'I':
                    if (Math.Abs(buffer) < 10e-6)   // provjera dijeljenja sa 0
                    {
                        errorFlag = true;
                        break;
                    }
                    buffer = 1 / buffer;
                    break;
                case '=':
                    if (!bufferState)
                    {   // izvodi se +=, -= *= ili /= 
                        buffer = value;
                        bufferState = true;
                    }
                    binaryUpdate();
                    break;
                default:
                    errorFlag = true;
                    break;
            }
            buffer = round(buffer);
            if (unar != 'M')
                wasLastUnar = true;
        }

        public void binaryUpdate()
        {
            if (!bufferState)
            {
                return;
            }

            switch (lastOperator)
            {
                case '+':
                    value += buffer;
                    break;
                case '-':
                    value -= buffer;
                    break;
                case '*':
                    value *= buffer;
                    break;
                case '/':
                    if (Math.Abs(buffer) < 10e-6)    // provjera dijeljenja sa 0
                    {
                        errorFlag = true;
                        break;
                    }
                    value /= buffer;
                    break;
                case ' ':
                    value = buffer;
                    break;
                default:
                    errorFlag = true;
                    break;
            }
            buffer = 0.0;
            bufferState = false;
            decimalState = 1.0;
            value = round(value);
            wasLastUnar = false;
        }

        public void controlUpdate(char control)
        {
            switch (control)
            {
                case 'P'://spremanje u memoriju
                    storedValue = buffer;
                    break;
                case 'G'://dohvaćanje iz memorije
                    buffer = storedValue;
                    break;
                case 'C':
                    clearDisplay();
                    break;
                case 'O':
                    clearDisplay();
                    storedValue = 0.0;
                    decimalState = 1.0;
                    value = 0.0;
                    lastOperator = ' ';
                    break;
                default:
                    errorFlag = true;
                    break;
            }
        }

        public void Press(char inPressedDigit)
        {
            if (Char.IsNumber(inPressedDigit))    // učitana brojka
            {
                if (inPressedDigit == '0' && (display.Contains(",") || (buffer.ToString().EndsWith("0"))))
                {
                    return; // ne ubacujemo nepotrebne 0
                }
                if (wasLastUnar)
                {
                    clearDisplay(); // ignoriramo zadnju unarnu operaciju ako smo nakon nje učitali broj
                }
                bufferState = true;
                if (decimalState == 1.0)
                    buffer *= 10;
                int predznak = buffer >= 0 ? 1 : -1;
                buffer += predznak * Double.Parse(inPressedDigit.ToString()) * decimalState;
                if (decimalState < 1.0)
                    decimalState *= 0.1;
            }
            if (unarniOperatori.Contains(inPressedDigit))   // učitan unarni operator
            {
                unarUpdate(inPressedDigit);
            }
            if (binarniOperatori.Contains(inPressedDigit))  // učitan binarni operator
            {
                binaryUpdate();
                lastOperator = inPressedDigit;
            }
            if (control.Contains(inPressedDigit))
            {
                controlUpdate(inPressedDigit);
            }
            if (inPressedDigit == ',')  // ako smo učitali zarez
            {
                decimalState = 0.1;
            }
        }

        public string GetCurrentDisplayState()
        {
            updateDisplay();
            return display;
        }

/*        public override string ToString() // za potrebe testiranja
        {
            return "display: " + display + ", value: " + value + ", buffer: " + buffer + ", lastOp: " + lastOperator + ", errorFlag: " + errorFlag;
        }*/
    }
}