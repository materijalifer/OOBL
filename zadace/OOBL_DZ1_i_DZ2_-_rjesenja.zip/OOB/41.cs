﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        bool biloJednako = false;

        private CalcDisplay display;
        public CalcDisplay Display { get { return display; } }

        private Operacija zadnjaOp;
        public Operacija ZadnjaOp { get { return zadnjaOp; } set { zadnjaOp = value; } }

        private Znak zadnjiZnak = null;

        private double screenSht = double.NaN;
        public double ScreenSht { get { return screenSht; } set { screenSht = value; } }

        private double memorija = 0;

        public Kalkulator()
        {
            this.display = new CalcDisplay();
        }

        public void Press(char inPressedDigit)
        {
            Znak noviZnak;
            try
            {
                noviZnak = new Znak(inPressedDigit);
            }
            catch (Exception)
            {

                display.Error();
                return;
            }
            
            analiza(noviZnak);
        }

        private void analiza(Znak noviZnak)
        {
            if (noviZnak.Tip == TipZnaka.IspisZnamenka)
                DodajNaDisplay(noviZnak);
            else
                izvrsiOperaciju(noviZnak);

            zadnjiZnak = noviZnak;

        }

        private void izvrsiOperaciju(Znak noviZnak)
        {
            List<char> binarneOp = new List<char>() { '+', '-', '/', '*' };
            List<char> unarneOp = new List<char>() { 'S', 'K', 'T', 'Q', 'R' , 'I'};
            if (binarneOp.Contains(noviZnak.Vrijednost))
            {
                if (binarneOp.Contains(zadnjiZnak.Vrijednost))
                {
                    zadnjaOp = FactoryOperacija.CreateOperacija(this, noviZnak);
                    return;
                }
                izvrsiBinarnuOperaciju(noviZnak);
            }

            else if (unarneOp.Contains(noviZnak.Vrijednost))
            {
                izvrsiUnarnuOperaciju(noviZnak);
            }
            else if (noviZnak.Vrijednost == 'P' || noviZnak.Vrijednost == 'G')
                izvrsiMemorijaOperaciju(noviZnak);

            else if (noviZnak.Vrijednost == 'C' || noviZnak.Vrijednost == 'O')
                izvrsiSustavnuOperaciju(noviZnak);

            else if (noviZnak.Vrijednost == '=')
                izvrsiJednakoOperaciju();

            else if (noviZnak.Vrijednost == ',')
                izvrsiZarezOperaciju();

            else if (noviZnak.Vrijednost == 'M')
                izvrsiNegOperaciju();

        }



        private void izvrsiSustavnuOperaciju(Znak noviZnak)
        {
            if (noviZnak.Vrijednost == 'C')
                ResetC();
            else if (noviZnak.Vrijednost == 'O')
            {
                ResetO();
                memorija = 0;
            }
        }

        private void ResetC()
        {
            display.Reset();
        }

        private void ResetO()
        {
            biloJednako = false;
            display = new CalcDisplay();
            zadnjaOp = null;
            zadnjiZnak = null;
            screenSht = double.NaN;
            memorija = 0;
        }

        private void izvrsiMemorijaOperaciju(Znak noviZnak)
        {
            if (noviZnak.Vrijednost == 'P')
                memorija = display.ToDouble();
            else if (noviZnak.Vrijednost == 'G')
                display.Dodaj(memorija);
        }


        private void izvrsiNegOperaciju()
        {
            Znak minus = new Znak("/-");
            display.Dodaj(minus);
        }

        private void izvrsiZarezOperaciju()
        {
            Znak zarez = new Znak("/,");
            display.Dodaj(zarez);
        }

        private void izvrsiJednakoOperaciju()
        {
            double temp = double.NaN;
            if (!biloJednako)
            {
                temp = display.ToDouble();
            }
            if (zadnjaOp != null)
            {
                if (biloJednako)
                    display.Dodaj((zadnjaOp as BinarnaOperacija).Funkcija(display.ToDouble(), screenSht));
                else
                    display.Dodaj((zadnjaOp as BinarnaOperacija).Funkcija(screenSht, display.ToDouble()));
            }
            if (!double.IsNaN(temp))
                screenSht = temp;

            biloJednako = true;
            if (display.ToString() != "-E-")
                display.Dodaj(display.ToDouble());
            display.ZaReset = true;
        }

        private void izvrsiBinarnuOperaciju(Znak noviZnak)
        {
            if (biloJednako)
            {
                zadnjaOp = null;
                biloJednako = false;
            }
            if (!Double.IsNaN(screenSht) && zadnjaOp != null)
            {
                display.Dodaj((zadnjaOp as BinarnaOperacija).Funkcija(screenSht, display.ToDouble()));
            }

            zadnjaOp = FactoryOperacija.CreateOperacija(this, noviZnak);
            screenSht = display.ToDouble();
            //display.Dodaj(display.ToDouble());
            display.ZaReset = true;
        }


        private void izvrsiUnarnuOperaciju(Znak noviZnak)
        {
            display.Dodaj(((FactoryOperacija.CreateOperacija(this, noviZnak)) as UnarnaOperacija).Funkcija(display.ToDouble()));
            display.ZaReset = true;
        }

        private void DodajNaDisplay(Znak znak)
        {
            display.Dodaj(znak);
        }

        public string GetCurrentDisplayState()
        {
            return display.ToString();
        }
    }

    public class Znak
    {
        List<char> ZNAMENKE = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        List<string> SPECZNAKOVI = new List<string>() { "/-", "/," };
        List<char> OPERACIJE = new List<char>() { '+', '-', '*', '/', '=', ',', 'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G', 'C', 'O' };

        char vrijednost;
        TipZnaka tip;

        public char Vrijednost { get { return vrijednost; } set { vrijednost = value; } }
        public TipZnaka Tip { get { return tip; } set { tip = value; } }

        public Znak(char vrijednost)
        {
            this.vrijednost = vrijednost;

            if (ZNAMENKE.Contains(vrijednost))
                tip = TipZnaka.IspisZnamenka;
            else if (OPERACIJE.Contains(vrijednost))
                tip = TipZnaka.Operacija;
            else
                throw new Exception("-E-");
        }

        public Znak(string vrijednost)
        {
            if (SPECZNAKOVI.Contains(vrijednost))
            {
                this.vrijednost = vrijednost[1];
                this.tip = TipZnaka.IspisSpecZnak;
            }
            else
                throw new Exception("-E-");
        }



    }

    class Zbrajanje : BinarnaOperacija
    {

        public Zbrajanje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x, double y)
        {
            return x + y;
        }
    }

    public abstract class UnarnaOperacija : Operacija
    {
        public UnarnaOperacija(Kalkulator kalk)
            : base(kalk)
        { }

        public abstract double Funkcija(double x);
    }

    public enum TipZnaka
    {
        IspisZnamenka,
        IspisSpecZnak,
        Operacija,
    }

    class Tangens : UnarnaOperacija
    {
        public Tangens(Kalkulator kalk)
            : base(kalk)
        { }


        public override double Funkcija(double x)
        {
            return Math.Tan(x);
        }
    }

    class Sinus : UnarnaOperacija
    {
        public Sinus(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x)
        {
            return Math.Sin(x);
        }
    }

    public abstract class Operacija
    {
        protected Kalkulator kalk;

        public Operacija(Kalkulator kalk)
        {
            this.kalk = kalk;
        }
    }

    class Oduzimanje : BinarnaOperacija
    {

        public Oduzimanje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x, double y)
        {
            return x - y;
        }
    }

    class Mnozenje : BinarnaOperacija
    {
        public Mnozenje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x, double y)
        {
            return x * y;
        }
    }

    class Kvadriranje : UnarnaOperacija
    {
        public Kvadriranje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x)
        {
            return Math.Pow(x, 2);
        }
    }

    class Kosinus : UnarnaOperacija
    {
        public Kosinus(Kalkulator kalk)
            : base(kalk)
        { }


        public override double Funkcija(double x)
        {
            return Math.Cos(x);
        }
    }

    class Korjenovanje : UnarnaOperacija
    {
        public Korjenovanje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x)
        {
            return Math.Sqrt(x);
        }
    }

    class Inverz : UnarnaOperacija
    {
        public Inverz(Kalkulator calc)
            : base(calc)
        { }

        public override double Funkcija(double x)
        {
            return 1 / x;
        }
    }

    public static class FactoryOperacija
    {
        public static Operacija CreateOperacija(Kalkulator kalk, Znak znak)
        {
            if (znak.Vrijednost == '+')
                return CreateZbrajanjeOperacija(kalk);
            else if (znak.Vrijednost == '-')
                return CreateOduzimanjeOperacija(kalk);
            else if (znak.Vrijednost == '*')
                return CreateMnozenjeOperacija(kalk);
            else if (znak.Vrijednost == '/')
                return CreateDijeljenjeOperacija(kalk);
            else if (znak.Vrijednost == 'S')
                return CreateSinusOperacija(kalk);
            else if (znak.Vrijednost == 'K')
                return CreateKosinusOperacija(kalk);
            else if (znak.Vrijednost == 'T')
                return CreateTangensOperacija(kalk);
            else if (znak.Vrijednost == 'Q')
                return CreateKvadriranjeOperacija(kalk);
            else if (znak.Vrijednost == 'R')
                return CreateKorijenovanjeOperacija(kalk);
            else if (znak.Vrijednost == 'I')
                return CreateInverzOperacija(kalk);

            else
                return null;
        }

        private static Operacija CreateInverzOperacija(Kalkulator kalk)
        {
            return new Inverz(kalk);
        }

        private static Operacija CreateKorijenovanjeOperacija(Kalkulator kalk)
        {
            return new Korjenovanje(kalk);
        }

        private static Operacija CreateKvadriranjeOperacija(Kalkulator kalk)
        {
            return new Kvadriranje(kalk);
        }

        private static Operacija CreateKosinusOperacija(Kalkulator kalk)
        {
            return new Kosinus(kalk);
        }

        private static Operacija CreateTangensOperacija(Kalkulator kalk)
        {
            return new Tangens(kalk);
        }

        private static Operacija CreateSinusOperacija(Kalkulator kalk)
        {
            return new Sinus(kalk);
        }

        private static Operacija CreateDijeljenjeOperacija(Kalkulator kalk)
        {
            return new Dijeljenje(kalk);
        }

        private static Operacija CreateMnozenjeOperacija(Kalkulator kalk)
        {
            return new Mnozenje(kalk);
        }

        private static Operacija CreateOduzimanjeOperacija(Kalkulator kalk)
        {
            return new Oduzimanje(kalk);
        }

        private static Operacija CreateZbrajanjeOperacija(Kalkulator kalk)
        {
            return new Zbrajanje(kalk);
        }
    }

    class Dijeljenje : BinarnaOperacija
    {

        public Dijeljenje(Kalkulator kalk)
            : base(kalk)
        { }

        public override double Funkcija(double x, double y)
        {
            return x / y;
        }
    }

    public class CalcDisplay
    {
        private string znakoviNaEkranu;
        private bool jePocetnoStanje;
        private bool zaResetirat;
        public bool ZaReset { get { return zaResetirat; } set { zaResetirat = value; } }

        public CalcDisplay()
        {
            this.znakoviNaEkranu = String.Empty;
            znakoviNaEkranu += '0';
            jePocetnoStanje = true;
        }

        public void Reset()
        {
            this.znakoviNaEkranu = String.Empty;
            znakoviNaEkranu += '0';
            jePocetnoStanje = true;
            zaResetirat = false;
        }

        public void Dodaj(double value)
        {
            if (double.IsInfinity(value))
            {
                znakoviNaEkranu = "-E-";
                return;
            }
            Reset();
            string zaDodati;
            string vrijednost = value.ToString();
            string[] splitano = vrijednost.Split(',');
            string prijeZareza = splitano[0];
            string poslijeZareza;
            try
            {
                poslijeZareza = splitano[1];
            }
            catch (Exception)
            {
                poslijeZareza = "";
            }

            int znamenkiprijeZareza = prijeZareza.Count(z => z != '-');
            if (znamenkiprijeZareza > 10)
            {
                Error();
                return;
            }
            else if (poslijeZareza.Count() == 0)
                zaDodati = prijeZareza;
            else
                zaDodati = Math.Round(value, 10 - znamenkiprijeZareza).ToString();

            foreach (char c in zaDodati)
            {
                if (c == '-')
                    Dodaj(new Znak("/-"));
                else if (c == ',')
                    Dodaj(new Znak("/,"));
                else
                    Dodaj(new Znak(c));
            }
        }

        public void Error()
        {
            znakoviNaEkranu = "-E-";
        }

        public void Dodaj(Znak znak)
        {
            if (zaResetirat && (znak.Tip == TipZnaka.IspisZnamenka || znak.Vrijednost == ','))
                Reset();


            if (znak.Tip == TipZnaka.IspisSpecZnak)
                dodajSpecZnak(znak.Vrijednost);  //za dodavanje '-' i ','
            else if (znak.Tip == TipZnaka.IspisZnamenka && !isFull())
                dodajZnamenku(znak.Vrijednost);  //za dodavanje znamenki
            else
                return;

        }

        private void dodajZnamenku(char znak)
        {
            if (znak == '0')   //znak 0 dodajemo samo ako nismo u pocetnom stanju
            {
                if (mozesDodatiNulu())
                    dodajNaHead(znak);
            }
            else
            {
                if (jePocetnoStanje)   //ako je pocetno stanje nova znamenka zamnjenjuje nulu
                {
                    noviHead(znak);
                    jePocetnoStanje = false;
                }
                else
                    dodajNaHead(znak);   //inače se samo dodaje na displej
            }
        }
        private void dodajSpecZnak(char znak)
        {
            if (mozesDodatiSpecZnak(znak)) //specijalni znak dodajemo samo ako ga već nema na ekranu
            {
                if (znak == '-')   //minus znak će uvijek biti prvi znak
                {
                    string temp;
                    if (znakoviNaEkranu == "0")
                        temp = "";
                    else
                        temp = znakoviNaEkranu;
                    noviHead(znak);
                    znakoviNaEkranu += temp;
                }
                else
                    if (!isFull())
                        dodajNaHead(znak);  //zarez se uvijek dodaje iza svega na displeju

                if (jePocetnoStanje)
                    jePocetnoStanje = false;
            }
            else
                return;
        }
        private void noviHead(char znak)
        {
            //postavljanje prvog znaka na displeju
            znakoviNaEkranu = "";
            znakoviNaEkranu += znak;
        }
        private void dodajNaHead(char znak)
        {
            //appendanje na displej
            znakoviNaEkranu += znak;
        }
        private bool mozesDodatiNulu()
        {
            //nulu mozemo dodati samo ako nismo u pocetnom stanju
            if (jePocetnoStanje)
                return false;
            else
                return true;
        }
        private bool mozesDodatiSpecZnak(char znak)
        {
            //znak dodajemo samo ako ga vec nema na ekranu (nemožemo imati 2 zareza)
            if (znakoviNaEkranu.Contains(znak))
            {
                if (znak == '-')
                    znakoviNaEkranu = znakoviNaEkranu.Remove(0, 1);
                return false;
            }
            else
                return true;
        }
        private bool isFull()
        {
            //dodajemo znakove samo ako displej nije pun
            if (znakoviNaEkranu.Count(z => ((z != ',') && (z != '-'))) < 10)
                return false;
            else
                return true;
        }
        public override string ToString()
        {
            return znakoviNaEkranu;
        }



        public double ToDouble()
        {
            return Convert.ToDouble(znakoviNaEkranu);
        }
    }

    public abstract class BinarnaOperacija : Operacija
    {

        public BinarnaOperacija(Kalkulator kalk)
            : base(kalk)
        { }

        public abstract double Funkcija(double x, double y);
    }
}

   



    

