﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
    
    //definicija razreda Dionica
    public class Dionica
    {
        //public varijable 
        public string ImeDionice;
        public long BrojDionica;
        public Decimal PocetnaCijena;
        public DateTime DatumNastanka;
        public DateTime DatumZadnjePromCijene;
        public Decimal ZadnjaCijena;
   
        //konstruktor
        public Dionica(string imeDionice, long brojDionica, Decimal pocetnaCijena, DateTime datumNastanka)
        {
            ImeDionice = imeDionice;
            BrojDionica = brojDionica;
            PocetnaCijena = pocetnaCijena;
            DatumNastanka = datumNastanka;
        }

        //metoda koja postavlja novu cijenu i datum promjene cijene
        public void  PromjenaCijene (decimal novaCijena, DateTime datumPromjene)
        {
            ZadnjaCijena = novaCijena;
            DatumZadnjePromCijene = datumPromjene;
        }
    }


    //definicija razreda Index
    public class Index
    {
        //public varijable
        public string ImeIndexa;
        public IndexTypes TipIndexa;
        public Dictionary<string, Dionica> DioniceUIndeksu = new Dictionary<string, Dionica>();

        //Konstruktor
        public Index(string imeIndexa, IndexTypes tipIndexa)
        {
            if (!Enum.IsDefined(typeof(IndexTypes), tipIndexa))
            {
                throw new StockExchangeException("Tip indexa ne postoji");
            }
            ImeIndexa = imeIndexa;
            TipIndexa = tipIndexa;
        }       

        //metoda koja dodaje dionice u index, tj. u dictionary koji se nalazi u Index-u
        public void DodajDionicuUIndex (Dionica dionica)
        {
            if (DioniceUIndeksu.ContainsKey(dionica.ImeDionice.ToUpper()))
                throw new StockExchangeException("Vec postoji ista dionica u indexu");
            DioniceUIndeksu.Add(dionica.ImeDionice.ToUpper(), dionica);
        }

        //metoda koja briše dionice iz indexa,isto kao i metoda koja dodaje dionice mijenja dictionary
        public void BrisiDionicuIzIndexa(string imeDionice)
        {
            if (!DioniceUIndeksu.ContainsKey(imeDionice.ToUpper()))
                throw new StockExchangeException("Nepostojeca dionica u indeksu");
            DioniceUIndeksu.Remove(imeDionice.ToUpper());
        }
    }

    //definicija klase Portfelj
    public class Portfelj
    {
        //public varijable
        public string Id;

        // Konstruktor
        public Portfelj(string id)
        {
            Id = id;
        }
    }
    

    public class StockExchange : IStockExchange
     {
        //public liste i dictionary koji sluze za pohranu dionica, indexa i portfelja
        public List<Dionica> Burza= new List<Dionica>();
        public Dictionary<string, Index> BurzaIndex = new Dictionary<string, Index>();
        public Dictionary<string, Portfelj> BurzaPortfelj = new Dictionary<string, Portfelj>();

         #region Stock metode

         //dodaje dionicu s početnom cijenom na burzu, stavlja je u listu svih dionica na burzi
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
            var item = Burza.FirstOrDefault(o => o.ImeDionice == inStockName);
            if (inNumberOfShares > 0 && inInitialPrice > 0 && item == null)              
            {
                Burza.Add(new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
            {
                throw new StockExchangeException("Greska pri unosu dionica");
            }
         }

         //briše dionicu s burze, brise je sa liste svih dionica na burzi
         public void DelistStock(string inStockName)
         {
             foreach (Dionica d in Burza)
             {
                 if (d.ImeDionice == inStockName)
                 {
                     Burza.Remove(d);
                 }
                 else
                 {
                     throw new StockExchangeException("Ne postoji dionica sa tim imenom");
                 }
             }
         }

        //provjerava dali postoji dionica sa tim imenom na listi burze
         public bool StockExists(string inStockName)
         {
             foreach (Dionica d in Burza)
             {
                 if (d.ImeDionice == inStockName) return true;
             }
             return false;
         }

        //metoda koja broji koliko se dionica nalazi na listi burze
         public int NumberOfStocks()
         {
             var brojac = 0;
             foreach (Dionica d in Burza)
             {
                 brojac++;
             }
             return brojac;
 
         }

        //metoda koja postavlja novu cijenu dionice u nekom trenutku
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {

             foreach (Dionica d in Burza)
             {
                 if (d.ImeDionice == inStockName)
                 {
                     d.PromjenaCijene(inStockValue, inIimeStamp);
                 }
                 else
                 {
                     throw new StockExchangeException("Ne postoji dionica sa tim imenom");
                 }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             throw new NotImplementedException();
         }

        //metoda koja vraca početnu cijenu neke dionice
         public decimal GetInitialStockPrice(string inStockName)
         {
    
             foreach (Dionica d in Burza)
             {
                 if (d.ImeDionice == inStockName)
                     return d.PocetnaCijena;             
             }
             throw new StockExchangeException("Ne postoji dionica sa tim imenom");

         }

        //metoda koja vraca zadnju cijenu neke dionice
         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Dionica d in Burza)
             {
                 if (d.ImeDionice == inStockName)              
                     return d.ZadnjaCijena;
             }
             throw new StockExchangeException("Ne postoji dionica sa tim imenom");
         }
         #endregion
     
         #region Index metode

        //metoda koja stvara novi inex i dodaje ga u dictionary BurzaIndexa
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!BurzaIndex.ContainsKey(inIndexName.ToUpper()))
             {
                 BurzaIndex.Add(inIndexName.ToUpper(), new Index(inIndexName, inIndexType));
             }
             else
             {
                 throw new StockExchangeException("Index sa tim imenom vec postoji");
             }
         }

        //metoda koja dodaje dionicu u neki index
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             try
             {
                 var item = Burza.Find(o => o.ImeDionice == inStockName);
                 BurzaIndex[inIndexName.ToUpper()].DodajDionicuUIndex(item);  
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Neuspjesno dodavanje dionice u index");
             }
         }

        
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             throw new NotImplementedException();
         }

        //metoda koja provjerava dali se neka dionica nalazi u trazenom indexu
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             try
             {
                 return BurzaIndex[inIndexName.ToUpper()].DioniceUIndeksu.ContainsKey(inStockName.ToUpper());
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Neuspjesno");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             throw new NotImplementedException();
         }

        //metoda koja provjerava dali postoji traženi index
         public bool IndexExists(string inIndexName)
         {            
             return BurzaIndex.ContainsKey(inIndexName.ToUpper());
         }

        //metoda koja broji koliko se indexa nalazi u BurzaIndex dictionary-u
         public int NumberOfIndices()
         {
             return BurzaIndex.Count();
         }

        //metoda koja broji koliko se dionica nalazi u nekom indexu
         public int NumberOfStocksInIndex(string inIndexName)
         {
             return BurzaIndex[inIndexName.ToUpper()].DioniceUIndeksu.Count;
         }

         #endregion

         #region Portfelj metode
         public void CreatePortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         //metoda koja broji koliko se Portfelja nalazi u BurzaPortfelj dictionary-u
         public int NumberOfPortfolios()
         {
             return BurzaPortfelj.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         //metoda koja provjerava dali se nalazi točno određeni portfelj u BurzaPortfelj dictionary-u
         public bool PortfolioExists(string inPortfolioID)
         {
             return BurzaPortfelj.ContainsKey(inPortfolioID.ToUpper());
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }

         #endregion
     }
}
