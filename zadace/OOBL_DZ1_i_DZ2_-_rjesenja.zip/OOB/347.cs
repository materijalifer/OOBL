using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockHistory
    {
        public DateTime beginning;
        public Decimal price;

        public StockHistory(DateTime inBeginning, Decimal price)
        {
            this.beginning = inBeginning;
            this.price = price;
        }
    }
    public class Stock
    {
        public string stockName;
        public long numberOfShares;
        public Decimal initialPrice;
        public Decimal currentPrice;
        public DateTime TimeStamp;
        public List<StockHistory> stockHistory = new List<StockHistory>();

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.stockName = inStockName.ToUpper();
            this.numberOfShares = inNumberOfShares;
            this.initialPrice = inInitialPrice;
            this.currentPrice = inInitialPrice;
            this.TimeStamp = inTimeStamp;
            stockHistory.Add(new StockHistory(inTimeStamp, inInitialPrice));
        }

        
    }
    public class Index
    {
        public IndexTypes type;
        public string indexName;
        public decimal indexValue;
        public Dictionary<string, Stock> indexStocks = new Dictionary<string, Stock>();

        public Index(string inIndexName, IndexTypes inType)
        {
            this.indexName = inIndexName.ToUpper();
            this.type = inType;
        }
        public void calculateValue()
        {
            if (this.type == IndexTypes.AVERAGE) indexCalculationAVG();
            else if (this.type == IndexTypes.WEIGHTED) indexCalculationWGHT();
        }
        private void indexCalculationWGHT()
        {
            decimal totalStockIndexPrice = 0;
            foreach (Stock _stock in indexStocks.Values)
            {
                totalStockIndexPrice += _stock.currentPrice*_stock.numberOfShares;
            }

            decimal weightedAverage = 0;
            foreach (Stock _stock in indexStocks.Values)
            {
                decimal weightFactor = (_stock.currentPrice*_stock.numberOfShares)/totalStockIndexPrice;
                weightedAverage += weightFactor*_stock.currentPrice;
            }
            this.indexValue = Math.Round(weightedAverage, 3);
        }
        private void indexCalculationAVG()
        {
            decimal sum = 0;
            long count = 0;
            foreach (Stock stock in indexStocks.Values)
            {
                count += 1;
                sum += stock.currentPrice;
            }
            if (count == 0) this.indexValue = 0;
            else this.indexValue = Math.Round(sum/count, 3);}
    }
    public class PortfolioElement
    {
        public Stock stock;
        public int quantity = 0;

        public PortfolioElement(Stock inStock, int inQuantity)
        {
            this.stock = inStock;
            this.quantity = inQuantity;
        }
    }
    public class Portfolio
    {
        public string portfolioID;
        public Dictionary<string, PortfolioElement> portfolioElements = new Dictionary<string, PortfolioElement>();
        
        public Portfolio(string inPortfolioId)
        {
            this.portfolioID = inPortfolioId;
        }
    }

    public class StockExchange : IStockExchange
    {
        public Dictionary<string, Stock> Stocks = new Dictionary<string, Stock>();        
        public Dictionary<string, Index> Indices = new Dictionary<string, Index>();
        public Dictionary<string, Portfolio> Portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName)) throw new StockExchangeException("Stock already exists on StockExchange.");
            else if (inInitialPrice <= 0) throw new StockExchangeException("Initial price must be greater than 0.");
            else if (inNumberOfShares <= 0) throw new StockExchangeException("Number of shares must be greater than 0.");
            else Stocks.Add(inStockName.ToUpper(), new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp));
        }
        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Can't delist nonexistent stock.");
            else
            {
                Stocks.Remove((inStockName.ToUpper()));
                foreach (Index index in Indices.Values)
                {
                    if (index.indexStocks.ContainsKey(inStockName.ToUpper()))
                        index.indexStocks.Remove(inStockName.ToUpper());
                }
                foreach (Portfolio portfolio in Portfolios.Values)
                {
                    if (portfolio.portfolioElements.ContainsKey(inStockName.ToUpper()))
                        portfolio.portfolioElements.Remove(inStockName.ToUpper());
                }
            }
            
            
        }   
        public bool StockExists(string inStockName)
        {
            if (Stocks.ContainsKey(inStockName.ToUpper())) return true;
            else return false;
        }
        public int NumberOfStocks()
        {
            return Stocks.Count;
        }
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (inIimeStamp < Stocks[inStockName.ToUpper()].stockHistory[0].beginning) throw new StockExchangeException("Stock didn't exist then.");
            if (inStockValue <= 0) throw new StockExchangeException("New stock value not allowed.");
            Stocks[inStockName.ToUpper()].stockHistory.Add(new StockHistory(inIimeStamp, inStockValue));
            Stocks[inStockName.ToUpper()].currentPrice = inStockValue;
        }      
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            Stock temp = Stocks[inStockName.ToUpper()];
            int stockHistLen = temp.stockHistory.Count;
            if (inTimeStamp < Stocks[inStockName.ToUpper()].stockHistory[0].beginning)
                throw new StockExchangeException("Stock price is not defined for specified time.");
            if (inTimeStamp > temp.stockHistory[stockHistLen - 1].beginning)
            {
                return temp.currentPrice;
            }
            else
            {
                int br = 0;
                for (int i = 0; i < stockHistLen; i++)
                    if (inTimeStamp > temp.stockHistory[i].beginning)
                    {
                        br = i - 1;
                        break;
                    }
                return temp.stockHistory[br + 1].price;
            }
            
        }       
        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            return Stocks[inStockName.ToUpper()].initialPrice;
        }       
        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            return Stocks[inStockName.ToUpper()].currentPrice;
        }
        
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName)) throw new Exception("Index already exists.");
            Indices.Add(inIndexName.ToUpper(), new Index(inIndexName.ToUpper(), inIndexType));
        }
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName)) throw new Exception("Index doesn't exists.");
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (Indices[inIndexName.ToUpper()].indexStocks.ContainsKey(inStockName.ToUpper()))
                throw new StockExchangeException("Stock already exists in index.");
            Indices[inIndexName.ToUpper()].indexStocks.Add(inStockName.ToUpper(), Stocks[inStockName.ToUpper()]);
        }
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            
            if (!IndexExists(inIndexName)) throw new Exception("Index doesn't exists.");
            if (!Indices[inIndexName.ToUpper()].indexStocks.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Stock doesn't exist.");
            Indices[inIndexName.ToUpper()].indexStocks.Remove(inStockName.ToUpper());
        }
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (!IndexExists(inIndexName)) throw new Exception("Index doesn't exists.");
            if (Indices[inIndexName.ToUpper()].indexStocks.ContainsKey(inStockName.ToUpper())) return true;
            else return false;
        }
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName)) throw new Exception("Index doesn't exists.");
            Indices[inIndexName.ToUpper()].calculateValue();
            return Indices[inIndexName.ToUpper()].indexValue;
        }
        public bool IndexExists(string inIndexName)
        {
            if (Indices.ContainsKey(inIndexName.ToUpper())) return true;
            else return false;
        }
        public int NumberOfIndices()
        {
            return Indices.Count;
        }
        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName)) throw new Exception("Index doesn't exists.");
            return Indices[inIndexName.ToUpper()].indexStocks.Count;
        }
        
        public void CreatePortfolio(string inPortfolioID)
        {
            if (Portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID already exists.");
            else Portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            if (Portfolios[inPortfolioID].portfolioElements.ContainsKey(inStockName.ToUpper()))
            {
                int sum = 0;
                foreach (Portfolio portfolio in Portfolios.Values)
                {
                    if (portfolio.portfolioElements.ContainsKey(inStockName.ToUpper()))
                        sum += portfolio.portfolioElements[inStockName.ToUpper()].quantity;
                }
                if (sum + numberOfShares > Stocks[inStockName.ToUpper()].numberOfShares)
                    throw new StockExchangeException("Too many shares.");
                Portfolios[inPortfolioID].portfolioElements[inStockName.ToUpper()].quantity += numberOfShares;
            }
            else
            {
                if (numberOfShares > Stocks[inStockName.ToUpper()].numberOfShares)
                    throw new StockExchangeException("Too many shares.");
                PortfolioElement temp = new PortfolioElement(Stocks[inStockName.ToUpper()], numberOfShares);
                Portfolios[inPortfolioID].portfolioElements.Add(inStockName.ToUpper(), temp);
            }
        }
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            if (!Portfolios[inPortfolioID].portfolioElements.ContainsKey(inStockName.ToUpper())) 
                throw new StockExchangeException("Portfolio doesn't contain stock.");
            else
            {
                Portfolios[inPortfolioID].portfolioElements[inStockName.ToUpper()].quantity -= numberOfShares;
                if (Portfolios[inPortfolioID].portfolioElements[inStockName.ToUpper()].quantity <= 0)
                    Portfolios[inPortfolioID].portfolioElements.Remove(inStockName.ToUpper());
            }
            
        }
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            else
            {
                Portfolios[inPortfolioID].portfolioElements.Remove(inStockName.ToUpper());    
            }
        }
        public int NumberOfPortfolios()
        {
            return Portfolios.Count;
        }
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            else return Portfolios[inPortfolioID].portfolioElements.Count;
        }
        public bool PortfolioExists(string inPortfolioID)
        {
            if (Portfolios.ContainsKey(inPortfolioID)) return true;
            else return false;
        }
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            else
            {
                if (Portfolios[inPortfolioID].portfolioElements.ContainsKey(inStockName.ToUpper())) return true;
                else return false;
            }
        }
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            return Portfolios[inPortfolioID].portfolioElements[inStockName.ToUpper()].quantity;
            
        }
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio doesn't exist.");
            decimal sum = 0;
            foreach (PortfolioElement portElement in Portfolios[inPortfolioID].portfolioElements.Values)
            {
                int stockCount = portElement.quantity;
                decimal stockValue;
                try
                {
                    stockValue = GetStockPrice(portElement.stock.stockName.ToUpper(), timeStamp);
                }
                catch (Exception)
                {
                    throw new StockExchangeException("Stock doesn't exist for specifies time period.");
                }
                sum += stockCount * stockValue;
            }
            return sum;
        }
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal startOfMonth = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0,0,0,0));
            DateTime lastDayOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            decimal endOfMonth = GetPortfolioValue(inPortfolioID, lastDayOfMonth);
            return Math.Round(((endOfMonth / startOfMonth) - 1) * 100);
        }
    }
}
