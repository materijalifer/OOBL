﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    class PromjeneCijeneDionica : IComparable
    {
        public DateTime pocetak;
        public DateTime kraj;
        public decimal cijena;

        public int CompareTo(object x)
        {
            PromjeneCijeneDionica y = (PromjeneCijeneDionica) x;
            return pocetak.CompareTo(y.pocetak);
        }
    }

    public class Dionica
     {
         public string ime;
         private DateTime zadnjaPromjena;
         private List<PromjeneCijeneDionica> promjene = new List<PromjeneCijeneDionica>();

        public long brDionica;
        public int preostaleDionice;

        private decimal cijena;
        public decimal tezinskiFaktor;

        public Dionica(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.ime = inStockName;
            this.brDionica = inNumberOfShares;
            this.cijena = inInitialPrice;
            this.zadnjaPromjena = inTimeStamp;
            this.preostaleDionice = (int) inNumberOfShares;
        }

        public Dionica()
        {
        }

        public Dionica(string inStockName, long inNumberOfShares)
        {
            this.ime = inStockName;
            this.brDionica = inNumberOfShares;
        }

        public void PostaviNovuCijenu(decimal cijena, DateTime vrijemePromjene)
        {
            foreach (var promjeneCijeneDionica in promjene)
            {
                if (promjeneCijeneDionica.kraj == vrijemePromjene || promjeneCijeneDionica.pocetak == vrijemePromjene || (vrijemePromjene > promjeneCijeneDionica.pocetak && vrijemePromjene < promjeneCijeneDionica.kraj))
                {
                    throw  new StockExchangeException("Greska!");
                }
            }
            PromjeneCijeneDionica novaPromjena = new PromjeneCijeneDionica();
            novaPromjena.cijena = this.cijena;
            novaPromjena.pocetak = this.zadnjaPromjena;
            novaPromjena.kraj = vrijemePromjene;
            promjene.Add(novaPromjena);
            this.cijena = cijena;
            this.zadnjaPromjena = vrijemePromjene;

        }

        public decimal VratiCijenuUVremenu(DateTime vrijeme)
        {
            decimal cijenaUVremenu = 0;
            foreach (PromjeneCijeneDionica p in promjene)
            {
                if (vrijeme < p.kraj && vrijeme > p.pocetak)
                {
                    cijenaUVremenu = p.cijena;
                }

            }
            
                if (cijenaUVremenu == 0)
                {
                    if (vrijeme >= zadnjaPromjena && vrijeme < DateTime.Now)
                    {
                        cijenaUVremenu = cijena;
                    }

                    //if (vrijeme < DateTime.Now)
                    //{
                    //    cijenaUVremenu = cijena;
                    //}

                     else throw  new StockExchangeException("Ne postoji podatak o cijeni za to vremensko razdoblje.");
                }
               
            
            return cijenaUVremenu;
        }


        public decimal VratiInicijalnuCijenu()
        {
            promjene.Sort();
            return promjene.First().cijena;
        }


        public decimal VratiZadnjuCijenu()
        {
            return this.cijena;
            //promjene.Sort();
            //return promjene.Last().cijena;
        }

     }

    public class Indeks
    {
        public string ime;
        private IndexTypes _tip;
        List<Dionica> dionice = new List<Dionica>();
        private decimal vrijednost;

       

        public Indeks(string ime, IndexTypes tip)
        {
            this.ime = ime;

            if (tip != IndexTypes.AVERAGE && tip != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Unos nepostojeceg tipa indeksa.");
            }
            else
            {
                _tip = tip;
            }

            this.vrijednost = 0;
        }

        public Indeks()
        {
            this.vrijednost = 0;
        }

        public decimal VratiVrijednostIndeksa(DateTime timeStamp)
        {
            decimal total = 0;
            if (dionice.Count > 0)
            {
                if (_tip == IndexTypes.AVERAGE)
                {
                    total = dionice.Average(d => d.VratiCijenuUVremenu(timeStamp));

                }

                if (_tip == IndexTypes.WEIGHTED)
                {
                    foreach (Dionica d in dionice)
                    {
                        total += d.VratiCijenuUVremenu(timeStamp)*d.brDionica;

                    }

                    foreach (Dionica d in dionice)
                    {
                        d.tezinskiFaktor = (decimal) d.VratiCijenuUVremenu(timeStamp)/total;
                    }


                    total = 0;

                    foreach (Dionica d in dionice)
                    {
                        total += d.VratiCijenuUVremenu(timeStamp)*d.tezinskiFaktor*d.brDionica;
                    }

                }

            }
            return Math.Round(total, 0);
        }


        public void DodajDionicuIndeksu(Dionica novaDionica)
        {
            if (DionicaUIndeksu(novaDionica))
            {
                throw  new StockExchangeException("Dionica je vec u indeksu!");
            }
            dionice.Add(novaDionica);
        }

        public void MakniDionicuIzIndeksa(Dionica dionicaZaMicanje)
        {
            if (dionice.Contains(dionicaZaMicanje))
            {
                dionice.Remove(dionicaZaMicanje);
            }
        }

        public bool DionicaUIndeksu(Dionica d)
        {
            return dionice.Contains(d);
        }

        public int BrojDionicaUIndeksu()
        {
            return dionice.Count();
        }


    }

    public class Portfolio
    {
        public string idPortfelja;
        //private List<Dionica> dionicePortfelja;
        private Dictionary<Dionica, int> dionicePortfelja;


        public Portfolio()
        {
        }


        public Portfolio (string id)
        {
            this.idPortfelja = id;
            dionicePortfelja = new Dictionary<Dionica, int>();
            
        }

        public void DodajDionicuPortfelju(Dionica d, int broj)
        {
            if (broj > 0)
            {
                if (DionicaUPortfelju(d))
                {
                    dionicePortfelja[d] += broj;
                }
                else
                {
                    dionicePortfelja[d] = broj;
                }
            }
            else throw  new StockExchangeException("Negativan broj dionica.");



        }

        public void MakniDionicuIzPortfelja(Dionica d)
        {
            if (dionicePortfelja.ContainsKey(d))
            {
                dionicePortfelja.Remove(d);
            }
        }

        public void PromijeniBrDionica(Dionica d, int broj)
        {
            int rez = dionicePortfelja[d] - broj;
            if (rez > 0)
            {
                dionicePortfelja[d] -= broj;
            }
            else
            {
                dionicePortfelja.Remove(d);
            }

        }

        public int VratiBrojDionica()
        {
            return dionicePortfelja.Count();
        }

        public bool DionicaUPortfelju(Dionica d)
        {
            return dionicePortfelja.ContainsKey(d);

        }

        public int BrDionicaDionice(Dionica  dionica)
        {
            if (DionicaUPortfelju(dionica))
            {
                return dionicePortfelja[dionica];
            }
            else return 0;


        }

        public decimal VrijednostPortfelja(DateTime timestamp)
        {
            decimal total = 0;

            foreach (var x in dionicePortfelja)
            {
                total += x.Key.VratiCijenuUVremenu(timestamp)*x.Value;
            }

            return total;

        }
    }




    public class StockExchange : IStockExchange
     {
         List<Dionica> dioniceBurze = new List<Dionica>();
        List< Indeks> indeksi = new List<Indeks>(); 
        List<Portfolio> portfolios = new List<Portfolio>(); 


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 if (inInitialPrice > 0)
                 {
                     Dionica novaDionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                     dioniceBurze.Add(novaDionica);
                 }

                 else
                 {
                     throw  new StockExchangeException("Pocetna cijena ne moze biti negativna.");
                 }
                
             }
             else
             {
                 throw new StockExchangeException("Vec postoji dionica tog imena.");
             }
         }


        public Dionica PronadjiDionicu(string imeDionice)
        {
            try{
                Dionica nadjenaDionica = null;
                foreach (Dionica d in dioniceBurze)
                {
                    if (d.ime.ToUpper() == imeDionice.ToUpper())
                    {
                        nadjenaDionica = d;

                    }

                }

                return nadjenaDionica;
            }

            catch
            {
                throw  new StockExchangeException("Ne postoji dionica tog imena!");
            }


        }

        public void DelistStock(string inStockName)
        {

            Dionica d = PronadjiDionicu(inStockName);
            if (d == null)
            {
                throw  new StockExchangeException("Greska!");
            }
            dioniceBurze.Remove(d);
            foreach (Indeks i in indeksi)
            {
                i.MakniDionicuIzIndeksa(d);
                
            }

            foreach (Portfolio p in portfolios)
            {
                p.MakniDionicuIzPortfelja(d);
                
            }
        }

         public bool StockExists(string inStockName)
         {
             Dionica d = PronadjiDionicu(inStockName);

             if (d != null)
             {
                 return true;
             }

            return false;
         }

         public int NumberOfStocks()
         {
             return dioniceBurze.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
             else
             {
                 d.PostaviNovuCijenu(inStockValue, inIimeStamp);
             }

         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {

             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
             return d.VratiCijenuUVremenu(inTimeStamp);
           
         }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Dionica d = PronadjiDionicu(inStockName);
            if (d == null)
            {
                throw new StockExchangeException("Ne postoji dionica tog imena!");
            }
            return d.VratiInicijalnuCijenu();

        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Dionica d = PronadjiDionicu(inStockName);
            if (d == null)
            {
                throw new StockExchangeException("Ne postoji dionica tog imena!");
            }
            return d.VratiZadnjuCijenu();
        }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (PronadjiDionicu(inIndexName) == null)
             {
                 Indeks noviIndeks = new Indeks(inIndexName, inIndexType);
                 indeksi.Add(noviIndeks);
             }

             else throw  new StockExchangeException("Greska!");
         }


        public Indeks PronadjiIndeks(string imeIndeksa)
        {
            
            foreach (Indeks i in indeksi)
            {
                if (i.ime.ToUpper() == imeIndeksa.ToUpper())
                {
                    return i;
                }

            }
          
            return null;

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Indeks i = PronadjiIndeks(inIndexName);
            if (i == null)
            {
                throw new StockExchangeException("Ne postoji indeks tog imena!");
            }
            Dionica d = PronadjiDionicu(inStockName);
            if (d == null)
            {
                throw new StockExchangeException("Ne postoji dionica tog imena!");
            }
            i.DodajDionicuIndeksu(d);
        }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Indeks i = PronadjiIndeks(inIndexName);
             if (i == null)
             {
                 throw new StockExchangeException("Ne postoji indeks tog imena!");
             }
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
             i.MakniDionicuIzIndeksa(d);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Indeks i = PronadjiIndeks(inIndexName);
             if (i == null)
             {
                 throw new StockExchangeException("Ne postoji indeks tog imena!");
             }
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }

             return i.DionicaUIndeksu(d);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Indeks i = PronadjiIndeks(inIndexName);
             if (i == null)
             {
                 throw new StockExchangeException("Ne postoji indeks tog imena!");
             }
             return i.VratiVrijednostIndeksa(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (PronadjiIndeks(inIndexName) != null)
             {
                 return true;
             }
             
             return false;
         }

         public int NumberOfIndices()
         {
             return indeksi.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Indeks i = PronadjiIndeks(inIndexName);

             if (i == null)
             {
                 throw new StockExchangeException("Ne postoji indeks tog imena!");
             }
             return i.BrojDionicaUIndeksu();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PronadjiPortfolio(inPortfolioID) == null)
             {
                 Portfolio p = new Portfolio(inPortfolioID);
                 portfolios.Add(p);
             }
             else
             {
                  throw  new StockExchangeException("Greska!");
             }
         }

        public Portfolio PronadjiPortfolio(string id)
        {
            
            foreach (Portfolio port in portfolios)
            {
                if (port.idPortfelja == id)
                {
                    return port;

                }

            }
            return null;

            // throw new StockExchangeException("Ne postoji portfelj tog imena");

        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //Dionica d = new Dionica(inStockName, numberOfShares);
            Dionica dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
            {
                throw new StockExchangeException("Ne postoji dionica tog imena!");
            }
            int rez = dionica.preostaleDionice - numberOfShares;
            if (rez >= 0)
            {
                Portfolio p = PronadjiPortfolio(inPortfolioID);
                if (p == null)
                {
                    throw new StockExchangeException("Ne postoji portfolio tog imena!");
                }
                dionica.preostaleDionice = rez;
                p.DodajDionicuPortfelju(dionica, numberOfShares);
            }
            else throw new StockExchangeException("Nema toliko preostalih dionica!");

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
           Portfolio p = PronadjiPortfolio(inPortfolioID);
           if (p == null)
           {
               throw new StockExchangeException("Ne postoji portfolio tog imena!");
           }
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }

           p.PromijeniBrDionica(d, numberOfShares);
             //Dionica d = PronadjiDionicu(inStockName);
             d.preostaleDionice += numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             //Dionica d = new Dionica();
             //d.ime = inStockName;
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }

             p.MakniDionicuIzPortfelja(d);
            
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }
             return p.VratiBrojDionica();

         }

         public bool PortfolioExists(string inPortfolioID)
         {

             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p != null)
             {
                 return true;
             }
             else return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
             return p.DionicaUPortfelju(d);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }
             Dionica d = PronadjiDionicu(inStockName);
             if (d == null)
             {
                 throw new StockExchangeException("Ne postoji dionica tog imena!");
             }
            return p.BrDionicaDionice(d);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }
             return p.VrijednostPortfelja(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             
             Portfolio p = PronadjiPortfolio(inPortfolioID);
             if (p == null)
             {
                 throw new StockExchangeException("Ne postoji portfolio tog imena!");
             }
             DateTime end = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23 , 59, 59, 999);
             DateTime start = new DateTime(Year, Month, 1, 0, 0,0,0 );
             decimal startValue = p.VrijednostPortfelja(start);

             if (startValue == 0)
             {
                 return 0;
             }

             decimal endValue = p.VrijednostPortfelja(end);
             decimal rezultat = Math.Abs((endValue/startValue - 1)*100);


             return rezultat;
         }
     }
}
