﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {

         private static Dictionary<Stock, long> stocks;
         private List<Index> indices;         
         private List<Portfolio> portfolios;

         public StockExchange () {
             stocks = new Dictionary<Stock, long> ();
             indices = new List<Index> ();
             portfolios = new List<Portfolio> ();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock newStock = new Stock ( inStockName, inTimeStamp, inInitialPrice );
             if (!stocks.Keys.Contains(newStock))
             {
                 stocks.Add ( newStock, inNumberOfShares );
             }
             else
             {
                 throw new StockExchangeException("Stock already exists");
             }                          
         }

         public void DelistStock(string inStockName)
         {
             Stock tmpStock = new Stock ( inStockName );
             if (stocks.Keys.Contains(tmpStock))
             {
                 // brisanje dionice iz svih indexa
                 foreach (Index i in indices)
                 {
                     if (i.ContainsStock(inStockName))
                     {
                         i.RemoveStock(inStockName);
                     }
                 }

                 //brisanje dionice iz svih portfelja
                 foreach (Portfolio p in portfolios)
                 {
                     if (p.ContainsStock(tmpStock))
                     {
                         p.RemoveStock(tmpStock);
                     }
                 }
                 stocks.Remove ( tmpStock );
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist." );
             }
         }

         public bool StockExists(string inStockName)
         {
             Stock s = new Stock ( inStockName );             
             return stocks.Keys.Contains ( s );
         }

         public int NumberOfStocks()
         {
             return stocks.Keys.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock s = new Stock ( inStockName );
             Stock existingStock = null;
             
             foreach (Stock tmpStock in stocks.Keys) {
                 if (tmpStock.Equals(s)) {
                     existingStock = tmpStock;
                 }
             }
             
             if (existingStock != null) {
                 existingStock.SetPrice ( inIimeStamp, inStockValue );
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist." );
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             decimal stockPrice = 0;
             bool isFound = false;

             foreach (Stock s in stocks.Keys)
             {
                 if (s.Name == inStockName)
                 {
                     stockPrice = s.GetPrice(inTimeStamp);
                     isFound = true;
                 }
             }

             if (isFound)
             {
                 return stockPrice;
             }
             else
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             decimal stockPrice = 0;
             bool isFound = false;

             foreach (Stock s in stocks.Keys) {
                 if (s.Name == inStockName.ToUpper())
                 {
                     stockPrice = s.GetInitialPrice();
                     isFound = true;
                 }
             }

             if (isFound) {
                 return stockPrice;
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist." );
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             decimal stockPrice = 0;
             bool isFound = false;

             foreach (Stock s in stocks.Keys) {
                 if (s.Name == inStockName.ToUpper())
                 {
                     stockPrice = s.GetLastPrice();
                     isFound = true;
                 }
             }

             if (isFound) {
                 return stockPrice;
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist." );
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException ( "Index already exists." );
             }
             else
             {
                 Index newIndex;
                 switch (inIndexType) {
                     case IndexTypes.AVERAGE:
                         newIndex = new AverageIndex ( inIndexName );
                         break;
                     case IndexTypes.WEIGHTED:
                         newIndex = new WeightedIndex ( inIndexName );
                         break;
                     default:
                         throw new StockExchangeException ( "Wrong indexType." );
                 }

                 indices.Add ( newIndex );
             }             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if ( IndexExists(inIndexName) && StockExists(inStockName) ) {
                 Stock stock = this.GetStock ( inStockName );
                 Index index = this.GetIndex ( inIndexName );

                 index.AddStock ( stock ); 
             }
             else
             {
                 throw new StockExchangeException("Index or stock doesn't exist.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName) ) {
                 Stock stock = this.GetStock ( inStockName );
                 Index index = this.GetIndex ( inIndexName );

                 index.RemoveStock ( inStockName ); 
             }
             else {
                 throw new StockExchangeException ( "Index or stock doesn't exist." );
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists ( inIndexName ) && StockExists ( inStockName )) {
                 Index index = this.GetIndex ( inIndexName );
                 return index.ContainsStock ( inStockName ); 
             }
             else {
                 throw new StockExchangeException ( "Index or stock doesn't exist." );
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName)) {
                 Index index = this.GetIndex ( inIndexName );
                 return index.GetValue ( inTimeStamp ); 
             }
             else {
                 throw new StockExchangeException ( "Index doesn't exist." );
             }
         }

         public bool IndexExists(string inIndexName)
         {
             bool exists = false;
             foreach (Index i in indices)
             {
                 if (i.Name == inIndexName.ToUpper())
                 {
                     exists = true;
                 }
             }
             return exists;
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName)) {
                 Index index = this.GetIndex ( inIndexName );
                 return index.StocksCount (); 
             }
             else {
                 throw new StockExchangeException ( "Index doesn't exist." );
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID)) {
                 Portfolio p = new Portfolio ( inPortfolioID );
                 this.portfolios.Add ( p ); 
             }
             else
             {
                 throw new StockExchangeException("Portfolio already exists.");
             }
         }
         
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName)) {
                 Stock stock = this.GetStock ( inStockName );
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );

                 portfolio.AddStock ( stock, numberOfShares ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Stock stock = this.GetStock ( inStockName );
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );

                 portfolio.RemoveStock ( stock, numberOfShares ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Stock stock = this.GetStock ( inStockName );
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );

                 portfolio.RemoveStock ( stock ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );
                 return portfolio.StocksCount (); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool exists = false;

             foreach (Portfolio p in portfolios)
             {
                 if (p.Name == inPortfolioID)
                 {
                     exists = true;
                 }
             }
             return exists;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Stock stock = this.GetStock ( inStockName );
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );
                 return portfolio.ContainsStock ( stock ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Stock stock = this.GetStock ( inStockName );
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );
                 return (int)portfolio.NumberOfStockShares ( stock ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );
                 return portfolio.GetValue ( timeStamp ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID)) {
                 Portfolio portfolio = this.GetPortfolio ( inPortfolioID );
                 return portfolio.GetMonthlyDerivation ( Year, Month ); 
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist." );
             }
         }

         public static Decimal GetStockTotalValue ( Stock s, DateTime timestamp ) {
             
             if (stocks.Keys.Contains ( s )) {
                 return s.GetPrice ( timestamp ) * stocks[s];
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist" );
             }
         }

         private Stock GetStock(string stockName)
         {
             Stock tmpStock = null;             
             
             foreach (Stock s in stocks.Keys)
             {
                 if (s.Name == stockName)
                 {
                     tmpStock = s;
                 }
             }

             if (tmpStock != null)
             {
                 return tmpStock;
             }
             else
             {
                 throw new StockExchangeException ( "Stock doesn't exist" );
             }
         }

         private Index GetIndex(string indexName)
         {
             Index tmpIndex = null;

             foreach (Index i in indices) {
                 if (i.Name == indexName)
                 {
                     tmpIndex = i;
                 }
             }

             if (tmpIndex != null) {
                 return tmpIndex;
             }
             else {
                 throw new StockExchangeException ( "Index doesn't exist" );
             }
         }

         private Portfolio GetPortfolio(string portfolioName)
         {
             Portfolio tmpPortfolio = null;

             foreach (Portfolio p in portfolios)
             {
                 if (p.Name == portfolioName)
                 {
                     tmpPortfolio = p;
                 }                 
             }

             if (tmpPortfolio != null) {
                 return tmpPortfolio;
             }
             else {
                 throw new StockExchangeException ( "Portfolio doesn't exist" );
             }
         }
     }

     public abstract class Index : IEquatable<Stock> {
         protected List<Stock> stockList;
         protected string name;
         protected IndexTypes type;

         public string Name {
             get {
                 return this.name;
             }
             set {
                 this.name = value;
             }
         }

         public IndexTypes Type {
             get {
                 return this.type;
             }
             set {
                 this.type = value; // zbog properties-a će value uvijek biti tipa IndexTypes
             }
         }

         public Index(string name)
         {
             this.Name = name;
             this.stockList = new List<Stock>();
         }


         // NADJAČANE METODE ZA USPOREDBU KAO KOD Stock

         public bool Equals(Stock obj)
         {
             // If parameter is null return false.
             if (obj == null) {
                 return false;
             }

             // Return true if the fields match:
             if (obj.Name == this.Name)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public override bool Equals ( object obj ) {

             if (obj == null) {
                 return false;
             }

             Index indexObj = obj as Index;
             if (indexObj == null)
             {
                 return false;
             }
             else
             {
                 return Equals(indexObj);
             }
         }

         public void AddStock ( Stock stock ) {
             if (!stockList.Contains(stock))
             {
                 this.stockList.Add ( stock );    
             }
             else
             {
                 throw new StockExchangeException("Stock is already in index.");
             }
         }

         public abstract Decimal GetValue ( DateTime timeStamp );

         public void RemoveStock ( string stockName)
         {
             Stock tmpStock = null;

             foreach (Stock s in stockList)
             {
                 if (s.Name == stockName )
                 {
                     tmpStock = s;
                 }
             }

             if (tmpStock != null)
             {
                 this.stockList.Remove(tmpStock);
             }
             else
             {
                 throw new StockExchangeException ( "Stock doesn't exist" );
             }
         }

         public bool ContainsStock(string stockName)
         {
             bool containsStock = false;
             foreach (Stock s in stockList)
             {
                 if (s.Name == stockName)
                 {
                     containsStock = true;
                 }
             }

             return containsStock;
         }

         public int StocksCount()
         {
             return this.stockList.Count;
         }
     }

     public class AverageIndex : Index {

         // poziva se konstriktor u roditelju
         public AverageIndex(string name) : base(name)
         {
         }

         // vrijednost je prosjek cijene svih dionica u indeksu
         public override Decimal GetValue ( DateTime timeStamp ) {
             Decimal sum = 0;
             foreach (Stock s in stockList) {
                 sum += s.GetPrice (timeStamp);
             }
             return sum / stockList.Count;
         }
     }

     public class WeightedIndex : Index {

         // poziva se konstruktor u roditelju
         public WeightedIndex(string name) : base(name)
         {
         }

         /* 
          * vrijednost je težinski prosjek cijene svih dionica u indeksu,
          * gdje je težinski faktor za pojedinu dionicu definiran kao omjer
          * ukupne vrijednosti te dionice na burzi (cijena dionice * broj dionica) i ukupne vrijednosti svih dionica unutar indeksa
          */
         public override Decimal GetValue (DateTime timeStamp) {
             
             // računanje ukupne vrijednosti svih dionica u indexu
             Decimal sumAllStocksInIndex = 0;
             foreach (Stock s in stockList)
             {
                 sumAllStocksInIndex += StockExchange.GetStockTotalValue(s, timeStamp);
             }

             // računanje faktora za svaku dionicu u indexu
             List<Decimal> factoredVals = new List<Decimal> ();
             Decimal totalStockValue;
             Decimal tmpPrice;
             foreach (Stock s in stockList) {
                 totalStockValue = StockExchange.GetStockTotalValue ( s, timeStamp );  // ukupna vrijednost dionice na burzi
                 //Math.Round(totalStockValue, 2);
                 tmpPrice = s.GetPrice(timeStamp);
                 factoredVals.Add ( (totalStockValue / sumAllStocksInIndex) * tmpPrice );     // dodaje se faktor za tu dionicu
             }

             return Math.Round ( factoredVals.Sum (), 3 ); // vraća se težinski prosjek cijene svih dionica u indeksu
         }
     }

     public class Stock : IEquatable<Stock> {
         private Dictionary<DateTime, Decimal> price;
         private string name;
         private decimal initialPrice;
     
         public string Name {
             get {
                 return this.name.ToUpper();
             }
             set {
                 this.name = value.ToUpper ();
             }
         }

         public Stock ( string name ) {
             this.name = name;
         }

         public Stock ( string name, DateTime startPeriod, Decimal price ) {
             if (price<0)
             {
                 throw new StockExchangeException("Price can't be negative.");
             }
             else
             {
                 this.name = name;
                 this.price = new Dictionary<DateTime, Decimal> ();
                 this.price.Add ( startPeriod, price );
                 this.initialPrice = price;
             }
         }


         // NADJAČANE METODE ZA USPOREDBU, OBJEKTI SE USPOREĐUJU PO IMENU

         public bool Equals ( Stock obj ) {

             // If parameter is null return false.
             if (obj == null) {
                 return false;
             }

             // Return true if the fields match:
             if (obj.Name == this.Name)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public override bool Equals ( object obj ) {
             if (obj == null)
             {
                 return false;
             }

             Stock stockObj = obj as Stock;
             if (stockObj == null)
             {
                 return false;
             }
             else
                 return Equals(stockObj);
         }

         public override int GetHashCode () {
             return this.Name.GetHashCode();
         }

         // za unos bilo kojeg datuma provjerava se da li postoji cijena definirana za taj period
         public Decimal GetPrice (DateTime fromDate) {
             
             DateTime dateFromPriceList = new DateTime();
             bool dateFound = false;
             foreach (DateTime date in price.Keys.OrderByDescending(key => key.ToFileTime())) { // sortirano silazno (novije prema starijem) po datumu
                 if (date <= fromDate) {
                     dateFromPriceList = date;
                     dateFound = true;
                     break;
                 }
             }

             if (dateFound) {
                 return this.price[dateFromPriceList];
             }
             else {
                 throw new StockExchangeException ( "Nema cijene za zadani period" );
             }

         }

         public decimal GetLastPrice()
         {
             if (this.price.Count > 0) {

                 List<DateTime> datumi = this.price.Keys.ToList();
                 datumi.Sort();
                 return price[datumi.Last ()]; 
             }
             else
             {
                 throw new StockExchangeException("No prices defined.");
             }
         }

         public decimal GetInitialPrice()
         {
             if (this.price.Count > 0) {

                 List<DateTime> datumi = this.price.Keys.ToList ();
                 datumi.Sort ();
                 return price[datumi.First ()];
             }
             else {
                 throw new StockExchangeException ( "No prices defined." );
             }
         }

         public void SetPrice ( DateTime timestamp, Decimal priceValue) {
             if (!this.price.Keys.Contains(timestamp))
             {
                 this.price.Add ( timestamp, priceValue );    
             }
             else
             {
                 throw new StockExchangeException("Price already set for this timestamp");
             }
         }
     }

     
     public class Portfolio {

         private Dictionary<Stock, long> stockList;
         private string name;         

         public string Name {
             get {
                 return this.name;
             }
             set {
                 this.name = value;
             }
         }

         public Portfolio(string name)
         {
             this.name = name;
             this.stockList = new Dictionary<Stock, long>();
         }

         public void AddStock ( Stock s, int numberOfShares ) {
             if (this.stockList.Keys.Contains(s))
             {
                 this.stockList[s] += numberOfShares;
             }
             else
             {
                 this.stockList.Add ( s, numberOfShares );
             }
             
         }

         public void RemoveStock ( Stock s, int numberOfShares ) {
             
             if (this.stockList.Keys.Contains(s)) {
                 
                 long stockShareInPortf = stockList[s];
                 if (numberOfShares < stockShareInPortf) {
                     stockList[s] -= numberOfShares;
                 }
                 else if (numberOfShares == stockShareInPortf) {
                     stockList.Remove ( s );
                 }
                 else {
                     throw new StockExchangeException ( "Too much stocks to delete." );
                 }
             }
             else {
                 throw new StockExchangeException ( "Stock doesn't exist in portfolio." );
             }
         }

         public void RemoveStock ( Stock s ) {
             if (this.stockList.Keys.Contains ( s ))
             {
                 //stockList[s] -= 1;
                 stockList.Remove(s);
             }
             else
             {
                 throw new StockExchangeException ( "Stock doesn't exist in portfolio." );
             }
         }

         public bool ContainsStock ( Stock s ) {
             return this.stockList.Keys.Contains ( s );
         }

         public long NumberOfStockShares ( Stock s ) {
             if (stockList.Keys.Contains(s)) {
                 return stockList[s];
             }
             else {
                 return 0;
             }
         }

         public Decimal GetValue (DateTime timeStamp) {
             Decimal sum = 0;
             foreach (var item in stockList) {
                 sum += item.Key.GetPrice ( timeStamp ) * item.Value;
             }

             return sum;    // ukupna vrijednost svih dionica u  portfelju
         }

         public Decimal GetMonthlyDerivation (int year, int month) {

             if (year <= 0 || month <= 0)
             {
                 throw new StockExchangeException("Wrong time period.");
             }
             DateTime monthBeginning = new DateTime(year, month, 1, 0, 0, 0, 0);    // prvi dan u 00:00:00
             
             DateTime lastDayOfMonthHelper = new DateTime(year, month, 1).AddMonths(1).AddDays(-1);
             int lastDayOfMonth = lastDayOfMonthHelper.Day;
             DateTime monthEnd = new DateTime(year, month, lastDayOfMonth, 23, 59, 59, 999);    // zadnji dan u 23:59:59:999

             Decimal valueFromMonthBeginning = this.GetValue ( monthBeginning );
             Decimal valueFromMonthEnd = this.GetValue ( monthEnd );

             return (valueFromMonthEnd / valueFromMonthBeginning) * 100;

         }

         public int StocksCount()
         {
             return this.stockList.Count;
         }
     }
}
