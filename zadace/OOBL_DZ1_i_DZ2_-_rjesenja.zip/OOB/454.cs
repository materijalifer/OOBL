﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private double Result;
        private string DisplayState;
        private char[] binaryOperators = { '+', '-', '*', '/' };
        private char[] unaryOperators = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        public double num1, num2;
        public Operator op;
        private string memory;
        private string num1String, num2String;
        private Operator binaryOnHold;
        // Contructor
        public Kalkulator()
        {
            // initial value of the display
            DisplayState = "0";
            num1String = num2String = String.Empty;
            Result = Double.NaN;
            num1 = num2 = double.NaN;
        }

        public void Press(char inPressedDigit)
        {
            if (char.IsNumber(inPressedDigit))
            {
                EvaluateNumber(inPressedDigit);
                UpdateDisplayState();
            }
            else if (unaryOperators.Contains(inPressedDigit))
            {
                SetOperatorObject(inPressedDigit);
                EvaluateUnaryExpression();
                UpdateDisplayState();
            }
            else if (binaryOperators.Contains(inPressedDigit))
            {
                EvaluateBinaryExpression();
                SetOperatorObject(inPressedDigit);
                UpdateDisplayState();
              
            }
            else if (inPressedDigit == '=')
            {
                Enter();
                UpdateDisplayState();
            }
            else if (inPressedDigit == ',')
            {
                if (!DisplayState.Contains(','))
                {
                    DisplayState += inPressedDigit.ToString();
                    EvaluateNumber(inPressedDigit);
                }
               
            }
            else if (inPressedDigit == 'P')
            {
                memory = DisplayState;
                UpdateDisplayState();
            }
            else if (inPressedDigit == 'G')
            {
                DisplayState = memory;
                if (!num1.Equals(double.NaN) && num2.Equals(double.NaN))
                {

                    num2String = memory;
                    Double.TryParse(memory, out num2);
                }
                else
                {
                    num1String = memory;
                    Double.TryParse(memory, out num1);
                }
            }
            else if (inPressedDigit == 'C')
            {
                DisplayState = "0";
                if (!num1.Equals(double.NaN) && num2.Equals(double.NaN))
                {
                    
                    num1String = String.Empty;
                    num1 = double.NaN;
                }
                else
                {
                    num2 = double.NaN;
                    num2String = String.Empty;
                }
            }
            else if (inPressedDigit == 'O')
            {
                memory = null;
                num1String = num2String = String.Empty;
                num1 = num2 = Double.NaN;
                UpdateDisplayState();
            }
        }

        /// <summary>
        /// Evaluate the expression with the binary operator
        /// </summary>
        private void EvaluateBinaryExpression()
        {
            if (binaryOnHold != null && !num1.Equals(double.NaN) && !num2.Equals(double.NaN))
            {
                num1 = Round(binaryOnHold.Evaluate(num1, num2));
                num1String = num1.ToString();
                num2 = double.NaN;
                num2String = String.Empty;
                binaryOnHold = null;
            }
        }

        /// <summary>
        /// When the equal sign is pressed
        /// Primarily handle the binary operation
        /// </summary>
        private void Enter()
        {
            Double.TryParse(num1String, out num1);
            Double.TryParse(num2String, out num2);
            num2 = String.IsNullOrEmpty(num2String) ? num1 : num2;

            if (op != null)
            {
                if (op.type == OperatorEnum.Binary)
                    Result = Round(op.Evaluate(num1, num2));
                else if (binaryOnHold != null)
                {
                    Result = Round(binaryOnHold.Evaluate(num1, num2));
                    binaryOnHold = null;
                }
                else
                    Result = num1;
            }
            else
            {
                Result = num1;
            }
            num1 = Result;
            num1String = Result.ToString();
            num2 = Double.NaN;
            num2String = String.Empty;
        }

        private void UpdateDisplayState()
        {
            if(!Result.Equals(Double.NaN))
                DisplayState = Double.IsInfinity(Result) ? "-E-" : Result.ToString();

            if(!String.IsNullOrEmpty(num1String))
                Double.TryParse(num1String, out num1);
            if (!String.IsNullOrEmpty(num2String))
                Double.TryParse(num2String, out num2);
            Result = double.NaN;
        }

        private void EvaluateNumber(char inPressedDigit)
        {
            
            if (binaryOnHold != null && binaryOnHold.type == OperatorEnum.Binary)
            {
                if (!(num2String.Contains(',') && num2String.Contains('-')))
                {
                    if (num2String.Length >= 10)
                        return;
                }
                num2String += inPressedDigit.ToString();
                Double.TryParse(num2String, out num2);
                
                if(inPressedDigit != ',')
                    DisplayState = num2.ToString(); 
            }
            else
            {
                if (!(num1String.Contains(',') && num1String.Contains('-')))
                {
                    if (num1String.Length >= 10)
                        return;
                }
                num1String += inPressedDigit.ToString();
                Double.TryParse(num1String, out num1);
                if (inPressedDigit != ',')
                    DisplayState = num1.ToString();
            }
        }
        /// <summary>
        /// Evaluate the expression with the unary operator
        /// </summary>
        private void EvaluateUnaryExpression()
        {
            if (binaryOnHold == null)
            {
                Result = Round(op.Evaluate(num1));
                num1String = Result.ToString();
            }
            else if (!String.IsNullOrEmpty(num2String))
            {
                Result = Round(op.Evaluate(num2));
                num2String = Result.ToString();

                if (binaryOnHold != null)
                    num2 = Result;
            }
            else if (binaryOnHold != null)
            {
                Result = Round(op.Evaluate(num1));
                if (op.GetType().Name == "Signum")
                    num1String = "-" + num1String;
            }
            
        }
        /// <summary>
        /// Helper method for rounding numbers, pomalo nespretna ali radi svoje :)
        /// </summary>
        /// <param name="Result"></param>
        /// <returns></returns>
        private double Round(double Result)
        {
            if (double.IsInfinity(Result))
                return Double.PositiveInfinity;

            if (Result > -10 && Result < 0)
                return Math.Round(Result, 9);
            if (Result > 0 && Result < 10)
                return Math.Round(Result,9);
            if (Result.ToString().Length > 10 && Result < 1000000000)
            {
                var temp = Math.Floor(Result);
                var n = temp.ToString().Length;
                return Math.Round(Result, 10 - n);
            }
            if (Result.ToString().Length > 10)
            {
                return Double.PositiveInfinity;
            }
            if (Double.IsNaN(Result))
                return Double.PositiveInfinity;
            return Result;
        }

        /// <summary>
        /// Set the global variable "op" to the current operator
        /// </summary>
        /// <param name="ope"></param>
        private void SetOperatorObject(char ope)
        {
            switch (ope)
            {
                case '+':
                    op = new Plus();
                    break;
                case '-':
                    op = new Minus();
                    break;
                case '*':
                    op = new Multiply();
                    break;
                case '/':
                    op = new Divide();
                    break;
                case 'M':
                    op = new Signum();
                    break;
                case 'S':
                    op = new Sinus();
                    break;
                case 'K':
                    op = new Cosinus();
                    break;
                case 'T':
                    op = new Tangens();
                    break;
                case 'Q':
                    op = new Quadrat();
                    break;
                case 'R':
                    op = new Root();
                    break;
                case 'I':
                    op = new Inverse();
                    break;
                default:
                    break;
            }

            binaryOnHold = op.type == OperatorEnum.Binary ? op : binaryOnHold;
            
        }

        public string GetCurrentDisplayState()
        {
            return DisplayState;
        }
    }

    /// <summary>
    /// Superclass Operator
    /// </summary>
    public class Operator
    {
        public OperatorEnum type;
        public virtual double Evaluate(double num1, double num2) { return new double(); }
        public virtual double Evaluate(double num1) { return new double(); }
    }
   
    /// <summary>
    /// Subclassed classes (concrete operators) with overriden methods
    /// </summary>
    public class Plus : Operator
    {
        public Plus()
        {
            base.type = OperatorEnum.Binary;
        }

        public override double Evaluate(double num1, double num2)
        {
            double result = num1 + num2;
            return result;
        }

    }
    public class Minus : Operator
    {
        public Minus()
        {
            base.type = OperatorEnum.Binary;
        }

        public override double Evaluate(double num1, double num2)
        {
            double result = num1 - num2;
            return result;
        }
    }
    public class Multiply : Operator
    {
        public Multiply()
        {
            base.type = OperatorEnum.Binary;
        }

        public override double Evaluate(double num1, double num2)
        {
            double result = num1 * num2;
            return result;
        }
    }
    public class Divide : Operator
    {
        public Divide()
        {
            base.type = OperatorEnum.Binary;
        }

        public override double Evaluate(double num1, double num2)
        {
            double result = num1 / num2;
            return result;
        }
    }
    public class Signum : Operator
    {
        public Signum()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = num1 * (-1);
            return result;
        }
    }
    public class Sinus : Operator
    {
        public Sinus()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = Math.Sin(num1);
            return result;
        }
    }
    public class Cosinus : Operator
    {
        public Cosinus()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = Math.Cos(num1);
            return result;
        }
    }
    public class Tangens : Operator
    {
        public Tangens()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = Math.Tan(num1);
            return result;
        }
    }
    public class Quadrat : Operator
    {
        public Quadrat()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = num1 * num1;
            return result;
        }
    }
    public class Root : Operator
    {
        public Root()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = Math.Sqrt(num1);
            return result;
        }
    }
    public class Inverse : Operator
    {
        public Inverse()
        {
            base.type = OperatorEnum.Unary;
        }

        public override double Evaluate(double num1)
        {
            double result = (double)1 / num1;
            return result;
        }
    }

    public enum OperatorEnum
    {
        Unary = 1,
        Binary = 2
    }

}
