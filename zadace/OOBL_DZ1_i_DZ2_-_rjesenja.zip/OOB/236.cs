﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    /*
     * Razred tvornice.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class Factory
    {

        /*
         * Metoda tvornica.
         * 
         * vraća: naše računalo
         */
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }

    }

    /*
     * Razred koji predstavlja naše računalo.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class Kalkulator : ICalculator
    {

        /*
         * Prikaz prethodnoga ishoda računala.
         */
        private string ishod = "0";

        /*
         * Prikaz trenutačnoga stanja računala.
         */
        private string prikaz = "0";

        /*
         * Prikaz memorije računala.
         */
        private string memorija = "0";

        /*
         * Unosi li se tek prva znamenka ili ne.
         */
        private bool pocinjemo = true;

        /*
         * Prethodni uneseni operator.
         */
        private char operacija = '=';

        /*
         * Implementacija metode Press.
         * 
         * parametar inPressedDigit: pritisnuta tipka na računalu
         */
        public void Press(char inPressedDigit)
        {
            double temp;

            switch (inPressedDigit)
            {
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    if (pocinjemo)
                    {
                        if (inPressedDigit != '0')
                        {
                            prikaz = inPressedDigit + "";
                            pocinjemo = false; 
                        }
                    }
                    else if (prikaz[0] == '-')
                    {
                        if (prikaz.Contains(','))
                        {
                            if (prikaz.Length < 12)
                            {
                                prikaz += inPressedDigit;
                            }
                        }
                        else if (prikaz.Length < 11)
                        {
                            prikaz += inPressedDigit;
                        }
                    }
                    else if (prikaz.Contains(','))
                    {
                        if (prikaz.Length < 11)
                        {
                            prikaz += inPressedDigit;
                        }
                    }
                    else if (prikaz.Length < 10)
                    {
                        prikaz += inPressedDigit;
                    }
                    break;
                case '+':
                case '-':
                case '*':
                case '/':
                case '=':
                    if (!pocinjemo || inPressedDigit == '=')
                    {
                        if (pocinjemo)
                        {
                            prikaz = ishod;
                        }
                        switch (operacija)
                        {
                            case '+':
                                prikaz = (double.Parse(ishod) + double.Parse(prikaz)).ToString("F9");
                                break;
                            case '-':
                                prikaz = (double.Parse(ishod) - double.Parse(prikaz)).ToString("F9");
                                break;
                            case '*':
                                prikaz = (double.Parse(ishod) * double.Parse(prikaz)).ToString("F9");
                                break;
                            case '/':
                                prikaz = (double.Parse(ishod) / double.Parse(prikaz)).ToString("F9");
                                break;
                        }
                        formatiraj();
                        pocinjemo = true;
                    }
                    ishod = prikaz;
                    operacija = inPressedDigit;
                    break;
                case ',':
                    if (pocinjemo)
                    {
                        prikaz = "0,";
                        pocinjemo = false;
                    }
                    else if (!prikaz.Contains(','))
                    {
                        prikaz += inPressedDigit;
                    }
                    break;
                case 'M':
                    if (!pocinjemo)
                    {
                        prikaz = prikaz[0] != '-' ? '-' + prikaz : prikaz = prikaz.Substring(1);
                    }
                    break;
                case 'S':
                    prikaz = Math.Sin(double.Parse(prikaz)).ToString("F9");
                    formatiraj();
                    break;
                case 'K':
                    prikaz = Math.Cos(double.Parse(prikaz)).ToString("F9");
                    formatiraj();
                    break;
                case 'T':
                    prikaz = Math.Tan(double.Parse(prikaz)).ToString("F9");
                    formatiraj();
                    break;
                case 'Q':
                    temp = double.Parse(prikaz);
                    prikaz = (temp * temp).ToString("F9");
                    formatiraj();
                    break;
                case 'R':
                    prikaz = Math.Sqrt(double.Parse(prikaz)).ToString("F9");
                    formatiraj();
                    break;
                case 'I':
                    if (prikaz == "0")
                    {
                        ishod = "0";
                        prikaz = "-E-";
                        pocinjemo = true;
                        operacija = '=';
                        return;
                    }
                    prikaz = (1 / double.Parse(prikaz)).ToString("F9");
                    formatiraj();
                    break;
                case 'P':
                    memorija = prikaz;
                    break;
                case 'G':
                    prikaz = memorija;
                    break;
                case 'C':
                    prikaz = "0";
                    pocinjemo = true;
                    break;
                default:
                    ishod = "0";
                    prikaz = "0";
                    memorija = "0";
                    pocinjemo = true;
                    operacija = '=';
                    break;
            }
        }

        /*
         * Metoda koja formatira prikaz trenutačnoga stanja računala.
         */
        private void formatiraj()
        {
            int i = prikaz.IndexOf(','), j = prikaz[0] == '-' ? 11 : 10;
            char[] polje = new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9' };

            if (i >= 0)
            {
                if (prikaz.IndexOfAny(polje) > j || i > j)
                {
                    ishod = "0";
                    prikaz = "-E-";
                    pocinjemo = true;
                    operacija = '=';
                    return;
                }
                prikaz = Math.Round(double.Parse(prikaz), j - i).ToString("F9");
                for (i = prikaz.Length; prikaz[--i] == '0' || prikaz[i] == ','; prikaz = prikaz.Remove(i))
                    ;
            }
            else if (prikaz.Length > j)
            {
                ishod = "0";
                prikaz = "-E-";
                pocinjemo = true;
                operacija = '=';
            }
        }

        /*
         * Implementacija metode GetCurrentDisplayState.
         * 
         * vraća: prikaz trenutačnoga stanja računala
         */
        public string GetCurrentDisplayState()
        {
            return prikaz;
        }

    }

}
