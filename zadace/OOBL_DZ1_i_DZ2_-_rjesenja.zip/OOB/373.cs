﻿ using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public const int PRECISION = 3;

         private IDictionary<string, Stock> stocks = new Dictionary<string, Stock>();
         
        #region Stock

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName)) throw new StockExchangeException("Pokušaj upisa iste dionice više puta na burzu!");

             string stockKey = GetStockKey(inStockName);
             Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(stockKey, newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName)) throw  new StockExchangeException("Nepoznata dionica!");

             string stockKey = GetStockKey(inStockName);
             Stock stock = stocks[stockKey];

             IList<Index> indicesWithStock = indices.Values.Where(index => index.IsStockPartOfIndex(stock)).ToList();
             foreach (var index in indicesWithStock)
             {
                 RemoveStockFromIndex(index.IndexName, stock.StockName);
             }

             IList<Portfolio> portfoliosWithStock = portfolios.Values.Where(p => p.IsStockPartOfPortfolio(stock)).ToList();
             foreach (var portfolio in portfoliosWithStock)
             {
                 RemoveStockFromPortfolio(portfolio.PortfolioID, stock.StockName);
             }
             
             
             stocks.Remove(stockKey);
             
         }

         public bool StockExists(string inStockName)
         {
             if (inStockName != null && stocks.ContainsKey(GetStockKey(inStockName))) {
                 return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {  
             if(!StockExists(inStockName)) throw new StockExchangeException("Nemoguće postaviti cijenu dionici koja ne postoji!");

             string key = GetStockKey(inStockName);
             Stock stock = stocks[key];
             stock.SetPrice(inTimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName)) throw new StockExchangeException("Nemoguće dohvatiti cijenu za dionicu koja ne postoji!");

             string key = GetStockKey(inStockName);
             Stock stock = stocks[key];
             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName)) throw new StockExchangeException("Nemoguće dohvatiti inicijalnu cijenu za dionicu koja ne postoji!");

             string key = GetStockKey(inStockName);
             Stock stock = stocks[key];
             return stock.GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName)) throw new StockExchangeException("Nemoguće dohvatiti zadnju cijenu za dionicu koja ne postoji!");

             string key = GetStockKey(inStockName);
             Stock stock = stocks[key];
             return stock.GetLastPrice();
         }

        #endregion

         private IDictionary<string,Index> indices = new Dictionary<string, Index>();

         #region Index

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName)) throw new StockExchangeException("Već postojeći index!");
             
             if(!isIndexTypeValid(inIndexType)) throw  new StockExchangeException("Neprepoznata vrijednost enumeracije!");

             string key = GetIndexKey(inIndexName);
             Index index = new Index(inIndexName, inIndexType);
             indices.Add(key, index);
         }

         /// <summary>
         /// Provjera IndexTypes enumeracije
         /// </summary>
         /// <param name="indexType"></param>
         /// <returns></returns>
         private bool isIndexTypeValid(IndexTypes indexType)
         {
             switch (indexType)
             {
                 case IndexTypes.AVERAGE:
                     return true;
                 case IndexTypes.WEIGHTED:
                     return true;
                 default:
                     return false;
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!(IndexExists(inIndexName) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći index ili dionica!");

             string indexKey = GetIndexKey(inIndexName);
             string stockKey = GetStockKey(inStockName);
             indices[indexKey].AddStock(stocks[stockKey]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!(IndexExists(inIndexName) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći index ili dionica!");

             string indexKey = GetIndexKey(inIndexName);
             string stockKey = GetStockKey(inStockName);

             indices[indexKey].RemoveStock(stocks[stockKey]);             
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!(IndexExists(inIndexName) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći index ili dionica!");

             string indexKey = GetIndexKey(inIndexName);
             string stockKey = GetStockKey(inStockName);

             return indices[indexKey].IsStockPartOfIndex(stocks[stockKey]);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName)) throw new StockExchangeException("Nepostojeći index!");

             string indexKey = GetIndexKey(inIndexName);

             return indices[indexKey].GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (inIndexName != null && indices.ContainsKey(GetIndexKey(inIndexName)))
             {
                 return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName)) throw new StockExchangeException("Nepostojeći index!");

             string indexKey = GetIndexKey(inIndexName);

             return indices[indexKey].NumberOfStocks();
         }

        #endregion

         private IDictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();
         private IDictionary<Stock, long> stockSharesInPortfolios = new Dictionary<Stock, long>(); 
 
         #region Portfolio

         public void CreatePortfolio(string inPortfolioID)
         {
             if(PortfolioExists(inPortfolioID)) throw new StockExchangeException("Pokušaj dodavanja istog portfolia više puta!");

             Portfolio portfolio = new Portfolio(inPortfolioID);
             portfolios.Add(inPortfolioID, portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!(PortfolioExists(inPortfolioID) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći portfolio ili dionica!");

             string errorMsg = "Zatražen prevelik broj udjela za upis u portfolio!";
             Stock stock = stocks[GetStockKey(inStockName)];
             if (stock.NumOfShares < numberOfShares) throw new StockExchangeException(errorMsg);
             if (stockSharesInPortfolios.ContainsKey(stock))
             {
                 if(stockSharesInPortfolios[stock] + numberOfShares > stock.NumOfShares) throw new StockExchangeException(errorMsg);
                 stockSharesInPortfolios[stock] += numberOfShares;
             }
             else
             {
                 stockSharesInPortfolios[stock] = numberOfShares;
             }
             portfolios[inPortfolioID].AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!(PortfolioExists(inPortfolioID) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći portfolio ili dionica!");

             Stock stock = stocks[GetStockKey(inStockName)];
             portfolios[inPortfolioID].RemoveStock(stock, numberOfShares);
             stockSharesInPortfolios[stock] -= numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!(PortfolioExists(inPortfolioID) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći portfolio ili dionica!");

             Stock stock = stocks[GetStockKey(inStockName)];
             int numOfShares = portfolios[inPortfolioID].RemoveStock(stock);
             stockSharesInPortfolios[stock] -= numOfShares;
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Nepostojeći portfolio!");

             return portfolios[inPortfolioID].NumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (inPortfolioID != null && portfolios.ContainsKey(inPortfolioID))
             {
                 return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!(PortfolioExists(inPortfolioID) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći portfolio ili dionica!");

             Stock stock = stocks[GetStockKey(inStockName)];
             return portfolios[inPortfolioID].IsStockPartOfPortfolio(stock);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!(PortfolioExists(inPortfolioID) || StockExists(inStockName))) throw new StockExchangeException("Nepostojeći portfolio ili dionica!");

             Stock stock = stocks[GetStockKey(inStockName)];
             return portfolios[inPortfolioID].NumberOfSharesOfStockInPortfolio(stock);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Nepostojeći portfolio!");

             return portfolios[inPortfolioID].GetPortfolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Nepostojeći portfolio!");
             //pretpostavljeno da godina ne smije biti manja od 1700-te jer su se tad otprilike pojavile dionice
             if (Year < 1700 || Month < 1 || Month > 12) throw new StockExchangeException("Pogrešan format godine ili mjeseca!");

             return portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month);
         }

         /// <summary>
         /// Generira jedinstveni ključ za svaku dionicu.
         /// Dopušta nepoštivanje malih i velikih slova u imenu dionice odnosno tvrtke.
         /// </summary>
         internal static string GetStockKey(string stockName) {
            if (stockName == null) throw new StockExchangeException("Null referenca umjesto imena dionice!");
             return stockName.ToLower();
         }

         /// <summary>
         /// Generira jedinstveni ključ za svaki index.
         /// </summary>
         /// <param name="indexName"></param>
         /// <returns></returns>
         internal static string GetIndexKey(string indexName) {
             if (indexName == null) throw new StockExchangeException("Null referenca umjesto imena indexa!");
             return indexName.ToLower();
         }

        #endregion
     }

     /// <summary>
     /// Klasa koja opisuje dionice puštene na burzu od neke tvrtke
     /// </summary>
     public class Stock
     {
         private readonly string stockName;

         /// <summary>
         /// Naziv dionice, najčešće ime tvrtke koja je pustila dionice
         /// </summary>
         public string StockName {
             get { return stockName; }
         }

         private readonly long numOfShares;

         /// <summary>
         /// Broj udjela te tvrtke koji su pušteni na burzu
         /// </summary>
         public long NumOfShares {
             get { return numOfShares; }
         }

         //pamti povijest cijena
         private SortedList<DateTime, decimal> priceHistory = new SortedList<DateTime,decimal>();

         public Stock(string inStockName, long numberOfShares, decimal initialPrice, DateTime timeStamp) {
             this.stockName = inStockName;
             this.numOfShares = numberOfShares;
             priceHistory.Add(timeStamp, initialPrice);

             if(!isValidEntry()) throw new StockExchangeException("Neispravan unos dionice!");
         }

         private bool isValidEntry() {
             if (stockName == null ||
                 numOfShares <= 0 ||
                 GetInitialPrice() <= 0m)
             {
                 return false;
             }

             return true;
         }

         /// <summary>
         /// Generira promjenu cijene u <param name="timeStamp">timeStamp</param> trenutku u vremenu
         /// </summary>
         /// <param name="timeStamp"></param>
         /// <param name="stockValue"></param>
         public void SetPrice(DateTime timeStamp, decimal stockValue) {
             if (priceHistory.ContainsKey(timeStamp)) throw new StockExchangeException("Pokušaj postavljanja 2 cijene za isti Timestamp");

             priceHistory.Add(timeStamp, stockValue);
         }

         public decimal GetPrice(DateTime timeStamp) {
              var priceHistoryBeforeInTimeStamp = from p in priceHistory
                                          where p.Key <= timeStamp
                                          select p;

              try {
                return priceHistoryBeforeInTimeStamp.Last().Value;
              }
              catch (Exception) {
                  throw new StockExchangeException("Nije moguće naći element koji je manji ili jednak: " + timeStamp.ToString());  
              }
         }

         /// <summary>
         /// 
         /// </summary>
         /// <returns>Vremenski najstariju cijenu dionice</returns>
         public decimal GetInitialPrice() {
             return priceHistory.First().Value;
         }

         /// <summary>
         /// 
         /// </summary>
         /// <returns>Vremenski najmlađu cijenu dionice </returns>
         public decimal GetLastPrice() {
             return priceHistory.Last().Value;
         }

        public override bool  Equals(object obj)
        {
 	        if (obj == null) return false;

            Stock st = obj as Stock;
            if ((object) st == null) return false;

            if (StockExchange.GetStockKey(stockName) == StockExchange.GetStockKey(st.StockName)) return true;

            return false;
        }

        public override int GetHashCode()
        {
 	        return stockName.GetHashCode();
        }
   
     }

    /// <summary>
    /// Klasa koja predstavlja index na burzi
    /// </summary>
     public class Index
    {
        private readonly string indexName;

        public string IndexName
        {
            get { return indexName; }
        }

        private readonly IndexTypes indexType;

         /// <summary>
         /// Tip indexa, bitan za način računanja vrijednosti Indexa
         /// </summary>
        public IndexTypes IndexType
        {
            get { return indexType; }
        }

        private IDictionary<string, Stock> stocksInPortfolio = new Dictionary<string, Stock>();

        public Index(string indexName, IndexTypes indexType)
        {
            this.indexName = indexName;
            this.indexType = indexType;
        }

         /// <summary>
         /// Dodaje Stock objekt u Index
         /// </summary>
         /// <param name="stock"></param>
        public void AddStock(Stock stock)
        {
            string key = StockExchange.GetStockKey(stock.StockName);

            if (stocksInPortfolio.ContainsKey(key))
                throw new StockExchangeException("Pokušaj dodavanja iste dionice indexu više puta!");

            stocksInPortfolio.Add(key, stock);
        }

        /// <summary>
        /// Miče dani Stock objekt iz Indexa, ako postoji. Inače baca <exception cref="StockExchangeException">StockExchangeExample</exception>
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            if (!IsStockPartOfIndex(stock))
                throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice u indexu!");
            stocksInPortfolio.Remove(StockExchange.GetStockKey(stock.StockName));
        }

        /// <summary>
        /// Provjera nalazi li se dani Stock objekt u Indexu
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool IsStockPartOfIndex(Stock stock)
        {
            if(stock == null) throw new StockExchangeException("Null referenca umjesto Stock objekta!");

            string key = StockExchange.GetStockKey(stock.StockName);

            if (stocksInPortfolio.ContainsKey(key))
            {
                return true;
            }
            return false;
        }

         /// <summary>
         /// Računa trenutnu vrijednost indexa
         /// </summary>
         /// <param name="timeStamp"></param>
         /// <returns></returns>
        public decimal GetIndexValue(DateTime timeStamp)
        {
            switch (indexType)
            {
                case IndexTypes.AVERAGE:
                    return getAverageIndexValue(timeStamp);
                case IndexTypes.WEIGHTED:
                    return getWeightedIndexValue(timeStamp);
                default:
                    throw new StockExchangeException("Nepoznati tip indexa!");
            }
        }

         /// <summary>
         /// 
         /// </summary>
         /// <returns>Broj Stock objekata koje Index referencira</returns>
        public int NumberOfStocks()
        {
            return stocksInPortfolio.Count;
        }

         /// <summary>
         /// Način računanja vrijednosti Indexa, aritmetički prosjek
         /// </summary>
         /// <param name="timeStamp"></param>
         /// <returns></returns>
        private decimal getAverageIndexValue(DateTime timeStamp)
        {
            if (stocksInPortfolio.Count == 0) return 0m;

            decimal sum = stocksInPortfolio.Values.Sum(sr => sr.GetPrice(timeStamp));
            decimal result = sum/stocksInPortfolio.Count;
            return decimal.Round(result, StockExchange.PRECISION);
        }
         
         /// <summary>
        /// Način računanja vrijednosti Indexa, težinski prosjek
         /// </summary>
         /// <param name="timeStamp"></param>
         /// <returns></returns>
        private decimal getWeightedIndexValue(DateTime timeStamp)
        {
            if (stocksInPortfolio.Count == 0) return 0m;

            decimal totalWeightValue = stocksInPortfolio.Values.Sum(
                stock => stock.GetPrice(timeStamp)*stock.NumOfShares);

            IList<decimal> resultForEachStock =
                stocksInPortfolio.Values.Select(
                    sr => sr.NumOfShares*sr.GetPrice(timeStamp)*sr.GetPrice(timeStamp)/totalWeightValue)
                      .ToList();

            return decimal.Round(resultForEachStock.Sum(), StockExchange.PRECISION);
        }
    }

     /// <summary>
     /// Klasa koja predstavlja portfolio nekog ulagača na burzi
     /// </summary>
     public class Portfolio
     {
        private readonly string portfolioID;

         /// <summary>
         /// Jedinstveni identifikator portfolia
         /// </summary>
        public string PortfolioID {
            get { return portfolioID; }
        }

        private IDictionary<Stock, int> stockSharesInPortfolio = new Dictionary<Stock, int>(); 

        public Portfolio(string portfolioID)
        {
            this.portfolioID = portfolioID;
        }

         /// <summary>
         /// Dodaje Stock u Portfolio
         /// </summary>
         /// <param name="stock"></param>
         /// <param name="numberOfShares"></param>
        public void AddStock(Stock stock, int numberOfShares)
        {
            if (stock == null) throw new StockExchangeException("Nedopušteni pokušaj dodavanja dionice u portfolio!");

            int totalNumOfShares = numberOfShares;
            if (IsStockPartOfPortfolio(stock))
            {
                totalNumOfShares += stockSharesInPortfolio[stock];
            }
            stockSharesInPortfolio[stock] =  totalNumOfShares;
        }

         /// <summary>
         /// Oduzima udjele danog Stock objekta za dani numberOfShares. Ako broj udjela padne na 0, briše se cijeli objekt.
         /// </summary>
         /// <param name="stock"></param>
         /// <param name="numberOfShares"></param>
        public void RemoveStock(Stock stock, int numberOfShares) {
            if (stock == null || !IsStockPartOfPortfolio(stock)) throw new StockExchangeException("Nedopušteni pokušaj brisanja udjela dionice iz portfolia!");

            int newNumStockSharesInPortfolio = stockSharesInPortfolio[stock] - numberOfShares;
            if (newNumStockSharesInPortfolio < 0)
            {
                throw new StockExchangeException("Pokušaj brisanja više udjela dionice nego što postoji u portfoliu!");
            }
            if (newNumStockSharesInPortfolio == 0)
            {
                RemoveStock(stock);
            }
            else
            {
                stockSharesInPortfolio[stock] = newNumStockSharesInPortfolio;
            }
        }

         /// <summary>
         /// Briše objekt bez obzira na broj udjela iz liste objekata Portfolia
         /// </summary>
         /// <param name="stock"></param>
         /// <returns></returns>
        public int RemoveStock(Stock stock) {
            if (stock == null || !IsStockPartOfPortfolio(stock)) throw new StockExchangeException("Nedopušteni pokušaj brisanja dionice iz portfolia!");

            int numOfShares = stockSharesInPortfolio[stock];

            stockSharesInPortfolio.Remove(stock);

            return numOfShares;
        }

         /// <summary>
         /// Broj Stock objekata u portfoliu
         /// </summary>
         /// <returns></returns>
        public int NumberOfStocks()
        {
            return stockSharesInPortfolio.Count;
        }

         /// <summary>
         /// Provjerava nalaze li se udjeli danog Stock objekta u Portfoliu
         /// </summary>
         /// <param name="stock"></param>
         /// <returns></returns>
        public bool IsStockPartOfPortfolio(Stock stock)
        {
            if (stock != null && stockSharesInPortfolio.ContainsKey(stock))
            {
                return true;
            }
            return false;
        }

         /// <summary>
         /// 
         /// </summary>
         /// <param name="stock"></param>
         /// <returns>Broj udjela Stock objekta u Portfoliu. Ako dani Stock objekt nije u Portfoliu, baca <exception 
         /// cref="StockExchangeException">StockExchangeException</exception></returns>
        public int NumberOfSharesOfStockInPortfolio(Stock stock) {
            if(stock == null || !IsStockPartOfPortfolio(stock)) throw new StockExchangeException("Nepostojeća dionica u portfoliu!");

            return stockSharesInPortfolio[stock];
        }

         /// <summary>
         /// Računa vrijednost Portfolia na 3 decimale
         /// </summary>
         /// <param name="timeStamp"></param>
         /// <returns></returns>
        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            return decimal.Round(stockSharesInPortfolio.Sum(pair => pair.Key.GetPrice(timeStamp)*pair.Value));
        }

         /// <summary>
         /// Računa postotnu promjenu cijene Portfolia za dani mjesec
         /// </summary>
         /// <param name="year"></param>
         /// <param name="month"></param>
         /// <returns></returns>
        public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month) {
            DateTime startTime = new DateTime(year,month,1,0,0,0,0);
            DateTime endTime = new DateTime(year, month, 1, 23, 59, 59, 59).AddMonths(1).AddDays(-1);

            decimal startMonthValue = GetPortfolioValue(startTime);
            if (startMonthValue == 0m) return 0m;
            decimal endMonthValue = GetPortfolioValue(endTime);

            decimal result = (endMonthValue - startMonthValue)/startMonthValue * 100;

            return decimal.Round(result, StockExchange.PRECISION);
        }
    }
}
