﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Operator
    {
        public virtual string press(string a, string b)
        {
            double result = Convert.ToDouble(b);
            return zaokruzi(result);
        }

        public string zaokruzi(double broj)
        {
            long cjelobrojneZnamenke = Convert.ToInt64(broj);

            int digits = 0;
            if (cjelobrojneZnamenke == 0)
            {
                digits = 1;
            }

            while (cjelobrojneZnamenke != 0)
            {
                cjelobrojneZnamenke /= 10;
                digits++;
            }

            string result;
            if (digits > 10)
            {
                result = "-E-";
            }
            else
            {
                result = Math.Round(broj, 10 - digits).ToString();
            }
            return result;
        }
    }

    public class PlusOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;

            if (a.Length == 0)
            {
                result = Convert.ToDouble(b);
            }
            else
            {
                result = Convert.ToDouble(a) + Convert.ToDouble(b);
            }

            return zaokruzi(result);
        }
    }

    public class MinusOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            if (a.Length == 0)
            {
                result = Convert.ToDouble(b);
            }
            else
            {
                result = Convert.ToDouble(a) - Convert.ToDouble(b);
            }

            return zaokruzi(result);
        }
    }

    public class MnozenjeOperator : Operator{
        public override string  press(string a, string b)
        {
            double result;
            if (a.Length == 0)
            {
                result = Convert.ToDouble(b);
            }
            else
            {
                result = Convert.ToDouble(a) * Convert.ToDouble(b);
            }

            return zaokruzi(result);
        }
    }

    public class DijeljenjeOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            if (a.Length == 0)
            {
                result = Convert.ToDouble(b);
            }
            else
            {
                if (b.Equals("0"))
                {
                    return "-E-";
                }
                else
                {
                    result = Convert.ToDouble(a) / Convert.ToDouble(b);
                }
            }

            return zaokruzi(result);
        }
    }

    public class KvadriranjeOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            result = Math.Pow(Convert.ToDouble(b), 2);

            return zaokruzi(result);
        }
    }

    public class KorjenovanjeOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            if (Convert.ToDouble(b) < 0)
            {
                return "-E-";
            }
            else
            {
                result = Math.Sqrt(Convert.ToDouble(b));
            }

            return zaokruzi(result);
        }
    }

    public class InverzOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            if (b.Equals("0"))
            {
                return "-E-";
            }
            else
            {
                result = 1 / Convert.ToDouble(b);
            }

            return zaokruzi(result);
        }
    }

    public class SinusOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            result = Math.Sin(Convert.ToDouble(b));

            return zaokruzi(result);
        }
    }

    public class KosinusOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            result = Math.Cos(Convert.ToDouble(b));

            return zaokruzi(result);
        }
    }

    public class TangensOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            result = Math.Tan(Convert.ToDouble(b));

            return zaokruzi(result);
        }
    }

    public class PredznakOperator : Operator
    {
        public override string press(string a, string b)
        {
            double result;
            result = 0 - Convert.ToDouble(b);

            return zaokruzi(result);
        }
    }

    public class Kalkulator:ICalculator
    {
        private string currentValue;
        private string savedValue;
        private string memoryValue;
        private bool overwriteDisplay;
        private bool isPrviOperator;
        private Operator unaryOperator;
        private Operator binaryOperator;
        
        public Kalkulator() 
        {
            reset();
        }
        
        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    pressDigit(inPressedDigit);
                    break;
                case '0':
                    pressZero();
                    break;
                case ',':
                    pressDecimal();
                    break;
                case '+':
                    pressPlus();
                    break;
                case '-':
                    pressMinus();
                    break;
                case '*':
                    pressMnozenje();
                    break;
                case '/':
                    pressDijeljenje();
                    break;
                case '=':
                    pressEquals();
                    break;
                case 'Q':
                    pressKvadriranje();
                    break;
                case 'R':
                    pressKorjenovanje();
                    break;
                case 'I':
                    pressInverz();
                    break;
                case 'S':
                    pressSinus();
                    break;
                case 'K':
                    pressKosinus();
                    break;
                case 'T':
                    pressTangens();
                    break;
                case 'O':
                    reset();
                    break;
                case 'C':
                    pressClear();
                    break;
                case 'M':
                    pressPredznak();
                    break;
                case 'P':
                    pressSave();
                    break;
                case 'G':
                    pressGet();
                    break;

            }
        }

        public string GetCurrentDisplayState()
        {
            return currentValue;
        }

        private void reset()
        {
            currentValue = "0";
            savedValue = "";
            memoryValue = "0";
            overwriteDisplay = true;
            isPrviOperator = false;
            binaryOperator = new Operator();
            unaryOperator = new Operator();
        }

        private void calculateBinary()
        {
            if (isPrviOperator)
            {
                savedValue = binaryOperator.press(savedValue, currentValue);
                //savedValue = currentValue;
                overwriteDisplay = true;
                isPrviOperator = false;
            }
            else
            {
                savedValue = currentValue;
            }
        }

        private void calculateUnary()
        {
            currentValue = unaryOperator.press("", currentValue);
            overwriteDisplay = true;
        }

        private void pressDigit(char pressedNumber)
        {
            string displayBezZareza = currentValue.Replace(",", "");
            string displayBezZarezaIMinusa = displayBezZareza.Replace("-", "");
            int duljinaDisplaya = displayBezZarezaIMinusa.Length;

            if (overwriteDisplay)
            {
                currentValue = pressedNumber.ToString();
                overwriteDisplay = false;
                isPrviOperator = true;
            }
            else if (duljinaDisplaya < 10)
            {
                currentValue += pressedNumber;
            }
        }

        private void pressZero()
        {
            if (overwriteDisplay)
            {
                currentValue = "0";
            }
            else
            {
                if (currentValue != "0")
                {
                    currentValue += '0';
                }
            }
        }

        private void pressDecimal()
        {
            if (overwriteDisplay)
            {
                currentValue = "0,";
                overwriteDisplay = false;
            }
            else if (currentValue.Contains(",") == false)
            {
                currentValue += ",";
            }
        }

        private void pressPlus()
        {
            calculateBinary();
            binaryOperator = new PlusOperator();
        }

        private void pressMinus()
        {
            calculateBinary();
            binaryOperator = new MinusOperator();
        }

        private void pressMnozenje()
        {
            calculateBinary();
            binaryOperator = new MnozenjeOperator();
        }
        
        private void pressDijeljenje()
        {
            calculateBinary();
            binaryOperator = new DijeljenjeOperator();
        }

        private void pressEquals()
        {
            currentValue = binaryOperator.press(savedValue, currentValue);
            savedValue = currentValue;
            overwriteDisplay = true;
        }

        private void pressKvadriranje()
        {
            unaryOperator = new KvadriranjeOperator();
            calculateUnary();
        }

        private void pressKorjenovanje()
        {
            unaryOperator = new KorjenovanjeOperator();
            calculateUnary();
        }

        private void pressInverz()
        {
            unaryOperator = new InverzOperator();
            calculateUnary();
        }

        private void pressSinus()
        {
            unaryOperator = new SinusOperator();
            calculateUnary();
        }

        private void pressKosinus()
        {
            unaryOperator = new KosinusOperator();
            calculateUnary();
        }

        private void pressTangens()
        {
            unaryOperator = new TangensOperator();
            calculateUnary();
        }

        private void pressClear()
        {
            currentValue = "0";
            overwriteDisplay = true;
        }

        private void pressPredznak()
        {
            double newValue = 0 - Convert.ToDouble(currentValue);
            currentValue = newValue.ToString();
        }

        private void pressSave()
        {
            memoryValue = currentValue;
        }

        private void pressGet()
        {
            currentValue = memoryValue;
            overwriteDisplay = true;
        }
    }
}
