﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private CalculatorEngine engine;
        private Display display;
        private Keypad keypad;

        public Kalkulator()
        {
            this.display = new Display();
            this.engine = new CalculatorEngine(this.display);
            this.keypad = new Keypad(engine);
        }

        public void Press(char inPressedDigit)
        {
            this.keypad.pressKey(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return this.display.getDisplayState();
        }
    }

    public class Display
    {
        private string displayState;

        public Display()
        {
            this.displayState = "0";
        }

        public string getDisplayState()
        {
            return this.displayState;
        }

        public void setDisplayState(string state)
        {
            this.displayState = state;
        }
    }

    public class Keypad
    {
        private CalculatorEngine engine;
        private HashSet<char> availableKeys;

        public Keypad(CalculatorEngine e)
        {
            this.engine = e;

            this.availableKeys = new HashSet<char>();

            this.availableKeys.Add('0');
            this.availableKeys.Add('1');
            this.availableKeys.Add('2');
            this.availableKeys.Add('3');
            this.availableKeys.Add('4');
            this.availableKeys.Add('5');
            this.availableKeys.Add('6');
            this.availableKeys.Add('7');
            this.availableKeys.Add('8');
            this.availableKeys.Add('9');
            this.availableKeys.Add(',');
            this.availableKeys.Add('M');
            this.availableKeys.Add('+');
            this.availableKeys.Add('-');
            this.availableKeys.Add('*');
            this.availableKeys.Add('/');
            this.availableKeys.Add('=');
            this.availableKeys.Add('S');
            this.availableKeys.Add('K');
            this.availableKeys.Add('T');
            this.availableKeys.Add('Q');
            this.availableKeys.Add('R');
            this.availableKeys.Add('I');
            this.availableKeys.Add('P');
            this.availableKeys.Add('G');
            this.availableKeys.Add('C');
            this.availableKeys.Add('O');
        }

        public void pressKey(char key)
        {
            if (this.availableKeys.Contains(key))
            {
                this.engine.charInput(key);
            }
        }
    }

    public class CalculatorEngine
    {
        private Display display;
        private double savedOperand;
        private double currentOperand;
        private double memory;
        private char operation;

        private string stringDisplay;

        public CalculatorEngine(Display d)
        {
            this.display = d;
            this.stringDisplay = "";

            this.savedOperand = 0;
            this.operation = ' ';
        }

        public void charInput(char input)
        {
            if (Char.IsDigit(input))
            {
                this.stringDisplay += input;
                this.updateDisplay();
            }

            if (input == ',')
            {
                if (!this.stringDisplay.Contains(','))
                {
                    if (this.stringDisplay.Length == 0)
                    {
                        this.stringDisplay += "0" + input;
                        this.updateDisplay();
                    }
                    else
                    {
                        this.stringDisplay += input;
                        this.updateDisplay();
                    } 
                }
            }

            if (input == '+')
            {
                if (this.operation == ' ')
                {
                    this.operation = '+';
                    this.binaryOperationPrep();
                    this.stringDisplay = "";
                }
                else
                {
                    this.updateOperation('+');
                }
            }

            if (input == '-')
            {
               if (this.operation == ' ')
                {
                    this.operation = '-';
                    this.binaryOperationPrep();
                    this.stringDisplay = "";
                }
                else
                {
                    this.updateOperation('-');
                }
            }

            if (input == '*')
            {
                if (this.operation == ' ')
                {
                    this.operation = '*';
                    this.binaryOperationPrep();
                    this.stringDisplay = "";
                }
                else
                {
                    this.updateOperation('*');
                }
            }

            if (input == '/')
            {
                if (this.operation == ' ')
                {
                    this.operation = '/';
                    this.binaryOperationPrep();
                    this.stringDisplay = "";
                }
                else
                {
                    this.updateOperation('/');
                }
            }

            if (input == '=')
            {
                this.calculateResult();
            }

            if (input == 'M')
            {
                this.changeSign();
            }

            if (input == 'S')
            {
                this.computeSinus();
            }

            if (input == 'K')
            {
                this.computeCosinus();
            }

            if (input == 'T')
            {
                this.computeTangens();
            }

            if (input == 'Q')
            {
                this.computeSquare();
            }

            if (input == 'R')
            {
                this.computeRoot();
            }

            if (input == 'I')
            {
                this.computeInverse();
            }

            if (input == 'P')
            {
                this.putMemory();
            }

            if (input == 'G')
            {
                this.getMemory();
            }

            if (input == 'C')
            {
                this.clear();
            }

            if (input == 'O')
            {
                this.reset();
            }
        }

        private void binaryOperationPrep()
        {
            this.savedOperand = Double.Parse(this.display.getDisplayState());
        }

        private void clear()
        {
            this.stringDisplay = "";
            this.updateDisplay();
        }

        private void changeSign()
        {
            double input = Double.Parse(this.display.getDisplayState());

            string result = (-input).ToString();

            this.stringDisplay = result;
            this.updateDisplay();
        }

        private void computeSinus()
        {
            double input = Double.Parse(this.display.getDisplayState());

            string result = Math.Sin(input).ToString();
            this.currentOperand = Math.Sin(input);

            this.stringDisplay = result;
            this.updateDisplay();
            this.stringDisplay = "";
        }

        private void computeCosinus()
        {
            double input = double.Parse(this.display.getDisplayState());
            string result = Math.Cos(input).ToString();
            this.currentOperand = Math.Cos(input);

            this.stringDisplay = result;
            this.updateDisplay();
            this.stringDisplay = "";
        }

        private void computeTangens()
        {
            double input = double.Parse(this.display.getDisplayState());
            string result = Math.Tan(input).ToString();
            this.currentOperand = Math.Tan(input);

            this.stringDisplay = result;
            this.updateDisplay();
            this.stringDisplay = "";
        }

        private void computeSquare()
        {
            double input = Double.Parse(this.display.getDisplayState());
            string result = (input * input).ToString();
            this.currentOperand = (input * input);

            this.stringDisplay = result;
            this.updateDisplay();
            this.stringDisplay = "";
        }

        private void computeRoot()
        {
            double input = Double.Parse(this.display.getDisplayState());

            if (input < 0)
            {
                this.display.setDisplayState("-E-");
                this.savedOperand = 0;
                this.operation = ' ';
            }

            string result = Math.Sqrt(input).ToString();
            this.currentOperand = Math.Sqrt(input);

            this.stringDisplay = result;
            this.updateDisplay();
            this.stringDisplay = "";
        }

        private void computeInverse()
        {
            double input = double.Parse(this.display.getDisplayState());
            if (input < 0.000000001 && input > -0.000000001)
            {
                this.display.setDisplayState("-E-");
                this.savedOperand = 0;
                this.operation = ' ';
            }
            else
            {
                string result = (1 / input).ToString();
                this.currentOperand = (1/input);

                this.stringDisplay = result;
                this.updateDisplay();
                this.stringDisplay = "";
            }
        }

        private void calculateResult()
        {
            if (this.operation == ' ')
            {
                //do nothing
                return;
            }

            if (this.operation == '+')
            {
                double input = double.Parse(this.display.getDisplayState());

                double result = input + savedOperand;

                if (result > 9999999999 || result < -9999999999)
                {
                    this.display.setDisplayState("-E-");
                    this.stringDisplay = "";
                    this.operation = ' ';
                    return;
                }
                else
                {
                    this.savedOperand = result;
                    this.stringDisplay = result.ToString();
                    this.updateDisplay();
                }
            }

            if (this.operation == '-')
            {
                double input = double.Parse(this.display.getDisplayState());

                double result = savedOperand - input;

                if (result < -9999999999 || result > 9999999999)
                {
                    this.display.setDisplayState("-E-");
                    this.stringDisplay = "";
                    this.operation = ' ';
                    return;
                }
                else
                {
                    this.savedOperand = result;
                    this.stringDisplay = result.ToString();
                    this.updateDisplay();
                }
            }

            if (this.operation == '*')
            {
                double input = double.Parse(this.display.getDisplayState());

                double result = input * savedOperand;

                if (result < -9999999999 || result > 9999999999)
                {
                    this.display.setDisplayState("-E-");
                    this.stringDisplay = "";
                    this.operation = ' ';
                    return;
                }
                else
                {
                    this.savedOperand = result;
                    this.stringDisplay = result.ToString();
                    this.updateDisplay();
                }
            }

            if (this.operation == '/')
            {
                double input = double.Parse(this.display.getDisplayState());

                if (input > -0.000000001 && input < 0.000000001)
                {
                    this.display.setDisplayState("-E-");
                    this.stringDisplay = "";
                    this.operation = ' ';
                    return;
                }

                double result = savedOperand / input;

                if (result < -9999999999 || result > 9999999999)
                {
                    this.display.setDisplayState("-E-");
                    this.stringDisplay = "";
                    this.operation = ' ';
                    return;
                }
                else
                {
                    this.savedOperand = result;
                    this.stringDisplay = result.ToString();
                    this.updateDisplay();
                }
            }
        }

        private void updateOperation(char op)
        {
            this.operation = op;
        }

        private void putMemory()
        {
            this.memory = Double.Parse(this.stringDisplay);
        }

        private void getMemory()
        {
            string num = this.memory.ToString();

            this.display.setDisplayState(this.cutOffDigits(num));
        }

        private void updateDisplay()
        {
            if (this.stringDisplay != "")
            {
                string num = Double.Parse(this.stringDisplay).ToString();

                this.display.setDisplayState(this.cutOffDigits(num));
            }
            else
            {
                this.display.setDisplayState("0");
            }
            
        }

        private void reset()
        {
            this.operation = ' ';
            this.savedOperand = 0;
            this.memory = 0;
            this.stringDisplay = "";
            this.updateDisplay();
        }

        private string cutOffDigits(string num)
        {
            int maxDigits = 10;
            string returnString;

            if (num.Contains(','))
            {
                int commaPosition = num.IndexOf(',');

                double number = Double.Parse(num);

                if (number < 0)
                {
                    commaPosition--;
                }

                returnString = Math.Round(number, maxDigits - commaPosition).ToString();
                return returnString;
            }
            else
            {
                if (num.Length > 10)
                {
                    returnString = num.Substring(0, maxDigits);
                    return returnString;
                }
                else
                {
                    return num;
                }
            }
        }
    }
}
