﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using DrugaDomacaZadaca_Burza_Students;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Share> shareList=new List<Share>();
         private List<Index> indexList=new List<Index>();
         private List<Portfolio> portfolioList=new List<Portfolio>(); 
         



         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice <= 0 || inNumberOfShares <= 0 )
             {
                 throw  new StockExchangeException("fsd"); 
             }
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower() )
                 {
                    
                     throw new StockExchangeException("fssd");
                 }
             }
             Share newShare= new Share(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             shareList.Add(newShare);
         }

         public void DelistStock(string inStockName)
         {
             int counter = 0;
             int counter2 = 0;
             int position = 0;
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     position = counter2;
                     counter++;
                 }
                 counter2++;
             }
             if (counter == 0)
             {
                 throw new StockExchangeException("fssd");
             }

             shareList.RemoveAt(position);

             foreach (Portfolio  portfolio in portfolioList)
             {
                 portfolio.TryDeleteShare(inStockName.ToLower());
             }

             
             foreach (Index index  in indexList)
             {
                 index.TryDeleteShare(inStockName.ToLower());
             }
         }

         public bool StockExists(string inStockName)
         {
             int flag = 0;
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     flag++;
                 }
             }
             if (flag == 0)
             {
                 return false;
             }
             else
             {
                 return true;
             }
         }

         public int NumberOfStocks()
         {
             int counter = 0;
             foreach (Share share in shareList)
             {
                 counter++;
             }
             return counter;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             bool flag = false;
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     flag = true;
                     share.StockValue = inStockValue;
                     share.TimeStamp = inIimeStamp;
                     share.AddValueToList();
                 }
             }
             if (flag == false)
             {
                 throw new StockExchangeException("fsd");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             bool exactName=false;
             Share tmpShare=new Share();
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     exactName = true;
                     tmpShare = share;
                 }
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }

             return tmpShare.FindStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             int counter = 0;
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     counter++;
                     return share.GetEarlierValue();
                 }
             }
             if (counter == 0)
             {
                  throw new StockExchangeException("fssd");
             }
             return 22;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             int counter = 0;
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     counter++;
                     return share.StockValue;
                 }
             }
             if (counter == 0)
             {
                 throw new StockExchangeException("fssd");
             }
             return 22;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             bool flag = false;
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     throw new StockExchangeException("fsd");
                     flag = true;
                 }
             }
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("fsd");
                 flag = true;
             }
             if (flag == false)
             {
                 Index newIndex = new Index(inIndexName, inIndexType);
                 indexList.Add(newIndex);
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             bool shareFlag = false;
             bool indexFlag = false;
             Share shareToIndexAdd= new Share();
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())   //provjerava dali postoji ta dionica u listi dionica na burzi
                 {
                     shareFlag = true;
                     shareToIndexAdd = share;
                 }
             }
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())   //provjerava dali postoji taj indeks
                 {
                     indexFlag = true;
                 }
             }
             if (shareFlag == false || indexFlag== false)
             {
                 throw new StockExchangeException("fsd");
             }
             bool dionicaNePostojiUIndeksu=true;
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     dionicaNePostojiUIndeksu = index.AddShareToIndex(shareToIndexAdd);   //ako ne postoji vraca true i doda je
                 }
             }
             if (dionicaNePostojiUIndeksu == false)
             {
                 throw new StockExchangeException("fsd");
             }


         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             bool wrongNameIndex = true;
             bool wrongnameShare = true;
             Index tmpIndex=new Index();
             Share tmpShare=new Share();
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     wrongNameIndex = false;
                     tmpIndex = index;
                 }
             }
             if (wrongNameIndex == true)
             {
                 throw new StockExchangeException("fsd");
             }
             foreach (Share share in tmpIndex.IndexListShare)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     wrongnameShare = false;
                     tmpShare = share;
                 }
             }
             if (wrongnameShare == true)
             {
                 throw new StockExchangeException("fsd");
             }
             tmpIndex.IndexListShare.Remove(tmpShare);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool wrongNameIndex = true;
             bool shareExist = false;
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     wrongNameIndex = false;
                     foreach (Share share in index.IndexListShare)
                     {
                         if (share.StockName == inStockName.ToLower())
                             shareExist = true;
                     }
                 }
             }
             if (wrongNameIndex == true)
             {
                 throw new StockExchangeException("fsd");
             }
             return shareExist;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             List<Decimal> valueList=new List<decimal>();
             bool wrongName = true;
             Index indexForValue = new Index();
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     indexForValue = index;
                     wrongName = false;
                     foreach ( Share share in index.IndexListShare)
                     {
                         int rezultat = DateTime.Compare(inTimeStamp, share.GetErlierTime());
                         if (rezultat >= 0)
                         {
                             valueList.Add(GetStockPrice(share.StockName, inTimeStamp));
                         }                        
                     }
                 }
             }
             if (wrongName == true)
             {
                 throw  new StockExchangeException("fsd");
             }
             if (indexForValue.IndexType == IndexTypes.AVERAGE)
             {
                 return indexForValue.IndexValue(valueList);
             }
             else
             {
                 decimal totalValue = 0;
                 totalValue = weightedAverage(indexForValue, inTimeStamp);
                 List<Decimal> weighedAverageIndex =new List<decimal>();
                 foreach (Share share in indexForValue.IndexListShare)
                 {
                     int dateResult = DateTime.Compare(inTimeStamp, share.GetErlierTime());   
                     if (dateResult >= 0)
                     {
                         weighedAverageIndex.Add(GetStockPrice(share.StockName, inTimeStamp) * share.NumberOfShares / totalValue);
                     }                     
                 }
                 Decimal result = 0;
                 int counter = 0;
                 foreach (Share share  in indexForValue.IndexListShare)
                 {
                     int rezultat = DateTime.Compare(inTimeStamp, share.GetErlierTime());
                     if (rezultat >= 0)
                     {
                         result += GetStockPrice(share.StockName, inTimeStamp) * weighedAverageIndex[counter];
                         counter++;
                     }
                 }
                 result = Math.Round(result, 3);
                 return result;
             }
         }
         private Decimal weightedAverage(Index indexForWeightedAverage, DateTime dateTim)
         {
             Decimal totalValue = 0;
             foreach (Share share in indexForWeightedAverage.IndexListShare)
             {
                 int rezultat = DateTime.Compare(dateTim, share.GetErlierTime());   //za vremena manja od najmanjega, ta dionica se ne gleda
                 if (rezultat >= 0)
                 {
                     totalValue += share.NumberOfShares * GetStockPrice(share.StockName, dateTim);
                 }               
             }
             totalValue=Math.Round(totalValue, 3);
             return totalValue;
         }

         public bool IndexExists(string inIndexName)
         {
             bool flag = false;
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     flag = true;
                 }
             }
             return flag;
         }

         public int NumberOfIndices()
         {
             int counter = 0;
             foreach (Index index in indexList)
             {
                 counter++;
             }
             return counter;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int counter = 0;
             bool exactName = false;
             foreach (Index index in indexList)
             {
                 if (index.IndexName == inIndexName.ToLower())
                 {
                     exactName = true;
                     foreach (Share share in index.IndexListShare)
                     {
                         counter++;
                     }
                 }
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             return counter;
         }


         public void CreatePortfolio(string inPortfolioID)
         {
             bool nameExist = false;
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     nameExist = true;
                 }
             }
             if (nameExist==true)
             {
                 throw new StockExchangeException("fsd");
             }
             Portfolio newPortfolio=new Portfolio(inPortfolioID);
             portfolioList.Add(newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool exactPortfolio = false;
             bool exactShare = false;
             Portfolio portfolioToAddStock=new Portfolio();
             Share shareToAddInPortfolio=new Share();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactPortfolio = true;
                     portfolioToAddStock = portfolio;    //nadje se porteflej u koji se ubacuje dionica
                 }
             }
             if (exactPortfolio == false)
             {
                 throw new StockExchangeException("fsa");
             }
             foreach (Share share in shareList)
             {
                 if (share.StockName == inStockName.ToLower())
                 {
                     exactShare = true;
                     shareToAddInPortfolio = share;     //dionica koja se ubacuje
                 }
             }
             if (exactShare == false)
             {
                 throw new StockExchangeException("fsd");
             }

             portfolioToAddStock.AddShareToPortfolio(shareToAddInPortfolio, numberOfShares, numberOfSharesInAllPortfolies(shareToAddInPortfolio));


         }
         private int numberOfSharesInAllPortfolies(Share share)
         {
             int result = 0;
             foreach (Portfolio  portfolio in portfolioList)
             {
                 result += portfolio.numberOfSharesInThisPortfolio(share);
             }
             return result;
         }



         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool exactPortfolio = false;
             bool exactShare = false;
             Portfolio portfolioForShareRemove=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactPortfolio = true;
                     portfolioForShareRemove = portfolio;
                 }
             }
             if (exactPortfolio == false)
             {
                 throw new StockExchangeException("fsd");
             }
             portfolioForShareRemove.RemoveShares(inStockName.ToLower(),numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             bool exactPortfolio = false;
             Portfolio tmpPortfolio=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactPortfolio = true;
                     tmpPortfolio = portfolio;
                 }
             }
             if (exactPortfolio == false)
             {
                 throw new Exception("fsd");
             }
             tmpPortfolio.RemoveStock(inStockName.ToLower());
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             bool exactName = false;
             Portfolio tmpPortfolio=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactName = true;
                     tmpPortfolio = portfolio;
                 }
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             return tmpPortfolio.NumberOfStcock();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool flag = false;
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     flag = true;
                 }
             }
             return flag;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool flag = false;
             Portfolio tmpPortfolio=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     flag = true;
                     tmpPortfolio = portfolio;
                 }
             }
             if (flag == false)
             {
                 throw new StockExchangeException("fsd");
             }
             return tmpPortfolio.CheckSctockExist(inStockName.ToLower());

         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             bool exactPortfolio = false;
             bool exactShare = false;
             Portfolio tmpPortfolio=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactPortfolio = true;
                     tmpPortfolio = portfolio;
                 }
             }
             if (exactPortfolio == false)
             {
                 throw new StockExchangeException("fsd");
             }
             return tmpPortfolio.NumberOfSharesInPortfolio(inStockName.ToLower());
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             bool exactName = false;
             Portfolio tmpPortfolio=new Portfolio();
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactName = true;
                     tmpPortfolio = portfolio;
                 }
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             List<Share> tmpShares= new List<Share>();
             List<int> tmpNumberOfShares=new List<int>();
             tmpShares = tmpPortfolio.GetListOfShares();
             tmpNumberOfShares = tmpPortfolio.GetNumberOfSheres();
             int brojac = 0;
             decimal result = 0;
             foreach (Share share  in tmpShares)
             {
                 int rez = DateTime.Compare(timeStamp, share.GetErlierTime());
                 if (rez >= 0)
                 {
                     result += GetStockPrice(share.StockName, timeStamp)*tmpNumberOfShares[brojac];
                     brojac++;
                 }
             }
             if (brojac == 0)
             {
                 throw new StockExchangeException("fsd");
             }
             result = Math.Round(result, 3);
             return result;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             bool exactName = false;
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     exactName = true;
                 }
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             DateTime begin= new DateTime(Year, Month,1, 00,00,00);
             DateTime end = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             Decimal valueOnBegin = GetPortfolioValue(inPortfolioID, begin);
             Decimal valueOnEnd = GetPortfolioValue(inPortfolioID, end);

             decimal result = 0;

             result = (valueOnEnd - valueOnBegin)/valueOnBegin*100;
             result = Math.Round(result, 3);
             return result;

         }
     }



     class Portfolio
     {
         private string id;
         List<Share> portfolioShares = new List<Share>();
         List<int> numberOfShares = new List<int>();

         public string Id { get { return id; } set { id = value; } }

         public Portfolio(string _id)
         {
             Id = _id;
         }

         public Portfolio() { }

         public void AddShareToPortfolio(Share newShare, int numberOfSharesToAdd, int totalNumbersOfShares)
         {
             int position = 0;
             int counter = 0;
             bool shareExist = false;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == newShare.StockName)
                 {
                     shareExist = true;
                     position = counter;
                 }
                 counter++;
             }
             if (shareExist == false)
             {
                 if (numberOfSharesToAdd + totalNumbersOfShares > newShare.NumberOfShares)
                 {
                     throw new StockExchangeException("fsd");
                 }
                 portfolioShares.Add(newShare);
                 numberOfShares.Add(numberOfSharesToAdd);
             }
             else
             {
                 if (numberOfSharesToAdd + totalNumbersOfShares > newShare.NumberOfShares)
                 {
                     throw new StockExchangeException("fsd");
                 }
                 int numberToAdd = numberOfShares[position] + numberOfSharesToAdd;
                 numberOfShares[position] = numberToAdd;
             }
         }

         public int numberOfSharesInThisPortfolio(Share shareToCheck)
         {
             bool flag = false;
             int position = 0;
             int counter = 0;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == shareToCheck.StockName)
                 {
                     flag = true;
                     position = counter;
                 }
                 counter++;
             }
             if (flag == true)
             {
                 return numberOfShares[position];
             }
             else
             {
                 return 0;
             }
         }
         public void RemoveShares(string name, int numberOfSharesToRemove)
         {
             bool exactName = false;
             int counter = 0;
             int position = 0;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == name)
                 {
                     exactName = true;
                     position = counter;
                 }
                 counter++;
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             if (numberOfSharesToRemove > numberOfShares[position])
             {
                 throw new StockExchangeException("fsd");
             }
             if (numberOfSharesToRemove == numberOfShares[position])
             {
                 numberOfShares.RemoveAt(position);
                 portfolioShares.RemoveAt(position);
             }
             if (numberOfSharesToRemove < numberOfShares[position])
             {
                 int tmoNumber = numberOfShares[position];
                 tmoNumber -= numberOfSharesToRemove;
                 numberOfShares[position] = tmoNumber;
             }
         }

         public int NumberOfSharesInPortfolio(string shareName)
         {
             bool exactName = false;
             int counter = 0;
             int position = 0;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == shareName)
                 {
                     exactName = true;
                     position = counter;
                 }
                 counter++;
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsa");
             }
             return numberOfShares[position];
         }

         public int NumberOfStcock()
         {
             return portfolioShares.Count;
         }


         public void RemoveStock(string shareName)
         {
             bool exactName = false;
             int counter = 0;
             int position = 0;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == shareName)
                 {
                     exactName = true;
                     position = counter;
                 }
                 counter++;
             }
             if (exactName == false)
             {
                 throw new StockExchangeException("fsd");
             }
             portfolioShares.RemoveAt(position);
             numberOfShares.RemoveAt(position);
         }

         public bool CheckSctockExist(string name)
         {
             bool flag = false;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == name)
                 {
                     flag = true;
                 }
             }
             return flag;
         }

         public List<Share> GetListOfShares()
         {
             return portfolioShares;
         }

         public List<int> GetNumberOfSheres()
         {
             return numberOfShares;
         }

         public void TryDeleteShare(string shareName)
         {
             bool flag = false;
             int counter = 0;
             int position = 0;
             foreach (Share share in portfolioShares)
             {
                 if (share.StockName == shareName)
                 {
                     flag = true;
                     position = counter;
                 }
                 counter++;
             }
             if (flag == true)
             {
                 portfolioShares.RemoveAt(position);
                 numberOfShares.RemoveAt(position);
             }
         }
     }

     class Index
     {
         private string indexName;
         private IndexTypes indexType;
         public List<Share> IndexListShare = new List<Share>();

         public string IndexName { get { return indexName; } set { indexName = value; } }
         public IndexTypes IndexType { get { return indexType; } set { indexType = value; } }

         public Index(string _indexName, IndexTypes _indexType)
         {
             IndexName = _indexName.ToLower();
             IndexType = _indexType;
         }

         public Index() { }

         public bool AddShareToIndex(Share newShare)
         {
             bool flag = false;
             foreach (Share share in IndexListShare)
             {
                 if (share.StockName == newShare.StockName)
                 {
                     flag = true;
                 }
             }
             if (flag == false)
             {
                 IndexListShare.Add(newShare);
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public Decimal IndexValue(List<Decimal> listValue)
         {
             decimal result = 0;
             foreach (Decimal number in listValue)
             {
                 result += number;
             }
             result = result / listValue.Count;
             result = Math.Round(result, 3);
             return result;
         }

         public void TryDeleteShare(string shareName)
         {
             bool flag = false;
             int counter = 0;
             int position = 0;
             foreach (Share share in IndexListShare)
             {
                 if (share.StockName == shareName)
                 {
                     flag = true;
                     position = counter;
                 }
                 counter++;
             }
             if (flag == true)
             {
                 IndexListShare.RemoveAt(position);
             }
         }

     }

     public class Share
     {
         private string stockName;
         private long numberOfShares;
         private Decimal initalPrice;
         private DateTime timeStamp;
         private Decimal stockValue;
         private DateTime initalTime;

         private List<Decimal> valueList = new List<decimal>();
         private List<DateTime> timeList = new List<DateTime>();

         public string StockName { get { return stockName; } set { stockName = value.ToLower(); } }
         public long NumberOfShares { get { return numberOfShares; } set { numberOfShares = value; } }
         public Decimal InitialPrice { get { return initalPrice; } set { initalPrice = value; } }
         public DateTime TimeStamp { get { return timeStamp; } set { timeStamp = value; } }
         public Decimal StockValue { get { return stockValue; } set { stockValue = value; } }

         public Share(string _stockName, long _numberOfShares, Decimal _initalPrice, DateTime _timeStamp)
         {
             StockName = _stockName;
             NumberOfShares = _numberOfShares;
             InitialPrice = _initalPrice;
             TimeStamp = _timeStamp;
             StockValue = _initalPrice;
             initalTime = _timeStamp;
             AddValueToList();
         }
         public Share() { }
         public void AddValueToList()   //dodaje nove cijene i sortira ih po vremenu, vremenski zadnja ce uvijek bit u timeStamp i valueStock, inicijalna se ne gleda
         {
             int counter = 0;
             if (timeList.Count == 0)
             {
                 timeList.Add(timeStamp);
                 valueList.Add(stockValue);
             }
             else
             {
                 foreach (DateTime datetime in timeList)
                 {
                     int result = DateTime.Compare(timeStamp, datetime);
                     if (result == 0)
                     {
                         throw new StockExchangeException("fsd");     // kada se postavlja nova cijena postojecoj dionici ne smi se u isto vrijeme zadat vise cijena
                     }
                     if (result > 0)
                     {
                         counter++;
                     }
                 }

                 timeList.Insert(counter, timeStamp);
                 valueList.Insert(counter, stockValue);
             }
             TimeStamp = timeList.Last();   //vremenski zadnja ce bit u timestamppu
             StockValue = valueList.Last();   //vremeski zadnja cijena je zapisana u stockValue
         }

         public Decimal FindStockPrice(DateTime wandetime)
         {
             if (valueList.Count == 0)
             {
                 return initalPrice;
             }
             int counter = 0;
             int tmp = DateTime.Compare(wandetime, timeList.First());    //to san zadnje mjenja
             if (tmp < 0)
             {
                 throw new StockExchangeException("fsd");
             }
             foreach (DateTime datetime in timeList)
             {
                 int result = DateTime.Compare(wandetime, datetime);
                 if (result >= 0)
                 {
                     counter++;
                 }
             }
             counter -= 1;
             if (counter < 0)
             {
                 return initalPrice;
             }
             else
             {
                 return valueList[counter];
             }

         }

         public DateTime GetErlierTime()
         {
             return timeList.First();
         }

         public decimal GetEarlierValue()
         {
             return valueList.First();
         }

     }
}
