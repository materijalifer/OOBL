﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    //predaja
    public class Portfelj
    {
        public string Id;
        public Dictionary<string, int> ListOfStocks = new Dictionary<string, int>();




    }
    public class Indeks
    {
        public string Name;
        public IndexTypes type;
        public List<Stock> ListOfStocks = new List<Stock>();



    }
    public class Stock
    {
        public string Name;
        public Decimal Price;
        public long numberOfStocks;
        public DateTime TimeActive;
        public Dictionary<DateTime, decimal> History = new Dictionary<DateTime, decimal>();
        public long ostalo;

    }
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Stock _stock;
        private List<Stock> stockList = new List<Stock>();
        private Indeks _index;
        private List<Indeks> indexList = new List<Indeks>();
        private bool _postojanjeIndeksa = false;
        private Portfelj _portfelj;
        private List<Portfelj> listOfPortfelj = new List<Portfelj>();
        private bool portfeljExist = false;


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            bool upisi = true;
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Nemoguca cijena dionice");
                upisi = false;
            }
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Nemoguca  dionica");
                upisi = false;
            }

            if (inInitialPrice > 0)
            {
                _stock = new Stock();

                _stock.Name = inStockName;
                _stock.numberOfStocks = inNumberOfShares;
                _stock.Price = inInitialPrice;
                _stock.TimeActive = inTimeStamp;
                _stock.ostalo = inNumberOfShares;
                upisi = true;
            }

            foreach (var item in stockList)
            {
                if (item.Name.ToUpper() == inStockName.ToUpper())
                {
                    upisi = false;
                    throw new StockExchangeException("takva dionica vec postoji");
                    break;
                }
            }


            if (upisi == true)
            {
                stockList.Add(_stock);

            }

        }

        public void DelistStock(string inStockName)
        {
            string kljuc = "";
            Stock d = new Stock();
            Indeks i = new Indeks();
            bool nasao = false;
            foreach (var dionice in stockList)
            {
                if (dionice.Name.ToUpper() == inStockName.ToUpper())
                {
                    d = dionice;
                    nasao = true;
                }

            }
            if (nasao == true)
            {
                stockList.Remove(d);


                foreach (var i1 in indexList)
                {
                    foreach (var d2 in i1.ListOfStocks)
                    {
                        if (d2.Name.ToUpper() == inStockName.ToUpper())
                        {

                            d = d2;
                        }
                    }
                    i1.ListOfStocks.Remove(d);
                }

                foreach (var p in listOfPortfelj)
                {
                    foreach (var dion in p.ListOfStocks.Keys)
                    {
                        if (dion.ToUpper() == inStockName.ToUpper())
                        {
                            kljuc = dion;
                        }
                    }
                    p.ListOfStocks.Remove(kljuc);
                }

            }
            if (nasao == false)
            {
                throw new StockExchangeException("ne postoji dionica");
            }
        }

        public bool StockExists(string inStockName)
        {
            foreach (var item in stockList)
            {
                if (item.Name.ToUpper() == inStockName.ToUpper())
                {
                    return true;
                }


            }

            return false;
        }

        public int NumberOfStocks()
        {
            int x = 0;
            foreach (var stock in stockList)
            {
                x++;
            }
            return x;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            bool nasao = false;
            foreach (var dionice in stockList)
            {
                if (dionice.Name.ToUpper() == inStockName.ToUpper())
                {
                    nasao = true;
                    if (inStockValue > 0)
                    {
                        dionice.History.Add(dionice.TimeActive, dionice.Price);
                        dionice.Price = inStockValue;
                        dionice.TimeActive = inIimeStamp;
                        break;

                    }
                    else
                    {
                        throw new StockExchangeException("cijena dionice mora biti veca od nule!");
                        break;
                    }

                }


            }
            if (nasao == false)
            {
                throw new StockExchangeException("ne postoji ta dionica");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {

            decimal x = 0;
            bool nasao = false;
            foreach (var item in stockList)
            {
                if (item.Name.ToUpper() == inStockName.ToUpper())
                {
                    nasao = true;
                    if (item.TimeActive <= inTimeStamp)
                    {
                        x = item.Price;

                    }
                    if (item.TimeActive > inTimeStamp)
                        foreach (var i in item.History.Keys)
                        {
                            if (i <= inTimeStamp)
                            {
                                x = item.History[i];
                            }

                        }

                }
            }
            if (nasao == false)
            {

                throw new StockExchangeException("ne postoji ta dionica");


            }
            else
            {
                return x;
            }




        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            bool nasao = false;
            decimal price = 0;
            foreach (var dionice in stockList)
            {
                if (dionice.Name.ToUpper() == inStockName.ToUpper())
                {
                    var t = dionice.History.Keys.Min();

                    price = dionice.History[t];
                    nasao = true;
                }

            }

            if (nasao == true)
            {
                return price;
            }

            else
            {
                throw new StockExchangeException("ne postoji!");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            bool nasao = false;
            decimal price = 0;
            foreach (var item in stockList)
            {
                if (item.Name.ToLower() == inStockName.ToLower())
                {
                    nasao = true;
                    price = item.Price;
                }
            }
            if (nasao == true)
            {
                return price;

            }
            else
            {
                throw new StockExchangeException("ne postoji ta dionica!");

            }
        }



        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            bool nasao = false;
            foreach (var item in indexList)
            {
                if (item.Name.ToUpper() == inIndexName.ToUpper())
                {
                    nasao = true;

                }
            }


            if (nasao == false)
            {
                _index = new Indeks();
                _index.Name = inIndexName;
                _index.type = inIndexType;
                indexList.Add(_index);

            }
            else
            {
                throw new StockExchangeException("Već postoji taj indeks");
            }
        }


        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            bool dodaj = false;

            if (StockExists(inStockName) && IndexExists(inIndexName))
            {
                dodaj = true;
            }
            if (dodaj == true)
            {
                foreach (var indeksi in indexList)
                {
                    if (indeksi.Name.ToLower() == inIndexName.ToLower())
                    {
                        foreach (var dionice in stockList)
                            if (dionice.Name.ToLower() == inStockName.ToLower())
                            {
                                indeksi.ListOfStocks.Add(dionice);
                            }

                    }
                }
            }
            else
            {
                throw new StockExchangeException("ili ne postoji index ili dionica");
            }

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            bool dodaj = false;

            if (IndexExists(inIndexName))
            {
                if (IsStockPartOfIndex(inIndexName, inStockName))
                {
                    dodaj = true;
                }

            }
            if (dodaj == true)
            {
                foreach (var indeksi in indexList)
                {
                    if (indeksi.Name.ToLower() == inIndexName.ToLower())
                    {
                        foreach (var dionice in stockList)
                            if (dionice.Name.ToLower() == inStockName.ToLower())
                            {
                                indeksi.ListOfStocks.Remove(dionice);
                            }

                    }
                }
            }
            else
            {
                throw new StockExchangeException("ili ne postoji index ili dionica");
            }

        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            bool n = false;
            foreach (var item in indexList)
            {
                if (item.Name.ToUpper() == inIndexName.ToUpper())
                {
                    foreach (var item2 in item.ListOfStocks)
                    {
                        if (item2.Name.ToUpper() == inStockName.ToUpper())
                        {
                            n = true;
                        }
                    }
                }
            }
            return n;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal indexValue = 0;
            decimal sum = 0;
            decimal tezFak = 0;

            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("ne postoji index");
            }
            else
            {


                foreach (var indeksi in indexList)
                {

                    if (indeksi.Name.ToUpper() == inIndexName.ToUpper())
                    {

                        if (indeksi.type == IndexTypes.AVERAGE)
                        {
                            foreach (var item in indeksi.ListOfStocks)
                            {
                                sum = sum + item.Price;
                            }
                            try
                            {
                                indexValue = Math.Round(sum / indeksi.ListOfStocks.Count, 3);
                            }
                            catch (Exception)
                            {

                                indexValue = 0;
                            }

                        }
                        if (indeksi.type == IndexTypes.WEIGHTED)
                        {
                            foreach (var item in indeksi.ListOfStocks)
                            {
                                sum = sum + item.Price * item.numberOfStocks;
                            }

                            foreach (var item2 in indeksi.ListOfStocks)
                            {
                                tezFak = (item2.Price * item2.numberOfStocks) / sum;
                                indexValue += tezFak * item2.Price;
                            }



                        }
                    }

                }

                return Math.Round(indexValue, 3);
            }
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (var indeks in indexList)
            {
                if (indeks.Name.ToUpper() == inIndexName.ToUpper())
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            int x = 0;
            foreach (var i in indexList)
            {
                x++;
            }
            return x;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            int num = 0;
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("ne postoji index");
            }
            else
            {
                foreach (var indeks in indexList)
                {
                    if (indeks.Name.ToUpper() == inIndexName.ToUpper())
                    {
                        foreach (var listOfStock in indeks.ListOfStocks)
                        {
                            num++;
                        }
                    }
                }
                return num;
            }

        }



        public void CreatePortfolio(string inPortfolioID)
        {

            if (PortfolioExists(inPortfolioID))
            {

                throw new StockExchangeException("Već postoji portfelj !");
            }
            else
            {
                _portfelj = new Portfelj();
                _portfelj.Id = inPortfolioID;

                listOfPortfelj.Add(_portfelj);
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock dionica = new Stock();
            foreach (var v in stockList)
            {
                if (inStockName.ToUpper() == v.Name.ToUpper())
                {
                    dionica = v;
                }
            }
            if (dionica.ostalo < numberOfShares)
            {
                throw new StockExchangeException("nemoguci portfelj!");

            }
            if (numberOfShares <= 0 || !StockExists(inStockName) || !PortfolioExists(inPortfolioID))
            {


                throw new StockExchangeException("nemoguci portfelj!");

            }


            else
            {


                foreach (var p in listOfPortfelj)
                {
                    if (p.Id == inPortfolioID)
                    {
                        foreach (var d in stockList)
                        {
                            if (d.Name.ToUpper() == inStockName.ToUpper())
                            {
                                if (p.ListOfStocks.Keys.Contains(d.Name))
                                {
                                    p.ListOfStocks[d.Name] = p.ListOfStocks[d.Name] + numberOfShares;
                                }
                                if (!p.ListOfStocks.Keys.Contains(d.Name))
                                {
                                    p.ListOfStocks.Add(d.Name, numberOfShares);
                                }
                                d.ostalo = d.ostalo - numberOfShares;
                            }
                        }
                    }



                }
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0 || !StockExists(inStockName) || !PortfolioExists(inPortfolioID))
            {

                throw new StockExchangeException("nemoguci portfelj!");

            }
            else
            {
                foreach (var portfelj in listOfPortfelj)
                {
                    if (portfelj.Id == inPortfolioID)
                    {
                        if (portfelj.ListOfStocks.Keys.Contains(inStockName))
                        {
                            portfelj.ListOfStocks[inStockName] = portfelj.ListOfStocks[inStockName] - numberOfShares;
                            if (portfelj.ListOfStocks[inStockName] <= 0)
                            {
                                portfelj.ListOfStocks.Remove(inStockName);
                            }
                        }
                        else
                        {
                            throw new StockExchangeException("nemoguci portfelj!");
                        }
                    }

                }
            }


        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Greška");

            }
            else
            {
                foreach (var p in listOfPortfelj)
                {

                    if (p.Id == inPortfolioID)
                    {
                        if (p.ListOfStocks.Keys.Contains(inStockName))
                        {
                            p.ListOfStocks.Remove(inStockName);
                        }
                        else
                        {
                            throw new StockExchangeException("Greška");
                        }
                    }

                }
            }
        }

        public int NumberOfPortfolios()
        {
            int x = 0;
            foreach (var i in listOfPortfelj)
            {
                x++;
            }
            return x;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Greška");

            }
            else
            {
                int r = 0;
                foreach (var p in listOfPortfelj)
                {
                    if (p.Id == inPortfolioID)
                    {
                        foreach (var i in p.ListOfStocks)
                        {
                            r++;
                        }
                    }
                }
                return r;
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {

            foreach (var t in listOfPortfelj)
            {
                if (t.Id == inPortfolioID)
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {

            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Greška");
            }
            else
            {
                foreach (var p in listOfPortfelj)
                {
                    if (p.Id == inPortfolioID)
                    {
                        foreach (var s in p.ListOfStocks)
                        {
                            if (s.Key.ToUpper() == inStockName.ToUpper())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }

        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Greška");
            }
            else
            {
                int num = 0;
                foreach (var portfelji in listOfPortfelj)
                {

                    if (portfelji.Id == inPortfolioID)
                    {
                        if (portfelji.ListOfStocks.Keys.Contains(inStockName))
                        {
                            num = portfelji.ListOfStocks[inStockName];
                        }

                    }


                }
                return num;
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal vrijednost = 0;

            try
            {
                foreach (var p in listOfPortfelj)
                {

                    if (p.Id == inPortfolioID)
                    {
                        foreach (var d in p.ListOfStocks)
                        {

                            foreach (var dp in stockList)
                            {
                                if (dp.Name.ToUpper() == d.Key.ToUpper())
                                {
                                    if (dp.TimeActive <= timeStamp)
                                    {
                                        vrijednost += dp.Price * p.ListOfStocks[dp.Name];
                                    }
                                    else
                                    {
                                        var x = dp.History.Keys.Where(vrijeme => vrijeme <= timeStamp).Max();

                                        vrijednost += dp.History[x] * p.ListOfStocks[dp.Name];

                                    }
                                }
                            }

                        }
                    }

                }

            }
            catch (Exception)
            {
                throw new StockExchangeException("Greška");
            }

            return Math.Round(vrijednost, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {

            decimal begin = 0;
            decimal end = 0;
            decimal change = 0;

            try
            {
                foreach (var portfelji in listOfPortfelj)
                {
                    if (portfelji.Id == inPortfolioID)
                    {

                        end = this.GetPortfolioValue(portfelji.Id, new DateTime(Year, Month, 30, 23, 59, 59, 999));
                        begin = this.GetPortfolioValue(portfelji.Id, new DateTime(Year, Month, 1, 0, 0, 0, 0));
                    }

                }
            }
            catch (Exception)
            {

                throw new StockExchangeException("greska");
            }

            try
            {
                return Math.Round(Math.Abs((end - begin) / begin * 100), 3);
            }
            catch (Exception)
            {

                return 0;
            }


        }

    }
}
