using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

	//STOCK EXCHANGE
    public class StockExchange : IStockExchange
    {
        StockRepository stockRepository = new StockRepository();
        IndexRepository indexRepository = new IndexRepository();
        PortofolioRepository portfolioRepository = new PortofolioRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock stock = StockFactory.CreateStock(inStockName, inInitialPrice, inTimeStamp, inNumberOfShares);
            stockRepository.AddStock(stock);
        }

        public void DelistStock(string inStockName)
        {
            stockRepository.RemoveStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return stockRepository.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return stockRepository.StockCount();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            stockRepository.SetStockPrice(inStockName, inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return stockRepository.GetStockPrice(inStockName, inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return stockRepository.GetInitialPrice(inStockName);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return stockRepository.GetLastPrice(inStockName);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index = IndexFactory.CreateIndex(inIndexName, inIndexType);
            indexRepository.AddIndex(index);

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = indexRepository.GetIndex(inIndexName);
            Stock stock = stockRepository.GetStock(inStockName);
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = indexRepository.GetIndex(inIndexName);
            Stock stock = stockRepository.GetStock(inStockName);
            index.RemoveStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = indexRepository.GetIndex(inIndexName);
            Stock stock = stockRepository.GetStock(inStockName);
            return index.IsPartOf(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = indexRepository.GetIndex(inIndexName);
            return index.GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return indexRepository.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return indexRepository.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = indexRepository.GetIndex(inIndexName);
            return index.NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio portofolio = PortofolioFactory.CreatePortofolio(inPortfolioID);
            portfolioRepository.AddPortofolio(portofolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            Stock stock = stockRepository.GetStock(inStockName);
            for (int i = 0; i < numberOfShares; i++)
            {
                if (stock.Count > 0)
                {
                    portfolio.AddStock(stock);
                }
                else
                {
                    break;
                }
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            Stock stock = stockRepository.GetStock(inStockName);
            for (int i = 0; i < numberOfShares; i++)
            {
                portfolio.RemoveStock(stock);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {

            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            Stock stock = stockRepository.GetStock(inStockName);
            while (portfolio.IsStockInPortfolio(stock))
            {
                portfolio.RemoveStock(stock);
            }

        }

        public int NumberOfPortfolios()
        {
            return portfolioRepository.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            return portfolio.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolioRepository.PortofolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            Stock stock = stockRepository.GetStock(inStockName);
            return portfolio.IsStockInPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            Stock stock = stockRepository.GetStock(inStockName);
            return portfolio.NumberOfShares(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            return portfolio.Value(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = portfolioRepository.GetPortofolio(inPortfolioID);
            return portfolio.MonthPrecentChange(Year, Month);
        }
    }

	//STOCK REPOSITORY
    class StockRepository
    {
        List<Stock> stocks =new List<Stock>();
        
        //PRAVILO VELIKIH SLOVA
        public void AddStock(Stock stock)
        {
            if (stocks.Find(s => s.Name == stock.Name) == null)
            {
                stocks.Add(stock);
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public void RemoveStock(string name) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                stocks.Remove(stock);
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public bool StockExists(string name) 
        {
            return stocks.Exists(s => s.Name == name);
        }

        public int StockCount() 
        {
            return stocks.Count;
        }

        public void SetStockPrice(string name, DateTime timeStamp, decimal price) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                stock.AddPrice(price, timeStamp);
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public decimal GetStockPrice(string name,DateTime timeStamp) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                StockPrice last = new StockPrice();
                foreach (StockPrice sp in stock.Prices) 
                {
                    if (timeStamp > sp.Start) 
                    {
                        last = sp;
                    }        
                }
                return last.Value;
            }
            throw new StockExchangeException("");
        }

        public decimal GetInitialPrice(string name) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                return stock.InitialPrice;
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public decimal GetLastPrice(string name) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                return stock.Prices[stock.Prices.Count - 1].Value;
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public Stock GetStock(string name) 
        {
            Stock stock = stocks.Find(s => s.Name == name);
            if (stock != null)
            {
                return stock;
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }
    }

	//INDEX REPOSITORY
    class IndexRepository
    {
       List<Index> indices = new List<Index>();

       //PRAVILO VELIKIH SLOVA
        public void AddIndex(Index index) 
        {
            if (indices.Find(i => i.Name == index.Name) == null)
            {
                indices.Add(index);
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public Index GetIndex(string name) 
        {
            Index index = indices.Find(i => i.Name == name);
            if (index != null)
            {
                return index;
            }
            else 
            {
                throw new StockExchangeException("");
            }
        }

        public bool IndexExists(string name) 
        {
            return indices.Exists(i => i.Name == name);    
        }

        public int NumberOfIndices() 
        {
            return indices.Count;
        }
    }

	//PORTFOLIO REPOSITORY
    class PortofolioRepository
    {
        List<Portfolio> portofolios = new List<Portfolio>();

       public void AddPortofolio(Portfolio portofolio) 
       {
           if (portofolios.Find(p => p.ID == portofolio.ID) == null)
           {
               portofolios.Add(portofolio);
           }
           else 
           {
               throw new StockExchangeException(""); 
           }
       }

       public Portfolio GetPortofolio(string id) 
       {
           Portfolio portofolio = portofolios.Find(p => p.ID == id);
           if (portofolio != null)
           {
               return portofolio;
           }
           else 
           {
               throw new StockExchangeException("");
           }
       }

       public bool PortofolioExists(string id) 
       {
           return portofolios.Exists(p => p.ID == id);
       }

       public int NumberOfPortfolios() 
       {
           return portofolios.Count;
       }
    }

	//STOCK FACTORY
	static class StockFactory
    {
         public static Stock CreateStock(string name, decimal initialPrice, DateTime start, long count) 
         {
             return new Stock(name, initialPrice, start, count);
         }
     }
	 //INDEX FACTORY
	static class IndexFactory
    {
        public static Index CreateIndex(string name, IndexTypes type)
        {
            if (type == IndexTypes.AVERAGE) 
            {
                return new AverageIndex(name);
            }
            if (type == IndexTypes.WEIGHTED) 
            {
                return new WeightedIndex(name);
            }
            return null;
        }
    }
	
	//PORTFOLIO FACTORY
	    static class PortofolioFactory
    {
        public static Portfolio CreatePortofolio(string id)
        {
            return new Portfolio(id);
        }
    }
         //STOCK
    class Stock
    {
        string name;
        //List<DateTime> startDates = new List<DateTime>();       
        //List<decimal> prices = new List<decimal>();
        List<StockPrice> stockPrices = new List<StockPrice>();
        decimal initialPrice;
        long count;

        public Stock(string name, decimal initialPrice, DateTime start, long count) 
        {
            this.name = name;
            if (initialPrice > 0)
            {
                StockPrice price = new StockPrice(initialPrice, start);
                this.initialPrice = initialPrice;
                stockPrices.Add(price);
            }
            else 
            {
                throw new StockExchangeException("");
            }
            if (count > 0) 
            {
                this.count = count;
            }
            else
            {
                throw new StockExchangeException("");               
            }            
            //startDates.Add(start);
        }

        public string Name
        {
            get { return name; }
        }

        public decimal InitialPrice
        {
            get { return initialPrice; }
        }

        public List<StockPrice> Prices 
        {
            get { return stockPrices; }
        }

        public long Count 
        {
            get { return count; }
            set { count = value; }
        }

        public void AddPrice(decimal value, DateTime timeStamp) 
        {
            if (stockPrices.Find(sp => sp.Start > timeStamp)!=null) 
            {
                return;
            }
            stockPrices.Add(new StockPrice(value, timeStamp));
        }
    }

	// STOCK PRICE
    public class StockPrice
    {
        decimal price;
        DateTime start;

        public StockPrice() { }

        public StockPrice(decimal price, DateTime start) 
        {
            this.price = price;
            this.start = start;
        }
        
        public decimal Value
        {
            get { return price; }
            set { price = value; }
        }

        public DateTime Start 
        {
            get { return start; }
            set { start = value; }
        }
    }

	//INDEX
    abstract class Index
    {
        protected string name;
        protected List<Stock> stocks = new List<Stock>();
       
        public string Name 
        {
            get { return name; }
        }

        public void AddStock(Stock stock) 
        {
            if (!stocks.Contains(stock))
            {
                stocks.Add(stock);
            }
        }

        public void RemoveStock(Stock stock) 
        {
            stocks.Remove(stock);
        }

        public bool IsPartOf(Stock stock) 
        {
            return stocks.Contains(stock);
        }

        public int NumberOfStocks() 
        {
            return stocks.Count;
        }

        public abstract decimal GetIndexValue(DateTime timeStamp);
    }
	//AVERAGE INDEX
	 class AverageIndex:Index
    {
        public AverageIndex(string name) 
        {
            this.name = name;
        }

        public override decimal GetIndexValue(DateTime timeStamp)
        {
            decimal value = 0m;
            long count=0;
            foreach (Stock stock in stocks) 
            {
                value += stock.Prices.Find(sp => sp.Start > timeStamp).Value * stock.Count;
                count += stock.Count;
            }
            return Convert.ToDecimal(value / count);
        }
    }

	//WEIGHTED INDEX
    class WeightedIndex:Index
    {
         public WeightedIndex(string name) 
        {
            this.name = name;
        }
        
        public override decimal GetIndexValue(DateTime timeStamp)
        {
            decimal faktor;
            decimal suma = 0m;
            decimal value = 0m;
            foreach (Stock stock in stocks)
            {
                try
                {
                    suma += stock.Count * stock.Prices.Find(sp => sp.Start > timeStamp).Value;
                }
                catch 
                {
                    suma += stock.Count * stock.Prices[stock.Prices.Count - 1].Value;
                }
            }
            foreach (Stock stock in stocks)
            {
                try
                {
                    faktor = stock.Count * stock.Prices.Find(sp => sp.Start > timeStamp).Value / suma;
                    value += faktor * stock.Prices.Find(sp => sp.Start > timeStamp).Value;
                }
                catch 
                {
                    faktor = stock.Count * stock.Prices[stock.Prices.Count - 1].Value / suma;
                    value += faktor * stock.Prices[stock.Prices.Count - 1].Value;
                }
                
            }
            return value;
        }
    }


	//PORTFOLIO
    class Portfolio
    {
        string id;
        List<Stock> stocks = new List<Stock>();

        public Portfolio(string id) 
        {
            this.id = id;
        }

        public string ID 
        {
            get { return id; }
            set { id = value; }
        }

        public void AddStock(Stock stock) 
        {
            stocks.Add(stock);
            stock.Count--;
        }
        public void RemoveStock(Stock stock) 
        {
            if (stocks.Remove(stock))
            {
                stock.Count++;
            }
        }

        public decimal Value(DateTime timeStamp) 
        {
            decimal value = 0;
            foreach (Stock stock in stocks) 
            {
                foreach (StockPrice sp in stock.Prices) 
                {
                    if (timeStamp > sp.Start) 
                    {
                        value += sp.Value;
                    }
                }
            }
            return value;
        }

        public decimal MonthPrecentChange(int year, int month) 
        { 
            DateTime start=new DateTime(year,month,1,0,0,0);
            start.AddMilliseconds(999);
            DateTime end=new DateTime(year ,month,DateTime.DaysInMonth(year,month),23,59,59);
            start.AddMilliseconds(999);
            return Convert.ToDecimal(Value(start) / Value(end));
        }

        public bool IsStockInPortfolio(Stock stock) 
        {
            if (stocks.Find(s => s.Name == stock.Name) != null)
            {
                return true;
            }
            else 
            {
                return false;
            }
        }
        public int NumberOfStocks() 
        {
            List<Stock> differentStocks = new List<Stock>();
            foreach (Stock stock in stocks) 
            {
                if (!differentStocks.Contains(stock)) 
                {
                    differentStocks.Add(stock);
                }
            }
            return differentStocks.Count;
        }

        public int NumberOfShares(Stock stock) 
        {
            int count = 0;
            foreach (Stock st in stocks) 
            {
                if (st == stock) 
                {
                    count++;
                }
            }
            return count;
        }
    }
}
