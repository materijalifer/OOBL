﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<String, Stock> stocks;
        private Dictionary<String, Index> indexes;
        private Dictionary<String, Portfolio> portfolios;

        public StockExchange() 
        {
            this.stocks = new Dictionary<String, Stock>();
            this.indexes = new Dictionary<String, Index>();
            this.portfolios = new Dictionary<String, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica postoji!");
            }
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica pojedinog izdanja mora biti veci od 0!");
            }
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Pocetna cijena dionice mora biti veca od 0!");
            }

            inStockName = inStockName.ToLower();
            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stocks.Add(inStockName, newStock);
        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Pokusavate delistati dionicu koja ne postoji na burzi!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            // Ukoliko je neka dionica koju zelimo delistati sa burze dio indexa, moramo ju maknuti iz indeksa
            foreach (var indexItem in indexes)
            {
                if (indexItem.Value.IsStockPartOfIndex(stock))
                {
                    indexItem.Value.RemoveStockFromIndex(stock);
                }
            }

            foreach (var portfolioItem in portfolios)
            {
                if (portfolioItem.Value.IsStockPartOfPortfolio(stock)) 
                {
                    portfolioItem.Value.RemoveStockFromPortfolio(stock);
                }
            }

            stocks.Remove(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            inStockName = inStockName.ToLower();
            if (stocks.ContainsKey(inStockName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Pokusaj unosa cijene za dionicu koja ne postoji!");
            }
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Cijena dionice mora biti veca od 0!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];
            stock.SetPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Nema trazene dionice!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];
            return Math.Round(stock.GetPrice(inTimeStamp), 3);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];
            return Math.Round(stock.GetInitialPrice(), 3);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];
            return Math.Round(stock.GetLastPrice(), 3);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa unesenim imenom vec postoji!");
            }
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Neispravna vrsta indexa!");
            }
            
            inIndexName = inIndexName.ToLower();
            Index newIndex = new Index(inIndexName, inIndexType);
            indexes.Add(inIndexName, newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji taj index!");
            }
            if(!StockExists(inStockName))
            {
                throw new StockExchangeException("Pokusavate unjeti dionicu u index koja ne postoji!");
            }

            inIndexName = inIndexName.ToLower();
            inStockName = inStockName.ToLower();

            Index newStockInIndex = indexes[inIndexName];
            Stock stock = stocks[inStockName];

            newStockInIndex.AddStockToIndex(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index iz kojeg zelite zelite obrisati dionicu!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Na burzi ne postoji dionica koju zelite obrisati iz indeksa!");
            }
            inIndexName = inIndexName.ToLower();
            inStockName = inStockName.ToLower();

            Index index = indexes[inIndexName];
            Stock stock = stocks[inStockName];

            index.RemoveStockFromIndex(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if(!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index ne postoji na burzi!");
            }
            if(!StockExists(inStockName))
            {
                return false;
            }

            inIndexName = inIndexName.ToLower();
            Index index = indexes[inIndexName];
            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            return index.IsStockPartOfIndex(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci index!");
            }

            inIndexName = inIndexName.ToLower();
            Index index = indexes[inIndexName];
            return Math.Round(index.GetIndexValue(inTimeStamp), 3);
        }

        public bool IndexExists(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            if (indexes.ContainsKey(inIndexName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if(!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci index!");
            }

            inIndexName = inIndexName.ToLower();
            Index index = indexes[inIndexName];

            return index.NumberOfStocksInIndex();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj nije moguce stvoriti jer vec postoji portfelj sa danim IDem!");
            }

            Portfolio portfolio = new Portfolio(inPortfolioID);
            portfolios.Add(inPortfolioID, portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Potrebno je u portfolio staviti broj dionica veci od 0!");
            }

            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            // Provjera da li kada dodamo u portfelj novu kolicinu dionica, ukupna kolicina dionica
            // u portfeljima nece prijeci ukupnu kolicinu dionica nekog izdanja.
            long noOfSharesOfStockInAllPortfolios = 0;
            foreach (var portfolioItem in portfolios)
            {
                noOfSharesOfStockInAllPortfolios += portfolioItem.Value.NumberOfSharesOfStockInPortfolio(stock);
            }

            if ((noOfSharesOfStockInAllPortfolios + numberOfShares) > stock.GetNumberOfShares())
            {
                throw new StockExchangeException("Nije moguce dodati unesenu kolicinu dionica u portfelj jer se premasuje ukupna kolicina dionica");
            }

            Portfolio portfolio = portfolios[inPortfolioID];

            portfolio.AddStockToPortfolio(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Kako bi se maknula neka dionica iz portfelja broj mora biti veci od 0!");
            }

            Portfolio portfolio = portfolios[inPortfolioID];
            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            portfolio.RemoveStockFromPortfolio(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }

            Portfolio portfolio = portfolios[inPortfolioID];
            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            portfolio.RemoveStockFromPortfolio(stock);
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }

            Portfolio portfolio = portfolios[inPortfolioID];

            return portfolio.NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (portfolios.ContainsKey(inPortfolioID))
            {
                return true;
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                return false;
            }

            Portfolio portfolio = portfolios[inPortfolioID];
            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            return portfolio.IsStockPartOfPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }

            Portfolio portfolio = portfolios[inPortfolioID];
            inStockName = inStockName.ToLower();
            Stock stock = stocks[inStockName];

            return portfolio.NumberOfSharesOfStockInPortfolio(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }

            Portfolio portfolio = portfolios[inPortfolioID];

            return Math.Round(portfolio.GetPortfolioValue(timeStamp), 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }

            // Kreiramo prvi dan u mjesecu
            DateTime first = new DateTime(Year, Month, 1, 00, 00, 00);
            
            // Kreiramo prvi dan u sljedecem mjesecu .. pripaziti na 12. mjesec
            DateTime nextMonthFirst; 
            if (Month == 12)
            {
                nextMonthFirst = new DateTime((Year + 1), 1, 1, 23, 59, 59, 999); 
            }
            else
            {
                nextMonthFirst = new DateTime(Year, (Month + 1), 1, 23, 59, 59, 999);
            }
            
            // Kako bi dobili zadnji dan prethodnog mjeseca od prvog dana sljedeceg mjeseca oduzmemo jedan dan
            DateTime last = nextMonthFirst.AddDays(-1);

            Portfolio portfolio = portfolios[inPortfolioID];

            return Math.Round(portfolio.GetPortfolioPercentChangeInValueForMonth(first, last), 3);
        }
    }

    public class Stock
    { 
        private string inStockName;
        private long inNumberOfShares;
        private decimal inInitialPrice;
        private DateTime inTimeStamp;
        private SortedDictionary<DateTime, decimal> historyPrice;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.inStockName = inStockName;
            this.inNumberOfShares = inNumberOfShares;
            this.inInitialPrice = inInitialPrice;
            this.inTimeStamp = inTimeStamp;
            this.historyPrice = new SortedDictionary<DateTime, decimal>();
            this.historyPrice.Add(inTimeStamp, inInitialPrice);
        }

        public void SetPrice(DateTime inIimeStamp, decimal inStockValue)
        {
            if (historyPrice.ContainsKey(inIimeStamp))
            {
                throw new StockExchangeException("Uneseno vrijeme vec sadrzi vrijednost dionice!");
            }
            if (this.inTimeStamp > inIimeStamp)
            {
                throw new StockExchangeException("Tada dionica još nije postojala!");
            }

            historyPrice.Add(inIimeStamp, inStockValue);
        }

        public decimal GetInitialPrice()
        {
            return inInitialPrice;
        }

        public decimal GetPrice(DateTime inTimeStamp)
        { 
            if(inTimeStamp < this.inTimeStamp)
            {
                throw new StockExchangeException("Za trazeni datum dionica jos nije postojala na burzi!");
            }

            // Ako je zadnja unesena cijena za datum 1.7, a mi trazimo za 15.7. moramo dobiti cijenu na dan 1.7.
            DateTime nearestTime = this.inTimeStamp;
            foreach (var time in historyPrice)
            {
                if (time.Key <= inTimeStamp)
                {
                    nearestTime = time.Key;
                }
                else 
                {
                    break;
                }
            }
            return historyPrice[nearestTime];
        }

        public decimal GetPriceAtConcretTime(DateTime inTimeStamp)
        {
            if (!historyPrice.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Nema podatka za trazeno vrijeme!");
            }
            return historyPrice[inTimeStamp];
        }

        public decimal GetLastPrice() 
        {
            return historyPrice.Last().Value;
        }

        public long GetNumberOfShares()
        {
            return inNumberOfShares;
        }

    }

    public class Index
    { 
        private string inIndexName;
        private IndexTypes inIndexType;
        private List<Stock> listOfStocks;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.inIndexName = inIndexName;
            this.inIndexType = inIndexType;
            this.listOfStocks = new List<Stock>();
        }

        public void AddStockToIndex(Stock stock)
        {
            if(listOfStocks.Contains(stock))
            {
                throw new StockExchangeException("Dionica koju pokusavate priduziti indexu vec postoji u indexu!");
            }
            listOfStocks.Add(stock);
        }

        public Boolean IsStockPartOfIndex(Stock stock)
        { 
            if(listOfStocks.Contains(stock))
            { 
                return true;
            }
            return false;
        }

        public int NumberOfStocksInIndex()
        {
            return listOfStocks.Count;
        }

        public decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (listOfStocks.Count == 0)
            {
                return 0m;
            }
            else if (inIndexType == IndexTypes.AVERAGE) // AVERAGE
            {
                decimal indexValue = 0;
                int noOfStocks = 0;

                foreach (var stock in listOfStocks)
                {
                    indexValue += stock.GetPrice(inTimeStamp);
                    noOfStocks++;
                }

                indexValue = indexValue / noOfStocks;
                return indexValue;
            }
            else if (inIndexType == IndexTypes.WEIGHTED)  // WEIGHTED
            {
                decimal totalValueOfIndex = 0m;

                // Ukupna kapitalizacija nekog indeksa
                foreach (var stock in listOfStocks)
                {
                    totalValueOfIndex += stock.GetPrice(inTimeStamp) * stock.GetNumberOfShares();
                }

                // Tezinski faktor svake dionice i racunanje tezinske vrijednosti indeksa 
                decimal indexValue = 0;
                foreach (var stock in listOfStocks)
                {
                    decimal weightingFactor = stock.GetPrice(inTimeStamp) * stock.GetNumberOfShares();
                    weightingFactor = weightingFactor / totalValueOfIndex;
                    indexValue += stock.GetPrice(inTimeStamp) * weightingFactor;
                }

                return indexValue;
            }
            else
            {
                throw new StockExchangeException("Greska!");
            }
        }

        public void RemoveStockFromIndex(Stock stock)
        {
            if (!listOfStocks.Contains(stock))
            {
                throw new StockExchangeException("Dionica koju pokusavate izbrisati iz indeksa ne postoji u njemu!");
            }
            listOfStocks.Remove(stock);
        }
    }

    public class Portfolio
    {
        private string inPortfolioID;
        private Dictionary<Stock, long> stocksInPortfolio;

        public Portfolio(string inPortfolioID)
        {
            this.inPortfolioID = inPortfolioID;
            this.stocksInPortfolio = new Dictionary<Stock, long>();
        }

        public void AddStockToPortfolio(Stock stock, long numberOfShares)
        {
            if (stocksInPortfolio.ContainsKey(stock))
            {
                stocksInPortfolio[stock] += numberOfShares;
            }
            else
            {
                stocksInPortfolio.Add(stock, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(Stock stock, long numberOfShares)
        {
            if (!stocksInPortfolio.ContainsKey(stock))
            {
                throw new StockExchangeException("Pokusaj brisanja nepostojece dionice iz portfelja!");
            }
            if (stocksInPortfolio[stock] < numberOfShares)
            {
                throw new StockExchangeException("Pokusaj brisanja veceg broja dionica iz porteflja nego ih neko izdanje ima u portfelju!");
            }

            if (stocksInPortfolio[stock] == numberOfShares)
            {
                RemoveStockFromPortfolio(stock);
            }
            else 
            {
                stocksInPortfolio[stock] -= numberOfShares;
            }
        }

        public void RemoveStockFromPortfolio(Stock stock)
        {
            if (!stocksInPortfolio.ContainsKey(stock))
            {
                throw new StockExchangeException("Pokusaj brisanja dionice koje ni nema u portfelju!");
            }

            stocksInPortfolio.Remove(stock);
        }

        public int NumberOfStocksInPortfolio()
        {
            return stocksInPortfolio.Count;
        }

        public bool IsStockPartOfPortfolio(Stock stock)
        {
            if (stocksInPortfolio.ContainsKey(stock))
            {
                return true;
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(Stock stock)
        {
            if (!stocksInPortfolio.ContainsKey(stock))
            {
                return 0;
            }

            return (int)stocksInPortfolio[stock];
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal portfolioValue = 0;

            foreach (var stock in stocksInPortfolio)
            {
                portfolioValue += stock.Key.GetPrice(timeStamp) * stock.Value;
            }

            return portfolioValue;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(DateTime first, DateTime last)
        {
            decimal valueAtBeginning = 0;
            decimal valueAtEnd = 0;
            
            foreach (var stock in stocksInPortfolio)
            {

                valueAtBeginning += stock.Key.GetPrice(first);
                valueAtEnd += stock.Key.GetPrice(last);
            }

            // Iako se nikad ne bi smijelo dogoditi, osiguravam stabilnost sustava
            if (valueAtBeginning == 0)
            {
                throw new StockExchangeException("Dijeljenje sa 0!!!");
            }
            decimal change = (valueAtEnd - valueAtBeginning) / valueAtBeginning * 100;
            return change;
        }
    }
}
