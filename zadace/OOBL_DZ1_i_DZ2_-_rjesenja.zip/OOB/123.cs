﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Index
    {
        private Dictionary<string, Stock> _StocksInIndex;
        public IndexTypes IndexType { get; private set; }

        public Index(IndexTypes indexType)
        {
            if (indexType == IndexTypes.AVERAGE || indexType == IndexTypes.WEIGHTED)
            {
                IndexType = indexType;
                _StocksInIndex = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
            }
            else
            {
                throw new StockExchangeException("Index not allowed");
            }
        }

        /// <summary>
        /// Adds a stock to index with key inStockName.
        /// </summary>
        /// <param name="inStockName">key of stock.</param>
        /// <param name="stock">element to be added to dictionary.</param>
        internal void AddStock(string inStockName, Stock stock)
        {
            _StocksInIndex.Add(inStockName, stock);
        }

        /// <summary>
        /// Removes a stock from index.
        /// </summary>
        /// <param name="inStockName">key of stock to be removed.</param>
        /// <param name="stock">stock to be removed.</param>
        internal void RemoveStock(string inStockName)
        {
            _StocksInIndex.Remove(inStockName);
        }

        /// <summary>
        /// Checks if index contains stock with inStockName as ID.
        /// </summary>
        /// <param name="inStockName">key of stock to check.</param>
        /// <returns>true if found, false otherwise.</returns>
        internal bool DoesContain(string inStockName)
        {
            return _StocksInIndex.ContainsKey(inStockName);
        }

        /// <summary>
        /// Returns number of stocks in index.
        /// </summary>
        /// <returns>number of stock.</returns>
        internal int GetNumberOfStocks()
        {
            return _StocksInIndex.Count;
        }

        internal decimal CalculateValue(DateTime inTimeStamp)
        {
            if (this.IndexType == IndexTypes.AVERAGE)
            {
                return CalculateAverage(inTimeStamp);
            }
            else
            {
                return CalculateWeighted(inTimeStamp);
            }
        }
        
        private decimal CalculateAverage(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (var item in _StocksInIndex)
            {
                sum += item.Value.GetPrice(inTimeStamp);
            }

            sum /= _StocksInIndex.Count;

            //rounded to a maximum of 3 decimal places
            return Decimal.Round(sum, 3);
        }

        private decimal CalculateWeighted(DateTime inTimeStamp)
        {
            List<decimal> weight = new List<decimal>();
            foreach (var item in _StocksInIndex)
            {
                decimal totalPrice = item.Value.GetPrice(inTimeStamp) * item.Value.InitNumberOfShares;
                weight.Add(totalPrice);
            }

            decimal sumPrice = weight.Sum();
            for (int i = 0; i < weight.Count; i++)
            {
                weight[i] /= sumPrice;
            }            
            decimal sum = 0;
            int j = 0;
            foreach (var item in _StocksInIndex)
	        {
		        sum += item.Value.GetPrice(inTimeStamp) * weight[j];
                j++;
	        }

            //rounded to a maximum of 3 decimal places            
            return Decimal.Round(sum, 3);            
        }
    }

    public class Stock
    {
        public long InitNumberOfShares { get; private set; }

        private long numberOfShares;
        public long NumberOfShares
        {
            get
            {
                return numberOfShares;
            }
            set
            {
                if (value >= 0)
                {
                    numberOfShares = value;
                }
                else
                {
                    throw new StockExchangeException("Invalid number of shares.");
                }
            }
        }
        public decimal InitialPrice { get; private set; }
        public DateTime InitTimeStamp { get; private set; }
        public decimal StockPrice { get; private set; }

        private Dictionary<DateTime, decimal> _TimeStamps = new Dictionary<DateTime, decimal>();

        public Stock(long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            if (initialPrice <= 0)
                throw new StockExchangeException("Price of stock cannot be 0 or less");
            InitNumberOfShares = numberOfShares;
            NumberOfShares = numberOfShares;
            InitialPrice = initialPrice;            
            InitTimeStamp = timeStamp;
            _TimeStamps.Add(timeStamp, initialPrice);
        }
       
        internal void SetPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
                throw new StockExchangeException("Price of stock cannot be 0 or less");
            _TimeStamps.Add(inTimeStamp, inStockValue);
        }

        /// <summary>
        /// Gets price of stock.
        /// </summary>
        /// <returns>latest price of stock.</returns>
        internal decimal GetPrice()
        {
            return _TimeStamps.Max(x => x.Value);
        }

        /// <summary>
        /// Gets stock price that was valid at requested time.
        /// </summary>
        /// <param name="timeStamp">time that the price was valid.</param>
        /// <returns>price.</returns>
        internal decimal GetPrice(DateTime timeStamp)
        {
            var result = _TimeStamps.Aggregate((l, r) => l.Key < timeStamp && r.Key > timeStamp ? l : r);

            if (result.Key > timeStamp)
            {
                throw new StockExchangeException("No such price found.");
            }

            return result.Value;
        }

        internal bool ContainsTimeStamp(DateTime dateTime)
        {
            var times = _TimeStamps.Keys;
            foreach (var date in times)
            {
                if(date.Date == dateTime.Date && date.Month == dateTime.Month)
		            return true;
            }            
            return false;
        }
    }

    public class StockExchange : IStockExchange
    {
        Dictionary<string, Stock> _Stocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
        Dictionary<string, Index> _Indexes = new Dictionary<string, Index>(StringComparer.InvariantCultureIgnoreCase);
        Dictionary<string, Dictionary<string, long>> _Portfolio = new Dictionary<string, Dictionary<string, long>>();

        #region Stock Methods
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (_Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Stock already exists.");
            else
                _Stocks.Add(inStockName, new Stock(inNumberOfShares, inInitialPrice, inTimeStamp));            
        }

        public void DelistStock(string inStockName)
        {
            _Stocks.Remove(inStockName);            
        }

        public bool StockExists(string inStockName)
        {
            return _Stocks.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return _Stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            _Stocks[inStockName].SetPrice(inTimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _Stocks[inStockName].GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return _Stocks[inStockName].InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return _Stocks[inStockName].GetPrice();
        }
        #endregion 

        #region Index Methods
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _Indexes.Add(inIndexName, new Index(inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("No such stock exists");
            }
            if(_Indexes[inIndexName].DoesContain(inStockName))
            {
                throw new StockExchangeException("Stock already assigned to index.");
            }
            _Indexes[inIndexName].AddStock(inStockName, _Stocks[inStockName]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            _Indexes[inIndexName].RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _Indexes[inIndexName].DoesContain(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return _Indexes[inIndexName].CalculateValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return _Indexes.ContainsKey(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _Indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _Indexes[inIndexName].GetNumberOfStocks();
        }
        #endregion

        #region Portfolio Methods
        public void CreatePortfolio(string inPortfolioID)
        {
            _Portfolio.Add(inPortfolioID, new Dictionary<string, long>(StringComparer.InvariantCultureIgnoreCase));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares >= 0)
            {
                if (!_Portfolio[inPortfolioID].ContainsKey(inStockName))
                {
                    _Portfolio[inPortfolioID].Add(inStockName, numberOfShares);
                    _Stocks[inStockName].NumberOfShares -= numberOfShares;
                }
                else
                {
                    _Portfolio[inPortfolioID][inStockName] += numberOfShares;
                    _Stocks[inStockName].NumberOfShares -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Invalid transfer of shares.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares >= 0)
            {
                _Portfolio[inPortfolioID][inStockName] -= numberOfShares;
                _Stocks[inStockName].NumberOfShares += numberOfShares;
                if (_Portfolio[inPortfolioID][inStockName] == 0)
                {
                    _Portfolio[inPortfolioID].Remove(inStockName);
                }
            }
            else
            {
                throw new StockExchangeException("Invalid transfer of shares.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (_Portfolio[inPortfolioID].ContainsKey(inStockName))
            {
                _Stocks[inStockName].NumberOfShares += _Portfolio[inPortfolioID][inStockName];
                _Portfolio[inPortfolioID].Remove(inStockName);
            }
            else
            {
                throw new StockExchangeException("Portfolio does not contain stocks.");
            }
        }

        public int NumberOfPortfolios()
        {
            return _Portfolio.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _Portfolio[inPortfolioID].Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _Portfolio.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return _Portfolio[inPortfolioID].ContainsKey(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return Convert.ToInt32(_Portfolio[inPortfolioID][inStockName]);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (var item in _Portfolio[inPortfolioID])
            {
                try
                {
                    sum += _Stocks[item.Key].GetPrice(timeStamp) * item.Value;
                }
                catch (StockExchangeException e)
                {
                    
                    throw e;
                }                

            }
            //round to 3 decimal places
            return Decimal.Round(sum, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            foreach (var item in _Portfolio[inPortfolioID])
            {
                if (!_Stocks[item.Key].ContainsTimeStamp(new DateTime(Year, Month, 1, 0, 0, 0, 0)) || !_Stocks[item.Key].ContainsTimeStamp(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)))
                {
                    throw new StockExchangeException("Stocks do not contain data for queried dates.");
                }
            }
            decimal priceAtStartOfMonth = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
            decimal priceAtEndOfMonth = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            //round to 3 decimal places
            return Decimal.Round((priceAtEndOfMonth / priceAtStartOfMonth - 1) * 100, 3);
        }
        #endregion
    }
}
