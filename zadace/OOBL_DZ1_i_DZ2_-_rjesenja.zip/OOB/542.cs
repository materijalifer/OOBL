﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {

        private RepozitorijDionica repozitorijDionica = new RepozitorijDionica();
        private RepozitorijIndexa repozitorijIndexa = new RepozitorijIndexa();
        private RepozitorijPortfolia repozitorijPortfolia = new RepozitorijPortfolia();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToLower();

            if (inInitialPrice <= 0 || inNumberOfShares <= 0) throw new StockExchangeException("Cijena i broj dionica ne smije biti <=0");

            repozitorijDionica.Add(new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            inStockName = inStockName.ToLower();

            repozitorijDionica.Remove(inStockName);
            repozitorijIndexa.RemoveStocksFromAllIndices(inStockName);
            repozitorijPortfolia.RemoveStocksFromAllPorfolios(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            inStockName = inStockName.ToLower();

            return repozitorijDionica.Contains(inStockName);
        }

        public int NumberOfStocks()
        {
            return repozitorijDionica.NumberOfStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, Decimal inStockValue)
        {
            inStockName = inStockName.ToLower();

            if (inStockValue <= 0) throw new StockExchangeException("Cijena ne smije biti <=0");

            Dionica d = repozitorijDionica.Get(inStockName);
            d.ChangePrice(inStockValue, inTimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            return d.Price(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            return d.InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            return d.LastPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            inIndexName = inIndexName.ToLower();
            inIndexName = inIndexName.ToLower();

            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED) throw new StockExchangeException("Nedozvoljen tip indexa");

            if (inIndexType == IndexTypes.AVERAGE)
            {
                repozitorijIndexa.Add(new AverageIndex(inIndexName));
            }
            else
            {
                repozitorijIndexa.Add(new WeightedIndex(inIndexName));
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            inIndexName = inIndexName.ToLower();
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            Index i = repozitorijIndexa.Get(inIndexName);
            i.AddStock(d);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            inIndexName = inIndexName.ToLower();
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            Index i = repozitorijIndexa.Get(inIndexName);
            i.Remove(d.StockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            inIndexName = inIndexName.ToLower();
            inStockName = inStockName.ToLower();

            Dionica d = repozitorijDionica.Get(inStockName);
            Index i = repozitorijIndexa.Get(inIndexName);
            return i.Contains(d.StockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            inIndexName = inIndexName.ToLower();

            Index i = repozitorijIndexa.Get(inIndexName);
            return i.GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            return repozitorijIndexa.Contains(inIndexName);
        }

        public int NumberOfIndices()
        {
            return repozitorijIndexa.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            Index i = repozitorijIndexa.Get(inIndexName);
            return i.NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            repozitorijPortfolia.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inStockName = inStockName.ToLower();

            if (numberOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veci od 0");
            
            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            Dionica d = repozitorijDionica.Get(inStockName);
            long existingStocks=repozitorijPortfolia.NumberOfStocks(inStockName) ;
            if (existingStocks + numberOfShares > d.NumberOfShares)
            {
                p.AddStock(d, d.NumberOfShares - existingStocks);
            }
            else 
            {
                p.AddStock(d, numberOfShares);
            }
            
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inStockName = inStockName.ToLower();

            if (numberOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veci od 0");
            
            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            if (p.Contains(inStockName) == false) throw new StockExchangeException("Dionica ne postoji u portfoliu");
            p.RemoveStock( inStockName,  numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            if (p.Contains(inStockName) == false) throw new StockExchangeException("Dionica ne postoji u portfoliu");
            p.RemoveStock(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return repozitorijPortfolia.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            return p.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return repozitorijPortfolia.Contains(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            return p.Contains(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            return (int) p.NumberOfStocks(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);
            return p.Value(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (Month < 1 || Month > 12) throw new StockExchangeException("Navedeni mjesec ne postoji");

            Portfolio p = repozitorijPortfolia.Get(inPortfolioID);

            DateTime firstDayOfTheMonth = new DateTime(Year, Month, 1);
            DateTime lastDayOfTheMonth=firstDayOfTheMonth.AddMonths(1).AddMilliseconds(-1);

            Decimal firstDayValue = p.Value(firstDayOfTheMonth);
            Decimal lastDayValue = p.Value(lastDayOfTheMonth);

            return Math.Round((lastDayValue - firstDayValue) / firstDayValue * 100, 3);
        }
    }

    abstract class Index
    {

        protected string name;
        protected RepozitorijDionica repozitorijDionica = new RepozitorijDionica();
        protected List<string> repozitorijNames = new List<string>();

        protected Index(string inName)
        {
            name = inName;
        }

        public string Name
        {
            get { return name; }
        }

        public void AddStock(Dionica d)
        {
            repozitorijDionica.Add(d);
            repozitorijNames.Add(d.StockName);
        }

        public void Remove(string inStockName)
        {
            repozitorijDionica.Remove(inStockName);
            repozitorijNames.Remove(inStockName);
        }

        public bool Contains(string inStockName)
        {
            return repozitorijDionica.Contains(inStockName);
        }

        public int NumberOfStocks()
        {
            return repozitorijDionica.NumberOfStocks();
        }

        public abstract Decimal GetIndexValue(DateTime inTimeStamp);


        public override bool Equals(object obj)
        {
            if (!(obj is Index)) return false;
            Index castedObj = (Index)obj;
            if (this.name.Equals(castedObj.name)) return true;
            return false;
        }

        public override int GetHashCode()
        {
            return name.GetHashCode();
        }

    }

    class AverageIndex : Index
    {

        public AverageIndex(string inName) : base(inName) { }

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            Decimal sum = 0;
            if (repozitorijDionica.NumberOfStocks() == 0) return sum;
            foreach (string name in repozitorijNames)
            {
                sum += repozitorijDionica.Get(name).Price(inTimeStamp);
            }
            return Math.Round(sum / repozitorijDionica.NumberOfStocks(), 3);
        }

    }

    class WeightedIndex : Index
    {

        public WeightedIndex(string inName) : base(inName) { }

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            Decimal sumaSvihDionica = 0;
            if (repozitorijDionica.NumberOfStocks() == 0) return sumaSvihDionica;

            foreach (string name in repozitorijNames)
            {
                sumaSvihDionica += repozitorijDionica.Get(name).Price(inTimeStamp) * repozitorijDionica.Get(name).NumberOfShares;
            }

            Decimal weightedSuma = 0;

            foreach (string name in repozitorijNames)
            {
                weightedSuma += ((repozitorijDionica.Get(name).Price(inTimeStamp) * repozitorijDionica.Get(name).NumberOfShares) / sumaSvihDionica) * repozitorijDionica.Get(name).Price(inTimeStamp);
            }
            return Math.Round(weightedSuma, 3);

        }

    }

    class Dionica
    {

        private string stockName;
        private long numberOfShares;
        private SortedList<DateTime, Decimal> timePrice = new SortedList<DateTime, Decimal>();


        public Dionica(string inStockName, long inNumberOfShares, Decimal inInitialPrice,
    DateTime inTimeStamp)
        {
            stockName = inStockName.ToLower();
            numberOfShares = inNumberOfShares;
            timePrice.Add(inTimeStamp, inInitialPrice);
        }

        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        public string StockName
        {
            get { return stockName; }
        }

        public Decimal LastPrice
        {
            get { return timePrice.Last().Value; }
        }

        public Decimal InitialPrice
        {
            get { return timePrice.First().Value; }
        }

        public Decimal Price(DateTime timeStamp)
        {
            return timePrice[FloorTimeStamp(timeStamp)];
        }

        private DateTime FloorTimeStamp(DateTime timeStamp)
        {
            DateTime floor = default(DateTime);
            foreach (KeyValuePair<DateTime, Decimal> e in timePrice)
            {
                if (e.Key > timeStamp) break;
                floor = e.Key;
            }
            if (floor == default(DateTime)) throw new StockExchangeException("Ne postoji floor timeStamp za zadani timeStamp");
            return floor;
        }

        public void ChangePrice(Decimal newPrice, DateTime newTimeStamp)
        {
            if (timePrice.ContainsKey(newTimeStamp)) throw new StockExchangeException("Cijena se moze definirati samo jednom u svakom trenutku");
            timePrice.Add(newTimeStamp, newPrice);

        }

        public override bool Equals(object obj)
        {
            if (!(obj is Dionica)) return false;
            Dionica castedObj = (Dionica)obj;
            if (this.stockName.Equals(castedObj.stockName)) return true;
            return false;

        }

        public override int GetHashCode()
        {
            return stockName.GetHashCode();
        }


    }

    class Portfolio
    {
        private RepozitorijDionica repozitorijDionica = new RepozitorijDionica();
        private Dictionary<string, long> listedStocks = new Dictionary<string, long>();

        private string _ID;

        public Portfolio(string inID)
        {
            _ID = inID;
        }

        public string ID
        {
            get { return _ID; }
        }

        public long NumberOfStocks(string inStockName)
        {
            if (listedStocks.ContainsKey(inStockName) == false) return 0;
            return listedStocks[inStockName];
        }

        public int NumberOfStocks()
        {
            int sum = 0;
            foreach (int n in listedStocks.Values)
            {
                sum += 1;
            }
            return sum;
        }

        public void AddStock(Dionica d, long numberOfShares)
        {
            if (listedStocks.ContainsKey(d.StockName))
            {
                listedStocks[d.StockName] += numberOfShares;
            }
            else
            {
                listedStocks.Add(d.StockName, numberOfShares);
                repozitorijDionica.Add(d);
            }
        }

        public void RemoveStock(string inStockName, int numberOfShares)
        {
            if (listedStocks[inStockName] - numberOfShares <= 0)
            {
                listedStocks.Remove(inStockName);
                repozitorijDionica.Remove(inStockName);
            }
            else
            {
                listedStocks[inStockName] -= numberOfShares;
            }
        }

        public void RemoveStock(string inStockName)
        {
            listedStocks.Remove(inStockName);
            repozitorijDionica.Remove(inStockName);
        }

        public bool Contains(string inStockName)
        {
            return listedStocks.ContainsKey(inStockName);
        }

        public Decimal Value(DateTime timeStamp)
        {
            Decimal sum = 0;
            foreach (string id in listedStocks.Keys)
            {
                sum += listedStocks[id] * repozitorijDionica.Get(id).Price(timeStamp);
            }
            return sum;
        }

    }

    class RepozitorijDionica
    {

        private Dictionary<string, Dionica> listedStocks = new Dictionary<string, Dionica>();

        public void Add(Dionica d)
        {
            if (listedStocks.ContainsKey(d.StockName)) throw new StockExchangeException("Dionica vec postoji");
            listedStocks.Add(d.StockName, d);
        }

        public void Remove(string name)
        {
            if (listedStocks.Remove(name) == false) throw new StockExchangeException("Dionica ne postoji na burzi");
        }

        public bool Contains(string name)
        {
            return listedStocks.ContainsKey(name);
        }

        public int NumberOfStocks()
        {
            return listedStocks.Count;
        }

        public Dionica Get(string name)
        {
            if (listedStocks.ContainsKey(name) == false) throw new StockExchangeException("Dionica ne postoji na burzi");
            return listedStocks[name];
        }

    }

    class RepozitorijIndexa
    {
        private Dictionary<string, Index> listedIndices = new Dictionary<string, Index>();

        public void Add(Index i)
        {
            if (listedIndices.ContainsKey(i.Name)) throw new StockExchangeException("Index vec postoji");
            listedIndices.Add(i.Name, i);
        }

        public void Remove(string name)
        {
            if (listedIndices.Remove(name) == false) throw new StockExchangeException("Index ne postoji na burzi");
        }

        public void RemoveStocksFromAllIndices(string inStockName)
        {
            foreach (Index i in listedIndices.Values)
            {
                if (i.Contains(inStockName)) i.Remove(inStockName);
            }
        }

        public bool Contains(string name)
        {
            return listedIndices.ContainsKey(name);
        }

        public int NumberOfIndices()
        {
            return listedIndices.Count;
        }

        public Index Get(string name)
        {
            if (listedIndices.ContainsKey(name) == false) throw new StockExchangeException("Index ne postoji na burzi");
            return listedIndices[name];
        }


    }

    class RepozitorijPortfolia
    {

        private Dictionary<string, Portfolio> listedPortfolios = new Dictionary<string, Portfolio>();

        public void Add(Portfolio i)
        {
            if (listedPortfolios.ContainsKey(i.ID)) throw new StockExchangeException("Portfolio vec postoji");
            listedPortfolios.Add(i.ID, i);
        }

        public void Remove(string id)
        {
            if (listedPortfolios.Remove(id) == false) throw new StockExchangeException("Portfolio ne postoji na burzi");
        }
        //
        public void RemoveStocksFromAllPorfolios(string inStockName)
        {
            foreach (Portfolio p in listedPortfolios.Values)
            {
                if (p.Contains(inStockName)) p.RemoveStock(inStockName);
            }
        }

        public bool Contains(string id)
        {
            return listedPortfolios.ContainsKey(id);
        }

        public int NumberOfPortfolios()
        {
            return listedPortfolios.Count;
        }
        //
        public long NumberOfStocks(string inStockName)
        {
            long sumOfStocks = 0;
            foreach (Portfolio p in listedPortfolios.Values)
            {
                sumOfStocks += p.NumberOfStocks(inStockName);
            }
            return sumOfStocks;
        }

        public Portfolio Get(string id)
        {
            if (listedPortfolios.ContainsKey(id) == false) throw new StockExchangeException("Portfolio ne postoji na burzi");
            return listedPortfolios[id];
        }

    }
    
}
