﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator(); // vratiti kalkulator
        }
    }

    public class Kalkulator : ICalculator
    {
        public Kalkulator() //konstruktor
        {
            this.DisplayState = "0";
            this.FirstNumber = 0;
            this.Operator = BinaryOp.doNothing;
            this.Clear = false;
            this.NewNumberFlag = false;
            this.ErrorOcc = false;
            this.Save = 0;

        }

        private string DisplayState //geteri i seteri za clanske varijable
        {
            get;
            set;
        }
        private double FirstNumber
        {
            get;
            set;
        }
        private bool Clear
        {
            get;
            set;
        }
        private bool NewNumberFlag
        {
            get;
            set;
        }
        public bool ErrorOcc
        {
            get;
            set;
        }
        public BinaryOp Operator
        {
            get;
            set;
        }

        private double Save
        {
            get;
            set;
        }




       





        public void Press(char inPressedDigit) //funkcija za unos brojeva i operacija
        {
            Double Number;
            string pressedDigit = inPressedDigit.ToString();
            int MaxDisplaySize = 10; // max velicina ekrana kalkulatora


            if (Double.TryParse(pressedDigit, out Number))
            {
                if (this.DisplayState == "0" || this.Clear) 
                {
                    this.Clear = false;
                    DisplayState = pressedDigit;   //omogucuje unos poput ',' da bude "0,"
                    this.NewNumberFlag = true;
                }
                else
                {
                   
                    int addSpace = 0;
                    if (DisplayState.Contains(','))  //povecati velicinu ekrana ako sadrzi '-' ili ','
                    {
                        addSpace++;
                    }

                    if (DisplayState.Contains('-'))
                    {
                        addSpace++;
                    }

                    if (DisplayState.Length - addSpace < MaxDisplaySize)
                    {
                        DisplayState += pressedDigit;     //promjeni stanje ekrana
                    }

                }
            }

            else
            {
                switch (inPressedDigit)
                {
                    case ',':
                        if (!DisplayState.Contains(',') && !Clear) //ako na ekranu ne postoji nijedan dec.zarez, slobodno dodaj
                        {
                            DisplayState += ",";
                        }
                        else //ignoriraj ako postoji >1 dec.zareza
                        { };
                        break;


                    case 'M': //promjena predznaka
                        if (!ErrorOcc)
                        {
                            Double DNumber = Convert.ToDouble(DisplayState);
                            if (DNumber < 0)
                                DisplayState = DisplayState.Replace("-", "");
                            else
                                DisplayState = "-" + DisplayState;
                        }
                        break;


                    case 'C':  //sadrzaj ekrana postavlja u '0'
                        DisplayState = "0";
                        ErrorOcc = false;
                        break;


                    case '=': 
                        if (Operator != BinaryOp.doNothing)
                        {
                            double r = doBinaryOp(); 
                            adjustDisplayState(r);  //prilagodi rezultat ekranu od 10 znamenaka
                        }
                        else
                        {
                            try
                            {

                                double r = 0;
                                Double.TryParse(this.DisplayState, out r);
                                this.DisplayState = r.ToString();
                            }
                            catch (Exception)
                            {
                                this.DisplayState = "-E-";  // ispisi "greska"
                            }

                        }
                        break;


                    case '*':
                        doBinaryOp(BinaryOp.multiply);
                        checkOutDisplayState();
                        break;


                    case '/':
                        doBinaryOp(BinaryOp.divide);
                        checkOutDisplayState();
                        break;


                    case '+':
                        //Console.WriteLine("TU SAM"); Console.ReadKey();
                        doBinaryOp(BinaryOp.add);
                        checkOutDisplayState();
                        break;


                    case '-':
                        doBinaryOp(BinaryOp.sub);
                        checkOutDisplayState();
                        break;


                    case 'S':
                        doUnaryOp(UnaryOp.sinus);
                        break;


                    case 'K':
                        doUnaryOp(UnaryOp.cosinus);
                        break;


                    case 'T':
                        doUnaryOp(UnaryOp.tangens);
                        break;
                    

                    case 'Q':
                        doUnaryOp(UnaryOp.square);
                        break;


                    case 'R':
                        doUnaryOp(UnaryOp.root);
                        break;


                    case 'I':
                        doUnaryOp(UnaryOp.inverse);
                        break;


                    case 'O':
                        OnOff();
                        break;
                        
                    case 'P':
                        try
                        { Save = Convert.ToDouble(DisplayState); }
                        catch
                        { Save = 0; }
                        break;

                    case 'G':
                        adjustDisplayState(Save);
                        break;

                }

            }


            
        }

        public string GetCurrentDisplayState() //metoda kojom provjeravamo stanje na ekranu
        {

            return this.DisplayState;
        }

        //TO DO -finished
        private void adjustDisplayState(double r)
        {
            int MaxDisplaySize=10;
            if (Double.IsNaN(r) || Double.IsInfinity(r))
            {
                ErrorOcc = true;
                DisplayState = "-E-";
            }
            else{
                long Number = Math.Abs((long)r);
                int countString,countNumber;
                countNumber=Number.ToString().Length;
                countString=r.ToString().Length;
                

                if (countString > MaxDisplaySize)
                {
                    if (r.ToString().Contains(',') && countNumber<MaxDisplaySize)
                    {
                        r=Math.Round(r,MaxDisplaySize-countNumber);  //prilagodi broj velicini ekrana
                        DisplayState=r.ToString();
                    }
                    else{
                        ErrorOcc = true;
                        DisplayState = "-E-"; //broj prevelik za ekran-->greska
                    }
                }

                else
                {
                    DisplayState=r.ToString();
                    ErrorOcc=false;
                }
                Clear=true;
            }

                        




        }


        private double doBinaryOp()
        {
            double secNumber = 0;

            try{secNumber = Convert.ToDouble(DisplayState);}
            catch{ return Double.NaN;}



            Double r = 0;

            switch (this.Operator)
            {
                case BinaryOp.multiply:
                    r = FirstNumber * secNumber;
                    break;

                case BinaryOp.divide:
                    r = FirstNumber / secNumber;
                    break;

                case BinaryOp.add:
                    r = FirstNumber + secNumber;
                    break;

                case BinaryOp.sub:
                    r = FirstNumber - secNumber;
                    break;

                default:
                    break;

            }
            FirstNumber = 0;  //resetiraj vrijednost prvog operatora
            Operator = BinaryOp.doNothing; //postavi da nema operacije

            return r;
        }

        private void doBinaryOp(BinaryOp op)
        {
            BinaryOp previousOp= Operator; //zapamti proslu operaciju
            
            if (previousOp != BinaryOp.doNothing && this.NewNumberFlag)
            {
                double r = Calculate(op); //racunaj dalje
                adjustDisplayState(r);
            }

            try
            {
                FirstNumber = Convert.ToDouble(DisplayState);
                Operator = op;
            }
            catch
            {
                FirstNumber = Double.NaN;
            }
            Clear=true;
            NewNumberFlag=false;
        
        
        }

        private double Calculate(BinaryOp op)
        {
            double secNumber =0;

            try { secNumber = Convert.ToDouble(DisplayState); }
            catch { return Double.NaN; }



            Double r = new double();

            switch (this.Operator)
            {
                case BinaryOp.multiply:
                    r = FirstNumber * secNumber;
                    break;

                case BinaryOp.divide:
                    r = FirstNumber / secNumber;
                    break;

                case BinaryOp.add:
                    r = FirstNumber + secNumber;
                    break;

                case BinaryOp.sub:
                    r = FirstNumber - secNumber;
                    break;

                default:
                    break;

            }
            FirstNumber = 0;
            Operator = BinaryOp.doNothing;

            return r;
        }

        private void doUnaryOp(UnaryOp op)
        {
            double r = Calculate(op);
            adjustDisplayState(r);
        }

        private double Calculate(UnaryOp op){
            double Number =0;
            try { Number = Convert.ToDouble(DisplayState); }
            catch { return Double.NaN; }

            Double r = 0;
            switch (op)
            {
                case UnaryOp.sinus:
                    r = Math.Sin(Number);
                    break;

                case UnaryOp.cosinus:
                    r = Math.Cos(Number);
                    break;

                case UnaryOp.tangens:
                    r = Math.Tan(Number);
                    break;

                case UnaryOp.root:
                    r = Math.Pow(Number, 0.5);
                    break;

                case UnaryOp.square:
                    r = Math.Pow(Number, 2);
                    break;

                case UnaryOp.inverse:
                    r = 1 / Number;
                    break;

                default:
                    r = Number;
                    break;
            }
            return r;
        }
        private void OnOff() //resetiraj - c/p konstruktor
        {
            this.DisplayState="0";
            this.FirstNumber=0;
            this.Operator = BinaryOp.doNothing;
            this.Clear=false;
            this.NewNumberFlag=false;
            this.ErrorOcc=false;
            this.Save=0;
        }

        private void checkOutDisplayState() //ako je upisan broj kojemu su decimale sve 0 ili ih nema, makni ih
        {
            double Number = 0;
            if (DisplayState.Contains(','))
            {
                int index = DisplayState.IndexOf(",");
                int l = DisplayState.Length;
                

                string s = DisplayState.Substring(index + 1, DisplayState.Length - (index+1));
                if (s.Length > 0)
                {
                     Number = Convert.ToDouble(s);
                }
                if (Number == 0 || s.Length==0 )
                {
                    DisplayState = DisplayState.Substring(0, index);
                  
                }
            }
        }



        //enumeratori za sve operacije

        public enum BinaryOp 
        {
            doNothing,
            add,
            sub,
            multiply,
            divide,
        };

        public enum UnaryOp
        {
            doNothing,
            square,
            sign,
            root,
            inverse,
            sinus,
            cosinus,
            tangens
        };




    }
}
