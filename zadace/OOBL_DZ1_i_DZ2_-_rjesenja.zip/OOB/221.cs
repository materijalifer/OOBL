﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string screen { get; set; } //ispis na ekran
        private string currResult { get; set; } // trenutni međurezultat
        private string currOperation { get; set; } //trenutna operacija - početno je '='
        private string memory { get; set; } // prostor za memoriranje broja
        private char lastPressed; // posljednje pritisnuta tipka
        private bool isNegative = false; // zastavica koja oznacava da li je trenutni broj koji unosimo negativan
        private bool binary = false; // jesmo li usli u binarnu operaciju
        private Dictionary <string,Delegate> binOperations; // rijecnik binarnih operacija <kratica, funkcija>
        private Dictionary<char, Delegate> OperationList; // rijecnik svih operacija
        private List<char> bins = new List<char>() { '+', '-', '*', '/' }; // lista binarnih operatora

        /// <summary>
        /// Konstruktor kalkulatora, inicijaliziraju se rijecnici bin operacija i svih operacija
        /// te ostale članske varijable
        /// </summary>
        public Kalkulator()
        {
            this.binOperations = new Dictionary<string, Delegate>();
            this.binOperations["+"] = new Func<double,double,double>(Add);
            this.binOperations["-"] = new Func<double, double, double>(Subtract);
            this.binOperations["*"] = new Func<double, double, double>(Multiply);
            this.binOperations["/"] = new Func<double, double, double>(Divide);

            this.OperationList = new Dictionary<char, Delegate>();
            this.OperationList['+'] = new Action<char>(SetOperation);
            this.OperationList['-'] = new Action<char>(SetOperation);
            this.OperationList['*'] = new Action<char>(SetOperation);
            this.OperationList['/'] = new Action<char>(SetOperation);
            this.OperationList[','] = new Action(Coma);
            this.OperationList['='] = new Action(Eq);
            this.OperationList['M'] = new Action(Minus);
            this.OperationList['S'] = new Action(Sin);
            this.OperationList['K'] = new Action(Cos);
            this.OperationList['T'] = new Action(Tan);
            this.OperationList['Q'] = new Action(Square);
            this.OperationList['R'] = new Action(Root);
            this.OperationList['I'] = new Action(Invert);
            this.OperationList['P'] = new Action(Put);
            this.OperationList['G'] = new Action(Get);
            this.OperationList['C'] = new Action(Clear);
            this.OperationList['O'] = new Action(Reset);
            
            this.currResult = null;
            this.currOperation = "=";
            this.screen = "0";
            this.memory = null;
            this.lastPressed = '0';
        }
        /// <summary>
        /// Prenosi vrijednost pritisnute tipke kalkulatoru i ovisno o njenoj vrijednosti poziva operacije iz rijecnika
        /// </summary>
        /// <param name="inPressedDigit">Pritisnuta tipka</param>
        public void Press(char inPressedDigit)
        {
            this.lastPressed = inPressedDigit;
            if (this.OperationList.Keys.Contains(inPressedDigit))
            {
                if (this.bins.Contains(inPressedDigit))
                    this.OperationList[inPressedDigit].DynamicInvoke(inPressedDigit);
                else
                    this.OperationList[inPressedDigit].DynamicInvoke();
            }
            else
            {
                DigitCheck();
            }
        }

        /// <summary>
        /// Metoda koja double parametar zaokruzi i pripremi za ispis na ekran.
        /// </summary>
        /// <param name="n">Double broj koji se priprema za ispis na ekran.</param>
        /// <returns></returns>
        private string MyOwnRound(double n)
        {
            n = Math.Round(n, 9);
            string s = n.ToString();
            
            int count = 0;
            if (s.Contains('-')) 
                count++;
            if (s.Contains(',') && s[s.Length - 1] != '0')
            {
                n = Math.Round(n, 10 - s.IndexOf(',')+count);
                count++;    
            }
            if (s.IndexOf(',')>9 || (s.Length > 10 && count == 0) || s.Contains('E')) 
                return "-E-";
            if (s.Length <= 10 + count) 
                return s;
            else
                return s.Substring(0, 10 + count);
        }

        /// <summary>
        /// Postavlja binarnu operaciju. Omogućava uzastopno nizanje operacija.
        /// </summary>
        /// <param name="inPressedDigit"> Znak operacije.</param>
        private void SetOperation(char op)
        {     
            if (this.currResult == null) this.currResult = this.screen;
            if (currOperation != "=" && !binary)
                this.Eq();
            this.currOperation = op.ToString();
            this.binary = true;
            
        }

        /// <summary>
        /// Provjera unosa znamenaka broja.
        /// </summary>
        private void DigitCheck()
        {
            if (this.screen == "0" || binary) 
            {
                this.screen = "";
                isNegative = false;
                binary = false;
            }
            if (char.IsDigit(this.lastPressed) || this.lastPressed == ',')
            {
                int count = 0;
                this.screen += this.lastPressed;
                if (this.screen.Contains('-')) 
                    count++;
                if (this.screen.Contains(',') && this.screen[this.screen.Length - 1] != '0') 
                    count++;
                if (this.screen.Length >  (10+count))
                    this.screen = this.screen.Substring(0, 10 + count);           
            }         
        }

        /// <summary>
        /// Resetiranje kalkulatora - postavljanje članskih varijabli na inicijalnu vrijednost.
        /// </summary>
        private void Reset()
        {
            this.Clear();
            this.memory = null;
            this.currOperation = "=";
            this.currResult = null;
        }

        /// <summary>
        /// Briše ekran - postavlja na 0.
        /// </summary>
        private void Clear()
        {
            this.screen = "0";
        }

        /// <summary>
        /// Dohvaća broj iz memorije i postavlja ga na ekran.
        /// </summary>
        private void Get()
        {   
            if (this.memory!=null)
                this.screen = this.memory;
        }

        /// <summary>
        /// Pohranjuje broj sa ekrana u memoriju
        /// </summary>
        private void Put()
        {
            this.memory = this.screen;
        }

        /// <summary>
        /// Operacija inverza broja na ekranu.
        /// </summary>
        private void Invert()
        {
            double rez = double.Parse(this.screen);
            if (Math.Abs(rez) < 0.000000001)
                this.screen = "-E-";
            else
            {
                rez = 1 / rez;
                this.screen = MyOwnRound(rez);
            }
        }

        /// <summary>
        /// Korijenovanje broja na ekranu.
        /// </summary>
        private void Root()
        {
            double rez = double.Parse(this.screen);
            try
            {
                rez = Math.Sqrt(rez);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            if (double.IsInfinity(rez) || double.IsNaN(rez))
                this.screen = "-E-";
            else
                this.screen = MyOwnRound(rez);
        }

        /// <summary>
        /// Kvadriranje broja na ekranu. Unarna operacija se uvijek obavlja nad brojem na ekranu.
        /// </summary>
        private void Square()
        {
            double rez = double.Parse(this.screen);
            try
            {
                rez = Math.Pow(rez,2);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            this.screen = MyOwnRound(rez);
        }

        /// <summary>
        /// Tangens broja na ekranu. Radi sa radijanima.
        /// </summary>
        private void Tan()
        {
            double rez = double.Parse(this.screen);
            try
            {
                rez = Math.Tan(rez);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            if (double.IsInfinity(rez) || double.IsNaN(rez)) 
                this.screen = "-E-";
            else
                this.screen = MyOwnRound(rez);
        }

        /// <summary>
        /// Kosinus broja na ekranu.
        /// </summary>
        private void Cos()
        {
            double rez = double.Parse(this.screen);
            try
            {
                rez = Math.Cos(rez);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            this.screen = MyOwnRound(rez);
        }

        /// <summary>
        /// Sinus broja na ekranu.
        /// </summary>
        private void Sin()
        {
            double rez = double.Parse(this.screen);
            try
            {
                rez = Math.Sin(rez);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            this.screen = MyOwnRound(rez);
        }

        /// <summary>
        /// Promjena predznaka trenutnog broja kojeg unosimo ili je na ekranu.
        /// </summary>
        private void Minus()
        {
            if (this.screen == "0") return;
            if (isNegative)
            {
                this.screen = this.screen.Substring(1);
                isNegative = false;
            }
            else
            {
                this.screen = "-" + this.screen;
                isNegative = true; 
            }
        }

        /// <summary>
        /// Dodavanje decimalnog zareza u zapis.
        /// </summary>
        private void Coma()
        {
            if (!this.screen.Contains(',')) this.screen += ',';
        }

        /// <summary>
        /// Zbrajanje. Oduzimanje. Mnozenje. Dijeljenje.
        /// </summary>
        /// <param name="a">operator 1</param>
        /// <param name="b">operator 2</param>
        /// <returns></returns>
        private double Add(double a, double b)
        {
            return a + b;
        }

        private double Subtract(double a, double b)
        {
            return a - b;
        }

        private static double Multiply(double a, double b)
        {
            return a * b;
        }

        private static double Divide(double a, double b)
        {
            return a / b;
        }

        /// <summary>
        /// Metoda koja izračunava međurezultat i reagira na tipku '='.
        /// </summary>
        private void Eq()
        {                
            double a, b;
            if (this.currResult == null) return; //ili je resetiran ili tek ukljucen :) 
            a = double.Parse(this.currResult);
            b = double.Parse(this.screen);
            try
            {
                var c = binOperations[this.currOperation].DynamicInvoke(a, b);
                this.currResult = MyOwnRound((double)c);
                this.screen = MyOwnRound((double)c);
            }
            catch (Exception e)
            {
                this.screen = "-E-";
                return;
            }
            //this.currOperation = "=";           
        }

        /// <summary>
        /// Ispis na ekran. Vraca broj koji ce se ispisati. Vrši manje provjere izgleda broja za ispis.
        /// </summary>
        /// <returns>Rezultat</returns>
        public string GetCurrentDisplayState()
        {
            if (this.screen[screen.Length - 1] == ',') this.screen = this.screen.Substring(0, this.screen.Length - 1);
            if (this.screen[screen.Length - 1] == '0')
            {
                double a = double.Parse(this.screen);
                this.screen = a.ToString();
            }

            return this.screen;
        }
    }
}
