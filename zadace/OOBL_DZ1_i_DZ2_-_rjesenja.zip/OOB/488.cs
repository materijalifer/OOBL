﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class StanjeEkrana
    {
        public const int MaxDigitsOnScreen = 10;
        public const char DecimalMarker = ',';


        private bool _slijediDecimalniDio = false;

        public string CijeliDio { get; private set; }
        public string DecimalniDio { get; private set; }

        public double TrenutniBroj
        {
            get { return _trenutniBroj; }
            set
            {
                _trenutniBroj = value;
                CijeliDio = Math.Abs((long) _trenutniBroj).ToString();
                string decimalniDio = Math.Abs(value).ToString(CultureInfo.InvariantCulture);
                int indexOfZarez = decimalniDio.IndexOf('.');
                
                if (indexOfZarez>-1)
                {
                    DecimalniDio = decimalniDio.Substring
                        (indexOfZarez+1)
                        .TrimEnd('0');
                    _slijediDecimalniDio = true;
                }
                else
                {
                    DecimalniDio = string.Empty;
                    _slijediDecimalniDio = false;
                }
            }
        }
        private double _trenutniBroj;

        /// <param name="makniNepotrebneNule">ako je true makne 0 s kraja stringa (decimalnog dijela)</param>
        public string GetPrikazBrojaNaEkranu(bool makniNepotrebneNule = true)
        {
            StringBuilder sb = new StringBuilder();
            // ako je broj negativan dodaj -
            if (TrenutniBroj < 0)
                sb.Append('-');

            // ako je cijeli dio veci nego sto stane na ekran ispisi samo sto stane
            if (CijeliDio.Length > MaxDigitsOnScreen)
            {
                sb.Append(CijeliDio.Substring(0, MaxDigitsOnScreen));
                return sb.ToString();
            }
            else sb.Append(CijeliDio);

            //ako ima decimalnog dijela
            if (DecimalniDio.Length > 0)
            {
                // nemoj dodat zarez ako se broj treba trimmat a nema zapravo decimalni dio
                if(!(makniNepotrebneNule && DecimalniDio.Trim('0').Length==0) )
                    sb.Append(DecimalMarker);

                if (makniNepotrebneNule)
                {
                    if (CijeliDio.Length + DecimalniDio.Length > MaxDigitsOnScreen)
                        sb.Append(DecimalniDio.Substring(0, MaxDigitsOnScreen - CijeliDio.Length).TrimEnd('0'));
                    else sb.Append(DecimalniDio.TrimEnd('0'));
                }
                else
                {
                    if (CijeliDio.Length + DecimalniDio.Length > MaxDigitsOnScreen)
                        sb.Append(DecimalniDio.Substring(0, MaxDigitsOnScreen - CijeliDio.Length));
                    else sb.Append(DecimalniDio);
                }
            }
            else if (_slijediDecimalniDio && !makniNepotrebneNule)
                sb.Append(DecimalMarker);
                
            return sb.ToString();
        }

        public StanjeEkrana()
        {
            CijeliDio = "0";
            DecimalniDio = string.Empty;
        }

        /// <summary>
        /// Dodaje novu cijelu znamenku ako broju prije nije dodavano decimalnih znamenki
        /// inace dodaje decimalnu znamenku
        /// </summary>
        /// <param name="znamenka">Znamenka koju se treba dodati</param>
        public void DodajZnamenku(char znamenka)
        {
            if(!char.IsDigit(znamenka))
                throw new Exception("Stanje Ekrana je primilo char koji nije znamenka!!");

            // dodaj cijelu znamenku
            if (string.IsNullOrEmpty(DecimalniDio) && !_slijediDecimalniDio)
            {
                CijeliDio += znamenka;
                CijeliDio = CijeliDio.TrimStart('0');
                if (string.IsNullOrEmpty(CijeliDio))
                    CijeliDio = "0";

                if(_trenutniBroj<0)
                    _trenutniBroj = -double.Parse(CijeliDio, CultureInfo.InvariantCulture);
                else _trenutniBroj = double.Parse(CijeliDio, CultureInfo.InvariantCulture);
            }
            // dodaj decimalnu znamenku
            else
            {
                _slijediDecimalniDio = true;
                DecimalniDio += znamenka;
                if (_trenutniBroj < 0)
                _trenutniBroj = -double.Parse(CijeliDio + "." + DecimalniDio, CultureInfo.InvariantCulture);
                else _trenutniBroj = double.Parse(CijeliDio + "." + DecimalniDio, CultureInfo.InvariantCulture);
            }
        }

        public void Clear()
        {
            _trenutniBroj = 0;
            _slijediDecimalniDio = false;
            DecimalniDio = string.Empty;
            CijeliDio = "0";
        }

        /// <summary>
        /// Pozove se kako bi se ekranu dalo do znanja da nadolazece znamenke nisu cijeli dio
        /// broja nego decimalne znamenke
        /// </summary>
        public void SlijediDecimalniDio()
        {
            _slijediDecimalniDio = true;
        }

        public double GetTrenutniBrojRounded()
        {
            double rezultat = 1;
            if (_trenutniBroj < 0)
                rezultat = -1;
            if (CijeliDio.Length >= MaxDigitsOnScreen)
                rezultat *= double.Parse(CijeliDio.Substring(0, MaxDigitsOnScreen));
            else if (DecimalniDio.Length + CijeliDio.Length > MaxDigitsOnScreen)
                rezultat = Math.Round(_trenutniBroj, MaxDigitsOnScreen - CijeliDio.Length);
            else rezultat = _trenutniBroj;

            return rezultat;
        }

        public void FlipPredznak()
        {
            _trenutniBroj = -_trenutniBroj;
        }
    }

    public class Kalkulator:ICalculator
    {
        public const string ErrorString = "-E-";
        private StanjeEkrana _stanjeEkrana = new StanjeEkrana();
        private bool _desioSeError;

        private double _brojUMemoriji;
        private double _prviOperand = double.NaN;
        private char _neUnarniOperator;
        private char _zadnjiPrimljenChar;
        private bool _cekamDrugogOperanda = false;

        public void Press(char inPressedDigit)
        {
            if(char.IsDigit(inPressedDigit))
                PressedDigit(inPressedDigit);
            else if (inPressedDigit == ',')
                Zarez();
            else if(inPressedDigit == '+')
                Zbroji();
            else if(inPressedDigit == '-')
                Oduzmi();
            else if(inPressedDigit == '*')
                Mnozi();
            else if(inPressedDigit == '/')
                Dijeli();
            else if(inPressedDigit == '=')
                Jednako();
            else if(inPressedDigit == 'M')
                FlipPredznak();
            else if(inPressedDigit == 'S')
                Sin();
            else if(inPressedDigit == 'K')
                Cos();
            else if(inPressedDigit == 'T')
                Tangens();
            else if(inPressedDigit == 'Q')
                Kvadriraj();
            else if(inPressedDigit == 'R')
                Korjenuj();
            else if(inPressedDigit == 'I')
                Inverz();
            else if(inPressedDigit == 'P')
                SpremiUMemoriju();
            else if(inPressedDigit == 'G')
                DohvatiIzMemorije();
            else if(inPressedDigit == 'C')
                Clear();
            else if(inPressedDigit == 'O')
                Reset();
            _zadnjiPrimljenChar = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            if (_desioSeError)
                return ErrorString;

            // ako zadnji znak nije bila unarna operacija ekran nije trimmao 0 s kraja
            // todo: pitat kada se sve desava trimmanje i popravit accordingly
            if(char.IsDigit(_zadnjiPrimljenChar) || _zadnjiPrimljenChar==StanjeEkrana.DecimalMarker)
                return _stanjeEkrana.GetPrikazBrojaNaEkranu(false);
            // vrati trimmani rezultat
            return _stanjeEkrana.GetPrikazBrojaNaEkranu();
        }

        private void Zarez()
        {
            // reci ekranu da pocimljemo dodavat decimalne znamenke
            _stanjeEkrana.SlijediDecimalniDio();
        }

        private void PressedDigit(char digit)
        {
            //ako prijasnji znak nije broj, zarez, M i P trebamo resetirati stanje ekrana
            // todo: postoji li jos neki znak na kojem se ne treba resetirat ekran, npr. na G?
            if (!char.IsDigit(_zadnjiPrimljenChar) && _zadnjiPrimljenChar != StanjeEkrana.DecimalMarker
                && _zadnjiPrimljenChar!='M' && _zadnjiPrimljenChar!='P')
                _stanjeEkrana.Clear();

            _stanjeEkrana.DodajZnamenku(digit);
            _zadnjiPrimljenChar = digit;
            _cekamDrugogOperanda = false;
        }

        private void RememberEnteredNumber()
        {
            _prviOperand = _stanjeEkrana.GetTrenutniBrojRounded();
        }

        private void Zbroji()
        {
            if (_neUnarniOperator != 0 && !double.IsNaN(_prviOperand)
                && !_cekamDrugogOperanda)
                IzvrsiOperaciju();
            RememberEnteredNumber();
            _neUnarniOperator = '+';
            _cekamDrugogOperanda = true;
        }

        private void Oduzmi()
        {
            if (_neUnarniOperator != 0 && !double.IsNaN(_prviOperand) 
                && !_cekamDrugogOperanda)
                IzvrsiOperaciju();
            RememberEnteredNumber();
            _neUnarniOperator = '-';
            _cekamDrugogOperanda = true;
        }

        private void Mnozi()
        {
            if (_neUnarniOperator != 0 && !double.IsNaN(_prviOperand)
                && !_cekamDrugogOperanda)
                IzvrsiOperaciju();
            RememberEnteredNumber();
            _neUnarniOperator = '*';
            _cekamDrugogOperanda = true;
        }

        private void Dijeli()
        {
            if (_neUnarniOperator != 0 && !double.IsNaN(_prviOperand)
                && !_cekamDrugogOperanda)
                IzvrsiOperaciju();
            RememberEnteredNumber();
            _neUnarniOperator = '/';
            _cekamDrugogOperanda = true;
        }

        private void FlipPredznak()
        {
            _stanjeEkrana.FlipPredznak();
        }

        private void RoundAndCheckForError()
        {
            if (_stanjeEkrana.CijeliDio.Length > StanjeEkrana.MaxDigitsOnScreen
                || double.IsInfinity(_stanjeEkrana.TrenutniBroj)
                || double.IsNaN(_stanjeEkrana.TrenutniBroj))
                _desioSeError = true;
            else
            {
                _desioSeError = false;
                _stanjeEkrana.TrenutniBroj = _stanjeEkrana.GetTrenutniBrojRounded();
            }
        }

        private void Kvadriraj()
        {
            _stanjeEkrana.TrenutniBroj = _stanjeEkrana.TrenutniBroj*_stanjeEkrana.TrenutniBroj;
            RoundAndCheckForError();
        }

        private void Korjenuj()
        {
            _stanjeEkrana.TrenutniBroj = Math.Sqrt(_stanjeEkrana.TrenutniBroj);
            RoundAndCheckForError();
        }

        private void Inverz()
        {
            if (Math.Abs(_stanjeEkrana.TrenutniBroj) <= double.Epsilon)
                _desioSeError = true;
            else
            {
                _stanjeEkrana.TrenutniBroj = 1/_stanjeEkrana.TrenutniBroj;
                RoundAndCheckForError();
            }
        }

        private void Sin()
        {
            _stanjeEkrana.TrenutniBroj = Math.Sin(_stanjeEkrana.TrenutniBroj);
            RoundAndCheckForError();
        }

        private void Cos()
        {
            _stanjeEkrana.TrenutniBroj = Math.Cos(_stanjeEkrana.TrenutniBroj);
            RoundAndCheckForError();
        }

        private void Tangens()
        {
            _stanjeEkrana.TrenutniBroj = Math.Tan(_stanjeEkrana.TrenutniBroj);
            RoundAndCheckForError();
        }

        private void SpremiUMemoriju()
        {
            // ne dozvoli spremanje u memoriju nevaljanih rezulatata
            if (_desioSeError)
                return;
            _brojUMemoriji = _stanjeEkrana.GetTrenutniBrojRounded();
        }

        private void DohvatiIzMemorije()
        {
            _stanjeEkrana.TrenutniBroj = _brojUMemoriji;
            _cekamDrugogOperanda = false;
        }

        private void Reset()
        {
            _brojUMemoriji = 0;
            _desioSeError = false;
            _neUnarniOperator = (char)0;
            _prviOperand = double.NaN;
            _stanjeEkrana.Clear();
            _cekamDrugogOperanda = false;
        }

        private void Clear()
        {
            _stanjeEkrana.Clear();
            _desioSeError = false;
            _cekamDrugogOperanda = false;
        }

        private void Jednako()
        {
            // ako prvi operand nije postavljen postavi ga sad
            if (double.IsNaN(_prviOperand))
                _prviOperand = _stanjeEkrana.GetTrenutniBrojRounded();

            IzvrsiOperaciju();
        }

        private void IzvrsiOperaciju()
        {
            if (_neUnarniOperator == '+')
                _stanjeEkrana.TrenutniBroj = _prviOperand + _stanjeEkrana.GetTrenutniBrojRounded();
            else if (_neUnarniOperator == '-')
                _stanjeEkrana.TrenutniBroj = _prviOperand - _stanjeEkrana.GetTrenutniBrojRounded();
            else if (_neUnarniOperator == '*')
                _stanjeEkrana.TrenutniBroj = _prviOperand * _stanjeEkrana.GetTrenutniBrojRounded();
            else if (_neUnarniOperator == '/')
                _stanjeEkrana.TrenutniBroj = _prviOperand / _stanjeEkrana.GetTrenutniBrojRounded();
            
            // resetiraj ne unarne operatore
            _neUnarniOperator = (char) 0;
            // vise nema prvog operanda nego samo sto je trenutno prikazano na ekranu
            _prviOperand = double.NaN;
            _cekamDrugogOperanda = false;
            RoundAndCheckForError();
        }
    }


}
