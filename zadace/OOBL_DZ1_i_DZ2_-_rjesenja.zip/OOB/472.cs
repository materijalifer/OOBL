﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private Unarni unar;
        private Binarni binar;
        private string displayState = "0";
        private string number = "";
        private string lastNumber = "";
        private string memory;
        private char lastOperator = 'E';

        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                if (number.Length == 1 && number[0] == '0')
                {
                    number = "" + inPressedDigit;
                }
                else if (number.Length < 11)
                {
                    number = number + inPressedDigit;                    
                }
                displayState = number;
            }
            else
            {
                if (number == "" )
                    number = lastNumber;
                if (lastOperator == '=')
                {
                    lastOperator = 'E';
                }
                if (lastOperator != 'E' && inPressedDigit != ',' && inPressedDigit != 'M' && inPressedDigit != 'S'
                    && inPressedDigit != 'K' && inPressedDigit != 'T' && inPressedDigit != 'Q'
                    && inPressedDigit != 'R' && inPressedDigit != 'I' && inPressedDigit != 'P'
                    && inPressedDigit != 'G' && inPressedDigit != 'C')
                {
                    char temp = lastOperator;
                    lastOperator = inPressedDigit;
                    inPressedDigit = temp;
                }

                switch (inPressedDigit)
                {
                    case '+':
                        number = Double.Parse(number).ToString();
                        if (lastOperator == 'E')
                        {
                            lastNumber = number;
                            displayState = number;
                            number = "";
                            lastOperator = '+';                            
                        }
                        else
                        {
                            binar = new Zbrajanje();
                            number = binar.Operacija(lastNumber, number);
                            lastNumber = "";
                            displayState = number;
                        }

                        break;
                    case '-':
                        number = Double.Parse(number).ToString();
                        if (lastOperator == 'E')
                        {
                            displayState = number;
                            lastNumber = number;
                            number = "";
                            lastOperator = '-';
                        }
                        else
                        {
                            binar = new Oduzimanje();
                            number = binar.Operacija(lastNumber, number);
                            lastNumber = "";
                            displayState = number;
                        }
                        break;
                    case '*':
                        number = Double.Parse(number).ToString();
                        if (lastOperator == 'E')
                        {
                            displayState = number;
                            lastNumber = number;
                            number = "";
                            lastOperator = '*';                            
                        }
                        else
                        {
                            binar = new Mnozenje();
                            number = binar.Operacija(lastNumber, number);
                            lastNumber = "";
                            displayState = number;
                        }
                        break;
                    case '/':
                        number = Double.Parse(number).ToString();
                        if (lastOperator == 'E')
                        {
                            displayState = number;
                            lastNumber = number;
                            number = "";
                            lastOperator = '/';

                        }
                        else
                        {
                            if (number == "0")
                            {
                                displayState = "-E-";
                                break;
                            }
                            binar = new Dijeljenje();
                            number = binar.Operacija(lastNumber, number);
                            lastNumber = "";
                            displayState = number;
                        }
                        break;
                    case '=':
                        displayState = Double.Parse(displayState).ToString();
                        break;
                    case ',':
                        if (number.Length == 0)
                        {
                            number = "0,";
                        }
                        else
                        {
                            number = number + ",";
                        }
                        break;
                    case 'M':
                        number = Double.Parse(number).ToString();
                        unar = new Minus();
                        number = unar.Operacija(number);
                        displayState = number;
                        break;
                    case 'S':
                        unar = new Sinus();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        number = "";
                        break;
                    case 'K':
                        unar = new Kosinus();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        number = "";
                        break;
                    case 'T':
                        unar = new Tangens();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        number = "";
                        break;
                    case 'Q':
                        unar = new Quadrat();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        break;
                    case 'R':
                        unar = new Root();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        number = "";
                        break;
                    case 'I':
                        if (number == "0")
                        {
                            displayState = "-E-";
                            break;
                        }
                        unar = new Invers();
                        number = unar.Operacija(number);
                        if (number.Length > 12)
                            number = number.Substring(0, 12);
                        displayState = number;
                        number = "";
                        break;
                    case 'P':
                        memory = displayState;
                        break;
                    case 'G':
                        displayState = memory;
                        break;
                    case 'C':
                        displayState = "0";
                        break;
                    case 'O':
                        lastNumber = "";
                        lastOperator = 'E';
                        number = "";
                        memory = "";
                        displayState = "0";
                        break;
                    default:
                        displayState = "-E-";
                        break;
                }
                if (displayState.Length > 12)
                {
                    displayState = "-E-";
                }
                else if (displayState.IndexOf(',') == -1 && displayState.IndexOf('-') == -1 && displayState.Length > 10)
                {
                    displayState = "-E-";
                }
                        
            }
            
        }

        public string GetCurrentDisplayState()
        {
            return this.displayState;
        }
    }

    abstract class Unarni
    {
        public abstract string Operacija(string broj);
    }

    class Minus : Unarni
    {
        public override string Operacija(string broj)
        {
            if (broj[0] == '-')
            {
                broj.Substring(0);
            }
            else
            {
                broj = "-" + broj;
            }
            return broj;
        }
    }

    class Sinus : Unarni
    {
        public override string Operacija(string broj)
        {
            double sinus = Math.Sin(Convert.ToDouble(broj));
            return sinus.ToString();
        }
    }

    class Kosinus : Unarni
    {
        public override string Operacija(string broj)
        {
            double kosinus = Math.Cos(Convert.ToDouble(broj));
            return kosinus.ToString();
        }
    }

    class Tangens : Unarni
    {
        public override string Operacija(string broj)
        {
            double tangens = Math.Tan(Convert.ToDouble(broj));
            return tangens.ToString();
        }
    }

    class Quadrat : Unarni
    {
        public override string Operacija(string broj)
        {
            double kvadrat = Convert.ToDouble(broj) * Convert.ToDouble(broj);
            return kvadrat.ToString();
        }
    }

    class Root : Unarni
    {
        public override string Operacija(string broj)
        {
            double korjen = Math.Sqrt(Convert.ToDouble(broj));
            return korjen.ToString();
        }
    }

    class Invers : Unarni
    {
        public override string Operacija(string broj)
        {
            double inverz = 1 / (Convert.ToDouble(broj));
            return inverz.ToString();
        }
    }

   
    abstract class Binarni
    {
        public abstract string Operacija(string broj1, string broj2);
    }

    class Zbrajanje : Binarni
    {
        public override string Operacija(string broj1, string broj2)
        {
            double rezultat = Convert.ToDouble(broj1) + Convert.ToDouble(broj2);
            return rezultat.ToString();
        }
    }

    class Oduzimanje : Binarni
    {
        public override string Operacija(string broj1, string broj2)
        {
            double rezultat = Convert.ToDouble(broj1) - Convert.ToDouble(broj2);
            return rezultat.ToString();
        }
    }

    class Mnozenje : Binarni
    {
        public override string Operacija(string broj1, string broj2)
        {
            double rezultat = Convert.ToDouble(broj1) * Convert.ToDouble(broj2);
            return rezultat.ToString();
        }
    }

    class Dijeljenje : Binarni
    {
        public override string Operacija(string broj1, string broj2)
        {
            double rezultat = Convert.ToDouble(broj1) / Convert.ToDouble(broj2);
            return rezultat.ToString();
        }
    }


}
