﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private Izvedba digitron;

        public void Press(char inPressedDigit)
        {
            if (digitron == null)
            {
                digitron = new Izvedba();
            }

            digitron.HandleKey(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            if (digitron == null)
            {
                digitron = new Izvedba();
            }

            return digitron.getCurrent();
        }
    }

    public class Izvedba
    {
        private string _current;
        private string _memory;
        private char _operator;
        private double _first;
        private bool _enterWait;
        private bool _short;

        public Izvedba() {
            _current = "0"; _enterWait = false; _short = false; _operator = 'N';
        }

        public string getCurrent() {
            return _current;
        }

        public void setCurrent(string c) {
            _current = c;
        }

        private bool checkBinary(char c)
        {
            if (c == '+' || c == '-' || c == '*' || c == '/')
            {
                return true;
            }
            return false;
        }

        private bool checkUnnary(char c)
        {
            if (c == 'S' || c == 'K' || c == 'T' || c == 'Q' || c == 'R'
              || c == 'I' || c == 'M')
            {
                return true;
            }
            return false;
        }

        public void HandleKey(char key) 
        {
            if (char.IsDigit(key)) {
                AddDigit(key);
                return;
            }

            if (checkUnnary(key)) {
                UnaryOperation(key);
                return;
            }

            if (key == 'P') { PutMemory(); return; }

            if (key == 'G') { GetMemory(); return; }

            if (key == 'C') { Clear(); return; }

            if (key == 'O') { OnOff(); return; }

            if (key == ',') { Comma(); return; }

            if (key == '=') { Equal(); return; }

            if (checkBinary(key)) { BinaryOperation(key); return; }
        }

        private void AddDigit(char d) {
            if (_enterWait == true) { setCurrent("0"); _enterWait = false; }
            string cur = getCurrent();

            if (cur != "0" && cur != "-E-")
            {
                cur += d.ToString();
            }
            else
            {
                cur = d.ToString();
            }

            int num = cur.Count(x => char.IsDigit(x));

            if (num > 10) {
                cur = cur.Substring(0, (cur.Count() - (num - 10)));
                if (cur.EndsWith(",")) cur = cur.TrimEnd();
            }
            setCurrent(cur);
        }

        private bool checkZero(string s)
        {
            foreach (char c in s)
            {
                if (c != '0')
                    return false;
            }

            return true;
        }

        private void Round() {
            string cur = getCurrent();
            int num = cur.Count(x => char.IsDigit(x));
            int c_pos = cur.IndexOf(',');
            if (cur != "-E-")
            {
                if (Math.Abs(Double.Parse(cur)) < 0.0000000005) { setCurrent("0"); return; }
            }
            if (cur.EndsWith(",")) cur = cur.TrimEnd();
            if (c_pos != -1)
            {
                if (checkZero(cur.Substring(c_pos + 1)))
                {
                    cur = cur.Substring(0, c_pos);
                    setCurrent(cur);
                }
            }

            if (num > 10)
            {
                if (c_pos == -1) { setCurrent("-E-"); return; }
                else
                {
                    int dig = cur.Substring(0, c_pos).Count(x => char.IsDigit(x));
                    cur = Math.Round(Double.Parse(cur), 10 - dig).ToString();
                }
                setCurrent(cur);
            }
        }

        private void UnaryOperation(char enter)
        {
            string curr = getCurrent();
            bool ret = true;

            if (enter == 'S') ret = Sinus(curr);
            else if (enter == 'K') ret = Kosinus(curr);
            else if (enter == 'T') ret = Tangens(curr);
            else if (enter == 'Q') ret = Quadrat(curr);
            else if (enter == 'R') ret = Root(curr);
            else if (enter == 'I') ret = Invers(curr);
            else if (enter == 'M') ret = Minus(curr);

            if (ret == false) { setCurrent("-E-"); return; }
            Round();

        }

        private bool Sinus(string value)
        {
            if (value == null) return false;

            double cur = Double.Parse(value);
            cur = Math.Sin(cur);
            setCurrent(cur.ToString());
            return true;
        }

        private bool Kosinus(string value)
        {
            if (value == null) return false;
            double cur = Double.Parse(value);
            cur = Math.Cos(cur);
            setCurrent(cur.ToString());
            return true;
        }

        private bool Tangens(string value)
        {
            if (value == null) return false;
            double cur = Double.Parse(value);
            cur = Math.Tan(cur);
            setCurrent(cur.ToString());
            return true;
        }

        private bool Quadrat(string value)
        {
            if (value == null) return false;
            double cur = Double.Parse(value);
            cur = Math.Pow(cur, 2);
            setCurrent(cur.ToString());
            return true;
        }

        private bool Root(string value)
        {
            if (value == null) return false;
            double cur = Double.Parse(value);
            if (cur < 0) return false;
            cur = Math.Sqrt(cur);
            setCurrent(cur.ToString());
            return true;
        }

        private bool Invers(string value)
        {
            double cur = Double.Parse(value);
            if (cur == 0) return false;
            cur = 1 / cur;
            setCurrent(cur.ToString());
            return true;
        }

        private bool Minus(string value)
        {
            if (value == null) return false;

            if (value == "0" || _enterWait) return true;
            if (value.IndexOf("-") == -1)
            {
                value = "-" + value;
            }
            else
            {
                value = value.Substring(1);
            }
            setCurrent(value);
            return true;
        }

        private void Clear()
        {
            _current = "0";
        }

        private void OnOff()
        {
            _current = "0"; _memory = null; 
            _enterWait = false; _short = false; _operator = 'N';
            _first = 0;
        }

        private void GetMemory()
        {
            if (_memory != null) setCurrent(_memory);
        }

        private void PutMemory()
        {
            string curr = getCurrent();
            if (curr != null) _memory = curr;
        }

        private void Comma()
        {

            string value = getCurrent();

            if (value == null) { setCurrent("-E-"); return; }
            if (_enterWait) { setCurrent("0"); }
            if (value.IndexOf(',') == -1)
            {
                value += ",";
                setCurrent(value);
            }
        }

        private void Equal() {
            if (_operator == 'N') { Round(); return; }
            if (_enterWait == true) _short = true;

            doOperation();
            if (_enterWait == false) _operator = 'N';

            Round();
        }

        private void BinaryOperation(char key) {
            if (_operator == 'N')
            {
                Round();
                _first = Double.Parse(getCurrent());
                _operator = key;
                _enterWait = true;
            }

            if (_operator != 'N' && _enterWait == true)
            {
                _operator = key;
                if (_short) _first = Double.Parse(getCurrent());
            }

            if (_operator != 'N' && _enterWait == false)
            {
                Round();
                doOperation();
                _operator = key;
                _enterWait = true;
                _short = false;
            }

            Round();
        }

        private void doOperation() {
            double second = double.Parse(getCurrent());

            if (_operator == '-')
            {
                if (_short) second = second - _first;
                else second = _first - second;
            }

            if (_operator == '+')
            {
                second = _first + second;
            }

            if (_operator == '*')
            {
                second = _first * second;
            }

            if (_operator == '/') 
            {
                if (_short)
                {
                    if (_first == 0) { setCurrent("-E-"); return; }
                    second = second / _first;
                }
                else
                {
                    if (second == 0) { setCurrent("-E-"); return; }
                    second = _first / second;
                }
            }

           

            if (_short) { setCurrent(second.ToString()); return; }
            else { _first = second; setCurrent(_first.ToString()); }
        }
    }
}


