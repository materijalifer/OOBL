﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string currentDisplayState;
        private double currentValue;
        public double? valueTemp;
        private double? memory;
        private bool isDecimal = false;
        private bool isBinary = false;
        private char? currentOperator;
        private char[] binaryOperators = { '+', '-', '*', '/' };
        private char[] unaryOperators = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };


        public Kalkulator()
        {
            currentValue = 0;
            updateDisplay();
        }

        private void updateDisplay()
        {
            if (currentValue<10000000000)
	        {
                int numberOfWholeDigits = (int)Math.Floor(Math.Abs(currentValue)).ToString().Length;
                currentValue = Math.Round(currentValue, (10 - numberOfWholeDigits));
                currentDisplayState = currentValue.ToString();
	        }
            else
            {
                currentValue = 0;
                currentDisplayState = "-E-";
            }
            
        }
        public void Press(char inPressedDigit)
        {
            if (char.IsNumber(inPressedDigit))
            {
                handleNumber(inPressedDigit);
            }
            else if (Array.IndexOf(binaryOperators,inPressedDigit)>-1)
            {
                handleBinaryOperator(inPressedDigit);
            }
            else if (Array.IndexOf(unaryOperators, inPressedDigit) > -1)
            {
                handleUnaryOperator(inPressedDigit);
            }
            else if (inPressedDigit == '=')
            {
                handleEquals();
            }
            else if (inPressedDigit == ',')
            {
                currentDisplayState += ",";
            }
            else if (inPressedDigit == 'P')
            {
                memory = currentValue;
            }
            else if (inPressedDigit == 'G')
            {
                if (memory.HasValue)
                {
                    currentValue = memory.Value;
                    updateDisplay();  
                }
            }
            else if (inPressedDigit == 'O')
            {
                memory = null;
                valueTemp = 0;
                currentValue = 0;
                currentOperator = null;
                updateDisplay();
            }
            else if (inPressedDigit == 'C')
            {
                currentDisplayState = "0";
            }
        }

        private void handleUnaryOperator(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case('M'):
                        currentValue=-currentValue;
                        break;
                case('S'):
                        currentValue = Math.Sin(currentValue);
                        break;
                case('K'):
                        currentValue = Math.Cos(currentValue);
                        break;
                case('T'):
                        currentValue = Math.Tan(currentValue);
                        break;
                case('Q'):
                        currentValue = Math.Pow(currentValue,2);
                        break;
                case('R'):
                        currentValue = Math.Sqrt(currentValue);
                        break;
                case('I'):
                        if (currentValue != 0)
                        {
                            currentValue = 1 / currentValue;
                        }
                        else
                        {
                            currentDisplayState = "-E-";
                            return;
                        }
                        break;
                default:
                        currentValue = 0;
                        break;
            }
            updateDisplay();
        }

        private void handleEquals()
        {
            double blje = currentValue;
            switch(currentOperator)
            {
                case '+':
                    currentValue = currentValue + valueTemp.Value;
                    break;
                case '*':
                    currentValue = currentValue * valueTemp.Value;
                    break;
                case '/':
                    if (currentValue!=0)
                    {
                        currentValue = valueTemp.Value / currentValue;
                    }
                    else
                    {
                        currentDisplayState = "-E-";
                        return;
                    }
                    break;
                case '-':
                    currentValue = valueTemp.Value - currentValue;
                    break;
                default:
                    break;
            }
            valueTemp = blje;
            updateDisplay();
        }

        private void handleBinaryOperator(char inPressedDigit)
        {
            if (currentValue!=null)
            {
                handleEquals();
                valueTemp = double.Parse(currentDisplayState);
            }
            else
            {
                valueTemp = double.Parse(currentDisplayState);
            }

            currentOperator = inPressedDigit;
            isBinary = true;
            //currentValue = 0;
        }

        private void handleNumber(char pressedDigit)
        {
            if (currentDisplayState=="0" || isBinary == true)
            {
                currentValue = Double.Parse(pressedDigit.ToString());
                updateDisplay();
                isBinary = false;
            }
            else
            {
                currentDisplayState += pressedDigit.ToString();
                currentValue = Double.Parse(currentDisplayState);
            }
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayState;
        }
        public double GetCurrentValue()
        {
            return currentValue;
        }
    }


}
