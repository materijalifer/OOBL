﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }

    }



     public class Dionica
     {
         public string imeDionice;
         public long brojTihDionica;
         private SortedDictionary<DateTime, Decimal> datumiICijene = new SortedDictionary<DateTime, Decimal>();

         
         public Dionica(string imeDionice, long brojTihDionica, Decimal cijena, DateTime datum)
         {
             this.imeDionice = imeDionice; //kljuc, nije case-sensitive
             this.brojTihDionica = brojTihDionica;
             this.datumiICijene.Add(datum, cijena);
         }
         
         public void dodaj_cijenu(DateTime datum, Decimal cijena)
         {
             if (cijena <= 0m)
             {
                 StockExchangeException iznimka = new StockExchangeException("Vrijednost dionice ne smije biti manja ili jednaka nuli.");
                 throw iznimka;
             }
             if (this.datumiICijene.Keys.Contains(datum))
             {
                 StockExchangeException iznimka = new StockExchangeException("Cijena dionice za ovaj datum vec postoji.");
                 throw iznimka;
             }
             this.datumiICijene.Add(datum, cijena);
             return;
         }
         public Decimal vrati_cijenu(DateTime datum)
         {
             Decimal NEDEFINIRAMA_I_NEMOGUCA_VRIJEDNOST = 0m;
             Decimal cijena = NEDEFINIRAMA_I_NEMOGUCA_VRIJEDNOST;
            
             foreach (DateTime iterDatum in this.datumiICijene.Keys)
             {
                 if (iterDatum > datum)
                 {
                     break;
                 };
                 cijena = this.datumiICijene[iterDatum];
             }
             if (cijena == NEDEFINIRAMA_I_NEMOGUCA_VRIJEDNOST)
             {
                 StockExchangeException iznimka = new StockExchangeException("Tog datuma nije bilo dionice.");
                 throw iznimka;
             }
             else
             {
                 return cijena;
             }
             
         }
         public Decimal vrati_pocetnu_cijenu()
         {
             return this.datumiICijene.First().Value;
         }
         public Decimal vrati_zadnju_cijenu()
         {
             return this.datumiICijene.Last().Value;
         }
     }
   
    public class Indeks
    {
        public string nazivIndeksa;
        public IndexTypes tipIndeksa;
        protected List<Dionica> listaDionica = new List<Dionica>(); 

        
        public virtual Decimal vrati_vrijednost(DateTime datum)
        {
            return 0m;
        }

        public void dodaj_dionicu(Dionica dionica)
        {
            if (dionica_postoji_u_skupu(dionica))
            {
                StockExchangeException iznimka = new StockExchangeException("Indeks vec sadrzi tu dionicu.");
                throw iznimka;
            }
            
            this.listaDionica.Add(dionica);
            return;
        }

        public bool dionica_postoji_u_skupu(Dionica dionica)
        {
            foreach (Dionica iterDionica in this.listaDionica)
            {
                if (iterDionica.imeDionice.Equals(dionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public int vrati_broj_dionica()
        {
            return this.listaDionica.Count;
        }

        public void makni_dionicu(Dionica dionica)
        {
            if (dionica_postoji_u_skupu(dionica) == false)
            {
                StockExchangeException iznimka = new StockExchangeException("Dionica ne postoji u indeksu.");
                throw iznimka;
            }

            for (int i = 0; i < this.listaDionica.Count; i++)
            {
                if (this.listaDionica[i].imeDionice.Equals(dionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    this.listaDionica.RemoveAt(i);
                    return;
                }
            }
        }
        
    }

    public class AverageIndeks : Indeks
    {
        public AverageIndeks(string nazivIndeksa, IndexTypes tipIndeksa)
        {
            this.nazivIndeksa = nazivIndeksa;
            this.tipIndeksa = tipIndeksa;
        }

        public override Decimal vrati_vrijednost(DateTime datum)
        {
            Decimal suma = 0m;
            long nazivnik = 0;
            foreach (Dionica dionica in this.listaDionica)
            {
                suma += dionica.vrati_cijenu(datum);
                nazivnik += 1;
            }
            if (suma != 0m)
            {
                return Decimal.Round(suma/nazivnik, 3, MidpointRounding.AwayFromZero);
            }
            else
            {
                return 0m;
            }
        }
    }

    public class WeightedIndeks : Indeks
    {
        public WeightedIndeks(string nazivIndeksa, IndexTypes tipIndeksa)
        {
            this.nazivIndeksa = nazivIndeksa;
            this.tipIndeksa = tipIndeksa;
        }
        public override Decimal vrati_vrijednost(DateTime datum)
        {
            Decimal ukupnaCijena = 0m;
            foreach (Dionica dionica in this.listaDionica)
            {
                ukupnaCijena += dionica.vrati_cijenu(datum) * dionica.brojTihDionica;
            }
            Decimal rezultat = 0m;
            foreach (Dionica dionica in this.listaDionica)
            {
                Decimal cijenaDionice = dionica.vrati_cijenu(datum);
                Decimal faktor = cijenaDionice/ukupnaCijena;
                rezultat += cijenaDionice*dionica.brojTihDionica*faktor;
            }
            return Decimal.Round(rezultat, 3, MidpointRounding.AwayFromZero);
        }
    }

    public class Portfelj
    {
        public string nazivPortfelja;
        private Dictionary<Dionica, long> dioniceIBroj = new Dictionary<Dionica, long>();

        public Portfelj(string nazivPortfelj)
        {
            this.nazivPortfelja = nazivPortfelj;
        }
        public Decimal vrati_vrijednost(DateTime datum)
        {
            Decimal suma = 0m;
            foreach (Dionica iterDionica in this.dioniceIBroj.Keys)
            {
                suma += iterDionica.vrati_cijenu(datum)*this.dioniceIBroj[iterDionica];
            }
            return suma;
        }
        public bool sadrzi_dionicu(Dionica dionica)
        {
            foreach (Dionica iterDionica in this.dioniceIBroj.Keys)
            {
                if (iterDionica.imeDionice.Equals(dionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
        public long vrati_broj_dionica()
        {
            return this.dioniceIBroj.Keys.Count();
        }
        public long vrati_broj_ovih_dionica(Dionica dionica)
        {
            foreach (Dionica iterDionica in this.dioniceIBroj.Keys)
            {
                if (dionica.imeDionice.Equals(iterDionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    return this.dioniceIBroj[dionica];
                }
            }
            return 0;
        }
        public void dodaj_dionicu(Dionica dionica, long brojDionica)
        {
            foreach (Dionica iterDionica in this.dioniceIBroj.Keys)
            {
                if (iterDionica.imeDionice.Equals(dionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    this.dioniceIBroj[iterDionica] += brojDionica;
                    return;
                }
            }
            this.dioniceIBroj[dionica] = brojDionica;
            return;
        }
        public void makni_dionice_sve(Dionica dionica)
        {
            this.dioniceIBroj.Remove(dionica);
        }
        public void makni_dionice(Dionica dionica, long broj)
        {
            if (this.vrati_broj_ovih_dionica(dionica) == 0)
            {
                StockExchangeException iznimka = new StockExchangeException("Ovaj portfelj vec nema ovih dionica.");
                throw iznimka;
            }
            if (this.vrati_broj_ovih_dionica(dionica) < broj)
            {
                StockExchangeException iznimka = new StockExchangeException("Portfelj nema toliko dionica");
                throw iznimka;
            }
            this.dioniceIBroj[dionica] -= broj;
            
        }
    }

    public class PripadnostDionicaIndeksima
    {
        private Dictionary<Dionica, List<Indeks>> pripadnostDionicaIndeksima = new Dictionary<Dionica, List<Indeks>>();
        
        public List<Indeks> vrati_indekse_kojemu_pripada_dionica_ili_null(Dionica dionica)
        {
            foreach (Dionica iterDionica in this.pripadnostDionicaIndeksima.Keys)
            {
                if (dionica.imeDionice.Equals(iterDionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    return this.pripadnostDionicaIndeksima[iterDionica];
                }
            }
            return null;
        }
        public void brisi_pripadnost_dionice_indeksu(Dionica dionica, Indeks indeks)//sta ako je lista == null, tj.
        {
            List<Indeks> indeksi = this.vrati_indekse_kojemu_pripada_dionica_ili_null(dionica);
            if (indeksi != null)
            {
                foreach (Indeks iterIndeks in indeksi)
                {
                    if (iterIndeks.nazivIndeksa.Equals(indeks.nazivIndeksa, StringComparison.OrdinalIgnoreCase))
                    {
                        indeks.makni_dionicu(dionica);
                        indeksi.Remove(iterIndeks);
                        break;
                    }
                }
            }
            if (indeksi == null)
            {
                this.pripadnostDionicaIndeksima.Remove(dionica);
            }
            return;
        }
        public void brisi_pripadnost_dionice_indeksima(Dionica dionica)
        {
            List<Indeks> indeksi = this.vrati_indekse_kojemu_pripada_dionica_ili_null(dionica);
            if (indeksi != null)
            {
                foreach (Indeks iterIndeks in indeksi)
                {
                    iterIndeks.makni_dionicu(dionica);
                }
            }
            this.pripadnostDionicaIndeksima.Remove(dionica);
            return;

        }
        public void dodaj_pripadnost_dionice_indeksu(Dionica dionica, Indeks indeks)
        {
            indeks.dodaj_dionicu(dionica);
            if (this.pripadnostDionicaIndeksima.Keys.Contains(dionica) == false)
            {
                this.pripadnostDionicaIndeksima.Add(dionica, new List<Indeks>());
            }
            if (this.pripadnostDionicaIndeksima[dionica].Contains(indeks) == false)
            {
                this.pripadnostDionicaIndeksima[dionica].Add(indeks);
            }
            else
            {
                StockExchangeException iznimka = new StockExchangeException("Indeks vec sadrzi tu dionicu");
                throw iznimka;
            }
            return;


        }
    }

    public class PripadnostDionicaPortfeljima
    {
        private Dictionary<Dionica, List<Portfelj>> pripadnostDionicaPortfeljima = new Dictionary<Dionica, List<Portfelj>>();

        public void dodaj_pripadnost_dionice_portfelju(Dionica dionica, Portfelj portfelj, long brojDionica)
        {
            if (brojDionica < 1)
            {
                StockExchangeException iznimka = new StockExchangeException("Broj dionica ne smije biti manji od 1.");
                throw iznimka;
            }
            portfelj.dodaj_dionicu(dionica, brojDionica);
            if (this.pripadnostDionicaPortfeljima.Keys.Contains(dionica) == false)
            {
                this.pripadnostDionicaPortfeljima.Add(dionica, new List<Portfelj>());
            }
            if (this.pripadnostDionicaPortfeljima[dionica].Contains(portfelj) == false)
            {
                this.pripadnostDionicaPortfeljima[dionica].Add(portfelj);
            }
            return;
        }

        public List<Portfelj> vrati_portfelje_kojima_pripada_dionica_ili_null(Dionica dionica)
        {
            foreach (Dionica iterDionica in this.pripadnostDionicaPortfeljima.Keys)
            {
                if (dionica.imeDionice.Equals(iterDionica.imeDionice, StringComparison.OrdinalIgnoreCase))
                {

                    return this.pripadnostDionicaPortfeljima[iterDionica];
                }
            }

            return null;
        }

        public void brisi_pripadnost_dionice_portfelju(Dionica dionica, Portfelj portfelj)
        {
            List<Portfelj> listaPortfelja = this.vrati_portfelje_kojima_pripada_dionica_ili_null(dionica);
            if (listaPortfelja == null)
            {
                StockExchangeException iznimka = new StockExchangeException("Dionica vec ne pripada portfelju.");
                throw iznimka;
            }
            listaPortfelja.Remove(portfelj);
            portfelj.makni_dionice_sve(dionica);
            if (listaPortfelja.Count == 0)
            {
                this.pripadnostDionicaPortfeljima.Remove(dionica);
            }
            return;
        }

        public void brisi_pripadnost_dionice_portfeljima(Dionica dionica)
        {
            List<Portfelj> listaPortfelja = this.vrati_portfelje_kojima_pripada_dionica_ili_null(dionica);
            if (listaPortfelja != null)
            {

                foreach (Portfelj iterPortfelj in listaPortfelja)
                {
                    iterPortfelj.makni_dionice_sve(dionica);
                    break;
                }
            }
            this.pripadnostDionicaPortfeljima.Remove(dionica);
            return;

        }

        public long broj_slobodnih_dionica(Dionica dionica)
        {
            long zauzeteDionice = 0;
            if (this.pripadnostDionicaPortfeljima.Keys.Contains(dionica) == false)
            {
                return dionica.brojTihDionica;
            }
            foreach (Portfelj portfelj in this.vrati_portfelje_kojima_pripada_dionica_ili_null(dionica))
            {
                zauzeteDionice += portfelj.vrati_broj_ovih_dionica(dionica);
            }
            return dionica.brojTihDionica - zauzeteDionice;
        }
    
    }

    public class StockExchange : IStockExchange
     {
        private List<Dionica> skupDionica = new List<Dionica>();
        private List<Indeks> skupIndeksa = new List<Indeks>(); 
        private List<Portfelj> skupPortfelja = new List<Portfelj>(); 

        private PripadnostDionicaIndeksima pripadnostDionicaIndeksima = new PripadnostDionicaIndeksima();
        private PripadnostDionicaPortfeljima pripadnostDionicaPortfeljima = new PripadnostDionicaPortfeljima();
        
        private bool postoji_dionica(string imeDionice)
        {
            foreach (Dionica dionica in this.skupDionica)
            {
                if (dionica.imeDionice.Equals(imeDionice, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;

        }
        private Dionica vrati_dionicu(string imeDionice)
         {
             foreach (Dionica dionica in this.skupDionica)
             {
                 if (dionica.imeDionice.Equals(imeDionice, StringComparison.OrdinalIgnoreCase))
                 {
                     return dionica;
                 }
             }
            StockExchangeException iznimka = new StockExchangeException("Dionica ne postoji.");
            throw iznimka;
         }

        private bool postoji_indeks(string imeIndeksa)
        {
            foreach (Indeks indeks in this.skupIndeksa)
            {
                if (imeIndeksa.Equals(indeks.nazivIndeksa, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

         private Indeks vrati_indeks(string imeIndeksa)
         {
             foreach (Indeks indeks in this.skupIndeksa)
             {
                 if (imeIndeksa.Equals(indeks.nazivIndeksa, StringComparison.OrdinalIgnoreCase))
                 {
                     return indeks;
                 }
             }
             StockExchangeException iznimka = new StockExchangeException("Indeks ne postoji.");
             throw iznimka;
         }

        private bool postoji_portfelj(string imePortfelja)
         {
             foreach (Portfelj portfelj in this.skupPortfelja)
             {
                 if (portfelj.nazivPortfelja == imePortfelja)
                 {
                     return true;
                 }
             }
            return false;
         }

         private Portfelj vrati_portfelj(string imePortfelja)
         {
             foreach (Portfelj portfelj in this.skupPortfelja)
             {
                 if (portfelj.nazivPortfelja == imePortfelja)
                 {
                     return portfelj;
                 }
             }
             StockExchangeException iznimka = new StockExchangeException("Portfelj ne postoji.");
             throw iznimka;
         }


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if(this.postoji_dionica(inStockName))
             {
                 StockExchangeException iznimka = new StockExchangeException("Vec postoji dionica tog imena.");
                 throw iznimka;
             }
             if (inNumberOfShares < 1)
             {
                 StockExchangeException iznimka = new StockExchangeException("Broj dionica manji od 1.");
                 throw iznimka;
             }
             if (inInitialPrice <= 0m)
             {
                 StockExchangeException iznimka = new StockExchangeException("Cijena dionice manja ili jednaka nuli.");
                 throw iznimka;
             }
             Dionica dionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             this.skupDionica.Add(dionica);
             return;
             //throw new NotImplementedException();
         }

         public void DelistStock(string inStockName)
         {
             if (this.postoji_dionica(inStockName) == false)
             {
                 StockExchangeException iznimka = new StockExchangeException("Dionica koju zelite obrisati vec ne postoji.");
                 throw iznimka;
             }
             Dionica dionica = this.vrati_dionicu(inStockName);
             this.pripadnostDionicaIndeksima.brisi_pripadnost_dionice_indeksima(dionica);
             this.pripadnostDionicaPortfeljima.brisi_pripadnost_dionice_portfeljima(dionica);
             this.skupDionica.Remove(dionica);
             return;
             //throw new NotImplementedException();

         }

         public bool StockExists(string inStockName)
         {
             return this.postoji_dionica(inStockName);
             //throw new NotImplementedException();
         }

         public int NumberOfStocks()
         {
             return this.skupDionica.Count;
             //throw new NotImplementedException();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             dionica.dodaj_cijenu(inIimeStamp, inStockValue);
             return;
             //throw new NotImplementedException();
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             Decimal cijena = dionica.vrati_cijenu(inTimeStamp);
             return cijena;
             //throw new NotImplementedException();
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             return dionica.vrati_pocetnu_cijenu();
             //throw new NotImplementedException();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             return dionica.vrati_zadnju_cijenu();
             //throw new NotImplementedException();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (this.postoji_indeks(inIndexName))
             {
                 StockExchangeException iznimka = new StockExchangeException("Indeks vec postoji");
                 throw iznimka;
             }

             Indeks ind;
             switch (inIndexType)
             {
                 case IndexTypes.AVERAGE:
                     ind = new AverageIndeks(inIndexName, inIndexType);
                     break;

                 case IndexTypes.WEIGHTED:
                     ind = new WeightedIndeks(inIndexName, inIndexType);
                     break;

                 default:
                     StockExchangeException iznimka = new StockExchangeException("Nedozvoljen tip indeksa.");
                     throw iznimka;
             }
             this.skupIndeksa.Add(ind);
             return;
             //throw new NotImplementedException();
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             Indeks indeks = this.vrati_indeks(inIndexName);
             this.pripadnostDionicaIndeksima.dodaj_pripadnost_dionice_indeksu(dionica, indeks);
             return;


             //throw new NotImplementedException();
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Indeks indeks = this.vrati_indeks(inIndexName);
             Dionica dionica = this.vrati_dionicu(inStockName);
             List<Indeks> listaIndekasa = this.pripadnostDionicaIndeksima.vrati_indekse_kojemu_pripada_dionica_ili_null(dionica);
             if (listaIndekasa == null)
             {
                 StockExchangeException iznimka = new StockExchangeException("Dionica vec ne pripada indeksu.");
                 throw iznimka;
             }
             this.pripadnostDionicaIndeksima.brisi_pripadnost_dionice_indeksu(dionica, indeks);
             return;
             //throw new NotImplementedException();
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Dionica dionica = this.vrati_dionicu(inStockName);
             Indeks indeks = this.vrati_indeks(inIndexName);

             return indeks.dionica_postoji_u_skupu(dionica);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Indeks indeks = this.vrati_indeks(inIndexName);
             return indeks.vrati_vrijednost(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return this.postoji_indeks(inIndexName);
             //throw new NotImplementedException();
         }

         public int NumberOfIndices()
         {
             return this.skupIndeksa.Count;
             //throw new NotImplementedException();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Indeks indeks = this.vrati_indeks(inIndexName);
             return indeks.vrati_broj_dionica();
             //throw new NotImplementedException();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (this.postoji_portfelj(inPortfolioID))
             {
                 StockExchangeException iznimka = new StockExchangeException("Portfelj vec postoji.");
                 throw iznimka;
             }
             Portfelj portfelj = new Portfelj(inPortfolioID);
             this.skupPortfelja.Add(portfelj);
             //throw new NotImplementedException();
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             Dionica dionica = this.vrati_dionicu(inStockName);
             if (this.pripadnostDionicaPortfeljima.broj_slobodnih_dionica(dionica) < numberOfShares)
             {
                 StockExchangeException iznimka = new StockExchangeException("Nema dovoljno slobodnih dionica");
                 throw iznimka;
             }
             this.pripadnostDionicaPortfeljima.dodaj_pripadnost_dionice_portfelju(dionica, portfelj, numberOfShares);
             return;
             //throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             Dionica dionica = this.vrati_dionicu(inStockName);
             portfelj.makni_dionice(dionica, numberOfShares);
             if (portfelj.vrati_broj_ovih_dionica(dionica) == 0)
             {
                 this.pripadnostDionicaPortfeljima.brisi_pripadnost_dionice_portfelju(dionica, portfelj);
             }
             //throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             Dionica dionica = this.vrati_dionicu(inStockName);
             this.pripadnostDionicaPortfeljima.brisi_pripadnost_dionice_portfelju(dionica, portfelj);
             return;
             // throw new NotImplementedException();
         }

         public int NumberOfPortfolios()
         {
             return this.skupPortfelja.Count;
             //throw new NotImplementedException();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             return (int)portfelj.vrati_broj_dionica();
             //throw new NotImplementedException();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this.postoji_portfelj(inPortfolioID);
             //throw new NotImplementedException();
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             Dionica dionica = this.vrati_dionicu(inStockName);
             return portfelj.sadrzi_dionicu(dionica);
             //throw new NotImplementedException();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
             Dionica dionica = this.vrati_dionicu(inStockName);
             if (portfelj.sadrzi_dionicu(dionica) == false)
             {
                 StockExchangeException iznimka = new StockExchangeException("Portfelj ne sadrzi ovu dionicu.");
                 throw iznimka;
             }
             return (int)portfelj.vrati_broj_ovih_dionica(dionica);
             
         }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
            return portfelj.vrati_vrijednost(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (Year < 0 || Month > 12 || Month < 1)
            {
                StockExchangeException iznimka = new StockExchangeException("Losa vrijednost godine ili mjeseca");
                throw iznimka;
            }
            Portfelj portfelj = this.vrati_portfelj(inPortfolioID);
            DateTime datumPrviDan = new DateTime(Year, Month, 1);
            DateTime datumZadnjiDan = datumPrviDan.AddMonths(1).AddMilliseconds(-1);

            try
            {
                return
                    Decimal.Round(
                        100*(portfelj.vrati_vrijednost(datumZadnjiDan)/portfelj.vrati_vrijednost(datumPrviDan)-1), 3,
                        MidpointRounding.AwayFromZero);
            }
            catch (DivideByZeroException e)
            {
               return 0m;
            }
            //throw new NotImplementedException();
        }
     }
}
