﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,Stock> allStocks = new Dictionary<string,Stock>(); //sve dionice na burzi
         private Dictionary<string, Index> allIndexes = new Dictionary<string, Index>(); //svi indeksi na burzi
         private Dictionary<string, Portfolio> allPorts = new Dictionary<string, Portfolio>(); //svi portfelji
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!allStocks.ContainsKey(inStockName.ToUpper()) && inInitialPrice>0)
             {
                 Stock addStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 allStocks[inStockName.ToUpper()]=addStock;
             }
             else
             {
                 throw new StockExchangeException("Dionica s istim imenom vec postoji!");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()))
             {
                
                 //izbacujemo dionicu iz svih indeksa
                 foreach (string key in allIndexes.Keys)
                 {
                     if (IsStockPartOfIndex(key,inStockName))
                     {
                         RemoveStockFromIndex(key,inStockName);
                     }
                 }
                 //izbacujemo dionicu iz svih portfolia
                 foreach (string key in allPorts.Keys)
                 {
                     if (IsStockPartOfPortfolio(key,inStockName))
                     {
                         RemoveStockFromPortfolio(key,inStockName);
                     }
                 }//brisemo dionicu s burze
                 allStocks.Remove(inStockName.ToUpper());
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa zadanim imenom!");
             }
         }

         public bool StockExists(string inStockName)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 return true;
             }
             else
                 return false;
         }

         public int NumberOfStocks()
         {
             return allStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()) && inStockValue>0)
             {
                 allStocks[inStockName.ToUpper()].addToHistory(inStockValue, inIimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Nije moguce postaviti vrijednost za nepostojecu dionicu!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 return allStocks[inStockName.ToUpper()].getCurrentPriceFromHistory(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Ne moze se provjeriti cijena za nepostojecu dionicu!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 return allStocks[inStockName.ToUpper()].getInitialPrice();
             }
             else
             {
                 throw new StockExchangeException("Dionica s navedenim imenom ne postoji!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 return allStocks[inStockName.ToUpper()].getLastPrice();
             }
             else
             {
                 throw new StockExchangeException("Dionica s navedenim imenom ne postoji!");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
            if (inIndexType!=IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Tip indeksa nije ispravan!!");
            }
            if(!allIndexes.ContainsKey(inIndexName.ToUpper()))
            {
                Index newInd = new Index(inIndexType);
                allIndexes.Add(inIndexName.ToUpper(),newInd);
            }
            else
            {
                throw new StockExchangeException("Indeks s istim imenom vec postoji!");
            }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ne mozemo dodati dionicu koja ne postoji na burzi u indeks!");
             }
             else if (!allIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ne možemo dodati dionicu u nepostojeći indeks!");
             }
             else
             {
                 allIndexes[inIndexName.ToUpper()].addStock(inStockName.ToUpper()); //dodajemo dionicu
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ne mozemo maknuti dionicu koja ne postoji na burzi!");
             }
             else if (!allIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ne možemo maknuti dionicu iz nepostojeceg indeksa!");
             }
             else
             {
                 allIndexes[inIndexName.ToUpper()].removeStock(inStockName.ToUpper()); 
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool contains = false;
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ne mozemo maknuti dionicu koja ne postoji na burzi!");
             }
             else if (!allIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ne možemo maknuti dionicu iz nepostojeceg indeksa!");
             }
             else
             {
                 contains=allIndexes[inIndexName.ToUpper()].containsStock(inStockName.ToUpper()); 
             }
             return contains;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal value = 0;
             decimal sum = 0;
             decimal numberOf = 0;
             if (allIndexes[inIndexName.ToUpper()].typeIndex == IndexTypes.AVERAGE)
             {
                 foreach (string names in allIndexes[inIndexName.ToUpper()].containsStocks)
                 {
                     sum += GetStockPrice(names, inTimeStamp);
                     numberOf ++;
                 }
                 if (numberOf == 0)
                 {
                     value = 0;
                 }
                 else
                 {
                     value = Math.Round((sum / numberOf), 3);
                 }
                 
             }
             else
             {
                 decimal valueAll = 0;
                 foreach (string names in allIndexes[inIndexName.ToUpper()].containsStocks)
                 {
                     valueAll += GetStockPrice(names, inTimeStamp) * allStocks[names.ToUpper()].numOfShares;
                 }
                 foreach (string names in allIndexes[inIndexName.ToUpper()].containsStocks)
                 {
                     value += (GetStockPrice(names, inTimeStamp) * allStocks[names.ToUpper()].numOfShares) * GetStockPrice(names, inTimeStamp) / valueAll;
                 }
                 value = Math.Round(value, 3);
             }
             
             return value;
         }

         public bool IndexExists(string inIndexName)
         {
             if (allIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return allIndexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 return allIndexes[inIndexName.ToUpper()].containsStocks.Count;
             }
             else
             {
                 throw new StockExchangeException("Indeks sa zadanim imenom ne postoji!!");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!allPorts.ContainsKey(inPortfolioID))
             {
                 Portfolio newPortfolio = new Portfolio();
                 allPorts.Add(inPortfolioID, newPortfolio);
             }
             else
             {
                 throw new StockExchangeException("Na burzi postoji portfolio sa istim imenom!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Nije moguce dodati u portfolio dionicu koja ne postoji!");
             }
             if (!allPorts.ContainsKey(inPortfolioID))
             {
                 throw new  StockExchangeException("Nije moguce dodati dionicu u portfolio koji ne postoji!");
             }
             else
             {
                 allPorts[inPortfolioID].addStock(inStockName,numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!allPorts.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Nije moguce ukloniti dionicu iz nepostojeceg portfolia!");
             }
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Nije moguce ukloniti dionicu koja ne postoji na burzi!");
             }
             if (numberOfShares > 0)
             {
                 allPorts[inPortfolioID].removeNumberOfStock(inStockName,numberOfShares);
             }
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!allPorts.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Nije moguce ukloniti dionicu iz nepostojeceg portfolia!");
             }
             if (!allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Nije moguce ukloniti dionicu koja ne postoji na burzi!");
             }
             else
             {
                 allPorts[inPortfolioID].removeStock(inStockName);
             }
         }

         public int NumberOfPortfolios()
         {
             return allPorts.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!allPorts.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji na burzi!");
             }
             else
             {
                 return allPorts[inPortfolioID].stocksInPortfoilo.Count;
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (allPorts.ContainsKey(inPortfolioID))
             {
                 return true;
             }
             else
             {
                 return false;
             }
             
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfolio!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji dionica!");
             }
             else
             {
                 if (allPorts[inPortfolioID].stocksInPortfoilo.ContainsKey(inStockName.ToUpper()))
                 {
                     return true;
                 }
                 return false;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID,inStockName))
             {
                 throw new StockExchangeException("Zadana dionica nije u zadanom portfoliu!");
             }
             else
             {
                 return allPorts[inPortfolioID].stocksInPortfoilo[inStockName.ToUpper()];
             }
            
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Trazeni portfolio ne postoji!");
             }
             decimal value = 0;
             foreach (string key in allPorts[inPortfolioID].stocksInPortfoilo.Keys)
             {
                 value += (GetStockPrice(key.ToUpper(), timeStamp) * allPorts[inPortfolioID].stocksInPortfoilo[key]);
             }
             value = Math.Round(value, 3);
             return value;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime timeStart = new DateTime(Year,Month,1,0,0,0,0);
             DateTime timeEnd = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             decimal timeChange = 0;
             if (GetPortfolioValue(inPortfolioID, timeEnd) == 0 || GetPortfolioValue(inPortfolioID, timeStart) == 0)
             {
                 return 0;
             }
             timeChange = ((GetPortfolioValue(inPortfolioID, timeEnd) - GetPortfolioValue(inPortfolioID, timeStart)) / GetPortfolioValue(inPortfolioID, timeStart))*100;
             timeChange = Math.Round(timeChange, 3);
             return timeChange;
         }
     }

     public class Stock
     {
         public long numOfShares;
         private Dictionary<DateTime, decimal> history = new Dictionary<DateTime, decimal>();
         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             numOfShares = inNumberOfShares;
             history[inTimeStamp] = inInitialPrice; //dodamo početnu vrijednost u povijest
         }
         public void addToHistory(decimal inInitialPrice, DateTime inTimeStamp)
         {
             history[inTimeStamp] = inInitialPrice;
         }
         public decimal getCurrentPriceFromHistory(DateTime time)
         {
             decimal currentPrice=0;
             if (history.ContainsKey(time))
             {
                 currentPrice = history[time];
             }
             else
             {
                 TimeSpan min=new TimeSpan();
                 int k = 0;
                 foreach (KeyValuePair<DateTime, decimal> pair in history)
                 {
                     if (k == 0 && DateTime.Compare(pair.Key,time)>0)
                     {
                         k++;
                         continue;
                     }
                     if (k == 0 && DateTime.Compare(pair.Key, time)<0)
                     {
                         min = pair.Key - time;
                         currentPrice = pair.Value;
                     }
                     if (DateTime.Compare(pair.Key, time)>0)
                         continue; 
                     if((pair.Key-time) > min)
                     {
                         currentPrice = pair.Value;
                     }
                    
                 }
             }
             return currentPrice;
         }

         public decimal getInitialPrice()
         {
             DateTime minKey = history.Keys.Min();    
             return history[minKey];
         }

         public decimal getLastPrice()
         {
             DateTime minKey = history.Keys.Max();
             return history[minKey];
         }


     }

     public class Index
     {
         public IndexTypes typeIndex;
         public List<string> containsStocks = new List<string>();
         public Index(IndexTypes inIndexType)
         {
             typeIndex = inIndexType;
         }
         public void addStock(string stockName)
         {
             containsStocks.Add(stockName.ToUpper());
         }
         public void removeStock(string stockName)
         {
             containsStocks.Remove(stockName.ToUpper());
         }
         public bool containsStock(string stockName)
         {
             if(containsStocks.Contains(stockName.ToUpper()))
             {
                 return true;
             }
             return false;
         }
         
     }

     public class Portfolio
     {
         public Dictionary<string, int> stocksInPortfoilo = new Dictionary<string, int>();
         
         public void addStock(string inStockName,int numberOfShares)
         {
             if (stocksInPortfoilo.ContainsKey(inStockName.ToUpper()))
             {
                 stocksInPortfoilo[inStockName.ToUpper()] += numberOfShares;
             }
             else
             {
                 stocksInPortfoilo[inStockName.ToUpper()] = numberOfShares;
             }
         }
         public void removeStock(string inStockName)
         {
             stocksInPortfoilo.Remove(inStockName.ToUpper());
         }
         public void addMoreShares(string inStockName, int numberOfShares)
         {
             stocksInPortfoilo[inStockName.ToUpper()] += numberOfShares;
         }
         public void removeNumberOfStock(string inStockName, int numberOfShares)
         {
             stocksInPortfoilo[inStockName.ToUpper()] -= numberOfShares;
             if(stocksInPortfoilo[inStockName.ToUpper()]==0)
             {
                 removeStock(inStockName);
             }
         }
         
     }
}
