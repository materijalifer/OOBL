﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator {
    public class SimpleCalculator : ICalculator {
        private const int DIGITS_LIMIT = 10;
        private const string DEFAULT_DISPLAY_STATE = "0";
        private const string ERROR_DISPLAY_STATE = "-E-";
        private const string DECIMAL_SIGN = ",";

        private readonly int digitsLimit;
        private string displayState = DEFAULT_DISPLAY_STATE;
        private bool screenIsPendingReset = true;

        private string memory;

        private DisplayHandler dh;
        private BaseOperator activeOperator = Operator.NeutralOperator();

        public SimpleCalculator() {
            this.digitsLimit = DIGITS_LIMIT;
            dh = new DisplayHandler(digitsLimit, DECIMAL_SIGN, ERROR_DISPLAY_STATE);
        }

        public SimpleCalculator(int digitsLimit) {
            this.digitsLimit = digitsLimit;
            dh = new DisplayHandler(digitsLimit, DECIMAL_SIGN, ERROR_DISPLAY_STATE);
        }

        public void Press(char digit) {
            if (Char.IsDigit(digit)) {
                ProcessNumber(digit);
            }
            else if (digit.ToString() == DECIMAL_SIGN) {
                ProcessDecimalSign();
            }
            else {
                ProcessOperator(digit);
            }
        }

        private void ProcessNumber(char digit) {
            if (screenIsPendingReset) {
                displayState = digit.ToString();
                if (displayState != DEFAULT_DISPLAY_STATE) {
                    screenIsPendingReset = false;
                }
            }
            else {
                displayState += digit;
            }
            displayState = dh.TrimDisplayState(displayState);
        }

        private void ProcessDecimalSign() {
            if (dh.DisplayIsDecimal(displayState) == false) {
                displayState += DECIMAL_SIGN;
                screenIsPendingReset = false;
            }
        }

        private void ProcessOperator(char digit) {
            BaseOperator newOperator = null;
            if (Operator.TryParse(digit.ToString(), out newOperator)) {
                double parsedDisplayState = dh.ParseStringToDouble(displayState);
                /* Special Operators */
                if (newOperator is OperatorEquals) {
                    if (activeOperator.ReadyToExecute() == false) {
                        activeOperator.PushOperand(parsedDisplayState);
                    }
                    double buffer = activeOperator.Execute();
                    displayState = dh.NormalizeDisplayState(buffer);
                    activeOperator = Operator.NeutralOperator();
                }
                else if (newOperator is OperatorPut) {
                    memory = displayState;
                }
                else if (newOperator is OperatorGet) {
                    displayState = memory;
                }
                else if (newOperator is OperatorReset) {
                    displayState = DEFAULT_DISPLAY_STATE;
                    activeOperator = Operator.NeutralOperator();
                    screenIsPendingReset = true;
                }
                else if (newOperator is OperatorClearScreen) {
                    displayState = DEFAULT_DISPLAY_STATE;
                    screenIsPendingReset = true;
                }
                else {
                    newOperator.PushOperand(parsedDisplayState);
                    if (newOperator.ReadyToExecute()) {
                        /* Uletio je unarni operator, on ima prioritet */
                        double buffer = newOperator.Execute();
                        displayState = dh.NormalizeDisplayState(buffer);
                    }
                    else {
                        /* Only binary operators here */
                        if (screenIsPendingReset) {
                            /* Two operators were entered in a row, without numbers in between */
                            /* Ignore the last operator and go with the new one */
                            activeOperator = newOperator;
                        }
                        else {
                            /* Add the current display state to the last activeOperator */
                            screenIsPendingReset = true;
                            activeOperator.PushOperand(parsedDisplayState);
                            if (activeOperator.ReadyToExecute()) {
                                double buffer = activeOperator.Execute();
                                displayState = dh.NormalizeDisplayState(buffer);
                                newOperator.RefreshOperand(buffer); /* Unfortunately, his operand is out of date. Refresh the results */
                                activeOperator = newOperator;
                            }
                        }
                    }
                }
            }
        }

        public string GetCurrentDisplayState() {
            return displayState;
        }
    }

    public class Factory {
        public static ICalculator CreateCalculator() {
            return new SimpleCalculator();
        }
    }
	
    public class DisplayHandler {
        private NumberFormatInfo nfi = new NumberFormatInfo();
        private int digitsLimit;
        private string errorState;

        public DisplayHandler(int digitsLimit, string decimalSign, string errorState) {
            this.digitsLimit = digitsLimit;
            nfi.NumberDecimalSeparator = decimalSign;
            this.errorState = errorState;
        }

        public string NormalizeDisplayState(string displayState) {
            string result;
            try {
                double buffer = ParseStringToDouble(displayState);
                result = ParseDoubleToString(buffer);
                result = RoundDisplayState(displayState);
            }
            catch (Exception) {
                result = errorState;
            }
            return result;
        }

        public string NormalizeDisplayState(double displayState) {
            string parsedDisplayState = ParseDoubleToString(displayState);
            return NormalizeDisplayState(parsedDisplayState);
        }

        public string RoundDisplayState(string displayState) {
            string result;
            if (ResultFitsOnDisplay(displayState)) {
                int integerDigitsCount = NumberOfIntegerDigits(displayState);
                double parsedResult = ParseStringToDouble(displayState);
                double roundedResult = Math.Round(parsedResult, digitsLimit - integerDigitsCount);
                result = ParseDoubleToString(roundedResult);
            }
            else {
                result = errorState;
            }
            return result;
        }

        public string TrimDisplayState(string displayState) {
            int decimalSize = (DisplayIsDecimal(displayState)) ? 1 : 0;
            int signSize = (DisplayIsNegative(displayState)) ? 1 : 0;
            string result = displayState.Substring(0, Math.Min(displayState.Length, digitsLimit + decimalSize + signSize));
            return result;
        }

        private bool ResultFitsOnDisplay(string displayState) {
            int integerDigitsCount = NumberOfIntegerDigits(displayState);
            if (integerDigitsCount <= digitsLimit) {
                return true;
            }
            else {
                return false;
            }
        }

        private int NumberOfIntegerDigits(string displayState) {
            return Math.Abs((int)ParseStringToDouble(displayState)).ToString().Length;
        }

        private bool DisplayIsFull(string displayState, int digitsLimit) {
            return (DigitsOnDisplay(displayState) >= digitsLimit);
        }

        private bool DisplayIsNegative(string displayState) {
            return (displayState[0] == '-');
        }

        private int DigitsOnDisplay(string displayState) {
            int decimalSize = (DisplayIsDecimal(displayState)) ? 1 : 0;
            int signSize = (DisplayIsNegative(displayState)) ? 1 : 0;
            int result = displayState.Length - decimalSize - signSize;
            return result;
        }

        public bool DisplayIsDecimal(string displayState) {
            return displayState.Contains(nfi.NumberDecimalSeparator);
        }

        public string ParseDoubleToString(double displayState) {
            return displayState.ToString(nfi);
        }

        public double ParseStringToDouble(string displayState) {
            return Double.Parse(displayState, nfi);
        }
    }	
	
	abstract public class BaseBinaryOperator : BaseOperator {
        protected double OperandA {
            get {
                return base.GetOperand(0);
            }
        }
        protected double OperandB {
            get {
                return base.GetOperand(1);
            }
        }

        public BaseBinaryOperator(string id) : base(id, 2) { }
    }
	
    public class OperatorAdd : BaseBinaryOperator {
        public OperatorAdd() : base("+") { }

        protected override double Calculate() {
            return OperandA + OperandB;
        }
    }
	
    public class OperatorDivide : BaseBinaryOperator {
        public OperatorDivide() : base ("/") { }

        protected override double Calculate() {
            return OperandA / OperandB;
        }
    }
	
    public class OperatorMultiply : BaseBinaryOperator {
        public OperatorMultiply() : base ("*") { }
        protected override double Calculate() {
            return OperandA * OperandB;
        }
    }
	
    public class OperatorSubtract : BaseBinaryOperator {
        public OperatorSubtract() : base ("-") { }

        protected override double Calculate() {
            return OperandA - OperandB;
        }
    }
	
    abstract public class BaseUnaryOperator : BaseOperator {
        protected double Operand { get { return base.GetOperand(0); } }

        public BaseUnaryOperator(string id) : base(id, 1) { }

    }
	
    public class OperatorChangeSign : BaseUnaryOperator {
        public OperatorChangeSign() : base("M") { }

        protected override double Calculate() {
            return Operand * -1;
        }
    }
	
    public class OperatorClearScreen : BaseUnaryOperator {
        public OperatorClearScreen() : base("C") { }

        protected override double Calculate() {
            return 0;
        }
    }
	
    public class OperatorCos : BaseUnaryOperator {
        public OperatorCos() : base("K") { }

        protected override double Calculate() {
            return Math.Cos(Operand);
        }
    }
	
    public class OperatorEquals : BaseUnaryOperator {
        public OperatorEquals() : base("=") { }

        protected override double Calculate() {
            return Operand;
        }
    }
	
    public class OperatorGet : BaseUnaryOperator {
        public OperatorGet() :base("G"){

        }
        protected override double Calculate() {
            return 0;
        }
    }
	
    public class OperatorInverse : BaseUnaryOperator {
        public OperatorInverse() : base("I") { }

        protected override double Calculate() {
            return 1 / Operand;
        }
    }
	
    public class OperatorPut : BaseUnaryOperator {
        public OperatorPut() : base("P") {

        }

        protected override double Calculate() {
            return 0;
        }
    }
	
    public class OperatorReset : BaseUnaryOperator {
        public OperatorReset() : base ("O") { }

        protected override double Calculate() {
            return 0;
        }
    }
	
    public class OperatorSin : BaseUnaryOperator {
        public OperatorSin() : base ("S") { }

        protected override double Calculate() {
            return Math.Sin(Operand);
        }
    }
	
    public class OperatorSquare : BaseUnaryOperator {
        public OperatorSquare() : base("Q") { }

        protected override double Calculate() {
            return Operand * Operand;
        }
    }
	
    public class OperatorSquareRoot : BaseUnaryOperator {
        public OperatorSquareRoot() : base("R") { }

        protected override double Calculate() {
            return Math.Sqrt(Operand);
        }
    }
	
    public class OperatorTan : BaseUnaryOperator {
        public OperatorTan() : base ("T") { }

        protected override double Calculate() {
            return Math.Tan(Operand);
        }
    }
	
    public abstract class BaseOperator {
        private double[] operands;
        private readonly int requiredNumOperands;
        private int currentNumOperands = 0;

        private readonly string id;
        public string Id { get { return id; } }

        public BaseOperator(string id, int requiredNumOperands) {
            this.id = id;
            this.requiredNumOperands = requiredNumOperands;
            operands = new double[this.requiredNumOperands];
        }

        public bool ReadyToExecute() {
            return (currentNumOperands == requiredNumOperands);
        }

        public void PushOperand(double operand) {
            operands[currentNumOperands] = operand;
            currentNumOperands += 1;
        }

        
        public void RefreshOperand(double operand) {
            operands[currentNumOperands - 1] = operand;
        }

        public double PopOperand() {
            if (currentNumOperands == 0) throw new Exception("No operands to pop");
            currentNumOperands -= 1;
            return operands[currentNumOperands + 1];
        }

        public double Execute() {
            if (ReadyToExecute() == false) {
                throw new Exception("Operator not ready for executing");
            }
            double result;
            try {
                result = Calculate();
            }
            catch (Exception) {
                result = double.NaN;
            }
            return result;
        }

        protected double GetOperand(int index) {
            if (index >= operands.Length) throw new ArgumentOutOfRangeException("GetOperand je tražio veći index nego što postoji");
            return operands[index];
        }

        abstract protected double Calculate();
    }
	
    public class Operator {
        private static readonly Dictionary<string, Type> supportedOperators = new Dictionary<string, Type>();

        static Operator() {
            /* Start Binary Operators  */
            AddNewOperator(new OperatorAdd());
            AddNewOperator(new OperatorSubtract());
            AddNewOperator(new OperatorMultiply());
            AddNewOperator(new OperatorDivide());
            /* End Binary Operators */

            /* Start Unary Operators */
            AddNewOperator(new OperatorEquals());
            AddNewOperator(new OperatorChangeSign());
            AddNewOperator(new OperatorSin());
            AddNewOperator(new OperatorCos());
            AddNewOperator(new OperatorTan());
            AddNewOperator(new OperatorSquare());
            AddNewOperator(new OperatorSquareRoot());
            AddNewOperator(new OperatorInverse());
            AddNewOperator(new OperatorClearScreen());
            AddNewOperator(new OperatorReset());
            AddNewOperator(new OperatorPut());
            AddNewOperator(new OperatorGet());
            /* End Unary Operators */
        }

        public static BaseOperator NeutralOperator() {
            return new OperatorEquals();
        }

        private static void AddNewOperator(BaseOperator op) {
            supportedOperators.Add(op.Id, op.GetType());
        }

        public static bool TryParse(string opId, out BaseOperator op) {
            if (supportedOperators.ContainsKey(opId)) {
                op = (BaseOperator)Activator.CreateInstance(supportedOperators[opId]);
                return true;
            }
            else {
                op = null;
                return false;
            }
        }
    }
	
}
