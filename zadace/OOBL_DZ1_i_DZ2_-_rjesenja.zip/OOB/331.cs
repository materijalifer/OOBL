﻿/*
 =======================================================================================
 Name        : StockExchange.cs
 Author      : Hrvoje Kozačinski
 Version     : 1.0
 Description : Druga domaća zadaća iz predmeta Objektno oblikovanje, FER, siječanj 2013.
 =======================================================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {

         private Dictionary<string, Stock> stocksList;
         private Dictionary<string, StockIndex> stockIndicesList;
         private Dictionary<string, StockPortfolio> stockPortfoliosList;

         public StockExchange()
         {
             stocksList = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
             stockIndicesList = new Dictionary<string, StockIndex>(StringComparer.InvariantCultureIgnoreCase);
             stockPortfoliosList = new Dictionary<string, StockPortfolio>();
         }


         // METODE DIONICA

         /**
          * Metoda koja dodaje dionice s početnom cijenom na burzu. U slučaju pokušaja
          * dodavanja već postojećih dionica ili null reference na burzu, metoda baca
          * iznimku s odgovarajućom porukom.
          **/
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             try
             {
                 stocksList.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Nije moguce dodati dionice (vec postoje ili se dodaje null)!");
             }
         }

         /**
          * Metoda koja briše tražene dionice s burze, ali time i
          * iz svih indeksa i portfelja.
          **/
         public void DelistStock(string inStockName)
         {
             // provjera imena
             if (string.IsNullOrEmpty(inStockName))
                 throw new StockExchangeException("Brisanje dionica nije moguće (ime dionica je prazno ili null)!");

             // uklanjanje dionica iz svih indeksa
             foreach (var index in stockIndicesList.Values)
             {
                 if (IsStockPartOfIndex(index.indexName, inStockName))
                     RemoveStockFromIndex(index.indexName, inStockName);
             }  

             // uklanjanje dionica iz svih portfelja
             foreach (var portfolio in stockPortfoliosList.Values)
             {
                 if (IsStockPartOfPortfolio(portfolio.portfolioID, inStockName))
                     RemoveStockFromPortfolio(portfolio.portfolioID, inStockName);
             }

             // uklanjanje dionica s burze
             stocksList.Remove(inStockName);
         }

         /**
          * Metoda koja provjerava postoje li tražene dionice na burzi. Ako postoje
          * tražene dionice, metoda vraća true, inače vraća false. U slučaju pokušaja
          * pretrage praznog imena ili null reference dionica, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public bool StockExists(string inStockName)
         {
             if(string.IsNullOrEmpty(inStockName))
                 throw new StockExchangeException("Pretraga dionica nije moguca (ime dionica je prazno ili null)!");
             
             if (stocksList.ContainsKey(inStockName))
                 return true;
             else
                 return false;
         }

         /**
          * Metoda koja vraća broj dionica na burzi.
          **/
         public int NumberOfStocks()
         {
             return stocksList.Count;
         }

         /**
          * Metoda koja postavlja cijenu dionica za određeno vrijeme. U slučaju krivo zadanih
          * parametara, metoda baca iznimku s odgovarajućom porukom.
          **/
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // provjera inicijalne cijene
             if (inStockValue <= 0)
                 throw new StockExchangeException("Pogresno zadana vrijednost (negativna ili nula)!");

             // ako već postoji cijena dionica za zadano vrijeme, baca se iznimka
             foreach (var currentTimeStamp in stock.stockPrices.Keys)
             {
                 if (currentTimeStamp.Equals(inIimeStamp))
                     throw new StockExchangeException("Već postoji cijena dionica za zadani datum!");
             }
             
             // postavljanje cijene za zadano vrijeme
             stock.stockPrices.Add(inIimeStamp, inStockValue);
         }

         /**
          * Metoda koja dohvaća cijenu dionica za određeno vrijeme. Ako je moguće dohvaća se cijena
          * u točnom vremenu, inače se dohvaća cijena vezana uz najbliže vrijeme prije zadanog vremena.
          * Ako je traženo vrijeme prije ijednog vremena vezanog uz cijene dionica, dohvaća se cijena
          * vezana uz najbliže vrijeme u budućnosti od zadanog vremena. U slučaju krivo zadanih
          * parametara, metoda baca iznimku s odgovarajućom porukom.
          **/
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // dohvaćanje odgovarajućeg vremena
             DateTime timeStamp = stock.stockPrices.Keys[0];
             foreach (var currentTimeStamp in stock.stockPrices.Keys)
             {
                 if (currentTimeStamp <= inTimeStamp)
                     timeStamp = currentTimeStamp;
                 else break;
             }

             // vraćanje cijene vezane uz odgovarajuće vrijeme
             decimal price;
             stock.stockPrices.TryGetValue(timeStamp, out price);
             return price;
         }

         /**
          * Metoda koja dohvaća najraniju moguću cijenu dionica. U slučaju krivo zadanih
          * parametara, metoda baca iznimku s odgovarajućom porukom.
          **/
         public decimal GetInitialStockPrice(string inStockName)
         {
             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // dohvaćanje odgovarajućeg vremena
             DateTime timeStamp = stock.stockPrices.Keys[0];

             // vraćanje odgovarajuće cijene dionica
             return stock.stockPrices[timeStamp];
         }

         /**
          * Metoda koja dohvaća najsvježiju moguću cijenu dionica. U slučaju krivo zadanih
          * parametara, metoda baca iznimku s odgovarajućom porukom.
          **/
         public decimal GetLastStockPrice(string inStockName)
         {
             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // dohvaćanje odgovarajućeg vremena
             DateTime timeStamp = stock.stockPrices.Keys[stock.stockPrices.Count - 1];

             // vraćanje odgovarajuće cijene dionica
             return stock.stockPrices[timeStamp];
         }

         /**
          * Pomoćna metoda koja provjerava ispravnost naziva dionica i
          * dohvaća tražene dionice. U slučaju neuspjele provjere, metoda
          * baca iznimku s odgovarajućom porukom.
          **/
         private Stock CheckAndFetchStock(string inStockName)
         {
             // provjera postoje li dionice na burzi
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Nije moguce dohvatiti dionice koje ne postoje na burzi!");

             // dohvaćanje dionica
             Stock stock;
             stocksList.TryGetValue(inStockName, out stock);

             // vraćanje dionica
             return stock;
         }


         // METODE INDEKSA

         /**
          * Metoda koja stvara indeks i dodaje na burzu. U slučaju pokušaja dodavanja
          * već postojećeg indeksa ili null reference na burzu, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             try
             {
                 stockIndicesList.Add(inIndexName, new StockIndex(inIndexName, inIndexType));
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Nije moguce dodati indeks (vec postoji ili se dodaje null)!");
             }
         }

         /**
          * Metoda koja dodaje dionice u indeks. U slučaju pokušaja dodavanja dionica
          * u indeks praznog imena, null reference imena ili nepostojeći indeks, odnosno
          * dodavanja dionica praznog imena, null reference imena, nepostojećih dionica
          * na burzi ili dodavanja dionica koje već postoje u indeksu, metoda baca iznimku
          * s odgovarajućom porukom.
          **/
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             // provjera postoji li indeks na burzi i dohvaćanje indeksa
             StockIndex index = CheckAndFetchIndex(inIndexName);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // provjera sadrži li već indeks dionice
             foreach (var currentStock in index.indexStocks)
             {
                 if (currentStock.stockName.Equals(inStockName, StringComparison.InvariantCultureIgnoreCase))
                     throw new StockExchangeException("Nije moguce dodati dionice koje već postoje u indeksu!");
             }

             // dodavanje dionica u indeks
             index.indexStocks.Add(stock);
         }

         /**
          * Metoda koja uklanja dionice iz indeksa. U slučaju pokušaja uklanjanja dionica
          * iz nepostojećeg indeksa ili uklanjanja nepostojećih dionica na burzi, metoda
          * baca iznimku s odgovarajućom porukom.
          **/
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             // provjera postoji li indeks na burzi i dohvaćanje indeksa
             StockIndex index = CheckAndFetchIndex(inIndexName);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // uklanjanje dionice iz indeksa
             index.indexStocks.Remove(stock);
         }

         /**
          * Metoda koja provjerava postoje li tražene dionice u indeksu. Ako postoje
          * tražene dionice, metoda vraća true, inače vraća false. U slučaju pokušaja
          * pretrage praznog imena, null reference ili nepostojećeg indeksa, odnosno
          * pokušaja pretrage praznog imena, null reference ili nepostojećih dionica,
          * metoda baca iznimku s odgovarajućom porukom.
          **/
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             // provjera postoji li indeks na burzi i dohvaćanje indeksa
             StockIndex index = CheckAndFetchIndex(inIndexName);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // provjera postoji li dionica u indeksu
             if (index.indexStocks.Contains(stock))
                 return true;
             else
                 return false;
         }

         /**
          * Metoda koja vraca izracunatu vrijednost trazenog indeksa za trazeno vrijeme.
          * U slučaju pokušaja izračuna vrijednosti indeksa praznog imena, null reference
          * ili nepostojećeg indeksa, odnosno praznog indeksa, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             // provjera postoji li indeks na burzi i dohvaćanje indeksa
             StockIndex index = CheckAndFetchIndex(inIndexName);

             // provjera je li indeks prazan i vraćanje vrijednosti 0 ako jest
             if (index.indexStocks.Count == 0)
                 // throw new StockExchangeException("Nije moguce izracunati vrijednost praznog indeksa!");
                 return 0;

             // grananje ovisno o tipu indeksa
             decimal indexValue = 0;
             decimal stocksSumValue = 0;
             switch (index.indexType)
             {
                 case IndexTypes.AVERAGE:

                     // računanje ukupne vrijednosti svih vrsta dionica
                     foreach (var stock in index.indexStocks)
                         stocksSumValue += GetStockPrice(stock.stockName, inTimeStamp);

                     // računanje vrijednosti indeksa
                     indexValue = stocksSumValue / index.indexStocks.Count;

                     // vraćanje vrijednosti indeksa zaokruženog na 3 decimale
                     return decimal.Round(indexValue, 3);


                 case IndexTypes.WEIGHTED:

                     // računanje ukupne vrijednosti svih dionica
                     foreach (var stock in index.indexStocks)
                         stocksSumValue += stock.numberOfShares * GetStockPrice(stock.stockName, inTimeStamp);

                     // računanje težinskih faktora pojedinih dionica
                     decimal[] weightFactors = new decimal[index.indexStocks.Count];
                     int weightFactorIndex = 0;
                     foreach (var stock in index.indexStocks)
                     {
                         decimal stockValue = stock.numberOfShares * GetStockPrice(stock.stockName, inTimeStamp);
                         weightFactors[weightFactorIndex] = stockValue / stocksSumValue;
                         weightFactorIndex++;
                     }

                     // računanje vrijednosti indeksa
                     weightFactorIndex = 0;
                     foreach (var stock in index.indexStocks)
                     {
                         indexValue += GetStockPrice(stock.stockName, inTimeStamp) * weightFactors[weightFactorIndex];
                         weightFactorIndex++;
                     }

                     // vraćanje vrijednosti indeksa zaokruženog na 3 decimale
                     return decimal.Round(indexValue, 3);
             }

             throw new StockExchangeException("Tip indeksa nalazi se u nedopuštenom stanju!");
         }

         /**
          * Metoda koja provjerava postoji li traženi indeks na burzi. Ako postoji
          * traženi indeks, metoda vraća true, inače vraća false. U slučaju pokušaja
          * pretrage praznog imena ili null reference indeksa, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public bool IndexExists(string inIndexName)
         {
             if (string.IsNullOrEmpty(inIndexName))
                 throw new StockExchangeException("Pretraga indeksa nije moguca (ime indeksa je prazno ili null)!");

             if (stockIndicesList.ContainsKey(inIndexName))
                 return true;
             else
                 return false;
         }

         /**
          * Metoda koja vraća broj indeksa na burzi.
          **/
         public int NumberOfIndices()
         {
             return stockIndicesList.Count;
         }

         /**
          * Metoda koja vraća broj različitih dionica koje se nalaze u indeksu.
          * U slučaju pokušaja pretrage praznog imena, null reference ili
          * nepostojećeg indeksa, metoda baca iznimku s odgovarajućom porukom.
          **/
         public int NumberOfStocksInIndex(string inIndexName)
         {
             // provjera postoji li indeks na burzi i dohvaćanje indeksa
             StockIndex index = CheckAndFetchIndex(inIndexName);

             // vraćanje broja različitih dionica u indeksu
             return index.indexStocks.Count;
         }

         /**
          * Pomoćna metoda koja provjerava ispravnost naziva indeksa i
          * dohvaća traženi indeks. U slučaju neuspjele provjere, metoda
          * baca iznimku s odgovarajućom porukom.
          **/
         private StockIndex CheckAndFetchIndex(string inIndexName)
         {
             // provjera postoji li indeks na burzi
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Nije moguce dohvatiti indeks koji ne postoji na burzi!");

             // dohvaćanje traženog indeksa
             StockIndex index;
             stockIndicesList.TryGetValue(inIndexName, out index);

             // vraćanje indeksa
             return index;
         }


         // METODE PORTFELJA

         /**
          * Metoda koja stvara portfelj i dodaje na burzu. U slučaju pokušaja dodavanja
          * već postojećeg portfelja ili null reference na burzu, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public void CreatePortfolio(string inPortfolioID)
         {
             try
             {
                 stockPortfoliosList.Add(inPortfolioID, new StockPortfolio(inPortfolioID));
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Nije moguce dodati portfelj (vec postoji ili se dodaje null)!");
             }
         }

         /**
          * Metoda koja dodaje dionice u portfelj. U slučaju pokušaja dodavanja dionica
          * u portfelj praznog imena, null reference imena ili nepostojeći portfelj, odnosno
          * dodavanja dionica praznog imena, null reference imena, nepostojećih dionica
          * na burzi ili dodavanja dionica koje već postoje u portfelju, metoda baca iznimku
          * s odgovarajućom porukom.
          **/
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // računanje ukupnog broja dionica po svim portfeljima
             int sharesInPortfolios = 0;
             foreach (var currentStockPortfolio in stockPortfoliosList.Values)
             {
                 foreach (var currentStock in currentStockPortfolio.portfolioStocks.Keys)
                 {
                     if (currentStock.stockName.Equals(inStockName))
                     {
                         int shares;
                         currentStockPortfolio.portfolioStocks.TryGetValue(currentStock, out shares);
                         sharesInPortfolios += shares;
                         break;
                     }
                 }
             }

             // provjera mogućnosti dodavanja dodatnih dionica
             if(sharesInPortfolios + numberOfShares > stock.numberOfShares)
                 throw new StockExchangeException("Nije moguce dodati više dionica nego postoji na burzi!");

             // dodavanje dionice u portfelj
             if (portfolio.portfolioStocks.ContainsKey(stock))
                 portfolio.portfolioStocks[stock] += numberOfShares;
             else
                 portfolio.portfolioStocks.Add(stock, numberOfShares);
         }

         /**
          * Metoda koja uklanja željeni broj dionica iz portfelja. U slučaju pokušaja uklanjanja
          * dionica iz nepostojećeg portfelja ili uklanjanja nepostojećih dionica na burzi ili
          * uklanjanja dionica koje se ne nalaze u navedenom portfelju, metoda baca iznimku s
          * odgovarajućom porukom. Također, do iznimke dolazi ako se želi ukloniti više dionica
          * iz portfelja nego ih zaista ima u njemu.
          **/
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // provjera ima li traženih dionica u portfelju
             if (!portfolio.portfolioStocks.ContainsKey(stock))
                 throw new StockExchangeException("Nije moguce ukloniti dionice koje ne postoje u portfoliju!");


             // provjera mogućnosti uklanjanja željenog broja dionica

             // ako ima manje dionica nego se želi ukloniti, dolazi do greške
             if (portfolio.portfolioStocks[stock] < numberOfShares)
                 throw new StockExchangeException("Nije moguce ukloniti više dionica iz portfelja nego što ih ima!");
             
             // ako ima više dionica nego treba ukloniti, uklanjaju se djelomično
             else if (portfolio.portfolioStocks[stock] > numberOfShares)
                 portfolio.portfolioStocks[stock] -= numberOfShares;
             
             // ako se uklanja onoliko dionica koliko ih ima u portfelju, uklanjaju se u potpunosti
             else
                 portfolio.portfolioStocks.Remove(stock);
         }

         /**
          * Metoda koja uklanja željene dionice iz portfelja. U slučaju pokušaja uklanjanja
          * dionica iz nepostojećeg portfelja, uklanjanja nepostojećih dionica na burzi ili
          * uklanjanja dionica koje se ne nalaze u navedenom portfelju, metoda baca iznimku
          * s odgovarajućom porukom.
          **/
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // provjera ima li traženih dionica u portfelju
             if (!portfolio.portfolioStocks.ContainsKey(stock))
                 throw new StockExchangeException("Nije moguce ukloniti dionice koje ne postoje u portfoliju!");

             // uklanjanje dionica iz portfelja
             portfolio.portfolioStocks.Remove(stock);
         }

         /**
          * Metoda koja vraća broj portfelja na burzi.
          **/
         public int NumberOfPortfolios()
         {
             return stockPortfoliosList.Count;
         }

         /**
          * Metoda koja vraća broj različitih dionica željenog portfelja na burzi.
          * U slučaju pokušaja pretrage praznog imena ili null reference portfelja,
          * odnosno nepostojećeg portfelja, metoda baca iznimku s odgovarajućom
          * porukom.
          **/
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             return portfolio.portfolioStocks.Count;
         }

         /**
          * Metoda koja provjerava postoji li traženi portfelj na burzi. Ako postoji
          * traženi portfelj, metoda vraća true, inače vraća false. U slučaju pokušaja
          * pretrage praznog imena ili null reference portfelja, metoda baca iznimku s
          * odgovarajućom porukom.
          **/
         public bool PortfolioExists(string inPortfolioID)
         {
             if (string.IsNullOrEmpty(inPortfolioID))
                 throw new StockExchangeException("Pretraga portfelja nije moguca (ime portfelja je prazno ili null)!");

             if (stockPortfoliosList.ContainsKey(inPortfolioID))
                 return true;
             else
                 return false;
         }

         /**
          * Metoda koja provjerava sadrži li traženi portfelj na burzi navedene dionice.
          * Ako sadrži, metoda vraća true, inače vraća false. U slučaju pokušaja pretrage
          * praznog imena, null reference portfelja ili nepostojećeg portfelja, odnosno
          * pokušaja pretrage nepostojećih dionica, metoda baca iznimku s odgovarajućom
          * porukom.
          **/
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             if (portfolio.portfolioStocks.ContainsKey(stock))
                 return true;
             else
                 return false;
         }

         /**
          * Metoda koja vraća broj navedenih dionica željenog portfelja na burzi. U
          * slučaju pokušaja pretrage praznog imena, null reference portfelja ili
          * nepostojećeg portfelja, odnosno pokušaja pretrage nepostojećih dionica,
          * metoda baca iznimku s odgovarajućom porukom.
          **/
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera postoje li dionice na burzi i dohvaćanje dionica
             Stock stock = CheckAndFetchStock(inStockName);

             // vraćanje traženog broja dionica u portfelju
             return portfolio.portfolioStocks[stock];
         }

         /**
          * Metoda koja vraća vrijednost željenog portfelja na burzi. U slučaju
          * pokušaja pretrage praznog imena, null reference portfelja ili
          * nepostojećeg portfelja, metoda baca iznimku s odgovarajućom porukom.
          **/
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // računanje ukupne vrijednosti portfelja
             decimal portfolioValue = 0;
             int numberOfShares;
             foreach (var stock in portfolio.portfolioStocks.Keys)
             {
                 numberOfShares = portfolio.portfolioStocks[stock];
                 portfolioValue += numberOfShares * GetStockPrice(stock.stockName, timeStamp);
             }

             // vraćanje vrijednosti željenog portfelja
             return decimal.Round(portfolioValue, 3);
         }

         /**
          * Metoda koja vraća postotak mjesečne promjene željenog portfelja na burzi.
          * U slučaju pokušaja pretrage praznog imena, null reference portfelja ili
          * nepostojećeg portfelja, metoda baca iznimku s odgovarajućom porukom.
          **/
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             // provjera postoji li portfelj na burzi i dohvaćanje portfelja
             StockPortfolio portfolio = CheckAndFetchPortfolio(inPortfolioID);

             // provjera valjanosti vrijednosti godine
             if (Year < DateTime.MinValue.Year || Year > DateTime.MaxValue.Year)
                 throw new StockExchangeException("Pogresno zadana godina!");

             // provjera valjanosti vrijednosti mjeseca
             if (Month < 1 || Month > 12)
                 throw new StockExchangeException("Pogresno zadan mjesec!");

             // ako u portfelju nema dionica, postotak promjene je 0
             if (NumberOfStocksInPortfolio(portfolio.portfolioID) == 0)
                 return 0;

             // provjera imaju li sve dionice cijene za prvi i zadnji dan mjeseca, ako ne promjena je 0
             DateTime firstDay = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             DateTime lastDay = firstDay.AddMonths(1).AddMilliseconds(-1);
             foreach (var stock in portfolio.portfolioStocks.Keys)
             {
                 if (!stock.stockPrices.Keys.Contains(firstDay)
                     || !stock.stockPrices.Keys.Contains(lastDay))
                     return 0;
             }

             // računanje postotka mjesečne promjene
             decimal firstDayValue = GetPortfolioValue(inPortfolioID, firstDay);
             decimal lastDayValue = GetPortfolioValue(inPortfolioID, lastDay);
             decimal percentChangeInValue = (lastDayValue - firstDayValue) / firstDayValue * 100;

             // vraćanje postotka mjesečne promjene zaokruženog na 3 decimale
             return decimal.Round(percentChangeInValue, 3);
         }

         /**
          * Pomoćna metoda koja provjerava ispravnost naziva portfelja i
          * dohvaća traženi portfelj. U slučaju neuspjele provjere, metoda
          * baca iznimku s odgovarajućom porukom.
          **/
         private StockPortfolio CheckAndFetchPortfolio(string inPortfolioID)
         {
             // provjera imena portfelja
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Nije moguce dohvatiti portfelj koji ne postoji na burzi!");

             // dohvaćanje traženog portfelja
             StockPortfolio portfolio;
             stockPortfoliosList.TryGetValue(inPortfolioID, out portfolio);

             // vraćanje portfelja
             return portfolio;
         }

     }

    /**
     * Razred koji modelira dionice burze.
     **/
    public class Stock
    {
        public string stockName;
        public long numberOfShares;
        public SortedList<DateTime, decimal> stockPrices;

        /**
         * Konstruktor za inicijalizaciju Stock objekta pomoću željenih parametara. U slučaju
         * krivo zadanih parametara, konstruktor baca iznimku s odgovarajućom porukom.
         **/
        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            // provjera ispravnosti argumenata konstruktora
            
            // ime
            if (string.IsNullOrEmpty(stockName))
                throw new StockExchangeException("Pogresno zadano ime dionica (prazno ili null)!");

            // broj dionica
            if (numberOfShares <= 0)
                throw new StockExchangeException("Pogresno zadan broj dionica (negativan ili nula)!");

            // inicijalna cijena
            if (initialPrice <= 0)
                throw new StockExchangeException("Pogresno zadana inicijalna cijena (negativan ili nula)!");


            // pohrana argumenata u novostvoreni objekt
            this.stockName = stockName;
            this.numberOfShares = numberOfShares;
            stockPrices = new SortedList<DateTime, decimal>();
            stockPrices.Add(timeStamp, initialPrice);
        }
    }

    /**
     * Razred koji modelira indekse na burzi.
     **/
    public class StockIndex
    {
        public string indexName;
        public IndexTypes indexType;
        public List<Stock> indexStocks;

        /**
         * Konstruktor za inicijalizaciju StockIndex objekta pomoću željenih parametara. U slučaju
         * krivo zadanih parametara, konstruktor baca iznimku s odgovarajućom porukom.
         **/
        public StockIndex(string indexName, IndexTypes indexType)
        {
            // provjera ispravnosti argumenata konstruktora

            // ime
            if (string.IsNullOrEmpty(indexName))
                throw new StockExchangeException("Pogresno zadano ime indeksa (prazno ili null)!");


            // pohrana argumenata u novostvoreni objekt
            this.indexName = indexName;
            this.indexType = indexType;
            indexStocks = new List<Stock>();
        }
    }

    /**
     * Razred koji modelira portfelje na burzi.
     **/
    public class StockPortfolio
    {
        public string portfolioID;
        public Dictionary<Stock, int> portfolioStocks;

        /**
         * Konstruktor za inicijalizaciju Stock objekta pomoću željenih parametara. U slučaju
         * krivo zadanih parametara, konstruktor baca iznimku s odgovarajućom porukom.
         **/
        public StockPortfolio(string portfolioID)
        {
            // provjera ispravnosti argumenata konstruktora

            // ime
            if (string.IsNullOrEmpty(portfolioID))
                throw new StockExchangeException("Pogresno zadano ime portfelja (prazno ili null)!");


            // pohrana argumenata u novostvoreni objekt
            this.portfolioID = portfolioID;
            portfolioStocks = new Dictionary<Stock, int>();
        }

    }

}
