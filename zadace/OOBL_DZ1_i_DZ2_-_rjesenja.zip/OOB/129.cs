﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DrugaDomacaZadaca_Burza;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        StockRepository _stockRep = new StockRepository();
        IndexRepository _indexRep = new IndexRepository();

        #region methods

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockRep.AddStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            _stockRep.RemoveStockByName(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return _stockRep.StockAlreadyExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return _stockRep.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            _stockRep.GetStockByName(inStockName).SetPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockRep.GetStockByName(inStockName).TempPrice;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockRep.GetStockByName(inStockName).InitPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return _stockRep.GetStockByName(inStockName).TempPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indexRep.AddIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (_stockRep.StockAlreadyExists(inStockName))
            {
                _indexRep.GetIndexByName(inIndexName).AddStock(_stockRep.GetStockByName(inStockName));
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            _indexRep.GetIndexByName(inIndexName).RemoveStockByName(_stockRep.GetStockByName(inStockName).Name);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _indexRep.GetIndexByName(inIndexName).StockExists(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            throw new NotImplementedException();
        }

        public bool IndexExists(string inIndexName)
        {
            return _indexRep.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indexRep.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            throw new NotImplementedException();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public int NumberOfPortfolios()
        {
            throw new NotImplementedException();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }
        #endregion
    }

    public class Stock
    {
        private string _name;
        private decimal _initPrice;
        private decimal _tempPrice;
        private long _stockNumber;
        private int _availableStocks; // ??
        private DateTime _validFrom;       

        public decimal TempPrice
        {
            get { return _tempPrice; }
            set 
            {
                if (value > 0)
                    _initPrice = value;
                else
                    throw new StockExchangeException("Cijena ne može biti 0 ili negativna.");
            }
        }

        public decimal InitPrice
        {
            get { return _initPrice; }
            set 
            {
                if (value > 0)
                    _initPrice = value;
                else
                    throw new StockExchangeException("Cijena ne može biti 0 ili negativna.");
            }
        }

        public DateTime ValidFrom
        {
            get { return _validFrom; }
            set { _validFrom = value; }
        }

        public long StockNumber
        {
            get { return _stockNumber; }
            set
            {
                if (value > 0)
                    _initPrice = value;
                else
                    throw new StockExchangeException("Broj dionica ne može biti 0 ili negativan.");
            }
        }

        public string Name
        {
            get { return _name; }
            set 
            { 
                _name = value.ToLower();
            }
        }

        public void SetPrice(DateTime inIimeStamp, decimal inStockValue)
        {
            this._tempPrice = inStockValue;
            this._validFrom = inIimeStamp;
            // OBAVIJESTITI INDEXE I PORTFELJE O PROMJENI
        }
    }
   
    public class Portfelj
    {
        List<Stock> _stockList = new List<Stock>();

        private string _id;

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public long GetNumberOfStocks()
        {
            long sum = 0;
            foreach (Stock st in _stockList)
            {
                sum += st.StockNumber;
            }
            return sum;
        }

        public void RemoveStock()
        {
            // TODO
        }

        public void AddStock()
        { }

        //public void RemoveStock()
        //{ }
    }

    public class Index
    {
        // dionice koje pripadaju indexu
        List<Stock> _stocks = new List<Stock>();
        List<Stock> _stockStorno = new List<Stock>();

        private string _name;
        private string _type;
        private decimal _value;
        private int _stockNumber;       

        public decimal Value
        {
            get 
            {
                GetIndexValue(); // TODO
                return _value; 
            }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value.ToLower(); }
        }

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this._name = inIndexName;
            SetIndexType(inIndexType);
        }

        public void SetIndexType(IndexTypes inType)
        {
            if (inType == IndexTypes.AVERAGE)
            {
                _type = "AVERAGE";
            }
            else if (inType == IndexTypes.WEIGHTED)
            {
                _type = "WEIGHED";
            }
            else 
            {
                throw new StockExchangeException("Nepostojeći tip indexa");
            }
        }

        public void GetIndexValue()
        {
            if (this._type == "AVERAGE")
            {
                decimal br = 0;
                foreach (Stock st in _stocks)
                {
                    br += st.InitPrice;
                }
                _value = br / _stocks.Count;
            }
            else 
            {
                // weighed todo
            }
        }

        public bool CheckStockStorno(Stock stock)
        {
            foreach (Stock s in _stocks)
            {
                if (stock.Name == s.Name)
                    return true;
            }
            _stockStorno.Add(stock);
            return false;
        }

        public void AddStock(Stock s)
        {
            if (!CheckStockStorno(s))
                _stocks.Add(s);
            else
                throw new StockExchangeException("Dionisa je već bila u indexu");
        }

        public void RemoveStockByName(string stName)
        {
            foreach (Stock st in _stocks)
            {
                if (st.Name == stName)
                    _stocks.Remove(st);
            }
        }

        public void RemoveStockByRef(Stock stock)
        {
            foreach (Stock s in _stocks)
            {
                if (stock.Name == s.Name)
                    _stocks.Remove(s);
            }
            _stocks.Remove(stock);
        }

        public bool StockExists(string name)
        {
            foreach (Stock s in _stocks)
            {
                if (s.Name == name)
                    return true;
            }
            return false;
        }
    }

    public class IndexRepository
    {
        List<Index> _indexes = new List<Index>();

        public int Count()
        {
            return _indexes.Count();
        }

        public void AddIndex(string name, IndexTypes type)
        {
            _indexes.Add(new Index(name, type));
        }

        public void RemoveIndex()
        {
            // TODO
        }

        public Index GetIndexByName(string name)
        {
            foreach (Index i in _indexes)
            {
                if (i.Name == name.ToLower())
                    return i;
            }
            throw new StockExchangeException("Taj index ne postoji");
        }

        public bool IndexExists(string name)
        {
            foreach (Index i in _indexes)
            {
                if (i.Name == name)
                    return true;
            }
            return false;
        }
    }

    public class StockRepository
    {
        // predstavlja listu dionica na cijeloj burzi
        List<Stock> _stocks = new List<Stock>();

        public int Count()
        {
            int sum = 0;
            foreach (Stock s in _stocks) 
            {
                sum += (int)s.StockNumber;
            }
            return sum;
        }

        public void AddStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock tmp = new Stock();
            tmp.Name = inStockName;
            tmp.StockNumber = inNumberOfShares;
            tmp.InitPrice = inInitialPrice;
            tmp.ValidFrom = DateTime.Now;
            if (StockAlreadyExists(inStockName))
                throw new StockExchangeException("Postoji takva dionica");
            tmp.TempPrice = inInitialPrice;
            _stocks.Add(tmp);
        }

        public bool StockAlreadyExists(string name)
        {
            foreach (Stock s in _stocks)
            {
                if (s.Name == name)
                    return true;
            }
            return false;
        }

        public void RemoveStockByName(string stName)
        {
            foreach (Stock st in _stocks)
            {
                if (st.Name == stName)
                    _stocks.Remove(st);
            }
        }

        public void RemoveStockByRef(Stock stock)
        {
            foreach (Stock s in _stocks)
            {
                if (stock.Name == s.Name)
                    _stocks.Remove(s);
            }
            _stocks.Remove(stock);
        }

        public Stock GetStockByName(string name)
        {
            foreach (Stock s in _stocks)
            {
                if (s.Name == name.ToLower())
                    return s;
            }
            throw new StockExchangeException("Dionica pod tim imenom ne postoji");
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            GetStockByName(inStockName).ValidFrom = inIimeStamp;
            GetStockByName(inStockName).TempPrice = inStockValue;
            // OBAVIJESTITI INDEXE I PORTFELJE ...?

        }
    }   

}
