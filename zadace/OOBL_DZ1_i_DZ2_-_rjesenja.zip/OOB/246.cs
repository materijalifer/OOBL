﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string display;
        private char ch;
        private double[] memory = new double[100];
        private string errorSymbol = "-E-";
        private double currentResult = 0;
        private int numberOfDigits = 0;
        private int numberOfDecimalDigits = 0;
        private int roundFactor = 0;
        private int memoryCounter = 0;
        private Boolean decimalPointSet = false;
        private Boolean resultIsBiggerThanAllowed = false;
        private double leftOperand = double.NegativeInfinity;
        private Boolean binaryOperationSet = false;
        private string lastOperation = "";

        Dictionary<string, MethodInfo> methodMappings = new Dictionary<string, MethodInfo>();

        public Kalkulator()
        {
            methodMappings["+"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("PlusAction");
            methodMappings["-"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("MinusAction");
            methodMappings["*"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("MultiplyAction");
            methodMappings["/"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("DivideAction");
            methodMappings["="] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("EqualsAction");
            methodMappings[","] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("DecimalPointAction");
            methodMappings["M"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("SwitchSignAction");
            methodMappings["S"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("SinusAction");
            methodMappings["K"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("CosinusAction");
            methodMappings["T"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("TangensAction");
            methodMappings["Q"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("SquareAction");
            methodMappings["R"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("RootAction");
            methodMappings["I"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("InvertAction");
            methodMappings["P"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("MemoryPutAction");
            methodMappings["G"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("MemoryGetAction");
            methodMappings["C"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("ClearDisplayAction");
            methodMappings["O"] = Type.GetType("PrvaDomacaZadaca_Kalkulator.Kalkulator").GetMethod("ResetAction");

            display = currentResult.ToString();
        }

        public void Press(char inPressedDigit)
        {
            ch = inPressedDigit;
            string s = new String(new char[] { inPressedDigit });
            if (methodMappings.Keys.Contains(s))
            {
                MethodInfo method = methodMappings[s];
                if (method != null)
                {
                    method.Invoke(this, null);
                }
            }
            else
            {
                handleNumber(ch);
            }
            
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        public void PlusAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = true;
            decimalPointSet = false;
            if (leftOperand.Equals(double.NegativeInfinity))
            {
                leftOperand = currentResult;
            }
            else
            {
                leftOperand += currentResult;
                currentResult = leftOperand;
                updateDisplay();
            }
            numberOfDecimalDigits = 0;
            numberOfDigits = 0;
            lastOperation = "+";
        }

        public void MinusAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = true;
            decimalPointSet = false;
            if (leftOperand.Equals(double.NegativeInfinity))
            {
                leftOperand = currentResult;
            }
            else
            {
                if (currentResult < 0)
                {
                    leftOperand += currentResult;
                }
                else
                {
                    leftOperand -= currentResult;
                }
                currentResult = leftOperand;
                updateDisplay();
            }
            numberOfDecimalDigits = 0;
            numberOfDigits = 0;
            lastOperation = "-";
        }

        public void MultiplyAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = true;
            decimalPointSet = false;
            if (leftOperand.Equals(double.NegativeInfinity))
            {
                leftOperand = currentResult;
            }
            else
            {
                leftOperand *= currentResult;
                currentResult = leftOperand;
                updateDisplay();
            }
            numberOfDecimalDigits = 0;
            numberOfDigits = 0;
            lastOperation = "*";
        }

        public void DivideAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = true;
            decimalPointSet = false;
            if (leftOperand.Equals(double.NegativeInfinity))
            {
                leftOperand = currentResult;
            }
            else
            {
                if (currentResult.Equals(0))
                {
                    display = errorSymbol;
                }
                else
                {
                    leftOperand /= currentResult;
                    currentResult = leftOperand;
                    updateDisplay();
                }
            }
            numberOfDecimalDigits = 0;
            numberOfDigits = 0;
            lastOperation = "/";
        }

        public void EqualsAction()
        {
            binaryOperationSet = false;
            if (lastOperation.Equals(""))
            {
                setRoundFactor();
                if (resultIsBiggerThanAllowed)
                {
                    display = errorSymbol;
                    return;
                }
                double temp = currentResult - (int)currentResult;
                if (temp == 0)
                {
                    display = currentResult.ToString();
                }
            }
            else if (lastOperation.Equals("+"))
            {
                currentResult = leftOperand + currentResult;
                updateDisplay();
            }
            else if (lastOperation.Equals("-"))
            {
                currentResult = leftOperand - currentResult;
                updateDisplay();
            }
            else if (lastOperation.Equals("*"))
            {
                currentResult = leftOperand * currentResult;
                updateDisplay();
            }
            else if (lastOperation.Equals("/"))
            {
                if (currentResult.Equals(0))
                {
                    display = errorSymbol;
                }
                else
                {
                    currentResult = leftOperand / currentResult;
                    updateDisplay();
                }
            }
        }

        public void DecimalPointAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            decimalPointSet = true;
        }

        public void SwitchSignAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            currentResult = currentResult * (-1);
            updateDisplay();
        }

        public void SinusAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            currentResult = Math.Sin(currentResult);
            display = Math.Round(currentResult, 9).ToString();
            binaryOperationSet = false;
            numberOfDecimalDigits = 9;
        }

        public void CosinusAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            currentResult = Math.Cos(currentResult);
            display = Math.Round(currentResult, 9).ToString();
            binaryOperationSet = false;
            numberOfDecimalDigits = 9;
        }

        public void TangensAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = false;
            currentResult = Math.Tan(currentResult);
            display = Math.Round(currentResult, 9).ToString();
            numberOfDecimalDigits = 9;
        }

        public void SquareAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = false;
            currentResult = Math.Pow(currentResult, 2);
            numberOfDecimalDigits *= 2;
            updateDisplay();
        }

        public void RootAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            binaryOperationSet = false;
            currentResult = Math.Pow(currentResult, 0.5);
            updateDisplay();
        }

        public void InvertAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            if (currentResult == 0)
            {
                display = errorSymbol;
                return;
            }
            binaryOperationSet = false;
            currentResult = Math.Pow(currentResult, -1);
            numberOfDecimalDigits = (currentResult % 1).ToString().Length - 2;
            updateDisplay();
        }

        public void MemoryPutAction()
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            memory[memoryCounter] = currentResult;
            memoryCounter++;
            currentResult = 0;
            numberOfDecimalDigits = 0;
            numberOfDigits = 0;
        }

        public void MemoryGetAction()
        {
            if (display == errorSymbol)
            {
                return;
            }
            int pom = 10;
            currentResult = 0;
            for (int i = 0; i < memoryCounter; i++)
            {
                currentResult = currentResult * pom + memory[i];
            }
            memoryCounter = 0;
            updateDisplay();
        }

        public void ClearDisplayAction()
        {
            display = "0";
        }

        public void ResetAction()
        {
            display = "0";
            memory = new double[100];
            roundFactor = 0;
            currentResult = 0;
            numberOfDigits = 0;
            numberOfDecimalDigits = 0;
            memoryCounter = 0;
            resultIsBiggerThanAllowed = false;
            decimalPointSet = false;
            leftOperand = double.NegativeInfinity;
            binaryOperationSet = false;
            lastOperation = "";
        }

        private void handleNumber(char ch)
        {
            if (display.Equals(errorSymbol))
            {
                return;
            }
            if (ch < '0' && ch > '9')
            {
                display = errorSymbol;
            }
            else
            {
                if (display.Equals("0") || binaryOperationSet)
                {
                    if (binaryOperationSet)
                    {
                        binaryOperationSet = false;
                        currentResult = 0;
                    }
                    if (decimalPointSet)
                    {
                        display = "0," + ch.ToString();
                        numberOfDigits++;
                        numberOfDecimalDigits++;
                    }
                    else
                    {
                        display = ch.ToString();
                        if (numberOfDigits == 0)
                        {
                            numberOfDigits++;
                        }
                    }
                    currentResult = ch - '0';
                }
                else
                {
                    double temp = ch - '0';
                    if (decimalPointSet)
                    {
                        temp /= 10;
                        for (int i = 0; i < numberOfDecimalDigits; i++)
                        {
                            temp /= 10;
                        }
                        if (currentResult < 0)
                        {
                            currentResult -= temp;
                        }
                        else
                        {
                            currentResult += temp;
                        }
                        numberOfDecimalDigits++;
                    }
                    else
                    {
                        if (currentResult < 0)
                        {
                            currentResult = currentResult * 10 - temp;
                        }
                        else
                        {
                            currentResult = currentResult * 10 + temp;
                        }

                    }
                    numberOfDigits++;
                    updateDisplay();
                }
            }

        }

        private void setRoundFactor()
        {
            int number = (int)currentResult;
            if (number < 0)
            {
                number *= -1;
            }
            int counter = 0;
            while (number > 0)
            {
                number /= 10;
                counter++;
            }
            if (counter >= 10)
            {
                resultIsBiggerThanAllowed = true;
                roundFactor = 0;
            }
            else
            {
                roundFactor = 10 - counter;
            }
            if (roundFactor > numberOfDecimalDigits)
            {
                roundFactor = numberOfDecimalDigits;
            }
        }

        private void updateDisplay()
        {
            if (binaryOperationSet)
            {
                return;
            }
            setRoundFactor();
            if (resultIsBiggerThanAllowed)
            {
                display = errorSymbol;
                return;
            }
            double temp = currentResult - (int)currentResult;
            if (!temp.Equals(0))
            {
                removeDecimalEndingZeros();
                display = Math.Round(currentResult, roundFactor).ToString();
            }
            else
            {
                display = Math.Round(currentResult, roundFactor).ToString();
                if (numberOfDecimalDigits > 0)
                {
                    display += ",";
                }
                for (int i = 0; i < roundFactor; i++)
                {
                    display += "0";
                }
            }
        }

        private void removeDecimalEndingZeros()
        {
            double temp = currentResult - (int)currentResult;
            if (temp.Equals(0.0))
            {
                return;
            }
            for (int i = 0; i < roundFactor; i++)
            {
                temp *= 10;
            }
            while (temp % 10 == 0)
            {
                temp /= 10;
                roundFactor--;
            }
        }
    }


}
