﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> stocks = new List<Stock>();
         List<Index> indexes = new List<Index>();
         List<Portfolio> portfolios = new List<Portfolio>();
         
        #region STOCK METHODS
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             //Check if exists share with same name
             if(StockExists(inStockName)) throw new StockExchangeException("Stock already exists.");
             if (inNumberOfShares < 1) throw new StockExchangeException("Number of shares must be positive.");
             if (inInitialPrice < 0) throw new StockExchangeException("Number of shares must be positive.");


             Stock inStock = new Stock(inStockName.ToUpper(), inInitialPrice, inNumberOfShares, inTimeStamp);
             stocks.Add(inStock);

         }

         public void DelistStock(string inStockName)
         {
             foreach (Stock stock in stocks)
             {
                 if (stock.Name == inStockName.ToUpper())
                     stocks.Remove(stock);
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock stock in stocks)
             {
                 if (stock.Name == inStockName.ToUpper())
                     return true;
             }
             return false;

         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (inStockValue < 0) throw new StockExchangeException("Stock value must be positive.");

             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);

                 // check if entry with inTimeStamp already exists in stock.Prices
                 if (stock.CheckExistenceOfTimeStamp(inTimeStamp))
                 {
                     throw new StockExchangeException("Time stamp already exists.");
                 }
                 //else add new timestamp with new stockValue
                 else 
                 {
                     stock.Prices.Add(inTimeStamp, inStockValue);
                 }
             }
             else 
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);

                 //check if this inTimeStamp is not before initialTime;
                 if(stock.PriceExists(inTimeStamp))
                 {
                     return stock.GetPriceForTimeStamp(inTimeStamp);
                 }
                 else
                 {
                     throw new StockExchangeException("Price for this timestamp not defined.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);
                 return stock.GetInitialPrice();
             }
             else
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             {
                 if (StockExists(inStockName))
                 {
                     Stock stock = GetStockByName(inStockName);
                     return stock.GetLastPrice();
                 }
                 else
                 {
                     throw new StockExchangeException("Stock doesn't exist.");
                 }
             }
         }

         private Stock GetStockByName(string inStockName)
         {
             foreach (Stock stock in stocks)
             {
                 if (stock.Name == inStockName.ToUpper())
                 {
                     return stock;
                 }
             }

             return null;
         }
        #endregion
        #region INDEX METHODS
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName)) throw new StockExchangeException("Index already exists.");
             else
             {
                 Index index = new Index(inIndexName.ToUpper(), inIndexType);
                 indexes.Add(index);
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 if (IsStockPartOfIndex(inIndexName, inStockName))
                 {
                     throw new StockExchangeException("Stock already a part of index.");
                 }
                 else
                 {
                     Index ind = GetIndexByName(inIndexName);
                     Stock stock = GetStockByName(inStockName);
                     ind.Data.Add(stock);
                 }

             }
             else
             {
                 throw new StockExchangeException("Index or stock doesn't exists.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName))
             {
                 Index ind = GetIndexByName(inIndexName);
                 Stock stock = GetStockByName(inStockName);
                 if (IsStockPartOfIndex(ind.Name, inStockName))
                 {
                     ind.Data.Remove(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("Stock not a part of index.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Index doesn't exists.");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Index ind = GetIndexByName(inIndexName);
                 if (ind.Data.Exists((delegate(Stock s)
                            {
                                return s.Name == inStockName;
                            })))
                 {
                     return true;
                 }
                 else return false;
             }
             else
             {
                 throw new StockExchangeException("Index or stock doesn't exists.");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 Index ind = GetIndexByName(inIndexName);
                 return ind.GetValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Index doesn't exists.");
             }

         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index ind in indexes)
             {
                 if (ind.Name == inIndexName.ToUpper())
                 {
                     return true;
                 }
             }

             return false;
         }

         public int NumberOfIndices()
         {
             return indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 Index ind = GetIndexByName(inIndexName);
                 return ind.Data.Count;
             }
             else
             {
                 throw new StockExchangeException("Index doesn't exists.");
             }
         }

         private Index GetIndexByName(string inIndexName)
         {
             foreach (Index index in indexes)
             {
                 if (index.Name == inIndexName.ToUpper())
                 {
                     return index;
                 }
             }
             return null;
         }

#endregion
        #region PORTFOLIO METHODS
         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio already exists.");
             else
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 portfolios.Add(portfolio);
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     pf.Data[stock] += numberOfShares; 
                 }
                 else
                 {
                     pf.Data.Add(stock, numberOfShares);
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfolio or stock doesn't exists.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 if (numberOfShares > pf.Data[stock])
                 {
                     RemoveStockFromPortfolio(inPortfolioID, inStockName);
                 }
                 else
                 {
                     pf.Data[stock] -= numberOfShares;
                 }

             }
             else
             {
                 throw new StockExchangeException("Portfolio doesn't exists.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);
                 pf.Data.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Portfolio doesn't exists.");
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 return pf.Data.Count;
             }
             else
             {
                 throw new StockExchangeException("Portfolio doesn't exists.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio portfolio in portfolios)
             {
                 if (portfolio.Name == inPortfolioID)
                 {
                     return true;
                 }
             }

             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 if (pf.Data.ContainsKey(stock))
                     return true;
                 else return false;
             }
             else
             {
                 throw new StockExchangeException("Portfolio or stock doesn't exists.");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Portfolio pf = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     return pf.Data[stock];
                 }
                 else 
                 {
                     throw new StockExchangeException("Stock not in portfolio.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfolio or stock doesn't exists.");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }

         private Portfolio GetPortfolioByName(string inPortfolioName)
         {
             foreach (Portfolio portfolio in portfolios)
             {
                 if (portfolio.Name == inPortfolioName)
                 {
                     return portfolio;
                 }
             }
             return null;
         }

        #endregion
     }

    public class Stock
    {
        private string _name;
        private long _number;
        private Dictionary<DateTime, decimal> _stockPrices = new Dictionary<DateTime,decimal>();
        
        private DateTime _initialTime;

        public Stock(string name, Decimal price, long number, DateTime time)
        {
            _name = name;
            _number = number;
            _stockPrices.Add(time, price);
            _initialTime = time;
        }

        public string Name
        {
            get 
            {
                return _name;
            }
        }

        public long NumberOfShares
        {
            get { return _number; }
        }

        public Dictionary<DateTime, Decimal> Prices
        {
            get
            {
                return _stockPrices;
            }
        }

        public bool CheckExistenceOfTimeStamp(DateTime inTime)
        {
            foreach (KeyValuePair<DateTime, decimal> pair in _stockPrices)
            {
                if (pair.Key == inTime)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// It is assumed there will be no definition of new price for moment before initial time.
        /// It is known that the price for this timestamp exists.
        /// </summary>
        /// <param name="inTime"></param>
        /// <returns>returns price for datetime in prices which is before inTime and Timespan
        /// between two moments is shortest</returns>
        public decimal GetPriceForTimeStamp(DateTime inTime)
        {
            decimal price = 0;
            TimeSpan smallestSpan = new TimeSpan(10000, 0, 0);
            TimeSpan span;

            foreach (KeyValuePair<DateTime, decimal> pair in _stockPrices)
            {
                if (pair.Key < inTime)
                {
                    span = pair.Key - inTime;
                    if (span < smallestSpan)
                    {
                        smallestSpan = span;
                        price = pair.Value;
                    }
                }
            }

            return price;
        }

        public bool PriceExists(DateTime inTime)
        {
            foreach (KeyValuePair<DateTime, decimal> pair in _stockPrices)
            {
                if (pair.Key < inTime)
                {
                    return true;
                }
            }

            return false;
        }

        public decimal GetInitialPrice()
        {
            return _stockPrices[_initialTime];
        }

        /// <summary>
        /// Get price with "biggest" timestamp becouse it is assumed that price can be defined
        /// for future time.
        /// </summary>
        /// <returns></returns>
        public decimal GetLastPrice()
        {
            DateTime inTime = _initialTime;
            decimal price = GetInitialPrice();

            foreach (KeyValuePair<DateTime, decimal> pair in _stockPrices)
            {
                if (pair.Key > inTime)
                {
                    if (pair.Key > inTime)
                    {
                        inTime = pair.Key;
                        price = pair.Value;
                    }
                }
            }

            return price;
        }

        public DateTime GetInitialTimeStamp()
        {
            return _initialTime;
        }
    }

    public class Index
    {
        private string _name;
        private List<Stock> _data;
        private IndexTypes _type;

        public string Name
        {
            get { return _name; }
        }
        public IndexTypes Type
        {
            get { return _type; }
        }
        public List<Stock> Data
        {
            get { return _data; }
        }

        public Index(string name, IndexTypes type)
        {
            _name = name;
            _type = type;
            _data = new List<Stock>();
        }

        public decimal GetValue(DateTime inTime)
        {
            decimal ret = 0m;

            //AVERAGE ALGORITHM
            if (_type == IndexTypes.AVERAGE)
            {
                decimal sum = 0m;

                foreach (Stock stock in _data)
                {
                    sum += stock.GetPriceForTimeStamp(inTime);
                }

               ret = (decimal) (sum / _data.Count);
               ret = Math.Round(ret, 3);
               return ret;
            }
            //WEIGHTED ALGORITHM
            else
            {   
                decimal stock_factor = 0m;
                decimal total_value = 0m;
                foreach (Stock s in _data)
                {
                    total_value += (((decimal)s.NumberOfShares) * s.GetPriceForTimeStamp(inTime));   
                }

                foreach (Stock s in _data)
                {
                    stock_factor = ((decimal)s.NumberOfShares) * s.GetPriceForTimeStamp(inTime) / total_value;
                    ret += stock_factor * s.GetPriceForTimeStamp(inTime);
                }

                ret = Math.Round(ret, 3);
                return ret;
            }
        }
    }

    public class Portfolio
    {
        private string _name;
        private Dictionary<Stock, int> _data;

        public string Name
        {
            get { return _name; }
        }
        public Dictionary<Stock, int> Data
        {
            get { return _data; }
        }

        public Portfolio(string name)
        {
            _name = name;
            _data = new Dictionary<Stock, int>();
        }

        

    }
}
