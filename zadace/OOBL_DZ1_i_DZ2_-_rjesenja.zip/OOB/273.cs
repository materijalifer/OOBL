﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string state;
        private string screen;
        private string memory;
        private char operation;
        private bool dec;
        bool pressedOp;

        public Kalkulator()
        {
            screen = "0";
            memory = null;
            state = "0";
            operation = '0';
            dec = false;
            pressedOp = false;
        }

        private void ToUsableNumber()
        {
            if (screen.Equals("-E-")) return;
            double temp = double.Parse(screen);
            double temp1 = temp;
            int len;

            if (temp < 0) temp1 *= -1;
            screen = temp1.ToString();
            len = screen.Split(new Char[] { ',' })[0].Length;

            if (len > 10)
            {
                screen = "-E-";
                state = "0";
                return;
            }

            len = 10 - len;

            Math.Round(temp, len, MidpointRounding.AwayFromZero);

            screen = temp.ToString();
            String.Format("{0:0.#########}", screen);

        }

        private void Operation(char op)
        {
            double temp1, temp2;

            temp1 = double.Parse(screen);
            temp2 = double.Parse(state);

            switch (operation)
            {
                case '+':
                    temp1 = temp1 + temp2;
                    break;
                case '-':
                    temp1 = temp2 - temp1;
                    break;
                case '*':
                    temp1 = temp1 * temp2;
                    break;
                case '/':
                    if (temp1 == 0)
                    {
                        screen = "-E-";
                        state = "0";
                        return;
                    }
                    temp1 = temp2 / temp1;
                    break;
                default:
                    break;
            }
            screen = temp1.ToString();
            ToUsableNumber();
            state = screen;
            operation = op;
        }

        public void Press(char inPressedDigit)
        {
            double temp = 0;
            

            //Uneseni znak je broj
            if (Char.IsDigit(inPressedDigit) == true)
            {
                if (screen.Equals("-E-")) screen = "0";
                if (pressedOp) {
                    screen = "0";
                    pressedOp = false;
                }
                screen = screen + inPressedDigit;
            }

            #region Unarne operacije
            //Uneseni znak je slovo
            else if (Char.IsLetter(inPressedDigit) == true)
            {
                switch (inPressedDigit)
                {
                    //Promjena predznaka
                    case 'M':
                        temp = double.Parse(screen);
                        temp = temp * -1;
                        screen = temp.ToString();
                        break;
                    //Sinus
                    case 'S':
                        temp = double.Parse(screen);
                        temp = Math.Sin(temp);
                        screen = temp.ToString();
                        break;
                    //Kosinus
                    case 'K':
                        temp = double.Parse(screen);
                        temp = Math.Cos(temp);
                        screen = temp.ToString();
                        break;
                    //Tangens
                    case 'T':
                        temp = double.Parse(screen);

                        if (temp % (Math.PI / (float)2) == 0)
                        {
                            screen = "-E-";
                            memory = "0";
                            operation = '0';
                            break;
                        }

                        temp = Math.Tan(temp);
                        screen = temp.ToString();
                        break;
                    //Kvadrat
                    case 'Q':
                        temp = double.Parse(screen);
                        temp = temp * temp;
                        screen = temp.ToString();
                        break;
                    //Korijen
                    case 'R':
                        temp = double.Parse(screen);

                        if (temp < 0) screen = "-E-";
                        else
                        {
                            temp = Math.Sqrt(temp);
                            screen = temp.ToString();
                        }
                        break;
                    //Inverz
                    case 'I':
                        temp = double.Parse(screen);

                        if (temp == 0)
                        {
                            screen = "-E-";
                            break;
                        }

                        temp = (float)1 / temp;
                        screen = temp.ToString();
                        break;
                    //Pohrana u memoriju
                    case 'P':
                        if (screen.Equals("-E-") == true) break;
                        memory = screen;
                        break;
                    //Citanje iz memorije
                    case 'G':
                        screen = memory;
                        break;
                    //Brisanje ekrana
                    case 'C':
                        screen = "0";
                        return;
                    //Reset
                    case 'O':
                        screen = "0";
                        memory = null;
                        state = "0";
                        operation = '0';
                        dec = false;
                        return;
                    default:
                        return;
                }

                ToUsableNumber();
            }
            #endregion

            //Operacija
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                dec = false;
                if (pressedOp == true)
                {
                    operation = inPressedDigit;

                }
                else 
                {
                    pressedOp = true;
                    ToUsableNumber();
                    Operation(inPressedDigit);
                }              

            }
            else if (inPressedDigit == ',')
            {
                if (dec == true) return;
                if (screen.Equals("-E-")) screen = "0";
                screen = screen + ',';
                dec = true;
                return;
            }
            else if (inPressedDigit == '=')
            {
                dec = false;
                ToUsableNumber();
                Operation('\0');
                pressedOp = true;
            }

        }

        public string GetCurrentDisplayState()
        {
            ToUsableNumber();
            return screen;
        }

    }


}
