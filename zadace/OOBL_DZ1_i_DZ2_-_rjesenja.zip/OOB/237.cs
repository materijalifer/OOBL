﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator {
    public class Factory {
        public static ICalculator CreateCalculator () {
            // vratiti kalkulator
            return new Kalkulator ();
        }
    }

    public class Kalkulator : ICalculator {

        //variables to hold operands
        private decimal operand1;
        private decimal operand2;

        //Varible to hold temporary values
        private double tmpValue;

        //True if "." is used else false
        private bool hasDecimal = false;

        private bool inputStatus = true;

        //variable to hold Operater
        private string calcFunc;

        //private string display;
        private string txtInput;

        private static List<char> UNAR_OPERATORS = new List<char> ( new char[] { 'K', 'T', 'R', 'I' } );
        private static List<char> BINARY_OPERATORS = new List<char> ( new char[] { '+', '-', '*', '/' } );
        private static int DISPLAY_MAX_DIGIT = 10;

        private string memory;



        public Kalkulator () {
            this.txtInput = "";
            calcFunc = "";
        }

        public string GetCurrentDisplayState () {
            if (txtInput == "") {
                return "0";
            }
            else if (txtInput.Length > DISPLAY_MAX_DIGIT) {
                fitToScreen ();
                return txtInput;
            }
            else {
                return txtInput;
            }

        }

        public void Press ( char inPressedChar ) {
            // za sve brojeve osim nule
            if (Char.IsDigit ( inPressedChar ) && inPressedChar != '0') {

                // ako je u tijeku unos broja
                if (inputStatus) {

                    txtInput += inPressedChar;
                }
                // inače započinje unos novog proja
                else {
                    // 
                    txtInput = "";
                    txtInput += inPressedChar;
                    inputStatus = true;
                }

            }
            // ako je pritisnuta nula
            else if (inPressedChar == '0') {

                if (inputStatus) {

                    if (txtInput.Length > 0 && txtInput != "0") {
                        txtInput += inPressedChar;
                    }

                }

            }
            // ako je pritisnut decimalni zarez
            else if (inPressedChar == ',') {

                if (inputStatus) {

                    // ako do sada nije unušen decimalni zarez
                    if (!hasDecimal) {

                        // ako ima unešenih znakova, samo nadodati zarez
                        if (txtInput.Length != 0) {
                            txtInput += ',';
                        }
                        // inače ispred zareza staviti 0
                        else {
                            txtInput = "0,";
                        }
                        hasDecimal = true;
                    }
                }
            }
            // ako je pretisnut neki od binarnih operatora
            else if (BINARY_OPERATORS.Contains ( inPressedChar )) {

                // mora u spremniku biti prvi operand
                if (txtInput.Length > 0) {

                    // ako zasad nema akumuliranog rezultata
                    if (calcFunc == "") {
                        operand1 = decimal.Parse ( txtInput );
                        txtInput = "";
                    }
                    // inače kao prvi operand uzmi akumulirani rezultat
                    else {
                        calculateTotals ();
                    }
                    calcFunc = inPressedChar.ToString ();
                    hasDecimal = false;
                }

            }
            // ako je pretisnut neki od unarnih operatora
            else if (UNAR_OPERATORS.Contains ( inPressedChar )) {

                if (txtInput.Length > 0) {

                    if (calcFunc == "") {
                        operand1 = decimal.Parse ( txtInput );
                        txtInput = "";
                    }
                    else {
                        calculateTotals ();
                    }
                    calcFunc = inPressedChar.ToString ();
                    hasDecimal = false;

                }

            }
            else {
                switch (inPressedChar) {
                    case 'M':
                        if (txtInput.StartsWith("-")) {
                            txtInput.Remove ( 0, 1 );
                        }
                        else {
                            txtInput = txtInput.Insert ( 0, "-" );
                        }
                        break;

                    case '=':
                        if (txtInput.Length > 0) {
                            calculateTotals ();                            
                        }
                        break;

                    case 'O':
                        reset ();
                        break;

                    case 'P':
                        memory += txtInput;
                        txtInput = "";
                        break;

                    case 'G':
                        txtInput = memory;
                        break;
                    
                    case 'S':
                        decimal tmp = decimal.Parse ( txtInput );
                        double tmp1 = Decimal.ToDouble ( tmp );
                        double result = Math.Sin ( tmp1 );
                        txtInput = result.ToString ();
                        break;

                    case 'Q':
                        
                        txtInput = Math.Pow ( Decimal.ToDouble ( decimal.Parse ( txtInput ) ), 2 ).ToString ();
                        break;

                }
            }


        }

        private void fitToScreen () {
            // ako sadrži - i ,
            if (txtInput.StartsWith("-") && txtInput.Contains(",")) {
                int digitsBeforeDecimal = txtInput.IndexOf ( ',' ) - 1;
                string nmbToRound = txtInput.Substring ( 1 );
                //nmbToRound = nmbToRound.Replace('.', ',');
                decimal nmbToRound1 = decimal.Parse ( nmbToRound );
                //Math.Round(
                decimal roundedNmb = Math.Round ( nmbToRound1, DISPLAY_MAX_DIGIT - digitsBeforeDecimal );
                txtInput = "-" + roundedNmb.ToString ();
                
            }
            // ako ne sadrži ni - ni ,
            else if (  !txtInput.StartsWith("-") && !txtInput.Contains(",")  ) {
                txtInput = "-E-";
            }
            // ako sadrži samo ,
            else if ( !txtInput.StartsWith("-") && txtInput.Contains(",")) {
                if (txtInput.Length > DISPLAY_MAX_DIGIT + 1) {
                    txtInput = "-E-";
                }
                else {
                    int digitsBeforeDecimal = txtInput.IndexOf ( ',' );
                    decimal nmbToRound1 = Decimal.Parse ( txtInput );
                    decimal roundedNmb = Math.Round ( nmbToRound1, DISPLAY_MAX_DIGIT - digitsBeforeDecimal );
                    txtInput = roundedNmb.ToString ();
                }                
            }
            // ako sadrži samo -
            else if (txtInput.StartsWith("-") && !txtInput.Contains(",")) {
                if (txtInput.Length > DISPLAY_MAX_DIGIT + 1) {
                    txtInput = "-E-";
                }
            }
        }

        private void reset () {
            inputStatus = true;
            hasDecimal = false;
            operand1 = operand2 = 0;
            memory = "";
            txtInput = "";
        }

        private int countDigits ( string expression ) {
            int counter = 0;
            foreach (char c in expression) {
                if (Char.IsDigit ( c )) {
                    counter++;
                }
            }
            return counter;
        }

        private void calculateTotals () {
            operand2 = decimal.Parse ( txtInput );

            switch (calcFunc) {

                case "+":
                    operand1 = operand1 + operand2;
                    break;
                case "-":
                    operand1 = operand1 - operand2;
                    break;
                
                case "*":
                    operand1 = operand1 * operand2;
                    break;

                case "/":
                    operand1 = operand1 / operand2;
                    break;

            }
            txtInput = operand1.ToString ();
            txtInput = txtInput.TrimEnd ( '0' );
            inputStatus = false;
        }
    }


}
