﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

	public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }
	
    public class Kalkulator:ICalculator
    {
        private String ekran = "0";
        private String stog = "";
        private String trenutni = "0";
        private char op = ' ';
        private String trenutnoStanje = "pocetno";
        private String greskaReport = "";
        private String memorija = "";
        //kada stisnemo "=" cuva medurezultat
        private String pomocni = "";

        private char[] binarniOperatori = { '+', '-', '*', '/' };
        private char[] unarniOperatori = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };

        #region ERROR REPORT
        private void GreskaReport(char inPressedDigit)
        {
            greskaReport = UnarnaOperacija(trenutni, inPressedDigit);
            if (greskaReport != "error")
            {
                ekran = Replace(ekran, trenutni, greskaReport);
                trenutni = greskaReport;
            }
            else
            {
                trenutnoStanje = "error";
            }
        }
        #endregion

        #region Declare Error
        private void DeclareError()
        {
            trenutnoStanje = "error";
            ekran = "-E-";
            return;
        }
        #endregion

        #region PROMJENA PREDZNAKA
        private void PromjenaPredznaka(char inPressedDigit)
        {
            greskaReport = UnarnaOperacija(trenutni, inPressedDigit);
            ekran = Replace(ekran, trenutni, greskaReport);
            trenutni = greskaReport;
        }
        #endregion

        #region GET LAST NUMBER
        public String GetLastNumber(String stack)
        {
            String number = "";
            while (!(Char.IsNumber(stack[stack.Length - 1])))
            {
                stack = stack.Substring(0, stack.Length - 1);
            }
            while ((Char.IsNumber(stack[stack.Length - 1])))
            {
                number += stack[stack.Length - 1];
                stack = stack.Substring(0, stack.Length - 1);
            }
            

            if (!(Char.IsNumber(stack[stack.Length - 1])) && !(Char.IsNumber(stack[stack.Length - 2])))
            {
                number += stack[stack.Length - 1];
            }

            char[] arr = number.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        #endregion

        public void Press(char inPressedDigit)
        {
            #region RESET
            if (inPressedDigit == 'O')
            {
                ekran = "0";
                stog = "";
                trenutni = "0";
                op = ' ';
                trenutnoStanje = "pocetno";
                greskaReport = "";
                memorija = "";
                pomocni = "";
                return;
            }
            #endregion

            #region SAVE
            if (inPressedDigit == 'P')
            {
                if (trenutnoStanje != "error")
                {
                    memorija = trenutni;
                }
                return;
            }
            #endregion

            #region LOAD
            if (inPressedDigit == 'G')
            {
                if (trenutnoStanje != "error" && memorija != "")
                {
                    if (trenutnoStanje == "binarni")
                    {
                        ekran += memorija;
                        trenutni = memorija;
                        trenutnoStanje = "broj";
                    }
                    else if (trenutnoStanje == "broj")
                    {
                        ekran = Replace(ekran, trenutni, memorija);
                        trenutni = memorija;
                    }
                    else if (trenutnoStanje == "unarni")
                    {
                        ekran = Replace(ekran, trenutni, memorija);
                        trenutni = memorija;
                        trenutnoStanje = "broj";
                    }
                    else if (trenutnoStanje == "b-u")
                    {
                        trenutni = memorija;
                        trenutnoStanje = "broj";
                    }
                    
                }
                return;
            }
            #endregion

            #region CLEAR
            if (inPressedDigit == 'C')
            {
                ekran = "0";
                trenutnoStanje = "pocetno";
                return;
            }
            #endregion

            #region EQUAL
            if (inPressedDigit == '=')
            {
                if (stog != "")
                {
                    if (trenutnoStanje != "b-u")
                    {
                        stog += trenutni;
                    }
                        // ako je u binarno-unarnom stanju, 
                        //    moramo dodati zadnji broj koji se nalazi na stogu jer on nije "oneciscen"
                    else
                    {
                        stog += GetLastNumber(stog);
                    }
                    ekran = Evaluate(stog);
                    if (ekran == "error")
                    {
                        DeclareError();
                    }
                    else
                    {
                        trenutnoStanje = "pocetno";
                    }
                    pomocni = op.ToString() + trenutni;
                    trenutni = ekran;
                    
                    stog = "";
                }
                    //vec smo imali jednako, ispraznili stog, ali ostao nam je pomocni u memoriji
                else if (stog == "" && pomocni != "")
                {
                    // ## treba provjeriti sta se dogodi prilikom pritiska npr. 2 + 3 = C =
                    stog += trenutni + pomocni;
                    ekran = Evaluate(stog);
                    if (ekran == "error")
                    {
                        DeclareError();
                    }
                    else
                    {
                        trenutnoStanje = "pocetno";
                    }
                    trenutni = ekran;
                    stog = "";
                }
                    // pocetak
                else if (stog == "" && pomocni == "")
                {
                    // totalni reset
                    trenutni = Stem(trenutni);
                    ekran = trenutni;
                    return;
                }

                return;

            }
            #endregion

            #region POCETNO
            if (trenutnoStanje == "pocetno")
            {

                if (Char.IsNumber(inPressedDigit) && inPressedDigit != '0')
                {
                    trenutni = inPressedDigit.ToString();
                    trenutnoStanje = "broj";
                    ekran = trenutni;
                }
                else if (inPressedDigit == ',')
                {
                    trenutni = "0,";
                    ekran = trenutni;
                    trenutnoStanje = "broj";
                }

                    //provjera je li element binarni operator
                else if (Array.IndexOf(binarniOperatori, inPressedDigit) != -1)
                {
                    op = inPressedDigit;
                    trenutnoStanje = "binarni";
                    stog = trenutni + op.ToString();
                }


                else if (Array.IndexOf(unarniOperatori, inPressedDigit) != -1)
                {
                    //ne treba nista jer s nulom ionako nije bitno kakav je predznak
                    if (inPressedDigit != 'M')
                    {
                        trenutnoStanje = "unarni";
                        GreskaReport(inPressedDigit);
                    }
                }


            }
            #endregion

            #region BROJ
            else if (trenutnoStanje == "broj")
            {
                if (Char.IsNumber(inPressedDigit) || inPressedDigit == ',')
                {
                    // ako vec postoji zarez u broju
                    if (!(inPressedDigit == ',' && trenutni.IndexOf(',') != -1))
                    {
                        if (!TooLong(trenutni + inPressedDigit.ToString()))
                        {
                            trenutni += inPressedDigit;
                            ekran += inPressedDigit;
                        }
                    }
                }
                else if (Array.IndexOf(binarniOperatori, inPressedDigit) != -1)
                {
                    //dijeljenje s nulom
                    if (Stem(trenutni) == "0" && op == '/')
                    {
                        trenutnoStanje = "error";
                    }
                    else
                    {
                        ekran = Stem(ekran);
                        stog += trenutni + inPressedDigit;
                        op = inPressedDigit;
                        trenutnoStanje = "binarni";
                    }
                }

                else if (Array.IndexOf(unarniOperatori, inPressedDigit) != -1)
                {
                    //promjena predznaka nije kao ostali unarni operatori
                    if (inPressedDigit != 'M')
                    {
                        trenutnoStanje = "unarni";
                        GreskaReport(inPressedDigit);
                    }
                    else
                    {
                        //ne bi trebalo bacati error jer se samo mijenja predznak
                        greskaReport = UnarnaOperacija(trenutni, inPressedDigit);
                        ekran = Replace(ekran, trenutni, greskaReport);
                        trenutni = greskaReport;
                    }
                }
            }
            #endregion

            #region BINARNI
            else if (trenutnoStanje == "binarni")
            {
                if (Char.IsNumber(inPressedDigit))
                {
                    trenutni = inPressedDigit.ToString();
                    //ekran += op + trenutni;
                    ekran = trenutni;
                    trenutnoStanje = "broj";

                }
                else if (inPressedDigit == ',')
                {
                    trenutni = "0,";
                    //ekran += op + trenutni;e
                    ekran = trenutni;
                    trenutnoStanje = "broj";
                }

                else if (Array.IndexOf(binarniOperatori, inPressedDigit) != -1)
                {
                    stog = Replace(stog, op.ToString(), inPressedDigit.ToString());
                    op = inPressedDigit;
                }
                //ako se unarni operator nalazi nakon binarnog, onda na ekran ispisemo promjenu, ali ju ne uvodimo u izracun
                else if (Array.IndexOf(unarniOperatori, inPressedDigit) != -1)
                {
                    if (inPressedDigit != 'M')
                    {
                        trenutnoStanje = "b-u";
                        GreskaReport(inPressedDigit);
                    }
                    else
                    {
                        //ne bi trebalo bacati error jer se samo mijenja predznak
                        PromjenaPredznaka(inPressedDigit);   
                    }
                    
                }
            }
            #endregion

            #region UNARNI
            else if (trenutnoStanje == "unarni")
            {
                if (Char.IsNumber(inPressedDigit))
                {
                    ekran = Replace(ekran, trenutni, inPressedDigit.ToString());
                    trenutni = inPressedDigit.ToString();
                    trenutnoStanje = "broj";

                }
                else if (inPressedDigit == ',')
                {
                    //Replace(stog, trenutni, "0,"); - stog se mijenja samo kod binarnih op
                    ekran = Replace(ekran, trenutni, "0,");
                    trenutni = "0,";
                    trenutnoStanje = "broj";
                }

                else if (Array.IndexOf(binarniOperatori, inPressedDigit) != -1)
                {
                    stog += trenutni + inPressedDigit;
                    op = inPressedDigit;
                    trenutnoStanje = "binarni";
                }
                //ako se unarni operator nalazi nakon binarnog, onda na ekran ispisemo promjenu, ali ju ne uvodimo u izracun
                else if (Array.IndexOf(unarniOperatori, inPressedDigit) != -1)
                {
                    if (inPressedDigit != 'M')
                    {
                        trenutnoStanje = "unarni";
                        GreskaReport(inPressedDigit);
                    }
                    else
                    {
                        PromjenaPredznaka(inPressedDigit);
                    }

                }
            }
            #endregion

            #region BINARNO-UNARNI
            else if (trenutnoStanje == "b-u")
            {
                if (Char.IsNumber(inPressedDigit))
                {
                    trenutni = inPressedDigit.ToString();
                    //ekran += op + trenutni;
                    ekran = trenutni;
                    trenutnoStanje = "broj";

                }
                else if (inPressedDigit == ',')
                {
                    trenutni = "0,";
                    //ekran += op + trenutni;
                    ekran = trenutni;
                    trenutnoStanje = "broj";
                }

                else if (Array.IndexOf(binarniOperatori, inPressedDigit) != -1)
                {
                    stog = Replace(stog, op.ToString(), inPressedDigit.ToString());
                    op = inPressedDigit;
                    trenutnoStanje = "binarni";
                }
                //ako se unarni operator nalazi nakon binarnog, onda na ekran ispisemo promjenu, ali ju ne uvodimo u izracun
                else if (Array.IndexOf(unarniOperatori, inPressedDigit) != -1)
                {
                    // kad mijenjamo predznak u b-u stanju, onda se on za pravo neće promijeniti, 
                    // nego samo na ekranu, ergo nema if uvjeta
                    GreskaReport(inPressedDigit);
                }
            }
            #endregion

            #region ERROR
            else if (trenutnoStanje == "error")
            {
                ekran = "-E-";
            }
            #endregion

        }


        #region GetCurrentDisplayState
        public string GetCurrentDisplayState()
        {
            return ekran;
        }
        #endregion

        #region Replace
        private String Replace(String stack, String old, String input)
        {
            int Place = stack.LastIndexOf(old);
            if (Place != -1)
            {
                return stack.Remove(Place, old.Length).Insert(Place, input);
            }
            else
            {
                return "error";
            }
        }
        #endregion

        #region Stem
        private String Stem(String broj)
        {
            //vraca -1 ako nije decimalni broj
            int indexOfDecimal = broj.IndexOf(',');

            if (indexOfDecimal != -1)
            {
                int lastIndex = broj.Length - 1;

                //micemo nule
                if (lastIndex != indexOfDecimal)
                {
                    while (broj[lastIndex] != ',' && broj[lastIndex] == '0')
                    {
                        broj = broj.Substring(0, lastIndex);
                        lastIndex = broj.Length - 1;
                    }
                }

                // kratimo zarez
                if (broj[lastIndex] == ',')
                {
                    broj = broj.Substring(0, lastIndex);
                }

                return broj;

            }
            else
            {
                return broj;
            }


        }
        #endregion

        #region BinarnaOperacija
        public String BinarnaOperacija(String lijevi, String desni, char op)
        {
            Double prvi = Double.Parse(Stem(lijevi));
            Double drugi = Double.Parse(Stem(desni));
            Double rezultat = 0.0;

            //dijeljenje s nulom
            if (op == '/' && drugi == 0.0)
            {
                return "error";
            }

            switch (op)
            {
                case '+':
                    rezultat = prvi + drugi;
                    break;
                case '-':
                    rezultat = prvi - drugi;
                    break;
                case '*':
                    rezultat = prvi * drugi;
                    break;
                case '/':
                    rezultat = prvi / drugi;
                    break;
            }

            return Stem(rezultat.ToString());

        }
        #endregion

        #region UnarnaOperacija
        public String UnarnaOperacija(String operand, char op)
        {
            Double broj = Double.Parse(operand);

            if (operand == "0" && op == 'I')
            {
                ekran = "-E-";
                return "error";
            }

            else if (op == 'R' && operand[0].ToString() == "-")
            {
                ekran = "-E-";
                return "error";
            }

            else if (op == 'T' && Math.Abs(Double.Parse(operand)) > Math.PI/2)
            {
                ekran = "-E-";
                return "error";
            }

            switch (op)
            {
                //promjena predznaka
                case 'M':
                    broj = broj * -1;
                    break;

                //sinus
                case 'S':
                    broj = Math.Sin(broj);
                    break;

                //kosinus
                case 'K':
                    broj = Math.Cos(broj);
                    break;

                //tangens
                case 'T':
                    broj = Math.Tan(broj);
                    break;

                //kvadrat
                case 'Q':
                    broj = broj * broj;
                    break;

                //korijen
                case 'R':
                    broj = Math.Sqrt(broj);
                    break;

                //inverz
                case 'I':
                    broj = Math.Pow(broj, -1.0);
                    break;

            }

            return Zaokruzi(Stem(broj.ToString()));

        }
        #endregion

        #region Evaluate
        public String Evaluate(String broj)
        {
            String izracunati = "";
            String trenutni = "";
            String op = "";
            // stanje je binarno je na pocetku moze biti i operator
            String stanje = "binarno";

            foreach (char element in broj)
            {
                if (stanje == "binarno")
                {
                    trenutni = element.ToString();
                    stanje = "broj";
                }

                else
                {
                    //u stanju smo broja i dolazi operator
                    if (Array.IndexOf(binarniOperatori, element) != -1)
                    {
                        if (izracunati != "")
                        {

                            izracunati = BinarnaOperacija(izracunati, trenutni, Char.Parse(op));
                        }
                        else
                        {
                            izracunati = trenutni;
                        }

                        op = element.ToString();
                        stanje = "binarno";
                    }
                    // u stanju smo broja i dolazi novi broj
                    else
                    {
                        trenutni += element;
                    }
                }
            }

            //ako je samo broj na stogu
            if (izracunati == "")
            {
                return Zaokruzi(Stem(trenutni));
            }
            else
            {
                izracunati = BinarnaOperacija(izracunati, trenutni, Char.Parse(op));
                return Zaokruzi(izracunati);
            }

        }
        #endregion

        #region TooLong
        private bool TooLong(String broj)
        {
            int duljina;
            if (broj[0] == '-')
            {
                duljina = 12;
            }
            else
            {
                duljina = 11;
            }

            if (IsDecimal(broj))
            {
                if (broj.Length <= duljina)
                {
                    return false;
                }
                return true;
            }
            else
            {
                if (broj.Length <= duljina - 1)
                {
                    return false;
                }
                return true;
            }
        }
        #endregion

        #region PrebrojiCjelobrojniDio
        private int PrebrojiCjelobrojniDio(String broj)
        {
            return broj[0] == '-' ? broj.IndexOf(',') - 1 : broj.IndexOf(',');
        }
        #endregion

        #region Zaokruzi
        private String Zaokruzi(String broj)
        {
            if (TooLong(broj))
            {
                //eksponent
                if (broj.IndexOf('E') != -1)
                {
                    return "error";
                }

                if (IsDecimal(broj))
                {
                    //zaokruzi broj
                    return (Math.Round((Double.Parse(broj)), 10 - PrebrojiCjelobrojniDio(broj))).ToString();
                }
                else
                {
                    return "error";
                }
            }

            else
            {
                return broj;
            }
        }
        #endregion

        #region IsDecimal
        private bool IsDecimal(String broj)
        {
            int indexOfDecimal = broj.IndexOf(',');

            if (indexOfDecimal != -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

    }
}
