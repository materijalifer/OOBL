﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    /// <summary>
    /// Implementacija kalkulatora. U ovoj klasi se implementira State Pattern.
    /// Kalkulator može biti u 3 stanja: inicijalnom, stanju znamenke i 
    /// stanju binarnog operatora. Svako stanje implementira sučelje ICalculatorState.
    /// </summary>
    public class SimpleCalculator : ICalculator
    {
        public const int MAXDIGITS = 10;
        char[] binaryOperators = new char[] { '+', '-', '*', '/' };
        char[] memoryOperators = new char[] { 'P', 'G', 'C' };

        public string _display;
        private string _memory;

        private ICalculatorState initState;
        private ICalculatorState digitState;
        private ICalculatorState binaryOperatorState;

        private ICalculatorState currentState { get; set; }

        public SimpleCalculator()
        {
            _display = "0";

            initState = new InitialState(this);
            digitState = new DigitState(this);
            binaryOperatorState = new BinaryOperatorState(this);

            currentState = initState;
        }

        #region ICalculator Members

        /// <summary>
        /// Metoda u kojoj se odvija obrada tipke. Svako stanje drugačije obrađuje
        /// neku tipku. Trenutno stanje ekrana i tipku predajemo trenutnom stanju tj. sučelju
        /// koje nam vraća rezultat i postavlja display.
        /// </summary>
        /// <param name="inPressedDigit">Oznaka tipke kalkulatora</param>
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',')
            {
                _display = currentState.onPressedDigit(_display, inPressedDigit);
            }
            else if (binaryOperators.Contains(inPressedDigit))
            {
                _display = currentState.onPressedBinaryOperator(_display, inPressedDigit);
            }
            else if (memoryOperators.Contains(inPressedDigit))
            {
                _display = currentState.onPressedMemoryOperator(_display, inPressedDigit);
            }
            else if (inPressedDigit == '=')
            {
                _display = currentState.onPressedEqual(_display);
            }
            else
                _display = currentState.onPresedUnaryOperator(_display, inPressedDigit);
        }

        /// <summary>
        /// Vraća trenutno stanje ekrana
        /// </summary>
        /// <returns> Trenutno stanje ekrana kao string</returns>
        public string GetCurrentDisplayState()
        {
            return this.ToString();
        }

        #endregion

        public override string ToString()
        {
            return _display;
        }

        public static int countDigits(string dis)
        {
            int count = 0;
            foreach (char c in dis)
            {
                if (Char.IsDigit(c))
                    count++;
            }

            return count;
        }

        public static string trimExcessDigits(string result)
        {
            int index = result.ToString().IndexOf(',');

            if (index != -1)
            {
                int numberOfIntDigits = result.ToString().Substring(0, index).Length;
                return
                    Math.Round(double.Parse(result), SimpleCalculator.MAXDIGITS - numberOfIntDigits).ToString();
            }
            else
                return result.ToString();
        }

        #region State Setters

        public void setInitialState()
        {
            this.currentState = initState;
        }

        public void setDigitState(bool isDecimal)
        {
            this.currentState = digitState;
            ((DigitState)digitState).IsDecimal = isDecimal;
        }

        public void setBinaryOperatorState(char op, string operand1)
        {
            this.currentState = binaryOperatorState;
            ((BinaryOperatorState)binaryOperatorState)._binOperator = op;
            ((BinaryOperatorState)binaryOperatorState).Operand1 = operand1;
        }


        #endregion

        #region Upravitelji memorijom
        public void putInMemory(string s)
        {
            this._memory = s;
        }

        public void clearMemory()
        {
            this._memory = "0";
        }

        public string getFromMemory()
        {
            return _memory;
        }
        #endregion
    }

    /// <summary>
    /// Sučelje stanja kalkulatora. 
    /// </summary>
    interface ICalculatorState
    {
        string onPressedDigit(string display, char digit);
        string onPressedBinaryOperator(string display, char binOperator);
        string onPresedUnaryOperator(string display, char unaryOperator);
        string onPressedMemoryOperator(string display, char memOperator);
        string onPressedEqual(string display);
    }

    /// <summary>
    /// Ovo je inicijalno stanje u kojem se kalkulator nalazi odmah po pokretanju.
    /// Prikaz na ekranu je 0.
    /// </summary>
    public class InitialState : ICalculatorState
    {
        private SimpleCalculator _sc;

        public InitialState(SimpleCalculator sc)
        {
            this._sc = sc;
        }

        #region ICalculatorState Members

        public string onPressedDigit(string display, char digit)
        {
            if (digit == '0')
                return display;
            else if (digit == ',')
            {
                _sc.setDigitState(true);
                return "0";
            }
            else
            {
                _sc.setDigitState(false);
                return digit.ToString();
            }
        }

        public string onPressedBinaryOperator(string display, char binOperator)
        {
            _sc.setBinaryOperatorState(binOperator, display);
            return "0";
        }

        public string onPresedUnaryOperator(string display, char unaryOperator)
        {
            if (unaryOperator == 'M')
                return display;
            else if (unaryOperator == 'K')
                return "1";
            else if (unaryOperator == 'I')
                return "-E-";
            else
                return "0";
        }

        public string onPressedMemoryOperator(string display, char memOperator)
        {
            if (memOperator == 'P')
            {
                _sc.putInMemory("0");
                return display;
            }
            else if (memOperator == 'G')
            {
                return _sc.getFromMemory();
            }
            else if (memOperator == 'C')
            {
                return "0";
            }

            return "0";
        }

        public string onPressedEqual(string display)
        {
            return "0";
        }

        #endregion
    }

    /// <summary>
    /// Ovo je stanje znamenke. U ovom stanju se unosi znamenka nad kojom se mogu izvršavati
    /// unarni operatori.
    /// </summary>
    public class DigitState : ICalculatorState
    {
        private SimpleCalculator _sc;

        public bool IsDecimal { get; set; }

        public DigitState(SimpleCalculator sc)
        {
            this._sc = sc;
        }

        #region ICalculatorState Members

        public string onPressedDigit(string display, char digit)
        {
            if (SimpleCalculator.countDigits(display) < SimpleCalculator.MAXDIGITS)
            {
                if (digit == ',')
                    IsDecimal = true;

                if (digit == ',' && display.Contains(','))
                    return display;

                if (IsDecimal && display == "0")
                    return display + "," + digit;
                else if(display == "0" && Char.IsDigit(digit))
                    return digit.ToString();
                else
                    return display + digit;
            }
            else 
                return display;
        }

        public string onPressedBinaryOperator(string display, char binOperator)
        {
            _sc.setBinaryOperatorState(binOperator, display);
            return 
                this.cleanDecimalZeros(display);
        }

        public string onPresedUnaryOperator(string display, char unaryOperator)
        {
            string retString = string.Empty;

            if (unaryOperator == 'M')
            {
                if (IsDecimal)
                    retString = (-double.Parse(display)).ToString();
                else
                    retString = (-int.Parse(display)).ToString();
            }
            else if (unaryOperator == 'S')
            {
                retString = Math.Round(Math.Sin(double.Parse(display)), 9).ToString();
            }
            else if (unaryOperator == 'K')
            {
                retString = Math.Round(Math.Cos(double.Parse(display)), 9).ToString();
            }
            else if (unaryOperator == 'T')
            {
                retString = Math.Round(Math.Tan(double.Parse(display)), 9).ToString();
            }
            else if (unaryOperator == 'Q')
            {
                string s = this.cleanDecimalZeros(display);
                int v = 0;
                bool isInt = int.TryParse(s, out v);

                if (isInt)
                    retString = (v * v).ToString();
                else
                {
                    double vd = double.Parse(s);
                    retString = SimpleCalculator.trimExcessDigits((vd * vd).ToString());
                }
            }
            else if (unaryOperator == 'R')
            {
                if (display[0] == '-')
                    return "-E-";
                retString = 
                    SimpleCalculator.trimExcessDigits((Math.Sqrt(double.Parse(display)).ToString()));
            }
            else if (unaryOperator == 'I')
            {
                string s = this.cleanDecimalZeros(display);
                if (s == "0")
                    retString = "-E-";
                else retString =
                    (1 / double.Parse(s)).ToString();

                IsDecimal = this.isStringDecimal(display);
            }

            return retString;
        }

        public string onPressedMemoryOperator(string display, char memOperator)
        {
            if (memOperator == 'P')
            {
                _sc.putInMemory(display);
                return display;
            }
            else if (memOperator == 'G')
            {
                return _sc.getFromMemory();
            }
            else if (memOperator == 'C')
            {
                this.IsDecimal = false;
                return "0";
            }

            return display;
        }

        public string onPressedEqual(string display)
        {
            while (display[display.Length - 1] == '0')
            {
                display = display.Substring(0, display.Length - 1);
            }

            if (display[display.Length - 1] == ',')
                display = display.Substring(0, display.Length - 1);

            return display;
        }

        #endregion

        private string cleanDecimalZeros(string display)
        {
            if (display.Contains(','))
            {
                int idx = display.IndexOf(',');

                bool containsOnly0s = true;
                for (int i = idx + 1; i < display.Length; i++)
                {
                    if (display[i] != '0')
                        containsOnly0s = false;
                }

                if (containsOnly0s)
                    return display.Substring(0, idx);
            }

            return display;
        }

        

        private bool isStringDecimal(string res)
        {
            int x = 0;
            return !int.TryParse(res, out x);
        }
    }

    /// <summary>
    /// Stanje binarnog operatora. U ovom stanju se kalkulator nalazi kad je
    /// pritisnut binarni operator.
    /// </summary>
    public class BinaryOperatorState : ICalculatorState
    {
        private SimpleCalculator _sc;

        private bool justEnteredInState;
        private bool isDecimalOperand2 = false;

        private string operand1;
        public string Operand1
        {
            get
            {
                return this.operand1;
            }
            set
            {
                this.operand1 = value;
                this.justEnteredInState = true;
            }
        }

        public char _binOperator { get; set; }

        public BinaryOperatorState(SimpleCalculator sc)
        {
            this._sc = sc;
        }

        #region ICalculatorState Members

        public string onPressedDigit(string display, char digit)
        {
            if (this.justEnteredInState)
            {
                this.justEnteredInState = false;
                if (Char.IsDigit(digit))
                    return digit.ToString();
                else if (digit == ',')
                {
                    this.isDecimalOperand2 = true;
                    return "0";
                }
            }
            else
            {
                if (digit == '0')
                    return "0";

                if (this.isDecimalOperand2 && digit == ',')
                    return display;
                else if (!this.isDecimalOperand2 && digit == ',')
                {
                    this.isDecimalOperand2 = true;
                    return display;
                }
                else if (this.isDecimalOperand2 && digit != ',' && !display.Contains(','))
                    return display + "," + digit;
                else
                    return display + digit;
            }

            return display + digit;
        }

        public string onPressedBinaryOperator(string display, char binOperator)
        {
            if (this.justEnteredInState)
            {
                this._binOperator = binOperator;
                return display;
            }
            else{
                string s = calculate(operand1, display, this._binOperator);
                int x = 0;

                if (this._binOperator == binOperator)
                    _sc.setDigitState(!int.TryParse(s, out x));
                else
                    _sc.setBinaryOperatorState(binOperator, s);
                return s;
            }
            
        }

        public string onPresedUnaryOperator(string display, char unaryOperator)
        {
            string retString = string.Empty;

            if (unaryOperator == 'M')
                retString = display = '-' + display;
            else if (unaryOperator == 'S')
            {
                retString = Math.Round(Math.Sin(double.Parse(display)), 9).ToString();
                this.isDecimalOperand2 = true;
            }
            else if (unaryOperator == 'K')
            {
                retString = Math.Round(Math.Cos(double.Parse(display)), 9).ToString();
                this.isDecimalOperand2 = true;
            }
            else if (unaryOperator == 'T')
            {
                retString = Math.Round(Math.Tan(double.Parse(display)), 9).ToString();
                this.isDecimalOperand2 = true;
            }
            else if (unaryOperator == 'Q')
            {
                string s = this.cleanDecimalZeros(display);
                int v = 0;
                bool isInt = int.TryParse(s, out v);
                if (isInt)
                {
                    retString = (v * v).ToString();
                }
                else
                {
                    this.isDecimalOperand2 = true;
                    double vd = double.Parse(s);
                    retString = (vd * vd).ToString();
                }

            }
            else if (unaryOperator == 'R')
            {
                this.isDecimalOperand2 = true;
                retString = Math.Sqrt(double.Parse(display)).ToString();
            }
            else if (unaryOperator == 'I')
            {
                string s = this.cleanDecimalZeros(display);
                if (s == "0")
                    retString = "-E-";
                else
                {
                    this.isDecimalOperand2 = true;
                    retString =
                        (1 / double.Parse(s)).ToString();
                }
            }
            else if (unaryOperator == 'O')
            {
                _sc.setInitialState();
                return "0";
            }

            int numOfDigits = SimpleCalculator.MAXDIGITS;

            if (retString.Contains('-'))
                numOfDigits++;
            if (retString.Contains(','))
                numOfDigits++;

            return retString;
        }

        public string onPressedMemoryOperator(string display, char memOperator)
        {
            if (memOperator == 'P')
            {
                string s = calculate(operand1, display, this._binOperator);
                _sc.putInMemory(s);
                return s;
            }
            else if (memOperator == 'G')
            {
                string operand2 = _sc.getFromMemory();
                return operand2;
            }
            else if (memOperator == 'C')
            {
                return "0";
            }

            return display;
        }

        public string onPressedEqual(string display)
        {
            string result = calculate(operand1, display, this._binOperator);

            result = SimpleCalculator.trimExcessDigits(result);
            int x=0;
            _sc.setDigitState(!int.TryParse(result, out x));

            return result;
        }

        private string calculate(string op1, string op2, char binOp)
        {
            int v1i = 0, v2i = 0;
            double v1f = 0, v2f = 0;

            bool isFirstInt = false;

            isFirstInt = int.TryParse(op1, out v1i);
            if (!isFirstInt)
                v1f = double.Parse(op1);

            if (isDecimalOperand2)
                v2f = double.Parse(op2);
            else
                v2i = int.Parse(op2);

            
            if (binOp == '+')
            {
                if (isFirstInt && !isDecimalOperand2)
                {
                    try
                    {
                        int x = checked(v1i + v2i);
                    }
                    catch (OverflowException)
                    {
                        return "-E-";
                    }
                }
                return
                    ((isFirstInt ? v1i : v1f) + (isDecimalOperand2 ? v2f : v2i)).ToString();

            }
            else if (binOp == '-')
            {
                if (isFirstInt && !isDecimalOperand2)
                {
                    try
                    {
                        int x = checked(v1i - v2i);
                    }
                    catch (OverflowException)
                    {
                        return "-E-";
                    }
                }
                return
                    ((isFirstInt ? v1i : v1f) - (isDecimalOperand2 ? v2f : v2i)).ToString();
            }
            else if (binOp == '*')
            {
                if (isFirstInt && !isDecimalOperand2)
                {
                    try
                    {
                        int x = checked(v1i*v2i);
                    }
                    catch (OverflowException)
                    {
                        return "-E-";
                    }
                }
                return
                    ((isFirstInt ? v1i : v1f) * (isDecimalOperand2 ? v2f : v2i)).ToString();
            }
            else if (binOp == '/')
            {
                if (isFirstInt && !isDecimalOperand2)
                {
                    try
                    {
                        int x = v1i / v2i;
                    }
                    catch (Exception)
                    {
                        return "-E-";
                    }
                }
                return
                    ((isFirstInt ? v1i : v1f) / (isDecimalOperand2 ? v2f : v2i)).ToString();
            }
            
            return "-E-";
        }

        private string cleanDecimalZeros(string display)
        {
            if (display.Contains(','))
            {
                int idx = display.IndexOf(',');

                bool containsOnly0s = true;
                for (int i = idx + 1; i < display.Length; i++)
                {
                    if (display[i] != '0')
                        containsOnly0s = false;
                }

                if (containsOnly0s)
                    return display.Substring(0, idx);
            }

            return display;
        }

        
        #endregion
    }

    /// <summary>
    /// Tvornica implementacije kalkulatora
    /// </summary>
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new SimpleCalculator();
        }
    }
}
