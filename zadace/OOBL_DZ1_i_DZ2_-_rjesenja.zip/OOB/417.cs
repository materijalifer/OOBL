﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Factory
	{
		public static ICalculator CreateCalculator ()
		{
			// vratiti kalkulator
			return new Kalkulator();
		}
	}

	public class Kalkulator: ICalculator
	{
		string currentDisplay = "0";
		string innerDisplay = "0";
		string memoryState;
		double firstBinary = double.NaN;
		double secondBinary = double.NaN;
		double unary = double.NaN;
		char currentOperator = ' ';
		bool isSecond = false;

		public bool isMemoryOperator (char input)
		{
			if ( input == 'P' || input == 'G' )
				return true;
			return false;
		}

		public bool isCalculatorOperator (char input)
		{
			if ( input == 'O' || input == 'C' )
				return true;
			return false;
		}

		public bool isEqualOperator (char input)
		{
			if ( input == '=' )
				return true;
			return false;
		}

		public bool isDecimalOperator (char input)
		{
			if ( input == ',' )
				return true;
			return false;
		}

		public bool isBinaryOperator (char input)
		{
			if ( input == '+' || input == '-' || input == '*' || input == '/' )
				return true;
			return false;
		}

		public bool isUnaryOperator (char input)
		{
			if ( input == 'M' || input == 'S' || input == 'K' || input == 'T' || input == 'Q' || input == 'R' || input == 'I' )
				return true;
			return false;
		}

		public double calculateBinary (char input)
		{
			if ( input == '+' )
				return firstBinary + secondBinary;
			if ( input == '-' )
				return firstBinary - secondBinary;
			if ( input == '*' )
				return firstBinary * secondBinary;
			if ( input == '/' )
				return firstBinary / secondBinary;
			else
				return double.NaN;
		}

		public double calculateUnary (char input)
		{
			if ( input == 'M' )
				return unary * (-1);
			if ( input == 'S' )
				return Math.Round(Math.Sin(unary), 9);
			if ( input == 'K' )
				return Math.Round(Math.Cos(unary), 9);
			if ( input == 'T' )
				return Math.Round(Math.Tan(unary), 9);
			if ( input == 'Q' )
				return Math.Round(unary * unary, 9);
			if ( input == 'R' )
				return Math.Round(Math.Sqrt(unary), 9);
			if ( input == 'I' )
				return Math.Round(1 / unary, 9);
			else
				return double.NaN;
		}

		public bool excedeedNumberOfDigits ()
		{
			return currentDisplay.Count(num => char.IsNumber(num)) == 10;
		}

		public bool isErrorDisplayed ()
		{
			return currentDisplay == "-E-";
		}

		public void formatDisplay ()
		{
			currentDisplay = double.Parse(currentDisplay).ToString();
		}

		public void Press (char inPressedDigit)
		{
			if ( char.IsNumber(inPressedDigit) )
			{
				if ( !excedeedNumberOfDigits() ||currentOperator!=' ')
				{
					if ( currentDisplay == "0" )
					{
						currentDisplay = inPressedDigit.ToString();
						innerDisplay = currentDisplay;
					}
					else if ( currentOperator != ' ' && !double.IsNaN(firstBinary) && double.IsNaN(secondBinary) && !isSecond )
					{
						currentDisplay = inPressedDigit.ToString();
						innerDisplay += inPressedDigit;
						isSecond = true;
					}
					else
					{
						currentDisplay += inPressedDigit;
						innerDisplay += inPressedDigit;
					}
				}
				else
				{
					return;
				}
			}
			if ( isMemoryOperator(inPressedDigit) )
			{
				if ( inPressedDigit == 'P' )
				{
					memoryState = currentDisplay;
				}
				if ( inPressedDigit == 'G' )
				{
					currentDisplay = memoryState;
				}
			}
			if ( isCalculatorOperator(inPressedDigit) )
			{
				if ( inPressedDigit == 'C' )
				{
					currentDisplay = "0";
				}
				if ( inPressedDigit == 'O' )
				{
					currentDisplay = "0";
					innerDisplay = "0";
					memoryState = "";
					firstBinary = double.NaN;
					secondBinary = double.NaN;
					unary = double.NaN;
					currentOperator = ' ';
				}
			}
			if ( isDecimalOperator(inPressedDigit) )
			{
				if ( char.IsNumber(innerDisplay.Last()) )
				{
					currentDisplay += inPressedDigit;
					innerDisplay += inPressedDigit;
				}
				else if ( innerDisplay.Last() == ',' )
				{
					return;
				}
				else if ( isBinaryOperator(innerDisplay.Last()) )
				{
					currentDisplay = "0,";
					innerDisplay += "0,";
				}
			}
			if ( isBinaryOperator(inPressedDigit) )
			{
				if ( isBinaryOperator(currentOperator) && !char.IsNumber (innerDisplay.Last()))
				{
					innerDisplay.Remove(innerDisplay.Length - 1);
					innerDisplay += inPressedDigit;
					currentOperator = inPressedDigit;
					return;
				}
				else if ( isBinaryOperator(currentOperator) )
				{
					secondBinary = double.Parse(currentDisplay);
					if ( secondBinary == 0 && currentOperator == '/' )
					{
						currentDisplay = "-E-";
						return;
					}
					if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
					{
						currentDisplay = "-E-";
						return;
					}
					currentDisplay = calculateBinary(currentOperator).ToString();
					innerDisplay += inPressedDigit;
					currentOperator = inPressedDigit;
					firstBinary = double.NaN;
					secondBinary = double.NaN;
					return;
				}
				else
				{
					innerDisplay += inPressedDigit;
					currentOperator = inPressedDigit;
				}
				if ( double.IsNaN(firstBinary) )
				{
					if ( currentDisplay.Contains(',') )
					{
						firstBinary = double.Parse(currentDisplay + "0");
						isSecond = false;
						return;
					}
					firstBinary = double.Parse(currentDisplay);
					isSecond = false;
					return;
				}
				if ( !double.IsNaN(firstBinary) && !double.IsNaN(secondBinary) && isBinaryOperator(currentOperator) )
				{
					if ( secondBinary == 0 && currentOperator == '/' )
					{
						currentDisplay = "-E-";
						return;
					}
					if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
					{
						currentDisplay = "-E-";
						return;
					}
					currentDisplay = calculateBinary(currentOperator).ToString();
					currentDisplay += inPressedDigit;
					innerDisplay = currentDisplay;
					currentOperator = inPressedDigit;
					firstBinary = double.NaN;
					secondBinary = double.NaN;
				}
				if ( !double.IsNaN(firstBinary) && double.IsNaN(secondBinary) && isBinaryOperator(currentOperator) )
				{
					secondBinary = double.Parse(currentDisplay);
					if ( secondBinary == 0 && currentOperator == '/' )
					{
						currentDisplay = "-E-";
						return;
					}
					if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
					{
						currentDisplay = "-E-";
						return;
					}
					currentDisplay = calculateBinary(currentOperator).ToString();
					currentDisplay += inPressedDigit;
					innerDisplay = currentDisplay;
					currentOperator = inPressedDigit;
					firstBinary = double.NaN;
					secondBinary = double.NaN;
				}
			}
			if ( isUnaryOperator(inPressedDigit) )
			{
				if ( double.IsNaN(unary) )
				{
					unary = double.Parse(currentDisplay);
					if ( currentDisplay == "0" && inPressedDigit == 'I' )
					{
						currentDisplay = "-E-";
						return;
					}
					else if ( Math.Abs(unary).Equals(Math.PI / 2) && inPressedDigit == 'T' )
					{
						currentDisplay = "-E-";
						return;
					}
					else if ( calculateUnary(inPressedDigit).ToString().Count(c => char.IsNumber(c)) > 10 )
					{
						currentDisplay = "-E-";
						return;
					}
					else if ( unary < 0 && inPressedDigit == 'R' )
					{
						currentDisplay = "-E-";
						return;
					}
					else
					{
						currentDisplay = calculateUnary(inPressedDigit).ToString();
						unary = double.NaN;
					}
				}
				else
				{
					if ( unary == 0 && inPressedDigit == 'I' )
					{
						currentDisplay = "-E-";
					}
					else if ( Math.Abs(unary).Equals(Math.PI / 2) && inPressedDigit == 'T' )
					{
						currentDisplay = "-E-";
						return;
					}
					else if ( calculateUnary(inPressedDigit).ToString().Count(c => char.IsNumber(c)) > 10 )
					{
						currentDisplay = "-E-";
						return;
					}
					else if ( unary < 0 && inPressedDigit == 'R' )
					{
						currentDisplay = "-E-";
						return;
					}
					else
					{
						currentDisplay = calculateUnary(inPressedDigit).ToString();
						unary = double.NaN;
					}
				}
			}
			if ( isEqualOperator(inPressedDigit) )
			{
				if ( isBinaryOperator(currentOperator) )
				{
					if ( !double.IsNaN(firstBinary) && !double.IsNaN(secondBinary) )
					{
						if ( secondBinary == 0 && currentOperator == '/' )
						{
							currentDisplay = "-E-";
							return;
						}
						if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
						{
							currentDisplay = "-E-";
							return;
						}
						currentDisplay = calculateBinary(currentOperator).ToString();
						innerDisplay = currentDisplay;
						firstBinary = double.NaN;
						secondBinary = double.NaN;
						currentOperator = ' ';
					}
					if ( !double.IsNaN(firstBinary) && double.IsNaN(secondBinary) && innerDisplay.Last()==currentOperator )
					{
						secondBinary = firstBinary;
						if ( secondBinary == 0 && currentOperator == '/' )
						{
							currentDisplay = "-E-";
							return;
						}
						if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
						{
							currentDisplay = "-E-";
							return;
						}
						currentDisplay = calculateBinary(currentOperator).ToString();
						innerDisplay = currentDisplay;
						firstBinary = double.NaN;
						secondBinary = double.NaN;
						currentOperator = ' ';
					}
					if ( !double.IsNaN(firstBinary) && double.IsNaN(secondBinary) && char.IsNumber(innerDisplay.Last()) )
					{
						secondBinary = double.Parse(currentDisplay);
						if ( secondBinary == 0 && currentOperator == '/' )
						{
							currentDisplay = "-E-";
							return;
						}
						if ( calculateBinary(currentOperator).ToString().Count(c => char.IsNumber(c)) > 10 )
						{
							currentDisplay = "-E-";
							return;
						}
						currentDisplay = calculateBinary(currentOperator).ToString();
						innerDisplay = currentDisplay;
						firstBinary = double.NaN;
						secondBinary = double.NaN;
						currentOperator = ' ';
					}
				}
			}
		}



		public string GetCurrentDisplayState ()
		{
			if(currentDisplay!="-E-")
				formatDisplay();
			return currentDisplay;
		}
	}


}
