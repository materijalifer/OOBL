﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
     {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
     }

     public class Stock
     {
         public string Name;
         public long Count;
         private decimal price;
         public SortedDictionary<DateTime, Decimal> PriceHistory = new SortedDictionary<DateTime, decimal>();

         public Stock(string name, long count, Decimal price)
         {
             Name = name;
             if (count <= 0)
             {
                 throw new StockExchangeException("Count must be greater than 0");
             }
             Count = count;
             if (price <= 0)
             {
                 throw new StockExchangeException("Price must be greater than 0");
             }
             this.price = price;
         }

         public void AddHistoryPrice(DateTime date, decimal price)
         {
             if (!PriceHistory.ContainsKey(date))
             {
                 PriceHistory.Add(date, price);
             }
             else
             {
                 throw new StockExchangeException("Price for that date already exists");
             }
         }

         public decimal GetHistoryPrice(DateTime date)
         {
             return PriceHistory.Last(x => x.Key <= date).Value;
         }
     }

    public class Portfolio
    {
        public string ID;
        public Dictionary<Stock, int> Stocks = new Dictionary<Stock, int>();

        public Portfolio(string inPortfolioID)
        {
            ID = inPortfolioID;
        }

    }

    public class Index
    {
        public string Name;
        public IndexTypes Type;
        public List<Stock> Stocks = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            Name = inIndexName.ToUpper();
            Type = inIndexType;
        }

        public decimal GetValue(DateTime date)
        {
            decimal index = Type == IndexTypes.AVERAGE ? GetAverageValue(date) : GetWeightedValue(date);
            return Math.Round(index, 3);
        }

        private decimal GetWeightedValue(DateTime date)
        {
            decimal weightedIndex = 0;
            decimal totalValue = Stocks.Sum(x => x.GetHistoryPrice(date) * x.Count);
            foreach (var stock in Stocks)
            {
                decimal stockPrice = stock.GetHistoryPrice(date);
                decimal weightFactor = (stockPrice*stock.Count)/totalValue;
                weightedIndex += (weightFactor*stockPrice);
            }
            return weightedIndex;
        }

        private decimal GetAverageValue(DateTime date)
        {
            return Stocks.Average(x => x.GetHistoryPrice(date));
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stocks = new List<Stock>();
         private List<Portfolio> portfolios = new List<Portfolio>();
         private List<Index> indices = new List<Index>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 Stock newStock = new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice);
                 newStock.PriceHistory.Add(inTimeStamp, inInitialPrice);
                 stocks.Add(newStock);
             }
             else
             {
                 throw new StockExchangeException("Stock already exists");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 stocks.RemoveAll(x => x.Name == inStockName);
             }
             else
             {
                 throw new StockExchangeException("Stock with that name is not listed.");
             }
         }

         public bool StockExists(string inStockName)
         {
             return stocks.Exists(x => x.Name == inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = GetStock(inStockName);
             stock.AddHistoryPrice(inIimeStamp, inStockValue);
         }

         public Stock GetStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 return stocks.Find(x => x.Name == inStockName.ToUpper());
             }
             else
             {
                 throw new StockExchangeException("Stock not found");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = GetStock(inStockName);
             return stock.GetHistoryPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = GetStock(inStockName);
             return stock.PriceHistory.Values.First();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = GetStock(inStockName);
             return stock.PriceHistory.Values.Last();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!IndexExists(inIndexName))
             {
                 Index index = new Index(inIndexName, inIndexType);
                 indices.Add(index);
             }
             else
             {
                 throw new StockExchangeException("Index already exists");
             }
             
         }

         public Index GetIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 return indices.Find(x => x.Name == inIndexName.ToUpper());
             }
             else
             {
                 throw new StockExchangeException("That index doesn't exist");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = GetStock(inStockName);
             Index index = GetIndex(inIndexName);
             if (!IsStockPartOfIndex(inIndexName, inStockName))
             {
                 index.Stocks.Add(stock);
             }
             else
             {
                 throw new StockExchangeException("That stock already exists in the index");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stock = GetStock(inStockName);
             index.Stocks.Remove(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndex(inIndexName).Stocks.Any(x => x.Name == inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return GetIndex(inIndexName).GetValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.Exists(x => x.Name == inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return GetIndex(inIndexName).Stocks.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 portfolios.Add(portfolio);
             }
             else
             {
                 throw new StockExchangeException("Index already exists");
             }
         }

         public Portfolio GetPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return portfolios.Find(x => x.ID == inPortfolioID);
             }
             else
             {
                 throw new StockExchangeException("That portfolio doesn't exist");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock stock = GetStock(inStockName);
             int numOfStocksBought = portfolios.Sum(port => port.Stocks.Where(x => x.Key.Name == inStockName).Sum(x => x.Value));
             if (numOfStocksBought + numberOfShares > stock.Count)
             {
                 throw new StockExchangeException("You can't buy more shares than there are on the market");
             }
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 portfolio.Stocks.Add(stock, numberOfShares);
             }
             else
             {
                 portfolio.Stocks[stock] += numberOfShares;
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Stock stock = GetStock(inStockName);
                 int numOfStocks = portfolio.Stocks[stock];
                 if (numberOfShares < numOfStocks)
                 {
                     portfolio.Stocks[stock] -= numberOfShares;
                 }
                 else
                 {
                     portfolio.Stocks.Remove(stock);
                 }
             }
             else
             {
                 throw new StockExchangeException("Stock is not a part of portfolio");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Stock stock = GetStock(inStockName);
                 portfolio.Stocks.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock is not a part of portfolio");
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return GetPortfolio(inPortfolioID).Stocks.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.Exists(x => x.ID == inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolio(inPortfolioID).Stocks.Keys.Any(x => x.Name == inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Portfolio portfolio = GetPortfolio(inPortfolioID);
                 Stock stock = GetStock(inStockName);
                 return portfolio.Stocks[stock];
             }
             else
             {
                 throw new StockExchangeException("Stock is not a part of portfolio");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             return Math.Round(portfolio.Stocks.Sum(x => x.Key.GetHistoryPrice(timeStamp)*x.Value), 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime firstDay = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             DateTime lastDay = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             decimal firstDayValue = GetPortfolioValue(inPortfolioID, firstDay);
             decimal lastDayValue = GetPortfolioValue(inPortfolioID, lastDay);
             decimal ratio = (lastDayValue/firstDayValue) - 1;
             return Math.Round(ratio*100, 3);
         }
     }
}
