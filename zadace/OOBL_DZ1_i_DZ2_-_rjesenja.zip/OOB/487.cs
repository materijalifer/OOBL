﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class MatijaStepanicCalculator:ICalculator
    {
        private static int max_digits = 10;
        
        private string screen;
        private double result;
        private bool error;
        private string input;
        private char? currentInput;
        private double? numberInMemory;
        private double? historyNumber;
        private char? historyOperation;
        private char? historyInputOneBefore;

        #region InitCalculator
        public MatijaStepanicCalculator()
        {
            InitCalculator();
        }
        private void InitCalculator()
        {
            this.screen = "0";
            this.result = 0;
            this.error = false;
            this.input = "";
            this.currentInput = null;
            this.numberInMemory = null;
            this.historyNumber = null;
            this.historyOperation = null;
            this.historyInputOneBefore = null;
        }
        #endregion


        #region LogicOfCalculator
        private void StopIsError()
        {
            this.error = true;
        }
        private bool IsScreenEmpty()
        {
            if ( this.screen == "0" && this.input == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void AppendCurrentInput()
        {
            if (this.historyOperation == null)
            {
                if (this.input == ",")
                {
                    this.input = "0,";
                }
                this.result = Convert.ToDouble(this.input);
            }
            this.screen = this.input;
        }
        private void ValidateBeforeRefreshScreen()
        {
            if (this.result > 9999999999)
            {
                this.error = true;
            }
            else if (this.result < -999999999)
            {
                this.error = true;
            }

            RoundDigitLength();
            RefreshScreenWithResult();
        }
        private void RefreshScreenWithResult()
        {
            if (this.error == true)
            {
                this.screen = "-E-";
            }
            else
            {
                this.screen = Convert.ToString(this.result);
            }
        }
        private void SaveBinaryOperation(char operation)
        {
            if (!Char.IsDigit(Convert.ToChar(this.historyInputOneBefore)))
            {
                this.historyOperation = operation;
                return;
            }

            try
            {
                this.historyNumber = Convert.ToDouble(this.input);
            }
            catch
            {
                this.historyNumber = null;
            }
            
            double num = 0;
            if (this.historyNumber != null)
            {
                num = Convert.ToDouble(this.historyNumber);
            }
            
            this.input = "";

            if (this.historyOperation != null)
            {            
                switch (this.historyOperation)
                {
                    case '+':
                        this.result += num;
                        break;
                    case '-':
                        this.result -= num;
                        break;
                    case '*':
                        this.result *= num;
                        break;
                    case '/':
                        this.result /= num;
                        break;                    
                }
            }

            this.historyOperation = operation;
            ValidateBeforeRefreshScreen(); 
        }

        private void SaveUnaryOperation(char operation)
        {
            

            if (this.historyOperation == null)
            {
                this.result = 0;
            }            

            try
            {
                double num = Convert.ToDouble(this.input);
                double result = 0;
                char ho = ' ';

                switch (operation)
                {
                    case 'S':
                        result = Math.Sin(num);
                        if (this.historyOperation == null)                        
                            ho = 'S';   
                        break;
                    case 'K':
                        result = Math.Cos(num);
                        if (this.historyOperation == null)                        
                            ho = 'K';  
                        break;
                    case 'T':
                        result = Math.Tan(num);
                        if (this.historyOperation == null)                        
                            ho = 'T';  
                        break;
                    case 'Q':
                        result = Math.Pow(num,2);
                        if (this.historyOperation == null)                        
                            ho = 'Q';                          
                        break;
                    case 'R':
                        result = Math.Pow(num,0.5);
                        if (this.historyOperation == null)                        
                            ho = 'R';  
                        break;
                    case 'I':
                        if (num == 0)
                        {
                            this.error = true;
                            break;
                        }
                        result = Math.Pow(num,-1);
                        if (this.historyOperation == null)                        
                            ho = 'I';  
                        break;                        
                }

                if (this.historyOperation == null)
                {
                    this.historyOperation = ho;
                    this.result = result;
                }
                else
                {
                    this.input = result.ToString();
                }                

                if (this.historyOperation != null)
                {
                    SaveBinaryOperation(Convert.ToChar(this.historyOperation));
                }

                RoundDigitLength();

                ValidateBeforeRefreshScreen();
            }
            catch
            {
                this.error = true;
                return;
            }
            
        }


        #endregion

        #region Wrappers
        private void DoDigit()
        {
            if (!this.input.Contains(','))
            {
                double currentNumber = Convert.ToDouble(this.input + this.currentInput); //filter za brisanje vodećih nula
                this.input = Convert.ToString(currentNumber);  
            }
            else
            {
                this.input += this.currentInput;
            }            
            
            AppendCurrentInput();   
        }
        private void DoPlus()
        {
            SaveBinaryOperation('+');
        }
        private void DoMinus()
        {
            SaveBinaryOperation('-');
        }
        private void DoMultiple()
        {
            SaveBinaryOperation('*');
        }
        private void DoDevide()
        {
            SaveBinaryOperation('/');
        }
        private void DoEqual()
        {
            SaveBinaryOperation('='); 
        }
        private void DoDecimalPoint()
        {
            if (!this.input.Contains(','))
            {
                this.input += ",";
                AppendCurrentInput();
            }
        }
        private void DoChangeSign()
        {
            if (!this.input.Contains('-'))
            {
                this.input = "-" + this.input;                
            }
            else
            {
                this.input = this.input.Substring(1);
            }
            AppendCurrentInput();
        }
        private void DoSinus()
        {
            SaveUnaryOperation('S');
        }
        private void DoCosine()
        {
            SaveUnaryOperation('K');
        }
        private void DoTangent()
        {
            SaveUnaryOperation('T');
        }
        private void DoSquare()
        {
            SaveUnaryOperation('Q');
        }
        private void DoSquareRoot()
        {
            SaveUnaryOperation('R');
        }
        private void DoInverse()
        {
            SaveUnaryOperation('I');
        }
        private void DoSaveToMemory()
        {
            this.numberInMemory = Convert.ToDouble(this.screen);
        }
        private void DoGetFromMemory()
        {
            this.screen = Convert.ToString(this.numberInMemory);
            this.input = this.screen;
        }
        private void DoClearScreen()
        {
            this.input = "";
            this.screen = "";
        }
        private void DoReset()
        {
            InitCalculator();
        }

        private bool PrePressValidateDigitLength()
        {
            if (!Char.IsDigit(Convert.ToChar(this.historyInputOneBefore)))
            {
                return true;
            }

            int numberOfDigits = this.screen.Length;

            

            if (this.screen.Contains(','))
            {
                numberOfDigits -= 1;
            }
            if (this.screen.Contains('-'))
            {
                numberOfDigits -= 1;
            }

            if (numberOfDigits < max_digits)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void RoundDigitLength()
        {
            string resultStr = Convert.ToString(this.result);
            int position = resultStr.IndexOf(',');
            int extra = 0;
            if (resultStr.Contains(','))
            {
                extra += 1;
            }
            if (resultStr.Contains('-'))
            {
                extra += 1;
            }
            this.result = Math.Round(this.result, max_digits + extra - position - 1);
            
        }
        #endregion

        #region PublicInterface
        public void Press(char inPressedDigit)
        {
            try
            {
                this.historyInputOneBefore = Convert.ToChar(this.input.Substring(this.input.Length - 1));

            }
            catch
            {
                this.historyInputOneBefore = null;
            }
            
            this.currentInput = inPressedDigit;            

            if (Char.IsDigit(inPressedDigit))
            {
                if (!PrePressValidateDigitLength())
                {
                    return;
                }

                DoDigit();
                return;
            }

            switch (inPressedDigit)
            {
                case '+':
                    DoPlus();
                    break;
                case '-':
                    DoMinus();
                    break;
                case '*':
                    DoMultiple();
                    break;
                case '/':
                    DoDevide();
                    break;
                case '=':
                    DoEqual();
                    break;
                case ',':
                    DoDecimalPoint();
                    break;
                case 'M':
                    DoChangeSign();
                    break;
                case 'S':
                    DoSinus();
                    break;
                case 'K':
                    DoCosine();
                    break;
                case 'T':
                    DoTangent();
                    break;
                case 'Q':
                    DoSquare();
                    break;
                case 'R':
                    DoSquareRoot();
                    break;
                case 'I':
                    DoInverse();
                    break;
                case 'P':
                    DoSaveToMemory();
                    break;
                case 'G':
                    DoGetFromMemory();
                    break;
                case 'C':
                    DoClearScreen();
                    break;
                case 'O':
                    DoReset();
                    break;                
            }

            

        }

        public string GetCurrentDisplayState()
        {
            return this.screen;
        }
        #endregion

    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new MatijaStepanicCalculator();
        }
    }


}
