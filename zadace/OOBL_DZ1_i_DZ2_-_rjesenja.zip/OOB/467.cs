using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private StringBuilder display;
        private double memory;
        private IOperation operation;
        private double firstOperand;

        private static readonly int MAX_DIGITS = 10; // without sign and decimal delimiter

        public Kalkulator()
        {
            display = new StringBuilder(MAX_DIGITS + 2, MAX_DIGITS + 2);
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                if ((inPressedDigit == '0' && !display.ToString().Equals("0"))
                        || Char.IsDigit(inPressedDigit))
                {
                    addDigit(inPressedDigit);
                }
                else if (inPressedDigit == '+'
                    || inPressedDigit == '-'
                    || inPressedDigit == '*'
                    || inPressedDigit == '/'
                    )
                {
                    binaryOperatorEncountered(inPressedDigit);
                }
                else if (inPressedDigit == '=')
                {
                    updateDisplayWithResult();
                }
                else if (inPressedDigit == ',')
                {
                    if (!display.ToString().Contains(inPressedDigit))
                    {
                        display.Append(inPressedDigit);
                    }
                }
                else if (inPressedDigit == 'M')
                {
                    if (display.ToString().ElementAt(0) == '-')
                    {
                        display.Remove(0, 1);
                    }
                    else
                    {
                        display.Insert(0, "-");
                    }
                }
                else if (inPressedDigit == 'S'
                    || inPressedDigit == 'K'
                    || inPressedDigit == 'T'
                    || inPressedDigit == 'Q'
                    || inPressedDigit == 'R'
                    || inPressedDigit == 'I'
                    )
                {
                    unaryOperatorEncountered(inPressedDigit);
                }
                else if (inPressedDigit == 'P')
                {
                    memory = numberOnDisplay();
                }
                else if (inPressedDigit == 'G')
                {
                    replaceDisplayWith(memory);
                }
                else if (inPressedDigit == 'C')
                {
                    replaceDisplayWith('0');
                }
                else if (inPressedDigit == 'O')
                {
                    operation = null;
                    firstOperand = 0;
                    memory = 0;
                    replaceDisplayWith('0');
                }
            }
            catch (Exception)
            {
                replaceDisplayWith("-E-");   
            }
        }

        private void unaryOperatorEncountered(char operatorSign)
        {
            replaceDisplayWith(unaryOperation(operatorSign));
        }

        private double unaryOperation(char operatorSign)
        {
            switch (operatorSign)
            {
                case 'S': return Math.Sin(numberOnDisplay()); break;
                case 'K': return Math.Cos(numberOnDisplay()); break;
                case 'T': return Math.Tan(numberOnDisplay()); break;
                case 'Q': return Math.Pow(numberOnDisplay(), 2); break;
                case 'R': return Math.Sqrt(numberOnDisplay()); break;
                case 'I': return 1/numberOnDisplay(); break;
                default: throw new System.ArgumentException();
            }
        }

        private void binaryOperatorEncountered(char operatorSign)
        {
            updateDisplayWithResult();
            firstOperand = numberOnDisplay();
            operation = createBinaryOperation(operatorSign);
        }

        private void updateDisplayWithResult()
        {
            if (operation == null || firstOperand == null)
            {
                return;
            }
            double operationResult = operation.calculate(firstOperand, numberOnDisplay());
            replaceDisplayWith(operationResult);
        }

        private void replaceDisplayWith(Object operationResult)
        {
            display.Clear();
            display.Append(operationResult);
        }

        private double numberOnDisplay()
        {
            return Double.Parse(display.ToString());
        }

        

        public string GetCurrentDisplayState()
        {
            return display.ToString();
        }

        private bool isFull()
        {
            int digits = 0;
            foreach (char c in display.ToString())
            {
                if (Char.IsDigit(c)) digits++;
            }

            return digits == (MAX_DIGITS);
        }

        private void addDigit(char digit)
        {
            if (!isFull())
            {
                display.Append(digit);
            }
        }

        private IOperation createBinaryOperation(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '+': return new AdditionOperation(); break;
                case '-': return new SubtractionOperation(); break;
                case '*': return new MultiplicationOperation(); break;
                case '/': return new DivisionOperation(); break;
                default: return null; break;
            }
        }

    }


    interface IOperation
    {
        double calculate(double firstOperand, double secondOperand);
    }

    class AdditionOperation : IOperation
    {
        public double calculate(double firstOperand, double secondOperand)
        {
            return firstOperand + secondOperand;
        }
    }

    class SubtractionOperation : IOperation
    {
        public double calculate(double firstOperand, double secondOperand)
        {
            return firstOperand - secondOperand;
        }
    }

    class MultiplicationOperation : IOperation
    {
        public double calculate(double firstOperand, double secondOperand)
        {
            return firstOperand * secondOperand;
        }
    }

    class DivisionOperation : IOperation
    {
        public double calculate(double firstOperand, double secondOperand)
        {
            return firstOperand / secondOperand;
        }
    }

}


