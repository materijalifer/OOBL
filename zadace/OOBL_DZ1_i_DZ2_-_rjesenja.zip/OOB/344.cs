﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        #region Fields

        public List<Portfolio> Portfolios { get; set; }

        public List<Index> Indices { get; set; }

        public List<Stock> Stocks { get; set; }

        #endregion

        #region Constructors

        public StockExchange()
        {
            Stocks = new List<Stock>();
            Indices = new List<Index>();
            Portfolios = new List<Portfolio>();
        }

        #endregion

        #region Methods

        #region Stock

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName)) throw new StockExchangeException("Već postoji dionica sa zadanim imenom.");
            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            Stocks.Add(newStock);
        }

        public void DelistStock(string inStockName)
        {
            Stock deleteStock = FindStock(inStockName);

            Indices.Where(i => i.StockExists(inStockName)).ToList().ForEach(i => i.RemoveStock(inStockName));
            Portfolios.Where(p => p.StockExists(inStockName)).ToList().ForEach(p => p.RemoveStock(inStockName));
            Stocks.Remove(deleteStock);
        }

        public bool StockExists(string inStockName)
        {
            return Stocks.Any(s => s.Name.ToLower() == inStockName.ToLower());
        }

        public Stock FindStock(string inStockName)
        {
            Stock stock = Stocks.FirstOrDefault(s => s.Name.ToLower() == inStockName.ToLower());

            if (stock == null) throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
            return stock;
        }

        public int NumberOfStocks()
        {
            return Stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock changeStock = FindStock(inStockName);

            changeStock.ChangePrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = FindStock(inStockName);

            return stock.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = FindStock(inStockName);

            return stock.GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = FindStock(inStockName);

            return stock.GetLastPrice();
        }

        #endregion

        #region Index

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName)) throw new StockExchangeException("Već postoji indeks sa zadanim imenom.");
            Index newIndex;
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    newIndex = new AverageIndex(inIndexName);
                    break;

                case IndexTypes.WEIGHTED:
                    newIndex = new WeightedIndex(inIndexName);
                    break;

                default:
                    throw new StockExchangeException("Pogrešno zadan tip indeksa.");
            }

            Indices.Add(newIndex);
        }

        public Index FindIndex(string inIndexName)
        {
            Index index = Indices.FirstOrDefault(i => i.Name.ToLower() == inIndexName.ToLower());

            if (index == null) throw new StockExchangeException("Ne postoji indeks sa zadanim imenom.");
            return index;
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = FindIndex(inIndexName);
            Stock stock = FindStock(inStockName);

            if (IsStockPartOfIndex(inIndexName, inStockName)) throw new StockExchangeException("Odabrana dionica je već u indeksu.");
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = FindIndex(inIndexName);
            FindStock(inStockName);

            index.RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = FindIndex(inIndexName);
            FindStock(inStockName);

            return index.StockExists(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = FindIndex(inIndexName);

            return index.GetValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return Indices.Any(i => i.Name.ToLower() == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return Indices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = FindIndex(inIndexName);

            return index.NumberOfStocks();
        }

        #endregion

        #region Portfolio

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Već postoji portfolio sa zadanim imenom.");
            Portfolio newPortfolio = new Portfolio(inPortfolioID);
            Portfolios.Add(newPortfolio);
        }

        public Portfolio FindPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = Portfolios.FirstOrDefault(p => p.Name == inPortfolioID);

            if (portfolio == null) throw new StockExchangeException("Ne postoji portfolio sa zadanim imenom.");
            return portfolio;
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            ValidateShares(numberOfShares);
            Portfolio portfolio = FindPortfolio(inPortfolioID);
            Stock stock = FindStock(inStockName);

            if (stock.GetNumberOfAvaliableShares() < numberOfShares)
                throw new StockExchangeException("Ne postoji dovoljna količina dionica na burzi.");
            portfolio.AddStock(stock, numberOfShares);
            stock.RemoveShares(numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            ValidateShares(numberOfShares);
            Portfolio portfolio = FindPortfolio(inPortfolioID);
            Stock stock = FindStock(inStockName);

            if (portfolio.GetStockShares(inStockName) < numberOfShares) throw new StockExchangeException("Ne postoji dovoljna količina dionica u portfoliu.");

            portfolio.RemoveStock(inStockName, numberOfShares);
            stock.AddShares(numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);
            Stock stock = FindStock(inStockName);
            
            stock.AddShares(NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName));
            portfolio.RemoveStock(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return Portfolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);

            return portfolio.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return Portfolios.Any(p => p.Name == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);
            FindStock(inStockName);

            return portfolio.StockExists(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);
            FindStock(inStockName);

            return unchecked((int)portfolio.GetStockShares(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);

            return portfolio.GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = FindPortfolio(inPortfolioID);

            return portfolio.GetPercentChangeInValueForMonth(Year, Month);
        }

        public void ValidateShares(int numberOfShares)
        {
            if (numberOfShares < 1) throw new StockExchangeException("Broj dionica mora biti veći od 0.");
        }

        #endregion

        #endregion
    }

    public class Stock
    {
        #region Fields

        public string Name { get; set; }

        private long Shares { get; set; }

        private long AvaliableShares { get; set; }


        private List<StockFluctation> StockFluctations { get; set; }

        #endregion

        #region Constructors

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            ValidateName(inStockName);
            ValidateNumberOfShares(inNumberOfShares);
            ValidatePrice(inInitialPrice);

            Name = inStockName;
            Shares = inNumberOfShares;
            AvaliableShares = Shares;
            StockFluctations = new List<StockFluctation> { new StockFluctation(inTimeStamp, DateTime.MaxValue, inInitialPrice) };
        }

        #endregion

        #region Methods

        private void ValidateName(string stockName)
        {
            if (stockName == null) throw new StockExchangeException("Ime dionice ne smije biti prazno.");
        }

        private void ValidateNumberOfShares(long numberOfShares)
        {
            if (numberOfShares < 1) throw new StockExchangeException("Pogrešno zadan broj dionica.");
        }

        private void ValidatePrice(decimal price)
        {
            if (price <= 0) throw new StockExchangeException("Pogrešno zadana cijena dionice.");
        }

        private void ValidateDate(DateTime timeStamp)
        {
            if (StockFluctations.Any(sf => sf.SameTimeStamp(timeStamp)))
            {
                throw new StockExchangeException("Vec postoji odabrani datum cijene dionice.");
            }
        }

        public StockFluctation FindFluctation(DateTime timeStamp)
        {
            StockFluctation stockFluctation = null;

            foreach (StockFluctation sf in StockFluctations)
            {
                if (sf.InTimeSpan(timeStamp)) stockFluctation = sf;
            }

            return stockFluctation;
        }

        public void ChangePrice(DateTime inTimeStamp, decimal inStockValue)
        {
            ValidatePrice(inStockValue);
            ValidateDate(inTimeStamp);

            ChangeStockFluctations(inTimeStamp, inStockValue);
        }

        public void ChangeStockFluctations(DateTime inTimeStamp, decimal inStockValue)
        {
            StockFluctation priorStockFluctation = FindFluctation(inTimeStamp);
            if (priorStockFluctation != null)
            {
                DateTime priorEndTimeStamp = priorStockFluctation.GetEndTimeStamp();
                priorStockFluctation.SetEndTimeStamp(inTimeStamp);
                StockFluctations.Add(new StockFluctation(inTimeStamp, priorEndTimeStamp, inStockValue));

                StockFluctations = StockFluctations.OrderBy(p => p.GetStartTimeStamp()).ToList();
            }

            else
            {
                DateTime endTime = StockFluctations[0].GetStartTimeStamp();
                StockFluctations.Add(new StockFluctation(inTimeStamp, endTime, inStockValue));

                StockFluctations = StockFluctations.OrderBy(p => p.GetStartTimeStamp()).ToList();
            }
        }

        public decimal GetInitialPrice()
        {
            return StockFluctations[0].GetFluctationPrice();
        }

        public decimal GetLastPrice()
        {
            return StockFluctations.Last().GetFluctationPrice();
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            if (FindFluctation(inTimeStamp) == null) throw new StockExchangeException("Cijena nije definirana za odabrano razdoblje.");
            return FindFluctation(inTimeStamp).GetFluctationPrice();
        }

        public decimal GetOverallPrice(DateTime inTimeStamp)
        {
            return GetPrice(inTimeStamp)*GetNumberOfShares();
        }

        public long GetNumberOfShares()
        {
            return Shares;
        }

        public long GetNumberOfAvaliableShares()
        {
            return AvaliableShares;
        }

        public void AddShares(long shares)
        {
            AvaliableShares += shares;
        }

        public void RemoveShares(long shares)
        {
            AvaliableShares -= shares;
        }

        #endregion
    }

    public class StockFluctation
    {
        #region Fields

        private decimal Price { get; set; }

        private DateTime StartTimeStamp { get; set; }

        private DateTime EndTimeStamp { get; set; }

        #endregion

        #region Constructors

        public StockFluctation(DateTime startTimeStamp, DateTime endTimeStamp, decimal inStockValue)
        {
            Price = inStockValue;
            StartTimeStamp = startTimeStamp;
            EndTimeStamp = endTimeStamp;
        }

        #endregion

        #region Methods

        public decimal GetFluctationPrice()
        {
            return Price;
        }

        public DateTime GetStartTimeStamp()
        {
            return StartTimeStamp;
        }

        public DateTime GetEndTimeStamp()
        {
            return EndTimeStamp;
        }

        public void SetEndTimeStamp(DateTime end)
        {
            EndTimeStamp = end;
        }

        public bool InTimeSpan(DateTime timeStamp)
        {
            if (timeStamp - StartTimeStamp >= TimeSpan.Zero && EndTimeStamp - timeStamp > TimeSpan.Zero) return true;
            return false;
        }

        public bool SameTimeStamp(DateTime timeStamp)
        {
            if (timeStamp - StartTimeStamp == TimeSpan.Zero) return true;
            return false;
        }

        #endregion
    }

    public abstract class StockExchangeItem
    {
        #region Fields

        public string Name { get; set; }

        protected List<Stock> Stocks { get; set; }

        #endregion

        #region Methods

        protected void ValidateName(string itemName)
        {
            if (itemName == null) throw new StockExchangeException("Ime predmeta ne smije biti prazno.");
        }

        public bool StockExists(string inStockName)
        {
            return Stocks.Any(s => s.Name.ToLower() == inStockName.ToLower());
        }

        public Stock FindStock(string inStockName)
        {
            Stock stock = Stocks.FirstOrDefault(s => s.Name.ToLower() == inStockName.ToLower());

            if (stock == null) throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
            return stock;
        }

        public void AddStock(Stock stock)
        {
            Stocks.Add(stock);
        }

        public void RemoveStock(string inStockName)
        {
            Stock stock = FindStock(inStockName);

            Stocks.Remove(stock);
        }

        public virtual int NumberOfStocks()
        {
            return Stocks.Count();
        }

        protected decimal GetOverallStockValue(DateTime inTimeStamp)
        {
            return Stocks.Sum(s => s.GetPrice(inTimeStamp) * s.GetNumberOfShares());
        }

        public abstract decimal GetValue(DateTime inTimeStamp);

        #endregion
    }

    public abstract class Index : StockExchangeItem
    {
        
    }

    public class AverageIndex : Index
    {
        #region Constructors

        public AverageIndex(string inIndexName)
        {
            ValidateName(inIndexName);

            Name = inIndexName;
            Stocks = new List<Stock>();
        }

        #endregion

        #region Methods

        public override decimal GetValue(DateTime inTimeStamp)
        {
            if (NumberOfStocks() == 0) return 0;
            decimal value = Stocks.Sum(s => s.GetPrice(inTimeStamp));

            value = value/NumberOfStocks();
            value = Math.Round(value, 3);

            return value;
        }

        #endregion
    }

    public class WeightedIndex : Index
    {
        #region Constructors

        public WeightedIndex(string inIndexName)
        {
            ValidateName(inIndexName);

            Name = inIndexName;
            Stocks = new List<Stock>();
        }

        #endregion

        #region Methods

        public override decimal GetValue(DateTime inTimeStamp)
        {
            if (NumberOfStocks() == 0) return 0;
            decimal overallStockValue = GetOverallStockValue(inTimeStamp);

            decimal value = (from s in Stocks
                             let price = s.GetOverallPrice(inTimeStamp)/s.GetNumberOfShares()
                             let weightedFactor = GetWeightedFactor(price, overallStockValue)
                             select price*weightedFactor*s.GetNumberOfShares()).Sum();

            value = Math.Round(value, 3);

            return value;
        }

        private decimal GetWeightedFactor(decimal price, decimal overallStockValue)
        {
            return price / overallStockValue;
        }

        #endregion
    }

    public class Portfolio : StockExchangeItem
    {
        #region Fields

        private PortfolioShares Shares { get; set; }

        #endregion

        #region Constructors

        public Portfolio(string inName)
        {
            ValidateName(inName);
            Name = inName;
            
            Stocks = new List<Stock>();
            Shares = new PortfolioShares();
        }

        #endregion

        #region Methods

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (StockExists(stock.Name))
            {
                Shares.AddShares(stock.Name, numberOfShares);
            }
            else
            {
                Stocks.Add(stock);
                Shares.AddStock(stock.Name, numberOfShares);
            }
        }

        public void RemoveStock(string inStockName, int numberOfShares)
        {
            FindStock(inStockName);

            if (Shares.NumberOfShares(inStockName) - numberOfShares == 0) RemoveStock(inStockName);
            else Shares.RemoveShares(inStockName, numberOfShares);
        }

        public new void RemoveStock(string inStockName)
        {
            Stock stock = FindStock(inStockName);

            Shares.RemoveStock(inStockName);
            Stocks.Remove(stock);
        }

        public long GetStockShares(string inStockName)
        {
            return Shares.NumberOfShares(inStockName);
        }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            return Stocks.Sum(s => s.GetPrice(inTimeStamp)*Shares.NumberOfShares(s.Name));
        }

        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            ValidateDate(year, month);
            if (NumberOfStocks() == 0) return 0;
            DateTime startDate = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime endDate = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

            decimal startValue = GetValue(startDate);
            decimal endValue = GetValue(endDate);
            decimal difference = endValue - startValue;
            return difference/startValue*100;
        }

        private void ValidateDate(int year, int month)
        {
            if (year < 1 | year > 9999) throw new StockExchangeException("Pogrešno odabran datum.");

            if (month < 1 | month > 12) throw new StockExchangeException("Pogrešno odabran datum.");
        }

        #endregion
    }

    public class PortfolioShares
    {
        #region Fields

        private Dictionary<string, int> StockShares { get; set; }

        #endregion

        #region Constructors

        public PortfolioShares()
        {
            StockShares = new Dictionary<string, int>();
        }

        #endregion

        #region Methods

        public int NumberOfShares(string stock)
        {
            if (StockShares.ContainsKey(stock)) return StockShares[stock];
            return 0;
        }

        public void AddShares(string stock, int numberOfShares)
        {
            StockShares[stock] += numberOfShares;  
        }

        public void RemoveShares(string stock, int numberOfShares)
        {
            StockShares[stock] -= numberOfShares;  
        }

        public void AddStock(string stock, int numberOfShares)
        {
            StockShares.Add(stock, numberOfShares);
        }

        public void RemoveStock(string stock)
        {
            StockShares.Remove(stock);
        }

        #endregion
    }
}
