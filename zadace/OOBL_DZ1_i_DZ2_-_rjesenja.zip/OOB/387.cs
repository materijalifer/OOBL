using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Dionica> dionice = new List<Dionica>(); //lista dionica
         List<Indeks> indeksi = new List<Indeks>(); //lista indeksa
         List<Portfolio> portfelji = new List<Portfolio>(); //lista portfolia
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             for (int i = 0; i < dionice.Count(); i++ ) //provjeravamo da li postoji vec takva dionica s istim imenom
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);
                 if (result==true)
                 {
                     throw new StockExchangeException("Dionica sa takvim imenom vec postoji.");
                 }
             }
             if (inInitialPrice<=0) //provjera da cijena nije negativna
             {
                 throw new StockExchangeException("Neispravna cijena dionice.");
             }
             if (inNumberOfShares<=0) //provjera da je broj shareova dobar
             {
                 throw new StockExchangeException("Neispravan broj shareova");
             }
             Dionica PomocnaDionica= new Dionica(); //stvaramo pomocnu dionicu u koju trpamo podatke i nju stavljamo u listu dionica
             PomocnaDionica.ImeDionice = inStockName;
             PomocnaDionica.BrojShareova = inNumberOfShares;
             PomocnaDionica.VrijemeCijena.Add(inTimeStamp, inInitialPrice);
             dionice.Add(PomocnaDionica);
         }

         public void DelistStock(string inStockName)
         {
             for (int i = 0; i < indeksi.Count(); i++)
             {
                 if (IsStockPartOfIndex(indeksi[i].ImeIndeksa, inStockName)==true)
                 {
                     RemoveStockFromIndex(indeksi[i].ImeIndeksa, inStockName); //ako brisemo dionicu s burze brisemo ju i iz indeksa
                 }
             }
             for (int i = 0; i < portfelji.Count(); i++)
             {
                 if (portfelji[i].DioniceUPortfolio.ContainsKey(inStockName))
                 {
                     RemoveStockFromPortfolio(portfelji[i].IDPortfolio, inStockName); //ako brisemo dionicu s burze brisemo ju i iz portfolia
                 }
             }
             bool odluka = false;
             for (int  i = 0;  i < dionice.Count();  i++)
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);//gledamo dal postoji dionica
                 if (result==true)
                 {
                     dionice.RemoveAt(i);
                     odluka = true;
                 }
             }
             if (odluka==false)
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom.");
             }
             
         }

         public bool StockExists(string inStockName)
         {
             for (int i = 0; i < dionice.Count(); i++) //provjeravamo da li postoji vec takva dionica s istim imenom
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);
                 if (result == true)
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return dionice.Count();
         }
         public long NumberOfSharesInStock(string inStockName)
         {
             long broj = 0;
             bool postojiStock = false;
             for (int i = 0; i < dionice.Count(); i++)
             {
                 if (dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase)==true) //ako je to ta dionica
                 {
                     postojiStock = true;
                     broj = dionice[i].BrojShareova;
                 }
             }
             if (postojiStock==false)//ne postoji dionica s tim imenom
             {
                 throw new StockExchangeException("ne postoji takva dionica");
             }
             return broj;
         }
         public long BrojZauzetihShareovaStocka(string inStockName) //metoda koja nam govori koliko je shareova zauzetih u odredenoj dionici
         {
             long broj = 0;
             for (int i = 0; i < dionice.Count(); i++)
             {
                 if (dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                 {
                     broj = dionice[i].BrojZauzetihShareova;
                 }
             }
             return broj;
         }
         public void PovecajZauzetostShareovaStocka(string inStockName, long Number) //metoda koja povecava zauzetost shareova u dionici
         {
             for (int i = 0; i < dionice.Count(); i++)
             {
                 if (dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                 {
                     dionice[i].BrojZauzetihShareova += Number;
                 }
             }
         }
         public void SmanjiZauzetostShareovaStocka(string inStockName, long Number) //metoda koja smanjuje zauzetost shareova u dionici
         {
             for (int i = 0; i < dionice.Count(); i++)
             {
                 if (dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                 {
                     dionice[i].BrojZauzetihShareova -= Number;
                 }
             }
         }
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             bool odluka = false;
             if (inStockValue<=0)
             {
                 throw new StockExchangeException("Neispravna cijena.");
             }
             for (int i = 0; i < dionice.Count(); i++)
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);//gledamo dal postoji dionica
                 if (result == true)
                 {
                     dionice[i].VrijemeCijena.Add(inIimeStamp, inStockValue);
                     odluka = true;
                 }
             }
             if (odluka == false)
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom.");
             }

         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             bool odluka = false;
             decimal cijena=0;
             for (int i = 0; i < dionice.Count(); i++)
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);//gledamo dal postoji dionica
                 if (result == true)
                 {
                     IList<DateTime> MojaLista = new List<DateTime>();
                     MojaLista = dionice[i].VrijemeCijena.Keys;
                     if (inTimeStamp<MojaLista[0])
                     {
                         throw new StockExchangeException("Dohvaceno je vrijeme prije postojanja dionice.");
                     }
                     else
                     {
                         for (int j=MojaLista.Count()-1; j>=0; j--)
                         {
                             if (MojaLista[j]<=inTimeStamp)
                             {
                                 cijena = dionice[i].VrijemeCijena[MojaLista[j]];
                                 break;
                             }
                         }
                     }  
                     odluka = true;
                 }
             }
             if (odluka == false)
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom.");
             }
             return cijena;

         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             bool odluka = false;
             decimal cijena=0;
             for (int i = 0; i < dionice.Count(); i++)
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);
                     //gledamo dal postoji dionica
                 if (result == true)
                 {
                     IList<DateTime> MojaLista = new List<DateTime>();
                     MojaLista = dionice[i].VrijemeCijena.Keys;
                     cijena = dionice[i].VrijemeCijena[MojaLista[0]];
                     odluka = true;
                 }
             }
             if (odluka == false)
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom.");
             }
             return cijena;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             bool odluka = false;
             decimal cijena = 0;
             for (int i = 0; i < dionice.Count(); i++)
             {
                 bool result = dionice[i].ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase);
                 //gledamo dal postoji dionica
                 if (result == true)
                 {
                     IList<DateTime> MojaLista = new List<DateTime>();
                     MojaLista = dionice[i].VrijemeCijena.Keys;
                     cijena = dionice[i].VrijemeCijena[MojaLista[MojaLista.Count()-1]];
                     odluka = true;
                 }
             }
             if (odluka == false)
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom.");
             }
             return cijena;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             for (int i = 0; i < indeksi.Count(); i++) //provjeravamo da li postoji vec takav indeks s istim imenom
             {
                 bool result = indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase);
                 if (result == true)
                 {
                     throw new StockExchangeException("Indeks sa takvim imenom vec postoji.");
                 }
             }
             if ((inIndexType == IndexTypes.AVERAGE) || (inIndexType == IndexTypes.WEIGHTED)) //ako je tip u redu
             {//kreiramo novi indeks i stavljamo ga u listu
                 Indeks PomocniIndeks = new Indeks();
                 PomocniIndeks.ImeIndeksa = inIndexName;
                 PomocniIndeks.TipIndeksa = inIndexType;
                 indeksi.Add(PomocniIndeks);
             }
             else
             {
                 throw new StockExchangeException("tip nije odgovarajuci");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName)) //provjera da li postoji dionica na burzi
             {
                 bool PostojiIndeks = false;
                 for (int i=0; i<indeksi.Count(); i++)
                 {
                     
                     if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)==true) //pronaden je indeks
                     {
                         PostojiIndeks = true;
                         bool provjera = false;
                         for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++) //provjera dal ima takva dionica unutra već
                         {
                             if ( indeksi[i].DioniceUIndeksu[j].Equals(inStockName, StringComparison.OrdinalIgnoreCase)==true)
                             {
                                 provjera = true;
                                 throw new StockExchangeException("dionica je vec u indeksu.");
                             }
                         }
                         if (provjera==false) //dionice nema u indeksu stavljamo ju unutra
                         {
                             indeksi[i].DioniceUIndeksu.Add(inStockName);
                         }
                     }
                     
                 }
                 if (PostojiIndeks == false)
                 {
                     throw new StockExchangeException("ne postoji takav indeks.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName)) //provjera da li postoji dionica na burzi
             {
                 bool PostojiIndeks = false;
                 for (int i = 0; i < indeksi.Count(); i++)
                 {

                     if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase) == true) //pronaden je indeks
                     {
                         PostojiIndeks = true;
                         bool provjera = false;
                         for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++) //provjera dal ima takva dionica unutra već
                         {
                             if (indeksi[i].DioniceUIndeksu[j].Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                             {
                                 provjera = true; //nasli smo dionicu i brisemo ju
                                 
                                 indeksi[i].DioniceUIndeksu.RemoveAt(j);
                             }
                         }
                         if (provjera == false) //dionice nema u indeksu 
                         {
                             throw new StockExchangeException("takve dionice nema u indeksu");
                         }
                     }
                 }
                 if (PostojiIndeks == false)
                 {
                     throw new StockExchangeException("ne postoji takav indeks.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool PostojiIndeks = false;
             bool pronaden = false;
             for (int i = 0; i < indeksi.Count(); i++)
             {
                 if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase) == true) //pronaden je indeks
                 {
                     PostojiIndeks = true;
                     for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++) //provjera dal ima takva dionica unutra već
                     {
                         if (indeksi[i].DioniceUIndeksu[j].Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                         {
                             pronaden = true;//nasli smo dionicu
                         }
                     }
                 }
             }
             if (PostojiIndeks == false)
             {
                 throw new StockExchangeException("ne postoji takav indeks.");
             }
             return pronaden;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal vrijednost = 0;
             //prvo pronaći indeks
             bool PostojiIndeks = false;
             for (int i = 0; i < indeksi.Count(); i++)
             {
                 if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase) == true) //pronaden je indeks
                 {  
                     PostojiIndeks = true; //to je taj indeks
                     if (NumberOfStocksInIndex(inIndexName) == 0)
                     {
                         vrijednost = 0;
                     }
                     else
                     {
                         if (indeksi[i].TipIndeksa == IndexTypes.AVERAGE)
                         {
                             decimal sumaDionica = 0;
                             for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++) //prolaz po svim dionicama
                             {
                                 sumaDionica += GetStockPrice(indeksi[i].DioniceUIndeksu[j], inTimeStamp);
                             }
                             if (NumberOfStocksInIndex(indeksi[i].ImeIndeksa) != 0)
                             {
                                 vrijednost = Math.Round((sumaDionica/NumberOfStocksInIndex(indeksi[i].ImeIndeksa)), 3);
                             }
                             else
                             {
                                 vrijednost = 0;
                             }
                         }
                         else if (indeksi[i].TipIndeksa == IndexTypes.WEIGHTED)
                         {
                             //weighted
                             decimal ukupnaVrijednost = 0;
                             //List<decimal> tezinskiFaktori = new List<decimal>();
                             for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++)
                             {
                                 ukupnaVrijednost += GetStockPrice(indeksi[i].DioniceUIndeksu[j], inTimeStamp)*
                                                     NumberOfSharesInStock(indeksi[i].DioniceUIndeksu[j]);
                             }
                             if (ukupnaVrijednost != 0)
                             {
                                 for (int j = 0; j < indeksi[i].DioniceUIndeksu.Count(); j++)
                                 {
                                     vrijednost += GetStockPrice(indeksi[i].DioniceUIndeksu[j], inTimeStamp)*
                                                   (GetStockPrice(indeksi[i].DioniceUIndeksu[j], inTimeStamp)*
                                                    NumberOfSharesInStock(indeksi[i].DioniceUIndeksu[j])/
                                                    ukupnaVrijednost);
                                 }
                             }
                             else
                             {
                                 throw new StockExchangeException("dijelis s nulom.");
                             }
                             vrijednost = Math.Round(vrijednost, 3);
                         }
                     }
                 }
             }
             if (PostojiIndeks==false)
             {
                 throw new StockExchangeException("takav indeks ne postoji");
             }
             return vrijednost;
         }

         public bool IndexExists(string inIndexName)
         {
             bool PostojiIndeks = false;
             for (int i = 0; i < indeksi.Count(); i++)
             {
                 if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase) == true) //pronaden je indeks
                 {
                     PostojiIndeks = true;
                 }
             }
             return PostojiIndeks;
         }

         public int NumberOfIndices() //broj indeksa
         {
             int broj = indeksi.Count();
             return broj;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int broj = 0;
             bool PostojiIndeks = false;
             for (int i = 0; i < indeksi.Count(); i++)
             {
                 if (indeksi[i].ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase) == true) //pronaden je indeks
                 {
                     PostojiIndeks = true;
                     broj = indeksi[i].DioniceUIndeksu.Count(); //prebroji dionice
                 }
             }
             if (PostojiIndeks == false)
             {
                 throw new StockExchangeException("ne postoji takav indeks.");
             }  
             return broj;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             bool postojiPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++)
             {
                 if (portfelji[i].IDPortfolio == inPortfolioID)
                     postojiPortfolio = true;
             }
             if (postojiPortfolio==false) //ako ne postoji takav portfolio stvori ga
             {
                 Portfolio pomocniPortfolio = new Portfolio();
                 pomocniPortfolio.IDPortfolio = inPortfolioID;
                 portfelji.Add(pomocniPortfolio);
             }
             else
             {
                 throw new StockExchangeException("postoji portfolio s istim imenom"); //ako postoji greska
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (StockExists(inStockName)) //provjera da li postoji dionica na burzi
             {
                 bool PostojiPortfolio = false;
                 for (int i = 0; i < portfelji.Count(); i++)
                 {
                     if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden je portfolio
                     {
                         PostojiPortfolio = true;
                         if (NumberOfSharesInStock(inStockName)-BrojZauzetihShareovaStocka(inStockName)>=numberOfShares)//ako ima slobodnog
                         { //onda stavim unutra te shareove i povecaj broj zauzetosti
                             if (portfelji[i].DioniceUPortfolio.ContainsKey(inStockName))//sadrzi tu dionicu samododaj shareove
                             {
                                 portfelji[i].DioniceUPortfolio[inStockName] += numberOfShares;
                             }
                             else //ne sadrzi napravi novi par
                             {
                                 portfelji[i].DioniceUPortfolio.Add(inStockName, numberOfShares);
                             }
                             PovecajZauzetostShareovaStocka(inStockName, numberOfShares);
                         }
                         else
                         {
                             throw new StockExchangeException("nije slobodno toliko shareova");
                         }
                     }
                 }
                 if (PostojiPortfolio == false)
                 {
                     throw new StockExchangeException("ne postoji takav portfolio.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (StockExists(inStockName)) //provjera da li postoji dionica na burzi
             {
                 bool PostojiPortfolio = false;
                 for (int i = 0; i < portfelji.Count(); i++)
                 {
                     if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden je portfolio
                     {
                         PostojiPortfolio = true;
                         if (portfelji[i].DioniceUPortfolio.ContainsKey(inStockName))//sadrzi tu dionicu uzmi shareove
                         {
                             if (portfelji[i].DioniceUPortfolio[inStockName]>numberOfShares)//uzmi potrebno shareova
                             {
                                 portfelji[i].DioniceUPortfolio[inStockName] -= numberOfShares;
                                 //pozovi fju da se poveca broj slobodnih shareova
                                 SmanjiZauzetostShareovaStocka(inStockName,numberOfShares);
                             }else if (portfelji[i].DioniceUPortfolio[inStockName]==numberOfShares)
                             {
                                 //delitaj stock
                                 SmanjiZauzetostShareovaStocka(inStockName, numberOfShares);
                             }
                             else
                             {
                                 throw new StockExchangeException("nema toliko shareova");
                             }
                         }
                         else
                         {
                             throw new StockExchangeException("ne postoji takva dionica u tom portfoliu");
                         }
                     }
                 }
                 if (PostojiPortfolio == false)
                 {
                     throw new StockExchangeException("ne postoji takav portfolio.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (StockExists(inStockName)) //provjera da li postoji dionica na burzi
             {
                 bool PostojiPortfolio = false;
                 for (int i = 0; i < portfelji.Count(); i++)
                 {

                     if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden je portfolio
                     {
                         PostojiPortfolio = true;
                         if (portfelji[i].DioniceUPortfolio.ContainsKey(inStockName))//sadrzi tu dionicu uzmi shareove
                         {
                             portfelji[i].DioniceUPortfolio.Remove(inStockName);
                             long zaKoliko = NumberOfSharesInStock(inStockName);
                             SmanjiZauzetostShareovaStocka(inStockName, zaKoliko);
                         }
                         else
                         {
                             throw new StockExchangeException("ne postoji takva dionica u tom portfoliu");
                         }
                     }
                 }
                 if (PostojiPortfolio == false)
                 {
                     throw new StockExchangeException("ne postoji takav portfolio.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }
         }

         public int NumberOfPortfolios() //broj portfolia
         {
             return portfelji.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int brojDionica = 0;
             bool pronadenPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++) //prolaz po portfolijima
             {
                 if (portfelji[i].IDPortfolio==inPortfolioID) //ako je to taj broji dionice
                 {
                     pronadenPortfolio = true;
                     brojDionica = portfelji[i].DioniceUPortfolio.Count();
                 }
             }
             if (pronadenPortfolio==false)
             {
                 throw new StockExchangeException("ne postoji portfolio s tim id-em");
             }
             return brojDionica;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool postojiPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++ )
             {
                 if (portfelji[i].IDPortfolio == inPortfolioID) //portfolio postoji
                 {
                     postojiPortfolio = true;
                 }
             }
             return postojiPortfolio;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool postojiStock = false;
             bool pronadenPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++)
             {  
                 if (portfelji[i].IDPortfolio == inPortfolioID)
                 {
                     pronadenPortfolio = true;
                     List<string> kljucevi = new List<string>(portfelji[i].DioniceUPortfolio.Keys);
                     for (int j  = 0; j  < kljucevi.Count(); j ++)
                     {
                         if (kljucevi[j].Equals(inStockName, StringComparison.OrdinalIgnoreCase)==true)
                         {
                             postojiStock = true;
                         }
                     }
                 }
             }
             if (pronadenPortfolio == false)
             {
                 throw new StockExchangeException("ne postoji portfolio s tim id-em");
             }
             return postojiStock;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int broj = 0;
             bool pronadenPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++) //trazimo odredeni portfolio
             {
                 if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden portfolio
                 {
                     pronadenPortfolio = true;
                     bool pronadenStock = false;
                     List<string> kljucevi = new List<string>(portfelji[i].DioniceUPortfolio.Keys);
                     for (int j = 0; j < kljucevi.Count(); j++) //trazimo odredeni stock
                     {
                         if (kljucevi[j].Equals(inStockName, StringComparison.OrdinalIgnoreCase) == true)
                         {
                             pronadenStock = true;
                             broj = portfelji[i].DioniceUPortfolio[inStockName]; //dohvacamo broj shareova
                         }
                     }
                     if (pronadenStock==false)
                     {
                         throw new StockExchangeException("ne postoji takav stock");
                     }
                 }
             }
             if (pronadenPortfolio == false)
             {
                 throw new StockExchangeException("ne postoji portfolio s tim id-em");
             }
             return broj;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal vrijednost = 0;
             bool pronadenPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++) //trazimo odredeni portfolio
             {
                 if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden portfolio
                 {
                     pronadenPortfolio = true;
                     if (NumberOfStocksInPortfolio(portfelji[i].IDPortfolio) == 0)
                     { //ako je portfolio prazaan vrijednost mu je nula
                         vrijednost = 0;
                     }
                     else
                     {//racunaj
                         foreach (KeyValuePair<string, int> pair in portfelji[i].DioniceUPortfolio)
                         {
                             vrijednost += pair.Value*GetStockPrice(pair.Key, timeStamp);
                         } 
                     }
                 }
             }
             if (pronadenPortfolio == false)
             {
                 throw new StockExchangeException("ne postoji portfolio s tim id-em");
             }
             return vrijednost;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal vrijednost = 0;
             decimal ZadnjiDan = 0;
             decimal PrviDan = 0;
             bool pronadenPortfolio = false;
             for (int i = 0; i < portfelji.Count(); i++) //trazimo odredeni portfolio
             {
                 if (portfelji[i].IDPortfolio == inPortfolioID) //pronaden portfolio
                 {
                     pronadenPortfolio = true;
                     if (NumberOfStocksInPortfolio(portfelji[i].IDPortfolio) == 0)
                     { //ako je portfolio prazaan vrijednost mu je nula
                         vrijednost = 0;
                     }
                     else
                     {//racunaj
                         PrviDan = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
                         int brojDana= DateTime.DaysInMonth(Year, Month);
                         ZadnjiDan = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, brojDana, 23, 59, 59, 999));
                         if (PrviDan==0)
                         {
                             throw new StockExchangeException("dijeljenje s nulom");
                         }
                         else
                         {
                             vrijednost = Math.Round((ZadnjiDan-PrviDan)/PrviDan*100, 3);
                         }
                     }
                 }
             }
             if (pronadenPortfolio == false)
             {
                 throw new StockExchangeException("ne postoji portfolio s tim id-em");
             }
             return vrijednost;
         }
     }
	public class Dionica
    {
        public string ImeDionice; //ime dionice
        public long BrojShareova;//broj shareova koje ima
        public SortedList<DateTime, Decimal> VrijemeCijena=new SortedList<DateTime, decimal>(); //vrijeme i cijena dionice
        public long BrojZauzetihShareova;//sprema se broj zauzetih shareova
    }
	public class Indeks
    {
        public string ImeIndeksa; //ime indeksa
        public IndexTypes TipIndeksa; //tip indeksa
        public List<string> DioniceUIndeksu = new List<string>(); //sprema se imena dionica koje su u indeksu
    }
	public class Portfolio
    {
        public string IDPortfolio; //ID portfolia
        public Dictionary<string, int > DioniceUPortfolio = new Dictionary<string, int>(); //sprema se ime dionice i broj shareova
    }
}
