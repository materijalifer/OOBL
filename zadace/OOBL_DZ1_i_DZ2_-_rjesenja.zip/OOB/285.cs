﻿/*************************************************/
/*              IME: Mihael                      */
/*          PREZIME: Mercvajler                  */
/*             JMBG: 0165028029                  */
/*************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /*Pravila*/
    public class Pravila
    {
        /*Pravila za dionice*/
        public bool imeDionice(string ime, List<Dionica> dionice)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == ime.ToLower());

            if (result != null)
            {
                throw new StockExchangeException("Dionica sa navedenim imenom već postoji!");
            }
            else
            {
                return true;
            }
        }

        public bool cijenaDionice(Decimal cijena)
        {
            if (cijena <= Decimal.Zero)
            {
                throw new StockExchangeException("Cijena dionice mora biti veća od 0!");
            }
            else
            {
                return true;
            }
        }

        public bool brojDionica(long kolicina)
        {
            if (kolicina <= 0)
            {
                throw new StockExchangeException("Broj dionica mora biti veći od 0!");
            }
            else
            {
                return true;
            }
        }

        public bool kolicinaDionica(List<Dionica> dionice)
        {
            if (dionice.Count() < 0)
            {
                throw new StockExchangeException("Nema dionica na burzi!");
            }
            else
            {
                return true;
            }
        }

        public bool vrijemePromijeneCijene(List<PovijestCijeneDionice> cijena, DateTime vrijeme)
        {
            PovijestCijeneDionice result = cijena.Find(
                temp_dionica => temp_dionica.getVrijeme() == vrijeme);

            if (result != null)
            {
                throw new StockExchangeException("Cijena je u željenom trenutku već zadana!");
            }
            else
            {
                return true;
            }
        }

        /*Pravila za indekse*/
        public bool imeIndexa(string ime, List<Index> indeksi)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme().ToLower() == ime.ToLower());

            if (result != null)
            {
                throw new StockExchangeException("Index sa navedenim imenom već postoji!");
            }
            else
            {
                return true;
            } 
        }

        /*Pravila za portfelje*/
        public bool imePortfelja(string ime, List<Portfelj> portfelji)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == ime);

            if (result != null)
            {
                throw new StockExchangeException("Portfelj sa navedenim imenom već postoji!");
            }
            else
            {
                return true;
            }
        }

        public bool kolicinaDionicaPortfelj(string i, long k, List<Portfelj> portfelji, List<Dionica> dionice)
        {
            long temp_sum = 0;
            foreach (Portfelj p in portfelji)
            {
                temp_sum = temp_sum + p.brojDionica(i);
            }

            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == i.ToLower());

            if (result != null)
            {
                if (k <= result.getKolicina() - temp_sum)
                {
                    return true;
                }
                else
                {
                    throw new StockExchangeException("Pravelik broj dionica!");
                }
            }
            else
            {
                throw new StockExchangeException("Navedena dionica ne postoji!");
            }
        }

        public bool imeDionicePortfelj(string ime, List<Dionica> dionice)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == ime.ToLower());

            return result == null;
        }
    }

    /*Dionica*/
    public class PovijestCijeneDionice
    {
        private DateTime vrijeme;
        private Decimal cijena;

        public PovijestCijeneDionice(DateTime v, Decimal c)
        {
            vrijeme = v;
            cijena = c;
        }

        public DateTime getVrijeme()
        {
            return vrijeme;
        }

        public Decimal getCijena()
        {
            return cijena;
        }
    }

    public class Dionica
    {
        private string ime;
        private long kolicina;
        private List<PovijestCijeneDionice> cijena; 
        private Pravila pravila;

        public Dionica()
        {
            ime = "0";
            kolicina = 0;
            cijena = new List<PovijestCijeneDionice>();
            pravila = new Pravila();
        }

        public Dionica(string i, long k, Decimal c, DateTime v)
        {
            cijena = new List<PovijestCijeneDionice>();
            pravila = new Pravila();

            if (pravila.brojDionica(k) == true && pravila.cijenaDionice(c) == true)
            {
                ime = i;
                kolicina = k;
                PovijestCijeneDionice temp_cijena = new PovijestCijeneDionice(v, c);
                cijena.Add(temp_cijena);
                cijena.Sort((p1, p2) => p1.getVrijeme().CompareTo(p2.getVrijeme()));
            }
        }

        public string getIme()
        {
            return ime;
        }

        public Decimal getPocetnaCijena()
        {
            return cijena.Last().getCijena();
        }

        public Decimal getZadnjaCijena()
        {
            return cijena.First().getCijena();
        }

        public long getKolicina()
        {
            return kolicina;
        }

        public Decimal getCijenaZaVrijeme(DateTime v)
        {
            if (v < cijena.Last().getVrijeme())
            {
                throw new StockExchangeException("Za zadano vrijeme cijena ne postoji!");
            }
            if (v >= cijena.First().getVrijeme())
            {
                return cijena.First().getCijena();
            }
            
            PovijestCijeneDionice result = cijena.Find(
                temp_dionica => temp_dionica.getVrijeme() <= v );
             
            return result.getCijena();    

        }

        public List<PovijestCijeneDionice> getSveCijene()
        {
            return cijena;
        } 

        public void setSveCijene(List<PovijestCijeneDionice> c)
        {
            cijena = c;
        }

        public void setKolicina(int k)
        {
            kolicina = k;
        }

        public void setCijenaZaVrijeme(Decimal c, DateTime v)
        {
            if (pravila.cijenaDionice(c) == true && pravila.vrijemePromijeneCijene(cijena, v))
            {
                PovijestCijeneDionice temp_cijena = new PovijestCijeneDionice(v, c);
                cijena.Add(temp_cijena);
                cijena.Sort((p1, p2) => p2.getVrijeme().CompareTo(p1.getVrijeme()));
            }
        }
    }

    /*Index*/
    public class Index
    {
        private string ime;
        private List<Dionica> dionice; 

        public Index()
        {
            ime = "0";
            dionice = new List<Dionica>();
        }

        public bool provjeriPrisutnostDionice(string ime)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme() == ime);

            return result != null;
        }

        public void dodajDionicu(Dionica dionica)
        {
            dionice.Add(dionica);
        }

        public void izbrisiDionicu(string ime)
        {
            var d = dionice.First(s => s.getIme() == ime);
            dionice.Remove(d);
        }

        public int brojDionica()
        {
            return dionice.Count();
        }

        public virtual Decimal vrijednost()
        {
            return 0;
        }

        public string getIme()
        {
            return ime;
        }

        public List<Dionica> getDionice()
        {
            return dionice;
        }

        public void setIme(string i)
        {
            ime = i;
        }
    }

    public class AverageIndex : Index
    {
       public AverageIndex(string ime)
       {
           setIme(ime);
       }

        public override Decimal vrijednost()
        {
            Decimal temp_decimal;
            temp_decimal = 0;
            foreach ( Dionica d in getDionice())
            {
                temp_decimal = temp_decimal + d.getZadnjaCijena();
                temp_decimal = Decimal.Round(temp_decimal, 3);
            }

            if (getDionice().Count() == 0) 
                return 0;
            else
            {
                temp_decimal = temp_decimal/getDionice().Count();
                temp_decimal = Decimal.Round(temp_decimal, 3);
                return temp_decimal;
            }
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string ime)
        {
            setIme(ime);
        }

        public override Decimal vrijednost()
        {
            Decimal temp_decimal;
            Decimal temp_sum;
            Decimal temp_sum2;

            temp_decimal = 0;
            temp_sum = 0;
            temp_sum2 = 0;
            foreach (Dionica d in getDionice())
            {
                temp_decimal = d.getZadnjaCijena() * d.getKolicina();
                temp_sum = temp_sum + temp_decimal;
                temp_sum = Decimal.Round(temp_sum, 3);
            }

            if (getDionice().Count() == 0)
                return 0;
            else
            {
                temp_decimal = 0;
                foreach (Dionica d in getDionice())
                {
                    temp_decimal = d.getZadnjaCijena() / temp_sum;
                    temp_decimal = temp_decimal*d.getZadnjaCijena();
                    temp_sum2 = temp_sum2 + temp_decimal * d.getKolicina();
                    temp_sum2 = Decimal.Round(temp_sum2, 3);
                }
                return temp_sum2;
            }
        }
    }

    /*Portfelj*/
    public class Portfelj
    {
        private Pravila pravila;
        private string idIme;
        private List<Dionica> dionice;
 
        public Portfelj()
        {
            pravila = new Pravila();
            dionice = new List<Dionica>();
            idIme = "0";
        }

        public Portfelj(string ime)
        {
            pravila = new Pravila();
            dionice = new List<Dionica>();
            idIme = ime;
        }

        public void dodajDionicu(Dionica d, long k)
        {
            if (pravila.imeDionicePortfelj(d.getIme(), dionice) == true)
            {
                Dionica temp_dionica = new Dionica(d.getIme(), k, 1, DateTime.Now);
                temp_dionica.setSveCijene(d.getSveCijene());
                dionice.Add(temp_dionica);
            }
            else
            {
                Dionica result = dionice.Find(
                    temp_dionica => temp_dionica.getIme().ToLower() == d.getIme().ToLower());

                if (result != null)
                {
                    int temp_kolicina = (int)result.getKolicina() + (int)k;
                     result.setKolicina( temp_kolicina);
                }
            }
        }

        public bool dionicaDioPortfelja(string ime)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == ime.ToLower());

            return result != null;
        }

        public long brojDionica(string i)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == i.ToLower());

            if (result != null)
            {
                return result.getKolicina();
            }
            else
            {
                return 0;
            }
        }

        public int kolicinaDionica()
        {
            return dionice.Count();
        }

        public long kolicinaDionica(string ime)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == ime.ToLower());

            if (result != null)
            {
                return result.getKolicina();
            }
            else
            {
                throw new StockExchangeException("Nema navedene dionice u portfejlu!");
            }
        }

        public void izbrisiDionicu(string ime)
        {
            var d = dionice.First(s => s.getIme() == ime);
            dionice.Remove(d);
        }

        public void izbrisiDionicu(string ime, int k)
        {
            var d = dionice.First(s => s.getIme() == ime);
            int temp_kolicina = (int) d.getKolicina() - k;
            if (temp_kolicina <= 0)
                izbrisiDionicu(ime);
            else
            {
                d.setKolicina(temp_kolicina);
            }
        }

        public Decimal cijenaSvihDionica(DateTime v)
        {
            Decimal sum = 0;
            foreach (Dionica d in dionice)
            {
                sum = sum + (d.getCijenaZaVrijeme(v) * d.getKolicina());
                sum = Decimal.Round(sum, 3);
            }
            return sum;
        }

        public Decimal mjesecnaCijena(int year, int month)
        {
            DateTime start = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime end = new DateTime(year, month, 1, 0, 0, 0, 0).AddMonths(1)
                .AddDays(-1).AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(999);

            Decimal pocetak = 0;
            Decimal kraj = 0;
            foreach (Dionica d in dionice)
            {
                pocetak = pocetak + d.getCijenaZaVrijeme(start);
                kraj = kraj + d.getCijenaZaVrijeme(end);
            }

            if (pocetak == 0) return 0;
            Decimal postotak = (kraj - pocetak) / pocetak * 100;
            postotak = Decimal.Round(postotak, 3);
            return postotak;
        }

        public string getIme()
        {
            return idIme;
        }

        public List<Dionica> getDionice()
        {
            return dionice;
        }     
    }

    /*Burza*/
    public class StockExchange : IStockExchange
    {
        private List<Dionica> dionice;
        private List<Index> indeksi;
        private List<Portfelj> portfelji; 
        private Pravila pravila;
       
        
        public StockExchange()
        {
            dionice = new List<Dionica>();
            indeksi = new List<Index>(); 
            portfelji = new List<Portfelj>();
            pravila = new Pravila();
        }

        /*Dionica*/
        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName) == true)
            {
                foreach (Portfelj p in portfelji)
                {
                    if (IsStockPartOfPortfolio(p.getIme(), inStockName) == true)
                    {
                        RemoveStockFromPortfolio(p.getIme(), inStockName);
                    }
                }

                foreach (Index i in indeksi)
                {
                    if (IsStockPartOfIndex(i.getIme(), inStockName) == true)
                    {
                        RemoveStockFromIndex(i.getIme(), inStockName);
                    }
                }

                var d = dionice.First(s => s.getIme() == inStockName);
                dionice.Remove(d);

            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public bool StockExists(string inStockName)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme().ToLower() == inStockName.ToLower());

            return result != null;
        }

        public int NumberOfStocks()
        {
            if (pravila.kolicinaDionica(dionice) == true)
            {
                return dionice.Count();
            }
            else
            {
                throw new StockExchangeException("Na burzi nema dionica!");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme() == inStockName);

            if (result == null)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            else
            {
                return result.getPocetnaCijena();
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme() == inStockName);

            if (result == null)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            else
            {
                return result.getZadnjaCijena();
            }
        }

        public void ListStock(string inStockName, long inNumberOfShares, 
                                decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (pravila.imeDionice(inStockName, dionice) == true)
            {
                Dionica temp_dionica = 
                    new Dionica(inStockName, inNumberOfShares,inInitialPrice, inTimeStamp);
                dionice.Add(temp_dionica);
            }

        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme() == inStockName);

            if (result == null)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            else
            {
                return result.getCijenaZaVrijeme(inTimeStamp);
            }
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Dionica result = dionice.Find(
                temp_dionica => temp_dionica.getIme() == inStockName);

            if (result == null)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            else
            {
                result.setCijenaZaVrijeme(inStockValue, inIimeStamp);
            }
        }

        /*Index*/
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (pravila.imeIndexa(inIndexName, indeksi) == true)
            {
                Index temp_index;
                if (inIndexType == IndexTypes.AVERAGE)
                {
                    temp_index = new AverageIndex(inIndexName);
                }
                else
                {
                    temp_index = new WeightedIndex(inIndexName);
                }
                indeksi.Add(temp_index);
            }
            else
            {
                throw new StockExchangeException("Index sa navedenim imenom već postoji!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme().ToLower() == inIndexName.ToLower());

            return result != null;
        }

        public int NumberOfIndices()
        {
            return indeksi.Count();
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme() == inIndexName);

            if (result != null)
            {
                return result.provjeriPrisutnostDionice(inStockName);
            }
            else
            {
                throw new StockExchangeException("NAvedeni indeks ne postoji!");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme() == inIndexName);

            if (result != null)
            {
                if (result.provjeriPrisutnostDionice(inStockName) == true)
                {
                    throw new StockExchangeException("Dionica je već u indeksu!");
                }
                else
                {
                    Dionica temp_result = dionice.Find(
                        temp_dionica => temp_dionica.getIme() == inStockName);

                    if (temp_result != null)
                    {
                        result.dodajDionicu(temp_result);
                    }
                    else
                    {
                        throw new StockExchangeException("Dionica ne postoji!");
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Navedeni indeks ne postoji!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme() == inIndexName);

            if (result != null)
            {
                if (result.provjeriPrisutnostDionice(inStockName) == true)
                {
                    result.izbrisiDionicu(inStockName);
                }
                else
                {
                    throw new StockExchangeException("Dionica nije u indeksu!");
                }
            }
            else
            {
                throw new StockExchangeException("Navedeni indeks ne postoji!");
            }
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme() == inIndexName);

            if (result != null)
            {
                return result.brojDionica();
            }
            else
            {
                throw new StockExchangeException("Navedeni indeks ne postoji!");
            }

        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index result = indeksi.Find(
                temp_index => temp_index.getIme() == inIndexName);

            if (result != null)
            {
                return result.vrijednost();
            }
            else
            {
                throw new StockExchangeException("Navedeni index ne postoji!");
            }
        }
        
        /*Portfelj*/
        public void CreatePortfolio(string inPortfolioID)
        {
            if (pravila.imePortfelja(inPortfolioID, portfelji) == true)
            {
                Portfelj temp_portfelj = new Portfelj(inPortfolioID);
                portfelji.Add(temp_portfelj);
            }
        }

        public int NumberOfPortfolios()
        {
            return portfelji.Count();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            return result != null;
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) == true &&
                pravila.kolicinaDionicaPortfelj(inStockName, numberOfShares, portfelji, dionice) == true)
            {
                Portfelj result = portfelji.Find(
                    temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

                Dionica result1 = dionice.Find(
                    temp_dionica => temp_dionica.getIme().ToLower() == inStockName.ToLower());

                result.dodajDionicu(result1, numberOfShares);
            }
            else
            {
                throw new StockExchangeException("ERROR!");
            }
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                return result.kolicinaDionica();
            }
            else
            {
                throw new StockExchangeException("Navedeni portfolio ne postoji!");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                return (int)result.kolicinaDionica(inStockName);
            }
            else
            {
                throw new StockExchangeException("Navedeni portfolio ne postoji!");
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                return result.dionicaDioPortfelja(inStockName);
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == true)
                    result.izbrisiDionicu(inStockName);
                else
                {
                    throw new StockExchangeException("Dionica se ne nalazi unutar zadanog portfelja!");
                }
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == true)
                {
                    result.izbrisiDionicu(inStockName, numberOfShares);
                }
                else
                {
                    throw new StockExchangeException("Dionica se ne nalazi unutar zadanog portfelja!");
                }
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji!");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfelj result = portfelji.Find(
                temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

            if (result != null)
            {
                return result.cijenaSvihDionica(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Zadani portfelj ne postoji!");
            }
        }      

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfelj result = portfelji.Find(
                 temp_portfelj => temp_portfelj.getIme() == inPortfolioID);

             if (result != null)
             {
                 return result.mjesecnaCijena(Year,Month);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfelj ne postoji!");
             }
         }
     }
}
 