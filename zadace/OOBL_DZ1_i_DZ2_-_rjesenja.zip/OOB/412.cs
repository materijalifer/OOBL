﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new SvemocniKalkulator();
        }
    }

    //value.ToString("0.00", CultureInfo.InvariantCulture)
    public class SvemocniKalkulator : ICalculator
    {
        //C samo brise trenutno sto je zadano i postavlja na 0
        //O postavlja sve na inicijalne postavke sto se tice memorije i podataka na ekranu
        //= izracunava sve sto ima 
        //, je samo dodatni znak
        //0 sadrzi dodatne uvjete koje treba provjeravati
        //-E- error kada nastane onda se ne prihvaca unos nijednog znaka osim C i O

        private stanjeKalkulator stanje = new stanjeKalkulator();

        public void Press(char inPressedDigit)
        {
            string znak = inPressedDigit.ToString();
            if (!provjeriZnak(znak))
                return;
            if (ignoreZnak(znak))
            {
                double meduRez;
                switch (znak)
                {
                    case "O":
                        stanje = new stanjeKalkulator();
                        break;

                    case "C":
                        stanje.setTrenutniZnakovi("0");
                        stanje.setSljedeciBroj(false);
                        break;

                    case "G":
                        stanje.setTrenutniZnakovi(stanje.getBrojMem().ToString());
                        if (stanje.getNegativanMem())
                        {
                            if (stanje.getTrenutni())
                            {
                                stanje.setNegativanPrvi(true);
                            }
                            else
                            {
                                stanje.setNegativanDrugi(true);
                            }
                        }
                        break;

                    case "P":
                        meduRez = Convert.ToDouble(stanje.getTrenutniZnakovi());
                        if (meduRez < 0)
                        {
                            stanje.setNegativanMem(true);
                            meduRez *= -1;
                        }
                        stanje.setBrojMem(meduRez);
                        stanje.setPostojiUMem(true);
                        break;

                    case "I":
                        double broj = Convert.ToDouble(stanje.getTrenutniZnakovi());
                        if (broj == 0)
                        {
                            stanje.setTrenutniZnakovi("-E-");
                            stanje.setError(true);
                        }
                        else
                        {
                            meduRez = 1 / broj;
                            if (meduRez > 9999999999 || meduRez < -9999999999)
                            {
                                stanje.setTrenutniZnakovi("-E-");
                            }
                            else
                            {
                                stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                            }
                        }
                        stanje.setUnarnaOperacija(true);
                        break;

                    case "R":
                        if (stanje.getTrenutni())
                        {
                            if (stanje.getNegativanPrvi())
                            {
                                stanje.setTrenutniZnakovi("-E-");
                                stanje.setError(true);
                            }
                            else
                            {
                                meduRez = Math.Pow(Convert.ToDouble(stanje.getTrenutniZnakovi()), 0.5);
                                stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                            }
                        }
                        else
                        {
                            if (stanje.getNegativanDrugi())
                            {
                                stanje.setTrenutniZnakovi("-E-");
                                stanje.setError(true);
                            }
                            else
                            {
                                meduRez = Math.Pow(Convert.ToDouble(stanje.getTrenutniZnakovi()), 0.5);
                                stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                            }
                        }
                        stanje.setUnarnaOperacija(true);
                        break;

                    case "Q":
                        meduRez = Math.Pow(Convert.ToDouble(stanje.getTrenutniZnakovi()), 2);
                        if (meduRez > 9999999999 || meduRez < -9999999999)
                        {
                            stanje.setTrenutniZnakovi("-E-");
                        }
                        else
                        {
                            if (stanje.getTrenutni())
                            {
                                if(stanje.getNegativanPrvi())
                                    stanje.setNegativanPrvi(false);
                            }
                            else
                            {
                                if (stanje.getNegativanDrugi())
                                    stanje.setNegativanDrugi(false);
                            }
                            stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                        }
                        stanje.setUnarnaOperacija(true);
                        break;

                    case "T":
                        try
                        {
                            meduRez = Math.Tan(Convert.ToDouble(stanje.getTrenutniZnakovi()));
                            if (meduRez > 9999999999 || meduRez < -9999999999)
                            {
                                stanje.setTrenutniZnakovi("-E-");
                            }
                            else
                            {
                                if (meduRez < 0)
                                {
                                    if (stanje.getTrenutni())
                                    {
                                        stanje.setNegativanPrvi(true);
                                    }
                                    else
                                    {
                                        stanje.setNegativanDrugi(true);
                                    }
                                    meduRez *= -1;
                                }
                                stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                            }
                            stanje.setUnarnaOperacija(true);
                        }
                        catch (Exception ex)
                        {
                            stanje.setTrenutniZnakovi("-E-");
                        }
                        break;

                    case "K":
                        meduRez = Math.Cos(Convert.ToDouble(stanje.getTrenutniZnakovi()));
                        if (meduRez > 9999999999 || meduRez < -9999999999)
                        {
                            stanje.setTrenutniZnakovi("-E-");
                        }
                        else
                        {
                            if (meduRez < 0)
                            {
                                if (stanje.getTrenutni())
                                {
                                    stanje.setNegativanPrvi(true);
                                }
                                else
                                {
                                    stanje.setNegativanDrugi(true);
                                }
                                meduRez *= -1;
                            }
                            stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                        }
                        stanje.setUnarnaOperacija(true);
                        break;

                    case "S":
                        meduRez = Math.Sin(Convert.ToDouble(stanje.getTrenutniZnakovi()));
                        if (meduRez > 9999999999 || meduRez < -9999999999)
                        {
                            stanje.setTrenutniZnakovi("-E-");
                        }
                        else
                        {
                            if (meduRez < 0)
                            {
                                if (stanje.getTrenutni())
                                {
                                    stanje.setNegativanPrvi(true);
                                }
                                else
                                {
                                    stanje.setNegativanDrugi(true);
                                }
                                meduRez *= -1;
                            }
                            stanje.setTrenutniZnakovi(provjeriDuljinu(meduRez.ToString()));
                        }
                        stanje.setUnarnaOperacija(true);
                        break;

                    case "M":
                        double brojNula = Convert.ToDouble(stanje.getTrenutniZnakovi());
                        if (brojNula != 0)
                        {
                            if (stanje.getTrenutni())
                            {
                                if (stanje.getNegativanPrvi())
                                {
                                    stanje.setNegativanPrvi(false);
                                }
                                else
                                {
                                    stanje.setNegativanPrvi(true);
                                }
                            }
                            else
                            {
                                if (stanje.getNegativanDrugi())
                                {
                                    stanje.setNegativanDrugi(false);
                                }
                                else
                                {
                                    stanje.setNegativanDrugi(true);
                                }
                            }
                        }
                        break;

                    case ",":
                        stanje.dodajTrenutniZnak(znak);
                        stanje.setSljedeciBroj(true);
                        break;

                    case "=":
                        izracunaj();
                        break;

                    case "/":
                        if (stanje.getSljedeciBroj() && !stanje.getTrenutni())
                        {
                            izracunaj();
                            stanje.setOperacija("/");
                            stanje.setSljedeciBroj(false);
                        }
                        else
                        {
                            stanje.setBrojPrvi(stanje.getTrenutniZnakovi());
                            stanje.setOperacija("/");
                            stanje.setSljedeciBroj(false);
                        }
                        break;

                    case "*":
                        if (stanje.getSljedeciBroj() && !stanje.getTrenutni())
                        {
                            izracunaj();
                            stanje.setOperacija("*");
                            stanje.setSljedeciBroj(false);
                        }
                        else
                        {
                            stanje.setBrojPrvi(stanje.getTrenutniZnakovi());
                            stanje.setOperacija("*");
                            stanje.setSljedeciBroj(false);
                        }
                        break;

                    case "-":
                        if (stanje.getSljedeciBroj() && !stanje.getTrenutni())
                        {
                            izracunaj();
                            stanje.setOperacija("-");
                            stanje.setSljedeciBroj(false);
                        }
                        else
                        {
                            stanje.setBrojPrvi(stanje.getTrenutniZnakovi());
                            stanje.setOperacija("-");
                            stanje.setSljedeciBroj(false);
                        }
                        break;

                    case "+":
                        if (stanje.getSljedeciBroj() && !stanje.getTrenutni())
                        {
                            izracunaj();
                            stanje.setOperacija("+");
                            stanje.setSljedeciBroj(false);
                        }
                        else
                        {
                            stanje.setBrojPrvi(stanje.getTrenutniZnakovi());
                            stanje.setOperacija("+");
                            stanje.setSljedeciBroj(false);
                        }
                        break;


                    //ovdje ce biti ako se unesu znamenke
                    default:
                        if (!stanje.getSljedeciBroj() || stanje.getUnarnaOperacija())
                        {
                            stanje.setTrenutniZnakovi(znak);
                        }
                        else
                        {
                            stanje.dodajTrenutniZnak(znak);
                        }
                        stanje.setTrenutniZnakovi(provjeriDuljinu(stanje.getTrenutniZnakovi()));
                        stanje.setSljedeciBroj(true);
                        stanje.setUnarnaOperacija(false);
                        //prebacujemo na drugi broj ako vec postoji unesena operacija
                        if (stanje.getOperacija().Length > 0)
                        {
                            stanje.setTrenutni(false);
                        }
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            if (!stanje.getTrenutniZnakovi().Equals("-E-") && Convert.ToDouble(stanje.getTrenutniZnakovi()) == Math.Round(Convert.ToDouble(stanje.getTrenutniZnakovi()), 0))
                stanje.setTrenutniZnakovi(Math.Round(Convert.ToDouble(stanje.getTrenutniZnakovi()), 0).ToString());

            if (stanje.getTrenutniZnakovi().Equals("0"))
            {
                return "0";
            }
            if (stanje.getTrenutni())
            {
                if (stanje.getNegativanPrvi())
                {
                    if (stanje.getTrenutniZnakovi().Contains("-E-"))
                        return "-E-";
                    return "-" + stanje.getTrenutniZnakovi();
                }
                else
                {
                    return stanje.getTrenutniZnakovi();
                }
            }
            else
            {
                if (stanje.getNegativanDrugi())
                {
                    if (stanje.getTrenutniZnakovi().Contains("-E-"))
                        return "-E-";
                    return "-" + stanje.getTrenutniZnakovi();
                }
                else
                {
                    return stanje.getTrenutniZnakovi();
                }
            }
        }

        private void izracunaj()
        {
            double prvi, drugi, rez;
            switch (stanje.getOperacija())
            {
                case "+":
                    prvi = Convert.ToDouble(stanje.getBrojPrvi());
                    drugi = Convert.ToDouble(stanje.getTrenutniZnakovi());
                    stanje.setBrojDrugi(provjeriDuljinu(drugi.ToString()));
                    rez = izracunNegativ(prvi,drugi);
                    if (rez < 0)
                    {
                        stanje.setNegativanPrvi(true);
                        rez *= -1;
                    }
                    if (rez > 9999999999 || rez < -9999999999)
                    {
                        stanje.setTrenutniZnakovi("-E-");
                    }
                    else
                    {
                        stanje.setTrenutniZnakovi(provjeriDuljinu(rez.ToString()));
                    }
                    stanje.setBrojPrvi(provjeriDuljinu(rez.ToString()));
                    stanje.setTrenutni(true);
                    break;

                case "-":
                    prvi = Convert.ToDouble(stanje.getBrojPrvi());                    
                    drugi = Convert.ToDouble(stanje.getTrenutniZnakovi());
                    stanje.setBrojDrugi(provjeriDuljinu(drugi.ToString()));
                    rez = izracunNegativ(prvi, drugi);
                    if (rez < 0)
                    {
                        stanje.setNegativanPrvi(true);
                        rez *= -1;
                    }
                    if (rez > 9999999999 || rez < -9999999999)
                    {
                        stanje.setTrenutniZnakovi("-E-");
                    }
                    else
                    {
                        stanje.setTrenutniZnakovi(provjeriDuljinu(rez.ToString()));
                    }
                    stanje.setBrojPrvi(provjeriDuljinu(rez.ToString()));
                    stanje.setTrenutni(true);
                    break;

                case "*":
                    prvi = Convert.ToDouble(stanje.getBrojPrvi());
                    drugi = Convert.ToDouble(stanje.getTrenutniZnakovi());
                    stanje.setBrojDrugi(provjeriDuljinu(drugi.ToString()));
                    rez = izracunNegativ(prvi, drugi);
                    if (rez < 0)
                    {
                        stanje.setNegativanPrvi(true);
                        rez *= -1;
                    }
                    if (rez > 9999999999 || rez < -9999999999)
                    {
                        stanje.setTrenutniZnakovi("-E-");
                    }
                    else
                    {
                        stanje.setTrenutniZnakovi(provjeriDuljinu(rez.ToString()));
                    }
                    stanje.setBrojPrvi(provjeriDuljinu(rez.ToString()));
                    stanje.setTrenutni(true);
                    break;

                case "/":
                    prvi = Convert.ToDouble(stanje.getBrojPrvi());
                    drugi = Convert.ToDouble(stanje.getTrenutniZnakovi());
                    stanje.setBrojDrugi(provjeriDuljinu(drugi.ToString()));
                    rez = izracunNegativ(prvi, drugi);
                    if (rez < 0)
                    {
                        stanje.setNegativanPrvi(true);
                        rez *= -1;
                    }
                    if (rez > 9999999999 || rez < -9999999999)
                    {
                        stanje.setTrenutniZnakovi("-E-");
                    }
                    else
                    {
                        stanje.setTrenutniZnakovi(provjeriDuljinu(rez.ToString()));
                    }
                    stanje.setBrojPrvi(provjeriDuljinu(rez.ToString()));
                    stanje.setTrenutni(true);
                    break;
                default:
                    rez = Convert.ToDouble(stanje.getTrenutniZnakovi());
                    stanje.setTrenutniZnakovi(provjeriDuljinu(rez.ToString()));
                    break;
            }
        }


        //ovisno o stanju kalkulatora neki znakovi se ignoriraju
        private bool ignoreZnak(string znak)
        {
            int Num;
            bool isNum = int.TryParse(znak, out Num);
            if (isNum && !stanje.getSljedeciBroj())
                return true;
            //ako je error i znak je razlicit od clear i on off nista se ne dogada
            if (stanje.getError() && !znak.Equals("C") && !znak.Equals("O"))
                return false;
            //ako znakovi sadrze , i pokusa unijeti novi, to se ignorira
            if (stanje.getTrenutniZnakovi().Contains(",") && znak.Equals(","))
                return false;
            //nadodavanje 0 na nulu
            if (stanje.getTrenutniZnakovi().Equals("0") && znak.Equals("0"))
                return false;
            //ako ima previse 
            if (isNum && stanje.getTrenutniZnakovi().Contains(",") && stanje.getTrenutniZnakovi().Length >= 11)
                return false;
            if (isNum && stanje.getTrenutniZnakovi().Length >= 10 && !stanje.getTrenutniZnakovi().Contains(","))
                return false;
            if (znak.Equals("G") && !stanje.getPostojiUMem())
                return false;
            return true;
        }

        //provjerava jel je jedan od znakova dozvoljen za unos ili jedan od znakova koji se ignorira
        private bool provjeriZnak(string znak)
        {
            String[] delimiteri = { "+", "-", "*", "/", "P" };
            String[] izracunajZnakovi = { "M", "S", "K", "T", "Q", "R", "I" };
            String[] ostali = { ",", "O", "C", "G", "=" };
            int Num;
            bool isNum = int.TryParse(znak, out Num);

            if (delimiteri.Contains(znak) || izracunajZnakovi.Contains(znak) || ostali.Contains(znak) || isNum)
            {
                return true;
            }
            return false;
        }

        private string provjeriDuljinu(string brojTekst)
        {
            if (brojTekst.Contains(",") && brojTekst.Length > 11)
            {
                //skrati i zaokruzi
                string zadnjiZnak = brojTekst.Substring(10, 1);
                if (zadnjiZnak.Equals(","))
                    return brojTekst.Substring(0, 10);
                //ovdje provjeravamo da li cemo zaokruziti na vecu znamenku
                string zadnjiBrojTekst = brojTekst.Substring(11, 1);
                int zadnjiBroj = Convert.ToInt32(zadnjiBrojTekst);
                if (zadnjiBroj >= 5)
                {
                    int zarezPozicija = brojTekst.IndexOf(",");
                    double zaokruzi = Math.Round(Convert.ToDouble(brojTekst),10-zarezPozicija);
                    string zaVratiti = zaokruzi.ToString();
                    return zaVratiti;
                }
                else
                {
                    return brojTekst.Substring(0, 11);
                }

            }
            else if (brojTekst.Length > 10 && !brojTekst.Contains(","))
            {
                //skrati
                return brojTekst.Substring(0, 10);
            }
            return brojTekst;
        }

        private double izracunNegativ(double a, double b)
        {
            switch(stanje.getOperacija()){
                case "+":
                        if (stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return -a - b;
                        }
                        if (!stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return a - b;
                        }
                        if (stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return -a + b;
                        }
                        if (!stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return a + b;
                        }
                        break;
                case "-":
                        if (stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return -a + b;
                        }
                        if (!stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return a + b;
                        }
                        if (stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return -a - b;
                        }
                        if (!stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return a - b;
                        }
                        break;
                case "*":
                    if (stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return -a*(-b);
                        }
                        if (!stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return a*(-b);
                        }
                        if (stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return -a*(b);
                        }
                        if (!stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return a*(b);
                        }
                        break;
                case "/":
                    if (stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return -a/(-b);
                        }
                        if (!stanje.getNegativanPrvi() && stanje.getNegativanDrugi())
                        {
                            return a/(-b);
                        }
                        if (stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return -a/(b);
                        }
                        if (!stanje.getNegativanPrvi() && !stanje.getNegativanDrugi())
                        {
                            return a/(b);
                        }
                        break;
            }
            return 0;
        }

    }

    public class stanjeKalkulator
    {
        private StringBuilder trenutniZnakovi;
        private double brojUMemoriji;
        private String brojPrvi;
        private String brojDrugi;
        //oznacava koja je operacija unesena
        private String operacija;
        private bool unarnaOperacija;
        private bool error;
        private bool sljedeciBroj;
        //ako ima zarez ako opet stavi zarez
        private bool negativanPrvi;
        private bool negativanDrugi;
        private bool negativanMemorija;
        //true prvi broj, false drugi broj
        private bool trenutni;
        private bool postojiUMem;

        public stanjeKalkulator()
        {
            trenutniZnakovi = new StringBuilder("0");
            operacija = String.Empty;
            error = false;
            sljedeciBroj = false;
            negativanPrvi = false;
            negativanDrugi = false;
            negativanMemorija = false;
            postojiUMem = false;
            unarnaOperacija = false;
            trenutni = true;
            brojPrvi = String.Empty;
        }

        public bool getUnarnaOperacija()
        {
            return this.unarnaOperacija;
        }

        public void setUnarnaOperacija(bool flag)
        {
            this.unarnaOperacija = flag;
        }

        public bool getPostojiUMem()
        {
            return this.postojiUMem;
        }

        public void setPostojiUMem(bool flag)
        {
            this.postojiUMem = flag;
        }


        public bool getError()
        {
            return this.error;
        }

        public void setError(bool flag)
        {
            this.error = flag;
        }

        public bool getNegativanPrvi()
        {
            return this.negativanPrvi;
        }

        public void setNegativanPrvi(bool flag)
        {
            this.negativanPrvi = flag;
        }

        public bool getNegativanDrugi()
        {
            return this.negativanDrugi;
        }

        public void setNegativanDrugi(bool flag)
        {
            this.negativanDrugi = flag;
        }

        public bool getNegativanMem()
        {
            return this.negativanMemorija;
        }

        public void setNegativanMem(bool flag)
        {
            this.negativanMemorija = flag;
        }

        public bool getTrenutni()
        {
            return this.trenutni;
        }

        public void setTrenutni(bool flag)
        {
            this.trenutni = flag;
        }

        public bool getSljedeciBroj()
        {
            return this.sljedeciBroj;
        }

        public void setSljedeciBroj(bool flag)
        {
            this.sljedeciBroj = flag;
        }

        public String getTrenutniZnakovi()
        {
            return this.trenutniZnakovi.ToString();
        }

        public String getBrojPrvi()
        {
            return this.brojPrvi;
        }

        public String getBrojDrugi()
        {
            return this.brojDrugi;
        }

        public double getBrojMem()
        {
            return this.brojUMemoriji;
        }

        public void setTrenutniZnakovi(String znakovi)
        {
            this.trenutniZnakovi = new StringBuilder(znakovi);
        }

        public void dodajTrenutniZnak(String znak)
        {
            this.trenutniZnakovi.Append(znak);
        }

        public void setBrojPrvi(String broj)
        {
            this.brojPrvi = broj;
        }

        public void setBrojDrugi(String broj)
        {
            this.brojDrugi = broj;
        }

        public void setBrojMem(double broj)
        {
            this.brojUMemoriji = broj;
        }

        public String getOperacija()
        {
            return this.operacija;
        }

        public void setOperacija(String operacija)
        {
            this.operacija = operacija;
        }

    }
}
