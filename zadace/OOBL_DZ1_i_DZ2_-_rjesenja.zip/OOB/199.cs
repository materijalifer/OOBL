﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        static int MAX_DISPLAY_LENGHT = 12;

        private bool _canAdd;
        private string _display;
        private IProcessor _proc;

        public Kalkulator()
        {
            this._canAdd = true;
            this._display = "0";
            this._proc = new Processor();
        }

        public void Press(char inPressedDigit)
        {
            if (isNumber(inPressedDigit) || inPressedDigit==',')
            {
                addDigit(inPressedDigit);
                _proc.SetInputFlag();
                _canAdd = true;
            }
            else
            {
                _display = _proc.ProcessValue(inPressedDigit, _display);
                _canAdd = continueCheck(inPressedDigit);
            }

            checkDisplay();
        }

        public string GetCurrentDisplayState()
        {
            return _display;
        }

        private void addDigit(char input)
        {
            if (_canAdd)
            {
                if (isNumber(input) || input == ',' && containsComma() == false)
                    _display += input;
            }
            if (!_canAdd)
                _display = "0" + input;
        }

        private bool continueCheck(char input)
        {
            if (input == 'M' || input == 'P') return true;
            else return false;
        }

        private void checkDisplay()
        {
            removeLeadingZeros();
            checkDisplayLenght();
        }

        private void removeLeadingZeros()
        {
            if (_display.Length > 1)
                if (_display[0] == '0' && _display[1] != ',')
                {
                    _display = _display.Substring(1);
                    removeLeadingZeros();
                }
        }

        private void checkDisplayLenght()
        {
            if (_display.Length > MAX_DISPLAY_LENGHT) _display = _display.Substring(0, MAX_DISPLAY_LENGHT);
        }

        private bool isNumber(char c)
        {
            if (c >= '0' && c <= '9') return true;
            else return false;
        }

        private bool containsComma()
        {
            if (_display.Contains(',')) return true;
            else return false;
        }

    }

    class Processor : IProcessor
    {
        static int MAX_NUMBER_LENGHT = 10;
        static double MAX_NUMBER = 9999999999;

        private string _result;
        private string _memory;
        private double _ans;
        private char _operator;
        private bool _lastWasBinary;
        private bool _lastWasEqual;

        private readonly IUnarOperations _unarOperations;
        private readonly IBinarOperations _binarOperations;

        private Dictionary<char, Func<double, string>> _unarDictionary;
        private Dictionary<char, Func<double, double, string>> _binarDictionary;
        private Dictionary<char, Func<string>> _procDictionary;

        public Processor()
        {
            _unarOperations = new UnarOperations();
            _binarOperations = new BinarOperations();
            createDictionaries();
            initializeVariables();
        }

        public string ProcessValue(char key, string value)
        {
            _result = value;
            if (_unarDictionary.ContainsKey(key))
                _result = unarOperation(key, value);

            else if (_binarDictionary.ContainsKey(key))
                _result = binarOperation(key, value);

            else if (_procDictionary.ContainsKey(key))
                _result = procOperation(key, value);

            else if (key == '=')
                _result = equalOperation(value);

            return editResult(_result);
        }

        public void SetInputFlag()
        {
            _lastWasBinary = false;
            _lastWasEqual = false;
        }

        private void initializeVariables()
        {
            _result = null;
            _memory = null;
            _ans = 0f;
            _operator = '+';
            _lastWasBinary = false;
            _lastWasEqual = false;
        }

        private void createDictionaries()
        {
            _unarDictionary = new Dictionary<char, Func<double, string>>
                                 {
                                     {'M', _unarOperations.Negate},
                                     {'S', _unarOperations.Sine},
                                     {'K', _unarOperations.Cosine},
                                     {'T', _unarOperations.Tangens},
                                     {'Q', _unarOperations.Quadrat},
                                     {'R', _unarOperations.Root},
                                     {'I', _unarOperations.Invers}
                                 };

            _binarDictionary = new Dictionary<char, Func<double, double, string>>
                                 {
                                     {'+', _binarOperations.Plus},
                                     {'-', _binarOperations.Minus},
                                     {'*', _binarOperations.Multiply},
                                     {'/', _binarOperations.Devide},
                                 };

            _procDictionary = new Dictionary<char, Func<string>>
                                {
                                    {'O', this.reset},
                                    {'C', this.clear},
                                    {'P', this.put},
                                    {'G', this.get}

                                };
        }

        private string unarOperation(char key, string value)
        {
            _lastWasBinary = false;
            _lastWasEqual = false;
            return _unarDictionary[key].Invoke(Convert.ToDouble(value));
        }

        private string binarOperation(char key, string value)
        {
            string result = value;
            if (_lastWasBinary == false)
            {
                if (_lastWasEqual)
                    _ans = Convert.ToDouble(value);
                else
                {
                    result = _binarDictionary[_operator].Invoke(_ans, Convert.ToDouble(value));
                    _ans = Convert.ToDouble(result);
                }
                _lastWasBinary = true;
                _lastWasEqual = false;
            }
            _operator = key;
            return result;
        }

        private string procOperation(char key, string value)
        {
            _lastWasBinary = false;
            _lastWasEqual = false;
            return _procDictionary[key].Invoke();
        }

        private string equalOperation(string value)
        {
            double calcValue = Convert.ToDouble(value);
            if (_lastWasBinary)
                _ans = Convert.ToDouble(value);
            if (_lastWasEqual)
            {
                double temp = _ans;
                _ans = calcValue;
                calcValue = temp;
            }
            string result = _binarDictionary[_operator].Invoke(_ans, calcValue);

            _lastWasBinary = false;
            _lastWasEqual = true;
            _ans = Convert.ToDouble(value);
            return result;
        }

        private string reset()
        {
            initializeVariables();
            return "0";
        }

        private string clear()
        {
            return "0";
        }

        private string put()
        {
            _memory = _result;
            return _memory;
        }

        private string get()
        {
            return _memory;
        }

        private string editResult(string data)
        {
            string result = checkRange(data);
            if (result != "-E-") result = round(result);
            return result;
        }

        private string round(string data)
        {
            string result = addNumberRange(data);
            if (containsComma(result) && countNumbers(result) == MAX_NUMBER_LENGHT + 1)
            {
                int position = result.IndexOf(',');
                if (position != result.Length - 1)
                    return Math.Round(Convert.ToDouble(result), result.Length - position - 2).ToString();
                else
                    return result.Substring(0, result.Length - 1);
            }
            else
                return result;

        }

        private string checkRange(string data)
        {
            if (data != "-E-" && Convert.ToDouble(data) > MAX_NUMBER) return "-E-";
            else return data;
        }

        private string addNumberRange(string data)
        {
            string result = null;
            int numCounter = 0;
            foreach (char c in data)
            {
                result += c;
                if (isNumber(c)) numCounter++;
                if (numCounter == MAX_NUMBER_LENGHT + 1) break;
            }
            return result;
        }

        private int countNumbers(string data)
        {
            int numCounter = 0;
            foreach (char c in data)
                if (isNumber(c)) numCounter++;
            return numCounter;
        }

        private bool isNumber(char c)
        {
            if (c >= '0' && c <= '9') return true;
            else return false;
        }

        private bool containsComma(string data)
        {
            if (data.Contains(',')) return true;
            else return false;
        }
    }

    public interface IProcessor
    {
        string ProcessValue(char key, string value);
        void SetInputFlag();
    }

    class BinarOperations : IBinarOperations
    {
        public string Plus(double first, double second)
        {
            return (first + second).ToString();
        }

        public string Minus(double first, double second)
        {
            return (first - second).ToString();
        }

        public string Devide(double first, double second)
        {
            if (second != 0)
                return (first / second).ToString();
            else
                return "-E-";
        }

        public string Multiply(double first, double second)
        {
            return (first * second).ToString();
        }
    }

    public interface IBinarOperations
    {
        string Plus(double first, double second);
        string Minus(double first, double second);
        string Devide(double first, double second);
        string Multiply(double first, double second);
    }

    class UnarOperations : IUnarOperations
    {

        public string Negate(double data)
        {
            if (data.ToString()[0] == '-') return data.ToString().Substring(1);
            else return "-" + data;
        }

        public string Sine(double data)
        {
            return Math.Sin(data).ToString();
        }

        public string Cosine(double data)
        {
            return Math.Cos(data).ToString();
        }

        public string Tangens(double data)
        {
            if (Cosine(data) != "0")
                return Math.Tan(data).ToString();
            else
                return "-E-";
        }

        public string Quadrat(double data)
        {
            return Math.Pow(data, 2).ToString();
        }

        public string Root(double data)
        {
            if (data >= 0)
                return Math.Sqrt(data).ToString();
            else
                return "-E-";
        }

        public string Invers(double data)
        {
            if (Convert.ToDouble(data) != 0)
                return (1 / data).ToString();
            else return "-E-";
        }
    }

    public interface IUnarOperations
    {
        string Negate(double data);
        string Sine(double data);
        string Cosine(double data);
        string Tangens(double data);
        string Quadrat(double data);
        string Root(double data);
        string Invers(double data);
    }
}
