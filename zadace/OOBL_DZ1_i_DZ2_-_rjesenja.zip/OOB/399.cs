﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        int numOfDigits, numOfComas;
        char basicOperator, advancedOperator, nullCharacter, comaCharacter;
        string errorMessage, nullString, currentDisplayState, newDisplayState, resultString, savedDisplayState;
        double resultNumber, currentAdvancedNumber, previousNumber, currentNumber;
        bool negativeNumber, isEmptyScreen, basicCalculationEnabled, resultError;

        public Kalkulator()
        {
            numOfDigits = 0;
            numOfComas = 0;

            resultError = false;
            negativeNumber = false;
            isEmptyScreen = false;
            basicCalculationEnabled = true;

            errorMessage = "-E-";
            nullString = "0";
            currentDisplayState = nullString;
            newDisplayState = nullString;

            comaCharacter = ',';
            nullCharacter = '0';
            basicOperator = nullCharacter;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayState;
        }

        public void Press(char pressedDigit)
        {
            switch (pressedDigit)
            {
                case '1':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '2':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '3':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '4':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '5':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '6':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '7':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '8':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '9':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '0':
                    {
                        EnterDigit(pressedDigit);
                        break;
                    }
                case ',':
                    {
                        numOfComas++;
                        EnterDigit(pressedDigit);
                        break;
                    }
                case '+':
                    {
                        BasicCalculation();
                        basicOperator = pressedDigit;
                        break;
                    }
                case '-':
                    {
                        BasicCalculation();
                        basicOperator = pressedDigit;
                        break;
                    }
                case '*':
                    {
                        BasicCalculation();
                        basicOperator = pressedDigit;
                        break;
                    }
                case '/':
                    {
                        BasicCalculation();
                        basicOperator = pressedDigit;
                        break;
                    }
                case '=':
                    {
                        basicCalculationEnabled = true;
                        BasicCalculation();
                        Equals();
                        basicOperator = nullCharacter;
                        break;
                    }
                case 'M':
                    {
                        ChangeSignOfNumber();
                        break;
                    }
                case 'Q':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'R':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'S':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'K':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'T':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'I':
                    {
                        AdvancedCalculation(pressedDigit);
                        break;
                    }
                case 'P':
                    {
                        SaveDisplayState();
                        break;
                    }
                case 'G':
                    {
                        LoadDisplayState();
                        break;
                    }
                case 'C':
                    {
                        ClearScreen();
                        break;
                    }
                case 'O':
                    {
                        ResetCalculator();
                        break;
                    }
                default:
                    {
                        DisplayStateString(errorMessage);
                        break;
                    }
            }
        }

        public void EnterDigit(char pressedDigit)
        {
            if (numOfDigits == 0)
            {
                if (pressedDigit != nullCharacter && numOfComas == 0)
                {
                    newDisplayState = new string(pressedDigit, 1);
                }
                else if (numOfComas == 1)
                {
                    newDisplayState = currentDisplayState + pressedDigit;
                }
                if (newDisplayState == nullString) isEmptyScreen = true;
                else numOfDigits = 1;
            }
            else if (numOfDigits > 0 && numOfDigits <= 9)
            {
                if (pressedDigit != comaCharacter) numOfDigits++;
                newDisplayState = currentDisplayState + pressedDigit;
            }

            DisplayStateString(newDisplayState);
        }

        public void DisplayStateString(string newDisplayState)
        {
            currentDisplayState = newDisplayState;
            isEmptyScreen = false;
            basicCalculationEnabled = true;

            if (currentDisplayState == nullString) isEmptyScreen = true;
            if (currentDisplayState == errorMessage)
            {
                isEmptyScreen = true;
                basicCalculationEnabled = false;
            }
        }

        public double NumberFromDisplayState()
        {
            string currentDisplayState = GetCurrentDisplayState();
            double currentDisplayStateNumber = Convert.ToDouble(currentDisplayState);
            ResetCalculatorDisplayState();

            return currentDisplayStateNumber;
        }

        public void ResetCalculatorDisplayState()
        {
            numOfDigits = 0;
            numOfComas = 0;
            negativeNumber = false;
        }

        public void BasicCalculation()
        {
            if (basicCalculationEnabled)
            {
                previousNumber = currentNumber;
                currentNumber = NumberFromDisplayState();

                if (basicOperator == '+') resultNumber = previousNumber + currentNumber;
                else if (basicOperator == '-') resultNumber = previousNumber - currentNumber;
                else if (basicOperator == '*') resultNumber = previousNumber * currentNumber;
                else if (basicOperator == '/') resultNumber = previousNumber / currentNumber;
                else resultNumber = currentNumber;

                CheckResult();
                currentNumber = resultNumber;
                basicCalculationEnabled = false;

            }
        }

        public void AdvancedCalculation(char advancedOperator)
        {
            currentAdvancedNumber = NumberFromDisplayState();
            if (advancedOperator == 'Q') resultNumber = Math.Pow(currentAdvancedNumber, 2);
            else if (advancedOperator == 'R')
            {
                if (currentAdvancedNumber >= 0) resultNumber = Math.Sqrt(currentAdvancedNumber);
                else resultError = true;
            }
            else if (advancedOperator == 'S') resultNumber = Math.Sin(currentAdvancedNumber);
            else if (advancedOperator == 'K') resultNumber = Math.Cos(currentAdvancedNumber);
            else if (advancedOperator == 'T') resultNumber = Math.Tan(currentAdvancedNumber);
            else if (advancedOperator == 'I')
            {
                if (currentAdvancedNumber != 0) resultNumber = 1 / currentAdvancedNumber;
                else resultError = true;
            }
            else resultNumber = currentAdvancedNumber;

            CheckResult();
            currentAdvancedNumber = resultNumber;
            Equals();
        }

        public void CheckResult()
        {
            string resultNumberAsString = Convert.ToString(resultNumber);

            if (resultNumberAsString.Contains("-")) resultNumberAsString = resultNumberAsString.Remove(0, 1);

            if (resultNumberAsString.Contains(","))
            {
                string[] splitStringArray = resultNumberAsString.Split(',');
                resultNumberAsString = splitStringArray[0];
                int stringWithoutDecimalPlacesLength = resultNumberAsString.Length;

                if (stringWithoutDecimalPlacesLength > 0 && stringWithoutDecimalPlacesLength <= 10)
                {
                    int numOfDecimalPlaces = 10 - stringWithoutDecimalPlacesLength;
                    resultNumber = Math.Round(resultNumber, numOfDecimalPlaces);
                }
                else resultError = true;
            }
            else
            {
                int stringLength = resultNumberAsString.Length;
                if (stringLength > 10) resultError = true;
                currentDisplayState = resultNumberAsString;
            }
        }

        public void Equals()
        {
            if (!resultError)
            {
                resultString = Convert.ToString(resultNumber);
                DisplayStateString(resultString);
            }
            else
            {
                DisplayStateString(errorMessage);
                resultError = false;
            }
        }

        public void ChangeSignOfNumber()
        {
            if (!isEmptyScreen)
            {
                string oldDisplayStateString = GetCurrentDisplayState();
                string newDisplayStateString = nullString;

                if (negativeNumber) newDisplayStateString = oldDisplayStateString.Remove(0, 1);
                else newDisplayStateString = '-' + oldDisplayStateString;

                negativeNumber = !negativeNumber;
                DisplayStateString(newDisplayStateString);
            }
        }

        public void ClearScreen()
        {
            currentDisplayState = nullString;
            ResetCalculatorDisplayState();
        }

        public void ResetCalculator()
        {
            ClearScreen();
            savedDisplayState = "";
            advancedOperator = nullCharacter;
            basicOperator = nullCharacter;
        }

        public void SaveDisplayState()
        {
            savedDisplayState = GetCurrentDisplayState();
        }

        public void LoadDisplayState()
        {
            DisplayStateString(savedDisplayState);
        }
    }
}
