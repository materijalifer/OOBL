﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private enum State { digit, binaryOperator, unaryOperator };
        char[] digits = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        char[] binaryOperators = { '+', '-', '*', '/' };
        char[] unaryOperators = { 'M', 'T', 'S', 'K', 'Q', 'R', 'I' };
        char[] memoryOperators = { 'P', 'G' };

        //expression that hasn't been evaluated
        List<string> expression = new List<string>();

        //state of memory
        string memoryState = "";

        //state of display
        string displayState = "0";

        //member holds the last state (which type of
        //char was last get)
        State lastChar = State.digit;


        public void Press(char inPressedDigit)
        {
            //if inPressedDigit is a number
            if (digits.Contains(inPressedDigit) == true)
            {
                //if the last inPressedDigit was also number
                //functions concats the two numbers and 
                //displays them
                if (lastChar == State.digit)
                {
                    if (displayState == "0")
                    {
                        displayState = inPressedDigit.ToString();
                    }
                    else
                    {
                        displayState = RoundNumber(String.Concat(displayState, inPressedDigit.ToString()));
                    }
                }
                //if the last inPressedDigit was not a number
                //functions displays the digit 
                else
                {
                    displayState = inPressedDigit.ToString();
                }

                lastChar = State.digit;
            }
            //if inPressedDigit is a binary operator
            else if (binaryOperators.Contains(inPressedDigit))
            {
                //removes the zeroes at the end of a decimal number
                displayState = RemoveZeroes(displayState);

                //if last character was also binary operator
                //removes it and puts a new one
                if (lastChar == State.binaryOperator)
                {
                    expression.RemoveAt(expression.Count - 1);
                    expression.Add(inPressedDigit.ToString());
                }
                else
                {
                    expression.Add(displayState);

                    //if there is expression with binary operator that
                    //can be evaluated, evaluate
                    if (expression.Count == 3)
                    {
                        expression = EvaluateExpression(expression);
                        displayState = expression[0];
                    }

                    expression.Add(inPressedDigit.ToString());
                }

                lastChar = State.binaryOperator;
            }
            //if inPressedDigit is a unary operator
            else if (unaryOperators.Contains(inPressedDigit))
            {
                //executes operator on number in display state
                displayState = UnaryOpResult(displayState, inPressedDigit);

                //number can change sign while being written
                if (inPressedDigit != 'M')
                {
                    lastChar = State.unaryOperator;
                }
                else
                {
                    lastChar = State.digit;
                }
            }
            else if (inPressedDigit == '=')
            {
                displayState = RemoveZeroes(displayState);

                //evaluation of short entry operation (2+=)
                if (lastChar == State.binaryOperator)
                {
                    expression = ShortEntryEvaluation(expression);
                }
                else
                {
                    expression.Add(displayState);

                    //evaluation if expression has binary operator
                    if (expression.Count == 3)
                    {
                        expression = EvaluateExpression(expression);
                    }
                }

                displayState = expression[0];
                lastChar = State.digit;
            }
            else if (inPressedDigit == ',')
            {
                //concatenation with the rest of the number and rounding
                if (lastChar == State.digit)
                {
                    displayState = RoundNumber(String.Concat(displayState, inPressedDigit.ToString()));
                }
                // if ',' is the first character in a number add 0
                // ,1 -> 0,1
                else
                {
                    displayState = String.Concat("0", inPressedDigit.ToString());
                }

                lastChar = State.digit;
            }
            //Clear
            else if (inPressedDigit == 'C')
            {
                displayState = "0";
                lastChar = State.digit;
            }
            //Off/On
            else if (inPressedDigit == 'O')
            {
                displayState = "0";
                memoryState = "";
                expression.Clear();
                lastChar = State.digit;
            }
            //memory operators (Put, Get)
            else if (memoryOperators.Contains(inPressedDigit))
            {
                switch (inPressedDigit)
                {
                    case 'P':
                        memoryState = displayState;
                        break;

                    case 'G':
                        //if memory empty -> error
                        if (memoryState != "")
                        {
                            displayState = memoryState;
                        }
                        else
                        {
                            displayState = "-E-";
                        }
                        break;
                }
                lastChar = State.digit;
            }
            else
            {
                displayState = "-E-";
            }

        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        //rounds a number
        private string RoundNumber(string displayState)
        {
            bool isDecimal = displayState.Contains(',');
            bool isNegative = displayState.Contains('-');

            //displayState can be max 10, 11 or 12 depending on
            //weather there are decimal point and negative sign
            if (displayState.Length - ((isDecimal == true) ? 1 : 0) - ((isNegative == true) ? 1 : 0) > 10)
            {
                //if decimal point in first 10 digits round the number
                if (isDecimal == true)
                {
                    int index = displayState.IndexOf(',');
                    int maxDecimal = 10 + ((isNegative == true) ? 1 : 0) - index;
                    displayState = Math.Round(Convert.ToDouble(displayState), maxDecimal).ToString();
                }
                else
                {
                    displayState = "-E-";
                }
            }
            return displayState;
        }

        //removes zeroes and ',' if last in decimal number
        private string RemoveZeroes(string displayState)
        {
            if (displayState != "0")
            {
                int index = displayState.Length - 1;

                while (displayState[index] == '0' || displayState[index] == ',')
                {
                    displayState = displayState.Remove(index);
                    index -= 1;
                }
            }

            return displayState;
        }

        //evaluation of binary expression
        private List<string> EvaluateExpression(List<string> expression)
        {
            //any operation with "-E-" is an error
            if (expression.Contains("-E-") == false)
            {
                double result = 0;
                double operand1 = Convert.ToDouble(expression[0]);
                double operand2 = Convert.ToDouble(expression[2]);

                switch (expression[1])
                {
                    case "+":
                        result = operand1 + operand2;
                        break;

                    case "-":
                        result = operand1 - operand2;
                        break;

                    case "*":
                        result = operand1 * operand2;
                        break;

                    case "/":
                        if (operand2 != 0)
                        {
                            result = operand1 / operand2;
                        }
                        //error dividing with zero
                        else
                        {
                            expression.Clear();
                            expression.Add("-E-");
                            return expression;
                        }
                        break;
                }

                //puts the result as first operand of a expression
                expression.Clear();
                expression.Add(RoundNumber(result.ToString()));

                return expression;
            }
            else
            {
                expression.Clear();
                expression.Add("-E-");
                return expression;
            }
        }

        private List<string> ShortEntryEvaluation(List<string> expression)
        {
            expression.Add(expression[0]);
            expression = EvaluateExpression(expression);

            return expression;
        }

        //evaluating unary expressions
        private string UnaryOpResult(string displayState, char inPressedDigit)
        {
            //any oparation with "-E-" is error
            if (displayState != "-E-")
            {
                double result = Convert.ToDouble(displayState);

                switch (inPressedDigit)
                {
                    case 'M':
                        if (Math.Sign(result) != 0)
                        {
                            result *= -1;
                        }
                        break;

                    case 'S':
                        result = Math.Sin(result);
                        break;

                    case 'K':
                        result = Math.Cos(result);
                        break;

                    case 'T':
                        result = Math.Tan(result);
                        break;

                    case 'Q':
                        result = Math.Pow(result, 2);
                        break;

                    case 'R':
                        if (result >= 0)
                        {
                            result = Math.Sqrt(result);
                        }
                        else
                        {
                            return "-E-";
                        }
                        break;

                    case 'I':
                        if (result != 0)
                        {
                            result = 1 / result;
                        }
                        else
                        {
                            return "-E-";
                        }
                        break;
                }

                return RoundNumber(result.ToString());
            }
            else
            {
                return "-E-";
            }
        }
        }
}
