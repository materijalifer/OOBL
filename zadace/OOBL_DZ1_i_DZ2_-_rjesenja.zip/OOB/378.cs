﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
      
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {

         #region Privatne varijable
         private Dionica _dionica;
         private List<Dionica> _listaDionica = new List<Dionica>();
         private bool _postojanjeDionice = false;
         private Indeks _indeks;
         private List<Indeks> _listaIndeksa = new List<Indeks>();
         private bool _postojanjeIndeksa = false;
         private Portfelj _portfelj;
         private List<Portfelj> _listaPortfelja = new List<Portfelj>();
         private bool _postojanjePortfelja = false;
         #endregion

         #region Dionice metode

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice > 0)
             {
                 _dionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Cijena dionice ne smije biti negativna!");
             }

             if (_listaDionica.Any(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
             {
                 _postojanjeDionice = true;
                 throw new StockExchangeException("Već postoji dionica na burzi s tim imenom!");
             }

             if (_postojanjeDionice == false)
             {
                 _listaDionica.Add(_dionica);
                 
             }
             
         }


         /// <summary>
         /// Uz brisanje same dionice, briše se ista dionica u portfelju i indeksu 
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// 
         public void DelistStock(string inStockName)
         {
             try
             {
                 foreach (var indekse in _listaIndeksa)
                 {
                     if (indekse.DioniceIndeks.Any(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
                     {
                         _dionica =
                             indekse.DioniceIndeks.FirstOrDefault(
                                 dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower());
                        indekse.IndeksDionica.Remove(_dionica);
                     }
                     
                 }

                 foreach (var portfelji in _listaPortfelja)
                 {
                     string dionica =
                         portfelji.PortfeljDionice.FirstOrDefault(
                             dionice => dionice.Key.ToLower() == inStockName.ToLower()).Key;
                     if (dionica != null)
                     {
                        portfelji.PortfeljDionice.Remove(dionica);  
                     }
                     
                 }
                 _dionica = _listaDionica.FirstOrDefault(dionica => dionica.ImeDionice.ToLower() == inStockName.ToLower());
                 _listaDionica.Remove(_dionica);
             }
             catch (Exception)
             {
                 
                 throw new StockExchangeException("Bond, James Bond, ne postoji dionica!");
             }

         }

         public bool StockExists(string inStockName)
         {
             return _listaDionica.Any(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower());

         }

         public int NumberOfStocks()
         {
             return _listaDionica.Count;
         }

         /// <summary>
         /// Za određeno vrijeme namjesti cijenu dionice i sačuvaj staru cijenu
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <param name="inIimeStamp">Vrijeme za koje se postavlja cijena</param>
         /// <param name="inStockValue">Cijena</param>
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             foreach (var dionice in _listaDionica.Where(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
             {
                dionice.PovijestCijeneDionice.Add(dionice.VrijemeAktivnosti, dionice.CijenaDionice);
                dionice.VrijemeAktivnosti = inIimeStamp;
                dionice.CijenaDionice = inStockValue;
             }
         }

         /// <summary>
         /// Za određeno vrijeme vrati cijenu dionice.
         /// Vrijeme treba biti manje ili jednako ulaznom vremenu
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <param name="inTimeStamp">Vrijeme za koje se traći cijena</param>
         /// <returns></returns>
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
            
             decimal cijenaDionice = 0;

             foreach (
                 var dionice in _listaDionica.Where(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
             {
                 if (dionice.VrijemeAktivnosti <= inTimeStamp)
                 {
                     cijenaDionice = dionice.CijenaDionice;
                 }
                 else
                     foreach (var vrijeme in dionice.PovijestCijeneDionice.Keys.Where(vrijeme => vrijeme <= inTimeStamp))
                     {
                         cijenaDionice = dionice.PovijestCijeneDionice[vrijeme];
                     }
             }

             return cijenaDionice;

         }

         /// <summary>
         /// Pretraživanje history dictionarya dionice
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <returns>Početna cijena</returns>
         public decimal GetInitialStockPrice(string inStockName)
         {
             decimal cijena = 0;
             try
             {
                 foreach (var dionice in _listaDionica.Where(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
                 {
                     var list = dionice.PovijestCijeneDionice.Keys.ToList();
                     list.Sort();
                     cijena = dionice.PovijestCijeneDionice[list[0]];
                 }
             }
             catch (Exception)
             {
                 
                 throw new StockExchangeException("James Bond");
             }

             return cijena;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return (from dionice in _listaDionica where dionice.ImeDionice.ToLower() == inStockName.ToLower() select dionice.CijenaDionice).FirstOrDefault();
         }

         #endregion

         #region Index metode
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
             {
                 if (_listaIndeksa.Any(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower()))
                 {
                     throw new StockExchangeException("Već postoji indeks na burzi s tim imenom!");
                 }
                 _indeks = new Indeks(inIndexName, inIndexType);
                 _listaIndeksa.Add(_indeks);
             }
             else
             {
                 throw new StockExchangeException("Skyfall je brutalan film i tip indeksa smije biti samo Average ili Weighted");
             }
             

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             foreach (var indeksi in _listaIndeksa)
             {
                 if (indeksi.ImeIndeksa.ToLower() != inIndexName.ToLower()) continue;
                 foreach (var dionice in _listaDionica.Where(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
                 {
                     indeksi.IndeksDionica.Add(dionice);
                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             try
             {
                 if (_listaIndeksa.Any(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower()))
                 {
                     _indeks = _listaIndeksa.FirstOrDefault(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower());
                     _dionica =
                         _indeks.DioniceIndeks.FirstOrDefault(
                             dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower());
                     _indeks.IndeksDionica.Remove(_dionica);
                 }

             }
             catch (Exception)
             {
                 
                 throw new StockExchangeException("Greška");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _listaIndeksa.Where(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower()).SelectMany(indeksi => indeksi.DioniceIndeks).Any(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower());
         }


         /// <summary>
         /// Računanje vrijednosti indeksa po određenom tipu indeksa
         /// </summary>
         /// <param name="inIndexName">Ime indeksa</param>
         /// <param name="inTimeStamp">Vrijeme za koje se traži vrijednost</param>
         /// <returns>Vrijednost indexa</returns>
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal suma = 0;
             decimal indeksVrijednost = 0;
             decimal tezinskiFaktor = 0;

            foreach (var indeksi in _listaIndeksa.Where(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower()))
            {
                switch (indeksi.TipIndeksa)
                {
                    case IndexTypes.AVERAGE:
                        {
                            if (indeksi.DioniceIndeks.Count != 0)
                            {
                                suma += indeksi.DioniceIndeks.Sum(dionice => dionice.CijenaDionice);
                                indeksVrijednost = suma / indeksi.DioniceIndeks.Count;
                                indeksVrijednost = Math.Round(indeksVrijednost, 3);
                            }
                            else
                            {
                                indeksVrijednost = 0;
                            }

                        }
                        break;
                    case IndexTypes.WEIGHTED:
                        {
                            if (indeksi.DioniceIndeks.Count != 0)
                            {
                                suma += indeksi.DioniceIndeks.Sum(dionice => dionice.CijenaDionice * dionice.BrojDionica);
                                foreach (var dionice in indeksi.DioniceIndeks)
                                {
                                    tezinskiFaktor = (dionice.CijenaDionice * dionice.BrojDionica) / suma;
                                    indeksVrijednost += tezinskiFaktor * dionice.CijenaDionice;
                                }
                                indeksVrijednost = Math.Round(indeksVrijednost, 3); 
                            }
                            else
                            {
                                indeksVrijednost = 0;
                            }

                        }
                        break;
                }
            }
            
            return indeksVrijednost;
         }

         public bool IndexExists(string inIndexName)
         {
             return _listaIndeksa.Any(indeksi => indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return _listaIndeksa.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return (from indeksi in _listaIndeksa where indeksi.ImeIndeksa.ToLower() == inIndexName.ToLower() select indeksi.DioniceIndeks.Count).FirstOrDefault();
         }
         #endregion

         #region Portfelj metode
         public void CreatePortfolio(string inPortfolioID)
         {
             
             if (_listaPortfelja.Any(portfelji => portfelji.IDPortfelj == inPortfolioID))
             {
                 _postojanjePortfelja = true;
                 throw new StockExchangeException("Već postoji portfelj s tim IDjem!");
             }
             else
             {
                 _portfelj = new Portfelj(inPortfolioID);
                 _listaPortfelja.Add(_portfelj);
             }
         }

         /// <summary>
         /// Dodavanje dionice u portfelj. 
         /// Ako se dodaje već postojeća dionica onda se samo zbroji broj shareova dionica
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <param name="inStockName">ime dionice</param>
         /// <param name="numberOfShares">Broj dionica u portfelju</param>
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares > 0)
             {
                 foreach (var portfelj in _listaPortfelja.Where(portfelj => portfelj.IDPortfelj == inPortfolioID))
                 {
                     foreach (var dionice in _listaDionica.Where(dionice => dionice.ImeDionice.ToLower() == inStockName.ToLower()))
                     {
                         if (portfelj.PortfeljDionice.Keys.Contains(dionice.ImeDionice))
                         {
                             portfelj.PortfeljDionice[dionice.ImeDionice] += numberOfShares;
                         }
                         else
                         {
                             portfelj.PortfeljDionice.Add(dionice.ImeDionice, numberOfShares);  
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška pri dodavanju dionica u portfelj!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares > 0)
             {
                 foreach (var portfelj in _listaPortfelja.Where(portfelj => portfelj.IDPortfelj == inPortfolioID))
                 {
                     if (portfelj.PortfeljDionice.Keys.Contains(inStockName))
                     {
                         portfelj.PortfeljDionice[inStockName] = portfelj.PortfeljDionice[inStockName] - numberOfShares;
                         if (portfelj.PortfeljDionice[inStockName] <= 0)
                         {
                             portfelj.PortfeljDionice.Remove(inStockName);
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška pri dodavanju dionica u portfelj!");
             }
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (var portfelj in _listaPortfelja.Where(portfelj => portfelj.IDPortfelj == inPortfolioID))
             {
                 if (portfelj.PortfeljDionice.Keys.Contains(inStockName))
                 {
                     portfelj.PortfeljDionice.Remove(inStockName);
                 }
                 else
                 {
                     throw new StockExchangeException("Greška!");
                 }
             }
         }

         public int NumberOfPortfolios()
         {
             return _listaPortfelja.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return
                 (from portfelji in _listaPortfelja
                  where portfelji.IDPortfelj == inPortfolioID
                  select portfelji.PortfeljDionice.Keys.Count).SingleOrDefault();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _listaPortfelja.Any(portfelji => portfelji.IDPortfelj == inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return _listaPortfelja.Where(portfelji => portfelji.IDPortfelj == inPortfolioID).SelectMany(portfelji => portfelji.PortfeljDionice).Any(dionice => dionice.Key.ToLower() == inStockName.ToLower());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int brojDionica = 0;
             foreach (var portfelji in _listaPortfelja.Where(portfelji => portfelji.IDPortfelj == inPortfolioID))
             {
                 if (portfelji.PortfeljDionice.Keys.Contains(inStockName))
                 {
                     brojDionica = portfelji.PortfeljDionice[inStockName];
                 }
                 else
                 {
                     brojDionica = 0;
                 }
                
             }
             return brojDionica;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal vrijednostPortfelja = 0;

             try
             {
                 foreach (var portfelji in _listaPortfelja.Where(portfelji => portfelji.IDPortfelj == inPortfolioID))
                 {
                     foreach (var dionice in _listaDionica.Where(dionice => portfelji.PortfeljDionice.Keys.Contains(dionice.ImeDionice)))
                     {
                         if (dionice.VrijemeAktivnosti <= timeStamp)
                         {
                             vrijednostPortfelja += dionice.CijenaDionice * portfelji.PortfeljDionice[dionice.ImeDionice];
                         }
                         else
                         {
                             foreach (var vrijeme in dionice.PovijestCijeneDionice.Keys.Where(vrijeme => vrijeme <= timeStamp))
                             {
                                 vrijednostPortfelja += dionice.PovijestCijeneDionice[vrijeme] * portfelji.PortfeljDionice[dionice.ImeDionice];
                             }
                         }
                     }
                 }
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Greška");
             }

             return vrijednostPortfelja;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal promjenaPortfetlja = 0;
             decimal pocetna = 0;
             decimal zavrsna = 0;
             
             try
             {
                 foreach (var portfelji in _listaPortfelja.Where(portfelji => portfelji.IDPortfelj == inPortfolioID))
                 {
                     DateTime pocetak = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                     DateTime kraj = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

                     zavrsna = this.GetPortfolioValue(portfelji.IDPortfelj, kraj);
                     pocetna = this.GetPortfolioValue(portfelji.IDPortfelj, pocetak);
                 }
                 promjenaPortfetlja = Math.Round(Math.Abs((zavrsna-pocetna)/pocetna * 100), 3);
             }
             catch (Exception)
             {
                 
                 throw new StockExchangeException("Bond, James Bond");
             }

             return promjenaPortfetlja;
         }
        #endregion
     }

     #region Dionica, indeks i portfelj klase

    /// <summary>
    /// Dionica - Ime, broj dionica, cijena, vrijeme aktivnosti, ime nije sensitive tj. aBc i AbC su iste dionice.
    ///  Sadrži Dictionary da za određeno vrijeme prati history cijena
    /// </summary>
     public class Dionica
     {
         private string _ime;
         private Decimal _cijenaDionice;
         private long _brojDionica;
         private DateTime _vrijemeAktivno;
         public Dictionary<DateTime, decimal> PovijestCijeneDionice = new Dictionary<DateTime, decimal>();

         public Dionica(string ime, long brojDionica, Decimal cijenaDionice, DateTime vrijemeAkt)
         {
             this._ime = ime;
             this._brojDionica = brojDionica;
             this._cijenaDionice = cijenaDionice;
             this._vrijemeAktivno = vrijemeAkt;
         }

         public string ImeDionice
         {
             get { return _ime; }
             set { _ime = value; }
         }

         public Decimal CijenaDionice
         {
             get { return _cijenaDionice; }
             set { _cijenaDionice = value; }
         }

         public long BrojDionica
         {
             get { return _brojDionica; }
             set { _brojDionica = value; }
         }

         public DateTime VrijemeAktivnosti
         {
             get { return _vrijemeAktivno; }
             set { _vrijemeAktivno = value; }
         }
     }

    /// <summary>
    /// Indeks - ime i tip indeksa. Ime nije sensitive tj. Abc i aBC su isti indeksi.
    ///  Sadrži listu dionica koje može imati a koje su na burzi
    /// </summary>
     public class Indeks
     {
         private string _ime;
         private IndexTypes _tip;
         public List<Dionica> IndeksDionica = new List<Dionica>();

         public Indeks(string ime, IndexTypes tip)
         {
             this._ime = ime;
             this._tip = tip;
         }

         public string ImeIndeksa
         {
             get { return _ime; }
             set { _ime = value; }
         }

         public IndexTypes TipIndeksa
         {
             get { return _tip; }
             set { _tip = value; }
         }

         public List<Dionica> DioniceIndeks
         { get { return IndeksDionica; } }
     }

    /// <summary>
    /// Portfelj - ID samo - sensitive Abc i aBC su različiti portfelji. 
    /// Sadrži Dictionary koji predstavlja zapravo repository određenih dionica za određeni portfelj
    /// </summary>
     public class Portfelj
     {
         private string _ID;
         public Dictionary<string, int> PortfeljDionice = new Dictionary<string, int>();

         public Portfelj(string id)
         {
             this._ID = id;
         }

         public string IDPortfelj
         {
             get { return this._ID; }
             set { this._ID = value; }
         }

     }
#endregion
}
