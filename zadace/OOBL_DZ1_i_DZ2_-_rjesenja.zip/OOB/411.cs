﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char lastDigit;

        private string lastNumber = "";
        private string CurrentDisplayState = "0";

        private List<decimal> operands = new List<decimal>();
        private List<Operator> operators = new List<Operator>();

        private string savedNumber = "";

        public void Press(char inPressedDigit)
        {
            if (CheckIfOperator(inPressedDigit))
            {
                Operator currentOperator = new Operator(inPressedDigit);
                Operator previousOperator = new Operator(lastDigit);
                if (CheckIfOperator(lastDigit) && previousOperator.isBinary())
                {
                    AddOperand();
                    if (!currentOperator.isBinary())
                    {
                        decimal res = operands.ElementAt(operators.Count - 1);
                        SetCurrentDisplayState(EvaluateUnaryOperations(res, currentOperator).ToString("G29"));
                    }
                    else // ignore previous binary operator
                    {
                        operators.RemoveAt(operators.Count - 1);
                        operators.Add(currentOperator);
                    }  
                }
                else
                {
                    if (!currentOperator.isBinary() && currentOperator.GetOper() == 'M')
                    {
                        changeLastNumberSign();
                    }
                    else if (!currentOperator.isBinary())
                    {
                        AddOperand();
                        decimal operand1 = operands.ElementAt(operands.Count - 1);
                        operands.RemoveAt(operands.Count - 1);
                        decimal res = EvaluateUnaryOperations(operand1,currentOperator);
                        operands.Add(res);
                        SetCurrentDisplayState(res.ToString("G29"));
                    }
                    else
                    {
                        AddOperand();
                        operators.Add(currentOperator);
                    }
                }
            }
            else if (CheckIfSpecialOperation(inPressedDigit))
            {
                EvaluateSpecialOperation(inPressedDigit);
            }
            else  // number or commma pressed
            {
                if (lastNumber == "" && inPressedDigit == ',')
                    lastNumber = "0,";
                else
                    lastNumber += inPressedDigit.ToString();
               
                SetCurrentDisplayState(lastNumber);
            }

            lastDigit = inPressedDigit;
        }


        public string GetCurrentDisplayState()
        {
            return this.CurrentDisplayState;
        }



        private void changeLastNumberSign()
        {
            if (lastNumber.Length > 0) 
            {
                if (lastNumber[0] == '-')
                    lastNumber = lastNumber.Substring(1);
                else
                    lastNumber = "-" + lastNumber;
            }
            SetCurrentDisplayState(lastNumber);
        }
        

        private void SetCurrentDisplayState(string CurrentState)
        {
            decimal state = Convert.ToDecimal(CurrentState);
            double numberOfDigits;
            if ( Math.Abs(state) < 1  )
                numberOfDigits = 1;
            else
                numberOfDigits = Math.Floor(Math.Log10(Math.Abs((double)state)) + 1);

            if (numberOfDigits > 10)
                CurrentDisplayState = "-E-";
            else
            {
                int precision = 10 - (int)numberOfDigits;
                state = Math.Round(state, precision);
                CurrentDisplayState = state.ToString("G29");
            }
        }


        private void EvaluateSpecialOperation(char operation)
        {
            switch(operation)
            {
                case '=':
                    AddOperand();
                    EvaluateExpression();
                    break;
                case 'O':
                    operands.Clear();
                    operators.Clear();
                    SetCurrentDisplayState("0");
                    lastNumber = "";
                    savedNumber = "";
                    break;
                case 'C':
                    lastNumber = "";
                    SetCurrentDisplayState("0");
                    break;
                case 'P':
                    savedNumber += lastDigit;
                    break;
                case 'G':
                    lastNumber = savedNumber;
                    SetCurrentDisplayState(savedNumber);
                    break;
            }
        }



        private void AddOperand()
        {
            if (!lastNumber.Equals(""))
            {
                decimal res;
                if (Decimal.TryParse(lastNumber, out res))
                {
                    operands.Add(res);
                }
                lastNumber = "";
            }
        }


        private void EvaluateExpression()
        {
            while(operators.Count > 0)
            {
                Operator op = operators.ElementAt(0);
                if (op.isBinary())
                {
                    decimal operand1 = operands.ElementAt(0);
                    operands.RemoveAt(0);
                    decimal operand2 ;
                    if (operands.Count == 0)
                        operand2 = operand1;
                    else
                    {
                        operand2 = operands.ElementAt(0);
                        operands.RemoveAt(0);
                    }
                    decimal res = EvaluateBinaryOperations(operand1,operand2, op);
                    operators.RemoveAt(0);
                    if(res!= Decimal.MaxValue)
                        operands.Insert(0, res);
                }
                else
                {
                    decimal operand1 = operands.ElementAt(0);
                    operands.RemoveAt(0);
                    decimal res = EvaluateUnaryOperations(operand1,op);
                    operators.RemoveAt(0);
                    if(res != Decimal.MaxValue)
                        operands.Insert(0,res);
                }
            }
            if(operands.Count > 0)
                SetCurrentDisplayState(operands.ElementAt(0).ToString("G29"));
        }



        private decimal EvaluateBinaryOperations(decimal operand1, decimal operand2, Operator o)
        {
            decimal res = 0.0m;
            switch(o.GetOper())
            {
                case '+':
                    res = operand1 + operand2;
                    break;
                case '-':
                    res = operand1 - operand2;
                    break;
                case '*':
                    res = operand1 * operand2;
                    break;
                case '/':
                    try
                    {
                        res = operand1 / operand2;
                    }
                    catch
                    {
                        CurrentDisplayState = "-E-";
                        res = Decimal.MaxValue;
                    }
                    break;
            }
            return res;
        }




        private decimal EvaluateUnaryOperations(decimal operand, Operator o)
        {
            decimal res = 0.0m;
            switch (o.GetOper()) 
            { 
                case 'S': // sin
                    res = new decimal( Math.Sin((double)operand));
                    break;
                case 'K': // cos
                    res = new decimal(Math.Cos((double)operand));
                    break;
                case 'T': // tan
                    res = new decimal(Math.Tan((double)operand));
                    break;
                case 'Q': // square
                    res = new decimal(Math.Pow((double)operand, 2.0));
                    break;
                case 'M': //change sign
                    res = new decimal((-1.0) * (double)operand);
                    break;
                case 'R': // root
                    try
                    {
                        res = new decimal(Math.Sqrt((double)operand));
                    }
                    catch
                    {
                        CurrentDisplayState = "-E-";
                        res = Decimal.MaxValue;
                    }
                    break;
                case 'I':
                    try
                    {
                        res = new decimal(1.0 / (double)operand);
                    }
                    catch
                    {
                        CurrentDisplayState = "-E-";
                        res = Decimal.MaxValue;
                    }
                    break;
            }
            return res;
        }


        private bool CheckIfOperator(char digit)
        {
            if (digit == '+' || digit == '-' || digit == '*' || digit == '/' || digit == 'M' ||
                digit == 'S' || digit == 'K' || digit == 'T' || digit == 'Q' || digit == 'R' || digit == 'I')
                return true;
            return false;
        }

        private bool CheckIfSpecialOperation(char digit) 
        {
            if (digit == '=' || digit == 'C' || digit == 'O' || digit == 'P' || digit == 'G')
                return true;
            return false;
        } 
    }

    public class Operator
    {
        private char oper;
      
        public Operator(char Operator)
        {
            this.oper = Operator;
        }

        public char GetOper()
        {
            return this.oper;
        }

        public bool isBinary()
        {
            if ( oper=='+' || oper=='-' || oper=='*' || oper=='/')
                return true;
            return false;
        }
    }
}
