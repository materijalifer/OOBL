﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        const int velicinaEkrana=10; //maksimalno 10 znamenki na ekranu + predznak + zarez

        Operand lijevi = null;
        Operand desni = null;
        Operand memorija = null;
        char binarniOperator ='\0';
        string ekran;
        char unarniOperator = '\0';

        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            ekran = "0";
            lijevi = new Operand();
        }
    
        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            { 
                //plus
                case '+':
                    if (desni == null || unarniOperator == '\0')
                        jedanOperand('+');
                    else
                        dvaOperanda('+');
                    break;

                //minus
                case '-':
                    if (desni == null || unarniOperator == '\0')
                        jedanOperand('-');
                    else
                        dvaOperanda('-');
                    break;

                //puta
                case '*':
                    if (desni == null || unarniOperator == '\0')
                        jedanOperand('*');
                    else
                        dvaOperanda('*');
                    break;

                //podjeljeno
                case '/':
                    if (desni == null || unarniOperator == '\0')
                        jedanOperand('/');
                    else
                        dvaOperanda('/');
                    break;


                //jednako
                case '=':
                    if (binarniOperator == '\0')
                    {
                        ekran = "0";
                        break;
                    }
                    if(unarniOperator == '\0')
                    {
                        if (binarniOperator != '\0')
                        {
                            switch (binarniOperator)
                            { 
                                case '+':
                                    lijevi.zbroji(lijevi.getBroj());
                                    break;
                                case '-':
                                    lijevi.oduzmi(lijevi.getBroj());
                                    break;
                                case '*':
                                    lijevi.pomnozi(lijevi.getBroj());
                                    break;
                                case '/':
                                    lijevi.podijeli(lijevi.getBroj());
                                    break;
                                default:
                                    break;
                            }
                        }
                        postaviEkran(lijevi);
                    }
                    else
                    {
                        switch (binarniOperator)
                        { 
                            case '+':
                                lijevi.zbroji(desni.getBroj());
                                desni = null;
                                break;

                            case '-':
                                lijevi.oduzmi(desni.getBroj());
                                desni = null;
                                break;

                            case '*':
                                lijevi.pomnozi(desni.getBroj());
                                desni = null;
                                break;

                            case '/':
                                lijevi.podijeli(desni.getBroj());
                                desni = null;
                                break;

                            default:
                                break;
                        }
                        binarniOperator = '\0';

                        int brojZnamenki = 0;
                        string provjera = lijevi.getBroj().ToString();
                        foreach (char a in provjera)
                            if (char.IsDigit(a))
                                brojZnamenki++;
                        if (brojZnamenki > 10)
                            ekran = "-E-";
                        else
                            postaviEkran(lijevi);
                    }
                    break;

                //zarez
                case ',':

                    if (desni == null)
                        lijevi.zarez();
                    else
                        desni.zarez();
                    break;

                //promjena predznaka
                case 'M':
                    if (desni == null)
                    {
                        lijevi.promijeniPredznak();
                        postaviEkran(lijevi);
                    }
                    else
                    {
                        desni.promijeniPredznak();
                        postaviEkran(desni);
                    }
                    break;

                case 'S':
                    if (desni == null)
                    {
                        lijevi.sinus();
                        postaviEkran(lijevi);
                    }
                    else
                    {
                        desni.sinus();
                        postaviEkran(desni);
                    }
                        break;

                case 'K':
                        if (desni == null)
                        {
                            lijevi.kosinus();
                            postaviEkran(lijevi);
                        }
                        else
                        {
                            desni.kosinus();
                            postaviEkran(desni);
                        }
                    break;

                case 'T':
                    if (desni == null)
                    {
                        lijevi.tangens();
                        postaviEkran(lijevi);
                    }
                    else
                    {
                        desni.tangens();
                        postaviEkran(desni);
                    }
                    break;

                case 'Q':
                    if (desni == null || unarniOperator == '\0')
                    {
                        lijevi.kvadriraj();
                        postaviEkran(lijevi);
                        desni = new Operand();
                    }
                    else
                    {
                        desni.kvadriraj();
                        postaviEkran(desni);
                    }
                    break;

                case 'R':
                    if (desni == null)
                    {
                        lijevi.korijen();
                        postaviEkran(lijevi);
                    }
                    else
                    {
                        desni.korijen();
                        postaviEkran(desni);
                    }
                    break;

                case 'I':
                    if (desni == null)
                    {
                            lijevi.inverz();
                            postaviEkran(lijevi);
                    }
                    else
                    {
                        desni.inverz();
                        postaviEkran(desni);
                    }
                    break;

                case 'P':
                    memorija = new Operand();
                    if (!ekran.Equals("-E-"))
                        memorija.setBroj(double.Parse(ekran));
                    break;

                case 'G':
                    if (memorija != null)
                    {
                        if (desni == null)
                        {
                            lijevi = memorija;
                            postaviEkran(lijevi);
                        }
                        else
                        {
                            desni = memorija;
                            postaviEkran(desni);
                        }

                    }
                    break;

                case 'C':
                    ekran = "0";
                    break;

                case 'O':
                    if (lijevi != null) //kalkulator je upaljen
                    {
                        desni = null;
                        lijevi = null;
                        memorija = null;
                        binarniOperator = '\0';
                    }
                    else
                    {
                        lijevi = new Operand();
                        ekran = "0";
                        binarniOperator = '\0';
                    }
                    break;

                case '0':
                    upisZnamenke(0);
                    break;

                case '1':
                    upisZnamenke(1);
                    break;
                    
                case '2':
                    upisZnamenke(2);
                    break;
                    
                case '3':
                    upisZnamenke(3);
                    break;
                    
                case '4':
                    upisZnamenke(4);
                    break;
                    
                case '5':
                    upisZnamenke(5);
                    break;
                    
                case '6':
                    upisZnamenke(6);
                    break;
                    
                case '7':
                    upisZnamenke(7);
                    break;
                    
                case '8':
                    upisZnamenke(8);
                    break;

                case '9':
                    upisZnamenke(9);
                    break;

                default:
                    ekran = "-E-";
                    break;
            }
        }

        private void upisZnamenke(int znamenka)
        {
            if (binarniOperator == '\0')
            {
                if (lijevi != null & lijevi.getBroj() != 0)
                {
                    desni = null;
                    lijevi = new Operand();
                }
                lijevi.dodajZnamenku(znamenka);
                postaviEkran(lijevi);
                binarniOperator = 'D';
            }
            else if (desni == null)
            {
                lijevi.dodajZnamenku(znamenka);
                postaviEkran(lijevi);
            }
            else
            {
                unarniOperator = 'D';
                desni.dodajZnamenku(znamenka);
                postaviEkran(desni);
            }
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }

        private void jedanOperand(char binOperator)
        {
            desni = new Operand();
            postaviEkran(lijevi);
            binarniOperator = binOperator;
        }

        private void dvaOperanda(char binOperator)
        {
                switch (binarniOperator)
                {
                    case '+':
                        lijevi.zbroji(desni.getBroj());
                        break;

                    case '-':
                        lijevi.oduzmi(desni.getBroj());
                        break;

                    case '*':
                        lijevi.pomnozi(desni.getBroj());
                        break;

                    case '/':
                        lijevi.podijeli(desni.getBroj());
                        break;

                    case 'Q':
                        desni.kvadriraj();
                        break;

                    default:
                        break;
                }
                postaviEkran(lijevi);
                desni = new Operand();
                binarniOperator = binOperator;
                unarniOperator = '\0';
        }

        /// <summary>
        /// postavlja ispis na ekranu
        /// </summary>
        /// <param name="operand"></param>
        private void postaviEkran(Operand operand)
        {
            if(double.IsInfinity(operand.getBroj()))
            {
                ekran = "-E-";
                return;
            }

            double broj = operand.getBroj();

            if (broj == (long)broj) //broj je cijeli
            {
                ekran = broj.ToString();

                //ako je broj negativan, na ekran stane 11 znakova (minus)
                int dodatniZnak=0;  
                if(broj<0)
                    dodatniZnak ++;

                if (ekran.Length > velicinaEkrana + dodatniZnak)
                {
                    int razlika = ekran.Length - (velicinaEkrana + dodatniZnak);
                    operand.setBroj(operand.getBroj() % (10 * razlika)); // zaokruživanje cijelog broja;
                    broj = operand.getBroj();
                }
            }
            else //broj je decimalan
            {
                ekran = broj.ToString();

                // rezanje trailing nula
                ekran = reziNule(ekran);

                //ako je broj negativan, na ekran stane 12 znakova (minus i točka)
                int dodatniZnak=1;  
                if(broj<0)
                    dodatniZnak ++;

                if (ekran.Length > velicinaEkrana + dodatniZnak)
                {
                    int razlika = ekran.Length - (velicinaEkrana + dodatniZnak);
                    string[] splitani = ekran.Split(',');

                    if (razlika!=0 && razlika < splitani[1].Length)
                    {
                        int brojDecimala = splitani[1].Length - razlika;
                        operand.setBroj((double)Math.Round(broj, brojDecimala));
                        broj = operand.getBroj();
                        ekran = broj.ToString();
                        ekran = reziNule(ekran);
                    }
                }
            }
        }

        /// <summary>
        /// vraća string koji pokazuje broj bez trailing nula
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private string reziNule(string str)
        {
            int i = str.Length - 1;
            while (str[i] == 0)
            {
                str = str.Substring(0, str.Length - 1);
                i--;
            }
            return str;
        }
    }



    
}

class Operand
{
    double broj;
    int potencija = 0;
    bool desnoOdZareza = false;

    public Operand()
    {
        broj = 0;
        potencija = 0; //sljedeća znamenka se množi s 10^2
        desnoOdZareza = false;
    }

    public void dodajZnamenku(int znamenka)
    {
        //provjera da li broj ima više od 10 znamenaka
        int brojZnamenki = 0;
        string provjera = broj.ToString();
        foreach (char a in provjera)
            if (char.IsDigit(a))
                brojZnamenki++;
        if (brojZnamenki == 10)
            return;

        if (potencija > 0)
            if (broj >= 0)
                broj = znamenka + broj * 10;
            else
                broj = -(znamenka + (-broj * 10));
        else if (potencija == 1)
            broj = znamenka;
        else
            if (broj >= 0)
                broj += znamenka * (double)Math.Pow(10, potencija);
            else
                broj = -(-broj + znamenka * (double)Math.Pow(10, potencija));

        if (desnoOdZareza)
            potencija--;
        else
            potencija++;
    }

    public void zarez()
    {
        if (!desnoOdZareza)
        {
            potencija = -1;
            desnoOdZareza = true;
        }
    }

    public void setBroj(double broj)
    {
        this.broj = broj;
    }

    public double getBroj()
    {
        return broj;
    }

    public bool isdouble()
    {
        if (desnoOdZareza)
            return true;
        else
            return false;
    }

    public void promijeniPredznak()
    {
        broj = -1 * broj;
    }

    public void zbroji(double pribrojnik)
    {
        broj += pribrojnik;
    }

    public void oduzmi(double pribrojnik)
    {
        broj -= pribrojnik;
    }

    public void pomnozi(double mnozitelj)
    {
        broj = broj * mnozitelj;
    }

    public void podijeli(double djelitelj)
    {
        broj = broj / djelitelj;
    }

    public void sinus()
    {
        broj = (double)Math.Sin(broj);
    }

    public void kosinus()
    {
        broj = (double)Math.Cos(broj);
    }

    public void tangens()
    {
        broj = (double)Math.Tan(broj);
    }

    public void kvadriraj()
    {
        broj = (double)Math.Pow(broj, 2);
    }

    public void korijen()
    {
        broj = (double)Math.Sqrt(broj);
    }

    public void inverz()
    {
        broj = 1 / broj;
    }
}
