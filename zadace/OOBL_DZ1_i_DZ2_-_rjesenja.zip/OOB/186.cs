﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    public class Kalkulator:ICalculator
    {
        private  string broj ;
        private double rezultat;
        private double memorija;
        private char operacija;
        private string nazivOperacije;
        private string pamtiBroj;
        private double spremanjeRezultataUMemoriju;
        private string brisiEkran;

        private bool zapamcenBrojZaPonavljanjeRadnje;
        private bool uneseniBrojBool;
        private bool unesenaOperacijaBool;
        private bool nijeUnesenaZnamenka;   //to je zastavica za 4**...
        private bool zarezUbroju;
        private bool minusUbroju;
        private bool prekoracenjeURacunanju;

        public void Press(char inPressedDigit)
        {
            int tmp;
            if(Int32.TryParse(inPressedDigit.ToString(), out tmp))
            {
                if (SljedecaZnamenka())
                {
                    broj += tmp.ToString();      //pisu se znamenke ukoliko je unesena znamenka u varijablu broj
                    uneseniBrojBool = true;
                    if (broj.Length > 1)
                    {
                        ProvjeriBrojPocetnihNula();
                    }
                    nijeUnesenaZnamenka = true;                  
                }        
            }
            else if (rezultat == 0 && broj == null && inPressedDigit!=',')
            {
                if (inPressedDigit == '-')
                {
                    broj = inPressedDigit.ToString();
                    minusUbroju = true;                          //provjerava se dali postoji negativan broj, zastavica se dize i funkcija sljedeca znamenka je koristi
                }
            }
            else if (inPressedDigit == ',')
            {
                broj += inPressedDigit.ToString();
                if (broj.Length == 1)
                {
                    broj = "0,";
                }
                zarezUbroju = true;                             //provjerava se dali postoji decimalni zarez, zastavica se dize i funkcija sljedeca znamenka je koristi
            }
         else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '='|| inPressedDigit =='M' || inPressedDigit=='*'|| 
                inPressedDigit=='S' || inPressedDigit=='K'|| inPressedDigit=='T' || inPressedDigit=='Q'|| inPressedDigit=='R' || inPressedDigit=='/'
                || inPressedDigit=='P' || inPressedDigit=='C' || inPressedDigit=='G' || inPressedDigit=='O')
            {
                foreach (char znak in broj)
                {
                    if (znak == ',')
                    {
                        ProvjeriZnamekeIzaDecZareza();                  //ide provjerit dali su nule iza , pa da ih makne njih i zarez
                    }
                }
                if (operacija == '\0')
                {
                    Racunaj(inPressedDigit);
                }
                zapamcenBrojZaPonavljanjeRadnje = false;
                if (operacija == inPressedDigit && broj=="")
                {
                    zapamcenBrojZaPonavljanjeRadnje = true;                   
                }
                if (inPressedDigit == 'M' && operacija != 'M'&& broj!="")
                {
                    string rez = rezultat.ToString() + broj;         //nadodano
                    rezultat = Convert.ToDouble(rez);
                }
                if (inPressedDigit == 'S'&& operacija!='\0')
                {
                    MjenjajBrojUSinus();
                }
                if (inPressedDigit == 'K'&&operacija!='\0')
                {
                    MjenjajBrojUKosinus();
                }
                if (inPressedDigit == 'T'&& operacija!='\0')
                {
                    MjenjajBrojUTanges();
                }
                if (inPressedDigit == 'Q' && operacija != '\0')
                {
                    MjenjajBrojUKvadrat();
                }
                if (inPressedDigit == 'R' && operacija != '\0')
                {
                    MjenjajBrojUKorijen();
                }
             
                Racunaj(operacija);
                operacija = inPressedDigit;
                unesenaOperacijaBool = true;
                zarezUbroju = false;                        //zastavica za decimalni broj se skida jer dolazi novi broj nakon tog znaka
                minusUbroju = false;                                     //zastavica za minus u broju se skida jer dolazi novi broj nakon tog znaka
            }          
        }
        public void ProvjeriZnamekeIzaDecZareza()     //ako pise 1.000 to je 1
        {
            int tmpbr = (Int32)Convert.ToDouble(broj);
            int duzinaSaDecimalnom= tmpbr.ToString().Length+1;
            int duzinaBroja = broj.Length;
            int brojac = 0;
            for (int i = duzinaSaDecimalnom; i < duzinaBroja; i++)
            {
                if (broj[i] == '0')
                {
                    brojac++;
                }
                if (brojac == duzinaBroja - duzinaSaDecimalnom)
                {
                    broj = tmpbr.ToString();
                } 
            }
            int ZadnjaZnamenka=broj.Length-1;
            char pamtiZadnjuZnamenku;
            int brojac1 = 0;
            for (int j = ZadnjaZnamenka; j > 0; j--)
            {
                pamtiZadnjuZnamenku = broj[j];
                if ( pamtiZadnjuZnamenku=='0')
                {
                    brojac1++;
                }
 
            }
            if (brojac1 != 0)
            {
                broj = broj.Remove(broj.Length - brojac1);
            }
        }        
        public void Racunaj(char znakOperacije)
        {
            
            if (znakOperacije == '+')
            {
                Zbroji();
                    
            }
            else if (znakOperacije == '-')
            {
                Oduzmi();
            }
            else if (znakOperacije == '=')
            {
                if (unesenaOperacijaBool == false)
                {
                    rezultat = Convert.ToDouble(broj);
                }
            }
            else if (znakOperacije == 'M')
            {
                string tmp = "-";
                tmp += broj;
                int duzinaBroja = tmp.Length;
                if (tmp[0] == '-' && tmp[1] == '-')
                {
                    broj = "";
                    for (int i = 2; i < duzinaBroja; i++)
                    {
                        broj += tmp[i];
                    }
                }
                else 
                {
                    broj = tmp;
                    if (broj.Length > 12)
                    {
                        double brojUdouble = ZaokruziDecimalniBroj(Convert.ToDouble(broj));
                        broj = brojUdouble.ToString();
                    }
                }
                rezultat = Convert.ToDouble(broj);
                broj = "";
            }
            else if (znakOperacije == '*')
            {
                Mnozi();
            }
            else if (znakOperacije == 'S')
            {
                Sinus();
            }
            else if (znakOperacije == 'K')
            {
                Kosinus();
            }
            else if (znakOperacije == 'T')
            {
                Tanges();
            }
            else if (znakOperacije == 'Q')
            {
                Kvadriraj();
            }
            else if (znakOperacije == 'R')
            {
                Korijenuj();
            }

            else if (znakOperacije == '/')
            {
                Djeli();
            }
            else if (znakOperacije == 'P')
            {
                SpremiUMemoriju();
            }
            else if (znakOperacije == 'C')
            {
                BrisanjeEkrana();
            }
            else if (znakOperacije == 'G')
            {
                DohvatiMemoriju();
            }
            else if (znakOperacije == 'O')
            {
                Resetiraj();
            }
            else if (znakOperacije == '\0')
            {
                return;
            }
        }
           //samo gleda dali je unesen prvi broj, da ga ne zsapise kao-x nego kao x
        public double ZaokruziDecimalniBroj(double brojZaProvjerit)                                 //broj koji je decimalan i ima vise od 10 znamenki zaokruzuje
        {
            int brojDuzine = 0;
            string reztmp = brojZaProvjerit.ToString();
            if (reztmp[0] == '-')
            {
                brojDuzine = 12;                            // ako ima minus broj ima 12 znamenaka, ako ne 11
            }
            else 
            {
                brojDuzine = 11;
            }
            foreach (char znamenka in reztmp)
            {
               
                if (znamenka == ',')
                {
                    int brojPrijeZareza;
                    brojPrijeZareza = (Int32)brojZaProvjerit;
                    if (brojPrijeZareza.ToString().Length > 11)
                    {
                        return 000;
                    }
                    char prviZnak = reztmp[0];
                    if (prviZnak == '-')
                    {
                        string brojPrijeZarezastr = brojPrijeZareza.ToString();
                        int brojDecimalnihMjesta = brojDuzine - brojPrijeZarezastr.Length - 1-1;
                        brojZaProvjerit = Math.Round(brojZaProvjerit, brojDecimalnihMjesta);

                    }
                    else
                    {
                        string brojPrijeZarezastr = brojPrijeZareza.ToString();
                        int brojDecimalnihMjesta = brojDuzine - brojPrijeZarezastr.Length - 1;
                        brojZaProvjerit = Math.Round(brojZaProvjerit, brojDecimalnihMjesta);
                    }
                }
            }
            return brojZaProvjerit;
        }

        public int provjeriVelicinuBroja(double brojZaProvjeru)           //provjerava dali broj stane u 10 znamenki
        {
            int imaMinus=0;
            int ImaZarez = 0;
            foreach (char znak in brojZaProvjeru.ToString())
            {
                if(znak==',')
                {
                    ImaZarez=1;
                }else if(znak=='-')
                {
                    imaMinus=1;
                }
            }
            if (((imaMinus==1 && ImaZarez==0)||(imaMinus==0 && ImaZarez==1))&&(brojZaProvjeru.ToString().Length > 11 ))
            {
                return 0;
            }
            else if ((imaMinus == 1 && ImaZarez == 1)&&(brojZaProvjeru.ToString().Length > 12 ))
            {
                 return 0;
            }
            else if (brojZaProvjeru.ToString().Length > 10)
            {
                return 0;
            }
            else
            {
                return 1;
            } 
        }
        public void SpremiUMemoriju()
        {
            spremanjeRezultataUMemoriju = rezultat;
        }
        public void BrisanjeEkrana()
        {            
            brisiEkran = "0";
        }
        public void DohvatiMemoriju()
        {
            rezultat = spremanjeRezultataUMemoriju;
            spremanjeRezultataUMemoriju = 0;
        }
        public void MjenjajBrojUSinus()
        {
            double tmpBroj = Convert.ToDouble(broj);
            double tmpBrojSin = Math.Sin(tmpBroj);
            tmpBrojSin = ZaokruziDecimalniBroj(tmpBrojSin);
            broj = tmpBrojSin.ToString();
        }
        public void MjenjajBrojUKosinus()
        {
            double tmpBroj = Convert.ToDouble(broj);
            double tmpBrojKos = Math.Cos(tmpBroj);
            tmpBrojKos = ZaokruziDecimalniBroj(tmpBrojKos);
            broj = tmpBrojKos.ToString();
            
        }

        public void MjenjajBrojUTanges()
        {
            double tmpBroj = Convert.ToDouble(broj);
            double tmpBrojTan = Math.Tan(tmpBroj);
            tmpBrojTan = ZaokruziDecimalniBroj(tmpBrojTan);
            broj = tmpBrojTan.ToString();
        }
        public void MjenjajBrojUKvadrat()
        {
            double tmpBroj = Convert.ToDouble(broj);
            double tmpBrojkvadr = Math.Pow(tmpBroj, 2);
            tmpBrojkvadr = ZaokruziDecimalniBroj(tmpBrojkvadr);
            broj = tmpBrojkvadr.ToString();
        }

        public void MjenjajBrojUKorijen()
        {
            double tmpBroj = Convert.ToDouble(broj);
            double tmpBrojkor = Math.Sqrt(tmpBroj);
            tmpBrojkor = ZaokruziDecimalniBroj(tmpBrojkor);
            broj = tmpBrojkor.ToString();
        }

        public void Resetiraj()
        {
            rezultat = 0;
            broj = "";
        }

        public void Sinus()
        {
            if (rezultat.ToString() == "0")
            {
                rezultat=Math.Sin(Convert.ToDouble(broj));
                rezultat = ZaokruziDecimalniBroj(rezultat);
                broj = "";
            }   
        }

        public void Kosinus()
        {
            if (rezultat.ToString() == "0")
            {
                rezultat = Math.Cos(Convert.ToDouble(broj));
                rezultat = ZaokruziDecimalniBroj(rezultat);
                broj = "";
            }
        }

        public void Tanges()
        {
            if (rezultat.ToString() == "0")
            {
                rezultat = Math.Tan(Convert.ToDouble(broj));
                rezultat = ZaokruziDecimalniBroj(rezultat);
                broj = "";
            }
        }
        public void Kvadriraj()
        {
            if (rezultat.ToString() == "0"&& broj!="")
            {

                rezultat = Math.Pow(Convert.ToDouble(broj), 2);
                rezultat = ZaokruziDecimalniBroj(rezultat);
                if (provjeriVelicinuBroja(rezultat) == 0)
                {
                    rezultat = 000;
                }
                broj = "";
            }
        }
        public void Korijenuj()
        {

            if (rezultat.ToString() == "0")
            {
                rezultat = Math.Sqrt(Convert.ToDouble(broj));
                rezultat = ZaokruziDecimalniBroj(rezultat);
                broj = "";
            }
        }

        public void Mnozi()
        {
            if (zapamcenBrojZaPonavljanjeRadnje)
            {
                broj = pamtiBroj;
            }
            if (broj == "0")
            {
                rezultat = 000;
            }
            else if (rezultat.ToString() == "0")
            {
                rezultat = Convert.ToDouble(broj);
            }
            else 
            {
                rezultat *= Convert.ToDouble(broj);
                if (provjeriVelicinuBroja(rezultat) == 0)
                {
                    prekoracenjeURacunanju = true;
                    rezultat = 000;
                }
            }
            pamtiBroj = broj;
            broj = "";
        }

        public void Oduzmi()
        {
            if (zapamcenBrojZaPonavljanjeRadnje)
            {
                broj = pamtiBroj;
            }
            if (rezultat.ToString() == "0")
            {
                rezultat = Convert.ToDouble(broj);
                pamtiBroj = broj;
                broj = "";
            }
            else
            {
                rezultat -= Convert.ToDouble(broj);
                if (rezultat.ToString().Length > 12)
                {
                    rezultat=ZaokruziDecimalniBroj(rezultat);
                }
                pamtiBroj = broj;
                broj = "";
            }
        } 

        public void Zbroji()
        {
            if (zapamcenBrojZaPonavljanjeRadnje)
            {
                broj = pamtiBroj;
            }
            else
            {
                rezultat += Convert.ToDouble(broj);
                int d = rezultat.ToString().Length;
                if (d > 11)
                {
                    rezultat = ZaokruziDecimalniBroj(rezultat);
                }                    
            }
            pamtiBroj = broj;
            broj = "";         
        }

        public void Djeli()
        {
            if (rezultat.ToString() == "0")
            {
                rezultat = Convert.ToDouble(broj);
                broj = "";
            }
            else 
            {
                rezultat = rezultat / Convert.ToDouble(broj);
                rezultat = ZaokruziDecimalniBroj(rezultat);
                broj = "";
            }
        }

        public bool SljedecaZnamenka()    //provjerava dali se moze uzet nova znamenka (10 ili 11 ili 12)
        {
            bool tmp;
            if (zarezUbroju && !minusUbroju)
            {
                tmp = ProvjeriDuzinuBroja(11);
            }
            else if (!zarezUbroju && minusUbroju)
            {
                tmp = ProvjeriDuzinuBroja(11);
            }
            else if (zarezUbroju && minusUbroju)
            {
                tmp = ProvjeriDuzinuBroja(12);
            }
            else 
            {
                tmp = ProvjeriDuzinuBroja(10);
            }
            return tmp;
        }  
        

        public bool ProvjeriDuzinuBroja( int manjeOdTogaBroja)    //vraca true ako broj ima manje ili jednako 10 znamenki, odnosno 11, odnosno 12
        {
            if (broj == null)
            {
                return true;
            }
            else if (broj.Length < manjeOdTogaBroja)
            {
                 return true;             
            }
            else
            {
                return false;
            }
        }

        public void ProvjeriBrojPocetnihNula()    //provjerava dali je vise nula za redon na pocetku i ako je sve brise jednu pusti
        {
            string pomocniPrvaZnamenka = broj[0].ToString();
            string pomocniDrugaZnamenka = broj[1].ToString();
            if(pomocniDrugaZnamenka=="0" && pomocniPrvaZnamenka=="0")
            {
                broj = broj.Remove(0, 1);
            }
        }

        public string GetCurrentDisplayState()
        {
            if (uneseniBrojBool == false)
            {
                return "0";
            }
            else if (prekoracenjeURacunanju)
            {
                return "-E-";
                prekoracenjeURacunanju = false;
            }
            else if (uneseniBrojBool == true && unesenaOperacijaBool == false)
            {
                uneseniBrojBool = false;
                ProvjeriZnamekeIzaDecZareza();
                return broj;
            }
            else if (unesenaOperacijaBool == true)
            {
                unesenaOperacijaBool = false;
                string pom = rezultat.ToString();
                if (brisiEkran == "0")
                {
                    return "";
                }
                else
                {
                    return rezultat.ToString();
                }
            }
            return "";
       
        }
    }
}
