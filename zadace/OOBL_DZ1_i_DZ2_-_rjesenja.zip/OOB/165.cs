﻿/*************************************************/
/*              IME: Mihael                      */
/*          PREZIME: Mercvajler                  */
/*             JMBG: 0165028029                  */
/*************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    public class Kalkulator : ICalculator
    {
        /*--PRIVATE--*/
        private enum digit
        {
            number = 0,
            binOperator,
            unOperator,
            equal,
            memPut,
            memGet,
            clear,
            reset,
            prefix,
            error
        };
        /*Variables*/
        private Rules rules;
        private Screen display;
        private Memory mem;
        private UnaryOperation unary;
        private BinaryOperation binary;
        private Sign sign;
        private Number temp_Number;
        private Number result;
        private Number temp_Operations;
        /*Constants*/
        private const string numbers = "0123456789,";
        private const string unaryOperators = "SKTQRI";
        private const string binaryOperators = "+-*/";

        /*Checks input*/
        private digit checkDigit(char inPressedDigit)
        {
            int testPressedKey = numbers.IndexOf(inPressedDigit);
            if (testPressedKey != -1)
            {
                return digit.number;
            }

            testPressedKey = unaryOperators.IndexOf(inPressedDigit);
            if (testPressedKey != -1)
            {
                return digit.unOperator;
            }

            testPressedKey = binaryOperators.IndexOf(inPressedDigit);
            if (testPressedKey != -1)
            {
                return digit.binOperator;
            }

            if (inPressedDigit == 'C') return digit.clear;
            if (inPressedDigit == 'O') return digit.reset;
            if (inPressedDigit == 'P') return digit.memPut;
            if (inPressedDigit == 'G') return digit.memGet;
            if (inPressedDigit == 'M') return digit.prefix;
            if (inPressedDigit == '=') return digit.equal;
            return digit.error;
        }

        /*--PUBLIC--*/
        public Kalkulator()
        {
            reset();
            temp_Number = new Number();
            mem = new Memory();
            display = new Screen();
            result = new Number();
            sign = new Sign();
            rules = new Rules();
            temp_Operations = new Number();
        }
        public void reset()
        {
            if (unary != null) unary.reset();
            if (binary != null) binary.reset();
            if (temp_Number != null) temp_Number.reset();
            if (display != null) display.reset();
            if (mem != null) mem.reset();
            if (result != null) result.reset();
            if (sign != null) sign.reset();
            if (rules != null) rules.reset();
            if (temp_Operations != null) temp_Operations.reset();
        }

        public void Press(char inPressedDigit)
        {
            digit input = checkDigit(inPressedDigit);
            switch (input)
            {
                /*The input is a NUMBER*/
                case digit.number:
                    /*Check the according rules*/
                    if (rules.number_NeedReset())
                        temp_Number.reset();
                    if (rules.number_ResultNeedReset())
                        result.reset();

                    temp_Number.addDigit(inPressedDigit);
                    display.setScreen(temp_Number);
                    break;


                /*The input is the +/- SIGN*/
                case digit.prefix:
                    /*Check the according rules*/
                    if(rules.sign_isBinaryOperatorBeforSign())
                        temp_Number.reset();

                    temp_Number = sign.operate(temp_Number);
                    display.setScreen(temp_Number);
                    break;


                /*The input is a UNARY OPERATION*/
                case digit.unOperator:
                    rules.setLastOperation((int)digit.unOperator);
                    
                    if (inPressedDigit == 'S')
                        unary = new Sinus();
                    if (inPressedDigit == 'K')
                        unary = new Cosinus();
                    if (inPressedDigit == 'T')
                        unary = new Tangens();
                    if (inPressedDigit == 'Q')
                        unary = new Square();
                    if (inPressedDigit == 'R')
                        unary = new Root();
                    if (inPressedDigit == 'I')
                        unary = new Inverz();

                    temp_Operations.addNumber(display.getScreenNumber());
                    result = unary.operate(temp_Operations);
                    temp_Number.addNumber(result.getDouble());
                    display.setScreen(result);
                    break;


                /*The input is a BINARY OPERATION*/
                case digit.binOperator:
                    temp_Operations.addNumber(display.getScreenNumber());
                    display.setScreen(temp_Operations);
                    rules.setLastOperation((int)digit.binOperator);

                    /*Check according rules*/
                    if (rules.equal_isBinaryOperation())
                    {
                        if (!rules.binary_isMultipleOperator())
                        {
                            if (rules.binary_isOperationWithTwoOperands())
                            {
                                if (rules.binary_isEqualDigitBeforeBinaryOperator())
                                {
                                    display.setScreen(result);
                                    temp_Number.addNumber(result.getDouble());
                                }
                                else
                                {
                                    binary.setSecondOperand(temp_Number);
                                    result = binary.operate();
                                    display.setScreen(result);
                                }
                            }
                        }
                    }

                    if (inPressedDigit == '+')
                        binary = new Plus();
                    if (inPressedDigit == '-')
                        binary = new Minus();
                    if (inPressedDigit == '*')
                        binary = new Multipy();
                    if (inPressedDigit == '/')
                        binary = new Divide();

                    temp_Operations.addNumber(display.getScreenNumber());
                    temp_Number.addNumber(display.getScreenNumber());
                    binary.setFirstOperand(temp_Operations);
                    break;


                /*The input is the CLEAR BUTTON*/
                case digit.clear:
                    temp_Number.reset();
                    display.setScreen(temp_Number);
                    break;


                /*The input is the RESET BUTTON*/
                case digit.reset:
                    reset();
                    display.setScreen(temp_Number);
                    break;


                /*The input is the EQUAL SIGN*/
                case digit.equal:
                    /*Check the according rules*/
                    if (!rules.equal_isBinaryOperation())
                        result.addNumber(display.getScreenNumber());
                    else
                    {
                        binary.setSecondOperand(temp_Number);
                        result = binary.operate();
                        binary.setCount(0);
                    }

                    display.setScreen(result);
                    break;


                /*The input is the PUT IN MEMORY BUTTON*/
                case digit.memPut:
                    temp_Operations.addNumber(display.getScreenNumber());
                    mem.setMemory(temp_Operations);
                    break;


                /*The input is the GET MEMORY BUTTON*/
                case digit.memGet:
                    temp_Operations = mem.getMemory();
                    temp_Number.addNumber(temp_Operations.getDouble());
                    display.setScreen(temp_Number);
                    break;

                case digit.error:
                    break;
            }

            rules.setBinary(binary);
            rules.setLastDigit((int)input);
            temp_Operations.reset();
        }
        public string GetCurrentDisplayState()
        {
            return display.getScreen();
        }
    }

    public class Rules
    {
        /*--PRIVATE--*/
        private enum digit
        {
            number = 0,
            binOperator,
            unOperator,
            equal,
            memPut,
            memGet,
            clear,
            reset,
            prefix,
            error
        };
        private digit lastDigit;
        private digit lastOperation;
        private BinaryOperation binary;

        /*--PUBLIC--*/
        public Rules()
        {
            reset();
        }
        public void reset()
        {
            lastDigit = digit.error;
            lastOperation = digit.error;
        }
        public void setLastDigit(int ld)
        {
            lastDigit = (digit)ld;
        }
        public void setLastOperation(int lo)
        {
            lastOperation = (digit)lo;
        }
        public void setBinary(BinaryOperation bin)
        {
            binary = bin;
        }
        
        /*Rule for starting new input number*/
        public bool number_NeedReset()
        {
            if (lastDigit != digit.number && lastDigit != digit.prefix
                        && lastDigit != digit.memPut)
                return true;
            else
                return false;
        }
        /*Rule for resetting the temporary result*/
        public bool number_ResultNeedReset()
        {
            if (lastDigit == digit.equal)
                return true;
            else
                return false;
        }
        /*Rule to check if the binary operations have both operands*/
        public bool binary_isOperationWithTwoOperands()
        {
            if (binary.getCount() == 1)
                return true;
            else
                return false;
        }
        /*Rule to check if multiple binary operators are pressed one after other*/
        public bool binary_isMultipleOperator()
        {
            if (lastDigit == digit.binOperator)
                return true;
            else
                return false;
        }
        /*Rule to check if a binary operator is pressed after the equal sign*/
        public bool binary_isEqualDigitBeforeBinaryOperator()
        {
            if (lastDigit == digit.equal)
                return true;
            else
                return false;
        }
        /*Rule to check if a binary operator is pressed before the +/- sign*/
        public bool sign_isBinaryOperatorBeforSign()
        {
            if (lastDigit == digit.binOperator)
                return true;
            else
                return false;
        }
        /*Rule to check if a binary operator is pressed*/
        public bool equal_isBinaryOperation()
        {
            if (binary != null)
                return true;
            else
                return false;
        }
    }  
    public class Screen
    {
        /*--PRIVATE--*/
        private string onScreen;

        /*--PUBLIC--*/
        public Screen()
        {
            reset();
        }
        public void reset()
        {
            onScreen = "0";
        }
        public void setScreen(Number num)
        {
            onScreen = num.getString();
        }
        public string getScreen()
        {
            return onScreen;
        }
        public double getScreenNumber()
        {
            return double.Parse(onScreen);
        }
    }
    public class Memory
    {
        /*--PRIVATE--*/
        private Number inMemory;

        /*--PUBLIC--*/
        public Memory()
        {
            inMemory = new Number();
            reset();
        }
        public void reset()
        {
            inMemory.reset();
        }
        public Number getMemory()
        {
            return inMemory;
        }
        public void setMemory(Number num)
        {
            inMemory.addNumber(num.getDouble());
        }
    }
    public class Number
    {
        /*--PRIVATE--*/
        private string inputDigit;
        private double numberDouble;
        private string numberString;
        private string tempNumber;
        private int maxLength;

        /*Maintains the length depending on the decimal point and the +/- sign*/
        private void setMaxLength()
        {
            int checkIfHasPoint;
            checkIfHasPoint = numberString.IndexOf(',');
            if (numberDouble < 0 && checkIfHasPoint != -1)
                maxLength = 12;
            else if (numberDouble < 0)
                maxLength = 11;
            else if (checkIfHasPoint != -1)
                maxLength = 11;
            else
                maxLength = 10;
        }
        /*Converts the number in the correct format*/
        private void formatNumber()
        {
            int checkIfHasPoint;
            checkIfHasPoint = numberString.IndexOf(',');
            // Check multiple decimal points
            if (inputDigit == "," && checkIfHasPoint == -1)
            {
                numberString = tempNumber;
                setMaxLength();
                numberDouble = double.Parse(numberString);
            }
            else if (inputDigit != ",")
            {
                // Check multiple 0 on beginning of number
                if (numberString == "0")
                {
                    numberString = inputDigit;
                }
                else
                {
                    // Round number
                    if (numberString.Length < maxLength)
                    {
                        numberString = tempNumber;
                    }
                }
                // Set number length
                setMaxLength();
                numberDouble = double.Parse(numberString);
            }
        }
        /*Round a number to 10 digits*/
        private void round()
        {
            if (numberDouble != numberDouble)
            {
                numberString = "-E-";
            }
            else if (Math.Abs(numberDouble) > 9999999999)
            {
                numberString = "-E-";
            }
            else
            {
                int i = 0;
                double temp_Result = numberDouble;
                do
                {
                    temp_Result /= 10;
                    i++;
                }
                while (Math.Abs(temp_Result) > 1);

                temp_Result = Math.Round(numberDouble, (10 - i));

                numberDouble = temp_Result;
                numberString = temp_Result.ToString();
            }
            setMaxLength();
        }

        /*--PUBLIC--*/
        public Number()
        {
            reset();
        }
        public void reset()
        {
            inputDigit = "";
            numberString = "0";
            tempNumber = "";
            numberDouble = 0;
            maxLength = 10;
        }
        public void addNumber(double num)
        {
            numberDouble = num;
            round();
        }
        public void addDigit(char digit)
        {
            inputDigit = digit.ToString();
            tempNumber = numberString + digit;
            formatNumber();
        }
        public string getString()
        {
            return numberString;
        }
        public double getDouble()
        {
            return numberDouble;
        }
    }

    /*Unary operations*/
    abstract public class UnaryOperation
    {
        /*--PUBLIC--*/
        public Number result;

        public UnaryOperation()
        {
            result = new Number();
            reset();
        }
        public void reset()
        {
            result.reset();
        }
        public virtual Number operate(Number operand) { return result; }

    }
    public class Sinus : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = Math.Sin(temp_Number);
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Cosinus : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = Math.Cos(temp_Number);
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Tangens : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = Math.Tan(temp_Number);
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Square : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = Math.Pow(temp_Number, 2);
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Root : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = Math.Sqrt(temp_Number);
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Inverz : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = 1 / temp_Number;
            result.addNumber(temp_Number);
            return result;
        }
    }
    public class Sign : UnaryOperation
    {
        /*--PUBLIC--*/
        public override Number operate(Number operand)
        {
            double temp_Number = operand.getDouble();
            temp_Number = temp_Number * (-1);
            result.addNumber(temp_Number);
            return result;
        }
    }

    /*Binary operation*/
    abstract public class BinaryOperation
    {
        /*--PUBLIC--*/
        public Number firstOperand;
        public Number secondOperand;
        public Number result;
        int count;

        public BinaryOperation()
        {
            result = new Number();
            firstOperand = new Number();
            secondOperand = new Number();
            reset();
        }
        public void reset()
        {
            firstOperand.reset();
            secondOperand.reset();
            result.reset();
            count = 0;
        }
        public int getCount()
        {
            return count;
        }
        public void setCount(int c)
        {
            count = c;
        }
        public void setFirstOperand(Number first)
        {
            firstOperand.addNumber(first.getDouble());
            count++;
        }
        public void setSecondOperand(Number second)
        {
            secondOperand.addNumber(second.getDouble());
        }
        public virtual Number operate() { return result; }
    }
    public class Plus : BinaryOperation
    {
        /*--PUBLIC--*/
        public Plus()
        {
            secondOperand.addNumber(0);
        }
        public override Number operate()
        {
            double temp_Result = firstOperand.getDouble() + secondOperand.getDouble();
            result.addNumber(temp_Result);
            firstOperand = result;
            return result;
        }
    }
    public class Minus : BinaryOperation
    {
        /*--PUBLIC--*/
        public Minus()
        {
            secondOperand.addNumber(0);
        }
        public override Number operate()
        {
            double temp_Result = firstOperand.getDouble() - secondOperand.getDouble();
            result.addNumber(temp_Result);
            firstOperand = result;
            return result;
        }
    }
    public class Multipy : BinaryOperation
    {
        /*--PUBLIC--*/
        public Multipy()
        {
            secondOperand.addNumber(1);
        }
        public override Number operate()
        {
            double temp_Result = firstOperand.getDouble() * secondOperand.getDouble();
            result.addNumber(temp_Result);
            firstOperand = result;
            return result;
        }
    }
    public class Divide : BinaryOperation
    {
        /*--PUBLIC--*/
        public Divide()
        {
            secondOperand.addNumber(1);
        }
        public override Number operate()
        {
            double temp_Result = firstOperand.getDouble() / secondOperand.getDouble();
            result.addNumber(temp_Result);
            firstOperand = result;
            return result;
        }
    }
}
 