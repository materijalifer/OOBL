﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stockList = new List<Stock>();
        private List<Index> indexList = new List<Index>();
        private List<Portfolio> portfolioList = new List<Portfolio>();


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0 || inNumberOfShares <= 0)
            {
                throw new StockExchangeException("The stock price can not be negative!");
            }

            foreach (Stock s in stockList)
            {
                if (String.Equals(inStockName.ToUpper(), s.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    throw new StockExchangeException("The stock with this name already exists!");
                }
            }

            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stockList.Add(stock);
        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("The stock does not exist!");
            }
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(), StringComparison.CurrentCultureIgnoreCase))
                {
                    stockList.Remove(s);
                    break;
                }
            }
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("The stock does not exist!");
            }
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    s.setPrice(inStockValue, inIimeStamp);
                }
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return s.getPrice(inTimeStamp);
                }
            }
            throw new StockExchangeException("The stock does not exist!");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return s.getInitialPrice();
                }
            }
            throw new StockExchangeException("The stock does not exist!");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return s.getLastPrice();
                }
            }
            throw new StockExchangeException("Time out of range!");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("This index type does not exist! Index types are: AVERAGE or WEIGHTED!");
            }

            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    throw new StockExchangeException("The index with this name already exists!");
                }
            }

            Index index = new Index(inIndexName, inIndexType);
            indexList.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
            {
                throw new StockExchangeException("The index or stock does not exist!");
            }
            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    i.addStock(returnStock(inStockName));
                }
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("The index does not exist!");
            }

            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    try
                    {
                        i.removeStock(inStockName);
                    }
                    catch (Exception)
                    {
                        
                        throw new StockExchangeException("The stock does not exist!");
                    }
                }
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("The index does not exist!");
            }
            if (!StockExists(inStockName))
            {
                return false;
            }
            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return i.containsStock(inStockName);
                }
            }
            return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return i.getValue(inTimeStamp);
                }
            }
            throw new StockExchangeException("The index does not exist!");
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            foreach (Index i in indexList)
            {
                if (String.Equals(inIndexName.ToUpper(), i.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return i.getNumberOfStocks();
                }
            }
            throw new StockExchangeException("The index does not exist!");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID()))
                {
                    throw new StockExchangeException("The portfolio with this ID already exist!");
                }
            }
            Portfolio portfolio = new Portfolio(inPortfolioID);
            portfolioList.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Impossible to add 0 or less shares to portfolio!");
            }
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio already exists!");
            }
            long newNumberOfShares = returnStock(inStockName).getNumberOfShares();
            if (newNumberOfShares < numberOfShares)
            {
                numberOfShares = (int) newNumberOfShares;
            }
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    p.addStock(returnStock(inStockName), numberOfShares);
                }
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    p.removeStock(returnStock(inStockName), numberOfShares);
                }
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio does not exist!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Stock does not exist!");
            }
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    p.removeStock(inStockName);
                    break;
                }
            }
        }

        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    return p.getNumberOfStocks();
                }
            }
            throw new StockExchangeException("The portfolio does not exist!");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    return p.containsStock(inStockName);
                }
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio does not exist!");
            }
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    return p.getNumberOfShares(inStockName);
                }
            }
            throw new StockExchangeException("Stock is not in portfolio!");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID(), StringComparison.CurrentCultureIgnoreCase))
                {
                    return p.getValue(timeStamp);
                }
            }
            throw new StockExchangeException("The portfolio does not exist!");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (String.Equals(inPortfolioID, p.getID()))
                {
                    try
                    {
                        return p.getMonthChange(Year, Month);
                    }
                    catch (Exception)
                    {

                        throw new StockExchangeException("The portfolio values are not defined!");
                    }
                }
            }
            throw new StockExchangeException("The portfolio does not exist!");
        }

        public Stock returnStock(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if (String.Equals(inStockName.ToUpper(), s.getName().ToUpper(),
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    return s;
                }
            }
            throw new StockExchangeException("The stock does not exist!");
        }

        public class Stock
        {
            private string stockName;
            private long numberOfShares;
            private DateTime timeStamp;
            private StockHistory stockHistory;
            private List<StockHistory> stockHistoryList;


            public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
            {
                this.stockName = stockName;
                this.numberOfShares = numberOfShares;
                this.timeStamp = timeStamp;
                stockHistory = new StockHistory(timeStamp, DateTime.MaxValue, initialPrice);
                stockHistoryList = new List<StockHistory>();
                stockHistoryList.Add(stockHistory);

            }

            public string getName()
            {
                return stockName;
            }

            public Decimal getLastPrice()
            {
                return stockHistoryList.Last().getPrice();
            }

            public Decimal getInitialPrice()
            {
                return stockHistoryList.First().getPrice();
            }

            public void setPrice(decimal inStockValue, DateTime inTimeStamp)
            {
                if (stockHistoryList.First().getStartDate() > inTimeStamp)
                {
                    stockHistoryList.Insert(0,
                        new StockHistory(inTimeStamp, stockHistoryList.First().getStartDate(), inStockValue));
                }

                if (stockHistoryList.Last().getStartDate() < inTimeStamp)
                {
                    stockHistoryList.Last().setEndDate(inTimeStamp);
                    stockHistoryList.Insert(stockHistoryList.Count, new StockHistory(inTimeStamp, DateTime.MaxValue, inStockValue));

                }

                foreach (StockHistory s in stockHistoryList)
                {
                    if (inTimeStamp > s.getStartDate() && inTimeStamp < s.getEndDate())
                    {
                        int index = stockHistoryList.IndexOf(s);
                        stockHistoryList.Insert(index + 1, new StockHistory(inTimeStamp, s.getEndDate(), inStockValue));
                        s.setEndDate(inTimeStamp);
                    }
                }
            }

            public Decimal getPrice(DateTime inTimeStamp)
            {
                foreach (StockHistory s in stockHistoryList)
                {
                    if (inTimeStamp >= s.getStartDate() && inTimeStamp < s.getEndDate())
                    {
                        return s.getPrice();
                    }
                }
                throw new StockExchangeException("Stock price is not defined for this period!");
            }

            public long getNumberOfShares()
            {
                return numberOfShares;
            }

            public void setNumberOfShares(long numberOfShares)
            {
                this.numberOfShares = numberOfShares;
            }

            public void addShares(int shares)
            {
                setNumberOfShares(numberOfShares + shares);
            }

        }

        public class StockHistory
        {
            private DateTime startDate;
            private DateTime endDate;
            private Decimal price;

            public StockHistory(DateTime startDate, DateTime endDate, Decimal price)
            {
                this.startDate = startDate;
                this.endDate = endDate;
                this.price = price;
            }

            public DateTime getStartDate()
            {
                return startDate;
            }

            public DateTime getEndDate()
            {
                return endDate;
            }

            public void setEndDate(DateTime endDate)
            {
                this.endDate = endDate;
            }

            public Decimal getPrice()
            {
                return price;
            }
        }

        public class Index
        {
            private string indexName;
            public IndexTypes indexType;
            private List<Stock> stocksInIndex;

            public Index(string indexName, IndexTypes indexType)
            {
                this.indexType = indexType;
                this.indexName = indexName;

                stocksInIndex = new List<Stock>();
            }

            public string getName()
            {
                return indexName;
            }

            public void addStock(Stock inStock)
            {
                if (stocksInIndex.Contains(inStock))
                {
                    throw new StockExchangeException("The stock is already in index!");
                }
                stocksInIndex.Add(inStock);
            }

            public void removeStock(string inStockName)
            {
                if (!containsStock(inStockName))
                {
                    throw new StockExchangeException("The stock does not exist!");
                }
                foreach (Stock s in stocksInIndex)
                {
                    if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                        StringComparison.CurrentCultureIgnoreCase))
                    {
                        stocksInIndex.Remove(s);
                    }
                }
            }


            public bool containsStock(string inStockName)
            {
                foreach (Stock s in stocksInIndex)
                {
                    if (String.Equals(s.getName().ToUpper(), inStockName.ToUpper(),
                        StringComparison.CurrentCultureIgnoreCase))
                    {
                        return true;
                    }
                }
                return false;
            }

            public int getNumberOfStocks()
            {
                return stocksInIndex.Count;
            }

            public decimal getValue(DateTime inTimeStamp)
            {

                if (indexType == IndexTypes.AVERAGE)
                {
                    return averageAlgorithm(inTimeStamp);
                }
                if (indexType == IndexTypes.WEIGHTED)
                {
                    return weightedAlgorithm(inTimeStamp);
                }
                throw new StockExchangeException("");
            }

            private decimal averageAlgorithm(DateTime inTimeStamp)
            {
                decimal sum = 0;
                decimal average;

                foreach (Stock s in stocksInIndex)
                {
                    sum += s.getPrice(inTimeStamp);
                }
                average = decimal.Divide(sum, getNumberOfStocks());
                return Math.Round(average, 3);
            }

            private decimal weightedAlgorithm(DateTime inTimeStamp)
            {
                decimal sum1 = 0;
                decimal sum2 = 0;

                foreach (Stock s in stocksInIndex)
                {
                    sum1 += s.getPrice(inTimeStamp)*s.getNumberOfShares();
                }
                foreach (Stock s in stocksInIndex)
                {
                    sum2 += s.getPrice(inTimeStamp)*decimal.Divide(s.getPrice(inTimeStamp), sum1)*s.getNumberOfShares();
                }

                return Math.Round(sum2, 3);
            }
        }

        public class Portfolio
        {
            private string portfolioID;
            private List<Stock> stocksInPortfolio = new List<Stock>();
            private Dictionary<string, int> sharesInPortfolio = new Dictionary<string, int>();

            public Portfolio(string portfolioID)
            {
                this.portfolioID = portfolioID;
            }

            public string getID()
            {
                return portfolioID;
            }

            public void addStock(Stock stock, int numberOfShares)
            {
                stock.setNumberOfShares(stock.getNumberOfShares() - numberOfShares);

                if (containsStock(stock.getName()))
                {

                    sharesInPortfolio[stock.getName()] += numberOfShares;
                }
                else
                {
                    sharesInPortfolio.Add(stock.getName(), numberOfShares);
                    stocksInPortfolio.Add(stock);
                }

            }

            public int getNumberOfStocks()
            {
                return stocksInPortfolio.Count;

            }

            public bool containsStock(string stockName)
            {
                foreach (Stock s in stocksInPortfolio)
                {
                    if (String.Equals(stockName.ToUpper(), s.getName().ToUpper(),
                        StringComparison.CurrentCultureIgnoreCase))
                    {
                        return true;
                    }
                }
                return false;
            }

            public void removeStock(string stockName)
            {
                sharesInPortfolio.Remove(stockName);
                foreach (Stock s in stocksInPortfolio)
                {
                    if (String.Equals(stockName.ToUpper(), s.getName().ToUpper(),
                        StringComparison.CurrentCultureIgnoreCase))
                    {
                        stocksInPortfolio.Remove(s);
                        break;
                    }
                }
            }

            internal int getNumberOfShares(string inStockName)
            {
                if (sharesInPortfolio.ContainsKey(inStockName))
                {
                    return sharesInPortfolio[inStockName]; 
                }
                return 0;
            }

            public void removeStock(Stock stock, int numberOfShares)
            {
                stock.addShares(numberOfShares);
                sharesInPortfolio[stock.getName()] -= numberOfShares;

                if (sharesInPortfolio[stock.getName()] <= 0)
                {
                    removeStock(stock.getName());
                }
            }

            public decimal getValue(DateTime timeStamp)
            {
                decimal sum = 0;

                foreach (Stock s in stocksInPortfolio)
                {
                    sum += s.getPrice(timeStamp)*sharesInPortfolio[s.getName()];
                }

                return sum;
            }

            internal decimal getMonthChange(int Year, int Month)
            {
                decimal firstDay;
                decimal lastDay;
                decimal monthChange;

                firstDay = getValue(new DateTime(Year, Month, 1, 00, 00, 00, 00));
                lastDay = getValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));


                monthChange = decimal.Divide(lastDay-firstDay, firstDay)*100;
                return monthChange;
            }
        }
    }
}
