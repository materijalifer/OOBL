﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private Ekran Ekran;
        private decimal memorija = 0;
        private List<decimal> listaOperanada;
        public bool KalkulatorUStanjuGreske = false;
        private Nullable<char> zadnjiBinarniOperator = null;
        private Nullable<char> zadnjePritisnutaTipka = null;


        public Kalkulator()
        {
            Ekran = new Ekran();
            memorija = 0;
            listaOperanada = new List<decimal>();
            KalkulatorUStanjuGreske = false;
            zadnjiBinarniOperator = null;
            zadnjePritisnutaTipka = null;
        }

        private void ResetCalculator()
        {
            memorija = 0;
            listaOperanada.Clear();
            KalkulatorUStanjuGreske = false;
            zadnjiBinarniOperator = null;
            zadnjePritisnutaTipka = null;
            Ekran.PobrisiSadrzajZaslona();
        }

        public void Press(char inPressedDigit)
        {
            try
            {

                if (KalkulatorUStanjuGreske == true && inPressedDigit != (char)Znak.O)
                {
                    return;
                }

                if (inPressedDigit == '0' || inPressedDigit == '1' || inPressedDigit == '2' || inPressedDigit == '3' ||
                    inPressedDigit == '4' || inPressedDigit == '5' || inPressedDigit == '6' || inPressedDigit == '7' ||
                    inPressedDigit == '8' || inPressedDigit == '9' || inPressedDigit == (char)Znak.Zarez)
                {
                    Ekran.PisiPoZaslonu(inPressedDigit);
                }
                else if (inPressedDigit == (char)Znak.Plus || inPressedDigit == (char)Znak.Minus ||
                     inPressedDigit == (char)Znak.Puta || inPressedDigit == (char)Znak.Kroz)
                {
                    if (zadnjePritisnutaTipka != null && zadnjePritisnutaTipka != (char)Znak.Plus &&
                        zadnjePritisnutaTipka != (char)Znak.Minus && zadnjePritisnutaTipka != (char)Znak.Puta &&
                        zadnjePritisnutaTipka != (char)Znak.Kroz)
                    {
                        decimal trenutniOperand = Ekran.DohvatiDecimalniBrojSaZaslona();
                        listaOperanada.Add(trenutniOperand);

                        Ekran.PrikaziRezultatNaZaslon(trenutniOperand); // tako da  0, => 0 i 1,0 => 1 itd..

                        if (listaOperanada.Count == 2 && zadnjiBinarniOperator != null)
                        {
                            if (zadnjiBinarniOperator == (char)Znak.Plus)
                            {
                                trenutniOperand = OperacijeKalkulatora.Zbrajanje(listaOperanada[0], listaOperanada[1]);
                            }
                            else if (zadnjiBinarniOperator == (char)Znak.Minus)
                            {
                                trenutniOperand = OperacijeKalkulatora.Oduzimanje(listaOperanada[0], listaOperanada[1]);
                            }
                            else if (zadnjiBinarniOperator == (char)Znak.Puta)
                            {
                                trenutniOperand = OperacijeKalkulatora.Mnozenje(listaOperanada[0], listaOperanada[1]);
                            }
                            else if (zadnjiBinarniOperator == (char)Znak.Kroz)
                            {
                                trenutniOperand = OperacijeKalkulatora.Dijeljenje(listaOperanada[0], listaOperanada[1]);
                            }

                            Ekran.PrikaziRezultatNaZaslon(trenutniOperand);

                            listaOperanada.Clear();
                            listaOperanada.Add(trenutniOperand);
                        }

                    }

                    zadnjiBinarniOperator = inPressedDigit;
                }
                else if (inPressedDigit == (char)Znak.Jednako)
                {
                    if (zadnjiBinarniOperator == null)
                    {
                        decimal trenutniOperand = Ekran.DohvatiDecimalniBrojSaZaslona();
                        Ekran.PrikaziRezultatNaZaslon(trenutniOperand);     // da bi se rjesili slucajevi kao 4,=4 i 4,0=4
                        listaOperanada.Clear();
                        return;
                    }
                    else if (zadnjePritisnutaTipka != null && (zadnjePritisnutaTipka == (char)Znak.Plus ||
                        zadnjePritisnutaTipka == (char)Znak.Minus || zadnjePritisnutaTipka == (char)Znak.Puta ||
                        zadnjePritisnutaTipka == (char)Znak.Kroz))
                    {
                        listaOperanada.Add(listaOperanada[0]);
                    }
                    else
                    {
                        decimal trenutniOperand = Ekran.DohvatiDecimalniBrojSaZaslona();
                        listaOperanada.Add(trenutniOperand);
                    }
                    if (listaOperanada.Count == 2)
                    {
                        decimal trenutniOperand = -10101010;  // nesto po cemu ce mi vrijednost biti cudna ako se pojavi na ekranu pa cu ici provjeravati ako bude neki bug
                        if (zadnjiBinarniOperator == (char)Znak.Plus)
                        {
                            trenutniOperand = OperacijeKalkulatora.Zbrajanje(listaOperanada[0], listaOperanada[1]);
                        }
                        else if (zadnjiBinarniOperator == (char)Znak.Minus)
                        {
                            trenutniOperand = OperacijeKalkulatora.Oduzimanje(listaOperanada[0], listaOperanada[1]);
                        }
                        else if (zadnjiBinarniOperator == (char)Znak.Puta)
                        {
                            trenutniOperand = OperacijeKalkulatora.Mnozenje(listaOperanada[0], listaOperanada[1]);
                        }
                        else if (zadnjiBinarniOperator == (char)Znak.Kroz)
                        {
                            trenutniOperand = OperacijeKalkulatora.Dijeljenje(listaOperanada[0], listaOperanada[1]);
                        }

                        Ekran.PrikaziRezultatNaZaslon(trenutniOperand);

                        listaOperanada.Clear();
                        zadnjiBinarniOperator = null;
                    }

                }
                else if (inPressedDigit == (char)Znak.M)
                {
                    Ekran.PromijeniPredznak();
                }
                else if (inPressedDigit == (char)Znak.P)
                {
                    this.memorija = Ekran.DohvatiDecimalniBrojSaZaslona();
                }
                else if (inPressedDigit == (char)Znak.C)
                {
                    Ekran.PobrisiSadrzajZaslona();
                }
                else if (inPressedDigit == (char)Znak.O)
                {
                    this.ResetCalculator();
                }
                else if (inPressedDigit == (char)Znak.S || inPressedDigit == (char)Znak.K || inPressedDigit == (char)Znak.T ||
                    inPressedDigit == (char)Znak.Q || inPressedDigit == (char)Znak.R || inPressedDigit == (char)Znak.I ||
                    inPressedDigit == (char)Znak.G)
                {
                    decimal trenutniOperand = Ekran.DohvatiDecimalniBrojSaZaslona();

                    if (inPressedDigit == (char)Znak.S)
                    {
                        trenutniOperand = OperacijeKalkulatora.Sinus(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.K)
                    {
                        trenutniOperand = OperacijeKalkulatora.Kosinus(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.T)
                    {
                        trenutniOperand = OperacijeKalkulatora.Tangens(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.Q)
                    {
                        trenutniOperand = OperacijeKalkulatora.Kvadriranje(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.R)
                    {
                        trenutniOperand = OperacijeKalkulatora.Korjenovanje(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.I)
                    {
                        trenutniOperand = OperacijeKalkulatora.Inverz(trenutniOperand);
                    }
                    else if (inPressedDigit == (char)Znak.G)
                    {
                        trenutniOperand = this.memorija;
                    }

                    Ekran.PrikaziRezultatNaZaslon(trenutniOperand);
                }


                zadnjePritisnutaTipka = inPressedDigit;

            }
            catch (KalkulatorskaGreskaException kge)
            {
                this.KalkulatorUStanjuGreske = true;
                Ekran.ObjaviPorukuGreske(kge.porukaGreske);
            }
        }


        public string GetCurrentDisplayState()
        {
            return this.Ekran.DohvatiTekstualniSadrzajZaslona();
        }


    }


    public class Ekran
    {
        private StringBuilder sadrzajEkrana;

        private const byte MAX_ZNAMENAKA_EKRANA = 10;

        private int brojRucnoUnesenihZnamenki;


        // KORISTI SE DECIMALNI ZAREZ !!!!!

        public Ekran()
        {
            sadrzajEkrana = new StringBuilder("0");
            brojRucnoUnesenihZnamenki = 0;
        }

        public void PobrisiSadrzajZaslona()
        {
            this.sadrzajEkrana.Length = 0;
            this.sadrzajEkrana.Append("0");
            brojRucnoUnesenihZnamenki = 0;
        }

        public void ObjaviPorukuGreske(string porukaGreske)
        {
            this.sadrzajEkrana.Length = 0;
            this.sadrzajEkrana.Append(porukaGreske);
        }

        public string DohvatiTekstualniSadrzajZaslona()
        {
            return sadrzajEkrana.ToString();
        }

        public decimal DohvatiDecimalniBrojSaZaslona()
        {
            return decimal.Parse(sadrzajEkrana.ToString());
        }

        public void PromijeniPredznak()
        {
            if (this.sadrzajEkrana[0] == '-')
            {
                this.sadrzajEkrana.Remove(0, 1);
            }
            else
            {
                this.sadrzajEkrana.Insert(0, '-');
            }
        }

        public void PisiPoZaslonu(char dodatniZnak)
        {
            if (brojRucnoUnesenihZnamenki == 0)
            {
                this.sadrzajEkrana.Length = 0;
            }

            if (dodatniZnak == ',')
            {
                if (this.sadrzajEkrana.ToString().Contains(',') == true)
                {
                    return;
                }
                if (this.sadrzajEkrana.Length == 0)
                {
                    this.sadrzajEkrana.Append("0");
                }
            }
            else if (brojRucnoUnesenihZnamenki == MAX_ZNAMENAKA_EKRANA)
            {
                return;
            }
            else if (this.sadrzajEkrana.ToString() == "0" && dodatniZnak == '0')
            {
                return;
            }

            this.sadrzajEkrana.Append(dodatniZnak);
            brojRucnoUnesenihZnamenki = this.sadrzajEkrana.ToString().Count(c => c != ',' && c != '-');

        }

        public void PrikaziRezultatNaZaslon(decimal rezultatZaPrikaz)
        {

            decimal cijelobrojniDio = Math.Round(rezultatZaPrikaz, 0);
            string tekstZapisCijelobrojniDijela = Math.Abs(cijelobrojniDio).ToString();
            int brojZnamenkiCijelobrojniDijela = tekstZapisCijelobrojniDijela.Length;

            if (brojZnamenkiCijelobrojniDijela > MAX_ZNAMENAKA_EKRANA)
            {
                throw new KalkulatorskaGreskaException();
            }
            else
            {
                int brojDecimalnihZnamenki = MAX_ZNAMENAKA_EKRANA - brojZnamenkiCijelobrojniDijela;
                rezultatZaPrikaz = Math.Round(rezultatZaPrikaz, brojDecimalnihZnamenki);
            }

            rezultatZaPrikaz = eliminirajPrateceNule(rezultatZaPrikaz);
            this.sadrzajEkrana.Length = 0;
            this.sadrzajEkrana.Append(rezultatZaPrikaz.ToString());
            brojRucnoUnesenihZnamenki = 0;
        }

        private decimal eliminirajPrateceNule(decimal x)
        {
            return x / 1.000000000000000000000000000000000m;
        }
    }


    public static class OperacijeKalkulatora
    {
        public static decimal Zbrajanje(decimal a, decimal b)
        {
            try
            {
                return a + b;
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Oduzimanje(decimal a, decimal b)
        {
            try
            {
                return a - b;
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Mnozenje(decimal a, decimal b)
        {
            try
            {
                return a * b;
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Dijeljenje(decimal a, decimal b)
        {
            try
            {
                return a / b;
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        //public static decimal PromjenaPredznaka(decimal x)
        //{
        //    try
        //    {
        //        return (decimal)(-x);
        //    }
        //    catch (Exception)
        //    {
        //        throw new KalkulatorskaGreskaException();
        //    }
        //}


        public static decimal Sinus(decimal angleInRadians)
        {
            try
            {
                return (decimal)Math.Sin((double)angleInRadians);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Kosinus(decimal angleInRadians)
        {
            try
            {
                return (decimal)Math.Cos((double)angleInRadians);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Tangens(decimal angleInRadians)
        {
            try
            {
                return (decimal)Math.Tan((double)angleInRadians);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }


        public static decimal Kvadriranje(decimal x)
        {
            try
            {
                return (decimal)(x * x);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Korjenovanje(decimal x)
        {
            try
            {
                return (decimal)Math.Sqrt((double)x);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        public static decimal Inverz(decimal x)
        {
            try
            {
                return (decimal)(1 / x);
            }
            catch (Exception)
            {
                throw new KalkulatorskaGreskaException();
            }
        }

        //public static void SpremanjeUMemoriju(decimal x)
        //{
        //    try
        //    {

        //    }
        //    catch (Exception)
        //    {
        //        throw new KalkulatorskaGreskaException();
        //    }
        //}

        //public static decimal DohvacanjeIzMemorije()
        //{
        //    try
        //    {

        //    }
        //    catch (Exception)
        //    {
        //        throw new KalkulatorskaGreskaException();
        //    }
        //}

        //public static void BrisanjeEkrana()
        //{
        //    try
        //    {
        //        Ekran.
        //    }
        //    catch (Exception)
        //    {
        //        throw new KalkulatorskaGreskaException();
        //    }
        //}

        //public static void ResetCalculator()
        //{
        //    try
        //    {

        //    }
        //    catch (Exception)
        //    {
        //        throw new KalkulatorskaGreskaException();
        //    }
        //}

    }


    public class KalkulatorskaGreskaException : Exception
    {
        public string porukaGreske;

        public KalkulatorskaGreskaException()
            : base()
        {
            this.porukaGreske = "-E-";
        }

        public KalkulatorskaGreskaException(string message)
            : base(message)
        {
            this.porukaGreske = message;
        }
    }


    public enum Znak
    {
        Plus = '+',
        Minus = '-',
        Puta = '*',
        Kroz = '/',
        Jednako = '=',
        Zarez = ',',
        M = 'M',
        S = 'S',
        K = 'K',
        T = 'T',
        Q = 'Q',
        R = 'R',
        I = 'I',
        P = 'P',
        G = 'G',
        C = 'C',
        O = 'O'
    }
}
