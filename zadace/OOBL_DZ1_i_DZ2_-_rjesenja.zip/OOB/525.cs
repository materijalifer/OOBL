﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Odbc;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using DrugaDomacaZadaca_Burza;
using Microsoft.SqlServer.Server;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock
     {
         public string stockName;
         public long numberOfShares;
         public decimal initialPrice;
         public DateTime timeStamp;
         public decimal stockValue;
         public SortedDictionary<DateTime, decimal> history = new SortedDictionary<DateTime, decimal>();
     }

    public class Index
    {
        public string indexName;
        public IndexTypes indexType;
        public List<Stock> stocksIndex = new List<Stock>(); 
    }

    public class Portfolio
    {
        public string portfolioID;
        public List<Stock> stocksPortfolio = new List<Stock>();
        public Dictionary<string, int> numberSharesPortfolio = new Dictionary<string, int>();
        public Dictionary<string, int> stocksLeft = new Dictionary<string, int>();
    }

  
     public class StockExchange : IStockExchange
     {
         private List<Stock> stocks = new List<Stock>();
         private List<Index> indexes = new List<Index>(); 
         private List<Portfolio> portfolios = new List<Portfolio>(); 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberOfShares <= 0 || inInitialPrice <= 0)
                 throw new StockExchangeException("Negativno!");
             else
             {
                 Stock temp = new Stock();
                 temp.stockName = inStockName.ToUpper();
                 temp.initialPrice = inInitialPrice;
                 temp.numberOfShares = inNumberOfShares;
                 temp.timeStamp = inTimeStamp;
                 temp.history.Add(inTimeStamp,inInitialPrice);
                 temp.stockValue = inInitialPrice;
                 foreach (Stock s in stocks)
                 {
                     if (s.stockName == inStockName.ToUpper() && s.initialPrice == inInitialPrice && s.numberOfShares == inNumberOfShares)
                         throw new StockExchangeException("Postoji vec takva!");
                 }
                 stocks.Add(temp);
             }

         }

         public void DelistStock(string inStockName)
         {
             int flag = 0;

             foreach (Stock s in stocks.ToList())
             {
                 if (s.stockName == inStockName.ToUpper())
                 {
                     flag = 1;
                     stocks.Remove(s);
                 }
             }
             if (flag == 0)
                 throw new StockExchangeException("msg");
             foreach (Index i in indexes)
             {
                 RemoveStockFromIndex(i.indexName,inStockName.ToUpper());
             }
             foreach (Portfolio p in portfolios)
             {
                 RemoveStockFromPortfolio(p.portfolioID,inStockName.ToUpper());
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock s in stocks)
             {
                 if (s.stockName == inStockName.ToUpper())
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             int flag = 0;
             foreach (Stock s in stocks)
             {
                 if (s.stockName == inStockName.ToUpper())
                 {
                     flag = 1;
                     if (s.timeStamp == inIimeStamp)
                         throw new StockExchangeException("msg");
                     s.timeStamp = inIimeStamp;
                     s.stockValue = inStockValue;
                     s.history.Add(inIimeStamp, inStockValue);
                 }
             }
             if (flag == 0)
             {
                 throw new StockExchangeException("msg");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             SortedDictionary<DateTime,decimal> temp = new SortedDictionary<DateTime, decimal>();
             decimal val = 0;

             foreach (Stock s in stocks)
             {
                 if (s.stockName == inStockName.ToUpper())
                 {
                     foreach (KeyValuePair<DateTime,decimal> pair in s.history)
                     {
                         if (pair.Key <= inTimeStamp)
                         {
                             temp.Add(pair.Key,pair.Value);
                         }
                            
                     }
                 }
             }

             if (temp.Count == 0)
                 throw new StockExchangeException("Ne");

             foreach (KeyValuePair<DateTime,decimal> pair in temp)
             {
                 val = pair.Value;
             }
             return val;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock s in stocks)
             {
                 if (s.stockName == inStockName.ToUpper())
                 {
                     foreach (KeyValuePair<DateTime, decimal> pair in s.history)
                     {
                         return pair.Value;
                     }
                 }
             }
             throw new StockExchangeException("Nema");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             decimal val = 0;
             foreach (Stock s in stocks)
             {
                 if (s.stockName == inStockName.ToUpper())
                 {
                     foreach (KeyValuePair<DateTime,decimal> pair in s.history)
                     {
                         val = pair.Value;
                     }
                 }
             }
             if (val <= 0)
                 throw new StockExchangeException("Nema");
             else
             {
                 return val;
             }
             
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index temp = new Index();
             temp.indexName = inIndexName.ToUpper();
             temp.indexType = inIndexType;
             foreach (Index i in indexes )
             {
                 if (temp.indexName == i.indexName)
                     throw  new StockExchangeException("Nemoze");
             }
             indexes.Add(temp);
             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             int flag1 = 0, flag2 = 0;

             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                 {
                     flag1 = 1;
                     foreach (Stock s in i.stocksIndex)
                     {
                         if (s.stockName == inStockName.ToUpper())
                             throw new StockExchangeException("msg");
                     }
                     foreach (Stock s in stocks)
                     {
                         if (s.stockName == inStockName.ToUpper())
                         {
                             flag2 = 1;
                             i.stocksIndex.Add(s);
                         }
                     }
                 }
             }
             if (flag1 == 0 || flag2 == 0)
                 throw new StockExchangeException("msg");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             int flag1 = 0, flag2 = 0;

             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                 {
                     flag2 = 1;
                     foreach (Stock s in i.stocksIndex.ToList())
                     {
                         if (s.stockName == inStockName.ToUpper())
                         {
                             flag1 = 1;
                             i.stocksIndex.Remove(s);
                         }
                     }
                 }
             }
             if (flag1 == 0 || flag2 == 0)
                 throw new StockExchangeException("Msg");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                 {
                     foreach (Stock s in i.stocksIndex)
                     {
                         if (s.stockName == inStockName.ToUpper())
                         {
                             return true;
                         }
                     }
                     return false;
                 }
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal sum = 0, temp = 0, factor = 1;

             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                 {
                     if (i.indexType == IndexTypes.AVERAGE)
                     {
                         foreach (Stock s in i.stocksIndex)
                         {
                             sum += GetStockPrice(s.stockName, inTimeStamp);
                         }
                         if (sum != 0)
                            return Decimal.Round(sum/i.stocksIndex.Count,3);
                     }
                     else
                     {
                         foreach (Stock s in i.stocksIndex)
                         {
                             temp += GetStockPrice(s.stockName, inTimeStamp)*s.numberOfShares;
                         }
                         foreach (Stock s in i.stocksIndex)
                         {
                             factor = GetStockPrice(s.stockName, inTimeStamp)/temp;
                             sum += GetStockPrice(s.stockName, inTimeStamp)*factor*s.numberOfShares;
                         }
                         return Decimal.Round(sum,3);
                     }
                 }
             }
             return sum;

         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                     return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index i in indexes)
             {
                 if (i.indexName == inIndexName.ToUpper())
                     return i.stocksIndex.Count;
             }
             throw new StockExchangeException("Ne iđe!");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                     throw  new StockExchangeException("Ne meze");                 
             }
             Portfolio temp = new Portfolio();
             temp.portfolioID = inPortfolioID;
             portfolios.Add(temp);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int postoji = 0, flag1 = 0, flag2 = 0;

             if (numberOfShares <= 0)
                 throw new StockExchangeException("msg");

             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     flag1 = 1;
                     foreach (Stock s in p.stocksPortfolio)
                     {
                         if (s.stockName == inStockName.ToUpper())
                         {
                             postoji = 1;
                             flag2 = 1;
                             if (s.numberOfShares < p.numberSharesPortfolio[inStockName.ToUpper()] + numberOfShares)
                             {
                                 p.numberSharesPortfolio[inStockName.ToUpper()] += (int)s.numberOfShares - p.numberSharesPortfolio[inStockName.ToUpper()];
                             }
                             else
                             {
                                 p.numberSharesPortfolio[inStockName.ToUpper()] += numberOfShares;
                             }
                             
                         }
                     }
                     if (postoji == 0)
                     {
                         foreach (Stock s in stocks)
                         {
                             if (s.stockName == inStockName.ToUpper())
                             {
                                 flag2 = 1;
                                 p.stocksPortfolio.Add(s);
                                 p.numberSharesPortfolio.Add(inStockName.ToUpper(), numberOfShares);
                                 p.stocksLeft.Add(inStockName.ToUpper(), (int)s.numberOfShares);
                             }
                         }
                     }
                     foreach (Stock s in stocks)
                     {
                         if (s.stockName == inStockName.ToUpper() && s.numberOfShares < p.numberSharesPortfolio[inStockName.ToUpper()])
                         {
                            throw new StockExchangeException("Ne");
                         }
                     }
                 }
             }
             if (flag1 == 0 || flag2 == 0)
                 throw new StockExchangeException("msg");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int tempL = 0, flag1 = 0;

             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     flag1 = 1;
                     if (p.numberSharesPortfolio[inStockName.ToUpper()] <= numberOfShares)
                     {
                         RemoveStockFromPortfolio(p.portfolioID, inStockName.ToUpper());
                     }
                     else
                     {
                         p.numberSharesPortfolio[inStockName.ToUpper()] -= numberOfShares;
                     }
                 }

             }
             if (flag1 == 0)
                 throw new StockExchangeException("msg");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             int flag1 = 0, flag2 = 0;
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     flag1 = 1;
                     foreach (Stock s in p.stocksPortfolio.ToList())
                     {
                         if (s.stockName == inStockName.ToUpper())
                         {
                             flag2 = 1;
                             p.stocksPortfolio.Remove(s);
                             p.numberSharesPortfolio.Remove(inStockName.ToUpper());
                         }
                     }
                 }             
             }
             if (flag1 == 0 || flag2 == 0)
                 throw new StockExchangeException("msg");
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                     return p.stocksPortfolio.Count;
             }
             return 0;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     foreach (Stock s in p.stocksPortfolio)
                     {
                         if (s.stockName == inStockName.ToUpper())
                             return true;
                     }
                 }
             }
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             
             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     try
                     {
                         return p.numberSharesPortfolio[inStockName.ToUpper()];
                     }
                     catch (Exception e)
                     {
                         return 0;
                     }

                 }
             }
             return 0;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal sum = 0;

             foreach (Portfolio p in portfolios)
             {
                 if (p.portfolioID == inPortfolioID)
                 {
                     foreach (Stock s in p.stocksPortfolio)
                     {
                         sum += GetStockPrice(s.stockName, timeStamp)*p.numberSharesPortfolio[s.stockName];
                     }
                 }
             }
             return sum;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal first = 0, last = 0;

             if (Month > 12)
                 throw new StockExchangeException("msg");

             DateTime start = new DateTime(Year,Month,1,0,0,0);
             DateTime end = new DateTime(Year,Month,1,23,59,59,999).AddMonths(1).AddDays(-1);

             first = GetPortfolioValue(inPortfolioID, start);
             last = GetPortfolioValue(inPortfolioID, end);

             if (first == 0)
                 return 0;

             return Decimal.Round((last-first)/first * 100,3);
         }

     }
}
