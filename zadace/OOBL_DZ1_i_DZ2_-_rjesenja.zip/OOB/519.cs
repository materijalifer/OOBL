using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using DrugaDomacaZadaca_Burza;
using NUnit.Framework.Constraints;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Portfolio
    {
        public string Id { get; set; }
        public Dictionary<Stock,int> StockInPortfolio=new Dictionary<Stock, int>();
        
    }
    


    public class Index
    {   
       
        public IndexTypes type;
        public List<Stock> ListOfStockIndex=new List<Stock>();
        public Dictionary<DateTime,decimal> IndexValueHistory=new Dictionary<DateTime, decimal>(); 

    }

     public class Stock
     {
         public string InStockName { get; set; }

         public long InNumberOfShares { get; set; }

         public decimal InStockPrice { get; set; }

         public DateTime InTimeStamp { get; set; }

         public Dictionary<DateTime, decimal> StockValueHistory=new Dictionary<DateTime, decimal>();
     }

     public class StockExchange : IStockExchange
     {

         public List<Stock> ListOfAllStocks = new List<Stock>();

         public Dictionary<string, Index> IndexDict = new Dictionary<string, Index>();

         public List<Portfolio> ListOfAllPortfolios=new List<Portfolio>(); 
         

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (ListOfAllStocks.Exists(p=>p.InStockName==inStockName.ToLower()) || inNumberOfShares<=0 || inInitialPrice<=0)
             {
                 throw new StockExchangeException("Duplikat dionice!!!");
             }
             else
             {
                 var stock = new Stock();
                 stock.InStockPrice = inInitialPrice;
                 stock.InNumberOfShares = inNumberOfShares;
                 stock.InStockName = inStockName.ToLower();
                 stock.InTimeStamp = inTimeStamp;

                 ListOfAllStocks.Add(stock);
                 stock.StockValueHistory.Add(inTimeStamp, inInitialPrice);
                 
             }


         }

         public void DelistStock(string inStockName)
         {

             /*if (ListOfAllStocks.RemoveAll(p => p.InStockName == inStockName.ToLower()).Equals(0))
             {
                 throw new StockExchangeException("erroe");
             }*/


             try
             {
             var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 if (stock.Equals(null))
                 {
                     throw new StockExchangeException("erroe");
                 }
             if (ListOfAllPortfolios.Exists(p=>p.StockInPortfolio.ContainsKey(stock)))
                 {
                     var list = ListOfAllPortfolios.Where(p => p.StockInPortfolio.ContainsKey(stock)).ToList();
                     foreach (var portfolio in list)
                     {
                         portfolio.StockInPortfolio.Remove(stock);
                     }
                     foreach (var portfolio in list)
                     {
                         if (portfolio.StockInPortfolio.Count.Equals(0))
                         {
                             ListOfAllPortfolios.Remove(portfolio);
                         }
                     }
                 }
             else if (!IndexDict.Where(p => p.Value.ListOfStockIndex.Exists(r => r.InStockName == inStockName.ToLower())).ToList().Equals(null))
             {
                 foreach (var kv in IndexDict.Where(p => p.Value.ListOfStockIndex.Exists(r => r.InStockName == inStockName.ToLower())).ToList())
                 {
                     kv.Value.ListOfStockIndex.RemoveAll(p => p.InStockName == inStockName.ToLower());
                 }

             }

             ListOfAllStocks.RemoveAll(p => p.InStockName == inStockName.ToLower());
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("puklo");
             }
             
             
             
         }

         public bool StockExists(string inStockName)
         {

             var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
             if (stock == null)
             {
                 return false;
             }
             
             return true;
             
         }

         public int NumberOfStocks()
         {
             return ListOfAllStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (inStockValue < 0 )
             {
               throw new StockExchangeException("Ne možete postaviti cijenu u budućnosti niti ju postaviti manjom ili jednakom 0!");  
             }



             var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
            
                 try
                 {
                     if (stock.StockValueHistory.ContainsKey(inIimeStamp))
                     {
                         throw new StockExchangeException(
                             "Cijena dionice postoji za taj datum te se ne može unijeti ponovo!");
                     }
                     stock.InTimeStamp = inIimeStamp;
                     stock.InStockPrice = inStockValue;
                     
                     stock.StockValueHistory.Add(inIimeStamp, inStockValue);
                     
                     
                 }
                 catch (NullReferenceException)
                 {

                     throw new StockExchangeException("Dionica ne postoji (null) pa joj ne možemo promijeniti cijenu!");
                 }
             


         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (inTimeStamp > DateTime.Now)
             {
                 throw new StockExchangeException("Ne možete tražiti cijenu dionice u budućnosti!");
             }
             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var price =
                     stock.StockValueHistory.Where(p => p.Key <= inTimeStamp)
                         .OrderByDescending(p => p.Key).FirstOrDefault();
                 return price.Value;
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("Ništa nema od cijene!");
             }
            
         }
             
             
         public decimal GetInitialStockPrice(string inStockName)
         {
             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var price =
                     stock.StockValueHistory.OrderBy(p => p.Key).FirstOrDefault();
                 return price.Value;
                 
             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("Ništa nema od cijene!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var price =
                     stock.StockValueHistory.OrderByDescending(p => p.Key).FirstOrDefault();
                 return price.Value;
             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("Ništa nema od cijene!");
             }
         }





         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             try
             {
                 if (!inIndexType.Equals(IndexTypes.AVERAGE) && !inIndexType.Equals(IndexTypes.WEIGHTED)) return;
                 var problem1 = IndexDict.Values.SingleOrDefault(p => p.type.Equals(IndexTypes.AVERAGE));
                 var problem2 = IndexDict.Values.SingleOrDefault(p => p.type.Equals(IndexTypes.WEIGHTED));
                 if (!IndexDict.ContainsKey(inIndexName.ToLower()) || !problem1.type.Equals(IndexTypes.AVERAGE) && !problem2.type.Equals(IndexTypes.WEIGHTED))
                 {
                     var index = new Index();
                     index.type = inIndexType;
                     IndexDict.Add(inIndexName.ToLower(), index);
                 }

                 else
                 {
                     throw new StockExchangeException("Tip indeksa nije dobar ili indeks postoji!");
                 }
             }
             catch (NullReferenceException)
             {

                 var index = new Index();
                 index.type = inIndexType;
                 IndexDict.Add(inIndexName.ToLower(), index); ;
             }

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 var indexPair = IndexDict.SingleOrDefault(p => p.Key == inIndexName.ToLower());
                 try
                 {
                     var index = indexPair.Value;
                     if (index.ListOfStockIndex.Exists(p => p.InStockName == inStockName.ToLower()))
                     {
                         throw new StockExchangeException("Pokušavate dodati dionicu koja je već dodana!");
                     }
                     index.ListOfStockIndex.Add(ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower()));
                     
                 }
                 catch (NullReferenceException)
                 {

                     throw new StockExchangeException("NULL");
                 }
             }
             else
             {
                 throw new StockExchangeException("Pokušavate pridjeliti nepostojeću dionicu!!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()) || !IndexDict.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji ili indeks s tim imenom ne postoji!");
             }
             var indexPair = IndexDict.SingleOrDefault(p => p.Key == inIndexName.ToLower());
             var index = indexPair.Value;
             if (index.ListOfStockIndex.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 index.ListOfStockIndex.RemoveAll(p => p.InStockName == inStockName.ToLower());
                 
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji u indeksu!");
             }

         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()) || !IndexDict.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji ili indeks s tim imenom ne postoji!");
             }
             var indexPair = IndexDict.SingleOrDefault(p => p.Key == inIndexName.ToLower());
             var index = indexPair.Value;
             if (index.ListOfStockIndex.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 return true;
             }
             return false;
             

         }

         

       
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             
             
             if (!IndexDict.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks s tim imenom ne postoji!");
             }
             var indexPair = IndexDict.SingleOrDefault(p => p.Key == inIndexName.ToLower());
             var index = indexPair.Value;

             if(index.type.Equals(IndexTypes.AVERAGE))
             {
                 decimal sum = 0;
                 foreach (var iterator in index.ListOfStockIndex)
                 {
                     var stockValue= iterator.StockValueHistory.Where(p => p.Key <= inTimeStamp)
                         .OrderByDescending(p => p.Key).FirstOrDefault();

                     sum += stockValue.Value;

                 }
                 return Math.Round((sum/index.ListOfStockIndex.Count),3);

             }
             
             if (index.type.Equals(IndexTypes.WEIGHTED))
             {
                 decimal sum = 0;
                 decimal sumStock = 0;
                 foreach (var iterator in index.ListOfStockIndex)
                 {
                     var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == iterator.InStockName);
                     if (stock != null)
                     {
                         sumStock += (GetInitialStockPrice(stock.InStockName)*stock.InNumberOfShares);


                     }
                     var stockValue = iterator.StockValueHistory.Where(p => p.Key <= inTimeStamp)
                         .OrderByDescending(p => p.Key).FirstOrDefault();
                     var value = stockValue.Value;
                     var numberOfShare = iterator.InNumberOfShares;
                     sum += (value*numberOfShare);
                 }
                 return Math.Round((sum/sumStock)*100,3);
             }
             return 0;
         }




         public bool IndexExists(string inIndexName)
         {
             var lowerString = inIndexName.ToLower();
             var index = IndexDict.SingleOrDefault(p => p.Key == lowerString);
             if (index.Key == null)
             {
                 return false;
             }
             
             return true;
         }

         public int NumberOfIndices()
         {
             return IndexDict.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexDict.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks s tim imenom ne postoji!");
             }
             var indexPair = IndexDict.SingleOrDefault(p => p.Key == inIndexName.ToLower());
             var index=indexPair.Value;
             return index.ListOfStockIndex.Count;
         }












         public void CreatePortfolio(string inPortfolioID)
         {
             if (ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID))
             {
                 throw new StockExchangeException("Duplikat portfolia!!!");
             }
             else
             {
                 var portfolio = new Portfolio {Id = inPortfolioID};
                 ListOfAllPortfolios.Add(portfolio);

             }


         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int max = 0;
             if (numberOfShares < 0 || !ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || !ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 throw new StockExchangeException("NE postoji portfolio ili ne postoji dionica ili pak broj dionica za dodavanje je prekomjeran!!!");
             }
             try
             {
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var list = ListOfAllPortfolios.Where(p => p.StockInPortfolio.ContainsKey(stock));

                 max += list.Sum(var => var.StockInPortfolio.Sum(p => p.Value));


                 if (stock != null && (portfolio.StockInPortfolio.ContainsKey(stock) && max < stock.InNumberOfShares))
                 {
                     if ((portfolio.StockInPortfolio[stock] + numberOfShares) <
                        stock.InNumberOfShares)
                     {
                         portfolio.StockInPortfolio[stock] = portfolio.StockInPortfolio[stock] + numberOfShares;
                     }
                     else
                     {
                         portfolio.StockInPortfolio[stock] = numberOfShares - portfolio.StockInPortfolio[stock];
                     }
                     
                     

                 }
                 else if (stock != null && (!portfolio.StockInPortfolio.ContainsKey(stock) && max < stock.InNumberOfShares))
                 {
                     if (numberOfShares <
                         stock.InNumberOfShares)
                     {
                         portfolio.StockInPortfolio.Add(stock, numberOfShares);

                     }
                     else
                     {
                         portfolio.StockInPortfolio.Add(stock,(int)(numberOfShares-stock.InNumberOfShares));
                     }
                    
                 }
                 
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("null");
             }
            
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || !ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 throw new StockExchangeException("NE postoji portfolio ili ne postoji dionica!!!");
             }
             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 if (portfolio.StockInPortfolio.ContainsKey(stock) && numberOfShares < portfolio.StockInPortfolio.Where(p => p.Key==stock).Sum(p => p.Value) && numberOfShares > 0)
                 {
                     if (stock != null)
                     {
                         var number = portfolio.StockInPortfolio[stock];
                         portfolio.StockInPortfolio[stock] = number - numberOfShares;
                     }
                     
                 }
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("opet null");
             }
            
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || !ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 throw new StockExchangeException("NE postoji portfolio ili ne postoji dionica!!!");
             }
             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 if (portfolio.StockInPortfolio.ContainsKey(stock))
                 {
                     portfolio.StockInPortfolio.Remove(stock);
                     
                 }
             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("opet null");
             }
         }

         public int NumberOfPortfolios()
         {
             return ListOfAllPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) )
             {
                 throw new StockExchangeException("NE postoji portfolio !!!");
             }
             try
             {
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 return portfolio.StockInPortfolio.Count;
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("i opet null");
             }
             


         }

         public bool PortfolioExists(string inPortfolioID)
         {
             
             var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
             if (portfolio == null)
             {
                 return false;
             }

             return true;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || !ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 return false;
                 
             }

             try
             {
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 if (portfolio.StockInPortfolio.ContainsKey(stock))
                 {
                     return true;
                 }
                 return false;
             }
             catch (NullReferenceException)
             {
                 
                 throw new StockExchangeException("Null jer nema portfolia s tim id-jem!");
             }
             
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || !ListOfAllStocks.Exists(p => p.InStockName == inStockName.ToLower()))
             {
                 throw new StockExchangeException("NE postoji portfolio ili ne postoji dionica!!!");
             }
             try
             {  
                 var stock = ListOfAllStocks.SingleOrDefault(p => p.InStockName == inStockName.ToLower());
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 return portfolio.StockInPortfolio.Where(p => p.Key ==stock ).Sum(p => p.Value);
             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("i opet null");
             }

         }

         

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal sum = 0;
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID))
             {
                 throw new StockExchangeException("NE postoji portfolio!!!");
             }
             try
             {
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 foreach (var keys in portfolio.StockInPortfolio.Keys)
                 {
                     var stockValue = keys.StockValueHistory.Where(p => p.Key <= timeStamp)
                         .OrderByDescending(p => p.Key).FirstOrDefault();
                     var value = stockValue.Value;
                     var number = portfolio.StockInPortfolio[keys];
                     sum += (value*number);
                 }
                 return sum;

             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("i opet null");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal sum = 0;
             decimal sum2 = 0;
             if (!ListOfAllPortfolios.Exists(p => p.Id == inPortfolioID) || Month>12)
             {
                 throw new StockExchangeException("NE postoji portfolio ili krivi mjesec!!!");
             }
             try
             {
                 var portfolio = ListOfAllPortfolios.SingleOrDefault(p => p.Id == inPortfolioID);
                 foreach (var keys in portfolio.StockInPortfolio.Keys)
                 {
                     var stockValue = keys.StockValueHistory.Where(p => p.Key <= new DateTime(Year, Month, 1, 0, 0, 0, 0))
                         .OrderByDescending(p => p.Key).FirstOrDefault();
                     var stockValue2 = keys.StockValueHistory.Where(p => p.Key <= new DateTime(Year, Month, 31, 23, 59,59, 999))
                         .OrderByDescending(p => p.Key).FirstOrDefault();
                     var value = stockValue.Value;
                     var value2 = stockValue2.Value;
                     var number = portfolio.StockInPortfolio[keys];
                     sum += value;
                     sum2 += value2;
                 }
                 return Math.Round(((sum2-sum)/sum)*100,3);

             }
             catch (NullReferenceException)
             {

                 throw new StockExchangeException("i opet null");
             }
         }
     }
}
