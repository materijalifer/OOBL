﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    /// <summary>
    /// Modelira ručni elektronički kalkulator, te može prikazati na display-u samo 10 znamenki
    /// </summary>
    public class Kalkulator:ICalculator
    {
        public IKalkulatorNumber memory = null;
        public IKalkulatorNumber leftOperand = null;
        public char? pendingBinaryOperation = null;
        public IKalkulatorNumber currentNumber = new EditableNumber();

        public void Press(char inPressedDigit)
        {
            currentNumber.RespondToInput(inPressedDigit, this);
        }

        public string GetCurrentDisplayState()
        {
            return currentNumber.ToString();
        }
        /// <summary>
        /// Vraća kalkulator u početno stanje
        /// </summary>
        public void ReturnToStartingState()
        {
            memory = null;
            leftOperand = null;
            pendingBinaryOperation = null;
            currentNumber = new EditableNumber();
        }
    }

    /// <summary>
    /// Modelira jedan broj ili sličan entitet u kalkulatoru
    /// </summary>
    public interface IKalkulatorNumber
    {
        /// <summary>
        /// Dohvaća decimalnu vrijednost ovog broja, koristi se za izračunavanje
        /// </summary>
        /// <returns>Decimalna vrijednost ovog broja</returns>
        decimal GetDecimalValue();

        /// <summary>
        /// String reprezentacija ovog broja, koristi se za ispis na display
        /// </summary>
        /// <returns></returns>
        string ToString();

        /// <summary>
        /// Slično oblikovnom obrascu Visitor, ovo je metoda koju kalkulator poziva nad trenutnim brojem prilikom pritiska
        /// na neku tipku na kalkulatoru
        /// </summary>
        /// <param name="input">Gumb koji je pritisnut na kalkulatoru</param>
        /// <param name="kalkulator">Kalkulator koji je pozvao ovu metodu, koristi se za osvježavanje stanja kalkulatora</param>
        void RespondToInput(char input, Kalkulator kalkulator);
    }
    /// <summary>
    /// Broj na zaslonu kojega korisnik još može mjenjati
    /// </summary>
    public class EditableNumber : IKalkulatorNumber
    {
        public StringBuilder numbersBeforeDecimalDot = new StringBuilder("0");
        public StringBuilder numbersAfterDecimalDot = new StringBuilder();
        public bool isNegative;
        public bool isDecimalDotAdded;
        /// <summary>
        /// Dali je broj uopće imao unosa? Ako nije, najćešće se može ignorirati
        /// </summary>
        public bool hadInput;
        /// <summary>
        /// Dali je unos nad ovim brojem gotov? Ako je, svaki novi unos znamenke stvoriti će novi broj na zaslonu
        /// </summary>
        private bool finishedInput;

        /// <summary>
        /// Slično oblikovnom obrascu Visitor, ovo je metoda koju kalkulator poziva nad trenutnim brojem prilikom pritiska
        /// na neku tipku na kalkulatoru
        /// </summary>
        /// <param name="input">Gumb koji je pritisnut na kalkulatoru</param>
        /// <param name="kalkulator">Kalkulator koji je pozvao ovu metodu, koristi se za osvježavanje stanja kalkulatora</param>
        public void RespondToInput(char input, Kalkulator kalkulator)
        {
            if (Char.IsDigit(input))
            {
                if (kalkulator.leftOperand == kalkulator.currentNumber)
                {
                    kalkulator.currentNumber = new EditableNumber();
                    kalkulator.currentNumber.RespondToInput(input, kalkulator);
                    return;
                }
                this.AddNum(input);
                hadInput = true;
            }
            else if (input == 'C')
            {
                kalkulator.currentNumber = new EditableNumber();
            }
            else if (input == 'M')
            {
                this.ChangeNegative();
            }
            else if (input == ',')
            {
                if (kalkulator.leftOperand == kalkulator.currentNumber)
                {
                    kalkulator.currentNumber = new EditableNumber();
                    kalkulator.currentNumber.RespondToInput(input, kalkulator);
                    return;
                }
                this.AddDecimalDot();
                hadInput = true;
            }
            else if (input == 'O')
            {
                kalkulator.ReturnToStartingState();
            }
            else if (input == '+' || input == '-' || input == '*' || input == '/')
            {
                if (kalkulator.leftOperand != null && kalkulator.leftOperand != kalkulator.currentNumber)
                {
                    DoBinaryOperation(kalkulator);
                    kalkulator.pendingBinaryOperation = input;
                    kalkulator.leftOperand = kalkulator.currentNumber;
                    return;
                }
                kalkulator.leftOperand = this;
                kalkulator.pendingBinaryOperation = input;
                finishedInput = true;
            }
            else if (input == '=')
            {
                if (kalkulator.leftOperand == null || kalkulator.pendingBinaryOperation == null) finishedInput = true;
                DoBinaryOperation(kalkulator);
                kalkulator.leftOperand = null;
                kalkulator.pendingBinaryOperation = null;
            }
            else if (input == 'S')
            {
                kalkulator.currentNumber = ImmutableNumber.CreateInstance((decimal)Math.Sin((double)GetDecimalValue()));
            }
            else if (input == 'K')
            {
                kalkulator.currentNumber = ImmutableNumber.CreateInstance((decimal)Math.Cos((double)GetDecimalValue()));
            }
            else if (input == 'T')
            {
                kalkulator.currentNumber = ImmutableNumber.CreateInstance((decimal)Math.Tan((double)GetDecimalValue()));
            }
            else if (input == 'Q')
            {
                kalkulator.currentNumber = ImmutableNumber.CreateInstance(GetDecimalValue() * GetDecimalValue());
            }
            else if (input == 'R')
            {
                try
                {
                    kalkulator.currentNumber = ImmutableNumber.CreateInstance((decimal)Math.Sqrt((double)GetDecimalValue()));
                }
                catch
                {
                    kalkulator.currentNumber = ErrorNumber.GetInstance();
                }
            }
            else if (input == 'I')
            {
                try
                {
                    kalkulator.currentNumber = ImmutableNumber.CreateInstance(1 / GetDecimalValue());
                }
                catch
                {
                    kalkulator.currentNumber = ErrorNumber.GetInstance();
                }
            }
            else if (input == 'P')
            {
                kalkulator.memory = this.getDeepCopy();
            }
            else if (input == 'G')
            {
                if (kalkulator.memory != null) kalkulator.currentNumber = kalkulator.memory;
            }
        }

        /// <summary>
        /// Obavi binarnu operaciju koja je trenutno spremljena kao "pending" u kalkulatoru. Ako nema takve operacije, ili lijevi
        /// operand kalkulatora nije postavljen, ne čini se ništa
        /// </summary>
        /// <param name="kalkulator">Kalkulator nad kojim se obavlja binarna operacija. Koristi se za osvježavanje stanja kalkulatora</param>
        private void DoBinaryOperation(Kalkulator kalkulator)
        {
            if (kalkulator.pendingBinaryOperation == null || kalkulator.leftOperand == null) return;
            if (kalkulator.pendingBinaryOperation == '+') kalkulator.currentNumber = ImmutableNumber.CreateInstance(
                 kalkulator.leftOperand.GetDecimalValue() + kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '-') kalkulator.currentNumber = ImmutableNumber.CreateInstance(
                    kalkulator.leftOperand.GetDecimalValue() - kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '*') kalkulator.currentNumber = ImmutableNumber.CreateInstance(
                 kalkulator.leftOperand.GetDecimalValue() * kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '/')
            {
                try
                {
                    kalkulator.currentNumber = ImmutableNumber.CreateInstance(kalkulator.leftOperand.GetDecimalValue() /
                        kalkulator.currentNumber.GetDecimalValue());
                }
                catch
                {
                    kalkulator.currentNumber = ErrorNumber.GetInstance();
                }
            }
        }

        /// <summary>
        /// Dodaje znamenku u broj. Ako je prosljeđeno nešto što nije znamenka, metoda ne čini ništa. Također, ako
        /// je broj veličine deset znamenki (ograničenje zaslona), metoda ne čini ništa
        /// </summary>
        /// <param name="num">Znamenka koja se dodaje u broj.</param>
        private void AddNum(char num)
        {
            if (GetNumberOfNumbers() == 10 || !Char.IsDigit(num)) return;
            if (!isDecimalDotAdded)
            {
                numbersBeforeDecimalDot.Append(num);
                trimLeadingZeroes(numbersBeforeDecimalDot);
            }
            else numbersAfterDecimalDot.Append(num);
        }

        /// <summary>
        /// Dohvaća broj znamenki u broju.
        /// </summary>
        /// <returns>Broj znamenki u broju</returns>
        private int GetNumberOfNumbers()
        {
            return numbersAfterDecimalDot.Length + numbersBeforeDecimalDot.Length;
        }

        /// <summary>
        /// Dodaje decimalnu točku u broj. Ako je decimalna točka već dodana, metoda ne čini ništa
        /// </summary>
        private void AddDecimalDot()
        {
            isDecimalDotAdded = true;
        }

        /// <summary>
        /// String reprezentacija unosivog broja, koristi se za ispis na zaslon kalkulatora.
        /// </summary>
        /// <returns>String reprezentacija broja</returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            if (isNegative) result.Append("-");
            result.Append(numbersBeforeDecimalDot);
            if (isDecimalDotAdded)
            {
                result.Append(',');
                result.Append(numbersAfterDecimalDot);
            }
            string returnResult = result.ToString();
            if (finishedInput && numbersAfterDecimalDot.Length > 0)
            {
                while (returnResult.ElementAt(returnResult.Length - 1) == '0') returnResult = returnResult.Remove(returnResult.Length - 1);
                if (returnResult.ElementAt(returnResult.Length - 1) == ',') returnResult = returnResult.Remove(returnResult.Length - 1);
            }
            return returnResult;
        }

        /// <summary>
        /// Mjenja predznak broja
        /// </summary>
        public void ChangeNegative()
        {
            isNegative = !isNegative;
        }

        /// <summary>
        /// Uklanja početne nule iz primjerka razreda StringBuilder
        /// </summary>
        /// <param name="sb">Primjerak razreda StringBuilder iz kojeg se uklanjaju početne nule</param>
        public static void trimLeadingZeroes(StringBuilder sb)
        {
            if (sb.ToString().ElementAt(0) == '0') sb.Remove(0, 1);
        }

        /// <summary>
        /// Dohvaća decimalnu vrijednost broja, koristi se prilikom izračuna
        /// </summary>
        /// <returns>Decimalna vrijednost broja</returns>
        public decimal GetDecimalValue()
        {
            string stringValue = this.ToString();
            stringValue = stringValue.Replace(",", ".");
            return Decimal.Parse(stringValue, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
        }

        /// <summary>
        /// Dohvaća "duboku" kopiju ovog unosivog broja, tj. broja koji ima istu vrijednost, ali ne djeli istu referencu sa
        /// primjerkom razreda nad kojim je pozvana metoda. Koristi se prilikom spremanja broja u memoriju, kako se promjene
        /// nebi očitovale i nad spremnjenim brojem.
        /// </summary>
        /// <returns>Duboka kopija broja</returns>
        private EditableNumber getDeepCopy()
        {
            EditableNumber ed = new EditableNumber();
            ed.numbersAfterDecimalDot = new StringBuilder(this.numbersAfterDecimalDot.ToString());
            ed.numbersBeforeDecimalDot = new StringBuilder(this.numbersBeforeDecimalDot.ToString());
            ed.isNegative = this.isNegative;
            ed.isDecimalDotAdded = this.isDecimalDotAdded;
            ed.hadInput = this.hadInput;
            ed.finishedInput = this.finishedInput;
            return ed;
        }
    }

    /// <summary>
    /// Predstavlja nepromjenjiv broj u kalkulatoru, primjerice rezultat operacija. Razred nema javni konstruktor, pošto moramo kontrolirati
    /// kako se stvara. Primjerice, ako želimo stvoriti nepromjenjivi broj veći od deset znakova a bez decimalne točke, moramo dobiti pogrešku
    /// (tj. primjerak razreda ErrorNumber)
    /// </summary>
    public class ImmutableNumber : IKalkulatorNumber
    {
        private decimal value;

        private ImmutableNumber(decimal value)
        {
            this.value = value;
        }

        /// <summary>
        /// Stvori primjerak razreda ImmutableNumber. Ako se proslijedi broj veći ili jednak deset milijardi, dobiva se primjerak razreda
        /// ErrorNumber. Također, ako broj ima više od deset znamenki (prije decimalne točke pluc poslije decimalne točke), broj se zaokružuje
        /// na deset znamenki.
        /// </summary>
        /// <param name="value">Vrijednost na koju se postavlja broj</param>
        /// <returns>Primjerak razreda ImmutableNumber zaokružen na deset znamenki ako je predana vrijedonst manja od deset milijardi,
        /// primjerak razreda ErrorNumber inače.</returns>
        public static IKalkulatorNumber CreateInstance(decimal value)
        {
            decimal absValue = Math.Abs(value);
            if (absValue >= 10000000000) return ErrorNumber.GetInstance();
            int numberOfNumbersBeforeDot = 1;
            if (absValue >= 10)
            {
                numberOfNumbersBeforeDot = (int)Math.Log10((double)absValue) + 1;
            }
            return new ImmutableNumber(Math.Round(value, 10 - numberOfNumbersBeforeDot));
        }

        /// <summary>
        /// Dohvaća decimalnu vrijednost broja, koristi se prilikom izračuna
        /// </summary>
        /// <returns>Decimalna vrijednost broja</returns>
        public decimal GetDecimalValue()
        {
            return value;
        }

        /// <summary>
        /// Slično oblikovnom obrascu Visitor, ovo je metoda koju kalkulator poziva nad trenutnim brojem prilikom pritiska
        /// na neku tipku na kalkulatoru.
        /// </summary>
        /// <param name="input">Gumb koji je pritisnut na kalkulatoru</param>
        /// <param name="kalkulator">Kalkulator koji je pozvao ovu metodu, koristi se za osvježavanje stanja kalkulatora</param>
        public void RespondToInput(char input, Kalkulator kalkulator)
        {
            if (Char.IsDigit(input) || input == ',')
            {
                kalkulator.currentNumber = new EditableNumber();
                kalkulator.currentNumber.RespondToInput(input, kalkulator);
                return;
            }
            else if (input == '+' || input == '-' || input == '*' || input == '/')
            {
                if (kalkulator.leftOperand != null && kalkulator.leftOperand != kalkulator.currentNumber)
                {
                    DoBinaryOperation(kalkulator);
                    kalkulator.leftOperand = kalkulator.currentNumber;
                    kalkulator.pendingBinaryOperation = input;
                    return;
                }
                kalkulator.leftOperand = this;
                kalkulator.pendingBinaryOperation = input;
            }
            else if (input == '=')
            {
                if (kalkulator.leftOperand == null || kalkulator.pendingBinaryOperation == null) return;
                DoBinaryOperation(kalkulator);
                kalkulator.leftOperand = null;
                kalkulator.pendingBinaryOperation = null;
            }
            else if (input == 'M')
            {
                kalkulator.currentNumber = new ImmutableNumber(value * -1);
            }
            else if (input == 'S')
            {
                kalkulator.currentNumber = new ImmutableNumber((decimal)Math.Sin((double)value));
            }
            else if (input == 'K')
            {
                kalkulator.currentNumber = new ImmutableNumber((decimal)Math.Cos((double)value));
            }
            else if (input == 'T')
            {
                kalkulator.currentNumber = new ImmutableNumber((decimal)Math.Tan((double)value));
            }
            else if (input == 'Q')
            {
                kalkulator.currentNumber = new ImmutableNumber(value * value);
            }
            else if (input == 'R')
            {
                try
                {
                    kalkulator.currentNumber = new ImmutableNumber((decimal)Math.Sqrt((double)value));
                }
                catch
                {
                    kalkulator.currentNumber = ErrorNumber.GetInstance();
                }
            }
            else if (input == 'I')
            {
                kalkulator.currentNumber = new ImmutableNumber(1 / value);
            }
            else if (input == 'P')
            {
                kalkulator.memory = this;
            }
            else if (input == 'G')
            {
                if (kalkulator.memory != null) kalkulator.currentNumber = kalkulator.memory;
            }
            else if (input == 'C')
            {
                kalkulator.currentNumber = new EditableNumber();
            }
            else if (input == 'O')
            {
                kalkulator.ReturnToStartingState();
            }
        }

        /// <summary>
        /// Obavi binarnu operaciju koja je trenutno spremljena kao "pending" u kalkulatoru. Ako nema takve operacije, ili lijevi
        /// operand kalkulatora nije postavljen, ne čini se ništa
        /// </summary>
        /// <param name="kalkulator">Kalkulator nad kojim se obavlja binarna operacija. Koristi se za osvježavanje stanja kalkulatora</param>
        private void DoBinaryOperation(Kalkulator kalkulator)
        {
            if (kalkulator.pendingBinaryOperation == null || kalkulator.leftOperand == null) return;
            if (kalkulator.pendingBinaryOperation == '+') kalkulator.currentNumber = new ImmutableNumber(
                 kalkulator.leftOperand.GetDecimalValue() + kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '-') kalkulator.currentNumber = new ImmutableNumber(
                 kalkulator.leftOperand.GetDecimalValue() - kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '*') kalkulator.currentNumber = new ImmutableNumber(
                 kalkulator.leftOperand.GetDecimalValue() + kalkulator.currentNumber.GetDecimalValue());
            if (kalkulator.pendingBinaryOperation == '/')
            {
                try
                {
                    kalkulator.currentNumber = new ImmutableNumber(kalkulator.leftOperand.GetDecimalValue() /
                        kalkulator.currentNumber.GetDecimalValue());
                }
                catch
                {
                    kalkulator.currentNumber = ErrorNumber.GetInstance();
                }
            }
        }

        /// <summary>
        /// String reprezentacija unosivog broja, koristi se za ispis na zaslon kalkulatora.
        /// </summary>
        /// <returns>String reprezentacija broja</returns>
        public override string ToString()
        {
            string returnResult = value.ToString();
            if (returnResult.Contains(","))
            {
                while (returnResult.ElementAt(returnResult.Length - 1) == '0') returnResult = returnResult.Remove(returnResult.Length - 1);
                if (returnResult.ElementAt(returnResult.Length - 1) == ',') returnResult = returnResult.Remove(returnResult.Length - 1);
            }
            return returnResult;
        }
    }

    /// <summary>
    /// Broj na kalkulatoru koji predstavlja grešku (overflow). Nije broj u pravom smislu te riječi. Organiziran je u obliku singleton-a.
    /// </summary>
    public class ErrorNumber : IKalkulatorNumber
    {
        private static ErrorNumber instance = new ErrorNumber();

        /// <summary>
        /// Privatni konstruktor.
        /// </summary>
        private ErrorNumber()
        {
        }

        /// <summary>
        /// Dohvati primjerak razreda ErrorNumber
        /// </summary>
        /// <returns>Primjerak razreda ErrorNumber</returns>
        public static ErrorNumber GetInstance()
        {
            return instance;
        }

        /// <summary>
        /// Dohvaća decimalnu vrijednost broja, koristi se prilikom izračuna. Ovaj razred za pozvanu ovu metodu
        /// baca iznimku NotImplementedException, pošto greška nema smislenu decimalnu vrijednost.
        /// </summary>
        /// <returns>Decimalna vrijednost broja</returns>
        public decimal GetDecimalValue()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// String reprezentacija unosivog broja, koristi se za ispis na zaslon kalkulatora.
        /// </summary>
        /// <returns>String reprezentacija broja</returns>
        public override string ToString()
        {
            return "-E-";
        }

        /// <summary>
        /// Slično oblikovnom obrascu Visitor, ovo je metoda koju kalkulator poziva nad trenutnim brojem prilikom pritiska
        /// na neku tipku na kalkulatoru. U ovom razredu ova metoda ne čini ništa osim za "Clear" i "On/Off"
        /// </summary>
        /// <param name="input">Gumb koji je pritisnut na kalkulatoru</param>
        /// <param name="kalkulator">Kalkulator koji je pozvao ovu metodu, koristi se za osvježavanje stanja kalkulatora</param>
        public void RespondToInput(char input, Kalkulator kalkulator)
        {
            if (input == 'O')
            {
                kalkulator.ReturnToStartingState();
            }
            else if (input == 'C')
            {
                kalkulator.currentNumber = new EditableNumber();
            }
        }
    }


}
