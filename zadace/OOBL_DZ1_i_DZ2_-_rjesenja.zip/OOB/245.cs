﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        
        
        //Trenutni binarni operator
        private char currentBinaryOperator = ' ';
        //Memorija
        private double? memory = null;

        //Stanja
        private double currentState = 0;
        private double? stateBeforeBinaryOperator = null;
      
        private string partialNumber = "";
        //Zastavica greske
        private bool errorFlag = false;

        //Znakovi prethodnih iteracija
        private char lastNonNumberFormer = ' ';
        private char lastNonUnaryNonP = ' ';
        private char previousChar = ' ';

        //Varijabla za pracenje predznaka
        private int minusActive = 1;

        //KONSTANTE
        private const int MAXDIGITS = 10;
        private const string ERROR = "-E-";


        /// <summary>
        /// Unosi zadani znak u kalkulator.
        /// </summary>
        /// <param name="inPressedDigit"></param>
        public void Press(char inPressedDigit)
        {
        
            char[] numberFormers = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ','};
            char[] memoryFunctions = { 'P', 'G'};
            char[] resetFunctions = { 'C', 'O' };
            char[] unaryOperators = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I'};
            char[] binaryOperators = {'+', '-', '*', '/'};
            
            //Slijedi obrada po navedenim skupinama(sveukupno 6 skupina jer je '=' izdvojen)
            //NUMBERFORMERS
            if (numberFormers.Contains(inPressedDigit))
            {
                if (errorFlag)
                    errorFlag = false;
                //2 + 3 = 
                //resetiraj stanja
                // unaryOperators.Contains(lastNonNumberFormer) && lastNonNumberFormer != 'M'
                if( previousChar == '=') 
                {
                    masterReset();
                }

                if (unaryOperators.Contains(lastNonNumberFormer) && lastNonNumberFormer != 'M' 
                    || previousChar == 'G')
                {
                    currentState = 0;
                    partialNumber = "";
                }
                //onemogucavanje 01 da je 01 nego 1
                //onemogucavanje da je 00, nego 0
                if (partialNumber.Length == 1 &&
                    partialNumber[0] == '0')
                {
                    partialNumber = "" + inPressedDigit;
                }
                else
                {
                    partialNumber += inPressedDigit;
                }
                if(partialNumber[0] == ',')
                    currentState = double.Parse("0"+partialNumber) * minusActive;
                else
                    currentState = double.Parse(partialNumber) * minusActive;

                fixCurrentState();
                previousChar = inPressedDigit;
                lastNonUnaryNonP = inPressedDigit;
                return;
            }
                //BINARY OPERATORS
            else if (binaryOperators.Contains(inPressedDigit))
            {

                minusActive = 1;
                //slucaj 2+-***- dakle promjena operatora na -
            
                if (binaryOperators.Contains(previousChar))
                {
                    currentBinaryOperator = inPressedDigit;
                }
                
                // '=' mora resetirati partialNumber
                
                //slucaj 2 + 3 +
                if (stateBeforeBinaryOperator.HasValue && ! binaryOperators.Contains(previousChar))
                {
                    if (currentBinaryOperator == '/' && currentState == 0)
                    {
                        errorFlag = true;
                        errorReset();
                        return;
                    }
                    currentState = doBinaryOperation(stateBeforeBinaryOperator.Value,
                        currentBinaryOperator, currentState);
                    fixCurrentState();
                }
                stateBeforeBinaryOperator = currentState;
                partialNumber = "";
                currentBinaryOperator = inPressedDigit;
                lastNonNumberFormer = inPressedDigit;
                previousChar = inPressedDigit;
                lastNonUnaryNonP = inPressedDigit;
                return;
            }
                //UNARY OPERATORS
            else if (unaryOperators.Contains(inPressedDigit))
            {
                
 
                //slucaj 2 + 3 + M 
                //M nema nikakvog utjecaja
                //preskoci ga
                //prethodni nije =, G, unarni(izuzevsi M)
                //trenutni je M 
                //preskoci!
                if (partialNumber.Length == 0 && previousChar != '=' && previousChar != 'G'
                    &&  ( unaryOperators.Contains(previousChar) && previousChar == 'M' || 
                    ! unaryOperators.Contains(previousChar) ) && inPressedDigit == 'M')
                {
                    previousChar = inPressedDigit;
                    return;
                } 
               
                switch (inPressedDigit)
                { 
                    case 'M':
                        currentState = -currentState;
                        minusActive *= -1;
                        break;
                    case 'S':
                        currentState = Math.Sin(currentState);
                        break;
                    case 'K':
                        currentState = Math.Cos(currentState);
                        break;
                    case 'T':
                        currentState = Math.Tan(currentState);
                        break;
                    case 'Q':
                        currentState *= currentState;
                        break;
                    case 'R':
                        if (currentState < 0) {
                            errorFlag = true;
                            errorReset();
                            return;
                        }
                        currentState = Math.Sqrt(currentState);
                        break;
                    case 'I':
                        if (currentState == 0)
                        {
                            errorFlag = true;
                            errorReset();
                            return;
                        }
                        currentState = 1 / currentState;
                        break;
               
                }


                fixCurrentState();
                //neka ne brise partialNumber u slucaju da je trenutni znak M!
                if(inPressedDigit != 'M')
                    partialNumber = "";
                lastNonNumberFormer = inPressedDigit;
                previousChar = inPressedDigit;
                if (inPressedDigit != 'M')
                    minusActive = 1;
                return;
            } 
                // ZNAK JEDNAKO =
            else if (inPressedDigit == '=')
            {
                
                // 2 = = = = = =
                if (! stateBeforeBinaryOperator.HasValue)
                {
                    partialNumber = "";
                    lastNonNumberFormer = inPressedDigit;
                    previousChar = inPressedDigit;
                    lastNonUnaryNonP = inPressedDigit;
                    minusActive = 1;
                    return;
                }
                // 2 + = ili 2 * =
                else if (binaryOperators.Contains(previousChar))
                {
                    if(previousChar == '/' && stateBeforeBinaryOperator.Value == 0)
                    {
                        errorFlag = true;
                        errorReset();
                        return;
                    }

                    currentState = doBinaryOperation(currentState, previousChar,
                        stateBeforeBinaryOperator.Value);
                    fixCurrentState();
                    //ne update stateBBO jer treba za daljnje operacije
                }
                else
                {
                    if (currentBinaryOperator == '/' && currentState == 0)
                    {
                        errorFlag = true;
                        errorReset();
                        return;
                    }
                    currentState = doBinaryOperation(stateBeforeBinaryOperator.Value,
                        currentBinaryOperator, currentState);
                    fixCurrentState();
                    stateBeforeBinaryOperator = null;
                }
                partialNumber = "";
                lastNonNumberFormer = inPressedDigit;
                previousChar = inPressedDigit;
                lastNonUnaryNonP = inPressedDigit;
                minusActive = 1;
                return;
            }
                //MEMORY FUNCTIONS
            else if (memoryFunctions.Contains(inPressedDigit))
            {
                if (inPressedDigit == 'P') {
                    memory = currentState;
                    //lastNonUnary = inPressedDigit; ne jer se nista ne dogada u slucaju 2 + unarni P i 
                }
                    //ne moze se nastaviti dodavati znamenke na dohvacen broj iz memorije
                else if (inPressedDigit == 'G')
                {
                    //prekida error
                    if (errorFlag)
                        errorFlag = false;
                    if (!memory.HasValue) {
                        errorFlag = true;
                        errorReset();
                        return;
                    }
                    currentState = memory.Value;
                    partialNumber = ""; 
                    lastNonUnaryNonP = inPressedDigit;
                    minusActive = 1;
                }
                lastNonNumberFormer = inPressedDigit;
                previousChar = inPressedDigit;
                return;

            }
                //RESET FUNCTIONS
            else if (resetFunctions.Contains(inPressedDigit))
            {
                //prekida error
                if (errorFlag)
                    errorFlag = false;

                if (inPressedDigit == 'C')
                { 
                    // 123 C
                    // G C
                    // = C
                    // nije slucaj "+ unarni C" jer unarni se preskoci
                    if(numberFormers.Contains(previousChar) || previousChar == 'G' || previousChar == '='
                        || unaryOperators.Contains(previousChar) && ! binaryOperators.Contains(lastNonUnaryNonP))
                    {
                        currentState = 0;
                    }                                           
                }
                else if (inPressedDigit == 'O')
                {
                    masterReset();
                    memory = null;
                }
                partialNumber = "";
                lastNonNumberFormer = inPressedDigit;
                lastNonUnaryNonP = inPressedDigit;
                previousChar = inPressedDigit;
                minusActive = 1;
                return;
            }

            //znak nije pronaden!
            errorFlag = true;
            errorReset();
            
        }

        /// <summary>
        /// Vraca vrijednost koja se nalazi na ekranu kalkulatora
        /// </summary>
        /// <returns></returns>
        public string GetCurrentDisplayState()
        {
            int maxLength = MAXDIGITS;
            //za slucaj prikazivanja zareza tijekom unosa brojeva
            if(partialNumber.Length != 0 && partialNumber.Contains(','))
            {
                maxLength++;
            }

            if (errorFlag)
                return ERROR;
            else if (partialNumber.Length != 0 && partialNumber.Length <= maxLength && partialNumber[0] != ',' )
            {
                if(minusActive == -1)
                    return "-" + partialNumber;
                else
                    return partialNumber;
            }

                
            else    
                return currentState.ToString();

        }

        /// <summary>
        /// Obavlja binarnu operaciju nad dva operanda first i second
        /// </summary>
        /// <param name="first"></param>
        /// <param name="oper"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        private double doBinaryOperation(double first, char oper, double second)
        {
            switch (oper)
            { 
                case '+':
                    return first + second;
                    
                case '-':
                    return first - second;
                   
                case '*':
                    return first * second;
                  
                case '/':
                    return first / second;
                    
            }
    
            throw new Exception("Not defined binary operation!");
            
        }
        /// <summary>
        /// Popravlja unos - pretvara ga u zapisivi broj
        /// Oslanja se na bool fixState(ref double state, int maxDigitsForThisState)
        /// </summary>
        private void fixCurrentState()
        {

            errorFlag = fixState(ref currentState, MAXDIGITS);
            if (errorFlag)
                errorReset();
            return;
        }

        private  bool fixState(ref double state, int maxDigitsForThisState)
        {
            int numberOfIntegerDigits = NumberOfIntegerDigits(state);
            if (numberOfIntegerDigits == 0)
                numberOfIntegerDigits = 1;
            int numberOfDecimalDigits = maxDigitsForThisState - numberOfIntegerDigits;
            //greska - previse znamenaka
            if (numberOfDecimalDigits < 0)
            {
                return true;
            }
                
            //provjera: ukoliko su zbog ogranicenja broja decimalnih znamenaka,
            //sve prikazive decimalne znamenke nula broj se prikazuje kao cjelobrojni
            double precision = Math.Pow(10, -numberOfDecimalDigits);

            if (numberOfDecimalDigits != 0 &&
                Math.Abs(currentState - Math.Truncate(currentState)) < precision)
            {
                state = Math.Truncate(currentState);
                return false;
            }
            state = Math.Round(currentState, numberOfDecimalDigits);
            return false;
        }


    
        /// <summary>
        /// Nasljanja se na errorReset(), dodatno brise zastavicu greske
        /// </summary>
        private void masterReset() 
        {
            errorReset();
            errorFlag = false;
        }

        /// <summary>
        /// Resetira koristene varijable i pohranjena stanja
        /// </summary>
        private void errorReset(){
            currentState = 0;
            currentBinaryOperator = ' ';
            lastNonNumberFormer = ' ' ;
            previousChar = ' ';
            stateBeforeBinaryOperator = null;
            partialNumber = "";
        }
        /// <summary>
        /// Racuna broj znamenaka lijevo od decimalne tocke
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        private int NumberOfIntegerDigits(double number)
        {
            long intPart = (long) Math.Floor(number);
            int result = 0;
            while (intPart > 0)
            {
                result++;
                intPart /= 10;
            }
            return result;

        }

    }


}
