﻿using System;
using System.Linq;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private bool isErrorState = false;

        private string _operand1 = "0";
        private string _operand2 = string.Empty;
        private char _operator1 = '\0';

        private string _memoryOperand = "0";
        private const int MaxDisplayNumberDigits = 10;

        private const char UnsetOperator = '\0';
        private const string ErrorMessage = "-E-";
        private string _currentDisplayState = "0";

        private const string BinaryOperators = "+-*/";
        private const string UnaryOperators = "SKTQRI";

        private bool IsOperand2Empty { get { return string.IsNullOrEmpty(_operand2); } }

        private bool IsOperator1Empty { get { return _operator1 == UnsetOperator; } }
        
        private char _lastPressedDigit = '\0';
        
        public void Press(char inPressedDigit)
        {
            try
            {
                // handle 0,1,2,3,4,5,6,7,8,9
                if (char.IsDigit(inPressedDigit))
                    HandlePressedDigit(inPressedDigit);
                    // handle unary operators M,S,K,T,Q,R,I, memory P,G, clear C, reset O
                else if (char.IsLetter(inPressedDigit))
                    HandlePressedLetter(inPressedDigit);
                else if (inPressedDigit == ',')
                    HandlePressedComma();
                else if (BinaryOperators.Contains(inPressedDigit))
                    HandleBinaryOperator(inPressedDigit);
                else if (inPressedDigit == '=')
                {
                    HandlePressedEqual();
                }
                else
                {
                    // what if sent digit is unknown?
                    // display error or?
                    throw new ArgumentException("Unknown Pressed Digit: '" + inPressedDigit + "'");
                }

                _lastPressedDigit = inPressedDigit;
            }
            catch (Exception e)
            {
                _currentDisplayState = ErrorMessage;
                isErrorState = true;
            }
        }

        public string GetCurrentDisplayState()
        {
            return _currentDisplayState;
        }

        private string FixOperandLeadZero(string operand)
        {
            string trimmedOperand = operand.TrimStart('0');
            
            // if operand was all zeros
            if (string.IsNullOrEmpty(trimmedOperand))
                trimmedOperand = "0";

            // if operand had only zeros in front of comma
            if(trimmedOperand[0] == ',')
                trimmedOperand = "0" + trimmedOperand;

            return trimmedOperand;
        }

        /// <summary>
        /// Popravi operand:
        /// ako je bio 12345, -> vrati 12345, 
        /// ako je imao više od 10 znamenaka ispred , -> javi grešku
        /// ako je imao više od 10 znamekana ispred+iza , -> zaokruži da ih ima 10
        /// </summary>
        private string FixOperand(string operand)
        {
            int minusOffset = (operand.StartsWith("-") ? -1 : 0);

            int digitsInFrontOfComma;
            if(operand.Contains(","))
                digitsInFrontOfComma = operand.Substring(-minusOffset).IndexOf(',');
            else
                digitsInFrontOfComma = operand.Length + minusOffset;
            if(digitsInFrontOfComma > MaxDisplayNumberDigits)
                throw new ArithmeticException("Maximum number of whole digits reached.");
            // this exception is handled in Press() method, where an error state is set

            if (operand.Contains(','))
            {
                int commaIndex = operand.IndexOf(',');
            
                int decimalDigitCount = operand.Substring(commaIndex + 1).Length;

                //                                  for comma + for "-"
                int totalDigitCount = operand.Length - 1 + minusOffset;

                // if total digit count exceeds max display number digits, round to [Max-(total-decimal)] digit count
                if (totalDigitCount > MaxDisplayNumberDigits)
                    return Math.Round(double.Parse(operand), MaxDisplayNumberDigits - totalDigitCount + decimalDigitCount).ToString();
                else
                {
                    // has comma, no max -> return operand

                    return operand;

                    /*
                    // if comma is on the last place, return number with comma
                    if (operand.EndsWith(","))
                        return double.Parse(operand).ToString() + ",";
                    // else comma will be included anyway, but you must return all the trailing zeros from input
                    else
                    {
                        return double.Parse(operand).ToString();
                    }*/
                }
            }
            else // No comma, no max digits -> return operand, without leading zeros -> case 0 and 02213
                return double.Parse(operand).ToString();
        }

        /// <summary>
        /// if operand contains comma, it trims zeros and comma from end
        /// assigns operand to current display state
        /// </summary>
        /// <param name="operand"></param>
        private void AssignCurrentDisplayState(string operand)
        {
            operand = FixOperand(operand);
            if(operand.Contains(','))
                _currentDisplayState = operand.TrimEnd('0').TrimEnd(',');
            else
                _currentDisplayState = operand;
        }

        /// <summary>
        /// Add digits to either first or second operand, depending on state of operator1.
        /// Adding digits may cause an error: if there are more than MaxDisplayNumberDigits digits in whole part
        /// </summary>
        /// <param name="digit"></param>
        private void HandlePressedDigit(char digit)
        {
            if(isErrorState)
                return;

            // if operator 1 is empty, we are still entering digits in operand 1
            // and operand1 should be displayed
            if (IsOperator1Empty)
            {
                _operand1 += digit;

                _operand1 = FixOperandLeadZero(_operand1);

                //_operand1 = FixOperand(_operand1);
                // operands are returned with comma, but current display state must be without trailing zeros and commas
                AssignCurrentDisplayState(_operand1);
            }
            else // we are entering digits in operand2, which should be displayed
            {
                _operand2 += digit;

                _operand2 = FixOperandLeadZero(_operand2);

                //_operand2 = FixOperand(_operand2);
                AssignCurrentDisplayState(_operand2);
            }
        }

        /// <summary>
        /// TODO: Decide on second comma in operand, currently causing error.
        /// </summary>
        private void HandlePressedComma()
        {
            if(isErrorState)
                return;

            if (IsOperator1Empty)
            {
                if(_operand1.Contains(','))
                    throw new ArgumentException("There is already comma in current operand");

                _operand1 += ',';
                _operand1 = FixOperand(_operand1);
                AssignCurrentDisplayState(_operand1);
            }
            else
            {
                if (_operand2.Contains(','))
                    throw new ArgumentException("There is already comma in current operand");

                _operand2 += ',';
                _operand2 = FixOperand(_operand2);
                AssignCurrentDisplayState(_operand2);
            }
        }

        /// <summary>
        /// Last binary operator is stored
        /// If last entered key was unary operator, result of last edited operand is in current display state 
        /// </summary>
        /// <param name="binaryOperator"></param>
        private void HandleBinaryOperator(char binaryOperator)
        {
            if(isErrorState)
                return;

            // if first binary operator is not set, just set it
            if (IsOperator1Empty)
            {
                _operator1 = binaryOperator;

                // if last pressed key was unary operator, result of operand1 is in current display state, fetch it back
                if (UnaryOperators.Contains(_lastPressedDigit))
                {
                    _operand1 = _currentDisplayState;
                }
            }
            else
            {
                // if there is second operand, we had binary operator
                if (!IsOperand2Empty)
                {
                    double operand2;
                    // if last pressed digit was unary operator
                    if (UnaryOperators.Contains(_lastPressedDigit))
                    {
                        //then result of operand2 is in _currentDisplayState
                        operand2 = double.Parse(_currentDisplayState);
                    }
                    else
                    {
                        operand2 = double.Parse(_operand2);
                    }

                    double operand1 = double.Parse(_operand1);

                    // calculate the result of operands and set operator1 
                    double result = ApplyBinaryOperator(operand1, _operator1, operand2);

                    // store the result in operand 1
                    _operand1 = FixOperand(result.ToString());

                    // set display state to operand1
                    AssignCurrentDisplayState(_operand1);

                    // set operator1 to binary operator
                    _operator1 = binaryOperator;

                    // set _operand2 to empty
                    _operand2 = string.Empty;
                }
                // there is no second operand, remember this binary operator as operator1
                else
                {
                    _operator1 = binaryOperator;

                    // if last pressed key was unary operator, result of operand1 is in current display state, fetch it back
                    if (UnaryOperators.Contains(_lastPressedDigit))
                    {
                        _operand1 = _currentDisplayState;
                    }
                }
            }
        }

        /// <summary>
        /// Applies binary operator to two operands. Allowed operators are +,-,*,/
        /// </summary>
        private double ApplyBinaryOperator(double operand1, char op, double operand2)
        {
            switch (op)
            {
                case '+':
                    return operand1 + operand2;
                case '-':
                    return operand1 - operand2;
                case '*':
                    return operand1 * operand2;
                case '/':
                    if(Math.Abs(operand2) < double.Epsilon)
                        throw new ArithmeticException("Operand 2 is 0, which is not allowed in division.");
                    return operand1/operand2;
                default: 
                    throw new ArgumentException("Operator " + op + " is not recognized as a binary operator.");
            }
        }

        /// <summary>
        /// if operand 2 is set, apply and assign to current state
        ///      if last pressed is unary, operator2 double is fetched from current state
        /// if operator 1 is set, but operand 2 unset, apply operand1 operator1 operand1, and assign to current state
        /// if operator 1 is unset
        ///     if last pressed is unary, operator1 double is fetched from current state
        /// 
        /// unset operand2 and operator1 
        /// </summary>
        private void HandlePressedEqual()
        {
            if(isErrorState)
                return;

            // if there is operand 2
            if (!IsOperand2Empty)
            {
                double operand2;
                if (UnaryOperators.Contains(_lastPressedDigit))
                    //then result of operand2 is in _currentDisplayState
                    operand2 = double.Parse(_currentDisplayState);
                else
                    operand2 = double.Parse(_operand2);

                double operand1 = double.Parse(_operand1);

                // calculate the result of operands and set operator1 
                double result = ApplyBinaryOperator(operand1, _operator1, operand2);

                // store the result in operand 1
                _operand1 = FixOperand(result.ToString());

                // set display state to operand1
                AssignCurrentDisplayState(_operand1);

                // set operator1 to binary operator
                _operator1 = UnsetOperator;

                // set _operand2 to empty
                _operand2 = string.Empty;

            }
            else // there is no operand 2
            {
                // if there is no operand 1
                if (IsOperator1Empty)
                {
                    if (UnaryOperators.Contains(_lastPressedDigit))
                        //then result of operand1 is in _currentDisplayState, only set operand1 to current state
                        _operand1 = _currentDisplayState;
                    else // else assign current display state to operand1
                        AssignCurrentDisplayState(_operand1);
                }
                else // there is operator1, but no operand2, so 2+= -> 2+2=
                    // use operand1 as operand 2
                {
                    double operand1;
                    if (UnaryOperators.Contains(_lastPressedDigit))
                        //then result of operand1 is in _currentDisplayState
                        operand1 = double.Parse(_currentDisplayState);
                    else
                        operand1 = double.Parse(_operand1);

                    // use operand1 as operand 2
                    double operand2 = operand1;

                    // calculate the result of operands and set operator1 
                    double result = ApplyBinaryOperator(operand1, _operator1, operand2);

                    // store the result in operand 1
                    _operand1 = FixOperand(result.ToString());

                    // set display state to operand1
                    AssignCurrentDisplayState(_operand1);

                    // set operator1 to binary operator
                    _operator1 = UnsetOperator;

                    // set _operand2 to empty
                    _operand2 = string.Empty;
                }
            }
        }
        
        /// <summary>
        /// repeated unary operators take value from current display state, get applied and assign value again to current display state
        /// </summary>
        /// <param name="letter"></param>
        private void HandlePressedLetter(char letter)
        {
            if(isErrorState && letter!='O')
                return;
            
            if (UnaryOperators.Contains(letter))
                HandleUnaryOperator(letter);
            else
            switch (letter)
            {
                /// Provjera {broj1} {binarni} {unarni} {broj1} = {broj1}{binarni}{broj2}
                /// unarni se izračuna i prikaže ali se ne uzima u obzir u binarnoj operaciji
                case 'M':
                    // change the signing of the operand in question
                    // what if operand is only "0"?
                    if (IsOperator1Empty)
                    {
                        if (_operand1.StartsWith("-"))
                            _operand1.TrimStart('-');
                        else
                            _operand1 = '-' + _operand1;
                        AssignCurrentDisplayState(_operand1);
                    }
                    else
                    {
                        if (_operand2.StartsWith("-"))
                            _operand2.TrimStart('-');
                        else
                            _operand2 = '-' + _operand2;
                        AssignCurrentDisplayState(_operand2);
                    }

                    break;

                    // Put in memory, do not change display state
                case 'P':
                    if (IsOperator1Empty)
                        _memoryOperand = _operand1;
                    else 
                        _memoryOperand = _operand2;
                    break;

                    // Get from memory
                case 'G':
                    
                    /*
                    string tempOperand = _memoryOperand;
                    int digits = tempOperand.Length - (tempOperand.Contains(',') ? 1 : 0)
                        - (tempOperand.StartsWith("-")?1:0);
                    if (digits > MaxDisplayNumberDigits)
                        _memoryOperand = Math.Round(double.Parse(_memoryOperand), MaxDisplayNumberDigits).ToString();
                    else
                        _memoryOperand = double.Parse(_memoryOperand).ToString();
                    
                    */

                    // set display state to operand in question
                    if (IsOperator1Empty)
                    {
                        _operand1 = _memoryOperand;
                        AssignCurrentDisplayState(_operand1);
                    }
                    else
                    {
                        _operand2 = _memoryOperand;
                        AssignCurrentDisplayState(_operand2);
                    }

                    break;

                    // Clear screen - TODO: currenty clears last operand/operator inserted, 
                    // but does not clear error
                case 'C':
                   
                    // if operand 2 is not empty, clear it
                    if (!IsOperand2Empty)
                    {
                        _operand2 = "0";
                        AssignCurrentDisplayState(_operand2);
                    }
                    else // operand 2 is empty
                    {
                        if (IsOperator1Empty)
                        {
                            // clear operand1
                            _operand1 = "0";
                            AssignCurrentDisplayState(_operand1);
                        }
                        else
                        {
                            // clear operator1 and operand 1
                            _operator1 = UnsetOperator;
                            _operand1 = "0";
                            AssignCurrentDisplayState(_operand1);
                        }
                    }

                    _currentDisplayState = "0";
                    break;

                    // Reset calculator
                case 'O':
                    // TODO: move this in reset function? and add in ctor?
                    _operand1 = "0";
                    _operand2 = string.Empty;
                    _operator1 = UnsetOperator;
                    _memoryOperand = "0";
                    isErrorState = false;
                    _currentDisplayState = "0";

                    break;

                default:
                    throw new ArgumentException();
            }
        }

        /// <summary>
        /// Handles unary operator:
        /// if operand 2 is not set, and operator 1 is set, throw exception
        /// 
        /// </summary>
        /// <param name="unaryOperator"></param>
        private void HandleUnaryOperator(char unaryOperator)
        {
            if (!IsOperator1Empty)
            {
                if(IsOperand2Empty)
                {
                    // use operand1
                    AssignCurrentDisplayState(ExecuteUnaryOperator(unaryOperator, _operand1));
                }
                else // operand 2 is not empty, apply unary operator to it and put result in current display state
                {
                    // if last input digit was unary operator, fetch result from current display state

                    if (UnaryOperators.Contains(_lastPressedDigit))
                    {
                       AssignCurrentDisplayState(ExecuteUnaryOperator(unaryOperator, _currentDisplayState));
                    }
                    else
                    {
                        AssignCurrentDisplayState(ExecuteUnaryOperator(unaryOperator, _operand2));
                    }
                }
            }
            else // operator 1 is empty
            {
                if (UnaryOperators.Contains(_lastPressedDigit))
                {
                    AssignCurrentDisplayState(ExecuteUnaryOperator(unaryOperator, _currentDisplayState));
                }
                else
                {
                    AssignCurrentDisplayState(ExecuteUnaryOperator(unaryOperator, _operand1));
                }
            }

            /*
            // ako nije postavljen operator1, izvrsi nad operandom 1, 
            if (_operator1 == UnsetOperator)
            {
                _operand1 = ExecuteUnaryOperator(unaryOperator, _operand1);
                if(_memoryOperand != ErrorMessage)
                    _memoryOperand = _operand1;
            }
            else
            // ako je postavljen operator 1 ali ne i operand 2, promijeni display primjenom unarnog,
            // ali ne prikazi ga u konacnom rezultatu
            {
                if (string.IsNullOrEmpty(_operand2))
                {
                    string tempOperand1 = _operand1;
                    ExecuteUnaryOperator(unaryOperator, tempOperand1);
                    if (_memoryOperand != ErrorMessage)
                        _memoryOperand = tempOperand1;
                }
                    // inace nad operandom 2
                else
                {
                    _operand2 = ExecuteUnaryOperator(unaryOperator, _operand2);
                    if (_memoryOperand != ErrorMessage)
                        _memoryOperand = _operand2;
                }
            }*/
        }

        private string ExecuteUnaryOperator(char unaryOperator, string operand)
        {
            operand = FixOperand(operand);           

            switch (unaryOperator)
            {
                case 'S':
                    operand = Math.Sin(double.Parse(operand)).ToString();
                    break;

                case 'K':
                    operand = Math.Cos(double.Parse(operand)).ToString();
                    break;

                case 'T':
                    operand = Math.Tan(double.Parse(operand)).ToString();
                    break;

                case 'Q':
                    double op = double.Parse(operand);
                    operand = (op*op).ToString();
                    break;

                case 'R':
                    if(double.Parse(operand) < 0)
                    {
                        _memoryOperand = ErrorMessage;
                        return "0";
                    }

                    operand = Math.Sqrt(double.Parse(operand)).ToString();
                    break;

                case 'I':
                    if (double.Parse(operand) == 0)
                    {
                       throw new ArithmeticException("Tried to make inverse of 0.");
                    }
                    else
                    {
                        operand = (1.0/double.Parse(operand)).ToString();
                    }
                    break;

                default:
                    throw new ArgumentException();
            }
            return FixOperand(operand);
        }
    }
}
