﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public Kalkulator()
        {
            //registracija operacija
            operationsBI.Add('+', Add);
            operationsBI.Add('-', Sub);
            operationsBI.Add('*', Mul);
            operationsBI.Add('/', Div);
            operationsUN.Add('S', Math.Sin);
            operationsUN.Add('K', Math.Cos);
            operationsUN.Add('T', Math.Tan);
            operationsUN.Add('Q', Sqr);
            operationsUN.Add('I', Inv);
        }
        public void Press(char inPressedDigit)
        {
            rawinput += inPressedDigit;
            var input = inPressedDigit;

            #region Digit
            if (input > 47 && input < 58)
            {
                if (OPentered)
                {
                    display = "";
                    OPentered = false;
                }

                display += input;
                //višak početnih nula
                if (display.Count() == 2 && display[0] == '0' && display[1] == '0')
                {
                    display = display.Remove(0, 1);
                }
            } 
            #endregion

            #region ,
            if (input == ',')
            {
                if (OPentered)
                {
                    display = "";
                    OPentered = false;
                }
                if (!display.Contains(","))
                {
                    display += input; 
                }               
            } 
            #endregion

            #region Binary operators
            if (binaryOP.Contains(input))
            {
                #region Više operatora zaredom
                if (binaryOP.Contains(rawinput.Last()) && binaryOP.Contains(rawinput[rawinput.Count() - 2]))
                {
                    //više uzastopnih minusa
                    if (rawinput.Last() == '-' && rawinput[rawinput.Count() - 2] == '-')
                    {
                        if (operation == '+')
                        {
                            operation = '-';
                        }
                        else
                        {
                            operation = '+';
                        }
                    }
                    else
                    {
                        operation = binaryOP.First(a => a == input);
                    }
                } 
                #endregion

                else
                {
                    //dohvat prvog operanda
                    if (operand1 == null)
                    {
                        OPentered = true;
                        operand1 = Convert(display);
                        display = DisplayCheck(operand1.ToString());
                        operation = binaryOP.First(a => a == input);
                    }

                    //dohvat drugog operatora i izracun operacije, priprema za daljni unos
                    else
                    {
                        try
                        {
                            OPentered = true;
                            operand2 = Convert(display);
                            operand1 = operationsBI[operation](operand1, operand2);
                            display = DisplayCheck(operand1.ToString());
                            operand2 = null;
                            operation = binaryOP.First(a => a == input);
                        }
                        catch (Exception)
                        {
                            display = "-E-";
                            operand1 = null;
                            operand2 = null;
                            OPentered = true;
                        }
                    } 
                }
            } 
            #endregion

            #region Unary operators
            if (unaryOP.Contains(input))
            {
                char? operationUN = unaryOP.First(a => a == input);
                try
                {
                    display =DisplayCheck(operationsUN[operationUN]((double)Convert(display)).ToString());
                    OPentered = true;
                }
                catch (Exception)
                {
                    display = "-E-";
                    operand1 = null;
                    operand2 = null;
                    OPentered = true;
                }
            }
            #endregion

            #region =
            if (input == '=')
            {
                //potrebno izvršiti operaciju
                if (operation != null)
                {
                    try
                    {   //skraceni zapis
                        if (binaryOP.Contains(rawinput[rawinput.Count() - 2]))
                        {
                            operand1 = operationsBI[operation](operand1, operand1);
                            display =DisplayCheck(operand1.ToString());
                            operation = null;
                            OPentered = true;
                            operand1 = null;

                        }        

                        //obican zapis
                        else
                        {
                            operand2 = Convert(display);
                            operand1 = operationsBI[operation](operand1, operand2);
                            display = DisplayCheck(operand1.ToString());
                            OPentered = true;
                            operation = null;
                            operand1 = null;
                        }
                    }
                    catch (Exception)
                    {
                        display = "-E-";
                        operand1 = null;
                        operand2 = null;
                        OPentered = true;
                    }
                }
                //samo prikaz broja
                else
                {
                    display = DisplayCheck(display);
                }
            }
            #endregion

            #region Minus
            if (input == 'M')
            {//radi samo kada ekran nije prazan
                if (display.Count() != 0)
                {

                    if (display[0] == '-')
                    {
                        display = display.Remove(0, 1);
                    }
                    else
                    {
                        display = display.Insert(0, "-");
                    }
                }
            } 
            #endregion

            #region On/Off
            if (input == 'O')
            {
                display = "";
                memory = "";
                rawinput = "";
                OPentered = true;
                operation = null;
                operand1 = null;
                operand2 = null;
            } 
            #endregion

            #region Memory
            if (input == 'P')
            {//spremi
                memory = display;
            }

            if (input == 'G')
            {//dohvati
                display = memory;
                OPentered = true;
            } 
            #endregion

            #region Clear
            if (input == 'C')
            {
                display = "";
            } 
            #endregion
         
        }

        public string GetCurrentDisplayState()
        {
            //prazan ekran ili samo zarez
            if (display == "" || display == ",")
            {
                display = "0";
            }

            //zarez na pocetku broja
            if (display[0] == ',')
            {
                display = display.Insert(0, "0");
            }
            
            #region Više od 10 znakova
            if (display.Count() > 10)
            {
                int counter = 0;
                foreach (var digit in display)
                {
                    if (digit > 47 && digit < 58)
                    {
                        counter++;
                    }
                }
                //previse znamenki
                if (counter > 10)
                {
                    var temp = Convert(display);
                    var cjelobrojno = (Math.Truncate(Math.Abs(temp))).ToString().Count();
                    if (cjelobrojno > 10)//greska, previse znamenki cjelobrojnog dijela
                    {
                        return "-E-";
                    }

                    //zaokruzi
                    display = Math.Round(temp, 10 - cjelobrojno).ToString();
                    while (display.Last() == '0' && display.Contains(','))
                    {
                        display = display.Remove(display.Count() - 1);
                    }
                    return display;
                }
            }
            #endregion
            
            return display;
        }

        //matematicke operacije
        private decimal? Add(decimal? x, decimal? y)
        { return x + y; }
        private decimal? Sub(decimal? x, decimal? y)
        { return x - y; }
        private decimal? Mul(decimal? x, decimal? y)
        { return x * y; }
        private decimal? Div(decimal? x, decimal? y)
        {
            if (y == 0)
                throw new Exception();
            return x / y; 
        }
        private double Sqr(double x)
        { return Math.Pow(x, 2); }
        private double Inv(double x)
        {
            if (x == 0)
                throw new Exception();
            return 1 / x; 
        }

        //pretvorba 
        private decimal Convert(string display)
        {
            if (display=="" || display==",")
            {
                return 0;
            }
            else
            {
                return System.Convert.ToDecimal(display);
            }
        }

        //provjera display-a
        private string DisplayCheck(string display)
        {
            //ako nije greška odradi pretvorbu radi obrade praznog ekrana ili samo zareza
            if (display != "-E-")
            {
                display = Convert(display).ToString();
            }

            //nule na kraju decimalnog broja
            while (display.Last() == '0' && display.Contains(','))
            {
                display = display.Remove(display.Count() - 1);
            }

            //zarez na kraju broja
            if (display.Last() == ',')
            {
                display = display.Remove(display.Count() - 1);
            }

            return display;
        }

        private string display = "";
        private bool OPentered=true;
        private decimal? operand1=null;
        private decimal? operand2 = null;
        private char? operation =null;
        private string binaryOP="+-*/";
        private string unaryOP = "SKTQI";
        private string memory = "";
        private string rawinput="";
        //binarne operacije
        private Dictionary<char?, Func<decimal?,decimal?,decimal?>> operationsBI=new Dictionary<char?,Func<decimal?,decimal?,decimal?>>();
        //unarne operacije
        private Dictionary<char?, Func<double, double>> operationsUN = new Dictionary<char?, Func<double, double>>();
    }


}
