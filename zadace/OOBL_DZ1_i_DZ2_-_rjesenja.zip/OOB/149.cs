﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        private Dictionary<string, StockIndex> indices = new Dictionary<string, StockIndex>();
        private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (this.stocks.ContainsKey(stockName))
            {
                // Check if stock already exists
                throw new StockExchangeException("Dionica sa zadanim imenom već postoji");
            }

            Stock stock = new Stock(stockName, inInitialPrice, inNumberOfShares, inTimeStamp);
            this.stocks.Add(stock.Name, stock);
        }

        public void DelistStock(string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Dionica ne postoji");
            }

            Stock stock = this.stocks[stockName];

            // Remove stock from stocks collection
            this.stocks.Remove(stockName);

            // Remove stock from all indices
            List<StockIndex> indices = this.indices.Values.Where(index => index.ContainsStock(stock)).ToList();
            foreach(StockIndex index in indices)
            {
                index.RemoveStock(stock);
            }

            // Remove stock from all portoflios
            List<Portfolio> portfolios = this.portfolios.Values.Where(portfolio => portfolio.ContainsStock(stock)).ToList();
            foreach (Portfolio portfolio in portfolios)
            {
                portfolio.RemoveStock(stock);
            }
        }

        public bool StockExists(string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            return this.stocks.ContainsKey(inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return this.stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if(!this.stocks.ContainsKey(stockName))
            {
                // Check if stock already exists
                throw new StockExchangeException("Nepostojeća dionica");
            }

            Stock stock = this.stocks[stockName];
            stock.SetPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Nepostojeća dionica");
            }

            Stock stock = this.stocks[stockName];
            return stock.GetPriceByTimestamp(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Nepostojeća dionica");
            }

            Stock stock = this.stocks[stockName];
            return stock.InitPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inStockName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Nepostojeća dionica");
            }

            Stock stock = this.stocks[stockName];
            return stock.Price;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            if (this.indices.ContainsKey(indexName))
            {
                // Check if already exists
                throw new StockExchangeException("Indeks već postoji");
            }

            StockIndex index = StockIndexFactory.CreateStockIndex(indexName, inIndexType);
            this.indices.Add(index.Name, index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();
            if (!this.indices.ContainsKey(indexName))
            {
                // Check if index exists
                throw new StockExchangeException("Indeks ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Dionica ne postoji");
            }

            StockIndex index = this.indices[indexName];
            index.AddStock(this.stocks[stockName]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();
            if (!this.indices.ContainsKey(indexName))
            {
                throw new StockExchangeException("Indeks ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                throw new StockExchangeException("Dionica ne postoji");
            }

            StockIndex index = this.indices[indexName];
            Stock stock = this.stocks[stockName];
            index.RemoveStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();
            if (!this.indices.ContainsKey(indexName))
            {
                throw new StockExchangeException("Indeks ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                throw new StockExchangeException("Dionica ne postoji");
            }

            StockIndex index = this.indices[indexName];
            Stock stock = this.stocks[stockName];
            return index.ContainsStock(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            if (!this.indices.ContainsKey(indexName))
            {
                throw new StockExchangeException("Indeks ne postoji");
            }

            StockIndex index = this.indices[indexName];
            return Decimal.Round(index.Value, 3);
        }

        public bool IndexExists(string inIndexName)
        {
            return this.indices.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return this.indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            // Guards
            if (String.IsNullOrEmpty(inIndexName))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string indexName = inIndexName.ToLower();
            if (!this.indices.ContainsKey(indexName))
            {
                throw new StockExchangeException("Indeks ne postoji");
            }

            StockIndex index = this.indices[indexName];
            return index.NumberOfStocks;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            if (this.portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj već postoji");
            }

            Portfolio portfolio = new Portfolio(inPortfolioID);
            this.portfolios.Add(portfolio.ID, portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                // Check if portfolio exists
                throw new StockExchangeException("Portfelj ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                // Check if stock exists
                throw new StockExchangeException("Dionica ne postoji");
            }

            // Check if there is available enough shares
            Stock stock = this.stocks[stockName];
            long sharesInPortfolios = this.portfolios.Values.Where(p => p.ContainsStock(stock)).
                Sum(p => p.NumberOfShares(stock));

            if (numberOfShares + sharesInPortfolios > stock.TotalShares)
            {
                throw new StockExchangeException("Prekoračenje broja dionica");
            }

            this.portfolios[inPortfolioID].AddStockShares(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                // Check if portfolio exists
                throw new StockExchangeException("Portfelj ne postoji");
            }
            else if (!this.stocks.ContainsKey(inStockName.ToLower()))
            {
                // Check if stock exists
                throw new StockExchangeException("Dionica ne postoji");
            }

            Stock stock = this.stocks[inStockName.ToLower()];
            Portfolio portfolio = this.portfolios[inPortfolioID];
            portfolio.RemoveShares(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                throw new StockExchangeException("Dionica ne postoji");
            }

            Stock stock = this.stocks[stockName];
            Portfolio portfolio = this.portfolios[inPortfolioID];
            portfolio.RemoveStock(stock);
        }

        public int NumberOfPortfolios()
        {
            return this.portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji");
            }

            Portfolio portfolio = this.portfolios[inPortfolioID];
            return portfolio.NumberOfStocks;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            return this.portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                throw new StockExchangeException("Dionica ne postoji");
            }

            Stock stock = this.stocks[stockName];
            Portfolio portfolio = this.portfolios[inPortfolioID];
            return portfolio.ContainsStock(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            string stockName = inStockName.ToLower();
            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj ne postoji");
            }
            else if (!this.stocks.ContainsKey(stockName))
            {
                throw new StockExchangeException("Dionica ne postoji");
            }

            Stock stock = this.stocks[stockName];
            Portfolio portfolio = this.portfolios[inPortfolioID];
            return portfolio.NumberOfShares(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                // Check if portfolio exists
                throw new StockExchangeException("Nepostojeći portfelj");
            }

            Portfolio portfolio = this.portfolios[inPortfolioID];
            return Decimal.Round(portfolio.GetValue(timeStamp), 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            // Guards
            if (String.IsNullOrEmpty(inPortfolioID))
            {
                // Name validation
                throw new StockExchangeException("Naziv ne smije biti prazan");
            }

            if (!this.portfolios.ContainsKey(inPortfolioID))
            {
                // Check if portfolio exists
                throw new StockExchangeException("Nepostojeći portfelj");
            }

            Portfolio portfolio = this.portfolios[inPortfolioID];
            return Decimal.Round(portfolio.GetPercentChangeInValueForMonth(Year, Month) * 100, 3);
        }
    }

    public class Stock
    {
        private string name;
        private long totalShares;
        private List<StockSharePrice> prices = new List<StockSharePrice>();

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public long TotalShares
        {
            get
            {
                return this.totalShares;
            }
        }

        public decimal Price
        {
            get
            {
                DateTime lastTimestamp = this.prices.Max(price => price.Timestamp);
                return this.prices.First(price => price.Timestamp.Equals(lastTimestamp)).Price;
            }
        }

        public decimal InitPrice
        {
            get
            {
                DateTime minTimestamp = this.prices.Min(price => price.Timestamp); 
                return this.prices.First(price => price.Timestamp.Equals(minTimestamp)).Price;
            }
        }

        public Stock(string name, decimal initPrice, long numOfShares, DateTime initTimestamp)
        {
            // Guards
            if (String.IsNullOrEmpty(name))
            {
                // Name can't be empty or null
                throw new StockExchangeException("Neispravan naziv dionice");
            }
            else if (numOfShares < 1L)
            {
                // Number of shares must be positive value
                throw new StockExchangeException("Broj dionica mora biti veci od 0");
            }

            this.name = name.ToLower(); // Name is case insensitive
            StockSharePrice stockPrice = new StockSharePrice(initPrice, initTimestamp);
            this.prices.Add(stockPrice);
            this.totalShares = numOfShares;
        } 

        public void SetPrice(decimal price, DateTime timestamp)
        {
            // Guards
            if(this.prices.Where(p => p.Timestamp.Equals(timestamp)).Count() > 0)
            {
                // There must not be price with same timestamp
                throw new StockExchangeException("Cijena za zadano vrijeme je već definirana");
            }

            StockSharePrice stockPrice = new StockSharePrice(price, timestamp);
            this.prices.Add(stockPrice);
        }

        public decimal GetPriceByTimestamp(DateTime timestamp)
        {
            // Guards

            // There must be price defined for given timestamp
            DateTime minTimestamp = this.prices.Min(price => price.Timestamp);
            if (timestamp.CompareTo(minTimestamp) < 0)
            {
                throw new StockExchangeException("Cijena za zadano vrijeme nije definirana.");
            }

            // Fetch first price with timestamp smaller than the given one
            StockSharePrice stockPrice = this.prices.Where(price => price.Timestamp.CompareTo(timestamp) <= 0).
                OrderByDescending(price => price.Timestamp).First();

            return stockPrice.Price;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            else if (obj.GetType() != typeof(Stock))
            {
                return false;
            }

            Stock other = (Stock)obj;
            return this.name.Equals(other.Name);
        }

        public override int  GetHashCode()
        {
 	         return this.name.GetHashCode();
        }
    }

    public class StockSharePrice
    {
        private readonly decimal price;
        private readonly DateTime timestamp;

        public DateTime Timestamp
        {
            get
            {
                return this.timestamp;
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
        }

        public StockSharePrice(decimal price, DateTime timestamp)
        {
            // Guards
            if (price <= 0m)
            {
                // Price must be positive value
                throw new StockExchangeException("Cijena mora biti veća od 0");
            }

            this.price = price;
            this.timestamp = timestamp;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            else if(obj.GetType() != typeof(StockSharePrice))
            {
                return false;
            }

            StockSharePrice other = (StockSharePrice) obj;
            return this.price == other.Price && this.timestamp.Equals(other.Timestamp);
        }

        public override int  GetHashCode()
        {
 	        int hash = 13;
            hash = (hash * 7) + this.price.GetHashCode();
            hash = (hash * 7) + this.timestamp.GetHashCode();
            return hash;
        }
    }

    public abstract class StockIndex
    {
        protected string name;
        protected List<Stock> stocks = new List<Stock>();

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public abstract decimal Value { get; }

        public int NumberOfStocks
        {
            get
            {
                return this.stocks.Count;
            }
        }

        public StockIndex(string name)
        {
            // Guards
            if (String.IsNullOrEmpty(name))
            {
                // Index name must not be empty string or NULL
                throw new StockExchangeException("Neispravan naziv indeksa");
            }

            this.name = name.ToLower(); // Name is case insensitive
        }
        
        public void AddStock(Stock stock)
        {
            // Guards
            if (this.stocks.Contains(stock))
            {
                // Checks if index already contains given stock
                throw new StockExchangeException("Dionica već postoji u indeksu");
            }

            this.stocks.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            if (!this.stocks.Remove(stock))
            {
                // If stock does not exists in index
                throw new StockExchangeException("Dionica ne postoji u indeksu");
            }
        }

        public bool ContainsStock(Stock stock)
        {
            return this.stocks.Contains(stock);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            else if (obj.GetType() != typeof(StockIndex))
            {
                return false;
            }

            StockIndex other = (StockIndex)obj;
            return this.name.Equals(other.Name);
        }

        public override int GetHashCode()
        {
            return this.name.GetHashCode();
        }
    }

    public class StockIndexAverage : StockIndex
    {
        public override decimal Value
        {
            get
            {
                if (this.stocks.Count > 0)
                {
                    return this.stocks.Average(stock => stock.Price);
                }
                else
                {
                    return 0;
                }
            }
        }

        public StockIndexAverage(string name) : base(name) { }
    }

    public class StockIndexWeighted : StockIndex
    {
        public override decimal Value
        {
            get 
            {
                if (this.stocks.Count > 0)
                {
                    decimal totalValue = this.stocks.Sum(stock => stock.Price * stock.TotalShares);
                    return this.stocks.Sum(stock => stock.Price * stock.Price * stock.TotalShares / totalValue);
                }
                else
                {
                    return 0;
                }
            }
        }

        public StockIndexWeighted(string name) : base(name) { }
    }

    public class StockIndexFactory
    {
        public static StockIndex CreateStockIndex(string name, IndexTypes type)
        {
            switch (type)
            {
                case IndexTypes.AVERAGE:
                    return new StockIndexAverage(name);
                case IndexTypes.WEIGHTED:
                    return new StockIndexWeighted(name);
                default:
                    throw new StockExchangeException("Neispravan tip indeksa");
            }
        }
    }

    public class Portfolio
    {
        private readonly string id;
        private Dictionary<Stock, int> shares = new Dictionary<Stock, int>();

        public string ID
        {
            get
            {
                return this.id;
            }
        }

        public int NumberOfStocks
        {
            get
            {
                return this.shares.Count;
            }
        }

        public int TotalNumberOfShares
        {
            get
            {
                return shares.Values.Sum();
            }
        }

        public Portfolio(string id)
        {
            if (String.IsNullOrEmpty(id))
            {
                throw new StockExchangeException("Neispravan naziv portfelja");
            }

            this.id = id;
        }

        public void AddStockShares(Stock stock, int numOfShares)
        {
            if (this.shares.ContainsKey(stock))
            {
                // If portfolio already contains stock
                int currNumOfShares = this.shares[stock];
                if (currNumOfShares + numOfShares > stock.TotalShares)
                {
                    // Check that there is enough stocks available
                    throw new StockExchangeException("Neispravan broj dionica");
                }

                this.shares[stock] += numOfShares;
            }
            else
            {
                if (numOfShares > stock.TotalShares)
                {
                    throw new StockExchangeException("Neispravan broj dionica");
                }

                this.shares.Add(stock, numOfShares);
            }
        }

        public bool ContainsStock(Stock stock)
        {
            return this.shares.ContainsKey(stock);
        }

        public int NumberOfShares(Stock stock)
        {
            // Guards
            if (!this.shares.ContainsKey(stock))
            {
                // Check if portfolio contains stock
                throw new StockExchangeException("Portfelj ne sadrži zadanu dionicu");
            }

            return this.shares[stock];
        }

        public void RemoveStock(Stock stock)
        {
            // Guards
            if (!this.shares.ContainsKey(stock))
            {
                // Check if portfolio contains stock
                throw new StockExchangeException("Zadana dionica se ne nalazi u portfelju");
            }

            this.shares.Remove(stock);
        }

        public void RemoveShares(Stock stock, int numOfShares)
        {
            // Guards
            if (!this.shares.ContainsKey(stock))
            {
                // Check if portfolio contains stock
                throw new StockExchangeException("Zadana dionica se ne nalazi u portfelju");
            }

            int sharesInPortfolio = this.shares[stock];
            if (numOfShares > sharesInPortfolio)
            {
                throw new StockExchangeException("Broj dionica je veći od broja dionica u portfelju");
            }
            else if (numOfShares == sharesInPortfolio)
            {
                this.shares.Remove(stock);
            }
            else
            {
                this.shares[stock] -= numOfShares;
            }
        }

        public decimal GetValue(DateTime timestamp)
        {
            return this.shares.Sum(item => item.Key.Price * item.Value);
        }

        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            DateTime monthStart, monthEnd;
            try
            {
                monthStart = new DateTime(year, month, 1, 0, 0, 0, 0);
                int lastDayInMonth = DateTime.DaysInMonth(year, month);
                monthEnd = new DateTime(year, month, lastDayInMonth, 23, 59, 59, 999);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Neispravan datum");
            }

            decimal startPrice = this.shares.Sum(item => item.Key.GetPriceByTimestamp(monthStart) * item.Value);
            decimal endPrice = this.shares.Sum(item => item.Key.GetPriceByTimestamp(monthEnd) * item.Value);
            decimal priceDiff = Math.Abs(startPrice - endPrice);

            return priceDiff / startPrice;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            else if (obj.GetType() != typeof(Portfolio))
            {
                return false;
            }

            Portfolio other = (Portfolio)obj;
            return this.id.Equals(other.ID);
        }
    }
}