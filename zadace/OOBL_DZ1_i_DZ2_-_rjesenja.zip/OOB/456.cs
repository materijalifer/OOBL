﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{   
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public enum BinaryOperations
    {
        plus,
        minus,
        multiple,
        divided,
        empty
    }

    public enum UnaryOperations 
    {
        sinus,
        cosinus,
        tangens,
        quadrat,
        root,
        invers,
    }

    public class Kalkulator : ICalculator
    {
        private const int MAX_NUMBERS_OF_DIGITS = 10;

        private string Display { get; set; }
        private double Memory { get; set; }
        private double FirstOperand { get; set; }
        private BinaryOperations CurrentOperation { get; set; }
        private bool OperationIsSet { get; set; }
        private bool NumberIsSet { get; set; }
        private bool ErrorIsSet { get; set; }

        public Kalkulator()
        {
            Display = "0";
            Memory = 0;
            FirstOperand = 0;
            CurrentOperation = BinaryOperations.empty;
            OperationIsSet = false;
            NumberIsSet = false;
            ErrorIsSet = false;
        }

        public void Press(char inPressedDigit)
        {
            if (IsNumber(inPressedDigit.ToString()))
            {
                ProcessNumber(inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        ProcessBinaryOperation(BinaryOperations.plus);
                        break;
                    case '-':
                        ProcessBinaryOperation(BinaryOperations.minus);
                        break;
                    case '*':
                        ProcessBinaryOperation(BinaryOperations.multiple);
                        break;
                    case '/':
                        ProcessBinaryOperation(BinaryOperations.divided);
                        break;
                    case '=':
                        ProcessEqual();
                        break;
                    case ',':
                        InsertComma();
                        break;
                    case 'M':
                        ChangeSign();
                        break;
                    case 'S':
                        ProcessUnaryOperation(UnaryOperations.sinus);
                        break;
                    case 'K':
                        ProcessUnaryOperation(UnaryOperations.cosinus);
                        break;
                    case 'T':
                        ProcessUnaryOperation(UnaryOperations.tangens);
                        break;
                    case 'Q':
                        ProcessUnaryOperation(UnaryOperations.quadrat);
                        break;
                    case 'R':
                        ProcessUnaryOperation(UnaryOperations.root);
                        break;
                    case 'I':
                        ProcessUnaryOperation(UnaryOperations.invers);
                        break;
                    case 'P':
                        SaveToMemory();
                        break;
                    case 'G':
                        GetFromMemory();
                        break;
                    case 'C':
                        ClearDisplay();
                        break;
                    case 'O':
                        ResetCalculator();
                        break;
                    default:
                        SetError();
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return Display;
        }

        private void ProcessNumber(char inputNumber)
        {
            if (!ErrorIsSet)
            {
                if (Display.Equals("0") || OperationIsSet)
                {
                    //postavi prvi znak na ekran
                    Display = inputNumber.ToString();

                    OperationIsSet = false;
                    NumberIsSet = true;
                }
                else
                {
                    int extraDigits = 0;

                    //zarez i predznak se ne ubrajaju za ogranicenje od max 10 znamenki 
                    if (Display.Contains(','))
                        extraDigits++;

                    if (Display.Contains('-'))
                        extraDigits++;

                    if (Display.Length - extraDigits < MAX_NUMBERS_OF_DIGITS)
                        Display = Display + inputNumber;
                }
            }      
        }

        private void ProcessBinaryOperation(BinaryOperations binaryOperation)
        {
            if (!ErrorIsSet)
            {
                BinaryOperations previousOperation = CurrentOperation;

                //ako prethodna operacija nije bila prazna i ako je broj postavljen, izvrsi zadanu operaciju
                if (previousOperation != BinaryOperations.empty && NumberIsSet)
                {
                    double result = ExecuteBinaryOperation();
                    ValidateResult(result);
                }

                //postavi operanda i operaciju za sljedece izvrsavanje
                FirstOperand = Convert.ToDouble(Display);
                CurrentOperation = binaryOperation;

                NumberIsSet = false;
                OperationIsSet = true;
            }
            
        }

        private double ExecuteBinaryOperation()
        {
            double secondOperand = Convert.ToDouble(Display);

            double result = 0;

            switch (CurrentOperation)
            {
                case BinaryOperations.plus:
                    result = FirstOperand + secondOperand;
                    break;
                case BinaryOperations.minus:
                    result = FirstOperand - secondOperand;
                    break;
                case BinaryOperations.multiple:
                    result = FirstOperand * secondOperand;
                    break;
                case BinaryOperations.divided:
                    result = FirstOperand / secondOperand;
                    break;
                default:
                    SetError();
                    break;
            }

            FirstOperand = 0;
            CurrentOperation = BinaryOperations.empty;

            return result;
        }

        private void ProcessEqual()
        {
            if (!ErrorIsSet)
            {
                //ako je zadana operacija, izvrsi ju i prikazi rezultat
                if (CurrentOperation != BinaryOperations.empty)
                {
                    double result = ExecuteBinaryOperation();
                    ValidateResult(result);
                }
                else
                {
                    //inace samo prikazi trenutni rezultat
                    double result = Convert.ToDouble(Display);
                    ValidateResult(result);
                }
            }        
        }

        private void InsertComma()
        {
            if (!Display.Contains(',') && !OperationIsSet && !ErrorIsSet)
            {
                Display = Display + ",";
            }
        }

        private void ChangeSign()
        {
            if (!ErrorIsSet)
            {
                double result = Convert.ToDouble(Display);

                if (result < 0)
                {
                    double display = Convert.ToDouble(Display.Replace('-', '0'));
                    Display = display.ToString();
                }
                else
                {
                    Display = Display.Insert(0, "-");
                }
            }
        }

        private void ProcessUnaryOperation(UnaryOperations unaryOperation)
        {
            if (!ErrorIsSet)
            {
                double result = ExecuteUnaryOperation(unaryOperation);
                ValidateResult(result);
            }         
        }

        private double ExecuteUnaryOperation(UnaryOperations unaryOperation)
        {
            double operand = Convert.ToDouble(Display);

            Double result = 0;

            switch (unaryOperation)
            {
                case UnaryOperations.sinus:
                    result = Math.Sin(operand);
                    break;
                case UnaryOperations.cosinus:
                    result = Math.Cos(operand);
                    break;
                case UnaryOperations.tangens:
                    result = Math.Tan(operand);
                    break;
                case UnaryOperations.quadrat:
                    result = Math.Pow(operand, 2);
                    break;
                case UnaryOperations.root:
                    result = Math.Pow(operand, 0.5);
                    break;
                case UnaryOperations.invers:
                    result = 1 / operand;
                    break;
                default:
                    SetError();
                    break;
            }
            return result;
        }

        private void SaveToMemory()
        {
            Memory = Convert.ToDouble(Display);
        }

        private void GetFromMemory()
        {
            string memory = Memory.ToString();

            if (!String.IsNullOrEmpty(memory))
            {
                Display = memory;
            }
        }

        private void ClearDisplay()
        {
            Display = "0";
            ErrorIsSet = false;
        }

        private void ResetCalculator()
        {
            Display = "0";
            Memory = 0;
            FirstOperand = 0;
            CurrentOperation = BinaryOperations.empty;
            OperationIsSet = false;
            NumberIsSet = false;
            ErrorIsSet = false;
        }
    
        private void SetError()
        {
            ErrorIsSet = true;
            Display = "-E-";
        }

        private void ValidateResult(double result)
        {
            if (Double.IsNaN(result) || Double.IsInfinity(result))
            {
                SetError();
            }
            else
            {
                int countDigits = result.ToString().Length;
                int countAbsDigits = (Math.Abs((long)result)).ToString().Length;

                if (countDigits > MAX_NUMBERS_OF_DIGITS)
                {
                    if (result.ToString().Contains(',') && countAbsDigits < MAX_NUMBERS_OF_DIGITS)
                    {
                        result = Math.Round(result, MAX_NUMBERS_OF_DIGITS - countAbsDigits);
                        Display = result.ToString();
                    }
                    else
                    {
                        SetError();
                    }
                }
                else
                {
                    Display = result.ToString();
                }
            }
        }

        private bool IsNumber(string digit)
        {
            int number;
            bool result = Int32.TryParse(digit, out number);

            return result;
        }
    }
}
