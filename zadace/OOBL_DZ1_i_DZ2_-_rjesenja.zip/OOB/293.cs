﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Dionica> listaDionica;
         private List<Indeks> listaIndeksa;
         private List<Portfelj> listaPortfelja;
         private List<TrackerBrojaDionica> listaTrackera; 

         public StockExchange()
         {
             listaDionica=new List<Dionica>();
             listaIndeksa=new List<Indeks>();
             listaPortfelja=new List<Portfelj>();
             listaTrackera=new List<TrackerBrojaDionica>();

         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Dionica novaDionica = new Dionica(inStockName, inInitialPrice, inTimeStamp, inNumberOfShares);
             if (!listaDionica.Contains(novaDionica))
             {
                 listaDionica.Add(new Dionica(inStockName, inInitialPrice, inTimeStamp, inNumberOfShares));
                 listaTrackera.Add(new TrackerBrojaDionica(novaDionica));
             }
             else
             {
                 throw new StockExchangeException("Dionica sa tim imenom vec postoji");
             }
             
         }

         public void DelistStock(string inStockName)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                    for (int j = 0; j < listaIndeksa.Count; j++)
                    {
                        if (this.IsStockPartOfIndex(listaIndeksa[j].GetIme(),inStockName))
                        {
                            this.RemoveStockFromIndex(listaIndeksa[j].GetIme(),inStockName);
                        }
                    }
                     for (int j = 0; j < listaPortfelja.Count; j++)
                     {
                         if (this.IsStockPartOfPortfolio(listaPortfelja[j].GetId(), inStockName))
                         {
                             this.RemoveStockFromPortfolio(listaPortfelja[j].GetId(), inStockName);
                         }
                     }
                     listaDionica.RemoveAt(i);
                     listaTrackera.RemoveAt(i);
                     return;

                 }
             }

             throw new StockExchangeException("Ne postoji dionica sa tim imenom!");
         }

         public bool StockExists(string inStockName)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return listaDionica.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                     listaDionica[i].PostaviCijenu(inIimeStamp,inStockValue);
                     return;
                 }
             }

             throw new StockExchangeException("Ne postoji dionica sa tim imenom!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                     return listaDionica[i].GetCijena(inTimeStamp);
                 }
             }

             throw new StockExchangeException("Ne postoji dionica sa tim imenom!");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                     return listaDionica[i].GetPocetnaCijena();
                 }
             }

             throw new StockExchangeException("Ne postoji dionica sa tim imenom!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             for (int i = 0; i < listaDionica.Count; i++)
             {
                 if (listaDionica[i].GetIme().ToLower() == inStockName.ToLower())
                 {
                     return listaDionica[i].GetPosljednjaCijena();
                 }
             }

             throw new StockExchangeException("Ne postoji dionica sa tim imenom!");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             listaIndeksa.Add(new Indeks(inIndexName,inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     for (int j = 0; j < listaDionica.Count; j++)
                     {
                         if (listaDionica[j].GetIme().ToLower() == inStockName.ToLower())
                         {
                             listaIndeksa[i].DodajDionicu(listaDionica[j]);
                         }
                     }
                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     listaIndeksa[i].RemoveDionicu(inStockName);
                     return;
                 }
             }
             throw new StockExchangeException("Ne postoji indeks sa tim imenom!");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     return listaIndeksa[i].ProvjeriDionicu(inStockName);
                     
                 }
             }
             throw new StockExchangeException("Ne postoji indeks sa tim imenom!");
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     return listaIndeksa[i].GetValue(inTimeStamp);

                 }
             }
             throw new StockExchangeException("Ne postoji indeks sa tim imenom!");
         }

         public bool IndexExists(string inIndexName)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return listaIndeksa.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             for (int i = 0; i < listaIndeksa.Count; i++)
             {
                 if (listaIndeksa[i].GetIme().ToLower() == inIndexName.ToLower())
                 {
                     return listaIndeksa[i].GetBrojDionica();
                 }
             }
             throw new StockExchangeException("Ne postoji indeks sa tim imenom!");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     throw new StockExchangeException("Vec postoji portelj sa istim id-om");
                 }
             }
                 listaPortfelja.Add(new Portfelj(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     for (int j = 0; j < listaDionica.Count; j++)
                     {
                         if (listaDionica[j].GetIme().ToLower() == inStockName.ToLower())
                         {
                             if (listaTrackera[j].PreostaleDionice(numberOfShares))
                             {
                                 listaTrackera[j].UzmiDionice(numberOfShares);
                                 listaPortfelja[i].DodajDionicu(listaDionica[j], numberOfShares);
                                 return;
                                 
                             }
                             else
                             {
                                 throw new StockExchangeException("Broj dionica nije ispravan");
                             }
                             
                         }
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     for (int j = 0; j < listaDionica.Count; j++)
                     {
                         if (listaDionica[j].GetIme().ToLower() == inStockName.ToLower())
                         {
                             listaTrackera[j].VratiDionice(numberOfShares);
                             listaPortfelja[i].UkloniBrojDionica(listaDionica[j], numberOfShares);
                             
                             return;
                         }
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     for (int j = 0; j < listaDionica.Count; j++)
                     {
                         if (listaDionica[j].GetIme().ToLower() == inStockName.ToLower())
                         {
                             listaTrackera[j].VratiDionice(listaPortfelja[i].GetBrojIstihDionicaUPortfelju(listaDionica[j]));
                             listaPortfelja[i].UkloniDionicu(listaDionica[j]);
                             
                             return;
                         }
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public int NumberOfPortfolios()
         {
             return listaPortfelja.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     return listaPortfelja[i].GetBrojRazlicitihDionica();
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     return listaPortfelja[i].ProvjeriDionicu(inStockName);
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     for (int j = 0; j < listaDionica.Count; j++)
                     {
                         if (listaDionica[j].GetIme().ToLower() == inStockName.ToLower())
                         {
                             return listaPortfelja[i].GetBrojIstihDionicaUPortfelju(listaDionica[j]);

                         }
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     return listaPortfelja[i].GetValue(timeStamp);
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             int brojDanaUMjesecu = 0;
             List<int> mjeseci30Dana=new List<int>(){4,6,9,11};
             if (Month < 1 || Month > 12)
             {
                 throw new StockExchangeException("Pogresan format vremena");
             }
             if (mjeseci30Dana.Contains(Month))
             {
                 brojDanaUMjesecu = 30;
             }
             else if (Month == 2)
             {
                 if (Year%4 == 0)
                 {
                     brojDanaUMjesecu = 29;
                 }
                 else
                 {
                     brojDanaUMjesecu = 28;
                 }
             }
             else
             {
                 brojDanaUMjesecu = 31;
             }
             DateTime prviTrenutak=new DateTime(Year,Month,1,0,0,0,0);
             DateTime drugiTrenutak=new DateTime(Year,Month,brojDanaUMjesecu,23,59,59,999);

             for (int i = 0; i < listaPortfelja.Count; i++)
             {
                 if (listaPortfelja[i].GetId() == inPortfolioID)
                 {
                     Decimal vrijednostPrviTren = listaPortfelja[i].GetValue(prviTrenutak);
                     Decimal vrijednostDrugiTren = listaPortfelja[i].GetValue(drugiTrenutak);
                     if (vrijednostPrviTren == vrijednostDrugiTren)
                     {
                         return 0;
                     }
                     else
                     {
                         Decimal rezultat = ((vrijednostDrugiTren - vrijednostPrviTren) / vrijednostPrviTren) * 100;
                         rezultat = Decimal.Round(rezultat, 3);
                         return rezultat;
                         
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfelj u burzi");
         }
     }

    public class Dionica:IEquatable<Dionica>
    {
        private string ime;
        private Decimal pocCijena;
        private DateTime trenutakAktivacije;
        private long ukupniBrojDionica;
        private List<CijenaUVremenu> povijestCijene; 


        public Dionica(string ime, Decimal pocCijena, DateTime trenutakAktivacije, long brojDionica)
        {
            if (pocCijena <= 0 || brojDionica <= 0)
            {
                throw new StockExchangeException("Broj dionica i cijena dionice ne mogu biti 0!");
            }
            this.ime = ime;
            this.pocCijena = pocCijena;
            this.trenutakAktivacije = trenutakAktivacije;
            this.ukupniBrojDionica = brojDionica;
            this.povijestCijene=new List<CijenaUVremenu>();
            this.povijestCijene.Add(new CijenaUVremenu(pocCijena,trenutakAktivacije));
        }

        public string GetIme()
        {
            return this.ime;
        }

        public void PostaviCijenu(DateTime noviTrenutak,Decimal novaCijena)
        {
            povijestCijene.Add(new CijenaUVremenu(novaCijena,noviTrenutak));
            povijestCijene.Sort();
        }

        public long GetBrojDionica()
        {
            return ukupniBrojDionica;
        }

        public Decimal GetCijena(DateTime trenutak)
        {
            int i;
            if (trenutak < povijestCijene[0].GetTime())
            {
                throw new StockExchangeException("Cijena nije bila postavljena");
            }
            for (i = 0; i < povijestCijene.Count; i++)
            {
                if (povijestCijene[i].GetTime() > trenutak)
                {
                    return povijestCijene[i-1].GetCijena();
                }
                else if (povijestCijene[i].GetTime() == trenutak)
                {
                    return povijestCijene[i].GetCijena();
                }
            }
            return povijestCijene[i - 1].GetCijena();
        }
        public Decimal GetPocetnaCijena()
        {
            return povijestCijene[0].GetCijena();
        }
        public Decimal GetPosljednjaCijena()
        {
            return povijestCijene[povijestCijene.Count - 1].GetCijena();
        }
        public bool Equals(Dionica obj)
        {

            return this.GetIme().ToLower() == obj.GetIme().ToLower();
        }
    }

    public class CijenaUVremenu : IComparable 
    {
        private Decimal cijena;
        private DateTime vrijeme;


        public CijenaUVremenu(Decimal cijena, DateTime vrijeme)
        {
            this.cijena = cijena;
            this.vrijeme = vrijeme;
        }

        public DateTime GetTime()
        {
            return this.vrijeme;
        }

        public Decimal GetCijena()
        {
            return this.cijena;
        }

        public int CompareTo(object obj)
        {
            try
            {
                CijenaUVremenu drugaCijenaUVremenu = obj as CijenaUVremenu;

                if (drugaCijenaUVremenu != null)

                    if (this.vrijeme < drugaCijenaUVremenu.vrijeme)
                    {
                        return -1;
                    }
                    else if (this.vrijeme == drugaCijenaUVremenu.vrijeme)
                    {
                        return 0;
                    }
                    else
                    {
                        return 1;
                    }
                else
                    throw new ArgumentException("Object is not a Temperature");
            }
            catch (Exception)
            {
                
                throw;
            }

        }
    }
    public class Indeks
    {
        private string ime;
        private IndexTypes vrsta;
        private List<Dionica> listaDionica; 

        public Indeks(string ime, IndexTypes vrsta)
        {
            this.ime = ime;
            this.vrsta = vrsta;
            listaDionica=new List<Dionica>();
        }

        public string GetIme()
        {
            return this.ime;
        }

        public void DodajDionicu(Dionica novaDionica)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == novaDionica.GetIme().ToLower())
                {
                    throw new StockExchangeException("Postoji dionica sa tim imenom u indekus");
                }
            }
            listaDionica.Add(novaDionica);
        }

        public int GetBrojDionica()
        {
            return listaDionica.Count;
        }

        public void RemoveDionicu(string imeDionice)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == imeDionice.ToLower())
                {
                    listaDionica.Remove(listaDionica[i]);
                    return;
                }
            }
            throw new StockExchangeException("Ne postoji dionica sa tim imenom unutar indeksa!");
        }

        public bool ProvjeriDionicu(string imeDionice)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == imeDionice.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        public Decimal GetValue(DateTime trenutak)
        {
            if (listaDionica.Count == 0)
            {
                return 0;
            }
            if (vrsta == IndexTypes.AVERAGE)
            {
                Decimal ukupnaVrijednost = 0;
                for (int i = 0; i < listaDionica.Count;i++ )
                {
                    ukupnaVrijednost += listaDionica[i].GetCijena(trenutak);
                }

                return ukupnaVrijednost/listaDionica.Count;
            }
            else if (vrsta == IndexTypes.WEIGHTED)
            {
                Decimal ukupnaVrijednost = 0;
                for (int i = 0; i < listaDionica.Count; i++)
                {
                    ukupnaVrijednost += (listaDionica[i].GetBrojDionica()* listaDionica[i].GetCijena(trenutak));
                }
                Decimal rezultat = 0;
                for (int i = 0; i < listaDionica.Count; i++)
                {
                    rezultat += ((listaDionica[i].GetCijena(trenutak)*listaDionica[i].GetBrojDionica())/ukupnaVrijednost)*
                                listaDionica[i].GetCijena(trenutak);
                }
                return rezultat;
            }
            throw new StockExchangeException("Somethin went wrong!");
        }
          



        
    }
    public class Portfelj
    {
        private string id;
        private List<DioniceUPortfelju> listaDionica;

        public Portfelj(string id)
        {
            this.id = id;
            listaDionica=new List<DioniceUPortfelju>();
        }

        public int GetBrojRazlicitihDionica()
        {
            return listaDionica.Count;
        }

        public int GetBrojIstihDionicaUPortfelju(Dionica dionica)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == dionica.GetIme().ToLower())
                {
                    return listaDionica[i].GetBrojDionicaUPortfelju();
                }
            }
            throw new StockExchangeException("Nesto");
        }

        public void DodajDionicu(Dionica dionica, long brojDionica)
        {
            if (brojDionica <= 0)
            {
                throw new StockExchangeException("Nedopusten broj dionica");
            }
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == dionica.GetIme().ToLower())
                {
                    listaDionica[i].SetBrojDionicaUPortfelju(listaDionica[i].GetBrojDionicaUPortfelju()+brojDionica);
                    return;
                }
            }
            listaDionica.Add(new DioniceUPortfelju(brojDionica,dionica));
        }

        public void UkloniDionicu(Dionica dionica)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == dionica.GetIme().ToLower())
                {
                    listaDionica.RemoveAt(i);
                    return;
                }
            }
            throw new StockExchangeException("Ne postoji trazena dionica uu portfelju");
        }

        public void UkloniBrojDionica(Dionica dionica, long brojDionica)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == dionica.GetIme().ToLower())
                {
                    if (listaDionica[i].GetBrojDionicaUPortfelju() - brojDionica < 0)
                    {
                        throw new StockExchangeException("Ne moze!");
                    }
                    else if (listaDionica[i].GetBrojDionicaUPortfelju() - brojDionica == 0)
                    {
                        this.UkloniDionicu(dionica);
                        return;
                    }
                    else
                    {
                        listaDionica[i].SetBrojDionicaUPortfelju(listaDionica[i].GetBrojDionicaUPortfelju()-brojDionica);
                        return;
                    }               
                }
            }
            throw new StockExchangeException("Ne postoji trazena dionica uu portfelju");
            
        }

        public Decimal GetValue(DateTime trenutak)
        {
            if (listaDionica.Count == 0)
            {
                return 0;
            }
            Decimal ukupnaVrijednost = 0;
            for (int i = 0; i < listaDionica.Count; i++)
            {
                ukupnaVrijednost += (listaDionica[i].GetCijena(trenutak)*listaDionica[i].GetBrojDionicaUPortfelju());
            }
            return ukupnaVrijednost;
        }

        public string GetId()
        {
            return this.id;
        }

        public bool ProvjeriDionicu(string imeDionice)
        {
            for (int i = 0; i < listaDionica.Count; i++)
            {
                if (listaDionica[i].GetIme().ToLower() == imeDionice.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

    }

    public class DioniceUPortfelju
    {
        private Dionica dionicaPortfelja;
        private long brojDionicaUPortfelju;


        public DioniceUPortfelju(long brojDionica, Dionica dionica)
        {
            dionicaPortfelja = dionica;
            brojDionicaUPortfelju = brojDionica;
        }

        public string GetIme()
        {
            return dionicaPortfelja.GetIme();
        }

        public Decimal GetCijena(DateTime trenutak)
        {
            return dionicaPortfelja.GetCijena(trenutak);
        }
        

        public int GetBrojDionicaUPortfelju()
        {
            return (int)brojDionicaUPortfelju;
        }

        public void SetBrojDionicaUPortfelju(long brojDionica)
        {
            brojDionicaUPortfelju = brojDionica;
        }

    }

    public class TrackerBrojaDionica
    {
        private Dionica dionica;
        private long raspoloziviBrojDionica;

            public TrackerBrojaDionica(Dionica dionicaZaPracenje)
            {
                dionica = dionicaZaPracenje;
                raspoloziviBrojDionica = dionicaZaPracenje.GetBrojDionica();
            }
        
        public bool PreostaleDionice(long trazeniBroj)
        {
            return raspoloziviBrojDionica - trazeniBroj >= 0;
        }
        public void VratiDionice(long vraceneDionice)
        {
            raspoloziviBrojDionica += vraceneDionice;
        }
        public void UzmiDionice(long trazeneDionice)
        {
            raspoloziviBrojDionica -= trazeneDionice;
        }
    }
   
}
