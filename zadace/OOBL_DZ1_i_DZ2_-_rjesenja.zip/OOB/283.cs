﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    class AverageIndex : Index
    {
        public AverageIndex(string name)
            : base(name)
        {

        }

        public override decimal GetValue(DateTime timeStamp)
        {
            // izbjegni dijeljenje s 0
            if (stocks.Count == 0)
            {
                return 0;
            }


            decimal value = 0;
            foreach (Stock stock in stocks)
            {
                value = value + stock.GetPrice(timeStamp);
            }
            return value / stocks.Count;
        }
    }

    abstract class Index
    {
        protected List<Stock> stocks;

        public string Name { get; set; }

        public IndexTypes IndexType { get; set; }


        public Index(string name)
        {
            this.Name = name;
            stocks = new List<Stock>();
        }

        // suma cijena za neki trenutak
        protected decimal sumOfValues(DateTime timeStamp)
        {
            decimal value = 0;

            foreach (Stock stock in stocks)
            {
                value = value + stock.GetPrice(timeStamp) * stock.NumberOfShares;
            }

            return value;
        }

        public void AddStock(Stock stock)
        {
            // ako dionica ne postoji u indeksu dodaj je, inače
            // dojavi poruku o greški
            if (!IsStockPartOfIndex(stock.Name))
            {
                stocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Index already contains stock!");
            }
        }

        public void RemoveStock(string stockName)
        {
            stocks.RemoveAt(GetStockIndex(stockName));
        }

        public int GetStockIndex(string name)
        {
            int ind = -1;

            for (int i = 0; i < stocks.Count; i++)
            {
                if (stocks.ElementAt(i).Name.ToLower() == name.ToLower())
                {
                    ind = i;
                }
            }

            if (ind != -1)
            {
                return ind;
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist");
            }
        }

        public bool IsStockPartOfIndex(string name)
        {
            foreach (Stock stock in stocks)
            {
                if (stock.Name.ToLower() == name.ToLower())
                {
                    return true;
                }
            }

            return false;
        }

        public int StocksNumber()
        {
            return stocks.Count();
        }

        public abstract decimal GetValue(DateTime inTimeStamp);
    }

    class Portfolio
    {
        public string Id { get; set; }

        // lista parova osnovna dionica-broj dionica u portfelju
        private List<PortfolioStock> portfolioStocks;


        public decimal GetValue(DateTime timeStamp)
        {
            decimal value = 0;

            foreach (PortfolioStock portfolioStock in portfolioStocks)
            {
                value = value + (portfolioStock.Stock.GetPrice(timeStamp) * portfolioStock.MyNumberOfShares);
            }

            return value;
        }

        public PortfolioStock GetPortfolioStock(string name)
        {
            foreach (PortfolioStock portfolioStock in portfolioStocks)
            {
                if (portfolioStock.Stock.Name == name)
                {
                    return portfolioStock;
                }
            }

            throw new StockExchangeException("Stock doesn't exist!");
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            // postoji li već dionica u portfelju?
            if (ContainsStock(stock.Name))
            {
                GetPortfolioStock(stock.Name).MyNumberOfShares += numberOfShares;
            }
            else
            {
                portfolioStocks.Add(new PortfolioStock(stock, numberOfShares));
            }
        }

        public int GetStockIndex(string stockName)
        {
            int ind = -1;
            for (int i = 0; i < portfolioStocks.Count; i++)
            {
                if (portfolioStocks.ElementAt(i).Stock.Name == stockName)
                {
                    ind = i;
                }
            }
            if (ind != -1)
            {
                return ind;
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't contain this stock!");
            }
        }

        public bool ContainsStock(string name)
        {
            foreach (PortfolioStock portfolioStock in portfolioStocks)
            {
                if (portfolioStock.Stock.Name == name)
                {
                    return true;
                }
            }

            return false;
        }

        public void RemoveStock(string stockName, int numberOfShares)
        {
            int ind = GetStockIndex(stockName);

            PortfolioStock portfolioStock = portfolioStocks.ElementAt(ind);

            // želi se ukloniti više dionica nego što postoji?
            long difference = portfolioStock.MyNumberOfShares - numberOfShares;
            if (difference >= 0)
            {
                portfolioStock.MyNumberOfShares = portfolioStock.MyNumberOfShares - numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Can't remove that much number of shares!");
            }

            // ako je ostalo 0 dionica, makni osnovnu
            if (portfolioStock.MyNumberOfShares == 0)
            {
                portfolioStocks.RemoveAt(ind);
            }
        }

        public void RemoveStock(string stockName)
        {
            int ind = GetStockIndex(stockName);
            if (ind != -1)
            {
                portfolioStocks.RemoveAt(GetStockIndex(stockName));
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't contain stock!");
            }
        }

        public int StocksNumber()
        {
            return portfolioStocks.Count;
        }

        public Portfolio(string id)
        {
            this.Id = id;
            portfolioStocks = new List<PortfolioStock>();
        }
    }

    class PortfolioStock
    {
        public Stock Stock { get; set; }

        public int MyNumberOfShares { get; set; }

        public PortfolioStock(Stock stock, int myNumberOfShares)
        {
            this.Stock = stock;

            this.MyNumberOfShares = myNumberOfShares;
        }
    }

    class Stock
    {
        public string Name { get; set; }

        public long NumberOfShares { get; set; }

        // lista parova datum-cijena
        private List<StockStage> stockStages;


        public Stock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            this.Name = name;

            this.NumberOfShares = numberOfShares;

            stockStages = new List<StockStage>();
            stockStages.Add(new StockStage(initialPrice, timeStamp));
        }


        public bool PriceAlreadyDeifned(DateTime timeStamp)
        {
            foreach (StockStage stockStage in stockStages)
            {
                if (stockStage.TimeStamp == timeStamp)
                {
                    return true;
                }
            }

            return false;
        }

        public void AddStage(decimal price, DateTime timeStamp)
        {
            stockStages.Add(new StockStage(price, timeStamp));
        }

        // pronalazi cijenu za najmlađi definirani datum
        public decimal GetLastPrice()
        {
            DateTime theNewest = stockStages.ElementAt(0).TimeStamp;
            int ind = 0;

            for (int i = 0; i < stockStages.Count; i++)
            {
                if (stockStages.ElementAt(i).TimeStamp > theNewest)
                {
                    theNewest = stockStages.ElementAt(i).TimeStamp;
                    ind = i;
                }
            }

            return stockStages.ElementAt(ind).Price;
        }

        // pronalazi cijenu za najstariji definirani datum
        public decimal GetInitialPrice()
        {
            return GetInitialStage().Price;
        }

        // traži cijenu za najstariji definirani datum do timeStamp-a
        public decimal GetPrice(DateTime timeStamp)
        {
            StockStage stage = GetInitialStage();

            for (int i = 1; i < stockStages.Count; i++)
            {
                if ((stockStages.ElementAt(i).TimeStamp > stage.TimeStamp) && (stockStages.ElementAt(i).TimeStamp <= timeStamp))
                {
                    stage = stockStages.ElementAt(i);
                }
            }

            return stage.Price;
        }

        private StockStage GetInitialStage()
        {
            StockStage theOldest = stockStages.ElementAt(0);

            for (int i = 1; i < stockStages.Count; i++)
            {
                if (stockStages.ElementAt(i).TimeStamp < theOldest.TimeStamp)
                {
                    theOldest = stockStages.ElementAt(i);
                }
            }

            return theOldest;
        }

    }

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stocks;

        private List<Index> indices;

        private List<Portfolio> portfolios;


        public StockExchange()
        {
            stocks = new List<Stock>();

            indices = new List<Index>();

            portfolios = new List<Portfolio>();
        }


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares < 1)
            {
                throw new StockExchangeException("Number of shares must be positive number!");
            }

            if (inInitialPrice < 1)
            {
                throw new StockExchangeException("Price must be positive number!");
            }

            if (!StockExists(inStockName))
            {
                stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
            {
                throw new StockExchangeException("Stock already exists!");
            }
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = GetStock(inStockName);

            // briši dionicu iz indexa
            foreach (Index index in indices)
            {
                if (index.IsStockPartOfIndex(stock.Name) == true)
                {
                    index.RemoveStock(stock.Name);
                }
            }

            // briši dionicu iz portfelja
            foreach (Portfolio portfolio in portfolios)
            {
                if (portfolio.ContainsStock(stock.Name))
                {
                    portfolio.RemoveStock(stock.Name);
                }
            }

            // briši dionicu
            stocks.RemoveAt(findStockIndex(stock.Name));
        }

        public bool StockExists(string inStockName)
        {
            return stockNameExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            // ne može se dva puta definirati cijena za isto vrijeme
            if (!GetStock(inStockName).PriceAlreadyDeifned(inTimeStamp))
            {
                GetStock(inStockName).AddStage(inStockValue, inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Price is already defined for inTimeStamp!");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return Math.Round(GetStock(inStockName).GetPrice(inTimeStamp), 3);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return Math.Round(GetStock(inStockName).GetInitialPrice(), 3);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return Math.Round(GetStock(inStockName).GetLastPrice(), 3);
        }


        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!indexNameExists(inIndexName))
            {
                if (inIndexType == IndexTypes.AVERAGE)
                {
                    indices.Add(new AverageIndex(inIndexName));
                }
                else
                {
                    indices.Add(new WeightedIndex(inIndexName));
                }
            }
            else
            {
                throw new StockExchangeException("Index already exists!");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            GetIndex(inIndexName).AddStock(GetStock(inStockName));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            GetIndex(inIndexName).RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return GetIndex(inIndexName).IsStockPartOfIndex(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return Math.Round(GetIndex(inIndexName).GetValue(inTimeStamp), 3);
        }

        public bool IndexExists(string inIndexName)
        {
            return indexNameExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return GetIndex(inIndexName).StocksNumber();
        }


        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                portfolios.Add(new Portfolio(inPortfolioID));
            }
            else
            {
                throw new StockExchangeException("Portfolio already exists!");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int inNumberOfShares)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);

            Stock stock = GetStock(inStockName);

            // suma broja dionica u svim portfeljima ne može biti veća od
            // ukupnog broja dionica izdanih za svaku pojedinačnu dionicu
            if ((NumOfSharesOfStockInPortfolios(inStockName) + inNumberOfShares) > stock.NumberOfShares)
            {
                throw new StockExchangeException("Stock doesn't have that much shares!");
            }

            // portfelj već sadrži dionicu?
            if (portfolio.ContainsStock(inStockName))
            {
                portfolio.GetPortfolioStock(inStockName).MyNumberOfShares += inNumberOfShares;
            }
            else
            {
                portfolio.AddStock(stock, inNumberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            GetPortfolio(inPortfolioID).RemoveStock(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            GetPortfolio(inPortfolioID).RemoveStock(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return GetPortfolio(inPortfolioID).StocksNumber();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio portfolio in portfolios)
            {
                if (portfolio.Id == inPortfolioID)
                {
                    return true;
                }
            }

            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return GetPortfolio(inPortfolioID).ContainsStock(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                return 0;
            }
            else
            {
                return GetPortfolio(inPortfolioID).GetPortfolioStock(inStockName).MyNumberOfShares;
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return Math.Round(GetPortfolio(inPortfolioID).GetValue(timeStamp), 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);

            // izbjegni dijeljenje s 0
            if (portfolio.StocksNumber() == 0)
            {
                return 0;
            }

            DateTime firstDay = new DateTime(Year, Month, 1);
            DateTime lastDay = firstDay.AddMonths(1);

            decimal firstDayPrice = portfolio.GetValue(firstDay);
            decimal lastDayPrice = portfolio.GetValue(lastDay);

            return Math.Round(((lastDayPrice - firstDayPrice) / firstDayPrice) * 100, 3);
        }


        private Stock GetStock(string stockName)
        {
            foreach (Stock stock in stocks)
            {
                if (stock.Name.ToLower() == stockName.ToLower())
                {
                    return stock;
                }
            }

            throw new StockExchangeException("Stock doesn't exist!");
        }

        private Index GetIndex(string indexName)
        {
            foreach (Index index in indices)
            {
                if (index.Name.ToLower() == indexName.ToLower())
                {
                    return index;
                }
            }

            throw new StockExchangeException("Index doesn't exist!");
        }

        private Portfolio GetPortfolio(string portfolioId)
        {
            foreach (Portfolio portfolio in portfolios)
            {
                if (portfolio.Id == portfolioId)
                {
                    return portfolio;
                }
            }

            throw new StockExchangeException("Portfolio doesn't exist!");
        }

        private int findStockIndex(string name)
        {
            int ind = -1;

            for (int i = 0; i < stocks.Count; i++)
            {
                if (stocks.ElementAt(i).Name.ToLower() == name.ToLower())
                {
                    ind = i;
                }
            }

            if (ind != -1)
            {
                return ind;
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist!");
            }
        }

        private bool stockNameExists(string name)
        {
            foreach (Stock stock in stocks)
            {
                if (stock.Name.ToLower() == name.ToLower())
                {
                    return true;
                }
            }

            return false;
        }

        private bool indexNameExists(string name)
        {
            foreach (Index index in indices)
            {
                if (index.Name.ToLower() == name.ToLower())
                {
                    return true;
                }
            }

            return false;
        }

        // portfolioS
        private int NumOfSharesOfStockInPortfolios(string inStockName)
        {
            int sum = 0;

            foreach (Portfolio portfolio in portfolios)
            {
                sum += NumberOfSharesOfStockInPortfolio(portfolio.Id, inStockName);
            }

            return sum;
        }

    }

    class StockStage
    {
        public decimal Price { get; set; }

        public DateTime TimeStamp { get; set; }


        public StockStage(decimal price, DateTime timeStamp)
        {
            this.Price = price;
            this.TimeStamp = timeStamp;
        }
    }

    class WeightedIndex : Index
    {
        public WeightedIndex(string name)
            : base(name)
        {

        }

        public override decimal GetValue(DateTime timeStamp)
        {
            // izbjegni dijeljenje s 0
            if (stocks.Count == 0)
            {
                return 0;
            }

            decimal value = 0;
            decimal weight = 0;
            decimal price = 0;

            foreach (Stock stock in stocks)
            {
                price = stock.GetPrice(timeStamp);

                weight = (price * stock.NumberOfShares) / sumOfValues(timeStamp);
                value = value + price * weight;
            }

            return value;
        }
    }
}
