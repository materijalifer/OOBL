﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private Ekran ekran = new Ekran();
        private double memorija;
        private bool memorirano;

        UnarnaOperacija unarne = new UnarnaOperacija();
        BinarnaOperacija binarne = new BinarnaOperacija();

        public void Press(char c)
        {
            // U slucaju prikazane greske na ekranu prihvati jedino tipku za reset
            if (ekran.Ispis() == "-E-")
            {
                if (c == 'O') Resetiraj();
            }
            else
            {
                // Izmjena prikaza na ekranu za unos znamenke, zareza ili predznaka
                if (c >= '0' && c <= '9' || c == 'M' || c == ',')
                {
                    ekran.DodajNaEkran(c);
                    // Ako je vec odabrana binarna op., cekati upis 2.operanda ili 'M'
                    if (binarne.Spreman && !binarne.DrugiOperand && c != ',')
                        binarne.DrugiOperand = true;
                }

                // Izbor jedne od unarnih operacija
                else if (c == 'S' || c == 'K' || c == 'T' || c == 'Q' || c == 'R' || c == 'I')
                {
                    ekran.DodajNaEkran(unarne.VratiRezultat(ekran.Ispis(), c));
                    // Dojava ekranu da je izvrsena unarna operacija
                    ekran.UnarnaGotova = true;
                    if (binarne.Spreman)
                        binarne.DrugiOperand = true;
                }

                // Izbor jedne od binarnih operacija
                else if (c == '+' || c == '-' || c == '/' || c == '*')
                {
                    if (binarne.BilaJednakost)
                    {
                        binarne.BilaJednakost = false;
                        if (binarne.DrugiOperand)
                            binarne.Spreman = false;
                    }
                    ekran.DodajNaEkran(binarne.VratiRezultat(ekran.Ispis(), c));
                    // Dojava ekranu da ceka novi operand
                    ekran.UnosNovogOperanda = true;

                }
                else
                {
                    switch (c)
                    {
                        case '=':
                            Izracunaj();
                            break;

                        case 'P':
                            SpremiUMemoriju();
                            break;
                        case 'G':
                            VratiIzMemorije();
                            break;

                        case 'O':
                            Resetiraj();
                            break;
                        case 'C':
                            ekran = new Ekran();
                            break;
                    }
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return ekran.Ispis();
        }

        // Resetiranje, inicijaliziranje svih vrijednosti
        private void Resetiraj()
        {
            ekran = new Ekran();
            memorija = 0;
            memorirano = false;
            binarne = new BinarnaOperacija();
        }

        // Upravljanje memorijom
        private void SpremiUMemoriju()
        {
            memorija = double.Parse(ekran.Ispis());
            memorirano = true;
        }
        private void VratiIzMemorije()
        {
            if (memorirano)
                ekran.DodajNaEkran(memorija.ToString());
        }

        // Odabirom operatora '=': 
        private void Izracunaj()
        {
            // za odabranu binarnu op. vraca rezultat
            if (binarne.Spreman)
            {
                if (!binarne.DrugiOperand)
                {
                    binarne.Skracen = true;
                }
                else
                {
                    binarne.Skracen = false;
                }
                ekran.DodajNaEkran(binarne.Izvrsi(ekran.Ispis(), binarne.ZadnjaOperacija));
            }
            // Inace vraca trenutni prikaz na ekran (po potrebi ga "sredi")
            else
            {
                ekran.DodajNaEkran(ekran.Ispis());
            }
            binarne.DrugiOperand = false;
            ekran.UnosNovogOperanda = true;
        }
    }

    public class Ekran
    {
        private StringBuilder zaslon;
        private static int maxDuljinaEkrana;
        public bool UnosNovogOperanda, UnarnaGotova;

        // Konstruktor koji inicijalizira ekran da prikazuje '0'
        public Ekran()
        {
            zaslon = new StringBuilder("0");
            maxDuljinaEkrana = 10;
        }

        // Javna metoda za ispis ekrana
        public string Ispis()
        {
            return zaslon.ToString();
        }

        // Ova metoda se zove ako se unose znamenke, decimalna tocka ili predznak,
        // i to samo u specijalnom stanju kada nisu potrebne nikakve operacije
        public void DodajNaEkran(char znak)
        {
            if ((UnosNovogOperanda || UnarnaGotova) && znak != 'M')
            {
                // Nije podrzano u .NET 3.0
                //zaslon.Clear();
                zaslon.Length = 0;
                //----
                zaslon.Append(0);
                if (UnosNovogOperanda) UnosNovogOperanda = false;
                if (UnarnaGotova) UnarnaGotova = false;
            }
            if (TrenutnaDuljinaEkrana() < maxDuljinaEkrana)
            {
                if (znak >= '0' && znak <= '9')
                {
                    // Ako je na zaslonu prvi znak '0', on se brise i stavlja se novi unos
                    if (zaslon[0] == '0')
                    {
                        if (!zaslon.ToString().Contains(','))
                            zaslon.Remove(0, 1);
                        zaslon.Append(znak);
                    }
                    else
                    {
                        zaslon.Append(znak);
                    }
                }
            }

            if (znak == ',' && !zaslon.ToString().Contains(',') &&
                TrenutnaDuljinaEkrana() < maxDuljinaEkrana)
            {
                zaslon.Append(znak);
            }
            else if (znak == 'M')
            {
                PromijeniPredznak();
            }

        }
        // Ispisuje na ekran rezultat operacije
        public void DodajNaEkran(string zapis)
        {
            // Nije podrzano u .NET 3.0
            //zaslon.Clear();
            zaslon.Length = 0;
            //----
            zaslon.Append(Zaokruzi(double.Parse(zapis)));
            if (TrenutnaDuljinaEkrana() > maxDuljinaEkrana)
            {
                // Nije podrzano u .NET 3.0
                //zaslon.Clear();
                zaslon.Length = 0;
                //----
                zaslon.Append("-E-");
            }
        }

        // Provjerava koliko je trenutno znakova na zaslonu (bez ',' i '-')
        private int TrenutnaDuljinaEkrana()
        {
            int duljina = zaslon.Length;
            if (zaslon.ToString().Contains(','))
                duljina--;
            if (zaslon.ToString().Contains('-'))
                duljina--;

            return duljina;
        }

        // Promjena predznaka (ako je na zaslonu nula, nista se ne dogada)
        private void PromijeniPredznak()
        {
            if (zaslon[0] != '-')
            {
                if (zaslon[0] != '0')
                    zaslon.Insert(0, '-');
            }
            else
            {
                zaslon.Remove(0, 1);
            }
        }

        // Nakon zaokruzivanja moze ostati najvise 9 mjesta iza zareza
        public string Zaokruzi(double rezultat)
        {
            return String.Format("{0:#########0.#########}", rezultat);
        }
    }

    abstract public class Operacija
    {
        protected static bool[] spreman;

        public bool Spreman
        {
            get { return spreman[0]; }
            set { spreman[0] = value; }
        }

        public Operacija()
        {
            spreman = new bool[5];
        }

        abstract public string VratiRezultat(string unos, char operacija);

        // Vrati veci broj znamenki od max duljine zaslona i obznani gresku
        protected string Error()
        {
            return "99999999999";
        }
    }

    public class UnarnaOperacija : Operacija
    {
        public override string VratiRezultat(string unos, char operacija)
        {
            double operand = double.Parse(unos);

            switch (operacija)
            {
                case 'S':
                    return Math.Sin(operand).ToString();
                case 'K':
                    return Math.Cos(operand).ToString();
                case 'T':
                    return Math.Tan(operand).ToString();
                case 'Q':
                    return Math.Pow(operand, 2).ToString();
                case 'R':
                    if (operand >= 0)
                        return Math.Sqrt(operand).ToString();
                    else
                        return Error();
                case 'I':
                    if (operand != 0)
                        return Math.Pow(operand, -1).ToString();
                    else
                        return Error();
                default:
                    return Error();
            }
        }
    }

    public class BinarnaOperacija : Operacija
    {

        private char zadnjaOperacija;
        private double operand1, operand2, rezultat, jednakoMem;
        Ekran ekr = new Ekran();

        // Pokazivaci trenutnog stanja
        public bool DrugiOperand
        {
            get { return spreman[1]; }
            set { spreman[1] = value; }
        }
        public bool Skracen
        {
            get { return spreman[2]; }
            set { spreman[2] = value; }
        }
        public bool ZapamtiOperand
        {
            get { return spreman[3]; }
            set { spreman[3] = value; }
        }
        public bool BilaJednakost
        {
            get { return spreman[4]; }
            set { spreman[4] = value; }
        }
        public char ZadnjaOperacija
        {
            get { return zadnjaOperacija; }
        }

        // Vraca rezultat binarne operacije u ovisnosti o razlicitim stanjima
        public override string VratiRezultat(string unos, char operacija)
        {
            // Ako prije poziva metode nije odabrana binarna operacija
            if (!Spreman)
            {
                operand1 = double.Parse(unos);
                zadnjaOperacija = operacija;

                Spreman = true;
                ZapamtiOperand = true;

                rezultat = double.Parse(unos);
            }
            else if (Skracen || DrugiOperand)
            {
                // Nacin na koji se uzima drugi operand ovisi o trenutnom stanju
                if (DrugiOperand)
                    operand2 = double.Parse(unos);

                if (!BilaJednakost)
                    jednakoMem = operand2;
                else
                {
                    operand2 = jednakoMem;
                    operand1 = double.Parse(unos);
                }

                switch (zadnjaOperacija)
                {
                    case '+':
                        rezultat = operand1 + operand2;
                        break;
                    case '-':
                        rezultat = operand1 - operand2;
                        break;
                    case '*':
                        rezultat = operand1 * operand2;
                        break;
                    case '/':
                        rezultat = operand1 / operand2;
                        break;
                }

                operand1 = double.Parse(ekr.Zaokruzi(rezultat));
                DrugiOperand = false;
                Skracen = false;
            }

            // pamti operand u slucaju skracenog izvrsenja bin.op.
            if (operacija != zadnjaOperacija)
                ZapamtiOperand = true;

            zadnjaOperacija = operacija;

            return rezultat.ToString();
        }

        // Odabirom operatora '=' pozvana je ova metoda, koja zove VratiRezultat
        public string Izvrsi(string unos, char operacija)
        {
            if (Skracen && ZapamtiOperand)
            {
                operand2 = double.Parse(unos);
                ZapamtiOperand = false;
            }

            string rez = VratiRezultat(unos, operacija);

            BilaJednakost = true;

            return rez;
        }
    }
}
