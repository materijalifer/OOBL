﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private ICalculatorDisplay display; 
        private ICalculatorMemory memory;
        private BinaryOperationFactory binaryFactory; // parametrizirana tvornica binarnih operacija
        private UnaryOperationFactory unaryFactory; // parametrizirana tvornica unarnih operacija
        private BinaryOperation currentBinaryOperation; // zadnja pritisnuta binarna operacija
        private double currentResult; // trenutni rezultat
        private const string initialCharacter = "0"; // znak koji se ispisuje na display prilikom poretanja ili reseta
        private char decimalPoint; // znak za decimalnu točku (ili zarez u ovom slučaju)
        private bool newNumberInput; // zastavica koja označava unos novog broja 
        private bool lastBinaryOperationInput;
        private const string errorString = "-E-";

        public Kalkulator()
        {
            display = new CalculatorDisplay();
            memory = new CalculatorMemory();
            binaryFactory = new BinaryOperationFactory();
            unaryFactory = new UnaryOperationFactory();
            currentBinaryOperation = null;
            currentResult = 0;
            newNumberInput = true;
            lastBinaryOperationInput = false;
            decimalPoint = display.getDecimalPointSign();
        }

        /*************************************
         * Metoda koja simulira pritisak gumba na kalkulatoru 
         * ***********************************/
        public void Press(char inPressedDigit)
        {
            string operandString;
            double operand;

            /*  Ako je pritisnuta ON/OFF tipka */
            if (inPressedDigit == 'O')
            {
                /* Inicijalizacija kalkulatora u početno stanje */
                currentResult = 0;
                currentBinaryOperation = null;
                display.setCurrentDisplay(initialCharacter);
                memory.storeResultIntoMemory("");
                newNumberInput = true;
                lastBinaryOperationInput = false;
            }
            /* Ako je pritisnuta "clear" tipka */
            else if (inPressedDigit == 'C')
            {
                /* Na zaslon stavljamo inicijalni znak (0) */
                display.setCurrentDisplay(initialCharacter);
                newNumberInput = true;
                lastBinaryOperationInput = false;
            }
            /* Ako je pritisnuto dohvaćanje iz memorije */
            else if (inPressedDigit == 'G')
            {
                display.setCurrentDisplay(memory.getResultFromMemory());
            }
            /* Ako je pritisnuto spremanje u memoriju */
            else if (inPressedDigit == 'P')
            {
                memory.storeResultIntoMemory(display.getCurrentDisplay());
            }
            /* Ako je pritisnuta tipka jedna od unarnih operacija */
            else if (unaryFactory.getSupportedOperations().Contains(inPressedDigit))
            {
                /* Dohvaćanje odgovarajuće unarne operacije */
                UnaryOperation operation = unaryFactory.getUnaryOperation(inPressedDigit);

                /* Dohvaćanje, izračunavanje i ispis rezultata na ekran */
                operandString = display.getCurrentDisplay();
                operandString = roundArgument(operandString);
                operand = convertStringToDouble(operandString);

                operand = operation.calculate(operand);

                if (Double.IsInfinity(operand))
                {
                    operandString = errorString;
                }
                else
                {
                    operandString = convertDoubleToString(operand);
                    operandString = roundArgument(operandString);
                }

                display.setCurrentDisplay(operandString);
                newNumberInput = true;
                lastBinaryOperationInput = false;
            }

            else if (inPressedDigit == 'M')
            {
                display.changeSign();
                operandString = display.getCurrentDisplay();
                operandString = roundArgument(operandString);
                display.setCurrentDisplay(operandString);
                lastBinaryOperationInput = false;
            }
            /* Ako je pritisnuta tipka jedna od binarnih operacija */
            else if (binaryFactory.getSupportedOperations().Contains(inPressedDigit))
            {
                /* Dohvaćanje odgovarajuće binarne operacije */
                BinaryOperation operation = binaryFactory.getBinaryOperation(inPressedDigit);

                /* Dohvaćanje trenutnog operanda s ekrana */
                operandString = display.getCurrentDisplay();
                operandString = roundArgument(operandString);
                operandString = removeEndZeroes(operandString);
                operand = convertStringToDouble(operandString);

                /* Ako ne postoji binarna operacija "na čekanju" */
                if (currentBinaryOperation == null)
                {
                    /* Stavi operand kao trenutni rezultat */
                    currentResult = operand;
                    currentBinaryOperation = operation;
                    display.setCurrentDisplay(operandString);
                }
                /* Ako već postoji binarna operacija */
                else if (!lastBinaryOperationInput)
                {
                    /* Izračunaj rezultat te operacije te ga ispiši na ekran */
                    operand = currentBinaryOperation.calculate(currentResult, operand);
                    if (Double.IsInfinity(operand))
                    {
                        operandString = errorString;
                    }
                    else
                    {
                        currentResult = operand;
                        operandString = convertDoubleToString(operand);
                        operandString = roundArgument(operandString);
                        operandString = removeEndZeroes(operandString);
                    }
                    display.setCurrentDisplay(operandString);

                    /* Stavi novu binarnu operaciju na čekanje drugog operanda*/
                    currentBinaryOperation = operation;
                }
                else if (lastBinaryOperationInput)
                {
                    currentBinaryOperation = operation;
                }
                newNumberInput = true;
                lastBinaryOperationInput = true;
            }
            /*Ako je pritisnuta tipka broj */
            else if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                /* Dohvati trenutni operand sa zaslona */
                operandString = display.getCurrentDisplay();

                /* Ako se čeka na unos novog broja, ignoriraj stari operand */
                if (newNumberInput || operandString == "0")
                {
                    operandString = inPressedDigit.ToString();
                    newNumberInput = false;
                }
                /* Ako se ne unosi novi broj, dodaj novu znamenku na postojeće */
                else
                {
                    operandString += inPressedDigit.ToString();
                    display.setCurrentDisplay(operandString);
                    if (operandString == errorString)
                        newNumberInput = true;
                }

                display.setCurrentDisplay(operandString);
                lastBinaryOperationInput = false;
            }
            /* Ako je unesena decimalna točka */
            else if (inPressedDigit == decimalPoint)
            {
                /* Provjera da li već postoji decimalna točka */
                if (!display.getCurrentDisplay().Contains(decimalPoint))
                {
                    operandString = display.getCurrentDisplay();
                    operandString += inPressedDigit.ToString();
                    display.setCurrentDisplay(operandString);

                    if (newNumberInput)
                        newNumberInput = false;
                    lastBinaryOperationInput = false;
                }
            }
            /* Ako je odabrana tipka "jednako" */
            else if (inPressedDigit == '=')
            {
                operandString = display.getCurrentDisplay();
                operandString = roundArgument(operandString);
                operand = convertStringToDouble(operandString);

                /* Ako ne postoji binarna operacija na čekanju */
                if (currentBinaryOperation == null)
                {
                    /* Trenutni operand je rješenje i prikazuje se na zaslonu*/
                    operandString = removeEndZeroes(operandString);
                    display.setCurrentDisplay(operandString);
                }
                /* Ako postoji binarna operacija */
                else
                {
                    /* Binarna operacija se izračunava i ispisuje na ekran */
                    operand = currentBinaryOperation.calculate(currentResult, operand);
                    operandString = convertDoubleToString(operand);
                    operandString = roundArgument(operandString);
                    operandString = removeEndZeroes(operandString);
                    currentBinaryOperation = null;
                    currentResult = 0;
                    display.setCurrentDisplay(operandString);
                }
                newNumberInput = true;
                lastBinaryOperationInput = false;
            }
        }

        /* Metoda koja vraća trenutno stanje na prikazniku (display-u) */
        public string GetCurrentDisplayState()
        {
            return display.getCurrentDisplay();
        }

        /* Pomoćna funkcija koja pretvara double u string */
        private string convertDoubleToString(double operand)
        {
            string operandString = Convert.ToString(operand);
            operandString = operandString.Replace('.', decimalPoint);
            return operandString;
        }

        /* Pomoćna funkcija koja pretvara string u double */
        private double convertStringToDouble(string operandString)
        {
            double operand;
            operandString = operandString.Replace(decimalPoint, '.');
            try
            {
                operand = double.Parse(operandString, CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                return Double.PositiveInfinity;
            }

            return operand;
        }

        /* Pomoćna funkcija koja zaokružuje broj u slučaju više od 10 znamenki */
        private string roundArgument(string arg)
        {
            int offset = 0;

            /* Provjera decimalnog zareza i predznaka */
            if (arg.Contains(decimalPoint))
                offset++;
            if (arg.Contains('-'))
                offset++;

            /* Zaokruživanje broja i ispis errora ako broj ne stane na ekran */
            if (arg.Contains(decimalPoint) && isTooLarge(arg))
            {
                /* Računanje dozvoljenih decimalnih mjesta */
                int allowedDecimalSize = display.getDisplaySize() + offset - 1 - arg.IndexOf(decimalPoint);
                if (allowedDecimalSize < 1)
                    return errorString;

                double argNum = convertStringToDouble(arg);
                argNum = Math.Round(argNum, allowedDecimalSize);
                return convertDoubleToString(argNum);
            }
            else if (!arg.Contains(decimalPoint) && isTooLarge(arg))
            {
                return errorString;
            }

            return arg;
        }

        /* Micanje nula iza decimalne točke */
        private string removeEndZeroes(string result)
        {
            while ((result.Last() == '0' && result.Contains(decimalPoint)) || result.Last() == decimalPoint)
            {
                result = result.Remove(result.Count() - 1, 1); // micanje zadnjeg znaka
            }
            return result;
        }

        /* Funkcija koja provjerava da li je broj prevelik da stane na ekran */
        private bool isTooLarge(string arg)
        {
            int count = 0;
            for (int i = 0; i < arg.Count(); ++i)
            {
                if (arg[i] >= '0' && arg[i] <= '9')
                    count++;
            }

            if (count > display.getDisplaySize())
                return true;
            return false;
        }
    }

    /* Sučelje za ekran kalkulatora */
    public interface ICalculatorDisplay
    {
        string getCurrentDisplay();
        void setCurrentDisplay(string result);
        int getDisplaySize();
        void changeSign();
        char getDecimalPointSign();
    }

    /* Implementacija sučelja za ekran kalkulatora */
    public class CalculatorDisplay : ICalculatorDisplay
    {
        private string currentDisplay;
        private string sign;
        private int displayLength;
        private const char decimalPoint = ',';

        /* Konstruktor */
        public CalculatorDisplay()
        {
            currentDisplay = "0";
            sign = "";
            displayLength = 10;
        }

        /* Vraća se predznak + trenutno stanje na zaslonu */
        public string getCurrentDisplay()
        {
            return sign + currentDisplay;
        }

        /* Postavljanje rezultata na ekran i zaokruživanje decimalnog broja */
        public void setCurrentDisplay(string result)
        {
            int length = displayLength;
            if (result[0] == '-')
            {
                sign = "-";
                result = result.Remove(0, 1);
            }
            else
            {
                sign = "";
            }

            if (result.Contains(decimalPoint))
                length++;

            /* Ako rezultat ima previše znamenki uzmi koliko stane*/
            if (result.Count() > length)
            {
                result = result.Substring(0, length);
            }

            currentDisplay = result;
            
        }

        /* Velicina ekrana */
        public int getDisplaySize()
        {
            return displayLength;
        }

        /* Promjena predznaka */
        public void changeSign () 
        {
            if (sign == "")
                sign = "-";
            else
                sign = "";
        }

        public char getDecimalPointSign ()
        {
            return decimalPoint;
        }
    
    }

    /* Sučelje za memoriju */
    public interface ICalculatorMemory
    {
        string getResultFromMemory();
        void storeResultIntoMemory (string result);

    }

    /* Implementacija razreda koji predstavlja memoriju kalkulatora */
    public class CalculatorMemory: ICalculatorMemory
    {
        public CalculatorMemory()
        {
            result = "0";
        }

        string result;

        /* Dohvat rezultata iz memorije */
        public string getResultFromMemory()
        {
            return result;
        }

        /* Spremi rezultat u memoriju */
        public void storeResultIntoMemory(string result)
        {
            this.result = result;
        }
    }

    /* Apstraktno sučelje za unarni operator */
    public interface UnaryOperation
    {
        double calculate(double arg);
    }

    /* Apstraktno sučelje za binarni operator */
    public interface BinaryOperation
    {
        double calculate(double arg1, double arg2);
    }

    /************************************************ 
     * Konkretne implementacije binarnih operatora 
     ************************************************/

    /* Zbrajanje */
    public class Add : BinaryOperation
    {
        public double calculate(double arg1, double arg2)
        {
            return arg1 + arg2;
        }
    }

    /* Oduzimanje */
    public class Subtract : BinaryOperation
    {
        public double calculate(double arg1, double arg2)
        {
            return arg1 - arg2;
        }
    }

    /* Množenje */
    public class Multiply : BinaryOperation
    {
        public double calculate(double arg1, double arg2)
        {
            return arg1 * arg2;
        }
    }

    /*Dijeljenje */
    public class Divide : BinaryOperation
    {
        public double calculate(double arg1, double arg2)
        {
            return arg1 / arg2;
        }
    }

    /* Parametrizirana tvornica binarnih operatora */
    public class BinaryOperationFactory
    {
        private List<char> supportedOperations;

        public BinaryOperationFactory()
        {
            supportedOperations = new List<char>();
            supportedOperations.Add('+');
            supportedOperations.Add('-');
            supportedOperations.Add('*');
            supportedOperations.Add('/');
        }

        public List<char> getSupportedOperations()
        {
            return supportedOperations;
        }

        public BinaryOperation getBinaryOperation(char operation)
        {
            switch (operation)
            {
                case '+': 
                    return new Add();
                case '-':
                    return new Subtract();
                case '*':
                    return new Multiply();
                case '/':
                    return new Divide();
                default:
                    throw new Exception();
            }
        }
    }

 /************************************************ 
 * Konkretne implementacije unarnih operatora 
 ************************************************/
    /* Sinus */
    public class Sinus : UnaryOperation
    {
        public double calculate(double arg)
        {
            return Math.Sin(arg);
        }
    }

    /* Kosinus */
    public class Cosinus : UnaryOperation
    {
        public double calculate(double arg)
        {
            return Math.Cos(arg);
        }
    }

    /* Tangens */
    public class Tangent : UnaryOperation
    {
        public double calculate(double arg)
        {
            return Math.Tan(arg);
        }
    }

    /*Inverz */
    public class Invert : UnaryOperation
    {
        public double calculate(double arg)
        {
            return 1 / arg;
        }
    }

    /* Kvadrat */
    public class Square : UnaryOperation
    {
        public double calculate(double arg)
        {
            return arg * arg;
        }
    }

    /* Korijen */
    public class SquareRoot : UnaryOperation
    {
        public double calculate(double arg)
        {
            return Math.Sqrt(arg);
        }
    }

    /* Parametrizirana tvornica unarnih operatora */
    public class UnaryOperationFactory
    {
        private List<char> supportedOperations;

        public UnaryOperationFactory()
        {
            supportedOperations = new List<char>();
            supportedOperations.Add('S');
            supportedOperations.Add('K');
            supportedOperations.Add('T');
            supportedOperations.Add('Q');
            supportedOperations.Add('R');
            supportedOperations.Add('I');
        }

        public List<char> getSupportedOperations()
        {
            return supportedOperations;
        }

        public UnaryOperation getUnaryOperation(char operation)
        {
            switch (operation)
            {
                case 'S':
                    return new Sinus();
                case 'K':
                    return new Cosinus();
                case 'T':
                    return new Tangent();
                case 'Q':
                    return new Square();
                case 'R':
                    return new SquareRoot();
                case 'I':
                    return new Invert();
                default:
                    throw new Exception();
            }
        }
    }




}
