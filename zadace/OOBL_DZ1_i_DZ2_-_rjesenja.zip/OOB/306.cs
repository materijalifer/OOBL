﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         StockCollection _stockCollection = new StockCollection();
         IndexCollection _indexCollection = new IndexCollection();
         PortfolioCollection _portfolioCollection = new PortfolioCollection();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             this._stockCollection.AddStock(stock);
         }

         public void DelistStock(string inStockName)
         {
             this._stockCollection.RemoveStock(inStockName);
             foreach (Index index in this._indexCollection)
             {
                 if (index.ContainsStock(inStockName))
                     index.RemoveStock(inStockName);
             }
             foreach (Portfolio portfolio in this._portfolioCollection)
             {
                 if (portfolio.ContainsStock(inStockName))
                     portfolio.RemoveStock(inStockName);
             }
         }
         

         public bool StockExists(string inStockName)
         {
             return this._stockCollection.Exists(inStockName);
         }

         public int NumberOfStocks()
         {
             return this._stockCollection.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = this._stockCollection.GetStock(inStockName);
             stock.SetStockPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = this._stockCollection.GetStock(inStockName);
             return stock.GetStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = this._stockCollection.GetStock(inStockName);
             return stock.GetFirstStockPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = this._stockCollection.GetStock(inStockName);
             return stock.GetLastStockPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index = new Index(inIndexName, inIndexType);
             this._indexCollection.AddIndex(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = this._stockCollection.GetStock(inStockName);
             Index index=this._indexCollection.GetIndex(inIndexName);
             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = this._indexCollection.GetIndex(inIndexName);
             index.RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = this._indexCollection.GetIndex(inIndexName);
             return index.ContainsStock(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = this._indexCollection.GetIndex(inIndexName);
             return index.CalculateIndex(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return this._indexCollection.ContainsIndex(inIndexName);
         }

         public int NumberOfIndices()
         {
             return this._indexCollection.NumberOfIndeices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = this._indexCollection.GetIndex(inIndexName);
             return index.GetStockNumber();             
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio portfolio = new Portfolio(inPortfolioID);
             this._portfolioCollection.AddPortfolio(portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int stockSum = this._portfolioCollection.Where(a => a.ContainsStock(inStockName)).Sum((a) => a.NumberOfStockShares(inStockName));
             Stock stock = this._stockCollection.GetStock(inStockName);
             if (stock.NumberOfShares < (stockSum + numberOfShares))
                 throw new StockExchangeException("");
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             p.AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             p.RemoveStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             p.RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return this._portfolioCollection.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             return p.StockCount();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this._portfolioCollection.Contains(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             return p.ContainsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             return p.NumberOfStockShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             return p.CalculatePortfolioValue(timeStamp);
         }


         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio p = this._portfolioCollection.GetPortfolio(inPortfolioID);
             return p.GetPercentageForMonth(Year, Month);
         }
     }

     /// <summary>
     /// Interface for index calculation
     /// </summary>
     interface IIndexCalculator
     {
         decimal CalculateIndex(StockCollection stockCollection, DateTime time);
     }

     /// <summary>
     /// Class that calculates the weighted index
     /// </summary>
     class WeightedIndexCalculator : IIndexCalculator
     {
         /// <summary>
         /// Calculates the weighted value of the index
         /// </summary>
         /// <param name="stockCollection">Collection of stock in the index</param>
         /// <param name="time">Timestamp for which to calculate the index value</param>
         /// <returns>Index value</returns>
         public decimal CalculateIndex(StockCollection stockCollection, DateTime time)
         {
             decimal index = 0;
             decimal stockSum = 0;
             foreach (Stock stock in stockCollection)
                 stockSum += stock.GetStockPrice(time) * stock.NumberOfShares;

             foreach (Stock stock in stockCollection)
                 index += stock.NumberOfShares * stock.GetStockPrice(time) * stock.GetStockPrice(time) / stockSum;

             return decimal.Round(index, 3);
         }
     }

     /// <summary>
     /// Class for average index value calculation
     /// </summary>
     class AverageIndexCalculator : IIndexCalculator
     {
         /// <summary>
         /// Calculates the 
         /// </summary>
         /// <param name="stockCollection">Collection of stocks in the index</param>
         /// <param name="time">Timestamp for which to calculate the index value</param>
         /// <returns>Index value</returns>
         public decimal CalculateIndex(StockCollection stockCollection, DateTime time)
         {
             decimal index = 0;

             foreach (Stock stock in stockCollection)
                 index += stock.GetStockPrice(time);
             if (stockCollection.Count() == 0)
                 return 0;

             return decimal.Round(index / stockCollection.Count(), 3);
         }
     }

     /// <summary>
     /// Creates the specified index calculator
     /// </summary>
     static class IndexCalculatorFactory
     {
         /// <summary>
         /// Gets the index calculator for the specified type
         /// </summary>
         /// <param name="type">Index calculator type</param>
         /// <returns>Index calculator</returns>
         public static IIndexCalculator GetIndexCalculator(IndexTypes type)
         {
             if (type == IndexTypes.WEIGHTED)
                 return new WeightedIndexCalculator();
             if (type == IndexTypes.AVERAGE)
                 return new AverageIndexCalculator();
             return null;
         }
     }

     /// <summary>
     /// Represents the index in stock exchange
     /// </summary>
     public class Index
     {
         string _name;

         /// <summary>
         /// Name of the index
         /// </summary>
         public string Name
         {
             get { return _name; }
         }
         IndexTypes _type;
         StockCollection _stockCollection;
         IIndexCalculator _indexCalculator;

         /// <summary>
         /// Creates a new index
         /// </summary>
         /// <param name="name">Name of the index</param>
         /// <param name="type">Type of the index</param>
         public Index(string name, IndexTypes type)
         {
             if (!Enum.IsDefined(typeof(IndexTypes), type))
                 throw new StockExchangeException("Index type not defined!");
             this._stockCollection = new StockCollection();
             this._name = name;
             this._type = type;
             this._indexCalculator = IndexCalculatorFactory.GetIndexCalculator(type);
         }

         /// <summary>
         /// Adds stock to the collection
         /// </summary>
         /// <param name="stock">Stock to be added</param>
         public void AddStock(Stock stock)
         {
             this._stockCollection.AddStock(stock);

         }

         /// <summary>
         /// Removes the specified stock from the index
         /// </summary>
         /// <param name="stock">Name of the stock</param>
         public void RemoveStock(string stockName)
         {
             this._stockCollection.RemoveStock(stockName);
         }

         /// <summary>
         /// Checks if the index contains the specified stock
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <returns></returns>
         public bool ContainsStock(string stock)
         {
             return this._stockCollection.ContainsStock(stock);
         }

         /// <summary>
         /// Gets the number of stocks in the index
         /// </summary>
         /// <returns>Number of stocks</returns>
         public int GetStockNumber()
         {
             return this._stockCollection.Count();
         }

         /// <summary>
         /// Calculates the index value
         /// </summary>
         /// <param name="time">Timestamp for which to calculate the value</param>
         /// <returns>Value of the index</returns>
         public decimal CalculateIndex(DateTime time)
         {
             return this._indexCalculator.CalculateIndex(this._stockCollection, time);
         }
     }

     /// <summary>
     /// Collection of indices
     /// </summary>
     public class IndexCollection : IEnumerable<Index>
     {
         Dictionary<String, Index> _indices;

         public IndexCollection()
         {
             this._indices = new Dictionary<string, Index>();
         }

         /// <summary>
         /// Returns the index specified by the name
         /// </summary>
         /// <param name="index">Index name</param>
         /// <returns>Specified index</returns>
         public Index GetIndex(string index)
         {
             string indexName = index.ToLower();
             if (!this._indices.ContainsKey(indexName))
                 throw new StockExchangeException("Index does not exist!");
             return this._indices[indexName];
         }

         /// <summary>
         /// Adds the index to the collection
         /// </summary>
         /// <param name="index">Index to be added</param>
         public void AddIndex(Index index)
         {
             string indexName = index.Name.ToLower();
             if (this._indices.ContainsKey(indexName))
                 throw new StockExchangeException("");
             this._indices.Add(indexName, index);
         }

         /// <summary>
         /// Checks if the collection contains the specified index
         /// </summary>
         /// <param name="index">Index name</param>
         /// <returns></returns>
         public bool ContainsIndex(string index)
         {
             string indexName = index.ToLower();
             return this._indices.ContainsKey(indexName);
         }

         /// <summary>
         /// Gets the number of indices in the collection
         /// </summary>
         /// <returns>Number of indices</returns>
         public int NumberOfIndeices()
         {
             return this._indices.Count;
         }

         public IEnumerator<Index> GetEnumerator()
         {
             foreach (string key in this._indices.Keys)
                 yield return this._indices[key];
         }

         System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
         {
             throw new NotImplementedException();
         }
     }


     /// <summary>
     /// Collection of Stocks
     /// </summary>
     public class StockCollection : IEnumerable<Stock>
     {
         Dictionary<String, Stock> _stocks;

         public StockCollection()
         {
             this._stocks = new Dictionary<string, Stock>();
         }

         /// <summary>
         /// Gets the stock with the specified name
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <returns>Stock with the specified name</returns>
         public Stock GetStock(string stock)
         {
             string stockName = stock.ToLower();
             if (!this._stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Stock does not exist!");
             return this._stocks[stockName];
         }

         /// <summary>
         /// Adds the stock to the collection
         /// </summary>
         /// <param name="stock">Stock that needs to be added</param>
         public void AddStock(Stock stock)
         {
             string stockName = stock.StockName.ToLower();
             if (this._stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Stockwith the same name already exists!");
             this._stocks.Add(stockName, stock);
         }

         /// <summary>
         /// Removes the stock with the specific name from the collection
         /// </summary>
         /// <param name="stockName">Stocn name</param>
         public void RemoveStock(string stockName)
         {
             string name = stockName.ToLower();
             if (!this._stocks.ContainsKey(name))
                 throw new StockExchangeException("Stock does not exist!");
             this._stocks.Remove(name);
         }

         /// <summary>
         /// Checks if the collection contains a stock with the specified name
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <returns></returns>
         public bool ContainsStock(string stock)
         {
             string stockName = stock.ToLower();
             return this._stocks.ContainsKey(stockName);
         }

         /// <summary>
         /// Returns the number of stocks in the collection
         /// </summary>
         /// <returns>Number of stocks</returns>
         public int Count()
         {
             return this._stocks.Count;
         }


         /// <summary>
         /// Checks if a stock with the specified name exists
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <returns></returns>
         public bool Exists(string stock)
         {
             string stockName = stock.ToLower();
             return this._stocks.ContainsKey(stockName);
         }

         /// <summary>
         /// Implementation of the IEnumerable inteface
         /// </summary>
         /// <returns>Traversable collenction of the stocks</returns>
         public IEnumerator<Stock> GetEnumerator()
         {
             foreach (string key in this._stocks.Keys)
                 yield return this._stocks[key];
         }

         /// <summary>
         /// Not implemented
         /// </summary>
         /// <returns></returns>
         System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
         {
             throw new NotImplementedException();
         }
     }


     public class Stock
     {

         /// <summary>
         /// Represents the value of the stock from a certain timestamp
         /// </summary>
         class StockPrice
         {
             DateTime _startDate;

             /// <summary>
             /// The date from which this price can be valid
             /// </summary>
             public DateTime StartDate
             {
                 get { return _startDate; }
             }
             decimal _value;

             /// <summary>
             /// Tha value of the stock
             /// </summary>
             public decimal Value
             {
                 get { return _value; }
             }


             /// <summary>
             /// Constructor
             /// </summary>
             /// <param name="startDate">Date from which the value can be valid</param>
             /// <param name="value">Value of the stock</param>
             public StockPrice(DateTime startDate, decimal value)
             {
                 if (value <= 0)
                     throw new StockExchangeException("Stock price is invalid!");

                 this._startDate = startDate;
                 this._value = value;
             }

             /// <summary>
             /// Checks if two objects are equal
             /// </summary>
             /// <param name="obj">Object to compare with</param>
             /// <returns>The equality of two objects</returns>
             public override bool Equals(object obj)
             {
                 StockPrice price = obj as StockPrice;
                 if (this._startDate.Equals(price._startDate))
                     return true;
                 return false;
             }
         }

         /// <summary>
         /// Collection of StockPrice objects
         /// </summary>
         class StockPriceCollection : IEnumerable<StockPrice>
         {
             List<StockPrice> _stockPrices;

             public StockPriceCollection()
             {
                 this._stockPrices = new List<StockPrice>();
             }

             /// <summary>
             /// Adds a StockPrice into the collection 
             /// </summary>
             /// <param name="price">Price of the stock</param>
             public void AddStockPrice(StockPrice price)
             {
                 this.CheckIfDateExists(price);
                 this._stockPrices.Add(price);
             }

             /// <summary>
             /// Checks if a price for the given timestamp already exists
             /// </summary>
             /// <param name="price">StockPrice which needs to be validated</param>
             void CheckIfDateExists(StockPrice price)
             {
                 if (this._stockPrices.Contains(price))
                     throw new StockExchangeException("Stock price already defined for the given timestamp!");
             }

             /// <summary>
             /// Implementation of the IEnumerable interface
             /// </summary>
             /// <returns>Returns the collection of StockPrices</returns>
             public IEnumerator<StockPrice> GetEnumerator()
             {
                 foreach (StockPrice price in this._stockPrices)
                     yield return price;
             }


             /// <summary>
             /// Not implemented
             /// </summary>
             /// <returns></returns>
             System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
             {
                 throw new NotImplementedException();
             }
         }

         string _stockName;

         /// <summary>
         /// Name of the stock
         /// </summary>
         public string StockName
         {
             get { return _stockName; }
         }
         long _numberOfShares;

         /// <summary>
         /// Number of stock shares
         /// </summary>
         public long NumberOfShares
         {
             get { return _numberOfShares; }
         }
         StockPriceCollection _stockPriceCollection;

         /// <summary>
         /// Initializes a new Stock
         /// </summary>
         /// <param name="stockName">Name of the stock</param>
         /// <param name="numberOfShares">Number of shares</param>
         /// <param name="stockPrice">Price of the stock</param>
         /// <param name="startDate">Date from which the price can be valid</param>
         public Stock(string stockName, long numberOfShares, decimal stockPrice, DateTime startDate)
         {
             if (numberOfShares <= 0)
                 throw new StockExchangeException("Number of shares can not be less than zero!");

             this._stockName = stockName;
             this._numberOfShares = numberOfShares;
             this._stockPriceCollection = new StockPriceCollection();
             StockPrice price = new StockPrice(startDate, stockPrice);
             this._stockPriceCollection.AddStockPrice(price);
         }

         /// <summary>
         /// Sets new stock price
         /// </summary>
         /// <param name="stockPrice">New stock price</param>
         /// <param name="startDate">Timestamp from which the price can be valid</param>
         public void SetStockPrice(decimal stockPrice, DateTime startDate)
         {
             StockPrice price = new StockPrice(startDate, stockPrice);
             this._stockPriceCollection.AddStockPrice(price);
         }

         /// <summary>
         /// Returns the stock price valid for the specified timestamp
         /// </summary>
         /// <param name="time">Requested timestamp</param>
         /// <returns>Value of the stock</returns>
         public decimal GetStockPrice(DateTime time)
         {
             var stockPrices = this._stockPriceCollection;
             var result = stockPrices.Where(a => a.StartDate <= time).OrderBy(a => a.StartDate);
             if (result.Count() == 0)
                 throw new StockExchangeException("No value specified for the timestamp!");
             return result.Last().Value;
         }
         /// <summary>
         /// Returns the firtst value of the stock
         /// </summary>
         /// <returns>Value of the stock</returns>
         public decimal GetFirstStockPrice()
         {
             return this._stockPriceCollection.OrderBy(a => a.StartDate).First().Value;
         }

         /// <summary>
         /// Returns the last price of the stock
         /// </summary>
         /// <returns>Value of the stock</returns>
         public decimal GetLastStockPrice()
         {
             return this._stockPriceCollection.OrderBy(a => a.StartDate).Last().Value;
         }
     }

     /// <summary>
     /// Represents a portfolio in stock exchange
     /// </summary>
     class Portfolio
     {
         /// <summary>
         /// Represents the stock with the portfolio share amount
         /// </summary>
         class PortfolioStock
         {
             Stock _stock;

             /// <summary>
             /// The specified stock
             /// </summary>
             public Stock Stock
             {
                 get { return _stock; }
             }
             int _numberOfSharesInPortfolio;

             /// <summary>
             /// Number of shares of the stock
             /// </summary>
             public int NumberOfSharesInPortfolio
             {
                 get { return _numberOfSharesInPortfolio; }
             }

             /// <summary>
             /// Returns new portfolioStock
             /// </summary>
             /// <param name="stock">Stock</param>
             /// <param name="numberOfSharesInPortfolio">Number of shares of the stock</param>
             public PortfolioStock(Stock stock, int numberOfSharesInPortfolio)
             {
                 this._stock = stock;
                 this._numberOfSharesInPortfolio = numberOfSharesInPortfolio;
             }

             /// <summary>
             /// Name of the stock
             /// </summary>
             public String Name
             {
                 get { return this._stock.StockName; }
             }

             /// <summary>
             /// Value of the stock
             /// </summary>
             /// <param name="time">Timestamp for which the value needs to be calculated</param>
             /// <returns>Stock value</returns>
             public Decimal GetStockValue(DateTime time)
             {
                 return this._stock.GetStockPrice(time) * this.NumberOfSharesInPortfolio;
             }

             /// <summary>
             /// Adds shares to the stock
             /// </summary>
             /// <param name="numberOfShares">Number of shares to be added</param>
             public void AddShares(int numberOfShares)
             {
                 this._numberOfSharesInPortfolio += numberOfShares;
             }

             /// <summary>
             /// Substracts shares from the sportfolio
             /// </summary>
             /// <param name="numberOfShares">Number of shares to be substracted</param>
             public void SubstractShares(int numberOfShares)
             {

                 this._numberOfSharesInPortfolio -= numberOfShares;
                 if (this._numberOfSharesInPortfolio < 0)
                     this._numberOfSharesInPortfolio = 0;
             }

         }

         /// <summary>
         /// Collection for PortfolioStocks
         /// </summary>
         class PortfolioStockCollection : IEnumerable<PortfolioStock>
         {
             Dictionary<string, PortfolioStock> _portfolioStocks;

             public PortfolioStockCollection()
             {
                 this._portfolioStocks = new Dictionary<string, PortfolioStock>();
             }

             /// <summary>
             /// Adds portfoliostock to collection
             /// </summary>
             /// <param name="stock">Portfolio stock to be added</param>
             public void AddPortfolioStock(PortfolioStock stock)
             {
                 string stockName = stock.Name.ToLower();
                 if (this._portfolioStocks.ContainsKey(stockName))
                     throw new StockExchangeException("Stock already exists");
                 this._portfolioStocks.Add(stockName, stock);
             }

             /// <summary>
             /// Removes portfoliostocks from the collection
             /// </summary>
             /// <param name="stock">Name of the portfoliostock to be removed</param>
             public void Remove(String stock)
             {
                 string stockName = stock.ToLower();
                 if (!this._portfolioStocks.ContainsKey(stockName))
                     throw new StockExchangeException("Stock does not exist");
                 this._portfolioStocks.Remove(stockName);
             }

             /// <summary>
             /// Gets the specified portfoliostock
             /// </summary>
             /// <param name="stock">Name of the stock to be returned</param>
             /// <returns>The specified stock</returns>
             public PortfolioStock Get(String stock)
             {
                 string stockName = stock.ToLower();
                 if (!this._portfolioStocks.ContainsKey(stockName))
                     throw new StockExchangeException("Stock does not exist");
                 return this._portfolioStocks[stockName];
             }

             /// <summary>
             /// Checks if the collection contains the specified stock
             /// </summary>
             /// <param name="stock">Name of the stock</param>
             /// <returns></returns>
             public bool Contains(String stock)
             {
                 return this._portfolioStocks.ContainsKey(stock.ToLower());
             }

             /// <summary>
             /// Returns the number of items in the collection
             /// </summary>
             /// <returns>Number of items</returns>
             public int Count()
             {
                 return this._portfolioStocks.Count;
             }


             /// <summary>
             /// Implementation of the IEnumerable interface
             /// </summary>
             /// <returns>The collecion of PortfolioStock</returns>
             public IEnumerator<PortfolioStock> GetEnumerator()
             {
                 foreach (string key in this._portfolioStocks.Keys)
                 {
                     yield return this._portfolioStocks[key];
                 }
             }

             System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
             {
                 throw new NotImplementedException();
             }
         }





         string _id;

         public string Id
         {
             get { return _id; }
             set { _id = value; }
         }
         PortfolioStockCollection _portfolioStocks;

         public Portfolio(string id)
         {
             this._id = id;
             this._portfolioStocks = new PortfolioStockCollection();
         }

         /// <summary>
         /// Adds stocks to portfolio
         /// </summary>
         /// <param name="stock">Stocn name</param>
         /// <param name="numberOfShares">Number of shares</param>
         public void AddStock(Stock stock, int numberOfShares)
         {
             if (numberOfShares <= 0)
                 throw new StockExchangeException("");

             if (this._portfolioStocks.Contains(stock.StockName))
             {
                 PortfolioStock portfolioStock = this._portfolioStocks.Get(stock.StockName);
                 portfolioStock.AddShares(numberOfShares);
             }
             else 
             {
                 PortfolioStock portfolioStock = new PortfolioStock(stock, numberOfShares);
                 this._portfolioStocks.AddPortfolioStock(portfolioStock);
             }

         }

         /// <summary>
         /// Removes stock from portfolio
         /// </summary>
         /// <param name="stock"></param>
         public void RemoveStock(string stock)
         {
             string stockName = stock.ToLower();
             if (!this._portfolioStocks.Contains(stockName))
                 throw new StockExchangeException("Stock does not exist");
             this._portfolioStocks.Remove(stockName);
         }

         /// <summary>
         /// Removes a number of shares for a stock from the portfolio
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <param name="numberOfShares">Number of shares</param>
         public void RemoveStock(string stock, int numberOfShares)
         {
             string stockName = stock.ToLower();
             if (!this._portfolioStocks.Contains(stockName))
                 throw new StockExchangeException("Stock does not exist");
             PortfolioStock portfolioStock = this._portfolioStocks.Get(stock);
             portfolioStock.SubstractShares(numberOfShares);
             if (portfolioStock.NumberOfSharesInPortfolio == 0)
                 this.RemoveStock(stock);
         }

         /// <summary>
         /// Returns the number of stocks in portfolio
         /// </summary>
         /// <returns>Number of stocks</returns>
         public int StockCount()
         {
             return this._portfolioStocks.Count();
         }

         /// <summary>
         /// Checks if the portfolio contains a stock
         /// </summary>
         /// <param name="stock">Name of the stock</param>
         /// <returns></returns>
         public bool ContainsStock(string stock)
         {
             return this._portfolioStocks.Contains(stock);
         }

         /// <summary>
         /// Returns the number of stock shares
         /// </summary>
         /// <param name="stock">Stock name</param>
         /// <returns>Number of stock shares</returns>
         public int NumberOfStockShares(string stock)
         {
             if (!this._portfolioStocks.Contains(stock))
                 return 0;
             PortfolioStock portfolioStock = this._portfolioStocks.Get(stock);
             return portfolioStock.NumberOfSharesInPortfolio;
         }

         /// <summary>
         /// Calculates the portfolio value
         /// </summary>
         /// <param name="timestamp">Timestamp for which the value is calculated</param>
         /// <returns>Value of the portfolio</returns>
         public decimal CalculatePortfolioValue(DateTime timestamp)
         {
             decimal portfolioValue = 0;
             foreach (PortfolioStock portfolioStock in this._portfolioStocks)
             {
                 portfolioValue += portfolioStock.GetStockValue(timestamp);
             }
             return portfolioValue;
         }

         /// <summary>
         /// Returns the portfolio percentage
         /// </summary>
         /// <param name="year">Year</param>
         /// <param name="month">Month</param>
         /// <returns>Percentage</returns>
         public decimal GetPercentageForMonth(int year, int month)
         {
             decimal startOfTheMonth = 0;
             decimal endOfTheMonth = 0;
             try
             {
                 DateTime dateTime = new DateTime(year, month, 2);
             }
             catch
             {
                 throw new StockExchangeException("Date invalid!");
             }
             foreach (PortfolioStock portfolioStock in this._portfolioStocks)
                 startOfTheMonth += portfolioStock.GetStockValue(new DateTime(year, month, 1));
             foreach (PortfolioStock portfolioStock in this._portfolioStocks)
                 endOfTheMonth += portfolioStock.GetStockValue(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
             decimal result = 0;

             if (this._portfolioStocks.Count() != 0)
                 result = decimal.Round((endOfTheMonth - startOfTheMonth) / startOfTheMonth * 100, 3);

             return result;
         }
     }

     /// <summary>
     /// Collection of portfolios
     /// </summary>
     class PortfolioCollection : IEnumerable<Portfolio>
     {
         Dictionary<string, Portfolio> _portfolios;
         public PortfolioCollection()
         {
             this._portfolios = new Dictionary<string, Portfolio>();
         }

         /// <summary>
         /// Adds a portfolio to the collection
         /// </summary>
         /// <param name="portfolio">Portfolio to be added</param>
         public void AddPortfolio(Portfolio portfolio)
         {
             if (this._portfolios.ContainsKey(portfolio.Id))
                 throw new StockExchangeException("Portfolio already exists");
             this._portfolios.Add(portfolio.Id, portfolio);
         }

         /// <summary>
         /// Removes portfolio from the collection
         /// </summary>
         /// <param name="portfolioId">Id of portfolio to be removed</param>
         public void RemovePortfolio(string portfolioId)
         {
             if (!this._portfolios.ContainsKey(portfolioId))
                 throw new StockExchangeException("");
             this._portfolios.Remove(portfolioId);
         }

         /// <summary>
         /// Returns the specified portfolio
         /// </summary>
         /// <param name="portfolioId">Id of the requested portfolio</param>
         /// <returns>Requested portfolio</returns>
         public Portfolio GetPortfolio(string portfolioId)
         {
             if (!this._portfolios.ContainsKey(portfolioId))
                 throw new StockExchangeException("");
             return this._portfolios[portfolioId];
         }

         /// <summary>
         /// Returns the number of items
         /// </summary>
         /// <returns></returns>
         public int Count()
         {
             return this._portfolios.Count;
         }

         /// <summary>
         /// Checks if the collection contains the 
         /// </summary>
         /// <param name="portfolioId">Id of specified portfolio</param>
         /// <returns></returns>
         public bool Contains(string portfolioId)
         {
             return this._portfolios.ContainsKey(portfolioId);
         }

         public IEnumerator<Portfolio> GetEnumerator()
         {
             foreach (string key in this._portfolios.Keys)
                 yield return this._portfolios[key];
         }

         System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
         {
             throw new NotImplementedException();
         }
     }
}
