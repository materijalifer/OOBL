﻿using System;
using System.Collections.Generic;
using System.Linq;

// ReSharper disable CheckNamespace
namespace DrugaDomacaZadaca_Burza
// ReSharper restore CheckNamespace
{
    /** 
     * Factory class for stock exchange market class - 
     * StockExchange.
     */
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     /** 
      * Stock exchange market class. Simulates stock exchange market.
      */
     public class StockExchange : IStockExchange
     {
         private readonly StockAdministrator _stocksAdmin;
         private readonly StockIndexAdministrator _stockIndexesAdmin; 
         private readonly StockPortfolioAdministrator _stockPortfoliosAdmin;

         public StockExchange()
         {
             _stockIndexesAdmin = new StockIndexAdministrator();
             _stockPortfoliosAdmin = new StockPortfolioAdministrator();

             var observers = new HashSet<IStockMarketObserver> {_stockIndexesAdmin, 
                                                    _stockPortfoliosAdmin};

             _stocksAdmin = new StockAdministrator(observers);
         }

         //STOCKS----------------------------------------------------------------

         public void ListStock(string inStockName, long inNumberOfShares, 
                               decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName + 
                            " is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             _stocksAdmin.AddStockToMarket(inStockName, (int)inNumberOfShares, 
                                          inInitialPrice, inTimeStamp);
         }

         public void DelistStock(string inStockName)
         {
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName + 
                            " is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             _stocksAdmin.RemoveStockFromMarket(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                            " is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             return _stocksAdmin.StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stocksAdmin.NumberOfStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, 
                                    decimal inStockValue)
         {
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                            " is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             _stocksAdmin.SetStockPrice(inStockName, inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                            " is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             return _stocksAdmin.GetStockPrice(inStockName, inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             return _stocksAdmin.GetInitialStockPrice(inStockName);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);
             return _stocksAdmin.GetLastStockPrice(inStockName);
         }

         //INDEX------------------------------------------------------------------

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                            " is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                                inIndexName);
             _stockIndexesAdmin.CreateIndex(inIndexName, inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName + 
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                                inIndexName);
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not add stock to stock " +
                            "index. Stock: " + inStockName + "doesn't exist in " +
                            "the stock exchange market. ");
             }

            _stockIndexesAdmin.AddStockToIndex(inIndexName, inStockName);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                               inIndexName);
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not remove stock from " +
                            "stock index. Stock index: " + inIndexName + 
                            " doesn't exist in the stock exchange market. ");
             }
             _stockIndexesAdmin.RemoveStockFromIndex(inIndexName, inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                               inIndexName);
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             return _stocksAdmin.StockExists(inStockName) && 
                 _stockIndexesAdmin.IsStockPartOfIndex(inIndexName, inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                               inIndexName);
             return _stockIndexesAdmin.GetIndexValue(_stocksAdmin.Stocks, 
                                                     inIndexName, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                               inIndexName);
             return _stockIndexesAdmin.IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _stockIndexesAdmin.NumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!CheckUserInputStringValidity(inIndexName))
             {
                 throw new StockExchangeException("Input: " + inIndexName +
                                                  "is not valid!");
             }
             inIndexName = _stockIndexesAdmin.ResolveStockIndexNameAmbiguity(
                                                               inIndexName);
             return _stockIndexesAdmin.NumberOfStocksInIndex(inIndexName);
         }

         //PORTFOLIO -----------------------------------------------------------

         public void CreatePortfolio(string inPortfolioId)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             _stockPortfoliosAdmin.CreatePortfolio(inPortfolioId);
         }

         public void AddStockToPortfolio(string inPortfolioId, 
                                         string inStockName, 
                                         int inNumberOfSharesToAdd)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not add stock to stock " +
                           "portfolio. Stock: " + inStockName + " doesn't exist");
             }
             if (!_stocksAdmin.IsNumberOfStockSharesValid(inNumberOfSharesToAdd))
             {
                 throw new StockExchangeException("Can not add stock to stock " +
                           "portfolio. Invalid number of shares: " 
                           + inNumberOfSharesToAdd);
             }

             var numberOfStockShares = _stocksAdmin.NumberOfStockShares(inStockName);

             _stockPortfoliosAdmin.AddStockToPortfolio(inPortfolioId, inStockName,
                                                    inNumberOfSharesToAdd, 
                                                    numberOfStockShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioId, 
                                              string inStockName, 
                                              int inNumberOfSharesToSubstract)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not remove stock from stock " +
                           "portfolio. Stock: " + inStockName + " doesn't exist");
             }
             if (!_stocksAdmin.IsNumberOfStockSharesValid(inNumberOfSharesToSubstract))
             {
                 throw new StockExchangeException("Can not remove stock from stock " +
                           "portfolio. Invalid number of shares: " 
                           + inNumberOfSharesToSubstract);
             }

             var numberOfStockShares = _stocksAdmin.NumberOfStockShares(inStockName);
             
            _stockPortfoliosAdmin.RemoveStockFromPortfolio(inPortfolioId, 
                                                           inStockName, 
                                                           inNumberOfSharesToSubstract,
                                                           numberOfStockShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioId, 
                                               string inStockName)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not remove stock from " +
                           "stock portfolio. Stock : " + inStockName + 
                           " doesn't exist in the stock exchange market. ");
             }
             _stockPortfoliosAdmin.RemoveStockFromPortfolio(inPortfolioId, inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _stockPortfoliosAdmin.NumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioId)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             return _stockPortfoliosAdmin.NumberOfStocksInPortfolio(inPortfolioId);
         }

         public bool PortfolioExists(string inPortfolioId)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             return _stockPortfoliosAdmin.PortfolioExists(inPortfolioId);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioId, 
                                            string inStockName)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             return _stocksAdmin.StockExists(inStockName) && 
                    _stockPortfoliosAdmin.IsStockPartOfPortfolio(inPortfolioId, 
                                                                 inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioId, 
                                                     string inStockName)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (!CheckUserInputStringValidity(inStockName))
             {
                 throw new StockExchangeException("Input: " + inStockName +
                                                  "is not valid!");
             }
             inStockName = _stocksAdmin.ResolveStockNameAmbiguity(inStockName);

             if (!_stocksAdmin.StockExists(inStockName))
             {
                 throw new StockExchangeException("Can not get the number of " +
                           "shares of stock from stock portfolio. Stock: " 
                           + inStockName + " doesn't exist in the stock " +
                            "exchange market. ");
             }
             return _stockPortfoliosAdmin.NumberOfSharesOfStockInPortfolio(inPortfolioId,
                                                                           inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioId, DateTime timeStamp)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             return _stockPortfoliosAdmin.GetPortfolioValue(inPortfolioId, 
                                                            timeStamp, 
                                                            _stocksAdmin.Stocks);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioId,
                                                                  int year, int month)
         {
             if (!CheckUserInputStringValidity(inPortfolioId))
             {
                 throw new StockExchangeException("Input: " + inPortfolioId +
                                                  "is not valid!");
             }
             if (month > 12 || month < 1)
             {
                 throw new StockExchangeException("Can not get stock portfolio" +
                           " percent change in value for month. The given month " +
                           "isn't valid: " + month);
             }
             return _stockPortfoliosAdmin.GetPortfolioPercentChangeInValueForMonth(
                                     inPortfolioId, year, month,_stocksAdmin.Stocks);
         }

         private static bool CheckUserInputStringValidity(string input)
         {
             return null != input && !input.Equals("");
         }
     }




     /**
      * Stock Administrator class used for stock administration, which includes:
      * adding and removing stocks to and from stock market and stock price 
      * manipulation. When stock is removed from the stock market, it is also
      * removed from the stock portfolio and stock index.
      */
     public class StockAdministrator 
    {
        private readonly Dictionary<string, Stock> _stocks;
        private readonly HashSet<IStockMarketObserver> _observers;

        public StockAdministrator(HashSet<IStockMarketObserver> observers) 
        {
            _stocks = new Dictionary<string, Stock>();
            _observers = observers;
        }

        public string ResolveStockNameAmbiguity(string stockName)
        {
            return Stock.ConvertStockName(stockName);
        }

        public void AddStockToMarket(string stockName, int numberOfShares,
                                     decimal initialPrice, DateTime timeStamp)
        {
            if (StockExists(stockName))
            {
                throw new StockExchangeException("Can not add new stock: " 
                           + stockName + ". This stock already exists in the " +
                           "stock exchange market");
            }
            var stock = new Stock(stockName, timeStamp, initialPrice, 
                                  numberOfShares);

            _stocks.Add(stock.Name, stock);
        }

        public void RemoveStockFromMarket(string stockName)
        {
            if (!StockExists(stockName))
            {
                throw new StockExchangeException("Can not delete stock: " 
                          + stockName + ". This stock does not exist in " +
                          "the stock exchange market");
            }
            _stocks.Remove(stockName);
            Notify(stockName);
        }

        private void Notify(string stockName)
        {
            foreach (var observer in _observers)
            {
                observer.UpdateState(stockName);
            }
        }

        public bool StockExists(string stockName)
        {
            return _stocks.Keys.Contains(stockName);
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public int NumberOfStockShares(string stockName)
        {
            return _stocks[stockName].NumberOfShares;
        }

        public bool IsNumberOfStockSharesValid(int numberOfStockShares)
        {
            return Stock.IsNumberOfSharesValid(numberOfStockShares);
        }

        public void SetStockPrice(string stockName, DateTime timeStamp, 
                                  decimal stockValue)
        {

            if (!StockExists(stockName))
            {
                throw new StockExchangeException("Can not set stock price for " +
                          "the stock: " + stockName + " . This stock does not " +
                          "exist in the stock exchange market");
            }
            var stock = _stocks[stockName];

            stock.SetPrice(timeStamp, stockValue);
        }

        public decimal GetStockPrice(string stockName, DateTime timeStamp)
        {
            if (!StockExists(stockName))
            {
                throw new StockExchangeException("Can not get stock price for " +
                          "the stock: " + stockName + " . This stock does not " +
                           "exist in the stock exchange market");
            }
            var stock = _stocks[stockName];
            var stockPrice = stock.GetPrice(timeStamp);

            return stockPrice.Amount;
        }

        public decimal GetInitialStockPrice(string stockName)
        {
            if (!StockExists(stockName))
            {
                throw new StockExchangeException("Can not get initial stock " +
                          "price for the stock: " + stockName + " . This stock" +
                          " does not exist in the stock exchange market");
            }
            var stock = _stocks[stockName];
            var stockPrice = stock.GetInitialPrice();

            return stockPrice.Amount;
        }

        public decimal GetLastStockPrice(string stockName)
        {
            if (!StockExists(stockName))
            {
                throw new StockExchangeException("Can not get last stock price " +
                           "for the tock: " + stockName + " . This stock " +
                            "does not exist in the stock exchange market");
            }
            var stock = _stocks[stockName];
            var stockPrice = stock.GetLastPrice();

            return stockPrice.Amount;
        }

        public Dictionary<string, Stock> Stocks
        {
            get { return _stocks; }
        }
    }




    /**
     * Stock market observer interface. Class which implements this interface 
     * is notified every time the stock is removed from the stock market.
     */
    public interface IStockMarketObserver
    {
        void UpdateState(string stockName);
    }



    /**
     * Stock index administrator class. Implements market observer interface
     * and is notified when stock is removed from the stock market. Used for 
     * stock index administration: adding and removing of stock indexes, adding
     * and removing of stocks from stock index and stock index value calculation.
     */
    public class StockIndexAdministrator : IStockMarketObserver
    {
        private readonly Dictionary<string, StockIndex> _stockIndexes;
        private readonly Dictionary<IndexTypes, IndexValueCalculator> _typesContainer;
        private IndexValueCalculator _valueCalculator;

        public StockIndexAdministrator()
        {
            _stockIndexes = new Dictionary<string, StockIndex>();

            _typesContainer = new Dictionary<IndexTypes, IndexValueCalculator>
                {
                    {IndexTypes.AVERAGE, new AverageIndexValueCalculator()},
                    {IndexTypes.WEIGHTED, new WeightedIndexValueCalculator()}
                };
        }

        public string ResolveStockIndexNameAmbiguity(string stockIndexName)
        {
            return StockIndex.ConvertIndexName(stockIndexName);
        }

        public void CreateIndex(string indexName, IndexTypes indexType)
        {
            if (IndexExists(indexName.ToUpper()))
            {
                throw new StockExchangeException("Can not create index. The " +
                          "index with the name " + indexName + " already " +
                          "exists in the stock exchange market. ");
            }

            if (!_typesContainer.Keys.Contains(indexType))
            {
                throw new StockExchangeException("Unable to create index. " +
                              "Unknown stock index type.");
            }

            _valueCalculator = _typesContainer[indexType];

            var stockIndex = new StockIndex(indexName, indexType);

            _stockIndexes.Add(indexName, stockIndex);
        }

        public void AddStockToIndex(string indexName, string stockName)
        {
            if (!IndexExists(indexName))
            {
                throw new StockExchangeException("Can not add stock to stock " +
                          "index. Stock index: " + indexName + " doesn't " +
                          "exist in the stock exchange market. ");
            }

            _stockIndexes[indexName].AddStock(stockName);
        }

        public void RemoveStockFromIndex(string indexName, string stockName)
        {
            if (!IndexExists(indexName))
            {
                throw new StockExchangeException("Can not remove stock from stock" +
                           " index. Stock index: " + indexName + " doesn't exist " +
                           "in the stock exchange market. ");
            }
            _stockIndexes[indexName].RemoveStock(stockName);
        }

        public bool IsStockPartOfIndex(string indexName, string stockName)
        {
            if (!IndexExists(indexName))
            {
                throw new StockExchangeException("Can not check if stock is part" +
                          " of index. Stock index: " + indexName + " doesn't " +
                          "exist in the stock exchange market. ");
            }
            return _stockIndexes[indexName].IsStockInIndex(stockName);
        }

        public decimal GetIndexValue(Dictionary<string, Stock> stocksFromMarket, 
                                    string indexName, DateTime timeStamp)
        {
            if (!IndexExists(indexName))
            {
                throw new StockExchangeException("Can not get stock index value. "
                          + "Stock index:" + indexName +" doesn't exist in the " +
                          "stock exchange market. ");
            }
            var stocksFromIndex = _stockIndexes[indexName].StocksFromIndex;

            return _valueCalculator.GetValue(stocksFromIndex, stocksFromMarket,
                                             timeStamp);
        }

        public bool IndexExists(string indexName)
        {
            return _stockIndexes.Keys.Contains(indexName);
        }

        public int NumberOfIndices()
        {
            return _stockIndexes.Count();
        }

        public int NumberOfStocksInIndex(string indexName)
        {
            if (!IndexExists(indexName))
            {
                throw new StockExchangeException("Can not retreive number of " +
                          "stocks in index. " + "Stock index:" + indexName +
                          " doesn't exist in the stock exchange market. ");
            }

            return _stockIndexes[indexName].StockCount();
        }

        public void UpdateState(string stockName)
        {
            foreach (var stockIndexPair in _stockIndexes)
            {
                var stockIndex = stockIndexPair.Value;

                if (!stockIndex.IsStockInIndex(stockName)) 
                    continue;
                stockIndex.RemoveStock(stockName);
                break;
            }
        }

        public Dictionary<string, StockIndex> StockIndexes
        {
            get { return _stockIndexes; }
        }
    }



    /**
     * Stock portfoilo administrator class. Implements market observer interface
     * and is notified when stock is removed from the stock market. Used for 
     * stock portfolio administration: adding and removing of stock portfolios, 
     * adding and removing of stocks from stock portfolio and stock portfolio 
     * value calculation. It also provides monthly change in portfolio value.
     */
    public class StockPortfolioAdministrator : IStockMarketObserver
    {
        private readonly Dictionary<string, StockPortfolio> _stockPortfolios;
        private readonly PortfolioValueCalculator _valueCalculator;

        public StockPortfolioAdministrator()
        {
            _stockPortfolios = new Dictionary<string, StockPortfolio>();  
            _valueCalculator = new PortfolioValueCalculator();
         }

        public void CreatePortfolio(string portfolioId)
         {
             if (PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not create stock portfolio." +
                            " The portfolio with the name " + portfolioId + 
                            " already exists in the stock exchange market. ");
             }
             var stockPortfolio = new StockPortfolio(portfolioId);

             _stockPortfolios.Add(portfolioId,stockPortfolio);
         }

         private int ComputeSumOfStockShares(string stockName)
         {
             return _stockPortfolios.Where(stockPortfolio => 
                     stockPortfolio.Value.IsStockInPortfolio(stockName))
                    .Sum(stockPortfolio => 
                     stockPortfolio.Value.GetNumberOfStockShares(stockName));
         }

         public void AddStockToPortfolio(string portfolioId, string stockName,
                                         int numberOfSharesToAdd, 
                                         int numberOfStockShares)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not add stock to stock " +
                           "portfolio. Stock portfolio: doesn't exist in the stock " +
                           "exchange market. Or invalid number " + "of shares " +
                           "was sent.");
             }

             var sumOfStockSharesInPortfolios = ComputeSumOfStockShares(stockName);
             var newNumberOfShares = sumOfStockSharesInPortfolios
                                     + numberOfSharesToAdd;

             if (newNumberOfShares > numberOfStockShares)
             {
                 throw new StockExchangeException("Can not add stock to stock" +
                           " portfolio. Invalid number of shares was sent for stock: "
                           + stockName);   
             }

             _stockPortfolios[portfolioId].AddStock(stockName, numberOfSharesToAdd);
         }

         public void RemoveStockFromPortfolio(string portfolioId, 
                                              string stockName, 
                                              int numberOfSharesToSubstract,
                                              int numberOfStockShares)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not remove stock from " +
                            "stock portfolio: " + portfolioId + "It doesn't " +
                            "exist in the stock exchange market.");
             }
             if (numberOfStockShares < numberOfSharesToSubstract)
             {
                 throw new StockExchangeException("Can not remove stock from stock" +
                            " portfolio. Invalid number of shares was sent: "
                            + numberOfSharesToSubstract);   
             }
             
             _stockPortfolios[portfolioId].RemoveStockShares(stockName, 
                                                numberOfSharesToSubstract);
         }

         public void RemoveStockFromPortfolio(string portfolioId, 
                                              string stockName)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not remove stock from " +
                            "stock portfolio. Stock portfolio: doesn't exist " +
                            "in the stock exchange market. ");
             }
             _stockPortfolios[portfolioId].RemoveStock( stockName );
         }

         public int NumberOfPortfolios()
         {
             return _stockPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string portfolioId)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not retreive number" +
                           " of stocks in portfolio. " + "Stock portfolio: "
                           + portfolioId + " doesn't exist in the stock " +
                            "exchange market. ");
             }
             return _stockPortfolios[portfolioId].StockCount();
         }

         public bool PortfolioExists(string portfolioId)
         {
             return _stockPortfolios.Keys.Contains(portfolioId);
         }

         public bool IsStockPartOfPortfolio(string portfolioId, string stockName)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not check if stock is part" +
                           " of stock portfolio. Stock portfolio: " + portfolioId +
                           " doesn't exist in the stock exchange market. ");
             }
             return _stockPortfolios[portfolioId].IsStockInPortfolio(stockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string portfolioId, 
                                                     string stockName)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not get the number of " +
                           "shares of stock from stock portfolio. Stock portfolio: " 
                           + portfolioId + " doesn't exist in the stock " +
                           "exchange market. ");
             }
             return _stockPortfolios[portfolioId].GetNumberOfStockShares(stockName);
         }

         public decimal GetPortfolioValue(string portfolioId, DateTime timeStamp, 
                                          Dictionary<string,Stock> stocksFromMarket)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not get stock portfolio " +
                            "value. Stock portfolio:" + portfolioId + " doesn't " +
                            "exist in the stock exchange market. ");
             }

             var stocksFromPortfolio = _stockPortfolios[portfolioId].StocksReferences;
             var value = _valueCalculator.GetValue(stocksFromPortfolio, 
                                                   stocksFromMarket, timeStamp);

             return value;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string portfolioId,
                                                                 int year, int month,
                                             Dictionary<string,Stock> stocksFromMarket)
         {
             if (!PortfolioExists(portfolioId))
             {
                 throw new StockExchangeException("Can not get stock portfolio percent" +
                           " change in value for month. Stock portfolio:" 
                           + portfolioId + " doesn't exist in the stock exchange");
             }
             var stocksFromPortfolio = _stockPortfolios[portfolioId].StocksReferences;
             var percent = _valueCalculator.GetPercentChangeInValueForMonth(
                                                              stocksFromPortfolio,
                                                              stocksFromMarket,
                                                              year, month);

             return percent;
         }

         public void UpdateState(string stockName)
         {
             foreach (var stockPortfolioPair in _stockPortfolios)
             {
                 var stockPortfolio = stockPortfolioPair.Value;

                 if (!stockPortfolio.IsStockInPortfolio(stockName)) 
                     continue;
                 stockPortfolio.RemoveStock(stockName);
                 break;
             }
         }

        public Dictionary<string, StockPortfolio> StockPortfolios
        {
            get { return _stockPortfolios; }
        }
    }




    /**
     * This class represents a stock from the stock exchange market.
     * Every stock has a name which is its identifier; number of stock
     * shares and price. Prices through time are saved and can be 
     * retreived and number of stock shares cannot be zero or negative.
     */
     public class Stock
     {
         private readonly string _name;
         private Price _price;
         private readonly int _numberOfShares;
         private readonly PriceHistory _priceHistory;

         public Stock(string name,  DateTime timestamp, Decimal amount,
                                                    int numberOfShares)
         {
             _name = ConvertStockName(name);
             _price = new Price(timestamp, amount);
             _numberOfShares = numberOfShares;
             if (!IsNumberOfSharesValid(numberOfShares))
             {
                 throw new StockExchangeException("Unable to set number " +
                           "of stock shares. The number is not valid.");
             }
             _priceHistory = new PriceHistory();
         }

         public static string ConvertStockName(string stockName)
         {
             return stockName.ToUpper();
         }

         public static bool IsNumberOfSharesValid(int numberOfShares)
         {
             return numberOfShares > 0;
         }

         private bool CheckPriceExistance(DateTime timeStamp)
         {
             return _price.IsPriceDefined(timeStamp) || 
                    _priceHistory.IsPriceForTimeDefined(timeStamp);
         }

         public void SetPrice( DateTime timeStamp, Decimal amount )
         {
             if (CheckPriceExistance(timeStamp))
             {
                 throw new StockExchangeException("The price is already " +
                           "defined for the given timestamp: " + timeStamp);
             }

             var newPrice = new Price(timeStamp, amount);
             if (_price.IsPriceOutdated(timeStamp))
             {
                 _priceHistory.StorePrice(_price);
                 _price = newPrice;
             }
             else
             {
                 _priceHistory.StorePrice(newPrice);
             }
         }

         public Price GetLastPrice()
         {
             return _price;
         }

         public Price GetPrice( DateTime timeStamp )
         {
             if (_price.IsTimeWithinThePriceTimeScope(timeStamp))
             {
                 return _price;
             }
             var price = _priceHistory.RetreivePrice( timeStamp );
             return price;
         }

         public Price GetInitialPrice()
         {
             try
             {
                 var price = _priceHistory.RetreiveInitialPrice();
                 return price;
             }
             catch (StockExchangeException)
             {
                 return _price;
             }
         }

         public Price StockPrice
         {
             get { return _price; }
         }

         public string Name
         {
             get { return _name; }
         }

         public int NumberOfShares
         {
             get { return _numberOfShares;  }
         }
     }



    /**
     * This class represents stock price. Stock price is defined for a certain
     * moment and cannot be defined for the same moment twice. The price amount
     * cannot be zero or negative. The price is valid until another price for 
     * earlier time is defined.
     */
     public class Price
     {
         private readonly DateTime _timeStamp;
         private readonly decimal _amount;

         public Price(DateTime timeStamp, decimal amount)
         {
             _amount = amount;
             if (!IsAmountValid())
             {
                 throw new StockExchangeException("Price amount is not valid: "
                                                   + amount);
             }
             _timeStamp = timeStamp;
         }

         public bool IsPriceOutdated(DateTime timeStamp)
         {
             return _timeStamp < timeStamp;
         }

         public bool IsPriceDefined( DateTime timeStamp )
         {
             return timeStamp.CompareTo(_timeStamp) == 0;
         }

         public bool IsTimeWithinThePriceTimeScope(DateTime timeStamp)
         {
             return timeStamp.CompareTo(_timeStamp) >= 0;
         }

         private bool IsAmountValid()
         {
             return _amount > 0;
         }

         public DateTime TimeStamp
         {
             get { return _timeStamp; }
         }

         public decimal Amount
         {
             get { return _amount; }
         }
     }



    /**
     * This class is used for preserving stock prices that are currently 
     * not valid, but were valid in some point in the past. Stock prices
     * can be retreived and added from and to price history.
     */
     public class PriceHistory
     {
         private readonly SortedDictionary<DateTime, Price> _prices;

         public PriceHistory()
         {
             _prices = new SortedDictionary<DateTime, Price>();
         }

         public bool IsPriceForTimeDefined(DateTime timeStamp)
         {
             return _prices.Keys.Contains(timeStamp);
         }

         public void StorePrice(Price price)
         {
             if (!IsPriceForTimeDefined(price.TimeStamp))
             {
                 _prices.Add(price.TimeStamp, price);
             }
             else
             {
                 throw new StockExchangeException("Can not add new price: "
                            + price + ". The amount for the given " +
                            "timestamp already exists.");
             }
         }

         private bool DoesValidPriceExistForTime(DateTime timeStamp)
         {
             var isPriceSet = false;
             try
             {
                 isPriceSet = timeStamp.CompareTo(_prices.Keys.First()) >= 0;
             }
             catch (InvalidOperationException)
             {
                 return isPriceSet;
             }
             return isPriceSet;
         }

         public Price RetreivePrice(DateTime timeStamp)
         {
             if (!_prices.Any() || !DoesValidPriceExistForTime(timeStamp))
             {
                 throw new StockExchangeException("Unable to retreive price " +
                           "for the given timestamp. The price with the given " +
                           "timeStamp was never defined.");
             }
             Price price;
             _prices.TryGetValue(timeStamp, out price);

             if (null != price)
             {
                 return price;
             }

             var lastPrice = _prices.First().Value;
             foreach (var pricePair in _prices)
             {
                 lastPrice = pricePair.Value;

                 if (timeStamp < pricePair.Key)
                 {
                     return lastPrice;
                 }
             }

             return lastPrice;
         }

         public Price RetreiveInitialPrice()
         {
             Price price;

             try
             {
                 price = _prices.Values.First();
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Unable to retreive initial" +
                            " price for the given timestamp. "); 
             }
             return price; 
         }
     }




    /**
     * This class represents stock index from stock exchange market. Every 
     * stock index has a name which is its identifier, type and it can contain
     * stocks. Stocks can be added and removed from the stock index. 
     */
    public class StockIndex
    {
        private readonly string _name;
        private readonly IndexTypes _type;
        private readonly HashSet<string> _stocksRef; 

        public StockIndex(string name, IndexTypes type)
        {
            _name = ConvertIndexName(name);
            _type = type;
            _stocksRef = new HashSet<string>();
        }

        public static string ConvertIndexName(string indexName)
        {
            return indexName.ToUpper();
        }

        public bool IsStockInIndex(string stockName)
        {
            return _stocksRef.Contains(stockName);
        }

        public void AddStock(string stockName)
        {
            if (IsStockInIndex(stockName))
            {
                throw new StockExchangeException("Can not add stock: " 
                          + stockName + " to stock reference container. " +
                          "This stock already exists in this reference " +
                          "container. ");
            }
            _stocksRef.Add(stockName);
        }

        public void RemoveStock(string stockName)
        {
            if (!IsStockInIndex(stockName))
            {
                throw new StockExchangeException("Can not remove stock: " 
                          + stockName + " from stock reference container. " +
                          "This stock doesn't exists in this reference container. ");
            }
            _stocksRef.Remove(stockName);
        }

        public int StockCount()
        {
            return _stocksRef.Count();
        }

        public HashSet<string> StocksFromIndex
        {
            get { return _stocksRef; }
        } 

        public IndexTypes Type
        {
            get { return _type; }
        }

        public string Name
        {
            get { return _name; }
        }
    }




    /**
    * This class represents stock portfolio from stock exchange market. Every 
    * stock portfolio has an identifier, type and it can contain stocks. Stocks
    * can be added and removed from the stock portfolio. 
    */
    public class StockPortfolio
    {
        private readonly string _id;
        private readonly Dictionary<string, int> _stocksRef;

        public StockPortfolio(string id)
        {
            _id = id;
            _stocksRef = new Dictionary<string, int>();
        }

        public int GetNumberOfStockShares(string stockName)
        {
            if (!IsStockInPortfolio(stockName))
            {
                throw new StockExchangeException("Can not retreive number of " +
                          "stock shares from portfolio. The stock: " + stockName
                          + "doesn't exist in portfolio. ");
            }
            return _stocksRef[stockName];
        }

        public void AddStock(string stockName, int numberOfSharesToAdd)
        {
            if (!IsStockInPortfolio(stockName))
            {
                _stocksRef.Add(stockName, numberOfSharesToAdd);
                return;
            }
            var newNumberOfStockShares = _stocksRef[stockName] + 
                                        numberOfSharesToAdd;

            _stocksRef[stockName] = newNumberOfStockShares;
        }

        public void RemoveStock(string stockName)
        {
            if (!IsStockInPortfolio(stockName))
            {
                throw new StockExchangeException("Can not remove stock from " +
                          "portfolio. The stock: " + stockName + "doesn't exist" +
                          " in portfolio. ");
            }

            _stocksRef.Remove(stockName);
        }

        public void RemoveStockShares(string stockName, int numberOfSharesToSubstract)
        {
            if (!IsStockInPortfolio(stockName))
            {
                throw new StockExchangeException("Can not remove stock from " +
                          "portfolio. This stock: " + stockName + "doesn't exist " +
                          "in portfolio. ");
            }

            var newNumberOfStockShares = _stocksRef[stockName] - 
                                          numberOfSharesToSubstract;

            if ( newNumberOfStockShares < 0 )
            {
               throw new StockExchangeException("Can not remove stock from " +
                         "portfolio. The stock: " + stockName + " doesn't have" +
                         " enough number of shares.");
            }
            if (newNumberOfStockShares == 0)
            {
                _stocksRef.Remove(stockName);
            }
            else
            {
                _stocksRef[stockName] = newNumberOfStockShares; 
            }
        }

        public bool IsStockInPortfolio(string stockName)
        {
            return _stocksRef.ContainsKey(stockName);
        }

        public int StockCount()
        {
            return _stocksRef.Count();
        }

        public string Id
        {
            get { return _id; }
        }

        public Dictionary<string, int> StocksReferences
        {
            get { return _stocksRef; }
        }
    }




    /**
     * Stock index value calculator interface. Stock index value can be calculated
     * based on the stocks the index holds. The calculated value is rounded onto 
     * three decimal points.
     */
    public abstract class IndexValueCalculator
    {
        public abstract decimal GetValue(HashSet<string> stocksReferencesFromContainer,
                                         Dictionary<string, Stock> stocksFromMarket, 
                                         DateTime timestamp );

        public decimal RoundValue(decimal value)
        {
            return decimal.Round(value, 3, MidpointRounding.AwayFromZero);
        }
    }





    /**
     * Stock index average value calculator class that implements stock index value 
     * calculator interface. Stock index value can be calculated based on the stocks 
     * the index holds. The value can be calculated based on the type of the stock 
     * index. This class calculates the stock index value for the average stock index.
     */
    public class AverageIndexValueCalculator : IndexValueCalculator
    {
        public override  decimal GetValue(HashSet<string> stocksRefFromIndex, 
                                          Dictionary<string, Stock> stocksFromMarket,
                                          DateTime timestamp)
        {
            var stockInIndexSum = stocksRefFromIndex.Sum( stockName => 
                                   stocksFromMarket[stockName].
                                   GetPrice(timestamp).Amount );

            var indexValue = stockInIndexSum / stocksRefFromIndex.Count();

            var indexValueRound = RoundValue(indexValue);

            return indexValueRound;
        }
    }




    /**
     * Stock index weighted value calculator class that implements stock index value
     * calculator interface. Stock index value can be calculated based on the stocks 
     * the index holds. The value can be calculated based on the type of the stock 
     * index. This class calculates the stock index value for the weighted stock index.
     */
    public class WeightedIndexValueCalculator : IndexValueCalculator
    {
        public override decimal GetValue(HashSet<string> stocksRefFromIndex, 
                                         Dictionary<string, Stock> stocksFromMarket,
                                         DateTime timestamp)
        {
            var sumOfStocksValuesInIndex = stocksRefFromIndex.Select(stockName => 
                                           stocksFromMarket[stockName]).
                                           Select(stock => 
                                           stock.GetPrice(timestamp).Amount * 
                                           stock.NumberOfShares).Sum();

            var indexValue = (from stockName in stocksRefFromIndex 
                              select stocksFromMarket[stockName] into stock 
                              let totalStockValue = stock.GetPrice(timestamp).Amount 
                                                    * stock.NumberOfShares 
                              let weight = totalStockValue / sumOfStocksValuesInIndex 
                              select weight * stock.GetPrice(timestamp).Amount).Sum();

            var indexValueRound = RoundValue(indexValue);

            return indexValueRound;
        }
    }




    /**
     * Portfolio value calculator class. Stock portfolio value can be calculated 
     * based on the stocks the portfolio holds. This class calculates the stock portfolio 
     * value and monthly change in portfolio value. The results are rounded onto three 
     * decimal points.
     */
    public class PortfolioValueCalculator
    {
        public decimal GetValue(Dictionary<string,int> stocksRefFromPortfolio, 
                                Dictionary<string, Stock> stocksFromMarket, 
                                DateTime timestamp)
        {
            var value = ( from stockPortfolio in stocksRefFromPortfolio 
                          let stock = stocksFromMarket[stockPortfolio.Key]
                          select stockPortfolio.Value * 
                                 stock.GetPrice(timestamp).Amount ).Sum();

            var valueRound = decimal.Round(value, 3, MidpointRounding.AwayFromZero);

            return valueRound;
        }

        public decimal GetPercentChangeInValueForMonth(
                                Dictionary<string, int> stocksRefFromPortfolio, 
                                Dictionary<string, Stock> stocksFromMarket, 
                                int year, int month)
        {
            var monthBegin = new DateTime(year, month, 1, 0, 0, 0, 0);
            var monthEnd = new DateTime(year, month, 1, 23, 59, 59, 999).
                                        AddMonths(1).AddDays(-1);

            var valueBegin = GetValue(stocksRefFromPortfolio, 
                                      stocksFromMarket, monthBegin);
            var valueEnd = GetValue(stocksRefFromPortfolio, 
                                    stocksFromMarket, monthEnd);

            var valueDifference = Math.Abs(valueEnd - valueBegin);

            var percentage = (valueDifference * 100) / valueBegin;

            var percentageRound = decimal.Round(percentage, 3, 
                                        MidpointRounding.AwayFromZero);

            return percentageRound; 
        }
    }
}
