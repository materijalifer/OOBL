﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class Stock
    {

        private string _stockName;
        private long _numberOfShares;

        List<DateTime> vrijeme = new List<DateTime>();
        List<decimal> cijena = new List<decimal>();

        public Stock(string ime, long brojDionica, Decimal pocetnaCijena, DateTime vrm)
        {
            this._stockName = ime;
            this._numberOfShares = brojDionica;
            this.vrijeme.Add(vrm);
            this.cijena.Add(pocetnaCijena);
        }

        public string getIme()
        {
            return this._stockName;
        }
        public void setIme(string ime)
        {
             this._stockName=ime;
        }
        public long getKolicina()
        {
            return this._numberOfShares;
        }
        public void setKolicina(long kolicina)
        {
            this._numberOfShares = kolicina;
        }

        public bool setStockPrice(DateTime ulVrm, decimal vrijednost) //postavlja vrijednost u određenom trenutku
        {
            if (this.vrijeme.Contains(ulVrm))
            {
                return false;
            }
            else
            {
                if (vrijednost > 0)
                {
                    this.vrijeme.Add(ulVrm);
                    this.cijena.Add(vrijednost);
                    sortirajListu(vrijeme, cijena);
                    return true;
                }
                else return false;
            }
        }

        public decimal getStockValue(DateTime vrijeme)
        {
            int i;
            for ( i = 0; i < this.vrijeme.Count; i++)
            {
                if (vrijeme == this.vrijeme[i])
                {
                    return this.cijena[i];
                }
                else if (vrijeme < this.vrijeme[i] && i == 0)
                {
                    throw new StockExchangeException("nema cijene za to vrijeme!");
                }
                else if (this.vrijeme[i] < vrijeme && i == this.vrijeme.Count-1)
                {
                    return this.cijena[i];
                }
                else if (this.vrijeme[i] > vrijeme)
                {
                    return this.cijena[i - 1];
                }
            }
            return this.cijena[i-1];
        }   //dohvaća u određenom trenutku vrijednost

        public decimal getFirstStockValue()  //početna cijena
        {
            return this.cijena[0];
        }

        public decimal getLastStockValue()  // zadnja cijena
        {
            return this.cijena[this.cijena.Count-1];
        }

        public void sortirajListu(List<DateTime> vrijeme, List<decimal> vrijednost)// sortiranje liste vrijeme i datum
        {

            DateTime a;
            decimal b;

            for (int i = 0; i < vrijeme.Count; i++)
            {
                for (int j = 0; j < vrijeme.Count; j++)
                {
                    if (vrijeme[i] < vrijeme[j])
                    {
                        a = vrijeme[i];
                        b = vrijednost[i];
                        vrijeme[i] = vrijeme[j];
                        vrijednost[i] = vrijednost[j];
                        vrijeme[j] = a;
                        vrijednost[j] = b;
                        
                    }
                }
            }
        }  

    }

    public class Index
    {
        private string _indeksIme;
        private IndexTypes _tipIndeksa;

        List<Stock> listaDionica = new List<Stock>();

        public Index (string imeIndeksa, IndexTypes tipInd)
        {
            this._indeksIme = imeIndeksa;
            this._tipIndeksa = tipInd;
        }


        public string getIme()
        {
            return this._indeksIme;
        }

        public void dodajDionicu (Stock dionica)
        {
            this.listaDionica.Add(dionica);
        }

        public bool provjeriPostojanjeDionice(Stock dionica)
        {
            if (this.listaDionica.Contains(dionica))
            {
                return true;
            }
            else return false;
        }

        public bool provjeriPostojanjeDioniceString(string imeDionice)
        {
            foreach (Stock a in listaDionica)
            {
                if (a.getIme() == imeDionice.ToUpper())
                {
                    return true;
                }
                
            }
            return false;
        }

        public void obrisiDionicu (Stock dionica)
        {
            this.listaDionica.Remove(dionica);
        }
        
        public int brojDionica()
        {
            return this.listaDionica.Count;
        }

        public List<Stock> dohvatiDionice()
        {
            return this.listaDionica;
        }

        public IndexTypes dohvatiIndeks()
        {
            return this._tipIndeksa;
        }
    }

    public class Portfolio
    {
        private string _idPortfolio;

        public Dictionary<String, int> dionice = new Dictionary<String, int>();

        public Portfolio (string imePorta)
        {
            this._idPortfolio = imePorta;
        }

        public string getIme()
        {
            return this._idPortfolio;
        }


        




    }



     public class StockExchange : IStockExchange
     {

         public List<Stock> dioniceNaBurzi = new List<Stock>();

         public List<Index> indeksi = new List<Index>();

         public List<Portfolio> portfelji = new List<Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp) // dodaje novu dionicu s početnom cijenom.
         {
             
             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("vec postoji");
             }
             else
             {
                 if (inInitialPrice > 0 && inNumberOfShares>0)
                 {
                     dioniceNaBurzi.Add(new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp));
                 }
                 else
                 {
                     throw new StockExchangeException("ne može imati negativnu cijenu/brojdionica!");
                 }
             }
             
         }

         public void obrisiSvugdje(Stock zaBrisanje)   //brišemo iz portfelja i indeksa
         {
             foreach (Index i in indeksi)
             {
                 if (i.provjeriPostojanjeDionice(zaBrisanje))
                 {
                     i.obrisiDionicu(zaBrisanje);
                 }
                 else
                 {

                 }
             }

             foreach (Portfolio p in portfelji)
             {
                 if (p.dionice.ContainsKey(zaBrisanje.getIme()))
                 {
                     p.dionice.Remove(zaBrisanje.getIme());
                 }
                 else
                 {

                 }
             }
         }

         public void DelistStock(string inStockName)  //briše dionicu sa burze
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock a in dioniceNaBurzi)
                 {
                     if (a.getIme() == inStockName.ToUpper())
                     {
                         dioniceNaBurzi.Remove(a);
                         obrisiSvugdje(a);
                         return;
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("nema te dionice!");
             }
         }

         public bool StockExists(string inStockName)  //provjerava postoji li dionica
         {
             
             foreach (Stock a in dioniceNaBurzi)
             {
                 if (a.getIme() == inStockName.ToUpper())
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfStocks()  //broj dionica
         {
             return dioniceNaBurzi.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)  //postavlja vrijednost u određenom trenutku
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock a in dioniceNaBurzi)
                 {
                     if (a.getIme() == inStockName.ToUpper())
                     {
                         if (inStockValue<=0)
                         {
                             throw new StockExchangeException("ne može biti negativna cijena!");
                         }
                         else if (!a.setStockPrice(inTimeStamp, inStockValue))
                         {
                             throw new StockExchangeException("već uneseno za taj trenutak!");
                         }
                         else return;
                     }
                     else 
                     { 

                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Nema te dionice!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)  //dohvati u određenom trenutku cijenu
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock a in dioniceNaBurzi)
                 {
                     if (a.getIme() == inStockName.ToUpper())
                     {
                         return a.getStockValue(inTimeStamp);
                     }
                     else
                     {

                     }
                 }
             }

             else
             {
                 throw new StockExchangeException("Nema te dionice!");
             }

             return -1;
         }

         public decimal GetInitialStockPrice(string inStockName)   // prva cijena
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock a in dioniceNaBurzi)
                 {
                     if (a.getIme() == inStockName.ToUpper())
                     {
                         return a.getFirstStockValue();
                     } 
                 }
             }
             else
             {
                 throw new StockExchangeException("Nema te dionice!");
             }
             return -1;
         }

         public decimal GetLastStockPrice(string inStockName )  // zadnja cijena
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock a in dioniceNaBurzi)
                 {
                     if (a.getIme() == inStockName.ToUpper())
                     {
                         return a.getLastStockValue();
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Nema te dionice!");
             }
             return -1;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)  //stvaranje novog indeksa
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("indeks već postoji!");
             }

             else if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("nepostojeći tip indeksa!");
             }

             else
             {
                 indeksi.Add(new Index(inIndexName.ToUpper(), inIndexType));
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)  //dodavanje dionice u indeks!
         {
             if (IndexExists(inIndexName))
             {

                 if (StockExists(inStockName))
                 {
                                          
                     foreach (Stock a in dioniceNaBurzi)
                     {
                         if (a.getIme() == inStockName.ToUpper())
                         {
                             foreach (Index b in indeksi)
                             {
                                 if (b.getIme() == inIndexName.ToUpper())
                                 {
                                     if (!b.provjeriPostojanjeDionice(a))
                                     {
                                         b.dodajDionicu(a);
                                         return;
                                     }
                                     else
                                     {
                                         throw new StockExchangeException("u indeksu već postoji dionica istog imena!");
                                     }
                                 }
                             }
                         }
                     }
                     throw new StockExchangeException("dogodila se greška!");
                 }
                 else
                 {
                     throw new StockExchangeException("ne postoji dionica!");
                 }
             }

             else
             {
                 throw new StockExchangeException("ne postoji indeks!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName))
             {

                 if (StockExists(inStockName))
                 {
                     if (!IsStockPartOfIndex(inIndexName, inStockName))
                     {
                         throw new StockExchangeException("nije dio indeksa!");
                     }
                     foreach (Stock a in dioniceNaBurzi)
                     {
                         if (a.getIme() == inStockName.ToUpper())
                         {
                             foreach (Index b in indeksi)
                             {
                                 if (b.getIme() == inIndexName.ToUpper())
                                 {
                                     if (b.provjeriPostojanjeDionice(a))
                                     {
                                         b.obrisiDionicu(a);
                                         return;
                                     }
                                     else
                                     {
                                         throw new StockExchangeException("dionica ne postoji u indeksu!!");
                                     }
                                 }
                                 
                             }
                         }
   
                     }
                     throw new StockExchangeException("dogodila se greška!");
                 }
                 else
                 {
                     throw new StockExchangeException("ne postoji dionica!");
                 }
             }

             else
             {
                 throw new StockExchangeException("ne postoji indeks!");
             }
         }   //brisanje stocka iz indeksa

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)  // je li dio indeksa?
         {
             if (IndexExists(inIndexName))
             {

                 if (StockExists(inStockName))
                 {
                     foreach (Index a in indeksi)
                     {
                         if (a.getIme() == inIndexName.ToUpper())
                         {
                             if (a.provjeriPostojanjeDioniceString(inStockName))
                             {
                                 return true;
                             }
                             else return false;
                         }
                        
                     }
                     
                     
                 }
                 else
                 {
                     return false;
                 }
             }

             else
             {
                 throw new StockExchangeException("ne postoji indeks!");
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 foreach (Index a in indeksi)
                 {
                     if (a.getIme() == inIndexName.ToUpper())
                     {
                         List<Stock> pomocna = new List<Stock>();
                         pomocna = a.dohvatiDionice();

                         if (a.dohvatiIndeks() == IndexTypes.AVERAGE)
                         {
                             decimal suma=0, brojDion=0;
                             foreach (Stock b in pomocna)
                             {
                                 suma += b.getStockValue(inTimeStamp)*b.getKolicina();
                             }
                             foreach(Stock b in pomocna)
                             {
                                 brojDion += b.getKolicina();
                             }
                             return Math.Round(suma / brojDion, 3);
                         }
                         else if (a.dohvatiIndeks() == IndexTypes.WEIGHTED)
                         {
                             decimal suma = 0, izlaz = 0;
                             foreach (Stock b in pomocna)
                             {
                                 suma += b.getStockValue(inTimeStamp) * b.getKolicina();
                             }
                             foreach (Stock b in pomocna)
                             {
                                 izlaz += ((b.getStockValue(inTimeStamp) * b.getStockValue(inTimeStamp)) / suma) * b.getKolicina();
                             }
                             return Math.Round(izlaz, 3);
                         }
                         else
                         {
                             throw new StockExchangeException("desila se greška!");
                         }
                     }
                     else
                     {
                         
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("ne postoji indeks!");
             }
             return -1;
         }

         public bool IndexExists(string inIndexName)   //provjeravamo ima li indeksa (true ako ima, false ako nema)
         {
             foreach (Index a in indeksi)
             {
                 if (a.getIme() == inIndexName.ToUpper())
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfIndices() // broj indeksa
         {
             return this.indeksi.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName) //broj u indeksu stockova
         {
             if (IndexExists(inIndexName))
             {
                 foreach (Index a in indeksi)
                 {
                     if (a.getIme() == inIndexName.ToUpper())
                     {
                         return a.brojDionica();
                     }
                     else
                     {
                         
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("ne postoji indeks!");
             }
             return 0;
         }

         public void CreatePortfolio(string inPortfolioID) //kreiranje portfelja!
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("već postoji portfelj s tim IDom!");
             }
             else
             {
                 portfelji.Add(new Portfolio(inPortfolioID));
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 if (StockExists(inStockName))
                 {
                     if (numberOfShares <= 0)
                     {
                         throw new StockExchangeException("broj dionica ne može biti 0 ili negativan!");
                     }
                     
                     long brojUdjela=0, brojUdjeljenih=0;
                     foreach (Stock a in dioniceNaBurzi)
                     {
                         if (a.getIme() == inStockName.ToUpper())
                         {
                             brojUdjela = a.getKolicina();
                             break;
                         }
                     }
                     foreach (Portfolio b in portfelji)
                     {
                         if (IsStockPartOfPortfolio(b.getIme(), inStockName))
                         {
                             brojUdjeljenih += b.dionice[inStockName];
                         }
                     }
                     if (numberOfShares < (brojUdjela - brojUdjeljenih))
                     {
                         foreach (Portfolio b in portfelji)
                         {
                             if (b.getIme() == inPortfolioID)
                             {
                                 if (IsStockPartOfPortfolio(b.getIme(),inStockName))
                                 {
                                     b.dionice[inStockName] += numberOfShares;
                                     return;
                                 }
                                 else
                                 {
                                     b.dionice.Add(inStockName, numberOfShares);
                                     return;
                                 }
                                 
                             }
                         }
                     
                     }
                     
                     else
                     {
                         throw new StockExchangeException("ne može biti više udijeljenih nego postoji!");
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("ne postoji ta dionica!");
                 }
             }
             else
             {
                 throw new StockExchangeException("ne postoji portfelj s tim imenom!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)  //brisanje određenog dijela stockova
         {
             if (PortfolioExists(inPortfolioID))
             {
                 if (StockExists(inStockName))
                 {
                     foreach (Portfolio p in portfelji)
                     {
                         if (p.getIme() == inPortfolioID)
                         {
                             if (p.dionice.ContainsKey(inStockName))
                             {
                                 if (p.dionice[inStockName] < numberOfShares)
                                 {
                                     throw new StockExchangeException("ne možete obrisati više nego što ima!");
                                 }
                                 else if (p.dionice[inStockName] == numberOfShares)
                                 {
                                     p.dionice.Remove(inStockName);
                                     return;
                                 }
                                 else
                                 {
                                     p.dionice[inStockName] -= numberOfShares;
                                     return;
                                 }
                             }
                             else throw new StockExchangeException("ne sadrži ovaj stock!");
                         }
                     }
                 }
                 else throw new StockExchangeException("ne postoji stock!");
             }
             else throw new StockExchangeException("ne postoji portfelj!");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName) //brisanje  stocka iz portfelja
         {
             if (PortfolioExists(inPortfolioID))
             {
                 if (StockExists(inStockName))
                 {
                     foreach (Portfolio p in portfelji)
                     {
                         if (p.getIme() == inPortfolioID)
                         {
                             if (p.dionice.ContainsKey(inStockName))
                             {
                                 p.dionice.Remove(inStockName);
                                 return;
                             }
                             else throw new StockExchangeException("ne sadrži ovaj stock!");
                         }
                     }
                 }
                 else throw new StockExchangeException("ne postoji stock!");
             }
             else throw new StockExchangeException("ne postoji portfelj!");
         }

         public int NumberOfPortfolios() //broj portfelja
         {
             return this.portfelji.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)  //broj stockova u portfoliu
         {
        
             if (PortfolioExists(inPortfolioID))
             {

                 foreach (Portfolio p in portfelji)
                 {
                     if (p.getIme() == inPortfolioID)
                     {

                         return p.dionice.Count;
                     }
                     
                 }
                 throw new StockExchangeException("došlo je do greške!");
             }
             else throw new StockExchangeException("ne postoji portfelj!");
         }

         public bool PortfolioExists(string inPortfolioID)  //postojanje portfelja! (true postoji, false ne postoji!)
         {
             foreach (Portfolio a in portfelji)
             {
                 if (a.getIme() == inPortfolioID)
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName) //vraća postoji li stock u portfoliu
         {
             if (PortfolioExists(inPortfolioID))
             {
                 if (StockExists(inStockName))
                 {
                     foreach (Portfolio p in portfelji)
                     {
                         if (p.getIme() == inPortfolioID)
                         {
                             if (p.dionice.ContainsKey(inStockName))
                             {
                                 return true;
                             }
                             else return false;
                         }
                     }
                     throw new StockExchangeException("nepoznata greska!");
                 }
                 else
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("ne postoji portfelj!");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName) // broj udjela
         {
             if (PortfolioExists(inPortfolioID))
             {
                 if (StockExists(inStockName))
                 {
                     foreach (Portfolio p in portfelji)
                     {
                         if (p.getIme() == inPortfolioID)
                         {
                             if (p.dionice.ContainsKey(inStockName))
                             {
                                 return p.dionice[inStockName];
                             }
                             else throw new StockExchangeException("nema tog stocka u portfelju!");
                         }
                     }
                     throw new StockExchangeException("greska");
                 }
                 else throw new StockExchangeException("ne postoji takav stock!");
             }
             else throw new StockExchangeException("ne postoji portfelj!");
         }  

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp) //izračun portfolio vrijednosti!
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio p in portfelji)
                 {
                     if (p.getIme() == inPortfolioID)
                     {
                         decimal suma = 0;
                         foreach (string d in p.dionice.Keys)
                         {
                             suma += p.dionice[d] * GetStockPrice(d, timeStamp);
                         }
                         return Math.Round(suma, 3);
                     }
                 }
                 throw new StockExchangeException("došlo do greške!");
             }
             else throw new StockExchangeException("ne psotoji!");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month) //mjesečnica
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio p in portfelji)
                 {
                     if (p.getIme() == inPortfolioID)
                     {
                         decimal postotak = 0, sumaPocetakMj = 0, sumaKrajMj = 0;
                         foreach (string d in p.dionice.Keys)
                         {
                             sumaPocetakMj += p.dionice[d] * GetStockPrice(d, new DateTime(Year, Month, 1, 0, 0, 0));
                             sumaKrajMj += p.dionice[d] * GetStockPrice(d, new DateTime(Year, Month, 30, 23, 59, 59));
                         }
                         postotak = ((sumaPocetakMj - sumaKrajMj) / sumaPocetakMj )* 100;
                         return Math.Round(postotak, 3);
                     }
                   
                 }
                
                 throw new StockExchangeException("greska!");
             }

             else throw new StockExchangeException("ne postoji portfelj!");
         }
     }

    
}
