﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> _listStock = new List<Stock>();
         List<Index> _listIndex = new List<Index>();
         List<Portfolio> _listPortfolio = new List<Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice < 0)
             {
                 throw new StockExchangeException("greska");
                 return;
             }
             foreach (Stock stock in _listStock)
             {
                 bool result = inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase);
                 if (result == true)
                 {
                     throw new StockExchangeException("greska");
                     return;
                 }
             }
             Stock _stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             _listStock.Add(_stock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("greska");
             }
             foreach (Stock stock in _listStock)
             {
                 if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                 {

                     foreach (Index index in _listIndex)
                     {
                         if (IsStockPartOfIndex(index.GetIndexName(), inStockName))
                         {
                             index.RemoveStock(inStockName);
                         }
                     }

                     foreach (Portfolio portfolio in _listPortfolio)
                     {
                         if (IsStockPartOfPortfolio(portfolio.GetPortfolioID(), stock.GetStockName()))
                         {
                             int sharesNumber = portfolio.GetStockSharesNumber(inStockName);
                             stock.SetNumberOfFreeStocks(-sharesNumber);
                             portfolio.RemoveStock(inStockName);
                         }
                     }
                     _listStock.Remove(stock);
                     return;
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock stock in _listStock)
             {
                 bool result = inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase);
                 if (result == true)
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             int _numberOfStocks = 0;
             _numberOfStocks = _listStock.Count();
             return _numberOfStocks;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             foreach (Stock stock in _listStock)
             {
                 if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                 {
                     stock.SetStockPrice(inStockValue);
                     stock.AddHistory(inStockName, inStockValue, inIimeStamp);
                 }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             int br = 0;
             if (StockExists(inStockName))
             {
                 foreach (Stock stock in _listStock)
                 {
                     if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                     {
                         List<StockHistory> tempList = stock.GetStockHistory();
                         if (tempList.First().GetDateTime() > inTimeStamp)
                         {
                             throw new StockExchangeException("greska");
                             return 0;
                         }
                         foreach (StockHistory stockHistory in tempList)
                         {
                             if (inTimeStamp == stockHistory.GetDateTime())
                             {
                                 return Math.Round(stockHistory.GetPrice(), 3);
                             }

                             if (stockHistory.GetDateTime() > inTimeStamp)
                             {
                                 return Math.Round(tempList[br - 1].GetPrice(), 3);
                             }

                             br++;
                         }
                         return Math.Round(tempList[br - 1].GetPrice(), 3);
                     }
                 }
             }
             throw new StockExchangeException("greska");
             return 0;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock stock in _listStock)
                 {
                     if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                     {
                         return Math.Round(stock.GetFirstStockPrice(), 3);
                     }
                 }
             }
             throw new StockExchangeException("greska");
             return 0;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock stock in _listStock)
                 {
                     if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                     {
                         return Math.Round(stock.GetLastStockPrice(),3);
                     }
                 }
             }
             throw new StockExchangeException("greska");
             return 0;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if ((inIndexType != IndexTypes.AVERAGE) && (inIndexType != IndexTypes.WEIGHTED))
             {
                 throw new StockExchangeException("greska");
                 return;
             }
             foreach (Index index1 in _listIndex)
             {
                 if (inIndexName.Equals(index1.GetIndexName(), StringComparison.OrdinalIgnoreCase) == true)
                 {
                     throw new StockExchangeException("greska");
                     return;
                 }
             }
             Index index = new Index(inIndexName, inIndexType);
             _listIndex.Add(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName))
             {
                 Index index = _listIndex.FirstOrDefault(o => o.GetIndexName().ToLower() == inIndexName.ToLower());
                 if (IsStockPartOfIndex(inIndexName, inStockName))
                 {
                     throw new StockExchangeException("greska");
                     return;
                 }
                 Stock stock = _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == inStockName.ToLower());
                 index.AddStockToIndex(stock);
                 return;
             }
             throw new StockExchangeException("greska");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 Index index = _listIndex.FirstOrDefault(o => o.GetIndexName().ToLower() == inIndexName.ToLower());
                 index.RemoveStock(inStockName);
                 return;
             }
             throw new StockExchangeException("greska");
             return;
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = _listIndex.FirstOrDefault(o => o.GetIndexName().ToLower() == inIndexName.ToLower());
             foreach (Stock stock in index.GetStockListInIndex())
             {
                 if (inStockName.Equals(stock.GetStockName(), StringComparison.OrdinalIgnoreCase) == true)
                 {
                     return true;
                 }
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 decimal value = 0;
                 decimal weight = 0;
                 List<Stock> list = new List<Stock>();
                 Index index = _listIndex.FirstOrDefault(o => o.GetIndexName().ToLower() == inIndexName.ToLower());
                 list = index.GetStockListInIndex();
                 if (list.Count == 0)
                 {
                     return 0;
                 }
                 switch (index.GetIndexType())
                 {
                     case IndexTypes.AVERAGE:
                         foreach (Stock stock in list)
                         {
                             value = value + GetStockPrice(stock.GetStockName(), inTimeStamp);
                         }
                         value = value / NumberOfStocksInIndex(inIndexName);
                         return Math.Round(value, 3);
                         break;
                     case IndexTypes.WEIGHTED:
                         foreach (Stock stock in list)
                         {
                             weight = weight + (GetStockPrice(stock.GetStockName(), inTimeStamp) * stock.GetNumberOfStocks());
                         }
                         foreach (Stock stock in list)
                         {
                             value = value +
                                     ((GetStockPrice(stock.GetStockName(), inTimeStamp))*
                                      (GetStockPrice(stock.GetStockName(), inTimeStamp)/weight)*
                                      (stock.GetNumberOfStocks()));
                         }
                         return Math.Round(value, 3);
                 }
             }
             throw new StockExchangeException("greska");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index index in _listIndex)
             {
                 if (inIndexName.Equals(index.GetIndexName(), StringComparison.OrdinalIgnoreCase) == true)
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return _listIndex.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 Index index = _listIndex.FirstOrDefault(o => o.GetIndexName().ToLower() == inIndexName.ToLower());
                 List<Stock> stockList = index.GetStockListInIndex();
                 return stockList.Count;
             }
             throw new StockExchangeException("greska");
             return 0;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 _listPortfolio.Add(portfolio);
                 return;
             }
             throw new StockExchangeException("greska");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("greska");
             }
             if ((StockExists(inStockName)) && (PortfolioExists(inPortfolioID)))
             {
                 Stock stock = _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == inStockName.ToLower());
                 if (stock.GetNumberOfFreeStocks() < numberOfShares)
                 {
                     throw new StockExchangeException("greska");
                 }
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 portfolio.AddStockToPortfolio(stock, numberOfShares);
                 stock.SetNumberOfFreeStocks(numberOfShares);
                 return;

             }
             throw new StockExchangeException("greska");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares < 0)
             {
                 throw new StockExchangeException("greska");
             }
             if ((PortfolioExists(inPortfolioID)) && (IsStockPartOfPortfolio(inPortfolioID, inStockName)))
             {
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 Stock stock = _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == inStockName.ToLower());
                 if (portfolio.GetStockSharesNumber(inStockName) < numberOfShares)
                 {
                     throw new StockExchangeException("greska");
                 }
                 portfolio.SetStockSharesNumber(inStockName, -numberOfShares);
                 if (portfolio.GetStockSharesNumber(inStockName) == 0)
                 {
                     portfolio.RemoveStock(inStockName);
                 }
                 return;
             }
             throw new StockExchangeException("greska");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if ((PortfolioExists(inPortfolioID)) && (IsStockPartOfPortfolio(inPortfolioID, inStockName)))
             {
                 int temp;
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 temp = portfolio.GetStockSharesNumber(inStockName);
                 Stock stock = _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == inStockName.ToLower());
                 stock.SetNumberOfFreeStocks(-temp);
                 portfolio.RemoveStock(inStockName);
                 return;
             }
             throw new StockExchangeException("greska");
         }

         public int NumberOfPortfolios()
         {
             return _listPortfolio.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 return portfolio.CountHashTable();
             }
             throw new StockExchangeException("greska");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio portfolio in _listPortfolio)
             {
                 if (portfolio.GetPortfolioID().Equals(inPortfolioID, StringComparison.Ordinal))
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if ((PortfolioExists(inPortfolioID)) && (StockExists(inStockName)))
             {
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 return portfolio.CheckForStock(inStockName);
             }
             throw new StockExchangeException("greska");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if ((PortfolioExists(inPortfolioID)) && (IsStockPartOfPortfolio(inPortfolioID, inStockName)))
             {
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 return portfolio.GetStockSharesNumber(inStockName);
             }
             throw new StockExchangeException("greska");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Hashtable hashtable;
             decimal sumValue = 0;
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 hashtable = portfolio.GetHashtable();
                 foreach (DictionaryEntry dictionaryEntry in hashtable)
                 {
                     Stock stock = _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == dictionaryEntry.Key.ToString());
                     sumValue += GetStockPrice(stock.GetStockName(), timeStamp) * Convert.ToInt32(dictionaryEntry.Value);
                 }
                 return Math.Round(sumValue, 3);
             }
             throw new StockExchangeException("greska");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Hashtable hashtable;
                 Portfolio portfolio = _listPortfolio.FirstOrDefault(o => o.GetPortfolioID() == inPortfolioID);
                 DateTime firstDay;
                 DateTime lastDay;
                 Date temp = new Date();
                 decimal value = 0;

                 if (portfolio.CountHashTable() == 0)
                 {
                     throw new StockExchangeException("greska");
                 }

                 firstDay = temp.SetFirstDayOfMonth(Year, Month);
                 lastDay = temp.SetLastDayOfMonth(Year, Month);
                 hashtable = portfolio.GetHashtable();
                 foreach (DictionaryEntry dictionaryEntry in hashtable)
                 {
                     List<StockHistory> history;
                     Stock stock =
                         _listStock.FirstOrDefault(o => o.GetStockName().ToLower() == dictionaryEntry.Key.ToString());
                     history = stock.GetStockHistory();
                     if (firstDay < history.First().GetDateTime())
                     {
                         throw new StockExchangeException("greska");
                     }
                 }
                 return Math.Round(((((GetPortfolioValue(inPortfolioID, lastDay)) - (GetPortfolioValue(inPortfolioID, firstDay))) /
                          GetPortfolioValue(inPortfolioID, firstDay)) * 100), 3);

             }
             throw new StockExchangeException("greska");
         }
     }

     public class Stock
     {
         private string _stockName;
         private long _numberOfStocks;
         private decimal _price;
         private DateTime _dateTime;
         private List<StockHistory> _history;
         private long _numberOfFreeStocks;

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             this._stockName = inStockName;
             this._numberOfStocks = inNumberOfShares;
             this._numberOfFreeStocks = inNumberOfShares;
             this._price = inInitialPrice;
             this._dateTime = inTimeStamp;
             StockHistory history = new StockHistory(inStockName, inInitialPrice, inTimeStamp);
             this._history = new List<StockHistory>();
             _history.Add(history);
             _history.Sort();
         }

         public long GetNumberOfStocks()
         {
             return this._numberOfStocks;
         }

         public void SetNumberOfFreeStocks(long numberOfShares)
         {
             this._numberOfFreeStocks = this._numberOfFreeStocks - numberOfShares;
             return;
         }

         public long GetNumberOfFreeStocks()
         {
             return this._numberOfFreeStocks;
         }

         public string GetStockName()
         {
             return this._stockName;
         }

         public void SetStockPrice(decimal inPrice)
         {
             this._price = inPrice;
         }

         public void AddHistory(string inStockName, decimal inInitialPrice, DateTime inTimeStamp)
         {
             StockHistory history = new StockHistory(inStockName, inInitialPrice, inTimeStamp);
             this._history.Add(history);
         }

         public decimal GetFirstStockPrice()
         {
             return this._history.First().GetPrice();
         }

         public decimal GetLastStockPrice()
         {
             return this._history.Last().GetPrice();
         }

         public List<StockHistory> GetStockHistory()
         {
             return this._history;
         }
     }

     public class StockHistory
     {
         private string _stockName;
         private decimal _price;
         private DateTime _dateTime;

         public StockHistory(string inStockName, decimal inInitialPrice, DateTime inTimeStamp)
         {
             this._stockName = inStockName;
             this._price = inInitialPrice;
             this._dateTime = inTimeStamp;
         }

         public decimal GetPrice()
         {
             return this._price;
         }

         public DateTime GetDateTime()
         {
             return this._dateTime;
         }
     }

     public class Index
     {
         private string _indexName;
         IndexTypes _indexType;
         private List<Stock> _stockList;

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             this._indexName = inIndexName;
             this._indexType = inIndexType;
             this._stockList = new List<Stock>();
         }

         public string GetIndexName()
         {
             return this._indexName;
         }

         public IndexTypes GetIndexType()
         {
             return this._indexType;
         }

         public List<Stock> GetStockListInIndex()
         {
             return this._stockList;
         }

         public void AddStockToIndex(Stock stock)
         {
             this._stockList.Add(stock);
         }

         public void RemoveStock(string inStockName)
         {
             _stockList.RemoveAll(o => o.GetStockName() == inStockName);
         }

     }

     public class Portfolio
     {
         private string _ID;
         private Hashtable _hashTable;

         public Portfolio(string ID)
         {
             this._ID = ID;
             this._hashTable = new Hashtable();
         }

         public void AddStockToPortfolio(Stock stock, int numberOfStocks)
         {
             int temp;
             if (_hashTable.ContainsKey(stock.GetStockName().ToLower()))
             {
                 temp = Convert.ToInt32(_hashTable[stock.GetStockName().ToLower()]) + numberOfStocks;
                 if (numberOfStocks <= stock.GetNumberOfFreeStocks())
                 {
                     _hashTable[stock.GetStockName().ToLower()] = Convert.ToInt32(_hashTable[stock.GetStockName().ToLower()]) + numberOfStocks;
                     return;
                 }
                 else throw new StockExchangeException("greska");
             }
             _hashTable.Add(stock.GetStockName().ToLower(), numberOfStocks);
         }

         public Hashtable GetHashtable()
         {
             return this._hashTable;
         }

         public void SetStockSharesNumber(string inStockName, int numberOfStocks)
         {
             _hashTable[inStockName.ToLower()] = Convert.ToInt32(_hashTable[inStockName.ToLower()]) + numberOfStocks;
             return;
         }

         public string GetPortfolioID()
         {
             return this._ID;
         }

         public int GetStockSharesNumber(string inStockName)
         {
             return Convert.ToInt32(_hashTable[inStockName.ToLower()]);
         }

         public int CountHashTable()
         {
             return this._hashTable.Count;
         }

         public bool CheckForStock(string inStockName)
         {
             return _hashTable.ContainsKey(inStockName.ToLower());
         }

         public void RemoveStock(string inStockName)
         {
             if (_hashTable.Contains(inStockName.ToLower()))
             {
                 _hashTable.Remove(inStockName.ToLower());
             }
         }
     }

     public class Date
     {
         public DateTime SetFirstDayOfMonth(int year, int month)
         {
             return new DateTime(year, month, 1, 0, 0, 0);
         }

         public DateTime SetLastDayOfMonth(int year, int month)
         {
             DateTime firstDayOfTheMonth = new DateTime(year, month, 1, 23, 59, 59, 999);
             return firstDayOfTheMonth.AddMonths(1).AddDays(-1);
         }
     }
}
