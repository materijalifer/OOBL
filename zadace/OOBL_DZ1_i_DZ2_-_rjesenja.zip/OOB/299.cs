﻿using System;
using System.Collections.Generic;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private  Indices marketIndices = new Indices();
        private  Portfolios marketPortfolios = new Portfolios();
        private  Stocks marketStocks = new Stocks();

        //***STOCKS***//
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            //stock name is the primary key, price and number cant be under 1
            if (StockExists((inStockName)) || inInitialPrice <= 0 || inNumberOfShares <= 0)
            {
                throw new StockExchangeException(
                    "Illegal stock entry, check if stock allready exists, or if initial price or number of shares are less than 1.");
            }

            Stock newStock = new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
            newStock.LastStockValue = inInitialPrice;
            marketStocks.StockList.Add(newStock);
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName) && marketStocks.StockList.Count > 0)
            {
                Stock removedStock = marketStocks.GetStock(inStockName); 
                foreach (Index index in marketIndices.IndexList)
                {
                    if (IsStockPartOfIndex(index.IndexName, removedStock.StockName))
                        RemoveStockFromIndex(index.IndexName,removedStock.StockName);
                }
                foreach (Portfolio portfolio in marketPortfolios.PortfolioList)
                {
                    if (IsStockPartOfPortfolio(portfolio.ID, removedStock.StockName))
                        RemoveStockFromPortfolio(portfolio.ID,removedStock.StockName);
                }

                marketStocks.StockList.Remove(removedStock);
            }
            else
                throw new StockExchangeException("Stock doesn't exist.");
        }

        public bool StockExists(string inStockName)
        {
            int index = marketStocks.GetStockIndex(inStockName);
            if (index == -1)
                return false;

            return true;
        }

        public int NumberOfStocks()
        {
            return marketStocks.StockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if(!StockExists(inStockName))
                throw new StockExchangeException("Stock does not exist.");

            Stock priceStock = marketStocks.GetStock(inStockName);
            if(priceStock.StockValues.ContainsKey(inIimeStamp))
                throw new StockExchangeException("Stock price for given time allready exists.");

            priceStock.StockValues[inIimeStamp] = inStockValue;
            //adjust initial price or last price if such dates are entered
            DateTime oldest = priceStock.GetDate(inIimeStamp);
            DateTime newest = priceStock.GetDate(inIimeStamp);
            foreach (DateTime key in priceStock.StockValues.Keys)
            {
                if (key < oldest)
                    oldest = key;
                if (key > newest)
                    newest = key;
                }            
                priceStock.LastStockValue = priceStock.StockValues[newest];
                priceStock.InitialPrice = priceStock.StockValues[oldest];
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock does not exist, unable to return initial price.");

            Stock  priceStock = marketStocks.GetStock(inStockName);
            DateTime oldest = inTimeStamp;
            foreach (DateTime key in priceStock.StockValues.Keys)
            {
                if (key < oldest)
                    oldest = key;
            }
            if(oldest == inTimeStamp)
                throw new StockExchangeException("Stock price isn't define before it's initial price.");

            DateTime priceTime = priceStock.GetDate(inTimeStamp);         
            return priceStock.StockValues[priceTime];
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                Stock priceStock = marketStocks.GetStock(inStockName);
                return priceStock.InitialPrice;
            }

            throw new StockExchangeException("Stock does not exist, unable to return initial price.");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
           if(!StockExists(inStockName))
               throw new StockExchangeException("Stock does not exist, unable to return initial price.");
           Stock priceStock = marketStocks.GetStock(inStockName);
           return priceStock.LastStockValue;
        }



        //***INDICES***//
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
                throw new StockExchangeException("Can't create index, selected index name allready exists.");

            if(inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Can't create index, invalid index type specified.");

            Index newIndex = new Index(inIndexName.ToUpper(), inIndexType);
            marketIndices.IndexList.Add(newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
                throw new StockExchangeException("Either index or stock don't exist. Can't add stock to index.");
            Stock addedStock = marketStocks.GetStock(inStockName);
            Index addingIndex = marketIndices.GetIndex(inIndexName);
            addingIndex.IndexStocks.Add(addedStock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !IsStockPartOfIndex(inIndexName,inStockName))
            {
                throw new StockExchangeException("Couldn't remove stock from index, either stock or index don't exist.");
            }

            Index removingIndex = marketIndices.GetIndex(inIndexName);
            Stock removedStock = removingIndex.IndexStocks.Find(stock => stock.StockName.Equals(inStockName.ToUpper()));
            removingIndex.IndexStocks.Remove(removedStock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
            {
                return false;
            }

            Stock stockExists = marketStocks.GetStock(inStockName);
            Index partOfIndex = marketIndices.GetIndex(inIndexName);
            if (!partOfIndex.IndexStocks.Contains(stockExists))
            {
                return false;
            }
            return true;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if(!IndexExists(inIndexName))
                throw new StockExchangeException("Index does not exist, can't get value.");
            Index valueIndex = marketIndices.GetIndex(inIndexName);
            valueIndex.SetIndexValue(inTimeStamp);
            return valueIndex.IndexValue;
        }

        public bool IndexExists(string inIndexName)
        {
            int indexPosition = marketIndices.GetIndexPosition(inIndexName);
            if (indexPosition == -1)
                return false;

            return true;
        }

        public int NumberOfIndices()
        {
            return marketIndices.IndexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if(!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist, can't return number of stocks.");
            Index stocksNumberIndex = marketIndices.GetIndex(inIndexName);
            return stocksNumberIndex.IndexStocks.Count;
        }



        //***PORTFOLIOS***//
        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Can't create portfolio, given ID allready exists.");

            Portfolio portfolio = new Portfolio(inPortfolioID);
            marketPortfolios.PortfolioList.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if(!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Either portfolio or stock don't exist. Can't add stock to portfolio.");

            if(numberOfShares <= 0)
                throw  new StockExchangeException("Number of shares added must be larger than 0.");

            Portfolio addingPortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            long totalNumberOfShares = 0;

            //check if total sum of portfolio shares would exceed the existing number on the market
            foreach (Portfolio portfolio in marketPortfolios.PortfolioList)
            {
                if (IsStockPartOfPortfolio(portfolio.ID, inStockName))
                {
                    Stock sharesStock = portfolio.PStocks.GetStock(inStockName);
                    totalNumberOfShares += sharesStock.NumberOfShares;
                }
            }
            if (totalNumberOfShares + numberOfShares > marketStocks.GetStock(inStockName).NumberOfShares)
                throw new StockExchangeException("Number of shares in portfolio can't exceed the total number of shares on the whole market.");

            Stock addingStock;
            //if stock exists in portfolio change number of shares, else add stock to portfolio
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                addingStock = addingPortfolio.PStocks.GetStock(inStockName);
                addingStock.NumberOfShares += numberOfShares;
            }

            //else add the stock to the portfolio
            else
            {            
                addingStock = marketStocks.GetStock(inStockName);
                if(numberOfShares > addingStock.NumberOfShares)
                    throw new StockExchangeException("Can't add larger than existing number of shares to portfolio.");

                Stock newPStock = new Stock();
                newPStock.Copy(addingStock);
                newPStock.NumberOfShares = numberOfShares;
                addingPortfolio.PStocks.StockList.Add(newPStock);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || !IsStockPartOfPortfolio(inPortfolioID, inStockName))
                throw new StockExchangeException("Can't remove stock share from portfolio, either stock or portfolio don't exist.");

            Portfolio removingPortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            Stock removingStock = removingPortfolio.PStocks.GetStock(inStockName);
            removingStock.NumberOfShares -= numberOfShares;
            //if share number <= 0, remove stock from portfolio
            if (removingStock.NumberOfShares <= 0)
                RemoveStockFromPortfolio(inPortfolioID, inStockName);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID) || !IsStockPartOfPortfolio(inPortfolioID, inStockName))
                throw new StockExchangeException(
                    "Can't remove stock from portfolio, either stock or portfolio don't exist.");

            Portfolio removingPortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            Stock removingStock = removingPortfolio.PStocks.GetStock(inStockName);
            removingPortfolio.PStocks.StockList.Remove(removingStock);
        }

        public int NumberOfPortfolios()
        {
            return marketPortfolios.PortfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int index = marketPortfolios.GetPortfolioPosition(inPortfolioID);
            if (index == -1)
                throw new StockExchangeException("Portfolio does not exist.");
            return marketPortfolios.PortfolioList[index].PStocks.StockList.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            int portfolioPosition = marketPortfolios.GetPortfolioPosition(inPortfolioID);
            if (portfolioPosition == -1)
                return false;

            return true;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if(!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Potrfolio does not exist.");

            Portfolio partOfPortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            Stock existingStock = marketStocks.GetStock(inStockName);
            if (partOfPortfolio.PStocks.GetStockIndex(inStockName) != -1)
                return true;

            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Potrfolio does not exist.");

            if(!IsStockPartOfPortfolio(inPortfolioID,inStockName))
                throw  new StockExchangeException("No such stock in portfolio.");
            Portfolio sharesPortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            Stock sharesStock = sharesPortfolio.PStocks.GetStock(inStockName);
            return (int) sharesStock.NumberOfShares;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Potrfolio does not exist.");

            Portfolio valuePortfolio = marketPortfolios.GetPortfolio(inPortfolioID);
            //throws exception in the method SetPortfolioValue if the price isn't defined
            valuePortfolio.SetPortfolioValue(timeStamp);
            return valuePortfolio.PortfolioValue;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Potrfolio does not exist.");
            if(Year <= 0 || Month < 1 || Month > 12)
                throw new StockExchangeException("Incorrect year/month input.");

            Portfolio monthlyPortfolio = new Portfolio(inPortfolioID);
            monthlyPortfolio = marketPortfolios.GetPortfolio(inPortfolioID).Copy();
            if (monthlyPortfolio.PStocks.StockList.Count == 0)
                return 0;       
            DateTime percentTimeStart = new DateTime(Year,Month,1,0,0,0,0);
            int daysInMonth = DateTime.DaysInMonth(Year, Month);
            DateTime percentTimeEnd = new DateTime(Year, Month, daysInMonth, 23, 59, 59, 999);
            monthlyPortfolio.SetPortfolioValue(percentTimeStart);
            decimal startValue = monthlyPortfolio.PortfolioValue;
            monthlyPortfolio.SetPortfolioValue(percentTimeEnd);
            decimal endValue = monthlyPortfolio.PortfolioValue;
            if (startValue == 0)
                return 0;
            return (endValue - startValue)/startValue * 100;
        }
    }


        //***CLASSES***//

    public class Stock
    {
        public string StockName { get; set; }
        public long NumberOfShares { get; set; }
        public decimal InitialPrice { get; set; }
        public decimal LastStockValue { get; set; }
        public Dictionary<DateTime, decimal> StockValues = new Dictionary<DateTime, decimal>();

        public Stock(string stockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockName = stockName;
            NumberOfShares = inNumberOfShares;
            InitialPrice = inInitialPrice;
            StockValues[inTimeStamp] = inInitialPrice;
        }

        public Stock()
        {
            StockName = " ";
            NumberOfShares = 0;
            InitialPrice = 0;
            LastStockValue = 0;
        }

        public void Copy(Stock originalStock)
        {
            this.StockName = originalStock.StockName;
            this.NumberOfShares = originalStock.NumberOfShares;
            this.InitialPrice = originalStock.InitialPrice;
            this.LastStockValue = originalStock.LastStockValue;
            this.StockValues = originalStock.StockValues;
        }

        public DateTime GetDate(DateTime inTimeStamp)
        {
            DateTime priceTime = inTimeStamp;
            DateTime lowerLimit = inTimeStamp;
            foreach (DateTime key in this.StockValues.Keys)
            {
                if (key < lowerLimit)
                {
                    lowerLimit = key;
                    priceTime = key;
                }
            }
            //find interval, return upper limit
            foreach (DateTime key in this.StockValues.Keys)
            {
                if (lowerLimit <= key && inTimeStamp >= key)
                    priceTime = key;
            }
            return priceTime;
        }
    }

    public class Stocks
    {
        public List<Stock> StockList = new List<Stock>();

        public int GetStockIndex(string inStockName)
        {
            int index = StockList.FindIndex(stock => stock.StockName.Equals(inStockName.ToUpper()));
            return index;
        }

        public Stock GetStock(string inStockName)
        {
            Stock returnStock = StockList.Find(stock => stock.StockName.Equals(inStockName.ToUpper()));
            return returnStock;
        }


    }

    public class Index
    {
        public List<Stock> IndexStocks = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            IndexName = inIndexName;
            IndexType = inIndexType;
        }

        public string IndexName { get; set; }
        public IndexTypes IndexType { get; set; }
        public decimal IndexValue { get; set; }

        public void SetIndexValue(DateTime inTimeStamp)
        {
            if (IndexStocks.Count <= 0)
            {
                IndexValue = 0;
                return;
            }

            IndexValue = 0;
            //find the DateTime that corresponds to the asked one (does not have to be the exact same value)
            foreach (Stock stock in IndexStocks)
            {
                DateTime priceTime = stock.GetDate(inTimeStamp);
                if (!stock.StockValues.ContainsKey(priceTime))
                    throw new StockExchangeException("Stock price not defined for the given date.");

                if (IndexType == IndexTypes.AVERAGE)
                    IndexValue += stock.StockValues[priceTime]; 
                else
                    IndexValue += stock.StockValues[priceTime] * stock.NumberOfShares;
            }

            if (IndexType == IndexTypes.AVERAGE)
                IndexValue = Math.Round(IndexValue/IndexStocks.Count, 3);
            else
            {
                decimal weightedValue = 0;
                
                foreach (Stock stock in IndexStocks)
                {
                    weightedValue += stock.LastStockValue/IndexValue*stock.NumberOfShares*stock.LastStockValue;
                }
                IndexValue = Math.Round(weightedValue,3);
            }
        }
    }

    public class Indices
    {
        public List<Index> IndexList = new List<Index>();

        public int GetIndexPosition(string inIndexName)
        {
            int position = IndexList.FindIndex(index => index.IndexName.Equals(inIndexName.ToUpper()));
            return position;
        }

        public Index GetIndex(string inIndexName)
        {
            Index returnIndex = IndexList.Find(index => index.IndexName.Equals(inIndexName.ToUpper()));
            return returnIndex;
        }
    }

    public class Portfolio
    {
        public Stocks PStocks = new Stocks();
        public decimal PortfolioValue {get;set;}
        public string ID { get; set; }

        public Portfolio(string Id)
        {
            ID = Id;
        }

       
        public Portfolio Copy()
        {
            Portfolio newPortfolio = new Portfolio(this.ID);
            this.PortfolioValue = this.PortfolioValue;
            foreach (Stock stock in this.PStocks.StockList)
            {
                Stock newStock = new Stock();
                newStock.Copy(stock);
                newPortfolio.PStocks.StockList.Add(newStock);
            }
            return newPortfolio;
        }

        public void SetPortfolioValue(DateTime inTimeStamp)
        {
            PortfolioValue = 0;
            if (this.PStocks.StockList.Count <= 0)
            {
                this.PortfolioValue = 0;
                return;
            }

            //find the DateTime that corresponds to the asked one (does not have to be the exact same value)
            foreach (Stock stock in this.PStocks.StockList)
            {
                DateTime priceTime = stock.GetDate(inTimeStamp);
                if(!stock.StockValues.ContainsKey(priceTime))
                    throw new StockExchangeException("Stock price not defined for the given date.");
                PortfolioValue += stock.StockValues[priceTime] * stock.NumberOfShares;
            }
            PortfolioValue = Math.Round(PortfolioValue, 3);
        }
    }

    public class Portfolios
    {
        public List<Portfolio> PortfolioList = new List<Portfolio>();

        public int GetPortfolioPosition(string inPortfolioId)
        {
            int position = PortfolioList.FindIndex(index => index.ID.Equals(inPortfolioId));
            return position;
        }

        public Portfolio GetPortfolio(string inPortfolioId)
        {
            Portfolio returnPortfolio = PortfolioList.Find(index => index.ID.Equals(inPortfolioId));
            return returnPortfolio;
        }
    }
}