﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        public Operand memOper;
        public Operand leftOper;
        public Operand rightOper;
        public Operand operPointer;
        public Operation currOperation;
        public string screen = "0";
        public double mem;

        public Dictionary<string, IPressable> btnMap = new Dictionary<string, IPressable>();

        public Kalkulator()
        {
            btnMap.Add("+", new Sum());
            btnMap.Add("Q", new Sqr());
            btnMap.Add(",", new Comma());
            btnMap.Add("M", new SwapSign());
            btnMap.Add("O", new TurnOff());
            btnMap.Add("=", new Eq());
            btnMap.Add("P", new Mem());
            btnMap.Add("G", new MemLoad());
            btnMap.Add("S", new Sin());
            btnMap.Add("-", new Sub());
            btnMap.Add("*", new Mul());
            btnMap.Add("I", new Inv());
            btnMap.Add("K", new Cos());
            btnMap.Add("C", new Clear());
            btnMap.Add("/", new Div());
            btnMap.Add("R", new Root());
            btnMap.Add("T", new Tan());
            this.leftOper = new Operand(0);
            this.setOperToLeft();
            
        }

        public void turnOff() {
            this.screen = "0";
            this.setOperToLeft();
            this.leftOper = new Operand(0);
            this.setCurrOperation(null);
        }

        public void redraw() {
            if( operPointer.getStrValue().Count(Char.IsDigit) > 10 )
                this.setErr();
            else {
                if(operPointer.getStrValue().Contains(','))
                    this.screen = string.Format("{0:G29}", decimal.Parse(operPointer.getStrValue()));
                else
                    this.screen = operPointer.getStrValue();
            }
        }

        public void Press(char inPressedDigit)
        {
            IPressable stisnuto = parseBtn(inPressedDigit);
            Console.WriteLine(stisnuto);
            stisnuto.pressed(this); //ovdje sad odraditi sto treba po pritiskanju
        }
        public string GetCurrentDisplayState()
        {
            return this.screen;
        }


        public IPressable parseBtn(char pressedKey)
        {
            if (Char.IsNumber(pressedKey))
            {
                return new Operand(int.Parse(pressedKey+""));
                
            }
            return btnMap[pressedKey + ""];

        }

        public void setCurrOperation(Operation oper) 
        {
            this.currOperation = oper;
            //izracunati tek poslije postavljanja opera i drugog broja
        }
        public void setOperToLeft() 
        {
            if( this.leftOper == null )
                this.leftOper = new Operand(0);
            this.operPointer = this.leftOper;
        }
        public void setOperToRight() 
        {
            if( this.rightOper == null )
                this.rightOper = new Operand();
            this.operPointer = this.rightOper;
        }
        public void setErr() {
            this.screen = "-E-";
        }

        public interface IPressable
        {
            void pressed(Kalkulator kalkulator);
        }
        public class Operand:IPressable
        {
            private double numValue;
            private string strValue;

            public Operand(int i)
            {
                this.numValue = i;
                this.strValue = "" + i;
            }
            public Operand() {
                this.numValue = 0;
                this.strValue = "";
            }

            public void swapSign() {
                this.numValue = -1 * numValue;
                this.strValue = numValue + "";
            }
            public double append(string c)
            {
                if( strValue.Equals("0") )
                    strValue = "";
                //provjeri jeli broj sada ispravan
                strValue = strValue + c;
                numValue = Double.Parse(strValue);
                
                return numValue;
            }
            public string getStrValue()
            {
                return strValue;
            }
            public double getNumValue()
            {
                return numValue;
            }
            public void setNumValue(double d)
            {
                this.numValue = d;
            }
            public void setStrValue( string s ) {
                this.strValue = s;
            }
            public void pressed(Kalkulator kalkulator)
            {
                if( kalkulator.screen.Count(Char.IsDigit) >= 10 && (kalkulator.operPointer.getStrValue().Length == kalkulator.screen.Length))
                    return;
                kalkulator.operPointer.append(this.getStrValue());
                kalkulator.redraw();
            }
        }

        public abstract class Operation : IPressable
        {   
            //provjere i podesavanje pointera, oper type specific
            //implementiraju ga vrste operacija
            public abstract void exec(Kalkulator k);
           
            public abstract void pressed( Kalkulator kalkulator );
            
        }
        public abstract class BinaryOperation : Operation
        {
            //specificira sto ce se raditi s pointerima i provjere 
            public override void  exec(Kalkulator k) {
                if( k.operPointer == k.leftOper ) { //jos uvijek nije unesen ljevi operator
                    k.setErr();
                }

            }
            public override void pressed( Kalkulator kalkulator ) {
                if( kalkulator.operPointer == kalkulator.rightOper && !kalkulator.rightOper.getStrValue().Equals("") ) {
                    kalkulator.currOperation.exec(kalkulator);

                }
                //ako je pointer na desnom, samo unesi operaciju a mora biti na desnom jel unosenje 
                //drugog nakon operacije automatski je i izvrsava
                kalkulator.setCurrOperation(this);
                kalkulator.setOperToRight();
            }
           
            
        }
        public abstract class UnaryOperation : Operation
        {
            public override void pressed( Kalkulator kalkulator ) {
                this.exec(kalkulator);
            } 
        }
        

        //jednako,  mem+ i mem- kao podklase Operation, UtilOperation

        public class Sub : BinaryOperation {
            public override void exec( Kalkulator k ) {
                //dohvati iz mape operaciju
                if( k.rightOper == k.operPointer && k.rightOper.Equals("") ) { //jos uvijek je na drugom, nije unesen
                    //k.rightOper = k.leftOper kopiraj samo desnog u ljevog i pusti dalje isto
                }
                double rez = k.leftOper.getNumValue() - k.rightOper.getNumValue();
                Console.WriteLine(k.leftOper.getNumValue() - k.rightOper.getNumValue());
                
                k.leftOper.setNumValue(rez);
                k.leftOper.setStrValue(rez + "");
                k.rightOper.setStrValue("");
                k.setOperToLeft();
                k.redraw();
            }
            
        }
        public class Sum : BinaryOperation
        {
            public override void exec(Kalkulator k)
            {
                //dohvati iz mape operaciju
                if( k.rightOper == k.operPointer && k.rightOper.getStrValue().Equals("")) { //jos uvijek je na drugom, nije unesen
                    k.rightOper.setNumValue(k.leftOper.getNumValue());
                }
                double rez = k.leftOper.getNumValue() + k.rightOper.getNumValue();
                k.setOperToLeft();
                k.leftOper.setNumValue(rez);
                k.leftOper.setStrValue(rez.ToString());
                k.rightOper.setStrValue("");
                k.redraw();
            }
            
        }
        private class Sqr : UnaryOperation {
            public override void  exec(Kalkulator k)
            {
                double n = k.operPointer.getNumValue();
 	            k.operPointer.setNumValue(Math.Pow(n,2));
                k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                k.redraw();
            }
            
        }
        private class Comma : Operation {
            public override void pressed( Kalkulator kalkulator ) {
                kalkulator.operPointer.setStrValue(kalkulator.operPointer.getStrValue()+",");
            }
            public override void exec( Kalkulator k ) {
                throw new NotImplementedException();
            }
           
        }
        private class Mem : Operation {
            public override void pressed( Kalkulator kalkulator ) {
                kalkulator.mem = double.Parse(kalkulator.GetCurrentDisplayState());
            }
            
            public override void exec( Kalkulator k ) {
                throw new NotImplementedException();
            }
        }
        private class MemLoad : Operation {
            public override void pressed( Kalkulator kalkulator ) {
                kalkulator.operPointer.setNumValue(kalkulator.mem);
                kalkulator.operPointer.setStrValue(kalkulator.mem + "");
                kalkulator.redraw();
            }
            public override void exec( Kalkulator k ) {
                throw new NotImplementedException();
            }
           
        }
        private class SwapSign : Operation {
            public override void pressed( Kalkulator kalkulator ) {
                kalkulator.operPointer.swapSign();
                kalkulator.redraw();
            }
            public override void exec( Kalkulator k ) {
                throw new NotImplementedException();
            }
            
        }
        private class TurnOff : Operation {
            public override void exec( Kalkulator k ) {
                throw new NotImplementedException();
            }
           
            public override void pressed( Kalkulator kalkulator ) {
                kalkulator.turnOff();
            }
        }
        private class Eq : Operation {
            public override void exec( Kalkulator k ) {
                
            }
            
            public override void pressed( Kalkulator kalkulator ) {
                if( kalkulator.currOperation != null )
                    kalkulator.currOperation.exec(kalkulator);
                
            }
        }
        private class Sin : UnaryOperation {
            public override void exec( Kalkulator k ) {
                k.operPointer.setNumValue(Math.Round(Math.Sin(k.operPointer.getNumValue()), 9));
                k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                k.redraw();
            }
           
           
        }
        private class Mul : BinaryOperation {
            public override void exec( Kalkulator k ) {
                //dohvati iz mape operaciju
                if( k.rightOper == k.operPointer && k.rightOper.Equals("") ) { //jos uvijek je na drugom, nije unesen
                    //k.rightOper = k.leftOper kopiraj samo desnog u ljevog i pusti dalje isto
                }
                double rez = k.leftOper.getNumValue() * k.rightOper.getNumValue();
                k.leftOper.setNumValue(rez);
                k.leftOper.setStrValue(rez + "");
                k.rightOper.setStrValue("");
                k.setOperToLeft();
                k.redraw();
            }
           
        }
        private class Inv : UnaryOperation {
            public override void exec( Kalkulator k ) {
                if( k.operPointer.getNumValue() == 0 && !k.operPointer.getStrValue().Equals("")) {
                    k.setErr();
                }
                else {
                    if( k.operPointer.getStrValue().Equals("") ) {
                        k.screen = "" +(1 / k.leftOper.getNumValue());
                    }
                    else {
                        k.operPointer.setNumValue(1 / k.operPointer.getNumValue());
                        k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                        k.redraw();
                    }
                }
            }
            
        }
        private class Cos : UnaryOperation {
            public override void exec( Kalkulator k ) {
                k.operPointer.setNumValue(Math.Round(Math.Cos(k.operPointer.getNumValue()), 9));
                k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                k.redraw();
            }
            
            
        }
        private class Clear : Operation {
            public override void pressed( Kalkulator kalkulator ) {
                this.exec(kalkulator);
            }
            public override void exec( Kalkulator k ) {
                k.operPointer.setNumValue(0);
                k.operPointer.setStrValue("0");
                k.redraw();
            }
            
        
        }
        private class Div : BinaryOperation {
            public override void exec( Kalkulator k ) {
                //dohvati iz mape operaciju
                if( k.rightOper == k.operPointer && k.rightOper.getStrValue().Equals("") ) { //jos uvijek je na drugom, nije unesen
                    k.rightOper.setNumValue(k.leftOper.getNumValue());
                }
                if( k.rightOper.getNumValue() == 0 )
                    k.setErr();
                double rez = k.leftOper.getNumValue() / k.rightOper.getNumValue();
                k.setOperToLeft();
                k.leftOper.setNumValue(rez);
                k.leftOper.setStrValue(rez.ToString());
                k.rightOper.setStrValue("");
                k.redraw();
            }
           
        }
        private class Root : UnaryOperation {
            public override void exec( Kalkulator k ) {
                if( k.operPointer.getNumValue() == 0 ) {
                    k.setErr();
                }
                else {
                    k.operPointer.setNumValue(Math.Round(Math.Sqrt(k.operPointer.getNumValue()), 9));
                    k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                    k.redraw();
                }
            }
        }
        private class Tan : UnaryOperation {
            public override void exec( Kalkulator k ) {
                k.operPointer.setNumValue(Math.Round(Math.Tan(k.operPointer.getNumValue()), 9));
                k.operPointer.setStrValue(k.operPointer.getNumValue() + "");
                k.redraw();
            }


        }
    }

    

}
