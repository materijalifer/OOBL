﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    /// <summary>
    /// Razred koji implementira sučelje ICalculator i ostvaruje
    /// željenu funkcionalnost kalkulatora u skladu s uputama danim
    /// u tekstu domaće zadaće.
    /// NAPOMENA: nije implementirana sva funkcionalnost :(
    /// </summary>
    public class Kalkulator:ICalculator
    {
        /// <summary>
        /// Konstanta koja označava maksimalan broj znamenki koji
        /// se može prikazati na kalkulatoru.
        /// </summary>
        private static int _MAX_DISPLAY_CHARACTERS = 10;

        /// <summary>
        /// Broj trenutnih znamenki gledanog operanda.
        /// </summary>
        int _digits;

        /// <summary>
        /// Double reprezentacija prvog operanda.
        /// </summary>
        double _operand1;

        /// <summary>
        /// Double reprezentacija drugog operanda.
        /// </summary>
        double _operand2;

        /// <summary>
        /// Trenutna operacija koja čeka izvođenje.
        /// </summary>
        char _operation;

        /// <summary>
        /// Podatak koji govori postoji li operacija
        /// koja čeka izvršavanje.
        /// </summary>
        bool _hasOperation;

        /// <summary>
        /// Podatak koji govori je li nakon unosa
        /// operacije unesen i drugi operand ili
        /// je operacija još uvijek podložna promjeni.
        /// </summary>
        bool _inOperationMode;

        /// <summary>
        /// Podatak koji govori je li počelo dohvaćanje
        /// drugog operanda potrebnog za izvršenje operacije.
        /// </summary>
        bool _gotFirstDigit;

        /// <summary>
        /// Podatak koji govori je li prilikom izvođenja došlo
        /// do greške.
        /// </summary>
        bool _hasError;


        // KOMPONENTE ZA ISPIS OPERANDA

        /// <summary>
        /// String reprezentacija preznaka gledanog operanda.
        /// </summary>
        private string _sign;

        /// <summary>
        /// String reprezentacija cijelobrojnog dijela gledanog operanda.
        /// </summary>
        private string _intString;

        /// <summary>
        /// Podatak o tome sadrži li gleani operand decimalni dio,
        /// konkretnije, sadrži li decimalni zarez.
        /// </summary>
        bool _hasDecimal;

        /// <summary>
        /// String reprezentacija decimalnog dijela gledanog operanda.
        /// </summary>
        private string _decString;

        //private string memory;


        /// <summary>
        /// Konstruktor razreda Kalkulator, postavlja početno
        /// stanje ispisa na "0", inicijalizira početne parametre
        /// i zastavice.
        /// </summary>
        public Kalkulator()
        {
            resetDisplayState();

            _hasOperation = false;
            _inOperationMode = false;
            _gotFirstDigit = false;

            _hasError = false;
        }

        /// <summary>
        /// Pomoćna metoda za poništavanje varijabli
        /// stanja ekrana;
        /// </summary>
        private void resetDisplayState()
        {
            _digits = 1;

            _hasDecimal = false;

            _sign = "+";
            _intString = "0";
            _decString = "";
        }

        /// <summary>
        /// Metoda koja prima podatak o pritisnutoj tipki
        /// kalkulatora i s obzirom na tipku izvodi odgovarajuće
        /// operacije.
        /// </summary>
        /// <param name="inPressedDigit">Podatak o pritisnutoj tipki</param>
        public void Press(char inPressedDigit)
        {
            // u slučaju prethodne pogreške, prihvati samo reset ('O')
            if (_hasError)
            {
                if (inPressedDigit == 'O')
                {
                    resetDisplayState();
                    _hasError = false;
                }

                // ignoriraj drugačiji input
                return;
            }

            // BROJEVI
            if (inPressedDigit >= '0' && inPressedDigit <= '9'
                && _digits < _MAX_DISPLAY_CHARACTERS)
            {
                // ako je prikazano 0 ili je prethodno odabrana računska operacija
                if (!_gotFirstDigit || GetCurrentDisplayState().Equals("0"))
                {
                    // prilikom upisa prve znamenke novog operanda, resetiraj stari
                    if (!_gotFirstDigit)
                    {
                        resetDisplayState();
                        _gotFirstDigit = true;
                    }

                    // ako već postoji decimalni zarez, dodaj kao decimalni dio
                    if (_hasDecimal)
                        _decString = new string(inPressedDigit, 1);
                    // inače dodaj kao cjelobrojni dio
                    else
                        _intString = new string(inPressedDigit, 1);
                    
                }
                // inače dodaj znamenku u postojeći broj
                else
                {
                    // zapisivanje u decimalni dio
                    if (_hasDecimal)
                    {
                        _decString += inPressedDigit;
                    }
                    // zapisivanje u cjelobrojni dio
                    else
                    {
                        _intString += inPressedDigit;
                    }

                    // uvećavanje broja znamenki
                    _digits++;
                }
            }

            // DECIMALNI ZAREZ
            else if (inPressedDigit == ',')
            {
                // ako ne postoji decimalni zarez, dodaj ga
                if (!_hasDecimal)
                {
                    // prilikom upisa decimalnog zareza kao prve znamenke novog operanda, resetiraj stari
                    if (!_gotFirstDigit)
                    {
                        resetDisplayState();
                        _gotFirstDigit = true;
                    }
                    _hasDecimal = true;
                }
                // zanemaruje se pokušaj naknadnog dodavanja zareza
            }

            // PROMJENA PREDZNAKA
            else if (inPressedDigit == 'M')
            {
                if (_sign.Equals("+"))
                    _sign = "-";
                else
                    _sign = "+";
            }

            // OSNOVNE ARITMETIČKE OPERACIJE I JEDNAKO
            else if (inPressedDigit == '+' || inPressedDigit == '-'
                || inPressedDigit == '*' || inPressedDigit == '/'
                || inPressedDigit == '=')
            {
                executeBasicArithmetics(inPressedDigit);
            }

            // TRIGONOMETRIJSKE OPERACIJE
            else if (inPressedDigit == 'S' || inPressedDigit == 'C' || inPressedDigit == 'T')
            {
                _operand1 = extractOperand();
                if (_sign == "-")
                    _operand1 *= -1;

                if (inPressedDigit == 'S')
                {
                    _operand1 = Math.Round(Math.Sin(_operand1), 9);
                }

                reconstructOperand();

                _hasOperation = false;
                _gotFirstDigit = false;
            }

            // RESETIRANJE KALKULATORA
            else if (inPressedDigit == 'O')
            {
                resetDisplayState();
            }
        }


        /// <summary>
        /// Pomoćna metoda za obavljanje osnovnih aritmetičkih
        /// operacija (zbrajanje, oduzimanje, množenje, dijeljenje).
        /// </summary>
        /// <param name="operation">Znak koji simbolizira operaciju</param>
        private void executeBasicArithmetics(char operation)
        {
            // ako još ne postoji operacija i ne radi se o operaciji jednako
            if (!_hasOperation && operation != '=')
            {
                // pohrani operaciju i pripremi operand za prikaz
                _hasOperation = true;
                _operation = operation;
                _operand1 = extractOperand();
                if (_sign == "-")
                    _operand1 *= -1;

                reconstructOperand();

                // postavi zastavicu da još ne postoje znamenke drugog operatora
                _gotFirstDigit = false;
            }
            // inače ako postoji operacija ili se radi o operaciji jednako
            else
            {
                // ako nema nikakve operacije, uredi operand
                if (!_hasOperation && operation == '=')
                {
                    _operand1 = extractOperand();
                    if (_sign == "-")
                        _operand1 *= -1;

                    reconstructOperand();
                    return;
                }

                // ako je i dalje u modu za odabir operacije, prebriši staru operaciju novom
                if (_inOperationMode)
                {
                    _operation = operation;
                }
                // inače odradi prethodnu operaciju, prikaži rezultat (pripremi za prikaz) i pohrani trenutnu operaciju
                else
                {
                    // priprema drugog operanda za operaciju
                    _operand2 = extractOperand();
                    if (_sign == "-")
                        _operand2 *= -1;

                    // traženje i izvođenje odgovarajuće aritmetičke operacije
                    if (_operation == '+')
                        _operand1 = _operand1 + _operand2;

                    else if (_operation == '-')
                        _operand1 = _operand1 - _operand2;

                    else if (_operation == '*')
                        _operand1 = _operand1 * _operand2;

                    else if (_operation == '/')
                    {
                        // provjera dijeljenja s nulom i izbacivanje greške
                        if (_operand2 == 0.0)
                        {
                            _hasError = true;
                            return;
                        }

                        _operand1 = _operand1 / _operand2;
                    }

                    // postavi zastavicu da ne postoje još znamenke drugog operatora
                    //_gotFirstDigit = false;

                    // pohrani trenutnu operaciju
                    _operation = operation;

                    // ako je operacija bila jednako, rekonstruiraj rezultat za prikaz
                    if(operation == '=')
                        reconstructOperand();
                }

            }
        }


        /// <summary>
        /// Pomoćna metoda koja podatke o operandu pretvara u
        /// double, radi lakšeg izračunavanja.
        /// </summary>
        /// <returns>Double reprezentaciju operanda</returns>
        private double extractOperand()
        {
            int decStringLength = _decString.Length;
            
            // postavljanje vrijednosti decimala na nulu ako su prazne
            if (_decString.Equals(""))
            {
                _decString = "0";
                decStringLength = 0;
            }

            return int.Parse(_intString) + int.Parse(_decString) / Math.Pow(10, decStringLength);
        }


        /// <summary>
        /// Pomoćna metoda koja nakon izvršene operacije rekonstruira
        /// pomoću rezultata prikaz na ekranu.
        /// </summary>
        private void reconstructOperand()
        {
            // dohvaćanje operanda
            string operand = _operand1.ToString();

            // spremanje informacije o predznaku
            if (operand.StartsWith("-"))
            {
                _sign = "-";
                // uklanjanje predznaka radi daljnje obrade
                operand = operand.Substring(1);
            }
            else
                _sign = "+";

            // određivanje pozicije decimalnog zareza
            int commaIndex = operand.IndexOf(",");

            // ako postoji decimalni zarez
            if (commaIndex != -1)
            {
                // spremanje informacije o cjelobrojnom i decimalnom dijelu operanda
                _intString = operand.Substring(0, commaIndex);
                _decString = operand.Substring(commaIndex + 1, operand.Length - (commaIndex + 1));
                // ako su decimale samo nule, makni decimale
                if (int.Parse(_decString) == 0)
                    _decString = "";
            }
            else
            {
                // spremanje informacije o cjelobrojnom i decimalnom dijelu operanda
                _intString = operand;
                _decString = "";
            }

            // provjera ispravnosti formata

            // ako ima više od 10 znamenaka cijelobrojnog dijela, pripremi grešku
            if (_intString.Length > 10)
                _hasError = true;
        }

        /// <summary>
        /// Metoda koja vraća string trenutnog stanja na
        /// ekranu kalkulatora.
        /// NAPOMENA: metoda pretpostavlja da će prikazati
        /// stanje u ispravnom formatu s ispravnim brojem
        /// znamenaka (provjera se odvija van ove metode).
        /// </summary>
        /// <returns>
        /// String reprezentacija trenutnog stanja
        /// ekrana kalkulatora.
        /// </returns>
        public string GetCurrentDisplayState()
        {
            // ako postoji greška, vrati ju
            if (_hasError)
                return "-E-";

            // slaganje komponenti u prikaz
            string displayState = "";
            
            // dodavanje predznaka po potrebi
            if (_sign.Equals("-"))
                displayState += _sign;
            
            // dodavanje cjelobrojnog dijela broja
            displayState += _intString;

            // dodavanje decimalnog dijela broja po potrebi
            if (!_decString.Equals(""))
                displayState += ("," + _decString);

            return displayState;
        }
    }


}
