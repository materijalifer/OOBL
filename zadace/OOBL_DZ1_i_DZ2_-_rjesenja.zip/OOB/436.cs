﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        string ekran = "0";
        string greska = "-E-";
        int brojZnamenki = 1;
        char operacija = '#';


        string prvaVarijabla = "0";
        string spremljenaVarijabla = "0";
        bool dodanaDruga = false;
        bool zarezNaPoc = false;

        public string GetCurrentDisplayState()
        {
            return ekran;
        }

        public void Press(char inPressedDigit)
        {
            if (ekran != greska)
            {
                switch (inPressedDigit)
                {
                    case '+': { plus(); break; }
                    case '-': { minus(); break; }
                    case '*': { pomnozi(); break; }
                    case '/': { podijeli(); break; }
                    case '=': { jednako(); break; }
                    case ',': { zarez(); break; }
                    case 'M': { predznak(); break; }
                    case 'S': { sinus(); break; }
                    case 'K': { kosinus(); break; }
                    case 'T': { tangens(); break; }
                    case 'Q': { kvadriraj(); break; }
                    case 'R': { korjenuj(); break; }
                    case 'I': { inverz(); break; }
                    case 'P': { spremi(); break; }
                    case 'G': { dohvati(); break; }
                    case 'C': { ocisti(); break; }
                    case 'O': { resetiraj(); break; }
                    default: { novaZnamenka(inPressedDigit); break; }
                }
            }
            else
            {
                switch (inPressedDigit)
                {
                    case 'C': { ocisti(); break; }
                    case 'O': { resetiraj(); break; }
                    default: { break; }
                }
            }
        }

        #region Funkcije
        private void novaZnamenka(char znamenka)
        {
            if (!dodanaDruga) ekran = "0";
            if (zarezNaPoc)
            {
                ekran = "0,";
                zarezNaPoc = false;
            }
            if (brojZnamenki < 10)
            {
                if (ekran == "0") ekran = znamenka.ToString();
                else
                {
                    ekran += znamenka.ToString();
                    brojZnamenki++;
                }
                dodanaDruga = true;
            }
            else if (brojZnamenki == 10)
            {
                if (ekran.Contains(","))
                {
                    ekran += znamenka.ToString();
                    string cijeliDio = ekran.Split(',')[0].TrimStart('-');
                    int naKolikoDec = 10 - cijeliDio.Length;

                    ekran = Math.Round(decimal.Parse(ekran), naKolikoDec).ToString();
                }

            }
        }

        private void plus()
        {
            ekran = trim(ekran);
            prvaVarijabla = ekran;
            operacija = '+';
            brojZnamenki = 1;
            dodanaDruga = false;
        }

        private string trim(string ekran)
        {
            if (ekran.Contains(","))
            {
                ekran = ekran.TrimEnd('0');
                ekran = ekran.TrimEnd(',');
            }
            return ekran;
        }

        private void minus()
        {
            ekran = trim(ekran);
            prvaVarijabla = ekran;
            operacija = '-';
            brojZnamenki = 1;
            dodanaDruga = false;
        }

        private void pomnozi()
        {
            ekran = trim(ekran);
            prvaVarijabla = ekran;
            operacija = '*';
            brojZnamenki = 1;
            dodanaDruga = false;
        }

        private void podijeli()
        {
            ekran = trim(ekran);
            prvaVarijabla = ekran;
            operacija = '/';
            brojZnamenki = 1;
            dodanaDruga = false;
        }

        private void jednako()
        {
            if (dodanaDruga)
            {
                string cijeliDio;
                switch (operacija)
                {
                    case '#':
                        ekran = ekran.TrimEnd('0');
                        ekran = ekran.TrimEnd(',');
                        break;
                    case '+':
                        ekran = (decimal.Parse(prvaVarijabla) + decimal.Parse(ekran)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '-':
                        ekran = (decimal.Parse(prvaVarijabla) - decimal.Parse(ekran)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '*':
                        ekran = (decimal.Parse(prvaVarijabla) * decimal.Parse(ekran)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '/':
                        try
                        {
                            ekran = (decimal.Parse(prvaVarijabla) / decimal.Parse(ekran)).ToString();
                            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                            else cijeliDio = ekran;

                            zaokruzi(cijeliDio);
                        }
                        catch (Exception e)
                        {
                            ekran = greska;
                        }
                        break;
                    default:
                        break;
                }
            }
            else
            {
                string cijeliDio;
                switch (operacija)
                {
                    case '+':
                        ekran = (decimal.Parse(prvaVarijabla) + decimal.Parse(prvaVarijabla)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '-':
                        ekran = (decimal.Parse(prvaVarijabla) - decimal.Parse(prvaVarijabla)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '*':
                        ekran = (decimal.Parse(prvaVarijabla) * decimal.Parse(prvaVarijabla)).ToString();
                        if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                        else cijeliDio = ekran;

                        zaokruzi(cijeliDio);
                        break;
                    case '/':
                        try
                        {
                            ekran = (decimal.Parse(prvaVarijabla) / decimal.Parse(prvaVarijabla)).ToString();
                            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                            else cijeliDio = ekran;

                            zaokruzi(cijeliDio);
                        }
                        catch (Exception e)
                        {
                            ekran = greska;
                        }

                        break;
                    default:
                        break;
                }
            }
        }

        private void zaokruzi(string cijeliDio)
        {
            if (cijeliDio.Length > 10) ekran = greska;
            else if (ekran.Contains(","))
            {

                int naKolikoDec = 10 - cijeliDio.Length;
                ekran = Math.Round(decimal.Parse(ekran), naKolikoDec).ToString();
                ekran = ekran.TrimEnd('0');
                ekran = ekran.TrimEnd(',');
            }
        }

        private void zarez()
        {
            if (ekran == "0")
            {
                ekran = "0,";
                zarezNaPoc = true;
            }
            else if (!ekran.Contains(","))
            {
                ekran += ",";
            }
        }

        private void predznak()
        {
            ekran = (decimal.Parse(ekran) * (-1)).ToString();
        }

        private void sinus()
        {
            ekran = ((decimal)Math.Sin(double.Parse(ekran))).ToString();
            string cijeliDio;
            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
            else cijeliDio = ekran;

            zaokruzi(cijeliDio);
        }

        private void kosinus()
        {
            ekran = ((decimal)Math.Cos(double.Parse(ekran))).ToString();
            string cijeliDio;
            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
            else cijeliDio = ekran;

            zaokruzi(cijeliDio);
        }

        private void tangens()
        {
            ekran = ((decimal)Math.Tan(double.Parse(ekran))).ToString();
            string cijeliDio;
            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
            else cijeliDio = ekran;

            zaokruzi(cijeliDio);
        }

        private void kvadriraj()
        {
            string cijeliDio;
            ekran = (decimal.Parse(ekran) * decimal.Parse(ekran)).ToString();
            if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
            else cijeliDio = ekran;

            zaokruzi(cijeliDio);
        }

        private void korjenuj()
        {
            string cijeliDio;
            try
            {
                ekran = ((decimal)Math.Sqrt(double.Parse(ekran))).ToString();
                if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                else cijeliDio = ekran;

                zaokruzi(cijeliDio);
            }
            catch (Exception e)
            {
                ekran = greska;
            }
        }

        private void inverz()
        {
            try
            {
                ekran = (1 / decimal.Parse(ekran)).ToString();
                string cijeliDio;
                if (ekran.Contains(",")) cijeliDio = ekran.Split(',')[0].TrimStart('-');
                else cijeliDio = ekran;

                zaokruzi(cijeliDio);
            }
            catch (Exception e)
            {
                ekran = greska;
            }
        }

        private void spremi()
        {
            spremljenaVarijabla = ekran;
        }

        private void dohvati()
        {
            ekran = spremljenaVarijabla;
        }

        private void ocisti()
        {
            ekran = "0";
            brojZnamenki = 1;
        }

        private void resetiraj()
        {
            ekran = "0";
            brojZnamenki = 1;
            prvaVarijabla = "0";
            spremljenaVarijabla = "0";
        }
        #endregion


    }


}
