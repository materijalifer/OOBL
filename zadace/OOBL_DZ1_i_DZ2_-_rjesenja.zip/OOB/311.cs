﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Contains stock information like price by time and number of shares.
    /// </summary>
    public class Stock
    {
        /// <summary>
        /// Stock unique identifier - ignores case.
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Number of shares of this stock on the exchange.
        /// </summary>
        public long Number { get; private set; }

        /// <summary>
        /// Timestamped prices.
        /// </summary>
        public SortedDictionary<DateTime, decimal> Prices { get; private set; } 

        /// <summary>
        /// Default constructor with starting price.
        /// </summary>
        /// <param name="name">Stock identifier.</param>
        /// <param name="number">Number of shares of this stock on the exchange.</param>
        /// <param name="price">Stock price at the given time.</param>
        /// <param name="timeStamp">Time the price is given for.</param>
        public Stock(string name, long number, decimal price, DateTime timeStamp)
        {
            if (name == null)
                throw new StockExchangeException("Invalid stock name.");

            // check number
            if (number <= 0)
                throw new StockExchangeException("Invalid number of shares.");

            // check price
            if (price <= 0)
                throw new StockExchangeException("Invalid share price");

            Name = name;
            Number = number;
            Prices = new SortedDictionary<DateTime, decimal>();
            Prices.Add(timeStamp, price);
        }

        /// <summary>
        /// Sets a new stock price with 1ms granularity.
        /// </summary>
        /// <param name="timeStamp">Time the price is given for.</param>
        /// <param name="price">Stock price at the given time.</param>
        public void SetPrice(DateTime timeStamp, decimal price)
        {
            // check if timestamp exists
            foreach (KeyValuePair<DateTime, decimal> p in Prices)
            {
                if (p.Key.Date == timeStamp.Date && 
                    p.Key.Hour == timeStamp.Hour && 
                    p.Key.Minute == timeStamp.Minute && 
                    p.Key.Second == timeStamp.Second && 
                    p.Key.Millisecond == timeStamp.Millisecond)
                {
                    throw new StockExchangeException("The timestamp already exists.");
                }
            }

            Prices.Add(timeStamp, price);
        }

        /// <summary>
        /// Gets the stock price at the given time.
        /// </summary>
        /// <param name="timeStamp">Time from which the price is asked for.</param>
        /// <returns>Stock price at the desired time.</returns>
        public decimal GetPrice(DateTime timeStamp)
        {
            if (Prices.Count((price) => price.Key < timeStamp) == 0)
                throw new StockExchangeException("No price set for given timestamp.");

            return Prices.LastOrDefault((price) => price.Key < timeStamp).Value;
        }

        /// <summary>
        /// Equality check by identifier - case ignored.
        /// </summary>
        /// <param name="obj">Object to check equality with.</param>
        /// <returns>True if this instance is equal to the object, false otherwise.</returns>
        public override bool Equals(object obj)
        {
            if (obj is Stock)
                return (obj as Stock).Name.Equals(Name, StringComparison.InvariantCultureIgnoreCase);

            return false;
        }
    }

    /// <summary>
    /// A tool for measuring group stock values. Contains stocks.
    /// </summary>
    public class Index
    {
        /// <summary>
        /// Case ignored identifier.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Type of index.
        /// </summary>
        public IndexTypes Type { get; set; }

        /// <summary>
        /// Group of stocks measured.
        /// </summary>
        public List<Stock> Stocks { get; private set; } 

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="name">Index identifier.</param>
        /// <param name="type">Index value type.</param>
        public Index(string name, IndexTypes type)
        {
            if (name == null)
                throw new StockExchangeException("Invalid index name.");

            Name = name;
            Type = type;
            Stocks = new List<Stock>();
        }

        /// <summary>
        /// Adds a stock to this index.
        /// </summary>
        /// <param name="stock">Stock to add.</param>
        public void AddStock(Stock stock)
        {
            Stocks.Add(stock);
        }

        /// <summary>
        /// Removes a stock from this index.
        /// </summary>
        /// <param name="stock">Stock to remove.</param>
        public void RemoveStock(Stock stock)
        {
            Stocks.Remove(stock);
        }

        /// <summary>
        /// Checks if the index contains a stock.
        /// </summary>
        /// <param name="stock">The stock to check.</param>
        /// <returns>True if index contains the stock, false otherwise.</returns>
        public bool ContainsStock(Stock stock)
        {
            return Stocks.Contains(stock);
        }

        /// <summary>
        /// Index value in the given time based on the index type.
        /// </summary>
        /// <param name="timeStamp">The time for which to check index value.</param>
        /// <returns>Index value and the given time.</returns>
        public decimal Value(DateTime timeStamp)
        {
            if (Stocks.Count == 0)
                throw new StockExchangeException("No stocks in index.");

            decimal totalPrice = 0;
            long totalStocks = 0;
            decimal totalValue = 0;
            foreach (Stock stock in Stocks)
            {
                totalStocks += stock.Number;
                totalValue += stock.GetPrice(timeStamp)*stock.Number;
            }

            if (Type == IndexTypes.AVERAGE)
            {
                foreach (Stock stock in Stocks)
                {
                    totalPrice += stock.GetPrice(timeStamp) * stock.Number;
                }

                return Math.Round(totalPrice/totalStocks, 3);
            }

            foreach (Stock stock in Stocks)
            {
                decimal stockPrice = stock.GetPrice(timeStamp) * stock.GetPrice(timeStamp) * stock.Number / totalValue;
                totalPrice += stockPrice;
            }

            return Math.Round(totalPrice, 3);
        }

        /// <summary>
        /// Equality check by identifier - case ignored.
        /// </summary>
        /// <param name="obj">Object to check for equality.</param>
        /// <returns>True if the object is equal to this instance, false otherwise.</returns>
        public override bool Equals(object obj)
        {
            if (obj is Index)
                return (obj as Index).Name.Equals(Name, StringComparison.InvariantCultureIgnoreCase);

            return false;
        }
    }

    /// <summary>
    /// A collection of stocks in someone's property.
    /// </summary>
    public class Portfolio
    {
        /// <summary>
        /// Portfolio identifier - case respected.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Number of shares of stocks.
        /// </summary>
        public Dictionary<Stock, long> Stocks { get; private set; } 

        /// <summary>
        /// Default constructor with portfolio identifier.
        /// </summary>
        /// <param name="id">Portfolio identifier.</param>
        public Portfolio(string id)
        {
            if (id == null)
                throw new StockExchangeException("Invalid portfolio name");

            Name = id;
            Stocks = new Dictionary<Stock, long>();
        }

        /// <summary>
        /// Adds a number of stock shares to the portfolio.
        /// </summary>
        /// <param name="stock">The stock to add to the portfolio.</param>
        /// <param name="number">The number of shares of the given stock to add to the portfolio.</param>
        public void AddStocks(Stock stock, long number)
        {
            if (Stocks.ContainsKey(stock))
                Stocks[stock] += number;
            else
                Stocks.Add(stock, number);
        }

        /// <summary>
        /// Removes a number of stock shares from the portfolio.
        /// </summary>
        /// <param name="stock">The stock to remove from the portfolio.</param>
        /// <param name="number">The number of shares of the given stock to remove from the portfolio.</param>
        public void RemoveStocks(Stock stock, long number)
        {
            if (!Stocks.ContainsKey(stock))
                throw new StockExchangeException("The stock doesn't exist in this portfolio.");

            if (Stocks[stock] < number)
                throw new StockExchangeException("The number of shares to remove is greater than the number of shares in this portfolio.");

            Stocks[stock] -= number;
            if (Stocks[stock] == 0)
                Stocks.Remove(stock);
        }

        /// <summary>
        /// Removes all stock shares of a given stock from the portfolio.
        /// </summary>
        /// <param name="stock">The stock to remove all shares from the portfolio.</param>
        public void RemoveStocks(Stock stock)
        {
            if (!Stocks.ContainsKey(stock))
                throw new StockExchangeException("The stock doesn't exist in this portfolio.");
            
            Stocks.Remove(stock);
        }

        /// <summary>
        /// Check if the portofolio contains the given stock.
        /// </summary>
        /// <param name="stock">The stock to check.</param>
        /// <returns>True if the portfolio contains the stock, false otherwise.</returns>
        public bool ContainsStocks(Stock stock)
        {
            return Stocks.ContainsKey(stock);
        }

        /// <summary>
        /// The number of shares of a given stock in this portfolio.
        /// </summary>
        /// <param name="stock">The stock.</param>
        /// <returns>Number of shares.</returns>
        public long NumberOfShares(Stock stock)
        {
            if (ContainsStocks(stock))
                return Stocks[stock];

            return 0;
        }

        /// <summary>
        /// The number of shares of all stocks in this portfolio.
        /// </summary>
        /// <returns>Number of shares.</returns>
        public long NumberOfShares()
        {
            long totalShares = 0;
            foreach (KeyValuePair<Stock, long> stock in Stocks)
            {
                totalShares += stock.Value;
            }

            return totalShares;
        }

        /// <summary>
        /// Value of this portfolio in the given time.
        /// </summary>
        /// <param name="timeStamp">The time.</param>
        /// <returns>Value of this portoflio.</returns>
        public decimal Value(DateTime timeStamp)
        {
            return Math.Round(Stocks.Sum(stock => Math.Round(stock.Key.GetPrice(timeStamp), 3)*stock.Value), 3);
        }

        /// <summary>
        /// Change in portfolio value for the given month and year.
        /// </summary>
        /// <param name="year">The year to calculate change from.</param>
        /// <param name="month">The month of the given year the calculate change from.</param>
        /// <returns>Change in value in percentage.</returns>
        public decimal ChangeInValue(int year, int month)
        {
            decimal startValue = Value(new DateTime(year, month, 1, 0, 0, 0, 0));
            decimal endValue = Value(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
            return Math.Round(endValue/startValue*100, 3);
        }
    }

    public class StockExchange : IStockExchange
    {
        public List<Stock> Stocks { get; private set; }
        public Stock FindStock(string name)
        {
            foreach (Stock stock in Stocks)
            {
                if (stock.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase))
                    return stock;
            }

            throw new StockExchangeException("Stock does not exist.");
        }

        public List<Index> Indices { get; private set; }
        public Index FindIndex(string name)
        {
            foreach (Index index in Indices)
            {
                if (index.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase))
                    return index;
            }

            throw new StockExchangeException("Index does not exist.");
        }

        public List<Portfolio> Portfolios { get; private set; }
        public Portfolio FindPortfolio(string name)
        {
            foreach (Portfolio portfolio in Portfolios)
            {
                if (portfolio.Name.Equals(name, StringComparison.InvariantCulture))
                    return portfolio;
            }

            throw new StockExchangeException("Portfolio does not exist.");
        }

        public StockExchange()
        {
            Stocks = new List<Stock>();
            Indices = new List<Index>();
            Portfolios = new List<Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock share = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            if (Stocks.Contains(share))
                throw new StockExchangeException("Stock with the same name already exists.");

            Stocks.Add(share);
        }

        public void DelistStock(string inStockName)
        {
            Stock selectedStock = FindStock(inStockName);
            Stocks.Remove(selectedStock);

            // remove stock from all indices
            foreach (Index index in Indices)
            {
                if (index.ContainsStock(selectedStock))
                    index.RemoveStock(selectedStock);
            }

            // remove stock from all portfolios
            foreach (Portfolio portfolio in Portfolios)
            {
                if (portfolio.ContainsStocks(selectedStock))
                    portfolio.RemoveStocks(selectedStock);
            }
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock share in Stocks)
            {
                if (share.Name.Equals(inStockName, StringComparison.InvariantCultureIgnoreCase))
                    return true;
            }

            return false;
        }

        public int NumberOfStocks()
        {
            return Stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock selectedStock = FindStock(inStockName);
            selectedStock.SetPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock selectedStock = FindStock(inStockName);
            return selectedStock.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock selectedStock = FindStock(inStockName);
            return selectedStock.Prices.First().Value;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock selectedStock = FindStock(inStockName);
            return selectedStock.Prices.Last().Value;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index = new Index(inIndexName, inIndexType);
            if (Indices.Contains(index))
                throw new StockExchangeException("Index with the same name already exists.");

            Indices.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index selectedIndex = FindIndex(inIndexName);
            Stock selectedStock = FindStock(inStockName);
            if (selectedIndex.ContainsStock(selectedStock))
                throw new StockExchangeException("Index already contains selected stock.");

            selectedIndex.AddStock(selectedStock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index selectedIndex = FindIndex(inIndexName);
            Stock selectedStock = FindStock(inStockName);
            selectedIndex.RemoveStock(selectedStock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index selectedIndex = FindIndex(inIndexName);
            Stock selectedStock = FindStock(inStockName);
            return selectedIndex.ContainsStock(selectedStock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index selectedIndex = FindIndex(inIndexName);
            return selectedIndex.Value(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            try
            {
                FindIndex(inIndexName);
                return true;
            }
            catch (StockExchangeException)
            {
                return false;
            }
        }

        public int NumberOfIndices()
        {
            return Indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index selectedIndex = FindIndex(inIndexName);
            return selectedIndex.Stocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio alredy exists.");

            Portfolio portfolio = new Portfolio(inPortfolioID);
            Portfolios.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock selectedStock = FindStock(inStockName);
            long totalStocksInPortfolios = 0;
            foreach (Portfolio portfolio in Portfolios)
            {
                if (portfolio.Stocks.ContainsKey(selectedStock))
                    totalStocksInPortfolios = portfolio.Stocks[selectedStock];
            }

            if (selectedStock.Number - totalStocksInPortfolios < numberOfShares)
                throw new StockExchangeException("The number of shares is greater then the remaining shares.");

            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            selectedPortfolio.AddStocks(selectedStock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            Stock selectedStock = FindStock(inStockName);
            selectedPortfolio.RemoveStocks(selectedStock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            Stock selectedStock = FindStock(inStockName);
            selectedPortfolio.RemoveStocks(selectedStock);
        }

        public int NumberOfPortfolios()
        {
            return Portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            return selectedPortfolio.Stocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            try
            {
                FindPortfolio(inPortfolioID);
                return true;
            }
            catch (StockExchangeException)
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            Stock selectedStock = FindStock(inStockName);
            return selectedPortfolio.ContainsStocks(selectedStock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            Stock selectedStock = FindStock(inStockName);
            return (int)selectedPortfolio.NumberOfShares(selectedStock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            return selectedPortfolio.Value(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio selectedPortfolio = FindPortfolio(inPortfolioID);
            return selectedPortfolio.ChangeInValue(Year, Month);
        }
    }
}
