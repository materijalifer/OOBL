using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        public List<Stock> stockList = new List<Stock>();
        public List<Index> indexList = new List<Index>();
        public List<Portfolio> portfolioList = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                stockList.Add(stock);
            }
            else throw new StockExchangeException("Stock already exists.");
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                if (NumberOfIndices() > 0)
                {
                    foreach (Index index in indexList.ToList())
                    {
                        RemoveStockFromIndex(index.IndexName, inStockName);
                    }
                }
                if (NumberOfPortfolios() > 0)
                {
                    foreach (Portfolio portfolio in portfolioList.ToList())
                    {
                        RemoveStockFromPortfolio(portfolio.PortfolioID, inStockName);
                    }
                }
                stockList.Remove(s);
            }
            else throw new StockExchangeException("Stock doesn't exist.");
        }

        public bool StockExists(string inStockName)
        {
            return stockList.Any(stock => stock.StockName.ToLower() == inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
            Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());

            if (s.SharePrice.Any(pts => pts.TimeStamp == inIimeStamp)) throw new StockExchangeException("Error!");
            s.SharePrice.Add(new PriceTimeStamp(inStockValue, inIimeStamp));
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
            if (inTimeStamp < s.SharePrice.First().TimeStamp) throw new StockExchangeException("Error!");

            DateTime closestTimeStamp = inTimeStamp;
            foreach (PriceTimeStamp pts in s.SharePrice)
            {
                if (pts.TimeStamp <= inTimeStamp) closestTimeStamp = pts.TimeStamp;
            }
            PriceTimeStamp priceTimeStamp = s.SharePrice.Find(pts => pts.TimeStamp == closestTimeStamp);
            return priceTimeStamp.Price;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
            PriceTimeStamp priceTimeStamp = s.SharePrice.First();
            return priceTimeStamp.Price;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
            DateTime currentTimeStamp = DateTime.Now;
            DateTime lastTimeStamp = DateTime.MinValue;
            foreach (PriceTimeStamp pts in s.SharePrice)
            {
                if (pts.TimeStamp <= currentTimeStamp && pts.TimeStamp >= lastTimeStamp) lastTimeStamp = pts.TimeStamp;
            }
            PriceTimeStamp priceTimeStamp = s.SharePrice.Find(pts => pts.TimeStamp == lastTimeStamp);
            return priceTimeStamp.Price;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {
                Index index = new Index(inIndexName, inIndexType);
                indexList.Add(index);
            }
            else throw new StockExchangeException("Index already exists.");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName))
            {
                Index i = indexList.Find(index => index.IndexName.ToLower() == inIndexName.ToLower());
                if (StockExists(inStockName))
                {
                    Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    if (!IsStockPartOfIndex(inIndexName, inStockName)) i.Stocks.Add(s);
                    else throw new StockExchangeException("Stock is already a part of index.");
                }
                else throw new StockExchangeException("Stock doesn't exist.");
            }
            else throw new StockExchangeException("Index doesn't exist.");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName))
            {
                Index i = indexList.Find(index => index.IndexName.ToLower() == inIndexName.ToLower());
                if (StockExists(inStockName))
                {
                    Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    if (IsStockPartOfIndex(inIndexName, inStockName)) i.Stocks.Remove(s);
                    else throw new StockExchangeException("Stock is not a part of index.");
                }
                else throw new StockExchangeException("Stock doesn't exist.");
            }
            else throw new StockExchangeException("Index doesn't exist.");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index i = indexList.Find(index => index.IndexName.ToLower() == inIndexName.ToLower());
            return i.Stocks.Any(stock => stock.StockName.ToLower() == inStockName.ToLower());
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName)) throw new StockExchangeException("Index doesn't exist.");
            Index i = indexList.Find(index => index.IndexName.ToLower() == inIndexName.ToLower());

            if (i.IndexType == IndexTypes.AVERAGE)
            {
                decimal sum = 0;
                foreach (Stock s in i.Stocks)
                {
                    if (inTimeStamp < s.SharePrice.First().TimeStamp) throw new StockExchangeException("Error!");
                    DateTime closestTimeStamp = inTimeStamp;
                    foreach (PriceTimeStamp pts in s.SharePrice)
                    {
                        if (pts.TimeStamp <= inTimeStamp) closestTimeStamp = pts.TimeStamp;
                    }
                    sum += s.SharePrice.Find(pts => pts.TimeStamp == closestTimeStamp).Price;
                }
                return (sum / i.Stocks.Count);
            }
            else
            {
                decimal totalSum = 0;
                decimal weightedValuePartial = 0;
                decimal weightedValue = 0;
                foreach (Stock s in i.Stocks)
                {
                    DateTime closestTimeStamp = inTimeStamp;
                    foreach (PriceTimeStamp pts in s.SharePrice)
                    {
                        if (pts.TimeStamp <= inTimeStamp) closestTimeStamp = pts.TimeStamp;
                    }
                    totalSum += s.SharePrice.Find(pts => pts.TimeStamp == closestTimeStamp).Price * s.NumberOfShares;
                }
                foreach (Stock s in i.Stocks)
                {
                    if (inTimeStamp < s.SharePrice.First().TimeStamp) throw new StockExchangeException("Error!");
                    DateTime closestTimeStamp = inTimeStamp;
                    foreach (PriceTimeStamp pts in s.SharePrice)
                    {
                        if (pts.TimeStamp <= inTimeStamp) closestTimeStamp = pts.TimeStamp;
                    }
                    weightedValuePartial = s.SharePrice.Find(pts => pts.TimeStamp == closestTimeStamp).Price * s.NumberOfShares * s.SharePrice.Find(pts => pts.TimeStamp == closestTimeStamp).Price / totalSum;
                    weightedValue += weightedValuePartial;
                }
                return weightedValue;
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return indexList.Any(index => index.IndexName.ToLower() == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return indexList.Find(index => index.IndexName.ToLower() == inIndexName.ToLower()).Stocks.Count;
            }
            else throw new StockExchangeException("Index doesn't exist.");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                portfolioList.Add(portfolio);
            }
            else throw new StockExchangeException("Portfolio already exists");
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
                if (numberOfShares <= 0) throw new StockExchangeException("Invalid stock share amount.");
                if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist.");
                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    Stock s = stockList.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    long usedShares = 0;
                    foreach (Portfolio portfolio in portfolioList)
                    {
                        if (IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName)) usedShares += portfolio.PortfolioStocks.Find(st => st.StockName.ToLower() == inStockName.ToLower()).NumberOfSharesInPortfolio;
                    }
                    if (numberOfShares < (s.NumberOfShares - usedShares)) p.PortfolioStocks.Add(new StockInPortfolio(s, numberOfShares));
                    else p.PortfolioStocks.Add(new StockInPortfolio(s, (s.NumberOfShares - usedShares)));
                }
                else
                {
                    StockInPortfolio s = p.PortfolioStocks.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    long usedShares = 0;
                    foreach (Portfolio portfolio in portfolioList)
                    {
                        if (IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName)) usedShares += portfolio.PortfolioStocks.Find(st => st.StockName.ToLower() == inStockName.ToLower()).NumberOfSharesInPortfolio;
                    }
                    if (numberOfShares > (s.NumberOfShares - usedShares)) numberOfShares = (int)(s.NumberOfShares - usedShares);
                    if (s.NumberOfShares - s.NumberOfSharesInPortfolio >= numberOfShares) s.NumberOfSharesInPortfolio += numberOfShares;
                    else s.NumberOfSharesInPortfolio = s.NumberOfShares;
                }
            }
            else throw new StockExchangeException("Portfolio doesn't exist");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    throw new StockExchangeException("Stock is not a part of portfolio.");
                }
                else
                {
                    StockInPortfolio s = p.PortfolioStocks.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    s.NumberOfSharesInPortfolio -= numberOfShares;
                    if (s.NumberOfSharesInPortfolio == 0) RemoveStockFromPortfolio(inPortfolioID, inStockName);
                }
            }
            else throw new StockExchangeException("Portfolio doesn't exist");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    throw new StockExchangeException("Stock is not a part of portfolio.");
                }
                else
                {
                    StockInPortfolio s = p.PortfolioStocks.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    p.PortfolioStocks.Remove(s);
                }
            }
            else throw new StockExchangeException("Portfolio doesn't exist");
        }

        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
            return p.PortfolioStocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolioList.Any(p => p.PortfolioID == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
                return p.PortfolioStocks.Any(stock => stock.StockName.ToLower() == inStockName.ToLower());
            }
            else throw new StockExchangeException("Portfolio doesn't exist.");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    StockInPortfolio s = p.PortfolioStocks.Find(stock => stock.StockName.ToLower() == inStockName.ToLower());
                    return (int)s.NumberOfSharesInPortfolio;
                }
                else return 0;
            }
            else throw new StockExchangeException("Portfolio doesn't exist.");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);

                DateTime closestTimeStamp = timeStamp;
                decimal sum = 0;
                foreach (StockInPortfolio s in p.PortfolioStocks)
                {
                    foreach (PriceTimeStamp pts in s.SharePrice)
                    {
                        if (pts.TimeStamp <= timeStamp) closestTimeStamp = pts.TimeStamp;
                    }
                    sum += s.SharePrice.Find(st => st.TimeStamp == closestTimeStamp).Price * s.NumberOfSharesInPortfolio;
                }
                return sum;
            }
            else throw new StockExchangeException("Portfolio doesn't exist");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolioList.Find(portfolio => portfolio.PortfolioID == inPortfolioID);

                if (Month < 1 || Month > 12) throw new StockExchangeException("Invalid month value.");
                int days = DateTime.DaysInMonth(Year, Month);
                DateTime first = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                DateTime last = new DateTime(Year, Month, days, 23, 59, 59, 999);
                DateTime min = DateTime.MinValue;
                DateTime max = DateTime.MinValue;
                decimal sum = 0;
                foreach (StockInPortfolio s in p.PortfolioStocks)
                {
                    foreach (PriceTimeStamp pts in s.SharePrice)
                    {
                        if (pts.TimeStamp > min && pts.TimeStamp <= first) min = pts.TimeStamp;
                        if (pts.TimeStamp > max && pts.TimeStamp <= last) max = pts.TimeStamp;
                    }

                    if (first == DateTime.MinValue || last == DateTime.MinValue) throw new StockExchangeException("Error!");
                    sum += ((s.SharePrice.Find(st => st.TimeStamp == max).Price - s.SharePrice.Find(st => st.TimeStamp == min).Price) / s.SharePrice.Find(st => st.TimeStamp == min).Price) * 100;
                }
                return sum;
            }
            else throw new StockExchangeException("Portfolio doesn't exist");
        }
    }

    public class Stock
    {
        private string _stockName;
        private long _numberOfShares;
        private List<PriceTimeStamp> _sharePrice = new List<PriceTimeStamp>();

        public string StockName
        {
            get { return _stockName; }
            set { _stockName = value; }
        }

        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }

        public List<PriceTimeStamp> SharePrice
        {
            get { return _sharePrice; }
            set { _sharePrice = value; }
        }

        public Stock() { }

        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            if (initialPrice <= 0 || numberOfShares <= 0)
            {
                throw new StockExchangeException("Error!");
            }
            _stockName = stockName;
            _numberOfShares = numberOfShares;
            _sharePrice.Add(new PriceTimeStamp(initialPrice, timeStamp));
        }

    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<Stock> _stocks = new List<Stock>();

        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }

        public IndexTypes IndexType
        {
            get { return _indexType; }
            set { _indexType = value; }
        }

        public List<Stock> Stocks
        {
            get { return _stocks; }
            set { _stocks = value; }
        }

        public Index(string indexName, IndexTypes indexType)
        {
            _indexName = indexName;
            _indexType = indexType;
        }

    }

    public class Portfolio
    {
        private string _portfolioID;
        private List<StockInPortfolio> _portfolioStocks = new List<StockInPortfolio>();

        public string PortfolioID
        {
            get { return _portfolioID; }
            set { _portfolioID = value; }
        }

        public List<StockInPortfolio> PortfolioStocks
        {
            get { return _portfolioStocks; }
            set { _portfolioStocks = value; }
        }

        public Portfolio(string portfolioID)
        {
            _portfolioID = portfolioID;
        }
    }

    public class StockInPortfolio : Stock
    {
        private long _numberOfSharesInPortfolio;

        public long NumberOfSharesInPortfolio
        {
            get { return _numberOfSharesInPortfolio; }
            set { _numberOfSharesInPortfolio = value; }
        }

        public StockInPortfolio(Stock stock, long numberOfSharesInPortfolio)
        {
            StockName = stock.StockName;
            NumberOfShares = stock.NumberOfShares;
            SharePrice = stock.SharePrice;
            _numberOfSharesInPortfolio = numberOfSharesInPortfolio;
        }
    }

    public class PriceTimeStamp
    {
        private decimal _price;
        private DateTime _timeStamp;

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public DateTime TimeStamp
        {
            get { return _timeStamp; }
            set { _timeStamp = value; }
        }

        public PriceTimeStamp(decimal price, DateTime timeStamp)
        {
            _price = price;
            _timeStamp = timeStamp;
        }
    }


}
