﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string stockName;
        private long numberOfShares;
        private decimal initialPrice;
        private Dictionary<DateTime, decimal> cijene = new Dictionary<DateTime,decimal>();
        private bool isPartOfIndex = false;
        private int numOfSharesInPortfolio = 0;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName == null || inTimeStamp == null)
            {
                throw new StockExchangeException("Null parametri zadani konstruktoru Stock.");
            }

            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Zadana nula ili negativan broj za Stock numberOfShares.");
            }

            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Zadana nula ili negativan broj za Stock initialPrice.");
            }

            stockName = inStockName.ToLower();
            numberOfShares = inNumberOfShares;
            initialPrice = inInitialPrice;
            cijene.Add(inTimeStamp, inInitialPrice);
        }

        public int getNumOfSharesInPortfolio()
        {
            return numOfSharesInPortfolio;
        }

        public bool putSharesInPortfolio(int count)
        {
            if (numOfSharesInPortfolio + count > numberOfShares)
            {
                return false;
            }
            else
            {
                numOfSharesInPortfolio += count;
                return true;
            }
        }

        public bool removeSharesFromPortfolio(int count)
        {
            if (numOfSharesInPortfolio - count < 0)
            {
                return false;
            }
            else
            {
                numOfSharesInPortfolio -= count;
                return true;
            }
        }

        public long getNumberOfShares()
        {
            return numberOfShares;
        }

        public void setStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (inTimeStamp == null)
            {
                throw new StockExchangeException("Null parametri zadani konstruktoru Stock.");
            }

            try
            {
                cijene.Add(inTimeStamp, inStockValue);
            } catch (System.ArgumentException)
            {
                throw new StockExchangeException("Stock cijena za to vrijeme već postoji u sustavu");
            }
        }

        public bool getIsPartOfIndex()
        {
            return isPartOfIndex;
        }

        public void setIsPartOfIndex(bool isPart)
        {
            this.isPartOfIndex = isPart;
        }

        public string getStockName()
        {
            return stockName;
        }

        public bool Equals(Stock drugi)
        {
            return drugi.stockName == this.stockName;
        }

        public decimal getInitialStockPrice()
        {
            return initialPrice;
        }

        public decimal getStockPrice(DateTime inTime)
        {
            TimeSpan razlika = TimeSpan.MaxValue;
            DateTime koji = inTime;
            foreach (DateTime d in cijene.Keys)
            {
                if (d < inTime && inTime - d < razlika)
                {
                    koji = d;
                    razlika = inTime - d;
                }
            }

            return cijene[koji];
        }

        public decimal getLastStockPrice()
        {
            DateTime max = DateTime.MinValue;
            foreach (DateTime d in cijene.Keys)
            {
                if (d > max)
                {
                    max = d;
                }
            }

            return cijene[max];
        }
    }

    public abstract class StockIndex
    {
        private IndexTypes tip;
        private string indexName;
        protected Dictionary<string, Stock> listaStock = new Dictionary<string, Stock>();

        public StockIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Null parametri zadani konstruktoru Stock.");
            }
            indexName = inIndexName.ToLower();
            tip = inIndexType;
        }

        public static StockIndex create(string inIndexName, IndexTypes inIndexType)
        {
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    return new AverageIndex(inIndexName, inIndexType);
                case IndexTypes.WEIGHTED:
                    return new WeightedIndex(inIndexName, inIndexType);
                default:
                    throw new StockExchangeException("Nepoznat index type.");
            }
        }

        public void addStockToIndex(Stock stock)
        {
            if (stock.getIsPartOfIndex())
            {
                throw new StockExchangeException("Stock već postoji u indexu");
            }

            try
            {
                listaStock.Add(stock.getStockName().ToLower(), stock);
                stock.setIsPartOfIndex(true);
            }
            catch (System.ArgumentException)
            {
                throw new StockExchangeException("Stock već postoji u indexu");
            }
        }

        public void removeStockFromIndex(string inStockName)
        {
            try
            {
                Stock s = listaStock[inStockName.ToLower()];
                s.setIsPartOfIndex(false);
                listaStock.Remove(inStockName.ToLower());
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock ne postoji u indexu");
            }

        }

        public bool isStockPartOf(string inStockName)
        {
            return listaStock.ContainsKey(inStockName.ToLower());
        }

        public bool Equals(StockIndex drugi)
        {
            return drugi.indexName == this.indexName;
        }

        public int getNumberOfStocks()
        {
            return listaStock.Count;
        }

        public abstract decimal getIndexValue(DateTime inTimeStamp);
    }

    public class AverageIndex :  StockIndex
    {
        public AverageIndex(string inIndexName, IndexTypes inIndexType) : base(inIndexName, inIndexType) { }

        public override decimal getIndexValue(DateTime inTimeStamp)
        {
            decimal ukupno = 0;
            foreach (Stock s in listaStock.Values)
            {
                ukupno += s.getStockPrice(inTimeStamp) * s.getNumberOfShares();
            }

            if (listaStock.Count > 0)
            {
                return decimal.Round(ukupno / listaStock.Count, 3);
            }
            else
            {
                return 0;
            }
        }
    }

    public class WeightedIndex : StockIndex
    {
        public WeightedIndex(string inIndexName, IndexTypes inIndexType) : base(inIndexName, inIndexType) { }

        public override decimal getIndexValue(DateTime inTimeStamp)
        {
            decimal ukupno = 0;
            foreach (Stock s in listaStock.Values)
            {
                ukupno += s.getStockPrice(inTimeStamp) * s.getNumberOfShares();
            }

            decimal weighted = 0;
            foreach (Stock s in listaStock.Values)
            {
                weighted += ((s.getNumberOfShares() * s.getStockPrice(inTimeStamp)) / ukupno) * (s.getStockPrice(inTimeStamp));
            }

            return decimal.Round(weighted, 3);
        }
    }

    public class StockPortfolio
    {
        private class StockPart
        {
            public int numberOfShares;
            public Stock stock;
        }

        private string name;
        private Dictionary<string, StockPart> listStock = new Dictionary<string, StockPart>();

        public StockPortfolio(string inName)
        {
            this.name = inName;
        }

        public void addStock(Stock s, int numberOfShares)
        {
            if (!s.putSharesInPortfolio(numberOfShares))
            {
                throw new StockExchangeException("Stock više ne može u portfelj.");
            }
            StockPart sp = new StockPart();
            sp.numberOfShares = numberOfShares;
            sp.stock = s;

            try
            {
                listStock.Add(s.getStockName().ToLower(), sp);
            }
            catch (System.ArgumentException)
            {
                sp = listStock[s.getStockName().ToLower()];
                sp.numberOfShares += numberOfShares;
            }
        }

        public void removeStock(Stock s, int numberOfShares)
        {
            if (!s.removeSharesFromPortfolio(numberOfShares))
            {
                throw new StockExchangeException("Miče se više shares nego ima na burzi.");
            }
            try
            {
                StockPart sp = listStock[s.getStockName().ToLower()];
                if (sp.numberOfShares - numberOfShares < 0)
                {
                    throw new StockExchangeException("Portfelj nema taj stock.");
                }
                sp.numberOfShares -= numberOfShares;
                if (sp.numberOfShares == 0)
                {
                    removeStock(s);
                }
            }
            catch (System.ArgumentException)
            {
                throw new StockExchangeException("Portfelj nema taj stock.");
            }
        }

        public void removeStock(Stock s)
        {
            try
            {
                StockPart sp = listStock[s.getStockName().ToLower()];
                s.removeSharesFromPortfolio(sp.numberOfShares);
                listStock.Remove(s.getStockName().ToLower());
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock ne postoji u indexu");
            }
        }

        public void removeStock(string inStockName)
        {
            try
            {
                StockPart sp = listStock[inStockName.ToLower()];
                sp.stock.removeSharesFromPortfolio(sp.numberOfShares);
                listStock.Remove(inStockName.ToLower());
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock ne postoji u indexu");
            }
        }

        public int getNumberOfStocks()
        {
            return listStock.Count;
        }

        public int getNumberOfSharesOfStock(Stock s)
        {
            try
            {
                StockPart sp = listStock[s.getStockName().ToLower()];
                return sp.numberOfShares;
            }
            catch (System.ArgumentException)
            {
                throw new StockExchangeException("Portfelj nema taj stock.");
            }
        }

        public bool isStockPartOf(Stock s)
        {
            return listStock.ContainsKey(s.getStockName().ToLower());
        }

        public decimal getPortfolioValue(DateTime inTime)
        {
            decimal value = 0;
            foreach (StockPart sp in listStock.Values)
            {
                value += sp.numberOfShares * sp.stock.getStockPrice(inTime);
            }

            return decimal.Round(value, 3);
        }

        public decimal getPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime start = new DateTime(Year, Month, 0, 0, 0, 00, 00);
            DateTime stop = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            decimal valueStart = 0, valueStop = 0;
            foreach (StockPart sp in listStock.Values)
            {
                valueStart += sp.stock.getStockPrice(start) * sp.numberOfShares;
                valueStop += sp.stock.getStockPrice(stop) * sp.numberOfShares;
            }

            return 100 * (valueStop - valueStart) / valueStart;
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> listaStock = new Dictionary<string, Stock>();
        private Dictionary<string, StockIndex> listaIndex = new Dictionary<string, StockIndex>();
        private Dictionary<string, StockPortfolio> listaPortfolio = new Dictionary<string, StockPortfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                listaStock.Add(inStockName.ToLower(), new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            } catch (System.ArgumentException)
            {
                throw new StockExchangeException("Stock već postoji u sustavu");
            }
            
        }

        public void DelistStock(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null naziv Stock-a.");
            }
            if (!listaStock.Remove(inStockName.ToLower()))
            {
                throw new StockExchangeException("Stock ne postoji u sustavu");
            }

            foreach (StockIndex s in listaIndex.Values)
            {
                try
                {
                    s.removeStockFromIndex(inStockName.ToLower());
                }
                catch (StockExchangeException)
                {
                    // ignore
                }
            }

            foreach (StockPortfolio p in listaPortfolio.Values)
            {
                try
                {
                    p.removeStock(inStockName.ToLower());
                }
                catch (StockExchangeException)
                {
                    // ignore
                }
            }
        }

        public bool StockExists(string inStockName)
        {
            if (inStockName == null)
            {
                return false;
            }
            return listaStock.ContainsKey(inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return listaStock.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null naziv Stock-a.");
            }

            try
            {
                listaStock[inStockName.ToLower()].setStockPrice(inIimeStamp, inStockValue);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null naziv Stock-a.");
            }

            try
            {
                return listaStock[inStockName.ToLower()].getStockPrice(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null naziv Stock-a.");
            }

            try
            {
                return listaStock[inStockName.ToLower()].getInitialStockPrice();
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null naziv Stock-a.");
            }

            try
            {
                return listaStock[inStockName.ToLower()].getLastStockPrice();
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                listaIndex.Add(inIndexName.ToLower(), StockIndex.create(inIndexName, inIndexType));
            }
            catch (System.ArgumentException)
            {
                throw new StockExchangeException("Stock već postoji u sustavu");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (inIndexName == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }
            
            try
            {
                listaIndex[inIndexName.ToLower()].addStockToIndex(s);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji index");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (inIndexName == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                listaIndex[inIndexName.ToLower()].removeStockFromIndex(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji index");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (inIndexName == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return listaIndex[inIndexName.ToLower()].isStockPartOf(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji index");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (inIndexName == null || inTimeStamp == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return listaIndex[inIndexName.ToLower()].getIndexValue(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji index");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return listaIndex.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return listaIndex.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return listaIndex[inIndexName.ToLower()].getNumberOfStocks();
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji index");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                listaPortfolio.Add(inPortfolioID, new StockPortfolio(inPortfolioID));
            }
            catch (System.ArgumentException)
            {
                throw new StockExchangeException("Stock već postoji u sustavu");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (inPortfolioID == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }

            try
            {
                listaPortfolio[inPortfolioID].addStock(s, numberOfShares);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (inPortfolioID == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }

            try
            {
                listaPortfolio[inPortfolioID].removeStock(s, numberOfShares);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (inPortfolioID == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }

            try
            {
                listaPortfolio[inPortfolioID].removeStock(s);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public int NumberOfPortfolios()
        {
            return listaPortfolio.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return listaPortfolio[inPortfolioID].getNumberOfStocks();
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Null parametri.");
            }
            return listaPortfolio.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (inPortfolioID == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }

            try
            {
                return listaPortfolio[inPortfolioID].isStockPartOf(s);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (inPortfolioID == null || inStockName == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            Stock s = null;
            try
            {
                s = listaStock[inStockName.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji stock");
            }

            try
            {
                return listaPortfolio[inPortfolioID].getNumberOfSharesOfStock(s);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (inPortfolioID == null || timeStamp == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return listaPortfolio[inPortfolioID].getPortfolioValue(timeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Null parametri.");
            }

            try
            {
                return decimal.Round(listaPortfolio[inPortfolioID].getPercentChangeInValueForMonth(Year, Month), 3);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Ne postoji portfelj");
            }
        }
    }
}
