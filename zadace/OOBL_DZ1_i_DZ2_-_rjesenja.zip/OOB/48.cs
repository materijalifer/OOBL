﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Factory
	{
		public static ICalculator CreateCalculator()
		{
			// vratiti kalkulator
			return new Kalkulator();
		}
	}

	public enum CalculatorState
	{
		InitialState,
		Calculating,
		CommaAdded,
		DecimalNumber,
		Error
	}

	public class Kalkulator : ICalculator
	{
		#region Članske varijable

		//varijable klase:
		CalculatorState state;
		double currentNumber;
		double previousNumber;
		double memory;
		int noDigits;
		int? decimalCommaPosition;
		int? minusPostion;
		char? currentBinaryOperator;
		string displayState;

		#endregion

		#region Konstruktor

		public Kalkulator()
		{
			ResetCalculator();
		}


		#endregion

		#region Javne metode

		public string GetCurrentDisplayState()
		{
			return displayState;
		}

		public void Press(char inPressedDigit)
        {
			switch (inPressedDigit)
			{
				case '+':
					Add();
				break;

				case '-':
					Subtract();
				break;

				case '*':
					Multiply();
				break;

				case '/':
					Divide();
				break;

				case '=':
					PerformCalculation();
				break;

				case ',':
					AddComma();
				break;

				case 'M':
					ChangeSign();
				break;

				case 'S':
					Sinus();
				break;

				case 'K':
					Cosinus();
				break;

				case 'T':
					Tangens();
				break;

				case 'Q':
					Square();
				break;

				case 'R':
					SquareRoot();
				break;

				case 'I':
					Invert();
				break;

				case 'P':
					PutMemory();
				break;

				case 'G':
					GetMemory();
				break;

				case 'C':
					ClearDisplay();
				break;

				case 'O':
					ResetCalculator();
				break;

				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					AddDigit(inPressedDigit);
				break;

				default:
					throw new Exception("Unrecognised operator: " + inPressedDigit.ToString());
			}
        }

		
	#endregion

		#region Privatne metode

		#region Sustavske operacije

		private void ResetCalculator()
		{
			state = CalculatorState.InitialState;
			currentNumber = 0;
			previousNumber = 0;
			memory = 0;
			noDigits = 1;
			decimalCommaPosition = null;
			minusPostion = null;
			currentBinaryOperator = null;
			displayState = "0";
		}

		private void ClearDisplay()
		{
			currentNumber = 0;
			displayState = "0";
		}

		private void GetMemory()
		{
			currentNumber = memory;
			string displayTemp = currentNumber.ToString();
			displayState = displayTemp.Replace(".", ",");
		}

		private void PutMemory()
		{
			memory = currentNumber;
		}

		private void AddDigit(char digit)
		{
			if ( (digit == '0') && (currentNumber == 0) ) return;
			if (noDigits == 10) return;

			if (state != CalculatorState.CommaAdded)
			{
				if (currentNumber != 0)
				{
					displayState = displayState + digit.ToString();
					noDigits++;
				}
				else
					displayState = digit.ToString();
			}

			if (state == CalculatorState.CommaAdded)
			{
				displayState = displayState + digit.ToString();
				state = CalculatorState.DecimalNumber;
			}

			string tempDisplay = displayState.Replace(",", ".");
			currentNumber = Double.Parse(tempDisplay);
		}

		private void AddComma()
		{
			if (noDigits == 10) return;
			if (state == CalculatorState.DecimalNumber) return;

			displayState = displayState + ",";
			state = CalculatorState.CommaAdded;
		}

		private void PerformCalculation()
		{
			throw new NotImplementedException();
		}

		#endregion

		#region Binarne operacije

		private void Divide()
		{
			throw new NotImplementedException();
		}

		private void Multiply()
		{
			throw new NotImplementedException();
		}

		private void Subtract()
		{
			throw new NotImplementedException();
		}

		private void Add()
		{
			throw new NotImplementedException();
		}

		#endregion

		#region Unarne operacije

		private void Invert()
		{
			throw new NotImplementedException();
		}

		private void SquareRoot()
		{
			throw new NotImplementedException();
		}

		private void Square()
		{
			throw new NotImplementedException();
		}

		private void Tangens()
		{
			throw new NotImplementedException();
		}

		private void Cosinus()
		{
			throw new NotImplementedException();
		}

		private void Sinus()
		{
			throw new NotImplementedException();
		}

		private void ChangeSign()
		{
			currentNumber *= -1;
			displayState = currentNumber.ToString();
		}

		#endregion

		#endregion
	}


}
