﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//konačna verzija

namespace PrvaDomacaZadaca_Kalkulator
{


    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public static class calcConst
    {
        public static long maxNumDisplay = 9999999999;
        public static int maxDigitDisplay = 10;
    }


    public static class Operations 
    {
        static char[] BinOps = { '+', '-', '*', '/' };
        static char[] UnOps = { 'M', 'S', 'K', 'T', 'Q', 'I','R' };
        static char[] MemOps = { 'P', 'G' };

        public static bool ContainsBinary(char op) 
        {
            return BinOps.Contains(op);
        }

        public static bool ContainsUnary(char op) 
        {
            return UnOps.Contains(op);
        }

        public static bool ContainMem(char op)
        {
            return MemOps.Contains(op);
        }
    }

    public static class OperationFactory
    {
        public static Operation createOperation(char op)
        {
           if (Operations.ContainsBinary(op))
           {
               return new BinaryOperation(op);
           }

           if (Operations.ContainsUnary(op))
           {
               return new UnaryOperation(op);
           }

           return null;                          
        }
    }


    public abstract class Operation    
    {
        protected char op;
        public abstract double Execute(Operand o1, Operand o2);

        protected double roundResult(double d)
        {
            if (d > calcConst.maxNumDisplay)
           {
               return double.NaN;
           }

           string s = d.ToString();
           int tmpLen = s.Length;
           int posebni=0;            

           if (s.Contains('-'))
           {
               posebni++;
           }

           if (s.Contains(','))
           {

               if (tmpLen > calcConst.maxDigitDisplay)
               {
                   int ispred = s.Split(',')[0].Length;
                   if (posebni == 0)
                   {
                       double temp = Math.Round(d, 10 - ispred);
                       return temp;
                   }
                   else
                   {
                       double temp = Math.Round(d, 11 - ispred);
                       return temp;
                   }
               }

               else
               {
                   return d;
               }
           }
           return d;

        }
       

    }



    public class BinaryOperation : Operation
    {
        public BinaryOperation(char op)
        {
            this.op = op;
        }
 
        public override double Execute(Operand o1, Operand o2)
        {
            if (this.op == '+')
            {
                return roundResult(o1.Value + o2.Value);
            }

            if (this.op == '*')
            {
                return roundResult(o1.Value * o2.Value);
            }

            if (this.op == '-')
            {
                return roundResult(o1.Value - o2.Value);
            }

            if (this.op == '/')
            {
                if (o2.Value != 0)
                {
                    return roundResult(o1.Value / o2.Value);
                }
                else
                {
                    return double.NaN;
                }
            }

            return double.NaN;
        }
    }

    public class UnaryOperation : Operation
    {
        public UnaryOperation(char op)
        {
            this.op = op;
        }

        public override double Execute(Operand o1, Operand o2)
        {
            if (this.op == 'M')
            {
                return roundResult(o1.Value * (-1));

            }
            if (this.op == 'S')
            {
                return roundResult(Math.Sin(o1.Value));
            }
            if (this.op == 'T')
            {
                try
                {
                    return roundResult(Math.Tan(o1.Value));
                }
                catch
                {
                    return double.NaN;
                }
            }
            if (this.op == 'Q')
            {
                return roundResult(o1.Value * o1.Value);
            }
            if (this.op == 'R')
            {
                try
                {
                    return roundResult(Math.Sqrt(o1.Value));
                }

                catch
                {
                    return double.NaN;
                }
            }

            if (this.op == 'I')
            {
                if (o1.Value != 0)
                {
                    return roundResult(1 / o1.Value);
                }
                return double.NaN;
            }

            if (this.op == 'K')
            {
                return roundResult(Math.Cos(o1.Value));
            }

            return double.NaN;

        }
    }

    public class Operand
    {
        public double Value { get; set; }
        public bool isDecimal{get; set;}
        public bool isSet { get; set; }
        private double decimalCount = 1.0f;

        public Operand()
        {
            this.isSet = false;
            this.isDecimal = false;
            this.Value=0;
        }

        public void setValue(string val)
        {

            string s = this.Value.ToString();
            int tmpLen = s.Length;
            if (s.Contains('-'))
            {
                tmpLen -= 1;
            }
            if (s.Contains(','))
            {
                tmpLen -= 1;
            }

            if (tmpLen >= calcConst.maxDigitDisplay)
            {
                this.Value = double.Parse(s);
                return;
            }

            if (isDecimal)
            {
                decimalCount /= 10;
                if (this.Value >= 0)
                {
                    this.Value += (double.Parse(val) * decimalCount);
                }
                else
                {
                    this.Value -= (double.Parse(val) * decimalCount);
                }
                
            }
            else
            {
                this.Value *= 10;

                if (this.Value >= 0)
                {

                    this.Value += double.Parse(val);
                }
                else
                {
                    this.Value -= double.Parse(val);
                }

            }

            this.isSet = true;
        }


    }

    public class Kalkulator:ICalculator
    {

        private string currentDisplayState;
        Operand operand1 = new Operand();
        Operand operand2 = new Operand();
        string isBinaryPressed;
        double memory;
        string mOperation;
        double mResult;
        double mOperand;
        string previous;
        string tmpDecString;

        public Kalkulator()
        
        {
            this.currentDisplayState = "0";
            this.isBinaryPressed = "";
            previous = "";
            mOperand = 0;
            mOperation = "";
            tmpDecString = "";
            mResult = 0;
        }


        public void Press(char inPressedDigit)
        {

            if (inPressedDigit == 'P')
            {
                this.memory = double.Parse(currentDisplayState);
            }

            if (inPressedDigit == 'G')
            {
                if (!operand1.isSet)
                {
                    operand1.Value = memory;
                    currentDisplayState = operand1.Value.ToString();
                }

                else
                {
                    operand2.Value = memory;
                    currentDisplayState = operand2.Value.ToString();
                }

            }

            if (inPressedDigit == 'C') 
            {
                currentDisplayState = "0";
                mOperation = "";
                mOperand = 0;
                mResult = 0;

                if (operand1.isSet && !operand2.isSet)
                {
                    operand1 = new Operand();
                    tmpDecString = "";
                }
                else
                {
                    operand2 = new Operand();
                    tmpDecString = "";
                }
            }

            if (inPressedDigit == 'O')
            {
                operand1 = new Operand();
                operand2 = new Operand();
                currentDisplayState = "0";
                tmpDecString = "";
            }

            if ((inPressedDigit == ','))
            {
                if (this.isBinaryPressed == "")
                {
                    operand1.isDecimal = true;
                    tmpDecString = "";
                    tmpDecString += operand1.Value.ToString() + ",";
                    currentDisplayState = tmpDecString;

                }
                else 
                {
                    tmpDecString = "";
                    operand2.isDecimal = true;
                    tmpDecString += operand2.Value.ToString() + ",";
                    currentDisplayState = tmpDecString;
                }
            }               
            
            int digit;

            if (int.TryParse(inPressedDigit.ToString(), out digit)&&(currentDisplayState != "-E-")) 
            {
                if (previous == "=")
                {
                    mResult = digit;
                    operand1 = new Operand();
                    operand2 = new Operand();
                    
                }

               if ((previous!="")&& Operations.ContainsUnary(previous[0]) && (operand1.isSet) &&(isBinaryPressed=="")&&(previous!="M"))
                {
                   operand1 = new Operand(); //minus se može dodati u bilo kojem trenutku, inače, ako je bio unarni operator a unosi se iduća znamenka koja ne pripada novom operandu jer nije unesen binarni - reset operanda1
               }

                if (this.isBinaryPressed == "")
                {
                    operand1.setValue(digit.ToString());
                    if (operand1.isDecimal)
                    {
                        tmpDecString += digit.ToString();
                        currentDisplayState = tmpDecString;
                    }
                    else
                    {
                        currentDisplayState = operand1.Value.ToString();
                    }
                }
                else 
                {
                    operand2.setValue(digit.ToString());
                    if (operand2.isDecimal)
                    {
                        tmpDecString += digit.ToString();
                        currentDisplayState = tmpDecString;
                    }
                    else
                    {
                        currentDisplayState = operand2.Value.ToString();
                    }
                }
            }

            //obrada binarnih operacija
            if (Operations.ContainsBinary(inPressedDigit) )
            {

                if ((isBinaryPressed != "") && (operand2.isSet))
                {
                    Operation op = OperationFactory.createOperation(isBinaryPressed[0]);
                    operand1.Value = op.Execute(operand1, operand2);
                    currentDisplayState = operand1.Value.ToString();
                    operand2.Value = 0;
                    isBinaryPressed = inPressedDigit.ToString();
                }

                else
                {
                    isBinaryPressed = inPressedDigit.ToString();

                    if (operand2.isSet)
                    {
                        Operation operation = OperationFactory.createOperation(inPressedDigit);
                        operand1.Value = operation.Execute(operand1, operand2);
                        currentDisplayState = operand1.Value.ToString();

                    }
                    else
                    {
                        currentDisplayState = operand1.Value.ToString();
                    }
                }
                
            }

            //obrada unarnih operacija

            if (Operations.ContainsUnary(inPressedDigit)) 
            {
                Operation operation = OperationFactory.createOperation(inPressedDigit);

                if (isBinaryPressed == "")
                {
                    currentDisplayState = operation.Execute(operand1, null).ToString();
                    operand1.Value = double.Parse(currentDisplayState);
                   
                }
                else 
                {
                    if (operand2.isSet)
                    {
                        operand2.Value = operation.Execute(operand2, null);
                        currentDisplayState = operand2.Value.ToString();
                    }
                    else
                    {
                        currentDisplayState = operation.Execute(operand1, operand2).ToString();
                    }
                }

            }

            if (inPressedDigit == '=') 
            {
                if (previous != "=")
                {
                    if((!operand2.isSet)&&(Operations.ContainsUnary(previous[0])))
                    {
                        operand2.isSet= true;
                        operand2.Value = double.Parse(currentDisplayState);
                    }


                    if (isBinaryPressed != "")
                    {
                        if ((!operand2.isSet)&&(previous!="C"))
                        {          
                            mOperation = isBinaryPressed;
                            mOperand = operand1.Value;
                            Operation operation = OperationFactory.createOperation(isBinaryPressed[0]);
                            operand1.Value = operation.Execute(operand1, operand1);
                            currentDisplayState = operand1.Value.ToString();
                            mResult = operand1.Value;
                            previous = "=";
                            isBinaryPressed = "";
                        }
                        else
                        {
                            mOperation = isBinaryPressed;
                            mOperand = operand2.Value;
                            Operation operation = OperationFactory.createOperation(isBinaryPressed[0]);
                            operand1.Value = operation.Execute(operand1, operand2);
                            mResult = operand1.Value;
                            previous = "=";
                            isBinaryPressed = "";
                            currentDisplayState = operand1.Value.ToString();
                            operand2 = new Operand();
                        }
                    }

                    else
                    {
                        currentDisplayState = operand1.Value.ToString();
                    }
                }
                else
                {
                    if ((mOperation != "") && (Operations.ContainsBinary(mOperation[0])))
                    {

                        Operation o = OperationFactory.createOperation(mOperation[0]);
                        Operand tmp1 = new Operand();
                        Operand tmp2 = new Operand();
                        tmp1.Value = mResult;
                        tmp2.Value = mOperand;
                        operand1.Value = o.Execute(tmp1, tmp2);
                        mResult = operand1.Value;
                        currentDisplayState = operand1.Value.ToString();
                    }
                }

            }
            previous = inPressedDigit.ToString();
        }

        public string GetCurrentDisplayState()
        {
            if (this.currentDisplayState == Double.NaN.ToString())
            {
                currentDisplayState = "-E-";

            }
            return currentDisplayState.ToString();
        }
    }
}
