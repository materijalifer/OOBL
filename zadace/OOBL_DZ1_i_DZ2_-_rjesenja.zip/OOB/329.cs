﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

     public static class Factory
     {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
     }
     public static class Constants
     {
         public const int NUMBER_OF_DECIMALS = 3;
     }

     public class Stock
     {
         private string inStockName;
         private long inNumberOfShares;
         private DateAndPrice inInitialDateAndPrice;
         private Dictionary<string, DateAndPrice> inDatesAndPrices = new Dictionary<string, DateAndPrice>();

         public Stock()
         {
         }
         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberOfShares <= 0 || inInitialPrice <= 0)
                 throw new StockExchangeException("Number of shares or initial price is equal or less zero.");
             this.inStockName = inStockName;
             this.inNumberOfShares = inNumberOfShares;
             this.inInitialDateAndPrice = new DateAndPrice(inInitialPrice, inTimeStamp);
         }

         public void addStockDateAndPrice(DateTime inTimeStamp, decimal inStockValue)
         {
             string timeStamp = inTimeStamp.ToString() + inTimeStamp.Millisecond.ToString();
             
             //ako se dodaje vrijeme prije vremena nastanka dionice
             if (DateTime.Compare(inTimeStamp, this.inInitialDateAndPrice.InTimeStamp) < 0)
             //throw new StockExchangeException("You are adding stock(" + this.inStockName + ") date and price before stock is defined");
             {
                 this.inDatesAndPrices.Add(timeStamp, new DateAndPrice(this.inInitialDateAndPrice.InPrice, this.inInitialDateAndPrice.InTimeStamp));
                 this.inInitialDateAndPrice = new DateAndPrice(inStockValue, inTimeStamp);
                 return;
             }
             //ako za to vrijeme nije zabilježena cijena dodaj cijenu dionice u pripadajućem datumu
             if (!this.inDatesAndPrices.ContainsKey(timeStamp))
             {
                 this.inDatesAndPrices.Add(timeStamp, new DateAndPrice(inStockValue, inTimeStamp));
             }
             else
                 throw new StockExchangeException("For stock:" + this.inStockName + " price for date " + timeStamp +
                                                    "already exists.");
         }
         public decimal getStockPrice(DateTime inTimeStamp)
         {
             DateAndPrice lastDateAndPrice = this.inInitialDateAndPrice;

             //ako se traži cijena dionice prije nego što je dionica stvorena
             if (DateTime.Compare(inTimeStamp, lastDateAndPrice.InTimeStamp) < 0)
                 throw new StockExchangeException("You ask for stock(" + this.inStockName + ") price before stock is defined.");
             
             foreach (KeyValuePair<string, DateAndPrice> dateAndPrice in this.inDatesAndPrices)
             {
                 if (DateTime.Compare(lastDateAndPrice.InTimeStamp, dateAndPrice.Value.InTimeStamp) <= 0 &&
                     DateTime.Compare(dateAndPrice.Value.InTimeStamp, inTimeStamp) <= 0)
                 {
                     lastDateAndPrice = dateAndPrice.Value;
                 }
             }
             return lastDateAndPrice.InPrice;
         }
         public decimal getInitialStockPrice()
         {
             return this.inInitialDateAndPrice.InPrice;
         }
         public decimal getLastStockPrice()
         {
             DateAndPrice lastDateAndPrice = this.inInitialDateAndPrice;
             foreach (KeyValuePair<string, DateAndPrice> dateAndPrice in this.inDatesAndPrices)
             {
                 if (DateTime.Compare(lastDateAndPrice.InTimeStamp, dateAndPrice.Value.InTimeStamp) < 0)
                 {
                     lastDateAndPrice = dateAndPrice.Value;
                 }
             }
             return lastDateAndPrice.InPrice;
         }
         
         public string InStockName { get { return this.inStockName; } set { this.inStockName = value; } }
         public long InNumberOfShares { get { return this.inNumberOfShares; } set { this.inNumberOfShares = value; } }
         public DateAndPrice InDateAndPrice { get { return this.inInitialDateAndPrice; } set { this.inInitialDateAndPrice = value; } }
     }
     public class DateAndPrice
     {
         private decimal inPrice;
         private DateTime inTimeStamp;

         public DateAndPrice(decimal inPrice, DateTime inTimeStamp)
         {
             this.inPrice = inPrice;
             this.inTimeStamp = inTimeStamp;
         }
         
         public decimal InPrice { get { return this.inPrice; } set { this.inPrice = value; } }
         public DateTime InTimeStamp { get { return this.inTimeStamp; } set { this.inTimeStamp = value; } }

         public override string ToString()
         {
             return this.inTimeStamp.ToString() + this.inTimeStamp.Millisecond.ToString();
         }
     }

     public class Index
     {
         private string inIndexName;
         private ICalculateIndexValue indexValue;
         private Dictionary<string, Stock> inIndexStocks = new Dictionary<string, Stock>();

         public Index()
         {
         }
         public Index(string inIndexName, IndexTypes inIndexType)
         {       
             this.inIndexName = inIndexName.ToUpper();
             defineIndexType(inIndexType);
         }

         public void defineIndexType(IndexTypes inIndexType)
         {
             if (inIndexType == IndexTypes.AVERAGE)
                 this.indexValue = new CalculateAverageIndex();
             else if (inIndexType == IndexTypes.WEIGHTED)
                 this.indexValue = new CalculateWeightedIndex();
             else
                 throw new StockExchangeException("You can't define another index beside AVERAGE and WEIGHTED.");
         }
         public void addStockToIndex(Stock inStock)
         {
             if (!this.inIndexStocks.ContainsKey(inStock.InStockName))
             {
                 this.inIndexStocks.Add(inStock.InStockName, inStock);
             }
             else
                 throw new StockExchangeException("Stock " + inStock.InStockName + " already exists in index " + this.inIndexName);
         }
         public void removeStockFromIndex(string inStockName)
         {
             if (this.inIndexStocks.ContainsKey(inStockName))
             {
                 this.inIndexStocks.Remove(inStockName);
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exists in index " + 
                                                     this.inIndexName + " so you can't remove it from index.");
         }
         public bool isStockPartOfIndex(string inStockName)
         {
             if (this.inIndexStocks.ContainsKey(inStockName))
                 return true;
             else
                 return false;
         }
         public int numberOfStocksInIndex()
         {
             return this.inIndexStocks.Keys.Count;
         }
         public decimal getIndexValue(DateTime inTimeStamp)
         {
             return this.indexValue.calculateIndexValue(this.inIndexStocks, inTimeStamp);
         }
     }
     public interface ICalculateIndexValue
     {
         decimal calculateIndexValue(Dictionary<string, Stock> stocks, DateTime inTimeStamp);
     }
     public class CalculateAverageIndex: ICalculateIndexValue
     {
         public CalculateAverageIndex()
         {
         }

         public decimal calculateIndexValue(Dictionary<string, Stock> stocks, DateTime inTimeStamp)
         {
             int stockNumber = 0;
             decimal result = 0;

             foreach (KeyValuePair<string, Stock> stock in stocks)
             {
                 stockNumber++;
                 result += stock.Value.getStockPrice(inTimeStamp);
             }
             if (stockNumber == 0)
                 return 0;
             result = (decimal)(result / stockNumber);
             return Math.Round(result, Constants.NUMBER_OF_DECIMALS);
         }
     }
     public class CalculateWeightedIndex : ICalculateIndexValue
     {
         public CalculateWeightedIndex()
         {
         }

         public decimal calculateIndexValue(Dictionary<string, Stock> stocks, DateTime inTimeStamp)
         {
             decimal result = 0;
             decimal allCount = stocks.Values.Sum(x => x.getStockPrice(inTimeStamp) * x.InNumberOfShares);
             foreach (KeyValuePair<string, Stock> stock in stocks)
             {
                 decimal weightFactor = (decimal)(stock.Value.getStockPrice(inTimeStamp) / allCount);
                 result += stock.Value.getStockPrice(inTimeStamp) * weightFactor * stock.Value.InNumberOfShares;
             }

             if (result == 0)
                 return 0;
             else
                 return Math.Round(result, Constants.NUMBER_OF_DECIMALS);
         }
     }

     public class Portfolio
     {
         private string inPortfolioID;
         private Dictionary<string, int> inPortfolioStocks = new Dictionary<string, int>();

         public Portfolio()
         {
         }
         public Portfolio(string inPortfolioID)
         {
             this.inPortfolioID = inPortfolioID;
         }

         public int numberOfStocksInPortfolio()
         {
             return this.inPortfolioStocks.Keys.Count;
         }
         public int numberOfSharesOfStockInPortfolio(string inStockName)
         {
             if (isStockPartOfPortfolio(inStockName))
             {
                 return (int)this.inPortfolioStocks[inStockName];
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " is not part of portfolio " + this.inPortfolioID + ".");
         }
         public bool isStockPartOfPortfolio(string inStockName)
         {
             if (this.inPortfolioStocks.ContainsKey(inStockName))
                 return true;
             else
                 return false;
         }
         public void addStockToPortfolio(string inStockName, int numberOfShares)
         {
             if (!isStockPartOfPortfolio(inStockName))
             {
                 //dodaj dionicu u portfelj
                 this.inPortfolioStocks.Add(inStockName, numberOfShares);
             }
             else
             {
                 this.inPortfolioStocks[inStockName] += numberOfShares;
             }
         }
         public void removeStockFromPortfolio(string inStockName)
         {
             if (isStockPartOfPortfolio(inStockName))
             {
                 this.inPortfolioStocks.Remove(inStockName);
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " isn't part of portfolio " + this.inPortfolioID + ".");
         }
         public void removeStockSharesFromPortfolio(string inStockName, int inNumberOfShares)
         {
             if (isStockPartOfPortfolio(inStockName))
             {
                 //ako je udio koji želimo maknuti iz portfelja manji ili jednak udjelu dionice koji portfelj sadrži makni udio
                 if (this.inPortfolioStocks[inStockName] >= inNumberOfShares)
                 {
                     this.inPortfolioStocks[inStockName] -= inNumberOfShares;
                     //ako više nema udjela neke dionice na portfelju obriši tu dionicu s portfelja
                     if (this.inPortfolioStocks[inStockName] == 0)
                     {
                         removeStockFromPortfolio(inStockName);
                     }
                 }
                 else
                     throw new StockExchangeException("You are trying to remove too many shares from portfolio stock.");
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " isn't part of portfolio " + this.inPortfolioID + ".");
         }
         public decimal getPortfolioValue(Dictionary<string, Stock> stocks, DateTime inTimeStamp)
         {
             decimal result = 0;
             foreach (KeyValuePair<string, Stock> stock in stocks)
             {
                 if (isStockPartOfPortfolio(stock.Key))
                     result += stock.Value.getStockPrice(inTimeStamp) * this.inPortfolioStocks[stock.Key];
             }
             return result;
         }
         public decimal GetPortfolioPercentChangeInValueForMonth(Dictionary<string, Stock> stocks, int Year, int Month)
         {
             decimal monthStartPrice = 0;
             DateTime monthStart = new DateTime(Year,Month, 1, 0, 0, 00, 00);
             decimal monthEndPrice = 0;
             DateTime monthEnd = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             foreach (KeyValuePair<string, int> stock in this.inPortfolioStocks)
             {
                 decimal stockPriceMonthStart = 0;
                 decimal stockPriceMonthEnd = 0;
                 //try
                 //{
                     stockPriceMonthStart = stocks[stock.Key].getStockPrice(monthStart);
                 //}
                 //catch (Exception ex)
                 //{ }
                 monthStartPrice += stockPriceMonthStart;
                 //try
                 //{
                     stockPriceMonthEnd = stocks[stock.Key].getStockPrice(monthEnd);
                 //}
                 //catch (Exception ex)
                 //{ }
                 monthEndPrice += stockPriceMonthEnd;
             }
             if (monthStartPrice == 0)
                 return 0;
             return Math.Round(((monthEndPrice - monthStartPrice) / monthStartPrice * 100m), Constants.NUMBER_OF_DECIMALS);
         }
     }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
         private Dictionary<string, Index> indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

         //dodaje dionicu s početnom cijenom na burzu
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             //ako dionica ne postoji na burzi, dodaj ju
             if (!StockExists(inStockName))
             {
                 this.stocks.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
             }
             //inače baci grešku
             else
                 throw new StockExchangeException("Can't add stock to stock exchange, stock " + inStockName + " already exists.");
         }
         //briše dionicu s burze
         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             //ako dionica postoji na burzi obriši ju
             if (StockExists(inStockName))
             {
                 foreach(KeyValuePair<string, Index> index in this.indices)
                 {
                     try
                     {
                         RemoveStockFromIndex(index.Key, inStockName);
                     }
                     catch (Exception ex)
                     { }
                 }
                 foreach (KeyValuePair<string, Portfolio> portfolio in this.portfolios)
                 {
                     try
                     {
                         RemoveStockFromPortfolio(portfolio.Key, inStockName);
                     }
                     catch (Exception ex)
                     { }
                 }
                 this.stocks.Remove(inStockName);
             }
             //inače baci grešku
             else
                 throw new StockExchangeException("Can't delete stock from stock exchange, stock " + inStockName + " doesn't exist");
         }
         //provjerava postoji li tražena dionica na burzi
         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (this.stocks.ContainsKey(inStockName))
                 return true;
             else
                 return false;
         }
         //vraća broj dionica na burzi
         public int NumberOfStocks()
         {
             return this.stocks.Keys.Count;
         }
         //postavlja cijenu dionice za određeno vrijeme
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 this.stocks[inStockName].addStockDateAndPrice(inIimeStamp, inStockValue);
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist you can't" +
                                                   "set price for defined time either :).");
         }
         //dohvaća cijenu dionice za neko vrijeme
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return this.stocks[inStockName].getStockPrice(inTimeStamp);
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist so the" +
                                                   " price for defined time doesn't exist either :).");
         }
         //dohvaća početnu cijenu dionice
         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return this.stocks[inStockName].getInitialStockPrice();
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist so the" +
                                                   "initial stock price for defined time doesn't exist either :).");
         }
         //dohvaća zadnju cijenu dionice
         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return this.stocks[inStockName].getLastStockPrice();
             }
             else
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist so the" +
                                                   "last stock price for defined time doesn't exist either :).");
         }
         //stvara novi indeks na burzi
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToUpper();
             if (!IndexExists(inIndexName))
             {
                 this.indices.Add(inIndexName, new Index(inIndexName, inIndexType));
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " already exist on stock exchange.");
         }
         //dodaje dionicu u indeks
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 this.indices[inIndexName].addStockToIndex(this.stocks[inStockName]);
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist or stock " + inStockName 
                     + " doesn't exist on stock exchange.");
         }
         //briše dionicu iz indeksa
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 this.indices[inIndexName].removeStockFromIndex(inStockName);
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist or stock " + inStockName
                     + " doesn't exist on stock exchange.");
         }
         //provjerava je li dionica u indeksu
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 return this.indices[inIndexName].isStockPartOfIndex(inStockName);
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist or stock " + inStockName
                     + " doesn't exist on stock exchange.");
         }
         //dohvaća vrijednost indeksa
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();
             if (IndexExists(inIndexName))
             {
                 return this.indices[inIndexName].getIndexValue(inTimeStamp);
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist so you can't " 
                                                     + "calculate index value.");
         }
         //provjerava postoji li traženi indeks na burzi
         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             if (this.indices.ContainsKey(inIndexName))
                 return true;
             else
                 return false;
         }
         //dohvaća broj indeksa na burzi
         public int NumberOfIndices()
         {
             return this.indices.Keys.Count;
         }
         //dohvaća broj dionica u traženom indeksu
         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             if (IndexExists(inIndexName))
             {
                 return this.indices[inIndexName].numberOfStocksInIndex();
             }
             else
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist on stock exchange.");
         }
         //stvara novi portfelj na burzi
         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 this.portfolios.Add(inPortfolioID, new Portfolio());
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " already exists on stock exchange.");
         }
         //dodaje određeni broj dionica u portfelju
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 //koliko udjela dionice ima na burzi
                 int inSharesOnStockExchange = (int)this.stocks[inStockName].InNumberOfShares;
                 //koliko je udjela zauzeto po portfeljima
                 int inSharesOnPortfolios = 0;
                 foreach (KeyValuePair<string, Portfolio> portfolio in this.portfolios)
                 {
                     if (portfolio.Value.isStockPartOfPortfolio(inStockName))
                     {
                         inSharesOnPortfolios += portfolio.Value.numberOfSharesOfStockInPortfolio(inStockName);
                     }
                 }
                 //je li moguće obaviti dodavanje
                 if (inSharesOnStockExchange - inSharesOnPortfolios >= numberOfShares)
                 {
                     portfolios[inPortfolioID].addStockToPortfolio(inStockName, numberOfShares);
                 }
                 else
                     throw new StockExchangeException("Can't add shares to portfolio, there are not enough avaliable shares on stock exchange.");
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " or stock " + inStockName +
                                                       " doesn't exist on stock exchange.");
         }
         //briše određeni broj dionica iz portfelja
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 //obriši udio dionice iz portfelja
                 this.portfolios[inPortfolioID].removeStockSharesFromPortfolio(inStockName, numberOfShares);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " or stock " + inStockName +
                                                       " doesn't exist on stock exchange.");
         }
         //briše dionicu iz portfelja 
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 //obriši dionicu iz portfelja
                 this.portfolios[inPortfolioID].removeStockFromPortfolio(inStockName);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " or stock " + inStockName +
                                                       " doesn't exist on stock exchange.");
         }
         //dohvaća broj portfelja na burzi
         public int NumberOfPortfolios()
         {
             return this.portfolios.Keys.Count;
         }
         //dohvaća broj dionica u traženom portfelju
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return this.portfolios[inPortfolioID].numberOfStocksInPortfolio();
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " already exists on stock exchange.");
         }
         //provjerava postoji li traženi portfelj na burzi
         public bool PortfolioExists(string inPortfolioID)
         {
             if (this.portfolios.ContainsKey(inPortfolioID))
                 return true;
             else
                 return false;
         }
         //provjerava nalazi li se dionica u portfelju
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (PortfolioExists(inPortfolioID))
             {
                 return this.portfolios[inPortfolioID].isStockPartOfPortfolio(inStockName);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " doesn't exists on stock exchange.");
         }
         //dohvaća broj dionice u traženom portfelj
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (PortfolioExists(inPortfolioID))
             {
                 return this.portfolios[inPortfolioID].numberOfSharesOfStockInPortfolio(inStockName);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " doesn't exists on stock exchange.");
         }
         //dohvaća vrijednost portfelja u određenom trenutku
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return this.portfolios[inPortfolioID].getPortfolioValue(this.stocks, timeStamp);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " doesn't exists on stock exchange.");
         }
         //dohvaća mjeseću promjenu vrijednosti portfelja
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return this.portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(this.stocks, Year, Month);
             }
             else
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " doesn't exists on stock exchange.");
         }
   }
}
