﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string _ekran;
        private string _memorija;
        private double _prosliOperand;
        private char _zadnjiBinarniOperator;
        private bool _maloprijePritisnutaBinarnaOperacija;          //[true] uzastopno su unošeni binarni operatori
        private bool _trebaOcistitiEkran;                           //[true] sljedeće pisanje po ekranu briše trenutnu vrijednost ekrana
        private bool _error;                                        //[true] došlo do greške, treba resetirati kalkulator
        private const int MAXBROJZNAMENKI = 10;                     //maksimalan broj znamenki na ekranu

        public Kalkulator()
        {
            Reset();
        }

        public void Press(char inPressedDigit)
        {
            if (_error == true)
            {
                switch (inPressedDigit)
                {
                    case 'O':
                        Reset();
                        return;
                    default:
                        return;
                }
            }
            switch (inPressedDigit)
            {
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    DodajZnamenku(inPressedDigit);
                    break;
                case '+':
                case '-':
                case '*':
                case '/':
                    BinarnaOperacija(inPressedDigit);
                    return;
                case '=':
                    _maloprijePritisnutaBinarnaOperacija = false;
                    BinarnaOperacija(inPressedDigit);
                    _maloprijePritisnutaBinarnaOperacija = false;
                    _trebaOcistitiEkran = false;
                    _zadnjiBinarniOperator = ' ';
                    break;
                case ',':
                    DodajZarez();
                    break;
                case 'M':                                                       //mijenjanje predznaka
                    if (_ekran.First() != '-')
                        _ekran = _ekran.Insert(0, "-");
                    else _ekran = _ekran.Remove(0, 1);
                    ZaokruziEkran();
                    break;
                case 'S':                                                       //sinus
                    _ekran = Math.Sin(Double.Parse(_ekran)).ToString();
                    ZaokruziEkran();
                    _trebaOcistitiEkran = true;
                    break;
                case 'K':                                                       //kosinus
                    _ekran = Math.Cos(Double.Parse(_ekran)).ToString();
                    ZaokruziEkran();
                    _trebaOcistitiEkran = true;
                    break;
                case 'T':                                                       //tangens
                    if (Math.Cos(Double.Parse(_ekran)) == 0)
                    {
                        Error();
                        return;
                    }
                    _ekran = Math.Tan(Double.Parse(_ekran)).ToString();
                    ZaokruziEkran();
                    _trebaOcistitiEkran = true;
                    break;
                case 'Q':                                                       //kvadriranje
                    _ekran = Math.Pow(Double.Parse(_ekran), 2).ToString();
                    ZaokruziEkran();
                    if (BrojZnamenkiNaEkranu() > 10)
                    {
                        Error();
                        return;
                    }
                    _trebaOcistitiEkran = true;
                    break;
                case 'R':                                                       //korjenovanje
                    if (Double.Parse(_ekran) < 0)
                    {
                        Error();
                        return;
                    }
                    _ekran = Math.Sqrt(Double.Parse(_ekran)).ToString();
                    ZaokruziEkran();
                    _trebaOcistitiEkran = true;
                    break;
                case 'I':                                                       // 1 / x
                    if (Double.Parse(_ekran).Equals(0))
                    {
                        Error();
                        return;
                    }
                    _ekran = (1.0 / (Double.Parse(_ekran))).ToString();
                    ZaokruziEkran();
                    _trebaOcistitiEkran = true;
                    break;
                case 'P':                                                       //spremi u memoriju
                    _memorija = _ekran;
                    break;
                case 'G':                                                       //dohvati iz memorije
                    _ekran = _memorija;
                    break;
                case 'C':                                                       //ocisti ekran
                    _ekran = "0";
                    break;
                case 'O':                                                       //resetiraj kalkulator
                    Reset();
                    break;
                default:
                    break;
            }
            _maloprijePritisnutaBinarnaOperacija = false;

        }

        public string GetCurrentDisplayState()
        {
            return _ekran;
        }

        private void DodajZnamenku(char znamenka)
        {
            if (_trebaOcistitiEkran == true)
            {
                _ekran = "0";
                _trebaOcistitiEkran = false;
            }
            if (PreviseZnamenki())
            {
                return;
            }
            _ekran += znamenka;
            MakniVodeceNule();
        }

        private void DodajZarez()
        {
            if (_trebaOcistitiEkran == true)
            {
                _ekran = "0";
                _trebaOcistitiEkran = false;
            }
            if (_ekran.Contains(','))
                return;
            else
                _ekran += ',';
        }

        private bool PreviseZnamenki()
        {
            if (BrojZnamenkiNaEkranu() == MAXBROJZNAMENKI)
                return true;
            else 
                return false;
        }

        private void MakniVodeceNule()
        {
            if (_ekran.ElementAt(0).Equals('0'))
            {
                while (_ekran.Length>1 && _ekran.ElementAt(0).Equals(_ekran.ElementAt(0 + 1)))
                {
                    _ekran = _ekran.Remove(0, 1);
                }
                if (_ekran.Length>1 && Char.IsDigit(_ekran.ElementAt(1)))
                {
                    _ekran = _ekran.Remove(0, 1);
                }
            }
            else if (!Char.IsDigit(_ekran.ElementAt(0)) && _ekran.ElementAt(1).Equals('0'))
            {
                while (_ekran.Length > 2 && _ekran.ElementAt(1).Equals(_ekran.ElementAt(1 + 1)))
                {
                    _ekran = _ekran.Remove(1, 1);
                }
                if (_ekran.Length > 2 && Char.IsDigit(_ekran.ElementAt(2)))
                {
                    _ekran = _ekran.Remove(1, 1);
                }
            }
        }

        private void ZaokruziEkran()
        {
            int offset = _ekran.IndexOf(',');
            if (_ekran.Contains('-')) offset -= 1;
            int decimals = 10 - offset;
            if (decimals < 0)
            {
                Error();
                return;
            }

            _ekran = Math.Round(Double.Parse(_ekran), decimals).ToString();
            //pratece nule i decimalni zarez
            while (_ekran.Contains(',') && _ekran.Last().Equals('0'))
            {
                _ekran = _ekran.Remove(_ekran.Length - 1, 1);
            }
            if (_ekran.Last().Equals(','))
                _ekran = _ekran.Remove(_ekran.Length-1,1);
        }

        private void BinarnaOperacija(char znak)
        {

            if (!_zadnjiBinarniOperator.Equals(' ') && _maloprijePritisnutaBinarnaOperacija == false)
            {
                switch (_zadnjiBinarniOperator)
                {
                    case '+':
                        _ekran = (_prosliOperand + Double.Parse(_ekran)).ToString();
                        if (BrojZnamenkiNaEkranu() > 10)
                        {
                            Error();
                            return;
                        }
                        break;
                    case '-':
                        _ekran = (_prosliOperand - Double.Parse(_ekran)).ToString();
                        if (BrojZnamenkiNaEkranu() > 10)
                        {
                            Error();
                            return;
                        }
                        break;
                    case '*':
                        _ekran = (_prosliOperand * Double.Parse(_ekran)).ToString();
                        if (BrojZnamenkiNaEkranu() > 10)
                        {
                            Error();
                            return;
                        }
                        break;
                    case '/':
                        if (Double.Parse(_ekran).Equals(0))
                        {
                            Error();
                            return;
                        }
                        _ekran = (_prosliOperand / Double.Parse(_ekran)).ToString();
                        break;
                    default:
                        return;
                }
            }
            _prosliOperand = Double.Parse(_ekran);
            _zadnjiBinarniOperator = znak;
            _maloprijePritisnutaBinarnaOperacija = true;
            _trebaOcistitiEkran = true;
            ZaokruziEkran();
        }

        private int BrojZnamenkiNaEkranu()
        {
            int help = 0;
            foreach (Char x in _ekran)
            {
                if (Char.IsDigit(x)) help++;
            }
            return help;
        }

        private void Error()
        {
            _ekran = "-E-";
            _error = true;
        }

        private void Reset()
        {
            _ekran = "0";
            _memorija = "0";
            _prosliOperand = 0.0;
            _zadnjiBinarniOperator = ' ';
            _maloprijePritisnutaBinarnaOperacija = false;
            _trebaOcistitiEkran = false;
            _error = false;
        }
    }
}
