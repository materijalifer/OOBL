﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange

     {

         private Dictionary<string, Stock> listedStocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
         private Dictionary<string, Portfolio> listedPortfolios = new Dictionary<string, Portfolio>();
         private Dictionary<string, Index> listedIndexes = new Dictionary<string, Index>(StringComparer.InvariantCultureIgnoreCase);
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice < 0)
             {
                 throw new StockExchangeException("Cijena nesmije biti manja od 0!");
             }
            
             if (listedStocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Postoji vec ta dionica!");
             }
             Stock stock = new Stock(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp);
             listedStocks.Add(inStockName,stock);
         }

         public void DelistStock(string inStockName)
         {
             if (!listedStocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             
             
             
             foreach (KeyValuePair<String, Index> index in listedIndexes)
             {
                 if (IsStockPartOfIndex(index.Value.name,inStockName))
                 {
                     RemoveStockFromIndex(index.Value.name, inStockName);
                 }
             }

             foreach (KeyValuePair<String, Portfolio> index in listedPortfolios)
             {
                 if (IsStockPartOfPortfolio(index.Value.ID, inStockName))
                 {
                     RemoveStockFromPortfolio(index.Value.ID, inStockName);
                 }
             }

             listedStocks.Remove(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             return listedStocks.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return listedStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             
             if (inStockValue < 0)
             {
                 throw new StockExchangeException("Manje od 0!");
             }
             listedStocks[inStockName].addPrice(inStockValue,inIimeStamp);

             foreach (KeyValuePair<String, Portfolio> index in listedPortfolios)
             {
                 if (IsStockPartOfPortfolio(index.Value.ID, inStockName))
                 {
                     index.Value.stockList[inStockName].addPrice(inStockValue,inIimeStamp);
                 }
             }
             
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             return listedStocks[inStockName].getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             return listedStocks[inStockName].getFirstPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return listedStocks[inStockName].getLastPrice();

         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Vec postoji!");
             }

             if (!Enum.IsDefined(typeof(IndexTypes), inIndexType))
             {
                 throw new StockExchangeException("Nije dozvoljeno!");
             }

             listedIndexes.Add(inIndexName,new Index(inIndexName,inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Ne postoji taj index!");
             }

             if (listedIndexes[inIndexName].containStock(inStockName))
             {
                 throw new StockExchangeException("Dionica vec pripada indexu!");
             }
             
             listedIndexes[inIndexName].addStock(inStockName, listedStocks[inStockName]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
            
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             listedIndexes[inIndexName].removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
            
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Ne postoji taj index!");
             }
             return listedIndexes[inIndexName].containStock(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             return listedIndexes[inIndexName].value(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return listedIndexes.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return listedIndexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }
             return listedIndexes[inIndexName].numOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Postoji vec taj portfolio!");
             }
             
             listedPortfolios.Add(inPortfolioID,new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }

             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }

             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                    listedStocks[inStockName].reserveShares(numberOfShares);
                    listedPortfolios[inPortfolioID].addStockExisting(inStockName,listedStocks[inStockName],numberOfShares);
                    
                    
             }
             
             else
             {
                 listedStocks[inStockName].reserveShares(numberOfShares);
                 listedPortfolios[inPortfolioID].addStockNew(inStockName, listedStocks[inStockName], numberOfShares);
             }
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }

             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }

             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica u portfoliu!");
             }

             listedPortfolios[inPortfolioID].removeStock(inStockName,listedStocks[inStockName],numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }

             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }

             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica u portfoliu!");
             }

             listedPortfolios[inPortfolioID].removeStock(inStockName, listedStocks[inStockName]);
         }

         public int NumberOfPortfolios()
         {
             return listedPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }

             return listedPortfolios[inPortfolioID].numStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return listedPortfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {

             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }
             
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }

             return listedPortfolios[inPortfolioID].containStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }
            
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica!");
             }

             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("Ne postoji vec ta dionica u portfoliu!");
             }

             return (int) listedPortfolios[inPortfolioID].numStocksShares(inStockName);

         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }

             return listedPortfolios[inPortfolioID].value(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji vec taj portfolio!");
             }
             DateTime start = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             int numDays = System.DateTime.DaysInMonth(Year, Month);
             DateTime end = new DateTime(Year, Month, numDays,23,59,59,999);

             decimal startValue = listedPortfolios[inPortfolioID].value(start);
             decimal endValue = listedPortfolios[inPortfolioID].value(end);
             
             

             if (startValue == 0 || endValue == 0)
             {
                 return 0;
             }

             decimal value = (endValue-startValue)/startValue ;

             return Math.Abs(value)*100;
         }


     }

    public class Stock
    {
        private long number { get; set; }
        private string name { get; set; }
        private List<StockPrice> priceList = new List<StockPrice>();
        public Index index = null;
        public int addedToPortfolios;

        public Stock()
        {
        }

        public Stock(String name, long number, decimal price, DateTime time)
        {
            this.name = name;
            this.number = number;
            StockPrice stockprice = new StockPrice(price, time);
            priceList.Add(stockprice);


        }

        public long getNumber()
        {
            return this.number;
        }

        public void addPrice(decimal price, DateTime date)
        {
            StockPrice stockprice = new StockPrice(price, date);
            priceList.Add(stockprice);
            if (index != null)
            {
                index.stockList[name].priceList.Add(stockprice);
            }
        }

        public decimal getPrice(DateTime time)
        {
            priceList.Sort();
            decimal thatPrice = priceList.First().price;

            foreach (StockPrice stockprice in priceList)
            {
                if (stockprice.time > time)
                {
                    return thatPrice;
                }

                else
                {
                    thatPrice = stockprice.price;
                }

            }
            return priceList.Last().price;
        }

        public decimal getFirstPrice()
        {
            priceList.Sort();
            return priceList.First().price;
        }

        public decimal getLastPrice()
        {
            priceList.Sort();
            return priceList.Last().price;

        }

        public bool hasIndex()
        {
            if (index != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void addShares(int num)
        {
            number += num;
        }

        public void removeShares(int num)
        {
            if (number < num)
            {
                throw new StockExchangeException("Nema dovoljno dionica");
            }
            number -= num;
        }

        public void reserveShares(int num)
        {
            if (addedToPortfolios + num > number)
            {
                throw new StockExchangeException("Nema dovoljno dionica");
            }
            
            addedToPortfolios += num;
        }

        public void freeShares(int num)
        {
            addedToPortfolios -= num;
        }

        public Stock clone(int num)
        {
            Stock newStock = new Stock();
            newStock.name = name;
            newStock.number = num;
            newStock.priceList = new List<StockPrice>(priceList);
            newStock.index = index;
            return newStock;
        }

    }

    public class StockPrice : IComparable<StockPrice>
    {
        public decimal price { get; set; } 
        public DateTime time { get; set; }

        public StockPrice(decimal price, DateTime time)
        {
            this.price = price;
            this.time = time;
        }

        public int CompareTo(StockPrice stockprice)
        {
            return this.time.CompareTo(stockprice.time);
        }

    }
    
    public class Portfolio
    {
        public string ID;
        public Dictionary<string, Stock> stockList = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);

        public Portfolio(string id)
        {
            this.ID = id;
        }

        
        public void addStockNew(String name,Stock stock,int num)
        {  
            stockList.Add(name,stock.clone(num));
        }

        public void addStockExisting(String name, Stock stock, int num)
        {
            stockList[name].addShares(num);
        }
        
        public void removeStock(String name,Stock stock)
        {
            stockList.Remove(name);
        }

        public void removeStock(String name, Stock stock, int num)
        {
            stockList[name].removeShares(num);
            if (stockList[name].getNumber() == 0)
            {
                stockList.Remove(name);
            }
        }

        public bool containStock(String name)
        {
            return stockList.ContainsKey(name);
        }

        public int numStocks()
        {
           return stockList.Count();
        }

        public long numStocksShares(String name)
        {
            return stockList[name].getNumber();
        }

        public decimal value(DateTime time)
        {
            decimal sum = 0;
            foreach (KeyValuePair<String, Stock> entry in stockList)
            {
                sum = sum + entry.Value.getPrice(time) * entry.Value.getNumber();
            }
           
            return Math.Round(sum , 3);
        }
    }

    public class Index
    {

        public string name;
        private IndexTypes type;
        public Index(string name, IndexTypes type)
        {
            this.name = name;
            this.type = type;
        }

        public Dictionary<string, Stock> stockList = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);

        public void addStock(string name,Stock stock)
        {
            stock.index = this;
            stockList.Add(name ,stock);
        }
        
        public void removeStock(string name)
        {
            stockList[name].index = null;
            stockList.Remove(name);
        }
        
        public bool containStock(string name)
        {
            return stockList.ContainsKey(name);
        }

        public int numOfStocks()
        {
            return stockList.Count;
        }
        
        public decimal value(DateTime time)
        {
            if (stockList.Count == 0)
            {
                return 0;
            }

            if (type == IndexTypes.AVERAGE)
            {
                decimal sum = 0;
                foreach (KeyValuePair<String, Stock> entry in stockList)
                {
                    
                    sum = sum + entry.Value.getPrice(time);
                }
                return Math.Round(sum/stockList.Count, 3);
            }
            
            else
            {
                decimal sum = 0;
                decimal sumFactors = 0;
                foreach (KeyValuePair<String, Stock> entry in stockList)
                {
                    sum = sum + entry.Value.getPrice(time) * entry.Value.getNumber();
                }
                
                foreach (KeyValuePair<String, Stock> entry in stockList)
                {
                    sumFactors = sumFactors + entry.Value.getPrice(time) * entry.Value.getPrice(time) * entry.Value.getNumber() / sum;
                }
                return Math.Round(sumFactors, 3);
            }
        }
    }
}

