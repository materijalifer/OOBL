﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {           
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private readonly Dictionary<String, Stock> stocks;
         private readonly Dictionary<String, Index> indices;
         private readonly Dictionary<String, Portfolio> portfolios;

         public StockExchange()
         {
             stocks = new Dictionary<string, Stock>();
             indices = new Dictionary<string, Index>();
             portfolios = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {

             if ( StockExists(inStockName) )
                 throw new StockExchangeException("Stock with this name already exists in the system!");

             var newStock = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(newStock.Name,newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist.");

             foreach (var index in indices.Values)
             {
                 if(index.StockExistsInIndex(inStockName))
                     index.RemoveStock(inStockName);
             }            

             foreach (var portfolio in portfolios.Values)
             {
                 if(portfolio.StockExistsInPortfolio(inStockName))
                     portfolio.RemoveStock(inStockName);
             }

             stocks.Remove(inStockName.ToLowerInvariant());
         }

         public bool StockExists(string inStockName)
         {
             return stocks.Keys.Contains(inStockName.ToLowerInvariant());
         }

         public int NumberOfStocks()
         {
             return stocks.Count; 
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't Exist");
            
             stocks[inStockName.ToLowerInvariant()].SetStockPrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock doesn't Exist");

             return stocks[inStockName.ToLowerInvariant()].GetStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock doesn't Exist");

             return stocks[inStockName.ToLowerInvariant()].GetStockPrice(StockPrice.Initial);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock doesn't Exist");

             return stocks[inStockName.ToLowerInvariant()].GetStockPrice(StockPrice.Last);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Index with ID: " + inIndexName + " already exists.");

             var newIndex = new Index(inIndexName.ToLowerInvariant(),inIndexType);
             indices.Add(inIndexName.ToLowerInvariant(),newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             var indexLower = inIndexName.ToLowerInvariant();
             var stockLower = inStockName.ToLowerInvariant();

             if (IndexExists(indexLower).Equals(false))
                 throw new StockExchangeException("Index with the name: " + inIndexName + " doesn't exist in the system.");

             if (StockExists(stockLower).Equals(false))     
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist in the system");

             var stockToIndex = stocks[stockLower];
             indices[indexLower].AddStock(stockToIndex);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if(StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist in the system.");
             if(IndexExists(inIndexName).Equals(false))
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist in the system.");

             indices[inIndexName.ToLowerInvariant()].RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock " + inStockName + " doesn't exist in the system.");
             if (IndexExists(inIndexName).Equals(false))
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist in the system.");

             return indices[inIndexName.ToLowerInvariant()].Stocks.ContainsKey(inStockName.ToLowerInvariant());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName).Equals(false))
                throw new StockExchangeException("Index doesn't exist");

             return indices[inIndexName.ToLowerInvariant()].GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.ContainsKey(inIndexName.ToLowerInvariant());
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if(IndexExists(inIndexName).Equals(false))
                 throw new StockExchangeException("Index " + inIndexName + " doesn't exist in the system.");

             return indices[inIndexName.ToLowerInvariant()].Stocks.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio already exists.");

             var portfolio = new Portfolio(inPortfolioID);
             portfolios.Add(portfolio.Name,portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist");
             if (stocks[inStockName.ToLowerInvariant()].RemainingShares < numberOfShares)
                 throw new StockExchangeException("Number of desired shares exceeds number of the remaining shares for this stock.");
             if (numberOfShares <= 0)
                 throw new StockExchangeException("Number of desired shares is invalid.");

             stocks[inStockName.ToLowerInvariant()].RemainingShares -= numberOfShares;
             portfolios[inPortfolioID].AddStock(inStockName,numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist");

             portfolios[inPortfolioID].RemoveShares(inStockName, numberOfShares);
             stocks[inStockName.ToLowerInvariant()].RemainingShares += numberOfShares;         

             if(portfolios[inPortfolioID].GetNumOfShares(inStockName).Equals(0))
                RemoveStockFromPortfolio(inPortfolioID,inStockName);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist");

             portfolios[inPortfolioID].RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if(PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");

             return portfolios[inPortfolioID].Stocks.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if(PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist");

             return portfolios[inPortfolioID].StockExistsInPortfolio(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if(PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");
             if (StockExists(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist");

             return portfolios[inPortfolioID].GetNumOfShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");

             return portfolios[inPortfolioID].GetPortfolioValue(stocks, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID).Equals(false))
                 throw new StockExchangeException("Portfolio doesn't exist.");


             return portfolios[inPortfolioID].GetPercentChangeForMonth(stocks, Year, Month);
         }
     }

     internal enum StockPrice
     {
         Initial = 1,
         Last = 2
     }

     internal class Stock
     {
         public string Name { get; set; }
         public long NumOfShares { get; set; }
         public long RemainingShares { get; set; }
         public SortedDictionary<DateTime, decimal> Prices { get; set; }

         /*
          * Provjerava se je li ispravna cijena, broj unesenih dionica i datum
          * Provjera imena se obavlja u StockExchange razredu, gdje se vodi lista dionica.
          */
         public Stock(string name, long numOfShares, Decimal initialPrice, DateTime initialMoment)
         {
             if (numOfShares <= 0) 
                 throw new StockExchangeException("Number of shares must be greater than 0");
             if (initialPrice <= 0)
                 throw new StockExchangeException("Initial stock price must be set to a number greater than 0");
             if (DateTime.TryParse(initialMoment.ToString(),out initialMoment).Equals(false))
                 throw new StockExchangeException("Date incorrect.");          

             Name = name;
             NumOfShares = numOfShares;
             RemainingShares = numOfShares;
             Prices = new SortedDictionary<DateTime, decimal> {{initialMoment, initialPrice}};
         }

         /*
          * Metoda GetStockPrice dolazi s dva različita potpisa:
          *     -Jedan za početnu i zadnju cijenu dionice; koristi se enum StockPrice
          *     -Drugi za dohvaćanje cijene u drugim trenucima
          */
         public decimal GetStockPrice(StockPrice price)
         {
             if (price.Equals(StockPrice.Initial))
                 return Prices.Values.First();
             if (price.Equals(StockPrice.Last))
                 return Prices.Values.Last();
             throw new StockExchangeException("Could not retrieve stock price for unknown reason.");
         }

         public decimal GetStockPrice(DateTime atMoment)
         {
             try
             {
                 return Prices.Last(price => price.Key <= atMoment).Value;
             }
             catch
             {
                 throw new StockExchangeException("Stock list is either empty, or the desired moment is before the initial stock enlisting date.");
             }
         }

         /* 
          * Kod postavljanja cijene pazi se da je cijena veća od 0, da je datum ispravan i da 
          * ne postoji zapis s tim time stampom.
          */ 
         public void SetStockPrice(DateTime moment, Decimal price)
         {
             if (DateTime.TryParse(moment.ToString(), out moment).Equals(false))
                 throw new StockExchangeException("Date incorrect.");
             if (Prices.ContainsKey(moment))
                 throw new StockExchangeException("Adding multiple prices to the same time stamp is not allowed.");
             if (price <= 0)
                 throw new StockExchangeException("Price must be greater than 0.");

             Prices.Add(moment, price);
         }
     }    

     internal class Index
     {
         public string Name { get; set; }
         public IndexTypes Type { get; set; }
         public Dictionary<String, Stock> Stocks { get; set; }

         /*
          * Provjerava se valjanost tipa indexa pri stvaranju objekta.
          */
         public Index(string name, IndexTypes type)
         {
             if (!type.Equals(IndexTypes.AVERAGE) && !type.Equals(IndexTypes.WEIGHTED))
                 throw new StockExchangeException("This index type is not allowed!");

             Name = name;
             Type = type;
             Stocks = new Dictionary<string, Stock>();
         }

         /*
          * Kod dodavanja dionice bitno je da index ne sadrzi dionicu istog imena 
          * (Uzevsi u obzir i pravilo o casingu)
          */
         public void AddStock(Stock stock)
         {
             if( StockExistsInIndex(stock.Name) )
                 throw new StockExchangeException("Stock " + stock.Name  + " already exists in this index.");

             Stocks.Add(stock.Name.ToLowerInvariant(),stock);
         }

         /*
          * Dionicu nije moguće maknuti iz indexa ako ona ne pripada tom indexu
          * te se odgovarajuća iznimka javlja u tom slučaju.
          */
         public void RemoveStock(string stockName)
         {
             if( StockExistsInIndex(stockName).Equals(false) )
                 throw new StockExchangeException("Stock " + stockName + " doesn't belong to index " + Name + ".");

             Stocks.Remove(stockName.ToLowerInvariant());
         }
         
         // Provjera postojanja dionice u indeksu
         public bool StockExistsInIndex(string stockName)
         {
             return Stocks.ContainsKey(stockName.ToLowerInvariant());
         }

         /*
          * "Factory" metoda za računanje vrijednosti indexa;
          * Poziva odgovarajuću metodu za računanje ovisno o tipu indexa.
          * Provjerava ispravnost datuma za koji se traž vrijednost te tipa indexa.
          */
         public decimal GetIndexValue(DateTime inTimeStamp)
         {
             if (DateTime.TryParse(inTimeStamp.ToString(), out inTimeStamp).Equals(false))
                 throw new StockExchangeException("Date incorrect.");

             if (Stocks.Count == 0)
                 return 0m;
             if (Type.Equals(IndexTypes.AVERAGE)) 
                 return GetAvgValue(inTimeStamp);
             if (Type.Equals(IndexTypes.WEIGHTED))
                 return GetWeightedValue(inTimeStamp);             
             throw new StockExchangeException("Index type provided is not supported.");
         }

         // Metoda za računanje vrijednosti težinskog indexa.      
         private decimal GetWeightedValue(DateTime inTimeStamp)
         {
             var totalStockValue = Stocks.Values.Sum(stock => stock.GetStockPrice(inTimeStamp)*(decimal) stock.NumOfShares);
             var weightedValue = Stocks.Values.Sum(stock => stock.GetStockPrice(inTimeStamp)*(stock.GetStockPrice(inTimeStamp)*(decimal) stock.NumOfShares)/totalStockValue);
             return weightedValue;
         }

         // Metoda za računanje prosječne vrijednosti indexa.
         private decimal GetAvgValue(DateTime inTimeStamp)
         {
             var value = Stocks.Values.Sum(stock => stock.GetStockPrice(inTimeStamp));
             var stocks = (decimal)Stocks.Count;
             return Math.Round(value/stocks,3);
         }
     }

     internal class Portfolio
     {
         public string Name { get; set; }
         public Dictionary<String, int> Stocks { get; set; } 

         public Portfolio(string id)
         {
             Name = id;
             Stocks = new Dictionary<string, int>();
         }

         /*
          * Ako dionica već postoji u portfelju, tada je dovoljno samo
          * promijeniti količinu njezinih pripadajućih dionica, a ako 
          * ne postoji, tada se dionica prvo dodaje u sustav.
          * Provjera broja preostalih dionica odvija se u klasi StockExchange.
          */
         public void AddStock(string stockName, int numberOfShares)
         {           
             if (Stocks.ContainsKey(stockName.ToLowerInvariant()))
                 Stocks[stockName.ToLowerInvariant()] += numberOfShares;
             else 
                 Stocks.Add(stockName.ToLowerInvariant(),numberOfShares);
         }

         // Provjera postojanja dionice u portfelju.
         public bool StockExistsInPortfolio(string stockName)
         {
             return Stocks.ContainsKey(stockName.ToLowerInvariant());
         }

         /*
          * Dionice nije moguće maknuti iz portfelja ako ne postoje u njemu i ako se
          * pokušava ukloniti više dionica no što stvarno postoji u sustavu.
          */
         public void RemoveShares(string inStockName, int numberOfShares)
         {
             if(StockExistsInPortfolio(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist in this portfolio");
             if(Stocks[inStockName.ToLowerInvariant()] < numberOfShares)
                 throw new StockExchangeException("Number of shares for this stock is smaller than prompted to remove.");

             Stocks[inStockName.ToLowerInvariant()] -= numberOfShares;
         }

         // Vraća broj shareova zadane dionicu u portfelju. Iznimka ako ne postoji dionica.
         public int GetNumOfShares(string inStockName)
         {
             if (StockExistsInPortfolio(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist in this portfolio");

             return Stocks[inStockName.ToLowerInvariant()];
         }

         // Briše postojeću dionicu iz portfelja.
         public void RemoveStock(string inStockName)
         {
             if (StockExistsInPortfolio(inStockName).Equals(false))
                 throw new StockExchangeException("Stock doesn't exist in this portfolio");

             Stocks.Remove(inStockName.ToLowerInvariant());
         }

         /* 
          * Ako je datum točan i ako su sve dionice definirane za to razdoblje, vraća 
          * vrijednost portfelja za zadani trenutak.
          */
         public decimal GetPortfolioValue(Dictionary<string, Stock> allStocks, DateTime timeStamp)
         {
             if (DateTime.TryParse(timeStamp.ToString(), out timeStamp).Equals(false))
                 throw new StockExchangeException("Date incorrect.");

             try
             {
                 return Stocks.Sum(stock => allStocks[stock.Key].GetStockPrice(timeStamp)*(decimal) stock.Value);
             }
             catch
             {
                 throw new StockExchangeException("Can't calculate value of the portfolio.");
             }
         }

         /*
          * Promjena u portfelju se računa ako u početku mjeseca nije 0 i ako je datum ispravan te
          * ako su sve dionice postojeće tokom čitavog mjeseca.
          */
         public decimal GetPercentChangeForMonth(Dictionary<string, Stock> allStocks, int year, int month)
         {
             try
             {
                 var begginingOfMonth = new DateTime(year, month, 1, 0, 0, 0, 0);
                 var endOfMonth = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
                 var valueBegginingOfMonth = GetPortfolioValue(allStocks, begginingOfMonth);

                 if (valueBegginingOfMonth.Equals(0))
                     throw new StockExchangeException("Cannot evaluate changes in portfolio.");

                 var valueEndOfMonth = GetPortfolioValue(allStocks, endOfMonth);
                 var percent = ((valueEndOfMonth - valueBegginingOfMonth) / valueBegginingOfMonth) * 100;
                 return Math.Round(percent, 3);
             }
             catch
             {
                 throw new StockExchangeException("Date is incorrect.");
             }            
         }
     }
}

