﻿/*
 Vladimir Rosancic
 0036445029
 2DZ iz Objektnog oblikovanja
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stocks;
         private List<Index> indexes;
         private List<Portfolio> portfolios;

         public StockExchange()
         {
             stocks = new List<Stock>();
             indexes = new List<Index>();
             portfolios = new List<Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             try
             {
                 if (StockExists(inStockName))
                 {
                     throw new StockExchangeException("Stock with that name already exists.");
                 }

                 Price price = new Price(inInitialPrice, inTimeStamp);
                 Stock stock = new Stock(inStockName, inNumberOfShares, price);

                 stocks.Add(stock);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void DelistStock(string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 if (stock != null)
                 {
                     foreach (Index i in indexes)
                     {
                         if(IsStockPartOfIndex(i.Name, inStockName))
                             RemoveStockFromIndex(i.Name, inStockName);
                     }
                     foreach (Portfolio p in portfolios)
                     {
                         if(IsStockPartOfPortfolio(p.PortfolioID, inStockName))
                             RemoveStockFromPortfolio(p.PortfolioID, inStockName);
                     }
                     stocks.Remove(stock);
                 
                 }
                 else
                     throw new StockExchangeException("Error: No stock with name " + inStockName);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public bool StockExists(string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 if (stock != null)
                 {
                     return true;
                 }
                 else
                     return false;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 if (stock.PriceExists(inTimeStamp))
                 {
                     throw new StockExchangeException("Price in that timestamp already exists.");
                 }
                 Price price = new Price(inStockValue, inTimeStamp);
                 stock.Prices.Add(price);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 Price price = stock.GetStockPrice(inTimeStamp);
                 return price.Value;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 Price price = stock.GetInitialStockPrice();
                 return price.Value;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 Price price = stock.GetLastStockPrice();
                 return price.Value;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             try
             {
                 if (IndexExists(inIndexName))
                 {
                     throw new StockExchangeException("Index with that name already exists.");
                 }

                 switch (inIndexType)
                 {
                     case IndexTypes.AVERAGE:
                         AverageIndex AverageIndex = new AverageIndex(inIndexName);
                         this.indexes.Add(AverageIndex);
                         break;
                     case IndexTypes.WEIGHTED:
                         WeightedIndex WeightedIndex = new WeightedIndex(inIndexName);
                         this.indexes.Add(WeightedIndex);
                         break;
                     default:
                         throw new StockExchangeException("Invalid index type.");
                 }
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 Index index = FindIndex(inIndexName);

                 if (stock != null && index != null)
                 {
                     if (IsStockPartOfIndex(inIndexName, inStockName))
                     {
                         throw new StockExchangeException("Stock in that index already exists.");
                     }
                     index.StocksInIndex.Add(stock);
                 }
                 else
                     throw new StockExchangeException("Stock or index invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 Index index = FindIndex(inIndexName);

                 if (stock != null && index != null)
                 {
                     index.StocksInIndex.Remove(stock);
                 }
                 else
                     throw new StockExchangeException("Stock or index invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             try
             {
                 Index index = FindIndex(inIndexName);
                 if (index != null)
                 {
                     if (index.IsStockPartOfIndex(inStockName))
                         return true;
                     else 
                         return false;
                 }
                 else
                     throw new StockExchangeException("Index invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             try
             {
                 Index index = FindIndex(inIndexName);
                 return index.GetIndexValue(inTimeStamp);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public bool IndexExists(string inIndexName)
         {
             try
             {
                 Index index = FindIndex(inIndexName);
                 if (index != null)
                     return true;
                 else return false;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public int NumberOfIndices()
         {
             return indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             try
             {
                 Index index = FindIndex(inIndexName);
                 if (index != null)
                 {
                     return index.StocksInIndex.Count;
                 }
                 else
                     throw new StockExchangeException("Index invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             try
             {
                 if (PortfolioExists(inPortfolioID))
                 {
                     throw new StockExchangeException("Portfolio with that ID already exists.");
                 }

                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 this.portfolios.Add(portfolio);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 Stock stock = FindStock(inStockName);
                 if (portfolio != null && stock!=null)
                 {
                     if (numberOfShares <= (stock.NumberOfShares - NumberOfSharesOfStockInPortfolios(inStockName)))
                     {
                         portfolio.SetStockInPortfolio(stock, numberOfShares); 
                     }
                     else
                     {
                         throw new StockExchangeException("Number of shares is too big.");
                     }
                 }
                 else
                     throw new StockExchangeException("Portfolio or stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 Stock stock = FindStock(inStockName);
                 if (portfolio != null && stock != null)
                 {
                     portfolio.RemoveStockFromPortfolio(stock, numberOfShares);
                 }
                 else
                     throw new StockExchangeException("Portfolio or stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 Stock stock = FindStock(inStockName);
                 if (portfolio != null && stock != null)
                 {
                     portfolio.RemoveStockFromPortfolio(stock);
                 }
                 else
                     throw new StockExchangeException("Portfolio or stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 if (portfolio != null)
                 {
                     return portfolio.GetNumberOfStocksInPortfolio();
                 }
                 else
                     throw new StockExchangeException("Portfolio invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 if (portfolio != null)
                     return true;
                 else
                     return false;
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 Stock stock = FindStock(inStockName);
                 if (portfolio != null && stock != null)
                 {
                     return portfolio.IsStockPartOfPortfolio(stock);
                 }
                 else
                     throw new StockExchangeException("Portfolio or stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 Stock stock = FindStock(inStockName);
                 if (portfolio != null && stock != null)
                 {
                     return (int)portfolio.GetNumberOfSharesOfStockInPortfolio(stock);
                 }
                 else
                     throw new StockExchangeException("Portfolio or stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public long NumberOfSharesOfStockInPortfolios(string inStockName)
         {
             try
             {
                 Stock stock = FindStock(inStockName);
                 if (stock != null)
                 {
                     long zbroj = 0;
                     foreach (Portfolio p in portfolios)
                     {
                         zbroj += p.GetNumberOfSharesOfStockInPortfolio(stock);
                     }
                     return zbroj;
                 }
                 else
                     throw new StockExchangeException("Stock invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 if (portfolio != null)
                 {
                     return portfolio.GetPortfolioValue(timeStamp);
                 }
                 else
                     throw new StockExchangeException("Portfolio invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             try
             {
                 Portfolio portfolio = FindPortfolio(inPortfolioID);
                 if (portfolio != null)
                 {
                     return portfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
                 }
                 else
                     throw new StockExchangeException("Portfolio invalid.");
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }

         public Stock FindStock(string stockName)
         {
             foreach (Stock s in stocks)
             {
                 if (s.Name.Equals(stockName, StringComparison.InvariantCultureIgnoreCase))
                 {
                     return s;
                 }                     
             }

             return null;
         }

         public Index FindIndex(string indexName)
         {
             foreach (Index i in indexes)
             {
                 if (i.Name.Equals(indexName, StringComparison.InvariantCultureIgnoreCase))
                 {
                     return i;
                 }
             }
             return null;
         }

         public Portfolio FindPortfolio(string portfolioID)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.PortfolioID.Equals(portfolioID))
                 {
                     return p;
                 }
             }
             return null;
         }

     }

     public class Stock
     {
         private String name;
         private long numberOfShares;
         private List<Price> prices = new List<Price>();
         
         public String Name
         {
             get { return name; }
             set { name = value.ToUpper(); }
         }
         
         public long NumberOfShares
         {
             get { return numberOfShares; }
             set { numberOfShares = value; }
         }
         
         public List<Price> Prices
         {
             get { return prices; }
             set { prices = value; }
         }

         public Stock(String name, long numberOfShares, Price initialPrice)
         {
             if (numberOfShares <= 0)
                 throw new StockExchangeException("Number of shares must be positive number.");

             this.name = name.ToUpper();
             this.numberOfShares = numberOfShares;
             prices.Add(initialPrice);
         }

         public Price GetStockPrice(DateTime timeStamp)
         {
             prices.Sort((x, y) => DateTime.Compare(x.TimeStamp, y.TimeStamp));
             if (timeStamp < prices.ElementAt(0).TimeStamp)
                 throw new StockExchangeException("No price for that timestamp.");
             for (int i = 0; i < prices.Count; i++)
             {
                 if(i==prices.Count-1)
                     return prices.ElementAt(i);
                 if (timeStamp >= prices.ElementAt(i).TimeStamp && timeStamp < prices.ElementAt(i+1).TimeStamp)
                 {
                     return prices.ElementAt(i);
                 } 
             }
             return null;
         }

         public Price GetInitialStockPrice()
         {
             prices.Sort((x, y) => DateTime.Compare(x.TimeStamp, y.TimeStamp));
             return prices.ElementAt(0);
         }

         public Price GetLastStockPrice()
         {
             prices.Sort((x, y) => DateTime.Compare(x.TimeStamp, y.TimeStamp));
             return prices.Last();
         }

         public bool PriceExists(DateTime timeStamp)
         {
             foreach (Price p in prices)
             {
                 if (timeStamp == p.TimeStamp)
                     return true;
             }
             return false;
         }

         public decimal GetUkupnaVrijednostDionice(DateTime timeStamp)
         {
             return GetStockPrice(timeStamp).Value * numberOfShares;
         }

     }

     public class Price
     {
         private Decimal value;
         private DateTime timeStamp;
        
         public Decimal Value
         {
             get { return this.value; }
             set { this.value = value; }
         }
         
         public DateTime TimeStamp
         {
             get { return timeStamp; }
             set { timeStamp = value; }
         }

         public Price(Decimal value, DateTime timeStamp)
         {
             if (value <= 0)
                 throw new StockExchangeException("Price must be positive.");

             this.value = value;
             this.timeStamp = timeStamp;
         }
     }

     public abstract class Index
     {
         protected String name;
         protected List<Stock> stocksInIndex = new List<Stock>();

         public String Name
         {
             get { return name; }
             set { name = value.ToUpper(); }
         }
         
         public List<Stock> StocksInIndex
         {
             get { return stocksInIndex; }
             set { stocksInIndex = value; }
         }

         public bool IsStockPartOfIndex(string stockName)
         {
             foreach (Stock s in StocksInIndex)
             {
                 if (s.Name.Equals(stockName, StringComparison.InvariantCultureIgnoreCase))
                 {
                     return true;
                 }
             }
             return false;
         }

         protected abstract decimal GetTotalValueOfStocks(DateTime timeStamp);

         public abstract decimal GetIndexValue(DateTime timeStamp);

     }

     public class AverageIndex : Index
     {
         public AverageIndex(string name)
         {
             this.name = name.ToUpper();
         }

         protected override decimal GetTotalValueOfStocks(DateTime timeStamp)
         {
             decimal zbroj = 0;
             foreach (Stock s in StocksInIndex)
             {
                 Price price = s.GetStockPrice(timeStamp);
                 zbroj += price.Value;
             }
             return zbroj;
         }

         public override decimal GetIndexValue(DateTime timeStamp)
         {
             decimal result = 0;
             if (StocksInIndex.Count > 0)
             {
                 result = GetTotalValueOfStocks(timeStamp) / StocksInIndex.Count;
             }

             return Math.Round(result, 3);
         }
     }

     public class WeightedIndex : Index
     {
         public WeightedIndex(string name)
         {
             this.name = name.ToUpper();
         }

         protected override decimal GetTotalValueOfStocks(DateTime timeStamp)
         {
             decimal zbroj = 0;
             foreach (Stock s in StocksInIndex)
             {
                 Price price = s.GetStockPrice(timeStamp);
                 zbroj += price.Value * s.NumberOfShares;
             }
             return zbroj;
         }

         public override decimal GetIndexValue(DateTime timeStamp)
         {
             decimal result = 0;
             if (StocksInIndex.Count > 0)
             {
                 decimal ukupnaVrijednostSvihDionica = GetTotalValueOfStocks(timeStamp);
                 
                 foreach (Stock s in StocksInIndex)
                 {
                     decimal weight = s.GetUkupnaVrijednostDionice(timeStamp) / ukupnaVrijednostSvihDionica;
                     result += s.GetStockPrice(timeStamp).Value*weight;
                 }
             }

             return Math.Round(result, 3);
         }
     }

     public class Portfolio
     {
         private string portfolioID;
         private Dictionary<Stock, long> stocksInPortfolio = new Dictionary<Stock, long>();
         
         public string PortfolioID
         {
             get { return portfolioID; }
             set { portfolioID = value; }
         }

         public Dictionary<Stock, long> StocksInPortfolio
         {
             get { return stocksInPortfolio; }
             set { stocksInPortfolio = value; }
         }

         public Portfolio(string portfolioID)
         {
             this.portfolioID = portfolioID;
         }
         

         public void SetStockInPortfolio(Stock stock, long numberOfShares)
         {
             if (this.IsStockPartOfPortfolio(stock))
             {
                 stocksInPortfolio[stock] += numberOfShares;
             }
             else
                 stocksInPortfolio.Add(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(Stock stock, long numberOfShares)
         {
             if (this.IsStockPartOfPortfolio(stock))
             {
                 if (numberOfShares > stocksInPortfolio[stock])
                     throw new StockExchangeException("Number of shares bigger than number of shares in portfolio");

                 stocksInPortfolio[stock] -= numberOfShares;
                 if(stocksInPortfolio[stock]==0)
                 {
                     RemoveStockFromPortfolio(stock);
                 }
             }
             else
                 throw new StockExchangeException("Stock is not part of portfolio");
         }

         public void RemoveStockFromPortfolio(Stock stock)
         {
             if (IsStockPartOfPortfolio(stock))
             {
                 stocksInPortfolio.Remove(stock);
             }
             else
                 throw new StockExchangeException("Stock is not part of portfolio");
         }

         public bool IsStockPartOfPortfolio(Stock stock)
         {
             foreach (KeyValuePair<Stock, long> pair in stocksInPortfolio)
             {
                 if (pair.Key.Name.Equals(stock.Name))
                 {
                     return true;
                 }
             }

             return false;
         }

         public long GetNumberOfSharesOfStockInPortfolio(Stock stock)
         {
             if (IsStockPartOfPortfolio(stock))
             {
                 return stocksInPortfolio[stock];
             }

             return 0;
         }

         public int GetNumberOfStocksInPortfolio()
         {
             return stocksInPortfolio.Count;
         }

         public decimal GetPortfolioValue(DateTime timeStamp)
         {
             decimal vrijednost = 0;
             foreach (KeyValuePair<Stock, long> pair in stocksInPortfolio)
             {
                 vrijednost += pair.Key.GetStockPrice(timeStamp).Value * pair.Value;
             }

             return Math.Round(vrijednost, 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
         {
             DateTime pocetakMjeseca = new DateTime(year, month, 1, 0, 0, 0, 0);
             DateTime krajMjeseca = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

             decimal vrijednostNaPocetkuMjeseca = this.GetPortfolioValue(pocetakMjeseca);
             decimal vrijednostNaKrajuMjeseca = this.GetPortfolioValue(krajMjeseca);

             decimal promjena = ((vrijednostNaKrajuMjeseca - vrijednostNaPocetkuMjeseca)/vrijednostNaPocetkuMjeseca)*100;

             return Math.Abs(Math.Round(promjena, 3));
         }

     }
}
