﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    /// <summary>
    /// Calculator implementation
    /// </summary>
    public class ExpandableCalculator : ICalculator
    {

        #region Private members

        ///<summary> Reference to calculator screen buffer </summary>
        private readonly CalculatorScreenBuffer _calculatorScreenBuffer = new CalculatorScreenBuffer();

        ///<summary> List of expansion commands </summary>
        private readonly IList<ICalculatorBinaryOperation> _binaryOperations = new List<ICalculatorBinaryOperation>() { new AddOperation(), new SubtractOperation(), new DivideOperation(), new MultiplyOperation() };

        ///<summary> List of expansion commands </summary>
        private readonly IList<ICalculatorUnaryOperation> _unaryOperations = new List<ICalculatorUnaryOperation>() { new NegativeSignOperation(), new CosinusOperation(), new InverseOperation(), new SinusOperation(), new SquareOperation(), new SquareRootOperation() };

        ///<summary> List of expansion commands </summary>
        private readonly IList<ICalculatorOperation> _calculatorOperations = new List<ICalculatorOperation>() { new OnOffOperation(), new ClearOperation(), new LoadOperandOperation(), new SaveOperandOperation() };

        /// <summary> Represents calculator state </summary>
        private CalculatorState State { get; set; }

        /// <summary> Active operation memory </summary>
        private ICalculatorBinaryOperation _operationMemory;

        /// <summary> Active operand memory </summary>
        private double _operandMemory;

        ///<summary> Personal memory used by user </summary>
        private string _internalMemory;
        
        #endregion


        public ExpandableCalculator()
        {
            // Starts with zero
            _calculatorScreenBuffer.Clear(withZero:true);
        }

        #region ICalculator Implementation

        /// <summary>
        /// Handles digit press
        /// </summary>
        public void Press(char inPressedDigit)
        {
            if (State != CalculatorState.Error)
            {

                #region Handle digit press

                if (char.IsDigit(inPressedDigit))
                {
                    if(State == CalculatorState.FirstOperandInMemory)
                    {
                        // We have first operand in memory saved but a new digit came!
                        // Rewrite this operand with a new one...
                        State = CalculatorState.ReceivingFirstOperand;
                        _calculatorScreenBuffer.Clear();
                    }
                    else if (State == CalculatorState.BinaryOperatorAdded)
                    {
                        // We got the binary operator, this digit now goes to second operand
                        // Clean the screen buffer (for second operand)
                        State = CalculatorState.ReceivingSecondOperand;
                        _calculatorScreenBuffer.Clear();
                    }
                    else if (State == CalculatorState.SecondOperandInMemory)
                    {
                        // We have second operand in memory saved but a new digit came!
                        // Rewrite this operand with a new one...
                        State = CalculatorState.ReceivingSecondOperand;
                        // Save operand and clean the screen buffer (waiting for second operand)
                        _calculatorScreenBuffer.Clear();
                    }
                    _calculatorScreenBuffer.Push(inPressedDigit);
                    return;
                }

                #endregion

                #region Handle decimal point

                if (inPressedDigit == ',')
                {
                    // Method does nothing if duplicate or no space left
                    _calculatorScreenBuffer.Push(',');
                    return;
                }

                #endregion

                try
                {
                    #region Handle equals operation

                    if (inPressedDigit == '=')
                    {
                        if (State == CalculatorState.ReceivingFirstOperand)
                        {
                            // We were receiving first operand
                            // just clean (remove redundant zeroes, round...) what we got and inject again on screen
                            State = CalculatorState.FirstOperandInMemory;
                            var firstOperand = GetActiveOperandFromBuffer();
                            _calculatorScreenBuffer.Insert(ParseAndCleanDouble(firstOperand));
                        }
                        else if (State == CalculatorState.ReceivingSecondOperand || State == CalculatorState.SecondOperandInMemory)
                        {
                            // We were receiving or we have a second operand in memory and = came
                            // Do a calculation and return to state where first operand is memorized (result from here)
                            State = CalculatorState.FirstOperandInMemory;

                            var secondOperand = GetActiveOperandFromBuffer();
                            var firstOperand = GetSavedOperand();
                            var result = _operationMemory.Execute(firstOperand, secondOperand, this);

                            // Round the result and inject it to screen
                            var parsedResult = ParseAndCleanDouble(result);
                            _calculatorScreenBuffer.Insert(parsedResult);
                        }
                        else if (State == CalculatorState.BinaryOperatorAdded)
                        {
                            // If operator was added and then = sign came
                            // Do the calculation with first and second operand equal to our memorized operand
                            // 2 /=   <---->  result =  2 / 2
                            var operand = GetActiveOperandFromBuffer();
                            var result = _operationMemory.Execute(operand, operand, this);

                            // Round the result and inject it to screen
                            var parsedResult = ParseAndCleanDouble(result);
                            _calculatorScreenBuffer.Insert(parsedResult);
                        }

                        return;
                    }

                    #endregion

                    #region Handle binary operation

                    var binaryOperation = _binaryOperations.FirstOrDefault(o => o.CommandId == inPressedDigit);
                    if (binaryOperation != null)
                    {
                        if (State == CalculatorState.ReceivingSecondOperand || State == CalculatorState.SecondOperandInMemory)
                        {
                            // We had or we were receiving second operand when the operation sign came
                            // Do the calculation
                            var secondOperand = GetActiveOperandFromBuffer();
                            var firstOperand = GetSavedOperand();
                            var result = _operationMemory.Execute(firstOperand, secondOperand, this);

                            // Round the result
                            var parsedResult = ParseAndCleanDouble(result);
                            _calculatorScreenBuffer.Insert(parsedResult);
                        }
                        
                        // Save the active operand to internal memory for future calculations 
                        // We always save when binary operand comes so we can work on getting the next operand.
                        // (number saved can be received first operand or the result from previous calculations that will act as one)
                        _calculatorScreenBuffer.Insert(ParseAndCleanDouble(GetActiveOperandFromBuffer()));
                        SaveOperand(GetActiveOperandFromBuffer());
                        // This operation will be dealt later when we get second operand. Save it to internal memory
                        // and update calculator state
                        _operationMemory = binaryOperation;
                        State = CalculatorState.BinaryOperatorAdded;
                        return;
                    }

                    #endregion

                    #region Handle unary operation

                    var unaryOperation = _unaryOperations.FirstOrDefault(o => o.CommandId == inPressedDigit);
                    if (unaryOperation != null)
                    {
                        if (State == CalculatorState.ReceivingFirstOperand && unaryOperation.CommandId != 'M')
                        {
                            // If we were in the process of receiving first operand, and the unary operation came
                            // this will finalize receiving and mark it as in memory 
                            // SPECIAL CASE: Number negation unary operation allows you to add more digits to operand after the operation was placed
                            State = CalculatorState.FirstOperandInMemory;
                        }
                        else if (State == CalculatorState.ReceivingSecondOperand && unaryOperation.CommandId != 'M') 
                        {
                            // If we were in the process of receiving second operand, and the unary operation came
                            // this will finalize receiving and mark it as in memory 
                            // SPECIAL CASE: Number negation unary operation allows you to add more digits to operand after the operation was placed
                            State = CalculatorState.SecondOperandInMemory;
                        }
                        
                        var result = unaryOperation.Execute(GetActiveOperandFromBuffer(), this);

                        // Round the result
                        var parsedResult = ParseAndCleanDouble(result);
                        _calculatorScreenBuffer.Insert(parsedResult);
                        return;
                    }

                    #endregion
                }
                catch (ArgumentOutOfRangeException)
                {
                    // Result had to many digits!
                    SetErrorState();
                }
            }

            #region Handle calculator operation
            var calculatorOperation = _calculatorOperations.FirstOrDefault(o => o.CommandId == inPressedDigit);
            if (calculatorOperation != null)
            {
                calculatorOperation.Execute(this);
                return;
            }
            #endregion

            // No more options
            SetErrorState();
        }

        /// <summary>
        /// Gets current display state from the screen
        /// </summary>
        public string GetCurrentDisplayState()
        {
            if (State == CalculatorState.Error)
            {
                return "-E-";
            }
            return _calculatorScreenBuffer.Display();
        }

        public void SetErrorState()
        {
            State = CalculatorState.Error;
            _calculatorScreenBuffer.Clear();
        }

        public void Reset()
        {
            State = CalculatorState.ReceivingFirstOperand;
            _calculatorScreenBuffer.Clear();
        }

        public void SaveCurrentToInternalMemory()
        {
            _internalMemory = GetCurrentDisplayState();
        }

        public void LoadFromInternalMemory()
        {
            State = CalculatorState.ReceivingFirstOperand;
            _calculatorScreenBuffer.Insert(_internalMemory.ToList());
        }

        public void Clear()
        {
            _calculatorScreenBuffer.Clear();
            if (State == CalculatorState.Error) State = CalculatorState.ReceivingFirstOperand;
        }

        /// <summary>
        /// Returns operand that is currently being processed in the screen buffer
        /// Removes leading zeroes right from decimal point.
        /// </summary>
        /// <returns></returns>
        private double GetActiveOperandFromBuffer()
        {
            return double.Parse(GetCurrentDisplayState());
        }

        /// <summary>
        /// Returns operand that is saved in internal calculation memory (first operand memory)
        /// </summary>
        /// <returns></returns>
        private double GetSavedOperand()
        {
            return _operandMemory;
        }

        /// <summary>
        /// Saves first operand in internal calculation memory (first operand memory)
        /// </summary>
        private void SaveOperand(double operand)
        {
            _operandMemory = operand;
        }


        /// <summary>
        /// Splits a new double for a screen buffer. 
        /// If limit is met, method cuts the characters right from the decimal point. 
        /// If number of digits left from the decimal point is greater than the number limit, 
        /// error gets saved in the buffer.
        /// </summary>
        /// <returns>null if input can't be split for screen buffer</returns>
        private List<char> ParseAndCleanDouble(double input)
        {
            var charList = new List<char>();

            var doubleParts = input.ToString(CultureInfo.InvariantCulture).Split('.');
            var leftSide = doubleParts[0];
            var leftSideDigitLength = leftSide.Where(char.IsDigit).Count();
            if (leftSideDigitLength > 10)
            {
                throw new ArgumentOutOfRangeException();
            }

            // Has decimal part
            if (doubleParts.Length > 1)
            {
                var rightSide = doubleParts[1];

                // there will be cutting
                if (leftSide.Length + rightSide.Length > 10)
                {
                    // cut so we have 10 digits total
                    input = Math.Round(input, 10 - leftSideDigitLength);
                    doubleParts = input.ToString(CultureInfo.InvariantCulture).Split('.');
                    leftSide = doubleParts[0];
                    rightSide = doubleParts[1];
                }

                charList.AddRange(leftSide);
                if (rightSide.Length > 0)
                {
                    charList.Add(',');
                    charList.AddRange(rightSide);
                }
            }
            else
            {
                // Else just push left side
                charList.AddRange(leftSide);
            }

            return charList;
        }

        #endregion

        #region Calculator expansion methods

        /// <summary>
        /// Adds a new command, should be part of IExpandableCalculator interface
        /// </summary>
        public void AddUnaryOperation(ICalculatorUnaryOperation operation)
        {
            if (_unaryOperations.Any(o => o.CommandId == operation.CommandId) || _binaryOperations.Any(o => o.CommandId == operation.CommandId))
            {
                throw new ArgumentException("Operation with this id already exists");
            }
            _unaryOperations.Add(operation);

        }

        /// <summary>
        /// Removes a new command, should be part of IExpandableCalculator interface
        /// </summary>
        public void RemoveUnaryOperation(ICalculatorUnaryOperation operation)
        {
            if (_unaryOperations.Contains(operation))
            {
                _unaryOperations.Remove(operation);
            }
        }

        /// <summary>
        /// Adds a new command, should be part of IExpandableCalculator interface
        /// </summary>
        public void AddBinaryOperation(ICalculatorBinaryOperation operation)
        {
            if (_unaryOperations.Any(o => o.CommandId == operation.CommandId) || _binaryOperations.Any(o => o.CommandId == operation.CommandId))
            {
                throw new ArgumentException("Operation with this id already exists");
            }
            _binaryOperations.Add(operation);
        }

        /// <summary>
        /// Removes a new command, should be part of IExpandableCalculator interface
        /// </summary>
        public void RemoveBinaryOperation(ICalculatorBinaryOperation operation)
        {
            if (_binaryOperations.Contains(operation))
            {
                _binaryOperations.Remove(operation);
            }
        }

        #endregion


    }

    #region Calculator Unary Commands

    public interface ICalculatorUnaryOperation
    {
        char CommandId { get; }
        double Execute(double operand, ExpandableCalculator calculator);
    }


    public class NegativeSignOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'M'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            return operand < 0 ? operand : operand * -1;
        }
    }

    public class SinusOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'S'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            return Math.Sin(operand);
        }
    }

    public class CosinusOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'K'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            return Math.Cos(operand);
        }
    }

    public class SquareOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'Q'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            return operand * operand;
        }
    }

    public class SquareRootOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'R'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            if (operand < 0)
            {
                calculator.SetErrorState();
                return 0;
            }
            return Math.Sqrt(operand);
        }
    }


    public class InverseOperation : ICalculatorUnaryOperation
    {
        public char CommandId
        {
            get { return 'I'; }
        }

        public double Execute(double operand, ExpandableCalculator calculator)
        {
            if (Math.Abs(operand) < 1e-10)
            {
                calculator.SetErrorState();
                return 0;
            }
            return 1 / operand;
        }
    }

    #endregion

    #region Calculator Binary Commands

    public interface ICalculatorBinaryOperation
    {
        char CommandId { get; }
        double Execute(double firstOperand, double secondOperand, ExpandableCalculator calculator);
    }

    public class AddOperation : ICalculatorBinaryOperation
    {
        public char CommandId
        {
            get { return '+'; }
        }

        public double Execute(double firstOperand, double secondOperand, ExpandableCalculator calculator)
        {
            return firstOperand + secondOperand;
        }
    }

    public class SubtractOperation : ICalculatorBinaryOperation
    {
        public char CommandId
        {
            get { return '-'; }
        }

        public double Execute(double firstOperand, double secondOperand, ExpandableCalculator calculator)
        {
            return firstOperand - secondOperand;
        }
    }

    public class MultiplyOperation : ICalculatorBinaryOperation
    {
        public char CommandId
        {
            get { return '*'; }
        }

        public double Execute(double firstOperand, double secondOperand, ExpandableCalculator calculator)
        {
            return firstOperand * secondOperand;
        }
    }

    public class DivideOperation : ICalculatorBinaryOperation
    {
        public char CommandId
        {
            get { return '/'; }
        }

        public double Execute(double firstOperand, double secondOperand, ExpandableCalculator calculator)
        {
            if (Math.Abs(secondOperand) < 1e-10)
            {
                calculator.SetErrorState();
                return 0;
            }
            return firstOperand / secondOperand;
        }
    }


    #endregion

    #region Calculator Commands
    public interface ICalculatorOperation
    {
        char CommandId { get; }
        void Execute(ExpandableCalculator calculator);
    }

    public class OnOffOperation : ICalculatorOperation
    {
        public char CommandId
        {
            get { return 'O'; }
        }
        public void Execute(ExpandableCalculator calculator)
        {
            calculator.Reset();
        }
    }

    public class SaveOperandOperation : ICalculatorOperation
    {
        public char CommandId
        {
            get { return 'P'; }
        }
        public void Execute(ExpandableCalculator calculator)
        {
            calculator.SaveCurrentToInternalMemory();
        }
    }

    public class LoadOperandOperation : ICalculatorOperation
    {
        public char CommandId
        {
            get { return 'G'; }
        }
        public void Execute(ExpandableCalculator calculator)
        {
            calculator.LoadFromInternalMemory();
        }
    }

    public class ClearOperation : ICalculatorOperation
    {
        public char CommandId
        {
            get { return 'C'; }
        }
        public void Execute(ExpandableCalculator calculator)
        {
            calculator.Clear();
        }
    }

    #endregion

    #region Utilities

    public enum CalculatorState
    {
        ReceivingFirstOperand, FirstOperandInMemory, BinaryOperatorAdded, ReceivingSecondOperand, SecondOperandInMemory, Error,
    }

    public enum Sign
    {
        Positive, Negative, NoSign
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new ExpandableCalculator();
        }
    }

    #endregion

    /// <summary>
    /// Represents screen buffer memory for calculator. Has methods for adding and removing values
    /// from screen buffer, and some used screen paterns (e.g error display format).
    /// </summary>
    public class CalculatorScreenBuffer
    {
        private const int ScreenLength = 11;
        private readonly char[] _internalScreen = new char[ScreenLength];
        private int _digitPointer;
        private Sign _sign = Sign.Positive;

        /// <summary>
        /// Pushes a new character to screen. 
        /// returns false if there is no space on the screen available
        /// returns true if the digit is succesfully logged
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public bool Push(char c)
        {
            if (!CanAddMoreDigits)
            {
                return false;
            }
            if (c == ',')
            {
                // Ignore multiple decimal points
                if (_internalScreen.Take(_digitPointer).Contains(','))
                {
                    return false;
                }
            }
            // Replace leading zero if digit was sent
            if (char.IsDigit(c) && _digitPointer == 1 && _internalScreen[0] == '0')
            {
                _digitPointer = 0;
            }

            _internalScreen[_digitPointer++] = c;
            return true;
        }

        /// <summary>
        /// Returns true if there are less than 10 digits on screen
        /// </summary>
        private bool CanAddMoreDigits
        {
            get
            {
                if (_internalScreen.Take(_digitPointer).Contains(','))
                {
                    return _digitPointer < ScreenLength;
                }
                return _digitPointer < ScreenLength - 1;
            }
        }

        /// <summary>
        /// Clears the internal display
        /// </summary>
        public void Clear(bool withZero = true)
        {
            _digitPointer = 0;
            _sign = Sign.Positive;
            if (withZero)
            {
                Push('0');
            }
        }

        public string Display()
        {
            var result = (_sign == Sign.Negative ? "-" : "") + new string(_internalScreen, 0, _digitPointer);

            return result;
        }

        public void Insert(List<char> digits)
        {
            Clear(withZero: false);
            if (digits[0] != '-')
            {
                foreach (var digit in digits)
                {
                    Push(digit);
                }
            }
            else
            {
                _sign = Sign.Negative;
                foreach (var digit in digits.Skip(1))
                {
                    Push(digit);
                }
            }
        }
    }
}
