﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> stockList = new List<Stock>();
         List<Index> indexList = new List<Index>();
         List<Portfolio> portfolioList = new List<Portfolio>();
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName.ToLower()) && inInitialPrice>0 && inNumberOfShares > 0)
             {
                 Stock stock = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
                 stockList.Add(stock);
             }
             else 
             {
                 throw new StockExchangeException("Greska!");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 Stock stock;
                 for (int i = 0; i < stockList.Count; i++)
                 {
                     if (stockList[i].StockName.Equals(inStockName.ToLower()))
                     {
                         stock = stockList[i];
                         stockList.Remove(stock);
                         break;
                     }
                 }
             }
             else throw new StockExchangeException("Greska!");
         }

         public bool StockExists(string inStockName)
         {
             for (int i = 0; i < stockList.Count; i++)
             {
                 if (stockList[i].StockName.Equals(inStockName.ToLower())) return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             int amount = 0;
             if (stockList.Count > 0) amount = stockList.Count();
             return amount;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName.ToLower())) 
             {
                 Stock stock;
                 for (int i = 0; i < stockList.Count; i++)
                 {
                     if (stockList[i].StockName.Equals(inStockName.ToLower()))
                     {
                         stock = stockList[i];
                         stock.SetStockValue(inIimeStamp, inStockValue);
                         break;
                     }
                 }
                 
             }
             else throw new StockExchangeException("Greska!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             decimal ret;
             if (StockExists(inStockName.ToLower()))
             {
                 Stock stock;
                 for (int i = 0; i < stockList.Count; i++)
                 {
                     if (stockList[i].StockName.Equals(inStockName.ToLower()))
                     {
                         stock = stockList[i];
                         ret = stock.GetStockValue(inTimeStamp);
                         return ret;
                     }
                 }
                 throw new StockExchangeException("Greska!");
             }
             else
             {
                 throw new StockExchangeException("Greska!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName.ToLower())) 
             {
                 decimal ret = 0;
                 Stock stock;
                 for (int i = 0; i < stockList.Count; i++)
                 {
                     if (stockList[i].StockName.Equals(inStockName.ToLower()))
                     {
                         stock = stockList[i];
                         ret = stock.StockInitialValue;
                         break;
                     }
                 }
                 return ret;
             }
             else throw new StockExchangeException("Greska!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 decimal ret = 0;
                 Stock stock;
                 for (int i = 0; i < stockList.Count; i++)
                 {
                     if (stockList[i].StockName.Equals(inStockName.ToLower()))
                     {
                         stock = stockList[i];
                         ret = stock.StockLastValue;
                         break;
                     }
                 }
                 return ret;
             }
             else throw new StockExchangeException("Greska!");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!IndexExists(inIndexName))
             {
                 if (inIndexType == IndexTypes.AVERAGE)
                 {
                     Index index = new IndexAverage(inIndexName.ToLower(), inIndexType);
                     indexList.Add(index);
                 }
                 else if (inIndexType == IndexTypes.WEIGHTED)
                 {
                     Index index = new IndexWeighted(inIndexName.ToLower(), inIndexType);
                     indexList.Add(index);
                 }
                 else throw new StockExchangeException("Greska!");
             }
             else throw new StockExchangeException("Greska!");
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName.ToLower()) && StockExists(inStockName))
             {
                 Index index = GetIndexFromList(inIndexName.ToLower());
                 if (!index.getListOfStockNamesInIndex().Contains(inStockName.ToLower()))
                 {
                     index.AddStockToIndex(inStockName.ToLower());
                 }
                 else  throw new StockExchangeException("Greska!");
             }
             else  throw new StockExchangeException("Greska!"); 
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName.ToLower()))
             {
                 Index index = GetIndexFromList(inIndexName.ToLower());
                 index.RemoveStockFromIndex(inStockName.ToLower());
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName.ToLower()))
             {
                 Index index = GetIndexFromList(inIndexName.ToLower());
                 if (index.StockPartOfIndex(inStockName.ToLower())) return true;
                 else return false;
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal ret = 0;
             int nazivnik1 = 0;
             decimal nazivnik2 = 0;
             decimal brojnik2 = 0;
             if (IndexExists(inIndexName.ToLower()))
             {
                 Index index = GetIndexFromList(inIndexName.ToLower());
                 if (index.getListOfStockNamesInIndex().Count > 0)
                 {
                     if (index.GetIndexType() == 1)
                     {
                         foreach (string stockName in index.getListOfStockNamesInIndex())
                         {
                             ret += GetStockPrice(stockName.ToLower(), inTimeStamp);
                             nazivnik1++;
                         }
                         ret /= nazivnik1;
                         return decimal.Round(ret, 3);
                     }
                     else
                     {
                         foreach (Stock stock in stockList)
                         {
                             nazivnik2 += GetStockPrice(stock.StockName.ToLower(), inTimeStamp) * stock.StockAmount;
                         }
                         foreach (string stockName in index.getListOfStockNamesInIndex())
                         {
                             Stock stock;
                             if (StockExists(stockName))
                             {
                                 for (int i = 0; i < stockList.Count; i++)
                                 {
                                     if (stockList[i].StockName.Equals(stockName.ToLower()))
                                     {
                                         stock = stockList[i];
                                         brojnik2 += GetStockPrice(stock.StockName.ToLower(), inTimeStamp) * stock.StockAmount;
                                     }
                                 }
                             }
                             else throw new StockExchangeException("Greska!");
                             
                         }
                         ret = brojnik2 / nazivnik2;
                         return decimal.Round(ret,3);
                     }
                 }
                 else throw new StockExchangeException("Greska!");
             }
             else throw new StockExchangeException("Greska!");
             
         }

         public bool IndexExists(string inIndexName)
         {
             for (int i = 0; i < indexList.Count; i++)
             {
                 if (indexList[i].GetIndexName().Equals(inIndexName.ToLower())) return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return indexList.Count();    
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName.ToLower()))
             {
                 Index index = GetIndexFromList(inIndexName.ToLower());
                 return index.NumberOfStocksInIndex();
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio portfolio = new Portfolio(inPortfolioID);
             if (!portfolioList.Contains(portfolio)) portfolioList.Add(portfolio);
             else throw new StockExchangeException("Greska!");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName)) 
             {
                 Portfolio portfolio = GetPortfolioFromList(inPortfolioID);
                 portfolio.AddStock(inStockName, numberOfShares);
             }
             else throw new StockExchangeException("Greska!");
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = GetPortfolioFromList(inPortfolioID);
                 portfolio.RemoveSomeStock(inStockName, numberOfShares);
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = GetPortfolioFromList(inPortfolioID);
                 portfolio.RemoveStock(inStockName);
             }
             else { throw new StockExchangeException("Greska!"); }
             
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = GetPortfolioFromList(inPortfolioID);
                 return portfolio.NumOfStocksInPortfolio();
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             for (int i = 0; i < portfolioList.Count; i++)
             {
                 if (portfolioList[i].PortfolioId.Equals(inPortfolioID)) return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = GetPortfolioFromList(inPortfolioID);
                 return portfolio.IsStockPartOfPortfolio(inStockName);
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio =GetPortfolioFromList(inPortfolioID);
                 return portfolio.NumberOfSharesOfStockInPortfolio(inStockName);
             }
             else { throw new StockExchangeException("Greska!"); }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal ret = 0;
             Portfolio portfolio;
             if (PortfolioExists(inPortfolioID))
             {
                 portfolio = GetPortfolioFromList(inPortfolioID);
             }
             else { throw new StockExchangeException("Greska!"); }
             List<string> listOfStocksInPortfolio = portfolio.GetPortfolioStockList();
             foreach (string stockName in listOfStocksInPortfolio)
             {
                 ret += portfolio.NumberOfSharesOfStockInPortfolio(stockName) * GetStockPrice(stockName, timeStamp);
             }
             return ret;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }

         public Portfolio GetPortfolioFromList(string inPortfolioID) 
         {
            Portfolio portfolio;
            for (int i = 0; i < portfolioList.Count; i++)
            {
                if (portfolioList[i].PortfolioId.Equals(inPortfolioID))
                {
                    portfolio = portfolioList[i];
                    return portfolio;
                }
            }
             throw new StockExchangeException("Greska!");
         }

         public Index GetIndexFromList(string inIndexName)
         {
             Index index;
             for (int i = 0; i < indexList.Count; i++)
             {
                 if (indexList[i].GetIndexName().Equals(inIndexName.ToLower()))
                 {
                     index = indexList[i];
                     return index;
                 }
             }
             throw new StockExchangeException("Greska!");
         }
     }

     public class Stock
     {
         string _inStockName;
         long _inNumberOfShares;
         SortedDictionary<DateTime, decimal> stockDatePrice = new SortedDictionary<DateTime, decimal>();
         decimal initialPrice;
         decimal lastPrice;

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _inStockName = inStockName.ToLower();
             _inNumberOfShares = inNumberOfShares;
             stockDatePrice.Add(inTimeStamp, inInitialPrice);
             initialPrice = inInitialPrice;
             lastPrice = inInitialPrice;
         }

         public void SetStockValue(DateTime inIimeStamp, decimal inStockValue)
         {
             stockDatePrice.Add(inIimeStamp, inStockValue);
             lastPrice = stockDatePrice.Last().Value;
         }

         public decimal GetStockValue(DateTime inTimeStamp)
         {
             bool index = false;
             int i = 0;
             decimal ret = 0;

             foreach (DateTime t in stockDatePrice.Keys)
             {
                 i++;
                 if (t > inTimeStamp) 
                 {
                     index = true;
                     break;
                 }
                 ret = stockDatePrice[t];
             }

             if (!index && i != stockDatePrice.Count()) throw new StockExchangeException("Greska!");
             return ret;
         }

         public decimal StockInitialValue
         {
             get { return initialPrice; }
         }

         public decimal StockLastValue {
             get { return lastPrice; }
         }

         public string StockName {
             get { return _inStockName; }
         }

         public long StockAmount {
             get { return _inNumberOfShares; }
         }

     }

     public abstract class Index
     {
        abstract public string GetIndexName();
        abstract public int GetIndexType();

        public List<string> dioniceUIndeksu = new List<string>();
        
        public void AddStockToIndex(string inStockName)
        {
            if (!dioniceUIndeksu.Contains(inStockName.ToLower())) dioniceUIndeksu.Add(inStockName);
        }

        public void RemoveStockFromIndex(string inStockName)
        {
            if (dioniceUIndeksu.Contains(inStockName.ToLower())) dioniceUIndeksu.Remove(inStockName);
            else throw new StockExchangeException("Greska!"); 
        }

        public bool StockPartOfIndex(string inStockName)
        {
            if (dioniceUIndeksu.Contains(inStockName.ToLower())) return true;
            else return false;
        }

        public List<string> getListOfStockNamesInIndex()
        {
            return dioniceUIndeksu;
        }

        public int NumberOfStocksInIndex()
        {
            return dioniceUIndeksu.Count();
        }
     }

     public class IndexAverage : Index
     {
         string _inIndexName;
         IndexTypes _inIndexType;

         public IndexAverage(string inIndexName, IndexTypes inIndexType)
         {
             _inIndexName = inIndexName.ToLower();
             _inIndexType = inIndexType;
         }

         public override string GetIndexName()
         {
             return _inIndexName;
         }

         public override int GetIndexType()
         {
             return 1;
         }
     }

     public class IndexWeighted : Index
     {
         string _inIndexName;
         IndexTypes _inIndexType;

         public IndexWeighted(string inIndexName, IndexTypes inIndexType)
         {
             _inIndexName = inIndexName.ToLower();
             _inIndexType = inIndexType;
         }

         public override string GetIndexName()
         {
             return _inIndexName;
         }

         public override int GetIndexType()
         {
             return 2;
         }

     }

     public class Portfolio
     {
         string _inPortfolioID;
         Dictionary<string, int> dioniceIKolicina = new Dictionary<string, int>();

         public Portfolio(string inPortfolioID)
         {
             _inPortfolioID = inPortfolioID;
         }

         public void AddStock(string inStockName, int numberOfShares) 
         {
             if (dioniceIKolicina.ContainsKey(inStockName)) 
             {
                dioniceIKolicina[inStockName] += numberOfShares; 
             }
             else 
             {
                 dioniceIKolicina.Add(inStockName, numberOfShares);
             }
         }

         public void RemoveSomeStock(string inStockName, int numberOfShares)
         {
             if (dioniceIKolicina.ContainsKey(inStockName))
             {
                 if (dioniceIKolicina[inStockName] <= numberOfShares)
                 {
                     dioniceIKolicina.Remove(inStockName);
                 }
                 else 
                 {
                    dioniceIKolicina[inStockName] -= numberOfShares;
                 }
             }
             else throw new StockExchangeException("Greska!");
         }

         public bool IsStockPartOfPortfolio(string inStockName)
         {
             if (dioniceIKolicina.ContainsKey(inStockName)) return true;
             else return false;
         }

         public void RemoveStock(string inStockName)
         {
             dioniceIKolicina.Remove(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inStockName)
         {
             if (dioniceIKolicina.ContainsKey(inStockName))
             {
                 return dioniceIKolicina[inStockName];
             }
             else throw new StockExchangeException("Greska!");
         }

         public List<string> GetPortfolioStockList()
         {
             List<string> ret = dioniceIKolicina.Keys.ToList();
             return ret;
         }

         public int NumOfStocksInPortfolio()
         {
             return dioniceIKolicina.Count;
         }

         public string PortfolioId 
         {
             get { return _inPortfolioID; }
         }
     }
}
