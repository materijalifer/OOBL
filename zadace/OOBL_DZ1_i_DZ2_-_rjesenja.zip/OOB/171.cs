﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    #region Enum

    public enum calculatorState
    {
        FirstNumber,
        SecondNumber,
        SecondNumberFirstDigit,
        Error
    }

    public enum calculatorOperation
    {
        Default,
        Addition,
        Subtraction,
        Multiplication,
        Division
    }

    #endregion

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        #region Fields

        private const string ERROR = "-E-";
        private const int DISPLAY_SIZE = 10;
        private const string DEFAULT_DISPLAY = "0";

        private List<char> BINARY_OPERATORS = new List<char> { '+', '-', '*', '/' };
        private List<char> UNAR_OPERATORS = new List<char> { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        private List<char> FUNCTION_OPERATORS = new List<char> { 'P', 'G', 'C', 'O', '=', ',' };

        private string currentDisplay;
        private calculatorState currentState;
        private calculatorOperation currentOperation;
        private double firstOperand;
        private double numberInMemory;

        #endregion

        public Kalkulator()
        {
            this.currentDisplay = DEFAULT_DISPLAY;
            this.currentState = calculatorState.FirstNumber;
            this.currentOperation = calculatorOperation.Default;
        }


        public void Press(char inPressedDigit)
        {

            if (this.currentState == calculatorState.Error && inPressedDigit != 'O') return;

            int num;
            bool isNum = int.TryParse(inPressedDigit.ToString(), out num);
            if (isNum)
            {
                if (this.currentDisplay == DEFAULT_DISPLAY && this.currentOperation == calculatorOperation.Default) this.currentDisplay = inPressedDigit.ToString();
                else
                {
                    if (this.currentState == calculatorState.SecondNumberFirstDigit)
                    {
                        this.currentDisplay = inPressedDigit.ToString();
                        this.currentState = calculatorState.SecondNumber;
                    }
                    else
                    {
                        this.currentDisplay = OutputToDisplay(this.currentDisplay + inPressedDigit.ToString());
                    }
                 }
            }
            else
            {
                double number = 0;


                double.TryParse(this.currentDisplay, out number);


                if (BINARY_OPERATORS.Contains(inPressedDigit))
                {
                    if (this.currentOperation != calculatorOperation.Default && this.currentState != calculatorState.SecondNumberFirstDigit)
                    {
                        Equals(number);
                        double.TryParse(this.currentDisplay, out number);
                    }

                    this.firstOperand = number;
                    this.currentDisplay = number.ToString();
                    this.currentState = calculatorState.SecondNumberFirstDigit;

                    switch (inPressedDigit)
                    {
                        // Addition
                        case '+':

                            this.currentOperation = calculatorOperation.Addition;
                            break;

                        // Subtraction
                        case '-':

                            this.currentOperation = calculatorOperation.Subtraction;
                            break;

                        // Multiplication
                        case '*':

                            this.currentOperation = calculatorOperation.Multiplication;
                            break;

                        // Division
                        case '/':

                            this.currentOperation = calculatorOperation.Division;
                            break;
                    }
                }

                else if (UNAR_OPERATORS.Contains(inPressedDigit))
                {
                    switch (inPressedDigit)
                    {
                        // Inverse +/-
                        case 'M':

                            number = operationMinusToggle(number);

                            break;

                        // Sinus function
                        case 'S':

                            operationSin(number);

                            break;

                        // Cosinus function
                        case 'K':

                            operationCos(number);

                            break;

                        // Tangens function
                        case 'T':

                            operationTan(number);

                            break;

                        // Square function
                        case 'Q':

                            operationSquare(number);

                            break;

                        // Root function
                        case 'R':

                            operationRoot(number);

                            break;
                        // Inverse function
                        case 'I':

                            number = operationInverse(number);

                            break;
                    }
                }

                else if(FUNCTION_OPERATORS.Contains(inPressedDigit))
                {

                    switch (inPressedDigit)
                    {
                        // Save to memory
                        case 'P':

                            functionSave(number);
                            break;

                        // Load from memory
                        case 'G':

                            functionLoad();
                            break;

                        // Clear
                        case 'C':

                            functionClear();
                            break;

                        // On-off
                        case 'O':

                            functionOnOff();
                            break;

                        // Calculate current operation
                        case '=':

                            Equals(number);

                            break;

                        // Decimal point
                        case ',':

                            functionFloatingPoint();

                            break;
                    }


                }

            }
        }

        public string GetCurrentDisplayState()
        {
            return this.currentDisplay;
        }

        private string OutputToDisplay(double numberToOutput)
        {
            decimal number = (decimal)numberToOutput;
            if ((double)number < Math.Pow(10, DISPLAY_SIZE))
            {
                if (number.ToString().Contains(','))
                {
                    int numberSize = (int)Math.Log10(Math.Abs((double)number)) + 1;
                    if (numberSize < 1) numberSize = 1;
                    return Math.Round(number, DISPLAY_SIZE - numberSize).ToString();
                }
                else return number.ToString();

            }
            else return ThrowError();
        }

        private string OutputToDisplay(string numberString)
        {
            int cut = 0;

            if (numberString.Contains('-')) cut++;
            if (numberString.Contains(',')) cut++;

            if (numberString.Length > DISPLAY_SIZE + cut) numberString = numberString.Remove(DISPLAY_SIZE + cut);

            return numberString;
        }

        private void Equals(double number)
        {

            switch (this.currentOperation)
            {
                case calculatorOperation.Addition:

                    if (this.currentState == calculatorState.SecondNumberFirstDigit) this.currentDisplay = OutputToDisplay(this.firstOperand + this.firstOperand);
                    else this.currentDisplay = OutputToDisplay(this.firstOperand + number);

                    break;

                case calculatorOperation.Subtraction:

                    if (this.currentState == calculatorState.SecondNumberFirstDigit) this.currentDisplay = OutputToDisplay(this.firstOperand - this.firstOperand);
                    else this.currentDisplay = OutputToDisplay(this.firstOperand - number);

                    break;

                case calculatorOperation.Multiplication:

                    if (this.currentState == calculatorState.SecondNumberFirstDigit) this.currentDisplay = OutputToDisplay(this.firstOperand * this.firstOperand);
                    else this.currentDisplay = OutputToDisplay(this.firstOperand * number);

                    break;

                case calculatorOperation.Division:

                    if (this.currentState == calculatorState.SecondNumberFirstDigit) this.currentDisplay = OutputToDisplay(this.firstOperand / this.firstOperand);
                    else this.currentDisplay = OutputToDisplay(this.firstOperand / number);

                    break;

                case calculatorOperation.Default:

                    this.currentDisplay = OutputToDisplay(number);

                    break;
            }

            this.currentOperation = calculatorOperation.Default;

        }

        private string ThrowError()
        {
            this.currentDisplay = ERROR;
            this.currentState = calculatorState.Error;

            return ERROR;
        }

        #region Operations

        private double operationMinusToggle(double number)
        {
            number = number * -1;
            this.currentDisplay = number.ToString();
            return number;
        }

        private void operationSin(double number)
        {
            this.currentDisplay = Math.Round(Math.Sin(number), DISPLAY_SIZE - 1).ToString();
        }

        private void operationCos(double number)
        {
            this.currentDisplay = Math.Round(Math.Cos(number), DISPLAY_SIZE - 1).ToString();
        }

        private void operationTan(double number)
        {
            this.currentDisplay = Math.Round(Math.Tan(number), DISPLAY_SIZE - 1).ToString();
        }

        private void operationSquare(double number)
        {
            this.currentDisplay = OutputToDisplay(Math.Pow(number, 2));
        }

        private void operationRoot(double number)
        {
            this.currentDisplay = OutputToDisplay(Math.Pow(number, 0.5));
        }

        private double operationInverse(double number)
        {
            if (number != 0)
            {
                number = 1 / number;
                this.currentDisplay = OutputToDisplay(number);
            }
            else ThrowError();
            return number;
        }

        #endregion

        #region Functions

        private void functionFloatingPoint()
        {
            if (!this.currentDisplay.Contains(',')) this.currentDisplay += ",";
        }

        private void functionSave(double number)
        {
            this.numberInMemory = number;
        }

        private void functionLoad()
        {
            this.currentDisplay = this.numberInMemory.ToString();
        }

        private void functionClear()
        {
            this.currentDisplay = DEFAULT_DISPLAY;
            if (this.currentState == calculatorState.SecondNumber) this.currentState = calculatorState.SecondNumberFirstDigit;
        }

        private void functionOnOff()
        {
            this.currentDisplay = DEFAULT_DISPLAY;
            this.currentState = calculatorState.FirstNumber;
            this.currentOperation = calculatorOperation.Default;
            this.firstOperand = 0;
            this.numberInMemory = 0;
        }

        #endregion

    }

}


