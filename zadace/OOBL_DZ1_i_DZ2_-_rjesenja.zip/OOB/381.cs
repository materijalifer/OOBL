﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
        public class Stock 
        {
            public Stock(string name,long NumberOfShare,StockPrice stockPrice) 
            {
                _stockPrices = new List<StockPrice>();
                Name = name;
                numberOfShare = NumberOfShare;
                _stockPrices.Add(stockPrice);
            }            
            public string Name { get; set; }
            public List<StockPrice> _stockPrices;
            public long numberOfShare;
            public void  SetPrice(StockPrice newPrice)
            {
                _stockPrices.Add(newPrice);
                
            }
            public decimal GetCurrentPrice() { return _stockPrices.OrderBy(x => x.TimeStamp).Last().Price; }
            public decimal PriceAtDate(DateTime time)
            {
                List<StockPrice> price = _stockPrices.OrderBy(x => x.TimeStamp).ToList();
                for (int i = 0; i < price.Count(); i++) 
                {
                    if (_stockPrices[i].TimeStamp > time) 
                    {
                        return _stockPrices[i].Price;
                    }
                }
                return _stockPrices.Last().Price;
            }
            public decimal GetTotalValueOnDate(DateTime time)
            {
                return numberOfShare * PriceAtDate(time);
            }            
           
        }

        public class StockPrice 
        {
            public StockPrice(decimal price, DateTime timeStamp)
            {
                Price = price;
                TimeStamp = timeStamp;
            }
            public decimal Price { get; set; }
            public DateTime TimeStamp { get; set; }
        }

        public class Index
        {
            public Index(string name, IndexTypes type)
            {
                Name = name;
                Type = type;
                stocks = new List<string>();
            }
            public string Name { get; set; }
            public IndexTypes Type { get; set; }
            List<string> stocks;
            public bool IsStockInIndex(string stockName)
            {
                return stocks.Contains(stockName.ToLower());
            }
            public int NumberOfStock()
            {
                return stocks.Count();
            }
            public List<string> Stocks { get { return stocks; } }
            public void AddStock(string stockName)
            { stocks.Add(stockName.ToLower()); }
            public void RemoveStock(string stockname)
            { stocks.Remove(stockname.ToLower()); }
        }

        public class Portfolio
        {
            public Portfolio(string id)
            {
                ID = id;
                _items = new List<PortfolioItem>();
            }
            public string ID { get; set; }
            private List<PortfolioItem> _items;
    
            public void AddStock(string stockName,int numberOfShares)
            {
                foreach (PortfolioItem pi in _items)
                {
                    if (pi.StockName == stockName)
                    {
                        pi.Count += numberOfShares;
                        return;
                    }
                }
                _items.Add(new PortfolioItem{StockName=stockName,Count=numberOfShares});

            }

            public List<PortfolioItem> Stocks { get { return _items; } }
            public void RemoveStockFromPortfolio(string stockName)
            {
                for (int i = 0; i < _items.Count(); i++) 
                {
                    if (_items[i].StockName.ToLower() == stockName.ToLower())
                    {
                        _items.RemoveAt(i);
                        break;
                    }
                }
            }
            public void RemoveStockFromPortfolio(string stockName, int count)
            {
                for (int i = 0; i < _items.Count(); i++)
                {
                    if (_items[i].StockName.ToLower() == stockName.ToLower())
                    {
                        _items[i].Count -= count;
                        if (_items[i].Count <= 0) _items.RemoveAt(i);
                        break;
                    }
                }
            }
            public bool ContainsStock(string stockName)
            {
                for (int i = 0; i < _items.Count(); i++)
                {
                    if (_items[i].StockName.ToLower() == stockName.ToLower()) return true;
                }
                return false;
            }
        }
        
        public class PortfolioItem
        {
            public string StockName;
            public int Count;
        }

     public class StockExchange : IStockExchange
     {
         private List<Stock> _stocks;
         private List<Index> _indexes;
         private List<Portfolio> _portfolios;
         public StockExchange()
         {
             _stocks = new List<Stock>();
             _indexes = new List<Index>();
             _portfolios = new List<Portfolio>();
         }

         


         #region Stocks
         private bool ValidateStockName(string inStockName, long inNumberOfShares, decimal inPrice)
         {
             if(  inNumberOfShares > 0 && inPrice > 0){
                foreach (Stock s in _stocks)
                {
                    if (s.Name == inStockName.ToLower()) return false;
                }
                return true;
             }
             return false;
         }
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (_stocks != null)
             {
                 if (ValidateStockName(inStockName, inNumberOfShares, inInitialPrice))
                 {
                     _stocks.Add(new Stock(inStockName.ToLower(), inNumberOfShares, new StockPrice(inInitialPrice, inTimeStamp)));
                 }
                 else { throw new StockExchangeException("Validation not passed for adding Stock"); };

             }
         }
         public void DelistStock(string inStockName)
         {
             for (int i = 0; i < _stocks.Count(); i++) 
             {
                 if (_stocks[i].Name == inStockName.ToLower())
                 {
                     _stocks.RemoveAt(i);
                 }
             }
             for (int i = 0; i < _indexes.Count(); i++)
             {
                 if (_indexes[i].Stocks.Contains(inStockName))
                 {
                     _indexes[i].Stocks.Remove(inStockName);
                 }
             }
             for (int i = 0; i < _portfolios.Count(); i++)
             {
                 for (int j = 0; j < _portfolios[i].Stocks.Count; j++)
                 {
                     if (_portfolios[i].Stocks[j].StockName.ToLower() == inStockName.ToLower())
                     {
                         _portfolios[i].Stocks.RemoveAt(j);
                     }
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock s in _stocks)
             {
                 if (s.Name == inStockName.ToLower()) return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return _stocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             for (int i = 0; i < _stocks.Count(); i++)
             {
                 if (_stocks[i].Name == inStockName.ToLower())
                 {
                     _stocks[i].SetPrice(new StockPrice(inStockValue, inTimeStamp));
                 }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             foreach (Stock s in _stocks)
             {
                 if (s.Name == inStockName.ToLower())
                 {
                     return s.PriceAtDate(inTimeStamp);
                 }
             }
             throw new StockExchangeException("Stock not found");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return _stocks.Where(x => x.Name == inStockName.ToLower()).First()._stockPrices[0].Price;
             throw new StockExchangeException("Stock not found");
         }


         public decimal GetLastStockPrice(string inStockName)
         {
             return _stocks.Where(x => x.Name == inStockName.ToLower()).First()._stockPrices.Last().Price;
             throw new StockExchangeException("Stock not found");
         }
         #endregion

         #region Index
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if(_indexes.Where(x=>x.Name.ToLower()==inIndexName.ToLower())==null)throw new StockExchangeException("index not found");
             _indexes.Add(new Index(inIndexName.ToLower(), inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             
               Index s= _indexes.Where(x => x.Name.ToLower() == inIndexName.ToLower()).First();
               if (s != null) s.AddStock(inStockName);
               else throw new StockExchangeException("Index not found");

         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index s = _indexes.Where(x => x.Name == inIndexName.ToLower()).First();
             if(s!=null)s.RemoveStock(inStockName);
             else throw new StockExchangeException("Index not found");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in _indexes)
             {
                 if (index.Name == inIndexName.ToLower())
                 {
                     return index.IsStockInIndex(inStockName);
                 }
             }
             throw  new StockExchangeException("Index not found"); 

         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             foreach(Index i in _indexes)
          {

                 if(i.Name.ToLower()==inIndexName.ToLower())
                 {
                     decimal indexValue = 0;
                     switch(i.Type)
                     {
                         case(IndexTypes.AVERAGE):
                            
                            foreach (string s in i.Stocks)
                            {
                                //indexValue+=_stocks.Where(x => x.Name.ToLower() == s.ToLower()).Select(x => x.PriceAtDate(inTimeStamp)).First();
                                foreach (Stock stock in _stocks)
                                {
                                    if (stock.Name.ToLower() == s.ToLower())
                                    {
                                        indexValue += stock.PriceAtDate(inTimeStamp);
                                    }    
                                }
                            }
                            return Math.Round(indexValue/i.Stocks.Count(),3);        
                         case(IndexTypes.WEIGHTED):
                            decimal TotalValueOfAllStocks = 0;
                           
                            foreach (string s in i.Stocks)
                            {
                                //indexValue+=_stocks.Where(x => x.Name.ToLower() == s.ToLower()).Select(x => x.PriceAtDate(inTimeStamp)).First();
                                foreach (Stock stock in _stocks)
                                {
                                    if (stock.Name.ToLower() == s.ToLower())
                                    {
                                        TotalValueOfAllStocks += stock.GetTotalValueOnDate(inTimeStamp);
                                    }
                                }

                            }

                            foreach (string s in i.Stocks)
                            {
                                //indexValue+=_stocks.Where(x => x.Name.ToLower() == s.ToLower()).Select(x => x.PriceAtDate(inTimeStamp)).First();
                                foreach (Stock stock in _stocks)
                                {
                                    if (stock.Name.ToLower() == s.ToLower())
                                    {
                                        indexValue += stock.PriceAtDate(inTimeStamp) / TotalValueOfAllStocks * stock.numberOfShare * stock.PriceAtDate(inTimeStamp);
                                    }
                                }
                                

                            }
                            return Math.Round(indexValue, 3);
                             
                         default:
                             throw new StockExchangeException("asda");
                     }
                 }
             }
             throw new StockExchangeException("Index not found");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index index in _indexes)
             {
                 if (index.Name.ToLower() == inIndexName.ToLower()) return true;
             }
                 return false;
         }

         public int NumberOfIndices()
         {
             return _indexes.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _indexes.Where(x => x.Name ==inIndexName.ToLower()).First().NumberOfStock();
         }
        #endregion  
         
         #region Portfolio

         private bool ValidatePortfolioId(string id)
         {
             return _portfolios.Where(x => x.ID == id).Count() == 0;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(ValidatePortfolioId(inPortfolioID))
             {
             _portfolios.Add(new Portfolio(inPortfolioID));
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _portfolios.Where(x => x.ID == inPortfolioID).First().AddStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _portfolios.Where(x => x.ID == inPortfolioID).First().RemoveStockFromPortfolio(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             _portfolios.Where(x => x.ID == inPortfolioID).First().RemoveStockFromPortfolio(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return _portfolios.Where(x => x.ID == inPortfolioID).First().Stocks.Count();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.Where(x => x.ID == inPortfolioID).Count() == 0 ? true : false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio p in _portfolios)
             {
                 if (p.ID == inPortfolioID)
                 {
                     return p.ContainsStock(inStockName);
                 }
             }
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
                foreach (Portfolio p in _portfolios)
                {
                    if (p.ID == inPortfolioID)
                    {
                        return p.Stocks.Where(x=>x.StockName.ToLower()==inStockName.ToLower()).Select(x=>x.Count).First();
                    }
                }
                throw new StockExchangeException("Stock not in portfolio");
                   
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             for (int i = 0; i < _portfolios.Count(); i++)
             {
                 if (_portfolios[i].ID == inPortfolioID)
                 {
                     decimal totalValue = 0;
                     foreach (PortfolioItem p in _portfolios[i].Stocks)
                     {
                        totalValue+=_stocks.Where(x=>x.Name.ToLower()==p.StockName.ToLower()).First().PriceAtDate(timeStamp)*p.Count;
                     }
                     return totalValue;
                 }
             }
             throw new StockExchangeException("Portfolio not found");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
            return Math.Round(GetPortfolioValue(inPortfolioID,new DateTime(Year,Month,1 ))/GetPortfolioValue(inPortfolioID, new DateTime( DateTime.DaysInMonth(Year,Month))),3);
         }
         #endregion

     }
}
