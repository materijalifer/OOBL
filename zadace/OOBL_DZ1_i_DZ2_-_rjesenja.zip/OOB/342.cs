﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DrugaDomacaZadaca_Burza
{
    /// <summary>
    /// Factory obrazac za kreiranje instance burze
    /// </summary>
    public static class Factory
    {
        /// <summary>
        /// Metoda koja stvara novu instancu burze
        /// </summary>
        /// <returns>IStockExchange</returns>
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Razred koji implementira sve funkcionalnosti burze zadane u zadaći
    /// Implemetira zadano sučelje IStockExcange
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private List<Stock> stocks;            // Lista svih dionica u sustavu burze
        private List<Index> indexs;            // Lista svih indeksa u sustvau burze
        private List<Portfolio> portfolios;    // Lista svih portfolia u sustvau burze

        /// <summary>
        /// Konstruktor bez parametera koji inicijalizira sve liste u sustavu
        /// </summary>
        public StockExchange()
        {
            stocks = new List<Stock>();
            indexs = new List<Index>();
            portfolios = new List<Portfolio>();
        }

        /// <summary>
        /// Dodavanje nove dionice u burzu
        /// Baca iznimku ako dionica već postoji u burzi
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inNumberOfShares">Broj dijelova dionice</param>
        /// <param name="inInitialPrice">Cijena dionice</param>
        /// <param name="inTimeStamp">Od kada cijena vrijedi</param>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Stock " + inStockName + " already exist in StockExchange.");
            }
            stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        /// <summary>
        /// Brisanje dionice iz burze
        /// Baca iznimku ako dionica nije u burzi
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        public void DelistStock(string inStockName)
        {
            Stock s = findStock(inStockName);
            foreach (Index i in indexs)
            {
                if (i.checkStock(s))
                    i.removeStock(s);
            }
            foreach (Portfolio p in portfolios)
            {
                if (p.StockExists(s))
                    p.removeStock(s);
            }
            stocks.Remove(s);
        }

        /// <summary>
        /// Provjera da li se dionica nalazi u burzi
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>true ako se nalazi, false inače</returns>
        public bool StockExists(string inStockName)
        {
            foreach (Stock s in stocks)
            {
                inStockName = inStockName.ToLower();
                if (s.Name.Equals(inStockName))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Broj dionica trenutno na burzi
        /// </summary>
        /// <returns>stocks.Count</returns>
        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        /// <summary>
        /// Postavljanje cijene dionice
        /// Cijena se može postaviti za bilo koje vrijeme što znaći trenutno, budeće ili prošlo
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inTimeStamp">Od kada cijena vrijedi</param>
        /// <param name="inStockValue">Cijena</param>
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            Stock stock = findStock(inStockName);
            stock.setNewPrice(inStockValue, inTimeStamp);
        }

        /// <summary>
        /// Dohvaćanje cijene dionice za neko vrijeme
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inTimeStamp">Od kada cijena vrijedi</param>
        /// <returns>cijenu zaokruženu na 3 decimale</returns>
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = findStock(inStockName);
            return round(stock.getPrice(inTimeStamp));
        }

        /// <summary>
        /// Vraća najraniju cijenu dionice
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>cijenu zaokruženu na 3 decimale</returns>
        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = findStock(inStockName);
            return round(stock.getInitialPrice());
        }

        /// <summary>
        /// Vraća zadnju cijenu dionice
        /// </summary>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>cijenu zaokruženu na 3 decimale</returns>
        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = findStock(inStockName);
            return round(stock.getLastPrice());
        }

        /// <summary>
        /// Stvaranje novog indeksa
        /// Baca iznimku ako indeks već postoji na burzi
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inIndexType">Tip indeksa</param>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index " + inIndexName + " already exist in StockExchange.");
            }
            indexs.Add(new Index(inIndexName, inIndexType));
        }

        /// <summary>
        /// Dodavanje dionice u indeks
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = findIndex(inIndexName);
            Stock stock = findStock(inStockName);
            index.addStock(stock);
        }

        /// <summary>
        /// Brisanje dionice iz indeksa
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = findIndex(inIndexName);
            Stock stock = findStock(inStockName);
            index.removeStock(stock);
        }

        /// <summary>
        /// Provjera dali se dionica nalazi u indeksu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>true ako se nalazi, false inače</returns>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = findIndex(inIndexName);
            Stock stock = findStock(inStockName);
            return index.checkStock(stock);
        }

        /// <summary>
        /// Izračunavanje vrijednosti indeksa koje je ovisno o tipu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="inTimeStamp">Traženo vrijeme</param>
        /// <returns>vrijednost indeksa zaokruženu na 3 decimale</returns>
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = findIndex(inIndexName);
            return round(index.calculateValue(inTimeStamp));
        }

        /// <summary>
        /// Provjera da li indeks postoji u burzi
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>true ako postoji, false inače</returns>
        public bool IndexExists(string inIndexName)
        {
            foreach (Index i in indexs)
            {
                inIndexName = inIndexName.ToLower();
                if (i.Name.Equals(inIndexName))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Broj indeksa trenutno na burzi
        /// </summary>
        /// <returns>indexs.Count</returns>
        public int NumberOfIndices()
        {
            return indexs.Count;
        }

        /// <summary>
        /// Ukupan broj dionica u nekom indeksu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>Ukupan broj dionica</returns>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = findIndex(inIndexName);
            return index.numberOfStocks();
        }

        /// <summary>
        /// Stvaranje novog portfolia
        /// Baca iznimku ako portfolio već postoji u burzi
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio " + inPortfolioID + " already exist in StockExchange.");
            }
            portfolios.Add(new Portfolio(inPortfolioID));
        }

        /// <summary>
        /// Dodavanje određenog broja dijelova dionice u neki portfolio
        /// Baca exception trenutni broj dijelova dionica koji se pokuša dodati
        /// premašuje ukupan zbroj dijelove te dionice u portfolima u burzi
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="numberOfShares">Broj dijelova dionice koji se dodaje</param>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            Stock stock = findStock(inStockName);
            if (stock.NumberOfPortfolioShares + numberOfShares > stock.NumberOfShares)
                throw new StockExchangeException("Portfolios can't have more shares then stock have.");
            stock.NumberOfPortfolioShares += numberOfShares;
            portfolio.addStock(stock, numberOfShares);
        }

        /// <summary>
        /// Smanjivanje broja dijelova dionice u nekom portfoliu
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <param name="numberOfShares">Broj dijelova dionice za koji se smanjuje trenutni broj</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            Stock stock = findStock(inStockName);
            portfolio.removeStock(stock, numberOfShares);
        }

        /// <summary>
        /// Potpuno brisanje dionice iz portfolia
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            Stock stock = findStock(inStockName);
            portfolio.removeStock(stock);
        }

        /// <summary>
        /// Trenutni broj portfolia u burzi
        /// </summary>
        /// <returns>portfolios.Count</returns>
        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        /// <summary>
        /// Ukupan broj dionica u nekom portfoliu
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <returns></returns>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio p = findPortfolio(inPortfolioID);
            return p.numberOfStock;
        }

        /// <summary>
        /// Provjera da li portfolio postoji u burzi
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <returns>true ako postoji, false inače</returns>
        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio p in portfolios)
            {
                if (p.ID.Equals(inPortfolioID))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Provjera da li je neka dionica u portfoliu
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>true ako je, false inače</returns>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            Stock stock = findStock(inStockName);
            return portfolio.StockExists(stock);
        }

        /// <summary>
        /// Točan broj dijelova neke dionice u portfoliu
        /// </summary>
        /// /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="inStockName">Ime dionice (jedinstveni ključ koji nije Case sensitive)</param>
        /// <returns>Broj dijelova</returns>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            Stock stock = findStock(inStockName);

            return portfolio.stockShares(stock);
        }

        /// <summary>
        /// Izračunavanje vrijednosti portfolia
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="timeStamp">Vrijeme za koje se izračunava</param>
        /// <returns>Vrijednost portfolia zaokruženo na 3 decimale</returns>
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = findPortfolio(inPortfolioID);
            return round(portfolio.getValue(timeStamp));
        }

        /// <summary>
        /// Izračun promjene vrijednosti portfolia na kraju mjeseca u odnosu na njegov početak
        /// Baca iznimku ako vrijednost porfolia nije definirana za zadani mjesec
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia (Case sensitive)</param>
        /// <param name="Year">Godina</param>
        /// <param name="Month">Mjesec</param>
        /// <returns>Mjesečnu promjenu u postotcima zaokruženu na 3 decimale</returns>
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (Year < 0)
            {
                throw new StockExchangeException("Year can't be negativ.");
            }
            if (Month > 12 || Month < 1)
            {
                throw new StockExchangeException("Month must be integer number form 1  to 12.");
            }
            Portfolio portfolio = findPortfolio(inPortfolioID);
            if (portfolio.numberOfStock == 0)
                return 0;
            return round(portfolio.monthValueChange(Year, Month));
        }

        /// <summary>
        /// Pomoćna funkcija za pronalaženje dionice
        /// </summary>
        /// <param name="name">Ime dionice</param>
        /// <returns>Stock</returns>
        private Stock findStock(string name)
        {
            name = name.ToLower();
            foreach (Stock s in stocks)
            {
                if (s.Name.Equals(name))
                    return s;
            }
            throw new StockExchangeException("Stock " + name + " not in StockExchange.");
        }

        /// <summary>
        /// Pomoćna funkcija za pronalaženje indeksa
        /// </summary>
        /// <param name="name">Ime indeksa</param>
        /// <returns>Index</returns>
        private Index findIndex(string name)
        {
            name = name.ToLower();
            foreach (Index i in indexs)
            {
                if (i.Name.Equals(name))
                    return i;
            }
            throw new StockExchangeException("Index " + name + " not in StockExchange.");
        }

        /// <summary>
        /// Pomoćna funkcija za pronalaženje portfolia
        /// </summary>
        /// <param name="name">Ime portfolia</param>
        /// <returns>Portfolio</returns>
        private Portfolio findPortfolio(string name)
        {
            foreach (Portfolio p in portfolios)
            {
                if (p.ID.Equals(name))
                    return p;
            }
            throw new StockExchangeException("Portfolio " + name + " not in StockExchange.");
        }

        /// <summary>
        /// Funkcija koja zaokružuje decimalni broj na 3 decimale
        /// </summary>
        /// <param name="number">broj</param>
        /// <returns>broj zaokružen na 3 deicmale</returns>
        private decimal round(decimal number)
        {
            return Decimal.Round(number, 3, MidpointRounding.AwayFromZero);
        }
    }

    /// <summary>
    /// Razred dionica
    /// </summary>
    public class Stock
    {
        private string name;                        // Jedinstveni ključ koji određuje dionicu
        private long numberOfShares;                // Ukupan broj dijelova u dionici
        private long numberOfSharesInPortfolios;    // Broj dijelova dionice dodjeljen portfolima
        private List<StockPrice> priceHistory;      // Povjest promjene cijene dionice

        /// <summary>
        /// Konstruktor sa parametrima
        /// Baca iznimku ako neki od parametara nije logičan
        /// </summary>
        /// <param name="name">ključ</param>
        /// <param name="numberOfShares">ukupan broj dijelova</param>
        /// <param name="initialPrice">cijena</param>
        /// <param name="date">od kada cijena vrijedi</param>
        public Stock(string name, long numberOfShares, decimal initialPrice, DateTime date)
        {
            this.name = name;
            if (numberOfShares > 0)
                this.numberOfShares = numberOfShares;
            else
                throw new StockExchangeException("Number of shares must be grater then 0.");
            if (initialPrice > 0)
            {
                priceHistory = new List<StockPrice> { new StockPrice(initialPrice, date) };
            }
            else
                throw new StockExchangeException("Price must be grater then 0.");
            numberOfSharesInPortfolios = 0;
        }

        /// <summary>
        /// Properti koji sadrži samo get za ključ
        /// </summary>
        public string Name
        {
            get { return name.ToLower(); }
        }

        /// <summary>
        /// Properti koji sadrži samo get za broj dijelova dionice
        /// </summary>
        public long NumberOfShares
        {
            get { return numberOfShares; }
        }
        
        /// <summary>
        /// Properti koji sadrži i get i set za broj dijelova dionice dodjeljen portfolima
        /// </summary>
        public long NumberOfPortfolioShares
        {
            get { return numberOfSharesInPortfolios; }
            set { numberOfSharesInPortfolios = value; }
        }

        /// <summary>
        /// Metoda za dodavanje još jedne cijene 
        /// </summary>
        /// <param name="inStockValue">cijena</param>
        /// <param name="inTimeStamp">vrijeme od kada vrijedi</param>
        internal void setNewPrice(decimal inStockValue, DateTime inTimeStamp)
        {
            if (inStockValue > 0)
            {
                priceHistory.Add(new StockPrice(inStockValue, inTimeStamp));
            }
            else
                throw new StockExchangeException("Price must be grater then 0.");
        }

        /// <summary>
        /// Metoda za dohvat cijene dionice za neko razdoblje
        /// </summary>
        /// <param name="inTimeStamp">Razdoblje</param>
        /// <returns>cijena dionice</returns>
        internal decimal getPrice(DateTime inTimeStamp)
        {
            priceHistory.Sort();
            priceHistory.Reverse();
            foreach (StockPrice p in priceHistory)
            {
                if (p.Time <= inTimeStamp)
                    return p.Price;
            }
            throw new StockExchangeException("Stock was define after " + inTimeStamp.ToLongDateString());
        }

        /// <summary>
        /// Dohvaćanje prve cijene dionice
        /// </summary>
        /// <returns>cijena dionice</returns>
        internal decimal getInitialPrice()
        {
            priceHistory.Sort();
            return priceHistory.First().Price;
        }

        /// <summary>
        /// Dohvaćanje zadnje cijene dionice
        /// </summary>
        /// <returns>cijena dionice</returns>
        internal decimal getLastPrice()
        {
            priceHistory.Sort();
            return priceHistory.Last().Price;
        }
    }

    /// <summary>
    /// Razred Indeks
    /// </summary>
    public class Index
    {
        private string name;            // Ključ indeksa
        private IndexTypes type;        // Tip indeksa
        private List<Stock> stocks;     // Lista dionica u indeksu

        /// <summary>
        /// Konstruktor sa parametrima
        /// Basa iznimku ako tip nije ispravan
        /// </summary>
        /// <param name="inIndexName">kluč</param>
        /// <param name="inIndexType">tip</param>
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if (!inIndexType.Equals(IndexTypes.AVERAGE) && !inIndexType.Equals(IndexTypes.WEIGHTED))
                throw new StockExchangeException("Wrong index type.");
            name = inIndexName;
            type = inIndexType;
            stocks = new List<Stock>();
        }

        /// <summary>
        /// Properti koji sadrži samo get za ključ
        /// </summary>
        public string Name
        {
            get { return name.ToLower(); }
        }

        /// <summary>
        /// Dodavanje dionice u indeks
        /// </summary>
        /// <param name="stock">dionica</param>
        internal void addStock(Stock stock)
        {
            if (!stocks.Contains(stock))
                stocks.Add(stock);
            else
                throw new StockExchangeException("Stock is already in Index.");

        }

        /// <summary>
        /// Brisane dionice iz indeksa
        /// </summary>
        /// <param name="stock">dionica</param>
        internal void removeStock(Stock stock)
        {
            if (stocks.Contains(stock))
                stocks.Remove(stock);
            else
            {
                throw new StockExchangeException("Stock isn't in Index.");
            }
        }

        /// <summary>
        /// Provjera da li se dionica nalazi u indeksu
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <returns>true ako se nalazi, false inače</returns>
        internal bool checkStock(Stock stock)
        {
            if (stocks.Contains(stock))
                return true;
            return false;
        }

        /// <summary>
        /// Izračun vrijendosti indeksa za neko vrijeme
        /// Ova metoda u ovisnosti o tipu indeksa poziva različite druge metode za izračun vrijednosti
        /// </summary>
        /// <param name="inTimeStamp">vrijeme</param>
        /// <returns>vrijednost indeksa</returns>
        internal decimal calculateValue(DateTime inTimeStamp)
        {
            if (stocks.Count == 0)
                return 0;
            if (type == IndexTypes.AVERAGE)
                return calcualteAverageValue(inTimeStamp);
            if (type == IndexTypes.WEIGHTED)
                return calcualteWeightedValue(inTimeStamp);
            throw new StockExchangeException("Wrong IndexType.");
        }

        /// <summary>
        /// Izračun težinske vrijednosti indeksa
        /// </summary>
        /// <param name="inTimeStamp">vrijeme</param>
        /// <returns>težinsku vrijednost indeksa</returns>
        private decimal calcualteWeightedValue(DateTime inTimeStamp)
        {
            decimal holeSum = 0;
            decimal sum = 0;
            foreach (Stock s in stocks)
            {
                holeSum += s.getPrice(inTimeStamp) * s.NumberOfShares;
            }
            foreach (Stock s in stocks)
            {
                decimal p = s.getPrice(inTimeStamp);
                sum += (s.NumberOfShares * p / holeSum) * p;
            }
            return sum;
        }

        /// <summary>
        /// Izračun prosječne vrijednosti indeksa
        /// </summary>
        /// <param name="inTimeStamp">vrijeme</param>
        /// <returns>prosječnu vrijendost indeksa</returns>
        private decimal calcualteAverageValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (Stock s in stocks)
            {
                sum += s.getPrice(inTimeStamp);
            }
            return sum / stocks.Count;
        }

        /// <summary>
        /// Broj dionica u indeksu
        /// </summary>
        /// <returns>stocks.Count</returns>
        internal int numberOfStocks()
        {
            return stocks.Count;
        }
    }

    /// <summary>
    /// Razred portfolio
    /// </summary>
    public class Portfolio
    {
        private string id;                      // ID portfolia
        private List<PortfolioStock> stocks;    // Dionice u portfoliu

        /// <summary>
        /// Konstruktor s paremetrom
        /// </summary>
        /// <param name="inPortfolioID">ID</param>
        public Portfolio(string inPortfolioID)
        {
            id = inPortfolioID;
            stocks = new List<PortfolioStock>();
        }

        /// <summary>
        /// Properti sa get za id
        /// </summary>
        public string ID
        {
            get { return id; }
        }

        /// <summary>
        /// Properti sa get za broj dionica
        /// </summary>
        public int numberOfStock
        {
            get { return stocks.Count; }
        }

        /// <summary>
        /// Dodavanje dijelova dionice u portfolio
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <param name="numberOfShares">broj dijelova</param>
        internal void addStock(Stock stock, int numberOfShares)
        {
            if (!StockExists(stock))
            {
                stocks.Add(new PortfolioStock(stock, numberOfShares));
            }
            else
            {
                PortfolioStock p = findStock(stock);
                p.addShares(numberOfShares);
            }
        }

        /// <summary>
        /// Brisanje dijelova dionice iz portfolia
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <param name="numberOfShares">broj dijelova</param>
        internal void removeStock(Stock stock, int numberOfShares)
        {
            if (StockExists(stock))
            {
                PortfolioStock p = findStock(stock);
                if (p.numberOfShares - numberOfShares > 0)
                    p.reduceNumberOfShares(numberOfShares);
                else if (p.numberOfShares - numberOfShares == 0)
                    stocks.Remove(p);
                else
                    throw new StockExchangeException("Can't reduce number of shares in portfolio.");
            }
        }

        /// <summary>
        /// Brisanje dionice iz portfolia
        /// </summary>
        /// <param name="stock">dionica</param>
        internal void removeStock(Stock stock)
        {
            if (StockExists(stock))
            {
                PortfolioStock p = findStock(stock);
                stocks.Remove(p);
            }
            else
            {
                throw new StockExchangeException("Portfolio Stock isn't in portfolio.");
            }
        }

        /// <summary>
        /// Pronalaženje dionice u portfliu
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <returns>PortfolioStock</returns>
        private PortfolioStock findStock(Stock stock)
        {
            foreach (PortfolioStock s in stocks)
            {
                if (s.Stock.Equals(stock))
                    return s;
            }
            throw new StockExchangeException("PortfolioStock doesen't exist.");
        }

        /// <summary>
        /// Provjera da li se dionica nalazi u portfoliu
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        internal bool StockExists(Stock stock)
        {
            foreach (PortfolioStock s in stocks)
            {
                if (s.Stock.Equals(stock))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Broj dijelova dionice koji se nalaze u portfoliu
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <returns>broj dijelova</returns>
        internal int stockShares(Stock stock)
        {
            PortfolioStock p = findStock(stock);
            return p.numberOfShares;
        }

        /// <summary>
        /// Izračun vrijednosti portfolia
        /// </summary>
        /// <param name="timeStamp">vrijeme</param>
        /// <returns>vrijednost portfolia</returns>
        internal decimal getValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (PortfolioStock ps in stocks)
            {
                sum += ps.Stock.getPrice(timeStamp) * ps.numberOfShares;
            }
            return sum;
        }

        /// <summary>
        /// Izračun mjesečne promjene vrijednosti portfolia
        /// Baca iznimku ako nije definirana vrijednost portfolia na početku mjeseca
        /// </summary>
        /// <param name="Year">godina</param>
        /// <param name="Month">mjesec</param>
        /// <returns>mjesečnu promjenu vrijednsoti portfolia izraženu u postotcima</returns>
        internal decimal monthValueChange(int Year, int Month)
        {
            DateTime first = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime last = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            decimal endMonthprice = getValue(last);
            decimal begingMonthprice = getValue(first);
            if (begingMonthprice == 0)
                throw new StockExchangeException("Stock price hasn't been seted for the begining of a month.");
            return (endMonthprice - begingMonthprice) / begingMonthprice * 100;
        }
    }

    /// <summary>
    /// Razred za dionicu u portfoli
    /// </summary>
    public class PortfolioStock
    {
        private Stock stock;                    // Dionica
        private int stockSharesInPortfolio;     // Broj dijelova dionice u portfoliu

        /// <summary>
        /// Konstruktor sa parametrima
        /// </summary>
        /// <param name="stock">dionica</param>
        /// <param name="numberOfShares">broj dijelova dionice u portfoliu</param>
        public PortfolioStock(Stock stock, int numberOfShares)
        {
            this.stock = stock;
            stockSharesInPortfolio = numberOfShares;
        }

        /// <summary>
        /// Properti sa get za dionicu
        /// </summary>
        public Stock Stock
        {
            get { return stock; }
        }

        /// <summary>
        /// Properti sa get za broj dijelova
        /// </summary>
        public int numberOfShares
        {
            get { return stockSharesInPortfolio; }
        }

        /// <summary>
        /// Smanjivanje broja dijelova dionice
        /// </summary>
        /// <param name="numberOfShares">dijelovi dionice</param>
        internal void reduceNumberOfShares(int numberOfShares)
        {
            stockSharesInPortfolio -= numberOfShares;
        }

        /// <summary>
        /// Dodajvanje broja dijelova dionice
        /// </summary>
        /// <param name="numberOfShares">dijelovi dionice</param>
        internal void addShares(int numberOfShares)
        {
            stockSharesInPortfolio += numberOfShares;
        }
    }

    /// <summary>
    /// Razred cijene dionice
    /// Implementira sučelje IComparable kako bi se cijene dionice mogle sortirati 
    /// unutar liste po vremenu od kada cijene vrijede
    /// </summary>
    public class StockPrice : IComparable
    {
        private decimal price;          // Cijena
        private DateTime worthFrom;     // Vrijeme od kada vrijedi cijena
        
        /// <summary>
        /// Konstruktor sa parametrima
        /// </summary>
        /// <param name="initialPrice">cijena</param>
        /// <param name="date">vrijeme</param>
        public StockPrice(decimal initialPrice, DateTime date)
        {
            price = initialPrice;
            worthFrom = date;
        }

        /// <summary>
        /// Properti za sa get za cijenu
        /// </summary>
        public decimal Price
        {
            get { return price; }
        }

        /// <summary>
        /// Properti sa get za vrijeme
        /// </summary>
        public DateTime Time
        {
            get { return worthFrom; }
        }

        public int CompareTo(object obj)
        {
            StockPrice sp = (StockPrice)obj;
            if (worthFrom < sp.worthFrom)
                return -1;
            if (worthFrom > sp.worthFrom)
                return 1;
            return 0;
        }
    }
}
