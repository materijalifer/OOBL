﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
		private const int maxDigitsLength = 10;
		private const decimal maxResultValue = 9999999999.5m;

        private NumberFormatInfo numberFormatInfo = new NumberFormatInfo();

		private decimal aggregateResult = 0;
		private string currentDisplay = "0";
		private char activeOperator = '=';
		private char previousKey = '=';
		private string currentMemory = null;

        public Kalkulator()
        {
            numberFormatInfo.NumberDecimalSeparator = ",";
            numberFormatInfo.NumberGroupSeparator = "";
        }
	
        public void Press(char pressedKey)
        {
			try {
				if (Char.IsDigit(pressedKey)) {
					PressDigit(pressedKey);
				} else if (pressedKey == '+' || pressedKey == '-' || pressedKey == '*' || pressedKey == '/') {
					PressBinaryOperator(pressedKey);
				} else if (pressedKey == '=') {
					PressEquals();
				} else if (pressedKey == ',') {
					PressComma();
				} else if (pressedKey == 'M' || pressedKey == 'S' || pressedKey == 'K' || pressedKey == 'T' || pressedKey == 'Q' || pressedKey == 'R' || pressedKey == 'I' || pressedKey == 'P' || pressedKey == 'G') {
					PressUnaryOperator(pressedKey);
				} else if (pressedKey == 'C') {
					PressClear();
				} else if (pressedKey == 'O') {
					PressReset();
				} else {
					throw new NotImplementedException();
				}
			} catch (Exception e) {
				Error();
				return;
			}
            
			previousKey = pressedKey;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplay;
        }
		
		private void PressDigit(char digit)
		{
            if (ShouldAppendPress()) {
                if (GetDigitsLength(currentDisplay) < maxDigitsLength) {
                    currentDisplay += digit;
                }
			} else {
				currentDisplay = new string(digit, 1);
			}
		}
		
		private void PressBinaryOperator(char op)
		{
			if (previousKey != '+' && previousKey != '-' && previousKey != '*' && previousKey != '/') {
				decimal operationResult = getDecimal(currentDisplay);
				if (activeOperator == '+') {
					operationResult = aggregateResult + operationResult;
				} else if (activeOperator == '-') {
					operationResult = aggregateResult - operationResult;
				} else if (activeOperator == '*') {
					operationResult = aggregateResult * operationResult;
				} else if (activeOperator == '/') {
					operationResult = aggregateResult / operationResult;
				}
				
				CommitOperationResult(operationResult, true);
			}
			
			activeOperator = op;
		}
		
		private void PressEquals()
		{
			decimal operationResult = getDecimal(currentDisplay);
			if (activeOperator == '+') {
				operationResult = aggregateResult + operationResult;
			} else if (activeOperator == '-') {
				operationResult = aggregateResult - operationResult;
			} else if (activeOperator == '*') {
				operationResult = aggregateResult * operationResult;
			} else if (activeOperator == '/') {
				operationResult = aggregateResult / operationResult;
			}
			
			CommitOperationResult(operationResult, true);
			
			activeOperator = '=';
		}
		
		private void PressComma()
		{
            if (ShouldAppendPress()) {
                if (!currentDisplay.Contains(",")) {
                    currentDisplay += ',';
                }
            } else {
                currentDisplay = "0,";
            }
		}
		
		private void PressUnaryOperator(char op)
		{
			decimal operationResult = getDecimal(currentDisplay);
			if (op == 'M') {
				operationResult = -operationResult;
			} else if (op == 'S') {
				operationResult = new decimal(Math.Sin(Decimal.ToDouble(operationResult)));
			} else if (op == 'K') {
				operationResult = new decimal(Math.Cos(Decimal.ToDouble(operationResult)));
			} else if (op == 'T') {
                operationResult = new decimal(Math.Tan(Decimal.ToDouble(operationResult)));
			} else if (op == 'Q') {
				operationResult *= operationResult;
			} else if (op == 'R') {
                operationResult = new decimal(Math.Sqrt(Decimal.ToDouble(operationResult)));
			} else if (op == 'I') {
				operationResult = Decimal.One / operationResult;
			} else if (op == 'P') {
				currentMemory = currentDisplay;
				return;
			} else if (op == 'G' && currentMemory != null) {
				currentDisplay = currentMemory;
				return;
			}
			
			CommitOperationResult(operationResult, false);
		}
		
		private void CommitOperationResult(decimal operationResult, bool toAggregate)
		{
			if (!IsValid(operationResult)) {
				throw new Exception();
			}

            operationResult = GetRounded(operationResult);
            currentDisplay = operationResult.ToString("0.#########", numberFormatInfo);

            if (toAggregate) {
                aggregateResult = operationResult;
            }
		}
		
		private void PressClear()
		{
			currentDisplay = "0";
		}
		
		private void PressReset()
		{
			aggregateResult = 0;
			currentDisplay = "0";
			activeOperator = '=';
			previousKey = '=';
		}
		
		private void Error()
		{
			aggregateResult = 0;
			currentDisplay = "-E-";
			activeOperator = '=';
			previousKey = '=';
		}

        private bool ShouldAppendPress()
        {
            return !currentDisplay.Equals("-E-") && !currentDisplay.Equals("0") && (Char.IsDigit(previousKey) || previousKey == ',' || previousKey == 'M' || previousKey == 'P');
        }
		
		private bool IsValid(decimal number)
		{
			return (number >= maxResultValue || number <= -maxResultValue) ? false : true;
		}
		
		private decimal getDecimal(string str)
		{
			return Decimal.Parse(str, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign);
		}
		
		private decimal GetRounded(decimal number)
		{
			return Decimal.Round(number, maxDigitsLength - GetIntegerPartLength(number), System.MidpointRounding.AwayFromZero);
		}
		
		private int GetIntegerPartLength(decimal number)
		{
			int length = 1;
			while (number >= 10) {
				number /= 10;
				++length;
			}
			return length;
		}
		
		private int GetDigitsLength(string str)
		{
			int digitsLength = 0;
			for (int i = 0; i < str.Length; ++i) {
				if (Char.IsDigit(str[i])) {
					++digitsLength;
				}
			}
			return digitsLength;
		}
		
    }

}
