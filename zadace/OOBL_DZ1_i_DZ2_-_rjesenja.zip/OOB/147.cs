﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string _stockName;
        public string StockName
        {
            get { return _stockName; }
            set { _stockName = ValidateStockName(value); }
        }

        private long _numberOfShares;
        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = ValidateNumberOfShares(value); }
        }

        Dictionary<DateTime, Decimal> _prices;
        public Dictionary<DateTime, Decimal> Prices
        {
            get { return _prices; }
            set { _prices = value; }
        }
        public void AddPrice(Decimal price, DateTime time)
        {
            _prices[time] = ValidatePrice(price);
        }

        public Stock(string inStockName)
        {
            _stockName = ValidateStockName(inStockName);
        }

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockName = ValidateStockName(inStockName);
            _numberOfShares = ValidateNumberOfShares(inNumberOfShares);
            _prices = new Dictionary<DateTime, decimal>();
            _prices[inTimeStamp] = ValidatePrice(inInitialPrice);
        }

        public Decimal getInitialPrice()
        {
            DateTime min = DateTime.MaxValue;
            foreach (DateTime current in _prices.Keys)
            {
                if (current < min)
                {
                    min = current;
                }
            }
            return _prices[min]; 
        }

        public Decimal getLastPrice()
        {
            DateTime max = DateTime.MinValue;
            foreach (DateTime current in _prices.Keys)
            {
                if (current > max)
                {
                    max = current;
                }
            }
            return _prices[max]; 
        }

        public Decimal getPrice(DateTime inTimeStamp)
        {
            DateTime min = DateTime.MaxValue;
            foreach (DateTime current in _prices.Keys)
            {
                if (current < min)
                {
                    min = current;
                }
            }

            if (inTimeStamp < min) throw new StockExchangeException("Za odabrani trenutak dionica nije postojala");

            if (_prices.Keys.Contains(inTimeStamp))
            {
                return _prices[inTimeStamp];
            }

            TimeSpan najmanjaUdaljenost = TimeSpan.MaxValue;
            DateTime najblizi = new DateTime();
            foreach (DateTime current in _prices.Keys)
            {
                if ((current < inTimeStamp) && ((inTimeStamp - current) < najmanjaUdaljenost))
                {
                    najblizi = current;
                }
            }
            return _prices[najblizi];
        }

        private string ValidateStockName(string name)
        {
            if (name == null || name == "")
                throw new StockExchangeException("Ime dionice nije ispravno!");
            else return name.ToLower();
        }

        private long ValidateNumberOfShares(long num)
        {
            if (num <= 0)
                throw new StockExchangeException("Neispravan broj dionica!");
            else return num;
        }

        private Decimal ValidatePrice(Decimal price)
        {
            if (price <= 0)
                throw new StockExchangeException("Neispravna cijena dionice!");
            else return price;
        }

        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Stock p = obj as Stock;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (_stockName == p.StockName) return true;
            else return false;
        }
    }

    public abstract class Index
    {
        protected string _name;
        public string Name
        {
            get { return _name; }
            set { _name = ValidateIndexName(value); }
        }

        protected List<Stock> _stocks;
        public List<Stock> Stocks
        {
            get { return _stocks; }
            set { _stocks = value; }
        }

        public abstract Decimal getIndexValue(DateTime time);

        protected string ValidateIndexName(string name)
        {
            if (name == null || name == "")
                throw new StockExchangeException("Ime indeksa nije ispravno!");
            else return name.ToLower();
        }

        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Index p = obj as Index;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (_name == p.Name) return true;
            else return false;
        }
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string name)
        {
            _name = ValidateIndexName(name);
            _stocks = new List<Stock>();
        }

        public override Decimal getIndexValue(DateTime time)
        {
            Decimal sum = 0;
            foreach (Stock stock in _stocks)
            {
                sum += stock.getPrice(time);
            }
            return Math.Round(sum / _stocks.Count, 3);
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string name)
        {
            _name = ValidateIndexName(name);
            _stocks = new List<Stock>();
        }

        public override Decimal getIndexValue(DateTime time)
        {
            Decimal faktor;
            Decimal sumNazivnik = 0;
            Decimal avg = 0;
            foreach (Stock stock in _stocks)
            {
                sumNazivnik += stock.getPrice(time) * stock.NumberOfShares;
            }
            foreach (Stock stock in _stocks)
            {
                faktor = stock.getPrice(time) * stock.NumberOfShares;
                avg += faktor * stock.getPrice(time);
            }

            return Math.Round(avg / sumNazivnik, 3);
        }
    }

    public class Portfolio
    {
        private string _id;
        public string Id
        {
            get { return _id; }
            set { _id = ValidateId(value); }
        }
        private Dictionary<Stock, int> _stocks = new Dictionary<Stock, int>();
        public Dictionary<Stock, int> Stocks
        {
            get { return _stocks; }
            set { _stocks = value; }
        }

        public Portfolio(string id)
        {
            _id = ValidateId(id);
        }

        private string ValidateId(string id)
        {
            if (id == null || id == "")
                throw new StockExchangeException("ID portfelja nije ispravan!");
            else return id;
        }

        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Portfolio p = obj as Portfolio;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (_id == p.Id) return true;
            else return false;
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks = new List<Stock>();
        private List<Index> _indices = new List<Index>();
        private List<Portfolio> _portfolios = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom vec postoji!");
            }
            else
            {
                _stocks.Add(newStock);
            }
        }

        public void DelistStock(string inStockName)
        {
            Stock newStock = new Stock(inStockName);
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            else
            {
                foreach (Index i in _indices)
                {
                    if (i.Stocks.Contains(newStock))
                    {
                        i.Stocks.Remove(newStock);
                    }
                }
                foreach (Portfolio i in _portfolios)
                {
                    if (i.Stocks.Keys.Contains(newStock))
                    {
                        i.Stocks.Remove(newStock);
                    }
                }
                _stocks.Remove(newStock);
            }
        }

        public bool StockExists(string inStockName)
        {
            Stock stock = new Stock(inStockName);
            if (_stocks.Contains(stock))
            {
               return true;
            }
            else
            {
                return false;
            }

        }

        public int NumberOfStocks()
        {
            return _stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock newStock = new Stock(inStockName);
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            else
            {
                int index = _stocks.IndexOf(newStock);
                _stocks[index].AddPrice(inStockValue, inIimeStamp);
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = new Stock(inStockName);
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            else
            {
                int index = _stocks.IndexOf(stock);
                return _stocks[index].getPrice(inTimeStamp);          
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = new Stock(inStockName);
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            else
            {
                int index = _stocks.IndexOf(stock);
                return _stocks[index].getInitialPrice();
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = new Stock(inStockName);
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            else
            {
                int index = _stocks.IndexOf(stock);
                return _stocks[index].getLastPrice();
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index;
            if(inIndexType == IndexTypes.AVERAGE)
                index = new AverageIndex(inIndexName);
            else if(inIndexType == IndexTypes.WEIGHTED)
                index = new WeightedIndex(inIndexName);
            else throw new StockExchangeException("Nedefinirani tip indeksa!");

            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Indeks s tim imenom vec postoji!");
            }
            else
            {
                _indices.Add(index);
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = new AverageIndex(inIndexName); // nebitan tip za usporedbu by name
            Stock stock = new Stock(inStockName);
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci indeks!");
            }
            else
            {
                if (!StockExists(inStockName))
                {
                    throw new StockExchangeException("Nepostojeca dionica!");
                }
                int indexIdx = _indices.IndexOf(index);
                if (IsStockPartOfIndex(inIndexName, inStockName))
                {
                    throw new StockExchangeException("Dionica vec postoji u tom indeksu!");
                }
                foreach(Index idx in _indices)
                {
                    if (idx.Stocks.Contains(stock))
                    {
                        throw new StockExchangeException("Dionica vec postoji u nekom drugom indeksu!");
                    }
                }
                int stockIdx = _stocks.IndexOf(stock);
                _indices[indexIdx].Stocks.Add(_stocks[stockIdx]);
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = new AverageIndex(inIndexName); // nebitan tip za usporedbu by name
            Stock stock = new Stock(inStockName);
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci indeks!");
            }
            else
            {
                if (!StockExists(inStockName))
                {
                    throw new StockExchangeException("Nepostojeca dionica!");
                }
                int indexIdx = _indices.IndexOf(index);
                if (!IsStockPartOfIndex(inIndexName, inStockName))
                {
                    throw new StockExchangeException("Dionica ne postoji u tom indeksu!");
                }
                else
                {
                    _indices[indexIdx].Stocks.Remove(stock);
                }
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = new AverageIndex(inIndexName); // nebitan tip za usporedbu by name
            Stock stock = new Stock(inStockName);
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci indeks!");
            }
            else
            {
                if (!StockExists(inStockName))
                {
                    throw new StockExchangeException("Nepostojeca dionica!");
                }
                int indexIdx = _indices.IndexOf(index);
                if (_indices[indexIdx].Stocks.Contains(stock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = new AverageIndex(inIndexName);
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci indeks!");
            }
            else
            {
                int indexIdx = _indices.IndexOf(index);
                index = _indices[indexIdx];
                return index.getIndexValue(inTimeStamp);
            }

        }

        public bool IndexExists(string inIndexName)
        {
            Index index = new AverageIndex(inIndexName);
            if (_indices.Contains(index))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = new AverageIndex(inIndexName);
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Nepostojeci indeks!");
            }
            int idx = _indices.IndexOf(index);
            index = _indices[idx];
            return index.Stocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if(PortfolioExists(inPortfolioID)) 
            {
                throw new StockExchangeException("Portfelj s tim ID-jem vec postoji!");
            }
            _portfolios.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            int stockIndex = _stocks.IndexOf(new Stock(inStockName));
            Stock stock = _stocks[stockIndex];
            int usedNumberOfShares = 0;
            foreach (Portfolio p in _portfolios)
            {
                if (p.Stocks.Keys.Contains(stock))
                {
                    usedNumberOfShares += p.Stocks[stock];
                }
            }
            if ((stock.NumberOfShares - usedNumberOfShares) < numberOfShares)
            {
                throw new StockExchangeException("Nema dovoljno raspolozivih dionica!");
            }
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            if (portfolio.Stocks.Keys.Contains(stock))
            {
                portfolio.Stocks[stock] += numberOfShares;
            }
            else
            {
                portfolio.Stocks.Add(stock, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            int stockIndex = _stocks.IndexOf(new Stock(inStockName));
            Stock stock = _stocks[stockIndex];
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            if (portfolio.Stocks.Keys.Contains(stock))
            {
                if (portfolio.Stocks[stock] < numberOfShares)
                {
                    throw new StockExchangeException("Portfelj ne sadrzi dovoljno dionica!");
                }
                else if (portfolio.Stocks[stock] == numberOfShares)
                {
                    portfolio.Stocks.Remove(stock);
                }
                else
                {
                    portfolio.Stocks[stock] -= numberOfShares;
                }                
            }
            else
            {
                throw new StockExchangeException("Portfelj ne sadrzi tu dionicu!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            int stockIndex = _stocks.IndexOf(new Stock(inStockName));
            Stock stock = _stocks[stockIndex];
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            if (portfolio.Stocks.Keys.Contains(stock))
            {
                portfolio.Stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Portfelj ne sadrzi tu dionicu!");
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio p = _portfolios[portfolioIndex];
            return p.Stocks.Keys.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfolio portfolio = new Portfolio(inPortfolioID);
            if (_portfolios.Contains(portfolio))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            int stockIndex = _stocks.IndexOf(new Stock(inStockName));
            Stock stock = _stocks[stockIndex];
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            if (portfolio.Stocks.Keys.Contains(stock))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
            int stockIndex = _stocks.IndexOf(new Stock(inStockName));
            Stock stock = _stocks[stockIndex];
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            if (!portfolio.Stocks.Keys.Contains(stock))
            {
                return 0;
            }
            else
            {
                return portfolio.Stocks[stock];
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim ID-jem ne postoji!");
            }
            int portfolioIndex = _portfolios.IndexOf(new Portfolio(inPortfolioID));
            Portfolio portfolio = _portfolios[portfolioIndex];
            decimal sum = 0;
            foreach (Stock s in portfolio.Stocks.Keys)
            {
                sum += s.getPrice(timeStamp) * portfolio.Stocks[s];
            }
            return Math.Round(sum, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            int numDaysInMonth =  DateTime.DaysInMonth(Year, Month);
            decimal begin = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0));
            decimal end = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, numDaysInMonth, 23, 59, 59));
            return Math.Round(((end - begin) / begin) * 100, 3);
        }
    }
}
