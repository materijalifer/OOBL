﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
         private Dictionary<string, Index> indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.ListStock: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             try
             {
                 stocks.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
             }
             catch (ArgumentException)
             {
                 throw new StockExchangeException("StockExchange.ListStock: a stock with this name has already been listed.");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.DelistStock: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             if (stocks.Remove(inStockName) == false)
             {
                 throw new StockExchangeException("StockExchange.DelistStock: this stock has not been listed.");
             }

             foreach (Index index in indices.Values)
             {
                 try
                 {
                     index.RemoveStock(inStockName);
                 }
                 catch (StockExchangeException)
                 {
                 }
             }

             foreach (Portfolio portfolio in portfolios.Values)
             {
                 try
                 {
                     portfolio.RemoveStock(inStockName);
                 }
                 catch (StockExchangeException)
                 {
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.StockExists: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             return stocks.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, Decimal inStockValue)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.SetStockPrice: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.SetStockPrice: this stock has not been listed.");
             }
             stock.SetPrice(inTimeStamp, inStockValue);
         }

         public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.GetStockPrice: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.GetStockPrice: this stock has not been listed.");
             }

             return Decimal.Round(stock.GetPrice(inTimeStamp), 3, MidpointRounding.AwayFromZero);
         }

         public Decimal GetInitialStockPrice(string inStockName)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.GetInitialStockPrice: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.GetInitialStockPrice: this stock has not been listed.");
             }
             return Decimal.Round(stock.GetInitialPrice(), 3, MidpointRounding.AwayFromZero);
         }

         public Decimal GetLastStockPrice(string inStockName)
         {
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.GetLastStockPrice: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.GetLastStockPrice: this stock has not been listed.");
             }
             return Decimal.Round(stock.GetLastPrice(), 3, MidpointRounding.AwayFromZero);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.CreateIndex: inIndexName is null.");
             }
             inIndexName = inIndexName.ToUpper();

             try
             {
                 indices.Add(inIndexName, Index.GetInstance(inIndexName, inIndexType));
             }
             catch (ArgumentException)
             {
                 throw new StockExchangeException("StockExchange.CreateIndex: an index with this name has already been listed.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.AddStockToIndex: inIndexName is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.AddStockToIndex: inStockName is null.");
             }
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.AddStockToIndex: this stock has not been listed.");
             }

             Index index;
             if (indices.TryGetValue(inIndexName, out index) == false)
             {
                 throw new StockExchangeException("StockExchange.AddStockToIndex: this index has not been listed.");
             }

             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromIndex: inIndexName is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromIndex: inStockName is null.");
             }
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Index index;
             if (indices.TryGetValue(inIndexName, out index) == false)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromIndex: this index has not been listed.");
             }

             index.RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfIndex: inIndexName is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfIndex: inStockName is null.");
             }
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Index index;
             if (indices.TryGetValue(inIndexName, out index) == false)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfIndex: this index has not been listed.");
             }

             return index.Contains(inStockName);
         }

         public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.GetIndexValue: inIndexName is null.");
             }
             inIndexName = inIndexName.ToUpper();

             Index index;
             if (indices.TryGetValue(inIndexName, out index) == false)
             {
                 throw new StockExchangeException("StockExchange.GetIndexValue: this index has not been listed.");
             }

             return Decimal.Round(index.GetValue(inTimeStamp), 3, MidpointRounding.AwayFromZero);
         }

         public bool IndexExists(string inIndexName)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.IndexExists: inIndexName is null.");
             }
             inIndexName = inIndexName.ToUpper();

             return indices.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (inIndexName == null)
             {
                 throw new StockExchangeException("StockExchange.NumberOfStocksInIndex: inIndexName is null.");
             }
             inIndexName = inIndexName.ToUpper();

             Index index;
             if (indices.TryGetValue(inIndexName, out index) == false)
             {
                 throw new StockExchangeException("StockExchange.NumberOfStocksInIndex: this index has not been listed.");
             }

             return index.GetNumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.CreatePortfolio: inPortfolioID is null.");
             }

             try
             {
                 portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
             catch (ArgumentException)
             {
                 throw new StockExchangeException("StockExchange.CreatePortfolio: a portfolio with this name has already been listed.");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.AddStockToPortfolio: inPortfolioID is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.AddStockToPortfolio: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.AddStockToPortfolio: this portfolio has not been listed.");
             }

             Stock stock;
             if (stocks.TryGetValue(inStockName, out stock) == false)
             {
                 throw new StockExchangeException("StockExchange.AddStockToPortfolio: this stock has not been listed.");
             }

             portfolio.AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: inPortfolioID is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: this portfolio has not been listed.");
             }

             portfolio.RemoveStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: inPortfolioID is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio: this portfolio has not been listed.");
             }

             portfolio.RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.NumberOfStocksInPortfolio: inPortfolioID is null.");
             }

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.NumberOfStocksInPortfolio: this portfolio has not been listed.");
             }

             return portfolio.GetNumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.PortfolioExists: inPortfolioID is null.");
             }

             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfPortfolio: inPortfolioID is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfPortfolio: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.IsStockPartOfPortfolio: this portfolio has not been listed.");
             }

             return portfolio.Contains(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.NumberOfSharesOfStockInPortfolio: inPortfolioID is null.");
             }
             if (inStockName == null)
             {
                 throw new StockExchangeException("StockExchange.NumberOfSharesOfStockInPortfolio: inStockName is null.");
             }
             inStockName = inStockName.ToUpper();

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.NumberOfSharesOfStockInPortfolio: this portfolio has not been listed.");
             }

             return portfolio.GetShares(inStockName);
         }

         public Decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.GetPortfolioValue: inPortfolioID is null.");
             }

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.GetPortfolioValue: this portfolio has not been listed.");
             }

             return Decimal.Round(portfolio.GetValue(timeStamp), 3, MidpointRounding.AwayFromZero);
         }

         public Decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (inPortfolioID == null)
             {
                 throw new StockExchangeException("StockExchange.GetPortfolioPercentChangeInValueForMonth: inPortfolioID is null.");
             }

             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio) == false)
             {
                 throw new StockExchangeException("StockExchange.GetPortfolioPercentChangeInValueForMonth: this portfolio has not been listed.");
             }

             return Decimal.Round(portfolio.GetPercentChangeInValueForMonth(Year, Month), 3, MidpointRounding.AwayFromZero);
         }
     }

     public class Stock
     {
         private string name;
         private long shares;
         private Decimal initialPrice;
         private SortedDictionary<DateTime, Decimal> prices = new SortedDictionary<DateTime,decimal>();
         private long sharesInPortfolio = 0;

         public Stock(string name, long shares, Decimal initialPrice, DateTime priceDate)
         {
             if (name == null)
             {
                 throw new StockExchangeException("Stock: name is null.");
             }
             if (shares <= 0)
             {
                 throw new StockExchangeException("Stock: shares <= 0.");
             }
             if (initialPrice <= 0)
             {
                 throw new StockExchangeException("Stock: initial price <= 0.");
             }
             if (priceDate == null)
             {
                 throw new StockExchangeException("Stock: price date timestamp is null.");
             }

             this.name = name;
             this.shares = shares;
             this.initialPrice = initialPrice;
             SetPrice(priceDate, initialPrice);
         }

         public string GetName()
         {
             return name;
         }

         public long GetShares()
         {
             return shares;
         }

         public Decimal GetInitialPrice()
         {
             return initialPrice;
         }

         public Decimal GetLastPrice()
         {
             return prices.Last().Value;
         }

         public Decimal GetPrice(DateTime priceDate)
         {
             if (priceDate < prices.First().Key)
             {
                 throw new StockExchangeException("Stock.GetPrice: price date is before earliest known price.");
             }

             Decimal price = prices.First().Value;
             foreach (KeyValuePair<DateTime, Decimal> datePricePair in prices)
             {
                 if (datePricePair.Key > priceDate)
                 {
                     return price;
                 }
                 price = datePricePair.Value;
             }
             return price;
         }

         public void SetPrice(DateTime priceDate, Decimal price)
         {
             if (priceDate == null)
             {
                 throw new StockExchangeException("Stock.SetPrice: price date is null.");
             }
             if (price <= 0)
             {
                 throw new StockExchangeException("Stock.SetPrice: price <= 0.");
             }

             try
             {
                 prices.Add(priceDate, price);
             }
             catch (ArgumentException)
             {
                 throw new StockExchangeException("Stock.SetPrice: price already exists for price date.");
             }
         }

         public long GetSharesInPortfolio()
         {
             return sharesInPortfolio;
         }

         public void AddSharesToPortfolio(long increase)
         {
             if (increase <= 0)
             {
                 throw new StockExchangeException("Stock.AddToPortfolio: increase <= 0.");
             }
             if (sharesInPortfolio + increase > shares || sharesInPortfolio + increase <= sharesInPortfolio)
             {
                 throw new StockExchangeException("Stock.AddToPortfolio: shares in portfolio would exceed the total shares.");
             }

             sharesInPortfolio += increase;
         }

         public void RemoveSharesFromPortfolio(long decrease)
         {
             if (decrease <= 0)
             {
                 throw new StockExchangeException("Stock.RemoveFromPortfolio: decrease <= 0.");
             }
             if (sharesInPortfolio - decrease < 0)
             {
                 throw new StockExchangeException("Stock.RemoveFromPortfolio: shares in portfolio would be below zero.");
             }

             sharesInPortfolio -= decrease;
         }
     }

     public abstract class Index
     {
         private string name;
         private IndexTypes type;
         protected Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();

         public Index(string name, IndexTypes type)
         {
             if (name == null)
             {
                 throw new StockExchangeException("Index: name is null.");
             }

             this.name = name;
             this.type = type;
         }

         public static Index GetInstance(string name, IndexTypes type)
         {
             if (name == null)
             {
                 throw new StockExchangeException("Index.GetInstance: name is null.");
             }

             if (type.Equals(IndexTypes.AVERAGE)) {
                return new IndexAverage(name);
             } else if (type.Equals(IndexTypes.WEIGHTED)) {
                return new IndexWeighted(name);
             } else {
                throw new StockExchangeException("Index.GetInstance: unknown index type");
             }
         }

         public string GetName()
         {
             return name;
         }

         public IndexTypes GeIndexType()
         {
             return type;
         }

         public void AddStock(Stock stock)
         {
             if (stock == null)
             {
                 throw new StockExchangeException("Index.AddStock: stock is null.");
             }

             try
             {
                 stocks.Add(stock.GetName(), stock);
             }
             catch (ArgumentException)
             {
                 throw new StockExchangeException("Index.AddStock: index already has the stock.");
             }
         }

         public void RemoveStock(string stockName)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Index.RemoveStock: stock is null.");
             }

             if (stocks.Remove(stockName) == false)
             {
                 throw new StockExchangeException("Index.RemoveStock: index doesn't have the stock.");
             }
         }

         public bool Contains(string stockName)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Index.Contains: stockName is null.");
             }

             return stocks.ContainsKey(stockName);
         }

         public int GetNumberOfStocks()
         {
             return stocks.Count;
         }

         public abstract Decimal GetValue(DateTime date);
     }

     public class IndexAverage : Index
     {
         public IndexAverage(string name) : base(name, IndexTypes.AVERAGE)
         {
         }

         public override Decimal GetValue(DateTime date)
         {
             if (date == null)
             {
                 throw new StockExchangeException("IndexAverage.GetValue: date is null.");
             }

             Decimal sum = 0;
             foreach (Stock stock in stocks.Values)
             {
                 sum += stock.GetPrice(date);
             }
             if (sum == 0)
             {
                 return 0;
             }
             return sum / stocks.Count;
         }
     }

     public class IndexWeighted : Index
     {
         public IndexWeighted(string name) : base(name, IndexTypes.AVERAGE)
         {
         }

         public override Decimal GetValue(DateTime date)
         {
             if (date == null)
             {
                 throw new StockExchangeException("IndexWeighted.GetValue: date is null.");
             }

             Decimal sum = 0;
             Decimal weightSum = 0;
             foreach (Stock stock in stocks.Values)
             {
                 Decimal price = stock.GetPrice(date);
                 Decimal weight = price * stock.GetShares();
                 sum += (weight * price);
                 weightSum += weight;
             }
             if (weightSum == 0)
             {
                 return 0;
             }
             return sum / weightSum;
         }
     }

     public class Portfolio
     {
         private class StockShares
         {
             public Stock stock;
             public int shares;
         }

         private string id;
         private Dictionary<string, StockShares> stocks = new Dictionary<string, StockShares>();

         public Portfolio(string id)
         {
             if (id == null)
             {
                 throw new StockExchangeException("Portfolio: id is null.");
             }

             this.id = id;
         }

         public void AddStock(Stock stock, int shares)
         {
             if (stock == null)
             {
                 throw new StockExchangeException("Portfolio.AddStock: stock is null.");
             }
             if (shares <= 0)
             {
                 throw new StockExchangeException("Portfolio.AddStock: shares <= 0.");
             }

             stock.AddSharesToPortfolio(shares);

             StockShares stockShares;
             if (stocks.TryGetValue(stock.GetName(), out stockShares) == false)
             {
                 stockShares = new StockShares();
                 stockShares.stock = stock;
                 stockShares.shares = shares;
                 stocks.Add(stock.GetName(), stockShares);
             }
             else
             {
                 stockShares.shares += shares;
             }
         }

         public void RemoveStock(string stockName, int shares)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: stockName is null.");
             }
             if (shares <= 0)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: shares <= 0.");
             }

             StockShares stockShares;
             if (stocks.TryGetValue(stockName, out stockShares) == false)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: portfolio doesn't have this stock.");
             }

             if (stockShares.shares < shares)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: more shares would be removed than there are in the portfolio.");
             }

             stockShares.stock.RemoveSharesFromPortfolio(shares);

             stockShares.shares -= shares;
             if (stockShares.shares == 0)
             {
                 stocks.Remove(stockName);
             }
         }

         public void RemoveStock(string stockName)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: stockName is null.");
             }

             StockShares stockShares;
             if (stocks.TryGetValue(stockName, out stockShares) == false)
             {
                 throw new StockExchangeException("Portfolio.RemoveStock: portfolio doesn't have this stock.");
             }

             stockShares.stock.RemoveSharesFromPortfolio(stockShares.shares);

             stocks.Remove(stockName);
         }

         public int GetNumberOfStocks()
         {
             return stocks.Count;
         }

         public bool Contains(string stockName)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Portfolio.Contains: stockName is null.");
             }

             return stocks.ContainsKey(stockName);
         }

         public int GetShares(string stockName)
         {
             if (stockName == null)
             {
                 throw new StockExchangeException("Portfolio.GetShares: stockName is null.");
             }

             StockShares stockShares;
             if (stocks.TryGetValue(stockName, out stockShares) == false)
             {
                 throw new StockExchangeException("Portfolio.GetShares: portfolio doesn't have this stock.");
             }

             return stockShares.shares;
         }

         public Decimal GetValue(DateTime date)
         {
             if (date == null)
             {
                 throw new StockExchangeException("Portfolio.GetValue: date is null.");
             }

             Decimal value = 0;
             foreach (StockShares stockShares in stocks.Values)
             {
                 value += (stockShares.shares * stockShares.stock.GetPrice(date));
             }
             return value;
         }

         public Decimal GetPercentChangeInValueForMonth(int year, int month)
         {
             DateTime begin;
             DateTime end;
             try
             {
                 begin = new DateTime(year, month, 1, 0, 0, 0, 0);
                 end = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Portfolio.GetPercentChangeInValueForMonth: invalid year or month.");
             }

             return (GetValue(end) / GetValue(begin) - 1) * 100;
         }
     }
}
