﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Globalization;
using System.Threading;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator

            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("hr-HR");
            return new Kalkulator();
        }
    }

    public interface ILib
    {
        string Add(double x, double y);
        string Substract(double x, double y);
        string Product(double x, double y);
        string Devide(double x, double y);
        string Quadrat(double x, double y, bool choose);
        string Root(double x, double y, bool choose);
        string Invert(double x, double y, bool choose);
        string Sinus(double x, double y, bool choose);
        string Cosinus(double x, double y, bool choose);
        string Tangens(double x, double y, bool choose);
        string Minus(double x, double y, bool choose);

    }

    public abstract class Lib : ILib
    {
        public abstract string Add(double x, double y);
        public abstract string Substract(double x, double y);
        public abstract string Product(double x, double y);
        public abstract string Devide(double x, double y);
        public abstract string Quadrat(double x, double y, bool choose);
        public abstract string Root(double x, double y, bool choose);
        public abstract string Invert(double x, double y, bool choose);
        public abstract string Sinus(double x, double y, bool choose);
        public abstract string Cosinus(double x, double y, bool choose);
        public abstract string Tangens(double x, double y, bool choose);
        public abstract string Minus(double x, double y, bool choose);
    }

    public sealed class Calculation : Lib
    {
        public override string Add(double x, double y)
        {
            return Convert.ToString((x + y));
        }

        public override string Substract(double x, double y)
        {
            return Convert.ToString((x - y));
        }

        public override string Product(double x, double y)
        {
            return Convert.ToString((x * y));
        }

        public override string Devide(double x, double y)
        {
            return Convert.ToString((x / y));
        }

        public override string Quadrat(double x, double y, bool choose)
        {
            string numQuadrat = null;
            double quadrat = 0;

            if (choose)
            {
                quadrat = Math.Pow(x, 2);
            }
            else if (!choose)
            {
                quadrat = Math.Pow(y, 2);
            }
            if (!double.IsInfinity(quadrat) && quadrat != double.NaN)
            {
                numQuadrat = quadrat.ToString(CultureInfo.GetCultureInfo("hr-HR"));
            }
            else
                numQuadrat = "-E-";
            return numQuadrat;
        }

        public override string Root(double x, double y, bool choose)
        {
            string numRoot = null;
            double root = 0;
            if (choose)
            {
                root = Math.Round(Math.Sqrt(x), 9);
            }
            else if (!choose)
            {
                root = Math.Round(Math.Sqrt(y), 9);
            }
            if (!double.IsInfinity(root) && root != double.NaN)
            {               
                numRoot = root.ToString(CultureInfo.GetCultureInfo("hr-HR"));
            }
            else
                numRoot = "-E-";
            return numRoot;
        }

        public override string Invert(double x, double y, bool choose)
        {
            string numInvert = null;
            double invert = 0;
            if (choose)
            {
                invert = Math.Round(1 / x, 9);
            }
            else if (!choose)
            {
                invert = Math.Round(1 / y, 9);
            }
            if (!double.IsInfinity(invert) && invert != double.NaN)
            {
                numInvert = invert.ToString(CultureInfo.GetCultureInfo("hr-HR"));
            }
            else
                numInvert = "-E-";
            return numInvert;
        }

        public override string Sinus(double x, double y, bool choose)
        {
            string numSinus = null;
            double sinus = 0;
            if (choose)
            {
                sinus = Math.Round(Math.Sin(x), 9);
            }
            else if (!choose)
            {
                sinus = Math.Round(Math.Sin(y), 9);
            }
           
            numSinus = sinus.ToString(CultureInfo.GetCultureInfo("hr-HR"));

            return numSinus;
        }

        public override string Cosinus(double x, double y, bool choose)
        {
            string numCosinus = null;
            double cosinus = 0;
            if (choose)
            {
                cosinus = Math.Round(Math.Cos(x), 9);
            }
            else if (!choose)
            {
                cosinus = Math.Round(Math.Cos(y), 9);
            }

            numCosinus = cosinus.ToString(CultureInfo.GetCultureInfo("hr-HR"));

            return numCosinus;
        }

        public override string Tangens(double x, double y, bool choose)
        {
            string numTangens = null;
            double tangens = 0;
            if (choose)
            {
                tangens = Math.Round(Math.Tan(x), 9); ;
            }
            else if (!choose)
            {
                tangens = Math.Round(Math.Tan(y), 9);
            }

            numTangens = tangens.ToString(CultureInfo.GetCultureInfo("hr-HR"));
            
            return numTangens;
        }

        public override string Minus(double x, double y, bool choose)
        {
            string newString = "-";
            if (choose)
            {
                string value = Convert.ToString(x);
                if (value[0] == '-')
                {
                    newString = newString.Insert(0, Convert.ToString(x));
                }
                else
                {
                    newString = newString.Insert(1, Convert.ToString(x));
                    newString.Insert(0, "-");
                    if (newString.Length > 10 && !newString.Contains(","))
                        newString.Remove(newString.Length - 1);
                }
            }
            else if (!choose)
            {
                string value = Convert.ToString(y);
                if (value[0] == '-')
                {
                    newString = newString.Insert(0, Convert.ToString(y));
                }
                else
                {
                    newString = newString.Insert(1, Convert.ToString(y));
                    newString.Insert(0, "-");
                    if (newString.Length > 10 && !newString.Contains(","))
                        newString.Remove(newString.Length - 1);
                }
            }
            return newString;
        }
    }

    public class Kalkulator : ICalculator
    {
        private char currentOperation = new char();
        private static string currentState = null;

        private string currentValue1 = null;
        private string currentValue2 = null;
        private string currentValueU1 = null;
        private string currentValueU2 = null;
        private bool unar = false;
        private string result = null;

        bool getMemory = false;
        private string memory = null;
        private string newValues = null;
        bool dot, pred = false;
        bool first = true;
        bool second = false;
        public static Calculation cal = new Calculation();

        private static Dictionary<char, Delegate> pressDictionary = new Dictionary<char, Delegate>()
        {
            { '+', new Func<double, double, string>(cal.Add) },
            { '-', new Func<double, double, string>(cal.Substract) },
            { '*', new Func<double, double, string>(cal.Product) },
            { '/', new Func<double, double, string>(cal.Devide) },
            { 'Q', new Func<double, double, bool, string>(cal.Quadrat) },            
            { 'R', new Func<double, double, bool, string>(cal.Root) },
            { 'I', new Func<double, double, bool, string>(cal.Invert) },
            { 'S', new Func<double, double, bool, string>(cal.Sinus) },
            { 'K', new Func<double, double, bool, string>(cal.Cosinus) },
            { 'T', new Func<double, double, bool, string>(cal.Tangens) },
            { 'M', new Func<double, double, bool, string>(cal.Minus) },
            { 'P', new Func<double, double, bool, string>(cal.Sinus) },
            { 'G', new Func<double, double, bool, string>(cal.Sinus) },
        };

        public void Press(char inPressedDigit)
        {
            if ((inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/') && currentOperation != '\0')
            {
                if (currentValue1 != null && currentValue2 != null)
                {
                    var result1 = new object();
                    result1 = pressDictionary[currentOperation].DynamicInvoke(Convert.ToDouble(currentValue1), Convert.ToDouble(currentValue2));
                    result = Convert.ToString(result1);
                    currentValue1 = result;
                    currentValue2 = null;
                    first = true;
                    second = false;
                }
            }
            if (Char.IsNumber(inPressedDigit) || inPressedDigit == ',')
            {
                if ((first && currentValue1 == null) || (second && currentValue2 == null))
                {
                    if (inPressedDigit.ToString() == ",")
                        currentState = "0,";
                    else
                        currentState = inPressedDigit.ToString();
                }
                else if (first || second)
                {
                    if (first)
                        currentState = insertValues(inPressedDigit.ToString(), currentValue1.ToString());
                    else if (second)
                        currentState = insertValues(inPressedDigit.ToString(), currentValue2.ToString());
                }

                if (first)
                    currentValue1 = currentState;
                else if (second)
                    currentValue2 = currentState;
                currentState = null;
            }
            else if (inPressedDigit == '=')
            {
                var result1 = new object();
                if (currentValue2 == null && currentOperation != '\0')
                {
                    result1 = pressDictionary[currentOperation].DynamicInvoke(Convert.ToDouble(currentValue1), Convert.ToDouble(currentValue1));
                    result = Convert.ToString(result1);
                    currentValue1 = GetCurrentDisplayState();
                    currentValue2 = null;
                    second = true;
                    first = false;
                    currentOperation = new char();
                }
                else if (currentOperation != '\0')
                {
                    result1 = pressDictionary[currentOperation].DynamicInvoke(Convert.ToDouble(currentValue1), Convert.ToDouble(currentValue2));
                    result = Convert.ToString(result1);
                    currentValue1 = GetCurrentDisplayState();
                    currentValue2 = null;
                    second = true;
                    first = false;
                    currentOperation = new char();
                }
                if(currentValue1 != null && currentOperation == '\0' && currentValue1 != "0")
                {
                    int s = currentValue1.IndexOf("0");
                    if (currentValue1[currentValue1.IndexOf(",") + 1] == '0' && currentValue1.IndexOf("0") == (currentValue1.Length - 1))
                        currentValue1 = currentValue1.Remove(currentValue1.IndexOf(","));
                }
                else if (currentValue2 != null && currentOperation == '\0' && currentValue1 != "0")
                {
                    if (currentValue2[currentValue2.IndexOf(",") + 1] == '0' && currentValue2.IndexOf("0") == (currentValue2.Length - 1))
                        currentValue2 = currentValue2.Remove(currentValue2.IndexOf(","));
                }
            }
            else if (inPressedDigit == 'C')
            {
                if (first)
                    currentValue1 = "0";
                else if (second)
                    currentValue2 = "0";
            }
            else if (inPressedDigit == 'O')
            {
                currentValue1 = "0";
                currentValue2 = "0";
                result = "0";
                memory = null;
                currentOperation = new char();
            }
            else if (inPressedDigit == 'P')
            {
                if (first)
                    memory = currentValue1;
                else if (second)
                    memory = currentValue2;
            }
            else if (inPressedDigit == 'G')
            {
                getMemory = true;
            }
            else
            {
                var result1 = new object();
                if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T' || inPressedDigit == 'M' ||
                    inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
                {
                    unar = true;
                    if (first)
                    {
                        result1 = pressDictionary[inPressedDigit].DynamicInvoke(Convert.ToDouble(currentValue1), 0, true);
                        result = Convert.ToString(result1);
                        currentValueU1 = result;
                        currentValue1 = result;
                    }
                    else if (second)
                    {
                        if (currentValue2 != null)
                        {
                            result1 = pressDictionary[inPressedDigit].DynamicInvoke(0, Convert.ToDouble(currentValue2), false);
                            result = Convert.ToString(result1);
                            currentValueU2 = result;
                            currentValue2 = result;
                        }
                        else
                        {
                            result1 = pressDictionary[inPressedDigit].DynamicInvoke(Convert.ToDouble(currentValue1), 0, true);
                            result = Convert.ToString(result1);
                            currentValueU1 = result;
                            currentValue1 = result;
                        }

                    }
                }
                else if (currentValue1 != null && currentValue2 != null)
                {
                    result1 = pressDictionary[inPressedDigit].DynamicInvoke(Convert.ToDouble(currentValue1), Convert.ToDouble(currentValue2));
                    result = Convert.ToString(result1);
                    second = false;
                }
                else
                {
                    currentOperation = inPressedDigit;
                    first = false;
                    second = true;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            string printState = null;

            if (getMemory)
            {
                getMemory = false;
                return memory;
            }

            if (unar)
            {
                unar = false;
                if (currentValue1 != null && currentValue2 == null)
                    return formatString(currentValueU1);
                else if (currentValue1 != null && currentValue2 != null)
                    return formatString(currentValueU2);
            }

            if (currentValue1 != null && currentValue2 == null)
                printState = currentValue1;
            else if (currentValue1 != null && currentValue2 != null)
                printState = currentValue2;
            else
                printState = "0";
           
            if (result != null)
            {
                if (result.Length > 10 && !result.Contains(',') && !result.Contains('-'))
                    result = "-E-";
                else if (result.Length == 11 && result.Contains(','))
                    return formatString(result);
                else if (result.Length == 11 && result.Contains('-'))
                    return formatString(result);
                return formatString(result);
            }
            else if (printState != null)
            {
                if (printState.Length > 10 && !printState.Contains(',') && !printState.Contains('-'))
                    printState = "-E-";
                else if (printState.Length == 11 && printState.Contains(','))
                    return formatString(printState);
                else if (printState.Length == 11 && printState.Contains('-'))
                    return formatString(printState);
            }
            return formatString(printState);
        }
        public string formatString(string input)
        {
            string a = input;
            if ((input.Contains(',') && input.IndexOf(',') == input.Length-2) && input.IndexOf('0') == input.Length-1)
            {
                a = a.Remove(a.IndexOf('0'));
                a = a.Remove(a.IndexOf(','));
            }
            return a;
        }

        public string insertValues(string inPressedDigit, string values)
        {
            if (values.Length == 1 && values[0].ToString() == "0" && inPressedDigit.ToString() == "0")
            {
                newValues = values;
            }
            else if (values.Length < 11)
            {
                if (inPressedDigit.ToString() == "." && !values.Contains("."))
                {
                    values += ",";
                }
                else
                {
                    values += inPressedDigit.ToString();
                }
            }
            else if (values.Length == 10 || values.Length == 11)
            {
                if (inPressedDigit.ToString() == "." && !values.Contains(","))
                {
                    values += ",";
                }
            }
            return values;
        }
    }
}