﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {
        // function with two operands
        delegate double TwoOperandFunction(double op1, double op2);
        // function with one operand
        delegate double OneOperandFunction(double op);
        // function without operand
        delegate void WOOperandFunction();

        const string errorString = "-E-";

        double? operand1, operand2;
        TextNumber currentDisplay;
        char operatorSign;
        string memory;

        // kad se pritisne operator+-*/, prosli broj treba ostati prikazan, dok se ne stigni novi broj
        // za to koristimo ovaj flag, kada dodje novi broj, prvo ce obrisat sadrzaj ekrana
        bool waitingForNumber = false;

        private Dictionary<char, TwoOperandFunction> twoOperatorFcs;
        private Dictionary<char, OneOperandFunction> oneOperatorFcs;
        private Dictionary<char, WOOperandFunction> woOperatorFcs;

        // constructor
        public Kalkulator()
        {
            // initialize fncs with two operands
            this.twoOperatorFcs = new Dictionary<char, TwoOperandFunction>();
            this.twoOperatorFcs['+'] = OpPlus;
            this.twoOperatorFcs['-'] = OpMinus;
            this.twoOperatorFcs['*'] = OpPuta;
            this.twoOperatorFcs['/'] = OpDijeli;

            // initialize fncs with one operands
            this.oneOperatorFcs = new Dictionary<char, OneOperandFunction>();
            this.oneOperatorFcs['M'] = OpPredznak;
            this.oneOperatorFcs['S'] = OpSinus;
            this.oneOperatorFcs['K'] = OpKosinus;
            this.oneOperatorFcs['T'] = OpTan;
            this.oneOperatorFcs['Q'] = OpQuad;
            this.oneOperatorFcs['R'] = OpSqrt;
            this.oneOperatorFcs['I'] = OpInverse;

            // initialize fncs without operands
            this.woOperatorFcs = new Dictionary<char, WOOperandFunction>();
            this.woOperatorFcs['O'] = OpReset;
            this.woOperatorFcs['C'] = OpClear;
            this.woOperatorFcs['='] = OpJednako;
            this.woOperatorFcs['P'] = OpPut;
            this.woOperatorFcs['G'] = OpGet;

            this.currentDisplay = new TextNumber();

            this.OpReset();
        }

        public void Press(char inPressedDigit)
        {
            // ako je pritisnut operator za dva operanda
            if (this.twoOperatorFcs.ContainsKey(inPressedDigit))
            {
                // ako nizamo operatore, tj prije je vec pritisnut neki
                if (this.waitingForNumber == false && this.operand1.HasValue && this.operatorSign != '\0')
                    this.OpJednako();

                // spremi trenutni broj u operand1
                this.operand1 = this.currentDisplay;
                // spremi predznak
                this.operatorSign = inPressedDigit;
                // uredi broj za prikaz
                this.currentDisplay.TrimRightZeroes();

                // reset display before next number
                this.waitingForNumber = true;
            }
            // ako je pritisnut operator za jedan operand
            else if (this.oneOperatorFcs.ContainsKey(inPressedDigit))
            {
                // dohvati trenutni broj
                double currNum = this.currentDisplay;
                // izvedi nad njim operaciju i prikazi ga
                try
                {
                    double operationResult = this.oneOperatorFcs[inPressedDigit](currNum);
                    if (double.IsInfinity(operationResult) || double.IsNaN(operationResult))
                        throw new Exception("Result is not a number");

                    this.currentDisplay.TextValue = operationResult.ToString();
                }
                catch
                {
                    this.currentDisplay.TextValue = errorString;
                }
            }
            // fkcije bez operanda
            else if (this.woOperatorFcs.ContainsKey(inPressedDigit))
            {
                // zovi metodu za ovaj znak
                this.woOperatorFcs[inPressedDigit]();
            }
            // ako smo unijeli znamenku
            else if (char.IsDigit(inPressedDigit))
            {
                if (this.waitingForNumber)
                {
                    this.waitingForNumber = false;
                    this.OpClear();
                }

                // ako je 0 i prikazujemo 0, preskoci
                if (inPressedDigit == '0' && this.currentDisplay == "0")
                    return;

                // ako je bio error ili 0 na ekranu, obrisi ih
                if (this.currentDisplay == errorString ||
                    this.currentDisplay == "0")
                {
                    this.currentDisplay.TextValue = string.Empty;
                }

                this.currentDisplay.AddChar(inPressedDigit);
            }
            // ako smo unijeli decimalnu tocku
            else if (inPressedDigit == ',')
            {
                // ako je na ekrenu error, ostavi ga (dok se ne stisne broj)
                if (this.currentDisplay == errorString)
                    return;

                // ako vec sadrzimo zarez, nemoj nista napraviti
                string text = this.currentDisplay;
                if (text.Contains(','))
                    return;

                // dodaj decimalni zarez
                this.currentDisplay.AddChar(inPressedDigit);
            }
            else // inace si unio neki krivi znak
            {
                //this.currentDisplay.TextValue = errorString;
                System.Diagnostics.Debug.WriteLine("Unknown character " + inPressedDigit);
            }
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplay;
        }

        // funkcije za trazene operacije
        private double OpPlus(double op1, double op2)
        {
            return op1 + op2;
        }
        private double OpMinus(double op1, double op2)
        {
            return op1 - op2;
        }
        private double OpPuta(double op1, double op2)
        {
            return op1 * op2;
        }
        private double OpDijeli(double op1, double op2)
        {
            return op1 / op2;
        }

        private double OpPredznak(double op)
        {
            return -op;
        }
        private double OpSinus(double op)
        {
            return Math.Sin(op);
        }
        private double OpKosinus(double op)
        {
            return Math.Cos(op);
        }
        private double OpTan(double op)
        {
            return Math.Tan(op);
        }
        private double OpQuad(double op)
        {
            return op * op;
        }
        private double OpSqrt(double op)
        {
            return Math.Sqrt(op);
        }
        private double OpInverse(double op)
        {
            return 1 / op;
        }

        private void OpJednako()
        {
            // parsiraj drugi operand
            operand2 = this.currentDisplay;

            // ako su postavljeni svi operandi i 
            if (operand1.HasValue && operand2.HasValue && operatorSign != '\0')
            {
                // izracunaj vrijednost i prikazi
                try
                {
                    double operationResult = this.twoOperatorFcs[operatorSign](operand1.Value, operand2.Value);
                    if (double.IsInfinity(operationResult) || double.IsNaN(operationResult))
                        throw new Exception("Result is not a number");

                    this.currentDisplay.TextValue = operationResult.ToString();
                }
                catch // ako se vrijednost ne moze prikazati, prikazi error
                {
                    this.currentDisplay.TextValue = errorString;
                }
            }
            else if (operand2.HasValue)
            {
                this.currentDisplay.TextValue = this.operand2.Value.ToString();
                this.currentDisplay.TrimRightZeroes();
            }
            this.operand1 = null;
            this.operand2 = null;
            this.operatorSign = '\0';
        }
        private void OpClear()
        {
            this.currentDisplay.TextValue = "0";
        }
        private void OpReset()
        {
            this.operand1 = null;
            this.operand2 = null;
            this.operatorSign = '\0';
            this.memory = string.Empty;
            this.currentDisplay.TextValue = "0";
        }
        private void OpPut()
        {
            this.memory = this.currentDisplay;
        }
        private void OpGet()
        {
            this.currentDisplay.TextValue = this.memory;
        }
    }

    class TextNumber
    {
        const int displayLength = 10;
        string textValue = "0";

        public string TextValue
        {
            set
            {
                this.textValue = value;

                // podijeli ga
                string[] splitted = this.textValue.Split(',');
                if (splitted == null || splitted[0] == null)
                    return;

                // mogu li prikazati cjelobrojni dio
                if (splitted[0].Count((c) => char.IsDigit(c)) > displayLength)
                    throw new Exception("Cannot show this number");

                this.textValue = splitted[0];

                // ako uopce postoji decimalni dio
                if (splitted.Length > 1 && splitted[1].Length > 0)
                {
                    int fractionalPartLength = displayLength - splitted[0].Count((c) => char.IsDigit(c));
                    double fractionalPart = double.Parse("0," + splitted[1]);
                    fractionalPart = Math.Round(fractionalPart, fractionalPartLength);
                    this.textValue += "," + fractionalPart.ToString().Substring(2);
                }
                //int beforeRounding = splitted[0].Length;
                //// skrati tekst
                //this.RoundText();
                //// ako cjelobrojni dio ne stane, baci exception
                //if (this.textValue.Length < beforeRounding)
                //    throw new Exception("Cannot show this number");
            }
        }

        public void AddChar(char c)
        {
            this.textValue += c;
            this.RoundText();
        }

        /// <summary>
        /// skrati tekst na maksimalnu duljinu znamenki
        /// </summary>
        private void RoundText()
        {
            int digitCount = this.textValue.Count((c) => char.IsDigit(c));
            if (digitCount > displayLength)
            {
                int newLength = this.textValue.Length - (digitCount - displayLength);
                this.textValue = this.textValue.Substring(0, newLength);
            }
        }

        /// <summary>
        /// pretvara trenutni string prikaza u broj
        /// </summary>
        /// <returns></returns>
        private double StringToDouble()
        {
            double value = 0.0;
            double realNumValue = double.Parse(textValue);
            string[] splitted = this.textValue.Split(',');

            // dodaj cjelobrojni dio
            value += double.Parse(splitted[0]);

            if (splitted.Length > 1 && splitted[1].Length > 0) // ako imamo decimalni broj
            {
                value += double.Parse(splitted[1]) * Math.Pow(10, -splitted[1].Length) * (realNumValue >= 0 ? 1 : -1);
            }

            return value;
        }

        /// <summary>
        /// uklanja sve nule s desne strane stringa (i decimalni zarez, ako ostane sam)
        /// </summary>
        public void TrimRightZeroes()
        {
            this.textValue = this.textValue.TrimEnd('0').TrimEnd(',');
            // ako je slucajno odrezao sve nule
            if (this.textValue == "")
                this.textValue = "0";
        }

        public static implicit operator string(TextNumber textNumber)
        {
            return textNumber.textValue;
        }

        public static implicit operator double(TextNumber textNumber)
        {
            return textNumber.StringToDouble();
        }
    }
}
