﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        const string DISPLAY_ON_START = "0";
        const string ERROR = "-E-";
        const char NO_OPERATION = '0';

        string numberForDisplay = DISPLAY_ON_START;
        string memory = DISPLAY_ON_START;

        char operation = NO_OPERATION;

        double number1 = 0;
        double number2 = 0;

        UInt16 lenght = 1;

        bool operationOnDisplay = false;
        bool memoryOn = false;

        public void Press(char inPressedDigit)
        {
            // numbers
            if ((inPressedDigit >= '0') && (inPressedDigit <= '9'))
            {
                addNumberOnDisplay(inPressedDigit);
            }
            // operations
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                    case '-':
                    case '*':
                    case '/':
                        binaryOperation(inPressedDigit);
                        break;
                    case '=':
                        equalOperation();
                        break;
                    case ',':
                        addCommaOnDisplay();
                        break;
                    case 'M':
                        multiplyWithMinusOne();
                        break;
                    case 'S':
                    case 'K':
                    case 'T':
                    case 'Q':
                    case 'R':
                    case 'I':
                        unaryOperation(inPressedDigit);
                        break;
                    case 'P':
                        saveNumberInMemory();
                        break;
                    case 'G':
                        getNumberFromMemory();
                        break;
                    case 'C':
                        clearDisplay();
                        break;
                    case 'O':
                        resetCalc();
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            control();
            return numberForDisplay;
        }

        // '0' <-> '9'
        private void addNumberOnDisplay(char inPressedDigit)
        {
            if (operationOnDisplay)
            {
                operationOnDisplay = false;
                clearDisplay();
            }
            if (lenght < 10)
            {
                if (numberForDisplay == DISPLAY_ON_START)
                    numberForDisplay = inPressedDigit.ToString();
                else
                {
                    memoryOn = false;
                    numberForDisplay += inPressedDigit;
                    lenght++;
                }
            }
        }

        // '+', '-', '*', '/'
        private void binaryOperation(char inPressedDigit)
        {
            memoryOn = false;
            if (!operationOnDisplay)
            {
                operationOnDisplay = true;
                if (operation == '0')
                {
                    number1 = number2 = double.Parse(numberForDisplay);
                }
                else
                {
                    number2 = double.Parse(numberForDisplay);
                    switch (operation)
                    {
                        case '+':
                            number1 += number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '-':
                            number1 -= number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '*':
                            number1 *= number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '/':
                            if (number2 != 0)
                            {
                                number1 /= number2;
                                number1 = Math.Round(number1, 9);
                                numberForDisplay = number1.ToString();
                            }
                            else
                                numberForDisplay = "-E-";
                                break;
                    }
                }
            }
            operation = inPressedDigit;
        }

        // '='
        private void equalOperation()
        {
            memoryOn = false;
            if (operation != '0')
            {
                if (operationOnDisplay)
                {
                    switch (operation)
                    {
                        case '+':
                            number1 += number1;
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '-':
                            number1 = 0;
                            numberForDisplay = number1.ToString();
                            break;
                        case '*':
                            number1 *= number1;
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '/':
                            if (number1 == 0)
                                numberForDisplay = "-E-";
                            else
                            {
                                numberForDisplay = "1";
                                number1 = 1;
                            }
                            break;
                    }
                }
                else
                {
                    number2 = double.Parse(numberForDisplay);
                    switch (operation)
                    {
                        case '+':
                            number1 += number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '-':
                            number1 -= number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '*':
                            number1 *= number2;
                            number1 = Math.Round(number1, 9);
                            if ((number1 > 9999999999) || (number1 < -9999999999))
                                numberForDisplay = "-E-";
                            else
                                numberForDisplay = number1.ToString();
                            break;
                        case '/':
                            if (number2 != 0)
                            {
                                number1 /= number2;
                                number1 = Math.Round(number1, 9);
                                numberForDisplay = number1.ToString();
                            }
                            else
                                numberForDisplay = "-E-";
                            break;
                    }
                }
            }
        }

        // ','
        private void addCommaOnDisplay()
        {
            if (operationOnDisplay)
            {
                operationOnDisplay = false;
                numberForDisplay = DISPLAY_ON_START + ',';
                lenght++;
            }
            else if (!numberForDisplay.Contains(',') && (lenght < 10))
            {
                numberForDisplay += ',';
                if (numberForDisplay == DISPLAY_ON_START + ',')
                    lenght++;
            }
        }

        // 'M'
        private void multiplyWithMinusOne()
        {
            memoryOn = false;
            if (numberForDisplay != DISPLAY_ON_START)
            {
                if (numberForDisplay[0] == '-')
                    numberForDisplay = numberForDisplay.Remove(0, 1);
                else
                    numberForDisplay = '-' + numberForDisplay;
            }
        }

        // 'S', 'K', 'T', 'Q', 'R', 'I'
        private void unaryOperation(char inPressedDigit)
        {
            memoryOn = false;
            if (operation == '0')
            {
                switch (inPressedDigit)
                {
                    case 'S':
                        number1 = Math.Round(Math.Sin(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number1.ToString();
                        break;
                    case 'K':
                        number1 = Math.Round(Math.Cos(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number1.ToString();
                        break;
                    case 'T':
                        // 90 + N*180 = "-E-"
                        number1 = Math.Round(Math.Tan(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number1.ToString();
                        break;
                    case 'Q':
                        number1 = Math.Round(Math.Pow(double.Parse(numberForDisplay), 2), 9);
                        if (number1 > 9999999999)
                            numberForDisplay = "-E-";
                        else
                            numberForDisplay = number1.ToString();
                        break;
                    case 'R':
                        if (numberForDisplay.Contains('-'))
                            numberForDisplay = ERROR;
                        else
                        {
                            number1 = Math.Round(Math.Sqrt(double.Parse(numberForDisplay)), 9);
                            numberForDisplay = number1.ToString();
                        }
                        break;
                    case 'I':
                        if (numberForDisplay == DISPLAY_ON_START)
                            numberForDisplay = ERROR;
                        else
                        {
                            number1 = Math.Round(1 / number1, 9);
                            numberForDisplay = number1.ToString();
                        }
                        break;
                }
            }
            else
            {
                switch (inPressedDigit)
                {
                    case 'S':
                        number2 = Math.Round(Math.Sin(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number2.ToString();
                        break;
                    case 'K':
                        number2 = Math.Round(Math.Cos(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number2.ToString();
                        break;
                    case 'T':
                        // 90 + N*180 = "-E-"
                        number2 = Math.Round(Math.Tan(double.Parse(numberForDisplay)), 9);
                        numberForDisplay = number2.ToString();
                        break;
                    case 'Q':
                        number2 = Math.Round(Math.Pow(double.Parse(numberForDisplay), 2), 9);
                        if (number2 > 9999999999)
                            numberForDisplay = "-E-";
                        else
                            numberForDisplay = number2.ToString();
                        break;
                    case 'R':
                        if (numberForDisplay.Contains('-'))
                            numberForDisplay = ERROR;
                        else
                        {
                            number2 = Math.Round(Math.Sqrt(double.Parse(numberForDisplay)), 9);
                            numberForDisplay = number2.ToString();
                        }
                        break;
                    case 'I':
                        if (numberForDisplay == DISPLAY_ON_START)
                            numberForDisplay = ERROR;
                        else
                        {
                            number2 = Math.Round(1 / number2, 9);
                            numberForDisplay = number2.ToString();
                        }
                        break;
                }
            }
        }

        // 'P'
        private void saveNumberInMemory()
        {
            if (!memoryOn)
            {
                memoryOn = true;
                memory = numberForDisplay;
                clearDisplay();
            }
            else
            {
                memory += numberForDisplay;
                clearDisplay();
            }
        }

        // 'G'
        private void getNumberFromMemory()
        {
            memoryOn = false;
            numberForDisplay = memory;
        }

        // 'C'
        private void clearDisplay()
        {
            numberForDisplay = DISPLAY_ON_START;
            lenght = 0;
        }

        // 'O'
        private void resetCalc()
        {
            numberForDisplay = DISPLAY_ON_START;
            memory = DISPLAY_ON_START;
            operation = NO_OPERATION;
            number1 = 0;
            number2 = 0;
            lenght = 0;
            operationOnDisplay = false;
            memoryOn = false;
        }

        private void control()
        {
            if (numberForDisplay.Contains(','))
                while ((numberForDisplay[numberForDisplay.Length - 1] == '0')
                    || (numberForDisplay[numberForDisplay.Length - 1] == ','))
                {
                    if (numberForDisplay[numberForDisplay.Length - 1] == ',')
                    {
                        numberForDisplay = numberForDisplay.Remove(numberForDisplay.Length-1);
                        break;
                    }
                    else
                        numberForDisplay = numberForDisplay.Remove(numberForDisplay.Length - 1);
                }

        }
    }

}
