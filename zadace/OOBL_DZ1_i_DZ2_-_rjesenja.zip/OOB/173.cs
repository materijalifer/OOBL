﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Zaokruziti
    {
        private int brCijZna = 0, brDecZna = 0;
        private int predznak = 0;
        private int i = 0, j = 0;

        public string zaokruzi(double rez)
        {
            string temp = rez.ToString();
            char[] nizZnak = temp.ToCharArray();

            for (i = 0; i < nizZnak.Length; ++i, ++j)   //ukupno "i" znakova + znamenki, ukupno "j" decimala
            {
                if (nizZnak[i] == ',')
                    j = -1;             //za j=0, broj decimal. mjesta bio bi za jedan veći od stvarnog
            }

            if (rez < 0)                //postoji predznak
                predznak = 1;

            if (j < i)                  //postoji decimalni dio
            {
                brCijZna = i - (j + 1 + predznak);
                brDecZna = j;
            }
            else                        //ne postji decimalni dio
            {
                brDecZna = 0;
                brCijZna = i;
            }


            if (brCijZna > 10)          //ne stane na ekran, error
                return "-E-";
            else if ((brCijZna + brDecZna) > 10)        //definira decimalu za zaokruživanje
            {
                rez = Math.Round(rez, 10 - brCijZna);
            }

            temp = rez.ToString();
            return temp;
        }
    }
    public class Razdvoji
    {
        //string[] _grupZnak = new String[10];
        double _broj;
        List<string> _grupZnak = new List<string>();
        int poziUstr = 0;
        int stanjeBr = -1;
        string temp;
        int pomq = 0;

        public List<string> grupiraj(char UlNizZna)
        {
            if (Char.IsDigit(UlNizZna) || UlNizZna == ',')
            {
                //if ( (stanjeBr < poziUstr && _grupZnak.Capacity == 0) || (stanjeBr < poziUstr && _grupZnak.Count < poziUstr ) )
                //if (stanjeBr < poziUstr && pomq == 0)
                if(stanjeBr < poziUstr)
                {
                    temp = Char.ToString(UlNizZna);
                    _grupZnak.Add(temp);

                    stanjeBr = poziUstr;
                    
                }
                else
                {
                    if (_grupZnak.Count != poziUstr + 1)
                    {
                        poziUstr = _grupZnak.Count - 1;
                        stanjeBr = poziUstr;
                    }
                    string temp = _grupZnak[poziUstr];
                    temp += UlNizZna;
                    _grupZnak[poziUstr] = temp;
                }
            }
            else 
            {
                switch(UlNizZna)
                {
                    case 'M':
                        if (poziUstr == stanjeBr && double.TryParse(_grupZnak[poziUstr], out _broj)) //obavezno upotreba dvostrukog &&, u suporotnom bimo ispitaivali neincijalizirani element liste!!!
                        {
                            _broj = -_broj;
                            _grupZnak[poziUstr] = _broj.ToString();
                        }
                        else
                        {
                            if (stanjeBr < poziUstr)
                            {
                                temp = "-";
                                _grupZnak.Add(temp);

                                stanjeBr = poziUstr;
                            }
                            else
                            {
                                if (_grupZnak[poziUstr] == "-")
                                    _grupZnak[poziUstr] = "";
                                else
                                    _grupZnak[poziUstr] = "-";
                            }
                        }

                        break;
                    case 'Q':
                        
                        if(poziUstr == stanjeBr && (double.TryParse(_grupZnak[poziUstr], out _broj)))
                        {
                            if(_grupZnak.Count != poziUstr+1) //ako je razlika veća za jedan drugima riječima ako ne pokazuju na isti element
                            { 
                                _grupZnak.Insert(_grupZnak.Count-1, "Q");
                                poziUstr = _grupZnak.Count; //prije je bilo -1
                                //stanjeBr = poziUstr;
                            }    
                            else {

                                    _grupZnak.Insert(poziUstr, "Q");

                                ++poziUstr;
                            }
                            //pomq = 1;
                        }
                        else
                        {
                            if (_grupZnak.Count == 0)
                            {
                                _grupZnak.Insert(poziUstr, "Q");
                                ++poziUstr;
                                _grupZnak.Insert(poziUstr, "0");
                            }
                            else
                            {
                                _grupZnak.Insert(poziUstr, "Q");
                                ++poziUstr;
                            }
                        }
                         
                         //   _grupZnak.Insert(poziUstr, "Q");
                           // ++poziUstr;

                        break;

                    case 'C':
                        
       
                        if (poziUstr == stanjeBr && (double.TryParse(_grupZnak[poziUstr], out _broj)))
                        {
                            _grupZnak.Insert(poziUstr, "C");
                            ++poziUstr;
                            pomq = 1;
                        }
                        else
                        {
                            _grupZnak.Insert(poziUstr, "Q");
                            ++poziUstr;
                        }
 

                        break;

                    case '+':
                    case '-':
                    case '*':
                    case '/':
                    case '=':
                        if(_grupZnak.Count == poziUstr+1)
                            ++poziUstr;
                        temp = Char.ToString(UlNizZna);
                        _grupZnak.Add(temp);
                        ++poziUstr;
                        pomq = 0;

                        break;
                }
            }

            return _grupZnak;
        }
    }
    public class Racun
    {
        private double rez = 0, operand = 0;
        private char _operator = '+';
        private int _brPojFunk = 0;
        private char _funkcija;
        char privOpert;

        public double izracunaj(string[] strRef)
        {
//implementirati preko for-a foreach da bih mogao maknuti operand = 0 iz switch-a na način da u prvom if-u to zapakiram u string
            foreach (string element in strRef)
            {
                if(_brPojFunk > 0 && (Double.TryParse(element, out operand)) )
                {
                    switch(_funkcija)
                    {
                        case 'Q':
                            for(int i=0; i<_brPojFunk; ++i) 
                                operand = Math.Pow(operand, 2);

                            _brPojFunk = 0;
                            break;
                            
                    }
                }
                if ( operand != 0 || Double.TryParse(element, out operand) ) //ne smije isprobavati drugi uvjet jer bi mi prebrisao odrađene f-je na operandu
                {
                    switch (_operator)
                    {
                        case '+':
                            rez += operand;
                            operand = 0;
                            break;
                        case '-':
                            rez -= operand;
                            operand = 0;
                            break;
                        case '*':
                            rez *= operand;
                            operand = 0;
                            break;
                        case '/':
                            rez /= operand;
                            operand = 0;
                            break;
                        case 'C':
                            rez = rez;
                            _operator = privOpert;
                            operand = 0;
                            break;
                        case '=':
                            return rez;
                         
                    }
                }
                else
                {
                    switch (element)
                    {
                        case "+":
                            _operator = '+';
                            break;
                        case "-":
                            _operator = '-';
                            break;
                        case "*":
                            _operator = '*';
                            break;
                        case "/":
                            _operator = '/';
                            break;
                        case "=":
                            _operator = '=';
                            break;
                        case "Q":
                            ++_brPojFunk;
                            _funkcija = 'Q';
                            break;
                        case "C":
                            privOpert = _operator;
                            _operator = 'C';
                            break;
                    }
                }
            }

            return rez;
        }

    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public List<string> refLisStr;
        public string[] refNizStr;
        public Razdvoji refRazdvoji = new Razdvoji();
        public string rezStrZaokruzeno = "0";


        public void Press(char inPressedDigit)
        {
            refLisStr = refRazdvoji.grupiraj(inPressedDigit);

            //throw new NotImplementedException();
        }

        public string GetCurrentDisplayState()
        {
            if (refLisStr != null)
            {
                Racun refRacun = new Racun();
                Zaokruziti refZaokruziti = new Zaokruziti();

                refNizStr = refLisStr.ToArray();

                double rez = refRacun.izracunaj(refNizStr);
                rezStrZaokruzeno = refZaokruziti.zaokruzi(rez);
            }

            return rezStrZaokruzeno;
            //throw new NotImplementedException();
        }
    }


}
