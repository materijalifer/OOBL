﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public enum Stanje
    {
        PočetnoStanje,
 
        Oduzimanje,
        StavljenZarez,
        DecimalniBroj,
        
    }

    public enum LastBinaryOperation
    {
        Zbrajanje,
        Oduzimanje,
        Mnozenje,
        Dijeljenje,
        Nijedna
    }

    public class Kalkulator : ICalculator
    {
        char PreviousPressedDigit = 'x';
        string CurrentDisplayState = "0";
        Stanje stanje = Stanje.PočetnoStanje;
        double numInMemory = 0;
        double savedNumber = 0;
        int veličinaBroja = 1;
        double rezultat = 0;
        double operand = 0;
        LastBinaryOperation zadnjaOperacija;

        private void DodajBrojku(char znamenka)
        {
            if (veličinaBroja == 9) return;

            else if ((znamenka == '0') && (numInMemory == 0)) return;


            if ((stanje != Stanje.StavljenZarez))
            {
                
                if (numInMemory != (double) 0)
                {
                    CurrentDisplayState = CurrentDisplayState + znamenka.ToString();
                    veličinaBroja++;
                }
                else
                    CurrentDisplayState = znamenka.ToString();
            }

            if (stanje == Stanje.StavljenZarez)
            {
                CurrentDisplayState = CurrentDisplayState + znamenka.ToString();
                stanje = Stanje.DecimalniBroj;
            }

            numInMemory = Double.Parse(CurrentDisplayState);
        }

        private void StaviZarez()
        {
            if (veličinaBroja == 10) return;
            if (stanje == Stanje.DecimalniBroj) return;

            CurrentDisplayState = CurrentDisplayState + ",";
            stanje = Stanje.StavljenZarez;
        }

        private void Oduzmi()
        {
            if (veličinaBroja == 10) return;
            

            CurrentDisplayState = CurrentDisplayState + ",";
            stanje = Stanje.Oduzimanje;
        }

        private void NamjestiDesetZnamenki(string BrojKojiTrebaSplitati)
        {
            if (BrojKojiTrebaSplitati.Length > 10)
            {
                if (BrojKojiTrebaSplitati.Contains("-") && BrojKojiTrebaSplitati.Contains(","))
                    BrojKojiTrebaSplitati.Substring(0, 12);
                else if (BrojKojiTrebaSplitati.Contains("-") || BrojKojiTrebaSplitati.Contains(","))
                    BrojKojiTrebaSplitati.Substring(0, 11);
                else
                    BrojKojiTrebaSplitati.Substring(0, 10);
            }

        }


        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    DodajBrojku(inPressedDigit);
                    break;

                case '+':
                   // Dodaj();
                    break;

                case '-':
                   Oduzmi();
                    break;

                case '*':
                  //  Pomnozi();
                    break;

                case '/':
                  //  Podijeli();
                    break;

                case '=':
                  //  JeJednako();
                    break;

                case ',':
                    StaviZarez();
                    break;
            }
            if (inPressedDigit == 'O')
            {
                PreviousPressedDigit = 'x';
                CurrentDisplayState = "0";
                numInMemory = 0;
                rezultat = 0;
            }

            if (inPressedDigit == 'P')
            {
                savedNumber = numInMemory;
            }
            else if (inPressedDigit == 'G')
            {
                numInMemory = savedNumber;
                CurrentDisplayState = numInMemory.ToString();
            }

            if (CurrentDisplayState == "-E-")
            {
                if (inPressedDigit == 'P')
                {
                    numInMemory = int.Parse(GetCurrentDisplayState());
                }
                else if (inPressedDigit == 'G')
                {
                    CurrentDisplayState = numInMemory.ToString();
                }
            }
            else
            {
                if (inPressedDigit == 'C')
                {
                    CurrentDisplayState = "0";
                }
            }

            if (PreviousPressedDigit == 'e')
            {
                if (inPressedDigit == 'O')
                {
                    PreviousPressedDigit = 'x';
                    CurrentDisplayState = "0";
                    numInMemory = 0;
                    rezultat = 0;
                }
                else
                    return;
            }

            else if (PreviousPressedDigit == 'x')
            {
                if (Char.IsDigit(inPressedDigit))
                {
                    CurrentDisplayState = inPressedDigit.ToString();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'K')
                {
                    CurrentDisplayState = "1";
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'I')
                {
                    CurrentDisplayState = "-E-";
                    PreviousPressedDigit = 'e';
                }
                else
                    PreviousPressedDigit = inPressedDigit;

            }
            else if (Char.IsDigit(PreviousPressedDigit))
            {
                if (inPressedDigit == 'M')
                {
                    CurrentDisplayState = "-" + CurrentDisplayState;

                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'S')
                {
                    rezultat = Math.Sin(double.Parse(CurrentDisplayState));
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'K')
                {
                    rezultat = Math.Cos(double.Parse(CurrentDisplayState));
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'T')
                {
                    rezultat = Math.Cos(double.Parse(CurrentDisplayState));
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'Q')
                {
                    rezultat = double.Parse(CurrentDisplayState) * double.Parse(CurrentDisplayState);
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'R')
                {
                    rezultat = Math.Sqrt(double.Parse(CurrentDisplayState));
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                else if (inPressedDigit == 'I')
                {
                    if (CurrentDisplayState == "0")
                    {
                        PreviousPressedDigit = 'e';
                        CurrentDisplayState = "-E-";
                    }
                    else
                    {
                        rezultat = 1 / double.Parse(CurrentDisplayState);
                        CurrentDisplayState = rezultat.ToString();
                        ZaokružiNaDesetku();
                        PreviousPressedDigit = inPressedDigit;
                    }
                }
                

            }
            else if (PreviousPressedDigit == '=')
            {

            }
            
            else if ((PreviousPressedDigit == '+'))
            {
                if (inPressedDigit == '=')
                {
                    rezultat = double.Parse(CurrentDisplayState) + double.Parse(CurrentDisplayState);
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
                if (Char.IsDigit(inPressedDigit))
                {
                    operand = double.Parse(CurrentDisplayState);
                    CurrentDisplayState = inPressedDigit.ToString();
                    zadnjaOperacija = LastBinaryOperation.Zbrajanje;
                    PreviousPressedDigit = inPressedDigit;
                    ZaokružiNaDesetku();
                }
            }
            else if ((PreviousPressedDigit == '-'))
            {
                if (inPressedDigit == '=')
                {
                    rezultat = double.Parse(CurrentDisplayState) - double.Parse(CurrentDisplayState);
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;

                }
            }
            else if ((PreviousPressedDigit == '*'))
            {
                if (inPressedDigit == '=')
                {
                    rezultat = double.Parse(CurrentDisplayState) * double.Parse(CurrentDisplayState);
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
            }
            else if ((PreviousPressedDigit == '/'))
            {
                if (inPressedDigit == '=')
                {
                    rezultat = double.Parse(CurrentDisplayState) / double.Parse(CurrentDisplayState);
                    CurrentDisplayState = rezultat.ToString();
                    ZaokružiNaDesetku();
                    PreviousPressedDigit = inPressedDigit;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return CurrentDisplayState;
        }

        public int DisplayToNumber(string CurrentState)
        {
            return int.Parse(CurrentState);
        }


        public void ZaokružiNaDesetku()
        {
            if (CurrentDisplayState.Length == 11)
            {
                if ((CurrentDisplayState.Contains(',')) || (CurrentDisplayState.Contains('-')))
                    CurrentDisplayState = rezultat.ToString();
                else
                    CurrentDisplayState = CurrentDisplayState.Substring(0, 10);
            }
            else if (CurrentDisplayState.Length == 12)
            {
                if ((CurrentDisplayState.Contains(',')) && (CurrentDisplayState.Contains('-')))
                    CurrentDisplayState = rezultat.ToString();
                else
                    CurrentDisplayState = CurrentDisplayState.Substring(0, 11);
            }
            else if (CurrentDisplayState.Length > 12)
            {
                if ((CurrentDisplayState.Contains(',')) && (CurrentDisplayState.Contains('-')))
                    CurrentDisplayState = CurrentDisplayState.Substring(0, 12);
                else if ((CurrentDisplayState.Contains(',')) || (CurrentDisplayState.Contains('-')))
                    CurrentDisplayState = CurrentDisplayState.Substring(0, 11);
                else
                    CurrentDisplayState = CurrentDisplayState.Substring(0, 10);
            }
            else
                CurrentDisplayState = rezultat.ToString();
        }
    }


}
