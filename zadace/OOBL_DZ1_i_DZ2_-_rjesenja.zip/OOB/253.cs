﻿/*
 * VLADIMIR ROSANČIĆ
 * 0036445029
 * 1. DOMAĆA ZADAĆA IZ OBJEKTNOG OBLIKOVANJA
 * Kalkulator
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private String trenutnoStanje;
        private String prviOperand;
        private String drugiOperand;
        private char binarniOperator;
        private Double rezultat;
        private String memorija;
        private Boolean postavljenDrugiOperand;
        private Boolean greska;
        private Boolean kraj;

        public Kalkulator()
        {
            this.trenutnoStanje = "0";
            this.prviOperand = "0";
            this.binarniOperator = '0';
            this.postavljenDrugiOperand = false;
            this.greska = false;
            this.kraj = false;
        }

        public void Press(char inPressedDigit)
        {
            //ako se unese broj
            if (Char.IsNumber(inPressedDigit))
            {
                //ako je postavljen binarni operator, onda radi append na drugi operator. inače na prvi.
                if (binarniOperator != '0')
                {
                    this.postavljenDrugiOperand = true;
                    if (provjeriDuljinu(drugiOperand) < 10)
                        drugiOperand += inPressedDigit;
                    trenutnoStanje = drugiOperand;
                }
                else
                {
                    if (prviOperand.CompareTo("0") == 0)
                    {
                        prviOperand = inPressedDigit.ToString();
                        trenutnoStanje = prviOperand;
                    }
                    else
                    {
                        if (provjeriDuljinu(prviOperand) < 10)
                            prviOperand += inPressedDigit;
                        trenutnoStanje = prviOperand;
                    }
                }

            }
            else if (inPressedDigit == ',')
            {
                if (binarniOperator != '0')
                {
                    drugiOperand += inPressedDigit;
                    trenutnoStanje = drugiOperand;
                }
                else
                {
                    prviOperand += inPressedDigit;
                    trenutnoStanje = prviOperand;
                }
            }
            //ako se unese binarni operator
            else if (inPressedDigit == '+' || inPressedDigit == '-'
                || inPressedDigit == '*' || inPressedDigit == '/')
            {
                this.IzracunajBinarnuOperaciju();
                this.binarniOperator = inPressedDigit;
            }
            //ako se unese unarni operator
            else if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T'
                || inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
            {
                this.izracunajUnarnuOperaciju(inPressedDigit);
            }
            //promjena predznaka
            else if (inPressedDigit == 'M')
            {
                rezultat = Double.Parse(trenutnoStanje) * (-1);
                trenutnoStanje = rezultat.ToString();
                if (binarniOperator == '0')
                {
                    prviOperand = trenutnoStanje;
                }
                else
                {
                    drugiOperand = trenutnoStanje;
                }
            }
            //stavljanje u memoriju
            else if (inPressedDigit == 'P')
            {
                this.memorija = this.trenutnoStanje;
            }
            //dohvaćanje iz memorije
            else if (inPressedDigit == 'G')
            {
                this.trenutnoStanje = this.memorija;
            }

            //resetiranje
            else if (inPressedDigit == 'O')
            {
                this.trenutnoStanje = "0";
                this.prviOperand = "0";
                this.prviOperand = null;
                this.binarniOperator = '0';
                this.postavljenDrugiOperand = false;
                this.greska = false;
                this.memorija = null;
            }

            //brisanje trenutnog stanja
            else if (inPressedDigit == 'C')
            {
                this.trenutnoStanje = "0";
                if (postavljenDrugiOperand)
                    drugiOperand = trenutnoStanje;
                else
                    prviOperand = trenutnoStanje;
            }

            //ako se unese znak '='
            else if (inPressedDigit == '=')
            {
                this.kraj = true;
                if (binarniOperator != '0')
                {
                    this.IzracunajBinarnuOperaciju();
                    this.prviOperand = this.trenutnoStanje;
                    this.drugiOperand = null;
                }
                if (trenutnoStanje != "-E-")
                    this.trenutnoStanje = Double.Parse(trenutnoStanje).ToString();
            }
        }

        private int provjeriDuljinu(String trenutnoStanje)
        {
            if (trenutnoStanje == null)
                return 0;
            string temp = trenutnoStanje.Replace("-", "");
            temp = temp.Replace(",", "");
            return temp.Length;
        }

        private int duljinaCijelogBroja(String trenutnoStanje)
        {
            if (trenutnoStanje == null)
                return 0;
            trenutnoStanje = trenutnoStanje.Replace("-", "");
            int zarez = trenutnoStanje.IndexOf(",");
            if (zarez != -1)
            {
                string temp = trenutnoStanje.Substring(0, zarez);
                return temp.Length;
            }
            else
                return 0;
        }

        private void IzracunajBinarnuOperaciju()
        {
            if (kraj == true)
                this.postavljenDrugiOperand = true;

            if (this.postavljenDrugiOperand)
            {
                if (binarniOperator == '+')
                    rezultat = this.Zbroji();
                else if (binarniOperator == '-')
                    rezultat = this.Oduzmi();
                else if (binarniOperator == '*')
                    rezultat = this.Pomnozi();
                else if (binarniOperator == '/')
                    rezultat = this.Podijeli();

                if (this.provjeriDuljinu(rezultat.ToString()) > 10)
                {
                    rezultat = Math.Round(rezultat, 10 - duljinaCijelogBroja(rezultat.ToString()));
                }

                //ako nakon zaokruživanja rezultat može stati na ekran, ispiši ga. Inače, ispiši '-E-'
                if (this.provjeriDuljinu(rezultat.ToString()) <= 10 && !Double.IsNaN(rezultat))
                {
                    this.trenutnoStanje = rezultat.ToString();
                    this.prviOperand = rezultat.ToString();
                    this.drugiOperand = null;
                    this.kraj = false;
                }
                else
                {
                    this.trenutnoStanje = "-E-";
                    this.prviOperand = null;
                    this.drugiOperand = null;
                }

                this.postavljenDrugiOperand = false;

            }
            else
                this.trenutnoStanje = Double.Parse(this.prviOperand).ToString();
        }

        private Double Zbroji()
        {
            return Double.Parse(prviOperand) + Double.Parse(trenutnoStanje);
        }

        private Double Oduzmi()
        {
            return Double.Parse(prviOperand) - Double.Parse(trenutnoStanje);
        }

        private Double Pomnozi()
        {
            return Double.Parse(prviOperand) * Double.Parse(trenutnoStanje);
        }

        private Double Podijeli()
        {
            return Double.Parse(prviOperand) / Double.Parse(trenutnoStanje);
        }

        private void izracunajUnarnuOperaciju(char unarniOperator)
        {
            if (unarniOperator == 'S')
            {
                rezultat = this.Sinus();
            }
            else if (unarniOperator == 'K')
            {
                rezultat = this.Kosinus();
            }
            else if (unarniOperator == 'T')
            {
                rezultat = this.Tangens();
            }
            else if (unarniOperator == 'Q')
            {
                rezultat = this.Kvadriraj();
            }
            else if (unarniOperator == 'R')
            {
                rezultat = this.Korjenuj();
            }
            else if (unarniOperator == 'I')
            {
                rezultat = this.Inverz();
                if (rezultat == 0)
                {
                    greska = true;
                }
            }

            if (this.provjeriDuljinu(rezultat.ToString()) > 10)
            {
                rezultat = Math.Round(rezultat, 10 - duljinaCijelogBroja(rezultat.ToString()));
            }

            //ako nakon zaokruživanja rezultat može stati na ekran, ispiši ga. Inače, ispiši '-E-'
            if (this.provjeriDuljinu(rezultat.ToString()) <= 10 && !Double.IsNaN(rezultat))
            {
                this.trenutnoStanje = rezultat.ToString();
                if (postavljenDrugiOperand)
                    drugiOperand = trenutnoStanje;
                else
                    if (binarniOperator == '0')
                        prviOperand = trenutnoStanje;
            }
            else
                this.trenutnoStanje = "-E-";

            if (greska)
                this.trenutnoStanje = "-E-";
        }

        private Double Sinus()
        {
            return Math.Sin(Double.Parse(this.trenutnoStanje));

        }

        private Double Kosinus()
        {
            return Math.Cos(Double.Parse(this.trenutnoStanje));
        }

        private Double Tangens()
        {
            return Math.Tan(Double.Parse(this.trenutnoStanje));
        }

        private Double Kvadriraj()
        {
            return Math.Pow(Double.Parse(this.trenutnoStanje), 2);
        }

        private Double Korjenuj()
        {
            return Math.Sqrt(Double.Parse(this.trenutnoStanje));
        }

        private Double Inverz()
        {
            if (trenutnoStanje != "0")
            {
                return 1 / Double.Parse(this.trenutnoStanje);
            }
            else
                return 0;
        }



        public string GetCurrentDisplayState()
        {
            return this.trenutnoStanje;
        }

    }


}