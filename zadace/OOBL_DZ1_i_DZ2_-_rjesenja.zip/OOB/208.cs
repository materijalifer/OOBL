﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public KalkulatorState beginningState = new BeginningState();
        public KalkulatorState FirstOperandEditingState = new FirstOperandEditingState();
        public KalkulatorState SecondOperandEditingState = new SecondOperandEditingState();
        public KalkulatorState equalsPressedState = new EqualsPressedState();

        public static CultureInfo cultureInfo = new CultureInfo("hr-HR");
        public static String errorDisplay = "-E-";
        public static int maxNumOfDigits = 10;

        //private KalkulatorState State;  // za oblikovni obrazac stanje. Mozda nece tribat. Iden prvo rijesit seljacki

        //private string Memory;
        //private string CurrentDisplay;
        //private string FirstOperand;
        //private String SecondOperand;

        public KalkulatorState State { get; set; }

        public String Memory { get; set; }
        public String CurrentDisplay { get; set; }
        public String FirstOperand { get; set; }
        public String SecondOperand { get; set; }

        // konstruktor
        public Kalkulator()
        {
            CurrentDisplay = "0";

            Memory = "empty";
            FirstOperand = "empty";
            SecondOperand = "empty";

            State = beginningState;
        }

        public void Press(char inPressedDigit)
        {
            State.Press(inPressedDigit, this);
        }

        public string GetCurrentDisplayState()
        {
            if (CurrentDisplay == Kalkulator.errorDisplay)
                return CurrentDisplay;
            State.ModifyCurrentDisplay(this);
            return CurrentDisplay;
        }

        internal void reset()
        {
            CurrentDisplay = "0";
            Memory = "empty";
            FirstOperand = "empty";
            SecondOperand = "empty";
            State = beginningState;
        }
    }

    public abstract class KalkulatorState
    {
        protected char[] binaryOperators = new char[] {'+', '-', '/', '*'};
        protected char[] unaryOperators = new char[] {'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G', 'C', 'O'};
        protected char[] trimCharacters = new char[] {'0', ','};

        public static char binaryOperator;

        virtual public void Press(char pressedDigit, Kalkulator kalkulator)
        {
        }

        virtual public void ModifyCurrentDisplay(Kalkulator kalkulator)
        {
            if(kalkulator.CurrentDisplay.Contains(','))
                kalkulator.CurrentDisplay = kalkulator.CurrentDisplay.TrimEnd(trimCharacters);

            // triba provjerit broj znamenki cijelog i decimalnog dijela
            int numOfDigitsBeforeComma = NumOfDigitsBeforeDecimalComma(kalkulator);
            int numOfDitgitsAfterComma = NumOfDigitsAfterDecimalComma(kalkulator);

            if (kalkulator.CurrentDisplay == "")
                kalkulator.CurrentDisplay = "0";

            if (numOfDigitsBeforeComma > Kalkulator.maxNumOfDigits)
            {
                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                kalkulator.State = kalkulator.equalsPressedState;
            }
            else
            {
                int decimalDigitsLeft = Kalkulator.maxNumOfDigits - numOfDigitsBeforeComma;
                double result = Double.Parse(kalkulator.CurrentDisplay, Kalkulator.cultureInfo);
                result = Math.Round(result, decimalDigitsLeft);

                kalkulator.CurrentDisplay = result.ToString(Kalkulator.cultureInfo);
            }
        }

        int NumOfDigitsBeforeDecimalComma(Kalkulator kalkulator)
        {
            int numOfDigits = 0;
            foreach(Char ch in kalkulator.CurrentDisplay)
            {
                if (ch == ',')
                {
                    break;
                }
                else if (Char.IsDigit(ch))
                {
                    numOfDigits++;
                }
            }

            return numOfDigits;
        }

        // mozda nece ni tribat
        int NumOfDigitsAfterDecimalComma(Kalkulator kalkulator)
        {
            int numOfDigits = 0;
            int positionOfComma = kalkulator.CurrentDisplay.IndexOf(',');

            // provjerit jel ovo radi
            // mozda buden mora napravit drukcije
            numOfDigits = kalkulator.CurrentDisplay.Length - (positionOfComma + 1);

            return numOfDigits;
        }
    }

    public class BeginningState : KalkulatorState
    {
        public override void Press(char pressedDigit, Kalkulator kalkulator)
        {
            if(Char.IsDigit(pressedDigit))
            {
                kalkulator.CurrentDisplay = pressedDigit.ToString();
                kalkulator.State = kalkulator.FirstOperandEditingState;
            }
            else if (pressedDigit == ',')
            {
                kalkulator.CurrentDisplay += pressedDigit;
                kalkulator.State = kalkulator.FirstOperandEditingState;
            }
            else if (binaryOperators.Contains(pressedDigit))
            {
                kalkulator.State = kalkulator.SecondOperandEditingState;
                // o kojoj je opearciji rijec
                KalkulatorState.binaryOperator = pressedDigit;
                // spremamo prvi operand koji je nula...
                kalkulator.FirstOperand = kalkulator.CurrentDisplay;
            }
            else if (unaryOperators.Contains(pressedDigit))
            {
                switch (pressedDigit)
                {
                    case 'I':
                        kalkulator.CurrentDisplay = "-E-";
                        kalkulator.State = kalkulator.equalsPressedState;
                        break;
                    case 'K': break;
                    case 'M':   // -0 nema smisla
                    case 'S':   // sin(0) = 0
                    case 'T':   // tan(0) = 0
                    case 'Q':   // 0^2 = 0
                    case 'R':   // sqrt(0) = 0
                    case 'P':
                    case 'G':
                    case 'C':
                    case 'O':
                        break;
                    default: break;
                }
            }
            else if (pressedDigit == '=')
            {
                kalkulator.State = kalkulator.equalsPressedState;
            }

        }
    }

    public class FirstOperandEditingState : KalkulatorState
    {
        public override void Press(char pressedDigit, Kalkulator kalkulator)
        {
            if(Char.IsDigit(pressedDigit))
            {
                kalkulator.CurrentDisplay += pressedDigit;
            }
            else if(pressedDigit == ',')
            {
                if(!kalkulator.CurrentDisplay.Contains(','))
                {
                    kalkulator.CurrentDisplay += ',';
                }
            }
            else if(binaryOperators.Contains(pressedDigit))
            {
                kalkulator.FirstOperand = kalkulator.CurrentDisplay;
                kalkulator.State = kalkulator.SecondOperandEditingState;
                KalkulatorState.binaryOperator = pressedDigit;
            }
            else if (unaryOperators.Contains(pressedDigit))
            {
                double result = Double.Parse(kalkulator.CurrentDisplay, Kalkulator.cultureInfo);
                switch (pressedDigit)
                {
                    case 'I':
                        if (result == 0)
                            kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                        else
                        {
                            result = 1 / result;
                            kalkulator.CurrentDisplay = result.ToString(Kalkulator.cultureInfo);
                            ModifyCurrentDisplay(kalkulator);
                        }
                        kalkulator.State = kalkulator.equalsPressedState;
                        break;
                    case 'K':
                        result = Math.Cos(result);
                        DisplayAfterUnarOperationOnFirstOperand(kalkulator, result);
                        break;
                    case 'S':
                        result = Math.Sin(result);
                        DisplayAfterUnarOperationOnFirstOperand(kalkulator, result);
                        break;
                    case 'T':
                        result = Math.Tan(result);
                        DisplayAfterUnarOperationOnFirstOperand(kalkulator, result);
                        break;
                    case 'M':
                        kalkulator.CurrentDisplay = kalkulator.CurrentDisplay.Insert(0, "-");
                        break;
                    case 'Q':
                        result *= result;
                        DisplayAfterUnarOperationOnFirstOperand(kalkulator, result);
                        break;
                    case 'R':
                        if (result < 0)
                        {
                            kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                        }
                        else
                        {
                            result = Math.Sqrt(result);
                            DisplayAfterUnarOperationOnFirstOperand(kalkulator, result);
                        }
                        break;
                    case 'P':
                        kalkulator.Memory = kalkulator.CurrentDisplay;
                        break;
                    case 'G':
                        kalkulator.CurrentDisplay = kalkulator.Memory;
                        break;
                    case 'C':
                        kalkulator.CurrentDisplay = "0";
                        break;
                    case 'O':
                        kalkulator.reset();
                        break;
                    default: break;
                }
            }
            else if (pressedDigit == '=')
            {
                ModifyCurrentDisplay(kalkulator);
                kalkulator.State = kalkulator.equalsPressedState;
            }
        }

        private void DisplayAfterUnarOperationOnFirstOperand(Kalkulator kalkulator, double result)
        {
            kalkulator.CurrentDisplay = result.ToString(Kalkulator.cultureInfo);
            ModifyCurrentDisplay(kalkulator);
            //kalkulator.State = kalkulator.equalsPressedState;
        }
    }

    public class SecondOperandEditingState : KalkulatorState
    {
        //pamti se zadnji operand
        public override void Press(char pressedDigit, Kalkulator kalkulator)
        {
            if(Char.IsDigit(pressedDigit))
            {
                if (kalkulator.SecondOperand == "empty")
                {
                    kalkulator.SecondOperand = pressedDigit.ToString();
                }
                else
                {
                    kalkulator.SecondOperand += pressedDigit;
                }
            }
            else if(pressedDigit == ',')
            {
                if (kalkulator.SecondOperand == "empty")
                {
                    kalkulator.SecondOperand = "0,";
                }
                else
                {
                    if (!kalkulator.SecondOperand.Contains(','))
                    {
                        kalkulator.SecondOperand += ',';
                    }
                }
            }
            else if (binaryOperators.Contains(pressedDigit))
            {
                // operandi se zanemaruju ako je upisan samo jedan operand
                if (kalkulator.SecondOperand == "empty")
                {
                    binaryOperator = pressedDigit;
                }
                else 
                {
                    double first = Double.Parse(kalkulator.FirstOperand, Kalkulator.cultureInfo);
                    double second = Double.Parse(kalkulator.SecondOperand, Kalkulator.cultureInfo);
                    kalkulator.SecondOperand = "empty";
                    double result = 0.0;
                    switch (binaryOperator)
                    {
                        case '+':
                            result = first + second;
                            ResolveBinaryOperation(kalkulator, result);
                            break;
                        case '-':
                            result = first - second;
                            ResolveBinaryOperation(kalkulator, result);
                            break;
                        case '*':
                            result = first * second;
                            ResolveBinaryOperation(kalkulator, result);
                            break;
                        case '/':
                            if (second == 0.0)
                            {
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            }
                            else
                            {
                                result = first / second;
                                ResolveBinaryOperation(kalkulator, result);
                            }
                            break;
                        default: break;
                    }
                    binaryOperator = pressedDigit;
                }
            }
            else if (unaryOperators.Contains(pressedDigit))
            {
                if (kalkulator.SecondOperand == "empty")
                {
                    // obavit operaciju nad prvim operatorom i spremit ga u drugi?? Kaze tole da je ovo ispravno. cudan je ovo slucaj
                    double result = Double.Parse(kalkulator.FirstOperand, Kalkulator.cultureInfo);
                    switch (pressedDigit)
                    {
                        case 'I':
                            if (result == 0)
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            else
                            {
                                result = 1 / result;
                                //UnaryOnOperand(kalkulator, result);
                                kalkulator.CurrentDisplay = result.ToString();
                                base.ModifyCurrentDisplay(kalkulator);
                            }
                            // bi li ovdi tribalo ic equalpressed stanje
                            break;
                        case 'K':
                            result = Math.Cos(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'S':
                            result = Math.Sin(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'T':
                            result = Math.Tan(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'M':
                            if (kalkulator.FirstOperand.StartsWith("-"))
                                kalkulator.FirstOperand = kalkulator.FirstOperand.Substring(1);
                            else
                                kalkulator.FirstOperand.Insert(0, "-");
                            break;
                        case 'Q':
                            result *= result;
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'R':
                            if (result < 0)
                            {
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            }
                            else
                            {
                                result = Math.Sqrt(result);
                                UnaryOnOperand(kalkulator, result);
                            }
                            break;
                        case 'P':
                            kalkulator.Memory = kalkulator.CurrentDisplay;
                            break;
                        case 'G':
                            kalkulator.CurrentDisplay = kalkulator.Memory;
                            break;
                        case 'C':
                            kalkulator.CurrentDisplay = "0";
                            break;
                        case 'O':
                            kalkulator.reset();
                            break;
                        default: break;
                    }
                }
                else
                {
                    double result = Double.Parse(kalkulator.SecondOperand, Kalkulator.cultureInfo);
                    ModifyCurrentDisplay(kalkulator);
                    switch (pressedDigit)
                    {
                        case 'I':
                            if (result == 0)
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            else
                            {
                                result = 1 / result;
                                UnaryOnOperand(kalkulator, result);
                            }
                            // bi li ovdi tribalo ic equalpressed stanje
                            break;
                        case 'K':
                            result = Math.Cos(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'S':
                            result = Math.Sin(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'T':
                            result = Math.Tan(result);
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'M':
                            if (kalkulator.SecondOperand.StartsWith("-"))
                                kalkulator.SecondOperand = kalkulator.SecondOperand.Substring(1);
                            else
                                kalkulator.SecondOperand = kalkulator.SecondOperand.Insert(0, "-");
                            break;
                        case 'Q':
                            result *= result;
                            UnaryOnOperand(kalkulator, result);
                            break;
                        case 'R':
                            if (result < 0)
                            {
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            }
                            else
                            {
                                result = Math.Sqrt(result);
                                UnaryOnOperand(kalkulator, result);
                            }
                            break;
                        case 'P':
                            kalkulator.Memory = kalkulator.CurrentDisplay;
                            break;
                        case 'G':
                            kalkulator.CurrentDisplay = kalkulator.Memory;
                            break;
                        case 'C':
                            kalkulator.SecondOperand = "0";
                            ModifyCurrentDisplay(kalkulator);
                            break;
                        case 'O':
                            kalkulator.reset();
                            break;
                        default: break;
                    }
                }
            }
            else if (pressedDigit == '=')   // triba izracunat
            {
                // ako nema drugog operanda, onda se nad prvin operandon vrsi operacija
                if(kalkulator.SecondOperand == "empty")
                {
                    double first = Double.Parse(kalkulator.FirstOperand, Kalkulator.cultureInfo);
                    double second = first;
                    kalkulator.SecondOperand = "empty";
                    double result = 0.0;
                    switch (binaryOperator)
                    {
                        case '+':
                            result = first + second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '-':
                            result = first - second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '*':
                            result = first * second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '/':
                            if (second == 0.0)
                            {
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            }
                            else
                            {
                                result = first / second;
                                ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            }
                            break;
                        default: break;
                    }
                }
                // inace se racuna operacija na oba operanda
                else
                {
                    double first = Double.Parse(kalkulator.FirstOperand, Kalkulator.cultureInfo);
                    double second = Double.Parse(kalkulator.SecondOperand, Kalkulator.cultureInfo);
                    kalkulator.SecondOperand = "empty";
                    double result = 0.0;
                    switch (binaryOperator)
                    {
                        case '+':
                            result = first + second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '-':
                            result = first - second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '*':
                            result = first * second;
                            ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            break;
                        case '/':
                            if (second == 0.0)
                            {
                                kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                            }
                            else
                            {
                                result = first / second;
                                ResolveBinaryOperationAndSetEqualsPressedState(kalkulator, result);
                            }
                            break;
                        default: break;
                    }
                }
            }
        }

        private void ResolveBinaryOperationAndSetEqualsPressedState(Kalkulator kalkulator, double result)
        {
            kalkulator.CurrentDisplay = result.ToString(Kalkulator.cultureInfo);
            base.ModifyCurrentDisplay(kalkulator);
            // prvi operand se prikazuje na displeju
            kalkulator.FirstOperand = kalkulator.SecondOperand = "empty";
            kalkulator.State = kalkulator.equalsPressedState;
        }

        private void UnaryOnOperand(Kalkulator kalkulator, double result)
        {
            kalkulator.CurrentDisplay = result.ToString(Kalkulator.cultureInfo);
            kalkulator.SecondOperand = kalkulator.CurrentDisplay;   //
            ModifyCurrentDisplay(kalkulator);
            //kalkulator.SecondOperand = kalkulator.CurrentDisplay;
        }

        private void ResolveBinaryOperation(Kalkulator kalkulator, double result)
        {
            kalkulator.CurrentDisplay = kalkulator.FirstOperand = result.ToString(Kalkulator.cultureInfo);
            ModifyCurrentDisplay(kalkulator);
            // prvi operand se prikazuje na displeju
            kalkulator.FirstOperand = kalkulator.CurrentDisplay;
        }



        public override void ModifyCurrentDisplay(Kalkulator kalkulator)
        {
            //provjerit jel ide first ili second operator u displej
            // kalkulator.CurrentDisplay == FirstOperand ili kalkulator.CurrentDisplay == SecondOperand;
            //if (kalkulator.SecondOperand == "empty")
            //{
            //    kalkulator.CurrentDisplay = kalkulator.FirstOperand;
            //}
            if(kalkulator.SecondOperand != "empty")
            {
                kalkulator.CurrentDisplay = kalkulator.SecondOperand;
            }

            base.ModifyCurrentDisplay(kalkulator);
        }
    }

    public class EqualsPressedState : KalkulatorState
    {
        public override void Press(char pressedDigit, Kalkulator kalkulator)
        {
            if (binaryOperators.Contains(pressedDigit))
            {
                KalkulatorState.binaryOperator = pressedDigit;
                kalkulator.FirstOperand = kalkulator.CurrentDisplay;
                kalkulator.State = kalkulator.SecondOperandEditingState;
            }
            else if (unaryOperators.Contains(pressedDigit))
            {
                double result = Double.Parse(kalkulator.CurrentDisplay, Kalkulator.cultureInfo);
                switch (pressedDigit)
                {
                    case 'I':
                        if (result == 0)
                            kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                        else
                        {
                            result = 1 / result;
                            kalkulator.CurrentDisplay = result.ToString();
                            ModifyCurrentDisplay(kalkulator);
                        }
                        break;
                    case 'K':
                        result = Math.Cos(result);
                        kalkulator.CurrentDisplay = result.ToString();
                        ModifyCurrentDisplay(kalkulator);
                        break;
                    case 'S':
                        result = Math.Sin(result);
                        kalkulator.CurrentDisplay = result.ToString();
                        ModifyCurrentDisplay(kalkulator);
                        break;
                    case 'T':
                        result = Math.Tan(result);
                        kalkulator.CurrentDisplay = result.ToString();
                        ModifyCurrentDisplay(kalkulator);
                        break;
                    case 'M':
                        if (kalkulator.CurrentDisplay.StartsWith("-"))
                            kalkulator.CurrentDisplay = kalkulator.CurrentDisplay.Substring(1);
                        else
                            kalkulator.CurrentDisplay = kalkulator.CurrentDisplay.Insert(0, "-");
                        break;
                    case 'Q':
                        result *= result;
                        kalkulator.CurrentDisplay = result.ToString();
                        ModifyCurrentDisplay(kalkulator);
                        break;
                    case 'R':
                        if (result < 0)
                        {
                            kalkulator.CurrentDisplay = Kalkulator.errorDisplay;
                        }
                        else
                        {
                            result = Math.Sqrt(result);
                            kalkulator.CurrentDisplay = result.ToString();
                            ModifyCurrentDisplay(kalkulator);
                        }
                        break;
                    case 'P':
                        kalkulator.Memory = kalkulator.CurrentDisplay;
                        break;
                    case 'G':
                        kalkulator.CurrentDisplay = kalkulator.Memory;
                        break;
                    case 'C':
                        kalkulator.CurrentDisplay = "0";
                        ModifyCurrentDisplay(kalkulator);
                        break;
                    case 'O':
                        kalkulator.reset();
                        break;
                    default: break;
                }
            }
            else if (Char.IsDigit(pressedDigit))
            {
                kalkulator.CurrentDisplay = pressedDigit.ToString();
                kalkulator.State = kalkulator.FirstOperandEditingState;
            }
            else if (pressedDigit == ',')
            {
                kalkulator.CurrentDisplay = "0,";
                kalkulator.State = kalkulator.FirstOperandEditingState;
            }
        }
    }
}
