﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory{
        public static ICalculator CreateCalculator(){
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator{
        private String displayState;
        private Double oldState;
        private Char operation;
        private double memory;
        private Boolean flag = false;

        public Kalkulator(){
            displayState = "0";
            oldState = 0;
            operation = 'E';
            memory = 0;
        }

        public void Press(char inPressedDigit){
            if(displayState.Equals("-E-")) {
                resetCalculator();
            }

            

            if(Char.IsNumber(inPressedDigit)) {
                if(flag) {
                    displayState = "";
                    flag = false;
                }
                int inDigit = (int) Char.GetNumericValue(inPressedDigit);

                if(displayState.Equals("0") && inDigit == 0 ) {
                    //do nothing
                }
                else {
                    addDigit(inDigit);
                }
            }
            else {
                doOperation(inPressedDigit);
            }
        }


        public string GetCurrentDisplayState(){
            return displayState;
        }


        private void addDigit( int digit ) {
            Char[] array = displayState.ToCharArray();
            int numberOfDigits = 0;

            for(int i = 0; i < array.Length; i++ ) {
                if(Char.IsNumber(array[i]))
                    numberOfDigits++;
            }

            if(numberOfDigits < 10) {
                if(numberOfDigits == 1 && displayState.Equals("0")) {
                    displayState = digit.ToString();
                }
                else {
                    displayState += digit.ToString();
                }
            }

        }

        private void doOperation(char inChar) {
            switch(inChar) {
                case '+':
                    if(operation != 'E' && !flag ) {
                        equals();
                    }
                    operation = inChar;
                    basicMath();
                    break;
                case '-':
                    if(operation != 'E' && !flag) {
                        equals();
                    }
                    operation = inChar;
                    basicMath();
                    break;
                case '*':
                    if(operation != 'E' && !flag) {
                        equals();
                    }
                    operation = inChar;
                    basicMath();
                    break;
                case '/':
                    if(operation != 'E' && !flag) {
                        equals();
                    }
                    operation = inChar;
                    basicMath();
                    break;
                case 'M':
                    changeSign();
                    break;
                case 'S':
                    updateDisplay(Math.Sin(double.Parse(displayState.Replace(",", "."))) );
                    break;
                case 'K':
                    updateDisplay(Math.Cos(double.Parse(displayState.Replace(",", "."))));
                    break;
                case 'T':
                    updateDisplay(Math.Tan(double.Parse(displayState.Replace(",", "."))));
                    break;
                case 'Q':
                    updateDisplay(Math.Pow(double.Parse(displayState.Replace(",", ".")), 2));
                    break;
                case 'R':
                    updateDisplay( Math.Pow( double.Parse( displayState.Replace( ",", "." ) ), 0.5 ) );
                    break;
                case 'I':
                    updateDisplay( 1 / double.Parse(displayState.Replace(",", ".")) );
                    break;
                case 'P':
                    saveToMemory();
                    break;
                case 'G':
                    getFromMemory();
                    break;
                case 'C':
                    displayState = "0";
                    break;
                case 'O':
                    resetCalculator();
                    break;
                case ',':
                    addDecimalPoint();
                    break;
                case '=':
                    equals();
                    break;
            }
        }

        private void saveToMemory() {
            memory = double.Parse(displayState.Replace(",", "."));
        }

        private void getFromMemory() {
            updateDisplay(memory);
        }

        private void resetCalculator(){
            memory = 0;
            displayState = "0";
            oldState = 0;
            operation = '=';
        }

        private void changeSign() {
            displayState = (-double.Parse(displayState.Replace(",", "."))).ToString().Replace( ".", "," );
        }

        private void addDecimalPoint() {
            displayState += ",";
        }

        private void equals(){
            double result = oldState;
            double secondOperand;

            if( displayState.Equals( "" ) ){
                secondOperand = oldState;
            }
            else{
                secondOperand = double.Parse( displayState.Replace( ",", "." ) );
            }

            switch( operation ){
                case '+':
                    result += secondOperand;
                    break;
                case '-':
                    result -= secondOperand;
                    break;
                 case '*':
                    result *= secondOperand;
                    break;
                 case '/':
                    result /= secondOperand;
                    break;
                default:
                    result = double.Parse(displayState.Replace(",", "."));
                    break;
            }

            operation = 'E';
            updateDisplay( result );

        }

        private void updateDisplay( double result ){
            if( Math.Abs( result ) > 9999999999.0 ){
                displayState = "-E-";
            }
            else{
                String s = result.ToString().Replace( ".", "," );
                if(s.Length > 12) {
                    s = s.Substring(0, 12);
                }
                int numberOfDigits = 0;

                for( int i = 0; i < 12; i++ ){

                    if(s.Length <= i) {
                        break;
                    }

                    if( Char.IsNumber( s[i] ) ){
                        numberOfDigits++;
                    }
                }

                while(numberOfDigits > 10) {
                    numberOfDigits--;
                    if(Char.GetNumericValue(s[s.Length - 1]) > 0.5) {
                        
                        String tmp = s.Substring(0, s.Length - 2);
                        s = s.Substring(0, s.Length - 1);
                        s = tmp + (Char.GetNumericValue(s[s.Length - 1]) + 1).ToString();
                    }
                    else {
                        s = s.Substring(0, s.Length - 1);
                    }
                }

                displayState = s;
            }

        }

        private void basicMath() {
            oldState = double.Parse( displayState.Replace( ",", "." ) );
            flag = true;
        }
    }


}
