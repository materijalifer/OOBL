﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Reflection;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

        public class Kalkulator : ICalculator
        {
            private Boolean nova = true;
            private static string prviBroj = "";
            private static string drugiBroj = "";
            private static string rezultat = "0";
            private static double racunaj = 0;
            private static char aktivniOperator = '0';
            private static string memorija = "";

            private static Dictionary<char, Action> posebniOperatori = new Dictionary<char, Action>()        
        {           
            {',',zarez},
            {'=',izracunaj}
        };

            private static Dictionary<char, Action> binarniOperatori = new Dictionary<char, Action>()
        {
            {'-',oduzmi},
            {'+',zbroji },
            {'*',pomnozi},
            {'/',podijeli}
        };

            private static Dictionary<char, Action> unarni = new Dictionary<char, Action>()
        {      
            {'M',promjeniPredznak},
            {'S',sinus},
            {'K',kosinus},
            {'T',tangens},
            {'Q',kvadriranje},
            {'R', korjenovanje},
            {'I',invers},
            {'C',izbrisi},
            {'O',izgasi},
            {'P',spremi},
            {'G',dohvati},
        };

            #region posebni operatori

            private static void zarez()
            {
                if (aktivniOperator.Equals('0')) //Ako je unesen samo jedan broj
                {
                    if (prviBroj.Length == 0)    //ako treba dodati 0 na pocetku
                    {
                        prviBroj = "0" + ',';
                    }
                    else   // ako postoje brojevi prije decmimalnog zareza provjeri postoji li vec zarez 
                    {
                        if (!prviBroj.Contains(','))     
                        {
                            prviBroj = prviBroj + ','; //Ako zarez ne postoji dodaj ga, inace ignoriraj
                        }
                    }
                }
                else          //Zarez treba staviti u drugi broj
                {
                    if (drugiBroj.Length == 0)     //postavi 0 ako ne postoji nista
                    {
                        drugiBroj = "0" + ',';
                    }
                    else
                    {
                        if (!drugiBroj.Contains(','))        //ako zarez ne postoji dodaj ga ,inace ignoriraj
                        {
                            drugiBroj = drugiBroj + ',';
                        }
                    }
                }


            }

            private static void izracunaj()     //Funkcija =
            {
                if (!aktivniOperator.Equals('0'))      //ako postoji operator koji se mora izvrsiti
                {
                    if (drugiBroj.Equals(""))         //drugi broj ne postoji pa treba kopirati prvi i izvrsiti operaciju s dva ista broja 
                    {
                        drugiBroj = prviBroj;
                    }
                    binarniOperatori[aktivniOperator]();  //operacija
                    rezultat = racunaj.ToString();
                    prviBroj = rezultat;                 //rezultat operacije spremamo sada kao prvi broj
                }
                else
                {
                    racunaj = double.Parse(prviBroj);       //ako ne postoji operator koji treba izvrsit zaokruzi broj i posalji u rezultat
                    rezultat = racunaj.ToString();
                }
            }

            #endregion

            
            #region unarni operatori
            private static void promjeniPredznak()
            {
                racunaj = racunaj * (-1);
                rezultat = racunaj.ToString();
            }
            private static void sinus()
            {
                racunaj = Math.Sin(racunaj);
                rezultat = racunaj.ToString();
            }
            private static void kosinus()
            {
                racunaj = Math.Cos(racunaj);
               // racunaj = Math.Round(racunaj, 9);
                rezultat = racunaj.ToString();
            }
            private static void tangens()
            {
                racunaj = Math.Tan(racunaj);
                rezultat = racunaj.ToString();

            }
            private static void kvadriranje()
            {
                racunaj = Math.Pow(racunaj, 2);
                rezultat = racunaj.ToString();
            }
            private static void korjenovanje()
            {
                racunaj = Math.Sqrt(racunaj);
                rezultat = racunaj.ToString();
            }
            private static void invers()
            {

                racunaj = 1 / racunaj;
                racunaj = Math.Round(racunaj, 9);
                rezultat = racunaj.ToString();
                if (rezultat.Equals("Infinity"))   //provjeri da li je rezultat ispravan
                {
                    rezultat = "-E-";
                }

            }
            private static void izbrisi()
            {
                if (!prviBroj.Equals("") && drugiBroj.Equals(""))      //nadi koji broj treba izbrisat
                {
                    prviBroj = "";
                    rezultat = "0";
                }
                else if (!prviBroj.Equals("") && !drugiBroj.Equals(""))
                {
                    drugiBroj = "";
                    rezultat = "0";

                }

            }
            private static void izgasi()
            {
                rezultat = "0";                   //reset svih operacija
                prviBroj = "";
                drugiBroj = "";
                aktivniOperator = '0';
            }
            private static void spremi()
            {
                memorija = rezultat;
            }

            private static void dohvati()
            {
                rezultat = memorija;
            }
            #endregion

            #region binarni operatori
            private static void oduzmi()
            {
                if (aktivniOperator.Equals('0') && prviBroj.Equals(""))       //ako ne treba oduzimati nego treba postaviti minus kao predznak
                {
                    prviBroj = "-";
                    rezultat = prviBroj;
                }
                else
                {
                    racunaj = double.Parse(prviBroj) - double.Parse(drugiBroj);  // inace izracunaj
                }
            }

            private static void zbroji()
            {
                racunaj = double.Parse(prviBroj) + double.Parse(drugiBroj);
            }
            private static void pomnozi()
            {
                racunaj = double.Parse(prviBroj) * double.Parse(drugiBroj);
            }
            private static void podijeli()
            {
                racunaj = double.Parse(prviBroj) / double.Parse(drugiBroj);
                rezultat = racunaj.ToString();
                if (rezultat.Equals("Infinity"))
                {
                    rezultat = "-E-";
                }
            }

            #endregion


            public void Press(char inPressedDigit)
            {
                //kod nove instance sve staticke varijable resetiraj
                if (nova)
                {
                    prviBroj = "";
                    drugiBroj = "";
                    rezultat = "0";
                    racunaj = 0;
                    aktivniOperator = '0';
                    memorija = "";
                    nova = false;
                    
                }

                if (Char.IsNumber(inPressedDigit))
                {
                    //prvi broj 
                    if (aktivniOperator.Equals('0'))
                    {
                        //ako je vec uneseno dovoljno znamenki nemoj vise dodavat
                        if (!(prviBroj.Length > 11 && prviBroj.Contains('-')) || (!(prviBroj.Length > 10 && !prviBroj.Contains('-'))))
                        {
                            prviBroj = prviBroj + inPressedDigit;
                            rezultat = prviBroj;
                        }
                    }
                    else
                    {
                        if (!(drugiBroj.Length > 11 && drugiBroj.Contains('-')) || (!(drugiBroj.Length > 10 && !drugiBroj.Contains('-'))))
                        {
                            drugiBroj = drugiBroj + inPressedDigit;
                            rezultat = drugiBroj;

                        }
                    }

                }

                else if (unarni.ContainsKey(inPressedDigit))
                {
                    //izvrsi operaciju

                    racunaj = Double.Parse(rezultat);
                    unarni[inPressedDigit]();
                    //ovisno o tome koliko brojeva trenutno postoji spremi rezultat kao jedan broj
                    if (!aktivniOperator.Equals('0') && !drugiBroj.Equals(""))
                    {
                        drugiBroj = rezultat;
                    }
                    else if (aktivniOperator.Equals('0') && drugiBroj.Equals(""))
                    {
                        prviBroj = rezultat;
                    }

                }
                else if (binarniOperatori.ContainsKey(inPressedDigit))
                {
                    //ako je ovo prvi operator 
                    if (aktivniOperator.Equals('0'))
                    {
                        if (inPressedDigit.Equals('-') && prviBroj.Equals(""))
                        {
                            prviBroj = "-";
                        }
                        else
                        {
                            aktivniOperator = inPressedDigit;
                            racunaj = double.Parse(prviBroj);
                            rezultat = racunaj.ToString();

                        }
                    }
                        //ako je vec prije bio neki operator
                    else
                    {
                        //ako se moze izracunati operacija
                        if (!drugiBroj.Equals(""))
                        {
                            binarniOperatori[aktivniOperator]();
                            aktivniOperator = inPressedDigit;
                            rezultat = racunaj.ToString();
                            prviBroj = rezultat;
                            drugiBroj = "";
                        }
                            //ako ne postoji drugi broj stari operator koji je bio zadan se zanemaruje
                        else
                        {
                            aktivniOperator = inPressedDigit;
                            racunaj = double.Parse(prviBroj);
                            rezultat = racunaj.ToString();
                            prviBroj = rezultat;
                            drugiBroj = "";
                        }

                    }

                }
                    //obrada posebnih znakova nakon kojih nema nikakvih operacija s rezultatima
                else if (posebniOperatori.ContainsKey(inPressedDigit))
                {
                    posebniOperatori[inPressedDigit]();
                }
                    //ako se upisu gluposti ispisi gresku
                else
                {
                    rezultat = "-E-";
                }
            }
            //stanje kalkulatora
            public string GetCurrentDisplayState()
            {
                //skloni sve nule s pocetka
                rezultat = rezultat.TrimStart('0');
                //ako si previse sklonila odnosno ako je bila 0 vrati ju
                if (rezultat.Equals(""))
                {
                    rezultat = "0";
                }
                //ako si previse sklonila decimalnom broju
                if (rezultat.First().Equals(','))
                {
                    rezultat = "0" + rezultat;
                }
                //ako je greska odmah je ispisi
                if (rezultat.Equals("-E-"))
                {
                    return rezultat;
                }
                //rezanje broja
                if (rezultat.Length > 12 && rezultat.Contains('-') && rezultat.Contains(','))
                {
                    rezultat = rezultat.Remove(12);
                }
                else if (rezultat.Length > 11 && !rezultat.Contains('-') && rezultat.Contains(','))
                {
                    rezultat = rezultat.Remove(11);
                }

               else if(!rezultat.Contains(','))
                {

                    if (rezultat.Length > 11 && rezultat.Contains('-') || (rezultat.Length > 10 && !rezultat.Contains('-')))
                    {
                        rezultat = "-E-";
                    }
                }
                return rezultat;


            }
        }
}

