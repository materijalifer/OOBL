﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        string Ekran = "0";
        string Memorija;
        double rezultat = 0;
        char prethodna_operacija;
        bool nakon_operacije = false;
        char LastPress;

        public void Press(char inPressedDigit)
        {
            switch(inPressedDigit)
            {

                case '0':
                case '1': 
                case '2':
                case '3': 
                case '4': 
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case ',': SetScreen(inPressedDigit);
                    LastPress = 'N';
                    break;
                case '+':
                    if (LastPress == 'N')
                    {
                        OperacijaZbrajanja();
                    }
                    else
                    {
                        prethodna_operacija = '+';
                    }
                    LastPress = 'A';
                    break;
                case '-':
                    if (LastPress == 'N')
                    {
                        OperacijaOduzimanja();
                    }
                    else
                    {
                        prethodna_operacija = '-';
                    }
                    LastPress = 'A';
                    break;
                case '*':
                    if (LastPress == 'N')
                    {
                        OperacijaMnozenja();
                    }
                    else
                    {
                        prethodna_operacija = '*';
                    }
                    LastPress = 'A';
                    break;
                case '/': 
                    if (LastPress == 'N')
                    {
                        OperacijaDjeljenja();
                    }
                    else
                    {
                        prethodna_operacija = '/';
                    }
                    LastPress = 'A';
                    break;
                case 'Q': OperacijaKvadriranja();
                    LastPress = 'N';
                    break;
                case 'R': OperacijaKorijenovanja();
                    LastPress = 'N';
                    break;
                case 'I': OperacijaInverz();
                    LastPress = 'N';
                    break;
                case '=': Izracunaj();
                    break;
                case 'S': Sinus();
                    LastPress = 'N';
                    break;
                case 'K': Kosinus();
                    LastPress = 'N';
                    break;
                case 'T': Tangens();
                    LastPress = 'N';
                    break;
                case 'O': Off();
                    break;
                case 'C': Clear();
                    break;
                case 'M': SetSign();
                    LastPress = 'N';
                    break;
                case 'P': SaveToMemory();
                    LastPress = 'N';
                    break;
                case 'G': GetFromMemory();
                    LastPress = 'N';
                    break;
                default: Ekran = "-E-";
                    break;
            }
        }

        private void SetScreen(char inPressedDigit)
        {
            if (nakon_operacije == true)
            {
                Ekran = "0";
                nakon_operacije = false;
            }
            char[] znakovi_na_ekranu = Ekran.ToArray();
            if (NumberGE10(Ekran) == true)
            {

            }
            else
            {
                if (znakovi_na_ekranu[0] == '0' && (inPressedDigit == ',' || znakovi_na_ekranu.Length > 1))
                {
                    Ekran += inPressedDigit.ToString();
                }
                else if (znakovi_na_ekranu[0] == '0')
                {
                    Ekran = inPressedDigit.ToString();
                }
                else
                {
                    Ekran += inPressedDigit.ToString();
                }
            }
        }
        private void SetSign()
        {
            if (Ekran[0] == '-')
            {
                Ekran = Ekran.TrimStart('-');
            }
            else
            {
                Ekran = '-' + Ekran;
            }
        }
        private bool NumberGE10(string number)
        {
            if (IsDecimal(number) == false)
            {
                int cjeli_broj_length;
                if (number[0] == '-')
                {
                    cjeli_broj_length = number.Length - 1;
                }
                else
                {
                    cjeli_broj_length = number.Length;
                }
                if (cjeli_broj_length >= 10)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                string[] number_array = number.Split(',');

                int prije_decimalnog;

                int poslje_decimalnog = number_array[1].Length;

                if (number_array[0][0] == '-')
                {
                    prije_decimalnog = number_array[0].Length - 1;
                }
                else
                {
                    prije_decimalnog = number_array[0].Length;
                }

                if (prije_decimalnog + poslje_decimalnog >= 10)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        private double StringToDouble(string s)
        {
            //char[] s_array = s.ToArray();
            //for (int i = 0; i < s_array.Length; i++)
            //{
            //    if (s_array[i] == ',')
            //    {
            //        s_array[i] = '.';
            //    }
            //}
            //s = new string(s_array);
            double s_double = double.Parse(s);
            return s_double;
        }
        private bool IsDecimal(double number)
        {
            if (number % 1 == 0)
            {
                return true;
            }
            else return false;
        }
        private bool IsDecimal(string number)
        {
            for (int i = 0; i < number.Length; i++)
            {
                if (number[i] == ',' || number[i] == '.')
                {
                    return true;
                }
            }
            return false;
        }
        private bool IsNegative(double number)
        {
            if (number < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void SaveToMemory()
        {
            Memorija = Ekran;
        }
        private void GetFromMemory()
        {
            Ekran = Memorija;
        }
        private void OperacijaZbrajanja()
        {
            if (rezultat == 0)
            {
                rezultat = StringToDouble(Ekran);
            }
            else
            {
                switch (prethodna_operacija)
                {
                    case '+':
                        rezultat += StringToDouble(Ekran);
                        break;
                    case '-':
                        rezultat -= StringToDouble(Ekran);
                        break;
                    case '*':
                        rezultat *= StringToDouble(Ekran);
                        break;
                    case '/':
                        if (Ekran == "0")
                        {
                            rezultat = 9999999999999;
                        }
                        else
                        {
                            rezultat /= StringToDouble(Ekran);
                        }
                        break;
                }
            }
            Ekran = rezultat.ToString();
            prethodna_operacija = '+';
            nakon_operacije = true;
        }
        private void OperacijaOduzimanja()
        {
            if (rezultat == 0)
            {
                rezultat = StringToDouble(Ekran);
            }
            else
            {
                switch (prethodna_operacija)
                {
                    case '+':
                        rezultat += StringToDouble(Ekran);
                        break;
                    case '-':
                        rezultat -= StringToDouble(Ekran);
                        break;
                    case '*':
                        rezultat *= StringToDouble(Ekran);
                        break;
                    case '/':
                        if (Ekran == "0")
                        {
                            rezultat = 9999999999999;
                        }
                        else
                        {
                            rezultat /= StringToDouble(Ekran);
                        }
                        break;
                }
            }
            Ekran = rezultat.ToString();
            prethodna_operacija = '-';
            nakon_operacije = true;

        }
        private void OperacijaMnozenja()
        {
            if (rezultat == 0)
            {
                rezultat = StringToDouble(Ekran);
            }
            else
            {
                switch (prethodna_operacija)
                {
                    case '+':
                        rezultat += StringToDouble(Ekran);
                        break;
                    case '-':
                        rezultat -= StringToDouble(Ekran);
                        break;
                    case '*':
                        rezultat *= StringToDouble(Ekran);
                        break;
                    case '/':
                        if (Ekran == "0")
                        {
                            rezultat = 9999999999999;
                        }
                        else
                        {
                            rezultat /= StringToDouble(Ekran);
                        }
                        break;
                }
            }
            Ekran = rezultat.ToString();
            prethodna_operacija = '*';
            nakon_operacije = true;
        }
        private void OperacijaDjeljenja()
        {
            if (rezultat == 0)
            {
                rezultat = StringToDouble(Ekran);
            }
            else
            {
                switch (prethodna_operacija)
                {
                    case '+':
                        rezultat += StringToDouble(Ekran);
                        break;
                    case '-':
                        rezultat -= StringToDouble(Ekran);
                        break;
                    case '*':
                        rezultat *= StringToDouble(Ekran);
                        break;
                    case '/':
                        if (Ekran == "0")
                        {
                            rezultat = 9999999999999;
                        }
                        else
                        {
                            rezultat /= StringToDouble(Ekran);
                        }
                        break;
                }
            }
            Ekran = rezultat.ToString();
            prethodna_operacija = '/';
            nakon_operacije = true;
        }
        private void OperacijaKvadriranja()
        {
            double kvadrat = Math.Pow(StringToDouble(Ekran), 2);
            if (kvadrat > Math.Abs(9999999999))
            {
                Ekran = "-E-";
            }
            else
            {
                Ekran = kvadrat.ToString();
            }
            //prethodna_operacija = 'Q';

        }
        private void OperacijaKorijenovanja()
        {
            if (StringToDouble(Ekran) < 0)
            {
                Ekran = "-E-";
            }
            else
            {
                double korijen = Math.Sqrt(StringToDouble(Ekran));
                Ekran = RoundNumber(korijen.ToString()).ToString(); 
            }
        }
        private void OperacijaInverz()
        {
            double inverz = StringToDouble(Ekran);
           
             if (inverz == 0)
             {
                Ekran="-E-";
             }
             else
             {
                inverz = 1 / inverz;
                Ekran = RoundNumber(inverz.ToString()).ToString(); ;
              }
        }
        private void Sinus()
        {
            double rez = Math.Sin(StringToDouble(Ekran));
            if (rez > Math.Abs(9999999999))
            {
                Ekran = "-E-";
            }
            else
            {
                if (IsDecimal(rez.ToString()) == true)
                {
                    Ekran = RoundNumber(rez.ToString()).ToString();
                }
                else
                {
                    Ekran = rez.ToString();
                }
            }
        }
        private void Kosinus()
        {
            double rez = Math.Cos(StringToDouble(Ekran));
            if (rez > Math.Abs(9999999999))
            {
                Ekran = "-E-";
            }
            else
            {
                if (IsDecimal(rez.ToString()) == true)
                {
                    Ekran = RoundNumber(rez.ToString()).ToString();
                }
                else
                {
                    Ekran = rez.ToString();
                }
            }
        }
        private void Tangens()
        {
            double rez = Math.Tan(StringToDouble(Ekran));
            if (rez > Math.Abs(9999999999))
            {
                Ekran = "-E-";
            }
            else
            {
                if (IsDecimal(rez.ToString()) == true)
                {
                    Ekran = RoundNumber(rez.ToString()).ToString();
                }
                else
                {
                    Ekran = rez.ToString();
                }
            }
        }
        private double RoundNumber(string number)
        {
            int prijedectocke;
            string[] number_array = number.Split(',');
            if (number[0] == '-')
            {
                prijedectocke=number_array[0].Length - 1;
            }
            else
            {
                prijedectocke=number_array[0].Length;
            }

            return (Math.Round(StringToDouble(number),10-prijedectocke));
        }
        private void Izracunaj()
        {
            switch (prethodna_operacija) {
                case '+':
                    rezultat += StringToDouble(Ekran);
                    break;
                case '-':
                    rezultat -= StringToDouble(Ekran);
                    break;
                case '*':
                    rezultat *= StringToDouble(Ekran);
                    break;
                case '/':
                    if (Ekran == "0")
                    {
                        rezultat = 9999999999999;
                    }
                    else
                    {
                        rezultat /= StringToDouble(Ekran);
                    }
                    break;
                case 'O':
                    rezultat = StringToDouble(Ekran);
                    break;
                default:
                    rezultat = StringToDouble(Ekran);
                    break;
            }

                Ekran = TooLarge(rezultat.ToString());
                nakon_operacije = false;
        }
        private void Off()
        {
            prethodna_operacija = 'O';
            Ekran = "0";
            Memorija = "";

        }
        private void Clear()
        {
            Ekran = "0";
        }
        private string TooLarge(string number)
        {
            if (StringToDouble(number) > Math.Abs(9999999999))
            {
                return "-E-";
            }
            else
            {
                return number;
            }
        }
        public string GetCurrentDisplayState()
        {
            return Ekran;
        }
    }
}
