﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private readonly List<Stock> _stocks;
        private readonly List<Index> _indices;
        private readonly List<Portfolio> _portfolios; 

        public StockExchange()
        {
            _stocks=new List<Stock>();
            _indices=new List<Index>();
            _portfolios=new List<Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if(StockExists(inStockName)) throw new StockExchangeException("Dionica već postoji!");
             _stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             var stock = GetStockByName(inStockName);
             _stocks.Remove(stock);
             DelistInObservers(stock);
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.Exists(stock => stock.Name.ToUpper() == inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;  
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             var stock = GetStockByName(inStockName);
             stock.AddPrice(inIimeStamp, inStockValue);
             UpdateInObservers(stock);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return GetStockByName(inStockName).GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return GetStockByName(inStockName).GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return GetStockByName(inStockName).GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName)) throw new StockExchangeException("Index već postoji!");
             _indices.Add(new Index(inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IsStockPartOfIndex(inIndexName, inStockName)) throw new StockExchangeException("Dionica već postoji u indexu!");
             GetIndexByName(inIndexName).AddStock(GetStockByName(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if(!IsStockPartOfIndex(inIndexName,inStockName)) throw new StockExchangeException("Dionica ne postoji u indexu!");
             GetIndexByName(inIndexName).RemoveStock(GetStockByName(inStockName));
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndexByName(inIndexName).ContainsStock(GetStockByName(inStockName));
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return GetIndexByName(inIndexName).GetValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.Exists(i => i.Name.ToUpper() == inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return GetIndexByName(inIndexName).StockCount;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio već postoji!");
             _portfolios.Add(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             GetPortfolioByID(inPortfolioID).AddStock(GetStockByName(inStockName), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName)) throw new StockExchangeException("Dionica ne postoji u portfoliju!");
             GetPortfolioByID(inPortfolioID).RemoveStock(GetStockByName(inStockName), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName)) throw new StockExchangeException("Dionica ne postoji u portfoliju!");
             GetPortfolioByID(inPortfolioID).RemoveStock(GetStockByName(inStockName));
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return GetPortfolioByID(inPortfolioID).StockCount;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.Exists(p => p.ID == inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolioByID(inPortfolioID).ContainsStock(GetStockByName(inStockName));
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolioByID(inPortfolioID).GetNumberOfShares(GetStockByName(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return GetPortfolioByID(inPortfolioID).GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return GetPortfolioByID(inPortfolioID).GetPercentChange(Year, Month);
         }

         private void UpdateInObservers(Stock inStock)
         {
             foreach (Index index in _indices)
                 if (index.ContainsStock(inStock))
                     index.UpdateStock(inStock);
             foreach (Portfolio portfolio in _portfolios)
                 if(portfolio.ContainsStock(inStock))
                    portfolio.UpdateStock(inStock);
         }

         private void DelistInObservers(Stock inStock)
         {
             foreach (Index index in _indices)
                 if (index.ContainsStock(inStock))
                    index.DelistStock(inStock);
             foreach (Portfolio portfolio in _portfolios)
                 if (portfolio.ContainsStock(inStock))
                     portfolio.DelistStock(inStock);
         }

         private Stock GetStockByName(string inStockName)
         {
             if (!StockExists(inStockName)) throw new StockExchangeException("Dionica s imenom " + inStockName + " nije pronađena.");
             return _stocks.Find(s => s.Name.ToUpper() == inStockName.ToUpper());
         }

         private Index GetIndexByName(string inIndexName)
         {
             if (!IndexExists(inIndexName)) throw new StockExchangeException("Index s imenom " + inIndexName + " nije pronađen.");
             return _indices.Find(i => i.Name.ToUpper() == inIndexName.ToUpper());
         }

         private Portfolio GetPortfolioByID(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio s id-om " + inPortfolioID + " nije pronađen.");
             return _portfolios.Find(p => p.ID == inPortfolioID);
         }
    }

    public class Stock
    {
        string _name;
        private long _shares;
        private long _remainingShares;
        private readonly SortedList<DateTime, Decimal> _prices;

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Cijena dionice ne može biti negativna ili 0");
            _name = inStockName;
            _shares = inNumberOfShares;
            _remainingShares = inNumberOfShares;
            _prices = new SortedList<DateTime, decimal> { { inTimeStamp, inInitialPrice } };
        }

        public Stock()
        {
            _name = null;
            _shares = 0;
            _remainingShares = 0;
            _prices = new SortedList<DateTime, decimal>();
        }

        public void AddPrice(DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
                throw new StockExchangeException("Cijena dionice ne može biti negativna ili 0");
            _prices.Add(inIimeStamp, inStockValue);
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp >= _prices.Keys.Last())
                return _prices.Values.Last();
            foreach (DateTime key in _prices.Keys)
                if (inTimeStamp < key)
                    continue;
                else return _prices[key];
            throw new StockExchangeException("Nije pronađena cijena za datum: " + inTimeStamp.ToString());
        }

        public decimal GetInitialPrice()
        {
            return _prices.Values.First();
        }

        public decimal GetLastPrice()
        {
            return this._prices.Values.Last();
        }

        public void TakeShares(long numberOfShares)
        {
            if (numberOfShares > _remainingShares) throw new StockExchangeException("Nedovoljno dionica!");
            else _remainingShares -= numberOfShares;
        }

        public void ReturnShares(long numberOfShares)
        {
            if (_remainingShares + numberOfShares > _shares) throw new StockExchangeException("Previse dionica!");
            else _remainingShares += numberOfShares;
        }

        public string Name
        {
            get { return _name; }
            set { this._name = value; }
        }

        public long Shares
        {
            get { return _shares; }
            set { _shares = value; }
        }
    }

    public class Index
    {
        private string _name;
        private readonly List<Stock> _stocks;
        private readonly IndexTypes _type;

        public Index(string name, IndexTypes type)
        {
            Name = name;
            _type = type;
            _stocks = new List<Stock>();
        }

        public void AddStock(Stock inStock)
        {
            _stocks.Add(inStock);
        }

        public void RemoveStock(Stock stock)
        {
            _stocks.Remove(stock);
        }

        public bool ContainsStock(Stock stock)
        {
            return _stocks.Contains(stock);
        }

        public decimal GetValue(DateTime inTimeStamp)
        {
            return _type == IndexTypes.AVERAGE ? AvarageValue(inTimeStamp) : WeightedValue(inTimeStamp);
        }

        public void UpdateStock(Stock stock)
        {
            _stocks.Remove(_stocks.Find(s => s.Name == stock.Name));
            _stocks.Add(stock);
        }

        public void DelistStock(Stock stock)
        {
            _stocks.Remove(_stocks.Find(s => s.Name == stock.Name));
        }

        private decimal AvarageValue(DateTime inTimeStamp)
        {
            if (_stocks.Count == 0) return 0;
            var totalValue = _stocks.Sum(stock => stock.GetPrice(inTimeStamp));
            return Math.Round(totalValue / _stocks.Count, 3);
        }

        private decimal WeightedValue(DateTime inTimeStamp)
        {
            var totalShares = GetTotalWeight(inTimeStamp);
            var totalValue = _stocks.Sum(stock => (decimal)(stock.Shares * Math.Pow((double)stock.GetPrice(inTimeStamp), 2) / (double)totalShares));
            return Math.Round(totalValue, 3);
        }

        private decimal GetTotalWeight(DateTime inTimeStamp)
        {
            decimal totalWeight = 0;
            foreach (Stock stock in _stocks)
                totalWeight += stock.Shares * stock.GetPrice(inTimeStamp);
            return totalWeight;
        }

        public int StockCount
        {
            get { return _stocks.Count; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
    }

    public class Portfolio
    {
        private string _id;
        private readonly Dictionary<Stock, int> _stocks;

        public Portfolio(string inPortfolioID)
        {
            _id = inPortfolioID;
            _stocks = new Dictionary<Stock, int>();
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if(numberOfShares<=0) throw new StockExchangeException("Ne može se dodati 0 ili manje dionica!");
            if (_stocks.ContainsKey(stock))
                _stocks[stock] += numberOfShares;
            else
                _stocks.Add(stock, numberOfShares);
            stock.TakeShares(numberOfShares);
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            if (!_stocks.ContainsKey(stock)) throw new StockExchangeException("Nema navedene dionice");
            if (numberOfShares > _stocks[stock]) throw new StockExchangeException("Nema dovoljno dionica za oduzeti");
            _stocks[stock] -= numberOfShares;
            if (_stocks[stock] == 0) _stocks.Remove(stock);
            stock.ReturnShares(numberOfShares);
        }

        public void RemoveStock(Stock stock)
        {
            if (!_stocks.ContainsKey(stock)) throw new StockExchangeException("Nema navedene dionice");
            stock.ReturnShares(_stocks[stock]);
            _stocks.Remove(stock);
        }

        public bool ContainsStock(Stock stock)
        {
            return _stocks.Keys.Contains(stock);
        }

        public int GetNumberOfShares(Stock stock)
        {
            if (!ContainsStock(stock)) return 0;
            return _stocks[stock];
        }

        public decimal GetValue(DateTime timeStamp)
        {
            decimal totalValue = 0;
            foreach (Stock stock in _stocks.Keys)
                totalValue += stock.GetPrice(timeStamp) * _stocks[stock];
            return Math.Round(totalValue, 3);
        }

        public decimal GetPercentChange(int year, int month)
        {
            var firstDay = new DateTime(year, month, 1, 0, 0, 0, 0);
            var lastDay = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
            if (GetValue(firstDay) == 0 && GetValue(lastDay) == 0) return 0;
            if (GetValue(firstDay) == 0) throw new StockExchangeException("Dijeljenje s 0!");

            return Math.Round((GetValue(lastDay) / GetValue(firstDay) - 1) * 100, 3);
        }

        public void UpdateStock(Stock stock)
        {
            var shares = _stocks[stock];
            _stocks.Remove(_stocks.Keys.Single(s => s.Name.ToUpper() == stock.Name.ToUpper()));
            _stocks.Add(stock, shares);
        }

        public void DelistStock(Stock stock)
        {
            _stocks.Remove(_stocks.Keys.Single(s => s.Name.ToUpper() == stock.Name.ToUpper()));
        }

        public int StockCount
        {
            get { return _stocks.Count; }
        }

        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }
    }
}
