﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{


    public class Factory
    {
        public static ICalculator CreateCalculator()
        {

            return new Kalkulator();
        }
    }



    public class Kalkulator : ICalculator
    {

        private String currentDisplayState; // display
        private CalcState currentState; // state in which the calculator is in
        private int maxNums = 10; // maximum number of allowed digits on the screen
        private string memory; // memory. User can store a single number in it
        public BinaryOperation pendingOperation; // binary operation which will be done in the future (we need the second parameter)
        public double tempResult; // temporary result

        private const string ERROR_SIGN = "-E-";
        private const string DECIMAL_SIGN = ",";
        private const string RESET_DISPLAY_STATE = "0";


        public Kalkulator()
        {
            this.currentDisplayState = RESET_DISPLAY_STATE;
            this.currentState = StartState.getInstance(); // go to start state
            this.memory = String.Empty;
            this.tempResult = 0;
        }


        public void Press(char inPressedDigit)
        {

            if (Char.IsDigit(inPressedDigit))
            {
                currentState.enterDigit(this, inPressedDigit);

            }
            else if (Char.IsLetter(inPressedDigit))
            {
                switch (inPressedDigit)
                {
                    case 'M':
                        this.enterSignChange(new ChangeSign());
                        break;
                    case 'S':
                        currentState.enterUnaryOperator(this, new Sine());
                        break;
                    case 'K':
                        currentState.enterUnaryOperator(this, new Cosine());
                        break;
                    case 'T':
                        currentState.enterUnaryOperator(this, new Tangent());
                        break;
                    case 'Q':
                        currentState.enterUnaryOperator(this, new Square());
                        break;
                    case 'R':
                        currentState.enterUnaryOperator(this, new Root());
                        break;
                    case 'I':
                        currentState.enterUnaryOperator(this, new Inverse());
                        break;
                    case 'P':
                        putIntoMemory(this.currentDisplayState);
                        break;
                    case 'G':
                        string memory = getFromMemory();
                        if (memory != String.Empty)
                        {
                            this.currentDisplayState = getFromMemory();

                            // getting a number from memory must be combined with state change, otherwise
                            // it will only be pasted on the screen and it won't be an operand, resulting in weird situation
                            if(memory.Contains(DECIMAL_SIGN))
                            {
                                this.currentState = CommaState.getInstance();
                            }
                            else
                            {
                                this.currentState = AccumulationState.getInstance();
                            }
                        }

                        break;
                    case 'C':
                        clearScreen();
                        break;
                    case 'O':
                        resetCalc();                        
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        currentState.enterBinaryOperator(this, new Addition());
                        break;
                    case '-':
                        currentState.enterBinaryOperator(this, new Subtraction());
                        break;
                    case '*':
                        currentState.enterBinaryOperator(this, new Multiplication());
                        break;
                    case '/':
                        currentState.enterBinaryOperator(this, new Division());
                        break;
                    case ',':
                        currentState.enterComma(this);
                        break;
                    case '=':
                        currentState.enterEquals(this);
                        break;
                    default:
                        break;
                }
            }

            
        }


        public void appendCurrentDisplayState(string addon)
        {
            this.currentDisplayState += addon;
        }

        public void setCurrentDisplayState(string display)
        {
            this.currentDisplayState = display;
        }

        public string GetCurrentDisplayState()
        {
            return this.currentDisplayState;
        }

        public void setCurrentState(CalcState newState)
        {
            this.currentState = newState;
        }

        public CalcState getCurrentState()
        {
            return this.currentState;
        }

        public void setPendingOperation(BinaryOperation pendingOp)
        {
            this.pendingOperation = pendingOp;
        }

        public BinaryOperation getPendingOperation()
        {
            return this.pendingOperation;
        }

        public void setTempResult(double tempResult)
        {
            this.tempResult = tempResult;
        }

        public double getTempResult()
        {
            return this.tempResult;
        }

        public void putIntoMemory(string data)
        {
            this.memory = data;
        }

        public string getFromMemory()
        {
            return this.memory;
        }

        public void clearMemory()
        {
            this.memory = String.Empty;
        }


        /// <summary>
        /// Just clears the screen.
        /// </summary>
        public void clearScreen()
        {
            this.currentDisplayState = RESET_DISPLAY_STATE;
        }

        /// <summary>
        /// Resets the calculator. This erases the screen, cleans the memory and resets calculator state to 
        /// the start state. It also removes any pending operations and temporary results.
        /// </summary>
        public void resetCalc()
        {
            this.clearMemory();
            this.clearScreen();
            this.pendingOperation = null;
            this.tempResult = 0;
            this.currentDisplayState = RESET_DISPLAY_STATE;
            this.currentState = StartState.getInstance();
        }

        public void completeCalculation()
        {
            this.clearMemory();
            this.pendingOperation = null;
            this.tempResult = 0;
            this.currentState = StartState.getInstance();
        }


        /// <summary>
        /// Method which makes sure that the given number is not too big to fit on the screen. If it is too big,
        /// it will be rounded to fit. If the integral part of the number is too big, an error will be signalled.
        /// </summary>
        /// <param name="result">Number to check</param>
        /// <returns></returns>
        public double checkLength(double result)
        {

            string resultString = result.ToString();
            double shortened;

            // count digits (we need this to avoid counting the comma and sign, if any).
            int count = resultString.Count(x => Char.IsDigit(x));
            int space = this.maxNums - count; // how much spaces do we have?

            if (resultString.Contains(DECIMAL_SIGN))
            {
                int indexComma = resultString.IndexOf(DECIMAL_SIGN);

                int integralPartSize = indexComma;
                if (resultString.Contains('-'))
                {
                    integralPartSize = indexComma - 1;
                }
                
                //if the integral part of the number is bigger than the screen, signal an error
                if (integralPartSize > this.maxNums)
                {
                    throw new NumberTooBigException();
                }

                // the maximum size of allowed decimals at the moment
                int validDecimalCount = this.maxNums - integralPartSize;

                // if the number is too big, round it with precision defined by the number of maximum allowed
                // decimals at the moment
                if (space < 0)
                {
                    shortened = Math.Round(result, validDecimalCount);
                }
                else
                {
                    shortened = result;
                }
            }
            else // the number does not contain decimal comma
            {
                // if the number is too big,signal an error
                if (space < 0)
                {
                    throw new NumberTooBigException();
                }
                else
                {
                    shortened = result;
                }
            }

            return shortened;


            
        }

        /// <summary>
        /// This method removes any unnecessary trailing zeros (if any)
        /// </summary>
        /// <param name="shortened">Number to normalize.</param>
        /// <returns></returns>
        public string tryToNormalize(double shortened)
        {
            int shortenedInt = (int)shortened;

            if ((shortened % 1) == 0) // check if all digits after decimal comma are 0
            {
                // get rid of a decimal form
                return shortenedInt.ToString();
            }
            else
            {
                return shortened.ToString("F10").TrimEnd('0');
            }
        }


        public void handleUnaryOperationCalc(UnaryOperation unaryOp)
        {
            // unary operation is calculated as soon as it is entered
            // its parameter is the one currently shown on the screen
            string display = this.GetCurrentDisplayState();
            double param = Double.Parse(display);
            double result = unaryOp.calculate(param);

            // check for weird results and signal error if they occur
            if (Double.IsInfinity(result) || Double.IsNaN(result))
            {
               this.handleErrorCalc();
               this.setCurrentState(ErrorState.getInstance());
            }
            else
            {
                try
                {
                    // check if the number is too big to fit on the screen
                    double shortened = this.checkLength(result);

                    // important! If there's no pending operation (binary one), the result of unary operation
                    // will be stored. Otherwise, it will only be displayed on the screen.
                    if (this.pendingOperation == null)
                    {
                        this.tempResult = shortened;
                    }

                    // get rid of the trailing zeros (if any).
                    string normalized = this.tryToNormalize(shortened);
                    this.setCurrentDisplayState(normalized);
                }
                catch (NumberTooBigException ex)
                {
                    this.handleErrorCalc();
                    this.setCurrentState(ErrorState.getInstance());
                }
            }
        }

        public void handleBinaryOperationCalc(BinaryOperation binaryOp)
        {
            /* If there's a pending operation stored (always a binary one, unary one is calculated immediately),
             * calculate the result using stored temporary result as the first parameter, and the currently displayed
             * number as the second one. If there's no pending operation stored, just set the currently displayed
             * number as a temporary result. Make sure to save the entered operation as the pending one.*/
            if (this.pendingOperation == null)
            {
                this.tempResult = Double.Parse(this.GetCurrentDisplayState());
            }
            else
            {
                string display = this.GetCurrentDisplayState();
                double param1 = this.tempResult;
                double param2 = Double.Parse(display);
                this.tempResult = this.pendingOperation.calculate(param1, param2);
            }

            // store the entered operation as the pending one
            this.pendingOperation = binaryOp;

            try
            {
                // make sure the result fits the screen and get rid of unneeded trailing zeros (if any)
                double shortened = this.checkLength(this.tempResult);
                this.tempResult = shortened;
                this.setCurrentDisplayState(this.tryToNormalize(shortened));
            }
            catch (NumberTooBigException ex)
            {
                this.handleErrorCalc();
                this.setCurrentState(ErrorState.getInstance());
            }
        }

        /// <summary>
        /// Displays the error symbol on the display.
        /// </summary>
        public void handleErrorCalc()
        {
            this.currentDisplayState = ERROR_SIGN;
        }

        /// <summary>
        /// Appends the decimal sign (comma in this case) on the display.
        /// </summary>
        public void handleCommaCalc()
        {
            this.appendCurrentDisplayState(DECIMAL_SIGN);
        }

        /* Helper function which takes care of not allowing multiple zeros to be stacked and to replace the zero
         * with a non-zero number when needed. */
        public void handleAccumulationCalc(char digit)
        {
            if (this.GetCurrentDisplayState() == "0")
            {
                this.setCurrentDisplayState(digit.ToString());
            }
            else
            {
                this.appendCurrentDisplayState(digit.ToString());
            }
        }

        /* Change the sign of currently displayed number. Again, make sure the result fits the screen and get
         * rid of the trailing zeros (if any).*/
        public void enterSignChange(ChangeSign changeSign)
        {
            try
            {
                double result = changeSign.calculate(Double.Parse(this.GetCurrentDisplayState()));
                result = this.checkLength(result);
                string resultString = this.tryToNormalize(result);
                this.setCurrentDisplayState(resultString);
            }
            catch (NumberTooBigException ex)
            {
                this.handleErrorCalc();
                this.setCurrentState(ErrorState.getInstance());
            }
        }

    }

    class NumberTooBigException : Exception, ISerializable
    {
        public NumberTooBigException()
        {
            // TODO
        }
    }


    /// <summary>
    /// Abstract model of a calculator state.
    /// </summary>
    public abstract class CalcState
    {
        public abstract void enterDigit(Kalkulator context, char digit);
        public abstract void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp);
        public abstract void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp);
        public abstract void enterEquals(Kalkulator context);
        public abstract void enterComma(Kalkulator context);
        public abstract void enterClear(Kalkulator context);
    }


    /// <summary>
    /// State which models continuous concatenation of new digits. The state is not changed
    /// until operators are entered.
    /// </summary>
    public class AccumulationState : CalcState
    {

        private static AccumulationState instance = null;

        private AccumulationState() { }

        public static AccumulationState getInstance()
        {
            if (instance == null)
            {
                instance = new AccumulationState();
            }
            return instance;
        }


        /* Just append the entered digit and stay in the same state.*/
        public override void enterDigit(Kalkulator context, char digit)
        {
            context.handleAccumulationCalc(digit);
        }

        /* Change state to state which handles binary operations.*/
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            context.handleBinaryOperationCalc(binaryOp);
            context.setCurrentState(BinaryComputationState.getInstance());
        }

        /* Change state to state which handles unary operations.*/
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            context.handleUnaryOperationCalc(unaryOp);
            context.setCurrentState(UnaryComputationState.getInstance());
        }

        /* Equal sign is entered, calculation needs to be done. 
         * If there's a pending operation stored (always a binary one, unary one is calculated immediately),
         * calculate the result using stored temporary result as the first parameter, and the currently displayed
         * number as the second one. If there's no pending operation stored, just set the currently displayed
         * number as a temporary result.*/
        public override void enterEquals(Kalkulator context)
        {
            if (context.pendingOperation != null)
            {
                double param1 = context.tempResult;
                double param2 = Double.Parse(context.GetCurrentDisplayState());
                double result = context.pendingOperation.calculate(param1, param2);
                context.tempResult = result;

                if (Double.IsInfinity(result) || Double.IsNaN(result))
                {
                    context.handleErrorCalc();
                    context.setCurrentState(ErrorState.getInstance());
                    return;
                }
            }
            else
            {
                context.tempResult = Double.Parse(context.GetCurrentDisplayState());
            }

            // make sure the result fits the screen and get rid of unneeded trailing zeros (if any)
            try
            {
                context.tempResult = context.checkLength(context.tempResult);
                context.setCurrentDisplayState(context.tryToNormalize(context.tempResult));
                context.completeCalculation();
            }
            catch (NumberTooBigException ex)
            {
                context.handleErrorCalc();
                context.setCurrentState(ErrorState.getInstance());
            }
        }

        /* The decimal comma is entered, switch to a state which handles it.*/
        public override void enterComma(Kalkulator context)
        {
            context.handleCommaCalc();
            context.setCurrentState(CommaState.getInstance());
        }

        /* Clears the screen. */
        public override void enterClear(Kalkulator context)
        {
            context.clearScreen();
        }

    }


    /// <summary>
    /// Class which models the state used for handling binary operations.
    /// </summary>
    public class BinaryComputationState : CalcState
    {

        private static BinaryComputationState instance = null;

        private BinaryComputationState() { }

        public static BinaryComputationState getInstance()
        {
            if (instance == null)
            {
                instance = new BinaryComputationState();
            }
            return instance;
        }

        /* This means the next operator needs to be entered, clear the first one and go 
         * to the state which handles continuous digit contatenation.*/
        public override void enterDigit(Kalkulator context, char digit)
        {
            context.clearScreen();
            context.handleAccumulationCalc(digit);
            context.setCurrentState(AccumulationState.getInstance());
        }

        /* Considering the fact we are already in the state which handles the binary operations,
         * just store the entered operation as the pending one. This means only the last input will
         * be used in the future.*/
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            context.pendingOperation = binaryOp;
        }

        /* Change state to state which handles unary operations.*/
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            context.handleUnaryOperationCalc(unaryOp);
            context.setCurrentState(UnaryComputationState.getInstance());
        }

        /* The equal sign is entered, calculation needs to be made. As we are in the binary
         * operations state, this situation describes the shortened form of binary operation.
         * e.g. 2 += 4. Both parameters are taken from the temporary result.*/
        public override void enterEquals(Kalkulator context)
        {
            double param = context.tempResult;
            context.tempResult = context.pendingOperation.calculate(param, param);

            // make sure the result fits the screen and get rid of unneeded trailing zeros (if any)
            try
            {
                context.tempResult = context.checkLength(context.tempResult);
                context.setCurrentDisplayState(context.tryToNormalize(context.tempResult));
                context.completeCalculation();
            }
            catch (NumberTooBigException ex)
            {
                context.handleErrorCalc();
                context.setCurrentState(ErrorState.getInstance());
            }
        }

        /* No decimal commas are allowed after the binary operation. Stay in same state.*/
        public override void enterComma(Kalkulator context)
        {
            // do nothing
        }

        /* Clears the screen. */
        public override void enterClear(Kalkulator context)
        {
            context.clearScreen();
        }
    }

    /// <summary>
    /// Class which models the state used for handling decimal comma. Quite similar to Accumulation state.
    /// </summary>
    public class CommaState : CalcState
    {

        private static CommaState instance = null;

        private CommaState() { }

        public static CommaState getInstance()
        {
            if (instance == null)
            {
                instance = new CommaState();
            }
            return instance;
        }


        /* Just append the entered digit. We don't change state to Accumulation state because we don't want to
         * enable entering multiple decimal commas in a number. */
        public override void enterDigit(Kalkulator context, char digit)
        {
            context.appendCurrentDisplayState(digit.ToString());
        }

        /* Change state to state which handles binary operations.*/
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            context.handleBinaryOperationCalc(binaryOp);
            context.setCurrentState(BinaryComputationState.getInstance());
        }

        /* Change state to state which handles unary operations.*/
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            context.handleUnaryOperationCalc(unaryOp);
            context.setCurrentState(UnaryComputationState.getInstance());
        }

        /* Equal sign is entered, calculation needs to be done. 
         * If there's a pending operation stored (always a binary one, unary one is calculated immediately),
         * calculate the result using stored temporary result as the first parameter, and the currently displayed
         * number as the second one. If there's no pending operation stored, just set the currently displayed
         * number as a temporary result.*/
        public override void enterEquals(Kalkulator context)
        {
            if (context.pendingOperation != null)
            {
                double param1 = context.tempResult;
                double param2 = Double.Parse(context.GetCurrentDisplayState());
                context.tempResult = context.pendingOperation.calculate(param1, param2);
            }
            else
            {
                context.tempResult = Double.Parse(context.GetCurrentDisplayState());
            }

            // make sure the result fits the screen and get rid of unneeded trailing zeros (if any)
            try
            {
                context.tempResult = context.checkLength(context.tempResult);
                context.setCurrentDisplayState(context.tryToNormalize(context.tempResult));
                context.completeCalculation();
            }
            catch (NumberTooBigException ex)
            {
                context.handleErrorCalc();
                context.setCurrentState(ErrorState.getInstance());
            }
        }

        /* Multiple decimal commas are not allowed. */
        public override void enterComma(Kalkulator context)
        {
            // do nothing
        }

        /* Clears the screen. */
        public override void enterClear(Kalkulator context)
        {
            context.clearScreen();
        }
    }

    /// <summary>
    /// The state which models the erroneous situation.
    /// </summary>
    public class ErrorState : CalcState
    {

        private static ErrorState instance = null;

        private ErrorState() { }

        public static ErrorState getInstance()
        {
            if (instance == null)
            {
                instance = new ErrorState();
            }
            return instance;
        }

        /* User can't do anything in this state. He can only press RESET (O) or CLEAR (C) button
         * to continue using the calculator.
         */

        public override void enterDigit(Kalkulator context, char digit)
        {
            // do nothing
        }
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            // do nothing
        }
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            // do nothing
        }
        public override void enterEquals(Kalkulator context)
        {
            // do nothing
        }
        public override void enterComma(Kalkulator context)
        {
            // do nothing
        }

        /* Clears the screen BUT also changes the state */
        public override void enterClear(Kalkulator context)
        {
            context.resetCalc();
        }
    }

    /// <summary>
    /// State which models the start state of the calculator.
    /// </summary>
    public class StartState : CalcState
    {

        private static StartState instance = null;

        private StartState() { }

        public static StartState getInstance()
        {
            if (instance == null)
            {
                instance = new StartState();
            }
            return instance;
        }

        /* Change state to state which handles continuous concatenation of digits.*/
        public override void enterDigit(Kalkulator context, char digit)
        {
            context.handleAccumulationCalc(digit);
            context.setCurrentState(AccumulationState.getInstance());
        }

        /* Change state to state which handles binary operations.*/
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            context.handleBinaryOperationCalc(binaryOp);
            context.setCurrentState(BinaryComputationState.getInstance());
        }

        /* Change state to state which handles unary operations.*/
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            context.handleUnaryOperationCalc(unaryOp);
            context.setCurrentState(UnaryComputationState.getInstance());
        }

        /* Equals has no effect in start state. */
        public override void enterEquals(Kalkulator context)
        {
            // do nothing
        }

        /* Change state to state which handles decimal comma.*/
        public override void enterComma(Kalkulator context)
        {
            context.handleCommaCalc();
            context.setCurrentState(CommaState.getInstance());
        }

        /* Clears the screen. */
        public override void enterClear(Kalkulator context)
        {
            context.clearScreen();
        }

    }

    /// <summary>
    /// Class which models the state used for handling unary operations.
    /// </summary>
    public class UnaryComputationState : CalcState
    {

        private static UnaryComputationState instance = null;

        private UnaryComputationState() { }

        public static UnaryComputationState getInstance()
        {
            if (instance == null)
            {
                instance = new UnaryComputationState();
            }
            return instance;
        }

        /* Digit can be entered after the unary operation, but the screen will be cleared and the result will
         * be ignored. */
        public override void enterDigit(Kalkulator context, char digit)
        {
            context.clearScreen();
            context.handleAccumulationCalc(digit);
            context.setCurrentState(AccumulationState.getInstance());
        }

        /* Change state to state which handles binary operations.*/
        public override void enterBinaryOperator(Kalkulator context, BinaryOperation binaryOp)
        {
            context.handleBinaryOperationCalc(binaryOp);
            context.setCurrentState(BinaryComputationState.getInstance());
        }

        /* Handle newly entered unary operation. */
        public override void enterUnaryOperator(Kalkulator context, UnaryOperation unaryOp)
        {
            context.handleUnaryOperationCalc(unaryOp);
        }

        /* Equal sign is entered, calculation needs to be done. 
         * If there's a pending operation stored (always a binary one, unary one is calculated immediately),
         * calculate the result using stored temporary result as the first parameter, and the currently displayed
         * number as the second one. If there's no pending operation stored, just set the currently displayed
         * number as a temporary result.*/
        public override void enterEquals(Kalkulator context)
        {
            // just display temporary result (which is now final, we don't need to wait for the other operand)
            if (context.pendingOperation != null)
            {
                double param1 = context.tempResult;
                double param2 = Double.Parse(context.GetCurrentDisplayState());
                context.tempResult = context.pendingOperation.calculate(param1, param2);
            }
            try
            {
                context.tempResult = context.checkLength(context.tempResult);
                context.setCurrentDisplayState(context.tryToNormalize(context.tempResult));
                context.completeCalculation();
            }
            catch (NumberTooBigException ex)
            {
                context.handleErrorCalc();
                context.setCurrentState(ErrorState.getInstance());
            }
        }

        /* Decimal comma can't be entered after the unary operation. */
        public override void enterComma(Kalkulator context)
        {
            context.clearScreen();
            context.handleCommaCalc();
            context.setCurrentState(CommaState.getInstance());
        }

        /* Clears the screen. */
        public override void enterClear(Kalkulator context)
        {
            context.clearScreen();
        }


    }

    public interface BinaryOperation
    {
        double calculate(double param1, double param2);
    }

    public class Addition : BinaryOperation
    {
        public double calculate(double param1, double param2)
        {
            return param1 + param2;
        }
    }

    public class Division : BinaryOperation
    {
        public double calculate(double param1, double param2)
        {
            return param1 / param2;
        }
    }

    public class Multiplication : BinaryOperation
    {
        public double calculate(double param1, double param2)
        {
            return param1 * param2;
        }
    }

    public class Subtraction : BinaryOperation
    {
        public double calculate(double param1, double param2)
        {
            return param1 - param2;
        }
    }

    public interface UnaryOperation
    {
        double calculate(double param);
    }

    public class ChangeSign : UnaryOperation
    {
        public double calculate(double param)
        {
            return -param;
        }
    }

    public class Cosine : UnaryOperation
    {
        public double calculate(double param)
        {
            return Math.Cos(param);
        }
    }

    public class Inverse : UnaryOperation
    {
        public double calculate(double param)
        {
            return 1 / param;
        }
    }

    public class Root : UnaryOperation
    {
        public double calculate(double param)
        {
            return Math.Sqrt(param);
        }
    }

    public class Sine : UnaryOperation
    {
        public double calculate(double param)
        {
            return Math.Sin(param);
        }
    }

    public class Square : UnaryOperation
    {
        public double calculate(double param)
        {
            return Math.Pow(param, 2);
        }
    }

    public class Tangent : UnaryOperation
    {
        public double calculate(double param)
        {
            return Math.Tan(param);
        }
    }




}