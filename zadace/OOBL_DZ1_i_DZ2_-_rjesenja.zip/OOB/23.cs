﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private CalculatorState calState = new CalculatorState();

        public void Press(char inPressedDigit)
        {
            calState.setCalculatorState(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return calState.getCalculatorState();
        }
    }

    public class CalculatorState
    {
        private string state = "0";
        private string operation = "0";
        private double result = 0;
        private double oper1 = 0;
        private double oper2 = 0;
        private string memory = "0";
        private Boolean binOp = false;
        private Boolean op2set = false;
        private Boolean numbers = false;
        private string inPressed;
        private Boolean reset = false;
        private Boolean reset2 = false;
 

        public void setCalculatorState(char inPressedDigit)
        {
            this.inPressed = inPressedDigit.ToString();
            if (reset2 == true) { this.Reset(); reset2 = false; }
            if (state.Equals("-E-") & !inPressed.Equals("O")) return;

            if (inPressed.Equals("0") | inPressed.Equals("1") |
                inPressed.Equals("2") | inPressed.Equals("3") |
                inPressed.Equals("4") | inPressed.Equals("5") |
                inPressed.Equals("6") | inPressed.Equals("7") |
                inPressed.Equals("8") | inPressed.Equals("9") |
                inPressed.Equals(",") )
            {
                numberInput();
            }
            else if (inPressed.Equals("+") | inPressed.Equals("-") |
                     inPressed.Equals("*") | inPressed.Equals("/"))
            {
                if (reset == true) { state = "-E-"; reset = false; reset2 = true; return; }
                binarnyOperationInput();
            }
            else if (inPressed.Equals("="))
            {
                if (reset == true) { state = "-E-"; reset = false; reset2 = true; return; }
                this.Equal();
            }
            else if (inPressed.Equals("M") | inPressed.Equals("S") |
                     inPressed.Equals("K") | inPressed.Equals("T") |
                     inPressed.Equals("Q") | inPressed.Equals("R") |
                     inPressed.Equals("I") | inPressed.Equals("P") |
                     inPressed.Equals("G") | inPressed.Equals("C") |
                     inPressed.Equals("O") )
            {
                unaryOperatorInput();
            }
            else state = "-E-";         

        }

        public void numberInput()
        {
            //if (!this.checkLenght()) { state = "-E-"; this.reset2 = true; return; }
            if (state.Contains(",") & inPressed.Equals(",")) return;
            binOp = false;
            if (numbers) { state += inPressed; return; }
            if (!this.operation.Equals("0")) { state = "0"; numbers = true; } //ako je operator postavljen onda novi state = 0
            if (this.state.Equals("0")) state = inPressed;
            else state += inPressed;
        }

        public void binarnyOperationInput()
        {

            if (this.operation.Equals("0"))
            {
                this.setOper1(); //ako na pocetku nema binarne operacije stavi stanje kao oper1
                this.oper2 = this.oper1; //i stavi ga kao oper2 u slučaju =
                op2set = true;
                binOp = true;
                setOperation(inPressed); return; //postavi operaciju
            }
            if (binOp) { setOperation(inPressed); return; }
            this.setOper2();
            if (operation.Equals("+")) Plus();
            else if (operation.Equals("-")) Minus();
            else if (operation.Equals("*")) Multiplication();
            else Dividing(); //ako operacija vec postoji izvrši je
            if (state.Equals("-E-")) { return; }
            this.setState(); //postavi rezultat kao stanje
            this.setOper1(); //postavi rezultat kao prvi operand
            setOperation(inPressed);
            this.binOp = true;
            numbers = false;
 
        }

        public void unaryOperatorInput()
        {
            if(inPressed.Equals("M")) this.Alternate();
            else if (inPressed.Equals("S")) this.Sinus();
            else if (inPressed.Equals("K")) this.Cosinus();
            else if (inPressed.Equals("T")) this.Tangens();
            else if (inPressed.Equals("Q")) this.Quadrat();
            else if (inPressed.Equals("R")) this.Root();
            else if (inPressed.Equals("I")) this.Invers();
            else if (inPressed.Equals("P")) this.setMemory();
            else if (inPressed.Equals("G")) this.getMemory();
            else if (inPressed.Equals("C")) this.Clear();
            else this.Reset();
        }

        public void setState()
        {
            this.state = result.ToString();
            //if (state.Length > 10) { state = "-E-"; reset2 = true; return;  }
            while (state.EndsWith("0") & !state.StartsWith("0") & state.Contains(",")) state = state.Remove(state.Length - 1);
            if (state.EndsWith(",")) state = state.Remove(state.Length - 1);
            if (state.StartsWith(".")) this.state = "0" + state;

        }

        public void setOper1()
        {
            string state = this.state;
            int i = state.IndexOf(",");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");
            while (state.EndsWith("0") & !state.StartsWith("0") & state.Contains(",")) state = state.Remove(state.Length - 1);
            if (state.Contains(",")) state = state.Replace(",", ".");
            if (state.EndsWith(".")) state = state.Remove(state.Length - 1);
            this.oper1 = double.Parse(state);
        }

        public void setOperation(String op)
        {
            this.operation = op;
        }

        public void setOper2()
        {
            string state = this.state;
            int i = state.IndexOf(",");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");
            while (state.EndsWith("0") & !state.StartsWith("0") & state.Contains(",")) state = state.Remove(state.Length - 1);
            if (state.Contains(",")) state = state.Replace(",", ".");
            if (state.EndsWith(",")) state = state.Remove(state.Length - 1);
            this.oper2 = double.Parse(state);
        }

        public string getCalculatorState()
        {
            
            int i = state.IndexOf(".");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");
            if (this.state.Contains(".")) state = state.Replace(".", ",");
            int k = state.IndexOf(",");
            if (k == 0) state = "0" + state;
            //if (!this.checkResultLength()) { state = "-E-"; this.reset2 = true; }
            return this.state;
        }

        private void Plus()
        {
            result = oper1 + oper2;
            
        }

        private void Minus()
        {
            result = oper1 - oper2;
        }

        private void Multiplication()
        {
            result = oper1 * oper2;
        }

        private void Dividing()
        {
            string op2 = oper2.ToString();
            if (op2.Equals("0")) { state = "-E-"; this.reset = true; return; }
            result = oper1 / oper2;
        }

        private void Equal()
        {
            while (state.EndsWith("0") & !state.StartsWith("0") & state.Contains(",")) state = state.Remove(state.Length - 1);
            if (state.EndsWith(",")) state = state.Remove(state.Length - 1);
            if (this.operation.Equals("0")) return;
            binOp = false;
            if (op2set) { this.setOper2(); op2set = false; }
            if (this.operation.Equals("+")) this.Plus();
            else if (this.operation.Equals("-")) this.Minus();
            else if (this.operation.Equals("*")) this.Multiplication();
            else this.Dividing();
            if (state.Equals("-E-")) { return; }
            this.setState(); //postavi rezultat kao stanje
            if (!checkResultLength()) { reset = true; state = "-E-"; return; }
            this.setOper1();
            numbers = false;
        }

        private void Alternate()
        {
            if (state.StartsWith("-")) state = state.Remove(0);
            else state = state.Insert(0, "-");
        }

        private void Sinus()
        {
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = Math.Sin(s);
            this.state = s.ToString("##########.#########");
            int i = state.IndexOf(".");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");
            if (this.state.Contains(".")) state = state.Replace(".", ",");
        }

        private void Cosinus()
        {
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = Math.Cos(s);
            this.state = s.ToString("##########.#########");
            int i = state.IndexOf(".");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");

        }

        private void Tangens()
        {
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = Math.Tan(s);
            this.state = s.ToString("##########.#########");
            int i = state.IndexOf(".");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");
        }

        private void Quadrat()
        {
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = Math.Pow(s, 2);
            this.state = s.ToString("##########.#########");
            int i = state.IndexOf(".");
            if (i == 0) state = "0" + state;
        }

        private void Root()
        {
            if (state.StartsWith("-"))
            {
                state = "-E-";
                reset = true;
                return;
            }
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = Math.Pow(s, 0.5);
            this.state = s.ToString("##########.#########");
            int i = state.IndexOf(".");
            if (i == 0) state = "0" + state;
        }

        private void Invers()
        {
            if (state.Equals("0"))
            {
                state = "-E-";
                reset = true;
                return;
            }
            if (this.state.Contains(",")) state = state.Replace(",", ".");
            double s = double.Parse(state);
            s = 1 / s;
            this.state = s.ToString("##########.#########");
            if (state.Equals("Infinity")) { state = "-E-"; reset2 = true; return; }
            int i = state.IndexOf(".");
            int j = state.IndexOf("-");
            if (i == 0) state = "0" + state;
            if (j == 0 & i == 1) state = state.Insert(1, "0");

        }

        private void setMemory()
        {
            this.memory = this.state;
        }

        private void getMemory()
        {
            this.state = this.memory;   
        }

        private void Clear()
        {
            this.state = "0";
        }

        private void Reset()
        {
            state = "0";
            operation = "0";
            result = 0;
            oper1 = 0;
            oper2 = 0;
            memory = "0";
            binOp = false;
            op2set = false;
            numbers = false;
        }

        private Boolean checkStateLenght()
        {
            if (state.Contains("-") & state.Contains(",") & state.Length > 12) return false;
            else if (state.Contains("-") & state.Contains(".") & state.Length > 12) return false;
            else if (state.Contains(",") & state.Length > 11) return false;
            else if (!state.Contains(",") & state.Length > 10) return false;
            else
                return true;

        }

        private Boolean checkResultLength()
        {
            string res = this.result.ToString();
            int j = res.IndexOf("0");
            if (res.Equals("Infinity")) return false;
            if (res.Contains("-") & j == 1) return true;
            if (!res.Contains("-") & j == 0) return true;
            if (res.Contains("-") & res.Contains(",") & res.Length > 12) return false;
            else if (res.Contains("-") & res.Contains(".") & res.Length > 12) return false;
            else if (res.Contains(",") & res.Length > 11) return false;
            else if (!res.Contains(",") & res.Length > 10) return false;
            else
                return true;

        }
    }


}
