﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         // hash tablica dionica na burzi
         IDictionary<int, Stock> _stocks  = new Dictionary<int, Stock>();
         // hash tablica indeksa na burzi
         IDictionary<int, Index> _indices = new Dictionary<int, Index>();
         //hash tablica portfolia na burzi
         IDictionary<string, Portfolio> _portfolios = new Dictionary<string, Portfolio>();

         #region Stock

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!this.StockExists(inStockName))
             {
                 Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 _stocks.Add(stock.GetHashCode(), stock);
             }
             else
             {
                 throw new StockExchangeException("Postoji dionica sa navedenim imenom!");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (this.StockExists(inStockName))
             {
                 int key = Stock.GetHashCode(inStockName);
                 Stock stock = _stocks[key];
                 _stocks.Remove(key);

                 foreach (int indexKey in _indices.Keys)
                 {
                     if (_indices[indexKey].ContainsStock(stock))
                     {
                         _indices[indexKey].Remove(stock);
                     }
                 }
                 foreach (string name in _portfolios.Keys)
                 {
                     if (_portfolios[name].ContainsStock(stock))
                     {
                         _portfolios[name].RemoveStock(stock);
                     }
                 }
                 _stocks.Remove(key);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa navedenim imenom!");
             }
         }

         public bool StockExists(string inStockName)
         {
             int key = Stock.GetHashCode(inStockName);
             if (_stocks.ContainsKey(key))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (this.StockExists(inStockName))
             {
                 int key = Stock.GetHashCode(inStockName);
                 Stock stock = _stocks[key];
                 stock.AddPrice(inIimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa navedenim imenom!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             int key = Stock.GetHashCode(inStockName);
             if (this.StockExists(inStockName))
             {
                 return _stocks[key].GetPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa navedenim imenom!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             int key = Stock.GetHashCode(inStockName);
             if (this.StockExists(inStockName))
             {
                 return _stocks[key].InitalPrice;
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa navedenim imenom!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             int key = Stock.GetHashCode(inStockName);
             if (this.StockExists(inStockName))
             {
                 return _stocks[key].CurrentPrice;
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica sa navedenim imenom!");
             }
         }

         #endregion

         #region Index

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!this.IndexExists(inIndexName))
             {
                 Index index = IndexFactory.Create(inIndexName, inIndexType);
                 _indices.Add(index.GetHashCode(), index);
             }
             else
             {
                 throw new StockExchangeException("Indeks sa navedenim imenom već postoji");
             }
             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             
             if (this.IndexExists(inIndexName) && this.StockExists(inStockName))
             {
                 int stockKey = Stock.GetHashCode(inStockName);
                 Stock stock = _stocks[stockKey];
                 
                 int indexKey = Index.GetHashCode(inIndexName);
                 Index index = _indices[indexKey];
                 index.Add(stock);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice u indeks");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (this.IndexExists(inIndexName) && this.StockExists(inStockName))
             {
                 int stockKey = Stock.GetHashCode(inStockName);
                 Stock stock = _stocks[stockKey];

                 int indexKey = Index.GetHashCode(inIndexName);
                 Index index = _indices[indexKey];
                 index.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri uklanjanju dionice iz indeksa");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {   
             if (this.IndexExists(inIndexName))
             {
                 int indexKey = Index.GetHashCode(inIndexName);
                 Index index = _indices[indexKey];

                 if ( index.ContainsStock( inStockName ) )
                     return true;
                 else
                     return false;
             }
             else
             {
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji!");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (this.IndexExists(inIndexName))
             {
                 int key = Index.GetHashCode(inIndexName);
                 Index index = _indices[key];
                 return index.CalculateValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji index sa imenom " + inIndexName);
             }
             throw new NotImplementedException();
         }

         public bool IndexExists(string inIndexName)
         {
             int key = Index.GetHashCode(inIndexName);
             if (_indices.ContainsKey(key))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (this.IndexExists(inIndexName))
             {
                 int key = Index.GetHashCode(inIndexName);
                 return _indices[key].NumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji!");
             }
         }

         #endregion

         #region Portofolio

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 _portfolios.Add(inPortfolioID, portfolio);
             }
             else
             {
                 throw new StockExchangeException("A boga  ti");
             }

         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (this.StockExists(inStockName) && this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 Stock stock = _stocks[Stock.GetHashCode(inStockName)];
                 portfolio.AddStock(stock, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");            
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {             
             if (this.StockExists(inStockName) && this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 Stock stock = _stocks[Stock.GetHashCode(inStockName)];
                 portfolio.RemoveStock(stock, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");            
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.StockExists(inStockName) && this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 Stock stock = _stocks[Stock.GetHashCode(inStockName)];
                 portfolio.RemoveStock(stock);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");
             }
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 return portfolio.NumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (_portfolios.ContainsKey(inPortfolioID))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.StockExists(inStockName) && this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 Stock stock = _stocks[Stock.GetHashCode(inStockName)];
                 return portfolio.ContainsStock(stock);
             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.StockExists(inStockName) && this.PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 Stock stock = _stocks[Stock.GetHashCode(inStockName)];

                 if (portfolio.ContainsStock(stock))
                     return portfolio.NumberOfSharesInStock(stock);
                 else
                     throw new StockExchangeException("Dionica ne postoji u portfoliju");

             }
             else
             {
                 throw new StockExchangeException("Pogreška pri dodavanju dionice portfoliju");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (_portfolios.ContainsKey(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 return portfolio.GetValue(timeStamp);
             }
             else
             {
                 throw new StockExchangeException("ne postoji portfolio!");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (_portfolios.ContainsKey(inPortfolioID))
             {
                 Portfolio portfolio = _portfolios[inPortfolioID];
                 return portfolio.GetMonthlyPercentageChange(Year, Month);
             }
             else
             {
                 throw new StockExchangeException("opet ne postoji");
             }
         }

         #endregion

         #region StockClass

         public class Stock
         {

             String _name;
             long _numberOfShares;

             Decimal _initalPrice;
             DateTime _startingTime;

             DateTime _lastPriceDate;

             SortedList<DateTime, Decimal> _prices;

             public Stock(string name)
             {
                 _name = name;
             }

             public Stock(string name, long numberOfShares, Decimal initialPrice, DateTime startingTime)
             {
                 if (initialPrice < 1 || numberOfShares < 1)
                     throw new StockExchangeException("Neispravne vrijednosti parametara u dionici " + _name);

                 _name = name;

                 _initalPrice = initialPrice;
                 _startingTime = startingTime;
                 _lastPriceDate = startingTime;
                 _numberOfShares = numberOfShares;

                 _prices = new SortedList<DateTime, Decimal>();
                 _prices.Add(startingTime, initialPrice);
             }

             public String Name
             {
                 get { return _name; }
             }

             public long NumberOfShares
             {
                 get { return _numberOfShares; }
                 set
                 {
                     if (value > 0)
                         _numberOfShares = value;
                     else
                         throw new StockExchangeException("Ne ispravan broj dionica dionice " + _name);
                 }
             }

             public Decimal InitalPrice
             {
                 get { return _initalPrice; }
                 set
                 {
                     if (value > 0)
                         _initalPrice = value;
                     else
                         throw new StockExchangeException("Ne ispravan broj dionica dionice " + _name);

                 }
             }

             public DateTime StartingTime
             {
                 get { return _startingTime; }
                 set { _startingTime = value; }
             }

             public Decimal CurrentPrice
             {
                 get { return _prices[_lastPriceDate]; }
             }

             public void AddPrice(DateTime time, Decimal price)
             {
                 if (price < 1)
                     throw new StockExchangeException("Neispravan broj dionica dionice " + _name);
                 if (_prices.ContainsKey(time))
                     throw new StockExchangeException("Postoji definirana cijena za trenutak " + time + " u dionici " + _name);

                 if (time > _lastPriceDate)
                 {
                     _lastPriceDate = time;
                 }
                 _prices.Add(time, price);
             }

             public Decimal GetPrice(DateTime time)
             {
                 _prices.Last(
                                 (x => x.Key.CompareTo(time) == -1 || x.Key.CompareTo(time) == 0)
                             );

                 if (this.ContainsPrice(time))
                 {
                     DateTime dateTime = this.GetMatchingTime(time);
                     Console.WriteLine(dateTime);
                     return _prices[dateTime];
                 }
                 else
                 {
                     throw new StockExchangeException("Dionica " + _name + " ne sadrži cijenu za datum: " + time);
                 }
             }

             public bool ContainsPrice(DateTime timeStamp)
             {
                 foreach (DateTime time in _prices.Keys)
                 {
                     int compareValue = time.CompareTo(timeStamp);
                     if (compareValue == -1 || compareValue == 0)
                     {
                         return true;
                     }
                 }
                 return false;
             }

             private DateTime GetMatchingTime(DateTime timeStamp)
             {
                 DateTime matchingTime = new DateTime();
                 foreach (DateTime time in _prices.Keys)
                 {
                     int compareValue = time.CompareTo(timeStamp);
                     if (compareValue == -1)
                     {
                         matchingTime = time;
                     }
                     else if (compareValue == 0)
                     {
                         matchingTime = time;
                         break;
                     }
                     else
                     {
                         break;
                     }
                 }
                 return matchingTime;
             }

             public override int GetHashCode()
             {
                 return _name.ToLower().GetHashCode();
             }

             public static int GetHashCode(string name)
             {
                 return name.ToLower().GetHashCode();
             }

         }

         #endregion +------------StockClass---------+

         #region PortfolioClass

         public class Portfolio
         {

             string _ID;

             IDictionary<Stock, int> _stocks = new Dictionary<Stock, int>();

             public Portfolio(string ID)
             {
                 _ID = ID;
             }

             public void AddStock(Stock stock, int numberOfShares)
             {
                 if (numberOfShares > 0 || stock.NumberOfShares < numberOfShares)
                 {
                     if (!_stocks.ContainsKey(stock))
                         _stocks.Add(stock, numberOfShares);
                     else
                     {
                         int currentNumberOfStocks = _stocks[stock];
                         currentNumberOfStocks += numberOfShares;
                         _stocks[stock] = currentNumberOfStocks;
                     }

                 }
                 else
                 {
                     throw new StockExchangeException("Pogreška pri dodavanju dionice");
                 }
             }

             public void RemoveStock(Stock stock, int numberOfShares)
             {
                 if (_stocks.ContainsKey(stock))
                 {
                     int currentNumberOfStocks = _stocks[stock];
                     currentNumberOfStocks -= numberOfShares;
                     if (currentNumberOfStocks > 0)
                     {
                         _stocks[stock] = currentNumberOfStocks;
                     }
                     else
                     {
                         _stocks.Remove(stock);
                     }

                 }
                 else
                 {
                     throw new StockExchangeException("Ne postoji dionica u portfoliju");
                 }
             }

             public bool ContainsStock(Stock stock)
             {
                 if (_stocks.ContainsKey(stock))
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }



             public decimal GetValue(DateTime time)
             {
                 decimal value = 0;
                 foreach (Stock stock in _stocks.Keys)
                 {
                     value += stock.GetPrice(time);
                 }
                 return decimal.Round(value, 3);
             }

             public int GetMonthlyPercentageChange(int year, int month)
             {

                 DateTime firstOfTheMonth = new DateTime(year, month, 1, 0, 0, 0, 0);
                 DateTime lastOfTheMonth = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 99);

                 decimal firstOfTheMonthPrice = 0;
                 decimal lastOfTheMonthPrice = 0;

                 foreach (Stock stock in _stocks.Keys)
                 {
                     firstOfTheMonthPrice += stock.GetPrice(firstOfTheMonth);
                     lastOfTheMonthPrice += stock.GetPrice(lastOfTheMonth);
                 }

                 return (int)
                     (((lastOfTheMonthPrice - firstOfTheMonthPrice) / firstOfTheMonthPrice) * 100);
             }

             public void RemoveStock(Stock stock)
             {
                 if (_stocks.ContainsKey(stock))
                 {
                     _stocks.Remove(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("Dionica ne postoji u portfoliju");
                 }
             }

             public int NumberOfStocks()
             {
                 return _stocks.Count;
             }

             public int NumberOfSharesInStock(Stock stock)
             {
                 return _stocks[stock];
             }

             public override int GetHashCode()
             {
                 return _ID.GetHashCode();
             }
         }

         #endregion +----------PorfolioClass------------------+

         #region IndexClass
   
         public static class IndexFactory
         {
            public static Index Create(string name, IndexTypes type)
            {
                if (type == IndexTypes.AVERAGE)
                {
                    return new AverageIndex(name);
                }
                else if (type == IndexTypes.WEIGHTED)
                {
                    return new WeightedIndex(name);
                }
                else
                {
                    throw new StockExchangeException("Pogrešan tip indeksa!");
                }

            }
        }
    
        public abstract class Index
        {

            string _name;

            public string Name
            { get { return _name; } }

            IDictionary<int, Stock> _stocks = new Dictionary<int, Stock>();

            protected ICollection<Stock> Stocks
            { get { return _stocks.Values; } }

            public Index(string name)
            {
                _name = name.ToLower();
            }

            public void Add(Stock stock)
            {
                int key = stock.GetHashCode();
                if (!_stocks.ContainsKey(key))
                {
                    _stocks.Add(key, stock);
                }
                else
                {
                    throw new StockExchangeException("Dionica " + stock.Name + " ne postoji u indeksu " + _name);
                }
            }

            public void Remove(Stock stock)
            {
                int key = stock.GetHashCode();
                if (_stocks.ContainsKey(key))
                {
                    _stocks.Remove(key);
                }
                else
                {
                    throw new StockExchangeException("Dionica " + stock.Name + " ne postoji u indeksu " + _name);
                }
            }

            public void Remove(string stockName)
            {
                int key = Stock.GetHashCode(stockName);
                if (_stocks.ContainsKey(key))
                {
                    _stocks.Remove(key);
                }
                else
                {
                    throw new StockExchangeException("Dionica " + stockName + " ne postoji u indeksu " + _name);
                }
            }

            public bool ContainsStock(Stock stock)
            {
                int key = stock.GetHashCode();
                if (_stocks.ContainsKey(key) )
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public bool ContainsStock(string stockName)
            {
                int key = Stock.GetHashCode(stockName);
                if ( _stocks.ContainsKey(key) )
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public int NumberOfStocks()
            {
                return _stocks.Count;
            }

            public abstract Decimal CalculateValue(DateTime timeStamp);

            public override int GetHashCode()
            {
                return _name.GetHashCode();
            }

            public static int GetHashCode(string name)
            {
                return name.ToLower().GetHashCode();
            }
        }

        public class AverageIndex : Index
        {
            public AverageIndex(string name) :base(name){ }

            public override decimal CalculateValue(DateTime timeStamp)
            {
                Decimal price = new Decimal(0.000);
                int numberOfStocks = 0;
                foreach (Stock stock in this.Stocks)
                {
                    if (stock.ContainsPrice(timeStamp))
                    {
                        price += stock.GetPrice(timeStamp);
                        numberOfStocks++;
                    }
                }
                return Decimal.Round(price / numberOfStocks, 3);
            }
        }

        public class WeightedIndex : Index
        {
            public WeightedIndex(string name) : base(name) { }

            public override decimal CalculateValue(DateTime timeStamp)
            {
                decimal sumOfPrices = 0;
                decimal sumOfWeigthedFactors = 0;
                foreach (Stock stock in this.Stocks)
                {
                
                    if (stock.ContainsPrice(timeStamp))
                    {
                        decimal priceOfTheShare = stock.GetPrice(timeStamp);
                        sumOfWeigthedFactors += (priceOfTheShare * priceOfTheShare * stock.NumberOfShares);
                        sumOfPrices += (priceOfTheShare*stock.NumberOfShares);
                    }
                }

                return Decimal.Round(sumOfWeigthedFactors/sumOfPrices, 3);
            }
        }
         #endregion +---------------IndexClass--------------+
     
     }
}