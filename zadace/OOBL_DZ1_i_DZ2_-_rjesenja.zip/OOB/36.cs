﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string ekran;
        double memory;
        double rezultat;
        double operandPrvi;
        double operandDrugi;
        Operator operacija;

        bool isAfterOperator;
        bool isFirstOperation;

        public Kalkulator()
        {
            reset();
        }

        public string GetCurrentDisplayState()
        {
            roundEkran();
            return ekran;
        }

        public void Press(char inPressedDigit)
        {
            inPressedDigit = char.ToUpper(inPressedDigit);

            if (inPressedDigit.Equals('.'))
                inPressedDigit = ',';
            if (char.IsDigit(inPressedDigit) || inPressedDigit.Equals(','))
            {
                if (isAfterOperator)
                {
                    isAfterOperator = false;
                    ekran = "";
                }
                if (ekran.Equals("0"))
                {
                    ekran = "";
                    if (inPressedDigit.Equals(','))
                        ekran="0,";
                }

                if (ekran.Contains(',') && inPressedDigit.Equals(','))
                {
                    return;
                }

                ekran += inPressedDigit;

                return;
            }

            switch (inPressedDigit)
            {
                case '+':
                    postaviPrviOperand();
                    operacija = Operator.ZBRAJANJE;
                    break;
                case '-':
                    postaviPrviOperand();
                    operacija = Operator.ODUZIMANJE;
                    break;
                case '*':
                    postaviPrviOperand();
                    operacija = Operator.MNOZENJE;
                    break;
                case '/':
                    postaviPrviOperand();
                    operacija = Operator.DIJELJENJE;
                    break;
                case '=':
                    izracunaj();
                    break;
                case 'M':
                    promijeniPredznak();
                    break;
                case 'S':
                    sinus();
                    break;
                case 'K':
                    cosin();
                    break;
                case 'T':
                    tan();
                    break;
                case 'Q':
                    quad();
                    break;
                case 'R':
                    root();
                    break;
                case 'I':
                    invers();
                    break;
                case 'P':
                    memory = Double.Parse(ekran);
                    break;
                case 'G':
                    ekran = memory.ToString();
                    break;
                case 'C':
                    resetScreen();
                    break;
                case 'O':
                    reset();
                    break;
            }

        }

        private void postaviPrviOperand()
        {
            if (isFirstOperation)
                operandPrvi = Double.Parse(ekran);
            else if(!isAfterOperator) 
                izracunaj();
            isAfterOperator = true;
            isFirstOperation = false;
        }

        private void izracunaj()
        {
            if (!ekran.Equals(""))
                operandDrugi = Double.Parse(ekran);
            else operandDrugi = operandPrvi;

            switch (operacija)
            {
                case Operator.ZBRAJANJE:
                    rezultat = operandPrvi + operandDrugi;
                    break;
                case Operator.ODUZIMANJE:
                    rezultat = operandPrvi - operandDrugi;
                    break;
                case Operator.MNOZENJE:
                    rezultat = operandPrvi * operandDrugi;
                    break;
                case Operator.DIJELJENJE:
                    rezultat = operandPrvi / operandDrugi;
                    break;
            }

            ekran = rezultat.ToString();
            operandPrvi = rezultat;
        }

        private void invers()
        {
            rezultat = Double.Parse(ekran);
            ekran = (1 / rezultat).ToString();
        }

        private void root()
        {
            rezultat = Double.Parse(ekran);
            if (rezultat > 0)
                ekran = Math.Sqrt(rezultat).ToString();
            else
                ekran = "-E-";
        }

        private void quad()
        {
            rezultat = Double.Parse(ekran);
            ekran = Math.Pow(rezultat, 2).ToString();
        }

        private void tan()
        {
            rezultat = Double.Parse(ekran);
            ekran = Math.Tan(rezultat).ToString();
        }

        private void cosin()
        {
            rezultat = Double.Parse(ekran);
            ekran = Math.Cos(rezultat).ToString();
        }

        private void sinus()
        {
            rezultat = Double.Parse(ekran);
            ekran = Math.Sin(rezultat).ToString();
        }

        private void promijeniPredznak()
        {
            if (ekran.Contains('-'))
                ekran = ekran.Remove(0, 1);
            else
                 ekran = '-' + ekran;
        }

        private void roundEkran()
        {
            int index = ekran.IndexOf(',');
            if (ekran.Contains('+'))
                index--;
            else if (ekran.Contains('-'))
                index--;
            Double num = Double.Parse(ekran);

            if (index > 0 && ekran.Length>12)
            {
                ekran = (Math.Round(num, 10 - index)).ToString(); 
            }

            if (num > 9999999999)
            {
                ekran = "-E-";
            }
        }

        private string parseEkran()
        {
            string parse = ekran;
            int index;
            if (parse.Contains(','))
            {
                index = parse.IndexOf(',');
                parse.Remove(index);
            }
            if (parse.Contains('+'))
            {
                index = parse.IndexOf('+');
                parse.Remove(index);
            }
            if (parse.Contains('-'))
            {
                index = parse.IndexOf('-');
                parse.Remove(index);
            }
            return parse;
        }

        private void reset()
        {
            resetScreen();
            memory = 0;
            rezultat = 0;
            operandPrvi = 0;
            operandDrugi = 0;
            isAfterOperator = false;
            isFirstOperation = true;
        }

        private void resetScreen()
        {
            ekran = "0";
        }

        private enum Operator
        {
            ZBRAJANJE,
            ODUZIMANJE,
            MNOZENJE,
            DIJELJENJE,
            NONE
        }

    }

}
