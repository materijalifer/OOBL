﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    #region Calculator
    
    public class Calculator:ICalculator
    {
        readonly char _separatorSymbol = ',';
        CalculatorState _state;
        Dictionary<string, IOperation> _operations;

        public Calculator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");

            _state = new CalculatorState();
            _state.Reset();
            
            _operations = new Dictionary<string, IOperation>();
            var operations = Assembly.GetAssembly(typeof(Calculator))
                    .GetTypes()
                    .Where(x => typeof(IOperation).IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract);
            foreach (var operationType in operations)
            {
                var operationInstance = (IOperation)Activator.CreateInstance(operationType);
                _operations[operationInstance.TriggerCharacter] = operationInstance;
            }

        }



        /// <summary>
        /// Catches keypresses.
        /// </summary>
        /// <param name="inPressedDigit">Pressed key.</param>
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                InputDigit(inPressedDigit);
            }
            else if (inPressedDigit == _separatorSymbol)
            {
                InputSeparator();
            }
            else
            {
                _operations[inPressedDigit.ToString()].PerformOperation(_state);
            }
        }

        /// <summary>
        /// Gets the current display state.
        /// </summary>
        /// <returns>A string containing the content of the display.</returns>
        public string GetCurrentDisplayState()
        {
            return _state.Display;
        }


        /// <summary>
        /// Inputs a separator (comma - ',') into the calculator.
        /// </summary>
        private void InputSeparator()
        {
            if (_state.ResultOnDisplay)
            {
                _state.ResultOnDisplay = false;
                _state.Display = "0,";
            }
            else
            {
                if (_state.Display.Contains(_separatorSymbol))
                    return;

                var prep = _state.Display + ",";
                if (DisplayValidator.DisplayValid(prep))
                {
                    _state.Display = prep;
                }
            }
        }

        /// <summary>
        /// Inputs a digit into the calculator.
        /// </summary>
        /// <param name="inPressedDigit"></param>
        private void InputDigit(char inPressedDigit)
        {
            if (_state.ResultOnDisplay)
            {
                _state.ResultOnDisplay = false;
                _state.Display = inPressedDigit.ToString();
            }
            else if (_state.Display == "0")
            {
                _state.Display = inPressedDigit.ToString();
            }
            else
            {
                if (_state.Display.Length < 10 + _state.Display.Count(x => x == '-') + _state.Display.Count(x => x == ','))
                {
                    var prep = _state.Display + inPressedDigit.ToString();
                    if (DisplayValidator.DisplayValid(prep))
                    {
                        _state.Display = prep;
                        return;
                    }
                    _state.Error();
                }
            }
        }




        /// <summary>
        /// Encapsulates the state of the calculator.
        /// </summary>
        private class CalculatorState
        {
            private string _display;
            private string _accumulator;

            /// <summary>
            /// Accumulator contains the last previously calculated value.
            /// </summary>
            public string Accumulator
            {
                get
                {
                    return _accumulator;
                }
                set
                {
                    _accumulator = value;
                }
            }

            /// <summary>
            /// Flag indicating whether the Accumulator has any value in it.
            /// </summary>
            public bool AccumulatorContainsValue { get; set; }

            /// <summary>
            /// Content of the calculator display.
            /// </summary>
            public string Display { 
                get 
                { 
                    return _display;
                } 
                set
                {
                    if (ValidateDisplayValue(value))
                    {
                        _display = value;
                    }
                    else
                    {
                        this.Error();
                    }
                }
            }

            /// <summary>
            /// Content of the calculator memory.
            /// </summary>
            public string Memory { get; set; }

            /// <summary>
            /// Flag indicating whether the display shows a result of some operation,
            /// or the user is currently inputing digits.
            /// </summary>
            public bool ResultOnDisplay { get; set; }

            /// <summary>
            /// Flag that indicates whether the equals operation is active.
            /// </summary>
            public bool IsEqualsActive { get; set; }

            /// <summary>
            /// Saves the last preformed operation.
            /// </summary>
            public BinaryOperation LastOperation { get; set; }

            /// <summary>
            /// Resets the calculator.
            /// </summary>
            public void Reset()
            {
                this.Display = "0";
                this.ResultOnDisplay = true;
                this.Accumulator = "0";
                this.AccumulatorContainsValue = false;
                this.Memory = "0";
                this.LastOperation = null;
                this.IsEqualsActive = false;
            }

            /// <summary>
            /// Switches the calculator to the error state. Calculator
            /// is reset and the display shows "-E-" message.
            /// </summary>
            public void Error()
            {
                this.Reset();
                this.Display = "-E-";
            }

            /// <summary>
            /// Determines if the input value can be displayed on the display.
            /// </summary>
            /// <param name="displayValue">Value for validation.</param>
            /// <returns>Result of the validation.</returns>
            private bool ValidateDisplayValue(string displayValue)
            {
                return DisplayValidator.DisplayValid(displayValue);
            }

            /// <summary>
            /// Outputs the input value to the display.
            /// </summary>
            /// <param name="output">Value to be shown on the display.</param>
            /// <returns>True if the value was successfully displayed.</returns>
            public bool Output(double output)
            {
                if (output >= 10e11)
                {
                    this.Display = "-E-";
                    return false;
                }
                string prep = output.ToString();
                
                if (output < 0)
                {
                    if (prep.Length > 12)
                    {
                        this.Display = Math.Round(output, 12 - 1 - prep.IndexOf(',')).ToString();
                        return true;
                    }
                }
                else
                {
                    if (prep.Length > 11)
                    {
                        this.Display = Math.Round(output, 11 - 1 - prep.IndexOf(',')).ToString();
                        return false;
                    }
                }

                this.Display = prep;
                return true;
            }

        }

        /// <summary>
        /// Interface all operations should implement. Implementations of this 
        /// interface are automatically recognized and registered to the calculator.
        /// </summary>
        private interface IOperation
        {
            /// <summary>
            /// Performs the operation.
            /// </summary>
            /// <param name="state">Current calculator state.</param>
            void PerformOperation(CalculatorState state);

            /// <summary>
            /// The input character the operation matches. For example that 
            /// would be '+' for adding or 'P' for memory save.
            /// </summary>
            string TriggerCharacter { get; }
        }




        #region Operations

        /// <summary>
        /// Encapsulates equals operation
        /// </summary>
        private class OperationEquals : IOperation
        {
            public void PerformOperation(CalculatorState state)
            {
                if (state.LastOperation != null)
                {
                    state.IsEqualsActive = true;
                    state.LastOperation.PerformOperation(state);
                    state.IsEqualsActive = false;
                }
                else
                {
                    double inputNumber = Double.Parse(state.Display);
                    state.Display = inputNumber.ToString();
                }
            }

            /// <summary>
            /// The input character the operation matches, '='
            /// </summary>
            public string TriggerCharacter
            {
                get { return "="; }
            }
        }

        /// <summary>
        /// Abstract class used as a base for all binary operations.
        /// Contains common operations. Concrete implementations diverge
        /// only in the concrete operation (they have to implement the
        /// abstract method Operation), and TriggerCharacter.
        /// </summary>
        private abstract class BinaryOperation : IOperation
        {
            /// <summary>
            /// Concrete BinaryOperation implementations should use this 
            /// method to define their operation. For example, adding would
            /// be implemented as a method that takes two doubles, and returns
            /// their sum.
            /// </summary>
            /// <param name="arg1">First parameter.</param>
            /// <param name="arg2">Second parameter.</param>
            /// <returns>Result of the operation over the arguments.</returns>
            public abstract double Operation(double arg1, double arg2);

            /// <summary>
            /// Performs the operation. Contains common behaviour for all the
            /// binary operations. Internally calls the abstracted Operation method
            /// to preform the operation itself.
            /// </summary>
            /// <param name="state">State of the calculator.</param>
            public void PerformOperation(CalculatorState state)
            {
                if (!state.AccumulatorContainsValue)
                {
                    state.Accumulator = this.PrepareForDisplay(state.Display);
                    state.Display = state.Accumulator;
                    state.AccumulatorContainsValue = true;
                    state.LastOperation = this;
                    state.ResultOnDisplay = true;
                }
                else
                {
                    double accumulator = Double.Parse(state.Accumulator);
                    double display;
                    if (Double.TryParse(state.Display, out display))
                    {
                        if (state.ResultOnDisplay)
                        {
                            if (state.IsEqualsActive)
                            {
                                var output = state.LastOperation.Operation(accumulator, display);
                                if (state.Output(output))
                                {
                                    //state.Accumulator = this.PrepareForDisplay(state.Display);
                                    //state.Display = state.Accumulator;
                                    state.LastOperation = this;
                                    state.ResultOnDisplay = true;
                                }
                                else
                                {
                                    state.Error();
                                }
                            }
                            else
                            {
                                state.Accumulator = this.PrepareForDisplay(state.Display);
                                state.Display = state.Accumulator;
                                state.LastOperation = this;
                                state.ResultOnDisplay = true;
                            }
                        }
                        else
                        {
                            try
                            {
                                var output = state.LastOperation.Operation(accumulator, display);
                                if (state.Output(output))
                                {
                                    state.Accumulator = this.PrepareForDisplay(state.Display);
                                    state.Display = state.Accumulator;
                                    state.LastOperation = this;
                                    state.ResultOnDisplay = true;
                                }
                                else
                                {
                                    state.Error();
                                }
                            }
                            catch
                            {
                                state.Error();
                            }
                        }
                    }
                    else
                    {
                        state.Error();
                    }
                }
            }

            public abstract string TriggerCharacter { get ; }

            /// <summary>
            /// Prepares the input string for the display.
            /// </summary>
            /// <param name="input"></param>
            /// <returns></returns>
            private string PrepareForDisplay(string input)
            {
                double inputNumber = Double.Parse(input);
                var retVal = inputNumber.ToString();
                return retVal;
            }
        }

        /// <summary>
        /// Add operation.
        /// </summary>
        private class OperationAdd : BinaryOperation
        {
            public override double Operation(double arg1, double arg2)
            {
                return arg1 + arg2;
            }

            public override string TriggerCharacter
            {
                get { return "+"; }
            }
        }

        /// <summary>
        /// Subtract operation.
        /// </summary>
        private class OperationSubtract : BinaryOperation
        {
            public override double Operation(double arg1, double arg2)
            {
                return arg1 - arg2;
            }

            public override string TriggerCharacter
            {
                get { return "-"; }
            }
        }

        /// <summary>
        /// Multiply operation.
        /// </summary>
        private class OperationMultiply : BinaryOperation
        {
            public override double Operation(double arg1, double arg2)
            {
                return arg1 * arg2;
            }

            public override string TriggerCharacter
            {
                get { return "*"; }
            }
        }

        /// <summary>
        /// Divide operation.
        /// </summary>
        private class OperationDivide : BinaryOperation
        {
            public override double Operation(double arg1, double arg2)
            {
                return arg1 / arg2;
            }

            public override string TriggerCharacter
            {
                get { return "/"; }
            }
        }

        /// <summary>
        /// Algebraic sign inversion operation. Denotes multiplying by -1.
        /// </summary>
        private class OperationInvertAgebraicSign : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    var output = -1 * input;
                    state.Output(output);
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "M"; }
            }
        }

        /// <summary>
        /// Arithmetic square function operation.
        /// </summary>
        private class OperationSquare : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    var output = input * input;
                    state.Output(output);
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "Q"; }
            }
        }

        /// <summary>
        /// Arithmetic square root operation.
        /// </summary>
        private class OperationRoot : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    var output = Math.Sqrt(input);
                    state.Output(output);
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "R"; }
            }
        }

        /// <summary>
        /// Inverse operation. Denotes 1/x.
        /// </summary>
        private class OperationInverse : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    if (input == 0)
                    {
                        state.Error();
                    }
                    else
                    {
                        var output = 1 / input;
                        state.Output(output);
                    }
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "I"; }
            }
        }

        /// <summary>
        /// Sine operation.
        /// </summary>
        private class OperationSin : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    try
                    {
                        var output = Math.Sin(input);
                        state.Output(output);
                    }
                    catch
                    {
                        state.Error();
                    }
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "S"; }
            }
        }

        /// <summary>
        /// Cosine operation.
        /// </summary>
        private class OperationCos : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    try
                    {
                        var output = Math.Cos(input);
                        state.Output(output);
                    }
                    catch
                    {
                        state.Error();
                    }
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "K"; }
            }
        }

        /// <summary>
        /// Tangens operation.
        /// </summary>
        private class OperationTan : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                Double input;
                if (Double.TryParse(state.Display, out input))
                {
                    try
                    {
                        var output = Math.Tan(input);
                        state.Output(output);
                    }
                    catch
                    {
                        state.Error();
                    }
                }
                else
                {
                    state.Error();
                }

            }

            public string TriggerCharacter
            {
                get { return "T"; }
            }
        }

        /// <summary>
        /// Memory insert operation.
        /// </summary>
        private class OperationMemoryPut : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                state.Memory = state.Display;
            }

            public string TriggerCharacter
            {
                get { return "P"; }
            }
        }

        /// <summary>
        /// Memory fetch operation.
        /// </summary>
        private class OperationMemoryGet : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                state.Display = state.Memory;
            }

            public string TriggerCharacter
            {
                get { return "G"; }
            }
        }

        /// <summary>
        /// Clear operation. 
        /// </summary>
        private class OperationClear : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                state.Display = "0";
                state.ResultOnDisplay = true;
            }

            public string TriggerCharacter
            {
                get { return "C"; }
            }
        }

        /// <summary>
        /// Reset operation.
        /// </summary>
        private class OperationOnOff : IOperation
        {

            public void PerformOperation(CalculatorState state)
            {
                state.Reset();
            }

            public string TriggerCharacter
            {
                get { return "O"; }
            }
        }


        #endregion

        /// <summary>
        /// Used for validation of the data to be displayed on the diplay.
        /// </summary>
        private class DisplayValidator
        {
            private static readonly char _separatorSymbol = ',';

            /// <summary>
            /// Validates data to be displayed on the calculator display.
            /// </summary>
            /// <param name="displayText">Date for calculator display.</param>
            /// <returns>True if the data can be displayed.</returns>
            public static bool DisplayValid(string displayText)
            {
                if (displayText.Length > 12)
                {
                    return false;
                }
                if (displayText.Count(x => x == _separatorSymbol) > 1)
                {
                    return false;
                }
                if (displayText.Count(x => Char.IsDigit(x)) > 10)
                {
                    return false;
                }
                return true;
            }
        }
    }

    #endregion

   


}
