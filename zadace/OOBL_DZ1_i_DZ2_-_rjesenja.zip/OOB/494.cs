﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    
    public class Factory
    {
        public static ICalculator CreateCalculator()
     {
         // vratiti kalkulator
         return new Kalkulator();
     }
    }



    public class Kalkulator : ICalculator
    {

        private string stanjeNaZaslonu;
        private string memorija;
        private List<char> BINARNI_OPERATORI = new List<char>() {'+', '-', '*', '/'};


        // ta zastavica MORA biti vani! jer inače bi se svaki puta mijenjala i postavljala na false kada bi netko pritisnuo nešto
        bool postavljenBinarniOperator;
        // zastavica koja nam pomaže idenfiticiranje više uzastopnih binarnih operatora zaredom
        // sjeti se da si imao problem: 2+3- je davalo da je prvo na stogu bilo 2+ i onda kada si upisao
        // 3-, 3 je došlo na ekran i kod - se ispitalo i uvidjelo da postoji već binarni operator
        // na stogu, pa se promijenio, iako je brojka bila prije njega

        // TAKO DA: ako se pojavi BROJKA u međuvremenu, ali NE I NEKI UNARNI OPERATOR
        // jer sjeti se: {broj1} {binarni} {unarni} {broj1} = {broj1}{binarni}{broj2}
        // binarniOperator se postavlja na false!
        // kod unarnih operatora se ništa ne mijenja!

        private string stog; 
            // najlakše da ipak držimo string i da samo poslije pozbrajamo ili što već trebamo


        private bool prikazanRezultat = true;
            // znači štos je ovakav: kada napišemo 2+2, mi stavljamo na stog 2+, a kada stisnemo = onda stavljamo
            // i ovu zadnju dvojku i to sve zbrajamo. NO, problem je kada mi kliknemo 2+ i onda =. ZAŠTO?
            // zato što na stanjuNaZaslonu MORA I DALJE BITI 2!

            // -- NEEEE! pa upravo nema problema! uvijek na kraju samo uzmeš ono što je gore i to je to!
            // zato je takvo i pravilo

        // DAAA! :DDD potrebno nam je to! iz ovog razloga - znači mi sada više ne gledamo ovo sve šugavo sa stogom
        // nego kod tipkanja novih znakova, možemo imati nešto na zaslonu što je stari rezultat
        // i onda ako nemamo ovu zastavicu,  mi ćemo samo dodavati na taj rezultat brojeve, a zapravo se treba osvježiti!

        public Kalkulator()
        {
            resetirajStanjeNaZaslonu();
            stog = ""; // nemoj popuniti sa 0, jer ćemo tek nakon binarnog operatora stavljati na stog!
            memorija = "";
            postavljenBinarniOperator = false;
        }


        public void Press(char inPressedDigit)
        {
            char lastChar = '0'; // nema veze to, to je samo defaultna vrijednost tako da bude postavljen
            if (!String.IsNullOrEmpty(stog)) // ako nije prazan
            {
                lastChar = stog[stog.Length - 1]; // zadnji znak sa stoga
            }
            
            // neke varijable
            double rezultat;
            double cjelobrojniDio;
            int brojZnamenkiCjelobrojnogDjela;
            string postaviNaStog;

            switch (inPressedDigit)
            {
                
                // neka znamenka
                case '0':
                    if (!stanjeNaZaslonu.Equals("-E-")) // SAMO TADA SE NEŠTO RADI! - ne smije biti jednako -E-
                    {
                        postavljenBinarniOperator = false;

                        if (prikazanRezultat)
                        {
                            stanjeNaZaslonu = inPressedDigit.ToString();
                            prikazanRezultat = false;
                        }
                        else
                        {
                            if (lessThanTenDigits(stanjeNaZaslonu))
                            {
                                if (stanjeNaZaslonu[0] == '0' && stanjeNaZaslonu.Length == 1)
                                {
                                    // ne radimo ništa, jer je na zaslonu SAMO NULA!
                                }
                                else
                                {
                                    stanjeNaZaslonu += inPressedDigit;
                                }
                            }
                        }
                    }

                    break;




                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        postavljenBinarniOperator = false;


                        if (prikazanRezultat)
                        {
                            stanjeNaZaslonu = inPressedDigit.ToString();
                            prikazanRezultat = false;
                        }
                        else
                        {
                            if (lessThanTenDigits(stanjeNaZaslonu))
                            {
                                stanjeNaZaslonu += inPressedDigit;
                            }
                        }
                    }



                    break;
                

                
                case '+':
                case '-':
                case '*':
                case '/':


                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (String.IsNullOrEmpty(stog))
                        {
                            // to se događa upravo na početku - kada imamo 0 na zaslonu i onda kliknemo na +, pa je
                            // to kao zbrajanje sa nulom!
                            if (stanjeNaZaslonu[0] == '0' && stanjeNaZaslonu.Length == 1)
                            {
                                stog += "0" + inPressedDigit;
                            }
                            else
                            {
                                postaviNaStog = stanjeNaZaslonu;

                                if (postaviNaStog.Contains(','))
                                {
                                    postaviNaStog = postaviNaStog.Replace(',', '.');
                                }

                                stog += postaviNaStog + inPressedDigit;
                            }
                        }
                        else
                        {
                            if (isBinaryOperation(lastChar) && postavljenBinarniOperator)
                            {
                                stog = stog.Remove(stog.Length - 1, 1) + inPressedDigit; // zamjena zadnjeg binarnog operatora
                            }
                            else
                            {
                                // bez obzira jel ima ili nema minusa, stanje koje je na zaslonu se pukne na stog

                                postaviNaStog = stanjeNaZaslonu; // ovaj će uvijek biti bez zareza, tako da na stog ide sa .
                                // moramo imati tu varijablu postaviNaStog, tako da se ne mijenja stanjeNaZaslonu
                                if (postaviNaStog.Contains(','))
                                {
                                    postaviNaStog = postaviNaStog.Replace(',', '.');
                                }
                                stog += postaviNaStog + inPressedDigit;

                            }
                        }

                        if (!postavljenBinarniOperator)
                        {
                            postavljenBinarniOperator = true;
                        }


                        // moramo još osvježiti stanje na zaslonu tako da ako sadrži samo 2,0 ili tako nešto, da zapravo piše samo nula!
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            bool samoNule = true;
                            
                            for (int i = stanjeNaZaslonu.IndexOf(',') + 1; i < stanjeNaZaslonu.Length; i++)
                            {
                                if (!stanjeNaZaslonu[i].Equals('0')) // ako je nešto drugo osim nule
                                {
                                    samoNule = false;
                                    break;
                                }
                            }

                            if (samoNule)
                            {
                                stanjeNaZaslonu = stanjeNaZaslonu.Substring(0, stanjeNaZaslonu.IndexOf(','));
                            }
                            
                        }

                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case '=':
                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        //if (stog == "") // ako je stog prazan! - nemoj napraviti ništa!!
                        //{

                        //}
                        //else 
                        //{
                            postaviNaStog = stanjeNaZaslonu; // ovaj će uvijek biti bez zareza, tako da na stog ide sa .
                            // moramo imati tu varijablu postaviNaStog, tako da se ne mijenja stanjeNaZaslonu
                            if (postaviNaStog.Contains(','))
                            {
                                postaviNaStog = postaviNaStog.Replace(',', '.');
                            }

                            // uvijek zbog onog pravila kraćeg zapisa uzimamo ono što je zapisano na ekranu
                            stog += postaviNaStog;

                            stanjeNaZaslonu = evaluiraj(stog);

                            //stog = ""; // niti slučajno ne zaboraviti! :)
                            // zapravo, nećemo postaviti prazno, jer ćemo pustiti da se može dva puta kliknuti zaredom =
                        //}


                        //else if (BINARNI_OPERATORI.Contains(stog.Last())) // ako je posljednji znak binarni operator
                        //{
                        //    postaviNaStog = stanjeNaZaslonu; // ovaj će uvijek biti bez zareza, tako da na stog ide sa .
                        //    // moramo imati tu varijablu postaviNaStog, tako da se ne mijenja stanjeNaZaslonu
                        //    if (postaviNaStog.Contains(','))
                        //    {
                        //        postaviNaStog = postaviNaStog.Replace(',', '.');
                        //    }

                        //    // uvijek zbog onog pravila kraćeg zapisa uzimamo ono što je zapisano na ekranu
                        //    stog += postaviNaStog;

                        //    stanjeNaZaslonu = evaluiraj(stog);

                        //    //stog = ""; // niti slučajno ne zaboraviti! :)
                        //    // zapravo, nećemo postaviti prazno, jer ćemo pustiti da se može dva puta kliknuti zaredom =
                        //}
                        //else
                        //{ // ako zadnji znak nije binarni opetaror, to znači da se stisnulo dva puta "="
                        //    // moramo ga naći i zadnji binarni opetarotor i broj i to ponovno staviti!
                        //    int indexOperatora = 0;

                        //    for (int i = stog.Length - 1; i >= 0; i--)
                        //    {
                        //        if (BINARNI_OPERATORI.Contains(stog[i]))
                        //        {
                        //            indexOperatora = i;
                        //            break;
                        //        }
                        //    }

                        //    // ne mora se ništa evaluirati, nego se samo
                        //    stog += stog[indexOperatora] + stog.Substring(indexOperatora + 1); // dodaje se sve ovo na stog opet

                        //    stanjeNaZaslonu = evaluiraj(stog);

                            // ima puno još uvjeta koji nisu pokriveni, npr:
                            // zapis 2+3=+5= bi treblao dati 10, ali je problem nakon ovog jednako i kada se stisne +
                            // pa bi se stalno trebalo provjeravati 
                            // te npr ako je na zaslonu -E-, onda bi trebalo stalno to i ostati, bez obzira što se dalje radi
                            // i omogućiti samo da se napravi C ili on off tako nešto! - može se zahtjevati unarna operacija
                        //}



                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case ',':
                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {

                        // ako je zadnji znak jednak , ili ako već sadržava, onda nemoj napraviti ništa
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            // nemoj napraviti ništa!
                        }
                        else
                        {
                            stanjeNaZaslonu += inPressedDigit;
                        }

                        prikazanRezultat = false;
                    }
                    break;



                case 'M':
                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains('-')) // ako sadržava minus, on će uvijek biti na prvom mjestu, pa ga mičemo
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Substring(1);
                        }
                        else
                        {

                            if (stanjeNaZaslonu.Length == 1 && stanjeNaZaslonu[0] == '0')
                            { // ako je na zaslonu samo nula, taj preznak NE radi ništa!

                            }
                            else
                            {
                                stanjeNaZaslonu = '-' + stanjeNaZaslonu; // dodaje se napred
                            }
                        }
                    }


                    break;



                case 'S':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        // konvertirati sa zarezom u točku ako ima! i to poslati u sinus!
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        stanjeNaZaslonu = Math.Round(Math.Sin(Convert.ToDouble(stanjeNaZaslonu)), 9).ToString();

                        // vraćamo zarez
                        if (stanjeNaZaslonu.Contains('.'))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!

                    }
                    break;



                case 'K':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        stanjeNaZaslonu = Math.Round(Math.Cos(Convert.ToDouble(stanjeNaZaslonu)), 9).ToString();

                        // vraćamo zarez
                        if (stanjeNaZaslonu.Contains('.'))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case 'T':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        stanjeNaZaslonu = Math.Round(Math.Tan(Convert.ToDouble(stanjeNaZaslonu)), 9).ToString();

                        // vraćamo zarez!
                        if (stanjeNaZaslonu.Contains('.'))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case 'Q':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        // ovdje se moramo poslužiti malim trikom:
                        // dakle, ako cjelobrojni rezultat ima više od 10 znamenki, tek ONDA ćemo morati proglasiti -E-
                        // jer postoji mogućnost da sveukupni broj (cjelobrojni i decimalni) dio imaju više od 10
                        // znamenki i onda bi lessThanTenDigits vraćala false, a mi ne znamo koji dio je tu u pitanju
                        rezultat = Math.Pow(Convert.ToDouble(stanjeNaZaslonu), Convert.ToDouble(2));
                        cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));

                        if (cjelobrojniDio == 0)
                        {
                            brojZnamenkiCjelobrojnogDjela = 1;
                        }
                        else
                        {
                            brojZnamenkiCjelobrojnogDjela = (int)Math.Floor(Math.Log10(cjelobrojniDio) + 1);
                        }

                        if (brojZnamenkiCjelobrojnogDjela > 10)
                        {
                            stanjeNaZaslonu = "-E-";
                            stog = "";
                            prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                        }
                        else
                        {
                            stanjeNaZaslonu = Math.Round(rezultat, 10 - brojZnamenkiCjelobrojnogDjela).ToString();

                            // vraćamo zarez!
                            if (stanjeNaZaslonu.Contains('.'))
                            {
                                stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                            }
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case 'R':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        if (!stanjeNaZaslonu.Contains('-')) // ako je pozitivan broj
                        {
                            // ovdje znamo da NE možemo dobiti veći broj od početnog broja, ali nas svejedno zanima
                            // koliko znamenaka ima cjelobrojni dio, jer po njemu moramo round-ati
                            rezultat = Math.Sqrt(Convert.ToDouble(stanjeNaZaslonu));
                            cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));


                            if (cjelobrojniDio == 0)
                            {
                                brojZnamenkiCjelobrojnogDjela = 1;
                            }
                            else
                            {
                                brojZnamenkiCjelobrojnogDjela = (int)Math.Floor(Math.Log10(cjelobrojniDio) + 1);
                            }
                            // brojZnamenki sada sa sigurnošću znamo da ne može biti veći od 10, jer se radi korjenovanje
                            stanjeNaZaslonu = Math.Round(rezultat, 10 - brojZnamenkiCjelobrojnogDjela).ToString();

                            // vraćamo zarez!
                            if (stanjeNaZaslonu.Contains('.'))
                            {
                                stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                            }
                        }
                        else
                        {
                            stanjeNaZaslonu = "-E-";
                            stog = "";
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;



                case 'I': // ovo je kao kvadriranje, o dnosno, koristi se Math.Pow, ali umjesto 2 je -1 :)

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        if (stanjeNaZaslonu.Contains(','))
                        {
                            stanjeNaZaslonu = stanjeNaZaslonu.Replace(',', '.');
                        }

                        double brojNaZaslonu = Convert.ToDouble(stanjeNaZaslonu);

                        if (brojNaZaslonu == Convert.ToDouble(0))
                        {
                            stanjeNaZaslonu = "-E-";
                            stog = "";
                            prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                            break;
                        }

                        rezultat = Math.Pow(brojNaZaslonu, Convert.ToDouble(-1));
                        cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));

                        if (cjelobrojniDio == 0)
                        {
                            brojZnamenkiCjelobrojnogDjela = 1;
                        }
                        else
                        {
                            brojZnamenkiCjelobrojnogDjela = (int)Math.Floor(Math.Log10(cjelobrojniDio) + 1);
                        }

                        if (brojZnamenkiCjelobrojnogDjela > 10)
                        {
                            stanjeNaZaslonu = "-E-";
                            stog = "";
                            prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                        }
                        else
                        {
                            stanjeNaZaslonu = Math.Round(rezultat, 10 - brojZnamenkiCjelobrojnogDjela).ToString();

                            // vraćamo zarez!
                            if (stanjeNaZaslonu.Contains('.'))
                            {
                                stanjeNaZaslonu = stanjeNaZaslonu.Replace('.', ',');
                            }
                        }


                        prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    }
                    break;


                    // ovdje sam umjesto da se nadodaje na memoriju, zapravo se samo prebacuje ono što je na zaslonu!
                case 'P':

                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        memorija = stanjeNaZaslonu; // samo jednostavno preslikavanje
                    }
                    
                    //prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    // nemoj jer se još mogu dodavati znamenke i ne smije se resetirati!
                    break;



                case 'G':
                    if (!stanjeNaZaslonu.Equals("-E-"))
                    {
                        stanjeNaZaslonu = memorija;
                    }
                    // nisam siguran jel ide ovo za prikazanRezultat zastavica jer ako dohvaćamo iz memorije
                    // ne znam jel možemo mijenjati taj broj, ali mislim da možemo, tako da neću postaviti
                    // da je prikazanRezultat na true, jer se onda ne bi nadodavalo
                    //prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    break;



                case 'C':
                    
                    stanjeNaZaslonu = "0";
                    prikazanRezultat = true; // i tu je isto true, jer ne želimo da se nadodaje!

                    break;



                case 'O':
                    stog = "";
                    stanjeNaZaslonu = "0";
                    prikazanRezultat = true; // POSTAVLJANJE TE ZASTAVICE!
                    break;
            }
        }



        public string GetCurrentDisplayState()
        {
            return stanjeNaZaslonu;
        }


        private void resetirajStanjeNaZaslonu()
        {
            stanjeNaZaslonu = "0";
        }


        private bool isBinaryOperation(char znak)
        {
            if (BINARNI_OPERATORI.Contains(znak))
                return true;
            return false;
        }

        // zaslon može imati samo 10 znamenaka, ali može tu još i prikazivati i decimalni zarez, a i predznak
        // tako da moramo izračunati imali manje od 10 znamenaka
        private bool lessThanTenDigits(string zaslon)
        {
            int digitsCounter = numberOfDigits(zaslon);
            if (digitsCounter < 10)
                return true;
            else
                return false;

        }

        private int numberOfDigits(string zaslon)
        {
            int digitsCounter = 0;
            for (int i = 0; i < zaslon.Length; i++)
            {
                if (Char.IsNumber(zaslon[i]))
                {
                    digitsCounter++;
                }
            }

            return digitsCounter;

        }


        private string evaluiraj(string zapisStoga)
        {
            double rezultat = 0;

            if (String.IsNullOrEmpty(zapisStoga))
            {
                return "0";
            }

            else
            {
                bool prvoIteriranje = true;
                char operacija = '+'; // ovo je praktički samo defaultno postavljena
                int indexOperacije;
                double broj;

                while (!String.IsNullOrEmpty(zapisStoga))
                {


                    if (zapisStoga[0] == '-')
                    {
                        indexOperacije = indexSljedecegBinarnogOperatora(zapisStoga.Substring(1));
                        if (prvoIteriranje)
                        {
                            if (indexOperacije == -1) // gotovo je
                            {
                                rezultat = Convert.ToDouble(zapisStoga.Substring(1)); // ne uzimamo onu jedinicu na početku
                                rezultat *= -1;
                                break;
                            }
                            else // postoji još jedan binarni znak (sjeti se da poslije njega sigurno postoji još jedan broj, zbog onog skraćivanja)
                            {
                                rezultat = Convert.ToDouble(zapisStoga.Substring(1, indexOperacije)); // krećemo opet od 1, pa je to dobar index!
                                rezultat *= -1;
                                operacija = zapisStoga[indexOperacije+1]; // jer smo kretali od substring 1
                                zapisStoga = zapisStoga.Substring(indexOperacije + 1 + 1);

                                prvoIteriranje = false;
                            }
                        }
                            
                        else // nije prvo iteriranje i to znači da imamo operaciju!
                        {
                            // ovo je index sljedeće operacije!
                            if (indexOperacije == -1) // nema ga, znači samo napravimo ovo evaluiranje i gotovi smo!
                            {
                                broj = Convert.ToDouble(zapisStoga.Substring(1));
                                broj *= -1;

                                // tako da se ne može dijeliti sa nulom!
                                if (operacija.Equals('-') && broj == Convert.ToDouble(0))
                                {
                                    return "-E-";
                                }

                                rezultat = izracunajOperaciju(operacija, rezultat, broj);
                                double cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));
                                int brojZnamenki;

                                // OBAVEZNO OVAKO PROVJERITI jer se može dogoditi da rezultat bude 0.000..1 i onda onaj
                                // log vraća lude rezultate, 
                                if (cjelobrojniDio == Convert.ToDouble(0))
                                {
                                    brojZnamenki = 1;
                                }
                                else
                                {
                                    brojZnamenki = brojCjelobrojnihZnamenki(cjelobrojniDio);
                                }

                                if (brojZnamenki > 10)
                                {
                                    return "-E-";
                                }
                                else
                                {
                                    rezultat = Math.Round(rezultat, 10 - brojZnamenki);
                                    break;
                                }
                            }
                            else
                            {
                                broj = Convert.ToDouble(zapisStoga.Substring(1, indexOperacije)); // krećemo od 1 pa je to dobar index!
                                broj *= -1;

                                // tako da se ne može dijeliti sa nulom!
                                if (operacija.Equals('-') && broj == Convert.ToDouble(0))
                                {
                                    return "-E-";
                                }

                                rezultat = izracunajOperaciju(operacija, rezultat, broj);
                                double cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));
                                int brojZnamenki;

                                // OBAVEZNO OVAKO PROVJERITI jer se može dogoditi da rezultat bude 0.000..1 i onda onaj
                                // log vraća lude rezultate, 
                                if (cjelobrojniDio == Convert.ToDouble(0))
                                {
                                    brojZnamenki = 1;
                                }
                                else
                                {
                                    brojZnamenki = brojCjelobrojnihZnamenki(cjelobrojniDio);
                                }

                                if (brojZnamenki > 10)
                                {
                                    return "-E-";
                                }
                                else
                                {
                                    rezultat = Math.Round(rezultat, 10 - brojZnamenki);
                                    
                                    // pripremanje za dalje
                                    operacija = zapisStoga[indexOperacije + 1]; // zbog početnog minusa
                                    zapisStoga = zapisStoga.Substring(indexOperacije + 1 + 1); // +1 zato jer smo tražili index od 1 i još jedan +1 jer želimo preskočiti taj predznak
                                }
                            }
                        }
                    }

                    // SLJEDEĆI BROJ  NIJE NEGATIVAN!
                    else
                    {
                        indexOperacije = indexSljedecegBinarnogOperatora(zapisStoga);
                        if (prvoIteriranje)
                        {
                            if (indexOperacije == -1) // gotovo je
                            {
                                rezultat = Convert.ToDouble(zapisStoga);
                                break;
                            }
                            else // postoji još jedan binarni znak (sjeti se da poslije njega sigurno postoji još jedan broj, zbog onog skraćivanja)
                            {
                                rezultat = Convert.ToDouble(zapisStoga.Substring(0, indexOperacije));
                                operacija = zapisStoga[indexOperacije];
                                zapisStoga = zapisStoga.Substring(indexOperacije + 1);

                                prvoIteriranje = false;
                            }
                        }
                            
                        else // nije prvo iteriranje i to znači da imamo operaciju!
                        {
                            // ovo je index sljedeće operacije!
                            if (indexOperacije == -1) // nema ga, znači samo napravimo ovo evaluiranje i gotovi smo!
                            {
                                broj = Convert.ToDouble(zapisStoga);

                                // tako da se ne može dijeliti sa nulom!
                                if (operacija.Equals('/') && broj == Convert.ToDouble(0))
                                {
                                    return "-E-";
                                }

                                rezultat = izracunajOperaciju(operacija, rezultat, broj);
                                double cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));
                                int brojZnamenki;

                                // OBAVEZNO OVAKO PROVJERITI jer se može dogoditi da rezultat bude 0.000..1 i onda onaj
                                // log vraća lude rezultate, 
                                if (cjelobrojniDio == Convert.ToDouble(0))
                                {
                                    brojZnamenki = 1;
                                }
                                else
                                {
                                    brojZnamenki = brojCjelobrojnihZnamenki(cjelobrojniDio);
                                }

                                if (brojZnamenki > 10)
                                {
                                    return "-E-";
                                }
                                else
                                {
                                    rezultat = Math.Round(rezultat, 10 - brojZnamenki);
                                    break;
                                }
                            }
                            else
                            {
                                broj = Convert.ToDouble(zapisStoga.Substring(0, indexOperacije));

                                // tako da se ne može dijeliti sa nulom!
                                if (operacija.Equals('/') && broj == Convert.ToDouble(0))
                                {
                                    return "-E-";
                                }

                                rezultat = izracunajOperaciju(operacija, rezultat, broj);

                                double cjelobrojniDio = Math.Abs(Math.Round(rezultat, 0));
                                int brojZnamenki;

                                // OBAVEZNO OVAKO PROVJERITI jer se može dogoditi da rezultat bude 0.000..1 i onda onaj
                                // log vraća lude rezultate, 
                                if (cjelobrojniDio == Convert.ToDouble(0))
                                {
                                    brojZnamenki = 1;
                                }
                                else
                                {
                                    brojZnamenki = brojCjelobrojnihZnamenki(cjelobrojniDio);
                                }


                                if (brojZnamenki > 10)
                                {
                                    return "-E-";
                                }
                                else
                                {
                                    rezultat = Math.Round(rezultat, 10 - brojZnamenki);
                                    
                                    // pripremanje za dalje
                                    operacija = zapisStoga[indexOperacije];
                                    zapisStoga = zapisStoga.Substring(indexOperacije+1);
                                }
                            }
                        }
                    }

                }
            }

            string rezultatString = rezultat.ToString(); // ovo miče nepotrebne nule! :) - tipa u primjeru 2,0=
            rezultatString = rezultatString.Replace('.',',');
            
            return rezultatString;
        }


        private int indexSljedecegBinarnogOperatora(string dioStoga)
        {
            for (int i = 0; i < dioStoga.Length; i++)
            {
                if (BINARNI_OPERATORI.Contains(dioStoga[i]))
                {
                    return i;
                }
            }

            return -1; // nije pronasao!
        }


        private double izracunajOperaciju(char operacija, double rezultat, double broj)
        {
            switch (operacija)
            {
                case '+':
                    rezultat += broj;
                    break;
                case '-':
                    rezultat -= broj;
                    break;
                case '*':
                    rezultat *= broj;
                    break;
                case '/':
                    rezultat /= broj;
                    break;
            }
            
            return rezultat;
        }


        private int brojCjelobrojnihZnamenki(double broj)
        {
            return (int) Math.Floor(Math.Log10(broj) + 1);
        }

    }

}
