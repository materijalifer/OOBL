﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
     {
         public static IStockExchange CreateStockExchange()
         {
             return new StockExchange();
         }
     }

     public class StockPrice
     {
         private DateTime validFrom;
         private DateTime validTo;
         private decimal amount;

         public DateTime ValidFrom
         {
             get { return validFrom; }
             set { validFrom = value; }
         }

         public DateTime ValidTo
         {
             get { return validTo; }
             set { validTo = value; }
         }

         public decimal Value
         {
             get { return amount; }
             set { amount = value; }
         }
     }

     public class Stock
     {
         private string stockName;
         private long inNumberOfShares;
         private DateTime inTimeStamp;

         public string StockName
         {
             get { return stockName; }
             set { stockName = value; }
         }

         public long InNumberOfShares
         {
             get { return inNumberOfShares; }
             set { inNumberOfShares = value; }
         }

         public DateTime InTimeStamp
         {
             get { return inTimeStamp; }
             set { inTimeStamp = value; }
         }

         public List<StockPrice> priceList = new List<StockPrice>();
     }

     public class Portfolio
     {
         private string id;

         public string Id
         {
             get { return id; }
             set { id = value; }
         }

         public Dictionary<Stock, int> stocks = new Dictionary<Stock, int>();
     }

     public class Index
     {
         private string indexName;
         private IndexTypes indexType;
         public List<Stock> stockList = new List<Stock>();

         public string IndexName
         {
             get { return indexName; }
             set { indexName = value; }
         }

         public IndexTypes IndexType
         {
             get { return indexType; }
             set { indexType = value; }
         }

     }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stockList = new List<Stock>();
         private List<Index> indexList = new List<Index>();
         private List<Portfolio> portfolioList = new List<Portfolio>();

         public Stock getStock(string inStockName)
         {
             foreach (Stock stock in stockList)
             {
                 if (System.String.Compare(stock.StockName, inStockName, true) == 0) // case insensitive
                     return stock;
             }
             return null;
         }

         public Index getIndex(string indexName)
         {
             foreach (Index index in indexList)
             {
                 if (System.String.Compare(index.IndexName, indexName, true) == 0) // case insensitive
                     return index;
             }
             return null;
         }

         public Portfolio getPortfolio(string portfolioId)
         {
             foreach (Portfolio portfolio in portfolioList)
             {
                 if (portfolio.Id == portfolioId) // case sensitive
                     return portfolio;
             }
             return null;
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             // provjeri da li stock vec postoji
             if (this.StockExists(inStockName))
                 throw new StockExchangeException("Stock vec postoji");

             if (inInitialPrice < 0)
                 throw new StockExchangeException("Cijena mora biti veca od 0");

             Stock stock = new Stock();

             stock.StockName = inStockName;
             stock.InNumberOfShares = inNumberOfShares;

             // pocetna cijena, prva u listi, vrijedi do +besk
             StockPrice price = new StockPrice();
             price.ValidFrom = inTimeStamp;
             price.ValidTo = new DateTime(9999, 1, 1, 00, 00, 00);
             price.Value = inInitialPrice;

             stock.priceList.Add(price);
             stockList.Add(stock);
             
         }

         public void DelistStock(string inStockName)
         {
             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             stockList.Remove(stock);

             // makni dionicu iz svih indeksa
             foreach(Index index in indexList)
                 if (IsStockPartOfIndex(index.IndexName, stock.StockName))
                     RemoveStockFromIndex(index.IndexName, stock.StockName);

             // makni dionicu iz svih portfolia
             foreach(Portfolio portfolio in portfolioList)
                 if (IsStockPartOfPortfolio(portfolio.Id, stock.StockName))
                     RemoveStockFromPortfolio(portfolio.Id, stock.StockName);
         }

         public bool StockExists(string inStockName)
         {
             Stock stock = getStock(inStockName);

             if (stock != null)
                 return true;
             else
                 return false;
         }

         public int NumberOfStocks()
         {
             return stockList.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             // provjeriti da li vec postoji taj trenutak
             foreach (StockPrice tempPrice in stock.priceList)
                 if (tempPrice.ValidFrom == inTimeStamp)
                     throw new StockExchangeException("Taj trenutak vec postoji");

             StockPrice price = new StockPrice();
             price.ValidFrom = inTimeStamp;
             price.ValidTo = new DateTime(9999, 1, 1, 00, 00, 00);
             price.Value = inStockValue;

             // prethodna cijena vrijedi do definicije nove
             StockPrice previousPrice = stock.priceList.Last();
             previousPrice.ValidTo = inTimeStamp;

             stock.priceList.Add(price);

         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             foreach (StockPrice price in stock.priceList)
                 if ((inTimeStamp > price.ValidFrom) && (inTimeStamp < price.ValidTo))
                     return price.Value;

             throw new StockExchangeException("Cijena ne postoji.");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             if (stock.priceList.Count > 0)
                 return stock.priceList[0].Value;
             else
                 throw new StockExchangeException("Cijena nije definirana");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             if (stock.priceList.Count > 0)
                 return stock.priceList.Last().Value;
             else
                 throw new StockExchangeException("Cijena nije definirana");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             // indeks nepoznatog tipa
             if ((inIndexType != IndexTypes.AVERAGE) && (inIndexType != IndexTypes.WEIGHTED)) 
                 throw new StockExchangeException("Indeks nepoznatog tipa");

             // index vec postoji
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks vec postoji");

             Index index = new Index();

             index.IndexName = inIndexName;
             index.IndexType = inIndexType;

             indexList.Add(index);

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index = getIndex(inIndexName);

             if (index == null)
                 throw new StockExchangeException("Indeks ne postoji");

             // provjeriti da li je dionica vec u indexu
             if (index.stockList.Contains(getStock(inStockName)))
                 throw new StockExchangeException("Stock vec postoji u indeksu");

             index.stockList.Add(getStock(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = getIndex(inIndexName);

             if (index == null)
                 throw new StockExchangeException("Indeks ne postoji");

             if (index.stockList.Contains(getStock(inStockName)))
                 index.stockList.Remove(getStock(inStockName));
             else
                 throw new StockExchangeException("Stock ne postoji");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = getIndex(inIndexName);

             if (index == null)
                 throw new StockExchangeException("Indeks ne postoji");

             Stock stock = getStock(inStockName);

             if (index.stockList.Contains(stock))
                 return true;
             else
                 return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = getIndex(inIndexName);

             if (index == null)
                 throw new StockExchangeException("Indeks ne postoji");

             if (index.IndexType == IndexTypes.AVERAGE)
             {
                 decimal totalStockValue = 0;
                 decimal average = 0;

                 // prvo nadji ukupnu vrijednost svih dionica unutar indexa
                 foreach (Stock stock in index.stockList)
                     totalStockValue += stock.priceList.Last().Value * stock.InNumberOfShares;

                 average = (totalStockValue / index.stockList.Count);

                 return Math.Round(average, 3);
             }
             else if (index.IndexType == IndexTypes.WEIGHTED)
             {
                 decimal totalStockValue = 0;
                 decimal weight = 0;
                 decimal average = 0;

                 // prvo nadji ukupnu vrijednost svih dionica unutar indexa
                 foreach (Stock stock in index.stockList)
                     totalStockValue += stock.priceList.Last().Value * stock.InNumberOfShares;

                 // onda nadji weight i zbroji u average
                 foreach (Stock stock in index.stockList)
                 {
                     weight = (stock.priceList.Last().Value * stock.InNumberOfShares) / totalStockValue;
                     average += weight * stock.priceList.Last().Value;
                 }

                 return Math.Round(average, 3);
             }
             else
                 throw new StockExchangeException("Indeks nepoznatog tipa");
         }

         public bool IndexExists(string inIndexName)
         {
             Index index = getIndex(inIndexName);

             if (index != null)
                 return true;
             else
                 return false;
         }

         public int NumberOfIndices()
         {
             return indexList.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = getIndex(inIndexName);

             if (index != null)
                return index.stockList.Count();
             else
                throw new StockExchangeException("Indeks ne postoji");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             // provjeri da li postoji portfolio sa tim id-em
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio vec postoji.");

             Portfolio portfolio = new Portfolio();
             portfolio.Id = inPortfolioID;

             portfolioList.Add(portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             // ako portfolio sadrzi dionice zbroji nove u postojece
             if (portfolio.stocks.ContainsKey(stock))
                 portfolio.stocks[stock] += numberOfShares;
             
             // inace, dodaj nove dionice
             else
                portfolio.stocks.Add(stock, numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             // ako je broj dionica koji micemo jednak broju dionica u portfoliu makni cijelu dionicu
             if (portfolio.stocks[stock] == numberOfShares)
                 portfolio.stocks.Remove(stock);

             // inace oduzmi odgovarajuci broj dionica
             else
                 portfolio.stocks[stock] -= numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             Stock stock = getStock(inStockName);

             if (stock == null)
                 throw new StockExchangeException("Stock ne postoji");

             portfolio.stocks.Remove(stock);
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             return portfolio.stocks.Count();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 return false;
             else
                 return true;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             if (portfolio.stocks.ContainsKey(getStock(inStockName)))
                 return true;
             else
                 return false;
             
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             if (portfolio.stocks.ContainsKey(getStock(inStockName)))
                return portfolio.stocks[getStock(inStockName)];
             else
                 throw new StockExchangeException("Stock ne postoji.");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             decimal currentValue = 0;

             foreach (KeyValuePair<Stock, int> stock in portfolio.stocks)
                 foreach (StockPrice price in stock.Key.priceList)
                     if ((timeStamp >= price.ValidFrom) && (timeStamp <= price.ValidTo))
                         currentValue += price.Value * stock.Value;

             return currentValue;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Portfolio ne postoji.");

             decimal startValue = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00));
             decimal endValue = 0;

             // ovisno o mjesecu i godini odredi konacni datum
             if ((Month == 1) || (Month == 3) || (Month == 5) || (Month == 7) || (Month == 8) || (Month == 10) || (Month == 12))
                 endValue = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 31, 23, 59, 999));
             else if ((Month == 4) || (Month == 6) || (Month == 9) || (Month == 11))
                 endValue = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 30, 23, 59, 999));
             else if (Month == 2)
             {
                 bool isLeapYear = false;

                 // ispitivanje da li je godina prijestupna
                 if (Year % 4 == 0)
                     if (Year % 100 == 0)
                         if (Year % 400 == 0)
                             isLeapYear = true;
                         else
                             isLeapYear = false;
                     else
                         isLeapYear = true;
                 else
                     isLeapYear = false;

                 // ako je prijestupna veljaca ima 29 dana
                 if (isLeapYear)
                     endValue = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 29, 23, 59, 999));
                 else
                     endValue = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 28, 23, 59, 999));
             }
             else
                 throw new StockExchangeException("Nepostojeci mjesec.");

             return Math.Round(((endValue - startValue) / startValue) * 100, 3);
         }
     }
}
