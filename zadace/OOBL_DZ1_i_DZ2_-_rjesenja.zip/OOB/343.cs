﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockPrice
    {
        private Decimal price;
        public Decimal Price
        {
            get { return this.price; }
            set { this.price = value; }
        }

        private DateTime priceTimeStamp;
        public DateTime PriceTimeStamp
        {
            get { return this.priceTimeStamp; }
            set { this.priceTimeStamp = value; }
        }

        public StockPrice(Decimal price, DateTime priceTimeStamp)
        {
            if (price <= 0)
            {
                throw new StockExchangeException("Stock price must be positive number");
            }
            this.price = price;
            this.priceTimeStamp = priceTimeStamp;
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() != typeof(StockPrice)) return false;

            StockPrice sp = (StockPrice) obj;
            if (this.priceTimeStamp.Equals(sp.PriceTimeStamp))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class Stock
    {
        private string stockName;
        public string StockName
        {
            get { return this.stockName; }
            set { this.stockName = value; }
        }

        private long numberOfStocks;
        public long NumberOdStock
        {
            get { return this.numberOfStocks; }
            set { this.numberOfStocks = value; }
        }

        private StockPrice startingPrice;
        public StockPrice StartingPrice
        {
            get { return this.startingPrice; }
            set { this.startingPrice = value; }
        }

        private List<StockPrice> prices;
 
        public void AddPrice(StockPrice stockPrice)
        {
            foreach (StockPrice sp in prices)
            {
                if(sp.Equals(stockPrice)) throw new StockExchangeException("A stock price is already added fot that date time.");
            }
            this.prices.Add(stockPrice);
        }

        public StockPrice GetPriceByTime(DateTime timeStamp)
        {
            StockPrice closestLowerStockPrice = this.StartingPrice;
            StockPrice lowestStockPrice = this.startingPrice;
            foreach (StockPrice sp in prices)
            {
                if (sp.PriceTimeStamp > timeStamp)
                {
                    continue;
                }
                if (sp.PriceTimeStamp > closestLowerStockPrice.PriceTimeStamp && sp.PriceTimeStamp <= timeStamp)
                {
                    closestLowerStockPrice = sp;
                }

                if (lowestStockPrice.PriceTimeStamp > sp.PriceTimeStamp)
                {
                    lowestStockPrice = sp;
                }
            }

            if(timeStamp < lowestStockPrice.PriceTimeStamp) throw new StockExchangeException("The stock was not created by that time.");

            return closestLowerStockPrice;
        }

        public StockPrice GetLatestPrice()
        {
            StockPrice latestStockPrice = this.startingPrice;
            foreach (StockPrice sp in this.prices)
            {
                if (latestStockPrice.PriceTimeStamp < sp.PriceTimeStamp)
                {
                    latestStockPrice = sp;
                }
            }
            return latestStockPrice;
        }

        public Stock(string stockName, long numberOfStocks, Decimal price, DateTime timeStamp)
        {
            StockPrice sp = new StockPrice(price, timeStamp);
            this.startingPrice = sp;
            prices = new List<StockPrice>();
            prices.Add(this.startingPrice);
            this.stockName = stockName;
            this.numberOfStocks = numberOfStocks;
        }


        public override bool Equals(object obj)
        {
            if (obj.GetType() != typeof (Stock))
            {
                return false;
            }

            Stock s = (Stock) obj;

            if (this.stockName.ToLower().Equals(s.StockName.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override int  GetHashCode()
        {
            return this.StockName.GetHashCode();
        }


        internal decimal GetStartinPrice()
        {
            StockPrice firstStockPrice = this.startingPrice;
            foreach (StockPrice sp in this.prices)
            {
                if (firstStockPrice.PriceTimeStamp > sp.PriceTimeStamp)
                {
                    firstStockPrice = sp;
                }
            }
            return firstStockPrice.Price;
        }
    }

    public class Portfolio
    {
        private string id;
        public string ID
        {
            get { return this.id; }
            set { this.id = value; }
        }

        public Portfolio(string id)
        {
            this.id = id;
            this.stocks = new Dictionary<Stock, int>();
        }

        private Dictionary<Stock, int> stocks; 

        public void AddStock(Stock stock, int numberOfShares)
        {
            if(numberOfShares <= 0) throw new StockExchangeException("A number of stocks must be postive number.");
            if (stocks.ContainsKey(stock))
            {
                if (numberOfShares + stocks[stock] > stock.NumberOdStock)
                {
                    throw new StockExchangeException("You can not add that many stocks.");
                }
                else
                {
                    stocks[stock] = stocks[stock] + numberOfShares;
                }
            }
            else
            {
                if (stock.NumberOdStock < numberOfShares)
                {
                    throw new StockExchangeException("You can not add that many stocks.");
                }
                else
                {
                    stocks.Add(stock, numberOfShares);
                }
            }
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            if (stocks.ContainsKey(stock))
            {
                if (stocks[stock] - numberOfShares <= 0)
                {
                    stocks.Remove(stock);
                }
                else
                {
                    stocks[stock] = stocks[stock] - numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio does not contain that stock");
            }
        }

        public int GetNumberOfStocks()
        {
            return stocks.Count;
        }

        public int GetNumberOfStockShares(Stock stock)
        {
            if (stocks.ContainsKey(stock))
            {
                return stocks[stock];
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in portfolio.");
            }

        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal price = 0;
            foreach (Stock stock in stocks.Keys.ToList())
            {
                price = price + stocks[stock]*stock.GetPriceByTime(timeStamp).Price;
            }
            return price;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            if(stocks.Count == 0) return 0;

            decimal startingPrice = 0;
            decimal endingPrice = 0;
            foreach (Stock stock in stocks.Keys.ToList())
            {
                DateTime startDate = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                startingPrice = startingPrice + stock.GetPriceByTime(startDate).Price;

                DateTime endDate = new DateTime(Year, Month+1, 1, 23, 59, 59, 999);
                endDate.AddMonths(-1);
                endingPrice = endingPrice + stock.GetPriceByTime(endDate).Price;

            }

            return (endingPrice - startingPrice) / startingPrice * 100;
        }

        public List<Stock> GetStocks()
        {
            return this.stocks.Keys.ToList();
        }
    }

    public abstract class Index
    {
        private string name;
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        protected List<Stock> stocks;
        
        public void AddStock(Stock stock)
        {
            foreach (Stock s in this.stocks)
            {
                if (s.Equals(stock)) throw new StockExchangeException("dionica vec postoji u indexu");
            }
            stocks.Add(stock);
        } 
        public void RemoveStock(Stock stock)
        {
            foreach (Stock s in this.stocks)
            {
                if (s.Equals(stock))
                {
                    stocks.Remove(stock);
                    return;
                }
            }
            throw new StockExchangeException("dionica ne postoji u indexu.");
        }

        public int GetNumberOfStocks()
        {
            return stocks.Count;
        }

        public List<Stock> GetStocks()
        {
            return this.stocks;
        }

        public abstract decimal GetIndexValue(DateTime inTimeStamp);
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string name)
        {
            this.Name = name;
            this.stocks = new List<Stock>();
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal indexValue = 0;
            if (stocks.Count == 0) return 0;
            foreach (Stock stock in stocks)
            {
                indexValue = indexValue + stock.GetPriceByTime(inTimeStamp).Price;
            }
            return indexValue/stocks.Count;
        }
    }

    public class WightedIndex : Index
    {
        public WightedIndex(string name)
        {
            this.Name = name;
            this.stocks = new List<Stock>();
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal totalValue = 0;
            foreach (Stock stock in stocks)
            {
                totalValue = totalValue + stock.NumberOdStock * stock.GetPriceByTime(inTimeStamp).Price;
            }

            decimal factor = 0;
            foreach (Stock stock in stocks)
            {
                factor = factor + ((stock.NumberOdStock*stock.GetPriceByTime(inTimeStamp).Price)/totalValue) * (stock.GetPriceByTime(inTimeStamp).Price);
            }
            return factor;
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Index> indexes;
        private List<Stock> stocks;
        private List<Portfolio> portfolios; 
 
        public StockExchange()
        {
            this.indexes = new List<Index>();
            this.stocks = new List<Stock>();
            this.portfolios = new List<Portfolio>();
        }
        
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             foreach (Stock s in stocks)
             {
                 if(s.StockName.ToLower().Equals(inStockName.ToLower())) throw new StockExchangeException("There already exists stock by that name");
             }
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(stock);
         }

         public void DelistStock(string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (s.StockName.ToLower().Equals(inStockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock != null)
             {
                 foreach (Index index in indexes)
                 {
                     if (IsStockPartOfIndex(index.Name, stock.StockName))
                     {
                         RemoveStockFromIndex(index.Name, stock.StockName);
                     }
                 }
                 foreach(Portfolio portfolio in portfolios)
                 {
                     if (IsStockPartOfPortfolio(portfolio.ID, stock.StockName))
                     {
                         RemoveStockFromPortfolio(portfolio.ID, stock.StockName);
                     }
                 }
                 stocks.Remove(stock);
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock s in stocks)
             {
                 if (s.StockName.ToLower().Equals(inStockName.ToLower()))
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return this.stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock != null)
             {
                 stock.AddPrice(new StockPrice(inStockValue, inIimeStamp));
             }
             else
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock != null)
             {
                 return stock.GetPriceByTime(inTimeStamp).Price;
             }
             else
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock != null)
             {
                 return stock.GetStartinPrice();
             }
             else
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock != null)
             {
                 return stock.GetLatestPrice().Price;
             }
             else
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("An index by that name already exists.");
             }
             else
             {
                 Index index = null;
                 switch (inIndexType)
                 {
                    case IndexTypes.AVERAGE :
                        index = new AverageIndex(inIndexName);
                        break;
                    case IndexTypes.WEIGHTED :
                        index = new WightedIndex(inIndexName);
                        break;
                    default :
                        throw new StockExchangeException("Cannon create index. Type of index not supported.");
                        break;
                 }   
                 indexes.Add(index);
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
             Index index = null;
             foreach (Index i in indexes)
             {
                 if (inIndexName.ToLower().Equals(i.Name.ToLower()))
                 {
                     index = i;
                     break;
                 }
             }
             if (index == null)
             {
                 throw new StockExchangeException("An index by that name does not exist.");
             }

             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
             Index index = null;
             foreach (Index i in indexes)
             {
                 if (inIndexName.ToLower().Equals(i.Name.ToLower()))
                 {
                     index = i;
                     break;
                 }
             }
             if (index == null)
             {
                 throw new StockExchangeException("An index by that name does not exist.");
             }

             index.RemoveStock(stock);
         }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stock = null;
            foreach (Stock s in stocks)
            {
                if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                {
                    stock = s;
                    break;
                }
            }
            if (stock == null)
            {
                throw new StockExchangeException("A stock by that name does not exist.");
            }
            Index index = null;
            foreach (Index i in indexes)
            {
                if (inIndexName.ToLower().Equals(i.Name.ToLower()))
                {
                    index = i;
                    break;
                }
            }
            if (index == null)
            {
                throw new StockExchangeException("An index by that name does not exist.");
            }
            List<Stock> indexesStocks = index.GetStocks();
            foreach (Stock st in indexesStocks)
            {
                if (st.Equals(stock))
                {
                    return true;
                }
            }

            return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = null;
             foreach (Index i in indexes)
             {
                 if (inIndexName.ToLower().Equals(i.Name.ToLower()))
                 {
                     index = i;
                     break;
                 }
             }
             if (index != null)
             {
                 return index.GetIndexValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("An index by that name does not exist.");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index i in indexes)
             {
                 if (i.Name.ToLower().Equals(inIndexName.ToLower()))
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return this.indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = null;
             foreach (Index i in indexes)
             {
                 if (inIndexName.ToLower().Equals(i.Name.ToLower()))
                 {
                     index = i;
                     break;
                 }
             }
             if (index != null)
             {
                 return index.GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("An index by that name does not exist.");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("portfolio by that name already exists.");
             }
             else
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 portfolios.Add(portfolio);
             }
            
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }

             portfolio.AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }

             portfolio.RemoveStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }

             portfolio.RemoveStock(stock, Convert.ToInt32(stock.NumberOdStock));
         }

         public int NumberOfPortfolios()
         {
             return this.portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio != null)
             {
                 return portfolio.GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("A portfolio by that name does not exist.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio p in portfolios)
             {
                 if (p.ID.Equals(inPortfolioID))
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("A portfolio by that name does not exist.");
             }
             List<Stock> portfolioStocks = portfolio.GetStocks();
             foreach (Stock st in portfolioStocks)
             {
                 if (st.Equals(stock))
                 {
                     return true;
                 }
             }

             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }
             Stock stock = null;
             foreach (Stock s in stocks)
             {
                 if (inStockName.ToLower().Equals(s.StockName.ToLower()))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("A stock by that name does not exist.");
             }

             return portfolio.GetNumberOfStockShares(stock);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }

             return portfolio.GetPortfolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = null;
             foreach (Portfolio p in portfolios)
             {
                 if (inPortfolioID.Equals(p.ID))
                 {
                     portfolio = p;
                     break;
                 }
             }
             if (portfolio == null)
             {
                 throw new StockExchangeException("Portfolio by that ID does not exist.");
             }

             return portfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
         }
     }
}
