﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class SuperCalculator : ICalculator
    {
        private const int MAX_CHAR = 10;
        private const string ERR_MSG = "-E-";

        private double lastState;
        private double curState;
        private double multipleEqualsLastState;
        private string display;
        private double memory;
        private char lastOperator;
        private char lastChar;

        private Dictionary<char, Func<double,double,double> > binFunctions;
        private Dictionary<char, Func<double, double>> unFunctions;
        private Dictionary<char, Func<bool>> memFunctions;
        private char[] binaryChars;
        private char[] unaryChars;
        private char[] memoryChars;

        public SuperCalculator()
        {
            binaryChars = new char[] { '+', '-', '*', '/' };
            unaryChars = new char[] { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
            memoryChars = new char[] { 'P', 'G' };

            binFunctions = new Dictionary<char, Func<double, double, double>>();
            binFunctions.Add('+', BinaryOperator.Add);
            binFunctions.Add('-', BinaryOperator.Subtract);
            binFunctions.Add('*', BinaryOperator.Multiply);
            binFunctions.Add('/', BinaryOperator.Devide);

            unFunctions = new Dictionary<char, Func<double, double>>();
            unFunctions.Add('M', UnaryOperator.Minus);
            unFunctions.Add('S', UnaryOperator.Sin);
            unFunctions.Add('K', UnaryOperator.Cos);
            unFunctions.Add('T', UnaryOperator.Tan);
            unFunctions.Add('Q', UnaryOperator.Square);
            unFunctions.Add('R', UnaryOperator.Sqrt);
            unFunctions.Add('I', UnaryOperator.Inverse);

            memFunctions = new Dictionary<char, Func<bool>>();
            memFunctions.Add('P', putMemory);
            memFunctions.Add('G', getMemory);

            Reset();
        }

        public void Reset()
        {
            Clear();
            memory = 0;
            curState = 0;
            lastState = 0;
            lastOperator = ' ';
            lastChar = ' ';
            multipleEqualsLastState = 0;
        }

        public void Clear()
        {            
            display = "0";
        }

        public void Equals()
        {   
            
            if (Array.IndexOf(binaryChars, lastChar) >= 0)
            {
                multipleEqualsLastState = curState; // for inputs like =,=,=,=,=,=,=,=,=,=,=
                curState = binFunctions[lastChar](curState, curState);
            }
            else if (lastChar == '=')
            {
                if( lastOperator!=' ')
                {
                    curState = binFunctions[lastOperator](multipleEqualsLastState, curState);
                }
            }
            else if (Array.IndexOf(binaryChars, lastOperator) >= 0)
            {
                multipleEqualsLastState = curState;
                curState = binFunctions[lastOperator](lastState, curState);
            }
            else
            {
                //ništa
            }
            
            StateToDisplay();
        }

        public bool DisplayToState()
        {
            if( string.IsNullOrEmpty(display)  )
            {
                curState = 0;
                return true;
            }
            else if(display != ERR_MSG)
            {
                curState = double.Parse(display);
                return true;
            }
            else
            {
                return false;
            }            
        }
        public void StateToDisplay()
        {
            if( !double.IsInfinity(curState) )
            {
                display = curState.ToString();
                if (display.Replace(',', '\r').Replace('-', '\r').Length > MAX_CHAR)
                {
                    display = Math.Round( curState, MAX_CHAR-(int)Math.Floor( Math.Abs(curState/10))-1 ).ToString();
                }
            }
            else
            {
                display = ERR_MSG;
            }                        
        }
        public void Press(char inPressedDigit)
        {
            if(!DisplayToState())
            {
                Reset();          
            }

            int num;
            if ( int.TryParse(inPressedDigit.ToString(), out num)  )
            {
                numDisplay(inPressedDigit);
            }
            else if ( inPressedDigit == ',' )
            {
                numDisplay(inPressedDigit);
            }            
            else if (Array.IndexOf(unaryChars, inPressedDigit) >= 0)
            {
                curState = unFunctions[inPressedDigit](curState);
                //lastOperator = inPressedDigit;
                StateToDisplay();
            }
            else if (Array.IndexOf(binaryChars, inPressedDigit) >= 0)
            {
                if (lastOperator != ' ' && Array.IndexOf(binaryChars, lastChar) < 0)
                {
                    Equals();
                }
                DisplayToState();
                StateToDisplay();
                lastState = curState;
                lastOperator = inPressedDigit;
            }
            else if (Array.IndexOf(memoryChars, inPressedDigit) >= 0)
            {
                memFunctions[inPressedDigit]();
            }
            else if (inPressedDigit == '=')
            {
                Equals();
            }
            else if (inPressedDigit == 'C')
            {
                Clear();
            }
            else if (inPressedDigit == 'O')
            {
                Reset();
            }
            else
            {
                display = ERR_MSG;
            }
            
            lastChar = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }



        public void FormatDisplay()
        {
            display = curState.ToString();
        }

        public void numDisplay(char inPressedDigit)
        {
            if (Array.IndexOf(binaryChars, lastChar) >= 0)
            {
                display = inPressedDigit.ToString();
            }
            else if (lastChar == '=')
            {
                display = inPressedDigit.ToString();
            }
            else if (display == "0" || Array.IndexOf(unaryChars, lastChar) >= 0)
            {
                display = inPressedDigit.ToString();
            }
            else
            {
                display += inPressedDigit;
            }
        }


        public bool putMemory()
        {
            memory = curState;
            return true;
        }

        public bool getMemory()
        {
            curState = memory;
            StateToDisplay();
            return true;
        }

    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new SuperCalculator();
        }
    }

    public static class UnaryOperator
    {
        public static double Minus(double a)
        {
            return -a;
        }
        public static double Sin(double a)
        {
            return Math.Sin(a);
        }
        public static double Cos(double a)
        {
            return Math.Cos(a);
        }
        public static double Tan(double a)
        {
            return Math.Tan(a);
        }
        public static double Square(double a)
        {
            return a*a;
        }
        public static double Sqrt(double a)
        {
            return Math.Sqrt(a);
        }
        public static double Inverse(double a)
        {
            return 1/a;
        }
    }

    public static class BinaryOperator 
    {
        public static double Add(double a, double b)
        {
            return a + b;
        }
        public static double Subtract(double a, double b)
        {
            return a - b;
        }
        public static double Multiply(double a, double b)
        {
            return a*b;
        }
        public static double Devide(double a, double b)
        {
            return a / b;
        }
    }

}
