﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        char[] _numbers = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        char[] _selfOperations = new char[] { 'S', 'K', 'T', 'Q', 'R', 'I' };
        char[] _binaryOperations = new char[] { '+', '-', '*', '/' };
        
        char _currentOperation;
        char _currentSelfOperation;
        
        char _reset = 'O';
        char _clearScreen = 'C';
        char _coma = ',';
        
        string _temp;
        string _currentDisplayString = "0";
        
        private string _resultS = "";
        private double _resultI = 0;
        private double _currentDisplayNumber = 0;
        private double _memory = 0;

        Operation operation = new Operation();

        public void Press(char inPressedDigit)
        {
            //pritisnuta tipka je zarez
            if (inPressedDigit == _coma)
            {
                if (_resultS.Contains(","))
                    return;
                _resultS = _resultS + _coma;
                return;
            }
            
            /*
            if ((_resultS == "") && (inPressedDigit == '-'))
            {
                _resultS = _resultS + inPressedDigit;
                return;
            }
            */

            if (inPressedDigit == _clearScreen)
            {
                _currentDisplayNumber = 0;
                _currentDisplayString = "0";
                _resultS = "";
                return;
            }

            //reset kalkulatora
            if (inPressedDigit == _reset)
            {
                _resultS = "";
                _currentDisplayNumber = 0;
                _currentDisplayString = "0";
                _resultI = 0;
                _currentOperation = '\0';
                _memory = 0;
                return;
            }

            //ako je upisan char znamenka, dodati ga na trenutni string
            if (_numbers.Contains(inPressedDigit))
            {
                if ((!(_resultS.Contains(','))) && (!(_resultS.Contains('-'))) && (_resultS.Length >= 10))
                    return;
                if ((!(_resultS.Contains(','))) && ((_resultS.Contains('-'))) && (_resultS.Length >= 11))
                    return;
                if (((_resultS.Contains(','))) && ((_resultS.Contains('-'))) && (_resultS.Length >= 12))
                    return;
                if (((_resultS.Contains(','))) && (!(_resultS.Contains('-'))) && (_resultS.Length >= 11))
                    return;
                _resultS = _resultS + inPressedDigit;
                _currentDisplayNumber = Convert.ToDouble(_resultS);
                _currentDisplayString = Convert.ToString(_currentDisplayNumber);
                return;
            }

            //izabrana je neka od {+, -, *, /} operacija
            //spremi prvi broj, spremi se za prihvat drugog
            if (_binaryOperations.Contains(inPressedDigit))
            {
                //ako se izraz za racunanje sastoji od vise binarnih operacija prije znaka =
                if ((_resultI != 0) && (_resultS.Length > 0))
                {
                    _resultI = operation.CalculateBinary(_resultI, _currentDisplayNumber, _currentOperation);
                    if (operation.roundResult(_resultI) == "-E-")
                    {
                        _currentDisplayString = "-E-";
                        return;
                    }
                    _temp = operation.roundResult(_resultI);
                    _resultI = Convert.ToDouble(_temp);
                    _currentDisplayNumber = _resultI;
                    _currentDisplayString = Convert.ToString(_currentDisplayNumber);
                    _currentOperation = inPressedDigit;
                    _resultS = "";
                    return;
                }


                //prvo pojavljivanje binarnog operatora u izrazu
                else
                {
                    _currentOperation = inPressedDigit;
                    if (operation.roundResult(_currentDisplayNumber) == "-E-")
                    {
                        _currentDisplayString = "-E-";
                        return;
                    }
                    _temp = operation.roundResult(_currentDisplayNumber);
                    _resultI = Convert.ToDouble(_temp);
                    _resultS = "";
                    return;
                }
            }

            //izracunaj rezultat operacije
            if ((inPressedDigit == '=') && (_binaryOperations.Contains(_currentOperation)))
            {
                if ((_currentDisplayNumber == 0) && (_currentOperation == '/'))
                {
                    _currentDisplayString = "-E-";
                    return;
                }
                _resultI = operation.CalculateBinary(_resultI, _currentDisplayNumber, _currentOperation);
                double temp = _currentDisplayNumber;
                _currentDisplayNumber = _resultI;
                if (operation.roundResult(_currentDisplayNumber) == "-E-")
                {
                    _currentDisplayString = "-E-";
                    return;
                }
                _currentDisplayNumber = Convert.ToDouble(operation.roundResult(_currentDisplayNumber));
                _currentDisplayString = Convert.ToString(_currentDisplayNumber);
                _currentDisplayNumber = temp;
                _resultI = 0;
                _resultS = "";
                //_currentOperation = '\0';
                return;
            }

            if (inPressedDigit == 'M')
            {
                _currentDisplayNumber = _currentDisplayNumber * (-1);
                _currentDisplayNumber = Convert.ToDouble(operation.roundResult(_currentDisplayNumber));
                _resultS = Convert.ToString(_currentDisplayNumber);
                _currentDisplayString = _resultS;
                return;
            }

            if (_selfOperations.Contains(inPressedDigit))
            {
                _currentSelfOperation = inPressedDigit;
                if ((inPressedDigit == 'I') && (_currentDisplayNumber == 0))
                {
                    _currentDisplayString = "-E-";
                    return;
                }
                if ((inPressedDigit == 'R') && (_currentDisplayNumber < 0))
                {
                    _currentDisplayString = "-E-";
                    return;
                }

                _currentDisplayNumber = operation.CalculateSelf(_currentDisplayNumber, _currentSelfOperation);
                if (operation.roundResult(_currentDisplayNumber) == "-E-")
                {
                    _currentDisplayString = "-E-";
                    return;
                }
                _currentDisplayNumber = Convert.ToDouble(operation.roundResult(_currentDisplayNumber));
                _currentDisplayString = Convert.ToString(_currentDisplayNumber);
                _resultS = "0";
                return;
            }

            if (inPressedDigit == '=')
            {
                _currentOperation = '\0';
                _resultS = "";
                _resultI = 0;
                return;
            }

            if (inPressedDigit == 'P')
            {
                _memory = _currentDisplayNumber;
                return;
            }

            if (inPressedDigit == 'G')
            {
                _currentDisplayNumber = _memory;
                _currentDisplayString = Convert.ToString(_currentDisplayNumber);
                _resultS = "";
                return;
            }
        }

        public string GetCurrentDisplayState()
        {
            //_currentDisplayString = operation.roundResult(Convert.ToDouble(_resultS));
            return _currentDisplayString;
        }
    }

    class Operation
    {
        public double CalculateSelf(double currentNumber, char operation)
        {
            switch (operation)
            {
                case 'S':
                    currentNumber = Math.Sin(currentNumber);
                    break;
                case 'K':
                    currentNumber = Math.Cos(currentNumber);
                    break;
                case 'T':
                    currentNumber = Math.Tan(currentNumber);
                    break;
                case 'Q':
                    currentNumber = Math.Pow(currentNumber, 2);
                    break;
                case 'R':
                    currentNumber = Math.Sqrt(currentNumber);
                    break;
                case 'I':
                    currentNumber = 1 / currentNumber;
                    break;
                default:
                    Console.WriteLine("Greška self operation!!!");
                    break;
            }
            return currentNumber;
        }

        public double CalculateBinary(double result, double currentNumber, char operation)
        {
            //double tempResult = calculator.getResult();
            switch (operation)
            {
                case '+':
                    result += currentNumber;
                    break;
                case '-':
                    result -= currentNumber;
                    break;
                case '*':
                    result *= currentNumber;
                    break;
                case '/':
                    result /= currentNumber;
                    break;
                default:
                    Console.WriteLine("Greška basic op!!!");
                    break;
            }
            return result;
        }


        public string roundResult(double resultI)
        {
            string _resultS;
            int _length = 0;
            int _comaIndex, _roundIndex;
            _resultS = resultI.ToString();
            _length = _resultS.Length;

            //RADI
            if ((resultI < 0) && (_resultS.Contains(",")) && (_length > 12))
            {
                _comaIndex = _resultS.IndexOf(',');
                _roundIndex = 11 - _comaIndex;
                resultI = Math.Round(resultI, _roundIndex);
                _resultS = Convert.ToString(resultI);
                return _resultS;
            }


            else if ((resultI < 0) && (!_resultS.Contains(",")) && (_length > 11))
            {
                string _substring = _resultS.Substring(0, 11);
                _comaIndex = _resultS.IndexOf(',');
                _roundIndex = 10 - _comaIndex;
                resultI = Math.Round(resultI, _roundIndex);
                _resultS = Convert.ToString(resultI);
                return _resultS;
            }

            //RADI
            else if ((resultI > 0) && (_resultS.Contains(",")) && (_length > 11))
            {
                string _substring = _resultS.Substring(0, 11);
                _comaIndex = _resultS.IndexOf(',');
                _roundIndex = 10 - _comaIndex;
                resultI = Math.Round(resultI, _roundIndex);
                _resultS = Convert.ToString(resultI);
                return _resultS;
            }

            
            else if (((_length > 10) && (resultI > 0) && (!_resultS.Contains(","))) || 
                ((resultI < 0) && (!_resultS.Contains(",")) && (_length > 12)) || 
                ((resultI > 0) && (!_resultS.Contains(",")) && (_length > 11)))
               return "-E-";
            

            else
                return _resultS;

            return "greska round";

        }
    }
}
