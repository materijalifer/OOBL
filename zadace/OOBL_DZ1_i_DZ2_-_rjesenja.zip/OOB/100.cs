﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        public class  Stock
        {
            public string StockName { get; set; }
            public long NumberOfShares { get; set; }
            public List<TimeValue> TimeValues { get; private set; }
            
            public Stock()
            {
                TimeValues = new List<TimeValue>();
            }

        }

        public class TimeValue
        {
            public decimal StockValue { get; set; }
            public DateTime TimeStamp { get; set; }

        }

        public class Index
        {
            public string Name { get; set; }
            public IndexTypes Type { get; set; }
            public List<Stock> Stocks { get; private set; }

            public Index()
            {
                Stocks = new List<Stock>();
            }
        }

        public class  Portfolio
        {
            public string Id { get; set; }
            public List<Stock> Stocks { get; private set; }

            public Portfolio()
            {
                Stocks = new List<Stock>();
            }
        }

        List<Stock> listStock = new List<Stock>();
        List<Index> listIndex = new List<Index>();
        List<Portfolio> listPortfolio = new List<Portfolio>();

        readonly StockExchangeException _greska = new StockExchangeException("Greška!");

        public Stock GetStock(string inStockName)
        {
            if(StockExists(inStockName))
            {
                return listStock.Single(stock => stock.StockName.ToUpper() == inStockName.ToUpper());
            }
            else
            {
                throw _greska;
            }
        }

        public Index GetIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return listIndex.Single(index => index.Name.ToUpper() == inIndexName.ToUpper());
            }
            else
            {
                throw _greska;
            }
        }

        public Portfolio GetPortfolio(string inPortfolioId)
        {
            if (PortfolioExists(inPortfolioId))
            {
                return listPortfolio.Single(portfolio => portfolio.Id == inPortfolioId);
            }
            else
            {
                throw _greska;
            }
        }

        public void SetStockIndex(string inIndexName, string inStockName, TimeValue timeValue)
        {
            var index = GetIndex(inIndexName);
            index.Stocks.Single().TimeValues.Add(timeValue);
        }

        public void SetStockPortfolio(string inPortfolioID, string inStockName, TimeValue timeValue)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            portfolio.Stocks.Single().TimeValues.Add(timeValue);
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
           if(StockExists(inStockName)) 
           {
               throw _greska;
           }
            
            else if ((inNumberOfShares>0) && (inInitialPrice>0))
            {
                var tv = new TimeValue { StockValue = inInitialPrice, TimeStamp = inTimeStamp };
                var st = new Stock
                               {
                                   StockName = inStockName,
                                   NumberOfShares = inNumberOfShares
                               };
                st.TimeValues.Add(tv);
                listStock.Add(st);
            }
            else
                {
                    throw _greska;
                }
            }


        public void DelistStock(string inStockName)
        {
            var delStock = GetStock(inStockName);
            
            foreach (var index in listIndex)
            {
                RemoveStockFromIndex(index.Name, inStockName);
            }
            foreach (var portfolio in listPortfolio)
            {
                RemoveStockFromPortfolio(portfolio.Id, inStockName);
            }

            listStock.Remove(delStock);
            
        }

        public bool StockExists(string inStockName)
        {
            return listStock.Any(stock => stock.StockName.ToUpper() == inStockName.ToUpper());
        }

        public int NumberOfStocks()
        {
            return listStock.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var stock = GetStock(inStockName);
            var timeValue = new TimeValue {StockValue = inStockValue, TimeStamp = inIimeStamp};

            foreach (var index in listIndex)
            {
                if (IsStockPartOfIndex(index.Name, inStockName))
                {
                    SetStockIndex(index.Name, inStockName, timeValue);
                }
                
            }

            foreach (var portfolio in listPortfolio)
            {
                if (IsStockPartOfPortfolio(portfolio.Id, inStockName))
                {
                    SetStockIndex(portfolio.Id, inStockName, timeValue);
                }

            }
            
            stock.TimeValues.Add(timeValue);
        }


        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stock = GetStock(inStockName);
            var time = new DateTime();
            var value = new decimal();
            foreach (var tv in stock.TimeValues)
            {
                if (tv.TimeStamp == inTimeStamp)
                {
                    time = tv.TimeStamp;
                    return tv.StockValue;
                }
                else if(tv.TimeStamp < inTimeStamp && tv.TimeStamp > time)
                {
                    time = tv.TimeStamp;
                    value = tv.StockValue;

                }
                
            }
            return decimal.Round(value,3);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            var stock = GetStock(inStockName);
            return decimal.Round(stock.TimeValues.First().StockValue,3);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            var stock = GetStock(inStockName);
            return decimal.Round(stock.TimeValues.Last().StockValue,3);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName) && Enum.IsDefined(typeof (IndexTypes), inIndexType))
            {
                var index = new Index
                {
                    Name = inIndexName,
                    Type = inIndexType
                };

                listIndex.Add(index);
            }

            else
            {
                throw _greska;
            }

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IsStockPartOfIndex(inIndexName, inStockName))
            {
                var index = GetIndex(inIndexName);
                var stock = GetStock(inStockName);
                index.Stocks.Add(stock);
            }
            else
            {
                throw _greska;
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IsStockPartOfIndex(inIndexName, inStockName))
            {
                var index = GetIndex(inIndexName);
                var stock = GetStock(inStockName);
                index.Stocks.Remove(stock);
            }
            else
            {
                throw _greska;
            }

        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var index = GetIndex(inIndexName);
            if (index.Stocks == null)
            {
                return false;
            }
            else if (index.Stocks.Any(st => st.StockName.ToUpper() == inStockName.ToUpper()))
            {
                return true;
            }
            return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var index = GetIndex(inIndexName);
            var sum = new decimal();
            var rezultat = new decimal();
            var broj = new long();
            if (Equals(index.Type, IndexTypes.AVERAGE))
            {
                foreach (var stock in index.Stocks)
                {
                    sum += GetStockPrice(stock.StockName, inTimeStamp)*stock.NumberOfShares;
                    broj += stock.NumberOfShares;
                }
                rezultat = sum/broj;

                return decimal.Round(rezultat, 3);
            }
            if (Equals(index.Type,IndexTypes.WEIGHTED))
            {
                var ukupno = new decimal();

                foreach (var stock in index.Stocks)
                {
                    sum += GetStockPrice(stock.StockName, inTimeStamp);
                    ukupno += GetStockPrice(stock.StockName, inTimeStamp) * stock.NumberOfShares;
                    broj += stock.NumberOfShares;
                }
                rezultat = sum*broj*100 / ukupno;
                return decimal.Round(rezultat, 3);
                
            }

            else
            {
                throw _greska;
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return listIndex.Any(index => index.Name.ToUpper() == inIndexName.ToUpper());
        }

        public int NumberOfIndices()
        {
            return listIndex.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            var index = GetIndex(inIndexName);
            return index.Stocks.Count();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                var portfolio = new Portfolio
                {
                    Id = inPortfolioID
                };

                listPortfolio.Add(portfolio);
            }

            else
            {
                throw _greska;
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= GetStock(inStockName).NumberOfShares)
            {
                var stock = GetStock(inStockName);

                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    var portfolio = GetPortfolio(inPortfolioID);
                    portfolio.Stocks.Add(stock);
                    stock.NumberOfShares -= numberOfShares;
                    portfolio.Stocks.Last().NumberOfShares = numberOfShares;
                }
                else
                {
                    var portfolio = GetPortfolio(inPortfolioID);
                    portfolio.Stocks.Single(s => s.StockName.ToUpper() == inStockName.ToUpper()).NumberOfShares +=
                        numberOfShares;
                    stock.NumberOfShares -= numberOfShares;
                }
            }
            else
            {
                throw _greska;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if(IsStockPartOfPortfolio(inPortfolioID,inStockName))
            {
                var portfolio = GetPortfolio(inPortfolioID);
                var stock = GetStock(inStockName);
                var shares = portfolio.Stocks.Single(s => s.StockName.ToUpper() == inStockName.ToUpper()).NumberOfShares;
                shares -= numberOfShares;
                if (shares == 0)
                {
                    portfolio.Stocks.Remove(stock);
                }
                else if (shares < 0)
                {
                    throw _greska;
                }
                else
                {
                    portfolio.Stocks.Single(s => s.StockName.ToUpper() == inStockName.ToUpper()).NumberOfShares -= numberOfShares;
                }
            }
            else
            {
                throw _greska;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                var portfolio = GetPortfolio(inPortfolioID);
                var stock = GetStock(inStockName);

                portfolio.Stocks.Remove(stock);
            }
            else
            {
                throw _greska;
            }
        }

        public int NumberOfPortfolios()
        {
            return listPortfolio.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.Stocks.Count();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return listPortfolio.Any(portfolio => portfolio.Id == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            if (portfolio.Stocks == null)
            {
                return false;
            }
            else if (portfolio.Stocks.Any(st => st.StockName.ToUpper() == inStockName.ToUpper()))
            {
                return true;
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                var portfolio = GetPortfolio(inPortfolioID);
                return Convert.ToInt32(portfolio.Stocks.Single(s => s.StockName.ToUpper() == inStockName.ToUpper()).NumberOfShares);
            }
            else
            {
                throw _greska;
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            var sum = new decimal();
            foreach (var stock in portfolio.Stocks)
            {
                sum += GetStockPrice(stock.StockName, timeStamp) * stock.NumberOfShares;
            }
            return decimal.Round(sum, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var poc = new decimal();
            var pocDatum = new DateTime(Year, Month,1,0,0,0,0);
            var kraj = new decimal();
            var krajDatum = new DateTime(Year, Month,DateTime.DaysInMonth(Year,Month),23,59,59,999);
            var rezultat = new decimal();


            poc = GetPortfolioValue(inPortfolioID, pocDatum);
            kraj = GetPortfolioValue(inPortfolioID, krajDatum);

            rezultat = (kraj - poc)*100/poc;

            return decimal.Round(rezultat, 3);

        }
    }
}
