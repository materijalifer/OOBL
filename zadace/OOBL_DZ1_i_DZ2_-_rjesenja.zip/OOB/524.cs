﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    class Stock
    {
        private SortedDictionary<DateTime, decimal> prices;

        // constructor
        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            // checking conditions
            if (initialPrice <= 0)
                throw new StockExchangeException("Price has to be positive number");
            if (numberOfShares <= 0)
                throw new StockExchangeException("Number of shares has to be positive number");

            this.Name = stockName;
            this.NumberOfShares = numberOfShares;

            // initializing container
            this.prices = new SortedDictionary<DateTime,decimal>();
            this.prices[timeStamp] = initialPrice;
        }

        public string Name { get; set; }
        public long NumberOfShares { get; set; }

        public void SetStockPrice(decimal price, DateTime timeStamp)
        {
            if (price <= 0)
                throw new StockExchangeException("Price has to be positive number");

            this.prices[timeStamp] = price;
        }
        public decimal GetStockPrice(DateTime timeStamp)
        {
            // checking if the stock existed at timestamp
            if (timeStamp < this.prices.Keys.First())
                throw new StockExchangeException("In that time stock was not listed yet.");

            // iterate through time and get the last price before timestamp
            decimal price = this.prices.Values.First();
            foreach (var kvp in this.prices)
            {
                if (kvp.Key > timeStamp)
                    break;
                price = kvp.Value;
            }

            return price;
        }

        public decimal GetLastStockPrice()
        {
            return this.prices.Values.Last();
        }
        public decimal GetInitialStockPrice()
        {
            return this.prices.Values.First();
        }
    }

    class StockRepository
    {
        // container for stocks
        private Dictionary<string, Stock> stocks;

        // constructor
        public StockRepository()
        {
            this.stocks = new Dictionary<string, Stock>();
        }
        // if stock is not in reposity, add it
        public void AddStock(Stock stock)
        {
            stock.Name = stock.Name.ToUpper();
            if (this.StockExists(stock.Name))
                throw new StockExchangeException("Stock already exists.");

            this.stocks[stock.Name] = stock;
        }
        public void RemoveStock(string stockName)
        {
            stockName = stockName.ToUpper();
            if (!this.StockExists(stockName))
                throw new StockExchangeException("Stock does not exist.");

            this.stocks.Remove(stockName);
        }
        // checks if the stock is in the repository
        public bool StockExists(string stockName)
        {
            stockName = stockName.ToUpper();
            return this.stocks.ContainsKey(stockName);
        }
        public Stock GetStock(string stockName)
        {
            stockName = stockName.ToUpper();
            if (!this.StockExists(stockName))
                throw new StockExchangeException("Stock does not exist.");

            return this.stocks[stockName];
        }
        public int StockCount() { return this.stocks.Count; }
    }

    abstract class StockIndex
    {
        protected List<Stock> stocks;

        public StockIndex(string name)
        {
            this.Name = name;
            this.stocks = new List<Stock>();
        }
        public string Name { get; set; }
        public abstract decimal CalcValue(DateTime timeStamp);

        public void AddStock(Stock stock)
        {
            // check if stock is already in this index
            if (this.stocks.Contains(stock))
                throw new StockExchangeException("Stock already in index");
            this.stocks.Add(stock);
        }
        public void RemoveStock(Stock stock)
        {
            if (!this.stocks.Contains(stock))
                throw new StockExchangeException("Stock not in index");

            if (this.stocks.Contains(stock))
                this.stocks.Remove(stock);
        }
        public bool StockInIndex(Stock stock) { return this.stocks.Contains(stock); }
        public int NumberOfStocks() { return this.stocks.Count; }
    }

    class AverageStockIndex : StockIndex
    {
        public AverageStockIndex(string name) : base(name) { }
        public override decimal CalcValue(DateTime timeStamp)
        {
            if (base.stocks.Count == 0)
                return 0m;
            decimal sum = 0;
            foreach (var stock in base.stocks)
                sum += stock.GetStockPrice(timeStamp);

            return decimal.Round(sum / base.stocks.Count, 3);
        }
    }

    class WeightenedStockIndex : StockIndex
    {
        public WeightenedStockIndex(string name) : base(name) { }
        public override decimal CalcValue(DateTime timeStamp)
        {
            if (base.stocks.Count == 0)
                return 0m;
            decimal wsum = 0;
            decimal sum = 0;
            foreach (var stock in base.stocks)
            {
                decimal price = stock.GetStockPrice(timeStamp);
                sum += price * stock.NumberOfShares;
                wsum += price * price * stock.NumberOfShares;
            }
            return decimal.Round(wsum / sum, 3);
        }
    }

    class IndicesRepository
    {
        // container for indices
        private Dictionary<string, StockIndex> indices;

        // constuctor
        public IndicesRepository()
        {
            this.indices = new Dictionary<string, StockIndex>();
        }
        public List<StockIndex> GetAll()
        {
            return this.indices.Values.ToList();
        }
        public void AddIndex(StockIndex index)
        {
            index.Name = index.Name.ToUpper();
            if (this.IndexExists(index.Name))
                throw new StockExchangeException("Index already exists.");
            this.indices[index.Name] = index;
        }
        public void RemoveIndex(string indexName)
        {
            indexName = indexName.ToUpper();
            if (!this.IndexExists(indexName))
                throw new StockExchangeException("Stock does not exist.");

            this.indices.Remove(indexName);
        }
        public bool IndexExists(string indexName)
        {
            indexName = indexName.ToUpper();
            return this.indices.ContainsKey(indexName);
        }
        public StockIndex GetIndex(string indexName)
        {
            indexName = indexName.ToUpper();
            if (!this.IndexExists(indexName))
                throw new StockExchangeException("Stock does not exist.");

            return this.indices[indexName];
        }
        public int IndicesCount() { return this.indices.Count; }
    }

    class Portfolio
    {
        private Dictionary<Stock, int> stockShares;

        public Portfolio(string id)
        {
            this.Name = id;

            this.stockShares = new Dictionary<Stock, int>();
        }
        
        public string Name { get; set; }
        
        private void AddStock(Stock stock, int numberOfShares)
        {
            this.stockShares[stock] = numberOfShares;
        }
        
        // increases or decreases number of stock shares
        public void ChangeStockShare(Stock stock, int changeOfShares)
        {
            // if we are adding the nonexistent stock (first time)
            if (changeOfShares > 0 && !this.stockShares.ContainsKey(stock))
            {
                this.AddStock(stock, changeOfShares);
                return;
            }
            CheckIfStockExists(stock); // check if stock is valid

            // increase/decrease (change of shares can be negative)
            this.stockShares[stock] = this.stockShares[stock] + changeOfShares;
            // if there is no more stocks of this kind
            if (this.stockShares[stock] <= 0)
                this.RemoveStock(stock);
        }
        public int NumberOfShares(Stock stock)
        {
            if (this.stockShares.ContainsKey(stock))
                return this.stockShares[stock];
            else
                return 0;
        }
        public void RemoveStock(Stock stock)
        {
            CheckIfStockExists(stock); // check if stock is valid
            this.stockShares.Remove(stock);
        }
        public bool StockInPortfolio(Stock stock)
        {
            return this.stockShares.ContainsKey(stock);
        }
        // calculates value of portfolio
        public decimal CalcValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (var kvp in this.stockShares)
                sum += kvp.Key.GetStockPrice(timeStamp) * kvp.Value;
            return sum;
        }
        public int NumberOfStocks() { return this.stockShares.Count; }

        // helper funkction for checking portfolio existence
        private void CheckIfStockExists(Stock stock)
        {
            if (!this.stockShares.ContainsKey(stock))
                throw new StockExchangeException("Stock not in portfolio");
        }
    }
    class PortfolioRepository
    {
        // container for portfolios
        private Dictionary<string, Portfolio> portfolios;

        public PortfolioRepository()
        {
            this.portfolios = new Dictionary<string, Portfolio>();
        }
        public List<Portfolio> GetAll()
        {
            return this.portfolios.Values.ToList();
        }
        public void AddPortfolio(Portfolio portfolio)
        {
            if (this.PortfolioExists(portfolio.Name))
                throw new StockExchangeException("Portfolio already exists.");

            this.portfolios[portfolio.Name] = portfolio;
        }
        public void RemovePortfolio(string portfolioName)
        {
            if (!this.PortfolioExists(portfolioName))
                throw new StockExchangeException("Portfolio does not exist.");

            this.portfolios.Remove(portfolioName);
        }
        public bool PortfolioExists(string portfolioName)
        {
            return this.portfolios.ContainsKey(portfolioName);
        }
        public Portfolio GetPortfolio(string portfolioName)
        {
            if (!this.PortfolioExists(portfolioName))
                throw new StockExchangeException("Portfolio does not exist.");

            return this.portfolios[portfolioName];
        }
        public int PortfolioCount() { return this.portfolios.Count; }
    }



    public class StockExchange : IStockExchange
    {
        // repositories
        private StockRepository stockRepo;
        private IndicesRepository indicesRepo;
        private PortfolioRepository portfolioRepo;

        // constructor
        public StockExchange()
        {
            this.stockRepo = new StockRepository();
            this.indicesRepo = new IndicesRepository();
            this.portfolioRepo = new PortfolioRepository();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.stockRepo.AddStock(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            // delete this stock from its index
            foreach(var i in this.indicesRepo.GetAll())
            {
                if (i.StockInIndex(stock))
                    i.RemoveStock(stock);
            }
            // delete this stock from all portfolios
            foreach (var p in this.portfolioRepo.GetAll())
            {
                if (p.StockInPortfolio(stock))
                    p.RemoveStock(stock);
            }

            this.stockRepo.RemoveStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return this.stockRepo.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return this.stockRepo.StockCount();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            this.stockRepo.GetStock(inStockName).SetStockPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return this.stockRepo.GetStock(inStockName).GetStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return this.stockRepo.GetStock(inStockName).GetInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return this.stockRepo.GetStock(inStockName).GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            StockIndex index;
            if (inIndexType == IndexTypes.AVERAGE)
                index = new AverageStockIndex(inIndexName);
            else if (inIndexType == IndexTypes.WEIGHTED)
                index = new WeightenedStockIndex(inIndexName);
            else
                throw new StockExchangeException("Index type invalid.");

            this.indicesRepo.AddIndex(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            StockIndex index = this.indicesRepo.GetIndex(inIndexName);
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            this.indicesRepo.GetIndex(inIndexName).RemoveStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            return this.indicesRepo.GetIndex(inIndexName).StockInIndex(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return this.indicesRepo.GetIndex(inIndexName).CalcValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return this.indicesRepo.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return this.indicesRepo.IndicesCount();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return this.indicesRepo.GetIndex(inIndexName).NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            this.portfolioRepo.AddPortfolio(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            Portfolio portfolio = this.portfolioRepo.GetPortfolio(inPortfolioID);
            
            // check number of stocks in all portfolios
            int stockCount = 0;
            foreach (var p in this.portfolioRepo.GetAll())
                if (p.StockInPortfolio(stock))
                    stockCount += p.NumberOfShares(stock);

            if (stockCount + numberOfShares > stock.NumberOfShares)
                throw new StockExchangeException("Stock shares limit passed.");

            portfolio.ChangeStockShare(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            Portfolio portfolio = this.portfolioRepo.GetPortfolio(inPortfolioID);
            portfolio.ChangeStockShare(stock, -numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            Portfolio portfolio = this.portfolioRepo.GetPortfolio(inPortfolioID);

            portfolio.RemoveStock(stock);
        }

        public int NumberOfPortfolios()
        {
            return this.portfolioRepo.PortfolioCount();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return this.portfolioRepo.GetPortfolio(inPortfolioID).NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return this.portfolioRepo.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            return this.portfolioRepo.GetPortfolio(inPortfolioID).StockInPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = this.stockRepo.GetStock(inStockName);
            return this.portfolioRepo.GetPortfolio(inPortfolioID).NumberOfShares(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return this.portfolioRepo.GetPortfolio(inPortfolioID).CalcValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = this.portfolioRepo.GetPortfolio(inPortfolioID);
            decimal startValue = portfolio.CalcValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
            decimal endValue = portfolio.CalcValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            if (startValue == 0m || endValue == 0m)
                throw new StockExchangeException("Portfolio value not defined at the beggining of month.");
            decimal ret = (endValue - startValue) / startValue * 100;
            return decimal.Round(ret, 3);
        }
    }
}
