﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
    public interface IStockEntity
    {
        string Name { get; set; }
    }
    public class Index : IStockEntity
    {
        private IndexTypes _indextype;
        public string Name { get; set; }
        public IndexTypes IndexType
        {
            get { return _indextype; }
            set
            {
                if (value == IndexTypes.AVERAGE || value == IndexTypes.WEIGHTED)
                {
                    _indextype = value;
                }
                else
                {
                    throw new StockExchangeException("Neispravan tip indeksa");
                }
            }
        }

        public Index(string name, IndexTypes type)
        {
            Name = name;
            IndexType = type;
            Stocks = new List<Stock>();
        } 
        public List<Stock> Stocks { get; set; }
    }
    public class StockValue
    {
        private decimal _price;

        public decimal Price
        {
            get { return _price; }
            set
            {
                if (value > 0)
                {
                    _price = value;
                }
                else throw new StockExchangeException("Cijena mora biti veća od 0");
            }
        }

        public DateTime TimeStamp { get; set; }

        public StockValue(decimal price, DateTime timestamp)
        {
            Price = price;
            TimeStamp = timestamp;
        }
    }

    public class Stock : IStockEntity
    {
        private long _numberofshares;
        public string Name { get; set; }

        public long NumberOfShares
        {
            get { return _numberofshares; }
            set
            {
                if (value > 0)
                    _numberofshares = value;
                else
                {
                    throw new StockExchangeException("Vrijednost mora biti veća od 0");
                }
            }
        }

        public List<StockValue> StockValues { get; set; }

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Name = inStockName;
            NumberOfShares = inNumberOfShares;
            StockValues= new List<StockValue>();
            StockValues.Add(new StockValue(inInitialPrice, inTimeStamp));
        }
        public Stock(Stock stock)
        {
            Name = stock.Name;
            NumberOfShares = stock.NumberOfShares;
            StockValues = new List<StockValue>();
            StockValues = stock.StockValues;
        }
    }

    public class Portfolio : IStockEntity
    {
        public string Name { get; set; }
        public List<Stock> Stocks { get; set; }
        public Portfolio(string name)
        {
            Name = name;
            Stocks=new List<Stock>();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks = new List<Stock>();
        private List<Index> _indexes = new List<Index>();
        private List<Portfolio> _portfolios = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                _stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            else
            {
                throw new StockExchangeException("Postoji dionica istog imena");
            }
        }
        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                _stocks.RemoveAll(x => x.Name.ToUpper() == inStockName.ToUpper());
                foreach (var index in _indexes)
                {
                    index.Stocks.RemoveAll(x => x.Name.ToUpper() == inStockName.ToUpper());
                }
                foreach (var portfolio in _portfolios)
                {
                    portfolio.Stocks.RemoveAll(x => x.Name.ToUpper() == inStockName.ToUpper());
                }
            }
            else throw new StockExchangeException("Dionica ovog imena ne postoji");
        }

        public bool StockExists(string inStockName)
        {
            return (_stocks.Exists(x => x.Name.ToUpper() == inStockName.ToUpper()));
        }

        public int NumberOfStocks()
        {
            return Convert.ToInt32(_stocks.Count);
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName))
            {
                if (_stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.Exists(y => y.TimeStamp == inIimeStamp))
                {
                    _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper())
                           .StockValues.First(y => y.TimeStamp == inIimeStamp)
                           .Price = inStockValue;
                }
                else
                {
                    _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.Add(new StockValue(inStockValue, inIimeStamp));
                }
                _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues = _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.OrderBy(x => x.TimeStamp).ToList();
            }
            else throw new StockExchangeException("Dionica ovog imena ne postoji");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                //provjeri i sort
                return _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.Last(x => x.TimeStamp < inTimeStamp).Price;
            }
            throw new StockExchangeException("Dionica ovog imena ne postoji");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                //provjeri
                return _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.First().Price;
            }
            throw new StockExchangeException("Dionica ovog imena ne postoji");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                //provjeri
                return _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).StockValues.Last().Price;
            }
            throw new StockExchangeException("Dionica ovog imena ne postoji");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {
                _indexes.Add(new Index(inIndexName, inIndexType));
            }
            else throw new StockExchangeException("Indeks ovog imena već postoji");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IsStockPartOfIndex(inIndexName, inStockName))
            {
                Stock stock = _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper());
                _indexes.First(x => x.Name.ToUpper() == inIndexName.ToUpper()).Stocks.Add(stock);

            }
            else
            {
                throw new StockExchangeException("U indexu dionica ovog imena vec postoji");
            }

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IsStockPartOfIndex(inIndexName, inStockName))
            {
                _indexes.First(x => x.Name.ToUpper() == inIndexName.ToUpper())
                        .Stocks.RemoveAll(y => y.Name.ToUpper() == inStockName.ToUpper());
            }
            else throw new StockExchangeException("Dionica nije u indeksu");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName))
            {
                if (StockExists(inStockName))
                {
                    
                    if (_indexes.First(x => x.Name.ToUpper() == inIndexName.ToUpper())
                            .Stocks.Exists(y => y.Name.ToUpper() == inStockName.ToUpper()))
                    {
                        return true;
                    }
                    return false;
                }
                throw new StockExchangeException("Dionica ne postoji na burzi");
            }
            throw new StockExchangeException("Index ovog imena ne postoji");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (IndexExists(inIndexName))
            {
                Index index = _indexes.First(x => x.Name.ToUpper() == inIndexName.ToUpper());
                if (index.IndexType == IndexTypes.AVERAGE)
                {
                    //provjeri da li mora biti suma*broj dionica
                    return Decimal.Round(index.Stocks.Sum(x => GetStockPrice(x.Name, inTimeStamp) * x.NumberOfShares) / index.Stocks.Count, 3);
                }
                if (index.IndexType == IndexTypes.WEIGHTED)
                {
                    decimal all = index.Stocks.Sum(x => GetStockPrice(x.Name, inTimeStamp) * x.NumberOfShares);
                    return
                        Decimal.Round(
                            index.Stocks.Sum(x => GetStockPrice(x.Name, inTimeStamp) * x.NumberOfShares / all * GetStockPrice(x.Name, inTimeStamp) ), 3);
                }
                throw new StockExchangeException("Krivi tip indeksa");
            }
            throw new StockExchangeException("Index ovog imena ne postoji");
        }

        public bool IndexExists(string inIndexName)
        {
            if (_indexes.Exists(x => x.Name.ToUpper() == inIndexName.ToUpper()))
            {
                return true;
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return _indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                int brojdionica = Convert.ToInt32(_indexes.First(x => x.Name.ToUpper() == inIndexName.ToUpper()).Stocks.Count);
                return brojdionica;
            }
            throw new StockExchangeException("Index ovog imena ne postoji");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                _portfolios.Add(new Portfolio(inPortfolioID));
            else
            {
                throw new StockExchangeException("Portfelj postoji");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            else
            {    
                if (numberOfShares > 0)
                {
                    int izdanedionice = 0;
                    foreach (var i in _portfolios)
                    {
                        if(IsStockPartOfPortfolio(i.Name,inStockName))
                            izdanedionice += Convert.ToInt32(i.Stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper()).NumberOfShares);
                    }
                    Stock dionica = _stocks.First(x => x.Name.ToUpper() == inStockName.ToUpper());
                    if (izdanedionice + numberOfShares <= dionica.NumberOfShares)
                    {
                        if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                        {
                            _portfolios.First(x => x.Name == inPortfolioID).Stocks.First(y => y.Name.ToUpper() == inStockName.ToUpper()).NumberOfShares+=numberOfShares;
                        }
                        else
                        {
                            Stock temp = new Stock(dionica);
                            temp.NumberOfShares = numberOfShares;
                            _portfolios.First(x => x.Name == inPortfolioID).Stocks.Add(temp);
                        }
                    }
                    else throw new StockExchangeException("Nema vise dionica na burzi");
                }
                else throw new StockExchangeException("Broj dionica mora biti veći od 0");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new Exception("Dionica nije u protfelju");
            }
            else
            {
                int brojdionica = NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
                if (brojdionica - numberOfShares > 0)
                {
                    _portfolios.First(x => x.Name == inPortfolioID)
                               .Stocks.First(y => y.Name.ToUpper() == inStockName.ToUpper()).NumberOfShares =
                        brojdionica -
                        numberOfShares;
                }
                else
                {
                    _portfolios.First(x => x.Name == inPortfolioID)
                               .Stocks.RemoveAll(y => y.Name.ToUpper() == inPortfolioID.ToUpper());
                }

            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new Exception("Dionica nije u protfelju");
            }
            else
            {
                _portfolios.First(x => x.Name == inPortfolioID)
                           .Stocks.RemoveAll(y => y.Name.ToUpper() == inStockName.ToUpper());
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return Convert.ToInt32(_portfolios.First(x => x.Name == inPortfolioID).Stocks.Count);
            }
            throw new StockExchangeException("Portfelj ne postoji");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (_portfolios.Exists(x => x.Name == inPortfolioID))
            {
                return true;
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfelj ne postoji");
            if (!StockExists(inStockName)) throw new StockExchangeException("Dionica ne postoji");
            if (_portfolios.First(x => x.Name == inPortfolioID).Stocks.Exists(y => y.Name.ToUpper() == inStockName.ToUpper()))
                return true;
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            return Convert.ToInt32(
                _portfolios.First(x => x.Name == inPortfolioID)
                           .Stocks.First(y => y.Name.ToUpper() == inStockName.ToUpper())
                           .NumberOfShares);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolios.First(x => x.Name == inPortfolioID)
                                  .Stocks.Sum(y => y.NumberOfShares * GetStockPrice(y.Name, timeStamp));
            }
            throw new StockExchangeException("Portfelj ne postoji");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                int daysinmonth = DateTime.DaysInMonth(Year, Month);
                DateTime pocetakmj = new DateTime(Year, Month, 1, 23, 59, 59, 999);
                DateTime krajmj = new DateTime(Year, Month, daysinmonth, 0, 0, 0, 0);
                decimal pocmjvalue = GetPortfolioValue(inPortfolioID, pocetakmj);
                decimal krajmjvalue = GetPortfolioValue(inPortfolioID, krajmj);
                return krajmjvalue / pocmjvalue;
            }
            throw new StockExchangeException("Portfelj ne postoji");
        }
    }
}
