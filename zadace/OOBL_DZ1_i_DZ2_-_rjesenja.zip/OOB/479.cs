using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{	
	class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }
	
    public class Calculator : ICalculator
    {
        
        private const int MAXDIGITS = 10;           
        private string display { get; set; }        
        private double memory { get; set; }         

        private double firstNumber { get; set; }    
        private bool newDigit { get; set; } 

        private bool error { get; set; }            
        private bool over { get; set; }             

        private char binOper { get; set; }          
        private bool isEqual { get; set; } 
        
       
        
        public Calculator()
        {
            this.display = "0";
            this.memory = 0;
            this.firstNumber = 0;
            this.binOper = '0';                     
            this.newDigit = false;
            this.error = false;
            this.over = false;
            this.isEqual = false;
        }

        
        public void Press(char inPressedDigit)
        {
            double number;
            if (Double.TryParse(inPressedDigit.ToString(), out number))
            {
                digits(inPressedDigit);
            }
            else 
            {
                switch (inPressedDigit)
                { 
                    case '+':
                        countBinary(inPressedDigit);
                        break;
                    case '-':
                        countBinary(inPressedDigit);
                        break;
                    case '*':
                        countBinary(inPressedDigit);
                        break;
                    case '/':
                        countBinary(inPressedDigit);
                        break;
                    case '=':
                        equal(inPressedDigit);
                        break;
                    case ',':
                        decimalPoint();
                        break;
                    case 'M':
                        signNumber();
                        break;
                    case 'S':
                        countUnary(inPressedDigit);
                        break;
                    case 'K':
                        countUnary(inPressedDigit);
                        break;
                    case 'T':
                        countUnary(inPressedDigit);
                        break;
                    case 'Q':
                        countUnary(inPressedDigit);
                        break;
                    case 'R':
                        countUnary(inPressedDigit);
                        break;
                    case 'I':
                        countUnary(inPressedDigit);
                        break;
                    case 'P':
                        putInMemory();
                        break;
                    case 'G':
                        getFromMemory();
                        break;
                    case 'C':
                        clear();
                        break;
                    case 'O':
                        reset();
                        break;
                }
            
            }
        }
        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        private void digits(char inPressedDigit)     
        {
            if (this.display == "0" || this.over)
            {
                display = inPressedDigit.ToString();
                this.over = false;
                this.newDigit = true;
            }
            else
            {
                int extra = 0;
                if (display.Contains(','))
                    extra++;
                if (display.Contains('-'))
                    extra++;
                if (display.Length - extra < MAXDIGITS)
                    display = display + inPressedDigit;
            }

            double Number = 0;
            if (display.Contains(','))
            {
                int i = display.IndexOf(",");
                int l = display.Length;

                string temp = display.Substring(i + 1, display.Length - (i + 1));
                if (temp.Length > 0)
                {
                    Number = Convert.ToDouble(temp);
                }
                if (Number == 0 || temp.Length == 0)
                {
                    display = display.Substring(0, i);

                }
            } 
        }

        private void decimalPoint()         
        {
            if (!display.Contains(',') && !over)
                display += ",";
        }
 
        private void signNumber()           
        {
            double temp;
            temp = Convert.ToDouble(display);
            if (!error)
            {
                if (temp > 0)
                {
                    display = "-" + display;
                }
                else
                {
                    display = display.Substring(1);
                }
            }
        }
      
        private void clear()        
        {
            display = "0";
            error = false;
        }
        
        private void reset()        
        {
            this.display = "0";
            this.memory = 0;
            this.firstNumber = 0;
            this.binOper = '0';       
            this.newDigit = false;
            this.error = false;
            this.over = false;
            this.isEqual = false;
        }
        
        private void handleError()      
        {
            error = true;
            display = "-E-";
        }
        
        private void equal(char operation)        
        {

            if (binOper != '0')
            {
                this.isEqual = true;
                countBinary(this.binOper); 
            }
            else
            {
                try
                {
                    double result = 0;
                    Double.TryParse(this.display, out result);
                    this.display = result.ToString();
                }
                catch
                {
                    this.display = "-E-";
                }
            }
            
        }
       
        public void putInMemory()       
        {
            try
            {
                memory = Convert.ToDouble(display);
            }
            catch
            {
                memory = 0;
            }
        }
        
        public void getFromMemory() 
        {
            resultCheck(memory);
        }
       
        private void resultCheck(double result)
        {
            if (double.IsInfinity(result) || double.IsNaN(result))
            {
                handleError();
            }
            else
            {
                long numb = Math.Abs((long)result);
                int numberOFDigitsBefore = numb.ToString().Length;
                int numberOfDigits = result.ToString().Length;
                
                if (numberOfDigits > MAXDIGITS)
                {
                    if (result.ToString().Contains(',') && numberOFDigitsBefore < MAXDIGITS)
                    {
                        result = Math.Round(result, MAXDIGITS - numberOFDigitsBefore);
                        display = result.ToString();
                    }
                    else
                    {
                        handleError();
                        error = true;
                    }
                }
                else
                {
                    display = result.ToString();
                    error = false;
                }
            }
            over = true;
        }
        
        private void countBinary(char operation) 
        {
            if (this.binOper != '0' && (this.newDigit || this.isEqual))
            {
                double secondNumber = 0;
                try
                {
                    secondNumber = Convert.ToDouble(display);
                }
                catch
                {
                    secondNumber = Double.NaN;
                }

                Double result = 0;
                switch (binOper)
                {
                    case '+':
                        result = firstNumber + secondNumber;
                        break;
                    case '-':
                        result = firstNumber - secondNumber;
                        break;
                    case '*':
                        result = firstNumber * secondNumber;
                        break;
                    case '/':
                        result = firstNumber / secondNumber;
                        break;
                    default:
                        break;
                }
                this.isEqual = false;
                deleteFirst();
                resultCheck(result);
            }
            saveFirst(operation);
            over = true;
            newDigit = false; 
        }
       
        private void countUnary(char operation)
        {
            double result = 0;
            double number = 0;
            try
            {
                number = Convert.ToDouble(display);
            }
            catch
            {
                result = Double.NaN;
            }
            switch (operation)
            {
                case 'S':
                    result = Math.Sin(number);
                    break;
                case 'K':
                    result = Math.Cos(number);
                    break;
                case 'T':
                    result = Math.Tan(number);
                    break;
                case 'Q':
                    result = Math.Pow(number, 2);
                    break;
                case 'R':
                    result = Math.Pow(number, 0.5);
                    break;
                case 'I':
                    result = 1 / number;
                    break;
                default:
                    result = number;
                    break;
            }
            resultCheck(result);
        }
        
        private void saveFirst(char operation)
        {
            try
            {
                firstNumber = Convert.ToDouble(display);
                binOper = operation;
            }
            catch 
            {
                firstNumber = Double.NaN;
            }
        }
       
        private void deleteFirst()
        {
            firstNumber = 0;
            binOper = '0';
        }
    } 
}
