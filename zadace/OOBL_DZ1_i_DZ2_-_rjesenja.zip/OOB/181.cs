﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
 {

        int brojacZnamenki;
        int brojacIzaZareza;

        bool minusSBrojem; 
        bool ekranPrazan;
        bool binarnaOperacijaOmoguci;
        
        char trenutniBinarniOperator;
        char nullCharacter;
        char zarez;

        string error; 
        string nullString;
        string trenutnoStanjeEkrana;
        string sljedeceStanjeEkrana;

        string rezultatString;
        double rezultatBroj;
        bool rezultatError;

        double trenutniUnarniBroj;
        double prethodniBinarniBroj;
        double trenutniBinarniBroj;

        public Kalkulator()
        {
            brojacZnamenki = 0;
            brojacIzaZareza = 0;

            rezultatError = false;
            minusSBrojem = false; 
            ekranPrazan = false;
            binarnaOperacijaOmoguci = true;

            error = "-E-";
            nullString = "0";
            trenutnoStanjeEkrana = nullString;
            sljedeceStanjeEkrana = nullString;

            zarez = ',';
            nullCharacter = '0';
            trenutniBinarniOperator = nullCharacter;
        }

        public string GetCurrentDisplayState()
        {
            return trenutnoStanjeEkrana;
        }

        public void Press(char pritisnutiGumb)
        {
            if(	pritisnutiGumb == '1' || pritisnutiGumb == '2' || pritisnutiGumb == '3' || 	
                pritisnutiGumb == '4' || pritisnutiGumb == '5' || pritisnutiGumb == '6' || 
                pritisnutiGumb == '7' || pritisnutiGumb == '8' || pritisnutiGumb == '9' || 
                pritisnutiGumb == '0')
            {
	            PrikaziPritisnutiGumb(pritisnutiGumb);
            }
            if (pritisnutiGumb == ',')
            {
                brojacIzaZareza++;
                PrikaziPritisnutiGumb(pritisnutiGumb);
            }
            if(pritisnutiGumb == 'M'){
	            Minus();
            }
            if(pritisnutiGumb == 'S' || pritisnutiGumb == 'K' || pritisnutiGumb == 'T' || pritisnutiGumb == 'Q' || 
                pritisnutiGumb == 'R' || pritisnutiGumb == 'I' ){
	            UnarnaOperacija(pritisnutiGumb);
            }
            if(pritisnutiGumb == '+' || pritisnutiGumb == '-' || pritisnutiGumb == '*' || pritisnutiGumb == '/'){
              //  string pomoc = trenutnoStanjeEkrana;
              //  pomoc.Replace(",0","");
              //  PrikaziString(pomoc);
				ProvjeriRezultat();
	            BinarnaOperacija();
                trenutniBinarniOperator = pritisnutiGumb;
            }
            if(pritisnutiGumb == '='){
	            binarnaOperacijaOmoguci = true;
                BinarnaOperacija();
                Jednako();
                trenutniBinarniOperator = nullCharacter;
            }
            if(pritisnutiGumb == 'P'){
	            Spremi();
            }
            if(pritisnutiGumb == 'G'){
	            Load();
            }
            if(pritisnutiGumb == 'C'){
	            OcistiEkran();
            }
            if(pritisnutiGumb == 'O'){
	            Reset();
            }
	        if(pritisnutiGumb != '1' && pritisnutiGumb != '2' && pritisnutiGumb != '3' && pritisnutiGumb != '4' && 
               pritisnutiGumb != '5' && pritisnutiGumb != '6' && pritisnutiGumb != '7' && pritisnutiGumb != '8' && 
               pritisnutiGumb != '9' && pritisnutiGumb != '0' && pritisnutiGumb != '+' && pritisnutiGumb != '-' && 
               pritisnutiGumb != '*' && pritisnutiGumb != '/' && pritisnutiGumb != ',' && pritisnutiGumb != 'M' && 
               pritisnutiGumb != 'S' && pritisnutiGumb != 'K' && pritisnutiGumb != 'T' && pritisnutiGumb != 'Q' && 
               pritisnutiGumb != 'R' && pritisnutiGumb != 'I' && pritisnutiGumb != '=' && pritisnutiGumb != 'P' && 
               pritisnutiGumb != 'G' && pritisnutiGumb != 'C' && pritisnutiGumb != 'O')
            {
                PrikaziString(error);
            }
        }

        public void ResetirajVrijednosti()
        {
            brojacZnamenki = 0; 
            brojacIzaZareza = 0; 
            minusSBrojem = false;
        }

        public void PrikaziPritisnutiGumb(char pritisnutiGumb)
        {
            if (brojacZnamenki == 0)
            {
                if ((brojacIzaZareza == 0) && (pritisnutiGumb != nullCharacter))
                {
                    sljedeceStanjeEkrana = new string(pritisnutiGumb, 1);
                }
                else if (brojacIzaZareza == 1)
                {
                    sljedeceStanjeEkrana = trenutnoStanjeEkrana + pritisnutiGumb;
                }

                if (sljedeceStanjeEkrana != nullString)
                {
                    brojacZnamenki = 1;
                }
                else
                {
                    ekranPrazan = true;
                }

            }
            else if ((brojacZnamenki > 0) && (brojacZnamenki < 10))
            {
                if (pritisnutiGumb == zarez)
                {
                    if (brojacIzaZareza == 1)
                    {
                        sljedeceStanjeEkrana = trenutnoStanjeEkrana + pritisnutiGumb;
                    }
                }
                else
                {
                    sljedeceStanjeEkrana = trenutnoStanjeEkrana + pritisnutiGumb;
                    brojacZnamenki++;
                }
            }

            PrikaziString(sljedeceStanjeEkrana);
        }

        public void PrikaziString(string displayString)
        {
            trenutnoStanjeEkrana = displayString;
            ekranPrazan = false;
            binarnaOperacijaOmoguci = true;

            if ((trenutnoStanjeEkrana == "0") || (trenutnoStanjeEkrana == "-E-"))
            {
                ekranPrazan = true;
                if (trenutnoStanjeEkrana == "-E-")
                {
                    binarnaOperacijaOmoguci = false;
                }
            }
        }

        public void Minus()
        {
            if (ekranPrazan == false)
            {
                string previousString = GetCurrentDisplayState();
                string trenutniString = nullString;
                
                if (minusSBrojem == false)
                {
                    trenutniString = "-" + previousString;
                    minusSBrojem = true;
                }
                else if (minusSBrojem == true)
                {
                    trenutniString = previousString.Remove(0, 1);
                    minusSBrojem = false;
                }

                PrikaziString(trenutniString);
            }
        }

        public double TrenutniStringUBroj()
        {
            string trenutniString = GetCurrentDisplayState();
            double trenutniBroj = Convert.ToDouble(trenutniString);
            ResetirajVrijednosti();
            return trenutniBroj;
        }

        public void UnarnaOperacija(char currentUnaryOperator)
        {
                trenutniUnarniBroj = TrenutniStringUBroj();
                switch (currentUnaryOperator)
                {
                    case 'S':
                        {
                            rezultatBroj = Math.Sin(trenutniUnarniBroj);
                            break;
                        }
                    case 'K':
                        {
                            rezultatBroj = Math.Cos(trenutniUnarniBroj);
                            break;
                        }
                    case 'T':
                        {
                            rezultatBroj = Math.Tan(trenutniUnarniBroj);
                            break;
                        }
                    case 'Q':
                        {
                            rezultatBroj = trenutniUnarniBroj * trenutniUnarniBroj;
                            break;
                        }
                    case 'R':
                        {
                            if (trenutniUnarniBroj >= 0)
                            {
                                rezultatBroj = Math.Sqrt(trenutniUnarniBroj);
                            }
                            else
                            {
                                rezultatError = true;
                            }
                            break;
                        }
                    case 'I':
                        {
                            if (trenutniUnarniBroj != 0)
                            {
                                rezultatBroj = 1 / trenutniUnarniBroj;
                            }
                            else
                            {
                                rezultatError = true;
                            }
                            break;
                        }
                    default:
                        {
                            rezultatBroj = trenutniUnarniBroj;
                            break;
                        }
                }
                ProvjeriRezultat();
                trenutniUnarniBroj = rezultatBroj;
                Jednako();
        }

        public void BinarnaOperacija()
        {
            if (binarnaOperacijaOmoguci == true)
            {
                prethodniBinarniBroj = trenutniBinarniBroj;
                trenutniBinarniBroj = TrenutniStringUBroj();
                switch (trenutniBinarniOperator)
                {
                    case '+':
                        {
                            rezultatBroj = prethodniBinarniBroj + trenutniBinarniBroj;
                            break;
                        }
                    case '-':
                        {
                            rezultatBroj = prethodniBinarniBroj - trenutniBinarniBroj;
                            break;
                        }
                    case '*':
                        {
                            rezultatBroj = prethodniBinarniBroj * trenutniBinarniBroj;
                            break;
                        }
                    case '/':
                        {
                            rezultatBroj = prethodniBinarniBroj / trenutniBinarniBroj;
                            break;
                        }
                    default:
                        {
                            rezultatBroj = trenutniBinarniBroj;
                            break;
                        }
                }
                ProvjeriRezultat();
                trenutniBinarniBroj = rezultatBroj;
                binarnaOperacijaOmoguci = false;
            }
        }

        public void ProvjeriRezultat()
        {
            int pomComaIndicator = 0;
            string pomResultString = Convert.ToString(rezultatBroj);
            if (pomResultString.Contains(","))
            {
                pomComaIndicator = 1;
            }
            string[] pomStringArray = pomResultString.Split(',');
            pomResultString = pomStringArray[0];
            if (pomResultString.Contains("-"))
            {
                pomResultString = pomResultString.Remove(0, 1);
            }
            if (pomComaIndicator == 0)
            {
                int pom1StringLength = pomResultString.Length;
                if (pom1StringLength > 10)
                {
                    rezultatError = true;
                }
            }
            else
            {
                int pom2StringDuljina = pomResultString.Length;
                if ((pom2StringDuljina < 11) && (pom2StringDuljina > 0))
                {
                    int decimalDigitNumber = 10 - pom2StringDuljina;
                    rezultatBroj = Math.Round(rezultatBroj, decimalDigitNumber);
                }
                else
                {
                    rezultatError = true;
                }
            }
        }

        public void Jednako()
        {
            if (rezultatError == false)
            {
                rezultatString = Convert.ToString(rezultatBroj);
                PrikaziString(rezultatString);
            }
            else
            {
                PrikaziString(error);
                rezultatError = false;
            }
        }

        string spremljenoStanjeEkrana;

        public void Spremi()
        {
            spremljenoStanjeEkrana = GetCurrentDisplayState();
        }

        public void Load()
        {
            PrikaziString(spremljenoStanjeEkrana);
        }

        public void OcistiEkran()
        {
            trenutnoStanjeEkrana = "0";
            ResetirajVrijednosti();
        }

        public void Reset()
        {
            OcistiEkran();
            spremljenoStanjeEkrana = "";
            trenutniBinarniOperator = nullCharacter;
        }
    }



}
