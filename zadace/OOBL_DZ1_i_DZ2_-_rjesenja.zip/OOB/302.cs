﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
     #region Klasa Dionica
     public class Dionica 
    {
        private string imeDionice;
        private long brojDionica;
        private Decimal cijenaDionice;
        private DateTime cijenaAktivnaOd;
        public List<HistoryCijenaDionica> povijestCijenaDionica = new List<HistoryCijenaDionica>(); //History lista datuma i cijena

        public Dionica(string inImeDionice, long inBrojDionica, Decimal inCijenaDionice, DateTime inCijenaAktivnaOd)
        {
            this.imeDionice = inImeDionice;
            this.brojDionica = inBrojDionica;
            this.cijenaDionice = inCijenaDionice;
            this.cijenaAktivnaOd = inCijenaAktivnaOd;
            
        }

        public string ImeDionice 
        {
            get
            {
                return imeDionice;
            }

            set
            {
                imeDionice = value;
            }
        }

        public long BrojDionica
        {
            get
            {
                return brojDionica;
            }

            set
            {
                brojDionica = value;
            }
        }

        public Decimal CijenaDionice
        {
            get
            {
                return cijenaDionice;
            }

            set
            {
                cijenaDionice = value;
            }
        }

        public DateTime CijenaAktivnaOd
        {
            get
            {
                return cijenaAktivnaOd;
            }

            set
            {
                cijenaAktivnaOd = value;
            }
        }
    }
    #endregion

     #region Klasa Index
     public class Index
     {
        private string imeIndexa;
        private IndexTypes tipIndexa;
        public List<Dionica> listaDionica = new List<Dionica>(); 

        public Index(string inImeIndexa, IndexTypes inTipIndexa)
        {
            this.imeIndexa = inImeIndexa;
            this.tipIndexa = inTipIndexa;
        }

        public string ImeIndexa 
        {
            get
            {
                return imeIndexa;
            }
            set
            {
                imeIndexa = value;
            }
        }

        public IndexTypes TipIndexa
        {
            get
            {
                return tipIndexa;
            }
            set
            {
                tipIndexa = value;
            }
        }
        
        public List<Dionica> ListaDionica
        {
            get
            {
                return listaDionica;
            }
        }
     }
     #endregion

     #region Klasa Portfiljo
     public class Portfiljo
     {
        private string idPortfiljo;
        public List<BrojZauzetihDionica> listaDionica = new List<BrojZauzetihDionica>(); //lista dionica u portfelju s odredenim brojem zauzetih dionica
        

        public Portfiljo(string inIdPortfiljo)
        {
            this.idPortfiljo = inIdPortfiljo;
        }

        public string IdPortfiljo
        {
            get
            {
                return idPortfiljo;
            }
            set
            {
                idPortfiljo = value;
            }
        }
     }
     #endregion

     #region Klasa HistoryCijenaDionica
     public class HistoryCijenaDionica //koristi se za pracenje cijena dionica za odredene datumske intervale
     {
         private DateTime datumVrijemeAktivno;
         private Decimal cijenaZaVrijeme;

         public HistoryCijenaDionica(DateTime inDatumVrijemeAktivno, Decimal inCijenaZaVrijeme)
         {
             this.datumVrijemeAktivno = inDatumVrijemeAktivno;
             this.cijenaZaVrijeme = inCijenaZaVrijeme;
         }

         public DateTime DatumVrijemeAktivno
         {
             get
             {
                 return datumVrijemeAktivno;
             }

             set
             {
                 datumVrijemeAktivno = value;
             }
         }

         public Decimal CijenaZaVrijeme
         {
             get
             {
                 return cijenaZaVrijeme;
             }

             set
             {
                 cijenaZaVrijeme = value;
             }
         }
     }

     #endregion

     #region Klasa BrojZauzetihDionica
     public class BrojZauzetihDionica //koristi se za pracanje kolicine dionica u nekom portfelju
     {
         private Dionica dionica;
         private int broj;

         public BrojZauzetihDionica(Dionica inDionica, int inBroj)
         {
             this.dionica = inDionica;
             this.broj = inBroj;
         }

         public Dionica Dionica
         {
             get
             {
                 return dionica;
             }

             set
             {
                 dionica = value;
             }
         }

         public int Broj
         {
             get
             {
                 return broj;
             }

             set
             {
                 broj = value;
             }
         }
     }
     #endregion

     public class StockExchange : IStockExchange
     {
         public Dionica dionica;
         public List<Dionica> listaDionica = new List<Dionica>();
         public HistoryCijenaDionica staraCijena;
         public Index index;
         public List<Index> listaIndexa = new List<Index>();
         public Portfiljo portfiljo;
         public List<Portfiljo> listaPortfelja = new List<Portfiljo>();
         public BrojZauzetihDionica novaDionicaUPortfelju;

         #region Metode za dionice

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Cijena dionice mora biti pozitivan iznos!");
             }
             else if (inNumberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica mora biti pozitivan iznos!");
             }
             else
             {
                 dionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             }

             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom vec postoji, nemoguce dodati tu dionicu!");
             }
             else
             {
                 listaDionica.Add(dionica);
             }
         }

         public void DelistStock(string inStockName)
         {
             
             if (StockExists(inStockName))
             {
                 foreach (Index elementIndex in listaIndexa)
                 {
                     if (IsStockPartOfIndex(elementIndex.ImeIndexa, inStockName))
                     {
                         RemoveStockFromIndex(elementIndex.ImeIndexa, inStockName);  //obrisati dionicu iz indeksa 
                     }
                 }

                 foreach (Portfiljo elementPortfiljo in listaPortfelja)
                 {
                     if (IsStockPartOfPortfolio(elementPortfiljo.IdPortfiljo, inStockName))
                     {
                         RemoveStockFromPortfolio(elementPortfiljo.IdPortfiljo, inStockName); //obrisati dionicu iz portfelja
                     }
                 }

                 foreach (Dionica element in listaDionica)
                 {
                     if (element.ImeDionice.ToUpper() == inStockName.ToUpper())
                     {
                         listaDionica.Remove(element);
                         break;
                     }
                 }

             }
             else
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
             }
         }

         public bool StockExists(string inStockName)
         {
             bool nadeno =false;
             foreach (Dionica element in listaDionica)
             {
                 if (element.ImeDionice.ToUpper() == inStockName.ToUpper())
                 {
                     nadeno = true;
                     break;
                 }
             }
             return nadeno;
         }

         public int NumberOfStocks()
         {
             return listaDionica.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 if (inStockValue > 0)
                 {
                     foreach (Dionica elementDionica in listaDionica)
                     {
                         if (elementDionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             if (elementDionica.CijenaAktivnaOd == inIimeStamp)
                             {
                                 throw new StockExchangeException("Cijena vec difnirana za zadano vrijeme!");
                             }
                             else if (elementDionica.CijenaAktivnaOd < inIimeStamp) //ako je datum noviji, spremi stare podatke u history, a novima zamjeni trenutne
                             {
                                 staraCijena = new HistoryCijenaDionica(elementDionica.CijenaAktivnaOd, elementDionica.CijenaDionice);
                                 elementDionica.povijestCijenaDionica.Insert(0, staraCijena);
                                 elementDionica.povijestCijenaDionica.Sort((x, y) => y.DatumVrijemeAktivno.CompareTo(x.DatumVrijemeAktivno));
                                 elementDionica.CijenaAktivnaOd = inIimeStamp;
                                 elementDionica.CijenaDionice = inStockValue;
                             }
                             else // samo spremi u history podatke
                             {
                                 foreach (HistoryCijenaDionica elementPovijest in elementDionica.povijestCijenaDionica) //provjera da li vec postoji definirana cijena za defirnirano vrijeme
                                 {
                                     if (elementPovijest.DatumVrijemeAktivno == inIimeStamp)
                                     {
                                         throw new StockExchangeException("Cijena vec difnirana za zadano vrijeme!");
                                     }
                                 }
                                 staraCijena = new HistoryCijenaDionica(inIimeStamp, inStockValue);
                                 elementDionica.povijestCijenaDionica.Insert(0, staraCijena);
                                 elementDionica.povijestCijenaDionica.Sort((x, y) => y.DatumVrijemeAktivno.CompareTo(x.DatumVrijemeAktivno));
                                     
                                 
                             }
                             break;
                         }
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("Broj dionica mora biti veci od 0!");
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             decimal cijena = 0;
             if (StockExists(inStockName))
             {
                 foreach (Dionica element in listaDionica)
                 {
                     if (element.ImeDionice.ToUpper() == inStockName.ToUpper())
                     {
                         if (element.CijenaAktivnaOd <= inTimeStamp)
                         {
                             cijena = element.CijenaDionice;
                             break;
                         }
                         else
                         {
                             foreach (HistoryCijenaDionica povijest in element.povijestCijenaDionica)
                             {
                                if (povijest.DatumVrijemeAktivno <= inTimeStamp)
                                {
                                    cijena = povijest.CijenaZaVrijeme;
                                    break;
                                }
                             }
                         }
                         break;
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
             }
             return cijena;

         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             decimal cijena = 0;
             DateTime vrijeme = DateTime.MaxValue;
             foreach (Dionica elementDionica in listaDionica)
             {
                 if (elementDionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                 {
                     foreach (HistoryCijenaDionica elementHistory in elementDionica.povijestCijenaDionica)
                     {
                         if (elementHistory.DatumVrijemeAktivno < vrijeme)
                         {
                             vrijeme = elementHistory.DatumVrijemeAktivno;
                             cijena = elementHistory.CijenaZaVrijeme;
                         }
                     }
                     break;
                 }
             }
             if (cijena == 0)
                 {
                     throw new StockExchangeException("Dionica s tim imenom ne postoji, nemoguce odrediti pocetnu cijenu!");
                 }
             
             return cijena;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             decimal cijena = 0;
             foreach (Dionica element in listaDionica)
             {
                 if (element.ImeDionice.ToUpper() == inStockName.ToUpper()) 
                 {
                     cijena = element.CijenaDionice;
                     break;
                 }
             }
             if (cijena == 0)
                 {
                     throw new StockExchangeException("Dionica s tim imenom ne postoji, nemoguce odrediti cijenu!");
                 }
             
             return cijena;
         }

         public long GetTotalNumberOfShares(string inStockName) //koristi se kod provjere dostupnosti broja dionica
         {
             long broj = 0;
             if (StockExists(inStockName))
             {
                 foreach (Dionica element in listaDionica)
                 {
                     if (element.ImeDionice.ToUpper() == inStockName.ToUpper())
                     {
                         broj = element.BrojDionica;
                         break;
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
             }
             return broj;
         }

         public long GetNumberOfBoughtShares(string inStockName) //koristi se kod provjere dostupnosti broja dionica
         {
             long broj = 0;
             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 foreach (BrojZauzetihDionica elementZauzetaDionica in elementPortfiljo.listaDionica)
                 {
                     if (elementZauzetaDionica.Dionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                     {
                         broj += elementZauzetaDionica.Broj;
                     }
                 }
             }
             return broj;
         }

         #endregion

         #region Metode za indexe
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             index = new Index(inIndexName, inIndexType);
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index s tim imenom vec postoji, nemoguce dodati taj index!");
             }
             else if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Ne postoji index tog tipa, nemoguce dodati taj index!");
             }
             else
             {
                 listaIndexa.Add(index);
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji, nemoguce dodati tu dionicu u index!");
             }
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index s tim imenom ne postoji, nemoguce dodati tu dionicu u index!");
             }
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 throw new StockExchangeException("U indexu vec postoji dionica s tim imenom, nemoguce dodati tu dionicu u index!");
             }

             foreach (Index elementIndex in listaIndexa)
             {
                 if (elementIndex.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     foreach (Dionica elementDionica in listaDionica)
                     {
                         if (elementDionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             elementIndex.ListaDionica.Add(elementDionica);
                             break;
                         }
                     }
                     break;
                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji, nemoguce brisati tu dionicu iz indexa!");
             }
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index s tim imenom ne postoji, nemoguce brisati tu dionicu iz indexa!");
             }
             if (!IsStockPartOfIndex(inIndexName, inStockName))
             {
                 throw new StockExchangeException("U indexu ne postoji dionica s tim imenom, nemoguce brisati tu dionicu iz indexa!");
             }

             foreach (Index elementIndex in listaIndexa)
             {
                 if (elementIndex.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     foreach (Dionica elementDionica in elementIndex.ListaDionica)
                     {
                         if (elementDionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             elementIndex.ListaDionica.Remove(elementDionica);
                             break;
                         }
                     }
                     break;
                 }

             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool nadeno = false;
             
             foreach (Index elementIndex in listaIndexa)
             {
                 if (elementIndex.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     foreach (Dionica elementDionica in elementIndex.ListaDionica)
                     {
                         if (elementDionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             nadeno = true;
                             break;
                         }
                     }
                     break;

                 }
             }
             return nadeno;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal vrijednostIndexa = 0;
             decimal sumaCijenaDionica = 0;
             decimal tezisnkiFaktor = 0;
             decimal vrijednostDionice = 0;
             int broj = 0;

             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index s tim imenom ne postoji, nemoguce odrediti vrijednost!");
             }

             foreach (Index elementIndex in listaIndexa)
             {
                 if (elementIndex.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     if (elementIndex.TipIndexa == IndexTypes.AVERAGE)
                         {
                             foreach (Dionica elementDionica in elementIndex.ListaDionica)
                             {
                                 broj ++;
                                 vrijednostDionice = GetStockPrice(elementDionica.ImeDionice, inTimeStamp);
                                 sumaCijenaDionica += vrijednostDionice;
                             }
                             if (broj > 0) //radi sprijecavanja dijeljenja s 0
                             {
                                 vrijednostIndexa = Math.Round(sumaCijenaDionica/broj, 3);
                             }

                         }
                     else  
                         {
                             foreach (Dionica elementDionica in elementIndex.ListaDionica)
                             {
                                 vrijednostDionice = GetStockPrice(elementDionica.ImeDionice, inTimeStamp) * elementDionica.BrojDionica;
                                 sumaCijenaDionica += vrijednostDionice;
                             }
                             foreach (Dionica elementDionica in elementIndex.ListaDionica)
                             {
                                 vrijednostDionice = GetStockPrice(elementDionica.ImeDionice, inTimeStamp);
                                 tezisnkiFaktor = vrijednostDionice * elementDionica.BrojDionica / sumaCijenaDionica;
                                 vrijednostIndexa += tezisnkiFaktor * vrijednostDionice;
                             }
                             vrijednostIndexa = Math.Round(vrijednostIndexa, 3);
                         }
                     
                     break;
                 }
             }
             return vrijednostIndexa;
         }

         public bool IndexExists(string inIndexName)
         {
             bool nadeno = false;
             foreach (Index element in listaIndexa)
             {
                 if (element.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     nadeno = true;
                     break;
                 }
             }
             return nadeno;
         }

         public int NumberOfIndices()
         {
             return listaIndexa.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int broj = 0;
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index s tim imenom ne postoji, nemoguce odrediti broj dionica!");
             }

             foreach (Index elementIndex in listaIndexa)
             {
                 if (elementIndex.ImeIndexa.ToUpper() == inIndexName.ToUpper())
                 {
                     broj = elementIndex.ListaDionica.Count;
                 }
             }
             return broj;
         }

         #endregion

         #region Metode za portelje
         public void CreatePortfolio(string inPortfolioID)
         {
             portfiljo = new Portfiljo(inPortfolioID);
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om vec postoji, nemoguce dodati taj portfiljo!");
             }
             else
             {
                 listaPortfelja.Add(portfiljo);
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             long ukupanBrojDionica = GetTotalNumberOfShares(inStockName);
             long brojZauzetihDionica = GetNumberOfBoughtShares(inStockName);
             Dionica tmpDionica = listaDionica[0]; //nebitna pocetna vrijednost, bitno da je inicijalizirana
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om ne postoji, nemoguce dodati dionicu!");
             }

             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji, nemoguce dodati tu dionicu u portfiljo!");
             }

             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica koje se zele dodati mora biti veci od 0!");
             }

             if (IsStockPartOfPortfolio(inPortfolioID, inStockName)) //ako je dionica vec dio portfelja, pa treba dodati broj dionica
             {
                 if (numberOfShares <= ukupanBrojDionica - brojZauzetihDionica) //postoji li dovoljni broj slobodnih dionica
                 {
                     foreach (Portfiljo elementPortfiljo in listaPortfelja)
                     {
                         if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                         {
                             foreach (BrojZauzetihDionica elementZauzetaDionica in elementPortfiljo.listaDionica)
                             {
                                 if (elementZauzetaDionica.Dionica.ImeDionice == inStockName)
                                 {
                                     elementZauzetaDionica.Broj += numberOfShares;
                                     break;
                                 }
                             }
                             break;
                         }
    
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("Nema dovoljno slobodnih dionica na raspolaganju!");
                 }
             }
             else //ako dionica jos uopce nije dio portfelja
             {
                 foreach (Dionica elementDionica in listaDionica)  //naci zeljenu dionicu i njezine podatke
                 {
                     if (elementDionica.ImeDionice == inStockName)
                     {
                         tmpDionica = elementDionica;
                         break;
                     }
                 }

                 foreach (Portfiljo elementPortfiljo in listaPortfelja)
                 {
                     if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                     {
                         novaDionicaUPortfelju = new BrojZauzetihDionica(tmpDionica, numberOfShares);
                         elementPortfiljo.listaDionica.Add(novaDionicaUPortfelju);
                         break;
                     }
                 }
             }   
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("U portfelju ne postoji dionica s tim imenom, nemoguce brisati tu dionicu iz portfelja!");
             }
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica koje se žele brisati mora biti veći od 0!");
             }

             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                 {
                     foreach (BrojZauzetihDionica elementZauzetaDionica in elementPortfiljo.listaDionica)
                     {
                         if (elementZauzetaDionica.Dionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             if (elementZauzetaDionica.Broj > numberOfShares) //ako je preostali broj dionica veci od 0, samo oduzeti broj
                             {
                                 elementZauzetaDionica.Broj -= numberOfShares;
                             }
                             else
                             {
                                 RemoveStockFromPortfolio(inPortfolioID, inStockName);
                             }
                             break;
                         }
                     }
                     break;
                 }

             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("U portfelju ne postoji dionica s tim imenom, nemoguce brisati tu dionicu iz portfelja!");
             }

             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                 {
                     foreach (BrojZauzetihDionica elementZauzetaDionica in elementPortfiljo.listaDionica)
                     {
                         if (elementZauzetaDionica.Dionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             elementPortfiljo.listaDionica.Remove(elementZauzetaDionica);
                             break;
                         }
                     }
                     break;
                 }

             }
         }

         public int NumberOfPortfolios()
         {
             return listaPortfelja.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int broj = 0;
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om ne postoji, nemoguce odrediti broj dionica!");
             }

             foreach (Portfiljo element in listaPortfelja)
             {
                 if (element.IdPortfiljo == inPortfolioID)
                 {
                     broj = element.listaDionica.Count;
                 }
             }
             return broj;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool nadeno = false;
             foreach (Portfiljo element in listaPortfelja)
             {
                 if (element.IdPortfiljo == inPortfolioID)
                 {
                     nadeno = true;
                     break;
                 }
             }
             return nadeno;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool nadeno = false;

             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                 {
                     foreach (BrojZauzetihDionica elementDionica in elementPortfiljo.listaDionica)
                     {
                         if (elementDionica.Dionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             nadeno = true;
                             break;
                         }
                     }
                 break;
                 }
             }
             return nadeno;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int brojDionica = 0;

             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom ne postoji uopce");
             }
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om ne postoji uopce!");
             }

             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("Zadana dionica ne postoji u zadanom portfelju.");
             }

             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                 {
                     foreach (BrojZauzetihDionica elementDionica in elementPortfiljo.listaDionica)
                     {
                         if (elementDionica.Dionica.ImeDionice.ToUpper() == inStockName.ToUpper())
                         {
                             brojDionica = elementDionica.Broj;
                             break;
                         }
                     }
                     break;
                 }
             }
             return brojDionica;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal vrijednostPortfilja = 0;
             decimal vrijednostDionica = 0;

             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om ne postoji uopce!");
             }

             foreach (Portfiljo elementPortfiljo in listaPortfelja)
             {
                 if (elementPortfiljo.IdPortfiljo == inPortfolioID)
                 {
                     foreach (BrojZauzetihDionica elementDionica in elementPortfiljo.listaDionica)
                     {
                         if (elementDionica.Dionica.CijenaAktivnaOd <= timeStamp) //uzeti trenutrnu vrijednost cijene dionice
                         {
                             vrijednostPortfilja += elementDionica.Dionica.CijenaDionice * elementDionica.Broj;
                         }
                         else //uzeti cijenu iz history-a
                         {
                             vrijednostDionica = GetStockPrice(elementDionica.Dionica.ImeDionice, timeStamp);
                             vrijednostPortfilja += vrijednostDionica*elementDionica.Broj;
                         }
                     }
                     vrijednostPortfilja = Math.Round(vrijednostPortfilja, 3);
                     break;
                 }
             }
             return vrijednostPortfilja;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal vrijednostPromjene = 0;
             DateTime pocetakMjeseca = new DateTime(Year, Month, 1, 0, 0, 0);
             DateTime krajMjeseca = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             decimal vrijednostPocetakMjeseca = GetPortfolioValue(inPortfolioID, pocetakMjeseca);
             decimal vrijednostKrajMjeseca = GetPortfolioValue(inPortfolioID, krajMjeseca);

             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfiljo s tim ID-om ne postoji uopce!");
             }

             if (NumberOfStocksInPortfolio(inPortfolioID) == 0)
             {
                 throw new StockExchangeException("Nema dionica u tom portfelju, pa stoga nema ni promjene!");
             }
             if (vrijednostPocetakMjeseca != 0) // ako na pocetku vrijednost dionice bila 0, promjena je 0 jer nemoguce odrediti postotak od 0, a ako je na kraju vrijednost dionica 0, onda je promjena 100%
             {
                 vrijednostPromjene = (vrijednostKrajMjeseca - vrijednostPocetakMjeseca)/vrijednostPocetakMjeseca*100;
             }

             return vrijednostPromjene;
         }
         #endregion
     }
}
