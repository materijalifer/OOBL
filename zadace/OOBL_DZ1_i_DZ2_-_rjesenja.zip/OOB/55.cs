﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new MyCalculator();
        }
    }

    public class MyCalculator : ICalculator
    {
        CalculatorScreen screen;
        InternalCalculator internalCalc;

        public MyCalculator()
        {
            this.screen = new CalculatorScreen();
            this.internalCalc = new InternalCalculator();
        }

        public void Press(char inPressedDigit)
        {
            this.screen.AddElement(inPressedDigit.ToString());
        }

        public string GetCurrentDisplayState()
        {
            String newScreenData = this.internalCalc.CalculateExression(this.screen.getScreenElements());
            this.screen.SetScreenData(newScreenData);
            return this.screen.ToString();
        }
    }

    public class InternalCalculator
    {
        public static String Error = "-E-";

        public CalculatorNumber memory;

        public InternalCalculator()
        {
            this.memory = null;
        }

        public String CalculateExression(List<String> expression)
        {
            try
            {
                List<CalculatorElement> listOfElements = new List<CalculatorElement>();
                listOfElements = CalculatorElement.ParseExpression(Util.ListToArray(expression), 0, listOfElements);
                CalculatorNumber result = null;
                result = Calculate(listOfElements.ToArray());
                return result.ToString();
            }
            catch (FormatException e)
            {
                return Error;
            }
        }

        private CalculatorNumber Calculate(CalculatorElement[] expression)
        {
            CalculatorNumber result = (CalculatorNumber)expression[0];
            result = CalculateAll(expression, 0, result);
            return result;
        }

        private CalculatorNumber CalculateAll(CalculatorElement[] expression, int index, CalculatorNumber result)
        {
            if (index < expression.Length)
            {
                //projerava da li postoji sljedeća vrijednost u izrazu
                if (index + 1 < expression.Length)
                {
                    //provjerava kakvu vrstu operacije treba izvesti
                    if (expression[index + 1].GetType() == (typeof(SingleOperaterOperation)))
                    {
                        result = ((SingleOperaterOperation)expression[index + 1]).CalculateOperation((CalculatorNumber)expression[index]);
                        result = CalculateAll(expression, index + 1, result);
                    }
                    else if (expression[index + 1].GetType() == typeof(DubleOperatorOperation))
                    {

                        if (index + 2 < expression.Length)
                        {
                            result = ((DubleOperatorOperation)expression[index + 1]).CalculateOperation(result, (CalculatorNumber)expression[index + 2]);
                            result = CalculateAll(expression, index + 2, result);
                        }
                        else
                        {
                            throw new FormatException("Uneseni niz nije pravilnog oblika");
                        }
                    }
                    else if (expression[index + 1].GetType() == typeof(SystemCalculatorOperation))
                    {
                        result = ((SystemCalculatorOperation)expression[index + 1]).ExecuteOperation(result, this);
                        result = CalculateAll(expression, index + 1, result);
                    }
                    else
                    {//broj je
                        string newResult = result.ToString() + ((CalculatorNumber)expression[index + 1]).ToString();
                        result = CalculateAll(expression, index + 1, new CalculatorNumber(newResult));
                    }

                }
                else
                {
                    return result;
                }
            }
            return result;
        }
    }

    public class CalculatorElement
    {
        public static String Zero = "0";
        public static String One = "1";
        public static String Two = "2";
        public static String Three = "3";
        public static String Four = "4";
        public static String Five = "5";
        public static String Six = "6";
        public static String Seven = "7";
        public static String Eight = "8";
        public static String Nine = "9";

        public static String CalculatorDecimalSeparator = ",";
        public static String NumberDecimalSeparator = ".";

        private static String[] arrayOfAllDigets = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        public static List<String> AllDigets = new List<string>(arrayOfAllDigets);

        //predznaci
        public static String AlgebicSignPlus = "+";
        public static String AlgebicSignMinus = "-";

        //operatori sa dva operanada
        public static String Addition = "+";
        public static String Subtraction = "-";
        public static String Multiplication = "*";
        public static String Devision = "/";

        //operatori sa jednim operandom
        public static String Sinus = "S";
        public static String Cosinus = "K";
        public static String Tangens = "T";
        public static String Square = "Q";
        public static String Root = "R";
        public static String Invers = "I";
        public static String InvertAlgebricSign = "M";

        //operacije kalkulatora
        public static String OnOff = "O";
        public static String StoreToMemory = "P";
        public static String GetFromMemory = "G";
        public static String ClearScreen = "C";
        public static String Equal = "=";

        private static String[] listOfAllOperations = { Addition, Subtraction, Multiplication, Devision, InvertAlgebricSign, Sinus, Cosinus, Tangens, Square, Root, Invers, OnOff, Equal, StoreToMemory, GetFromMemory, ClearScreen };
        public static List<String> AllOperations = new List<string>(listOfAllOperations);

        public static bool IsOperation(String input)
        {
            if (AllOperations.Contains(input))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsDigit(String input)
        {
            if (AllDigets.Contains(input))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static bool IsNumber(String input)
        {
            char[] parsInput = input.ToArray();
            for (int i = 0; i < parsInput.Length; i++)
            {
                if (CalculatorElement.IsOperation(parsInput[i].ToString()))
                {
                    return false;
                }
            }
            return true;
        }

        public static List<CalculatorElement> ParseExpression(String[] expression, int index, List<CalculatorElement> listOfElements)
        {
            StringBuilder operand = new StringBuilder();
            bool parsedOperand = false;

            if (expression.Length > index)
            {

                while (expression.Length > index && CalculatorNumber.isNumberElement(expression[index]))
                {
                    parsedOperand = true;
                    operand.Append(expression[index]);
                    index++;
                }
                if (parsedOperand)
                {
                    listOfElements.Add(new CalculatorNumber(operand.ToString()));
                }
                else
                {
                    //dodaje operaciju u izraz
                    if (SingleOperaterOperation.IsSingleOperaterOperation(expression[index]))
                    {
                        listOfElements.Add(new SingleOperaterOperation(expression[index]));
                    }
                    else if (DubleOperatorOperation.IsDoubleOperatorOperation(expression[index]))
                    {
                        listOfElements.Add(new DubleOperatorOperation(expression[index]));
                    }
                    else if (SystemCalculatorOperation.IsSystemCalculatorOperation(expression[index]))
                    {
                        listOfElements.Add(new SystemCalculatorOperation(expression[index]));
                    }
                    else
                    {
                        throw new InvalidOperationException("Operacija nije podrzana");
                    }
                    index++;
                }

                listOfElements = ParseExpression(expression, index, listOfElements);
            }
            return listOfElements;
        }
    }

    public class CalculatorNumber : CalculatorElement
    {
        public const int MaxNumberOfDigits = 10;

        string number;
        string decimalNumber; // sadrzi . kao separator a ne ,

        public CalculatorNumber(string numberString)
        {
            char[] numElements = numberString.ToArray();

            StringBuilder number = new StringBuilder();
            StringBuilder decNumber = new StringBuilder();

            bool inverAlgebricSign = false;
            bool hasDecimalSpace = false;
            int numberOfDigits = 0;
            for (int i = 0; i < numElements.Length; i++)
            {
                // decimalni separator
                if (numElements[i].ToString().Equals(CalculatorElement.CalculatorDecimalSeparator) ||
                        numElements[i].ToString().Equals(CalculatorElement.NumberDecimalSeparator))
                {
                    if (i == 0)
                    { //ako je broj oblika ,X 
                        number.Append(CalculatorElement.Zero);
                        decNumber.Append(CalculatorElement.Zero);
                    }
                    hasDecimalSpace = true;
                    number.Append(CalculatorElement.CalculatorDecimalSeparator);
                    decNumber.Append(CalculatorElement.NumberDecimalSeparator); //ododaje se . umjesto ,
                }
                //ako se u broju nalazi M
                else if (numElements[i].ToString().Equals(CalculatorElement.InvertAlgebricSign))
                {

                    inverAlgebricSign = true;
                }
                //ako je prvi znak predznak broja (+)
                else if (i == 0 && numElements[i].ToString().Equals(CalculatorElement.AlgebicSignPlus))
                {
                    //ignorira se
                    //ako je prvi znak predznak broja (-)
                }
                else if (i == 0 && numElements[i].ToString().Equals(CalculatorElement.AlgebicSignMinus))
                {

                    number.Append(CalculatorElement.AlgebicSignMinus);
                    decNumber.Append(CalculatorElement.AlgebicSignMinus);

                    //nova znamenka
                }
                else
                {
                    if (numberOfDigits < MaxNumberOfDigits)
                    {
                        number.Append(numElements[i]);
                        decNumber.Append(numElements[i]);
                        numberOfDigits++;
                    }
                    else
                    {
                        if (!hasDecimalSpace)
                        { //dogodila se greska ima revise brojeva
                            throw new FormatException("Rezultat ima previse brojeva");
                        }
                        //prevsen je maksimalni broj znamenki
                    }
                }
            }

            if (inverAlgebricSign == true)
            {
                char[] numberElements = number.ToString().ToArray(); //prvi element broja
                string firstElement = numberElements[0].ToString();
                if (CalculatorElement.IsDigit(firstElement))
                {//prvi element je broj
                    number = Insert(number, CalculatorElement.AlgebicSignMinus, 0);
                    decNumber = Insert(decNumber, CalculatorElement.AlgebicSignMinus, 0);
                }
                else if (firstElement.Equals(CalculatorElement.AlgebicSignMinus))
                {//prvi element je znak minus
                    number = number.Replace(CalculatorElement.AlgebicSignMinus, CalculatorElement.AlgebicSignPlus);
                    decNumber = decNumber.Replace(CalculatorElement.AlgebicSignMinus, CalculatorElement.AlgebicSignPlus);
                }
                else
                {//prvi element je znak plus
                    number = number.Replace(CalculatorElement.AlgebicSignPlus, CalculatorElement.AlgebicSignMinus);
                    decNumber = decNumber.Replace(CalculatorElement.AlgebicSignPlus, CalculatorElement.AlgebicSignMinus);
                }
            }

            this.number = number.ToString();
            this.decimalNumber = decNumber.ToString();
        }

        //dodaje element na poziciju a ostale pomice u desno
        private StringBuilder Insert(StringBuilder str, string element, int position)
        {
            StringBuilder newStr = new StringBuilder();
            char[] strElements = str.ToString().ToArray();
            for (int i = 0; i < strElements.Length; i++)
            {
                if (i == position)
                {
                    newStr.Append(element);
                    newStr.Append(strElements[i]);
                }
                else
                {
                    newStr.Append(strElements[i]);
                }
            }
            return newStr;
        }

        public decimal ToDecimal()
        {
            return decimal.Parse(this.decimalNumber);
        }

        public override string ToString()
        {
            return this.number;
        }

        public double ToDouble()
        {
            return Double.Parse(this.decimalNumber);
        }

        //helper functions
        public static bool isNumberElement(string element)
        {
            if (CalculatorElement.IsDigit(element) || element.Equals(CalculatorElement.InvertAlgebricSign) ||
                element.Equals(CalculatorElement.CalculatorDecimalSeparator))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    class CalculatorOperation : CalculatorElement
    {
        string operation;

        public CalculatorOperation(string calcOperation)
        {
            this.operation = calcOperation;
        }
    }

    class SystemCalculatorOperation : CalculatorOperation
    {
        private static String[] listOfSystemCalculatorOperations = { OnOff, Equal, StoreToMemory, GetFromMemory, ClearScreen };
        public static List<String> SystemCalculatorOperations = new List<string>(listOfSystemCalculatorOperations);

        string operation;

        public SystemCalculatorOperation(string opr)
            : base(opr)
        {
            this.operation = opr;

        }

        public CalculatorNumber ExecuteOperation(CalculatorNumber result, InternalCalculator calculator)
        {
            if (operation.Equals(CalculatorElement.OnOff))
            {
                result = new CalculatorNumber(CalculatorElement.Zero);
                calculator.memory = new CalculatorNumber(CalculatorElement.Zero);
            }
            else if (operation.Equals(CalculatorElement.Equal))
            {
                result = RemoveUnneededZeroes(result);
            }
            else if (operation.Equals(CalculatorElement.StoreToMemory))
            {
                calculator.memory = result;
            }
            else if (operation.Equals(CalculatorElement.GetFromMemory))
            {
                result = calculator.memory;
            }
            else if (operation.Equals(CalculatorElement.ClearScreen))
            {
                result = new CalculatorNumber(CalculatorElement.Zero);
            }
            else
            {
                result = null;
            }
            return result;
        }

        private CalculatorNumber RemoveUnneededZeroes(CalculatorNumber result)
        {
            char[] resultElements = result.ToString().ToArray();
            bool hasDecimalSpace = false;
            int lastNonZero = 0;
            for (int i = 0; i < resultElements.Length; i++)
            {

                if (hasDecimalSpace == true && resultElements[i].Equals(CalculatorElement.Zero))
                {
                    //i dalje su nule
                }
                else if (hasDecimalSpace == true && !resultElements[i].Equals(CalculatorElement.Zero))
                {
                    lastNonZero = i;
                }
                else if (resultElements[i].Equals("."))
                {
                    hasDecimalSpace = true;
                }
            }

            if (hasDecimalSpace == false)
            {
                return result;
            }
            else
            {
                StringBuilder roundedResult = new StringBuilder();
                for (int i = 0; i < lastNonZero; i++)
                {
                    roundedResult.Append(resultElements[i]);
                }
                return new CalculatorNumber(roundedResult.ToString());
            }

        }


        public static bool IsSystemCalculatorOperation(string operation)
        {
            if (SystemCalculatorOperations.Contains(operation))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    class SingleOperaterOperation : CalculatorOperation
    {
        private static String[] listOfSingleOperationOperators = { InvertAlgebricSign, Sinus, Cosinus, Tangens, Square, Root, Invers };
        public static List<String> SingleOperatorOperations = new List<string>(listOfSingleOperationOperators);

        string operation;

        public SingleOperaterOperation(string calcOperation)
            : base(calcOperation)
        {
            this.operation = calcOperation;
        }

        public CalculatorNumber CalculateOperation(CalculatorNumber argumnet)
        {
            decimal result = 0;
            if (operation.Equals(CalculatorElement.InvertAlgebricSign))
            {
                decimal num = argumnet.ToDecimal();
                result = num * (-1);

            }
            else if (operation.Equals(CalculatorElement.Sinus))
            {
                double newResult = Math.Sin(argumnet.ToDouble());
                result = (Decimal)newResult;
            }
            else if (operation.Equals(CalculatorElement.Cosinus))
            {
                double newResult = Math.Cos(argumnet.ToDouble());
                result = (Decimal)newResult;
            }
            else if (operation.Equals(CalculatorElement.Tangens))
            {
                double newResult = Math.Tan(argumnet.ToDouble());
                result = (Decimal)newResult;
            }
            else if (operation.Equals(CalculatorElement.Square))
            {
                double newResult = Math.Pow(argumnet.ToDouble(), 2);
                result = (Decimal)newResult;
            }
            else if (operation.Equals(CalculatorElement.Root))
            {
                double newResult = Math.Sqrt(argumnet.ToDouble());
                result = (Decimal)newResult;
            }
            else if (operation.Equals(CalculatorElement.Invers))
            {
                if (argumnet.ToDecimal() == 0)
                {
                    throw new FormatException("Pokusalo se dijeliti sa nula");
                }
                result = 1 / argumnet.ToDecimal();
            }
            else
            {

            }
            return new CalculatorNumber(result.ToString());
        }

        public static bool IsSingleOperaterOperation(string operation)
        {
            if (SingleOperatorOperations.Contains(operation))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }

    class DubleOperatorOperation : CalculatorOperation
    {
        private static String[] listOfDubleOperationOperators = { Addition, Subtraction, Multiplication, Devision };
        public static List<String> DubleOperatorOperations = new List<string>(listOfDubleOperationOperators);

        string operation;

        public DubleOperatorOperation(string opr)
            : base(opr)
        {
            this.operation = opr;
        }

        public CalculatorNumber CalculateOperation(CalculatorNumber firstOperator, CalculatorNumber secondOperator)
        {
            decimal result = 0;
            decimal firstOp = firstOperator.ToDecimal();
            decimal secondOp = secondOperator.ToDecimal();
            if (this.operation.Equals(CalculatorElement.Addition))
            {
                result = firstOp + secondOp;
            }
            else if (this.operation.Equals(CalculatorElement.Subtraction))
            {
                result = firstOp - secondOp;
            }
            else if (this.operation.Equals(CalculatorElement.Multiplication))
            {
                result = firstOp * secondOp;
            }
            else if (this.operation.Equals(CalculatorElement.Devision))
            {
                if (secondOp == 0)
                {
                    new FormatException("Pokusalo se dijeliti sa nula!");
                }
                result = firstOp / secondOp;
            }

            return new CalculatorNumber(result.ToString());
        }

        public static bool IsDoubleOperatorOperation(string operation)
        {
            if (DubleOperatorOperations.Contains(operation))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }

    public class CalculatorScreen
    {
        List<String> screenElemetns;

        public bool startUpScreenOn { get; set; }//kada se na ekranu pokazuje pocetna nula


        public CalculatorScreen()
        {
            this.screenElemetns = new List<string>();
            this.screenElemetns.Add(CalculatorElement.Zero);
            this.startUpScreenOn = true;
        }

        public void AddElement(String element)
        {
            if (this.startUpScreenOn.Equals(true))
            {
                //ako se dok je startUpScreen ukljucen stisne nula nista se ne dodaje
                if (!element.Equals(CalculatorElement.Zero))
                {

                    //brise 0 sa ekrana i mice startUpScreen
                    this.startUpScreenOn = false;
                    this.screenElemetns.Remove(CalculatorElement.Zero);

                    //dodaje element na ekran
                    this.screenElemetns.Add(element);
                }
            }
            else
            {
                //ako je samo nula na ekranu onda se druga nula ne dodaje
                if (!this.screenElemetns.ElementAt(0).Equals(CalculatorElement.Zero) &&
                        !element.Equals(CalculatorElement.Zero))
                {
                    this.screenElemetns.Add(element);
                }
            }
        }

        public void SetScreenData(String newScreenData)
        {
            this.screenElemetns.Clear();
            char[] listOfScrData = newScreenData.ToArray();
            for (int i = 0; i < listOfScrData.Length; i++)
            {
                this.screenElemetns.Add(listOfScrData[i].ToString());
            }
        }

        public List<String> getScreenElements()
        {
            return this.screenElemetns;
        }

        public override String ToString()
        {
            StringBuilder screenToString = new StringBuilder();
            foreach (String screenElement in this.screenElemetns)
            {
                screenToString.Append(screenElement);
            }
            return screenToString.ToString();
        }
    }

    class Util
    {
        public static String[] ListToArray(List<String> list)
        {
            String[] stringArray = new String[list.Count];
            int counter = 0;
            foreach (String str in list)
            {
                stringArray[counter] = str;
                counter++;
            }
            return stringArray;
        }
    }


}
