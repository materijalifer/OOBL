using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public class StockExchange : IStockExchange
    {
        private readonly List<Index> _indices;
        private readonly List<Portfolio> _portfolios;
        private readonly List<Stock> _stocks;

        public StockExchange()
        {
            this._stocks = new List<Stock>();
            this._indices = new List<Index>();
            this._portfolios = new List<Portfolio>();
        }

        #region Stocks

        // Dodavanje dionice na burzu
        public void ListStock( string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp )
        {
            if ( this.StockExists( inStockName ) )
                throw new StockExchangeException( "Dionica s unesenim imenom već postoji" );
            var stock = new Stock( inStockName, inNumberOfShares, inInitialPrice, inTimeStamp );
            this._stocks.Add( stock );
        }

        // Micanje dionice sa burze
        public void DelistStock( string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            foreach ( Index index in this._indices ) // micanje dionice iz svih indeksa gdje je dodana
            {
                if ( index.IsStockPartOfIndex( stock ) )
                    index.RemoveStockFromIndex( stock );
            }
            foreach ( Portfolio portfolio in this._portfolios ) // micanje dionice iz svih portfelja gdje je definirana
            {
                if ( portfolio.IsStockPartOfPortfolio( stock ) )
                    portfolio.RemoveStockFromPortfolio( stock );
            }
            this._stocks.Remove( stock );
        }

        // Provjera je li definirana dionica sa zadanim imenom
        public bool StockExists( string inStockName )
        {
            Stock stock = this._stocks.Find( s => s.Name.ToLower() == inStockName.ToLower() );
            if ( stock == null )
                return false;
            return true;
        }

        // Vraca broj dionica na burzi
        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

        // Postavlja novu cijenu nekoj dionici
        public void SetStockPrice( string inStockName, DateTime inIimeStamp, decimal inStockValue )
        {
            Stock stock = this.GetStock( inStockName );
            stock.AddNewStockPrice( inStockValue, inIimeStamp );
        }

        // Vraca cijenu dionice u zadano vrijeme
        public decimal GetStockPrice( string inStockName, DateTime inTimeStamp )
        {
            Stock stock = this.GetStock( inStockName );
            return stock.GetStockPrice( inTimeStamp );
        }

        // Vraca najstariju cijenu dionice
        public decimal GetInitialStockPrice( string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            return stock.GetInitialStockPrice();
        }

        // Vraca najnoviju cijenu dionice
        public decimal GetLastStockPrice( string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            return stock.GetLastStockPrice();
        }

        // Pomocna metoda za dohvat dionice
        private Stock GetStock( string stockName )
        {
            Stock stock = this._stocks.Find( s => s.Name.ToLower() == stockName.ToLower() );
            if ( stock == null )
                throw new StockExchangeException( "Dionica s unesenim imenom ne postoji" );
            return stock;
        }

        #endregion

        #region Indices

        // Dodavanje indeksa na burzu
        public void CreateIndex( string inIndexName, IndexTypes inIndexType )
        {
            if ( this.IndexExists( inIndexName ) )
                throw new StockExchangeException( "Indeks s unesenim imenom već postoji" );
            Index index = Factory.CreateIndex( inIndexName, inIndexType ); // metoda tvornica
            this._indices.Add( index );
        }

        // Dodavanje dionice u indeks
        public void AddStockToIndex( string inIndexName, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Index index = this.GetIndex( inIndexName );
            index.AddStockToIndex( stock );
        }

        // Micanje dionice iz indeksa
        public void RemoveStockFromIndex( string inIndexName, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Index index = this.GetIndex( inIndexName );
            index.RemoveStockFromIndex( stock );
        }

        // Provjera je li dionica pripada indeksu
        public bool IsStockPartOfIndex( string inIndexName, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Index index = this.GetIndex( inIndexName );
            return index.IsStockPartOfIndex( stock );
        }

        // Vraca vrijednost indeksa
        public decimal GetIndexValue( string inIndexName, DateTime inTimeStamp )
        {
            Index index = this.GetIndex( inIndexName );
            return index.GetIndexValue( inTimeStamp );
        }

        // Provjera postoji li indeks na burzi
        public bool IndexExists( string inIndexName )
        {
            Index index = this._indices.Find( i => i.Name.ToLower() == inIndexName.ToLower() );
            if ( index == null )
                return false;
            return true;
        }

        // Vraca broj indeksa na burzi
        public int NumberOfIndices()
        {
            return this._indices.Count;
        }

        // Vraca broj dionica u indeksu
        public int NumberOfStocksInIndex( string inIndexName )
        {
            Index index = this.GetIndex( inIndexName );
            return index.GetNumberOfStocksInIndex();
        }

        // Pomocna metoda za dohvat indeksa
        private Index GetIndex( string indexName )
        {
            Index index = this._indices.Find( i => i.Name.ToLower() == indexName.ToLower() );
            if ( index == null )
                throw new StockExchangeException( "Indeks s unesenim imenom ne postoji" );
            return index;
        }

        #endregion

        #region Portfolios

        // Dodaje novi portfelj na burzu
        public void CreatePortfolio( string inPortfolioID )
        {
            if ( this.PortfolioExists( inPortfolioID ) )
                throw new StockExchangeException( "Portfolio s unesenim ID-em već postoji" );
            var portfolio = new Portfolio( inPortfolioID );
            this._portfolios.Add( portfolio );
        }

        // Dodavanje dionice u portfelj
        public void AddStockToPortfolio( string inPortfolioID, string inStockName, int numberOfShares )
        {
            Stock stock = this.GetStock( inStockName );
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            int totalNumberOfSharesOfStockInPortfolios = this.GetTotalNumberOfSharesOfStockInPortfolios( stock );
            portfolio.AddStockToPortfolio( stock, numberOfShares, totalNumberOfSharesOfStockInPortfolios );
        }

        // Micanje određenog broja udjela dionice iz portfelja
        public void RemoveStockFromPortfolio( string inPortfolioID, string inStockName, int numberOfShares )
        {
            Stock stock = this.GetStock( inStockName );
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            portfolio.RemoveStockFromPortfolio( stock, numberOfShares );
        }

        // Micanje dionice iz portfelja
        public void RemoveStockFromPortfolio( string inPortfolioID, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            portfolio.RemoveStockFromPortfolio( stock );
        }

        // Vraca broj portfelja
        public int NumberOfPortfolios()
        {
            return this._portfolios.Count;
        }

        // Vraca broj dionica u portfelju
        public int NumberOfStocksInPortfolio( string inPortfolioID )
        {
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            return portfolio.GetNumberOfStocksInPortfolio();
        }

        // Provjera je li definiran portfelj sa zadanim ID-em
        public bool PortfolioExists( string inPortfolioID )
        {
            Portfolio portfolio = this._portfolios.Find( p => p.Id == inPortfolioID );
            if ( portfolio == null )
                return false;
            return true;
        }

        // Provjera je li dionica dio portfelja
        public bool IsStockPartOfPortfolio( string inPortfolioID, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            return portfolio.IsStockPartOfPortfolio( stock );
        }

        // Vraca broj udjela dionice u portfelju
        public int NumberOfSharesOfStockInPortfolio( string inPortfolioID, string inStockName )
        {
            Stock stock = this.GetStock( inStockName );
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            return portfolio.GetNumberOfSharesOfStockInPortfolio( stock );
        }

        // Vraca vrijednost portfelja u zadanom trenutku
        public decimal GetPortfolioValue( string inPortfolioID, DateTime timeStamp )
        {
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            return portfolio.GetPortfolioValue( timeStamp );
        }

        // Vraca promjenu portfelja zadanog mjeseca zadane godine
        // Vraca se postotak (negativan ako se vrijednost smanjila, a pozitivan ako se vrijednost povecala)
        public decimal GetPortfolioPercentChangeInValueForMonth( string inPortfolioID, int year, int month )
        {
            Portfolio portfolio = this.GetPortfolio( inPortfolioID );
            return portfolio.GetPortfolioPercentChangeInValueForMonth( year, month );
        }

        // Pomocna metoda za dohvat portfelja
        private Portfolio GetPortfolio( string portfolioID )
        {
            Portfolio portfolio = this._portfolios.Find( p => p.Id == portfolioID );
            if ( portfolio == null )
                throw new StockExchangeException( "Portfolio s unesenim ID-em ne postoji" );
            return portfolio;
        }

        // Pomocna metoda za dohvat ukupnog broja udjela neke dionice u svim portfeljima
        private int GetTotalNumberOfSharesOfStockInPortfolios( Stock stock )
        {
            return ( from portfolio in this._portfolios
                     where portfolio.IsStockPartOfPortfolio( stock )
                     select portfolio.GetNumberOfSharesOfStockInPortfolio( stock ) ).Sum();
        }

        #endregion
    }

    public class Stock
    {
        private readonly string _name;
        private readonly long _numberOfShares;
        private readonly SortedList<DateTime, decimal> _prices;

        public Stock( string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp )
        {
            this._name = stockName;

            if ( numberOfShares <= 0 )
                throw new StockExchangeException( "Broj dionica ne smije biti negativan" );
            this._numberOfShares = numberOfShares;

            if ( initialPrice <= 0 )
                throw new StockExchangeException( "Početna cijena dionice ne smije biti negativna" );
            this._prices = new SortedList<DateTime, decimal> { { timeStamp, initialPrice } };
        }

        public string Name
        {
            get { return this._name; }
        }

        public long NumberOfShares
        {
            get { return this._numberOfShares; }
        }

        // Dodavanje nove cijene dionice
        public void AddNewStockPrice( decimal newStockPrice, DateTime newIimeStamp )
        {
            if ( newStockPrice <= 0 )
                throw new StockExchangeException( "Cijena dionice ne smije biti negativna" );
            if ( this._prices.ContainsKey( newIimeStamp ) )
                throw new StockExchangeException( "Cijena za zadano vrijeme je već definirana" );
            this._prices.Add( newIimeStamp, newStockPrice );
        }

        // Dohvat cijene dionice za zadani timestamp
        public decimal GetStockPrice( DateTime dateTime )
        {
            if ( dateTime < this._prices.Keys[0] )
                throw new StockExchangeException( "Dionica nema definiranu cijenu za traženo vrijeme" );
            decimal price = this._prices.Values[0];
            foreach ( var timePricePair in this._prices ) // algoritam vraca cijenu za najvece vrijeme koje je manje/jednako dateTime
            {
                if ( timePricePair.Key <= dateTime )
                    price = timePricePair.Value;
                else
                    return price;
            }
            return price;
        }

        // Dohvat najstarije cijene dionice
        public decimal GetInitialStockPrice()
        {
            return this._prices.Values[0];
        }

        // Dohvat najnovije cijene dionice
        public decimal GetLastStockPrice()
        {
            return this._prices.Values[this._prices.Count - 1];
        }
    }

    public class Portfolio
    {
        private readonly string _id;
        private readonly Dictionary<Stock, int> _stocks;

        public Portfolio( string portfolioID )
        {
            this._id = portfolioID;
            this._stocks = new Dictionary<Stock, int>();
        }

        public string Id
        {
            get { return this._id; }
        }

        // Dodavanje dionica u portfelj
        // TotalNumberOfSharesOfStockInPortfolios predstavlja trenutni broj udjela dionice stock u svim portfeljima
        public void AddStockToPortfolio( Stock stock, int numberOfShares, int totalNumberOfSharesOfStockInPortfolios )
        {
            if ( numberOfShares < 0 )
                throw new StockExchangeException( "Broj udjela mora biti pozitivan broj" );
            if ( numberOfShares + totalNumberOfSharesOfStockInPortfolios > stock.NumberOfShares )
            {
                throw new StockExchangeException(
                    "Broj udjela koji se žele dodati u portfelj je veći od maksimalnog broja udjela dionice na burzi" );
            }

            if ( this.IsStockPartOfPortfolio( stock ) ) // ako je dionica vec dodana u portfelj, povecaj broj udjela u portfelju
                this._stocks[stock] += numberOfShares;
            else if ( numberOfShares > 0 ) // ako dionice nema u portfelju, dodaje se u portfelj
                this._stocks.Add( stock, numberOfShares );
        }

        // Micanje udjela dionice iz portfelja
        public void RemoveStockFromPortfolio( Stock stock, int numberOfShares )
        {
            if ( !this.IsStockPartOfPortfolio( stock ) )
                throw new StockExchangeException( "Dionica nije dio portfelja" );
            if ( numberOfShares < 0 )
                throw new StockExchangeException( "Broj udjela mora biti pozitivan broj" );

            if ( numberOfShares < this._stocks[stock] ) // ako je broj udjela koji se zeli maknuti manji od trenutnog, mice se
                this._stocks[stock] -= numberOfShares;
            else if ( numberOfShares == this._stocks[stock] ) // ako je broj udjela koji se zeli maknuti jednak trenutnom, mice se cijela dionica
                this._stocks.Remove( stock );
            else
            {
                throw new StockExchangeException(
                    "Broj udjela koji se žele izbrisati iz portfelja je veći od ukupnog broja udjela u portfelju" );
            }
        }

        // Micanje dionice iz portfelja
        public void RemoveStockFromPortfolio( Stock stock )
        {
            if ( !this.IsStockPartOfPortfolio( stock ) )
                throw new StockExchangeException( "Dionica nije dio portfelja" );
            this._stocks.Remove( stock );
        }

        // Dohvacanje broja dionica u portfelju
        public int GetNumberOfStocksInPortfolio()
        {
            return this._stocks.Count;
        }

        // Je li dionica dio portfelja
        public bool IsStockPartOfPortfolio( Stock stock )
        {
            if ( this._stocks.ContainsKey( stock ) )
                return true;
            return false;
        }

        // Dohvaca broj udjela dionice u portfelju
        public int GetNumberOfSharesOfStockInPortfolio( Stock stock )
        {
            if ( !this.IsStockPartOfPortfolio( stock ) )
                throw new StockExchangeException( "Dionica nije dio portfelja" );
            return this._stocks[stock];
        }

        // Vraca vrijednost portfelja
        // Baca exception u slucaju da bilo koja dionica nema cijenu za zadani timestamp
        public decimal GetPortfolioValue( DateTime timeStamp )
        {
            decimal value =
                this._stocks.Sum( stockSharesPair => stockSharesPair.Key.GetStockPrice( timeStamp ) * stockSharesPair.Value );
            return decimal.Round( value, 3 );
        }

        // Vraca promjenu vrijednosti portfelja za zadani mjesec zadane godine
        // Baca exception u slucaju da bilo koja dionica nema cijenu za prvu i zadnju milisekundu zadanog mjeseca zadane godine
        public decimal GetPortfolioPercentChangeInValueForMonth( int year, int month )
        {
            if ( this.GetNumberOfStocksInPortfolio() == 0 )
                return 0;
            var startingDate = new DateTime( year, month, 1, 0, 0, 0, 0 );
            decimal startingPrice = this.GetPortfolioValue( startingDate );
            var endingDate = new DateTime( year, month, DateTime.DaysInMonth( year, month ), 23, 59, 59, 999 );
            decimal endingPrice = this.GetPortfolioValue( endingDate );
            decimal valueChange = ( ( endingPrice - startingPrice ) / startingPrice ) * 100;
            return decimal.Round( valueChange, 3 );
        }
    }

    public abstract class Index
    {
        protected string _name;
        protected List<Stock> _stocks;
        protected IndexTypes _type;

        public string Name
        {
            get { return this._name; }
        }

        public IndexTypes Type
        {
            get { return this._type; }
        }

        // Dodavanje novih dionica u indeks
        public void AddStockToIndex( Stock stock )
        {
            if ( this.IsStockPartOfIndex( stock ) )
                throw new StockExchangeException( "Zadana dionica je već dodana u indeks" );
            this._stocks.Add( stock );
        }

        // Micanje dionica iz indeksa
        public void RemoveStockFromIndex( Stock stock )
        {
            if ( !this.IsStockPartOfIndex( stock ) )
                throw new StockExchangeException( "Zadana dionica se ne nalazi u indeksu" );
            this._stocks.Remove( stock );
        }

        // Provjera je li dionica u indeksu
        public bool IsStockPartOfIndex( Stock stock )
        {
            return this._stocks.Contains( stock );
        }

        // Broj dionica trenutno u indeksu
        public int GetNumberOfStocksInIndex()
        {
            return this._stocks.Count;
        }

        public abstract decimal GetIndexValue( DateTime inTimeStamp );
    }

    public class AverageIndex : Index
    {
        public AverageIndex( string indexName, IndexTypes indexType )
        {
            this._name = indexName;
            this._type = indexType;
            this._stocks = new List<Stock>();
        }

        // Izracun vrijednosti indeksa za average tip indeksa
        // Baca exception u slucaju da neka dionica iz indeksa nema zadanu cijenu za trazeni timestamp
        public override decimal GetIndexValue( DateTime inTimeStamp )
        {
            if ( this.GetNumberOfStocksInIndex() == 0 )
                return 0;
            decimal sumOfPrices = this._stocks.Sum( stock => stock.GetStockPrice( inTimeStamp ) );
            decimal index = sumOfPrices / this.GetNumberOfStocksInIndex();
            return decimal.Round( index, 3 );
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex( string indexName, IndexTypes indexType )
        {
            this._name = indexName;
            this._type = indexType;
            this._stocks = new List<Stock>();
        }

        // Izracun vrijednosti indeksa za weighted vrste indeksa
        // Baca exception u slucaju da neka dionica iz indeksa nema zadanu cijenu za trazeni timestamp
        public override decimal GetIndexValue( DateTime inTimeStamp )
        {
            if ( this.GetNumberOfStocksInIndex() == 0 )
                return 0;
            decimal totalValue = this._stocks.Sum( stock => stock.GetStockPrice( inTimeStamp ) * stock.NumberOfShares );
            decimal index = ( from stock in this._stocks
                              let weightFactor = ( stock.GetStockPrice( inTimeStamp ) * stock.NumberOfShares ) / totalValue
                              select stock.GetStockPrice( inTimeStamp ) * weightFactor ).Sum();
            return decimal.Round( index, 3 );
        }
    }

    public static class Factory
    {
        // Metoda tvornica za burzu
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }

        // Metoda tvornica za indeks
        // Posto postoje dvije vrste indeksa, stvaranje je izdvojeno
        public static Index CreateIndex( string indexName, IndexTypes indexType )
        {
            if ( indexType == IndexTypes.AVERAGE )
                return new AverageIndex( indexName, indexType );
            if ( indexType == IndexTypes.WEIGHTED )
                return new WeightedIndex( indexName, indexType );
            throw new StockExchangeException( "Zadan je indeks nepostojećeg tipa" );
        }
    }
}
