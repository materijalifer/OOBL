﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private string display = "0";
        private bool newEntry = true; // kad je true, unos kreće od početka
        private double firstOperand=0; // prvi operand računske operacije
        private bool firstOperandUsed = true; 
        
        
        
        private char lastOperation='#';


        private double numberInMemory = 0;
        private bool memoryUsed = false;

        private bool error = false;
        private bool waitingAnotherOperand = false;
        

        


        public string GetCurrentDisplayState()
        {
            return display;
        }

        public void Press(char inPressedDigit)
        {
            if (error == true)
                return;          
            if (inPressedDigit <= '9' && inPressedDigit >= '0')
            {                
                if (!newEntry)
                {
                    if (inPressedDigit == '0' && display.Equals("0"))
                        display = "0";
                    else
                        if(display.Replace("-","").Replace(",","").Length<10)
                            display += inPressedDigit;
                }                
                else
                {
                    display = inPressedDigit + "";
                    newEntry = false;
                }
                if (waitingAnotherOperand == true)
                    waitingAnotherOperand = false;
            }     
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        if (firstOperandUsed == true ) // nema neizračunatoga u zraku, spremi prvi operand
                        {
                            firstOperand = DisplayToNumber();                           
                            FormatDisplay();
                            lastOperation = '+';
                            waitingAnotherOperand = true;
                            firstOperandUsed = false;
                        }
                        else // već ima prvi operand u memoriji
                        {                           
                            if(!waitingAnotherOperand)
                                Calculate();
                            else
                                lastOperation = '+';
                        }
                        
                        newEntry = true;
                        break;
                    case '-':
                        if (firstOperandUsed == true) 
                        {
                            FormatDisplay();
                            firstOperand = DisplayToNumber();
                            lastOperation = '-';
                            waitingAnotherOperand = true;
                            firstOperandUsed = false;
                        }
                        else 
                        {
                            if (!waitingAnotherOperand)
                                Calculate();
                            else
                                lastOperation = '-';
                        }
                        
                        newEntry = true;
                        break;
                    case '*':
                        if (firstOperandUsed == true) 
                        {
                            firstOperand = DisplayToNumber();
                            FormatDisplay();
                            lastOperation = '*';
                            waitingAnotherOperand = true;
                            firstOperandUsed = false;                            
                        }
                        else 
                        {
                            if (!waitingAnotherOperand)
                                Calculate();
                            else
                                lastOperation = '*';
                        }
                        
                        newEntry = true;
                        break;
                    case '/':
                        if (firstOperandUsed == true) 
                        {
                            firstOperand = DisplayToNumber();
                            FormatDisplay();
                            lastOperation = '/';
                            waitingAnotherOperand = true;
                            firstOperandUsed = false;                            
                        }
                        else 
                        {
                            if (!waitingAnotherOperand)
                                Calculate();
                            else
                                lastOperation = '/';
                        }
                        
                        newEntry = true;
                        break;
                    case '=':
                        FormatDisplay();
                        if (lastOperation != '#')
                        {
                            Calculate();
                            newEntry = true;
                        }
                        else
                            newEntry = true;
                        break;
                    case ',':
                        if (display.Contains(',') == false)
                        {
                            display += ",";
                            newEntry = false;
                        }
                            
                        break;
                    case 'M':
                        display = (DisplayToNumber() * (-1)).ToString();
                        break;
                    case 'S':
                        display = Math.Round(Math.Sin(DisplayToNumber()),9).ToString();
                        newEntry = true;
                        break;
                    case 'K':
                        display = Math.Round(Math.Cos(DisplayToNumber()), 9).ToString();
                        newEntry = true;
                        break;
                    case 'T':
                        display = Math.Round(Math.Tan(DisplayToNumber()), 9).ToString();
                        FormatDisplay();
                        newEntry = true;
                        break;
                    case 'Q':
                        display = (DisplayToNumber() * DisplayToNumber()).ToString();
                        FormatDisplay();
                        newEntry = true;
                        break;
                    case 'R':
                        if (DisplayToNumber() < 0)
                            throwError();
                        else
                            display = Math.Round(Math.Sqrt(DisplayToNumber()), 9).ToString();
                        newEntry = true;
                        break;
                    case 'I':
                        if (DisplayToNumber() == 0)
                            throwError();
                        else
                        {
                            display = (1 / DisplayToNumber()).ToString();
                            FormatDisplay();
                        }
                        
                        newEntry = true;
                        break;
                    case 'P':
                        numberInMemory = DisplayToNumber();
                        memoryUsed = true;
                        break;
                    case 'G':
                        if (memoryUsed == true)
                            display = numberInMemory.ToString();
                        else
                            display = display;
                        break;
                    case 'C':
                        display = "0";
                        break;
                    case 'O':
                        turnOFFON();
                        break;
                }
            }

            
        }

        private void FormatDisplay()
        {
            double number = DisplayToNumber();
            if (number % 1 == 0)
            {              
                display = number.ToString();
            }
            else
            {
                int numbmersBeforeComma = display.Replace("-", "").IndexOf(",");
                if (numbmersBeforeComma > 10)
                    throwError();
                else
                    display = Math.Round(number, 10 - numbmersBeforeComma).ToString();
            }
        }

        private void CheckSize()
        {
            
            if ( display.Contains(",") == false && display.Length > 10)
                throwError();              
        }

        private double DisplayToNumber()
        {
            try
            {
                double f = double.Parse(display);
                return f;
            }
            catch(Exception e)
            {
                Console.WriteLine("Greška kod pretvaranja displeja u broj");
            }
            return -1;
        }
       


        

        private void turnOFFON()
        {
            firstOperandUsed = true;
            display = "0";
            newEntry = true;
            lastOperation = '#';
            memoryUsed = false;
        }

        private void Calculate()
        {
            double result = 0;
            
            
                switch (lastOperation)
                {
                    case '#':
                        break;
                    case '+':
                        result = firstOperand + DisplayToNumber();
                        break;
                    case '-':
                        result = firstOperand - DisplayToNumber();
                        break;
                    case '*':
                        result = firstOperand * DisplayToNumber();
                        break;
                    case '/':
                        if (DisplayToNumber() == 0)
                            throwError();
                        else
                            result = firstOperand / DisplayToNumber();
                        break;
                   
                }
                lastOperation = '#';
                
                waitingAnotherOperand = false;
                firstOperandUsed = true;
                display = result.ToString();
                CheckSize();           
        }

        private void throwError()
        {
            error = true;
            display = "-E-";
        }
   
    }


}
