﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stockList = new List<Stock>();
        private List<Index> indexList = new List<Index>();
        private List<Portfolio> portfolioList = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                stockList.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Stock already exists");
            }
            
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = getStockByName(inStockName);
            foreach (Index index in indexList)
            {
                if (index.ContainsStock(stock))
                {
                    throw new StockExchangeException("Stock is still used by index");
                }
            }

            foreach (Portfolio portfolio in portfolioList)
            {
                if (portfolio.ContainsStock(stock))
                {
                    throw new StockExchangeException("Stock is still used by portfolio");
                }
            }
            
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if (s.StockName.Equals(inStockName.ToLower()))
                {
                    return true;
                }
            }

            return false;
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = getStockByName(inStockName);
            stock.AddPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = getStockByName(inStockName);
            return stock.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = getStockByName(inStockName);
            return stock.GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = getStockByName(inStockName);
            return stock.GetLastPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {
                Index index = IndexFactory.createIndex(inIndexName, inIndexType);
                indexList.Add(index);
            }
            else
            {
                throw new StockExchangeException("Index already exists");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            Stock stock = getStockByName(inStockName);
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            Stock stock = getStockByName(inStockName);
            index.DeleteStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            Stock stock = getStockByName(inStockName);
            return index.ContainsStock(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = getIndexByName(inIndexName);
            return index.getValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (Index i in indexList)
            {
                if (i.IndexName.Equals(inIndexName.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = getIndexByName(inIndexName);
            return index.CountStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                portfolioList.Add(portfolio);
            }
            else
            {
                throw new StockExchangeException("Portfolio already exists");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            Stock stock = getStockByName(inStockName);
            portfolio.AddStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            Stock stock = getStockByName(inStockName);
            portfolio.RemoveStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            Stock stock = getStockByName(inStockName);
            portfolio.RemoveStock(stock);
        }

        public int NumberOfPortfolios()
        {
            return this.portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            return portfolio.CountStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (p.PortfolioID.Equals(inPortfolioID))
                {
                    return true;
                }
            }

            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            Stock stock = getStockByName(inStockName);
            return portfolio.ContainsStock(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            Stock stock = getStockByName(inStockName);
            return portfolio.NumberOfSharesOfStock(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            return portfolio.GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = getPortfolioByID(inPortfolioID);
            return portfolio.GetPortfolioPercetChangeInValueForMonth(Year, Month);
        }

        private Index getIndexByName(string inIndexName)
        {
            foreach (Index i in indexList)
            {
                if (i.IndexName.Equals(inIndexName.ToLower()))
                {
                    return i;
                }
            }
            throw new StockExchangeException("Index doesn't exist");
        }

        private Stock getStockByName(string inStockName)
        {
            foreach (Stock s in stockList)
            {
                if(s.StockName.Equals(inStockName.ToLower()))
                {
                    return s;
                }
            }

            throw new StockExchangeException("Stock doesn't exist");
        }

        private Portfolio getPortfolioByID(string inPortfolioID)
        {
            foreach (Portfolio p in portfolioList)
            {
                if (p.PortfolioID.Equals(inPortfolioID))
                {
                    return p;
                }
            }

            throw new StockExchangeException("Portfolio doesn't exist");
        }

    }

    public class Stock
    {
        private string stockName;
        public string StockName
        {
            get { return this.stockName; }
        }

        private long numberOfShares;
        public long NumberOfShares
        {
            get { return this.numberOfShares; }
        }

        private List<PriceWithTimeStamp> prices = new List<PriceWithTimeStamp>();

        private long numberOfStocksLeft;
        public long NumberOfStocksLeft
        {
            get { return this.numberOfStocksLeft; }
            set { this.numberOfStocksLeft = value; }
        }

        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            this.stockName = stockName.ToLower();
            if (numberOfSharesValid(numberOfShares))
            {
                this.numberOfShares = numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Number of shares is not valid");
            }

            AddPrice(initialPrice, timeStamp);

            numberOfStocksLeft = this.numberOfShares;
            
        }

        public void AddPrice(Decimal inPrice, DateTime inTimeStamp)
        {
            if (priceValid(inPrice))
            {
                if (timeStampValid(inTimeStamp))
                {
                    PriceWithTimeStamp price = new PriceWithTimeStamp(inPrice, inTimeStamp);
                    prices.Add(price);
                }
                else
                {
                    throw new StockExchangeException("Price already exists");
                }
            }
            else
            {
                throw new StockExchangeException("Price is not valid");
            }
        }

        public Decimal GetPrice(DateTime inTimeStamp)
        {
            prices.Sort();
            int index = -1;
            for (int i= 0; i < prices.Count; i++)
            {
                PriceWithTimeStamp p = prices[i];
                if (p.TimeStamp > inTimeStamp)
                {
                    break;
                }
                index = i;
            }
            if (index >= 0)
            {
                return prices[index].Price;
            }
            else
            {
                throw new StockExchangeException("Price is not defined for timestamp");
            }
        }

        public Decimal GetInitialPrice()
        {
            prices.Sort();
            return prices[0].Price;
        }
        
        public Decimal GetLastPrice()
        {
            prices.Sort();
            return prices[prices.Count-1].Price;
        }

        private bool numberOfSharesValid(long numberOfShares)
        {
            if (numberOfShares > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool priceValid(decimal price)
        {
            if (price > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool timeStampValid(DateTime inTimeStamp)
        {
            foreach (PriceWithTimeStamp p in prices)
            {
                if (p.TimeStamp.Equals(inTimeStamp))
                {
                    return false;
                }
            }
            return true;
        }
    }

    public abstract class Index
    {
        private string indexName;
        public string IndexName
        {
            get { return indexName; }
        }

        protected List<Stock> stockList = new List<Stock>();

        public Index(string inIndexName)
        {
            this.indexName = inIndexName.ToLower();
        }

        public void AddStock(Stock stock)
        {
            if (!this.ContainsStock(stock))
            {
                stockList.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Stock already exists in Index");
            }

        }

        public void DeleteStock(Stock stock)
        {
            if (this.ContainsStock(stock))
            {
                stockList.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist in Index");
            }
        }

        public bool ContainsStock(Stock stock)
        {
            if (stockList.Contains(stock))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int CountStocks()
        {
            return stockList.Count;
        }

        public abstract Decimal getValue(DateTime timeStamp);

    }
    
    public class AverageIndex : Index
    {
        public AverageIndex(string inIndexName) : base(inIndexName) { }

        public override decimal getValue(DateTime timeStamp)
        {
            long numberOfStocks = 0;
            Decimal sum = 0;
            try
            {
                foreach (Stock s in this.stockList)
                {
                    /*numberOfStocks += s.NumberOfShares;
                    sum += s.NumberOfShares * s.GetPrice(timeStamp);*/
                    numberOfStocks += 1;
                    sum += s.GetPrice(timeStamp);
                }
                return Math.Round(sum / numberOfStocks,3);
            }
            catch
            {
                throw new StockExchangeException("Unable to calculate Index value");
            }
            
            
        }
    }

    public class WeightedIndex : Index 
    {
        public WeightedIndex(string inIndexName) : base(inIndexName) { }

        public override decimal getValue(DateTime timeStamp)
        {
            Decimal sumPrices = 0;
            Decimal sumWeighted = 0;
            try
            {
                foreach (Stock s in stockList)
                {
                    sumWeighted += (s.NumberOfShares * s.GetPrice(timeStamp) * s.GetPrice(timeStamp));
                    sumPrices += s.NumberOfShares * s.GetPrice(timeStamp);
                }
                return Math.Round((sumWeighted / sumPrices),3);
            }
            catch
            {
                throw new StockExchangeException("Unable to calculate Index value");
            }


        }
    }

    public class PriceWithTimeStamp : IComparable<PriceWithTimeStamp>
    {
        private Decimal price;
        private DateTime timeStamp;
        public Decimal Price
        {
            get { return this.price; }
        }
        public DateTime TimeStamp
        {
            get { return this.timeStamp; }
        }

        public PriceWithTimeStamp(Decimal price, DateTime timeStamp)
        {
            this.price = price;
            this.timeStamp = timeStamp;
        }

        public int CompareTo(PriceWithTimeStamp other)
        {
            if (this.TimeStamp < other.TimeStamp)
                return -1;
            if (this.TimeStamp > other.TimeStamp)
                return 1;
            else
                return 0;
        }
    }

    public static class IndexFactory
    {
        public static Index createIndex(string inIndexName, IndexTypes inIndexType)
        {
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    {
                        return new AverageIndex(inIndexName);
                    }
                case IndexTypes.WEIGHTED:
                    {
                        return new WeightedIndex(inIndexName);
                    }
                default:
                    {
                        throw new StockExchangeException("Unknown Index type");
                    }
            }
        }
    }

    public class Portfolio
    {
        private List<StockWithNumberOfShares> stockList = new List<StockWithNumberOfShares>();

        private string portfolioID;
        public string PortfolioID
        {
            get { return this.portfolioID; }
        }

        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
        }

        public bool ContainsStock(Stock stock)
        {
            foreach (StockWithNumberOfShares s in stockList)
            {
                if (s.Stock.Equals(stock))
                {
                    return true;
                }
            }

            return false;
        }

        public int NumberOfSharesOfStock(Stock stock)
        {
            if (this.ContainsStock(stock))
            {
                StockWithNumberOfShares stockToReturn = getStock(stock);
                return stockToReturn.NumberOfShares;
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist in Portfolio");
            }
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if ((stock.NumberOfStocksLeft - numberOfShares) >= 0)
            {
                if (!this.ContainsStock(stock))
                {
                    StockWithNumberOfShares s = new StockWithNumberOfShares(stock, numberOfShares);
                    this.stockList.Add(s);
                }
                else
                {
                    StockWithNumberOfShares stockToEdit = getStock(stock);
                    stockToEdit.NumberOfShares += numberOfShares;
                }
                stock.NumberOfStocksLeft -= numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Not enough Stocks in Stock Exchange");
            }
            
        }

        private StockWithNumberOfShares getStock(Stock stock)
        {
            foreach (StockWithNumberOfShares s in stockList)
            {
                if (s.Stock.Equals(stock))
                {
                    return s;
                }
            }
            throw new StockExchangeException("Stock doesnt't Exist in Portfolio");
        }

        public void RemoveStock(Stock stock)
        {
            if (this.ContainsStock(stock))
            {
                StockWithNumberOfShares stockToDelete = getStock(stock);
                stock.NumberOfStocksLeft += stockToDelete.NumberOfShares;
                this.stockList.Remove(stockToDelete);
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't contain Stock"); 
            }
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            if (this.ContainsStock(stock))
            {
                StockWithNumberOfShares stockToDelete = getStock(stock);
                if ((stockToDelete.NumberOfShares - numberOfShares) > 0)
                {
                    stockToDelete.NumberOfShares -= numberOfShares;
                    stock.NumberOfStocksLeft += numberOfShares;
                    return;
                }
                else if ((stockToDelete.NumberOfShares - numberOfShares) == 0)
                {
                    RemoveStock(stock);
                    return;
                }
                else
                {
                    throw new StockExchangeException("Not enough stocks");
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't contain Stock");
            }
        }

        public int CountStocks()
        {
            return stockList.Count;
        }

        public Decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            decimal value = 0;
            foreach (StockWithNumberOfShares s in stockList)
            {
                value += s.Stock.GetPrice(inTimeStamp) * s.NumberOfShares; 
            }
            return Math.Round(value, 3);
        }

        public Decimal GetPortfolioPercetChangeInValueForMonth(int Year,int Month)
        {
            Decimal firstDayValue = GetPortfolioValue(new DateTime(Year, Month, 1, 0,0,0,0));
            Decimal lastDayValue = GetPortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            Decimal percentChange = 100 * (lastDayValue - firstDayValue) / firstDayValue;
            return Math.Round(percentChange,3);
        }
    }

    public class StockWithNumberOfShares
    {
        private Stock stock;
        public Stock Stock
        {
            get { return this.stock; }
        }

        private int numberOfShares;
        public int NumberOfShares
        {
            get { return this.numberOfShares; }
            set { this.numberOfShares = value; }
        }

        public StockWithNumberOfShares(Stock stock, int numberOfShares)
        {
            this.stock = stock;
            this.numberOfShares = numberOfShares;
        }
    }
}
