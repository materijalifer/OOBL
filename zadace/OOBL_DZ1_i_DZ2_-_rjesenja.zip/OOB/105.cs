﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        List<Stock> _listStocks = new List<Stock>();
        List<Index> _listIndeces = new List<Index>();
        List<Portfolio> _listPortfolios = new List<Portfolio>();
    
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
                throw new StockExchangeException("Dionica sa tim imenom već postoji");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Cijena ne smije biti manja ili jednaka nuli");
            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            _listStocks.Add(stock);
        }

        public Stock GetStockByName(string inStockName)
        {
            foreach (Stock st in _listStocks)
                if (st.Name.ToLower() == inStockName.ToLower())
                    return st;

            throw new StockExchangeException("Ne postoji dionica sa tim imenom na burzi");
        }

        public void DelistStock(string inStockName)
        {            
            _listStocks.Remove(GetStockByName(inStockName));
            foreach (Index ind in _listIndeces)
            {
                if (ind.IsStockInIndex(GetStockByName(inStockName)))
                    ind.RemoveStock(GetStockByName(inStockName));
            }
            foreach (Portfolio por in _listPortfolios)
            {
                if (por.IsStockInPortfilio(GetStockByName(inStockName))) 
                    por.RemoveStock(GetStockByName(inStockName), por.NumberOfSharesOfStock(GetStockByName(inStockName)));
            }
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock st in _listStocks)
            { 
                if (st.Name.ToLower() == inStockName.ToLower())
                    return true;
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return _listStocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            GetStockByName(inStockName).AddPrice(inStockValue, inIimeStamp);   
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return GetStockByName(inStockName).GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return GetStockByName(inStockName).GetPriceByIndex(0);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return GetStockByName(inStockName).GetLastPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
                throw new StockExchangeException("Index sa tim imenom već postoji");
            
            Index index = new Index(inIndexName, inIndexType);
            _listIndeces.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
             if (!IsStockPartOfIndex(inIndexName, inStockName))
                  GetIndexByName(inIndexName).AddStock(GetStockByName(inStockName));
             else throw new StockExchangeException("Dionica već postoji u indexu");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IsStockPartOfIndex(inIndexName, inStockName))
                GetIndexByName(inIndexName).RemoveStock(GetStockByName(inStockName));
            else throw new StockExchangeException("Dionica sa tim imenom ne postoji u tom indexu");
        }

        public Index GetIndexByName(string inIndexName)
        {
            foreach (Index ind in _listIndeces)
                if (ind.Name.ToLower() == inIndexName.ToLower())
                    return ind;

            throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return GetIndexByName(inIndexName).IsStockInIndex(GetStockByName(inStockName));
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (GetIndexByName(inIndexName).Type == IndexTypes.WEIGHTED)
            {
                return GetIndexByName(inIndexName).GetWeightedIndexValue(inTimeStamp);
            }
            else if (GetIndexByName(inIndexName).Type == IndexTypes.AVERAGE)
            {
                return GetIndexByName(inIndexName).GetAverageIndexValue(inTimeStamp);
            }
            else throw new StockExchangeException("Tip mora biti weighted ili average");
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (Index ind in _listIndeces)
                if (inIndexName.ToLower() == ind.Name.ToLower())
                    return true;
            
            return false;
        }

        public int NumberOfIndices()
        {
            return _listIndeces.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return GetIndexByName(inIndexName).CountStock();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj sa tim id-eim već postoji");

            Portfolio portfolio = new Portfolio(inPortfolioID);
            _listPortfolios.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares == 0)
                throw new StockExchangeException("broj dionica ne smije biti nula");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji na burzi");
            int totalNumberOfShares = 0;
            foreach (Portfolio por in _listPortfolios)
                if (por.IsStockInPortfilio(GetStockByName(inStockName)))
                    totalNumberOfShares += por.NumberOfSharesOfStock(GetStockByName(inStockName));
            if (GetStockByName(inStockName).Number < (totalNumberOfShares + numberOfShares))
                throw new StockExchangeException("Nema dovoljno dionica");
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj sa tim id-em ne postoji");

            GetPortfolioById(inPortfolioID).AddStock(GetStockByName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!IsStockPartOfPortfolio(inPortfolioID ,inStockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji u porfelju");
            GetPortfolioById(inPortfolioID).RemoveStock(GetStockByName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji u porfelju");
            GetPortfolioById(inPortfolioID).RemoveStock(GetStockByName(inStockName), NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName));
        }

        public int NumberOfPortfolios()
        {
            return _listPortfolios.Count();
        }

        public Portfolio GetPortfolioById(string inPortfolioID)
        {
            foreach (Portfolio por in _listPortfolios)
                if (por.Id == inPortfolioID)
                    return por;

            throw new StockExchangeException("Ne postoji portfelj sa tim id-em");
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return GetPortfolioById(inPortfolioID).Count();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio por in _listPortfolios)
                if (por.Id == inPortfolioID)
                    return true;
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return GetPortfolioById(inPortfolioID).IsStockInPortfilio(GetStockByName(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return GetPortfolioById(inPortfolioID).NumberOfSharesOfStock(GetStockByName(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return GetPortfolioById(inPortfolioID).GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal firstDayInMonth = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 00));
            decimal lastDayInMonth = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            decimal result = ((firstDayInMonth - lastDayInMonth)/firstDayInMonth)*100;
            return decimal.Round(result, 3);
        }
    }


    public class Stock
    {

        private string _name;
        private long _number;
        List<PriceTime> _listPrices = new List<PriceTime>();

        public Stock( string name, long number, decimal price, DateTime timeStamp)
        {
            _name = name;
            _number = number;
            PriceTime priceTime = new PriceTime(price, timeStamp);
            _listPrices.Add(priceTime);
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public long Number
        {
            get
            {
               return _number ;
            }
            set
            {
                _number = value;
            }
        }

        public void AddPrice(decimal newPrice, DateTime newTimeStamp)
        {
            if (newPrice <= 0)
                throw new StockExchangeException("Ne smije biti negativna cijena");
            foreach (PriceTime pr in _listPrices)
                if (pr.TimeStamp == newTimeStamp)
                    throw new StockExchangeException("Cijena sa tim timestampom već postoji");
            
            PriceTime price = new PriceTime(newPrice, newTimeStamp);
            _listPrices.Add(price);
        }

        public decimal GetPrice(DateTime getTimeStamp)
        {
            DateTime max = new DateTime();
            for (int i = 0; i < _listPrices.Count(); i++)
            {
                if (_listPrices[i].TimeStamp <= getTimeStamp && _listPrices[i].TimeStamp > max)
                    max = _listPrices[i].TimeStamp;
            }
            foreach (PriceTime pr in _listPrices)
                if (pr.TimeStamp == max)
                    return pr.Price;
            throw new StockExchangeException("nema cijene");
        }

        public decimal GetPriceByIndex(int index)
        {
            return _listPrices[index].Price;
        }

        public decimal GetLastPrice()
        {
            DateTime max = _listPrices[0].TimeStamp;
            for (int i = 1; i < _listPrices.Count(); i++)
            {
                if (_listPrices[i].TimeStamp > max)
                    max = _listPrices[i].TimeStamp;
            }
            foreach (PriceTime pr in _listPrices)
                if (pr.TimeStamp == max)
                    return pr.Price;
            throw new StockExchangeException("nema cijene");

        }
    }


    public class PriceTime
    {

        private decimal _price;
        private DateTime _timeStamp;

        public PriceTime(decimal price, DateTime timeStamp)
        {
            _price = price;
            _timeStamp = timeStamp;
        }

        public decimal Price
        {
            get
            {
                return _price; ;
            }
            set
            {
                _price = value;
            }
        }

        public DateTime TimeStamp
        {
            get
            {
               return _timeStamp;
            }
            set
            {
                _timeStamp = value;
            }
        }
    }


    public class Index
    {
        private string _name;
        private IndexTypes _type;
        List<Stock> _listStocks = new List<Stock>();

        public Index(string name, IndexTypes type)
        {
            _name = name;
            if ((type == IndexTypes.AVERAGE) || (type == IndexTypes.WEIGHTED))
                _type = type;
            else throw new StockExchangeException("mora biti average ili weighted");
        }

        public string Name
        {
            get
            {
                return _name; ;
            }
            set
            {
                _name = value;
            }
        }

        public IndexTypes Type
        {
            get
            {
                return _type;    
            }
            set
            {
                _type = value;
            }
        }

        public void AddStock(Stock stock)
        {
            foreach (Stock st in _listStocks)
                if (st.Name.ToLower() == stock.Name.ToLower())
                    throw new StockExchangeException("Dionica već postoji u indexu");

            _listStocks.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            _listStocks.Remove(stock);
        }

        public bool IsStockInIndex(Stock stock)
        {
            foreach (Stock st in _listStocks)
                if (stock.Equals(st))
                    return true;
            return false;
        }

        public int CountStock()
        {
            return _listStocks.Count();
        }

        public decimal GetWeightedIndexValue(DateTime inTimeStamp)
        {
            decimal result = 0;
            decimal totalValue = 0;
            foreach (Stock st in _listStocks)
            {
                totalValue += (st.GetPrice(inTimeStamp) * st.Number);
            }
            foreach (Stock st in _listStocks)
            { 
                result += (st.GetPrice(inTimeStamp)*st.GetPrice(inTimeStamp)*st.Number)/totalValue;
            }
            return decimal.Round(result, 3);
        }

        public decimal GetAverageIndexValue(DateTime inTimeStamp)
        {
            decimal result = 0;
            decimal totalWeight = 0;
            foreach (Stock st in _listStocks)
            {
                totalWeight+= st.Number;
            }
            foreach (Stock st in _listStocks)
            {
                result += st.Number*st.GetPrice(inTimeStamp);
            }
            return decimal.Round(result/totalWeight, 3);
        }
    }


    public class Portfolio
    {

        List<Stock> _listStocks = new List<Stock>();
        private string _id;
        Dictionary<string, int> _dictionaryNumberOfShares = new Dictionary<string,int>();

        public Portfolio(string id)
        {
            _id = id;
        }

        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public int Count()
        {
           return _listStocks.Count();
        }

        public bool IsStockInPortfilio(Stock stock)
        {
            foreach (Stock st in _listStocks)
                if (stock.Equals(st))
                    return true;

            return false;
        }

        public int NumberOfSharesOfStock(Stock stock)
        {
            if (_dictionaryNumberOfShares.ContainsKey(stock.Name))
                return _dictionaryNumberOfShares[stock.Name];

            throw new StockExchangeException("Dionica sa tim imenom ne postoji u portfelju");
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (_dictionaryNumberOfShares.ContainsKey(stock.Name))
                    _dictionaryNumberOfShares[stock.Name] += numberOfShares;
            else
            {
                _listStocks.Add(stock);
                _dictionaryNumberOfShares.Add(stock.Name, numberOfShares);
            }
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            _dictionaryNumberOfShares[stock.Name] -= numberOfShares;
            if (_dictionaryNumberOfShares[stock.Name] <= 0)
            {
                _listStocks.Remove(stock);
                _dictionaryNumberOfShares.Remove(stock.Name);
            }
        }

        public decimal GetValue(DateTime timeStamp)
        {
            decimal result = 0;
            foreach (Stock st in _listStocks)
                result += st.GetPrice(timeStamp)*_dictionaryNumberOfShares[st.Name];
            return decimal.Round(result, 3);
        }
    }
}
