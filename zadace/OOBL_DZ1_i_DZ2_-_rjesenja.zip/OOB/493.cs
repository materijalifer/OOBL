﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//ovaj kod je pisan od strane studenta koji nikad do sad nije pisao nista u C#
//i koji nije koristio nista osim MATLABa u skoro zadnje 2 godine.
//buduci da sam potrosio gotovo 3 dana na ovo i onda sam na testovima skuzio 
//da mi ne prolaze 2 testa (jer nisam dobro niti dizajnirao kod niti sam dobro
//napravio funkcionalnost) odustao sam od prepravljanja jer nemam vremena,
//imam i druge predmete pa ne stingem, dosta sam utrosio vremena na ovu DZ.
//problem je sto sam previse u razno-raznim drugim razvijateljskim vodama (MATLAB, 
//neuronske mreze, image processing, komunication bands ...) pa sam skroz ispao 
//iz toka problema poput ovakvog automata.
//
//moj kod je uvijek pun smeca(komentara i viska koda koji se ne izvodi) pa sam stoga
//i upisao ovaj predmet da se ipak koliko toliko dovedem u red i da naucim pisati
//cisti i razumljivi kod (zadnje razumljivo sto sam pisao je bio c++ kod za Zavrsni rad,
//a i to je bila grafika i stvaranje scene, tako da nije bio preveliki problem napisati
//kod koji je citljiv)
namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new OvoJeMojKalkulator();
        }
    }

    public class OvoJeMojKalkulator : ICalculator
    {   //varijable klase kalkualtora
        char inPressedDigit;
        short zarez = 0;
        bool znak1 = false;
        bool znak2 = false;
        decimal rezultat = 0;
        decimal zadnji_broj = 0;
        string temp_digit = "0";
        string temp_znak = "prazno";
        string ispis = "0";
        string prvi_broj = "-E-";
        string drugi_broj = "0";
        string zadnje_ukucano = "broj";
        string memori = "0";
        
        ////////////////////////////////////
        //Funkcija Press() omogućuje unos znaka u kalkulator
        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'O')
            {
                temp_digit = "0";
                rezultat = 0;
                temp_znak = "prazno";
                //znak1 = false; // + - S itd
                zarez = 0;
                zadnji_broj = 0;
                ispis = "0";
                prvi_broj = "-E-";
                drugi_broj = "0";
                znak1 = false;
                znak2 = false;
                zadnje_ukucano = "broj";
                memori = "0";
            }
            //upisujem broj odnosno ,
            if ((Char.IsDigit(inPressedDigit)) | inPressedDigit.Equals(','))
            {
                //temp_digit = temp_digit + inPressedDigit.ToString();
                if ((temp_digit.StartsWith("0")) & (inPressedDigit.Equals(',')))
                    temp_digit = temp_digit + inPressedDigit.ToString();
                else
                {
                    temp_digit = temp_digit.TrimStart('0');
                    temp_digit = temp_digit + inPressedDigit.ToString();
                }
                if ((temp_digit.Contains(',')) & inPressedDigit.Equals(','))
                {
                    //Console.WriteLine("zarez postoji u temp_digit {0}", temp_digit);
                    zarez++;
                    ispis = "-E-";
                }
                else if (inPressedDigit.Equals(',') & (temp_digit.Equals("0")))
                    zarez++;
                if (!temp_digit.Contains(","))
                    zarez = 0;
                if (zarez > 1)
                {
                    goto Van;
                }
                zadnje_ukucano = "broj";
            }
            //upisujem znak
            else if (!(Char.IsDigit(inPressedDigit)))
            {
                if (inPressedDigit.Equals('M'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = MinusNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('S'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = SinusNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('K'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = CosinusNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('T'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = TangensNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('Q'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = QuadNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('R'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = RootNumber(temp_digit);
                }
                else if (inPressedDigit.Equals('P'))
                {
                    if (CheckNumber(temp_digit) != "-E-")
                    {
                        temp_digit = CircleNumber(temp_digit);
                        memori = CheckNumber(temp_digit);
                    }
                    else
                        memori = "-E-";
                }
                else if (inPressedDigit.Equals('G'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = memori;
                }
                else if (inPressedDigit.Equals('C'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = "0";
                }
                else if (inPressedDigit.Equals('I'))
                {
                    temp_digit = CircleNumber(temp_digit);
                    temp_digit = InverseNumber(temp_digit);
                }
                else if (prvi_broj.Equals("-E-"))
                {
                    prvi_broj = CheckNumber(temp_digit);
                    temp_digit = "0";
                }
                if (!znak1)
                    znak1 = true;
                else if (!temp_digit.Equals("0"))
                {
                    if ( !Char.IsLetter(inPressedDigit))
                        znak2 = true;
                }
                //sad ide kompliciranje
                if (((znak1) & (znak2)) | (inPressedDigit.Equals('=')))
                {
                    drugi_broj = temp_digit;
                    if ((inPressedDigit.Equals('=')) & (! (znak2)))
                        drugi_broj = prvi_broj;
                JEDNAKO:
                    switch (temp_znak)
                    {
                        case "=":   //ovo se nikad ne izvodi, vec tu je kao podsjetnik
                            if (zadnje_ukucano.Equals("znak"))
                            {
                                zadnje_ukucano = "znak";
                                prvi_broj = drugi_broj;// = prvi_broj;
                                goto JEDNAKO;
                            }
                            else
                                goto Van;
                            break;

                        case "+":
                            prvi_broj = AddNumber(prvi_broj, drugi_broj);
                            break;
                        case "-":
                            prvi_broj = SubtraNumber(prvi_broj, drugi_broj);
                            break;
                        case "*":
                            prvi_broj = MultiNumber(prvi_broj, drugi_broj);
                            break;
                        case "/":
                            prvi_broj = DivNumber(prvi_broj, drugi_broj);
                            break;
                    }
                    temp_digit = "0";
                    znak2 = false;
                }
                zadnje_ukucano = "znak";
                if (!Char.IsLetter(inPressedDigit))
                    temp_znak = inPressedDigit.ToString();
            }
            
            if ((inPressedDigit == '=') & (zadnje_ukucano.Equals("znak")))
            {
                goto Van;
            }
            else if (temp_digit.Equals("-E-"))
                ispis = "-E-";
            /*else
            {
                ispis = CheckNumber(temp_digit);
            }*/
        Van:

            if (!ispis.Equals("-E-") | (zarez <= 1))
            {
                if (prvi_broj.Equals("-E-"))
                    ispis = prvi_broj;
                else
                    ispis = CheckNumber(prvi_broj);
            }
            else
                ispis = "-E-";
            if (memori.Equals("-E-"))
                ispis = "-E-";
        }

        ////////////////////////////////////
        //funkcija GetCurrentDisplayState() omogućuje uvid u trenutno stanje ekrana kalkulatora
        public string GetCurrentDisplayState()
        {
            if (temp_znak.Equals("prazno"))
            {
                //temp_digit = "808080808";
                return (CheckNumber(temp_digit));
            }
            else
                return CheckNumber(ispis);
        }

        ////////////////////////////////////
        //metode +-*/
        private static string AddNumber(string prvi_broj, string drugi_broj)
        {
            decimal rezultat = decimal.Parse(prvi_broj) + decimal.Parse(drugi_broj);

            return CheckNumber(rezultat.ToString());
        }
        private static string SubtraNumber(string prvi_broj, string drugi_broj)
        {
            decimal rezultat = decimal.Parse(prvi_broj) - decimal.Parse(drugi_broj);
            return CheckNumber(rezultat.ToString());
        }
        private static string MultiNumber(string prvi_broj, string drugi_broj)
        {
            decimal rezultat = decimal.Parse(prvi_broj) * decimal.Parse(drugi_broj);
            return CheckNumber(rezultat.ToString());
        }
        private static string DivNumber(string prvi_broj, string drugi_broj)
        {
            string ispis;
            decimal rezultat;
            decimal a = decimal.Parse(prvi_broj);
            decimal b = decimal.Parse(drugi_broj);
            if (b == 0)
                ispis = "-E-";
            else
            {
                //Console.WriteLine("decimal.Parse(prvi) {0} , decimal.Parse(drugi_broj) {1} \n a = {2}, b = {3}", decimal.Parse(prvi_broj), decimal.Parse(drugi_broj), a, b);
                //rezultat = (decimal.Parse(prvi_broj)) /(decimal.Parse(prvi_broj));
                rezultat = a / b;
                //Console.WriteLine("decimalc reztulat {0}", rezultat);
                ispis = CheckNumber(rezultat.ToString());
            }
            return ispis;
        }
        ///kraj tih metoda
        ////////////////////////////////////

        ////////////////////////////////////
        //metode M, S, K, T, Q, R, I
        private static string MinusNumber(string drugi_broj)
        {
            decimal rezultat = -1 * decimal.Parse(drugi_broj);
            //string ulaz = CheckNumber(rezultat.ToString());
            return CheckNumber(rezultat.ToString());
        }

        private static string SinusNumber(string drugi_broj)
        {
            double rezultat = (Math.Sin((double)(decimal.Parse(drugi_broj))));
            rezultat = Math.Round(rezultat, 9);
            return CheckNumber(rezultat.ToString());
        }

        private static string CosinusNumber(string drugi_broj)
        {
            double rezultat = (Math.Cos((double)(decimal.Parse(drugi_broj))));
            rezultat = Math.Round(rezultat, 9);
            return CheckNumber(rezultat.ToString());
        }

        private static string TangensNumber(string drugi_broj)
        {
            double rezultat = (Math.Tan((double)(decimal.Parse(drugi_broj))));
            rezultat = Math.Round(rezultat, 9);
            return CheckNumber(rezultat.ToString());
        }
        private static string QuadNumber(string drugi_broj)
        {
            decimal rezultat = decimal.Parse(drugi_broj) * decimal.Parse(drugi_broj);
            rezultat = Math.Round(rezultat, 9);
            //string ulaz = CheckNumber(rezultat.ToString());
            return CheckNumber(rezultat.ToString());
        }
        private static string RootNumber(string drugi_broj)
        {
            decimal rezultat;
            if (decimal.Parse(drugi_broj) > 0)
            {
                rezultat = (Decimal)(Math.Round(Math.Sqrt((double)decimal.Parse(drugi_broj)), 9));
                return CheckNumber(rezultat.ToString());
            }
            else
                return ("-E-");
        }
        private static string InverseNumber(string drugi_broj)
        {
            decimal rezultat;
            rezultat = decimal.Parse(drugi_broj);
            if (rezultat != 0)
            {
                rezultat = 1 / decimal.Parse(drugi_broj);
                return CheckNumber(rezultat.ToString());
            }
            else
                return ("-E-");
        }
        //kraj tih metoda
        ////////////////////////////////////

        ////////////////////////////////////
        //funkcija provjere broja (br znamenki)
        private static string CheckNumber(string ulaz)
        {
            // string ulaz = "-1,885858";
            bool minus = false;
            bool eror = false;
            string ispis;
            decimal result = 0;
            if (ulaz.Equals("-E-"))
            {
                eror = true;
                ispis = "-E-";
                goto Anva;
            }
            else
	        {
                result = decimal.Parse(ulaz);
	        }
            char[] izlaz = { '-', 'E', '-' };
            string temp_str = "0";

            if (result < 0)
            {
                minus = true;
                result = result * -1;
            }
            //dodati provjeru više zareza, JESAM
            decimal cijel = System.Decimal.Truncate(result);
            decimal dec = result - cijel;
            string str = result.ToString();

            if (str.Contains("-"))
            {
                str = str.Remove(0, 1);
            }
            if (dec.Equals(0))
            {
                temp_str = cijel.ToString();
            }
            else
            {
                temp_str = str.ToString();
            }
            long dugo = temp_str.Length;
            if (dugo <= 11)
            {
                izlaz = temp_str.ToCharArray(0, temp_str.Length);
            }
            ispis = new string(izlaz);
            if ((minus) && !(ispis.StartsWith("-")))
            {
                ispis = "-" + ispis;
            }
            if (ispis.Equals("-E-"))
                goto Anva;
            else
            {
                result = decimal.Parse(ispis);
                double temp = Decimal.ToDouble(result);
                ispis = temp.ToString();
            }
            Anva:
            return ispis;

        }
        private static string CircleNumber(string temp_digit)
        {
            if (temp_digit.Length > 10)
            {
                string kaos_i_anarhija = temp_digit; //nije potrebno ali svida mi se ime
                int temp = 10;
                //Console.WriteLine("ovo je kaos_i_anarhija {0}", kaos_i_anarhija);
                if (kaos_i_anarhija.Contains(","))
                    temp++;
                if (kaos_i_anarhija.Contains("-"))
                    temp++;
                temp_digit = temp_digit.Substring(0, temp);
            }
            return temp_digit;
        }
    }
    
}