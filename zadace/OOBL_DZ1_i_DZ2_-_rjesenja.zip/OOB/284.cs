﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DrugaDomacaZadaca_Burza;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         StockRepository _stockRepository = new StockRepository();
         IndexRepository _indexRepository = new IndexRepository();
         PortfolioRepository _portfolioRepository = new PortfolioRepository();

         public string ToUpper(string inStockName)
         {

             return inStockName.ToUpper();

         }
     
         

     

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _stockRepository.ListStock(ToUpper(inStockName),inNumberOfShares,inInitialPrice,inTimeStamp);
         }

         public void DelistStock(string inStockName)
         {
             _indexRepository.DelistStockFromIndex(_stockRepository.GetStock(ToUpper(inStockName)));
             _portfolioRepository.DelistStockFromPortfolio(_stockRepository.GetStock(ToUpper(inStockName)));

             _stockRepository.DelistStock(ToUpper(inStockName));
         }

         public bool StockExists(string inStockName)
         {
             return _stockRepository.StockExists(ToUpper(inStockName));
         }

         public int NumberOfStocks()
         {
             return _stockRepository.NumberOfStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             _stockRepository.SetStockPrice(ToUpper(inStockName),inIimeStamp,inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return _stockRepository.GetStockPrice(ToUpper(inStockName), inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return _stockRepository.GetInitialStockPrice(ToUpper(inStockName));
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return _stockRepository.GetLastStockPrice(ToUpper(inStockName));
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             _indexRepository.CreateIndex(ToUpper(inIndexName),inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             _indexRepository.AddStockToIndex(ToUpper(inIndexName),_stockRepository.GetStock(ToUpper(inStockName)));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             _indexRepository.RemoveStockFromIndex(ToUpper(inIndexName),_stockRepository.GetStock(ToUpper(inStockName)));
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _indexRepository.IsStockPartOfIndex(ToUpper(inIndexName), ToUpper(inStockName));
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return _indexRepository.GetIndexValue(ToUpper(inIndexName), inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indexRepository.IndexExists(ToUpper(inIndexName));
         }

         public int NumberOfIndices()
         {
             return _indexRepository.NumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _indexRepository.NumberOfStocksInIndex(ToUpper(inIndexName));
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             _portfolioRepository.CreatePortfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _portfolioRepository.AddStockToPortfolio(inPortfolioID, _stockRepository.GetStock(ToUpper(inStockName)),numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _portfolioRepository.RemoveStockFromPortfolio(inPortfolioID,ToUpper(inStockName),numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             _portfolioRepository.RemoveStockFromPortfolio(inPortfolioID,ToUpper(inStockName));
         }

         public int NumberOfPortfolios()
         {
             return _portfolioRepository.NumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return _portfolioRepository.NumberOfStocksInPortfolio(inPortfolioID);
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolioRepository.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return _portfolioRepository.IsStockPartOfPortfolio(inPortfolioID, _stockRepository.GetStock(ToUpper(inStockName)));
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return _portfolioRepository.NumberOfSharesOfStockInPortfolio(inPortfolioID, ToUpper(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return _portfolioRepository.GetPortfolioValue(inPortfolioID, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return _portfolioRepository.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
         }
     }


    public class DateTimePrice
    {
        public Decimal _validPrice { get; set; }
        public DateTime _validDate { get; set; }

        public DateTimePrice(DateTime inIimeStamp, Decimal inStockValue)
        {
            _validDate = inIimeStamp;
            _validPrice = inStockValue;


        }

    }


         public class Stock
         {
             public string _stockName { get; set; }
             public long _numberOfShares { get; set; }
             public Decimal _initialPrice { get; set; }
             public DateTime _timeStamp { get; set; }
             public List<DateTimePrice> _DateTimePrices;
             public List<string> _indexNames; 
             

             public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
             {
                 _stockName = inStockName;
                 _numberOfShares = inNumberOfShares;
                 _initialPrice = inInitialPrice;
                 _timeStamp = inTimeStamp;
                 _DateTimePrices = new List<DateTimePrice>();
                 _DateTimePrices.Add(new DateTimePrice(inTimeStamp,inInitialPrice));
               
                 _indexNames = new List<string>();
             }

             public void SetStockPrice(DateTime inIimeStamp, Decimal inStockValue)
             {
                 if (_DateTimePrices.Exists(x => x._validDate.Equals(inIimeStamp)) || inStockValue <= 0)
                     throw new StockExchangeException("Greska");

                 _DateTimePrices.Add(new DateTimePrice(inIimeStamp, inStockValue));

                 _DateTimePrices.Sort((x, y) => x._validDate.CompareTo(y._validDate));


             }

              public Decimal GetStockPrice( DateTime inTimeStamp)
              {
                
               

                  try
                  {
                      return _DateTimePrices.TakeWhile(x => x._validDate <= inTimeStamp).Last()._validPrice;
                  }

                  catch (Exception e)
                  {
                      throw new StockExchangeException("greska");

                  }
              }

              public Decimal GetInitialStockPrice()
              {

                  return _initialPrice;

              }

              public Decimal GetLastStockPrice()
              {

                  return _DateTimePrices.Last()._validPrice;

              }

         }

    public class StockRepository
    {
        List< Stock> _listStock = new List<Stock>();

        public int NumberOfStocks()
        {
            return _listStock.Count;


        }

        public Stock GetStock(string inStockName)
        {

            Stock stock = _listStock.Find(x => x._stockName.Equals(inStockName));

            return stock;

          


        }

        public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0 || inNumberOfShares <= 0)
                throw new StockExchangeException("Greska");

           
            if(StockExists(inStockName))
            {
                throw new StockExchangeException("Greska");
            }
           
            
            

            _listStock.Add(new Stock(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp));


        }

        public bool StockExists(string inStockName)
        {
           
            return _listStock.Exists(x => x._stockName.Equals(inStockName));
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, Decimal inStockValue)
        {

            if (!StockExists(inStockName))
                throw new StockExchangeException("greska");
           
            Stock stock = GetStock(inStockName);

           


            stock.SetStockPrice(inIimeStamp,inStockValue);


        }

        public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("greska");

            Stock stock = GetStock(inStockName);

            return stock.GetStockPrice(inTimeStamp);

        }

        public Decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("greska");
            
            Stock stock = GetStock(inStockName);

            return stock.GetInitialStockPrice();


        }

        public Decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("greska");

            Stock stock = GetStock(inStockName);

            return stock.GetLastStockPrice();

        }


        public void DelistStock(string inStockName)
        {
            if(!StockExists(inStockName))
                throw new StockExchangeException("greska");
            
            Stock stock = GetStock(inStockName);

            

            _listStock.Remove(stock);


        }



    }

    public class Index
    {
        public string _indexName { get; set; }
        public IndexTypes _IndexType { get; set; }
        public List<Stock> _listStocks { get; set; }


        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if(inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Greska");

            _indexName = inIndexName;
            _IndexType = inIndexType;
            _listStocks = new List<Stock>();

        }

        

        public int NumberOfStocks()
        {
            return _listStocks.Count;



        }

        public Decimal IndexValue(DateTime inTimeStamp)
        {
            //PROVJERITI
            //
            //

            if (_listStocks.Count == 0)
                return 0;


            Decimal suma2 = 0;
            if (_IndexType == IndexTypes.WEIGHTED)
            {
                Decimal suma = _listStocks.Sum(stock => stock._numberOfShares*stock.GetStockPrice(inTimeStamp));



                suma2 = (from stock in _listStocks
                                 let produkt = stock.GetStockPrice(inTimeStamp)*stock.GetStockPrice(inTimeStamp)
                                 select stock._numberOfShares*produkt/suma).Sum();


               
            }
            else
            {
                suma2 = _listStocks.Sum(x => x.GetStockPrice(inTimeStamp))/_listStocks.Count;
            }

            return Math.Round(suma2, 3);
        }

        public void AddStockToIndex( Stock stock)
        {
            if(stock._indexNames.Exists(x => x.Equals(_indexName)) || stock == null)
                throw new StockExchangeException("Greska");
            
            _listStocks.Add(stock);


            stock._indexNames.Add(_indexName);


        }

        public bool IsStockPartOfIndex( string inStockName)
        {
            return  _listStocks.Exists(x => x._stockName.Equals(inStockName));

            

           

        }

        public void RemoveStockFromIndex( Stock inStock)
        {
            if(inStock == null)
                throw new StockExchangeException("greska");
            
            if(!IsStockPartOfIndex(inStock._stockName))
                throw new StockExchangeException("Greska");


            _listStocks.Remove(inStock);

            inStock._indexNames.Remove(_indexName);

        }

    }

    public class IndexRepository
    {
        List<Index> _listIndex = new List<Index>();

        public int NumberOfIndices()
        {
            return _listIndex.Count;


        }

        public void RemoveStockFromIndex(string inIndexName, Stock inStock)
        {
            if (!IndexExists(inIndexName) || inStock == null)
                throw new StockExchangeException("greska");
            
            Index indeks = GetIndex(inIndexName);

            

            indeks.RemoveStockFromIndex(inStock);


        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
           if(IndexExists(inIndexName))
               throw new StockExchangeException("Greska");
            
            _listIndex.Add(new Index(inIndexName,inIndexType));



        }

        public Index GetIndex(string inIndexName)
        {
            Index indeks = _listIndex.Find(x => x._indexName.Equals(inIndexName));

            return indeks;



        }

        public bool IndexExists(string inIndexName)
        {

            return _listIndex.Exists(x => x._indexName.Equals(inIndexName));


        }

        public void AddStockToIndex(string inIndexName, Stock stock)
        {
            if (!IndexExists(inIndexName) || stock == null)
                throw new StockExchangeException("greska");
            
            Index indeks = GetIndex(inIndexName);

            indeks.AddStockToIndex(stock);
        
            


        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("greska");
            
            Index indeks = GetIndex(inIndexName);

            return indeks.IsStockPartOfIndex(inStockName);



        }
        
       public int NumberOfStocksInIndex(string inIndexName)
       {
           if (!IndexExists(inIndexName))
               throw new StockExchangeException("greska");
           
           Index indeks = GetIndex(inIndexName);

          

           return indeks.NumberOfStocks();



       }

       public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
       {
           if(!IndexExists(inIndexName))
               throw new StockExchangeException("greska");
           
           Index indeks = GetIndex(inIndexName);

           return indeks.IndexValue(inTimeStamp);
           
           


       }

        public void DelistStockFromIndex(Stock inStock)
        {
            if (inStock != null)
            {

                foreach (var index in _listIndex)
                {
                    if (index.IsStockPartOfIndex(inStock._stockName))
                        RemoveStockFromIndex(index._indexName, inStock);
                }

            }
        }
        

    }

    public class StocksInPortfolio
    {
        public Stock _stock { get; set; }
        public int _numberOfShares { get; set; }

        public StocksInPortfolio(Stock inStock, int inNumberOfShares)
        {

            _stock = inStock;
            _numberOfShares = inNumberOfShares;


        }

        



    }

    public class Portfolio
    {
        public string _PortfolioID { get; set; }
        public List<StocksInPortfolio> _StocksInPortfolios; 
        
        public Portfolio(string inPortfolioID)
        {
            _PortfolioID = inPortfolioID;
            _StocksInPortfolios = new List<StocksInPortfolio>();
        }

        public int NumberOfStocks()
        {
            return _StocksInPortfolios.Count;


        }
        
        public StocksInPortfolio GetStockFromPortfolio(string inStockname)
        {

            return _StocksInPortfolios.Find(x => x._stock._stockName.Equals(inStockname));
        }
        
        public void RemoveStockFromPortfolio(string inStockName, int numberOfShares)
        {
            StocksInPortfolio stockInPortfolio = GetStockFromPortfolio(inStockName);

            if(stockInPortfolio == null)
                throw new StockExchangeException("greska");
        

            stockInPortfolio._numberOfShares -= numberOfShares;

            if(stockInPortfolio._numberOfShares == 0)
                RemoveStockFromPortfolio(inStockName);


        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            StocksInPortfolio stockInPortfolio = GetStockFromPortfolio(inStockName);

            if(stockInPortfolio == null)
                throw new StockExchangeException("grska");

            _StocksInPortfolios.Remove(stockInPortfolio);


        }

        public void AddStocksToPortfolio(Stock inStock, int numberOfShares)
        {
           
            
            StocksInPortfolio stockInPortfolio = GetStockFromPortfolio(inStock._stockName);

            if (inStock == null || stockInPortfolio == null)
                throw new StockExchangeException("grska");

            if((stockInPortfolio._numberOfShares + numberOfShares) > inStock._numberOfShares )
                throw new StockExchangeException("Greska");

            stockInPortfolio._numberOfShares += numberOfShares;


        }

        public int NumberOfShares(string inStockName)
        {
            StocksInPortfolio stockInPortfolio = GetStockFromPortfolio(inStockName);

            //PAZNJA

            if (stockInPortfolio == null)
                throw new StockExchangeException("greska");

            return stockInPortfolio._numberOfShares;

        }


    }

    public class PortfolioRepository
    {
        
        List<Portfolio > _listPortfolio = new List<Portfolio>(); 

        public int NumberOfPortfolios()
        {
            return _listPortfolio.Count;


        }

        public Portfolio GetPortfolio(string inPortfolioID)
        {
            return _listPortfolio.Find(x => x._PortfolioID.Equals(inPortfolioID));


        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _listPortfolio.Exists(x => x._PortfolioID.Equals(inPortfolioID));


        }
        

        public void AddStockToPortfolio(string inPortfolioID, Stock inStock, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || inStock == null || numberOfShares <= 0)
                throw new StockExchangeException("greska");
            
            Portfolio portfelj = GetPortfolio(inPortfolioID);

            

            string StockName = inStock._stockName;

            if (IsStockPartOfPortfolio(inPortfolioID,inStock))
                portfelj.AddStocksToPortfolio(inStock,numberOfShares);

            else
            {
                if(numberOfShares > inStock._numberOfShares)
                    throw new StockExchangeException("Greska");
               

                portfelj._StocksInPortfolios.Add(new StocksInPortfolio(inStock, numberOfShares));
                
            }

            


        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if(PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");

            _listPortfolio.Add(new Portfolio(inPortfolioID));

        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, Stock inStock)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");
            
            Portfolio portfelj = GetPortfolio(inPortfolioID);

          

            return portfelj._StocksInPortfolios.Exists(x => x._stock._stockName.Equals(inStock._stockName));


        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");
            
            Portfolio portfelj = GetPortfolio(inPortfolioID);

            

            return portfelj.NumberOfStocks();


        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");


            Portfolio portfelj = GetPortfolio(inPortfolioID);


            

            return portfelj.NumberOfShares(inStockName);



        }

         public Decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("greska");
             
             Portfolio portfelj = GetPortfolio(inPortfolioID);

             Decimal suma = portfelj._StocksInPortfolios.Sum(x => x._numberOfShares*x._stock.GetStockPrice(timeStamp));

             return Math.Round(suma, 3);


         }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if(Month <= 0 || Month > 12 || Year <= 0 )
                throw new StockExchangeException("greska");
                

            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");

            Portfolio portfelj = GetPortfolio(inPortfolioID);

            

            int pocetniDan = 1;
            int zadnjiDan = pocetniDan + DateTime.DaysInMonth(Year, Month) - 1;

            Decimal pocetnaSuma = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, pocetniDan, 00, 00, 00));
            Decimal zavrsnaSuma = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, zadnjiDan, 23, 59, 59, 999));

            if (pocetnaSuma == 0)
                return 0;

            

            Decimal suma = ((zavrsnaSuma - pocetnaSuma)/pocetnaSuma)*100;

            return Math.Round(suma, 3);

        }


        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("greska");

            Portfolio portfelj = GetPortfolio(inPortfolioID);

            

            portfelj.RemoveStockFromPortfolio(inStockName,numberOfShares);


          
        }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("greska");

             Portfolio portfelj = GetPortfolio(inPortfolioID);

             

             portfelj.RemoveStockFromPortfolio(inStockName);
         }

        public void DelistStockFromPortfolio(Stock stock)
        {
            if (stock != null)
            {

                foreach (var portfolio in _listPortfolio)
                {
                    if (IsStockPartOfPortfolio(portfolio._PortfolioID, stock))
                        RemoveStockFromPortfolio(portfolio._PortfolioID, stock._stockName);
                }
            }
        }
    }

}
