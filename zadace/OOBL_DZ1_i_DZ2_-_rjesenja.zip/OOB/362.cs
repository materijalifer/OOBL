﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Dionica> _dionice = new List<Dionica>();
        private List<Indeks> _indeksi = new List<Indeks>();
        private List<Portfelj> _portfelji = new List<Portfelj>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Broj dionica ne može biti negativan!");
             
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Cijena dionice ne može biti negativna!");

            if (StockExists(inStockName))
                throw new StockExchangeException("Već postoji dionica sa zadanim nazivom!");

             
            Dionica dionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

            _dionice.Add(dionica);

        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Brišete nepostojeću dionicu!");

            Dionica dionica = new Dionica(inStockName);

            foreach (Indeks indeks in _indeksi)
                if (indeks.SadrziDionicu(dionica))
                    indeks.ObrisiDionicu(dionica);

            foreach (Portfelj portfelj in _portfelji)
                if (portfelj.SadrziDionicu(inStockName))
                    portfelj.MakniDionice(inStockName);


            _dionice.Remove(new Dionica(inStockName));

        }

        public bool StockExists(string inStockName)
        {
            return _dionice.Contains(new Dionica(inStockName));

        }

        public int NumberOfStocks()
        {
            return _dionice.Count;

        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue < 0)
                throw new StockExchangeException("Cijena dionice ne može biti negativna!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Tražena dionica ne postoji!");


            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));

            dionica.PromijeniCijenu(inStockValue, inIimeStamp);

        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Tražena dionica ne postoji!");


            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));
             

            if (dionica.DohvatiPrviDatum() > inTimeStamp)
                throw new StockExchangeException("Dionica tada nije postojala!");


            return dionica.DohvatiCijenu(inTimeStamp);

        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Tražena dionica ne postoji!");


            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica((inStockName))));
             
            return dionica.DohvatiCijenu(dionica.DohvatiPrviDatum());

        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Tražena dionica ne postoji!");


            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica((inStockName))));

            return dionica.DohvatiCijenu(dionica.DohvatiZadnjiDatum());

        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Ne postoji zadani tip indeksa!");

            if (IndexExists(inIndexName))
                throw new StockExchangeException("Već postoji indeks sa zadanim nazivom!");


            Indeks indeks = new Indeks(inIndexName,inIndexType);

            _indeksi.Add(indeks);

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Ne postoji indeks sa zadanim nazivom!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Indeks indeks = _indeksi.ElementAt(_indeksi.IndexOf(new Indeks(inIndexName)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));


            if (dionica.GetIndeks() != null)
                throw new StockExchangeException("Dionica već pripada indeksu" + dionica.GetIndeks() + "!");


            dionica.SetIndeks(indeks);
            indeks.DodajDionicu(dionica);

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Ne postoji indeks sa zadanim nazivom!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Indeks indeks = _indeksi.ElementAt(_indeksi.IndexOf(new Indeks(inIndexName)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));


            if (!indeks.SadrziDionicu(dionica) || !dionica.GetIndeks().Equals(indeks))
                throw new StockExchangeException(indeks + " ne sadrži dionicu " + dionica);


            indeks.ObrisiDionicu(dionica);
            dionica.SetIndeks(null);

        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Ne postoji indeks sa zadanim nazivom!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Indeks indeks = _indeksi.ElementAt(_indeksi.IndexOf(new Indeks(inIndexName)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));

            return indeks.SadrziDionicu(dionica);

        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Ne postoji indeks sa zadanim nazivom!");


            Indeks indeks = _indeksi.ElementAt(_indeksi.IndexOf(new Indeks(inIndexName)));

            return indeks.IzracunajVrijednost(inTimeStamp);

        }

        public bool IndexExists(string inIndexName)
        {
            return _indeksi.Contains(new Indeks(inIndexName));

        }

        public int NumberOfIndices()
        {
            return _indeksi.Count;

        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Ne postoji indeks sa zadanim nazivom!");

            Indeks indeks = _indeksi.ElementAt(_indeksi.IndexOf(new Indeks(inIndexName)));

            return indeks.BrojDionica();

        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj " + inPortfolioID + " već postoji!");


            Portfelj portfelj = new Portfelj(inPortfolioID);

            _portfelji.Add(portfelj);

        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));


            if (dionica.GetBrojDionica() < dionica.GetBrojPoPortfeljima() + numberOfShares)
                throw new StockExchangeException("Ne postoji dovoljno dionica za transakciju!");


            portfelj.DodajDionice(inStockName,numberOfShares);
            dionica.PromijeniBrojPoPortfeljima(-numberOfShares);

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));


            if (!portfelj.SadrziDionicu(inStockName))
                throw new StockExchangeException("Portfelj ne sadrži zadanu dionicu!");

            if (numberOfShares > portfelj.VratiBrojDionica(inStockName))
                throw new StockExchangeException("Portfelj ne sadrži dovoljno dionica za transakciju!");


            dionica.PromijeniBrojPoPortfeljima(numberOfShares);
            portfelj.SmanjiDionice(inStockName, numberOfShares);

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));
            Dionica dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(inStockName)));


            if (!portfelj.SadrziDionicu(inStockName))
                throw new StockExchangeException("Portfelj ne sadrži zadanu dionicu!");


            dionica.PromijeniBrojPoPortfeljima(portfelj.VratiBrojDionica(inStockName));
            portfelj.MakniDionice(inStockName);

        }

        public int NumberOfPortfolios()
        {
            return _portfelji.Count;

        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));

            return portfelj.VratiBrojDionica();

        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfelji.Contains(new Portfelj(inPortfolioID));

        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));

            return portfelj.SadrziDionicu(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");

            if (!StockExists(inStockName))
                throw new StockExchangeException("Ne postoji dionica sa zadanim nazivom!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));


            if (!portfelj.SadrziDionicu(inStockName))
                throw new StockExchangeException("Portfelj ne sadrži zadanu dionicu");

            return portfelj.VratiBrojDionica(inStockName);

        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Ne postoji portfelj sa zadanim ID-em!");


            Portfelj portfelj = _portfelji.ElementAt(_portfelji.IndexOf(new Portfelj(inPortfolioID)));

            decimal value = 0;

            Dionica dionica;
            string imeDionice;
            for (int i = 0; i < portfelj.VratiBrojDionica(); i++)
            {
                imeDionice = portfelj.VratiImeDionice(i);
                dionica = _dionice.ElementAt(_dionice.IndexOf(new Dionica(imeDionice)));
                if (dionica.DohvatiPrviDatum() < timeStamp)
                {
                    value += dionica.DohvatiCijenu(timeStamp)*portfelj.VratiBrojDionica(imeDionice);
                }
            }
            
            return decimal.Round(value, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            DateTime prviDan = new DateTime(Year,Month,1,0,0,0,0);
            DateTime zadnjiDan = new DateTime(Year,Month,DateTime.DaysInMonth(Year,Month),23,59,59,999);

            decimal vrijednostPrviDan = GetPortfolioValue(inPortfolioID, prviDan);
            decimal vrijednostZadnjiDan = GetPortfolioValue(inPortfolioID, zadnjiDan);

            if (vrijednostPrviDan == 0) return 0;
            return (vrijednostZadnjiDan - vrijednostPrviDan)/vrijednostPrviDan*100;
        }
    }

    class Dionica
    {
        private string _imeDionice;
        private long _brojDionica;
        private List<Decimal> _povijestCijene = new List<decimal>();
        private List<DateTime> _povijestPromjena = new List<DateTime>();
        private Indeks _pripadaIndeksu;
        private long _poPortfeljima = 0;

        public Dionica(string imeDionice, long brojDionica, Decimal cijenaDionice, DateTime datumKreiranja)
        {
            _imeDionice = imeDionice;
            _brojDionica = brojDionica;
            _povijestCijene.Add(cijenaDionice);
            _povijestPromjena.Add(datumKreiranja);

        }
        public Dionica(string imeDionice)
        {
            _imeDionice = imeDionice;
        }

        public long GetBrojDionica()
        {
            return _brojDionica;
        }

        public void PromijeniCijenu(Decimal cijena, DateTime dateTime)
        {
            _povijestCijene.Add(cijena);
            _povijestPromjena.Add(dateTime);
        }

        public decimal DohvatiCijenu(DateTime inTimeStamp)
        {
            decimal cijena = 0;

            DateTime target = DohvatiPrviDatum();
            foreach (DateTime dateTime in _povijestPromjena)
            {
                if (dateTime <= inTimeStamp && dateTime >= target)
                    target = dateTime;
            }
            cijena = _povijestCijene.ElementAt(_povijestPromjena.IndexOf(target));
            return cijena;
        }

        public DateTime DohvatiPrviDatum()
        {
            DateTime pocetak = _povijestPromjena.ElementAt(0);
            foreach (DateTime time in _povijestPromjena)
            {
                if (time <= pocetak) pocetak = time;
            }
            return pocetak;
        }

        public DateTime DohvatiZadnjiDatum()
        {
            DateTime kraj = _povijestPromjena.ElementAt(0);
            foreach (DateTime time in _povijestPromjena)
            {
                if (time >= kraj) kraj = time;
            }
            return kraj;
        }

        public void SetIndeks(Indeks indeks)
        {
            _pripadaIndeksu = indeks;
        }
        public Indeks GetIndeks()
        {
            return _pripadaIndeksu;
        }

        public long GetBrojPoPortfeljima()
        {
            return _poPortfeljima;
        }
        public void PromijeniBrojPoPortfeljima(long brojDionica)
        {
            _poPortfeljima += brojDionica;
        }

        // override object.Equals
        public override bool Equals(object obj)
        {
            //       
            // See the full list of guidelines at
            //   http://go.microsoft.com/fwlink/?LinkID=85237  
            // and also the guidance for operator== at
            //   http://go.microsoft.com/fwlink/?LinkId=85238
            //

            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            return _imeDionice.ToLower().Equals(((Dionica) obj)._imeDionice.ToLower());
        }

        // override object.ToString
        public override string ToString()
        {
            return _imeDionice;
        }
    }

    class Indeks
    {
        private string _imeIndeksa ;
        private IndexTypes _tipIndeksa;
        private List<Dionica> _dionice = new List<Dionica>();

        public Indeks(string imeIndeksa, IndexTypes tipIndeksa)
        {
            _imeIndeksa = imeIndeksa;
            _tipIndeksa = tipIndeksa;
        }
        public Indeks(string imeIndeksa)
        {
            _imeIndeksa = imeIndeksa;
        }

        public void DodajDionicu(Dionica dionica)
        {
            _dionice.Add(dionica);
        }
        public void ObrisiDionicu(Dionica dionica)
        {
            _dionice.Remove(dionica);
        }
        public bool SadrziDionicu(Dionica dionica)
        {
            return _dionice.Contains(dionica);
        }
        public int BrojDionica()
        {
            return _dionice.Count;
        }

        public decimal IzracunajVrijednost(DateTime inTimeStamp)
        {
            decimal value = 0;
            
            switch (_tipIndeksa)
            {
                case IndexTypes.AVERAGE:
                    int brojDionica = 0;
                    foreach (Dionica dionica in _dionice)
                    {
                        if (dionica.DohvatiPrviDatum() < inTimeStamp)
                        {
                            value += dionica.DohvatiCijenu(inTimeStamp);
                            brojDionica++;
                        }
                    }
                    if (brojDionica == 0) return 0;
                    value /= brojDionica;
                    break;

                case IndexTypes.WEIGHTED:
                    decimal sum = 0;
                    foreach (Dionica dionica in _dionice)
                    {
                        if (dionica.DohvatiPrviDatum() < inTimeStamp)
                            sum += dionica.DohvatiCijenu(inTimeStamp) * dionica.GetBrojDionica();
                    }
                    foreach (Dionica dionica in _dionice)
                    {
                        if (dionica.DohvatiPrviDatum() < inTimeStamp)
                            value += dionica.DohvatiCijenu(inTimeStamp) * dionica.DohvatiCijenu(inTimeStamp) * dionica.GetBrojDionica();
                    }
                    if (sum == 0) return 0;
                    value /= sum;
                    break;
            }
            return decimal.Round(value, 3);
        }

        // override object.Equals
        public override bool Equals(object obj)
        {
            //       
            // See the full list of guidelines at
            //   http://go.microsoft.com/fwlink/?LinkID=85237  
            // and also the guidance for operator== at
            //   http://go.microsoft.com/fwlink/?LinkId=85238
            //

            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            return _imeIndeksa.ToLower().Equals(((Indeks)obj)._imeIndeksa.ToLower());
        }

        // override object.ToString
        public override string ToString()
        {
            return _imeIndeksa;
        }

    }

    class Portfelj
    {
        private string _imePortfelja;
        private Dictionary<string, int> _dionicePoDionicama = new Dictionary<string, int>();

        public Portfelj(string imePortfelja)
        {
            _imePortfelja = imePortfelja;
        }
        public void DodajDionice(string nazivDionice, int brojDionica)
        {
            if (_dionicePoDionicama.ContainsKey(nazivDionice))
                _dionicePoDionicama[nazivDionice] += brojDionica;
            else
                _dionicePoDionicama.Add(nazivDionice, brojDionica);
        }
        public void SmanjiDionice(string nazivDionice, int brojDionica)
        {
            _dionicePoDionicama[nazivDionice] -= brojDionica;

            if (_dionicePoDionicama[nazivDionice] == 0)
                MakniDionice(nazivDionice);
        }
        public void MakniDionice(string nazivDionice)
        {
            _dionicePoDionicama.Remove(nazivDionice);
        }
        public int VratiBrojDionica()
        {
            return _dionicePoDionicama.Count;
        }
        public int VratiBrojDionica(string nazivDionice)
        {
            return _dionicePoDionicama[nazivDionice];
        }
        public bool SadrziDionicu(string nazivDionice)
        {
            return _dionicePoDionicama.ContainsKey(nazivDionice);
        }
        public string VratiImeDionice(int index)
        {
            return _dionicePoDionicama.Keys.ElementAt(index);
        }



        // override object.Equals
        public override bool Equals(object obj)
        {
            //       
            // See the full list of guidelines at
            //   http://go.microsoft.com/fwlink/?LinkID=85237  
            // and also the guidance for operator== at
            //   http://go.microsoft.com/fwlink/?LinkId=85238
            //

            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            return _imePortfelja.Equals(((Portfelj)obj)._imePortfelja);
        }

        // override object.ToString
        public override string ToString()
        {
            return _imePortfelja;
        }

    }
}
