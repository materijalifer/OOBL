﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> allStockInMarket = new Dictionary<string, Stock>();
        private Dictionary<string, Index> allIndicesInMarket = new Dictionary<string, Index>();
        private Dictionary<string, Portfolio> allPortfoliosInMarket = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            CheckIfStockExists(inStockName, false);
            CheckNumberOfShares(inNumberOfShares);
            CheckPrice(inInitialPrice);

            allStockInMarket.Add(inStockName.ToLower(), new Stock(inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            CheckIfStockExists(inStockName, true);

            allStockInMarket.Remove(inStockName.ToLower());
        }

        public bool StockExists(string inStockName)
        {
            return allStockInMarket.Keys.Contains(inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return allStockInMarket.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            CheckPrice(inStockValue);
            CheckIfStockExists(inStockName, true);

            Stock stock = allStockInMarket[inStockName.ToLower()];
            stock.SetPrice(inIimeStamp, inStockValue);  
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            CheckIfStockExists(inStockName, true);
                
            return allStockInMarket[inStockName.ToLower()].GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            CheckIfStockExists(inStockName, true);
                
            return allStockInMarket[inStockName.ToLower()].GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            CheckIfStockExists(inStockName, true);
                
            return allStockInMarket[inStockName.ToLower()].GetPrice(DateTime.MaxValue);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            CheckIfIndexExists(inIndexName, false);
                    
            allIndicesInMarket.Add(inIndexName.ToLower(), new Index(inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            CheckIfStockPartOfIndex(inIndexName, inStockName, false);
            
            allIndicesInMarket[inIndexName.ToLower()].Stocks.Add(inStockName.ToLower(), allStockInMarket[inStockName.ToLower()]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            CheckIfStockPartOfIndex(inIndexName, inStockName, true);
            
            allIndicesInMarket[inIndexName.ToLower()].Stocks.Remove(inStockName.ToLower());
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            CheckIfIndexExists(inIndexName, true);
            CheckIfStockExists(inStockName, true);
                    
            return allIndicesInMarket[inIndexName.ToLower()].Stocks.Keys.Contains(inStockName.ToLower());
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            CheckIfIndexExists(inIndexName, true);
            decimal sum;

            switch (allIndicesInMarket[inIndexName.ToLower()].Type)
            {
                case IndexTypes.AVERAGE:
                    sum = 0;
                    foreach (Stock stock in allIndicesInMarket[inIndexName.ToLower()].Stocks.Values)
                        sum += stock.GetPrice(inTimeStamp);

                    return decimal.Round(sum / NumberOfStocksInIndex(inIndexName.ToLower()), 3);

                case IndexTypes.WEIGHTED:
                    sum = 0;
                    decimal result = 0;
                    decimal stockValue;

                    foreach (KeyValuePair<string, Stock> stock in allIndicesInMarket[inIndexName.ToLower()].Stocks)
                        sum += stock.Value.GetPrice(inTimeStamp) * stock.Value.NumberOfShares;

                    foreach (KeyValuePair<string, Stock> stock in allIndicesInMarket[inIndexName.ToLower()].Stocks)
                    {
                        stockValue = stock.Value.GetPrice(inTimeStamp) * stock.Value.NumberOfShares;
                        result += stock.Value.GetPrice(inTimeStamp) * stockValue / sum;
                    }

                    return decimal.Round(result, 3);

                default:
                    throw new StockExchangeException("Wrong IndexType");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return allIndicesInMarket.Keys.Contains(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return allIndicesInMarket.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            CheckIfIndexExists(inIndexName, true);

            return allIndicesInMarket[inIndexName.ToLower()].Stocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            CheckIfPortfolioExists(inPortfolioID, false);

            allPortfoliosInMarket.Add(inPortfolioID, new Portfolio());
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            CheckIfPortfolioExists(inPortfolioID, true);
            CheckIfStockExists(inStockName, true);

            if (allStockInMarket[inStockName.ToLower()].NumberOfSharesNotInPortfolio < numberOfShares)
                throw new StockExchangeException("Not enough shares to add.");

            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()] += numberOfShares;
            else
                allPortfoliosInMarket[inPortfolioID].Stocks.Add(inStockName.ToLower(), numberOfShares);

            allStockInMarket[inStockName.ToLower()].NumberOfSharesNotInPortfolio -= numberOfShares;
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            CheckIfStockPartOfPortfolio(inPortfolioID, inStockName.ToLower(), true);

            if (allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()] >= numberOfShares)
            {
                allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()] -= numberOfShares;
                allStockInMarket[inStockName.ToLower()].NumberOfSharesNotInPortfolio += numberOfShares;
            }
            else
                throw new StockExchangeException("Not enough shares to remove.");

            if (allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()] == 0)
                RemoveStockFromPortfolio(inPortfolioID, inStockName);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            CheckIfStockPartOfPortfolio(inPortfolioID, inStockName.ToLower(), true);

            allStockInMarket[inStockName].NumberOfSharesNotInPortfolio +=
                allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()];

            allPortfoliosInMarket[inPortfolioID].Stocks.Remove(inStockName.ToLower());
        }

        public int NumberOfPortfolios()
        {
            return allPortfoliosInMarket.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            CheckIfPortfolioExists(inPortfolioID, true);
                return allPortfoliosInMarket[inPortfolioID].Stocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return allPortfoliosInMarket.Keys.Contains(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            CheckIfPortfolioExists(inPortfolioID, true);
            CheckIfStockExists(inStockName, true);
            
            return allPortfoliosInMarket[inPortfolioID].Stocks.Keys.Contains(inStockName.ToLower());
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            CheckIfStockPartOfPortfolio(inPortfolioID, inStockName.ToLower(), true);

            return (int)allPortfoliosInMarket[inPortfolioID].Stocks[inStockName.ToLower()];
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            CheckIfPortfolioExists(inPortfolioID, true);

            decimal result = 0;
            foreach (KeyValuePair<string, long> shares in allPortfoliosInMarket[inPortfolioID].Stocks)
                result += allStockInMarket[shares.Key].GetPrice(timeStamp) * shares.Value;

            return result;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            CheckIfPortfolioExists(inPortfolioID, true);
            DateTime from = DateTime.Now;
            DateTime to = DateTime.Now;
            try
            {
                from = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                to = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            }
            catch
            {
                throw new StockExchangeException("Wrong year/month");
            }

            return (GetPortfolioValue(inPortfolioID, from) / GetPortfolioValue(inPortfolioID, to) - 1) * 100;
        }

        #region checks

        private void CheckIfStockExists(string inStockName, bool expected)
        {
            if (StockExists(inStockName) != expected)
                throw new StockExchangeException("'CheckIfStockExists' threw an exception.");
        }

        private void CheckIfIndexExists(string inIndexName, bool expected)
        {
            if (IndexExists(inIndexName) != expected)
                throw new StockExchangeException("'CheckIfIndexExists' threw an exception.");
        }

        private void CheckIfPortfolioExists(string inPortfolioName, bool expected)
        {
            if (PortfolioExists(inPortfolioName) != expected)
                throw new StockExchangeException("'CheckIfPortfolioExists' threw an exception.");
        }

        private void CheckNumberOfShares(long inNumberOfShares)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Number of shares can't be zero or negative.");
        }

        private void CheckPrice(decimal price)
        {
            if( price <= 0)
                throw new StockExchangeException("Price can't be zero or negative.");
        }

        private void CheckIfStockPartOfIndex(string inIndexName, string inStockName, bool expected)
        {
            if(IsStockPartOfIndex(inIndexName, inStockName) != expected)
                throw new StockExchangeException("'CheckIfStockPartOfIndex' threw an exception");
        }

        private void CheckIfStockPartOfPortfolio(string inPortfolioName, string inStockName, bool expected)
        {
            if (IsStockPartOfPortfolio(inPortfolioName, inStockName) != expected)
                throw new StockExchangeException("'CheckIfStockPartOfPortfolio' threw an exception");
        }

        #endregion
    }

    public class Stock
    {
        #region private members
        long numberOfShares;
        Dictionary<DateTime, decimal> prices = new Dictionary<DateTime,decimal>();

        // better than counting the in all partfolios, no?
        long numberOfSharesNotInPortfolio;
        #endregion

        #region constructor
        public Stock(long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            numberOfShares = inNumberOfShares;
            NumberOfSharesNotInPortfolio = inNumberOfShares;
            prices.Add(inTimeStamp, inInitialPrice);

        }
        #endregion

        #region public properties

        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }

        public long NumberOfSharesNotInPortfolio
        {
            get { return numberOfSharesNotInPortfolio; }
            set { numberOfSharesNotInPortfolio = value; }
        }
        #endregion

        #region public methods

        public decimal GetInitialPrice()
        {
            return prices.First().Value;
        }

        public decimal GetPrice (DateTime inTimeStamp)
        {
            try
            {
                return prices.Last(x => x.Key < inTimeStamp).Value;
            }
            catch
            {
                throw new StockExchangeException("Too early junior...");
            }
        }

        public void SetPrice(DateTime inTimeStamp, decimal inPrice)
        {
            prices.Add(inTimeStamp, inPrice);
        }

        #endregion
    }

    public class Index
    {
        #region private members
        IndexTypes type;
        Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        #endregion

        #region constructor
        public Index(IndexTypes inIndexType)
        {
            type = inIndexType;
        }
        #endregion

        #region public properties
        
        public IndexTypes Type
        {
            get { return type; }
            set { type = value; }
        }

        public Dictionary<string, Stock> Stocks
        {
            get { return stocks; }
            set { stocks = value; }
        }

        #endregion
    }

    public class Portfolio
    {
        #region private members

        Dictionary<string, long> stocks = new Dictionary<string, long>();

        #endregion
        
        #region public properties

        public Dictionary<string, long> Stocks
        {
            get { return stocks; }
            set { stocks = value; }
        }
        #endregion
    }
}
