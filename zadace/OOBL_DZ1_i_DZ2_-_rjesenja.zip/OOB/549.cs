﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string StockName;
        public long NumberOfShares;
        public decimal InitialPrice;
        public SortedDictionary<DateTime, decimal> StockPrices;
        public DateTime TimeStamp;
    }

    public class Index
    {
        public string IndexName;
        public IndexTypes IndexType;
        public List<Stock> ListOfStocksInIndex;
    }

    public class Portfolio
    {
        public string PortfolioID;
        public Dictionary<Stock, long> StocksInPortfolio;
    }

    public class StockExchange : IStockExchange
    {
        public List<Stock> ListOfStocks = new List<Stock>();
        public List<Index> ListOfIndices = new List<Index>(); 
        public List<Portfolio> ListOfPortfolios=new List<Portfolio>(); 
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName)) throw new StockExchangeException("Stock with that name already exists!");
             if (inInitialPrice <= 0 || inNumberOfShares <= 0) throw new StockExchangeException("Initial price can not be negative!");
             var newStock = new Stock
             {
                 StockName = inStockName,
                 NumberOfShares = inNumberOfShares,
                 InitialPrice = inInitialPrice,
                 StockPrices = new SortedDictionary<DateTime, decimal>(){{inTimeStamp, inInitialPrice}},
                 TimeStamp = inTimeStamp
             };
             ListOfStocks.Add(newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName)) throw new StockExchangeException("Stock with that name does not exist!");
             foreach (var index in ListOfIndices.Where(index => IsStockPartOfIndex(index.IndexName, inStockName)))
                 RemoveStockFromIndex(index.IndexName, inStockName);
             foreach (
                 var portfolio in
                     ListOfPortfolios.Where(portfolio => IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName))
                 )
                 RemoveStockFromPortfolio(portfolio.PortfolioID, inStockName);
             ListOfStocks.RemoveAll(
                 stock => String.Equals(stock.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
         }

        public bool StockExists(string inStockName)
         {
             return ListOfStocks != null && ListOfStocks.Any(stock => String.Equals(stock.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
         }

         public int NumberOfStocks()
         {
             return ListOfStocks == null ? 0 : ListOfStocks.Count();
         }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var stock = GetStock(inStockName);
            try
            {
                stock.StockPrices.Add(inIimeStamp, inStockValue);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Price at that time is already set!");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stock = GetStock(inStockName);
            if(inTimeStamp < stock.StockPrices.Keys.First()) throw new StockExchangeException("Price not set for that time!");
            var stockPrice = stock.StockPrices.Values.First();
            foreach (var pair in stock.StockPrices)
            {
                if (pair.Key <= inTimeStamp)
                    stockPrice = pair.Value;
                else
                    break;
            }
            return stockPrice;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             var stock = GetStock(inStockName);
             return stock.StockPrices.Values.First();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             var stock = GetStock(inStockName);
             return stock.StockPrices.Values.Last();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!CheckIndexType(inIndexType)) throw new StockExchangeException("Can not create index of that type!");
             if (IndexExists(inIndexName)) throw new StockExchangeException("Index with that name already exists!");
             var newIndex = new Index
             {
                 IndexName = inIndexName,
                 IndexType = inIndexType,
                 ListOfStocksInIndex = new List<Stock>()
             };
             ListOfIndices.Add(newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
            var stock = GetStock(inStockName);
            var index = GetIndex(inIndexName);
            if(!IsStockPartOfIndex(inIndexName, inStockName))
                    index.ListOfStocksInIndex.Add(stock);
            else throw new StockExchangeException("Stock is already a part of that index!");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             var index = GetIndex(inIndexName);
             if (IsStockPartOfIndex(inIndexName, inStockName))
                 index.ListOfStocksInIndex.RemoveAll(
                     (stock => String.Equals(stock.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase)));
             else
                 throw new StockExchangeException("That stock is not a part of this index!");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             var index = GetIndex(inIndexName);
             return
                 index.ListOfStocksInIndex.Any(
                     stock => String.Equals(stock.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             var index = GetIndex(inIndexName);
             if (index.ListOfStocksInIndex == null || !index.ListOfStocksInIndex.Any()) return 0m;
             if (index.IndexType == IndexTypes.AVERAGE)
             {
                 var sum = index.ListOfStocksInIndex.Sum(stock => GetStockPrice(stock.StockName, inTimeStamp));
                 return Math.Round(sum/NumberOfStocksInIndex(inIndexName), 3);
             }
             else
             {
                 var sum = 0m;
                 var total = 0m;
                 foreach (var stock in index.ListOfStocksInIndex)
                 {
                     sum += GetStockPrice(stock.StockName, inTimeStamp)*GetStockPrice(stock.StockName, inTimeStamp)*
                            stock.NumberOfShares;
                     total += stock.NumberOfShares*GetStockPrice(stock.StockName, inTimeStamp);
                 }
                 return Math.Round(sum/total, 3);
             }
         }

         public bool IndexExists(string inIndexName)
         {
             return ListOfIndices != null && ListOfIndices.Any(index => String.Equals(index.IndexName, inIndexName, StringComparison.CurrentCultureIgnoreCase));
         }

         public int NumberOfIndices()
         {
             return ListOfIndices == null ? 0 : ListOfIndices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             var index = GetIndex(inIndexName);
             return index.ListOfStocksInIndex == null ? 0 : index.ListOfStocksInIndex.Count();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID already exists!");
             var newPortfolio = new Portfolio
             {
                 PortfolioID = inPortfolioID,
                 StocksInPortfolio = new Dictionary<Stock, long>()
             };
             ListOfPortfolios.Add(newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             var newNumberOfShares = CanAddStockToPortfolio(inStockName, numberOfShares);
             if (newNumberOfShares < numberOfShares) numberOfShares = (int) newNumberOfShares;

             var stock = GetStock(inStockName);
             var portfolio = GetPortfolio(inPortfolioID);
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 portfolio.StocksInPortfolio.Add(stock, numberOfShares);
             else
                 portfolio.StocksInPortfolio[stock] += numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName)) throw new StockExchangeException("Stock is not a part of this portfolio!");
             var portfolio = GetPortfolio(inPortfolioID);
             var stock =
                 portfolio.StocksInPortfolio.First(
                     s => String.Equals(s.Key.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
             portfolio.StocksInPortfolio[stock.Key] -= numberOfShares;
             if(portfolio.StocksInPortfolio[stock.Key] <= 0)
                 RemoveStockFromPortfolio(inPortfolioID, inStockName);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName)) throw new StockExchangeException("Stock is not a part of this portfolio!");
             var portfolio = GetPortfolio(inPortfolioID);
             var stock =
                 portfolio.StocksInPortfolio.First(
                     s => String.Equals(s.Key.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
             portfolio.StocksInPortfolio.Remove(stock.Key);
         }

         public int NumberOfPortfolios()
         {
             return ListOfPortfolios == null ? 0 : ListOfPortfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             return portfolio.StocksInPortfolio == null ? 0 : portfolio.StocksInPortfolio.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return ListOfPortfolios != null && ListOfPortfolios.Any(portfolio => String.Equals(portfolio.PortfolioID, inPortfolioID));
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             try
             {
                 var stock = GetStock(inStockName);
                 return portfolio.StocksInPortfolio.ContainsKey(stock);
             }
             catch (StockExchangeException)
             {
                 return false;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName)) return 0; 
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);
             return (int) portfolio.StocksInPortfolio[stock];
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             return portfolio.StocksInPortfolio.Sum(stock => GetStockPrice(stock.Key.StockName, timeStamp)*stock.Value);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (Year < 1 || Year > 9999 || Month < 1 || Month > 12)
                 throw new StockExchangeException("Wrong month and/or year!");
            var portfolioValueForMonth = 0m;
            var valueFirstDay = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 000));
            var valueLastDay = GetPortfolioValue(inPortfolioID,
                new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

             if (valueFirstDay != 0 && valueLastDay != 0)
                 portfolioValueForMonth = (valueLastDay - valueFirstDay)*100/valueFirstDay;

             return Math.Round(portfolioValueForMonth, 3);
         }



        public Stock GetStock(string inStockName)
        {
            if (StockExists(inStockName))
                return ListOfStocks.First(
                    s => String.Equals(s.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase));
            throw new StockExchangeException("Stock with that name does not exist!");
        }

        public Index GetIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
                return ListOfIndices.First(
                    i => String.Equals(i.IndexName, inIndexName, StringComparison.CurrentCultureIgnoreCase));
            throw new StockExchangeException("Index with that name does not exist!");
        }

        public Portfolio GetPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                return ListOfPortfolios.First(p => String.Equals(p.PortfolioID, inPortfolioID));
            throw new StockExchangeException("Portfolio with that name does not exist!");
        }

        public decimal CanAddStockToPortfolio(string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0) throw new StockExchangeException("Number of shares can not be negative or zero!");
            var stock = GetStock(inStockName);
            var sumOfSharesInPortfolios = ListOfPortfolios.Where(portfolio => IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName)).Aggregate(0m, (current, portfolio) => current + NumberOfSharesOfStockInPortfolio(portfolio.PortfolioID, inStockName));
            return stock.NumberOfShares - sumOfSharesInPortfolios;
        }

        public bool CheckIndexType(IndexTypes type)
        {
            return (int)type == (int)IndexTypes.AVERAGE || (int)type == (int)IndexTypes.WEIGHTED;
        }
    }
}
