﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
     {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
     }

     public class StockPriceInTime
     {
         private decimal _stockPrice;
         private DateTime _priceTimeStamp;

         public decimal Price
         {
             get
             {
                 return _stockPrice;
             }
         }

         public DateTime Time
         {
             get
             {
                 return _priceTimeStamp;
             }
         }

         public StockPriceInTime(decimal inStockPrice, DateTime inPriceTime)
         {
             _stockPrice = inStockPrice;
             _priceTimeStamp = inPriceTime;
         }
         
     }

     public class Stock
     {
         private string _name;
         private long _numberOfShares;
         private long _numberOfFreeShares;
         private List<StockPriceInTime> _listStockPrices;

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _name = inStockName;
             _numberOfShares = inNumberOfShares;
             _numberOfFreeShares = inNumberOfShares;
             _listStockPrices = new List<StockPriceInTime>();
             SetStockPrice(inTimeStamp, inInitialPrice);
         }

         public void SetStockPrice(DateTime inIimeStamp, decimal inStockValue) 
         {
             if (_listStockPrices.Find(x => x.Time == inIimeStamp) == null)
             {
                 StockPriceInTime stockPrice = new StockPriceInTime(inStockValue, inIimeStamp);
                 _listStockPrices.Add(stockPrice);
             }
             else
             {
                 throw new StockExchangeException("Postojeci timestamp!");
             }
         }

         public string Name
         {
             get
             {
                 return _name;
             }
         }

         public long NumberOfShares
         {
             get
             {
                 return _numberOfShares;
             }
             set
             {
                 _numberOfShares = value;
             }
         }

         public int GetSomeShares(int inNumberOfShares)
         {
             if (inNumberOfShares <= _numberOfFreeShares)
             {
                 _numberOfFreeShares -= inNumberOfShares;
                 return inNumberOfShares;
             }
             else
             {
                 throw new StockExchangeException("Nema toliko dionica!");
             }
         }

         public void ReturnSomeShares(int inNumberOfShares)
         {
             _numberOfFreeShares += inNumberOfShares;
         }

         public decimal InitialPrice
         {
             get
             {
                 StockPriceInTime initialPrice;
                 initialPrice = _listStockPrices.SingleOrDefault(x => x.Time == _listStockPrices.Min(y => y.Time));
                 return initialPrice.Price;
             }
         }

         public decimal GetStockPrice(DateTime inTimeStamp)
         {
             List<StockPriceInTime> orderedListPriceInTime;
             StockPriceInTime searchResult;
             orderedListPriceInTime = _listStockPrices.OrderBy(x => x.Time).ToList<StockPriceInTime>();
             if (orderedListPriceInTime[0].Time < inTimeStamp)
             {
                 searchResult = orderedListPriceInTime[0];
                 foreach (StockPriceInTime spt in orderedListPriceInTime)
                 {
                     if (spt.Time < inTimeStamp)
                     {
                         searchResult = spt;
                     }
                 }
                 return searchResult.Price;
             }
             else
             {
                 throw new StockExchangeException("Nema definiranu vrijednost u tom trenutku!");
             }
         }

         public decimal LastPrice
         {
             get
             {
                 StockPriceInTime lastPrice;
                 lastPrice = _listStockPrices.SingleOrDefault(x => x.Time == _listStockPrices.Max(y => y.Time));
                 return lastPrice.Price;
             }
         }
     }

     public class Index
     {
         private string _name;
         private IndexTypes _type;
         private List<Stock> _listStocks;

         public Index(string inIndexName, IndexTypes indexType)
         {
             _name = inIndexName;
             _type = indexType;
             _listStocks = new List<Stock>();
         }

         public string Name
         {
             get
             {
                 return _name;
             }
         }

         public int NumberOfStocks
         {
             get
             {
                return _listStocks.Count;
             }
         }

         public void AddStock(Stock stock)
         {
             if (!ContainsStock(stock))
             {
                 _listStocks.Add(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock postoji!");
             }
         }

         public bool ContainsStock(Stock stock)
         {
             if (_listStocks.Contains(stock))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public void RemoveStock(Stock stock)
         {
             if (ContainsStock(stock))
             {
                 _listStocks.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Ne postojeci stock!");
             }
         }

         public decimal GetValue(DateTime inTimeStamp)
         {
             if (_listStocks.Count != 0)
             {
                 if (_type == IndexTypes.AVERAGE)
                 {
                     decimal resultValue;
                     resultValue = _listStocks.Average(x => x.GetStockPrice(inTimeStamp));
                     return resultValue;
                 }
                 else if (_type == IndexTypes.WEIGHTED)
                 {
                     decimal weightedValueSum = 0;
                     decimal weightSum = 0;
                     decimal weight;
                     decimal weightedValue;
                     decimal stockValueSum;

                     stockValueSum = _listStocks.Sum(x => x.NumberOfShares * x.GetStockPrice(inTimeStamp));

                     foreach (Stock s in _listStocks)
                     {
                         weight = s.GetStockPrice(inTimeStamp) * s.NumberOfShares / stockValueSum;
                         weightSum += weight;
                         weightedValue = weight * s.GetStockPrice(inTimeStamp);
                         weightedValueSum += weightedValue;
                     }

                     return weightedValueSum / weightSum;
                 }
                 else
                 {
                     throw new StockExchangeException("Ne postojeci tip indeksa!");
                 }
             }
             else
             {
                 return 0;
             }             
         }
     }

     public class StockInPortfolio
     {
         private Stock _stock;
         private int _numberOfShares;

         public StockInPortfolio(Stock inStock, int inNumberOfShares)
         {
             _stock = inStock;
             _numberOfShares = inNumberOfShares;
         }

         public int NumberOfShares
         {
             get
             {
                 return _numberOfShares;
             }
         }

         public Stock Stock
         {
             get
             {
                 return _stock;
             }
         }

         public void RemoveSomeShares(int inNumberOfShares)
         {
             if (_numberOfShares >= inNumberOfShares)
             {
                 _stock.ReturnSomeShares(inNumberOfShares);
                 _numberOfShares -= inNumberOfShares;
             }
             else
             {
                 throw new StockExchangeException("Nema tolko dionica!");
             }
         }
     }

     public class Portfolio
     {
         private string _id;
         private List<StockInPortfolio> _listStocks;

         public Portfolio(string inId)
         {
             _id = inId;
             _listStocks = new List<StockInPortfolio>();
         }

         public string ID
         {
             get
             {
                 return _id;
             }
         }

         public void AddStock(Stock inStock, int inNumberOfShares)
         {
             StockInPortfolio newStockInPortfolio = new StockInPortfolio(inStock, inStock.GetSomeShares(inNumberOfShares));
             _listStocks.Add(newStockInPortfolio);
         }

         public void RemoveStock(Stock inStock, int inNumberOfShares)
         {
             StockInPortfolio stockInPortfolio = _listStocks.Find(x => x.Stock == inStock);
             stockInPortfolio.RemoveSomeShares(inNumberOfShares);
             if (stockInPortfolio.NumberOfShares == 0)
             {
                 _listStocks.Remove(stockInPortfolio);
             }
         }

         public void RemoveStock(Stock inStock)
         {
             StockInPortfolio stockInPortfolio = _listStocks.Find(x => x.Stock == inStock);
             stockInPortfolio.RemoveSomeShares(stockInPortfolio.NumberOfShares);
             _listStocks.Remove(stockInPortfolio);
         }

         public int NumberOfStocks
         {
             get
             {
                 return _listStocks.Count;
             }
         }

         public bool IsStockPartOfPortfolio(Stock inStock)
         {
             if (_listStocks.Find(x => x.Stock == inStock) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfSharesOfStock(Stock inStock)
         {
             StockInPortfolio stockInPortfolio = _listStocks.Find(x => x.Stock == inStock);
             return stockInPortfolio.NumberOfShares;
         }

         public decimal GetPortfolioValue(DateTime inTimeStamp)
         {
             decimal stockPrice;
             decimal stockValue;
             decimal portfolioValue = 0.0M;
             foreach (StockInPortfolio s in _listStocks)
             {
                 stockPrice = s.Stock.GetStockPrice(inTimeStamp);
                 stockValue = stockPrice * s.NumberOfShares;
                 portfolioValue += stockValue;
             }
             return portfolioValue;
         }

         public decimal GetPercentChangeInValueForMonth(int Year, int Month)
         {
             DateTime pocetakMjeseca;
             DateTime krajMjeseca;
             decimal portfolioValuePocetakMjeseca;
             decimal portfolioValueKrajMjeseca;
             decimal percentChange;

             pocetakMjeseca = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             krajMjeseca = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

             portfolioValueKrajMjeseca = GetPortfolioValue(krajMjeseca);
             portfolioValuePocetakMjeseca = GetPortfolioValue(pocetakMjeseca);

             percentChange = (portfolioValueKrajMjeseca - portfolioValuePocetakMjeseca) / portfolioValuePocetakMjeseca * 100;

             return Math.Round(percentChange, 3);
         }
     }

     public class StockExchange : IStockExchange
     {
         private List<Stock> _listStocks = new List<Stock>();
         private List<Index> _listStockIndexes = new List<Index>();
         private List<Portfolio> _listPortfolios = new List<Portfolio>();

         private Stock GetStockByName(string inStockName)
         {
             string searchString = inStockName.ToLower();
             Stock stock = _listStocks.Find(x => x.Name.ToLower().Equals(searchString));
             return stock;
         }

         private Index GetIndexByName(string inIndexName)
         {
             string searchString = inIndexName.ToLower();
             Index index = _listStockIndexes.Find(x => x.Name.ToLower().Equals(searchString));
             return index;
         }

         private Portfolio GetPortfolioByName(string inId)
         {
             Portfolio portfolio = _listPortfolios.Find(x => x.ID.Equals(inId));
             return portfolio;
         }


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 _listStocks.Add(newStock);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 string searchString = inStockName.ToLower();
                 Stock stockToRemove = GetStockByName(searchString);
                 _listStocks.Remove(stockToRemove);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public bool StockExists(string inStockName)
         {
             if (GetStockByName(inStockName) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return _listStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 Stock stock;
                 stock = GetStockByName(inStockName);
                 stock.SetStockPrice(inIimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);
                 return stock.GetStockPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);
                 return stock.InitialPrice;
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Stock stock = GetStockByName(inStockName);
                 return stock.LastPrice;
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!IndexExists(inIndexName))
             {
                 Index newIndex = new Index(inIndexName, inIndexType);
                 _listStockIndexes.Add(newIndex);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Index index = GetIndexByName(inIndexName);
                 Stock stock = GetStockByName(inStockName);
                 index.AddStock(stock);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Index index = GetIndexByName(inIndexName);
                 Stock stock = GetStockByName(inStockName);
                 index.RemoveStock(stock);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Index index = GetIndexByName(inIndexName);
                 Stock stock = GetStockByName(inStockName);
                 if (index.ContainsStock(stock))
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 Index index = GetIndexByName(inIndexName);
                 return index.GetValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             if (GetIndexByName(inIndexName) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return _listStockIndexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 return GetIndexByName(inIndexName).NumberOfStocks;
             }
             else
             {
                 throw new StockExchangeException("Error!");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 Portfolio newPortfolio = new Portfolio(inPortfolioID);
                 _listPortfolios.Add(newPortfolio);
             }
             else
             {
                 throw new StockExchangeException("Portfolio vec postoji!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Portfolio portfolio = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);
                 portfolio.AddStock(stock, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port ili stock!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Portfolio portfolio = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 portfolio.RemoveStock(stock, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port ili stock!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Portfolio portfolio = GetPortfolioByName(inPortfolioID);
                 Stock stock = GetStockByName(inStockName);

                 portfolio.RemoveStock(stock);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port ili stock!");
             }
         }

         public int NumberOfPortfolios()
         {
             return _listPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return GetPortfolioByName(inPortfolioID).NumberOfStocks;
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port!");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (GetPortfolioByName(inPortfolioID) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 if (GetPortfolioByName(inPortfolioID).IsStockPartOfPortfolio(GetStockByName(inStockName)))
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port ili stock!");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 return GetPortfolioByName(inPortfolioID).NumberOfSharesOfStock(GetStockByName(inStockName));
             }
             else
             {
                 throw new StockExchangeException("Ne postoji port ili stock!");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return GetPortfolioByName(inPortfolioID).GetPortfolioValue(timeStamp);
             }
             else
             {
                 throw new StockExchangeException("Nema portfelja!");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = GetPortfolioByName(inPortfolioID);
                 return portfolio.GetPercentChangeInValueForMonth(Year, Month);
             }
             else
             {
                 throw new StockExchangeException("Nema portfelja!");
             }
         }
     }
}
