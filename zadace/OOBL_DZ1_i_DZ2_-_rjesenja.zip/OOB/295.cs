﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> _listOfStocks = new List<Stock>();
         private List<Index> _listOfIndices = new List<Index>();
         private List<Portfolio> _listOfPortfolios = new List<Portfolio>();


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             bool stockExists = this.StockExists(inStockName);

             if ((!stockExists) && (inNumberOfShares > 0) && (inInitialPrice > 0))
                 this._listOfStocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
             else throw new StockExchangeException("ERROR");
         }

         public void DelistStock(string inStockName)
         {
             bool stockExists = this.StockExists(inStockName);

             if (stockExists)
             {
                 this._listOfStocks.RemoveAt(this.StockIndex(inStockName));
                 
                 foreach (Index ind in this._listOfIndices)
                 {
                     if (this.IsStockPartOfIndex(ind.IndexName, inStockName)) ind.RemoveStock(inStockName);
                 }

                 foreach (Portfolio portfolio in this._listOfPortfolios)
                 {
                     if (this.IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName)) portfolio.RemoveStock(inStockName);
                 }
             }
             else throw new StockExchangeException("ERROR");
         }

         public bool StockExists(string inStockName)
         {
             for (int i = 0; i < this._listOfStocks.Count; i++)
                 if (this._listOfStocks[i].StockName.ToLower() == inStockName.ToLower()) return true;
             
             return false;
         }

         public int NumberOfStocks()
         {
             return this._listOfStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             bool stockExists = this.StockExists(inStockName);

             if ((stockExists) && (inStockValue > 0))
                 this._listOfStocks[this.StockIndex(inStockName)].AddPrice(inStockValue, inIimeStamp);
             else throw new StockExchangeException("ERROR");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             bool stockExists = this.StockExists(inStockName);

             if (stockExists)
                 return this._listOfStocks[this.StockIndex(inStockName)].Price(inTimeStamp);
             throw new StockExchangeException("ERROR");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {            
             bool stockExists = this.StockExists(inStockName);

             if (stockExists)
                 return  this._listOfStocks[this.StockIndex(inStockName)].InitalPrice;
             throw new StockExchangeException("ERROR");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             bool stockExists = this.StockExists(inStockName);

             if (stockExists) return this._listOfStocks[this.StockIndex(inStockName)].Price();
             throw new StockExchangeException("ERROR");

         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             bool indexExists = this.IndexExists(inIndexName);
             
             if ((!indexExists) && (((int)inIndexType == 1) || ((int)inIndexType == 2))) 
                 this._listOfIndices.Add(new Index(inIndexName, inIndexType));
             else throw new StockExchangeException("ERROR");
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             bool indexExists = this.IndexExists(inIndexName);
             bool stockExists = this.StockExists(inStockName);
             bool indexHasStock = this.IsStockPartOfIndex(inIndexName, inStockName);

             if(indexExists && stockExists && !indexHasStock)
                 this._listOfIndices[this.IndexOfIndex(inIndexName)].AddStock(this._listOfStocks[this.StockIndex(inStockName)]);
             else throw new StockExchangeException("ERROR");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             bool indexExists = this.IndexExists(inIndexName);
             bool indexHasStock = this.IsStockPartOfIndex(inIndexName, inStockName);

             if (indexExists && indexHasStock)
                 this._listOfIndices[this.IndexOfIndex(inIndexName)].RemoveStock(inStockName);
             else throw new StockExchangeException("ERROR");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool indexExists = this.IndexExists(inIndexName);
             bool stockExits = this.StockExists(inStockName);

             if (indexExists && stockExits)
                 return this._listOfIndices[this.IndexOfIndex(inIndexName)].HasStock(inStockName);
             throw new StockExchangeException("ERROR");
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             bool indexExists = this.IndexExists(inIndexName);

             if (indexExists)
                 return this._listOfIndices[this.IndexOfIndex(inIndexName)].CalculateValue(inTimeStamp);
             throw new StockExchangeException("ERROR");
         }

         public bool IndexExists(string inIndexName)
         {
             for (int i = 0; i < this._listOfIndices.Count; i++)
                 if (this._listOfIndices[i].IndexName.ToLower() == inIndexName.ToLower()) return true;

             return false;
         }

         public int NumberOfIndices()
         {
             return this._listOfIndices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             bool indexExists = this.IndexExists(inIndexName);

             if (indexExists)
                 return this._listOfIndices[this.IndexOfIndex(inIndexName)].NumberOfStocks();
             throw new StockExchangeException("ERROR");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);

             if (!portfolioExists)
                 this._listOfPortfolios.Add(new Portfolio(inPortfolioID));
             else throw new StockExchangeException("ERROR");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             bool stockExits = this.StockExists(inStockName);
             bool stockInPortfolio = this.IsStockPartOfPortfolio(inPortfolioID, inStockName);

             if (portfolioExists && stockExits && !(numberOfShares < 0))
             {
                 if (this._listOfStocks[this.StockIndex(inStockName)].RemainingShares - numberOfShares >= 0)
                 {
                     this._listOfStocks[this.StockIndex(inStockName)].ReduceShares(numberOfShares);
                     if(stockInPortfolio) this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].AddStock(inStockName, numberOfShares);
                     else this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].AddStock(this._listOfStocks[this.StockIndex(inStockName)], numberOfShares);
                 }
                 else throw new StackOverflowException("ERROR");
             }
             else throw new StockExchangeException("ERROR");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             bool stockExits = this.StockExists(inStockName);
             bool stockInPortfolio = this.IsStockPartOfPortfolio(inPortfolioID, inStockName);

             if (portfolioExists && stockExits && stockInPortfolio)
                 if (this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].RemoveStock(inStockName, numberOfShares))
                     this._listOfStocks[this.StockIndex(inStockName)].IncreaseShares(numberOfShares);
                 else throw new StockExchangeException("ERROR");
             else throw new StockExchangeException("ERROR");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             bool stockExits = this.StockExists(inStockName);
             bool stockInPortfolio = this.IsStockPartOfPortfolio(inPortfolioID, inStockName);
             
             if (portfolioExists && stockExits && stockInPortfolio)
                  this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].RemoveStock(inStockName);
             throw new StackOverflowException("ERROR");
         }

         public int NumberOfPortfolios()
         {
             return this._listOfPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);

             if (portfolioExists)
                 return this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].NumberOfStocks();
             throw new StockExchangeException("ERROR");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             for (int i = 0; i < this._listOfPortfolios.Count; i++)
                 if (this._listOfPortfolios[i].PortfolioID == inPortfolioID) return true;
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             bool stockExits = this.StockExists(inStockName);

             if (portfolioExists && stockExits)
                 return this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].HasStock(inStockName);
             throw new StackOverflowException("ERROR");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             bool stockExits = this.StockExists(inStockName);
             bool stockInPortfolio = this.IsStockPartOfPortfolio(inPortfolioID, inStockName);

             if (portfolioExists && stockExits && stockInPortfolio)
                 return this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].NumberOfShares(inStockName);
             throw new StackOverflowException("ERROR");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             bool portfoliioExists = this.PortfolioExists(inPortfolioID);

             if (portfoliioExists)
                 return this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].PortfolioValue(timeStamp);
             throw new StockExchangeException("ERROR");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             bool portfolioExists = this.PortfolioExists(inPortfolioID);
             

             DateTime firstDayOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             int lastDay = new DateTime(Year, Month, 1).AddMinutes(1).AddDays(-1).Day;
             DateTime lastDayOfMonth = new DateTime(Year, Month, lastDay, 23, 59, 59, 999);

             decimal ValueOnFirstDay;
             decimal ValueOnLastDay;

             if (portfolioExists && (this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].NumberOfStocks() > 0))
             {
                 ValueOnFirstDay = this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].PortfolioValue(firstDayOfMonth);
                 ValueOnLastDay = this._listOfPortfolios[this.PortfolioIndex(inPortfolioID)].PortfolioValue(lastDayOfMonth);

                 return (ValueOnLastDay - ValueOnFirstDay)/ValueOnFirstDay*100;
             }

             throw new StockExchangeException("ERROR");
         }


         private int StockIndex(string stockName)
         {
             int index =
                 this._listOfStocks.FindIndex(stock => stock.StockName.ToLower().Equals(stockName.ToLower(), StringComparison.Ordinal));

             return index;
         }

         private int IndexOfIndex(string indexName)
         {
             int numIndex =
                 this._listOfIndices.FindIndex(index => index.IndexName.ToLower().Equals(indexName.ToLower(), StringComparison.Ordinal));

             
             return numIndex;
         }

         private int PortfolioIndex(string portfolioId)
         { 
             int index =
                 this._listOfPortfolios.FindIndex(portfolio => portfolio.PortfolioID.Equals(portfolioId, StringComparison.Ordinal));
 
             return index;
         }
     }

    public class Stock
    {
        private string _stockName;
        private long _numOfShares;
        private long _remainingShares;
        private List<StockPrice> _stockPrices = new List<StockPrice>();
        private decimal _weightFacor;

        public Stock(string stockName, long numberOfShares, decimal price, DateTime timeStamp)
        {
            this._stockName = stockName;
            this._numOfShares = numberOfShares;
            this._remainingShares = numberOfShares;
            this._stockPrices.Add(new StockPrice(price, timeStamp));
        }

        public string StockName
        {
            get { return this._stockName; }
        }

        public long NumberOfShares
        {
            get { return this._numOfShares; }
        }

        public long RemainingShares
        {
            get { return this._remainingShares; }
        }
        public decimal WeightFactor
        {
            get { return this._weightFacor; }
            set { this._weightFacor =  value; }
        }

        public void AddPrice(decimal price, DateTime timeStamp)
        {
            this._stockPrices.Add(new StockPrice(price, timeStamp));
            this._stockPrices.Sort((x, y) => DateTime.Compare(x.Time, y.Time));
        }

        public decimal Price()
        {
            return this._stockPrices.Last().Price;
        }

        public decimal Price(DateTime timeStamp)
        {
            decimal result;
            bool lastPrice = true;
            int index = 0;

            for (int i = 0; i < this._stockPrices.Count; i ++)
            {
                if (this._stockPrices[i].Time > timeStamp)
                {
                    lastPrice = false;
                    index = i;
                    break;
                }
            }

            if (lastPrice) result = this._stockPrices.Last().Price;
            else result = this._stockPrices[index - 1].Price;

            return result;
        }

        public decimal InitalPrice
        {
            get { return this._stockPrices[0].Price;  }
        }

        public void ReduceShares(long shares)
        {
            this._remainingShares -= shares;
        }

        public void IncreaseShares(long shares)
        {
            this._remainingShares += shares;
        }
    }

    public class StockPrice
    {
        private decimal _price;
        private DateTime _timeStamp;

        public StockPrice(decimal price, DateTime timeStamp)
        {
            this._price = price;
            this._timeStamp = timeStamp;
        }

        public decimal Price
        {
            get { return this._price; }
        }

        public DateTime Time
        {
            get { return this._timeStamp;  }
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _typeOfIndex;

        private List<Stock> _stocksInIndex = new List<Stock>();

        private IValueCalculator calculator;

        public Index(string indexName, IndexTypes indexType)
        {
            this._indexName = indexName;
            this._typeOfIndex = indexType;
        }

        public string IndexName
        {
            get { return this._indexName;  }
        }

        public IndexTypes IndexType
        {
            get { return this._typeOfIndex;  }
        }

        public int NumberOfStocks()
        {
            return this._stocksInIndex.Count;
        }

        public bool HasStock(string stockName)
        {
            for (int i = 0; i < this._stocksInIndex.Count; i++)
                if (this._stocksInIndex[i].StockName.ToLower() == stockName.ToLower()) return true;

            return false;
        }

        public void AddStock(Stock stock)
        {
            this._stocksInIndex.Add(stock);
        }

        public void RemoveStock(string stockName)
        {
            for (int i = 0; i < this._stocksInIndex.Count; i++)
            {
                if (this._stocksInIndex[i].StockName.ToLower() == stockName.ToLower())
                    this._stocksInIndex.RemoveAt(i);
            }
        }

        public decimal CalculateValue(DateTime timeStamp)
        {
            if (this._stocksInIndex.Count > 0)
            {
                switch ((int) _typeOfIndex)
                {
                    case 1:
                        calculator = new AverageCalculator(this._stocksInIndex);
                        break;
                    case 2:
                        calculator = new WeightedCalculator(this._stocksInIndex);
                        break;
                        ;
                }

                return calculator.CalculateValue(timeStamp);
            }

            return 0;
        }
    }

    public interface IValueCalculator
    {
        decimal CalculateValue(DateTime timeStamp);
    }

    public class AverageCalculator : IValueCalculator
    {
        private List<Stock> _stocks; 

        public AverageCalculator(List<Stock> stocks)
        {
            this._stocks = stocks;
        }

        public decimal CalculateValue(DateTime timeStamp)
        {
            decimal result = 0;
            long totalShares = 0;

            for (int i = 0; i < this._stocks.Count; i++)
            {
                result += this._stocks[i].Price(timeStamp)*this._stocks[i].NumberOfShares;
                totalShares += this._stocks[i].NumberOfShares;
            }

            return Math.Round(result/this._stocks.Count, 3);
        }
    }

    public class WeightedCalculator : IValueCalculator
    {
        private List<Stock> _stocks = new List<Stock>();
        private decimal _totalValue = 0;
 
        public WeightedCalculator(List<Stock> stocks)
        {
            this._stocks = stocks;
        }

        public decimal CalculateValue(DateTime timeStamp)
        {
            decimal result = 0;

            for (int i = 0; i < this._stocks.Count; i++)
            {
                this._totalValue += this._stocks[i].Price(timeStamp)*this._stocks[i].NumberOfShares;
            }

            for (int i = 0; i < this._stocks.Count; i++)
            {
                this._stocks[i].WeightFactor = this._stocks[i].Price(timeStamp)/this._totalValue;
            }

            for (int i = 0; i < this._stocks.Count; i++)
            {
                result += this._stocks[i].NumberOfShares * this._stocks[i].Price(timeStamp) * this._stocks[i].WeightFactor;
            }

            return Math.Round(result, 3);
        }
    }

    public class Portfolio
    {
        private string _portfolioId;

        private Dictionary<Stock, long> _stocksInPortfolio = new Dictionary<Stock, long>(); 

        public Portfolio(string portfolioId)
        {
            this._portfolioId = portfolioId;
        }

        public string PortfolioID
        {
            get { return this._portfolioId;  }   
        }

        public bool HasStock(string stockName)
        {
            foreach (Stock stock in this._stocksInPortfolio.Keys)
            {
                if (stock.StockName.ToLower() == stockName.ToLower()) return true;
            }

            return false;
        }

        public int NumberOfShares(string stockName)
        {
            int result = 0;

            foreach (var stock in this._stocksInPortfolio)
            {
                if (stock.Key.StockName.ToLower() == stockName.ToLower()) return Convert.ToInt32(stock.Value);
            }

            return result;
        }

        public decimal PortfolioValue(DateTime timeStamp)
        {
            decimal result = 0;

            foreach (var stock in this._stocksInPortfolio)
            {
                result += stock.Key.Price(timeStamp)*stock.Value;
            }

            return result;
        }

        public void AddStock(Stock stock, int numberOfStocks)
        {
            this._stocksInPortfolio.Add(stock, numberOfStocks);   
        }

        public void AddStock(string stockName, int numberOfStocks)
        {
            foreach (Stock stock in this._stocksInPortfolio.Keys)
            {
                if (stock.StockName.ToLower() == stockName.ToLower()) this._stocksInPortfolio[stock] += numberOfStocks;
                break;
            }
            
        }

        public void RemoveStock(string stockName)
        {
            foreach (Stock stock in this._stocksInPortfolio.Keys)
            {
                if (stock.StockName.ToLower() == stockName.ToLower()) this._stocksInPortfolio.Remove(stock);
                break;
            }
        }

        public bool RemoveStock(string stockName, int numberOfShares)
        {
            foreach (var stock in this._stocksInPortfolio)
            {
               if (stock.Key.StockName.ToLower() == stockName.ToLower())
               {
                   if (Convert.ToInt32(stock.Value) - numberOfShares > 0)
                   {
                       this._stocksInPortfolio[stock.Key] = stock.Value - numberOfShares;
                       return true;
                   }
                   if (Convert.ToInt32(stock.Value) - numberOfShares == 0)
                   {
                       this._stocksInPortfolio.Remove(stock.Key);
                       return true;
                   }
                   return false;
               }
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return this._stocksInPortfolio.Count;
        }
    }
}
