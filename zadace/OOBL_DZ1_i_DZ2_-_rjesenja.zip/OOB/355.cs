﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class PortfolioStock
    {
        private int _numberOfShares;
        private Stock _stock;
        public PortfolioStock (Stock stock, int inNumberOfShares)
        {
            _stock = stock;
            _numberOfShares = inNumberOfShares;
        }

        public int NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }

        public Stock Stock
        {
            get { return _stock; }
        }
    }

    public class Stock
    {
        private string _name;
        private decimal _initialPrice;
        private decimal _price;
        private long _totalShares;
        private DateTime _initialDate;
        private DateTime _lastPriceUpdate;
        public Stock(String inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this._name = inStockName.ToUpper();
            this._totalShares = inNumberOfShares;
            this._initialPrice = inInitialPrice;
            this._price = inInitialPrice;
            this._initialDate = inTimeStamp;
            this._lastPriceUpdate = inTimeStamp;

        }
        
        public DateTime LastPriceUpdate
        {
            get { return _lastPriceUpdate; }
            set { _lastPriceUpdate = value; }
        }

        public long TotalShares
        {
            get { return _totalShares; }
            set { _totalShares = value; }
        }

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public string Name
        {
            get { return _name; }
        }

        public decimal InitialPrice
        {
            get { return _initialPrice; }
        }

        public DateTime InitialDate
        {
            get { return _initialDate; }
        }
    }

    public class Index
    {
        private string _name;
        private IndexTypes _indexType;
        public List<Stock> Stocks=new List<Stock>();
        private decimal _indexValue;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            _name = inIndexName.ToUpper();
            _indexType = inIndexType;
            CalculateIndexValue();
        }

        public string Name
        {
            get { return _name; }
        }

        private void CalculateIndexValue()
        {
            if (Stocks.Count == 0) _indexValue = 0;
            //račun, ovisno o vrsti indeksa
        }

        public IndexTypes IndexType
        {
            get { return _indexType; }
        }

        public decimal IndexValue
        {
            get { return _indexValue; }
        }
    }

    public class Portfolio
    {
        private string _ID;
        public List<PortfolioStock> Stocks=new List<PortfolioStock>();
        public Portfolio(string inPortfolioID)
        {
            _ID = inPortfolioID;
        }

        public string Id
        {
            get { return _ID; }
        }
    }
     public class StockExchange : IStockExchange
     {
         public List<Stock> Stocks=new List<Stock>();
         public List<Index> Indices=new List<Index>();
         public List<Portfolio> Portfolios=new List<Portfolio>();
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stockNew = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             if (stockNew.Price<=0)
             throw new StockExchangeException("The initial price must be greater than 0.");
             else if (stockNew.TotalShares <= 0) throw new StockExchangeException("The stock must have more than 0 shares.");
             else if (StockExists(stockNew.Name)==true) throw new StockExchangeException("This stock already exists!");
             else Stocks.Add(stockNew);
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                foreach (Stock stock in Stocks)
                {
                 if (stock.Name.Equals(inStockName.ToUpper())) Stocks.Remove(stock);
                }
             }
             else throw new StockExchangeException("The stock doesn't exist.");
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock stock in Stocks)
             {
                 if (stock.Name.Equals(inStockName.ToUpper())) return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return Stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock stock in Stocks)
                {
                    if (stock.Name.Equals(inStockName.ToUpper()))
                    {
                        stock.Price = inStockValue;
                        stock.LastPriceUpdate = inIimeStamp;
                    }
                }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock stock in Stocks)
                 {
                     if (stock.Name.Equals(inStockName.ToUpper())) return stock.Price;
                 }
             }
             else throw new StockExchangeException("The requested stock does not exist.");
             return 0;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock stock in Stocks)
             {
                 if (stock.Name.Equals(inStockName.ToUpper())) return stock.InitialPrice;
             }
             throw new StockExchangeException("The requested stock does not exist.");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Stock stock in Stocks)
             {
                 if (stock.Name.Equals(inStockName.ToUpper())) return stock.Price;
             }
             throw new StockExchangeException("The requested stock does not exist.");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index indexNew=new Index(inIndexName, inIndexType);
             //if ((inIndexType!=IndexTypes.WEIGHTED)||(inIndexType!=IndexTypes.AVERAGE)) throw new StockExchangeException("The only index types available are weighted and average.");
             if (IndexExists(indexNew.Name)) throw new StockExchangeException("This index already exists!");
             else Indices.Add(indexNew);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in Indices)
             {
                 if (index.Name.Equals(inIndexName.ToUpper()))
                 {
                     if (IsStockPartOfIndex(index.Name, inStockName)==true) throw new StockExchangeException("The stock is already a part of the index.");
                     foreach (Stock indexStock in Stocks)
                         {
                             if (indexStock.Name.Equals(inStockName.ToUpper())) index.Stocks.Add(indexStock);
                         //promijeni indexValue
                         } 
                 }
             }
             
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 foreach (Index index in Indices)
                 {
                     if (index.Name.Equals(inIndexName.ToUpper()))
                     {
                         foreach (Stock indexStock in index.Stocks)
                         {
                             if (indexStock.Name.Equals(inStockName.ToUpper())) index.Stocks.Remove(indexStock);
                             //promijeni indexValue
                         }
                     }
                 }
             }
             else throw new StockExchangeException("The stock isn't in the given index.");
 
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in Indices)
             {
                 if (index.Name.Equals(inIndexName.ToUpper()))
                 {
                     foreach (Stock indexStock in index.Stocks)
                     {
                         if (indexStock.Name.Equals(inStockName.ToUpper())) return true;
                     }
                 }
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             throw new NotImplementedException();
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index index in Indices)
             {
                 if (index.Name.Equals(inIndexName.ToUpper())) return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return Indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index index in Indices)
             {
                 if (index.Name.Equals(inIndexName.ToUpper())) return index.Stocks.Count;
             }
             return 0;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID) == false)
             {
                 Portfolio portfolioNew=new Portfolio(inPortfolioID);
                 Portfolios.Add(portfolioNew);
             }
             else throw new StockExchangeException("The portfolio already exists.");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Stock stock in Stocks)
                 {
                     if (stock.Name.Equals(inStockName.ToUpper()))
                     {
                         PortfolioStock portfolioStockNew = new PortfolioStock(stock, numberOfShares);
                         foreach (Portfolio portfolio in Portfolios)
                         {
                             if (portfolio.Id.Equals(inPortfolioID))
                             {
                                 if (IsStockPartOfPortfolio(portfolio.Id, stock.Name))
                                 {
                                     foreach (PortfolioStock portfolioStock in portfolio.Stocks)
                                     {
                                         if (portfolioStock.Stock.Name.Equals(stock.Name))
                                             portfolioStock.NumberOfShares += numberOfShares;
                                     }
                                 }
                                 else portfolio.Stocks.Add(portfolioStockNew);
                             }
                         }
                     }
                 }
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio portfolio in Portfolios)
                 {
                     if (portfolio.Id.Equals(inPortfolioID))
                     {
                         foreach (PortfolioStock portfolioStock in portfolio.Stocks)
                         {
                             if (portfolioStock.Stock.Name.Equals(inStockName))
                             {
                                 portfolioStock.NumberOfShares -= numberOfShares;
                                 if (portfolioStock.NumberOfShares<=0) RemoveStockFromPortfolio(inPortfolioID, inStockName);
                             }
                         }
                     }
                 }
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio portfolio in Portfolios)
                 {
                     if (portfolio.Id.Equals(inPortfolioID))
                     {
                         foreach (PortfolioStock portfolioStock in portfolio.Stocks)
                         {
                             if (portfolioStock.Stock.Name.Equals(inStockName))
                             {
                                 portfolio.Stocks.Remove(portfolioStock);
                             }
                         }
                     }
                 }
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public int NumberOfPortfolios()
         {
             return Portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio portfolio in Portfolios)
                 {
                     if (portfolio.Id.Equals(inPortfolioID)) return portfolio.Stocks.Count;
                 }
                 return -1;
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.Id.Equals(inPortfolioID)) return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio portfolio in Portfolios)
                 {
                     if (portfolio.Id.Equals(inPortfolioID))
                     {
                         foreach (Stock stock in Stocks)
                         {
                             if (stock.Name.Equals(inStockName.ToUpper()))
                             {
                                 foreach (PortfolioStock portfoliostock in portfolio.Stocks)
                                 {
                                     if (portfoliostock.Stock.Name.Equals(stock.Name)) return true;
                                 }
                             }
                         }
                     }
                 }
                 return false;
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio portfolio in Portfolios)
                 {
                     if (portfolio.Id.Equals(inPortfolioID))
                     {
                         int shareSum=0;
                         foreach (PortfolioStock portfolioStock in portfolio.Stocks)
                         {
                             if (portfolioStock.Stock.Name.Equals(inStockName)) shareSum += portfolioStock.NumberOfShares;
                         }
                         return shareSum;
                     }
                 }
                 return -1;
             }
             else throw new StockExchangeException("The portfolio does not exist.");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
     }
}
