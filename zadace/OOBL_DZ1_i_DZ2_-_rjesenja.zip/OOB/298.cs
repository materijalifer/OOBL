﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {

        //List<Stock> stocks = new List<Stock>();
        Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        //List<Index> indexes = new List<Index>();
        Dictionary<string, Index> indexes = new Dictionary<string, Index>();
        Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string name = inStockName.ToLower();
            if (inInitialPrice <= 0 || inNumberOfShares <= 0) throw new StockExchangeException("Stock value and price must be positive!");
            if (StockExists(name)) throw new StockExchangeException("Stock exists!");
            stocks.Add(name, new Stock(name, inNumberOfShares, inInitialPrice, inTimeStamp));
            //throw new NotImplementedException();
        }

        public void DelistStock(string inStockName)
        {
            string name = inStockName.ToLower();
            /*foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    stocks.Remove(s);
                }
            }*/
            foreach (Index ind in indexes.Values)
            {
                ind.RemoveStock(stocks[name]);
            }
            foreach (Portfolio port in portfolios.Values)
            {
                port.removeStock(stocks[name]);
            }
            if (StockExists(name) && stocks[name].numOfShares != 0) stocks.Remove(name);
            else throw new StockExchangeException("Stock doesn't exist");
            //throw new NotImplementedException();
        }

        public bool StockExists(string inStockName)
        {
            string name = inStockName.ToLower();
            /*foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    return true;
                }
            }*/
            return stocks.ContainsKey(name);
            //return false;
            //throw new NotImplementedException();
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
            //throw new NotImplementedException();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            string name = inStockName.ToLower();
            if (stocks.ContainsKey(name))
            {
                stocks[name].AddPrice(inTimeStamp, inStockValue);
            }
            /*foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    s.AddPrice(inTimeStamp, inStockValue);
                }
            }*/
            //throw new NotImplementedException();
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            string name = inStockName.ToLower();
            if (stocks.ContainsKey(name))
            {
                return stocks[name].GetPrice(inTimeStamp);
            }
            /*
            foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    return s.
                }
            }*/
            else throw new StockExchangeException("stock not found");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            string name = inStockName.ToLower();
            if (stocks.ContainsKey(name))
            {
                return stocks[name].getInitialPrice();
            }
            /*
            foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    return s.initialPrice;
                }
            }*/
            else throw new StockExchangeException("stock not found");
            //throw new NotImplementedException();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            string name = inStockName.ToLower();
            if (stocks.ContainsKey(name))
            {
                return stocks[name].getLastPrice();
            }
            /*
            foreach (Stock s in stocks)
            {
                if (s.name.Equals(name))
                {
                    return s.currentPrice;
                }
            }*/
            else throw new StockExchangeException("stock not found");
            //throw new NotImplementedException();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            string name = inIndexName.ToLower();
            if (IndexExists(name)) throw new StockExchangeException("Index exists!");
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED) throw new StockExchangeException("Wrong Index type!");
            indexes.Add(name, new Index(name, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();

            if (IndexExists(indexName) && StockExists(stockName))
            {
                indexes[indexName].AddStock(stocks[stockName]);
            }
            else throw new StockExchangeException("Index or Stock doesn't exist!");

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();

            if (IndexExists(indexName) && StockExists(stockName))
            {
                indexes[indexName].RemoveStock(stocks[stockName]);
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();
            if (IndexExists(indexName) && StockExists(stockName))
            {
                if (indexes[indexName].myStocks.ContainsKey(stockName)) return true;
            }
            return false;
            //throw new NotImplementedException();
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            string indexName = inIndexName.ToLower();
            if (IndexExists(indexName))
            {
                return indexes[indexName].Calculate(inTimeStamp);
            }
            else throw new StockExchangeException("Index doesn't exist!");
        }

        public bool IndexExists(string inIndexName)
        {
            string indexName = inIndexName.ToLower();
            if (indexes.ContainsKey(indexName)) return true;
            else return false;
        }

        public int NumberOfIndices()
        {
            return indexes.Count;
            //throw new NotImplementedException();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            string indexName = inIndexName.ToLower();
            return indexes[indexName].myStocks.Count;
            //throw new NotImplementedException();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio exists!");
            portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string stockName = inStockName.ToLower();
            if (portfolios.ContainsKey(inPortfolioID) && stocks.ContainsKey(stockName))
            {
                portfolios[inPortfolioID].addStock(stocks[stockName], numberOfShares);
            }
            else throw new StockExchangeException("Portfolio ili Stock doesn't exist");
            long shareCount = 0;
            foreach (Portfolio p in portfolios.Values)
            {
                if (p.shares.ContainsKey(stockName))
                {
                    shareCount += p.shares[stockName].Value;
                }
            }
            if (shareCount > stocks[stockName].numOfShares) throw new StockExchangeException("Too many shares");
            //throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string stockName = inStockName.ToLower();
            if (portfolios.ContainsKey(inPortfolioID) && stocks.ContainsKey(stockName))
            {
                portfolios[inPortfolioID].deductStock(stocks[stockName], numberOfShares);
            }
            else throw new StockExchangeException("Portfolio or Stock doesn't exist");
            //throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            string stockName = inStockName.ToLower();
            if (portfolios.ContainsKey(inPortfolioID) && stocks.ContainsKey(stockName))
            {
                portfolios[inPortfolioID].removeStock(stocks[stockName]);
            }
            else throw new StockExchangeException("Portfolio ili Stock doesn't exist");
            //throw new NotImplementedException();
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
            //throw new NotImplementedException();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return portfolios[inPortfolioID].shares.Count;
            //throw new NotImplementedException();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolios.ContainsKey(inPortfolioID);
            //throw new NotImplementedException();
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            string stockName = inStockName.ToLower();
            return portfolios[inPortfolioID].shares.ContainsKey(stockName);
            //throw new NotImplementedException();
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            string stockName = inStockName.ToLower();
            if (portfolios[inPortfolioID].shares.ContainsKey(stockName)) return (int)portfolios[inPortfolioID].shares[stockName].Value;
            return 0;
            //throw new NotImplementedException();
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return portfolios[inPortfolioID].Value(timeStamp);
            //throw new NotImplementedException();
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal startValue = portfolios[inPortfolioID].Value(new DateTime(Year, Month, 1, 0, 0, 0));
            decimal endValue = portfolios[inPortfolioID].Value(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            if (startValue == 0) return 0;
            return (Math.Abs(endValue - startValue) / startValue) * 100;
            //throw new NotImplementedException();
        }
    }

    public class Stock
    {
        public string name;
        public long numOfShares;
        //public decimal initialPrice;
        public DateTime timestamp;
        public decimal currentPrice;

        private Dictionary<DateTime, decimal> prices = new Dictionary<DateTime,decimal>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            name = inStockName;
            numOfShares = inNumberOfShares;
            //initialPrice = inInitialPrice;
            timestamp = inTimeStamp;
            currentPrice = inInitialPrice;
            prices.Add(inTimeStamp, inInitialPrice);
        }

        public void AddPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (prices.ContainsKey(inTimeStamp)) throw new StockExchangeException("More than 1 price for same time");
            prices.Add(inTimeStamp, inStockValue);
            bool flag = true;
            foreach (DateTime dt in prices.Keys)
            {
                if (dt > inTimeStamp) flag = false;
            }
            if (flag) currentPrice = inStockValue;
        }

        internal decimal GetPrice(DateTime inTimeStamp)
        {
            decimal myPrice = -1;
            bool flag = true;
            DateTime previous = new DateTime();
            foreach (DateTime dt in prices.Keys)
            {
                if (flag && dt <= inTimeStamp)
                {
                    flag = false;
                    previous = dt;
                    myPrice = prices[dt];
                }
                else if (dt <= inTimeStamp && dt > previous)
                {
                    previous = dt;
                    myPrice = prices[dt];
                }
            }
            if (myPrice == -1) throw new StockExchangeException("too early");
            return myPrice;
            //throw new NotImplementedException();
        }

        internal decimal getInitialPrice()
        {
            decimal myPrice = -1;
            bool flag = true;
            DateTime previous = new DateTime();
            foreach (DateTime dt in prices.Keys)
            {
                if (flag)
                {
                    flag = false;
                    previous = dt;
                    myPrice = prices[dt];
                }
                else if (dt < previous)
                {
                    previous = dt;
                    myPrice = prices[dt];
                }
            }
            if (myPrice == -1) throw new StockExchangeException("no price");
            return myPrice;
        }

        internal decimal getLastPrice()
        {
            decimal myPrice = -1;
            bool flag = true;
            DateTime previous = new DateTime();
            foreach (DateTime dt in prices.Keys)
            {
                if (flag)
                {
                    flag = false;
                    previous = dt;
                    myPrice = prices[dt];
                }
                else if (dt > previous)
                {
                    previous = dt;
                    myPrice = prices[dt];
                }
            }
            if (myPrice == -1) throw new StockExchangeException("no price");
            return myPrice;
        }
    }


    public class Index
    {
        public string name;
        public IndexTypes type;
        //public List<Stock> myStocks = new List<Stock>();
        public Dictionary<string, Stock> myStocks = new Dictionary<string, Stock>();
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            // TODO: Complete member initialization
            name = inIndexName;
            type = inIndexType;
        }


        internal void AddStock(Stock stock)
        {
            myStocks.Add(stock.name, stock);
            //throw new NotImplementedException();
        }

        internal void RemoveStock(Stock stock)
        {
            myStocks.Remove(stock.name);
        }



        internal decimal Calculate(DateTime inTimeStamp)
        {
            if (this.type == IndexTypes.AVERAGE)
            {
                decimal values = 0;
                foreach (Stock s in myStocks.Values)
                {
                    values += s.GetPrice(inTimeStamp);
                }
                if (myStocks.Values.Count == 0) return 0;
                return values / myStocks.Values.Count;
            }
            else if (this.type == IndexTypes.WEIGHTED)
            {
                decimal values = 0;
                decimal sum_factors = 0;
                decimal sum_values = 0;
                foreach (Stock s in myStocks.Values)
                {
                    sum_values += s.GetPrice(inTimeStamp) * s.numOfShares;
                }
                if (sum_values == 0) return 0;
                foreach (Stock s in myStocks.Values)
                {
                    decimal factor = s.numOfShares * s.GetPrice(inTimeStamp) / sum_values;
                    sum_factors += factor;
                    values += factor * s.GetPrice(inTimeStamp);
                }
                if (sum_factors == 0) return 0;
                return values / sum_factors;
            }
            else throw new StockExchangeException("Index not found");
        }
    }

    public class Portfolio
    {
        public string portfolioID;
        public Dictionary<string, KeyValuePair<Stock, long>> shares = new Dictionary<string, KeyValuePair<Stock, long>>();

        public Portfolio(string inPortfolioID)
        {
            // TODO: Complete member initialization
            portfolioID = inPortfolioID;
        }



        internal void addStock(Stock stock, int numberOfShares)
        {
            if (numberOfShares <= 0) throw new StockExchangeException("Wrong number of shares");
            if (shares.ContainsKey(stock.name))
            {
                KeyValuePair<Stock, long> updated = new KeyValuePair<Stock, long>(shares[stock.name].Key, shares[stock.name].Value + numberOfShares);
                shares.Remove(stock.name);
                shares.Add(stock.name, updated);
            }
            else
            {
                shares.Add(stock.name, new KeyValuePair<Stock, long>(stock, numberOfShares));
            }
            //throw new NotImplementedException();
        }

        internal void deductStock(Stock stock, int numberOfShares)
        {
            if (shares.ContainsKey(stock.name))
            {
                KeyValuePair<Stock, long> updated = new KeyValuePair<Stock, long>(shares[stock.name].Key, shares[stock.name].Value - numberOfShares);
                shares.Remove(stock.name);
                if (updated.Value > 0) shares.Add(stock.name, updated);
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't own that specific share");
            }
            //throw new NotImplementedException();
        }

        internal void removeStock(Stock stock)
        {
            if (shares.ContainsKey(stock.name))
            {
                shares.Remove(stock.name);
            }
            //throw new NotImplementedException();
        }

        internal decimal Value(DateTime timeStamp)
        {
            decimal value = 0;
            foreach (string key in shares.Keys)
            {
                value += shares[key].Key.GetPrice(timeStamp) * shares[key].Value;
            }
            return value;
        }
    }
}
