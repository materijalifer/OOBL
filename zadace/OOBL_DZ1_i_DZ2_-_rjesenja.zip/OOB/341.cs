﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> stocks;

         private Dictionary<string, Index> indexes;

         private Dictionary<string, Portfolio> portfolios;

         public StockExchange()
         {
             stocks = new Dictionary<string, Stock>();
             indexes = new Dictionary<string, Index>();
             portfolios = new Dictionary<string, Portfolio>();
         }
         #region Stock
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = Formater(inStockName);
             Stock toAdd = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             if (StockExists(inStockName))
                 throw new StockExchangeException("Dionica već postoji!");
             else stocks.Add(Formater(inStockName), toAdd);
         } 

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 if (stocks[Formater(inStockName)].Index != null)
                 {
                     stocks[Formater(inStockName)].Index.RemoveStock(Formater(inStockName));
                 }
                 stocks.Remove(Formater(inStockName));
             }
             else throw new StockExchangeException("Ne postoji dionica s tim imenom!");
         } 

         public bool StockExists(string inStockName)
         {
             return stocks.ContainsKey(Formater(inStockName));
         } 

         public int NumberOfStocks()
         {
             return stocks.Count();
         } 

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName)) stocks[Formater(inStockName)].SetPrice(inIimeStamp, inStockValue);
             else throw new StockExchangeException("Dionica ne postoji!");
         } 

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName)) return stocks[Formater(inStockName)].GetPrice(inTimeStamp);
             else throw new StockExchangeException("Dionica s tim imenom ne postoji!");
         } 

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName)) return stocks[Formater(inStockName)].InitialPrice();
             else throw new StockExchangeException("Dionica s tim imenom ne postoji!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName)) return stocks[Formater(inStockName)].LastPrice();
             else throw new StockExchangeException("Dionica s tim imenom ne postoji!");
         }

#endregion
         #region Index
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName)) throw new StockExchangeException("Index postoji!");
             else indexes.Add(Formater(inIndexName), new Index(inIndexType));
         } 

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if ((IndexExists(inIndexName)) && (StockExists(inStockName)))
                 indexes[Formater(inIndexName)].AddStock(stocks[Formater(inStockName)]);
             else throw new StockExchangeException("nema dionice s tim imenom");
         } 

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if ((IndexExists(inIndexName)) && (StockExists(inStockName)))
                 indexes[Formater(inIndexName)].RemoveStock(Formater(inStockName));
             else throw new StockExchangeException("nema dionice s tim imenom");
         } 

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if ((IndexExists(inIndexName)) && (StockExists(inStockName)))
                 return indexes[Formater(inIndexName)].HasStock(Formater(inStockName));
             else throw new StockExchangeException("nema dionice s tim imenom");
         } 

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName)) return indexes[Formater(inIndexName)].IndexValue(inTimeStamp);
             else throw new StockExchangeException("Nema indexa s tim imenom");
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             return indexes.ContainsKey(inIndexName);
         } 

         public int NumberOfIndices() 
         {
             return indexes.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName)) return indexes[Formater(inIndexName)].StockCount();
             else throw new StockExchangeException("ne postoji index tog imena");
         } 

#endregion Index
         #region Portfolio
         public void CreatePortfolio(string inPortfolioID)
         {
             if (!portfolios.ContainsKey(inPortfolioID))
                 portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             else throw new StockExchangeException("postoji portfolio s tim ID-om");
         } //napravljeno

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if(portfolios.ContainsKey(inPortfolioID))
                 if (StockExists(inStockName))
                     portfolios[inPortfolioID].AddStock(stocks[Formater(inStockName)], numberOfShares);
                 else throw new StockExchangeException("nema te dionice na burzi");
             else throw new StockExchangeException("nema tog portfolia");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 if (StockExists(inStockName))
                     portfolios[inPortfolioID].RemoveShares(Formater(inStockName), numberOfShares);
                 else throw new StockExchangeException("nema te dionice na burzi");
             else throw new StockExchangeException("nema tog portfolia");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 if (StockExists(inStockName))
                     portfolios[inPortfolioID].RemoveStock(Formater(inStockName));
                 else throw new StockExchangeException("nema te dionice na burzi");
             else throw new StockExchangeException("nema tog portfolia");
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (portfolios.ContainsKey(inPortfolioID)) return portfolios[inPortfolioID].NumberOfStocks();
             else throw new StockExchangeException("nema portfolija sa tim ID-om");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 if (StockExists(inStockName))
                     return portfolios[inPortfolioID].HasStock(Formater(inStockName));
                 else throw new StockExchangeException("nema te dionice na burzi");
             else throw new StockExchangeException("nema tog portfolia");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 if (StockExists(inStockName))
                     return portfolios[inPortfolioID].StockSharesNumber(Formater(inStockName));
                 else throw new StockExchangeException("nema te dionice na burzi");
             else throw new StockExchangeException("nema tog portfolia");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 return portfolios[inPortfolioID].Value(timeStamp);
             else throw new StockExchangeException("nema tog portfolia");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (portfolios.ContainsKey(inPortfolioID))
                 return portfolios[inPortfolioID].PercentChangeValue(Year, Month);
             else throw new StockExchangeException("nema tog portfolia");
         }
#endregion

         private static string Formater(string input)
         {
             return input.ToUpper();
         }
     }

     public class Stock
     {
         private string _name;
         private long _count;
         private long _availableCount;

         private Index _index;

         public Index Index
         {
             get { return _index; }
             set { _index = value; }
         }

         private List<DateTimePrice> prices;
         private List<DateTime> addedDates;

         public string Name
         {
             get { return _name; }
             set { _name = value; }
         }
         public long Count
         {
             get { return _count; }
             set { _count = value; }
         }

         public Stock(string name, long count, decimal initialPrice, DateTime date)
         {
             _name = name.ToUpper();
             if (count > 0)
             {
                 _count = count;
                 _availableCount = count;
             }
             else throw new StockExchangeException("Broj dionica manji ili jednak nuli!");
             if (initialPrice <= 0) throw new StockExchangeException("Zadana cijena manja ili jednaka nuli");
             _index = null;
             prices = new List<DateTimePrice>();
             addedDates = new List<DateTime>();
             SetPrice(date, initialPrice);
         }

         public void SetPrice(DateTime timeStamp, decimal stockValue)
         {
             if (!addedDates.Contains(timeStamp))
             {
                 addedDates.Add(timeStamp);
                 prices.Add(new DateTimePrice(timeStamp, stockValue));
             }
             else throw new StockExchangeException("za taj datum već definirana cijena");
         } 
         public decimal GetPrice(DateTime date)
         {
             prices.Sort();
             DateTimePrice last = null;
             if (date < prices[0].Date) throw new StockExchangeException("ne postoji zapis");
             else last = prices[0];
             for (int i = 1; i < prices.Count; i++)
             {
                 if (date >= prices[i].Date)
                 {
                     last = prices[i];
                 }
                 else break;
                 
             }
             return last.Value;
         }
         public decimal LastPrice()
         {
             prices.Sort();
             return prices.Last().Value;
         }
         public decimal InitialPrice()
         {
             prices.Sort();
             return prices.First().Value;
         }
         public long TakeShares(long value)
         {
             if ((_availableCount- value) >= 0)
             {
                 _availableCount -= value;
                 return value;
             }
             else throw new StockExchangeException("pokušaj dodavanja više dionica nego je raspoloživo");
         }
         public void RecieveShares(long value)
         {
             _availableCount += value;
         }
     }

     public class Index
     {
         private Dictionary<string, Stock> stocks;
         private Strategy valueCalculator;

         public Index(IndexTypes indexType)
         {
             if (indexType.Equals(IndexTypes.AVERAGE))
             {
                 valueCalculator = new Average();
             }
             else if (indexType.Equals(IndexTypes.WEIGHTED))
             {
                 valueCalculator = new Weighted();
             }
             else throw new StockExchangeException("Krivi tip izračuna indexa");

             stocks = new Dictionary<string, Stock>();
         }

         public decimal IndexValue(DateTime timeStamp)
         {
             if (stocks.Count > 0)
                 return valueCalculator.Calculate(ref stocks, timeStamp);
             else throw new StockExchangeException("prazan index");
         }
         public void AddStock(Stock stock)
         {
             if (!HasStock(stock.Name))
             {
                 if (stock.Index == null)
                 {
                     stocks.Add(stock.Name, stock);
                     stock.Index = this;
                 }
                 else throw new StockExchangeException("Dionica pripada nekom indexu");
             }
             else throw new StockExchangeException("već dodana dionica");
         }
         public void RemoveStock(string stockName)
         {
             if (stocks.ContainsKey(stockName))
             {
                 stocks[stockName].Index = null;
                 stocks.Remove(stockName);
             }
             else throw new StockExchangeException("nema tražene dionice u indexu");
         }
         public bool HasStock(string stockName)
         {
             return stocks.ContainsKey(stockName);
         }
         public int StockCount()
         {
             return stocks.Count();
         }
     }

     public class DateTimePrice : IComparable<DateTimePrice>
     {
         private DateTime _date;

         public DateTime Date
         {
             get { return _date; }
             set { _date = value; }
         }
         private decimal _value;

         public decimal Value
         {
             get { return _value; }
             set { _value = value; }
         }

         public DateTimePrice(DateTime date, decimal value)
         {
             _date = date;
             _value = value;
         }

         public int CompareTo(DateTimePrice other)
         {
             return Date.CompareTo(other.Date);
         }
     }

     public abstract class Strategy
     {
         public abstract decimal Calculate(ref Dictionary<string, Stock> stocks, DateTime timeStamp);
     }

     public class Average : Strategy
     {
         public override decimal Calculate(ref Dictionary<string, Stock> stocks, DateTime timeStamp)
         {
             long numOfStocks = 0;
             decimal sum = 0;

             foreach (KeyValuePair<string, Stock> pair in stocks)
             {
                 numOfStocks++;
                 sum += pair.Value.GetPrice(timeStamp);
             }

             return Math.Round(sum/numOfStocks, 3);
         }
     }

     public class Weighted : Strategy
     {
         public override decimal Calculate(ref Dictionary<string, Stock> stocks, DateTime timeStamp)
         {
             decimal sum = 0;
             decimal weightedSum = 0;

             foreach (KeyValuePair<string, Stock> pair in stocks)
             {
                 sum += pair.Value.Count * pair.Value.GetPrice(timeStamp);
             }
             foreach (KeyValuePair<string, Stock> pair in stocks)
             {
                 weightedSum += ((pair.Value.GetPrice(timeStamp) / sum)) * pair.Value.Count * pair.Value.GetPrice(timeStamp);
             }
             return Math.Round(weightedSum, 3);
         }
     }

     public class Portfolio
     {
         private string _id;
         private Dictionary<string, Stock> stocks;
         private Dictionary<string, long> numberOfShares;

         public string ID
         {
             get { return _id; }
             set { _id = value; }
         }

         public Portfolio(string portfolioID)
         {
             stocks = new Dictionary<string,Stock>();
             numberOfShares = new Dictionary<string,long>();
             _id = portfolioID;
         }

         public void AddStock(Stock stock, long num_of_shares)
         {
             if (HasStock(stock.Name))
             {
                 numberOfShares[stock.Name] += stock.TakeShares(num_of_shares);
             }
             else
             {
                 stocks.Add(stock.Name, stock);
                 numberOfShares.Add(stock.Name, stock.TakeShares(num_of_shares));
             }
         }
         public void RemoveShares(string stockName, int numOfShares)
         {
             if (HasStock(stockName))
             {
                 stocks[stockName].RecieveShares(numOfShares);
                 numberOfShares[stockName] -= numOfShares;
                 if (numberOfShares[stockName] == 0)
                 {
                     numberOfShares.Remove(stockName);
                     stocks.Remove(stockName);
                 }
                 else if (numberOfShares[stockName] < 0) throw new StockExchangeException("previše udjela za povratak");
             }
             else throw new StockExchangeException("portfolio nema tu dionicu");

         }
         public void RemoveStock(string stockName)
         {
             if (HasStock(stockName))
             {
                 stocks[stockName].RecieveShares(numberOfShares[stockName]);
                 stocks.Remove(stockName);
                 numberOfShares.Remove(stockName);
             }
             else throw new StockExchangeException("portfolio nema tu dionicu");
         }
         public int NumberOfStocks()
         { return stocks.Count; }
         public bool HasStock(string stockName)
         {
             return stocks.ContainsKey(stockName);
         }
         public int StockSharesNumber(string stockName)
         {
             if (HasStock(stockName)) return (int)numberOfShares[stockName];
             else throw new StockExchangeException("nema te dionice");
         }

         public decimal Value(DateTime timeStamp)
         {
             decimal sum = 0;

             foreach (KeyValuePair<string, Stock> pair in stocks)
             {
                 sum += numberOfShares[pair.Key] * pair.Value.GetPrice(timeStamp);
             }

             return Math.Round(sum, 3);
         }

         public decimal PercentChangeValue(int year, int month)
         {
             DateTime last = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
             DateTime first = new DateTime(year, month, 1, 0, 0, 0, 0);
             return Math.Round(((Value(last) - Value(first)) / Value(first)) * 100,3);
         }

     }

}
