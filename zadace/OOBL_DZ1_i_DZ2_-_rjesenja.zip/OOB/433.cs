﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new MojNajboljiKalkulator();
        }
    }
    class MojNajboljiKalkulator : ICalculator
    {
        string displayValue = "0", testStringLength, ispisiSinCosTan;
        string[] testOutput2;
        double firstNumber = 0, secondNumber = 0,testOutput,sinus,cosinus,tangens,inverz, kvadrat, korijen;
        char operation;
        string memorija;
        int state = 0; 
        //0-> pocetno stanje
        //1-> unasanje prvog broja 
        //2-> unesen operator, tj. prvi broj je zapamcen
        //3 -> unasanje drugog broja
        Boolean flagFirstAfterOperator = false, pocetak = false;
        int brojZnamenkiIspredZareza;
        public string ConnectStringsForDisplay(char x) 
        {
            testStringLength = displayValue + x.ToString();
            if (testStringLength.Replace(",","").Length < 11) return testStringLength;
            return displayValue;
        }

        public double ConvertDisplayToDouble () 
        {
            double rtnValue;
            string temp = displayValue;
            temp = temp.Replace(',', '.');
            double temp2 = double.Parse(temp);
            rtnValue = temp2 % 1;
            if (rtnValue == 0)
            {
                rtnValue = Convert.ToInt32(temp2);
                displayValue = rtnValue.ToString();
            }
            else
            {
                rtnValue = temp2;
            }
            return rtnValue;
        }

        public string ConverterDoubleUDisplayZaSinCos(double x) 
        {
            string y = x.ToString();
            string[] z;
            int brojZnamenakaIspred;
            if (y.Contains('-'))  y = y.Replace("-", "");
            z = y.Split('.');
            brojZnamenakaIspred = z[0].Length;
            x = Math.Round(x, 10 - brojZnamenakaIspred);
            y = x.ToString().Replace(".",",");
            return y;
        }

        public string PrintOutput()
        {
            if (displayValue.Contains(','))
            {
                testOutput2 = displayValue.Split(',');
                brojZnamenkiIspredZareza = testOutput2[0].Length;
                testOutput = ConvertDisplayToDouble();
                testOutput = Math.Round(testOutput, 10 - brojZnamenkiIspredZareza);
                return testOutput.ToString();
            }
            return displayValue;
        }
        
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                if (!displayValue.Equals("0") && flagFirstAfterOperator == false && pocetak == false) displayValue = ConnectStringsForDisplay(inPressedDigit);
                else
                {
                    displayValue = inPressedDigit.ToString();
                    flagFirstAfterOperator = false;
                    pocetak = false;
                }
                if (state == 2) state = 3;
            } else if (inPressedDigit.Equals(',')) 
            {
                if (!displayValue.Contains(','))
                {
                    displayValue += inPressedDigit;
                }
            } else
                switch (inPressedDigit)
                { 
                    case '+':
                        if (state == 0)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '+';
                        }
                        else if (state == 1)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '+';
                        }
                        else if (state == 2)
                        {
                            if (operation == '-' || operation == '+') { }
                            else { operation = '+'; }
                        }
                        else if (state == 3)
                        {
                            secondNumber = Convert.ToDouble(displayValue);
                            if (operation == '+')
                            {
                                displayValue = (firstNumber + secondNumber).ToString();
                                firstNumber = firstNumber + secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '-')
                            {
                                displayValue = (firstNumber - secondNumber).ToString();
                                firstNumber = firstNumber - secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '*')
                            {
                                displayValue = (firstNumber * secondNumber).ToString();
                                firstNumber = firstNumber * secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '/')
                            {
                                displayValue = (firstNumber / secondNumber).ToString();
                                firstNumber = firstNumber / secondNumber;
                                secondNumber = firstNumber;
                            }
                            operation = '+';
                            PrintOutput();
                        }
                        flagFirstAfterOperator = true;
                        state = 2;
                        break;
                    case '-':
                        if (state == 0)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '-';
                        }
                        else if (state == 1)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '-';
                        }
                        else if (state == 2)
                        {
                            if (operation == '-') { operation = '+'; }
                            else { operation = '-'; }
                        }
                        else if (state == 3)
                        {
                            secondNumber = Convert.ToDouble(displayValue);
                            if (operation == '+')
                            {
                                displayValue = (firstNumber + secondNumber).ToString();
                                firstNumber = firstNumber + secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '-')
                            {
                                displayValue = (firstNumber - secondNumber).ToString();
                                firstNumber = firstNumber - secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '*')
                            {
                                displayValue = (firstNumber * secondNumber).ToString();
                                firstNumber = firstNumber * secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '/')
                            {
                                displayValue = (firstNumber / secondNumber).ToString();
                                firstNumber = firstNumber / secondNumber;
                                secondNumber = firstNumber;
                            }
                            operation = '-';
                            PrintOutput();
                        }
                        flagFirstAfterOperator = true;
                        state = 2;
                        break;
                    case '*':
                        if (state == 0)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '*';
                        }
                        else if (state == 1)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '*';
                        }
                        else if (state == 2)
                        {
                            operation = '*';
                        }
                        else if (state == 3)
                        {
                            secondNumber = Convert.ToDouble(displayValue);
                            if (operation == '+')
                            {
                                displayValue = (firstNumber + secondNumber).ToString();
                                firstNumber = firstNumber + secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '-')
                            {
                                displayValue = (firstNumber - secondNumber).ToString();
                                firstNumber = firstNumber - secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '*')
                            {
                                displayValue = (firstNumber * secondNumber).ToString();
                                firstNumber = firstNumber * secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '/')
                            {
                                displayValue = (firstNumber / secondNumber).ToString();
                                firstNumber = firstNumber / secondNumber;
                                secondNumber = firstNumber;
                            }
                            operation = '*';
                            PrintOutput();
                        }
                        flagFirstAfterOperator = true;
                        state = 2;
                        break;
                    case '/':
                        if (state == 0)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '/';
                        }
                        else if (state == 1)
                        {
                            firstNumber = ConvertDisplayToDouble();
                            secondNumber = ConvertDisplayToDouble();
                            operation = '/';
                        }
                        else if (state == 2)
                        {
                            operation = '/';
                        }
                        else if (state == 3)
                        {
                            secondNumber = Convert.ToDouble(displayValue);
                            if (operation == '+')
                            {
                                displayValue = (firstNumber + secondNumber).ToString();
                                firstNumber = firstNumber + secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '-')
                            {
                                displayValue = (firstNumber - secondNumber).ToString();
                                firstNumber = firstNumber - secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '*')
                            {
                                displayValue = (firstNumber * secondNumber).ToString();
                                firstNumber = firstNumber * secondNumber;
                                secondNumber = firstNumber;
                            }
                            else if (operation == '/')
                            {
                                displayValue = (firstNumber / secondNumber).ToString();
                                firstNumber = firstNumber / secondNumber;
                                secondNumber = firstNumber;
                            }
                            operation = '/';
                            PrintOutput();
                        }
                        flagFirstAfterOperator = true;
                        state = 2;
                        break;
                    case '=':
                        secondNumber = ConvertDisplayToDouble();
                        switch (operation)
                        { 
                            case '+':
                                if ((firstNumber * secondNumber) < 9999999999) displayValue = ConverterDoubleUDisplayZaSinCos(firstNumber + secondNumber);
                                else displayValue = "-E-";
                                break;
                            case '-':
                                displayValue = ConverterDoubleUDisplayZaSinCos(firstNumber - secondNumber);
                                break;
                            case '*':
                                if ((firstNumber * secondNumber) < 9999999999) displayValue = ConverterDoubleUDisplayZaSinCos(firstNumber * secondNumber);
                                else displayValue = "-E-";
                                break;
                            case '/':
                                displayValue = ConverterDoubleUDisplayZaSinCos(firstNumber / secondNumber);
                                break;
                            default:
                                break;
                        }
                        state = 1;
                        pocetak = true;
                        break;
                    case 'M':
                        if (displayValue.Contains('-')) { displayValue = displayValue.Replace("-", ""); }
                        else displayValue = "-" + displayValue;
                        break;
                    case 'S':
                        sinus = ConvertDisplayToDouble();
                        sinus = Math.Sin(sinus);
                        ispisiSinCosTan = ConverterDoubleUDisplayZaSinCos(sinus);
                        displayValue = ispisiSinCosTan;
                        break;
                    case 'K':
                        cosinus = ConvertDisplayToDouble();
                        cosinus = Math.Cos(cosinus);
                        ispisiSinCosTan = ConverterDoubleUDisplayZaSinCos(cosinus);
                        displayValue = ispisiSinCosTan;
                        break;
                    case 'T':
                        tangens = ConvertDisplayToDouble();
                        tangens = Math.Tan(tangens);
                        ispisiSinCosTan = ConverterDoubleUDisplayZaSinCos(tangens);
                        displayValue = ispisiSinCosTan;
                        break;
                    case 'Q':
                        kvadrat = ConvertDisplayToDouble();
                        kvadrat = Math.Pow(kvadrat, 2);
                        displayValue = ConverterDoubleUDisplayZaSinCos(kvadrat);
                        break;
                    case 'R':
                        korijen = ConvertDisplayToDouble();
                        korijen = Math.Sqrt(korijen);
                        displayValue = ConverterDoubleUDisplayZaSinCos(korijen);
                        break;
                    case 'I':
                        inverz = ConvertDisplayToDouble();
                        if (inverz != 0)
                        {
                            inverz = 1 / inverz;
                            displayValue = ConverterDoubleUDisplayZaSinCos(inverz);
                        }
                        else displayValue = "-E-";
                        break;
                    case 'P':
                        memorija = displayValue;
                        break;
                    case 'G':
                        displayValue = memorija;
                        break;
                    case 'C':
                        displayValue = "0";
                        break;
                    case 'O':
                        displayValue = "0";
                        firstNumber = 0;
                        secondNumber = 0;
                        state = 0;
                        break;
                    default:
                        break;

                }
        }

        public string GetCurrentDisplayState() 
        {
            return displayValue;
        }

        public string GetCurrentState()
        {
            return state.ToString();
        }
        public string GetFirst()
        {
            return firstNumber.ToString();
        }
        public string GetSecond()
        {
            return secondNumber.ToString();
        }
    }
}
