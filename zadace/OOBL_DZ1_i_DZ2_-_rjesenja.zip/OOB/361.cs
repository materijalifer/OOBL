﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new SpockExchange();
        }
    }

    // Uglavnom ne radi nista pametno i prosljedjuje pozive objektima; verbozan error handling rezultira vecom kolicinom koda
    public class SpockExchange : IStockExchange
    {
        // Broj decimala svih necjelobrojnih izracuna
        public const int Precision = 3;

        private Dictionary<string, StockListing> stocks;

        private Dictionary<string, StockIndex> indices;

        private Dictionary<string, SharesPortfolio> portfolios;

        public SpockExchange()
        {
            // Rjecnici koriste usporedbu kljuca koju definira odgovarajuci tip objekta (konkretno, case sensitivity)
            this.stocks = new Dictionary<string, StockListing>(StockListing.Comparer);
            this.indices = new Dictionary<string, StockIndex>(StockIndex.Comparer);
            this.portfolios = new Dictionary<string, SharesPortfolio>(SharesPortfolio.Comparer);
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try {
                stocks.Add(inStockName, new StockListing(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            } catch (ArgumentException e) {
                throw new StockExchangeException("Tried to list stock " + inStockName + " that is already listed on exchange");
            }
        }

        public void DelistStock(string inStockName)
        {
            try {
                StockListing stock = stocks[inStockName];
                stock.DelistStock();
                stocks.Remove(inStockName);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to delist stock " + inStockName + " that is not listed on exchange");
            }
        }

        public bool StockExists(string inStockName)
        {
            return stocks.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            try {
                stocks[inStockName].SetStockPrice(inIimeStamp, inStockValue);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to set price of nonlisted stock " + inStockName);
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try {
                return stocks[inStockName].GetStockPrice(inTimeStamp);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get price of nonlisted stock " + inStockName);
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            try {
                return stocks[inStockName].GetInitialStockPrice();
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get initial price of nonlisted stock " + inStockName);
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            try {
                return stocks[inStockName].GetLastStockPrice();
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get last price of nonlisted stock " + inStockName);
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            // Zasad samo dva tipa indeksa, nema potrebe uvoditi tvornicu
            StockIndex index = null;
            if (inIndexType == IndexTypes.AVERAGE) {
                index = new AverageStockIndex(inIndexName);
            } else if (inIndexType == IndexTypes.WEIGHTED) {
                index = new WeightedStockIndex(inIndexName);
            } else {
                throw new StockExchangeException("Index " + inIndexName + " must have AVERAGE or WEIGHTED type");
            }
            try {
                indices.Add(inIndexName, index);
            } catch (ArgumentException e) {
                throw new StockExchangeException("Tried to add index " + inIndexName + " that already exists on exchange");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try {
                indices[inIndexName].AddStockToIndex(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to add stock " + inStockName + " to index " + inIndexName + "; stock and/or index doesn't exist");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try {
                indices[inIndexName].RemoveStockFromIndex(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to remove stock " + inStockName + " from index " + inIndexName + "; stock and/or index doesn't exist");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName)) {
                return false;
            }
            try {
                return indices[inIndexName].IsStockPartOfIndex(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to query index " + inIndexName + " for stock " + inStockName + "; index doesn't exist");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try {
                return indices[inIndexName].GetIndexValue(inTimeStamp);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get value of index " + inIndexName + " that doesn't exist");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return indices.ContainsKey(inIndexName);
        }

        public int NumberOfIndices()
        {
            return indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            try {
                return indices[inIndexName].NumberOfStocksInIndex();
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get stock count of index " + inIndexName + " that doesn't exist");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            try {
                portfolios.Add(inPortfolioID, new SharesPortfolio(inPortfolioID));
            } catch (ArgumentException e) {
                throw new StockExchangeException("Tried to create portfolio " + inPortfolioID + " that already exists on exchange");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try {
                portfolios[inPortfolioID].AddStockToPortfolio(stocks[inStockName], numberOfShares);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to add shares of " + inStockName + " to portfolio " + inPortfolioID + "; stock and/or portfolio doesn't exist");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try {
                portfolios[inPortfolioID].RemoveStockFromPortfolio(stocks[inStockName], numberOfShares);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to remove shares of " + inStockName + " from portfolio " + inPortfolioID + "; stock and/or portfolio doesn't exist");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            try {
                portfolios[inPortfolioID].RemoveStockFromPortfolio(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to remove all shares of " + inStockName + " from portfolio " + inPortfolioID + "; stock and/or portfolio doesn't exist");
            }
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try {
                return portfolios[inPortfolioID].NumberOfStocksInPortfolio();
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get stock count of portfolio " + inPortfolioID + " that doesn't exist");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!StockExists(inStockName)) {
                return false;
            }
            try {
                return portfolios[inPortfolioID].IsStockPartOfPortfolio(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to query portfolio " + inPortfolioID + " for stock " + inStockName + "; portfolio doesn't exist");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!StockExists(inStockName)) {
                return 0;
            }
            try {
                return (int)portfolios[inPortfolioID].NumberOfSharesOfStockInPortfolio(stocks[inStockName]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get share count of " + inStockName + " in portfolio " + inPortfolioID + "; portfolio doesn't exist");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            try {
                return portfolios[inPortfolioID].GetPortfolioValue(timeStamp);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get value of portfolio " + inPortfolioID + " that doesn't exist");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            try {
                return portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to get monthly change of portfolio " + inPortfolioID + " that doesn't exist");
            }
        }
    }

    internal static class Utility
    {
        public static DateTime TrimTimestampToMillisecond(DateTime timestamp)
        {
            return timestamp.AddMilliseconds(-(timestamp.Ticks % TimeSpan.TicksPerMillisecond));
        }
    }

    internal interface IDelistStockListener
    {
        void StockDelisted(StockListing stock);
    }

    internal class StockListing
    {
        // Case insensitive usporedba
        public static IEqualityComparer<string> Comparer = StringComparer.CurrentCultureIgnoreCase;

        // Uppercase
        private string stockName;

        private long totalShares;

        // Broj prodanih dionica (npr. u portfeljima)
        private long soldShares;

        private SortedList<DateTime, decimal> prices;

        // StockListing obavjestava objekte koji ga referiraju kada se mice s burze; smanjuje koheziju, ali je po mojoj procjeni najelegantnije efikasno rjesenje
        private HashSet<IDelistStockListener> delistListeners;

        public StockListing(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName.Length == 0)
            {
                throw new StockExchangeException("Stock cannot have zero-length name");
            }
            this.stockName = inStockName.ToUpper();
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Stock " + GetStockName() + " must have positive number of shares");
            }
            this.totalShares = inNumberOfShares;
            this.soldShares = 0;
            this.prices = new SortedList<DateTime, decimal>();
            this.SetStockPrice(inTimeStamp, inInitialPrice);
            this.delistListeners = new HashSet<IDelistStockListener>();
        }

        // Pozvati kad se dionica mice s burze
        public void DelistStock()
        {
            // Svrha ToArray je kloniranje (firing listener callbacka ce uzrokovati deregistraciju)
            foreach (IDelistStockListener listener in delistListeners.ToArray()) {
                listener.StockDelisted(this);
            }
        }

        public void RegisterStockListener(IDelistStockListener listener)
        {
            try {
                delistListeners.Add(listener);
            } catch (ArgumentException e) {
                // ignore
            }
        }

        public void UnregisterStockListener(IDelistStockListener listener)
        {
            delistListeners.Remove(listener);
        }

        public string GetStockName()
        {
            return stockName;
        }

        public long GetTotalShares()
        {
            return totalShares;
        }

        public long GetSoldShares()
        {
            return soldShares;
        }

        public void SellShares(long count)
        {
            if (count < 0) {
                throw new StockExchangeException("Cannot sell negative number of " + GetStockName() + " shares");
            }
            if (soldShares + count > GetTotalShares()) {
                throw new StockExchangeException("Tried to sell " + count + " shares of " + GetStockName() + ", only " + (GetTotalShares() - soldShares) + " available");
            }
            soldShares += count;
        }

        public void BuyBackShares(long count)
        {
            if (count < 0) {
                throw new StockExchangeException("Cannot buy back negative number of " + GetStockName() + " shares");
            }
            if (count > soldShares) {
                throw new StockExchangeException("Tried to buy back " + count + " shares of " + GetStockName() + ", only " + soldShares + " outstanding");
            }
            soldShares -= count;
        }

        public void SetStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            inTimeStamp = Utility.TrimTimestampToMillisecond(inTimeStamp);
            if (inStockValue <= 0) {
                throw new StockExchangeException("Stock " + GetStockName() + " must have positive price");
            }
            try {
                prices.Add(inTimeStamp, inStockValue);
            } catch (ArgumentException e) {
                throw new StockExchangeException("Tried to add price for " + GetStockName() + " at existing timestamp " + inTimeStamp);
            }
        }

        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            inTimeStamp = Utility.TrimTimestampToMillisecond(inTimeStamp);
            IList<DateTime> timeStamps = prices.Keys;
            // Binary search, naravno
            int b = 0, e = timeStamps.Count, m;
            while (b + 1 < e) {
                m = b + (e - b) / 2;
                if (timeStamps[m] > inTimeStamp) {
                    e = m;
                } else {
                    b = m;
                }
            }
            if (timeStamps[b] > inTimeStamp) {
                throw new StockExchangeException("Stock " + GetStockName() + " price undefined for timestamp " + inTimeStamp);
            } else {
                return prices.Values[b];
            }
        }

        public decimal GetInitialStockPrice()
        {
            return prices.Values[0];
        }

        public decimal GetLastStockPrice()
        {
            return prices.Values[prices.Count - 1];
        }

        public override bool Equals(object obj)
        {
            try {
                return Comparer.Equals(this.GetStockName(), ((StockListing)obj).GetStockName());
            } catch (InvalidCastException e) {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return ("S_" + GetStockName()).GetHashCode();
        }
    }

    internal abstract class StockIndex : IDelistStockListener
    {
        // Case insensitive usporedba
        public static IEqualityComparer<string> Comparer = StringComparer.CurrentCultureIgnoreCase;

        // Uppercase
        private string indexName;

        protected HashSet<StockListing> indexStocks;

        public StockIndex(string inIndexName)
        {
            if (inIndexName.Length == 0) {
                throw new StockExchangeException("Index cannot have zero-length name");
            }
            this.indexName = inIndexName.ToUpper();
            this.indexStocks = new HashSet<StockListing>();
        }

        public string GetIndexName()
        {
            return indexName;
        }

        public void AddStockToIndex(StockListing stock)
        {
            try {
                indexStocks.Add(stock);
            } catch (ArgumentException e) {
                throw new StockExchangeException("Tried to add stock " + stock.GetStockName() + " to index " + GetIndexName() + " that already contains the stock");
            }
            stock.RegisterStockListener(this);
        }

        public void RemoveStockFromIndex(StockListing stock)
        {
            if (!indexStocks.Remove(stock)) {
                throw new StockExchangeException("Tried to remove stock " + stock.GetStockName() + " from index " + GetIndexName() + " that doesn't contain the stock");
            }
            stock.UnregisterStockListener(this);
        }

        public void StockDelisted(StockListing stock)
        {
            RemoveStockFromIndex(stock);
        }

        public bool IsStockPartOfIndex(StockListing stock)
        {
            return indexStocks.Contains(stock);
        }

        public abstract decimal GetIndexValue(DateTime inTimeStamp);

        public int NumberOfStocksInIndex()
        {
            return indexStocks.Count;
        }

        public override bool Equals(object obj)
        {
            try {
                return Comparer.Equals(this.GetIndexName(), ((StockIndex)obj).GetIndexName());
            } catch (InvalidCastException e) {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return ("I_" + GetIndexName()).GetHashCode();
        }
    }

    internal class AverageStockIndex : StockIndex
    {
        public AverageStockIndex(string inIndexName) : base(inIndexName) { }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (indexStocks.Count == 0) {
                return 0;
            }
            decimal average = 0;
            foreach (StockListing stock in indexStocks) {
                average += stock.GetStockPrice(inTimeStamp);
            }
            return Decimal.Round(average / indexStocks.Count, SpockExchange.Precision);
        }
    }

    internal class WeightedStockIndex : StockIndex
    {
        public WeightedStockIndex(string inIndexName) : base(inIndexName) { }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (indexStocks.Count == 0) {
                return 0;
            }
            // Prvo se racuna nazivnik da mozemo svaki clan posebno dijeliti s njim - manja vjerojatnost overflowa
            decimal totalIndexValue = 0;
            foreach (StockListing stock in indexStocks) {
                totalIndexValue += stock.GetStockPrice(inTimeStamp) * stock.GetTotalShares();
            }
            decimal weighted = 0;
            foreach (StockListing stock in indexStocks) {
                decimal stockPrice = stock.GetStockPrice(inTimeStamp);
                weighted += stockPrice * stockPrice * stock.GetTotalShares() / totalIndexValue;
            }
            return Decimal.Round(weighted, SpockExchange.Precision);
        }
    }

    internal class SharesPortfolio : IDelistStockListener
    {
        // Case sensitive usporedba
        public static IEqualityComparer<string> Comparer = StringComparer.CurrentCulture;

        private string portfolioID;

        // StockListing -> broj dionica u portfoliju
        private Dictionary<StockListing, long> portfolioShares;

        public SharesPortfolio(string inPortfolioID)
        {
            if (inPortfolioID.Length == 0) {
                throw new StockExchangeException("Portfolio cannot have zero-length ID");
            }
            this.portfolioID = inPortfolioID;
            this.portfolioShares = new Dictionary<StockListing, long>();
        }

        public string GetPortfolioID()
        {
            return portfolioID;
        }

        public void AddStockToPortfolio(StockListing stock, long numberOfShares)
        {
            if (numberOfShares <= 0) {
                throw new StockExchangeException("Tried to add zero or a negative number of " + stock.GetStockName() + " shares to portfolio " + GetPortfolioID());
            }
            if (!portfolioShares.ContainsKey(stock)) {
                portfolioShares.Add(stock, numberOfShares);
                stock.RegisterStockListener(this);
            } else {
                portfolioShares[stock] += numberOfShares;
            }
            stock.SellShares(numberOfShares);
        }

        public void RemoveStockFromPortfolio(StockListing stock, long numberOfShares)
        {
            if (numberOfShares <= 0) {
                throw new StockExchangeException("Tried to remove zero or a negative number of " + stock.GetStockName() + " shares from portfolio " + GetPortfolioID());
            }
            try {
                if (portfolioShares[stock] < numberOfShares) {
                    throw new StockExchangeException("Tried to remove " + numberOfShares + " " + stock.GetStockName() + " shares from portfolio " + GetPortfolioID() + " that only contains " + portfolioShares[stock]);
                } else if (portfolioShares[stock] == numberOfShares) {
                    portfolioShares.Remove(stock);
                    stock.UnregisterStockListener(this);
                } else {
                    portfolioShares[stock] -= numberOfShares;
                }
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to remove " + stock.GetStockName() + " shares from portfolio " + GetPortfolioID() + " that doesn't contain the stock");
            }
            stock.BuyBackShares(numberOfShares);
        }

        public void RemoveStockFromPortfolio(StockListing stock)
        {
            try {
                RemoveStockFromPortfolio(stock, portfolioShares[stock]);
            } catch (KeyNotFoundException e) {
                throw new StockExchangeException("Tried to remove all " + stock.GetStockName() + " shares from portfolio " + GetPortfolioID() + " that doesn't contain the stock");
            }
        }

        public void StockDelisted(StockListing stock)
        {
            RemoveStockFromPortfolio(stock);
        }

        public int NumberOfStocksInPortfolio()
        {
            return portfolioShares.Count;
        }

        public bool IsStockPartOfPortfolio(StockListing stock)
        {
            return portfolioShares.ContainsKey(stock);
        }

        public long NumberOfSharesOfStockInPortfolio(StockListing stock)
        {
            try {
                return portfolioShares[stock];
            } catch (KeyNotFoundException e) {
                return 0;
            }
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal totalValue = 0;
            foreach (KeyValuePair<StockListing, long> stockShares in portfolioShares) {
                totalValue += stockShares.Key.GetStockPrice(timeStamp) * stockShares.Value;
            }
            return Decimal.Round(totalValue, SpockExchange.Precision);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            if (portfolioShares.Count == 0) {
                return 0;
            }
            DateTime monthBegin = new DateTime(Year, Month, 1, 0, 00, 00, 000);
            DateTime monthEnd = monthBegin.AddMonths(1).AddMilliseconds(-1);
            decimal bomValue = GetPortfolioValue(monthBegin);
            decimal eomValue = GetPortfolioValue(monthEnd);
            return Decimal.Round((eomValue - bomValue) / bomValue * 100, SpockExchange.Precision);
        }

        public override bool Equals(object obj)
        {
            try {
                return Comparer.Equals(this.GetPortfolioID(), ((SharesPortfolio)obj).GetPortfolioID());
            } catch (InvalidCastException e) {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return ("P_" + GetPortfolioID()).GetHashCode();
        }
    }
}
