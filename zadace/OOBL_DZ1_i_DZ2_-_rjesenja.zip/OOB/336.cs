﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DrugaDomacaZadaca_Burza;

namespace DrugaDomacaZadaca_Burza
{
    public class StockExchange : IStockExchange
    {
        List<Stock> Stocks = new List<Stock>();
        List<Index> Indices = new List<Index>();
        List<Portfolio> Portfolios = new List<Portfolio>();


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("A stock with that name already exists");
            }
            if (inInitialPrice < 0)
            {
                throw new StockExchangeException("The price must me zero or more");
            }

            Stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            Stocks.Remove(Stocks.Find(a => a.StockName == inStockName.ToLower()));
        }

        public bool StockExists(string inStockName)
        {
            return Stocks.Exists(a => a.StockName == inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return Stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockValue < 0)
            {
                throw new StockExchangeException("The price must me zero or more");
            }

            Stock stock = Stocks.Find(a => a.StockName == inStockName.ToLower());
            if (stock.TimePrice.Exists(a => a.Key == inTimeStamp))
            {
                stock.TimePrice.Remove(stock.TimePrice.Find(a => a.Key == inTimeStamp));
                stock.TimePrice.Add(new KeyValuePair<DateTime, decimal>(inTimeStamp, inStockValue));
            }
            else
            {
                stock.TimePrice.Add(new KeyValuePair<DateTime, decimal>(inTimeStamp, inStockValue));
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return Stocks.Find(a => a.StockName == inStockName.ToLower()).GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return Stocks.Find(a => a.StockName == inStockName.ToLower()).GetFirstPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return Stocks.Find(a => a.StockName == inStockName.ToLower()).GetLastPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Indices.Add(new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Indices.Find(a => a.IndexName == inIndexName.ToLower()).IndexStocks.Add(Stocks.Find(a => a.StockName == inStockName.ToLower()));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Indices.Find(a => a.IndexName == inIndexName.ToLower()).IndexStocks.Remove(Stocks.Find(a => a.StockName == inStockName.ToLower()));
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return Indices.Find(a => a.IndexName == inIndexName.ToLower()).IndexStocks.Contains(Stocks.Find(a => a.StockName == inStockName.ToLower()));
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return Decimal.Round(Indices.Find(a => a.IndexName == inIndexName.ToLower()).GetValue(inTimeStamp), 3);
        }

        public bool IndexExists(string inIndexName)
        {
            return Indices.Exists(a => a.IndexName == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return Indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return Indices.Find(a => a.IndexName == inIndexName.ToLower()).IndexStocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolios.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                Stock st = Stocks.Find(a => a.StockName == inStockName.ToLower());
                if (TotalNumOfSharesInPortfolio(inStockName) + numberOfShares > st.NumberOfShares)
                {
                    throw new StockExchangeException("Ne postoji toliko dionica");
                }
                Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Find(a => a.StockName == inStockName.ToLower()).NumberOfShares += numberOfShares;
            }
            else
            {
                Stock st = Stocks.Find(a => a.StockName == inStockName.ToLower());
                if (TotalNumOfSharesInPortfolio(inStockName) + numberOfShares > st.NumberOfShares)
                {
                    throw new StockExchangeException("Ne postoji toliko dionica");
                }
                Stock stock = new Stock(st.StockName, numberOfShares, st.InitialPrice, st.TimeStamp);
                stock.TimePrice = st.TimePrice;

                Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Add(stock);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock st = Stocks.Find(a => a.StockName == inStockName.ToLower());
            if (TotalNumOfSharesInPortfolio(inStockName) - numberOfShares < 1)
            {
                RemoveStockFromPortfolio(inPortfolioID, inStockName);
            }
            Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Find(a => a.StockName == inStockName.ToLower()).NumberOfShares -= numberOfShares;
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Remove(Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Find(a => a.StockName == inStockName));
            if (Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Count < 1)
            {
                Portfolios.Remove(Portfolios.Find(a => a.PortfolioID == inPortfolioID));
            }
        }

        public int NumberOfPortfolios()
        {
            return Portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return Portfolios.Exists(a => a.PortfolioID == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Exists(a => a.StockName == inStockName.ToLower());
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return Convert.ToInt32(Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks.Find(a => a.StockName == inStockName.ToLower()).NumberOfShares);

        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (Stock stock in Portfolios.Find(a => a.PortfolioID == inPortfolioID).PortfolioStocks)
            {
                sum += stock.GetPrice(timeStamp);
            }
            return sum;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal change;
            decimal last = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
            DateTime time = new DateTime(Year, Month, 1);
            time.AddMonths(1);
            time.AddDays(-1);
            int days = time.Day;
            decimal first = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, days, 23, 59, 59, 999));
            change = (last - first) / first * 100;
            return Math.Abs(change);

        }

        private int TotalNumOfSharesInPortfolio(string inStockName)
        {
            long sum = 0;
            foreach (Portfolio port in Portfolios)
            {
                foreach (Stock stock in port.PortfolioStocks)
                {
                    if (stock.StockName == inStockName)
                    {
                        sum += stock.NumberOfShares;
                    }
                }
            }
            return Convert.ToInt32(sum);
        }
    }
    public class Stock
    {
        public string StockName { get; set; }
        public long NumberOfShares { get; set; }
        public Decimal InitialPrice { get; set; }
        public List<KeyValuePair<DateTime, Decimal>> TimePrice { get; set; }
        public DateTime TimeStamp { get; set; }

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            TimePrice = new List<KeyValuePair<DateTime, decimal>>();
            StockName = inStockName.ToLower();
            NumberOfShares = inNumberOfShares;
            InitialPrice = inInitialPrice;
            TimeStamp = inTimeStamp;
            TimePrice.Add(new KeyValuePair<DateTime, Decimal>(inTimeStamp, InitialPrice));
        }

        public Decimal GetPrice(DateTime timeStamp)
        {
            if (TimePrice.Count == 1)
            {
                return TimePrice.Last().Value;
            }

            TimePrice.Sort(Comparer);

            for (int i = 0; i < TimePrice.Count - 1; i++)
            {
                if (TimePrice[i].Key <= timeStamp)
                {
                    if (TimePrice[i + 1].Key > timeStamp)
                    {
                        return TimePrice[i].Value;
                    }
                }
            }
            return TimePrice.Last().Value;
        }
        public Decimal GetLastPrice()
        {
            TimePrice.Sort(Comparer);
            return TimePrice.Last().Value;
        }
        public Decimal GetFirstPrice()
        {
            TimePrice.Sort(Comparer);
            return TimePrice.First().Value;
        }

        static int Comparer(KeyValuePair<DateTime, Decimal> a, KeyValuePair<DateTime, Decimal> b)
        {
            return a.Key.CompareTo(b.Key);
        }
    }
    public class Index
    {
        public List<Stock> IndexStocks { get; set; }
        public String IndexName { get; set; }
        public IndexTypes IndexType { get; set; }

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            IndexStocks = new List<Stock>();

            IndexName = inIndexName.ToLower();
            IndexType = inIndexType;
        }
        public Decimal GetValue(DateTime timeStamp)
        {
            if (IndexType == IndexTypes.AVERAGE)
            {
                return GetAverageValue(timeStamp);
            }
            else if (IndexType == IndexTypes.WEIGHTED)
            {
                return GetWeightedValue(timeStamp);
            }
            else
            {
                return 0;
            }
        }
        Decimal GetAverageValue(DateTime timeStamp)
        {
            Decimal sum = 0;
            foreach (Stock indexStock in IndexStocks)
            {
                sum += indexStock.GetPrice(timeStamp);
            }
            return (sum / IndexStocks.Count);
        }
        Decimal GetWeightedValue(DateTime timeStamp)
        {
            Decimal upSum = 0;
            Decimal downSum = 0;
            foreach (Stock indexStock in IndexStocks)
            {
                upSum += (indexStock.GetPrice(timeStamp) * indexStock.NumberOfShares);
            }
            foreach (Stock indexStock in IndexStocks)
            {
                downSum += indexStock.NumberOfShares * indexStock.GetPrice(timeStamp) * indexStock.GetPrice(timeStamp) / upSum;
            }
            return downSum;
        }
    }
    public class Portfolio
    {
        public List<Stock> PortfolioStocks { get; set; }
        public string PortfolioID { get; set; }

        public Portfolio(string inPortfolioID)
        {
            PortfolioStocks = new List<Stock>();
            PortfolioID = inPortfolioID;
        }

    }
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new DrugaDomacaZadaca_Burza.StockExchange();
        }
    }

}
