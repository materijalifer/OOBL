﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         //private List<Stock> _stockList = new List<Stock>(); 
         private Dictionary<string, Stock> _stockList = new Dictionary<string, Stock>();
         private Dictionary<string, Index> _indexList = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> _portfolioList = new Dictionary<string, Portfolio>();

         #region Stocks
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (!StockExists(inStockName))
             {
                 this._stockList.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
             }
             else
             {
                 throw new StockExchangeException("Dionica imena: " + inStockName + " vec postoji.");
             }
         }

         public void DelistStock(string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (StockExists(inStockName))
             {
                 Stock stock = this._stockList[inStockName];

                 foreach (Index index in this._indexList.Values)
                 {
                     if (IsStockPartOfIndex(index.IndexName, stock.StockName))
                     {
                         index.RemoveStock(stock);
                     }
                 }

                 foreach (Portfolio portfolio in this._portfolioList.Values)
                 {
                     if (IsStockPartOfPortfolio(portfolio.PortfolioID, stock.StockName))
                     {
                         portfolio.RemoveStock(stock);
                     }
                 }

                 this._stockList.Remove(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Trazena dionica ne postoji.");
             }
         }

         public bool StockExists(string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (this._stockList.ContainsKey(inStockName))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             //throw new NotImplementedException();
             return this._stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (StockExists(inStockName))
             {
                 this._stockList[inStockName].StockPrices.Add(inTimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Trazena dionica ne postoji.");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (StockExists(inStockName))
             {
                 Stock stock = this._stockList[inStockName];
                 List<DateTime> stockPriceTimeStamps = new List<DateTime>(stock.StockPrices.Keys);
                 stockPriceTimeStamps.Sort();

                 if (inTimeStamp < stockPriceTimeStamps.Min())
                 {
                     throw new StockExchangeException("Za trzenu dionicu ne postoji definirana cijena za vrijeme: " + inTimeStamp);
                 }
                 else if (inTimeStamp >= stockPriceTimeStamps.Max())
                 {
                     return stock.CurrentPrice;
                 }
                 else
                 {
                     for (int i = 0; i < stockPriceTimeStamps.Count - 1; i++)
                     {
                         if (inTimeStamp >= stockPriceTimeStamps[i] && inTimeStamp < stockPriceTimeStamps[i + 1])
                         {
                             return stock.StockPrices[stockPriceTimeStamps[i]];
                         }
                     }
                     throw new StockExchangeException("Greska u dohvacanju cijene dionice za vrijeme: " + inTimeStamp);
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazena dionica ne postoji.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (StockExists(inStockName))
             {
                 Stock stock = this._stockList[inStockName];
                 return stock.StockPrices[stock.StockPrices.Keys.Min()];
             }
             else
             {
                 throw new StockExchangeException("Trazena dionica ne postoji.");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (StockExists(inStockName))
             {
                 Stock stock = this._stockList[inStockName];
                 return stock.StockPrices[stock.StockPrices.Keys.Max()];
             }
             else
             {
                 throw new StockExchangeException("Trazena dionica ne postoji.");
             }
         }
#endregion

         #region Indices
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();

             if (!IndexExists(inIndexName))
             {
                 this._indexList.Add(inIndexName.ToUpper(), new Index(inIndexName, inIndexType));
             }
             else
             {
                 throw new StockExchangeException("Indeks imena: " + inIndexName + " vec postoji.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 if (!IsStockPartOfIndex(inIndexName.ToUpper(), inStockName))
                 {
                     this._indexList[inIndexName.ToUpper()].AddStock(this._stockList[inStockName]);
                 }
                 else
                 {
                     throw new StockExchangeException("Dionica vec postoji u indeksu.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni indeks i/ili dionica ne postoje.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 if (IsStockPartOfIndex(inIndexName.ToUpper(), inStockName))
                 {
                     this._indexList[inIndexName.ToUpper()].RemoveStock(this._stockList[inStockName]);
                 }
                 else
                 {
                     throw new StockExchangeException("Dionica ne postoji u indeksu.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni indeks i/ili dionica ne postoje.");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Index index = this._indexList[inIndexName.ToUpper()];
                 Stock stock = this._stockList[inStockName];

                 if (index.ContainsStock(stock))
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni indeks i/ili dionica ne postoje.");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();

             if (IndexExists(inIndexName) && NumberOfStocksInIndex(inIndexName) > 0)
             {
                 Index index = this._indexList[inIndexName.ToUpper()];
                 Decimal totalValue = 0m;
                 if (index.IndexType == IndexTypes.AVERAGE)
                 {
                     foreach (Stock stock in index.IndexStockList)
                     {
                         totalValue += stock.CurrentPrice;
                     }

                     return Math.Round(totalValue/index.IndexStockList.Count, 3);
                 }
                 else if (index.IndexType == IndexTypes.WEIGHTED)
                 {
                     Decimal totalWeight = index.IndexStockList.Sum(stock => stock.CurrentPrice*stock.NumberOfShares);

                     foreach (Stock stock in index.IndexStockList)
                     {
                         totalValue += stock.CurrentPrice*stock.NumberOfShares*(stock.CurrentPrice/totalWeight);
                     }

                     return Math.Round(totalValue, 3);
                 }
                 else
                 {
                     throw new StockExchangeException("Zadani indeks je nepostojećeg tipa.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni indeks ne postoji.");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();

             if (this._indexList.ContainsKey(inIndexName))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             //throw new NotImplementedException();
             return this._indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             //throw new NotImplementedException();
             inIndexName = inIndexName.ToUpper();

             if (IndexExists(inIndexName))
             {
                 return this._indexList[inIndexName.ToUpper()].StockCount();
             }
             else
             {
                 throw new StockExchangeException("Trazeni indeks ne postoje.");
             }
         }
#endregion

         #region Portofolio
         public void CreatePortfolio(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if (!PortfolioExists(inPortfolioID))
             {
                 this._portfolioList.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
             else
             {
                 throw new StockExchangeException("Portfelj s ID-jem: " + inPortfolioID + " već postoji.");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Nije moguće dodati manje od 1 dionice portfelju");
             }

             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Portfolio portfolio = this._portfolioList[inPortfolioID];
                 Stock stock = this._stockList[inStockName];

                 if (numberOfShares > stock.NumberOfAvailableShares)
                 {
                     throw new StockExchangeException("Nedovoljno dionica dostupno.");
                 }
                 else
                 {
                     stock.NumberOfAvailableShares -= numberOfShares;
                     portfolio.AddStock(stock, numberOfShares);
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj i/ili dionica ne postoje.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Nije moguće oduzeti manje od 1 dionice portfelju");
             }

             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     Portfolio portfolio = this._portfolioList[inPortfolioID];
                     Stock stock = this._stockList[inStockName];

                     if (numberOfShares > portfolio.StockShareCount(stock))
                     {
                         throw new StockExchangeException("Nedovoljno dionica dostupno u portfelju.");
                     }
                     else
                     {
                         stock.NumberOfAvailableShares += numberOfShares;
                         portfolio.RemoveStock(stock, numberOfShares);
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("Trazena dionica ne postoji u portfelju");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj i/ili dionica ne postoje.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     Portfolio portfolio = this._portfolioList[inPortfolioID];
                     Stock stock = this._stockList[inStockName];

                     portfolio.RemoveStock(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("Trazena dionica ne postoji u portfelju");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj i/ili dionica ne postoje.");
             }
         }

         public int NumberOfPortfolios()
         {
             //throw new NotImplementedException();
             return this._portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if (PortfolioExists(inPortfolioID))
             {
                 return this._portfolioList[inPortfolioID].StockCount();
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj ne postoji.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if (this._portfolioList.ContainsKey(inPortfolioID))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Portfolio portfolio = this._portfolioList[inPortfolioID];
                 Stock stock = this._stockList[inStockName];

                 if (portfolio.ContainsStock(stock))
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj i/ili dionica ne postoje.");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             inStockName = inStockName.ToUpper();

             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     Portfolio portfolio = this._portfolioList[inPortfolioID];
                     Stock stock = this._stockList[inStockName];
                     return Convert.ToInt32(portfolio.StockShareCount(stock));
                 }
                 else
                 {
                     throw new StockExchangeException("Trazena dionica ne postoji u portfelju.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj i/ili dionica ne postoje");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             //throw new NotImplementedException();
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = this._portfolioList[inPortfolioID];
                 Decimal totalValue = 0m;

                 foreach (Stock stock in portfolio.PortfolioStockList.Keys )
                 {
                     totalValue += GetStockPrice(stock.StockName, timeStamp)*portfolio.PortfolioStockList[stock];
                 }
                 return Math.Round(totalValue, 3);
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj ne postoji.");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             //throw new NotImplementedException();
             if (PortfolioExists(inPortfolioID))
             {
                 Decimal firstDayValue = 0m;
                 Decimal lastDayValue = 0m;
                 DateTime firstDay = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                 DateTime lastDay = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

                 firstDayValue = GetPortfolioValue(inPortfolioID, firstDay);
                 lastDayValue = GetPortfolioValue(inPortfolioID, lastDay);

                 if (firstDayValue > 0)
                 {
                     Decimal percentChange = ((lastDayValue - firstDayValue)/firstDayValue)*100;
                     return Math.Round(percentChange, 3);
                 }
                 else
                 {
                     throw new StockExchangeException("Nisu sve dionice definirane u trazenom portfelju za zadani mjesec.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Trazeni portfelj ne postoji.");
             }
         }
#endregion
     }

    public class Stock
    {
        private string _stockName;
        private long _numberOfShares;
        private long _numberOfAvailableShares;
        //private decimal _initialPrice;
        private Dictionary<DateTime, decimal> _stockPrices; 

        public string StockName { get { return this._stockName; } }

        public long NumberOfShares { get { return this._numberOfShares; } }

        public long NumberOfAvailableShares
        {
            get { return this._numberOfAvailableShares; }
            set
            {
                if (value >= 0 && value <= this._numberOfShares)
                {
                    this._numberOfAvailableShares = value;
                }
                else
                {
                    throw new StockExchangeException("Pogrešan broj dostupnih dionica.");
                }
            }
        }

        //public decimal InitialPrice { get { return this._initialPrice; } }

        public Dictionary<DateTime, decimal> StockPrices { get { return this._stockPrices; } } 

        public decimal CurrentPrice
        {
            get { return this._stockPrices[this._stockPrices.Keys.Max()]; }
        }

        public Stock(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
        {
            this._stockName = stockName.ToUpper();
            if (numberOfShares > 0)
            {
                this._numberOfShares = numberOfShares;
                this.NumberOfAvailableShares = numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Broj dionica mora biti pozitivan.");
            }
            this._stockPrices = new Dictionary<DateTime, decimal>();
            if (initialPrice > 0)
            {
                //this._initialPrice = initialPrice;
                this._stockPrices.Add(timeStamp, initialPrice);
            }
            else
            {
                throw new StockExchangeException("Cijena dionica mora biti pozitivna.");
            }
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private Dictionary<string, Stock> _indexStockList;

        public string IndexName { get { return this._indexName; } }

        public IndexTypes IndexType { get { return this._indexType; } }

        public List<Stock> IndexStockList { get { return this._indexStockList.Values.ToList(); } } 

        public Index(string indexName, IndexTypes indexType)
        {
            this._indexName = indexName.ToUpper();
            this._indexType = indexType;
            this._indexStockList = new Dictionary<string, Stock>();
        }

        public void AddStock(Stock stock)
        {
            if (!this._indexStockList.ContainsKey(stock.StockName))
            {
                this._indexStockList.Add(stock.StockName, stock);
            }
            else
            {
                throw new StockExchangeException("Dionica vec postoji u indeksu.");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (this._indexStockList.ContainsKey(stock.StockName))
            {
                this._indexStockList.Remove(stock.StockName);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji u indeksu.");
            }
        }

        public bool ContainsStock(Stock stock)
        {
            if (this._indexStockList.ContainsKey(stock.StockName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int StockCount()
        {
            return this._indexStockList.Count;
        }
    }

    public class Portfolio
    {
        private string _portfolioID;
        private Dictionary<Stock, long> _portfolioStockList;

        public string PortfolioID { get { return this._portfolioID; } }

        public Dictionary<Stock, long> PortfolioStockList { get { return this._portfolioStockList; } } 

        public Portfolio(string portfolioID)
        {
            this._portfolioID = portfolioID;
            this._portfolioStockList = new Dictionary<Stock, long>();
        }

        public bool ContainsStock(Stock stock)
        {
            if (this._portfolioStockList.ContainsKey(stock))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void AddStock(Stock stock, long numberOfShares)
        {
            if (this._portfolioStockList.ContainsKey(stock))
            {
                this._portfolioStockList[stock] += numberOfShares;
            }
            else
            {
                this._portfolioStockList.Add(stock, numberOfShares);
            }
        }

        public void RemoveStock(Stock stock, long numberOfShares)
        {
            if (this._portfolioStockList.ContainsKey(stock))
            {
                if (numberOfShares > this._portfolioStockList[stock])
                {
                    throw new StockExchangeException("Nedovoljno dionica dostupno u portfelju.");
                }
                else
                {
                    this._portfolioStockList[stock] -= numberOfShares;
                    if (this._portfolioStockList[stock] == 0)
                    {
                        this._portfolioStockList.Remove(stock);
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Trazena dionica ne postoji u portfelju.");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (this._portfolioStockList.ContainsKey(stock))
            {
                this._portfolioStockList.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Trazena dionica ne postoji u portfelju.");
            }
        }

        public int StockCount()
        {
            return this._portfolioStockList.Count;
        }

        public long StockShareCount(Stock stock)
        {
            if (_portfolioStockList.ContainsKey(stock))
            {
                return this._portfolioStockList[stock];
            }
            else
            {
                throw new StockExchangeException("Trazena dionica ne postoji u portfelju.");
            }
        }
    }
}
