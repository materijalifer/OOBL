﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    //predstavlja vrijednost dionice u određenom trenutku
     public class StockValue: IComparable
     {
         private decimal value; //vrijednost dionice

         public decimal Value //setteri
         {
             get { return this.value; }
             set { this.value = value; }
         }
         private DateTime time; //datum za koji ta vrijednost vrijedi

         public DateTime Time
         {
             get { return time; }
             set { time = value; }
         }

         public StockValue(decimal inValue, DateTime inTime)
         {
             value = inValue;
             time = inTime;
         }

         //Preopteretio sam ovu funkciju tako da se mogu sortirati vrijednosti, sortira se po DateTime
         public int CompareTo(object obj)
         {
             if(obj is StockValue)
             {
                 StockValue input= (StockValue) obj;
                 //usporedi po vremenu
                 return Time.CompareTo(input.Time);
             }
             throw new ArgumentException();

         }

         //Za usporedbu vrijednosti, olakšava provjeru jel DateTime-Value par već unesen. Dovoljno je da 2 unosa vrijednosti imaju jednak time da budu isti.
         public override bool Equals(object obj)
         {
             if (obj is StockValue)
             {
                 StockValue input = (StockValue)obj;
                 //usporedi vremena, sama vrijednost nije bitna za usporedbu jednakosti
                 return time.Equals(input.time);
             }
             return false;
         }
     }

     //Predstavlja dionicu, jel
     public class Stock
     {
         string name; //ime dionice

         public string Name
         {
             get { return name; }
             set { name = value; }
         }

         long numberOfShares; //broj dionica

         public long NumberOfShares
         {
             get { return numberOfShares; }
             set { numberOfShares = value; }
         }
         
         List<StockValue> values; //lista vrijednosti dionica, par vrijednost-datum. Lista se sortira pa je prvi uvijek s najmanjim datumom, a zadnji s najvecim

         public Stock(string inName, long inNumberOfShares, StockValue inValue)
         {
             if(inName==null || inValue==null)
                 throw new StockExchangeException("Invalid values"); //provjeri jel treba provjeravati
             //Cijena i broj dionica ne mogu biti negativni niti 0
             if(inNumberOfShares<=0) throw new StockExchangeException("Invalid stock number");
             if(inValue.Value<=0) throw new StockExchangeException("Invalid stock value");
             name = inName;
             numberOfShares = inNumberOfShares;
             values = new List<StockValue>();
             values.Add(inValue);
         }

         public void AddValue(StockValue inValue)
         {
             if(inValue.Value<=0) throw new StockExchangeException("Invalid stock value");
             //usporedjuje se po datumu
             if(values.Contains(inValue)) throw new StockExchangeException("Date already added");
             //ako sve valja
             values.Add(inValue);
             values.Sort(); //Nije bitan redoslijed unosa cijena, a ovako je prvi unos prvi, zadnji zadnji.
         }

         /* 
          * Ime dionice predstavlja ključ, tj. specifično je za svaku dionicu. 
          * Kako bi se spriječile pogreške djelatnika ime dionice neovisno je o veličini slova (tj. „ABC“, „abc“ i „AbC“ su iste dionice)
          */ 
         public override bool Equals(object obj)
         {
             if (obj is Stock)
             {
                 Stock input = (Stock)obj;
                 //usporedi ime ali lowercaseano
                 return name.ToLower().Equals(input.name.ToLower());
             }
             return false;
         }

         //Cijena dionice vrijedi od trenutka u kojem je definirana do trenutka definicije sljedeće cijene
         public decimal getStockPrice(DateTime inTime)
         {
             StockValue result=values[0];
             //Ako je inTime prije pocetnog vremena baci exception.
             if (DateTime.Compare(result.Time, inTime) == 1)
                 throw new StockExchangeException("Wrong date.");
             foreach(StockValue value in values)
             {
                 //Kada vrijednost ima veci time od ulaznog onda ta vrijednost vise ne vrijedi pa breakaj
                 if (DateTime.Compare(value.Time, inTime)>0) break;
                 result=value;
             }
             return result.Value;
         }

         //Vraca pocetnu vrijednost dionice.
         internal decimal getInitialStockPrice()
         {
             return values.First().Value;
         }

         //Vraca zadnju vrijednost dionice.
         internal decimal getLastStockPrice()
         {
             return values.Last().Value;
         }
     }

     //Predstavlja index, jel
     public class Index
     {
         string name; //ime indeksa, nije case sensitive

         public string Name
         {
             get { return name; }
             set { name = value; }
         }
         IndexTypes type; //tip indeksa

         public IndexTypes Type
         {
             get { return type; }
             set { type = value; }
         }
         List<Stock> stocks;

        public Index(string inName, IndexTypes inType)
         {
             //Stvaranje indeksa nekog drugog tipa ne smije biti dopušteno u sustavu te je u tom slučaju potrebno obavijestiti korisnika
             if (!(inType.Equals(IndexTypes.AVERAGE) || inType.Equals(IndexTypes.WEIGHTED)))
                 throw new StockExchangeException("Wrong index type.");
             if (inName == null)
                 throw new StockExchangeException("Invalid index name");
             name = inName;
             type = inType;
             stocks = new List<Stock>();
         }

        public void AddStock(Stock inStock)
        {
            //ako dionica vec postoji
            if (stocks.Contains(inStock)) throw new StockExchangeException("Stock already added");
            stocks.Add(inStock);
        }


        //Za naziv indeksa vrijede ista pravila kao i za naziv dionice. 
        public override bool Equals(object obj)
        {
            if (obj is Index)
            {
                Index input = (Index)obj;
                //usporedi po imenu lowercase
                return Name.ToLower().Equals(input.Name.ToLower());
            }
            return false;
        }


        internal void RemoveStock(Stock inStock)
        {
            if (!stocks.Remove(inStock)) throw new StockExchangeException("Stock doesn't exist");
        }

        internal bool ContainsStock(Stock inStock)
        {
            return stocks.Contains(inStock);
        }

        internal int getNumberOfStocks()
        {
            return stocks.Count();
        }

        internal decimal getValue(DateTime inTimeStamp)
        {
            decimal indexValue = 0;

            //Racunanje vrijednosti indexa za average
            if (Type.Equals(IndexTypes.AVERAGE))
            {
                foreach (Stock stock in stocks)
                {
                    indexValue += stock.getStockPrice(inTimeStamp);
                }
                indexValue /= stocks.Count;
            }

            //Racunanje vrijednosti indexa za weighted
            else
            {
                decimal allStockValue = 0;
                foreach (Stock stock in stocks)
                {
                    allStockValue += stock.getStockPrice(inTimeStamp) * stock.NumberOfShares;
                }
                foreach (Stock stock in stocks)
                {
                    indexValue += stock.getStockPrice(inTimeStamp) * stock.getStockPrice(inTimeStamp) * stock.NumberOfShares / allStockValue;
                }
            }
            return indexValue;
        }
     }


     public class Portfolio
     {
         string portfolioID; //ID portfolija. Case sensitive.

         public string PortfolioID
         {
             get { return portfolioID; }
             set { portfolioID = value; }
         }

         //Par dionica-kolicina dionice u portfoliju. Index određene dionice u listi odgovara indexu broja te dionice u listi svih brojeva
         List<Stock> stocks; //dioncice
         List<long> stockNumber; //broj dionica u portfoliju
         public Portfolio(string inPortfolioID)
         {
             if (inPortfolioID == null)
                 throw new StockExchangeException("Invalid portfolio ID.");
             portfolioID = inPortfolioID;
             stockNumber = new List<long>();
             stocks = new List<Stock>();
         }

         //Funkcija koja dodaje dionicu u portfolio. Ako dionica već nije u portfoliju dodati ju po prvi put, ako je samo dodati jos komada
         public void addStock(Stock inStock, long numberOfShares)
         {
             //Ako nema dionice dodati ju i postaviti da ima 0 komada
             if (!stocks.Contains(inStock))
             {
                 stocks.Add(inStock);
                 stockNumber.Add(0);
             }
             int i=stocks.IndexOf(inStock);
             long totalNumberOfStocksInPortfolio = stockNumber[i] + numberOfShares;

             //U slučaju da se pokuša dodati broj dionica veći od ukupnog broja dionica baci exception.
             if (totalNumberOfStocksInPortfolio > stocks[i].NumberOfShares)
                 throw new StockExchangeException("Invalid number of shares to add");
             stockNumber[i] += numberOfShares;
         }

         internal int CountStocks()
         {
             return stocks.Count();
         }

         internal bool ContainStock(Stock inStock)
         {
             return stocks.Contains(inStock);
         }

         //Ova funkcija vraća broj različitih dionica. Ne vraća količinu pojedine dionice.
         internal int getNumberOfStocks()
         {
             return stocks.Count;
         }

         //ID portfelja je ključ te je jedinstven za svaki portfelj
         public override bool Equals(object obj)
         {
             if (obj is Portfolio)
             {
                 Portfolio input = (Portfolio)obj;
                 return PortfolioID.Equals(input.PortfolioID);
             }
             return false;
         }

         //E ova funkcija vraća količinu određene vrste dionice.
         internal long NumberOfShares(Stock inStock)
         {
             //Ako portfolio ne sadrži dionicu.
             if (!stocks.Contains(inStock))
                 throw new StockExchangeException("Stock doesn't exist in portfolio.");
             return stockNumber[stocks.IndexOf(inStock)];
         }
         //Iz portfelja se mogu obrisati sve dionice ili samo određeni broj. Ova funkcija briše određeni broj
         internal void RemoveShares(Stock inStock, long numberOfShares)
         {
             //Ako portfolio ne sadrži dionicu
             if (!ContainStock(inStock)) throw new StockExchangeException("Stock doesn't exist in the portfolio.");
             int i = stocks.IndexOf(inStock);
             //Ako je broj dionica koje treba oduzeti veći od broja koji postoji
             if (stockNumber[i] < numberOfShares) throw new StockExchangeException("Invalid share number");
             stockNumber[i] -= numberOfShares;
             //Ako je nakon oduzimanja ostalo 0 dionica obrisati tu dionicu iz portfolija.
             if (stockNumber[i] == 0)
             {
                 //Brise prvi item s vrijednošću 0 na koji naidje, taj bi trebao biti i jedini
                 stockNumber.Remove(0);
                 stocks.Remove(inStock);
             }
         }

         /*
          * Ova funkcija vraća vrijednost portolija za neki datum.
          * Ako je datum prije onog za koji su navedene vrijednosti SVIH dionica, bacit ce exception.
          * Provjeriti jel treba tako.
          */ 
         internal decimal getValue(DateTime timeStamp)
         {
             decimal value = 0;
             for (int i = 0; i < stocks.Count; i++)
             {
                 value += stockNumber[i] * stocks[i].getStockPrice(timeStamp);
             }
             return value;
         }
     }

    public class StockExchange : IStockExchange
     {
        List<Stock> stocks;
        List<Index> indices;
        List<Portfolio> portfolios;

        public StockExchange()
        {
            stocks = new List<Stock>();
            indices = new List<Index>();
            portfolios = new List<Portfolio>();
        }

         /*
          * Dodaje dionicu s početnom cijenom na burzu.
          * Ako dionica vec postoji baca exception. Ako su vrijednosti za dionicu krivi, također baca exception.
          */ 
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock inStock = new Stock(inStockName, inNumberOfShares, new StockValue(inInitialPrice, inTimeStamp));
             if(StockExists(inStockName)) throw new StockExchangeException("Stock already exists");
             stocks.Add(inStock);
         }

         /*
          * Briše dionicu s burze.
          * Ako dionica ne postoji baca exception. Provjeriti jel treba tako.
          */ 
         public void DelistStock(string inStockName)
         {
             Stock inStock = findStockByName(inStockName);
             //Obrisi tu dionicu iz svih indeksa
             foreach(Index index in indices)
                 this.RemoveStockFromIndex(index.Name,inStockName);
             //Obrisi tu dionicu iz svih portfelja
             foreach(Portfolio portfolio in portfolios)
                 this.RemoveStockFromPortfolio(portfolio.PortfolioID,inStockName);
             stocks.Remove(inStock);
         }

         /*
          * Privatna funkcija koja pronalazi dionicu po imenu.
          * Ako dionica ne postoji baca exception.
          */ 
         Stock findStockByName(string inStockName)
         {
             //Ako dionica ne postoji baci exception
             if (!StockExists(inStockName)) throw new StockExchangeException("Stock doesn't exist");
             //Nadji dionicu po imenu
             return stocks.Find(delegate(Stock stock)
             {
                 return stock.Name.Equals(inStockName);
             });
         }
         
        /*
         * Provjerava postoji li tražena dionica na burzi.
         */ 
        public bool StockExists(string inStockName)
         {
             //Pošto su 2 dionice jednake ako su im jednaka imena, ostatak nije ni bitan.
             Stock inStock = new Stock(inStockName, 1, new StockValue(1, DateTime.Now));
             return stocks.Contains(inStock);
         }

        /*
         * Vraća broj dionica na burzi. Dakle koliko ih ima različitih sveukupno.
         */
        public int NumberOfStocks()
         {
             return stocks.Count;
         }

         /*
          * Postavlja cijenu dionice za određeno vrijeme.
          * Ako dionica ne postoji baca exception. Ako su vrijednosti krive opet baca exception.
          */ 
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             //Ovaj ce baciti ako nema dionice.
             Stock stock = findStockByName(inStockName);
             //Ovaj ce baciti ako su vrijednosti krive.
             stock.AddValue(new StockValue(inStockValue, inIimeStamp));
         }

         /*
          * Dohvaća cijenu dionice za neko vrijeme.
          * Ako dionica ne postoji baca exception.
          * Ako je vrijeme prije vremena za koji dionica ima vrijednost opet baca exception.
          */ 
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             //Ovaj ce baciti ako nema dionice.
             Stock stock = findStockByName(inStockName);
             //Ovaj ce baciti ako je vrijeme krivo. Zaokruziti na 3 decimale (iako mozda ne treba, provjeriti).
             return decimal.Round(stock.getStockPrice(inTimeStamp),3);
         }

        
         /*
          * Dohvaća početnu cijenu dionice.
          * Ako dionica ne postoji baca exception.
          */ 
         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = findStockByName(inStockName);
             //zaokruzi na 3 decimale
             return decimal.Round(stock.getInitialStockPrice(),3);
         }

         /*
          * Dohvaća zadnju cijenu dionice.
          * Ako dionica ne postoji baca exception.
          */ 
         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = findStockByName(inStockName);
             return decimal.Round(stock.getLastStockPrice(),3);
         }

         /*
          * Stvara novi indeks na burzi.
          * Ako indeks vec postoji baca exception.
          */ 
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index inIndex = new Index(inIndexName,inIndexType);
             //Ako vec postoji baci exception.
             if (IndexExists(inIndexName)) throw new StockExchangeException("Index already exists");
             indices.Add(inIndex);
         }
         
         /*
          * Ova funkcija pronalazi indeks po imenu.
          * Ako indeks ne postoji baca exception.
          */ 
         Index findIndexByName(string inIndexName)
         {
             if (!IndexExists(inIndexName)) 
                 throw new StockExchangeException("Index doesn't exist");
             {
                 return indices.Find(delegate(Index index)
                 {
                     return index.Name.Equals(inIndexName);
                 });
             }
         }

         /*
          * Dodaje dionicu u indeks.
          * Ako index ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          */
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index inIndex = findIndexByName(inIndexName);
             Stock inStock = findStockByName(inStockName);
             inIndex.AddStock(inStock);

         }

         /*
          * Briše dionicu iz indeksa.
          * Ako index ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          */ 
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index inIndex = findIndexByName(inIndexName);
             Stock inStock = findStockByName(inStockName);
             inIndex.RemoveStock(inStock);
         }

         /*
          * Provjerava je li dionica u indeksu
          */
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index inIndex = findIndexByName(inIndexName);
             Stock inStock = findStockByName(inStockName);
             return inIndex.ContainsStock(inStock);
         }

         /*
          * Dohvaća vrijednost indeksa u nekom trenutku. 
          * Ako indeks ne postoji baca exception.
          * Ako je trenutak takav da postoji dionica za koju u tom trenutku nije definirana vrijednost baca exception.
          */ 
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index inIndex = findIndexByName(inIndexName);
             return decimal.Round(inIndex.getValue(inTimeStamp),3);
         }

         /*
          * Provjerava postoji li traženi indeks na burzi.
          */ 
         public bool IndexExists(string inIndexName)
         {
             //Samo je ime vazno, tip nebitan.
             return indices.Contains(new Index(inIndexName, IndexTypes.AVERAGE));
         }
         /*
          * Dohvaća broj indeksa na burzi.
          */ 
         public int NumberOfIndices()
         {
             return indices.Count();
         }

         /*
          * Dohvaća broj dionica u traženom indeksu.
          * Ako indeks ne postoji baca exception.
          */
         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index inIndex = findIndexByName(inIndexName);
             return inIndex.getNumberOfStocks();
         }

         /*
          * Stvara novi portfolio na burzi.
          * Ako portfolio vec postoji baca exception.
          */
         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio inPortfolio= new Portfolio (inPortfolioID);
             if(PortfolioExists(inPortfolioID)) 
                 throw new StockExchangeException("Portfolio already exists.");
             portfolios.Add(inPortfolio);
         }

         /*
          * Privatna funkcija koja pronalazi portfolio po imenu.
          * Ako portfolio ne postoji baca exception.
          */
         Portfolio findPortfolioByName(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID)) 
                 throw new StockExchangeException("Portfolio doesn't exist.");
             {
                 return portfolios.Find(delegate(Portfolio portfolio)
                 {
                     return portfolio.PortfolioID.Equals(inPortfolioID);
                 });
             }
         }

         /*
          * Dodaje određeni broj dionica u portfolio.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          * Ako dionica ne postoji u portfoliu dodat će ju.
          * Ako je broj dionica u svim portfolijima uvećan za novi broj dionica veći od ukupnog broja dionica baca exception.
          */
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock inStock = findStockByName(inStockName);
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             //Postavi ukupan broj dionica na default veličinu za tu dionicu.
             long totalNumberOfShares = inStock.NumberOfShares;
             //Za svaki portfolio koji ima tu dionicu oduzmi njegov broj dionica.
             foreach (Portfolio portfolio in portfolios)
             {
                 if(portfolio.ContainStock(inStock))
                     totalNumberOfShares-=portfolio.NumberOfShares(inStock);
             }
             //Ako je još ostalo manje dionica od broja kojeg želimo dodati broj je kriv pa baci exception
             if (totalNumberOfShares < numberOfShares)
                 throw new StockExchangeException("Invalid number of shares");
             //Ako dodje do ovdje sve je ok - dodaj dionicu
             inPortfolio.addStock(inStock, numberOfShares);
         }

         /*
          * Oduzima određeni broj dionica iz portfolija.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          * Ako je broj dionica koje treba maknuti veci od broja koji postoji u portfoliu baca exception.
          */
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock inStock = findStockByName(inStockName);
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             inPortfolio.RemoveShares(inStock, numberOfShares);
         }

         /*
          * Oduzima određeni broj dionica iz portfolija.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          */
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Stock inStock = findStockByName(inStockName);
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             //Oduzmi sve dionice iz portfolia sto ce automatski obrisati dionicu iz njega.
             inPortfolio.RemoveShares(inStock, inPortfolio.NumberOfShares(inStock));
         }

         /*
          * Dohvaća broj krumpira na burzi
          */
         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         /*
          * Dohvaća broj dionica u traženom portfoliju.
          * Ako portfolio ne postoji baca exception.
          */
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             return inPortfolio.CountStocks();
         }

         /*
          * Provjerava postoji li traženi portfolio na burzi.
          */
         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.Contains(new Portfolio(inPortfolioID));
         }

         /*
          * Provjerava nalazi li se dionica u portfoliju.
          * Ako dionica uopce ne postoji baca exception.
          */
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             Stock inStock = findStockByName(inStockName);
             return inPortfolio.ContainStock(inStock);
         }

         /*
          * Dohvaća broj dionice u traženom portfoliju.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          */
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             Stock inStock = findStockByName(inStockName);
             //Ova funkcija bi trebala vracati long, ne int
             return (int)inPortfolio.NumberOfShares(inStock);
         }

         /*
          * Dohvaća vrijednost portfolija u određenom trenutku.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          * Ako je datum takav da postoji dionica koja nema definiranu vrijednost za taj datum baca exception.
          */
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio inPortfolio = findPortfolioByName(inPortfolioID);
             return decimal.Round(inPortfolio.getValue(timeStamp),3);
         }

         /*
          * Dohvaća mjesecnu promjenu vrijednosti portfolija.
          * Ako portfolio ne postoji baca exception.
          * Ako dionica ne postoji baca exception.
          * Ako je datum takav da postoji dionica koja nema definiranu vrijednost za taj datum baca exception.
          */
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             //Prvi dan u mjesecu
             DateTime monthStart = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             DateTime monthEnd = new DateTime(Year, Month +1 , 1, 0, 0, 0, 0);
             //Nakon ovoga zadnja milisekunda u mjesecu
             monthEnd = monthEnd.AddMilliseconds(-1);
             decimal monthStartValue = GetPortfolioValue(inPortfolioID, monthStart);
             decimal monthEndValue = GetPortfolioValue(inPortfolioID, monthEnd);
             //Izracun promjene
             decimal change = (monthEndValue - monthStartValue) / monthStartValue * 100;
             //Zaokruziti na 3 decimale
             return decimal.Round(change, 3);
         }
     }
}
