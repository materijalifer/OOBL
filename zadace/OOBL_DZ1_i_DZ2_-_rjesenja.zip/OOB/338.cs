using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza {

    public static class Factory {
        public static IStockExchange CreateStockExchange() {
            return new StockExchange();
        }
    }

    /* STOCK EXCHANGE CLASS AND REQUIREMENTS
     * Burza je osnovni objekt te se na njoj trguje odre�enim skupom dionica, �ija se cijena formira na tr�i�tu 
     * (i za na� sustav je eksterni faktor � zna�i, unosi se �izvana�!). 
     * Na burzi postoji odre�eni broj svake �vrste� dionice (npr. Postoje 4 �IBM� dionice �ija je cijena 100). 
     * Osnovna namjena sustava izra�unavanje je vrijednosti indeksa definiranih u sustavu. 
     * Indeks mo�e sadr�avati samo onu dionicu koja postoji na burzi.
     * Dionicu je u svakom trenutku mogu�e maknuti s burze. 
     * Ime dionice predstavlja klju�, tj. specifi�no je za svaku dionicu. 
     * Kako bi se sprije�ile pogre�ke djelatnika ime dionice neovisno je o veli�ini slova (tj. �ABC�, �abc� i �AbC� su iste dionice). 
     * Na burzi se prate i portfelji. Burza mo�e sadr�avati vi�e portfelja. 
     */
    public class StockExchange : IStockExchange {

        public const int ROUNDUP_DECIMALS = 3;

        #region PRIVATE MEMBERS

        private List<Stock> _stocks;
        private List<IIndex> _indices;
        private List<IPortfolio> _portfolios;

        #endregion

        #region PRIVATE GETTERS AND SETTERS

        private List<Stock> Stocks { get { return this._stocks; } set { this._stocks = value; } }
        private List<IIndex> Indices { get { return this._indices; } set { this._indices = value; } }
        private List<IPortfolio> Portfolios { get { return this._portfolios; } set { this._portfolios = value; } }

        #endregion

        #region PUBLIC INTERFACE

        public StockExchange() {
            this.Stocks = new List<Stock>();
            this.Indices = new List<IIndex>();
            this.Portfolios = new List<IPortfolio>();
        }

        #region STOCKS

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp) {
            if(StockExists(inStockName)) {
                throw new StockExchangeException("Stock is already in the stock exchange system!");
            }

            try {
                Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                this.Stocks.Add(newStock);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.ListStock() -> " + e.Msg);
            }
        }

        public void DelistStock(string inStockName) {
            if(!StockExists(inStockName)) {
                throw new StockExchangeException("Stock doesn't exist on the market!");
            }

            foreach(IIndex index in Indices) {
                if(index.HasStock(inStockName)) {
                    index.RemoveStock(inStockName);
                }
            }

            foreach(IPortfolio portfolio in Portfolios) {
                if(portfolio.HasStock(inStockName)) {
                    portfolio.RemoveStock(inStockName);
                }
            }

            for(int i = 0; i < Stocks.Count; i++) {
                if(Stocks[i].CompareByName(inStockName)) {
                    this.Stocks.RemoveAt(i);
                    break;
                }
            }

        }

        public bool StockExists(string inStockName) {
            foreach(Stock stock in this.Stocks) {
                if(stock.CompareByName(inStockName)) return true;
            }
            return false;
        }

        public int NumberOfStocks() {
            return this.Stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue) {
            try {
                Stock stock = GetStockByName(inStockName);
                stock.SetPrice(inStockValue, inTimeStamp);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.SetStockPrice() -> " + e.Msg);
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp) {
            try {
                Stock stock = GetStockByName(inStockName);
                return stock.GetPrice(inTimeStamp);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.GetStockPrice() -> " + e.Msg);
            }
        }

        public decimal GetInitialStockPrice(string inStockName) {
            try {
                Stock stock = GetStockByName(inStockName);
                return stock.GetInitialPrice();
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.GetInitialStockPrice() -> " + e.Msg);
            }
        }

        public decimal GetLastStockPrice(string inStockName) {
            try {
                Stock stock = GetStockByName(inStockName);
                return stock.GetLastPrice();
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.GetLastStockPrice() -> " + e.Msg);
            }
        }

        #endregion

        #region INDICES

        public void CreateIndex(string inIndexName, IndexTypes inIndexType) {
            if(IndexExists(inIndexName)) {
                throw new StockExchangeException("Index already exists!");
            }

            try {
                IIndex newIndex = IndexFactory.CreateIndexByType(inIndexName, inIndexType);
                this.Indices.Add(newIndex);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.CreateIndex() -> " + e.Msg);
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName) {
            try {
                Stock stock = GetStockByName(inStockName);
                IIndex index = GetIndexByName(inIndexName);
                index.AddStock(stock);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.AddStockToIndex() -> " + e.Msg);
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName) {
            if(!StockExists(inStockName)) {
                throw new StockExchangeException("Stock doesn't exist on the market!");
            }

            try {
                IIndex index = GetIndexByName(inIndexName);
                index.RemoveStock(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.RemoveStockFromIndex() -> " + e.Msg);
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName) {
            try {
                IIndex index = GetIndexByName(inIndexName);
                return index.HasStock(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.IsStockPartOfIndex() -> " + e.Msg);
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp) {
            try {
                IIndex index = GetIndexByName(inIndexName);
                return index.GetValue(inTimeStamp);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.IsStockPartOfIndex() -> " + e.Msg);
            }
        }

        public bool IndexExists(string inIndexName) {
            foreach(IIndex index in this.Indices) {
                if(index.CompareByName(inIndexName)) return true;
            }
            return false;
        }

        public int NumberOfIndices() {
            return this.Indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName) {
            try {
                IIndex index = GetIndexByName(inIndexName);
                return index.NumberOfStocks();
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.NumberOfStocksInIndex() -> " + e.Msg);
            }
        }

        #endregion

        #region PORTFOLIOS

        public void CreatePortfolio(string inPortfolioID) {
            if(PortfolioExists(inPortfolioID)) {
                throw new StockExchangeException("Portfolio with same ID already exist!");
            }
            try {
                Portfolio newPortfolio = new Portfolio(inPortfolioID);
                this.Portfolios.Add(newPortfolio);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.CreatePortfolio() -> " + e.Msg);
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int inNumberOfShares) {

            try {
                Stock stock = GetStockByName(inStockName);
                if(NumberOfSharesOfStockInAllPortfolios(inStockName) + inNumberOfShares > stock.NumOfShares) {
                    throw new StockExchangeException("There's not enaugh shares of stock on the market for this action!");
                }
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                portfolio.AddStock(stock, inNumberOfShares);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.AddStockToPortfolio() -> " + e.Msg);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int inNumberOfShares) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                portfolio.RemoveStock(inStockName, inNumberOfShares);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio() -> " + e.Msg);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                portfolio.RemoveStock(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.RemoveStockFromPortfolio() -> " + e.Msg);
            }
        }

        public int NumberOfPortfolios() {
            return this.Portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                return portfolio.NumberOfStocks();
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.NumberOfStocksInPortfolio() -> " + e.Msg);
            }
        }

        public bool PortfolioExists(string inPortfolioID) {
            foreach(Portfolio p in this.Portfolios) {
                if(p.CompareId(inPortfolioID)) return true;
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                return portfolio.HasStock(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.IsStockPartOfPortfolio() -> " + e.Msg);
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                return portfolio.NumberOfSharesOfStock(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.NumberOfSharesOfStockInPortfolio() -> " + e.Msg);
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime inTimeStamp) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                return portfolio.GetValue(inTimeStamp);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.GetPortfolioValue() -> " + e.Msg);
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int inYear, int inMonth) {
            try {
                IPortfolio portfolio = GetPortfolioByID(inPortfolioID);
                return portfolio.GetPercentChangeForMonth(inYear, inMonth);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.GetPortfolioPercentChangeInValueForMonth() -> " + e.Msg);
            }
        }

        #endregion


        #region PUBLIC DEBUG

        public string PrintAllStocks() {
            string res = "";
            foreach(Stock s in this.Stocks) {
                res += s.Print();
            }
            return res;
        }

        public string PrintAllIndices() {
            string res = "";
            foreach(IIndex index in this.Indices) {
                res += index.Print();
            }
            return res;
        }

        public string PrintAllPortfolios() {
            string res = "";
            foreach(IPortfolio portfolio in this.Portfolios) {
                res += portfolio.Print();
            }
            return res;
        }

        #endregion

        #endregion

        #region PRIVATE METHODS

        private Stock GetStockByName(string inStockName) {
            if(!StockExists(inStockName)) {
                throw new StockExchangeException("Stock doesn't exist!");
            }

            int stockIndex = -1;
            for(int i = 0; i < this.Stocks.Count; i++) {
                if(this.Stocks[i].CompareByName(inStockName)) stockIndex = i;
            }
            return this.Stocks[stockIndex];
        }

        private IIndex GetIndexByName(string inIndexName) {
            if(!IndexExists(inIndexName)) {
                throw new StockExchangeException("Index doesn't exist!");
            }

            int indexIndex = -1;
            for(int i = 0; i < this.Indices.Count; i++) {
                if(this.Indices[i].CompareByName(inIndexName)) indexIndex = i;
            }
            return this.Indices[indexIndex];
        }

        private IPortfolio GetPortfolioByID(string inPortfolioID) {
            if(!PortfolioExists(inPortfolioID)) {
                throw new StockExchangeException("Portfolio doesn't exist!");
            }

            int portfolioIndex = -1;
            for(int i = 0; i < this.Portfolios.Count; i++) {
                if(this.Portfolios[i].CompareId(inPortfolioID)) portfolioIndex = i;
            }
            return this.Portfolios[portfolioIndex];
        }

        private int NumberOfSharesOfStockInAllPortfolios(string inStockName) {
            try {
                int numOfShares = 0;
                foreach(IPortfolio portfolio in this.Portfolios) {
                    if(portfolio.HasStock(inStockName)) {
                        numOfShares += portfolio.NumberOfSharesOfStock(inStockName);
                    }
                }
                return numOfShares;
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("StockExchange.NumberOfSharesOfStockInAllPortfolios() -> " + e.Msg);
            }
        }

        #endregion

    }

    /* STOCK PRICE FOR SPECIFIC DATE USED IN STOCK CLASS FOR PRICE HISTORY
     */
    public class StockPrice {

        private decimal _value;
        private DateTime _timestamp;

        public decimal Value {
            get { return this._value; }
            set {
                if(value <= 0) {
                    throw new StockExchangeException("Stock price must be greater than zero!");
                }
                this._value = Math.Round(value, 3);
            }
        }

        public DateTime Timestamp {
            get { return this._timestamp; }
            set { this._timestamp = value; }
        }

        public StockPrice(decimal inPrice, DateTime inTimestamp) {
            this.Value = inPrice;
            this.Timestamp = inTimestamp;
        }

        public static int CompareTimestamp(StockPrice sp1, StockPrice sp2) {
            if(sp1.Timestamp < sp2.Timestamp) return -1;
            else if(sp1.Timestamp == sp2.Timestamp) return 0;
            else return 1;
        }

        public static int CompareValues(StockPrice sp1, StockPrice sp2) {
            if(sp1.Value < sp2.Value) return -1;
            else if(sp1.Value == sp2.Value) return 0;
            else return 1;
        }

    }

    /* STOCK CLASS AND GIVEN REQUIREMENTS
     * Prilikom dodavanja neke dionice na burzu za dionicu se definira ime, broj tih dionica, po�etna cijena i trenutak od kojeg ta cijena vrijedi. 
     * Za svaku se dionicu u odre�enim trenucima bilje�i cijena.
     * Cijena dionice vrijedi od trenutka u kojem je definirana do trenutka definicije sljede�e cijene. 
     * Nije bitan redoslijed unosa cijena, ali za odre�eni trenutak nije mogu�e unijeti vi�e zapisa cijena. 
     * Nije potrebno provoditi provjere trenutaka unosa cijena kao �to bi bilo provjera je li uneseni trenutak < DateTime.Now. 
     * Pretpostavlja se da se cijena mo�e unijeti za svaki trenutak. 
     * Granularnost definicije vremena je 1ms, tj. unose se datum i vrijeme uklju�uju�i milisekunde. 
     * Cijena i broj dionica ne mogu biti negativni niti 0.
     */
    public class Stock {

        private string _name;
        private long _numOfShares;
        private List<StockPrice> _priceHistory;

        public string Name {
            get { return this._name; }
            private set {
                if(value.Length <= 0) {
                    throw new StockExchangeException("Stock name must be set!");
                }
                this._name = value;
            }
        }
        public long NumOfShares {
            get {
                return this._numOfShares;
            }
            private set {
                if(value <= 0) {
                    throw new StockExchangeException("Number of shares for stock must be greater than zero!");
                }
                this._numOfShares = value;
            }
        }
        public List<StockPrice> PriceHistory {
            get {
                return this._priceHistory;
            }
            private set {
                this._priceHistory = value;
            }
        }

        public Stock(string inName, long inNumOfShares, decimal inInitialPrice, DateTime inTimeStamp) {
            this.Name = inName;
            this.NumOfShares = inNumOfShares;
            this.PriceHistory = new List<StockPrice>();
            SetPrice(inInitialPrice, inTimeStamp);
        }

        public void SetPrice(decimal inPrice, DateTime inTimeStamp) {
            if(inPrice <= 0) {
                throw new StockExchangeException("Stock price must be greater than zero!");
            }
            foreach(StockPrice price in this.PriceHistory) {
                if(price.Timestamp == inTimeStamp) {
                    throw new StockExchangeException("Stock price is already set for given timestamp!");
                }
            }
            this.PriceHistory.Add(new StockPrice(Math.Round(inPrice, StockExchange.ROUNDUP_DECIMALS), inTimeStamp));
            SortPricesByDate();
        }

        public decimal GetPrice(DateTime inTimestamp) {
            if(this.PriceHistory.Count <= 0) {
                throw new StockExchangeException("Stock doesn't have initial price set!");
            }

            bool timestampInPriceInterval = inTimestamp > this.PriceHistory[0].Timestamp;
            if(!timestampInPriceInterval) {
                throw new StockExchangeException("Stock price is not set for give timestamp!");
            }

            for(int i = 0; i < this.PriceHistory.Count - 1; i++) {
                if(inTimestamp >= this.PriceHistory[i].Timestamp && inTimestamp < this.PriceHistory[i + 1].Timestamp) {
                    return this.PriceHistory[i].Value;
                }
            }
            return this.GetLastPrice();
        }

        public decimal GetInitialPrice() {
            return this.PriceHistory[0].Value;
        }

        public decimal GetLastPrice() {
            int lastIndex = this.PriceHistory.Count - 1;
            return this.PriceHistory[lastIndex].Value;
        }

        public bool CompareTo(Stock inStock) {
            return CompareByName(inStock.Name);
        }

        public bool CompareByName(string inStockName) {
            if(this.Name.ToUpper() == inStockName.ToUpper()) return true;
            else return false;
        }

        public string Print() {
            string res = "\n" + this.Name + ", Number of shares: " + this.NumOfShares + "\n------------------------------------\n";
            foreach(StockPrice sp in this.PriceHistory) {
                res += "\t" + sp.Timestamp + " -> " + sp.Value + "\n";
            }
            return res;
        }

        private void SortPricesByDate() {
            this.PriceHistory.Sort(new Comparison<StockPrice>(StockPrice.CompareTimestamp));
        }

    }

    /* INDICES REQUIREMENTS AND INTERFACE IMPLEMENTATION
     * Prilikom dodavanja nekog indeksa na burzu za indeks se definiraju naziv i tip. 
     * Vrijednosti mogu�ih tipova indeksa definirane su enumom: AVERAGE, WEIGHTED.
     * Stvaranje indeksa nekog drugog tipa ne smije biti dopu�teno u sustavu te je u tom slu�aju potrebno obavijestiti korisnika. 
     * Za naziv indeksa vrijede ista pravila kao i za naziv dionice. 
     * Naziv indeksa je klju� bez obzira na tip indeksa.
     * Indeksu se pridjeljuju dionice. 
     * Ista dionica smije se samo jednom pridijeliti indeksu. 
     * Na temelju tih dionica ra�unaju se vrijednosti indeksa za odre�eni trenutak. 
     * Rezultate izra�una potrebno je zaokru�iti na 3 decimale.
     * Dionice se u svakom trenutku mogu izbaciti iz indeksa (�ime se NE bri�u s burze). U tom slu�aju sustav se pona�a kao da dionice nikada 
     * nisu bile u indeksu, tj. nije potrebno pamtiti povijesne podatke o vrijednostima kada su dionice jo� bile u indeksu. */
    public interface IIndex {

        string GetName();
        decimal GetValue(DateTime inTimeStamp);
        void AddStock(Stock inStock);
        void RemoveStock(string inStockName);
        bool HasStock(string inStockName);
        int NumberOfStocks();
        bool CompareTo(IIndex inIndex);
        bool CompareByName(string inIndexName);
        //DEBUG
        string Print();

    }

    /* ABSTRACT INDEX CLASS
     * Catches all exceptions, wraps them and throws them again to be caught in parent class.
     */
    public abstract class Index : IIndex {

        private string _name;
        private decimal _value;
        private List<Stock> _stocks;

        protected string Name {
            get { return this._name; }
            set {
                if(value.Length <= 0) {
                    throw new StockExchangeException("Index name must be set!");
                }
                this._name = value;
            }
        }
        protected decimal Value {
            get { return this._value; }
            set {
                if(value < 0) {
                    throw new StockExchangeException("Index value must be greater or equal to zero!");
                }
                this._value = Math.Round(value, StockExchange.ROUNDUP_DECIMALS);
            }
        }
        protected List<Stock> Stocks {
            get { return this._stocks; }
            set { this._stocks = value; }
        }

        public Index(string inIndexName) {
            this.Name = inIndexName;
            this.Value = 0;
            this.Stocks = new List<Stock>();
        }

        public string GetName() {
            return this.Name;
        }

        public decimal GetValue(DateTime inTimeStamp) {
            CalculateValue(inTimeStamp);
            return this.Value;
        }

        public void AddStock(Stock inStock) {
            if(HasStock(inStock)) {
                throw new StockExchangeException("Stock is already in this index!");
            }
            this.Stocks.Add(inStock);
        }

        public void RemoveStock(string inStockName) {
            int stockIndex;
            try {
                stockIndex = GetStockIndex(inStockName);
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Index.RemoveStock() -> " + e.Msg);
            }
            this.Stocks.RemoveAt(stockIndex);
        }

        public bool HasStock(string inStockName) {
            foreach(Stock stock in this.Stocks) {
                if(stock.CompareByName(inStockName)) return true;
            }
            return false;
        }

        public int NumberOfStocks() {
            return this.Stocks.Count;
        }

        public bool CompareTo(IIndex inIndex) {
            return CompareByName(inIndex.GetName());
        }

        public bool CompareByName(string inIndexName) {
            if(this.Name.ToUpper() == inIndexName.ToUpper()) return true;
            return false;
        }

        public string Print() {
            string res = this.Name + ", value = " + this.Value + ", num of stocks = " + this.Stocks.Count + "\n-------------------------------\n\t";
            foreach(Stock stock in this.Stocks) res += stock.Name + " ";
            return "\n" + res + "\n";
        }

        protected abstract void CalculateValue(DateTime inTimeStamp);

        protected bool HasStock(Stock inStock) {
            return HasStock(inStock.Name);
        }

        protected int GetStockIndex(string inStockName) {
            for(int i = 0; i < this.Stocks.Count; i++) {
                if(this.Stocks[i].CompareByName(inStockName)) return i;
            }
            throw new StockExchangeException("Stock is not found in this index!");
        }

    }

    /* INDEX FACTORY FOR CREATING INDEX DEFINED BY ENUM IndexType
     */
    public static class IndexFactory {

        public static IIndex CreateIndexByType(string inIndexName, IndexTypes inType) {
            switch(inType) {
                case IndexTypes.AVERAGE:
                    return new AverageIndex(inIndexName);
                case IndexTypes.WEIGHTED:
                    return new WeightedIndex(inIndexName);
                default:
                    throw new StockExchangeException("Wrong index type!");
            }
        }

    }

    /* AVERAGE INDEX CLASS AND CALCULATION EXPLANATION
     * Vrijednost indeksa se ra�una kao jednostavan prosjek cijene svih dionica u indeksu */
    public class AverageIndex : Index {

        public AverageIndex(string inIndexName)
            : base(inIndexName) {
        }

        protected override void CalculateValue(DateTime inTimeStamp) {
            decimal sum = 0;
            decimal numOfStocks = 0;
            try {
                foreach(Stock stock in this.Stocks) {
                    sum += (stock.GetPrice(inTimeStamp) * stock.NumOfShares);
                    numOfStocks += stock.NumOfShares;
                }
                if(numOfStocks > 0) {
                    this.Value = sum / numOfStocks;
                }
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("AverageIndex.CalculateValue() -> " + e.Msg);
            }
        }

    }

    /* WEIGHTED INDEX CLASS AND CALCULATION EXPLANATION
     * Vrijednost indeksa se ra�una kao te�inski prosjek cijene svih dionica u indeksu, 
     * gdje je te�inski faktor za pojedinu dionicu definiran kao omjer ukupne vrijednosti te dionice na burzi (cijena dionice * broj dionica) 
     * i ukupne vrijednosti svih dionica unutar indeksa. */
    public class WeightedIndex : Index {

        public WeightedIndex(string inIndexName)
            : base(inIndexName) {
        }

        protected override void CalculateValue(DateTime inTimeStamp) {
            decimal weightedSum = 0;
            decimal totalSum = 0;
            try {
                foreach(Stock stock in this.Stocks) {
                    decimal stockPrice = stock.GetPrice(inTimeStamp);
                    totalSum += (stockPrice * stock.NumOfShares);
                }

                if(totalSum == 0) return;

                foreach(Stock stock in this.Stocks) {
                    decimal stockPrice = stock.GetPrice(inTimeStamp);
                    decimal weightFactor = stockPrice / totalSum;
                    weightedSum += (weightFactor * stockPrice * stock.NumOfShares);
                }
                this.Value = weightedSum;
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("AverageIndex.CalculateValue() -> " + e.Msg);
            }
        }

    }

    /* STOCK WRAPPER FOR USAGE IN PORTFOLIO CLASS 
     */
    class PortfolioStock {

        private Stock _stock;
        private int _numberOfShares;

        public PortfolioStock(Stock inStock, int inNumOfShares) {
            if(inNumOfShares > inStock.NumOfShares) {
                throw new StockExchangeException("PortfolioStock -> Number of shares in portfolio is larger than number of shares of stock in whole stock exchange system!");
            }
            this.Stock = inStock;
            this.NumberOfShares = inNumOfShares;
        }

        private Stock Stock {
            get {
                return this._stock;
            }
            set {
                this._stock = value;
            }
        }
        private int NumberOfShares {
            get {
                return this._numberOfShares;
            }
            set {
                if(value <= 0) {
                    throw new StockExchangeException("PortfolioSTock -> Number of shares of stock in portfolio must be greater than zero!");
                }
                if(value > this.Stock.NumOfShares) {
                    throw new StockExchangeException("PortfolioStock -> Number of shares in portfolio must be lower or equal than total number of shares on the market!");
                }
                this._numberOfShares = value;
            }
        }

        public void AddNumberOdShares(int numOfSharesToAdd) {
            this.NumberOfShares = this.NumberOfShares + numOfSharesToAdd;
        }

        public void SubstractNumberOfShares(int numOfSharesToSubstract) {
            this.NumberOfShares = this.NumberOfShares - numOfSharesToSubstract;
        }

        public int GetNumberOfSharesInPortfolio() {
            return this.NumberOfShares;
        }

        public long GetNumberOfSharesOnTheMarket() {
            return this.Stock.NumOfShares;
        }

        public string GetStockName() {
            return this.Stock.Name;
        }

        public decimal GetStockPrice(DateTime inTimeStamp) {
            return this.Stock.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice() {
            return this.Stock.GetInitialPrice();
        }

        public decimal GetLastStockPrice() {
            return this.Stock.GetLastPrice();
        }

        public bool CompareStockByName(string inStockName) {
            return this.Stock.CompareByName(inStockName);
        }

        public string Print() {
            string res = this.Stock.Name + ", Total num of shares = " + this.Stock.NumOfShares + ", Num of shares in portfolio = " + this.NumberOfShares;
            return res;
        }


    }

    /* PORTFOLIO REQUIREMENTS AND INTERFACE IMPLEMENTATION
     * 
     * Prilikom stvaranja portfelja definira se samo ID tog portfelja. ID portfelja je klju� te je jedinstven za svaki portfelj.
     * Ovdje ne vrijedi pravilo slova kao kod dionica i indeksa.
     * 
     * Portfelju se dodaje odre�eni broj dionica (s time da je jasno da suma broja dionica u svim portfeljima ne mo�e biti ve�a od 
     * ukupnog broja izdanih dionica za svaku pojedina�nu dionicu). 
     * 
     * Iz portfelja se mogu obrisati sve dionice ili samo odre�eni broj. 
     * 
     * Portfelj ne mo�e sadr�avati 0 dionica te je u takvom slu�aju potrebno obrisati dionicu iz portfelja. U tom slu�aju vrijedi isto 
     * pravilo kao i kod indeksa (ne pamte se povijesne vrijednosti ve� se pona�a kao da obrisane dionice nisu nikad ni bile dio portfelja).
     * 
     * Vrijednost portfelja ra�una se kao ukupna vrijednost svih dionica koje korisnik dr�i u tom portfelju u nekom trenutku.
     * 
     * Osim vrijednosti portfelja ra�una se i postotak mjese�ne promjene vrijednosti portfelja. Vrijednost se prikazuje u postocima, tj. 
     * mno�i se sa 100 (40% se prikazuje kao 40) i promjena vrijednost se ra�una u odnosu na po�etak mjeseca. Da bi se mogao izra�unati
     * postotak mjese�ne promjene vrijednosti portfelja potrebno je imati definiranu cijenu SVIH dionica u portfelju za po�etni i zadnji 
     * dan u mjesecu za koji se tra�i ta vrijednost (uzeti vrijednost dionica prvog dana u 00:00:00 i zadnjeg dana u 23:59:59:999). 
     * Sve vrijednosti potrebno je zaokru�iti na 3 decimale. 
     * 
     * Dionice se u svakom trenutku mogu izbaciti iz portfelja. 
     */
    interface IPortfolio {

        void AddStock(Stock inStock, int inNumberOfShares);
        void RemoveStock(string inStockName);
        void RemoveStock(string inStockName, int inNumberOfShares);
        int NumberOfStocks();
        bool HasStock(string inStockName);
        int NumberOfSharesOfStock(string inStockName);
        decimal GetValue(DateTime inTimeStamp);
        decimal GetPercentChangeForMonth(int inYear, int inMonth);
        bool CompareId(string inPortfolioID);
        string Print();

    }

    /* PORTFOLIO CLASS
     * Catches all exceptions, wraps them and throws them again to be caught in main class
     */
    class Portfolio : IPortfolio {

        private string _id;
        private decimal _value;
        private decimal _changeForMonth;
        private List<PortfolioStock> _stocks;

        private string Id {
            get {
                return this._id;
            }
            set {
                if(value.Length <= 0) {
                    throw new StockExchangeException("Portfolio ID must be set!");
                }
                this._id = value;
            }
        }
        private decimal Value {
            get {
                /*if(this._value <= 0) {
                    throw new StockExchangeException("Portfolio value is not calculated!");
                }*/
                return this._value;
            }
            set {
                if(value <= 0) {
                    throw new StockExchangeException("Portfolio value must be greater than zero!");
                }
                this._value = Math.Round(value, StockExchange.ROUNDUP_DECIMALS);
            }
        }
        private decimal ChangeForMonth {
            get {
                return this._value;
            }
            set {
                this._changeForMonth = Math.Round(value, StockExchange.ROUNDUP_DECIMALS);
            }
        }
        private List<PortfolioStock> Stocks {
            get { return this._stocks; }
            set { this._stocks = value; }
        }

        #region PUBLIC INTERFACE

        public Portfolio(string inPortfolioID) {
            this.Id = inPortfolioID;
            this.ChangeForMonth = 0;
            this._value = 0;    // Set value to 0 directly because setter and getter throws exception on <= 0
            this.Stocks = new List<PortfolioStock>();
        }

        public void AddStock(Stock inStock, int inNumberOfShares) {
            try {
                if(HasStock(inStock.Name)) {    // If stock exist, increase its number of shares in this portfolio
                    int pStockIndex = GetPortfolioStockIndex(inStock.Name);
                    this.Stocks[pStockIndex].AddNumberOdShares(inNumberOfShares);
                }
                else {  // If stock doesn't exist, create new stock and add it  to portfolio
                    PortfolioStock portfolioStock;
                    portfolioStock = new PortfolioStock(inStock, inNumberOfShares);
                    this.Stocks.Add(portfolioStock);
                }
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio -> AddStock() -> " + e.Msg);
            }
        }

        public void RemoveStock(string inStockName) {
            int stockIndex = -1;
            try {
                stockIndex = GetPortfolioStockIndex(inStockName);
                if(stockIndex >= 0 && stockIndex < NumberOfStocks()) {
                    this.Stocks.RemoveAt(stockIndex);
                }
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio -> RemoveStock() -> " + e.Msg);
            }
        }

        public void RemoveStock(string inStockName, int inNumOfShares) {
            int portfolioStockIndex = -1;
            PortfolioStock ps;
            try {
                portfolioStockIndex = GetPortfolioStockIndex(inStockName);
                ps = this.Stocks[portfolioStockIndex];

                if(inNumOfShares <= 0) {
                    throw new StockExchangeException("Number of shares must be number greater than zero!");
                }
                else if(inNumOfShares > ps.GetNumberOfSharesInPortfolio()) {
                    throw new StockExchangeException("Portfolio doesn't have that number of shares for entered stock!");
                }
                else if(inNumOfShares == ps.GetNumberOfSharesInPortfolio()) {
                    this.Stocks.RemoveAt(portfolioStockIndex);
                }
                else {
                    ps.SubstractNumberOfShares(inNumOfShares);
                }
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio -> RemoveStock() -> " + e.Msg);
            }
        }

        public int NumberOfStocks() {
            return this.Stocks.Count;
        }

        public bool HasStock(string inStockName) {
            foreach(PortfolioStock ps in this.Stocks) {
                if(ps.CompareStockByName(inStockName)) return true;
            }
            return false;
        }

        public int NumberOfSharesOfStock(string inStockName) {
            try {
                PortfolioStock ps = GetPortfolioStock(inStockName);
                return ps.GetNumberOfSharesInPortfolio();
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio -> NumberOfSharesOfStock() -> " + e.Msg);
            }
        }

        public decimal GetValue(DateTime inTimeStamp) {
            try {
                decimal sum = 0;
                foreach(PortfolioStock ps in this.Stocks) {
                    sum += (ps.GetStockPrice(inTimeStamp) * ps.GetNumberOfSharesInPortfolio());
                }
                this.Value = sum;
                return this.Value;
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio -> GetValue() -> " + e.Msg);
            }
        }

        public decimal GetPercentChangeForMonth(int inYear, int inMonth) {
            if(inMonth > 12 || inMonth <= 0 || inYear < 0) {
                throw new StockExchangeException("Invalid year or month!");
            }

            decimal sumMonthStart = 0;
            decimal sumMonthEnd = 0;
            DateTime monthStart = new DateTime(inYear, inMonth, 1, 0, 0, 0, 0);
            DateTime monthEnd = new DateTime(inYear, inMonth, DateTime.DaysInMonth(inYear, inMonth), 23, 59, 59, 999);

            try {
                foreach(PortfolioStock ps in this.Stocks) {
                    sumMonthStart += (ps.GetStockPrice(monthStart) * ps.GetNumberOfSharesInPortfolio());
                    sumMonthEnd += (ps.GetStockPrice(monthEnd) * ps.GetNumberOfSharesInPortfolio());
                }
            }
            catch(StockExchangeException e) {
                throw e;
                //throw new StockExchangeException("Portfolio.GetPercentChangeForMonth() -> " + e.Msg);
            }

            decimal change = sumMonthEnd - sumMonthStart;

            this.ChangeForMonth = (change / sumMonthStart) * 100;

            return this.ChangeForMonth;
        }

        public bool CompareId(string inPortofolioID) {
            if(inPortofolioID == this.Id) return true;
            else return false;
        }

        public string Print() {
            string res = this.Id + ", value = " + this.Value + ", change = " + this.ChangeForMonth + "\n------------------------------------\n\t";
            foreach(PortfolioStock ps in this.Stocks) {
                res += ps.GetStockName() + "-" + ps.GetNumberOfSharesInPortfolio() + "  ";
            }
            return "\n" + res + "\n";
        }

        #endregion

        #region PRIVATE METHODS

        private int GetPortfolioStockIndex(string inStockName) {
            int index = -1;
            for(int i = 0; i < this.Stocks.Count; i++) {
                if(this.Stocks[i].CompareStockByName(inStockName)) {
                    index = i;
                    break;
                }
            }
            if(index >= 0 && index < this.Stocks.Count) return index;
            else throw new StockExchangeException("Stock hasn't been found in this portfolio!");
        }

        private PortfolioStock GetPortfolioStock(string inStockName) {
            return this.Stocks[GetPortfolioStockIndex(inStockName)];
        }

        #endregion

    }

}
