﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Klasa koja modelira dionicu.
    /// </summary>
    public class Stock
    {
        private string _name;
        private readonly SortedList<DateTime, decimal> _prices;

        public Stock(string name, decimal price, DateTime time)
        {
            Name = name;
            _prices = new SortedList<DateTime, decimal>();
            this.SetPrice(price, time);
        }

        public string Name
        {
            get
            {
                return _name;
            }

            private set
            {
                if (value == null)
                {
                    throw new StockExchangeException("Potrebno je zadati ime dionice!");
                }
                _name = value.ToUpper();
            } 
        }

        /// <summary>
        /// Vraca cijenu za navedeni trenutak.
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public decimal GetPrice(DateTime time)
        {
            for (int i = _prices.Keys.Count - 1; i >= 0; i--)
            {
                DateTime t = _prices.Keys[i];
                if (t <= time)
                {
                    return _prices[t];
                }
            }
            throw new StockExchangeException("Cijena nije definirana za dani trenutak!");
        }

        public decimal GetInitialPrice()
        {
            return _prices[_prices.Keys.First()];
        }

        public decimal GetLastPrice()
        {
            return _prices[_prices.Keys.Last()];
        }

        /// <summary>
        /// Postavi cijenu za dani trenutak.
        /// </summary>
        /// <param name="price"></param>
        /// <param name="time"></param>
        public void SetPrice(decimal price, DateTime time)
        {
            if (price <= decimal.Zero || time == null)
            {
                throw new StockExchangeException("Cijena dionice mora biti pozitivna i trenutak mora biti zadan!");
            }
            if (_prices.Keys.Contains(time))
            {
                _prices.Remove(time);
            }
            _prices.Add(time, price);
        }

        /// <summary>
        /// Dionice su jednake ako su im imena jednaka.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {   
            Stock other = null;
            try
            {
                other = (Stock)obj;
            }
            catch (Exception)
            {
                return false;
            }
            if (this.Name == other.Name)
            {
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _name.GetHashCode();
        } 
    }

    /// <summary>
    /// Klasa koja modelira indeks.
    /// </summary>
    public class Index
    {
        private string _name;
        private readonly Dictionary<Stock, long> _stockShares;

        public Index(string name, IndexTypes type)
        {
            Name = name;
            Type = type;
            _stockShares = new Dictionary<Stock, long>();
        }

        public string Name
        {
            get
            {
                return _name;
            }

            private set
            {
                if (value == null)
                {
                    throw new StockExchangeException("Potrebno je zadati ime dionice!");
                }
                _name = value.ToUpper();
            }
        }

        public IndexTypes Type { get; private set; }

        public decimal GetValue(DateTime time)
        {
            decimal temp = decimal.Zero;

            if (Type == IndexTypes.AVERAGE)
            {
                foreach (Stock s in _stockShares.Keys)
                {
                    temp += s.GetPrice(time);
                }
                temp = _stockShares.Keys.Count > 0 ? temp / _stockShares.Keys.Count : decimal.Zero;
            }
            else if (Type == IndexTypes.WEIGHTED)
            {
                decimal sum = decimal.Zero;
                foreach (Stock s in _stockShares.Keys)
                {
                    sum += s.GetPrice(time) * _stockShares[s];
                }
                foreach (Stock s in _stockShares.Keys)
                {
                    temp += (s.GetPrice(time) * _stockShares[s]) * (s.GetPrice(time) / sum);
                }
            }
            else 
            {
                throw new StockExchangeException("Nepodrzani tip indeksa!");
            }

            return decimal.Round(temp, 3);
        }

        /// <summary>
        /// Dodaj dionicu u index.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="numberOfShares"></param>
        public void AddStock(Stock s, long numberOfShares)
        {
            if (s == null || numberOfShares <= 0)
            {
                throw new StockExchangeException("Pogresno zadani podaci o dionicama!");
            }
            if (!_stockShares.Keys.Contains(s))
            {
                _stockShares.Add(s, numberOfShares);
            }
        }

        /// <summary>
        /// Izbrisi dionicu iz indeksa.
        /// </summary>
        /// <param name="s"></param>
        public void RemoveStock(Stock s)
        {
            if (_stockShares.Keys.Contains(s))
            {
                _stockShares.Remove(s);
            }
        }

        /// <summary>
        /// Provjerava nalazi li se navedena dionica u indeksu.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public bool ContainsStock(Stock s)
        {
            if (_stockShares.Keys.Contains(s))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Vraca broj dionica u indeksu.
        /// </summary>
        /// <returns></returns>
        public int NumberOfStocks()
        {
            return _stockShares.Count;
        }

        /// <summary>
        /// Indeksi su jednaki ako su im imena jednaka.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            Index other = null;
            try
            {
                other = (Index)obj;
            }
            catch (Exception)
            {
                return false;
            }
            if (this.Name == other.Name)
            {
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _name.GetHashCode();
        }
    }

    /// <summary>
    /// Klasa koja modelira portfelj.
    /// </summary>
    public class Portfolio
    {
        private string _id;
        private readonly Dictionary<Stock, long> _stockShares;

        public Portfolio(string id)
        {
            ID = id;
            _stockShares = new Dictionary<Stock, long>();
        }

        public string ID
        {
            get
            {
                return _id;
            }

            private set
            {
                if (value == null)
                {
                    throw new StockExchangeException("Potrebno je zadati ID portfelja!");
                }
                _id = value;
            }
        }

        /// <summary>
        /// Dodaj dionicu u portfelj.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="numberOfShares"></param>
        public void AddStock(Stock s, long numberOfShares)
        {
            if (s == null || numberOfShares <= 0)
            {
                throw new StockExchangeException("Pogresno zadani podaci o dionicama!");
            }
            if (!_stockShares.Keys.Contains(s))
            {
                _stockShares.Add(s, numberOfShares);
            }
            else
            {
                _stockShares[s] += numberOfShares;
            }
        }

        /// <summary>
        /// Izbrisi dionicu iz portfelja.
        /// </summary>
        /// <param name="s"></param>
        public void RemoveStock(Stock s)
        {
            if (_stockShares.Keys.Contains(s))
            {
                _stockShares.Remove(s);
            }
        }

        /// <summary>
        /// Izbrisi odredjeni broj dionica iz portfelja.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="numberOfShares"></param>
        public void RemoveStockShares(Stock s, long numberOfShares)
        {
            if (_stockShares.Keys.Contains(s))
            {
                if (numberOfShares >= _stockShares[s])
                {
                    _stockShares.Remove(s);
                }
                else
                {
                    _stockShares[s] -= numberOfShares;
                }
            }
        }

        public decimal GetValue(DateTime time)
        {
            decimal sum = decimal.Zero;
            foreach (Stock s in _stockShares.Keys)
            {
                sum += s.GetPrice(time) * _stockShares[s];
            }
            return decimal.Round(sum, 3);
        }

        public decimal GetMonthlyChange(int year, int month)
        {
            decimal temp = decimal.Zero;
            DateTime first = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime last = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

            if (GetValue(first).Equals(decimal.Zero))
            {
                if (GetValue(last).Equals(decimal.Zero))
                {
                    return decimal.Round(temp, 3);
                }

                throw new StockExchangeException("Dijeljenje s nulom!");
            }

            temp = (GetValue(last) - GetValue(first)) / GetValue(first) * 100;

            return decimal.Round(temp, 3);
        }

        /// <summary>
        /// Vraca broj dionica u portfelju.
        /// </summary>
        /// <returns></returns>
        public int NumberOfStocks()
        {
            return _stockShares.Count;
        }

        /// <summary>
        /// Provjerava nalazi li se navedena dionica u portfelju.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public bool ContainsStock(Stock s)
        {
            if (_stockShares.Keys.Contains(s))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Vraca broj navedenih dionica u portfelju.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public long NumberOfSharesOfStock(Stock s)
        {
            if (ContainsStock(s))
            {
                return _stockShares[s];
            }
            else
            {
                throw new StockExchangeException("Navedena dionica se ne nalazi u portfelju!");
            }
        }

        /// <summary>
        /// Portfelji su jednaki ako su im ID-evi jednaki.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            Portfolio other = null;
            try
            {
                other = (Portfolio)obj;
            }
            catch (Exception)
            {
                return false;
            }
            if (this.ID == other.ID)
            {
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _id.GetHashCode();
        }
    }

    /// <summary>
    /// Klasa koja modelira burzu.
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private readonly Dictionary<string, Stock> _stocks;
        private readonly Dictionary<Stock, long> _stockShares;
        private readonly Dictionary<string, Index> _indexes;
        private readonly Dictionary<string, Portfolio> _portfolios;

        public StockExchange()
        {
            _stocks = new Dictionary<string, Stock>();
            _stockShares = new Dictionary<Stock, long>();
            _indexes = new Dictionary<string, Index>();
            _portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName != null && inInitialPrice != null && inTimeStamp != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (!StockExists(inStockName))
            {
                Stock s = new Stock(inStockName, inInitialPrice, inTimeStamp);
                _stocks.Add(inStockName, s);
                _stockShares.Add(s, inNumberOfShares);
            }
            else
            {
                throw new StockExchangeException("Dionica pod tim imenom vec postoji na burzi!");
            }
        }

        public void DelistStock(string inStockName)
        {
            if (inStockName != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (StockExists(inStockName))
            {
                Stock s = _stocks[inStockName];
                foreach (Index ind in _indexes.Values)
                {
                    if (ind.ContainsStock(s))
                    {
                        ind.RemoveStock(s);
                    }
                }
                foreach (Portfolio ptf in _portfolios.Values)
                {
                    if (ptf.ContainsStock(s))
                    {
                        ptf.RemoveStock(s);
                    }
                }

                _stocks.Remove(inStockName);
                _stockShares.Remove(s);
            }
        }

        public bool StockExists(string inStockName)
        {
            if (inStockName != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (_stocks.Keys.Contains(inStockName.ToUpper()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockName != null && inStockValue != null && inTimeStamp != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (StockExists(inStockName))
            {
                Stock s = _stocks[inStockName];
                s.SetPrice(inStockValue, inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Dionica pod tim imenom ne postoji na burzi!");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (inStockName != null && inTimeStamp != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (StockExists(inStockName))
            {
                Stock s = _stocks[inStockName];
                return s.GetPrice(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Dionica pod tim imenom ne postoji na burzi!");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (inStockName != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (StockExists(inStockName))
            {
                Stock s = _stocks[inStockName];
                return s.GetInitialPrice();
            }
            else
            {
                throw new StockExchangeException("Dionica pod tim imenom ne postoji na burzi!");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (inStockName != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (StockExists(inStockName))
            {
                Stock s = _stocks[inStockName];
                return s.GetLastPrice();
            }
            else
            {
                throw new StockExchangeException("Dionica pod tim imenom ne postoji na burzi!");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName != null)
            {
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (!IndexExists(inIndexName))
            {
                Index ind = new Index(inIndexName, inIndexType);
                _indexes.Add(inIndexName, ind);
            }
            else
            {
                throw new StockExchangeException("Indeks pod tim imenom vec postoji na burzi!");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (inStockName != null && inIndexName != null)
            {
                inStockName = inStockName.ToUpper();
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index ind = _indexes[inIndexName];
                Stock s = _stocks[inStockName];
                ind.AddStock(s, _stockShares[s]);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni indeks ili dionica ne postoji na burzi!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (inStockName != null && inIndexName != null)
            {
                inStockName = inStockName.ToUpper();
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index ind = _indexes[inIndexName];
                Stock s = _stocks[inStockName];
                ind.RemoveStock(s);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni indeks ili dionica ne postoji na burzi!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (inStockName != null && inIndexName != null)
            {
                inStockName = inStockName.ToUpper();
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index ind = _indexes[inIndexName];
                Stock s = _stocks[inStockName];
                return ind.ContainsStock(s);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni indeks ili dionica ne postoji na burzi!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (inIndexName != null && inTimeStamp != null)
            {
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (IndexExists(inIndexName))
            {
                Index ind = _indexes[inIndexName];
                return ind.GetValue(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Navedeni indeks ne postoji na burzi!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            if (inIndexName != null)
            {
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (_indexes.Keys.Contains(inIndexName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return _indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (inIndexName != null)
            {
                inIndexName = inIndexName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (IndexExists(inIndexName))
            {
                return _indexes[inIndexName].NumberOfStocks();
            }
            else
            {
                throw new StockExchangeException("Navedeni indeks ne postoji na burzi!");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (!PortfolioExists(inPortfolioID))
            {
                Portfolio ptf = new Portfolio(inPortfolioID);
                _portfolios.Add(inPortfolioID, ptf);
            }
            else
            {
                throw new StockExchangeException("Portfelj s tim ID-em vec postoji na burzi!");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (inStockName != null && inPortfolioID != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                Stock s = _stocks[inStockName];
                ptf.AddStock(s, numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni portfelj ili dionica ne postoji na burzi!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (inStockName != null && inPortfolioID != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                Stock s = _stocks[inStockName];
                ptf.RemoveStockShares(s, numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni portfelj ili dionica ne postoji na burzi!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (inStockName != null && inPortfolioID != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                Stock s = _stocks[inStockName];
                ptf.RemoveStock(s);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni portfelj ili dionica ne postoji na burzi!");
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                return ptf.NumberOfStocks();
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji na burzi!");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (_portfolios.Keys.Contains(inPortfolioID))
            {
                return true;
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (inStockName != null && inPortfolioID != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                Stock s = _stocks[inStockName];
                return ptf.ContainsStock(s);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni portfelj ili dionica ne postoji na burzi!");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (inStockName != null && inPortfolioID != null)
            {
                inStockName = inStockName.ToUpper();
            }
            else
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                Stock s = _stocks[inStockName];
                return (int)ptf.NumberOfSharesOfStock(s);
            }
            else
            {
                throw new StockExchangeException("Ili navedeni portfelj ili dionica ne postoji na burzi!");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (inPortfolioID == null || inPortfolioID == null)
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                return ptf.GetValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji na burzi!");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Ima null parametara!");
            }

            if (PortfolioExists(inPortfolioID))
            {
                Portfolio ptf = _portfolios[inPortfolioID];
                return ptf.GetMonthlyChange(Year, Month);
            }
            else
            {
                throw new StockExchangeException("Navedeni portfelj ne postoji na burzi!");
            }
        }
    }
}
