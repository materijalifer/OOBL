﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string memory = "0";
        private string display = "0";
        private string lastDisplay = "0";
        private List<string> operands = new List<string>();
        private List<char> operators = new List<char>();
        private string availableOperators = "+-*/=,MSKTQRIPGCO";
        private string availableNumbers = "0123456789";
        private string availableBinaryOperators = "+-*/";
        private char lastOperator = '0';
        private int numLength = 0;
        private char lastInput = 'E';
        private bool unaryDisplay = false;
        private char lastBinaryOperator = '=';
        private string lastNumber = "E";

        public void Press(char inPressedDigit)
        {
            if (isValidInput(inPressedDigit))
            {
                if (unaryDisplay)
                {
                    display = "0";
                    unaryDisplay = false;
                }

                if (inPressedDigit.Equals('O'))
                {
                    display = "0";
                    operands.Clear();
                    operators.Clear();
                    numLength = 0;
                    return;
                }
                if (display != "0")
                {
                    if (!(numLength == 10 && isNumber(inPressedDigit)))
                    {
                        if (isNumber(inPressedDigit))
                        {
                            display += inPressedDigit;
                            numLength++;
                        }
                        else if (isOperator(inPressedDigit))
                        {
                            char beforeLastOperator = '0';

                            switch (inPressedDigit)
                            {
                                case 'M':
                                    display.Replace(',','.');
                                    double minus = Convert.ToDouble(display);
                                    minus *= -1; 
                                    display = minus.ToString();
                                    display.Replace('.',',');
                                    break;
                                case ',':
                                    if (lastOperator != ',')
                                        display += inPressedDigit;
                                    else
                                        display = "-E-";
                                    break;
                                case 'P':
                                    memory = display;
                                    break;
                                case 'G':
                                    display = memory;
                                    break;
                                case 'S':
                                    display.Replace(',', '.');
                                    double result = Convert.ToDouble(display);
                                    result = Math.Round(Math.Sin(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    break;
                                case 'K':
                                    display.Replace(',', '.');
                                    result = Convert.ToDouble(display);
                                    result = Math.Round(Math.Cos(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    break;
                                case 'T':
                                    display.Replace(',', '.');
                                    result = Convert.ToDouble(display);
                                    result = Math.Round(Math.Tan(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    break;
                                case 'Q':
                                    display.Replace(',', '.');
                                    result = Convert.ToDouble(display);
                                    result = Math.Round(Math.Pow(result, 2), 9);
                                    display = result.ToString();
                                    display = toFormat(display);
                                    display.Replace('.', ',');
                                    break;
                                case 'R':
                                    display.Replace(',', '.');
                                    result = Convert.ToDouble(display);
                                    result = Math.Round(Math.Sqrt(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    break;
                                case 'I':
                                    display.Replace(',', '.');
                                    result = Convert.ToDouble(display);
                                    if (result != 0)
                                    {
                                        result = Math.Round(1 / result, 9);
                                        display = result.ToString();
                                        display.Replace('.', ',');
                                    }
                                    else
                                    {
                                        display = "-E-";
                                    }
                                    break;
                                case 'C':
                                    display = "0";
                                    break;
                                default:
                                    if (!isBinaryOperator(lastInput))
                                    {
                                        if (lastInput.Equals('=') && inPressedDigit.Equals('='))
                                        {
                                            beforeLastOperator = lastInput;
                                            lastOperator = inPressedDigit;
                                            lastNumber = display;
                                            break;
                                        }
                                        display.Replace(',', '.');
                                        string number = display;

                                        operands.Add(number);//add new number
                                        lastNumber = number;
                                        operators.Add(inPressedDigit);//add new operator
                                        beforeLastOperator = lastOperator;
                                        if(isBinaryOperator(inPressedDigit))//memory last binary operator
                                            lastBinaryOperator = inPressedDigit;
                                        lastOperator = inPressedDigit;
                                        lastDisplay = display;
                                        display = "0";
                                        numLength = 0;
                                    }
                                    else
                                    {
                                        operators.RemoveAt(operators.Count - 1);
                                        operators.Add(inPressedDigit);
                                    }
                                    break;
                            }
                            
                            if (inPressedDigit.Equals('='))
                            {
                                if (beforeLastOperator.Equals('='))
                                {
                                    operands.Add(lastDisplay);
                                    operands.Add(lastNumber);
                                    operators.Add(lastBinaryOperator);
                                }
                                double result = 0;
                                result = calculate();

                                display = toFormat(result.ToString());
                                //lastNumber = display;
                                //lastDisplay = display;
                            }
                        }
                    }
                    //display += inPressedDigit;
                }
                else
                {
                    if (inPressedDigit == '0')
                    {
                        display = "0";
                    }
                    if (isOperator(inPressedDigit))
                    {
                        switch (inPressedDigit)
                        {
                            case '=':
                                double result = 0;
                                result = calculate();

                                display = toFormat(result.ToString());
                                break;
                            case ',':
                                display += inPressedDigit;
                                break;
                            case 'M':
                                if (operands.Count == 0)
                                {
                                    display = "0";
                                }
                                else if (isOperator(lastInput))
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result *= -1;
                                    operands.RemoveAt(operands.Count - 1);
                                    operands.Add(result.ToString().Replace('.', ','));
                                    unaryDisplay = true;
                                }
                                else
                                {
                                    display = "0";
                                }
                                break;
                            case 'S':
                                if (operands.Count == 0)
                                {
                                    display = "0";
                                }
                                else if (isOperator(lastInput))
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = Math.Round(Math.Sin(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                else
                                {
                                    display = "0";
                                }
                                break;
                            case 'K':
                                if (operands.Count == 0)
                                {
                                    display = "1";
                                }
                                else if (isOperator(lastInput))
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = Math.Round(Math.Cos(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                else
                                {
                                    display = "1";
                                }
                                break;
                            case 'T':
                                if (operands.Count == 0)
                                {
                                    display = "0";
                                }
                                else
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = Math.Round(Math.Tan(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                break;
                            case 'Q':
                                if (operands.Count == 0)
                                {
                                    display = "0";
                                }
                                else
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = Math.Round(Math.Pow(result, 2), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                break;
                            case 'R':
                                if (operands.Count == 0)
                                {
                                    display = "0";
                                }
                                else
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = Math.Round(Math.Sqrt(result), 9);
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                break;
                            case 'I':
                                if (operands.Count == 0)
                                {
                                    display = "-E-";
                                }
                                else
                                {
                                    result = Convert.ToDouble(operands.ElementAt(operands.Count - 1));
                                    result = 1 / result;
                                    display = result.ToString();
                                    display.Replace('.', ',');
                                    unaryDisplay = true;
                                }
                                break;
                            default:
                                if (isBinaryOperator(lastInput))
                                {
                                    operators.RemoveAt(operators.Count - 1);
                                    operators.Add(inPressedDigit);
                                }
                                else if(lastInput.Equals('E'))
                                {
                                    operands.Add("0");
                                    operators.Add(inPressedDigit);
                                }
                                break;
                        }
                    }
                    else if (isNumber(inPressedDigit))
                    {
                        display = inPressedDigit.ToString();
                        numLength++;
                    }
                }
            }
            else
            {
                //ignore input
            }

            lastInput = inPressedDigit;
            //throw new NotImplementedException();
        }

        public string GetCurrentDisplayState()
        {
            //string currentDisplay = "";
            if (display.Equals("0") && operands.Count != 0)
                return lastDisplay;
            else
                return display;
            //throw new NotImplementedException();
        }



        //*********************************PROVJERA UNOSA*********************//
        private bool isOperator(char inPressedDigit)
        {
            if (availableOperators.Contains(inPressedDigit))
                return true;
            else
                return false;
        }

        private bool isNumber(char inPressedDigit)
        {
            if (availableNumbers.Contains(inPressedDigit))
                return true;
            else
                return false;
        }

        private bool isValidInput(char inPressedDigit)
        {
            if (isOperator(inPressedDigit) || isNumber(inPressedDigit))
                return true;
            else
                return false;
        }

        private bool isBinaryOperator(char inPressedDigit)
        {
            if (availableBinaryOperators.Contains(inPressedDigit))
                return true;
            else
                return false;
        }
        //******************************************************************/

        //***********************FORMIRANJE REZULTATA NA 10 ZNAMENKI**************************/
        private string toFormat(string number)
        {
            int i = 0;
            double num = Convert.ToDouble(number);
            do
            {
                num = num / 10;
                i++;
            } while (num > 1);
            if (i > 10)
                return "-E-";
            else
            {
                Math.Round(num, 10);
                num = num * Math.Pow(10, i);
                return num.ToString();
            }
        }
        //*************************************************/

        //**********************IZRAČUNATI IZRAZ KAD SE STISNE "=" ****************************/
        private double calculate()
        {
            if (operands.Count == 0) return 0;
            double result = Convert.ToDouble(operands.ElementAt(0));
            double nextNum;
            operands.RemoveAt(0);
            char oper;
            do
            {
                if (operands.Count == 0)
                {
                    nextNum = result;
                }
                else
                {
                    nextNum = Convert.ToDouble(operands.ElementAt(0));
                    operands.RemoveAt(0);
                }

                oper = operators.ElementAt(0);//get next operator
                operators.RemoveAt(0);
                switch (oper)
                {
                    case '+':
                        result += nextNum;
                        break;
                    case '-':
                        result -= nextNum;
                        break;
                    case '*':
                        result *= nextNum;
                        break;
                    case '/':
                        result /= nextNum;
                        break;
                }
            } while (operands.Count != 0);
            return result;
        }
    }
}
