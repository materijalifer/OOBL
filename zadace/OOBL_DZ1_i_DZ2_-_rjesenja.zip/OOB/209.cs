﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    public class Kalkulator : ICalculator
    {
        private string display;
        private string memory;
        private double result;
        char operation;//zadnja zadana operacija
        bool newNumber;
        char previousInput;//predzadnji input->da se uzima samo zadnja uzastopna binarna operacija

        char[] listOperationBinary = new char[] { '+', '-', '*', '/', '=' };
        char[] listOperationUnary = new char[] { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        char[] listOperationMemorija = new char[] { 'P', 'G', 'C', 'O' };

        public Kalkulator()
        {
            operation = ' ';
            display = "0";
            result = 0;
            memory = "";
            newNumber = true;
            previousInput = ' ';
        }

        public void CalculateUnary(char unaryOperation)
        {
            //'M','S','K','T','Q','R','I'
            switch (unaryOperation)
            {
                case 'M':
                    if (display.Contains('-'))
                    {
                        display = display.Remove(0, 1);
                    }
                    else
                    {
                        display = "-" + display;
                    }
                    break;
                case 'S':
                    display = Math.Sin(Convert.ToDouble(display)).ToString();
                    break;
                case 'K':
                    display = Math.Cos(Convert.ToDouble(display)).ToString();
                    break;
                case 'T':
                    display = Math.Tan(Convert.ToDouble(display)).ToString();
                    break;
                case 'Q':
                    display = (Convert.ToDouble(display) * Convert.ToDouble(display)).ToString();
                    break;
                case 'R':
                    display = Math.Sqrt(Convert.ToDouble(display)).ToString();
                    break;
                case 'I':
                    if (Convert.ToDouble(display) == 0)
                    {
                        display = "-E-";
                    }
                    else
                    {
                        display = (1 / Convert.ToDouble(display)).ToString();//ako je 1/0 vratit gresku
                    }
                    break;
                default:
                    break;
            }
            //zaokruzivanje
            display = Round(display);
        }

        public void CalculateBinary()
        {
            switch (operation)
            {
                case '+':
                    result += Convert.ToDouble(display);
                    break;
                case '-':
                    result -= Convert.ToDouble(display);
                    break;
                case '*':
                    result *= Convert.ToDouble(display);

                    break;
                case '/':
                    if (Convert.ToDouble(display) == 0)
                    {
                        display = "-E-";
                    }
                    else
                    {
                        result /= Convert.ToDouble(display);//ako je 1/0 vratit gresku
                        result = Convert.ToDouble(Round(result.ToString()));
                        display = result.ToString();
                    }
                    break;
                default:
                    break;
            }

            if (Round(result.ToString()) == "-E-" || display == "-E-")
            {
                display = "-E-";
            }
            else
            {
                result = Convert.ToDouble(Round(result.ToString()));
            }
            display = result.ToString();
            //display se ne zaokruzuje->ako ima viska znamenki error
            //tu treba ubacit funkciju za zaokruzivanje
        }

        public void MemoryOperation(char o)
        {
            switch (o)
            {
                case 'P':
                    memory = display;
                    break;
                case 'G':
                    display = memory;
                    break;
                case 'C':
                    display = "0";
                    break;
                case 'O':
                    Reset();
                    break;

            }
        }

        public void Reset()
        {
            operation = ' ';
            display = "0";
            result = 0;
            memory = "";
            newNumber = true;
            previousInput = ' ';
        }

        public void Press(char inPressedDigit)
        {
            if (display != "-E-")
            {
                //znamenka
                if ((inPressedDigit > 47) && (inPressedDigit < 58))
                {
                    if (newNumber)
                    {
                        display = "";
                        newNumber = false;
                    }
                    //zanemaruju se znamenke koje se unose a ne stanu na ekran
                    if (display == "0") display = "";
                    int length = 10;
                    if (display.Contains("-")) length++;
                    if (display.Contains(",")) length++;
                    if (display.Length < length) display += inPressedDigit;
                }
                //binarna operacija
                else if (listOperationBinary.Contains(inPressedDigit))
                {
                    if (operation == ' ')
                    {
                        //ne treba obavit nikakvu operaciju
                        //sprema se trenutna operacija
                        result = Convert.ToDouble(display);//tu treba zaokruzit display i result??????

                    }
                    else if (listOperationBinary.Contains(previousInput) && previousInput != '=')
                    {
                        if(inPressedDigit=='=') CalculateBinary();
                        previousInput = inPressedDigit;
                    }
                    else
                    {
                        //postoji zadana operacija
                        CalculateBinary();
                    }

                    if (inPressedDigit != '=')
                    {
                        operation = inPressedDigit;
                    }
                    newNumber = true;
                }
                //unarna operacija
                else if (listOperationUnary.Contains(inPressedDigit))
                {
                    CalculateUnary(inPressedDigit);
                    if(inPressedDigit!='M') newNumber = true;
                }
                //memorija operacija
                else if (listOperationMemorija.Contains(inPressedDigit))
                {
                    MemoryOperation(inPressedDigit);

                }
                else if (inPressedDigit == ',')
                {
                    //provejrit jel u stringu display postoji zarez, ako postoji javi gresku
                    if (display.Contains(','))
                    {
                        display = "-E-";
                    }
                    else if (display == "")
                    {
                        display = "0,";
                    }
                    else
                    {
                        display += ",";
                    }
                    newNumber = false;
                }
            }
            previousInput = inPressedDigit;
        }

        public string Round(string number)
        {
            if (number == "-E-") return number;

            int length = 10;
            bool minus = false;
            int comma = -1;
            if (number.Contains("-")) length++;

            //ako je broj prevelik vraca se greska
            if (number.IndexOf(',') == -1 && number.Length > length)
            {
                return "-E-";
            }

            if (number.IndexOf(',') <= length && number.IndexOf(',') != -1) length++;

            //ako je broj prevelik vraca se greska
            if (number.IndexOf(',') >= length)
            {
                return "-E-";
            }


            if (number.Length > length)
            {

                //treba zaokruzivati-->>>>AKO JE BROJ PREVELIK JAVLJA SE GRESKA!!!
                //micemo minus(na kraju ga treba vratit)
                if (number.Contains("-"))
                {
                    minus = true;
                    number = number.Remove(0, 1);
                }
                //provjeravamo di je zarez
                if (number.IndexOf(',') <= 10 && number.IndexOf(',') != -1)
                {
                    //maknemo zarez te ga na kraju dodajemo(da se svi brojevi mogu zaokruzivati na isti nacin)
                    comma = number.IndexOf(',');
                    number = number.Remove(comma, 1);
                }
                else
                {
                    return "-E-";
                    //broj je prevelik, greska

                }
                number = number.Substring(0, 11);
                int currentDigit = 9;
                bool round = true;
                //
                if (Convert.ToInt32(number[10].ToString()) >= 5)
                {
                    round = false;
                }

                //zaokruzujemo bez obzira na zarez
                //ako je zadnja+1 znamenka>=5 :zadnja++(treba while petlja u slucaju da treba mjenjat vise znamenki)
                bool zarez = false;
                while (round == false)
                {
                    if (Convert.ToInt32(number[currentDigit].ToString()) + 1 > 9)
                    {
                        char[] tmp = number.ToCharArray();
                        tmp[currentDigit] = '0';
                        number = new string(tmp);
                        currentDigit--;
                        if (currentDigit < 0)
                        {
                            number = "1000000000";
                            round = true;
                            zarez = true;
                        }
                    }
                    else
                    {
                        char[] tmp2 = number.ToCharArray();
                        tmp2[currentDigit] = (Convert.ToInt32(number[currentDigit].ToString()) + 1).ToString()[0];
                        number = new string(tmp2);
                        round = true;
                        zarez = true;
                    }
                    // number = number.Substring(0, 10);
                }
                number = number.Substring(0, 10);
                //vracamo minus i zarez ako je potrebno
                if (comma != -1)
                {
           
                        number = number.Insert(comma , ",");
                       }
                if (minus == true)
                {
                    number = number.Insert(0, "-");
                }
                
                //provjerit jel rez ima vise od 10 znamenki prije zareza


            }

            //ako je broj 0 maknut ostale 0
            if (Convert.ToDouble(number) == 0) number = "0";
            //ako ima zarez maknut nule s kraja
            if (number.Contains(","))
            {
                int lastDigit = number.Length - 1;
                bool remove = true;
                while (remove)
                {
                    if (number[lastDigit] == '0')
                    {
                        number = number.Substring(0, lastDigit);
                        lastDigit--;
                    }
                    else if (number[lastDigit] == ',')
                    {
                        number = number.Substring(0, lastDigit);
                        remove = false;
                    }
                    else
                    {
                        remove = false;
                    }
                }
            }

            return number;

        }

        public string GetCurrentDisplayState()
        {
            return Round(display.ToString());
            //throw new NotImplementedException();
        }

        private bool CheckNumberLength(double number)
        {
            return true;
        }


    }
}
