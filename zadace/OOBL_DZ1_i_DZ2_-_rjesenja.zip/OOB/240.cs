﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    class Kalkulator : ICalculator
    {
        private string Screen = "0";
        private string FirstVariable = "0";
        private string SecondVariable = "0";
        private string Memory = "0";

        private int DigitCount = 1;

        private bool UnexecutedOperation = false;
        private bool DigitAdded = false;
        private bool ShortOperation = false;
        private bool ShortOperationFinished = false;
        private bool FirstTimeExecute = true;

        private char LastOperation = '?';
        private const string ERROR = "-E-";
        
        public void Press(char inPressedDigit)
        {
            if (Screen.Equals(ERROR))
            {
                switch (inPressedDigit)
                {
                    case 'C':
                        Clear();
                        break;
                    case 'O':
                        Reset();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        standardPreOperation('+');
                        break;
                    case '-':
                        standardPreOperation('-');
                        break;
                    case '/':
                        standardPreOperation('/');
                        break;
                    case '*':
                        standardPreOperation('*');
                        break;
                    case '=':
                        operationExecute();
                        break;
                    case ',':
                        addComma();
                        break;
                    case 'M':
                        addMinus();
                        break;
                    case 'S':
                        operationSinus();
                        break;
                    case 'K':
                        operationCosinus();
                        break;
                    case 'T':
                        operationTangens();
                        break;
                    case 'Q':
                        operationSquare();
                        break;
                    case 'R':
                        operationSquareRoot();
                        break;
                    case 'I':
                        operationInvers();
                        break;
                    case 'P':
                        operationSave();
                        break;
                    case 'G':
                        operationGetSaved();
                        break;
                    case 'C':
                        Clear();
                        break;
                    case 'O':
                        Reset();
                        break;
                    default:
                        newDigit(inPressedDigit);
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return Screen;
        }

        private void newDigit(char digit)
        {
            if (ShortOperation && !ShortOperationFinished)
            {
                UnexecutedOperation = true;
                Clear();
            }

            if (DigitCount < 10)
            {
                if (DigitAdded)
                {
                    Screen += digit.ToString();
                    DigitCount++;
                }
                else
                {
                    if (digit != '0')
                    {
                        DigitAdded = true;
                    }
                    ShortOperation = false;
                    Screen = digit.ToString();
                }
            }
        }

        private void operationAdd()
        {
            if (ShortOperation)
            {
                Screen = (decimal.Parse(Screen) + decimal.Parse(FirstVariable)).ToString();
            }
            else if (FirstTimeExecute)
            {
                SecondVariable = Screen;
                Screen = (decimal.Parse(FirstVariable) + decimal.Parse(Screen)).ToString();
                FirstTimeExecute = false;
            }
            else
            {
                Screen = (decimal.Parse(Screen) + decimal.Parse(SecondVariable)).ToString();
            }

            standardPostOperation();
        }

        private void operationSubstract()
        {
            if (ShortOperation)
            {
                Screen = (decimal.Parse(Screen) - decimal.Parse(FirstVariable)).ToString();
            }
            else if (FirstTimeExecute)
            {
                SecondVariable = Screen;
                Screen = (decimal.Parse(FirstVariable) - decimal.Parse(Screen)).ToString();
                FirstTimeExecute = false;
            }
            else
            {
                Screen = (decimal.Parse(Screen) - decimal.Parse(SecondVariable)).ToString();
            }

            standardPostOperation();
        }

        private void operationMultiply()
        {
            if (ShortOperation)
            {
                Screen = (decimal.Parse(Screen) * decimal.Parse(FirstVariable)).ToString();
            }
            else if (FirstTimeExecute)
            {
                SecondVariable = Screen;
                Screen = (decimal.Parse(FirstVariable) * decimal.Parse(Screen)).ToString();
                FirstTimeExecute = false;
            }
            else
            {
                Screen = (decimal.Parse(Screen) * decimal.Parse(SecondVariable)).ToString();
            }
            
            standardPostOperation();
        }

        private void operationDivide()
        {
            try
            {
                if (ShortOperation)
                {
                    Screen = (decimal.Parse(Screen) / decimal.Parse(FirstVariable)).ToString();
                }
                else if (FirstTimeExecute)
                {
                    SecondVariable = Screen;
                    Screen = (decimal.Parse(FirstVariable) / decimal.Parse(Screen)).ToString();
                    FirstTimeExecute = false;
                }
                else
                {
                    Screen = (decimal.Parse(Screen) / decimal.Parse(SecondVariable)).ToString();
                }
                
                standardPostOperation();
            }
            catch (Exception e)
            {
                Screen = ERROR;
            }
        }

        private void standardPreOperation(char Operator)
        {
            if (UnexecutedOperation)
            {
                operationExecute();
                UnexecutedOperation = false;
            }

            ShortOperation = true;
            ShortOperationFinished = false;
            DigitAdded = false;
            FirstTimeExecute = true;

            removeRedundantZeros();
            FirstVariable = Screen;
            LastOperation = Operator;
        }

        private void standardPostOperation()
        {
            removeRedundantZeros();
            digitCounter();
            roundResult();
            removeRedundantZeros();
            digitCounter();
        }

        private void operationExecute()
        {
            switch (LastOperation)
            {
                case '+':
                    operationAdd();
                    break;
                case '-':
                    operationSubstract();
                    break;
                case '*':
                    operationMultiply();
                    break;
                case '/':
                    operationDivide();
                    break;
                case '?':
                    standardPostOperation();
                    break;
                default:
                    break;
            }

            DigitAdded = false;
            UnexecutedOperation = false;
            ShortOperationFinished = true;
        }

        private void operationSinus()
        {
            Screen = ((decimal)Math.Sin(double.Parse(Screen))).ToString();
            standardPostOperation();
            DigitAdded = false;
        }

        private void operationCosinus()
        {
            Screen = ((decimal)Math.Cos(double.Parse(Screen))).ToString();
            standardPostOperation();
            DigitAdded = false;
        }

        private void operationTangens()
        {
            Screen = ((decimal)Math.Tan(double.Parse(Screen))).ToString();
            standardPostOperation();
            DigitAdded = false;
        }

        private void operationSquare()
        {
            Screen = (decimal.Parse(Screen) * decimal.Parse(Screen)).ToString();
            standardPostOperation();
            DigitAdded = false;
        }

        private void operationSquareRoot()
        {
            try
            {
                Screen = ((decimal)Math.Sqrt(double.Parse(Screen))).ToString();
                standardPostOperation();
                DigitAdded = false;
            }
            catch (Exception e)
            {
                Screen = ERROR;
            }
        }

        private void operationInvers()
        {
            try
            {
                Screen = (1 / decimal.Parse(Screen)).ToString();
                standardPostOperation();
                DigitAdded = false;
            }
            catch (Exception e)
            {
                Screen = ERROR;
            }
        }

        private void operationSave()
        {
            Memory = Screen;
        }

        private void operationGetSaved()
        {
            Screen = Memory;
            DigitAdded = true;
            digitCounter();
        }

        private void addComma()
        {
            if (!DigitAdded)
            {
                if (ShortOperation && !ShortOperationFinished)
                {
                    UnexecutedOperation = true;
                }

                Screen = "0,";
                DigitCount = 1;
                ShortOperation = false;
                DigitAdded = true;
            }
            else if (!checkForComma())
            {
                Screen += ",";
                DigitAdded = true;
            }
        }

        private void addMinus()
        {
            Screen = (decimal.Parse(Screen) * (-1)).ToString();
        }

        private void Clear()
        {
            Screen = "0";
            DigitCount = 1;
            DigitAdded = false;
        }

        private void Reset()
        {
            Clear();
            FirstVariable = "0";
            SecondVariable = "0";
            Memory = "0";

            UnexecutedOperation = false;
            ShortOperation = false;
            ShortOperationFinished = false;
            FirstTimeExecute = true;

            LastOperation = '?';
        }

        private void removeRedundantZeros()
        {
            if (checkForComma())
            {
                Screen = Screen.TrimEnd('0');
                Screen = Screen.TrimEnd(',');
            }
        }

        private void roundResult()
        {
            if (!checkForComma() && DigitCount > 10)
            {
                Screen = ERROR;
            }
            else if (checkForComma() && DigitCount > 10)
            {
                int numberOfDigitsBehindTheComma = Screen.Split(',')[1].Length;
                int numberOfDigitsBeforeTheComma = DigitCount - numberOfDigitsBehindTheComma;

                if (numberOfDigitsBeforeTheComma > 10)
                {
                    Screen = ERROR;
                }
                else
                {
                    Screen = Math.Round(decimal.Parse(Screen), 10 - numberOfDigitsBeforeTheComma).ToString();
                }
            }
        }

        private void digitCounter()
        {
            string onlyDigitScreen = Screen.Replace(",", "").Replace("-", "");
            DigitCount = onlyDigitScreen.Length;
        }

        private bool checkForComma()
        {
            return Screen.Contains(",");
        }
    }
}
