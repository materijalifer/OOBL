﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string currentDisplayStateString = "0";
        double currentDisplayStateNumber = 0;

        string currentString = "";
        double currentNumber = 0;
        string currentNumberString = "";

        char counter;

        string memoryString = "";
        double memoryNumber = 0; 

        bool plus = false;
        bool minus = false;
        bool product = false;
        bool divide = false;

        int length = 0;
        char rememberOperation;
        char rememberOperationForEqual;
        double operationNumber;

        public void Press(char inPressedDigit)
        {
            for (counter = '0'; counter <= '9'; counter++)
            {
                if (currentString == "0" && inPressedDigit == '0')
                    return;
                if (counter == inPressedDigit)
                {
                    currentString = currentString + inPressedDigit;
                    currentDisplayStateNumber = Convert.ToDouble(currentString);
                    currentDisplayStateString = Convert.ToString(currentString);
                    rememberOperation = inPressedDigit;
                    return;
                }
            }

            if (inPressedDigit == '+' && rememberOperation =='+' || inPressedDigit == '-' && rememberOperation =='-' || inPressedDigit == '*' && rememberOperation =='*' || inPressedDigit == '/' && rememberOperation =='/')
                return;
            if (inPressedDigit == '+' && (rememberOperation == '-' || rememberOperation == '*' || rememberOperation == '/'))
            {
                minus = false;
                product = false;
                divide = false;

            }
            else if (inPressedDigit == '-' && (rememberOperation == '+' || rememberOperation == '*' || rememberOperation == '/'))
            {
                plus = false;
                product = false;
                divide = false;

            }
            else if (inPressedDigit == '*' && (rememberOperation == '+' || rememberOperation == '-' || rememberOperation == '/'))
            {
                minus = false;
                plus = false;
                divide = false;

            }
            else if (inPressedDigit == '/' && (rememberOperation == '+' || rememberOperation == '-' || rememberOperation == '*'))
            {
                minus = false;
                product = false;
                plus = false;

            }
            if (inPressedDigit == ',')
            {
                if (currentString.Contains(","))
                {
                    currentDisplayStateString = "-E-";
                    GetCurrentDisplayState();
                    return;
                }
                if (currentString == "")
                    currentString = "0,";
                else
                    currentString = currentString + ',';
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == 'M')
            {
                currentDisplayStateNumber = currentDisplayStateNumber * (-1);
                currentString = Convert.ToString(currentDisplayStateNumber);
                currentDisplayStateString = currentString;
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == 'C')
            {
                currentDisplayStateString = "0";
                currentDisplayStateNumber = 0;
                currentString = "";
                rememberOperation = inPressedDigit;

                return;
            }

            if (inPressedDigit == 'O')
            {
                currentDisplayStateString = "0";
                currentDisplayStateNumber = 0;
                currentString = "";
                currentNumber = 0;
                memoryString = "";
                memoryNumber = 0;
                rememberOperation = inPressedDigit;

                return;
            }

            if (inPressedDigit == 'P')
            {
                memoryString = memoryString + currentString;
                memoryNumber = Convert.ToDouble(memoryString);
                currentString = "";
                currentNumber = 0;
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == 'G')
            {
                currentDisplayStateString = memoryString;
                currentDisplayStateNumber = memoryNumber;
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == 'S')
            {
                currentDisplayStateNumber = Math.Round(Math.Sin(currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                currentString = "";
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == 'K')
            {
                currentDisplayStateNumber = Math.Round(Math.Cos(currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                currentString = "";
                rememberOperation = inPressedDigit;
                return;
            }
            if (inPressedDigit == 'T')
            {
                currentDisplayStateNumber = Math.Round(Math.Tan(currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                currentString = "";
                rememberOperation = inPressedDigit;
                return;
            }
            if (inPressedDigit == 'Q')
            {
                currentDisplayStateNumber = Math.Round(Math.Pow(currentDisplayStateNumber, 2), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = inPressedDigit;
                return;
            }
            if (inPressedDigit == 'R')
            {
                currentDisplayStateNumber = Math.Round(Math.Sqrt(currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = inPressedDigit;
                return;
            }
            if (inPressedDigit == 'I')
            {
                if (currentDisplayStateNumber == 0)
                {
                    currentDisplayStateString = "-E-";
                    return;
                }
                currentDisplayStateNumber = 1 / currentDisplayStateNumber;
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                currentString = "";
                rememberOperation = inPressedDigit;
                return;
            }

            if (inPressedDigit == '=' && rememberOperation == '=')
            {
                switch (rememberOperationForEqual)
                {
                    case '+':
                        currentDisplayStateNumber += operationNumber;
                        currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                        break;
                    case '-':
                        currentDisplayStateNumber -= operationNumber;
                        currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                        break;
                    case '*':
                        currentDisplayStateNumber *= operationNumber;
                        currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                        break;
                    case '/':
                        currentDisplayStateNumber /= operationNumber;
                        currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                        break;
                }
            }
            if (inPressedDigit == '=' && rememberOperation == '+')
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber * 2), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = '=';
                rememberOperationForEqual = '+';
                plus = false;
                return;
            }

            if (inPressedDigit == '=' && rememberOperation == '-')
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber - currentNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = '=';
                rememberOperationForEqual = '-';
                minus = false;
                return;
            }


            if (inPressedDigit == '=' && rememberOperation == '*')
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber * currentNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = '=';
                rememberOperationForEqual = '*';
                product = false;
                return;
            }

            if (inPressedDigit == '=' && rememberOperation == '/')
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber / currentNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = '=';
                rememberOperationForEqual = '/';
                divide = false;
                return;
            }

            if (plus == true && (inPressedDigit == '=' || inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/'))
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber + currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = inPressedDigit;
                plus = false;
                CheckOperation(inPressedDigit);
                return;
            }

            if (minus == true && (inPressedDigit == '=' || inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/'))
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber - currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = inPressedDigit;
                minus = false;
                CheckOperation(inPressedDigit);
                return;
            }

            if (product == true && (inPressedDigit == '=' || inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/'))
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber * currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = '*';
                product = false;
                CheckOperation(inPressedDigit);
                return;
            }

            if (divide == true && (inPressedDigit == '=' || inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/'))
            {
                operationNumber = currentDisplayStateNumber;
                currentDisplayStateNumber = Math.Round((currentNumber / currentDisplayStateNumber), 9);
                currentDisplayStateString = Convert.ToString(currentDisplayStateNumber);
                rememberOperation = inPressedDigit;
                rememberOperationForEqual = inPressedDigit;
                divide = false;
                CheckOperation(inPressedDigit);
                return;
            }
            if (inPressedDigit == '+')
            {
                GetReadyForPlus(inPressedDigit);
                return;
            }
            
            if (inPressedDigit == '-')
            {
                GetReadyForMinus(inPressedDigit);
                return;
            }
            

            if (inPressedDigit == '*')
            {
                GetReadyForProduct(inPressedDigit);
                return;
            }
            
            if (inPressedDigit == '/')
            {
                GetReadyForDivide(inPressedDigit);
                return;
            }
           
     }
        public void GetReadyForPlus(char inPressedDigit)
        {
            currentNumber = currentDisplayStateNumber;
            currentNumberString = Convert.ToString(currentNumber);
            currentString = "";
            plus = true;
            rememberOperation = inPressedDigit;
        }

        public void GetReadyForMinus(char inPressedDigit)
        {
            currentNumber = currentDisplayStateNumber;
            currentNumberString = Convert.ToString(currentNumber);
            currentString = "";
            rememberOperation = inPressedDigit;
            minus = true;
        }

        public void GetReadyForProduct(char inPressedDigit)
        {
            currentNumber = currentDisplayStateNumber;
            currentNumberString = Convert.ToString(currentNumber);
            currentString = "";
            product = true;
            rememberOperation = inPressedDigit;
        }

        public void GetReadyForDivide(char inPressedDigit)
        {
            currentNumber = currentDisplayStateNumber;
            currentNumberString = Convert.ToString(currentNumber);
            currentString = "";
            rememberOperation = inPressedDigit;
            divide = true;
        }
        public void CheckOperation(char inPressedDigit)
        {
            if (inPressedDigit == '+')
            {
                plus = true;
                currentString = "";
                currentNumber = currentDisplayStateNumber;
            }
            else if (inPressedDigit == '-')
            {
                minus = true;
                currentString = "";
                currentNumber = currentDisplayStateNumber;
            }
            else if (inPressedDigit == '*')
            {
                product = true;
                currentString = "";
                currentNumber = currentDisplayStateNumber;
            }
            else if (inPressedDigit == '/')
            {
                divide = true;
                currentString = "";
                currentNumber = currentDisplayStateNumber;
            }
        }
        public string RemoveDecimalZeroes(string number)
        {
            while (number.Contains(","))
            {
                length = number.Length;
                if (number[length - 1] == '0')
                {
                    number = number.Substring(0, length - 1);
                }
                else if (number[length - 1] == ',')
                    number = number.Substring(0, length - 1);
                else
                    break;
            }
            return number;
        }
        
        public string GetCurrentDisplayState()
        {
            if (currentDisplayStateNumber > 9999999999 || currentDisplayStateNumber < -9999999999 || currentDisplayStateString == "NaN")
                return "-E-";
            else if (currentDisplayStateString.Length <= 12)
                    return RemoveDecimalZeroes (currentDisplayStateString);
                 else
                    return currentDisplayStateString.Substring(0, 12);
        }
    }


}
