﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        #region [Atributi]
        public List<string> tempDisplay = new List<string>(new string [] {"", "", "", ""});
        public List<string> numbers = new List<string>(new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" });
        public List<string> operators = new List<string>(new string[] { "+", "-", "*", "/", "=", "M", "Q", "R","I", "S", "K", "T", "P", "G", "," });
        public List<string> systemOperators = new List<string>(new string[] { "C", "O" });
        public List<string> mathOperators = new List<string>(new string[] { "S", "K", "T", "Q", "R","I" });
        public List<string> binaryOperators = new List<string>(new string[] { "+", "-", "*", "/" });
        public string display = "0";
        public string lastvalue = "";
        public string memory = "";
        public int count = 1;
        public int element = 1;
        #endregion
        #region [Metode]
        public void Press(char inPressedDigit)
        {
            if (!systemOperators.Contains(inPressedDigit.ToString()) && !operators.Contains(inPressedDigit.ToString()) && !numbers.Contains(inPressedDigit.ToString()))
            {
                Error();
                return;
            }
            if (numbers.Contains(inPressedDigit.ToString()))
            {
                NumberDigit(inPressedDigit.ToString());
            }
            else if (operators.Contains(inPressedDigit.ToString()))
            {
                OperatorDigit(inPressedDigit.ToString());
            }
            else if (systemOperators.Contains(inPressedDigit.ToString()))
            {
                SystemOperatorDigit(inPressedDigit.ToString());
            }
            else if (display.Equals("-E-") || tempDisplay[0].Equals("-E-"))
            {
                if (!inPressedDigit.ToString().Equals('C') && !inPressedDigit.ToString().Equals('O'))
                    return;
            }
            else
            {
                return;
            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        public void Error()
        {
            display = "-E-";
            tempDisplay[0] = "-E-";

        }
        public void EraseDisplay()
        {
            count = 1;
            display = "0";
            tempDisplay[element] = "";
            tempDisplay[0] = "";
        }
        public void OnOffDisplay()
        {
            memory = "0";
            display = "0";
            for (int i=0; i< 4; i++)
            {
                tempDisplay[i] = "";
            }

        }
        public string Round(string value, int decimals) 
        {
            return Math.Round(double.Parse(value),decimals - (value.IndexOf(",")+1)).ToString();
        }
        public void MaxRestriction()
        {
            if ((display.Length > 12) && display.Contains(",") && display.Contains("-"))
                display = Round(display, 12);
            else if (((display.Length > 12) && display.Contains(",") && !display.Contains("-")) || ((display.Length > 12) && !display.Contains(",") && display.Contains("-")))
                display = Round(display, 11);
            else if ((display.Length > 10) && !display.Contains("-") && !display.Contains(","))
                Error();

            else
                return;
        }
        public void BinaryCalculation(string firstValue, string _operator, string secondValue)
        {
            double valueFirst = double.Parse(firstValue);
            double valueSecond = double.Parse(secondValue);
            switch (_operator) { 
                case "-":
                    valueFirst -= valueSecond;
                    lastvalue = valueFirst.ToString();
                    tempDisplay[1]=lastvalue;
                    element = 2;
                    display = lastvalue;
                    MaxRestriction();
                    return;
                case "+":
                    valueFirst += valueSecond;
                    lastvalue = valueFirst.ToString();
                    tempDisplay.ElementAt(1).Replace(tempDisplay.ElementAt(1), lastvalue);
                    element = 2;
                    display = lastvalue;
                    MaxRestriction();
                    return;
                case "*":
                    valueFirst *= valueSecond;
                    lastvalue = valueFirst.ToString();
                    tempDisplay[1]=lastvalue;
                    element = 2;
                    display = lastvalue;
                    MaxRestriction();
                    return;
                case "/":
                    valueFirst /= valueSecond;
                    lastvalue = valueFirst.ToString();
                    tempDisplay.ElementAt(1).Replace(tempDisplay.ElementAt(1), lastvalue);
                    element = 2;
                    display = lastvalue;
                    MaxRestriction();
                    return;
            }
        }
        public void OperatorDigit(string value) 
        {
            if (count > 12)
            {
                if ((tempDisplay[element].Contains("-") && !tempDisplay[element].Contains(",")) || (!tempDisplay[element].Contains("-") && tempDisplay[element].Contains(",")))
                    Round(tempDisplay[element], 11);
                if (tempDisplay[element].Contains("-") && tempDisplay[element].Contains(","))
                    Round(tempDisplay[element], 12);
            }
            if (value.Equals("M"))
            {
                if (display.Equals("0"))
                {
                    return;
                }
                else if (!display.StartsWith("-"))
                {
                    display = "-" + display;
                    tempDisplay[element] = "-" + tempDisplay[element];
                    count++;
                }
                else
                {
                    display = display.Remove(0, 1);
                    count--;
                }
            }
            else if (value.Equals(","))
            {
                if (!display.Contains(","))
                {
                    display += value;
                    tempDisplay[element] = display;
                    count++;
                }
                else
                {
                    tempDisplay[2 + element] += value;
                }
            }
            else if (value.Equals("="))
            {
                if (tempDisplay[1].Equals("") && tempDisplay[2].Equals(""))
                    display = "0";
                else
                {                    
                    if ((!tempDisplay[2].Equals("")) && !(tempDisplay[3].Equals("")))
                        BinaryCalculation(tempDisplay[1], tempDisplay[3], tempDisplay[2]);
                    if (tempDisplay[2].Equals("") && !tempDisplay[3].Equals(""))
                    {
                        tempDisplay[2] = tempDisplay[1];
                        BinaryCalculation(tempDisplay[1], tempDisplay[3], tempDisplay[2]);
                    }

                }
                if ((tempDisplay[element].Contains(",")) && (tempDisplay[element].EndsWith("0") && (tempDisplay[element].IndexOf(",").Equals(tempDisplay[element].LastIndexOf("0")-tempDisplay[element].IndexOf(",")+1))))
                {
                    tempDisplay[element] = tempDisplay[element].Substring(0, tempDisplay[element].IndexOf(","));
                    display = tempDisplay[element];
                 }
                else if ((tempDisplay[element].Contains(",")) && (tempDisplay[element].EndsWith("0") && (tempDisplay[element].IndexOf(",").Equals(tempDisplay[element].Length-2))))
                {
                    tempDisplay[element] = tempDisplay[element].Substring(0, tempDisplay[element].IndexOf(","));
                    display = tempDisplay[element];
                }
                else if ((tempDisplay[element].Contains(",")) && (tempDisplay[element].IndexOf(",").Equals(tempDisplay[element].Length - 1)))
                {
                    tempDisplay[element] = tempDisplay[element].Substring(0, tempDisplay[element].IndexOf(","));
                    display = tempDisplay[element];
                }
                }
            else if (binaryOperators.Contains(value))
                {
                    if (!tempDisplay[2].Equals(""))
                    {                       
                        BinaryCalculation(tempDisplay[1], value, tempDisplay[2]);
                    }
                    if (tempDisplay[1].Equals("") && tempDisplay[2].Equals(""))
                    {
                        tempDisplay[1] = "0";
                        //tempDisplay[3] = value;
                        element = 2;
                        count = 2;
                    
                    }
                tempDisplay[3] = value;
                element = 2;
                if ((tempDisplay[1].Contains(",")) && (tempDisplay[1].EndsWith("0") && (tempDisplay[1].IndexOf(",").Equals(tempDisplay[1].Length - 2))))
                {
                    tempDisplay[1] = tempDisplay[1].Substring(0, tempDisplay[1].IndexOf(","));
                    display = tempDisplay[1];
                }
            }
            else if ((tempDisplay[element].Contains(",")) && (tempDisplay[element].EndsWith("0") && (tempDisplay[element].IndexOf(",").Equals(tempDisplay[element].Length - 2))))
            {
                tempDisplay[element] = tempDisplay[element].Substring(0, tempDisplay[element].IndexOf(","));
                display = tempDisplay[element];
            }

            else if ((tempDisplay[element].Contains(",")) && (tempDisplay[element].IndexOf(",").Equals(tempDisplay[element].Length - 1)))
            {
                tempDisplay[element] = tempDisplay[element].Substring(0, tempDisplay[element].IndexOf(","));
                display = tempDisplay[element];

            }
            //užasni dio
            if (!value.Equals(",") && !value.Equals("M") && !binaryOperators.Contains(value) && !value.Equals("="))
            {

                if (element.Equals(1) && !(mathOperators.Contains(value)))
                    element = 2;

                if (value.Equals("P"))
                {
                    if (operators.Any(display.Contains) || systemOperators.Any(display.Contains))
                    {
                        Error();
                        return;
                    }
                    memory += display;
                    display = "0";
                }

                if (value.Equals("G"))
                {
                    display = memory;
                    tempDisplay[element] += display;
                }

                if (!value.Equals("G") && !value.Equals("P"))
                {
                    if (element.Equals(2) && tempDisplay[element].Equals(""))
                        element = 1;

                    double temp;
                    temp = double.Parse(tempDisplay[element]);

                    if (value.Equals("Q"))
                        temp = Math.Pow(temp, 2);
                    if (value.Equals("R"))
                        temp = Math.Pow(temp, 0.5);
                    if (value.Equals("S"))
                        temp = Math.Sin(temp);
                    if (value.Equals("K"))
                        temp = Math.Cos(temp);
                    if (value.Equals("T"))
                        temp = Math.Tan(temp);
                    if (value.Equals("I"))
                    {
                        if (temp.Equals(0))
                        {
                            Error();
                            return;
                        }
                        else
                            temp = 1 / temp;
                    }
                    if ((temp > 9999999999) && (temp < -9999999999))
                    {
                        Error();
                        return;
                    }
                    display = temp.ToString();

                    if (!binaryOperators.Contains(tempDisplay[3]) || element.Equals(2))
                        tempDisplay[element] = temp.ToString();

                    MaxRestriction();

                    if (element.Equals(1) && binaryOperators.Contains(tempDisplay[3]))
                        element = 2;

                    if (!binaryOperators.Contains(tempDisplay[3]))
                        tempDisplay[3] = value;
                }
            }
            //kraj
            

        }
        public void NumberDigit(string value)
        {
            if (count.Equals(1) && display.Equals("0"))
            {
                display = value;
                tempDisplay[element] = display;
                count = 0;
            }
            else if (count.Equals(1) && !display.Equals("0"))
            {
                if (!mathOperators.Contains(tempDisplay[3]))
                {
                    tempDisplay[element] += value;
                    display = tempDisplay[element];
                }
                else
                {
                    tempDisplay[element] = value;
                    tempDisplay[3] = "";
                    display = tempDisplay[element];
                }
            }
            else if ((count > 1) && (count <= 10))
            {
                if ((display.Contains(",") && count.Equals(10)) || (display.Contains("-") && count.Equals(10)))
                {
                    tempDisplay[element] += value;
                    display = tempDisplay[element];
                }
                else
                {
                    tempDisplay[element] += value;
                    display = tempDisplay[element];
                }
            }
            else if (count.Equals(11))
            {
                if (display.Contains(",") && display.Contains("-"))
                {
                    tempDisplay[element] += value;
                    display = tempDisplay[element];
                }
                else
                    tempDisplay[element] += value;
            }
            else if ((count >= 12) && (tempDisplay[element].Contains(",")))
                tempDisplay[element] += value;
            else if ((count > 10) && (!display.Contains(",")))
                Error();
            else
                return;
            count++;        
        }
        public void SystemOperatorDigit(string value)
        {
            if (value.Contains("C"))
            {
                EraseDisplay();
                return;
            }
            else
                OnOffDisplay();
        }

        #endregion
    }


}
