﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Klasa koja predstavlja dionicu.
    /// Kao atribute sadrži ime dionice, koje je ujedno i jedinstveno,
    /// broj dionica, cijene i trenutak od kojeg neka cijena vrijedi.
    /// </summary>
    public class Stock
    {
        #region Fields & Properties...

        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private long _numberOfShares;
        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }

        private decimal _initialPrice;
        public decimal InitialPrice
        {
            get { return _initialPrice; }
            set { _initialPrice = value; }
        }

        private DateTime _timeStamp;
        public DateTime TimeStamp
        {
            get { return _timeStamp; }
            set { _timeStamp = value; }
        }

        private Dictionary<DateTime, decimal> _mapOfPrices;
        public Dictionary<DateTime, decimal> MapOfPrices
        {
            get { return _mapOfPrices; }
            set
            {

                _mapOfPrices = value;
            }
        }

        private long _usedShares;
        public long UsedShares
        {
            get { return _usedShares; }
            set { _usedShares = value; }
        }

        #endregion

        #region Methods...

        /// <summary>
        /// Metoda koja dodaje novu cijenu u nekom trenutku.
        /// </summary>
        /// <param name="timestamp">Trenutak dodavanja</param>
        /// <param name="price">Nova cijena</param>
        public void AddTimestampAndPrice(DateTime timestamp, decimal price)
        {
            try
            {
                ValidatePrice(price);
                _mapOfPrices.Add(timestamp, price);
            }
            catch
            {
                throw new StockExchangeException("Ne može se dodati više cijena u isti trenutak!");
            }
        }

        /// <summary>
        /// Metoda koja dohvaća za određeni trenutak cijenu dionice.
        /// </summary>
        /// <param name="timestamp">Trenutak za koji se dhovaća</param>
        /// <returns>Cijena dionice</returns>
        public decimal GetStockPrice(DateTime timestamp)
        {
            if (_mapOfPrices.ContainsKey(timestamp))
                return _mapOfPrices[timestamp];
            else
                return 0.0m;
        }

        /// <summary>
        /// Metoda koja vraća sumu svih cijena dionice.
        /// </summary>
        /// <returns>Suma svih cijena</returns>
        public decimal SumOfStockPrices()
        {
            decimal total = 0.0m;

            foreach (var price in _mapOfPrices.Values)
            {
                total += price;
            }

            return total;
        }

        /// <summary>
        /// Metoda kojom se definira koliko je ukupno udjela dionica kupljeno.
        /// </summary>
        /// <param name="numberOfShares">Broj dionica koje se kupuju</param>
        public void BuyShares(int numberOfShares)
        {
            long availableShares = _numberOfShares - _usedShares;

            if (availableShares >= numberOfShares)
            {
                _usedShares += numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Ne može se kupiti toliko udjela dionica!");
            }
        }
        /// <summary>
        /// Metoda kojom je definirano koliko je udjela dionica prodano.
        /// </summary>
        /// <param name="numberOfShares">Prodane dionice</param>
        public void SellShares(int numberOfShares)
        {
            if (numberOfShares > _usedShares)
            {
                throw new StockExchangeException("Ne može se toliko udjela dionica prodati!");
            }
            else
            {
                _usedShares -= numberOfShares;
            }
        }

        #endregion

        #region Validation...
        //validacija imena
        private static void ValidateName(string name)
        {
            if (name.Length == 0)
                throw new StockExchangeException("Potrebno je upisati ime!");
        }
        //validacija broja udjela dionice
        private static void ValidateNumberOfShares(long numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Broj dionica ne može biti negativan ili manji od 0!");
        }
        //validacija cijene
        private static void ValidatePrice(decimal price)
        {
            if (price <= 0)
                throw new StockExchangeException("Cijena dionica ne može biti negativna ili manja od 0!");
        }


        #endregion

        #region Constructors...

        public Stock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            ValidateName(name);
            ValidateNumberOfShares(numberOfShares);
            ValidatePrice(initialPrice);

            this._name = name;
            this._numberOfShares = numberOfShares;
            this._initialPrice = initialPrice;
            this._timeStamp = timeStamp;
            this._mapOfPrices = new Dictionary<DateTime, decimal>();
            this._usedShares = 0;

            _mapOfPrices.Add(timeStamp, initialPrice);
        }

        #endregion

        #region Equals Override...

        public override bool Equals(object obj)
        {
            Stock other = (Stock)obj;

            return other.Name.ToLower().Equals(this.Name.ToLower());
        }
        #endregion
    }

    /// <summary>
    /// Factory koji stvara objekte korištene u programu.
    /// (Stock, Index, Portfolio)
    /// </summary>
    public class StockExchangeFactory
    {
        public static Stock CreateStock(string name, long numberOfShares, decimal initialPrice, DateTime timestamp)
        {
            return new Stock(name, numberOfShares, initialPrice, timestamp);
        }

        public static Index CreateIndex(string name, IndexTypes type)
        {
            return new Index(name, type);
        }

        public static Portfolio CreatePortfolio(string id)
        {
            return new Portfolio(id);
        }
    }

    /// <summary>
    /// Repozitorij objekata Stock s pripadajućim metodama.
    /// </summary>
    public class StockRepository
    {

        #region Private fields...

        private List<Stock> _stocks;

        #endregion

        #region Constructors...

        public StockRepository()
        {
            _stocks = new List<Stock>();
        }

        #endregion

        #region Helpers...
        /// <summary>
        /// Metoda koja vraća dionicu po njenom imenu.
        /// </summary>
        /// <param name="name">Ime dionice koja se traži</param>
        /// <returns>Nađena dionica</returns>
        public Stock GetStockByName(string name)
        {
            try
            {
                return _stocks.Where(s => s.Name.ToLower().Equals(name.ToLower())).Single();
            }
            catch
            {
                throw new StockExchangeException("Nepostojeća dionica!");
            }
        }

        #endregion

        #region Methods...

        /// <summary>
        /// Metoda koja provjerava da li postoji tražena dionica.
        /// </summary>
        /// <param name="stock">Tražena dionica</param>
        /// <returns>T OR F</returns>
        public bool StockExists(Stock stock)
        {
            return _stocks.Contains(stock);
        }
        /// <summary>
        /// Metoda koja dodaje novu dionicu.
        /// </summary>
        /// <param name="newStock">Nova dionica</param>
        public void AddNewStock(Stock newStock)
        {
            if (this.StockExists(newStock))
            {
                throw new StockExchangeException("Postoji ta dionica!");
            }

            _stocks.Add(newStock);
        }
        /// <summary>
        /// Metoda koja briše postojeću dionicu.
        /// </summary>
        /// <param name="stock">Dionica koja se briše</param>
        public void RemoveStock(Stock stock)
        {
            bool remove = _stocks.Remove(stock);

            if (!remove)
                throw new StockExchangeException("Neuspješno micanje dionice!");
        }
        /// <summary>
        /// Metoda koja vraća ukupan broj postojećih dionica.
        /// </summary>
        /// <returns>Broj postojećih dionica</returns>
        public int NumberOfStocks()
        {
            return _stocks.Count;
        }
        /// <summary>
        /// Metoda koja postavlja novu cijenu dionice za neki trenutak.
        /// </summary>
        /// <param name="stockName">Ime dionice</param>
        /// <param name="timestamp">Trenutak nove cijene</param>
        /// <param name="stockValue">Nova cijena</param>
        public void SetStock(string stockName, DateTime timestamp, decimal stockValue)
        {
            Stock stock = this.GetStockByName(stockName);

            stock.AddTimestampAndPrice(timestamp, stockValue);
        }
        /// <summary>
        /// Metoda koja vraća cijenu dionice u nekom trenutku.
        /// </summary>
        /// <param name="stockName">Ime dionice</param>
        /// <param name="timestamp">Trenutak</param>
        /// <returns>Cijena u traženom trenutku</returns>
        public decimal GetStockPrice(string stockName, DateTime timestamp)
        {
            Stock stock = this.GetStockByName(stockName);

            return stock.GetStockPrice(timestamp);
        }
        /// <summary>
        /// Metoda koja vraća početnu cijenu dionice.
        /// </summary>
        /// <param name="name">Ime dionice</param>
        /// <returns>Početna cijena dionice</returns>
        public decimal GetInitialPrice(string name)
        {

            return this.GetStockByName(name).InitialPrice;
        }
        /// <summary>
        /// Metoda koja vraća posljednju cijenu dionice.
        /// </summary>
        /// <param name="name">Ime dionice</param>
        /// <returns>Posljednja cijena dionice</returns>
        public decimal GetLastPrice(string name)
        {

            return this.GetStockByName(name).MapOfPrices.OrderByDescending(m => m.Key).First().Value;
        }

        #endregion
    }
    /// <summary>
    /// Klasa koja predstavlja indeks burze.
    /// Atribute koje sadrži su naziv indeksa,
    /// njegov tip i dionice za taj indeks.
    /// </summary>
    public class Index
    {
        #region Fields & Properties...

        private string _indexName;
        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }

        private IndexTypes _indexTypes;
        public IndexTypes IndexTypes
        {
            get { return _indexTypes; }
            set { _indexTypes = value; }
        }

        private List<Stock> _stocks;
        public List<Stock> Stocks
        {
            get { return _stocks; }
            set { _stocks = value; }
        }

        #endregion

        #region Methods...

        /// <summary>
        /// Metoda koja vraća broj dionica u indeksu.
        /// </summary>
        /// <returns></returns>
        public int StockCount()
        {
            return _stocks.Count;
        }

        /// <summary>
        /// Metoda koja vraća vrijednost indeksa u nekom trenutku.
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public decimal GetValue(DateTime timestamp)
        {
            decimal indexValue;

            if (_indexTypes == IndexTypes.AVERAGE)
            {
                indexValue = this.GetAverageValue(timestamp);
            }
            else if (_indexTypes == IndexTypes.WEIGHTED)
            {
                indexValue = this.GetWeightedValue(timestamp);
            }
            else
            {
                throw new StockExchangeException("Greska pri dohvatu vrijednosti!");
            }
            return indexValue;
        }

        //Average IndexType formula
        private decimal GetAverageValue(DateTime timestamp)
        {
            decimal sum = 0.0m;

            foreach (var stock in _stocks)
            {
                sum += stock.GetStockPrice(timestamp);
            }

            return decimal.Round(sum / _stocks.Count, 3, MidpointRounding.ToEven);
        }

        //Weighted IndexType formula
        private decimal GetWeightedValue(DateTime timestamp)
        {
            decimal sum = 0.0m;

            decimal totalIndexSum = this.SumOfPrices();

            foreach (var stock in _stocks)
            {
                long numberOfShares = stock.NumberOfShares;
                decimal stockPrice = stock.GetStockPrice(timestamp);

                sum += ((numberOfShares * stockPrice) / totalIndexSum) * stockPrice;
            }

            return decimal.Round(sum, 3, MidpointRounding.ToEven);
        }

        //Vraća zbroj svih cijena
        private decimal SumOfPrices()
        {
            decimal totalSum = 0.0m;

            foreach (var stock in _stocks)
            {
                long numberOfShares = stock.NumberOfShares;

                totalSum += numberOfShares * stock.SumOfStockPrices();
            }

            return totalSum;
        }
        /// <summary>
        /// Metoda koja dodaje novu dionicu u indeks.
        /// </summary>
        /// <param name="stock"></param>
        public void AddStockToIndex(Stock stock)
        {
            if (this.StockExists(stock))
            {
                throw new StockExchangeException("Postoji već ta dionica u indeksu!");
            }

            _stocks.Add(stock);
        }
        /// <summary>
        /// Metoda koja briše postojeću dionicu iz indeksa.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            try
            {
                _stocks.Remove(stock);
            }
            catch
            {
                throw new StockExchangeException("Greska u brisanju dionice iz indeksa!");
            }
        }
        /// <summary>
        /// Metoda koja javlja da li postoji tražena dionica u indeksu.
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool StockExists(Stock stock)
        {
            return _stocks.Contains(stock);
        }

        #endregion

        #region Constructors...

        public Index(string indexName, IndexTypes indexTypes)
        {
            this._indexName = indexName;
            this._indexTypes = indexTypes;
            this._stocks = new List<Stock>();
        }

        #endregion

        #region Equals Override...

        public override bool Equals(object obj)
        {
            Index other = (Index)obj;

            return other.IndexName.ToLower().Equals(this.IndexName.ToLower());
        }

        #endregion
    }

    public class IndexRepository
    {
        #region Private fields...

        private List<Index> _indices;

        #endregion

        #region Constructors...

        public IndexRepository()
        {
            _indices = new List<Index>();
        }

        #endregion

        #region Helpers...
        //vrati indeks po imenu
        private Index getIndexByName(string name)
        {
            try
            {
                return _indices.Where(i => i.IndexName.ToLower().Equals(name.ToLower())).Single();
            }
            catch
            {
                throw new StockExchangeException("Nepostojeći indeks!");
            }
        }

        #endregion

        #region Methods...
        /// <summary>
        /// Metoda koja javlja da li indeks postoji.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool IndexExists(Index index)
        {
            return _indices.Contains(index);
        }
        /// <summary>
        /// Metoda koja vraća broj postojećih indeksa.
        /// </summary>
        /// <returns></returns>
        public int NumberOfIndices()
        {
            return _indices.Count;
        }
        /// <summary>
        /// Metoda koja dodaje novi indeks.
        /// </summary>
        /// <param name="index"></param>
        public void AddNewIndex(Index index)
        {
            if (_indices.Contains(index))
            {
                throw new StockExchangeException("Postoji taj indeks!");
            }

            _indices.Add(index);
        }
        /// <summary>
        /// Metoda koja dodaje dionicu u postojeći indeks.
        /// </summary>
        /// <param name="indexName"></param>
        /// <param name="stock"></param>
        public void AddStockToIndex(string indexName, Stock stock)
        {
            Index index = this.getIndexByName(indexName);

            index.AddStockToIndex(stock);
        }
        /// <summary>
        /// Metoda koja briše dionicu iz indeksa.
        /// </summary>
        /// <param name="indexName"></param>
        /// <param name="stock"></param>
        public void RemoveStock(string indexName, Stock stock)
        {
            Index index = this.getIndexByName(indexName);

            index.RemoveStock(stock);
        }
        /// <summary>
        /// Metoda koja briše dionicu iz svih indeksa.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveAllSameStocks(Stock stock)
        {
            foreach (var index in _indices)
            {
                this.RemoveStock(index.IndexName, stock);
            }
        }
        /// <summary>
        /// Metoda koja vraća da li postoji tražena dionica u nekom indeksu.
        /// </summary>
        /// <param name="indexName"></param>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool StockExistsInIndex(string indexName, Stock stock)
        {
            return this.getIndexByName(indexName).StockExists(stock);
        }
        /// <summary>
        /// Metoda koja vraća broj dionica u indeksu.
        /// </summary>
        /// <param name="indexName"></param>
        /// <returns></returns>
        public int StockCountInIndex(string indexName)
        {
            return this.getIndexByName(indexName).StockCount();
        }
        /// <summary>
        /// Metoda koja vraća vrijednost indeksa u nekom trenutku.
        /// </summary>
        /// <param name="indexName"></param>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public decimal IndexValue(string indexName, DateTime timestamp)
        {
            return this.getIndexByName(indexName).GetValue(timestamp);
        }

        #endregion
    }
    /// <summary>
    /// Klasa koja prestavlja portfolio dionica.
    /// </summary>
    public class Portfolio
    {
        #region Fields & Properties...

        private string _id;
        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }

        private Dictionary<Stock, long> _mapOfStockShares;
        public Dictionary<Stock, long> MapOfStockShares
        {
            get { return _mapOfStockShares; }
            set { _mapOfStockShares = value; }
        }

        #endregion

        #region Constructors...

        public Portfolio(string id)
        {
            this._id = id;
            _mapOfStockShares = new Dictionary<Stock, long>();
        }

        #endregion

        #region Methods...

        /// <summary>
        /// Metoda koja vraća broj dionica u portfoliju.
        /// </summary>
        /// <returns></returns>
        public int StocksInPortfolio()
        {
            return _mapOfStockShares.Count;
        }
        /// <summary>
        /// Metoda koja javlja da li postoji tražena dionica u portfoliju.
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool StockExists(Stock stock)
        {
            return _mapOfStockShares.ContainsKey(stock);
        }
        /// <summary>
        /// Metoda koja vraća broj udjela određene dionice u portfoliju.
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public int SharesOfStock(Stock stock)
        {
            return Convert.ToInt32(_mapOfStockShares[stock]);
        }
        /// <summary>
        /// Metoda koja briše dionicu iz portfolija.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            _mapOfStockShares.Remove(stock);
        }
        /// <summary>
        /// Metoda koja dodaje novu dionicu.
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void AddNewShares(Stock stock, int numberOfShares)
        {
            if (StockExists(stock))
            {
                _mapOfStockShares[stock] += numberOfShares;
            }
            else
            {
                _mapOfStockShares.Add(stock, numberOfShares);
            }
        }
        /// <summary>
        /// Metoda koja briše broj udjela određene dionice iz portfolija.
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void RemoveShares(Stock stock, int numberOfShares)
        {
            try
            {
                long oldNumberOfShares = _mapOfStockShares[stock];

                if (oldNumberOfShares > numberOfShares)
                {
                    _mapOfStockShares[stock] -= numberOfShares;
                }
                else if (oldNumberOfShares == numberOfShares)
                {
                    RemoveStock(stock);
                }
                else
                {
                    throw new StockExchangeException("Nemoguće ukloniti više od raspoloživih udjela dionica!");
                }
            }
            catch
            {
                throw new StockExchangeException("Greška pri uklanjanju udjela dionica!");
            }
        }
        /// <summary>
        /// Metoda koja vraća vrijednost dionica u portfoliju u nekom trenutku.
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public decimal GetStockValue(DateTime timestamp)
        {

            decimal sum = 0.0m;

            foreach (var stockSharePair in _mapOfStockShares)
            {
                long numberOfShares = stockSharePair.Value;

                sum += (numberOfShares * stockSharePair.Key.GetStockPrice(timestamp));
            }

            return decimal.Round(sum, 3, MidpointRounding.ToEven);
        }
        /// <summary>
        /// Metoda koja vraća postotak promjene vrijednosti od početka mjeseca do kraja.
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            int day = DateTime.DaysInMonth(year, month);

            DateTime startOfMonth = new DateTime(year, month, day, 0, 0, 0);

            DateTime endOfMonth = new DateTime(year, month, day, 23, 59, 59, 999);

            decimal startValue = GetStockValue(startOfMonth);
            decimal endValue = GetStockValue(endOfMonth);

            decimal result = (startValue > endValue ? (startValue - endValue) : (endValue - startValue)) / startValue * 100;

            return decimal.Round(result, 3, MidpointRounding.ToEven);
        }

        #endregion

        #region Equals Override...

        public override bool Equals(object obj)
        {
            Portfolio other = (Portfolio)obj;

            return other.ID.Equals(this._id);
        }


        #endregion
    }

    public class PortfolioRepository
    {
        #region Private fields...

        private List<Portfolio> _portfolios;

        #endregion

        #region Constructors...

        public PortfolioRepository()
        {
            _portfolios = new List<Portfolio>();
        }

        #endregion

        #region Helpers...
        //pronalazi portfolio po ID-u
        private Portfolio getPortfolioByID(string id)
        {
            try
            {
                return _portfolios.Where(p => p.ID.Equals(id)).Single();
            }
            catch
            {
                throw new StockExchangeException("Nepostojeći portfolio!");
            }
        }

        #endregion

        #region Methods...
        /// <summary>
        /// Metoda koja briše sve dionice iz portfolija.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveAllStocksFromPortifolio(Stock stock)
        {
            foreach (var portfolio in _portfolios)
            {
                portfolio.RemoveStock(stock);
            }
        }
        /// <summary>
        /// Metoda koja stvara novi portfolio.
        /// </summary>
        /// <param name="portfolio"></param>
        public void AddNewPortfolio(Portfolio portfolio)
        {
            if (PortfolioExists(portfolio))
            {
                throw new StockExchangeException("Postoji portfolio!");
            }

            _portfolios.Add(portfolio);
        }
        /// <summary>
        /// Metoda koja provjerava da li postoji određeni portfolio.
        /// </summary>
        /// <param name="portfolio"></param>
        /// <returns></returns>
        public bool PortfolioExists(Portfolio portfolio)
        {
            return _portfolios.Contains(portfolio);
        }
        /// <summary>
        /// Metoda koja vraća broj portfolija.
        /// </summary>
        /// <returns></returns>
        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }
        /// <summary>
        /// Metoda koja dodaje novu dionicu i njen udjel u portfolio.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void AddStockToPortfolio(string id, Stock stock, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioByID(id);

            portfolio.AddNewShares(stock, numberOfShares);
        }
        /// <summary>
        /// Metoda koja briše udjel dionice iz portfolija.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void RemoveStockFromPortfolio(string id, Stock stock, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioByID(id);

            portfolio.RemoveShares(stock, numberOfShares);
        }
        /// <summary>
        /// Metoda koja briše dionicu iz portfolija.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="stock"></param>
        public void RemoveStockFromPortfolio(string id, Stock stock)
        {
            Portfolio portfolio = getPortfolioByID(id);

            portfolio.RemoveStock(stock);
        }
        /// <summary>
        /// Metoda koja vraća broj dionica za neki portfolio.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int NumberOfStocks(string id)
        {
            Portfolio portfolio = getPortfolioByID(id);

            return portfolio.StocksInPortfolio();
        }
        /// <summary>
        /// Metoda koja vraća broj dionica u portfoliju.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool StockInPortifolio(string id, Stock stock)
        {
            Portfolio portfolio = getPortfolioByID(id);

            return portfolio.StockExists(stock);
        }
        /// <summary>
        /// Metoda koja vraća udjel dionica u portfoliju.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="stock"></param>
        /// <returns></returns>
        public int SharesOfStockInPortifolio(string id, Stock stock)
        {
            Portfolio portfolio = getPortfolioByID(id);

            return portfolio.SharesOfStock(stock);
        }
        /// <summary>
        /// Metoda koja vraća vrijednost dionica u portfoliju u nekom trenutku.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public decimal GetPortfolioValue(string id, DateTime timestamp)
        {
            Portfolio portfolio = getPortfolioByID(id);

            return portfolio.GetStockValue(timestamp);
        }
        /// <summary>
        /// Metoda koja vraća postotak promjene vrijednosti od početka do kraja mjeseca.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public decimal PortfolioPercentChangeInValueForMonth(string id, int year, int month)
        {
            Portfolio portfolio = getPortfolioByID(id);

            return portfolio.GetPercentChangeInValueForMonth(year, month);
        }

        #endregion
    }

    public class StockExchange : IStockExchange
    {

        private StockRepository _stockRepository = new StockRepository();
        private IndexRepository _indexRepository = new IndexRepository();
        private PortfolioRepository _portfolioRepository = new PortfolioRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock stock = StockExchangeFactory.CreateStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

            _stockRepository.AddNewStock(stock);
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _stockRepository.RemoveStock(stock);
            _indexRepository.RemoveAllSameStocks(stock);
            _portfolioRepository.RemoveAllStocksFromPortifolio(stock);

        }

        public bool StockExists(string inStockName)
        {
            Stock dummyStock = StockExchangeFactory.CreateStock(inStockName, 1, 1, DateTime.Now);

            return _stockRepository.StockExists(dummyStock);
        }

        public int NumberOfStocks()
        {
            return _stockRepository.NumberOfStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            _stockRepository.SetStock(inStockName, inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockRepository.GetStockPrice(inStockName, inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockRepository.GetInitialPrice(inStockName);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return _stockRepository.GetLastPrice(inStockName);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index = StockExchangeFactory.CreateIndex(inIndexName, inIndexType);

            _indexRepository.AddNewIndex(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _indexRepository.AddStockToIndex(inIndexName, stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _indexRepository.RemoveStock(inIndexName, stock);
        }


        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stock = null;

            try
            {
                stock = _stockRepository.GetStockByName(inStockName);
            }
            catch
            {
                return false;
            }

            return _indexRepository.StockExistsInIndex(inIndexName, stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return _indexRepository.IndexValue(inIndexName, inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            Index dummyIndex = StockExchangeFactory.CreateIndex(inIndexName, IndexTypes.AVERAGE);

            return _indexRepository.IndexExists(dummyIndex);
        }

        public int NumberOfIndices()
        {
            return _indexRepository.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _indexRepository.StockCountInIndex(inIndexName);
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio portfolio = StockExchangeFactory.CreatePortfolio(inPortfolioID);

            _portfolioRepository.AddNewPortfolio(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _portfolioRepository.AddStockToPortfolio(inPortfolioID, stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            _portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, stock);
        }

        public int NumberOfPortfolios()
        {
            return _portfolioRepository.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _portfolioRepository.NumberOfStocks(inPortfolioID);
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfolio dummyPortfolio = StockExchangeFactory.CreatePortfolio(inPortfolioID);

            return _portfolioRepository.PortfolioExists(dummyPortfolio);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            return _portfolioRepository.StockInPortifolio(inPortfolioID, stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Stock stock = _stockRepository.GetStockByName(inStockName);

            return _portfolioRepository.SharesOfStockInPortifolio(inPortfolioID, stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return _portfolioRepository.GetPortfolioValue(inPortfolioID, timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return _portfolioRepository.PortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
        }
    }
}
