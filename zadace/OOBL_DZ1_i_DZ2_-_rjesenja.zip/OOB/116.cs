﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Index> indices;
        private List<Stock> sharesOnMarket;
        private List<Portfolio> portfolios;

        public StockExchange()
        {
            this.indices = new List<Index>();
            this.sharesOnMarket = new List<Stock>();
            this.portfolios = new List<Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            String stockName = inStockName.ToLower();

            if (!StockExists(stockName))
            {
                this.sharesOnMarket.Add(new Stock(stockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
            {
                throw new StockExchangeException("Dionica postoji!");
            }
        }

        public void DelistStock(string inStockName)
        {
            String stockName = inStockName.ToLower();

            if (StockExists(stockName))
            {
                foreach (Index i in this.indices)
                {
                    if (IsStockPartOfIndex(i.IndexName, stockName))
                    {
                        RemoveStockFromIndex(i.IndexName, stockName);
                    }
                }

                Stock s = getStock(stockName);
                this.sharesOnMarket.Remove(s);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public bool StockExists(string inStockName)
        {
            String stockName = inStockName.ToLower();

            Stock s = getStock(stockName);
            if (s != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfStocks()
        {
            return this.sharesOnMarket.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            String stockName = inStockName.ToLower();

            if (StockExists(stockName))
            {
                Stock s = getStock(stockName);

                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);
                    if (DateTime.Compare(v.TimeStamp, inIimeStamp) >= 0)
                    {
                        throw new StockExchangeException("Postoji cijena za to vrijeme!");
                    }
                }

                foreach (Portfolio p in this.portfolios)
                {
                    if (IsStockPartOfPortfolio(p.PortfolioID, stockName))
                    {
                        Stock stock = p.getStockFromPortfolio(stockName);
                        stock.setNewStockPrice(inStockValue, inIimeStamp);

                    }
                }

                foreach (Index i in this.indices)
                {
                    if (IsStockPartOfIndex(i.IndexName, stockName))
                    {
                        Stock stock = i.getStockFromIndex(stockName);
                        stock.setNewStockPrice(inStockValue, inIimeStamp);
                    }
                }

                s.setNewStockPrice(inStockValue, inIimeStamp);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            String stockName = inStockName.ToLower();

            if (StockExists(stockName))
            {
                Stock s = getStock(stockName);

                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);

                    if (DateTime.Compare(v.TimeStamp, inTimeStamp) <= 0)
                    {
                        return v.Price;
                    }
                }

                throw new StockExchangeException("Ne postoji vrijednost dionice za to vrijeme!");
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            } 
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            String stockName = inStockName.ToLower();

            if (StockExists(stockName))
            {
                Stock s = getStock(stockName);
                return s.InitialPrice;
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            String stockName = inStockName.ToLower();

            if (StockExists(stockName))
            {
                Stock s = getStock(stockName);
                Value v = s.StockHistory.ElementAt(s.StockHistory.Count - 1);

                return v.Price;  
            }
            else
            {
                throw new StockExchangeException("Ne postoji dionica!");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            String indexName = inIndexName.ToLower();

            if (!IndexExists(indexName))
            {
                this.indices.Add(new Index(indexName, inIndexType));
            }
            else
            {
                throw new StockExchangeException("Indeks već postoji!");
            }      
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            String stockName = inStockName.ToLower();
            String indexName = inIndexName.ToLower();

            if (StockExists(stockName) && IndexExists(indexName))
            {
                if (!IsStockPartOfIndex(indexName, stockName))
                {
                    Index i = getIndex(indexName);
                    Stock s = getStock(stockName);
                    i.addStock(s);
                }
                else
                {
                    throw new StockExchangeException("Već postoji ta dionica u indeksu!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji dionica ili indeks!");
            }     
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            String stockName = inStockName.ToLower();
            String indexName = inIndexName.ToLower();

            if (IsStockPartOfIndex(indexName, stockName) && IndexExists(indexName))
            {
                Index i = getIndex(indexName);
                Stock s = i.getStockFromIndex(stockName);
                i.SharesInIndex.Remove(s);
            }
            else
            {
                throw new StockExchangeException("Dionica nije u indeksu ili on ne postoji!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            String stockName = inStockName.ToLower();
            String indexName = inIndexName.ToLower();

            if (IndexExists(indexName))
            {
                Index i = getIndex(indexName);
                Stock s = i.getStockFromIndex(stockName);
                if (s != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji indeks!  ");
            }           
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            String indexName = inIndexName.ToLower();

            if (IndexExists(indexName))
            {
                Index i = getIndex(indexName);

                if (i.IndexType == IndexTypes.WEIGHTED)
                {
                    return i.calculateWeighted(inTimeStamp);
                }
                else if (i.IndexType == IndexTypes.AVERAGE)
                {
                    return i.calculateAverage(inTimeStamp);
                }
                else
                {
                    throw new StockExchangeException("Ne postoji taj tip indeksa!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji indeks!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            String indexName = inIndexName.ToLower();

            Index i = getIndex(indexName);

            if (i != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfIndices()
        {
            return this.indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            String indexName = inIndexName.ToLower();

            if (IndexExists(indexName))
            {
                Index i = getIndex(indexName);
                return i.SharesInIndex.Count;
            }
            else
            {
                throw new StockExchangeException("Indeks ne postoji!");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                this.portfolios.Add(new Portfolio(inPortfolioID));
            }
            else
            {
                throw new StockExchangeException("Portfolio postoji!");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            String stockName = inStockName.ToLower();

            if (PortfolioExists(inPortfolioID) && StockExists(stockName))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                Stock s = getStock(stockName);
                s.NumberOfShares -= numberOfShares;

                if (IsStockPartOfPortfolio(inPortfolioID, stockName))
                {
                    Stock s2 = p.getStockFromPortfolio(stockName);
                    s2.NumberOfShares += numberOfShares;
                }
                else
                {
                    Stock s3 = new Stock(s.StockName, numberOfShares, s.InitialPrice, s.TimeStamp);
                    p.SharesInPortfolio.Add(s3);
                }

                foreach (Index i in this.indices)
                {
                    if (IsStockPartOfIndex(i.IndexName, stockName))
                    {
                        Stock stockInIndex = i.getStockFromIndex(stockName);
                        stockInIndex.NumberOfShares = s.NumberOfShares;
                    }
                }

            }
            else
            {
                throw new StockExchangeException("Ne postoji portfolio ili dionica!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            String stockName = inStockName.ToLower();

            if (PortfolioExists(inPortfolioID) && StockExists(stockName))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                Stock s = p.getStockFromPortfolio(stockName);
                s.NumberOfShares -= numberOfShares;

                if (s.NumberOfShares == 0)
                {
                    RemoveStockFromPortfolio(inPortfolioID, stockName);
                }
                else if (s.NumberOfShares < 0)
                {
                    throw new StockExchangeException("numberOfShares > s.NumberOfShares");
                }

                foreach (Index i in this.indices)
                {
                    if (IsStockPartOfIndex(i.IndexName, stockName))
                    {
                        Stock stockInIndex = i.getStockFromIndex(stockName);
                        stockInIndex.NumberOfShares += numberOfShares;
                    }
                }

                Stock stock = getStock(stockName);
                stock.NumberOfShares += numberOfShares;

           }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }          
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            String stockName = inStockName.ToLower();

            if (PortfolioExists(inPortfolioID) && IsStockPartOfPortfolio(inPortfolioID, stockName))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                Stock s = p.getStockFromPortfolio(inStockName.ToLower());
                p.SharesInPortfolio.Remove(s);
            }
            else
            {
                throw new StockExchangeException("Portfolio ili dionica unutar portfolia ne postoji!");
            }  
        }

        public int NumberOfPortfolios()
        {
            return this.portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                return p.SharesInPortfolio.Count;
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfolio p = getPortfolio(inPortfolioID);

            if (p != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                Stock s = p.getStockFromPortfolio(inStockName.ToLower());
                if (s != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }  
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            String stockName = inStockName.ToLower();

            if (PortfolioExists(inPortfolioID) && IsStockPartOfPortfolio(inPortfolioID, stockName))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                Stock s = p.getStockFromPortfolio(inStockName.ToLower());
                return (int) s.NumberOfShares;
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji ili ne postoji ta dionica unutar portfolia!");
            }     
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = getPortfolio(inPortfolioID);
                return p.calculateValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = getPortfolio(inPortfolioID);

                Decimal poc = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
                Decimal kra = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));


                System.Diagnostics.Debug.Print("-----------------------------------------------------");
                System.Diagnostics.Debug.Print("{0}  {1}", poc, kra);
                System.Diagnostics.Debug.Print("-----------------------------------------------------");

                if (poc > kra)
                {
                    return roundThreeDecimal(kra / poc);
                }
                else
                {
                    return roundThreeDecimal(poc / kra);
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }
        }

        private Portfolio getPortfolio(string inPortfolioID)
        {
            foreach (Portfolio p in this.portfolios)
            {
                if (p.PortfolioID.Equals(inPortfolioID))
                {
                    return p;
                }
            }

            return null;
        }

        private Stock getStock(string inStockName)
        {
            foreach (Stock s in this.sharesOnMarket)
            {
                if (s.StockName.Equals(inStockName.ToLower()))
                {
                    return s;
                }
            }
            return null;
        }

        private Index getIndex(string inIndexName)
        {
            foreach (Index i in this.indices)
            {
                if (i.IndexName.Equals(inIndexName.ToLower()))
                {
                    return i;
                }
            }
            return null;
        }

        private Decimal roundThreeDecimal(Decimal d)
        {
            return decimal.Round(d, 3, MidpointRounding.AwayFromZero);
        }
    }


    public class Index
    {
        private String indexName;
        private IndexTypes indexType;
        private List<Stock> sharesInIndex;

        public IndexTypes IndexType
        {
            get { return indexType; }
        }

        public List<Stock> SharesInIndex
        {
            get { return sharesInIndex; }
            set { sharesInIndex = value; }
        }

        public String IndexName
        {
            get { return indexName; }
            set { indexName = value; }
        }

        public Index(String indexName, IndexTypes indexType)
        {
            if (indexType != IndexTypes.AVERAGE && indexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Ne postoji taj tip indeksa!");
            }

            this.sharesInIndex = new List<Stock>();
            this.indexName = indexName;
            this.indexType = indexType;
        }

        public Stock getStockFromIndex(string inStockName)
        {
            foreach (Stock s in this.sharesInIndex)
            {
                if (s.StockName.Equals(inStockName.ToLower()))
                {
                    return s;
                }
            }

            return null;
        }

        public Decimal calculateWeighted(DateTime time)
        {
            Decimal sum = 0m;
            Decimal res = 0m;

            foreach (Stock s in this.sharesInIndex)
            {
                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);

                    if (DateTime.Compare(v.TimeStamp, time) <= 0)
                    {
                        sum += v.Price * v.NumberOfShares;
                        break;
                    }
                }
            }

            foreach (Stock s in this.SharesInIndex)
            {
                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);

                    if (DateTime.Compare(v.TimeStamp, time) <= 0)
                    {
                        res += v.Price * (v.Price * v.NumberOfShares);
                        break;
                    }
                }
            }

            /*System.Diagnostics.Debug.Print("**********************************************");
            System.Diagnostics.Debug.Print("{0}", res);
            System.Diagnostics.Debug.Print("{0}", decimal.Round(res, 3, MidpointRounding.AwayFromZero));
            System.Diagnostics.Debug.Print("**********************************************");*/

            return roundThreeDecimal(res / sum);
        }

        public Decimal calculateAverage(DateTime time)
        {
            Decimal sum = 0m;

            foreach (Stock s in this.sharesInIndex)
            {

                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);

                    if (DateTime.Compare(v.TimeStamp, time) <= 0)
                    {
                        sum += v.Price;
                        break;
                    }
                }
            }

            return roundThreeDecimal(sum / this.sharesInIndex.Count);
        }

        public void addStock(Stock s)
        {
            this.sharesInIndex.Add(s);
        }

        private Decimal roundThreeDecimal(Decimal d)
        {
            return decimal.Round(d, 3, MidpointRounding.AwayFromZero);
        }
    }


    public class Portfolio
    {
        private String portfolioID;
        private List<Stock> sharesInPortfolio;

        public List<Stock> SharesInPortfolio
        {
            get { return sharesInPortfolio; }
            set { sharesInPortfolio = value; }
        }

        public String PortfolioID
        {
            get { return portfolioID; }

        }

        public Portfolio(String portfolioID)
        {
            this.sharesInPortfolio = new List<Stock>();
            this.portfolioID = portfolioID;
        }

        public Stock getStockFromPortfolio(string inStockName)
        {
            foreach (Stock s in this.sharesInPortfolio)
            {
                if (s.StockName.Equals(inStockName.ToLower()))
                {
                    return s;
                }
            }
            return null;
        }

        public Decimal calculateValue(DateTime timeStamp)
        {
            Decimal sum = 0m;

            foreach (Stock s in this.SharesInPortfolio)
            {
                for (int i = s.StockHistory.Count - 1; i >= 0; i--)
                {
                    Value v = s.StockHistory.ElementAt(i);

                    if (DateTime.Compare(v.TimeStamp, timeStamp) <= 0)
                    {
                        sum += v.Price * v.NumberOfShares;
                        break;
                    }
                }
            }

            return roundThreeDecimal(sum);
        }

        private Decimal roundThreeDecimal(Decimal d)
        {
            return decimal.Round(d, 3, MidpointRounding.AwayFromZero);
        }
    }


    public class Stock
    {
        private String stockName;
        private long numberOfShares;
        private Decimal initialPrice;
        private DateTime timeStamp;
        private List<Value> stockHistory;

        public List<Value> StockHistory
        {
            get { return stockHistory; }
        }

        public long NumberOfShares
        {
            set { numberOfShares = value; }
            get { return numberOfShares; }
        }

        public String StockName
        {
            get { return stockName; }
        }

        public Decimal InitialPrice
        {
            get { return initialPrice; }
            set { initialPrice = value; }
        }

        public DateTime TimeStamp
        {
            get { return timeStamp; }
            set { timeStamp = value; }
        }

        public Stock(String stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
        {
            if (numberOfShares <= 0 || initialPrice <= 0m)
            {
                throw new StockExchangeException("Jedan od parametara je nula ili manji!");
            }

            this.stockName = stockName;
            this.numberOfShares = numberOfShares;
            this.initialPrice = initialPrice;
            this.timeStamp = timeStamp;

            this.stockHistory = new List<Value>();
            this.stockHistory.Add(new Value(initialPrice, timeStamp, numberOfShares));
        }

        public void setNewStockPrice(Decimal price, DateTime timeStamp)
        {
            this.stockHistory.Add(new Value(price, timeStamp, this.numberOfShares));
            this.stockHistory.Sort();
        }
    }

    public class Value : IComparable
    {
        private Decimal price;
        private DateTime timeStamp;
        private long numberOfShares;

        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        public Decimal Price
        {
            get { return price; }
        }

        public DateTime TimeStamp
        {
            get { return timeStamp; }
        }

        public Value(Decimal price, DateTime timeStamp, long numberOfShares)
        {
            this.price = price;
            this.timeStamp = timeStamp;
            this.numberOfShares = numberOfShares;
        }

        int IComparable.CompareTo(object obj)
        {
            Value v = (Value)obj;
            if (DateTime.Compare(this.timeStamp, v.timeStamp) > 0)
            {
                return 1;
            }
            else if (DateTime.Compare(this.timeStamp, v.timeStamp) < 0)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
