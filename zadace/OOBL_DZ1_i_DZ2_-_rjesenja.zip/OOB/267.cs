﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        private string _trenutniEkran = "0"; //prikazano na ekranu
        private string _brojUmemoriji = ""; // broj spremljen u memoriju sa P
        private string _prviOperand = ""; //prvi operand za binarne operacije
        private string _drugiOperand = ""; //drugi operand za binarne operacije
        private string _operacija = ""; //binarna operacija koja se racuna

        private int _maksimalniBrojZnamenki = 10; //broj znamenki koje se mogu prikazati na ekranu
        private string _porukaZaPogresku = "-E-"; //poruka koja se ispise u slucaju pogreske

        private bool _biloJednako = false; //oznacava da je bilo jednako
        private bool _bioJeUnarni = false; //oznacava da je izracunata unarna operacija


        /// <summary>
        /// Prihvaca unos tipke te odlucuje ovisno o njoj daljnju operaciju
        /// </summary>
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit)) //ako je pritisnuta znamenka
            {
                if (!_trenutniEkran.Equals(_porukaZaPogresku)) pritisnutBroj(inPressedDigit);
            }
            else if ("+-*/".Contains(inPressedDigit)) //ako je osnovna racunska operacija
            {
                if (!_trenutniEkran.Equals(_porukaZaPogresku)) pritisnutaBinarnaOperacija(inPressedDigit);
            }
            else if ("SKTQRI".Contains(inPressedDigit)) //ako je unarna operacija
            {
                if (!_trenutniEkran.Equals(_porukaZaPogresku)) izracunajUnarnuOperaciju(inPressedDigit);
            }
            else //lovi sve ostale pritisnute tipke
            {
                switch (inPressedDigit)
                {
                    case '=':
                        if (!_trenutniEkran.Equals(_porukaZaPogresku)) pritisnutJednako();
                        break;
                    case ',':
                        if (!_trenutniEkran.Equals(_porukaZaPogresku)) pritisnutZarez();
                        break;
                    case 'M':
                        if (!_trenutniEkran.Equals(_porukaZaPogresku)) promijeniPredznak();
                        break;

                    case 'P':
                        if (!_trenutniEkran.Equals(_porukaZaPogresku)) spremiUMemoriju();
                        break;
                    case 'G': dohvatiIzMemorije(); break;

                    case 'C': obrisiEkran(); break;
                    case 'O': resetirajKalkulator(); break;
                    default: break;
                }
            }

        }

        /// <summary>
        /// Vraca vrijednost koja se nalazi na ekranu kalkulatora
        /// </summary>
        public string GetCurrentDisplayState()
        {
            return _trenutniEkran;
        }

        /// <summary>
        /// Brise samo sadrzaj ekrana i operand koji je predstavljen njime, a ne dira ostale dijelove "memorije" kao sto su npr. prethodni operand, unesena operacija...
        /// </summary>
        private void obrisiEkran()
        {
            if (_operacija.Equals("") == true || _trenutniEkran.Equals(_porukaZaPogresku))
            {
                _prviOperand = "0";
            }
            else
            {
                _drugiOperand = "0";
            }

            _trenutniEkran = "0"; //brise se ekran
        }

        /// <summary>
        /// Postavlja kalkulator u pocetno stanje i resetira sve zastavice te vrijednosti
        /// </summary>
        private void resetirajKalkulator()
        {
            _trenutniEkran = "0";
            _brojUmemoriji = "";
            _prviOperand = "";
            _drugiOperand = "";
            _operacija = "";

            _biloJednako = false;
            _bioJeUnarni = false;
        }

        /// <summary>
        /// Sprema trenutni broj sa ekrana u memoriju
        /// </summary>
        private void spremiUMemoriju()
        {
            _brojUmemoriji = _trenutniEkran;
        }

        /// <summary>
        /// Dohvaca vrijednost iz memorije te ju postavlja na ekran
        /// </summary>
        private void dohvatiIzMemorije()
        {
            if (_brojUmemoriji.Equals("") == false) //ako je spremljen broj u memoriju dohvaca ga, inace ignorira tipku
            {
                _trenutniEkran = _brojUmemoriji;
                if (_operacija.Equals("") == true)
                {
                    _prviOperand = _trenutniEkran;
                }
                else
                {
                    _drugiOperand = _brojUmemoriji;
                }
            }
        }

        /// <summary>
        /// Mijenja predznak broju koji je prikazan na ekranu
        /// </summary>
        private void promijeniPredznak()
        {
            string ekranPrijePromjene = _trenutniEkran;
            if (_trenutniEkran.Substring(0, 1) == "-") //ako je predznak - mijenja se u + (odnosno brise)
            {
                _trenutniEkran = _trenutniEkran.Substring(1, _trenutniEkran.Length - 1);
            }
            else if (_trenutniEkran.Equals("0") == false) //ako je broj bio pozitivan mijenja se u negativan, ako je 0 ne dira se
            {
                _trenutniEkran = "-" + _trenutniEkran;
            }

            if (_prviOperand.Equals(ekranPrijePromjene) == true) //promjena predznaka se zabiljezi i u operandu
            {
                _prviOperand = _trenutniEkran;
                _drugiOperand = "";
            }
            else if (_drugiOperand.Equals("") == false) //ako je drugi operand prazan znaci da se mijenja predznak rezultata zadnje operacije zato se ne sprema u drugi operand
            {
                _drugiOperand = _trenutniEkran;
            }
        }

        /// <summary>
        /// Dodaje zarez na ekran ako se smije dodati
        /// </summary>
        private void pritisnutZarez()
        {
            if (_trenutniEkran.Contains(",") == false) //ako vec nema zarez na ekranu 
            {
                if ((_biloJednako == false && _operacija.Equals("") == true) || (_drugiOperand.Equals("") == false && _operacija.Equals("") == false))
                {
                    _trenutniEkran = _trenutniEkran + ",";
                }
                else //ako je zadnje bilo jednako/operator onda se rezultat/prviOperad mijenja sa 0, 
                {
                    _trenutniEkran = "0,";
                }
                _biloJednako = false;
                if (_operacija.Equals("") == true)
                {
                    _prviOperand = _trenutniEkran;
                }
                else
                {
                    _drugiOperand = _trenutniEkran;
                }
            }
        }

        /// <summary>
        /// Pokrece izracun operacije te ga prikazuje na ekran
        /// </summary>
        private void pritisnutJednako()
        {
            string rezultat = _trenutniEkran;

            if (_trenutniEkran.Equals(_prviOperand) == false) //na ekranu je rezultat unarne operacije i taj rezultat postaje 2. operand
            {
                _drugiOperand = _trenutniEkran;
            }

            if (_operacija.Equals("") == false) //ako je zadana operacija ide racunati
            {
                if (_drugiOperand.Equals("")) //ako nije unesen drugi operand onda je oblika 2+= i racuna se 2+2=
                {
                    if (_prviOperand.Equals("") == false) //ako postoji prvi operand ona racuna gore navedeno
                    {
                        rezultat = izracunajBinarnuOperaciju(_prviOperand, _prviOperand);
                    }
                    else //u suprotnom nista ne radi (na ekranu je pocetna nula i ona ostaje 0)
                    {
                        rezultat = "0";
                    }
                }
                else //ako su unesena oba operanda onda racuna operaciju nad njima
                {
                    rezultat = izracunajBinarnuOperaciju(_prviOperand, _drugiOperand);
                }
            }
            else //u suprotnom nista ne radi (i dalje ostane prikazan pocenti ekran, samo ocisti nepotrebne 0 iza ,)
            {
                rezultat = ukloniNepotrebneNule(zaokruziBroj(rezultat));
            }

            _biloJednako = true;
            _bioJeUnarni = false;

            if (_drugiOperand.Equals(""))
            {
                _drugiOperand = _prviOperand; //podrska za 2*=== -> 4,8,16
            }
            _prviOperand = rezultat; //u prvi operand stavlja rezultat kako bi se moglo nastaviti racunati

            _trenutniEkran = rezultat; //postavlja rezultat na ekran
        }

        /// <summary>
        /// Dodaje broj na ekran i u odgovarajuci operand
        /// </summary>
        private void pritisnutBroj(char inPressedDigit)
        {
            if (_biloJednako == true && _trenutniEkran.Equals(_prviOperand) == true) //ako je na ekranu prikazan rezultat zadnje operacije i pritisnut je broj onda se zadnji rezultat ignorira i krece unos prvog operanda
            {
                _trenutniEkran = ""; //kada je "0" onda je kao pocetno stanje
            }
            if (_operacija.Equals("") == false && _drugiOperand.Equals(""))//ako se krece sa unosom drugog broja brise se ekran
            {
                _trenutniEkran = "";
            }
            if (_bioJeUnarni == true)//ako je prethodno izracunat unarni broj i onda odmah stisnuta znamenka preko zadnjeg rezultata se prepise znamenka
            {
                _trenutniEkran = "";
                _bioJeUnarni = false;
            }
            if (izracunajBrojZnamenki(_trenutniEkran) < _maksimalniBrojZnamenki) //ako ima jos mjesta za znamenke
            {

                if (_trenutniEkran.Equals("0")) //ako je ekran prazan onda se nula brise prilikom unosa prve znamenke
                {
                    _trenutniEkran = "";
                }

                _trenutniEkran += inPressedDigit;

                if (_operacija.Equals("") == true || (_biloJednako == true && (_trenutniEkran.Equals(_prviOperand) == true || _drugiOperand.Equals("") == false))) //unosi se prvi operand (jos nije bila operacija)
                {
                    _prviOperand = _trenutniEkran;
                }
                else  //vec je bila operacija i unosi se drugi operand
                {
                    _drugiOperand = _trenutniEkran;
                    _biloJednako = false;
                }
            }

        }

        /// <summary>
        /// Biljezi operaciju te pokrece racunanje u slucaju potrebe (npr. slucaj: 2+2+)
        /// </summary>
        private void pritisnutaBinarnaOperacija(char operacija)
        {
            string rezultat;


            if (_prviOperand.Equals("") == true) //ako je odmah pritisnuta binarna operacija smatra se da je prvi operand 0
            {
                _prviOperand = "0";
            }


            if (_biloJednako == true)
            {
                _drugiOperand = "";
            }

            if (_bioJeUnarni == true && _drugiOperand.Equals("") == true && _operacija.Equals("") == false && _biloJednako == false) //kombinacija tipa 4+Q+ se racuna kao 4+4^2+ te se
            {

                rezultat = izracunajBinarnuOperaciju(_prviOperand, _trenutniEkran);

                _prviOperand = rezultat; //u prvi operand stavlja rezultat kako bi se moglo nastaviti racunati
                _trenutniEkran = rezultat; //postavlja rezultat na ekran
                _drugiOperand = ""; //brise drugi operand
            }
            else if (_operacija.Equals("") == false && _drugiOperand.Equals("") == false) //ako se unio niz tipa "3+4+" onda se ovdje prisili izracun nad prva dva operanda
            {
                rezultat = izracunajBinarnuOperaciju(_prviOperand, _drugiOperand);

                _prviOperand = rezultat; //u prvi operand stavlja rezultat kako bi se moglo nastaviti racunati
                _trenutniEkran = rezultat; //postavlja rezultat na ekran

                _drugiOperand = ""; //brise drugi operand
            }
            else
            {
                _trenutniEkran = ukloniNepotrebneNule(_trenutniEkran); //binarni operator zahtjeva uklanjanje viska nula (slucaj '2'',''0''+' na ekranu prikaze 2)
            }
            _operacija = operacija.ToString();
            _bioJeUnarni = false;
        }

        /// <summary>
        /// Za dva broja racuna odgovarajucu osnovnu racunsku operaciju koja je zadnja unesena (+,-,*,/)
        /// </summary>
        private string izracunajBinarnuOperaciju(string prvi, string drugi)
        {
            double rezultat = 0;
            string povratna;

            double prviOp = Double.Parse(prvi);
            double drugiOp = Double.Parse(drugi);

            try
            {
                switch (_operacija)
                {
                    case "+":
                        rezultat = prviOp + drugiOp;
                        break;
                    case "-":
                        rezultat = prviOp - drugiOp;
                        break;
                    case "*":
                        rezultat = prviOp * drugiOp;
                        break;
                    case "/":
                        rezultat = prviOp / drugiOp;
                        break;
                    default: //nije bila operacija i samo je pritisnuto = nakon unosa broja
                        povratna = _trenutniEkran;
                        break;
                }
                povratna = rezultat.ToString();
            }
            catch (Exception e)
            {
                povratna = _porukaZaPogresku;
            }

            if (Double.IsInfinity(rezultat) == true || Double.IsNaN(rezultat) == true) //ako je rezultat beskonacnost ili NaN onda se ispisuje greska (npr. dijeljenje sa 0);
            {
                povratna = _porukaZaPogresku;
            }
            return ukloniNepotrebneNule(zaokruziBroj(povratna)); //uredjuje se rezultat
        }

        /// <summary>
        /// Izracunava pritisnutu unarnu operaciju nad brojem koji je prikazan na ekranu
        /// </summary>
        private void izracunajUnarnuOperaciju(char operacija)
        {
            _bioJeUnarni = true;
            string ekranPrijeRacunanja = _trenutniEkran;

            double broj = Double.Parse(_trenutniEkran);
            double rezultat = 0;
            try
            {
                switch (operacija)
                {
                    case 'S': rezultat = Math.Sin(broj); break;
                    case 'K': rezultat = Math.Cos(broj); break;
                    case 'T': rezultat = Math.Tan(broj); break;
                    case 'Q': rezultat = Math.Pow(broj, 2); break;
                    case 'R': rezultat = Math.Sqrt(broj); break;
                    case 'I': rezultat = 1 / broj; break;
                    default: break;
                }
            }
            catch (Exception e)
            {
                _trenutniEkran = _porukaZaPogresku;
                _bioJeUnarni = false;
            }

            if (double.IsInfinity(rezultat) == true || double.IsNaN(rezultat) == true)
            {
                _trenutniEkran = _porukaZaPogresku;
                _bioJeUnarni = false;
            }

            if (_trenutniEkran.Equals(_porukaZaPogresku) == false) //ako je dobro izracunato 
            {
                rezultat = Math.Round(rezultat, 9);
                _trenutniEkran = ukloniNepotrebneNule(zaokruziBroj(rezultat.ToString()));
            }

            if (_operacija.Equals("") == true || _biloJednako == true) //ako jos nije bio operator onda prvi operand postaje novoizracunata vrijednost
            {
                _prviOperand = _trenutniEkran;
            }

            if (_operacija.Equals("") == false && _drugiOperand.Equals("") == false) //ako je bio operator i na ekranu je drugi operand onda izracunata vrijednost postaje drugi operand
            {
                _drugiOperand = _trenutniEkran;
            }

        }

        /// <summary>
        /// Zaokruzuje broj na maksimalni dozvoljeni broj decimala koje se mogu prikazati zbog ogranicenja ekrana
        /// </summary>
        private string zaokruziBroj(string broj)
        {
            if (broj.Equals(_porukaZaPogresku) == false)
            {
                broj = urediDecimalniZapis(Math.Round(Double.Parse(broj), (_maksimalniBrojZnamenki - 1)));  //ukloni eksponencijanlni zapis ako postoji 
                int brojCijelihZnamenki = 0;                                                               //i zaokruzi na maksimalni broj decimala koji se moze prikazati ako je samo jedna cijela znamenka 

                brojCijelihZnamenki = (broj.Split(','))[0].Length;

                if (broj.Substring(0, 1).Equals("-") == true) //ako je broj negativan onda se - ne racuna kao znamenka
                {
                    brojCijelihZnamenki--;
                }
                if (brojCijelihZnamenki > _maksimalniBrojZnamenki) return _porukaZaPogresku; //broj izlazi izvan dopustenog opsega i prikazuje se greska

                double br;
                br = Math.Round(double.Parse(broj), _maksimalniBrojZnamenki - brojCijelihZnamenki); //reze decimalne znamenke koje ne stanu
                broj = urediDecimalniZapis(br);

                brojCijelihZnamenki = (broj.Split(','))[0].Length; // osvjezava broj cijelih znamenki nakon zaokruzivanja
                if (brojCijelihZnamenki > _maksimalniBrojZnamenki) return _porukaZaPogresku; //ponovno provjerava da li boj izlazi jer je prilikom zaokruzivanja mogao narasti
            }                                                                                //slucaj 9999999999 + 0,9 = 9999999999,9 -> zaokruzi na 10000000000

            return broj;
        }

        /// <summary>
        /// Mijenja zapis broja u slucaju da je prikazan u obliku eksponencijalnog zapisa
        /// </summary>
        private string urediDecimalniZapis(Double broj) //uklanja eksponencijalni zapis ako postoji
        {                                               //mijenja format decimalnog zapisa
            string format = "{0:0.";
            for (int i = 0; i < (_maksimalniBrojZnamenki - 1); i++) //uredi string za format broja
            {
                format += "#"; //String.Format("{0:0.#########}", broj} je oblik koji ce na kraju imati u slucaju sa 10 znamenki
            }
            format += "}";

            return String.Format(format, broj);
        }

        /// <summary>
        /// Uklanja nule viska iz decimalnog zapisa (2,560 -> 2,56)
        /// </summary>
        private string ukloniNepotrebneNule(string broj) //uklanja nule sa kraja
        {
            if (broj.Equals(_porukaZaPogresku) == false)
            {
                string brojBezNula = broj;
                int brojNula = 0;
                int i;
                if (broj.Contains(',')) //ako je broj decimalan uklanja nule, inace ne smije
                {
                    for (i = broj.Length - 1; i > 0; i--)
                    {
                        if (string.Equals("0", broj.Substring(i, 1)) == true) //ako je nasao nulu uveca brojac
                        {
                            brojNula++;
                        }
                        else if (string.Equals(",", broj.Substring(i, 1)) == true) //ako je dosao do , znaci da su iza njega sve nule, pa ce na kraju i , ukloniti
                        {                                                  //zato se povecava brojac
                            brojNula++;
                        }
                        else break; //ako je naisao na bilo koju znamenku osim 0 ne smije ju dirati i prekida petlju
                    }
                    brojBezNula = broj.Substring(0, broj.Length - brojNula);
                }
                return brojBezNula;
            }
            else
            {
                return broj; //vrati natrag poruku o gresci koju je i dobila
            }
        }

        /// <summary>
        /// Izracunava broj znamenki zadanog broja (ignorira predznak i decimalnu tocku)
        /// </summary>
        private int izracunajBrojZnamenki(string broj)
        {
            int brZnamenki;
            brZnamenki = broj.Length;

            if (broj.Contains(",") == true)
            {
                brZnamenki--; //, se ne racuna kao znamenka
            }
            if (broj.Contains("-") == true)
            {
                brZnamenki--; //- se ne racuna kao znamenka
            }

            return brZnamenki;
        }
    }


}
