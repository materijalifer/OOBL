﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        public double zaslon;
        public bool zaslonPostavljen;

        public double Zaslon {
        
            get{
                return zaslon;
            }
            set{
                if (value > 9999999999 || value < -9999999999) {
                    error = true;
                    return;
                }
                else if (value % 1 == 0.0) {
                    zarez = false;

                    zaslonPostavljen = true;
                    zaslon = value;
                }
                else {

                    string zaslonBezMinusa = value.ToString().Replace("-", "");
                    String[] rascjepano = zaslonBezMinusa.Split(',');

                    int velicinaCijelogDijela = rascjepano[0].Length;

                    zarez = true;

                    zaslonPostavljen = true;
                    zaslon = Math.Round(value, 10 - velicinaCijelogDijela);
                }
            }
        }


        public double prviOperand;
        public bool prviOperandPostavljen;

        public double PrviOperand {

            get {
                return prviOperand;
            }
            set {
                prviOperandPostavljen = true;
                prviOperand = value;
            }
        }

        public double memorija;
        public string spremljenaPrethodnaOperacija;
        public bool zarez;
        public bool error;
        public bool prebaciZaslonUPrviOperand;
        public bool prebrisiNovimUnosom;


        //public static int Main() {

        //    ICalculator calculator = Factory.CreateCalculator();

        //    const string tipkanje = "2+2====";

        //    for (int i = 0; i < tipkanje.Length; i++) {
        //        calculator.Press(tipkanje.ElementAt(i));
        //    }

        //    string displayState = calculator.GetCurrentDisplayState();

        //    return 0;
        //}




        public void Press(char inPressedDigit) {

            if (error){
                if (!Char.IsDigit(inPressedDigit.ToString(), 0)) {
                    
                    var novaOperacijaKlasa = TvornicaOperacija.VratiOperaciju(inPressedDigit);

                    if (novaOperacijaKlasa is IResetirajucaOperacija) {
                        novaOperacijaKlasa.izvrsi(this);
                    }
                    else {
                        return;
                    }
                }
                return;
            }

            // unos znamenke
            if(Char.IsDigit(inPressedDigit.ToString(), 0)){

                if (prebrisiNovimUnosom) {
                    Zaslon = 0;
                    zaslonPostavljen = false;
                    zarez = false;
                }

                
                if (prebaciZaslonUPrviOperand) {
                    PrviOperand = Zaslon;
                    Zaslon = 0;
                    zarez = false;
                    prebaciZaslonUPrviOperand = false;
                }

                if (Zaslon == 0) {                      // ako je zaslon prazan tj na njemu je "0"

                    if (zarez) {
                        Zaslon = double.Parse( "0," + inPressedDigit.ToString());
                    }
                    else {
                        Zaslon = double.Parse(inPressedDigit.ToString());
                    }
                } 

                else if (Zaslon % 1 == 0.0 && zarez == false) {               // cjelobroji broj na ekranu
                    if (Zaslon >= 1000000000 && Zaslon <= 9999999999 || Zaslon <= -1000000000 && Zaslon >= -9999999999) {
                        return;     //nemoj napraviti ništa ako ne stane više znamenki
                    }

                    Zaslon = double.Parse(Zaslon.ToString() + inPressedDigit.ToString());   // nadodaj znamenku na kraj zaslona
                }

                else{                                                       // decimalni broj na ekranu

                    string zaslonBezPredznakaItocke = Zaslon.ToString().Replace("-", "");
                    zaslonBezPredznakaItocke = zaslonBezPredznakaItocke.Replace(",", "");


                    // ne napravi ništa ako je maksimalan broj znamenki na zaslonu
                    if (zaslonBezPredznakaItocke.Length == 10) {
                    }

                    // ako je zastavica za zarez u true a nema zareza na zaslonu, nadodaj zarez i novu znamenku na zaslon
                    else if (Zaslon.ToString().IndexOf(',') == -1) {

                        string spojenoSZarezom = Zaslon.ToString() + "," + inPressedDigit.ToString();
                        Zaslon = double.Parse(spojenoSZarezom.ToString());
                    }

                    // obično nadodavanje znamenke u decimalni broj
                    else {
                        string temp = Zaslon.ToString() + inPressedDigit.ToString();
                        Zaslon = double.Parse(temp);
                    }

                }
            }



            // unos znaka tj operacije
            else{

                var novaOperacijaKlasa = TvornicaOperacija.VratiOperaciju(inPressedDigit);

                if (novaOperacijaKlasa == null) {
                    error = true;
                    return;
                }


                if (novaOperacijaKlasa is IUnarnaOperacija) {
                    novaOperacijaKlasa.izvrsi(this);
                    prebrisiNovimUnosom = true;
                    prebaciZaslonUPrviOperand = false;
                }
                
                else if (novaOperacijaKlasa is IBinarnaOperacija) {

                    prebrisiNovimUnosom = false;

                    // 2+                       samo spremi operaciju u spremnik
                    if (prviOperandPostavljen == false && zaslonPostavljen == true) {

                        spremljenaPrethodnaOperacija = inPressedDigit.ToString();

                        PrviOperand = Zaslon;
                        prebaciZaslonUPrviOperand = true;
                        
                    }


                    // 2+2*                     pokreni prethodnu operaciju (zbrajanje), rezultat (4) u prvi operand, * u spremnik
                    else if (prviOperandPostavljen == true && zaslonPostavljen == true) {

                        IOperacija prethodnaOperacijaKlasa = TvornicaOperacija.VratiOperaciju(spremljenaPrethodnaOperacija.ToCharArray()[0]);
                        prethodnaOperacijaKlasa.izvrsi(this);

                        PrviOperand = Zaslon;
                        spremljenaPrethodnaOperacija = inPressedDigit.ToString();
                        prebaciZaslonUPrviOperand = true;
                    }
                    
                }

                 else {                                    // globalna operacija

                    novaOperacijaKlasa.izvrsi(this);
                }
                
            }

        }

        public string GetCurrentDisplayState()
        {

            if (error){
                return "-E-";
            }

            string zaVratiti = null;

            // ako je vrijednost -1 < x < 1, zaokružit na 9 decimala
            if (Zaslon > -1.0 && Zaslon < 1.0) {
                zaVratiti = Math.Round(Zaslon, 9).ToString();
            }

            else{
                string zaslonBezMinusa = Zaslon.ToString().Replace("-", "");

                String[] rascjepano = zaslonBezMinusa.Split(',');
                int velicinaCijelogDijela = rascjepano[0].Length;

                zaVratiti = Math.Round(Zaslon, 10 - velicinaCijelogDijela).ToString();
            }

            return zaVratiti;

        }
    }


    // tvornica koja u ovisnosti o primljenom znaku vraća odgovarajuću klasu
    // ukoliko se u kod doda nova operacija tj klasa, potrebno je rekompajlirati SAMO ovu klasu

    public class TvornicaOperacija {
        public static IOperacija VratiOperaciju(char inPressedDigit) {
            
            switch (inPressedDigit){

                // binarne operacije
                //+
                //-
                //*
                ///

                case '+':
                    return new Plus();

                case '-':
                    return new Minus();

                case '*':
                    return new Puta();

                case '/':
                    return new Podijeljeno();


                // unarne operacije
                //=
                //S sinus
                //K kosinus
                //T tangens
                //Q kvadriranje
                //R korjenovanje
                //I inverz

                case '=':
                    return new Jednako();

                case 'S':
                    return new Sinus();

                case 'K':
                    return new Kosinus();

                case 'T':
                    return new Tangens();

                case 'Q':
                    return new Kvadriranje();

                case 'R':
                    return new Korjenovanje();

                case 'I':
                    return new Inverz();


                // globalne operacije
                //P pohrani u memoriju
                //G uzmi iz memorije
                //C
                //O
                //,
                //M predznak

                case 'P':
                    return new Memoriraj();

                case 'G':
                    return new VratiIzMemorije();

                case 'C':
                    return new ObrisiEkran();

                case 'O':
                    return new Resetiraj();

                case ',':
                    return new Zarez();

                case 'M':
                    return new Predznak();

            }

            return null;

        }
    }




    // sučelja

    public interface IOperacija {

        void izvrsi(Kalkulator kalkulator);

    }

    public interface IBinarnaOperacija : IOperacija {

        void izvrsi(Kalkulator kalkulator);

    }

    public interface IUnarnaOperacija : IOperacija {

        void izvrsi(Kalkulator kalkulator);

    }

    public interface IGlobalnaOperacija : IOperacija {

        void izvrsi(Kalkulator kalkulator);

    }


    
    // binarne operacije

    public class Plus : IBinarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = kalkulator.PrviOperand + kalkulator.Zaslon;
        }

    }

    public class Minus : IBinarnaOperacija
    {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = kalkulator.PrviOperand - kalkulator.Zaslon;
        }
    }

    public class Puta : IBinarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = kalkulator.PrviOperand * kalkulator.Zaslon;
        }
    }

    public class Podijeljeno : IBinarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            if (kalkulator.Zaslon == 0){
                kalkulator.error = true;
                return;
            }

            kalkulator.Zaslon = kalkulator.PrviOperand / kalkulator.Zaslon;
        }
    }



    // unarne operacije

    public class Jednako : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            if (kalkulator.spremljenaPrethodnaOperacija == null) {
                //kalkulator.prebrisiNovimUnosom = true;
                return;
            }
            

            // 2+                       izvrši operaciju s tim da je prvi operand isti kao i zaslon
            if (kalkulator.prviOperandPostavljen == false && kalkulator.zaslonPostavljen == true) {

                kalkulator.PrviOperand = kalkulator.Zaslon;

                IOperacija prethodnaOperacijaKlasa = TvornicaOperacija.VratiOperaciju(kalkulator.spremljenaPrethodnaOperacija.ToCharArray()[0]);
                prethodnaOperacijaKlasa.izvrsi(kalkulator);

                kalkulator.prebaciZaslonUPrviOperand = true;
            }


            // 2+2=                     pokreni prethodnu operaciju (zbrajanje), rezultat (4) u prvi operand, * u spremnik
            else if (kalkulator.prviOperandPostavljen == true && kalkulator.zaslonPostavljen == true) {

                IOperacija prethodnaOperacijaKlasa = TvornicaOperacija.VratiOperaciju(kalkulator.spremljenaPrethodnaOperacija.ToCharArray()[0]);
                prethodnaOperacijaKlasa.izvrsi(kalkulator);
                
                kalkulator.prebaciZaslonUPrviOperand = true;
            }

        }
    }

    public class Sinus : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            if (kalkulator.Zaslon == 0){
                kalkulator.error = true;
                return;
            }

            kalkulator.Zaslon = Math.Sin(kalkulator.Zaslon);
        }
    }

    public class Kosinus : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = Math.Cos(kalkulator.Zaslon);
        }
    }

    public class Tangens : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = Math.Tan(kalkulator.Zaslon);
        }
    }

    public class Kvadriranje : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = Math.Pow(kalkulator.Zaslon, 2);
        }
    }

    public class Korjenovanje : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            if (kalkulator.Zaslon < 0){
                kalkulator.error = true;
                return;
            }

            kalkulator.Zaslon = Math.Pow(kalkulator.Zaslon, -2);
        }
    }

    public class Inverz : IUnarnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = Math.Pow(kalkulator.Zaslon, -1);
        }
    }




    // globalne operacije

    public class Memoriraj : IGlobalnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.memorija = kalkulator.Zaslon;
        }
    }

    public class VratiIzMemorije : IGlobalnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = kalkulator.memorija;
        }
    }

    public class Zarez : IGlobalnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.zarez = true;

        }
    }

    public class Predznak : IGlobalnaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = kalkulator.Zaslon * (-1);

        }
    }



    // resetirajuće (ujedno i globalne) operacije

    public interface IResetirajucaOperacija : IGlobalnaOperacija {

        void izvrsi(Kalkulator kalkulator);
    }


    public class ObrisiEkran : IResetirajucaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.Zaslon = 0;
            kalkulator.zaslonPostavljen = false;
            kalkulator.error = false;
        }
    }

    public class Resetiraj : IResetirajucaOperacija {

        public void izvrsi(Kalkulator kalkulator) {

            kalkulator.memorija = 0;
            kalkulator.PrviOperand = 0;
            kalkulator.prviOperandPostavljen = false;
            kalkulator.Zaslon = 0;
            kalkulator.zaslonPostavljen = false;
            kalkulator.zarez = false;
            kalkulator.spremljenaPrethodnaOperacija = null;
            kalkulator.error = false;
            kalkulator.prebaciZaslonUPrviOperand = false;
            kalkulator.prebrisiNovimUnosom = false;
        }
    }

}
