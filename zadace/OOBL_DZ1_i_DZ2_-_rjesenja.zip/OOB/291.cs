﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private readonly List<Stock> _stockList = new List<Stock>();
        private readonly List<StockIndex> _indexList = new List<StockIndex>();
        private readonly List<Portfolio> _portfolioList = new List<Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 if(inInitialPrice > 0) this._stockList.Add( new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp) );
                 else throw new StockExchangeException("Stock price must be a positive value!");
             }
             else throw  new StockExchangeException("Stock already exists in the system!");
         }

         public void DelistStock(string inStockName)
         {
             throw new NotImplementedException();
         }

         public bool StockExists(string inStockName)
         {
             if (this._stockList.Any(p => p.StockName == inStockName))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return this._stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = GetStockByName(inStockName);

             stock.SetStockValue(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = GetStockByName(inStockName);

             return stock.GetStockValueOnTimeStamp(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             throw new NotImplementedException();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             throw new NotImplementedException();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (inIndexType == IndexTypes.AVERAGE)
             {
                 this._indexList.Add(new StockIndexAverage(inIndexName));
             }
             else if (inIndexType == IndexTypes.WEIGHTED)
             {
                 this._indexList.Add( new StockIndexWeighted(inIndexName) );
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             StockIndex stockIndex = GetIndexByName(inIndexName);

             stockIndex.AddStockToIndex(GetStockByName(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             throw new NotImplementedException();
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndexByName(inIndexName).ContainsStock(GetStockByName(inStockName));
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return GetIndexByName(inIndexName).GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (this._indexList.Any(p => p.IndexName == inIndexName))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return this._indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return GetIndexByName(inIndexName).NumberOfStocksInIndex;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             this._portfolioList.Add( new Portfolio(inPortfolioID) );
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = GetPortfolioById(inPortfolioID);

             portfolio.AddSharesToPortfolio(GetStockByName(inStockName), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             GetPortfolioById(inPortfolioID).RemoveSharesFromPortfolio(GetStockByName(inStockName), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             GetPortfolioById(inPortfolioID).RemoveStockFromPortfolio(GetStockByName(inStockName));
         }

         public int NumberOfPortfolios()
         {
             return this._portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return GetPortfolioById(inPortfolioID).NumberOfStocks;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (this._portfolioList.Any(p => p.PortfolioId == inPortfolioID)) return true;
             else return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolioById(inPortfolioID).ContainsStock(GetStockByName(inStockName));
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolioById(inPortfolioID).GetNumberOfSharesOfStock(GetStockByName(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return GetPortfolioById(inPortfolioID).PortfolioValueOnTimeStamp(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return GetPortfolioById(inPortfolioID).PortfolioPercentageChange(Year, Month);
         }

         private Stock GetStockByName(string stockName)
         {
             foreach (Stock stock in this._stockList)
             {
                 if (stock.StockName == stockName) return stock;
             }

             throw new StockExchangeException("Stock could not be found!");
         }

         private StockIndex GetIndexByName(string indexName)
         {
             foreach (StockIndex index in this._indexList)
             {
                 if (index.IndexName == indexName) return index;
             }

             throw new StockExchangeException("Index could not be found!");
         }

         private Portfolio GetPortfolioById(string portfolioId)
         {
             foreach (Portfolio portfolio in this._portfolioList)
             {
                 if (portfolio.PortfolioId == portfolioId) return portfolio;
             }

             throw new StockExchangeException("Portfolio could not be found!");
         }
    }

    public class Stock
    {
        private string stockName;
        private long numberOfShares;
        private DateTime timeStamp;
        private StockValue stockValue;

        public Stock(string stockName, long numberOfShares, decimal stockValue, DateTime timeStamp)
        {
            this.stockName = stockName;
            this.numberOfShares = numberOfShares;
            this.timeStamp = timeStamp;
            this.stockValue = new StockValue(stockValue, timeStamp);
        }

        public decimal GetStockValueOnTimeStamp(DateTime timeStamp)
        {
            return this.stockValue.GetStockValueOnTimeStamp(timeStamp); 
        }

        public void SetStockValue(decimal value, DateTime timeStamp)
        {
            this.stockValue.SetNewStockValue(value, timeStamp);
        }

        public long NumberOfShares
        {
            get { return this.numberOfShares; }
        }

        public string StockName
        {
            get
            {
                return this.stockName ;
            }
        }

        public decimal StockValue
        {
            get { return this.stockValue.GetStockValueOnTimeStamp(DateTime.Now); }
        }

    }

    public class StockValue
    {
        Dictionary<DateTime, decimal> stockHistory = new Dictionary<DateTime, decimal>();

        public StockValue(decimal startValue, DateTime timeStamp)
        {
            this.SetNewStockValue(startValue, timeStamp);
        }

        public void SetNewStockValue(decimal newValue, DateTime currentTimeStamp)
        {
            this.stockHistory.Add(currentTimeStamp, newValue);
        }

        public decimal GetStockValueOnTimeStamp(DateTime timeStamp)
        {
            decimal returnValue = 0;
            TimeSpan minDifference = new TimeSpan(0,0,0,0,0);
            bool firstIter = true;

            foreach (var pair in this.stockHistory)
            {
                
                if (timeStamp >= pair.Key)
                {
                    if (firstIter || ((TimeSpan) (timeStamp - pair.Key) < minDifference))
                    {
                        firstIter = false;
                        minDifference = (TimeSpan) (timeStamp - pair.Key);
                        returnValue = pair.Value;
                    }
                }
            }

            return returnValue;
        }
    }

    public abstract class StockIndex
    {
        protected string indexName;
        protected List<Stock> stockList = new List<Stock>();

        public string IndexName
        {
            get { return this.indexName; }
        }

        public void AddStockToIndex(Stock stockToAdd)
        {
            this.stockList.Add(stockToAdd);
        }

        public bool ContainsStock(Stock stock)
        {
            if (this.stockList.Contains(stock)) return true;
            else return false;
        }

        public int NumberOfStocksInIndex
        {
            get { return this.stockList.Count; }
        }

        public abstract decimal GetIndexValue(DateTime timeStamp);
    }

    public class StockIndexAverage : StockIndex
    {
        public StockIndexAverage(string indexName)
        {
            this.indexName = indexName;
        }

        public override decimal GetIndexValue(DateTime timeStamp)
        {
            decimal sumIndex = 0m;

            foreach (Stock stock in this.stockList)
            {
                sumIndex += stock.GetStockValueOnTimeStamp(timeStamp);
            }

            return sumIndex / this.NumberOfStocksInIndex;
        }
    }

    public class StockIndexWeighted : StockIndex
    {
        public StockIndexWeighted(string indexName)
        {
            this.indexName = indexName;
        }

        private decimal GetTotalStockValue(DateTime timeStamp)
        {
            decimal sum = 0m;

            foreach (Stock stock in this.stockList)
            {
                sum += stock.GetStockValueOnTimeStamp(timeStamp) * stock.NumberOfShares;
            }

            return sum;
        }

        public override decimal GetIndexValue(DateTime timeStamp)
        {
            decimal sumIndex = 0m;

            foreach (Stock stock in this.stockList)
            {
                sumIndex += ((stock.GetStockValueOnTimeStamp(timeStamp)*stock.NumberOfShares) /
                             GetTotalStockValue(timeStamp))*stock.GetStockValueOnTimeStamp(timeStamp);
            }

            return sumIndex;
        }
    }

    public class Portfolio
    {
        private string portfolioId;
        private List<StockInPortfolio> stockList = new List<StockInPortfolio>();


        public Portfolio(string portfolioId)
        {
            this.portfolioId = portfolioId;
        }

        public void AddSharesToPortfolio(Stock stockToAdd, long numberOfShares)
        {
            if (this.ContainsStock(stockToAdd))
            {
                this.GetStockInPortfolio(stockToAdd).NumberOfShares += numberOfShares;
            }
            else
            {
                this.AddStockToPortfolio(stockToAdd, numberOfShares);
            }
        }

        private void AddStockToPortfolio(Stock stockToAdd, long numberOfShares)
        {
            this.stockList.Add( new StockInPortfolio(stockToAdd, numberOfShares) );
        }

        public bool ContainsStock(Stock stock)
        {
            if (this.stockList.Any(p => p.PortfolioStock == stock)) return true;
            else return false;
        }

        private StockInPortfolio GetStockInPortfolio(Stock stockToGet)
        {

            foreach (StockInPortfolio item in this.stockList)
            {
                if (item.PortfolioStock == stockToGet) return item;
            }

            throw new StockExchangeException("This stock could not be found in this portfolio.");
        }

        public int GetNumberOfSharesOfStock(Stock stock)
        {
            return (int)this.GetStockInPortfolio(stock).NumberOfShares;
        }

        public void RemoveSharesFromPortfolio(Stock stock, int numberOfShares)
        {
            StockInPortfolio portfolioStock = GetStockInPortfolio(stock);
            portfolioStock.NumberOfShares -= numberOfShares;

            if (portfolioStock.NumberOfShares == 0) RemoveStockFromPortfolio(stock);
        }

        public void RemoveStockFromPortfolio(Stock stock)
        {
            this.stockList.Remove(GetStockInPortfolio(stock));
        }

        public string PortfolioId
        {
            get { return this.portfolioId; }
        }

        public int NumberOfStocks
        {
            get { return this.stockList.Count; }
        }

        public decimal PortfolioValueOnTimeStamp(DateTime timeStamp)
        {
            decimal sumValue = 0m;

            foreach (StockInPortfolio item in this.stockList)
            {
                sumValue += item.PortfolioStock.GetStockValueOnTimeStamp(timeStamp) * item.NumberOfShares;
            }

            return sumValue;
        }

        public decimal PortfolioPercentageChange(int year, int month)
        {
            DateTime timeStart = new DateTime(year, month, 1);
            DateTime timeEnd;
            if (month == 12) timeEnd = new DateTime(year+1, 1, 1);
            else timeEnd = new DateTime(year, month+1, 1);

            timeEnd.Subtract(new TimeSpan(0,0,0,0,1));

            decimal valueStart = this.PortfolioValueOnTimeStamp(timeStart);
            decimal valueEnd = this.PortfolioValueOnTimeStamp(timeEnd);

            return Math.Round((valueEnd/valueStart) * 100, 3);
        }

    }

    public class StockInPortfolio
    {
        private long numberOfShares;
        private Stock portfolioStock;

        public StockInPortfolio(Stock stock, long numberOfShares)
        {
            this.portfolioStock = stock;
            this.numberOfShares = numberOfShares;
        }

        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { this.numberOfShares = value; }
        }

        public Stock PortfolioStock
        {
            get { return this.portfolioStock; }
        }
    }

}
