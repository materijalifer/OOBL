﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private IndexRepository IndexRepository = new IndexRepository();
        private PortfolioRepository PortfolioRepository = new PortfolioRepository();
        private StockRepository StockRepository = new StockRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockRepository.AddStock(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        //nije pokriveno testom
        public void DelistStock(string inStockName)
        {
            var stock = StockRepository.GetStock(inStockName);
            StockRepository.RemoveStock(stock);
        }

        public bool StockExists(string inStockName)
        {
            return StockRepository.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return StockRepository.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var stock = StockRepository.GetStock(inStockName);
            stock.ChangePrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stock = StockRepository.GetStock(inStockName);
            return stock.GetPrice(inTimeStamp);
        }

        //nije pokriveno testom
        public decimal GetInitialStockPrice(string inStockName)
        {
            var stock = StockRepository.GetStock(inStockName);
            return stock.InitialPrice.Price;
        }

        //nije pokriveno testom
        public decimal GetLastStockPrice(string inStockName)
        {
            var stock = StockRepository.GetStock(inStockName);
            return stock.GetNewestPrice().Price;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            IndexRepository.AddIndex(new Index(inIndexName, inIndexType));
        }


        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var index = IndexRepository.GetIndex(inIndexName);
            var stock = StockRepository.GetStock(inStockName);
            index.AddStock(stock);
        }

        //nije pokriveno testom
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var index = IndexRepository.GetIndex(inIndexName);
            var stock = StockRepository.GetStock(inStockName);
            index.RemoveStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var index = IndexRepository.GetIndex(inIndexName);
            var stock = StockRepository.GetStock(inStockName);
            return index.HasStock(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var index = IndexRepository.GetIndex(inIndexName);
            return index.GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return IndexRepository.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return IndexRepository.CountIndex();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            var index = IndexRepository.GetIndex(inIndexName);
            return index.CountStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            PortfolioRepository.AddPortfolio(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            var stock = StockRepository.GetStock(inStockName);
            portfolio.AddStockShares(stock, numberOfShares, PortfolioRepository);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            var stock = StockRepository.GetStock(inStockName);
            portfolio.RemoveStockShares(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            var stock = StockRepository.GetStock(inStockName);
            portfolio.RemoveStockShares(stock, portfolio.CountSharesInStock(stock.StockName));
        }

        public int NumberOfPortfolios()
        {
            return PortfolioRepository.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            return portfolio.CountStocks();
        }

        //nije pokriveno testom
        public bool PortfolioExists(string inPortfolioID)
        {
            return PortfolioRepository.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            var stock = StockRepository.GetStock(inStockName);
            return portfolio.HasStock(stock.StockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            var stock = StockRepository.GetStock(inStockName);
            return portfolio.CountSharesInStock(stock.StockName);
        }


        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            return portfolio.GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var portfolio = PortfolioRepository.GetPortfolio(inPortfolioID);
            return portfolio.GetPortfolioPercentChange(Year, Month);
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<Stock> _stocks;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if (String.IsNullOrEmpty(inIndexName))
                throw new StockExchangeException("Ime indexa mora biti definirano!");
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Tip indexa mora biti ili AVERAGE ili WEIGHTED");

            _indexName = inIndexName;
            _indexType = inIndexType;
            _stocks = new List<Stock>();
        }

        public void AddStock(Stock stock)
        {
            if (HasStock(stock))
                throw new StockExchangeException("Ova dionica već je u ovom indexu!");

            _stocks.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            if (!HasStock(stock))
                throw new StockExchangeException("Ova dionica ne postoji u ovom indexu!");

            _stocks.Remove(stock);
        }

        public int CountStocks()
        {
            return _stocks.Count;
        }

        public bool HasStock(Stock stock)
        {
            return _stocks.Where(s => s.StockName == stock.StockName).Count() > 0;
        }


        public string IndexName
        {
            get { return _indexName; }
        }

        public decimal GetIndexValue(DateTime inTimeStamp)
        {
            return _indexType == IndexTypes.AVERAGE ? getAverage(inTimeStamp) : getWeighted(inTimeStamp);
        }

        private decimal getWeighted(DateTime inTimeStamp)
        {
            var totalIndexValue = getTotalValue(inTimeStamp);
            return Decimal.Round(_stocks.Sum(s => s.GetPrice(inTimeStamp) * (s.GetTotalValue(inTimeStamp) / totalIndexValue)), 3);
        }

        private decimal getAverage(DateTime inTimeStamp)
        {
            var stockCount = CountStocks();
            return Decimal.Round(_stocks.Sum(s => s.GetPrice(inTimeStamp) / stockCount), 3);
        }

        private decimal getTotalValue(DateTime inTimeStamp)
        {
            return _stocks.Sum(stock => stock.GetTotalValue(inTimeStamp));
        }
    }
    public class IndexRepository
    {
        private List<Index> _listIndices = new List<Index>();

        public bool IndexExists(string inIndexName)
        {
            return _listIndices.Count(i => i.IndexName.ToLower() == inIndexName.ToLower()) != 0;
        }

        public Index GetIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
                return _listIndices.Where(i => i.IndexName.ToLower() == inIndexName.ToLower()).ToList()[0];

            throw new StockExchangeException("Ne postoji index stim imenom!");
        }

        public void AddIndex(Index inIndex)
        {
            // provjeriti da li već postoji index s tim imenom
            if (IndexExists(inIndex.IndexName))
            {
                throw new StockExchangeException("Već postoji index stim imenom na burzi!");
            }

            _listIndices.Add(inIndex);
        }

        public int CountIndex()
        {
            return _listIndices.Count;
        }
    }

    public class Portfolio
    {
        private string _portfolioID;
        private List<PortfolioStock> _stocks;

        public Portfolio(string inPortfolioId)
        {
            if (String.IsNullOrEmpty(inPortfolioId))
                throw new StockExchangeException("Id portfolia mora biti definiran!");

            _portfolioID = inPortfolioId;
            _stocks = new List<PortfolioStock>();
        }

        public bool HasStock(string inStockName)
        {
            return _stocks.Where(s => s.Stock.StockName == inStockName).Count() != 0;
        }

        public int CountStocks()
        {
            return _stocks.Count;
        }

        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            return Decimal.Round(_stocks.Sum(stock => stock.Stock.GetPrice(inTimeStamp) * stock.SharesInPortfolio), 3);
        }

        public decimal GetPortfolioPercentChange(int inYear, int inMonth)
        {
            var timeStampStart = new DateTime(inYear, inMonth, 1, 0, 0, 0, 0);
            var timeStampEnd = new DateTime(inYear, inMonth, DateTime.DaysInMonth(inYear, inMonth), 23, 59, 59, 999);
            return Decimal.Round((((GetPortfolioValue(timeStampEnd) - GetPortfolioValue(timeStampStart)) / GetPortfolioValue(timeStampStart)) * 100), 3);
        }

        public int CountSharesInStock(string inStockName)
        {
            return GetPortfolioStock(inStockName).SharesInPortfolio;
        }

        public PortfolioStock GetPortfolioStock(string inStockName)
        {
            if (HasStock(inStockName))
                return _stocks.Where(s => s.Stock.StockName == inStockName).ToList()[0];

            throw new StockExchangeException("Portfelj ne sadrži tu dionicu!");
        }

        public void AddStockShares(Stock inStock, int inNumberOfShares, PortfolioRepository inPr)
        {
            if (inStock.NumberOfShares - inPr.GetTotalNumberOfSharesOf(inStock.StockName) < inNumberOfShares)
                throw new StockExchangeException("Nema dovoljno dionica na tržištu za dodati toliko u portfelj!");
            if (HasStock(inStock.StockName))
            {
                var stock = GetPortfolioStock(inStock.StockName);
                stock.SharesInPortfolio += inNumberOfShares;
            }
            else
                _stocks.Add(new PortfolioStock(inStock, inNumberOfShares));
        }

        public void RemoveStockShares(Stock inStock, int inNumberOfShares)
        {
            if (!HasStock(inStock.StockName))
                throw new StockExchangeException("Portfelj ne sadrži tu dionicu!");
            if (GetPortfolioStock(inStock.StockName).SharesInPortfolio < inNumberOfShares)
                throw new StockExchangeException("Portfelj ne sadrži toliko dionica koliko želite ukloniti!");

            var stock = GetPortfolioStock(inStock.StockName);
            stock.SharesInPortfolio -= inNumberOfShares;

            if (stock.SharesInPortfolio == 0)
                _stocks.Remove(stock);
        }

        public string PortfolioId
        {
            get { return _portfolioID; }
        }
    }

    public class PortfolioRepository
    {

        private List<Portfolio> _listPortfolios = new List<Portfolio>();

        public int GetTotalNumberOfSharesOf(string inStockName)
        {
            return _listPortfolios.Where(portfolio => portfolio.HasStock(inStockName)).Sum(portfolio => portfolio.GetPortfolioStock(inStockName).SharesInPortfolio);
        }

        public Portfolio GetPortfolio(string inPortfolioId)
        {
            if (PortfolioExists(inPortfolioId))
                return _listPortfolios.Where(p => p.PortfolioId == inPortfolioId).ToList()[0];

            throw new StockExchangeException("Ne postoji dionica stim imenom!");
        }

        public void AddPortfolio(Portfolio inPortfolio)
        {
            // provjeriti da li već postoji portfolio s tim id-om
            if (PortfolioExists(inPortfolio.PortfolioId))
            {
                throw new StockExchangeException("Već postoji portfolio stim id-om na burzi!");
            }

            _listPortfolios.Add(inPortfolio);
        }

        public bool PortfolioExists(string inPortfolioId)
        {
            return _listPortfolios.Count(i => i.PortfolioId == inPortfolioId) != 0;
        }

        public int Count()
        {
            return _listPortfolios.Count;
        }
    }

    public class PortfolioStock
    {
        private Stock _stock;
        private int _sharesInPortfolio;

        public PortfolioStock(Stock inStock, int inSharesInPortfolio)
        {
            if (inSharesInPortfolio <= 0)
                throw new StockExchangeException("Broj dionica u portfoliu mora biti veci od nule!");

            _stock = inStock;
            _sharesInPortfolio = inSharesInPortfolio;
        }

        public Stock Stock
        {
            get { return _stock; }
        }

        public int SharesInPortfolio
        {
            get { return _sharesInPortfolio; }
            set { _sharesInPortfolio = value; }
        }
    }

    public class Stock
    {
        private string _stockName;
        private long _numberOfShares;
        private DateTime _timeStampCreation;
        private StockPrice _initialPrice;
        private StockPrice _latestPrice;
        private List<StockPrice> _prices;

        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            if (String.IsNullOrEmpty(stockName))
                throw new StockExchangeException("Ime dionice mora biti definirano!");
            if (numberOfShares <= 0)
                throw new StockExchangeException("Broj dionica mora biti veći od nule!");


            _stockName = stockName;
            _numberOfShares = numberOfShares;
            _timeStampCreation = timeStamp;
            _prices = new List<StockPrice>();

            var price = new StockPrice(initialPrice, timeStamp);
            _initialPrice = price;
            _latestPrice = price;
            _prices.Add(price);
        }

        public StockPrice InitialPrice
        {
            get { return _initialPrice; }
        }

        public StockPrice GetOldestPrice()
        {
            return _prices.Where(price => price.TimeStampFrom == _prices.Min(p => p.TimeStampFrom)).ToList()[0];
        }

        public StockPrice GetNewestPrice()
        {
            return _prices.Where(price => price.TimeStampFrom == _prices.Max(p => p.TimeStampFrom)).ToList()[0];
        }


        public long NumberOfShares
        {
            get { return _numberOfShares; }
        }

        public void ChangePrice(decimal inNewPrice, DateTime inTimeStamp)
        {
            var newPrice = new StockPrice(inNewPrice, inTimeStamp);
            _latestPrice.Deactivate(inTimeStamp);
            _latestPrice = newPrice;
            _prices.Add(newPrice);
        }


        public decimal GetPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp < _timeStampCreation)
                throw new StockExchangeException("U tom vremenu dionica nije ni postojala!");

            if (inTimeStamp >= GetNewestPrice().TimeStampFrom)
                return GetNewestPrice().Price;

            return _prices.Where(p => p.TimeStampFrom >= inTimeStamp && p.TimeStampTo < inTimeStamp).ToList()[0].Price;
        }

        public string StockName
        {
            get { return _stockName; }
        }

        public decimal GetTotalValue(DateTime inTimeStamp)
        {
            return GetPrice(inTimeStamp) * NumberOfShares;
        }
    }

    public class StockPrice
    {
        private decimal _price;
        private DateTime _timeStampFrom;
        private DateTime _timeStampTo;

        public StockPrice(decimal inPrice, DateTime inStart)
        {
            if (inPrice <= 0)
                throw new StockExchangeException("Cijena dionice mora biti veća od nule!");

            _price = inPrice;
            _timeStampFrom = inStart;
        }

        public decimal Price
        {
            get { return _price; }
        }

        public DateTime TimeStampTo
        {
            get { return _timeStampTo; }
        }

        public DateTime TimeStampFrom
        {
            get { return _timeStampFrom; }
        }

        public void Deactivate(DateTime inStop)
        {
            _timeStampTo = inStop;
        }
    }

    public class StockRepository
    {
        private List<Stock> _listStocks = new List<Stock>();

        public int Count()
        {
            return _listStocks.Count;
        }

        public void AddStock(Stock inStock)
        {
            // provjeriti da li već postoji stock s tim imenom
            if (StockExists(inStock.StockName))
            {
                throw new StockExchangeException("Već postoji dionica stim imenom na burzi!");
            }

            _listStocks.Add(inStock);
        }

        public void RemoveStock(Stock inStock)
        {
            if (StockExists(inStock.StockName))
                _listStocks.Remove(inStock);
        }

        public Stock GetStock(string inStockName)
        {
            if (StockExists(inStockName))
                return _listStocks.Where(s => s.StockName.ToLower() == inStockName.ToLower()).ToList()[0];

            throw new StockExchangeException("Ne postoji dionica stim imenom!");
        }

        public bool StockExists(string inStockName)
        {
            return _listStocks.Count(s => s.StockName.ToLower() == inStockName.ToLower()) != 0;
        }
    }
}
