﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private string broj1 = "0";
        private string broj2 = "0";
        private string memoriraniBroj = "0";
        private char operacija = ' ';
        private bool errorState = false;
        private bool unosNovogBroja = true;
        private bool odabirBinarnogOperatora = false;

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'O') //reset
            {
                reset();
            }
            else if (errorState)
            {
                //blokirano sve osim tipke reset
            }
            else if (inPressedDigit == 'C') //clear
            {
                broj1 = "0";
            }
            else if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                if (unosNovogBroja)
                {
                    broj1 = "" + inPressedDigit;
                    unosNovogBroja = false;
                }
                else
                    inputNumber(inPressedDigit);
            }
            else if (inPressedDigit == ',')
            {
                if (unosNovogBroja)
                {
                    broj1 = "0,";
                    unosNovogBroja = false;
                }
                else if (!broj1.Contains(','))
                {
                    int limit = 10;
                    if (!broj1.Contains('-')) limit++;
                    if (broj1.Length < limit)
                        broj1 = broj1 + ",";
                }
            }
            else if (inPressedDigit == 'M') //promjena predznaka
            {
                if (unosNovogBroja)
                {
                    broj1 = "-0";
                    unosNovogBroja = false;
                }
                else if (broj1[0] == '-') broj1 = broj1.Remove(0, 1);
                else broj1 = "-" + broj1;
            }
            else if (inPressedDigit == 'P') //spremanje u memoriju
            {
                memoriraniBroj = broj1;
            }
            else if (inPressedDigit == 'G') //dohvacanje iz memorije
            {
                broj1 = memoriraniBroj;
            }
            else if (inPressedDigit == 'S') //sinus
            {
                broj1 = doubleToString(Math.Sin(Double.Parse(broj1)));
            }
            else if (inPressedDigit == 'K') //kosinus
            {
                broj1 = doubleToString(Math.Cos(Double.Parse(broj1)));
            }
            else if (inPressedDigit == 'T') //tangens
            {
                broj1 = doubleToString(Math.Tan(Double.Parse(broj1)));
            }
            else if (inPressedDigit == 'Q') //kvadrat
            {
                broj1 = doubleToString(Math.Pow(Double.Parse(broj1), 2));
            }
            else if (inPressedDigit == 'R') //korjen
            {
                if (broj1.Contains('-')) errorState = true;
                else
                {
                    broj1 = doubleToString(Math.Sqrt(Double.Parse(broj1)));
                }
            }
            else if (inPressedDigit == 'I') //inverz
            {
                if (Double.Parse(broj1.Replace(',', '.')) == 0) errorState = true;
                else
                {
                    broj1 = doubleToString(1.0d/(Double.Parse(broj1)));
                }
            }
            else if (inPressedDigit == '=')
            {
                obaviOperaciju();
                operacija = ' ';
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                if(!odabirBinarnogOperatora) obaviOperaciju();
                odabirBinarnogOperatora = true;
                broj2 = doubleToString(Double.Parse(broj1));
                operacija = inPressedDigit;
            }
            else
            {
                //neocekivani unos
                errorState = true;
            }
            if (!(inPressedDigit >= '0' && inPressedDigit <= '9' || inPressedDigit == ',' || inPressedDigit == 'M' || inPressedDigit == 'P'))
                unosNovogBroja = true;
            if (!(inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/'))
                odabirBinarnogOperatora = false;
        }

        public string GetCurrentDisplayState()
        {
            if (errorState) return "-E-";
            return broj1;
        }

        private void obaviOperaciju()
        {
            double operator1 = Double.Parse(broj1);
            double operator2 = Double.Parse(broj2);
            if (operacija == ' ')
                broj1 = doubleToString(operator1);
            else if (operacija == '+')
                broj1 = doubleToString(operator2 + operator1);
            else if (operacija == '-')
                broj1 = doubleToString(operator2 - operator1);
            else if (operacija == '*')
                broj1 = doubleToString(operator2 * operator1);
            else if (operacija == '/')
                broj1 = doubleToString(operator2 / operator1);
        }

        private void reset()
        {
            broj1 = "0";
            broj2 = "0";
            memoriraniBroj = "0";
            operacija = ' ';
            errorState = false;
        }

        private void inputNumber(char number)
        {
            if (broj1 == "0")
                broj1 = "" + number;
            else if (broj1 == "-0")
                broj1 = "-" + number;
            else
            {
                int limit = 10;
                if (broj1.Contains('-')) limit++;
                if (broj1.Contains(',')) limit++;
                if (broj1.Length < limit)
                    broj1 = broj1 + number;
            }
        }

        private string doubleToString(double number)
        {
            if (number > 9999999999.5)
            {
                errorState = true;
                return "-E-";
            }
            if (Math.Abs(number) > 10) number = Math.Round(number, 9 - (int)Math.Log10(Math.Abs(number)));
            else number = Math.Round(number, 9);
            return number.ToString();
        }

    }


}
