﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string pom;
        private string memory;
        private string display;
        private string BinOperator;
        private bool unarni;
        private List<double> numbers;
        private List<string> operators;

        public Kalkulator()
        {
            display = "0";
            memory = "0";
            pom = "";
            BinOperator = "";
            unarni = false;
            numbers = new List<double>();
            operators = new List<string>();
        }

        public void Press(char inPressedDigit)
        {
            // provjera je li upisani znak broj ili operator
            if (Char.IsDigit(inPressedDigit))
            {
                DetermineOperandNumber(inPressedDigit);
            }
            else
            {
                DetermineOperator(inPressedDigit);
            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        private void DetermineOperator(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '+':
                case '-':
                case '*':
                case '/':
                    DetermineBinary(inPressedDigit);
                    break;
                case ',':
                    DetermineOperandNumber(',');
                    break;
                case 'S':
                    display = Math.Sin(Convert.ToDouble(display)).ToString();
                    display = Rounding(display);
                    if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                    {
                        pom = display;
                        unarni = true;
                    }
                    if (!CheckResult(display)) isError();
                    break;
                case 'K':
                    display = Math.Cos(Convert.ToDouble(display)).ToString();
                    display = Rounding(display);
                    if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                    {
                        pom = display;
                        unarni = true;
                    }
                    if (!CheckResult(display)) isError();
                    break;
                case 'T':
                    display = Math.Tan(Convert.ToDouble(display)).ToString();
                    display = Rounding(display);
                    if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                    {
                        pom = display;
                        unarni = true;
                    }
                    if (!CheckResult(display)) isError();
                    break;
                case 'Q':
                    display = Math.Pow(Convert.ToDouble(display), 2).ToString();
                    display = Rounding(display);
                    if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                    {
                        pom = display;
                        unarni = true;
                    }
                    if (!CheckResult(display)) isError();
                    break;
                case 'R':
                    if (display[0] != '-')
                    {
                        display = Math.Sqrt(Convert.ToDouble(display)).ToString();
                        display = Rounding(display);
                        if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                        {
                            pom = display;
                            unarni = true;
                        }
                        if (!CheckResult(display)) isError();
                    }
                    else // u slučaju greške obrisi sve i ispisi -E- na ekran
                    {
                        isError();

                    }
                    break;
                case 'I':
                    if (display != "0") // ne može se dogoditi slučaj broj/0
                    {
                        display = (1 / (Convert.ToDouble(display))).ToString();
                        display = Rounding(display);
                        if (!(String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator)))
                        {
                            pom = display;
                            unarni = true;
                        }
                        if (!CheckResult(display)) isError();
                    }
                    else // u slučaju greške obrisi sve i ispisi -E- na ekran
                    {
                        isError();
                    }
                    break;
                case 'O': // nakon paljenja se na displayu prikazuje 0,a svi ostali podaci su resetirani!
                    display = "0";
                    memory = "0";
                    pom = BinOperator = "";
                    numbers.Clear();
                    operators.Clear();
                    break;
                case 'C': // brisanje ekrana, ne brisu se podaci iz memorije i prijasnjih operacija!
                    display = "0";
                    pom = "0";
                    break;
                case 'P': // spremanje u memoriju
                    memory = pom;
                    break;
                case 'G': // dohvaćanje iz memorije
                    pom = memory;
                    display = pom;
                    break;
                case 'M': // promjena predznaka 
                    if (display != "0")
                    {
                        if (display[0] == '-') display = display.Remove(0, 1);
                        else display = "-" + display;

                        display = Rounding(display);
                        pom = display;
                        if (!CheckResult(display)) isError();
                    }
                    break;
                case '=':
                    if (!String.IsNullOrEmpty(pom) && String.IsNullOrEmpty(BinOperator))
                    {
                        numbers.Add(Convert.ToDouble(pom));
                        display = Evaluate();
                        unarni = false;
                        numbers.Clear();
                        operators.Clear();
                        pom = display;
                        if (!CheckResult(display)) isError();
                    }
                    else if ((String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator) && numbers.Count > 0))
                    {
                        numbers.Add(numbers[numbers.Count - 1]);
                        operators.Add(BinOperator);
                        BinOperator = "";
                        unarni = false;
                        display = Evaluate();
                        numbers.Clear();
                        operators.Clear();
                        pom = display;
                        if (!CheckResult(display)) isError();
                    }
                    break;
                default:
                    isError();
                    break;
            }
        }

        private void isError()
        {
            display = "-E-";
            memory = "0";
            pom = BinOperator = "";
            unarni = false;
            operators.Clear();
            numbers.Clear();
        }

        private void DetermineOperandNumber(char inPressedDigit)
        {
            if (String.IsNullOrEmpty(pom) && String.IsNullOrEmpty(BinOperator))
            {
                if (inPressedDigit == ',') pom = "0,";
                else pom = inPressedDigit.ToString();
                pom = CheckNumberOfDigits(pom);
                display = pom;
            }

            else if (!String.IsNullOrEmpty(pom) && String.IsNullOrEmpty(BinOperator) && !(pom.Contains(",") && inPressedDigit == ','))
            {
                if (!(pom == "0" && inPressedDigit == '0'))
                {
                    if ((pom == "0" && inPressedDigit != ',') || unarni)
                    {
                        pom = inPressedDigit.ToString();
                        unarni = false;
                    }
                    else
                        pom = pom + inPressedDigit.ToString();
                    pom = CheckNumberOfDigits(pom);
                    display = pom;              
                }
                
            }

            else if (String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator) && numbers.Count > 0)
            {
                if (inPressedDigit == ',') pom = "0,"; 
                else pom = inPressedDigit.ToString();
                pom = CheckNumberOfDigits(pom);
                display = pom;
                operators.Add(BinOperator);
                BinOperator = "";
            }
        }

        private void DetermineBinary(char inPressedDigit)
        {
            if (String.IsNullOrEmpty(pom) && String.IsNullOrEmpty(BinOperator) && numbers.Count == 0)
            {
                numbers.Add(Convert.ToDouble("0"));
                BinOperator = inPressedDigit.ToString();
            }
            else if (!String.IsNullOrEmpty(pom) && String.IsNullOrEmpty(BinOperator))
            {
                unarni = false;
                pom = (Convert.ToDouble(pom)).ToString(); 
                pom = CheckNumberOfDigits(pom);
                display = pom;
                numbers.Add(Convert.ToDouble(pom));
                pom = "";
                BinOperator = inPressedDigit.ToString();
            }

            else if (String.IsNullOrEmpty(pom) && !String.IsNullOrEmpty(BinOperator) && numbers.Count > 0)
            {
                BinOperator = inPressedDigit.ToString();
            }
        }

        private string CheckNumberOfDigits(string pom)
        {
            int digits = GetNumberOfDigits(pom);
            if (digits > 10)
            {
                if (!pom.Contains(',') && !pom.Contains('-'))
                {
                    pom = pom.Remove(10, pom.Length - 10);
                    return pom;
                }
                else if (pom.Contains(',') && pom.Contains('-'))
                {
                    pom = pom.Remove(12, pom.Length - 12);
                    if (pom[pom.Length - 1] == ',') pom.Remove(pom.Length - 1);
                    return pom;
                }
                else
                {
                    pom = pom.Remove(11, pom.Length - 11);
                    if (pom[pom.Length - 1] == ',') pom.Remove(pom.Length - 1);
                    return pom;
                }
            }
            
            else return pom;

        }

        private int GetNumberOfDigits(string number)
        {
            int counter = 0;
            for (int i = 0; i < number.Length; i++)
            {
                if (Char.IsDigit(number[i]))
                    counter++;
            }
            return counter;
        }

        private int GetDecimalCount(decimal val)
        {
            int decimalCount = 0;
            while (val != Math.Floor(val))
            {
                val = (val - Math.Floor(val)) * 10;
                decimalCount++;
            }
            return decimalCount;
        }

        private string Rounding(string pom)
        {
            decimal number;
            if (Decimal.TryParse(pom, out number))
            {
                if (pom.Contains(',') && !pom.Contains('-'))
                    return pom = (Math.Round(number, 10 - (pom.Length - GetDecimalCount(number) - 1))).ToString();
                else if (pom.Contains(',') && pom.Contains('-'))
                    return pom = (Math.Round(number, 10 - (pom.Length - GetDecimalCount(number) - 2))).ToString();
            }
            return pom;
        }

        private string Evaluate()
        {
            double resultat = numbers[0];
            for (int i = 0; i < operators.Count; i++)
            {
                switch (operators[i])
                {
                    case "+":
                        resultat = resultat + numbers[i + 1];
                        break;
                    case "-":
                        resultat = resultat - numbers[i + 1];
                        break;
                    case "*":
                        resultat = resultat * numbers[i + 1];
                        break;
                    case "/":
                        if (numbers[i + 1] == 0) return "-E-";
                        else
                            resultat = resultat / numbers[i + 1];
                        break;
                }

            }

            return resultat.ToString();
        }

        private bool CheckResult(string result)
        {
            if (result.Length > 10)
            {
                if (!((result.Contains(",") || result.Contains("-")) && result.Length <= 12))
                {

                    return false;

                }
                else return true;
            }
            else
            {
                if (result == "-E-") return false;
                else return true;
            } 
        }
        
    }


}
