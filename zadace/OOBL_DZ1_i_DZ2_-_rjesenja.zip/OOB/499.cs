﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        public string ekran = "0";


        #region varijable     Kalkulatora
        private char[] bufer = new char[12];
        int broj_znamenki = 0;
        double prvi_operand;
        double rezultat = 0;
        string memorija = "";
        string funkcija = "";
        string posljednji_Stisnut = "";
        bool dogodila_se_greska = false;
        bool operandi = false;
        bool Stisnuo_jednako = false;
        string error_M = "-E-";
        string operatori = "+-*/";
        string operatori2 = "SKTQRI";
        #endregion

        #region Binary
        private void Jednako()
        {
            Stisnuo_jednako = true;

            if (funkcija.Equals("+"))
            {
                rezultat = prvi_operand + double.Parse(ekran);
                Zaokruzi(rezultat.ToString());
                return; 
            }
            if (funkcija.Equals("-"))
            {
                rezultat = prvi_operand - double.Parse(ekran);
                Zaokruzi(rezultat.ToString());
                return; 
            }
            if (funkcija.Equals("*"))
            {
                rezultat = prvi_operand * double.Parse(ekran);
                Zaokruzi(rezultat.ToString());
                return;
            }
            if (funkcija.Equals("/"))
            {
                rezultat = prvi_operand / double.Parse(ekran);
                Zaokruzi(rezultat.ToString());
                return;
            }

            
            
        }

        private void Oduzimanje()
        {
            if (!operandi)
            {
                prvi_operand = double.Parse(ekran);
                operandi = true;
                ocistiBuffer();
            }
            else if (!operatori.Contains(posljednji_Stisnut) && Stisnuo_jednako == false)
            {
                Jednako();
                prvi_operand = rezultat;
                ekran = rezultat.ToString();
                ocistiBuffer();
            }
            posljednji_Stisnut = "-";
            funkcija = "-";
            if (Stisnuo_jednako == true)
            {
                Stisnuo_jednako = false;
                ocistiBuffer();
                prvi_operand = rezultat;
            }
        }

        private void Zbrajanje()
        {
            if (!operandi)
            {
                prvi_operand = double.Parse(ekran);
                operandi = true;
                ocistiBuffer();

            }
            else if (!operatori.Contains(posljednji_Stisnut) && Stisnuo_jednako == false)
            {
                Jednako();
                prvi_operand = rezultat;
                ekran = rezultat.ToString();
                ocistiBuffer();
            }
            posljednji_Stisnut = "+";
            this.funkcija = "+";
            if (Stisnuo_jednako == true)
            {
                Stisnuo_jednako = false;
                ocistiBuffer();
                prvi_operand = rezultat;
            }
        }

        private void Dijeljenje()
        {
            if (!operandi)
            {
                prvi_operand = double.Parse(ekran);
                operandi = true;
                ocistiBuffer();
            }
            else if (!operatori.Contains(posljednji_Stisnut) && Stisnuo_jednako == false)
            {
                Jednako();
                prvi_operand = rezultat;
                ekran = rezultat.ToString();
                ocistiBuffer();

            }
            posljednji_Stisnut = "/";
            this.funkcija = "/";
            if (Stisnuo_jednako == true)
            {
                Stisnuo_jednako = false;
                ocistiBuffer();
                prvi_operand = rezultat;
            }
        }

        private void Mnozenje()
        {
            if (!operandi)
            {
                prvi_operand = double.Parse(ekran);
                operandi = true;
                ocistiBuffer();

            }
            else if (!operatori.Contains(posljednji_Stisnut) && Stisnuo_jednako == false)
            {
                Jednako();
                prvi_operand = rezultat;
                ekran = rezultat.ToString();
                ocistiBuffer();
            }
            posljednji_Stisnut = "*";
            this.funkcija = "*";
            if (Stisnuo_jednako == true)
            {
                Stisnuo_jednako = false;
                ocistiBuffer();
                prvi_operand = rezultat;
            }
        }

        #endregion

        #region Unary
        private void Inverz()
        {
            this.posljednji_Stisnut = "I";
            if (double.Parse(ekran) == 0)
            {
                ekran = error_M;
                dogodila_se_greska = true;
                return;
            }
            double inverz = 1 / double.Parse(ekran);
            string test = inverz.ToString();
            Zaokruzi(test);
        }

        private void Korjenovanje()
        {
            this.posljednji_Stisnut = "R";
            if ((double.Parse(ekran)) < 0)
            {
                ekran = error_M;
                dogodila_se_greska = true;
                return;
            }
            string izracun = Math.Sqrt(double.Parse(ekran)).ToString();
            Zaokruzi(izracun);

        }
        private void Kvadriranje()
        {
            this.posljednji_Stisnut = "Q";
            string izracun = Math.Pow((double.Parse(ekran)), 2).ToString();
            Zaokruzi(izracun);
        }
        private void Tangens()
        {
            this.posljednji_Stisnut = "T";
            if (double.Parse(ekran) % 90 == 0)
            {
               ekran = error_M;
                dogodila_se_greska = true;
                return;
            }
            double tangens = Math.Tan(double.Parse(ekran));
            string test = tangens.ToString();
            Zaokruzi(test);
        }
        private void Kosinus()
        {
            this.posljednji_Stisnut = "K";
            string izracun = Math.Cos(double.Parse(ekran)).ToString();
            Zaokruzi(izracun);
        }
        private void Sinus()
        {
            this.posljednji_Stisnut = "S";
            string izracun = Math.Sin(double.Parse(ekran)).ToString();
            Zaokruzi(izracun);
        }

        #endregion

        #region pomocneFunkcije

        private void ucitajBuffer()
        {
            ocistiBuffer();
            int j = 11;
            bool predznak = false;
            for (int i = ekran.Length - 1; i >= 0; i--)
            {

                if (ekran[i] >= '0' && ekran[i] <= '9' || ekran[i] == ',')
                {
                    bufer[j] = ekran[i];
                }
                else if (ekran[i] == '-')
                {
                    predznak = true;
                }
                j--;
            }

            if (predznak)
            {
                bufer[0] = '-';
            }


        }
        private void IspuniDisplay()
        {
            string nes = new string(this.bufer);
            string novi = nes.Replace("\0", "");
            if (novi.Contains(","))
            {
                decimal test = decimal.Parse(novi);
                test = test / 1.000000000000000000000000000000000m;
                novi = test.ToString();

            }
            ekran = novi;
        }

        private void Pomakni(char[] buff)
        {
            if (ekran.Contains(','))
            {
                for (int i = 1; i < 11; i++)
                {
                    buff[i] = buff[i + 1];
                }
            }
            else if (!ekran.Contains(','))
            {
                for (int i = 2; i < 11; i++)
                {
                    buff[i] = buff[i + 1];
                }

            }
           
        }
        private void ocistiBuffer()
        {
            if (!dogodila_se_greska)
            {
                this.broj_znamenki = 0;
                for (int i = 0; i < 12; i++)
                {
                    this.bufer[i] = '\0';
                }
            }
        }
        #endregion

        #region ostaleFunkcije


        private void Zarez()
        {
            if (ekran.Length == 1 && ekran.Contains("0"))
            {
                this.bufer[11] = '0';
                broj_znamenki++;
            }
            else if (broj_znamenki == 10 || ekran.Contains(","))
            {
                return;
            }
            Pomakni(this.bufer);
            this.bufer[11] = ',';
            IspuniDisplay();
        }

        private void Reset()
        {
            ekran = "0";
            prvi_operand = 0;
            rezultat = 0;


            dogodila_se_greska = false;
            
            funkcija = "";
            memorija = "";


            ocistiBuffer();
        }

        private void BrisanjeEkrana()
        {
            ekran = "0";
            if (this.dogodila_se_greska == true)
            {
                dogodila_se_greska = false;
                operandi = false;
                rezultat = 0;
            }
            ocistiBuffer();
        }

        private void DohvatMemorija()
        {
            this.ekran = this.memorija;
        }

        private void SpremanjeMemorija()
        {
            this.memorija = this.ekran;
        }

        private void PromijeniPredznak()
        {
            if (ekran != "0" && !Stisnuo_jednako && !operatori2.Contains(this.posljednji_Stisnut))
            {

                if (this.bufer[0].Equals('\0'))
                {
                    this.bufer[0] = '-';
                    IspuniDisplay();
                }
                else
                {
                    this.bufer[0] = '\0';
                    IspuniDisplay();
                }
            }
            else if (Stisnuo_jednako)
            {
                ucitajBuffer();

                if (this.bufer[0].Equals('\0'))
                {
                    this.bufer[0] = '-';
                    IspuniDisplay();
                    string a = new string(this.bufer);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
                else
                {
                    this.bufer[0] = '\0';
                    IspuniDisplay();
                    string a = new string(this.bufer);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
            }
            else
            {
                ekran = "-" + ekran;
            }
        }
        #endregion

        
        private void Zaokruzi(string rezultat)
        {

            double nes = double.Parse(rezultat);
            if (nes < -9999999999 || nes > 9999999999)
            {
                ekran = error_M;
                this.dogodila_se_greska = true;
                return;
            }
            else
            {
                if (rezultat.Contains(","))
                {
                    int zarez = rezultat.IndexOf(',');
                    int broj;
                    if (rezultat.Contains("-"))
                    {
                        broj = 11;
                    }
                    else
                    {
                        broj = 10;
                    }
                    broj = broj - zarez;
                    double zaokruzeni = double.Parse(rezultat);
                    zaokruzeni = Math.Round(zaokruzeni, broj);
                    ekran = zaokruzeni.ToString();
                    rezultat = zaokruzeni.ToString();
                }

            }


            ekran = rezultat;

        }
       

        #region unos
        public void Press(char inPressedDigit)
        {
            if (!dogodila_se_greska || inPressedDigit.Equals('C') || inPressedDigit.Equals('O'))
            {
                if (inPressedDigit.Equals('0'))
                {
                    Unesena_nula(); 
                    return;
                }
                if (inPressedDigit.Equals('1'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('2'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('3'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('4'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('5'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('6'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('7'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('8'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('9'))
                {
                    Unos_broja(inPressedDigit);
                    return;
                }
                if (inPressedDigit.Equals('+'))
                {
                    Zbrajanje();
                    return;
                }
                if (inPressedDigit.Equals('-'))
                {
                    Oduzimanje();
                    return;
                }
                if (inPressedDigit.Equals('*'))
                {
                    Mnozenje(); 
                    return;
                }
                if (inPressedDigit.Equals('/'))
                {
                    Dijeljenje();
                    return;
                }
                if (inPressedDigit.Equals('='))
                {
                    Jednako(); 
                    return;
                }
                if (inPressedDigit.Equals(','))
                {
                    Zarez();
                    return;
                }
                if (inPressedDigit.Equals('M'))
                {
                    PromijeniPredznak();
                    return;
                }
                if (inPressedDigit.Equals('S'))
                {
                    Sinus();
                    return;
                }
                if (inPressedDigit.Equals('K'))
                {
                    Kosinus();
                    return;
                }
                if (inPressedDigit.Equals('T'))
                {
                    Tangens();
                    return;
                }
                if (inPressedDigit.Equals('Q'))
                {
                    Kvadriranje();
                    return;
                }
                if (inPressedDigit.Equals('R'))
                {
                    Korjenovanje();
                    return;
                }
                if (inPressedDigit.Equals('I'))
                {
                    Inverz();
                    return;
                }
                if (inPressedDigit.Equals('P'))
                {
                    SpremanjeMemorija();
                    return;
                }
                if (inPressedDigit.Equals('G'))
                {
                    DohvatMemorija();
                    return;
                }
                if (inPressedDigit.Equals('C'))
                {
                    BrisanjeEkrana();
                    return;
                }
                if (inPressedDigit.Equals('O'))
                {
                    Reset();
                    return;
                }
               

                
            }
        }


        private void Unesena_nula()
        {
            if (broj_znamenki < 10)
            {

                if (!(broj_znamenki == 0 && ekran == "0"))
                {
                    posljednji_Stisnut = "0";
                    Pomakni(this.bufer);
                    this.bufer[11] = '0';
                    broj_znamenki++;
                    IspuniDisplay();
                }
               
            }
           
        }

        private void Unos_broja(char broj)
        {
            if (broj_znamenki < 10)
            {
                posljednji_Stisnut = broj.ToString();
                Pomakni(this.bufer);
                this.bufer[11] = broj;
                broj_znamenki++;
                IspuniDisplay();

            }
           
        }
        #endregion


        public string GetCurrentDisplayState()
        {
            return this.ekran;
        }

    }

        
}
