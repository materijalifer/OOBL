﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public StockExchange()
         {
             stocks = new List<Stock>();
             indices = new List<Index>();
             portfolioes = new List<Portfolio>();
         }

         private List<Stock> stocks;

         private List<Index> indices;

         private List<Portfolio> portfolioes; 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             // Provjera cijene i broja udjela
             if ((inNumberOfShares <= 0) || (inInitialPrice <= 0))
                 throw new StockExchangeException("Cijena i broj dionica nemogu biti negativni niti 0!");

             // Sva velika slova
             inStockName = inStockName.ToUpper();

             // Provjeriti postoji li već dionica
             if(FindStock(inStockName) != null)
                 throw new StockExchangeException("Dionica" + inStockName + "već postoji!");

             // Dodati dionicu
             stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             Stock stock = FindStock(inStockName);

             // Brisanje dionice iz svih indexa u kojim postoji
             foreach (Index index in indices)
             {
                 if(index.ContainsStock(stock))
                     index.RemoveStockFromIndex(stock);
             }

             foreach (Portfolio portfolio in portfolioes)
             {
                 try
                 {
                     portfolio.RemoveStockShares(stock);
                 }
                 catch {}
             }

             if ( stock != null )
                 stocks.Remove(stock);
             else
                 throw new StockExchangeException("Dionicu nije moguće obrisati jer ne postoji!");
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();

             if (FindStock(inStockName) != null)
                 return true;
             
             return false;
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (inStockValue <= 0)
                 throw new StockExchangeException("Cijena dionice mora biti veća od nula!");

             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);

             if (stock != null)
             {
                 if (!stock.AddNewPrice(inStockValue, inTimeStamp))
                     throw new StockExchangeException("Postoji definirana cijena za zadani trenutak!");
             }
             else
             {
                 throw new StockExchangeException("Nemoguće dodati novu cijenu jer dionica ne postoji!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);

             if (stock != null)
             {
                 try
                 {
                     return stock.GetPrice(inTimeStamp);
                 }
                 catch (StockExchangeException e)
                 {
                     //re-throw exception
                     throw e;
                 }
             }
             
             throw new StockExchangeException("Dionica ne postoji!");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);

             if (stock != null)
             {
                 return stock.GetInitialPrice();
             }
             
             throw new StockExchangeException("Dionica ne postoji!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);

             if (stock != null)
             {
                 return stock.GetLastPrice();
             }
             
             throw new StockExchangeException("Dionica ne postoji!");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             // Provjera tipa indexa
             if (!((inIndexType == IndexTypes.AVERAGE) || (inIndexType == IndexTypes.WEIGHTED)))
                 throw new StockExchangeException("Index je nedefiniranog tipa!");

             inIndexName = inIndexName.ToUpper();

             if( FindIndex(inIndexName) != null )
                 throw new StockExchangeException("Index" + inIndexName + "već postoji!");

             // Dodaj novi index
            indices.Add(new Index( inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);
             Index index = FindIndex(inIndexName);

             if(stock == null)
                 throw new StockExchangeException("Ne postoji zadana dionica!");

             if(index == null)
                 throw new StockExchangeException("Ne postoji zadani index!");

             if (!index.AddNewStockToIndex(stock))
                 throw new StockExchangeException("U indexu već postoji zadana dionica!");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);
             Index index = FindIndex(inIndexName);

             if (stock == null)
                 throw new StockExchangeException("Ne postoji zadana dionica!");

             if (index == null)
                 throw new StockExchangeException("Ne postoji zadani index!");

             if (!index.RemoveStockFromIndex(stock))
                 throw new StockExchangeException("U indexu ne postoji zadana dionica!");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();

             Stock stock = FindStock(inStockName);
             Index index = FindIndex(inIndexName);

             if (stock == null)
                 throw new StockExchangeException("Ne postoji zadana dionica!");

             if (index == null)
                 throw new StockExchangeException("Ne postoji zadani index!");

             return index.ContainsStock(stock);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();

             Index index = FindIndex(inIndexName);

             if (index != null)
             {
                 try
                 {
                     return index.ClaculateValueOfIndex(inTimeStamp);
                 }
                 catch (StockExchangeException e)
                 {
                     throw e;
                 }   
             }
             
             throw new StockExchangeException("Index ne postoji!");
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();

             Index index = FindIndex(inIndexName);

             if (index != null)
             {
                 return true;
             }
             
             return false;
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();

             Index index = FindIndex(inIndexName);

             if (index != null)
             {
                 return index.NumberOfStocks();
             }
         
             throw new StockExchangeException("Index ne postoji!");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(FindPortfolio(inPortfolioID) != null)
                 throw new StockExchangeException("Portofelj sa zadanim IDem već postoji!");

             portfolioes.Add(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if(numberOfShares <= 0)
                 throw new StockExchangeException("Negativna vrijednost dijelova dionica!");

             inStockName = inStockName.ToUpper();

             Portfolio portfolio = FindPortfolio(inPortfolioID);
             Stock stock = FindStock(inStockName);

             if( portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             if( stock == null )
                 throw new StockExchangeException("Zadana dionica ne postoji!");

             int sumShares = 0;

             // Izračunaj broj dijelova u ostalim portfeljima
             foreach (Portfolio hPortfolio in portfolioes)
             {
                 sumShares += hPortfolio.NumberOfSharesForStock(stock);
             }

             if ((sumShares + numberOfShares) <= stock.NumberOfShares)
             {
                 portfolio.AddStockShares(stock, numberOfShares);
             }
             else
             {
                 portfolio.AddStockShares(stock, ((int)stock.NumberOfShares - sumShares));
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();

             Portfolio portfolio = FindPortfolio(inPortfolioID);
             Stock stock = FindStock(inStockName);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             if (stock == null)
                 throw new StockExchangeException("Zadana dionica ne postoji!");

             if( !portfolio.RemoveStockShares( stock, numberOfShares))
                 throw new StockExchangeException("Dionica ne postoji u portfelju!");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();

             Portfolio portfolio = FindPortfolio(inPortfolioID);
             Stock stock = FindStock(inStockName);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             if (stock == null)
                 throw new StockExchangeException("Zadana dionica ne postoji!");

             if (!portfolio.RemoveStockShares(stock))
                 throw new StockExchangeException("Dionica ne postoji u portfelju!");
         }

         public int NumberOfPortfolios()
         {
             return portfolioes.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = FindPortfolio(inPortfolioID);

             if (portfolio != null)
                 return portfolio.NumberOfStockShares();

             throw new StockExchangeException("Zadani portfelj ne postoji!");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             Portfolio portfolio = FindPortfolio(inPortfolioID);

             if (portfolio != null)
                 return true;

             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();

             Portfolio portfolio = FindPortfolio(inPortfolioID);
             Stock stock = FindStock(inStockName);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             if (stock == null)
                 return false;

             return portfolio.IsStock(stock);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();

             Portfolio portfolio = FindPortfolio(inPortfolioID);
             Stock stock = FindStock(inStockName);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             if (stock == null)
                 throw new StockExchangeException("Zadana dionica ne postoji!");

             return portfolio.NumberOfSharesOfStock(stock);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = FindPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             try
             {
                 return portfolio.GetValue(timeStamp);
             }
             catch (StockExchangeException e)
             {    
                 throw e;
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime startDate;
             DateTime endDate;

             Portfolio portfolio = FindPortfolio(inPortfolioID);

             if (portfolio == null)
                 throw new StockExchangeException("Zadani portfelj ne postoji!");

             try
             {
                 startDate = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                 endDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Krivo formatiran datum!");   
             }
             

             decimal valueStartDay;
             decimal valueEndDay;
             decimal result;

             try
             {
                 valueStartDay = portfolio.GetValue(startDate);
             }
             catch (StockExchangeException e)
             {
                 throw e;
             }

             try
             {
                 valueEndDay = portfolio.GetValue(endDate);
             }
             catch (StockExchangeException e)
             {
                 throw e;
             }

             result = ((valueEndDay - valueStartDay)/valueStartDay)*100;
             result = Decimal.Round(result, 3);

             return result;
         }

         private Stock FindStock(string stockName)
         {
             foreach (Stock stock in stocks)
             {
                 if (stock.StockName == stockName)
                     return stock;
             }

             // Nepostoji
             return null;
         }

         private Index FindIndex(string indexName)
         {
             foreach (Index index in indices)
             {
                 if (index.IndexName == indexName)
                     return index;
             }

             // Ne postoji
             return null;
         }

         private Portfolio FindPortfolio(string portfolioID)
         {
             foreach (Portfolio portfolio in portfolioes)
             {
                 if (portfolio.PortfolioID == portfolioID)
                     return portfolio;
             }

             return null;
         }
     }

    public class Stock
    {
        // Dionica
        public Stock( string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp )
        {
            this.stockName = stockName;
            this.numberOfShares = numberOfShares;
            
            // Otvaranje zapisnika cijena kroz vrijeme
            priceLogs = new List<PriceLog>();

            // Unesi inicijalnu cijenu u zapisnik
            AddNewPrice(initialPrice, timeStamp);
        }

        // Varijable dionice
        private string stockName;

        private long numberOfShares;

        private List<PriceLog> priceLogs;


        // Geteri
        public string StockName
        {
            get { return stockName; }
        }

        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        // Dodavanje nove cijene
        public bool AddNewPrice(decimal price, DateTime date)
        {
            // Postoji već unesena cijena za uneseni trenutak
            foreach (PriceLog priceLog in priceLogs)
            {
                int result = DateTime.Compare(date, priceLog.Date);
                if (result == 0)
                    return false;
            }

            // Ubaci novi zapis
            priceLogs.Add( new PriceLog( price, date ));

            return true;
        }

        // Traženje inicijalne cijene
        public decimal GetInitialPrice()
        {
            PriceLog initPriceLog = priceLogs.ElementAt(0);

            foreach (PriceLog priceLog in priceLogs)
            {
                int result = DateTime.Compare(initPriceLog.Date, priceLog.Date);

                if (result > 0)
                    initPriceLog = priceLog;
            }

            return initPriceLog.Price;
        }

        // Traženje zadnje cijene
        public decimal GetLastPrice()
        {
            PriceLog lastPriceLog = priceLogs.ElementAt(0);

            foreach (PriceLog priceLog in priceLogs)
            {
                int result = DateTime.Compare(lastPriceLog.Date, priceLog.Date);

                if (result < 0)
                    lastPriceLog = priceLog;
            }

            return lastPriceLog.Price;
        }

        // Traženje cijene aktualne u nekom vremenu
        public decimal GetPrice(DateTime date)
        {
            PriceLog hPriceLog = priceLogs.ElementAt(0);

            // Pronadji inicijalnu
            foreach (PriceLog priceLog in priceLogs)
            {
                int result = DateTime.Compare(hPriceLog.Date, priceLog.Date);

                if (result > 0)
                    hPriceLog = priceLog;
            }

            // Provjeriti je li zadan datum raniji od inicijalnog datuma
            int res = DateTime.Compare(hPriceLog.Date, date);

            if (res > 0)
                throw new StockExchangeException("Cijena za zadano vrijeme nije definirana!");

            // Od inicijalnog traži najveći datum ali da nije veći od zadanog
            foreach (PriceLog priceLog in priceLogs)
            {
                int result1 = DateTime.Compare(hPriceLog.Date, priceLog.Date);
                int result2 = DateTime.Compare(priceLog.Date, date);

                if (result1 < 0)
                {
                    // Ako je datum ranije od zadanog
                    if (result2 <= 0)
                    {
                        hPriceLog = priceLog;
                    }
                }
            }

            return hPriceLog.Price;
        }
    }

    public class PriceLog
    {
        // Zapis cijene u nekom vremenu
        public PriceLog( decimal price, DateTime date )
        {
            this.price = price;
            this.date = date;
        }

        private decimal price;

        private DateTime date;

        public decimal Price
        {
            get { return price; }
        }

        public DateTime Date
        {
            get { return date; }
        }
    }

    public class Index
    {
        public Index(string indexName, IndexTypes indexType)
        {
            this.indexName = indexName;
            this.indexType = indexType;

            stocksInIndex = new List<Stock>();
        }

        private string indexName;

        private IndexTypes indexType;

        private List<Stock> stocksInIndex;

        public string IndexName
        {
            get { return indexName; }
        }

        public IndexTypes IndexType
        {
            get { return indexType; }
        }

        public bool AddNewStockToIndex(Stock newStock)
        {
            if (!stocksInIndex.Contains(newStock))
            {
                // U indexu ne postoji zadana dionica
                stocksInIndex.Add(newStock);
                return true;
            }

            // Index već sadrži zadanu dionicu
            return false;
        }

        public bool RemoveStockFromIndex(Stock delStock)
        {
            if(stocksInIndex.Contains( delStock ))
            {
                stocksInIndex.Remove(delStock);
                return true;
            }

            return false;
        }

        public bool ContainsStock(Stock stock)
        {
            return stocksInIndex.Contains(stock);
        }

        public decimal ClaculateValueOfIndex(DateTime timeStamp)
        {
            if (indexType == IndexTypes.AVERAGE)
            {
                // Algoritam za average
                decimal result = 0;

                foreach (Stock stock in stocksInIndex)
                {
                    try
                    {
                        decimal pom = stock.GetPrice(timeStamp);
                        result += pom;
                    }
                    catch (StockExchangeException e)
                    {
                        // re-throw exception
                        throw e;
                    }
                }

                decimal numOfStocks = (decimal)stocksInIndex.Count;

                if (numOfStocks != 0)
                {
                    result /= numOfStocks;
                    result = Decimal.Round(result, 3);

                    return result;
                }
                
                // Nema dionica u indexu
                return 0;
            }
            else
            {
                // Algoritam za weighted
                decimal sum = 0;
                decimal result = 0;

                // Suma vrijednosti
                foreach (Stock stock in stocksInIndex)
                {
                    try
                    {
                        decimal pom = stock.GetPrice(timeStamp);
                        pom *= stock.NumberOfShares;
                        sum += pom;
                    }
                    catch (StockExchangeException e)
                    {
                        // re-throv exception
                        throw e;
                    }
                }

                if (sum == 0)
                    return 0;

                foreach (Stock stock in stocksInIndex)
                {
                    try
                    {
                        decimal price = stock.GetPrice(timeStamp);
                        decimal weight = price/sum;

                        result += (price * weight) * stock.NumberOfShares;
                    }
                    catch (StockExchangeException e)
                    {
                        // re-throw exception
                        throw e;
                    }
                }

                result = Decimal.Round(result, 3);
                return result;
            }
        }

        public int NumberOfStocks()
        {
            return stocksInIndex.Count;
        }
    }

    public class Portfolio
    {
        public Portfolio( string portfolioID)
        {
            this.portfolioID = portfolioID;

            stockShares = new List<StockShare>();
        }

        private string portfolioID;

        private List<StockShare> stockShares;  

        public string PortfolioID
        {
            get { return portfolioID; }
        }

        public void AddStockShares(Stock stock, int sharesInPortfolio)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
            {
                // Dionica već postoji u portfelju
                stockShare.SharesInPortfolio += sharesInPortfolio;
            }
            else
            {
                // Dionica ne postoji u portfelju
                stockShares.Add(new StockShare(stock, sharesInPortfolio));
            }
        }

        public int NumberOfSharesForStock(Stock stock)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
                return stockShare.SharesInPortfolio;

            return 0;
        }

        public StockShare FindStockSare(Stock stock)
        {
            foreach (StockShare stockShare in stockShares)
            {
                if (stockShare.Stock == stock)
                    return stockShare;
            }

            return null;
        }

        public bool RemoveStockShares(Stock stock, int sharesInPortfolio)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
            {
                // Dionica postoji
                stockShare.SharesInPortfolio -= sharesInPortfolio;

                // Je li potrebno brisanje
                if(stockShare.SharesInPortfolio <= 0)
                    stockShares.Remove(stockShare);

                return true;
            }
            
            // Ne postoji
            return false;
        }

        public bool RemoveStockShares(Stock stock)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
            {
                // Dionica postoji
                stockShares.Remove(stockShare);

                return true;
            }

            // Ne postoji
            return false;
        }

        public int NumberOfStockShares()
        {
            return stockShares.Count;
        }

        public bool IsStock(Stock stock)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
                return true;

            return false;
        }

        public int NumberOfSharesOfStock(Stock stock)
        {
            StockShare stockShare = FindStockSare(stock);

            if (stockShare != null)
                return stockShare.SharesInPortfolio;

            return 0;
        }

        public decimal GetValue( DateTime timeStamp )
        {
            decimal value = 0;

            foreach (StockShare stockShare in stockShares)
            {
                decimal pom;

                try
                {
                    pom = stockShare.Stock.GetPrice(timeStamp);
                }
                catch (StockExchangeException e)
                {
                    throw e;
                }

                value += pom * stockShare.SharesInPortfolio;
            }

            return value;
        }
    }

    public class StockShare
    {
        public StockShare(Stock stock, int sharesInPortfolio)
        {
            this.stock = stock;
            this.sharesInPortfolio = sharesInPortfolio;
        }

        private Stock stock;

        private int sharesInPortfolio;

        public Stock Stock
        {
            get { return stock; }
        }

        public int SharesInPortfolio
        {
            get { return sharesInPortfolio; }
            set { sharesInPortfolio = value; }
        }
    }
        
}
