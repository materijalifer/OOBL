﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {

        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        String inputA = "0", inputB = "0", operation = "", minus = "", output = "0", minusB = "";
        Double opA, opB, result, memory = 0;
        Boolean waitForOpA = true, waitForOpB = false, isDecimalA = false, isDecimalB = false, numberIsPressed = true, operationDone = false;
        String[] numbers = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        String[] unarOperators = { "S", "K", "T", "Q", "R", "I" };
        String[] binaryOperations = { "+", "-", "*", "/" };
        String key = "";

        public static Boolean decimalCheck(String number)
        {
            Decimal num = Convert.ToDecimal(number);
            num = Math.Round(num, 9);
            if (num > 10) return true;
            else return false;
        }

        public static Double round(Double number)
        {
            String strNum = "";
            Double retNum = 0;
            Int32 indexOfComa;
            strNum = number.ToString();
            if (number > 9999999999) return 10000000000;
            if (strNum.Contains(','))
            {
                indexOfComa = strNum.IndexOf(',');
                if (strNum[0] == '-')
                {
                    retNum = Math.Round(number, 11 - indexOfComa);
                }
                else
                {
                    retNum = Math.Round(number, 11 - indexOfComa - 1);
                }
            }
            else retNum = number;


            return retNum;
        }


        public void Press(char inPressedDigit)
        {
            //Console.WriteLine("You pressed: " + inPressedDigit);
            key = inPressedDigit.ToString();

            if (waitForOpA)
            {

                if (key == "P")
                {
                    memory = Convert.ToDouble(inputA);
                }
                if (key == "G")
                {
                    inputA = memory.ToString();
                    opA = memory;
                }


                if (key == "C")
                {
                    inputA = "0";
                    opA = 0;
                }
                if (key == "O") {
                    inputA = "0";
                    inputB = "0";
                    opA = 0;
                    opB = 0;
                    memory = 0;
                    isDecimalA = false;
                    isDecimalB = false;
                    output = "0";
                }



                if (round(opA) > 9999999999)
                    output = "-E-";
                else if (key == "-" && inputA[0].ToString() != "-" && inputA.Length == 1)
                {
                    minus = "-";

                }
                else if (numbers.Contains(key)) //if pressed key is number
                {
                    if (inputA == "0" && key != "0")
                    {
                        inputA = minus + key;
                        opA = Convert.ToDouble(inputA);
                    }
                    else if (inputA.Count(x => Char.IsDigit(x)) < 10 && inputA != "0")//need to count only numbers, but no "-" or ","
                    {
                        inputA += key;
                        opA = Convert.ToDouble(inputA);


                    }

                }
                else if (key == "," && !isDecimalA && inputA.Count(x => Char.IsDigit(x)) < 10)
                {
                    if (inputA == "0")
                        inputA = minus + "0,";
                    else inputA += ",";
                    isDecimalA = true;
                    opA = Convert.ToDouble(inputA);

                }



                else if (unarOperators.Contains(key))
                {
                    if (key == "S")
                    {
                        opA = Math.Sin(Convert.ToDouble(inputA));
                        inputA = opA.ToString();
                    }
                    else if (key == "K")
                    {
                        opA = Math.Cos(Convert.ToDouble(inputA));
                        inputA = opA.ToString();
                    }
                    else if (key == "T")
                    {
                        opA = Math.Tan(Convert.ToDouble(inputA));
                        inputA = opA.ToString();
                    }
                    else if (key == "Q")
                    {
                        opA = Convert.ToDouble(inputA);
                        opA = opA * opA;
                        inputA = opA.ToString();
                    }
                    else if (key == "R")
                    {
                        if (opA < 0)
                            inputA = "-E-";
                        else
                        {
                            opA = Math.Sqrt(Convert.ToDouble(inputA));
                            inputA = opA.ToString();
                        }
                    }
                    else if (key == "I") //dodaj provjeru inverza 0
                    {
                        if (Convert.ToDouble(inputA) == 0)
                            inputA = "-E-";

                        else
                        {
                            if (inputA == "0")
                                output = "-E-";
                            else{
                            opA = 1 / Convert.ToDouble(inputA);
                            inputA = opA.ToString();
                            }
                        }
                    }

                    if (inputA != "-E-")
                    {
                        opA = round(opA);
                        output = opA.ToString();
                        inputA = opA.ToString();
                    }
                    else { output = "-E-"; }
                }
                else if (binaryOperations.Contains(key))
                {
                    waitForOpB = true;
                    waitForOpA = false;
                    operation = key;
                }
                else if (key == "=")
                    output = opA.ToString();
                else output = opA.ToString();
                if (opA > 9999999999)
                    output = "-E-";
            }

            if (waitForOpB) /////////////////////////////////
            {
                //operationDone = true;

                if (key == "O")
                {
                    inputA = "0";
                    inputB = "0";
                    opA = 0;
                    opB = 0;
                    memory = 0;
                    isDecimalA = false;
                    isDecimalB = false;
                    output = "0";
                }

                if (key == "P")
                {
                    memory = Convert.ToDouble(output);
                }
                if (key == "G")
                {
                    inputA = memory.ToString();
                    opA = memory;
                    output = inputA;
                    operationDone = false;
                }

                if (key == "C") {
                    opB = 0;
                    output = "0";
                }

                if (key == "-" && inputB[0].ToString() != "-")// && inputB.Length == 1)
                {
                    operationDone = false;
                    minusB = "-";

                }

                if (inputA.Count(x => Char.IsDigit(x)) > 10 && decimalCheck(inputA))
                {
                    output = "-E-"; 
                }
                else if (numbers.Contains(key)) //if pressed key is number
                {
                    operationDone = false;
                    numberIsPressed = true;
                    if (inputB == "0" && key != "0")
                    {
                        inputB = minusB + key;
                        opB = Convert.ToDouble(inputB);

                    }
                    else if (inputB.Count(x => Char.IsDigit(x)) < 10 && inputB != "0")//need to count only numbers, but no "-" or ","
                    {
                        inputB += key;
                        opB = Convert.ToDouble(inputB);

                    }


                }



                else if (key == "," && !isDecimalB && output.Count(x => Char.IsDigit(x)) < 10)
                {
                    numberIsPressed = true;
                    if (inputB == "0")
                        inputB = minusB + "0,";
                    else inputB += ",";
                    isDecimalB = true;
                    opB = Convert.ToDouble(inputB);

                }


                else if (key == "=" && operationDone)
                {
                    output = result.ToString();


                    if (output.Count(x => Char.IsDigit(x)) > 10 && decimalCheck(output))
                    {
                        output = "-E-";
                    }

                    opB = 0;
                    opA = 0;
                    inputA = "0";
                    inputB = "0";
                    minus = "";
                    minusB = "";
                    waitForOpA = true;
                    waitForOpB = false;
                    isDecimalA = false;
                    isDecimalB = false;
                    result = 0;
                }


                else if (unarOperators.Contains(key))
                {

                    if (key == "S")
                    {
                        opB = Math.Sin(Convert.ToDouble(inputB));
                        inputB = opB.ToString();
                    }
                    else if (key == "K")
                    {
                        opB = Math.Cos(Convert.ToDouble(inputB));
                        inputB = opB.ToString();
                    }
                    else if (key == "T")
                    {
                        opB = Math.Tan(Convert.ToDouble(inputB));
                        inputB = opB.ToString();
                    }
                    else if (key == "Q")
                    {
                        opB = Convert.ToDouble(inputB);
                        opB = opB * opB;
                        inputB = opB.ToString();
                    }
                    else if (key == "R")
                    {

                        if (Convert.ToDouble(inputB) < 0 || Convert.ToDouble(inputA) < 0)
                            output = "-E-";

                        else
                        {

                            opB = Math.Sqrt(Convert.ToDouble(inputB));
                            inputB = opB.ToString();
                        }

                    }
                    else if (key == "I")
                    {
                        if (opB != 0)
                        {
                            opB = 1 / Convert.ToDouble(inputB);
                            inputB = opB.ToString();
                        }
                        else output = "-E-";
                    }
                    else operationDone = true;


                    opB = round(opB);
                    inputB = opB.ToString();
                }


                else if (binaryOperations.Contains(operation) && numberIsPressed) //checking for operation from opA
                {

                    if (operation == "+")
                    {
                        opA = opA + opB;
                        result = opA;
                        inputA = opA.ToString();

                        output = result.ToString();
                        opB = 0;
                        inputB = "0";
                        minusB = "";
                        isDecimalB = false;
                    }

                    else if (operation == "-")
                    {
                        opA = opA - opB;
                        inputA = opA.ToString();

                        result = round(opA);
                        output = result.ToString();

                        opB = 0;
                        inputB = "0";
                        minusB = "";
                        isDecimalB = false;


                    }

                    else if (operation == "*")
                    {
                        if (opB != 0)
                        {
                            opA = opA * opB;
                            result = opA;
                        }
                        else result = 0;
                        inputA = opA.ToString();
                        output = result.ToString();
                        opB = 0;
                        inputB = "0";
                        minusB = "";
                        isDecimalB = false;
                    }

                    else if (operation == "/")
                    {

                        if (opB != 0)
                        {
                            opA = opA / opB;
                            result = opA;
                            output = result.ToString();
                        }
                        else output = "-E-";

                        inputA = opA.ToString();
                        opB = 0;
                        inputB = "0";
                        minusB = "";

                        isDecimalB = false;
                    }
                    else operationDone = false;
                    if (output != "-E-")
                    {
                        result = round(result);
                        output = result.ToString();

                    }
                    //output = result.ToString();
                    if (result > 9999999999 && decimalCheck(output))
                    {
                        output = "-E-";
                    }

                    //operation = key; unsafe
                    numberIsPressed = false;

                }

            }



        }

        public string GetCurrentDisplayState()
        {
            return output;
        }
    }


}

