﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string displayValue;
        private string tempDisplayValue; //when using combination of binary and unary operators
        private string savedValue; //when user enters 'P' or 'G'
        private string numberString = "0123456789"; //allowed numbers
        private string binaryOperatorString = "+-*/"; //allowed binary operations
        private string unaryOperatorString = "SKTQRI"; //allowed unary operations
        private string otherOperations = "PGCOM,"; //other allowed commands
        private bool startFlag = true; //starting flag
        private bool errorFlag = false; //flag to notify when error accures
        private List<double> numbersList = new List<double>(); //list of numbers to calculate
        private List<char> operatorList = new List<char>(); //list of operations to execute
        private char previousDigit; //to remenber the previous digit


        public Kalkulator()
        {
            displayValue = "0";
        }

        /// <summary>
        /// Method for entering Digits into the calculator
        /// </summary>
        /// <param name="inPressedDigit"></param>
        public void Press(char inPressedDigit)
        {
            if (numberString.Contains(inPressedDigit) || binaryOperatorString.Contains(inPressedDigit)
                || unaryOperatorString.Contains(inPressedDigit) || otherOperations.Contains(inPressedDigit) || inPressedDigit == '=') //check for illegal sign
            {

                if (inPressedDigit == 'O') //reset calculator
                {
                    displayValue = "0";
                    savedValue = "";
                    numbersList.RemoveRange(0, numbersList.Count);
                    operatorList.RemoveRange(0, operatorList.Count);
                    previousDigit = inPressedDigit;
                }

                else if (inPressedDigit == 'P') //saving value in memory
                {
                    savedValue = displayValue;
                }

                else if (inPressedDigit == 'G') //retriving the saved value back to the display
                {
                    if (savedValue.Length != 0) //if no values was saved then report error
                    {
                        displayValue = savedValue;
                        startFlag = false;
                        previousDigit = inPressedDigit;
                    }

                }

                else if (inPressedDigit == 'C')
                {
                    //clean screen
                    displayValue = "0";
                    startFlag = true;
                }

                else if (startFlag && inPressedDigit == '0') //entering 0 at the begining
                {
                    displayValue = "0";
                    previousDigit = inPressedDigit;
                }

                else if (startFlag && (inPressedDigit == ',' || numberString.Contains(inPressedDigit)))  //initial check for 0 and change for new digid
                {
                    if (inPressedDigit != ',')
                    {
                        displayValue = "";
                    }
                    displayValue += inPressedDigit;
                    startFlag = false;
                    previousDigit = inPressedDigit;
                }

                else if (inPressedDigit == 'M')
                {
                    if (displayValue[0] != '-')
                    {
                        displayValue = '-' + displayValue;
                    }
                    else
                    {
                        displayValue = displayValue.Substring(1, displayValue.Length - 1);
                    }
                }

                else if (inPressedDigit == ',')
                {
                    if (!displayValue.Contains(',')) //for multiple ',' press
                    {
                        displayValue += inPressedDigit;
                    }

                }
                //Binary operation handle
                else if (binaryOperatorString.Contains(inPressedDigit))
                {

                    try
                    {
                        if (binaryOperatorString.Contains(previousDigit)) //if more binary operators come in a  row
                        {
                            operatorList.RemoveAt(operatorList.Count - 1);
                        }
                        else
                        {
                            tempDisplayValue = displayValue;
                            double tempNumber = Convert.ToDouble(displayValue);
                            numbersList.Add(tempNumber);
                        }

                        operatorList.Add(inPressedDigit);

                        previousDigit = inPressedDigit; //for now not needed because of displav length

                        displayValue = "";
                        startFlag = true;

                    }
                    catch (FormatException e)
                    {
                        errorFlag = true;
                    }

                }
                //Unary operation handle
                else if (unaryOperatorString.Contains(inPressedDigit)) //if an unary operation is entered
                {

                    try
                    {
                        double tempNumber;
                        if (displayValue.Length == 0)  //used when before unary operator a binary operator was pressed
                        {
                            tempNumber = Convert.ToDouble(tempDisplayValue);
                        }
                        else
                        {
                            tempNumber = Convert.ToDouble(displayValue);
                        }

                        if (inPressedDigit == 'S')
                        {
                            tempNumber = Math.Sin(tempNumber);
                        }
                        else if (inPressedDigit == 'K')
                        {
                            tempNumber = Math.Cos(tempNumber);
                        }
                        else if (inPressedDigit == 'T')
                        {
                            tempNumber = Math.Tan(tempNumber);
                        }
                        else if (inPressedDigit == 'Q')
                        {
                            tempNumber = Math.Pow(tempNumber, 2);
                        }
                        else if (inPressedDigit == 'R')
                        {
                            tempNumber = Math.Sqrt(tempNumber);
                        }
                        else
                        {
                            tempNumber = 1 / tempNumber;
                        }

                        try
                        {
                            checkNumber(tempNumber);
                            if (displayValue.Length == 0)
                            {
                                tempDisplayValue = specificRound(tempNumber);  //convert number back to string for display
                                if (tempDisplayValue == "0") { startFlag = true; }
                                else { startFlag = false; }
                            }
                            else
                            {
                                displayValue = specificRound(tempNumber);
                                if (displayValue == "0") { startFlag = true; }
                                else { startFlag = false; }
                            }
                        }
                        catch (InvalidOperationException e)
                        {
                            errorFlag = true;
                        }

                    }
                    catch (FormatException e)
                    {
                        errorFlag = true;
                    }

                }

                else if (inPressedDigit == '=')
                {
                    if (previousDigit != '=') //check for multiple entries of '=' in a row
                    {
                        if (numbersList.Count != 0) //check if there are any numbers to calculate
                        {

                            double firstOperator, secondOperator;
                            double result = 0;

                            try
                            {

                                if (displayValue.Length != 0) //for the combination {number}{operator}'='
                                {
                                    double lastOperator = Convert.ToDouble(displayValue);
                                    numbersList.Add(lastOperator);
                                }

                                while (operatorList.Count != 0)
                                {
                                    firstOperator = numbersList.ElementAt(0);
                                    if (numbersList.Count != 1) //for the combination {number}{operator}'='
                                    {
                                        secondOperator = numbersList.ElementAt(1);
                                    }
                                    else
                                    {
                                        secondOperator = firstOperator;
                                    }

                                    //executing operators from operators list
                                    if (operatorList.ElementAt(0) == '+')
                                    {
                                        result = firstOperator + secondOperator;
                                    }
                                    else if (operatorList.ElementAt(0) == '-')
                                    {
                                        result = firstOperator - secondOperator;
                                    }
                                    else if (operatorList.ElementAt(0) == '*')
                                    {
                                        result = firstOperator * secondOperator;
                                    }
                                    else if (operatorList.ElementAt(0) == '/')
                                    {
                                        result = firstOperator / secondOperator;
                                    }

                                    try
                                    {
                                        checkNumber(result); //check the result
                                    }
                                    catch (InvalidOperationException e)
                                    {
                                        errorFlag = true;
                                        result = 0;
                                    }

                                    numbersList.RemoveAt(0); //removing the used number

                                    if (numbersList.Count != 0) //for the combination {number}{operator}'='
                                    {
                                        numbersList.RemoveAt(0);
                                    }

                                    operatorList.RemoveAt(0); //removing the executed operator


                                    numbersList.Insert(0, result); //storing the result to be used in the other operation

                                } //end of while 

                                previousDigit = inPressedDigit;
                                displayValue = specificRound(numbersList.ElementAt(0));
                            }
                            catch (FormatException e)
                            {
                                errorFlag = true;
                            }
                        }
                    }
                }

                else
                {
                    if ((displayValue.Length < 10 && !displayValue.Contains(',') && !displayValue.Contains('-'))  //check if the dsplay is full
                        || (displayValue.Length < 11 && (displayValue.Contains(',') || displayValue.Contains('-')))
                        || (displayValue.Length < 12 && displayValue.Contains(',') && displayValue.Contains('-')))
                    {
                        previousDigit = inPressedDigit;
                        displayValue += inPressedDigit;
                    }
                }
            }

        }

        /// <summary>
        /// Method for getting the display
        /// </summary>
        /// <returns>the display value</returns>
        public string GetCurrentDisplayState()
        {

            if (!errorFlag) //if no errors
            {
                double tempNumber;
                if (displayValue.Length != 0)
                {
                    tempNumber = Convert.ToDouble(displayValue);
                }
                else { tempNumber = Convert.ToDouble(tempDisplayValue); }
                return Convert.ToString(tempNumber);
            }
            else
            {
                return "-E-";
            }

        }

        /// <summary>
        /// Method for rounding numbers to fit display
        /// </summary>
        /// <param name="temp">the number that needs to be rounded</param>
        /// <returns>the rounded number as a string</returns>
        public string specificRound(double temp)
        {
            string tempString = Convert.ToString(temp);
            int index;
            if ((tempString.IndexOf(',') > 11 && tempString.Contains('-'))
                || (tempString.IndexOf(',') > 10 && !tempString.Contains('-'))
                || (!tempString.Contains(',') && !tempString.Contains('-') && tempString.Length > 10)
                || (!tempString.Contains(',') && tempString.Contains('-') && tempString.Length > 11))
            {
                errorFlag = true;
                return displayValue;
            }
            else
            {
                if (tempString.Contains('-') && tempString.Contains(','))
                {
                    index = tempString.IndexOf(',');
                    return Convert.ToString(Math.Round(temp, 11 - index));
                }
                else if (!tempString.Contains('-') && tempString.Contains(','))
                {
                    index = tempString.IndexOf(',');
                    return Convert.ToString(Math.Round(temp, 10 - index));
                }
                else
                    return Convert.ToString(temp);
            }
        }

        /// <summary>
        /// Method for checking if the number is valid
        /// </summary>
        /// <param name="num">the number that needs to be checked</param>
        public void checkNumber(double num)
        {
            if (Double.IsNaN(num) || Double.IsInfinity(num))
                throw new System.InvalidOperationException("the result is not a real number");
        }

    }

}

