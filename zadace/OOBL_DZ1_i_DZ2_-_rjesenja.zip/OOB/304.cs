﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         #region fields

         private StockKeeper stocks;
         private IndexKeeper indexes;
         private PortfoliosKeeper portfolios;

         #endregion

         #region ctor

         public StockExchange(){
             this.stocks = new StockKeeper();
             this.indexes = new IndexKeeper();
             this.portfolios = new PortfoliosKeeper();
         }

         #endregion

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stock = new Stock(inStockName, inNumberOfShares);
             stock.addStockValue(new StockValue(inInitialPrice, inTimeStamp));
             stocks.addStock(stock);
         }

         public void DelistStock(string inStockName)
         {
             Stock s = stocks[inStockName];

             foreach(KeyValuePair<String, Portfolio> p in portfolios.all){
                 if(p.Value.containsStock(s)) p.Value.removeStock(s);
             }

             stocks.removeStockWithName(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             return stocks.hasStockWithName(inStockName);
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             StockValue value = new StockValue(inStockValue, inIimeStamp);
             stocks[inStockName].addStockValue(value);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return stocks[inStockName].getValueForTime(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return stocks[inStockName].getInitialValue();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return stocks[inStockName].getLastValue();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             this.indexes[inIndexName] = new Index(inIndexName, inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             this.indexes[inIndexName].addStock(this.stocks[inStockName]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             this.indexes[inIndexName].removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return this.indexes[inIndexName].containsStock(this.stocks[inStockName].Name);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return this.indexes[inIndexName].getValueForTime(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return this.indexes.containsIndex(inIndexName);
         }

         public int NumberOfIndices()
         {
             return this.indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return this.indexes[inIndexName].StockCount;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             this.portfolios[inPortfolioID] = new Portfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             this.portfolios[inPortfolioID].addSharesToStock(this.stocks[inStockName], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             this.portfolios[inPortfolioID].removeSharesFromStock(this.stocks[inStockName], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             this.portfolios[inPortfolioID].removeStock(this.stocks[inStockName]);
         }

         public int NumberOfPortfolios()
         {
             return this.portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return this.portfolios[inPortfolioID].StockCount;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this.portfolios.containsPortfolio(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return this.portfolios[inPortfolioID].containsStock(this.stocks[inStockName]);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return this.portfolios[inPortfolioID].getSharesForStock(this.stocks[inStockName]);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return this.portfolios[inPortfolioID].getValueForTime(timeStamp, stocks);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return this.portfolios[inPortfolioID].getMonthlyChange(Year, Month, stocks);
         }
     }

     #region stocks

     public class StockKeeper
     {
         #region fields

         private Dictionary<String, Stock> stocks;

         public int Count
         {
             get { return stocks.Count; }
         }

         public Stock this[String name]
         {
             get 
             {
                if(!stocks.ContainsKey(name.ToLower())) throw new StockExchangeException("Stock does not exist!");
                 return stocks[name.ToLower()];
             }
         }

         #endregion

         #region ctor

         public StockKeeper()
         {
             this.stocks = new Dictionary<string, Stock>();
         }

         #endregion

         #region methods

         public bool hasStockWithName(String name)
         {
             return stocks.ContainsKey(name.ToLower());
         }

         public void addStock(Stock stock)
         {
            if(stocks.ContainsKey(stock.Name.ToLower())) throw new StockExchangeException("Stock already existing!");
            stocks.Add(stock.Name.ToLower(), stock);
         }

         public void removeStockWithName(String name)
         {
             if(!stocks.ContainsKey(name.ToLower())) throw new StockExchangeException("Cannot remove stock if it does not exist!");
             this.stocks.Remove(name.ToLower());
         }

         #endregion

     }

     public class Stock
     {
         #region fields

         private String _name;

         public String Name
         {
             get { return _name; }
         }

         private long _numberOfStocks;

         public long NumberOfStocks
         {
             get { return _numberOfStocks; }
         }

         private List<StockValue> stockValues;

        #endregion

         #region ctor

         public Stock(String name, long numberOfShares)
         {
             if(name == null || name.Equals("") || numberOfShares<=0) throw new StockExchangeException("Invalid stock!");
             this._numberOfStocks = numberOfShares;
             this._name = name;
             this.stockValues = new List<StockValue>();
         }

         #endregion

         #region methods

         public void addStockValue(StockValue value)
         {
             foreach(StockValue sv in this.stockValues){
                 if(sv.ValidFrom.Equals(value.ValidFrom)) throw new StockExchangeException("Value already there");
             }

             stockValues.Add(value);

         }

         public Decimal getValueForTime(DateTime time)
         {

             for (int i = stockValues.Count - 1; i >= 0; i-- )
             {
                 if(stockValues[i].ValidFrom.Subtract(time).TotalMilliseconds <= 0) return stockValues[i].Value;
             }

             //stock wasn't created than
             throw new StockExchangeException("Stock value not available for given time!");
         }

         public Decimal getInitialValue()
         {
             if(stockValues.Count == 0) throw new StockExchangeException("Value not initialized!");
             return stockValues[0].Value;
         }

         public Decimal getLastValue()
         {
             if (stockValues.Count == 0) throw new StockExchangeException("Value not initialized!");
             return stockValues[stockValues.Count-1].Value;
         }

         #endregion
     }

     public class StockValue : IComparable<StockValue>
     {
         #region fields

         private Decimal _value;

         public Decimal Value
         {
             get { return _value; }
         }

         private DateTime _validFrom;

         public DateTime ValidFrom
         {
             get { return _validFrom; }
         }

        #endregion

         #region ctor

         public StockValue(Decimal value, DateTime validTo)
         {
             if(value.CompareTo(new Decimal(0)) <= 0) throw new StockExchangeException("Stock value cannot be less or equal to zero!");
             this._value = value;
             this._validFrom = validTo;
         }

        #endregion



         #region IComparable<StockValue> Members

         public int CompareTo(StockValue other)
         {
             return (int)this.ValidFrom.Subtract(other.ValidFrom).TotalMilliseconds;
         }

         #endregion
     }

    #endregion

    #region index

     public class Index
     {

         private String _name;

         public String Name
         {
             get { return _name; }
         }

         private IndexTypes _type;

         private Dictionary<String, Stock> stocks;

         public Index(String name, IndexTypes type)
         {
             this._name = name;
             this._type = type;
             this.stocks = new Dictionary<string, Stock>();
         }

         public decimal getValueForTime(DateTime time)
         {
             //avoid division by zero
             if(stocks.Count==0) return 0;

             if (this._type == IndexTypes.AVERAGE)
             {

                 decimal sum = 0;

                 foreach (Stock stock in this.stocks.Values)
                 {
                     sum += stock.getValueForTime(time);
                 }

                 sum /= stocks.Count;

                 sum = Decimal.Round(sum, 3);

                 return sum;
             }
             else
             {

                 decimal indexSumValue = 0.0m;
                 foreach (Stock stock in this.stocks.Values)
                 {
                     indexSumValue += stock.getValueForTime(time) * stock.NumberOfStocks;
                 }
                 decimal sum = 0.0m;
                 foreach (Stock stock in this.stocks.Values)
                 {
                     decimal factor = (stock.getValueForTime(time) * stock.NumberOfStocks) / indexSumValue;
                     sum += stock.getValueForTime(time) * factor;
                 }
                 return Decimal.Round(sum, 3);
             }

             throw new StockExchangeException("Type ivalid");
         }

         public void addStock(Stock stock)
         {
             if(stocks.ContainsKey(stock.Name)) throw new StockExchangeException("Stock already in index!");

             this.stocks.Add(stock.Name, stock);

         }

         public void removeStock(string stockName)
         {
             this.stocks.Remove(stockName);
         }

         public bool containsStock(string stockName)
         {
             return this.stocks.ContainsKey(stockName);
         }

         public int StockCount
         {
             get{return this.stocks.Count;}
         }
     }

     public class IndexKeeper
     {

         private Dictionary<String, Index> indexes;

         public IndexKeeper()
         {
             this.indexes = new Dictionary<string, Index>();
         }

         public int Count
         {
             get { return this.indexes.Count; }
         }

         public bool containsIndex(String name)
         {
             return this.indexes.ContainsKey(name.ToLower());
         }

         public Index this[String name]{

             get 
             { 
                if(!this.indexes.ContainsKey(name.ToLower())) throw new StockExchangeException("Index does not exist");
                 return this.indexes[name.ToLower()];
             }

             set
             {
                 if(this.indexes.ContainsKey(value.Name.ToLower())) throw new StockExchangeException("Index already exists!");
                 this.indexes.Add(value.Name.ToLower(), value);
             }
            }


     }

#endregion

    #region protfolios

     public class Portfolio
     {
         private string _id;

         private Dictionary<String, PortfolioValue> values;

         public string ID
         {
             get { return _id; }
         }

         public Portfolio(string id)
         {
             this._id = id;
             this.values = new Dictionary<String, PortfolioValue>();
         }

         public int StockCount
         {
             get { return this.values.Count; }
         }

         public bool containsStock(Stock stock)
         {
             return this.values.ContainsKey(stock.Name);
         }

         public void removeSharesFromStock(Stock stock, int number)
         {
             if(!this.values.ContainsKey(stock.Name)) throw new StockExchangeException("Cannot remove if no stock");

             PortfolioValue value = this.values[stock.Name];

             if(value.Number - number < 0){
                 throw new StockExchangeException("Manje od nula");
             }

             if (value.Number == number)
             {
                 this.values.Remove(stock.Name);
             }
             else
             {
                 value.Number = value.Number - number;
             }

         }

         public void removeStock(Stock stock)
         {
             if (!this.values.ContainsKey(stock.Name)) throw new StockExchangeException("Cannot remove if no stock");
             this.values.Remove(stock.Name);
         }

         public void addSharesToStock(Stock stock, int number)
         {
             if(number<=0) throw new StockExchangeException("Cannot add lessorequal zero");
             //assumes it's good
             if (!this.values.ContainsKey(stock.Name))
             {
                 this.values.Add(stock.Name, new PortfolioValue(stock, number));
             }
             else
             {
                 this.values[stock.Name].Number = this.values[stock.Name].Number + number;
             }
         }

         public int getSharesForStock(Stock stock)
         {
             if(!this.values.ContainsKey(stock.Name)) return 0;
             return this.values[stock.Name].Number;
         }

         public decimal getValueForTime(DateTime time, StockKeeper keeper)
         {
             decimal value = 0;

             foreach(KeyValuePair<String, PortfolioValue> current in this.values){
                 value += keeper[current.Key].getValueForTime(time) * current.Value.Number;
             }

             return value;
         }

         public decimal getMonthlyChange(int year, int month, StockKeeper keeper)
         {
             //radim ovo s keeperom jer me mrsko singletona sad pisat :D
             
             DateTime start = new DateTime(year, month,1,0,0,0,0);
                 DateTime end = new DateTime(year, month, 1,0,0,0,0).AddMonths(1).Subtract(new TimeSpan(0, 0, 0, 0, 1));

                 decimal startValue = getValueForTime(start, keeper);
                 decimal endValue = getValueForTime(end, keeper);

                 decimal dividor = startValue;
                 if (dividor == 0) dividor = 1;

                 return Decimal.Round(Math.Abs(startValue - endValue)/dividor * 100, 3);

         }
     }

     public class PortfolioValue
     {

         private Stock _stock;
         public Stock Stock
         {
             get { return _stock; }
         }

         private int _number;
         public int Number
         {
             get { return this._number; }
             set { this._number = value; }
         }

         public PortfolioValue(Stock stock, int number)
         {
             this._stock = stock;
             this._number = number;
         }


     }

     public class PortfoliosKeeper
     {
         private Dictionary<string, Portfolio> portfolios;

         public PortfoliosKeeper()
         {
             this.portfolios = new Dictionary<string, Portfolio>();
         }

         public int Count
         {
             get { return this.portfolios.Count; }
         }

         public Dictionary<string, Portfolio> all
         {
             get {return this.portfolios ;}
         }

         public Portfolio this[String id]
         {
             get
             {
                    if(!this.portfolios.ContainsKey(id)) throw new StockExchangeException("Nema portfolia");
                    return this.portfolios[id];
             }

             set
             {
                 if(this.portfolios.ContainsKey(id)) throw new StockExchangeException("Vec je tu");
                 this.portfolios[id] = value;
             }
         }

         
         public int getTotalSharesForStock(Stock stock)
         {
             int sum = 0;

             foreach(Portfolio portfolio in this.portfolios.Values){
                 sum += portfolio.getSharesForStock(stock);
             }

             return sum;
         }

         public bool containsPortfolio(String id)
         {
             return this.portfolios.ContainsKey(id);
         }
     }

    #endregion
}
