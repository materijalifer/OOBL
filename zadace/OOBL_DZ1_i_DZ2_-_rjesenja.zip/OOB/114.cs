using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace DrugaDomacaZadaca_Burza
{
	
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// Klasa koja predstavlja dionicu. Sadr�i ime dionice, broj tih dionica, po�etnu 
    /// cijenu, broj prodanih dionica i trenutak od kojeg ta cijena vrijedi.
    public class Dionica
    {
        // Naziv dionice
        public string StockName;

        // Broj dionica
        public long NumberOfShares;

        // Broj prodanih dionica
        public long NumberOfSoldStocks = 0;

        // Vrijednost dionice od odre�enog trenutka
        public Dictionary<DateTime, decimal> timePrice = new Dictionary<DateTime, decimal>();

        /// Konstruktor klase
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inNumberOfShares">Broj dionica</param>
        /// <param name="inInitialPrice">Po�etna cijena dionice</param>
        /// <param name="inTimeStamp">Vrijeme dodavanja dionice</param>
        public Dionica(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockName = inStockName.ToUpper();
            NumberOfShares = inNumberOfShares;
            timePrice.Add(inTimeStamp, inInitialPrice);
        }
    }

    /// Klasa koja predstavlja index. Sadr�i ime indexa, njegov tip i 
    /// mapu dionica vezanih uz taj index.
    public class Index
    {
        // Naziv indexa
        public string nazivIndeksa;

        // Tip indexa - mo�e biti AVERAGE ili WEIGHTED
        public IndexTypes tip;

        // Mapa dionica uz index
        public SortedDictionary<string, Dionica> listaDionica = new SortedDictionary<string, Dionica>();

        /// Konstruktor klase
        /// <param name="inIndexName">Naziv indexa</param>
        /// <param name="inIndexType">Tip indeksa</param>
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            nazivIndeksa = inIndexName.ToUpper();
            tip = inIndexType;
        }

    }

    /// Klasa koja predstavlja portfolio. Sadr�i id portfolia i 
    /// mapu koja sadr�i naziv dionice kao klju�, a vrijednost je
    /// broj prodanih dionica.
    public class Portfolio
    {
        // ID portfolia
        public string ID;

        // Mapa koja sadr�i broj prodanih dionica
        public Dictionary<string, int> dionice = new Dictionary<string, int>();

        /// Konstruktor klase
        /// <param name="PortfolioID">ID portfolia</param>
        public Portfolio(string PortfolioID)
        {
            ID = PortfolioID;
        }
    }

    public class StockExchange : IStockExchange
    {
        // Mapa u koju se spremaju dionice
        Dictionary<string, Dionica> listaDionica = new Dictionary<string, Dionica>();

        // Mapa u koju se spremaju indexi
        Dictionary<string, Index> listaIndexa = new Dictionary<string, Index>();

        // Mapa u koju se spremaju portfoliji
        Dictionary<string, Portfolio> listaPortfolia = new Dictionary<string, Portfolio>();

        /// <summary>
        /// Dodaje dionicu s po�etnom cijenom na burzu
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inNumberOfShares">Broj dionica</param>
        /// <param name="inInitialPrice">Po�etna cijena dionice</param>
        /// <param name="inTimeStamp">Trenutak dodavanja dionice</param>
        /// <throws>StockExcangeException</throws>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ve� postoji.");
            }
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena dionice mora biti pozitivna.");
            }
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica mora biti pozitivan.");
            }

            listaDionica.Add(inStockName.ToUpper(), new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        /// <summary>
        /// Bri�e dionicu s burze
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <throws>StockExcangeException</throws>
        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            foreach (KeyValuePair<string, Index> kvp in listaIndexa)
            {
                if (kvp.Value.listaDionica.ContainsKey(inStockName.ToUpper()))
                {
                    RemoveStockFromIndex(kvp.Key, inStockName);
                }
            }

            foreach (KeyValuePair<string, Portfolio> kvp in listaPortfolia)
            {
                if (kvp.Value.dionice.ContainsKey(inStockName.ToUpper()))
                {
                    kvp.Value.dionice.Remove(inStockName.ToUpper());
                }
            }

            listaDionica.Remove(inStockName.ToUpper());
        }

        /// <summary>
        /// Provjerava postoji li tra�ena dionica na burzi
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>True ako dionica postoji na burzi, ina�e false</returns>
        /// <throws>StockExcangeException</throws>
        public bool StockExists(string inStockName)
        {
            if (listaDionica.ContainsKey(inStockName.ToUpper()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Vra�a broj dionica na burzi
        /// </summary>
        /// <returns>Broj dionica</returns>
        public int NumberOfStocks()
        {
            return listaDionica.Count;
        }

        /// <summary>
        /// Postavlja cijenu dionice za odre�eno vrijeme
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inTimeStamp">Trenutak od kad vrijedi cijena dionice</param>
        /// <param name="inStockValue">Nova cijena dionice</param>
        /// <throws>StockExcangeException</throws>
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }
            if (inStockValue < 0)
            {
                throw new StockExchangeException("Cijena dionice mora biti pozitivna.");
            }

            Dionica d = listaDionica[inStockName.ToUpper()];
            d.timePrice.Add(inTimeStamp, inStockValue);
            listaDionica[inStockName.ToUpper()] = d;

        }

        /// <summary>
        /// Dohva�a cijenu dionice za neko vrijeme
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inTimeStamp">Vrijeme za koje se �eli znati cijena dionice</param>
        /// <returns>Cijena dionice</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            decimal price = -1;
            foreach (KeyValuePair<DateTime, decimal> kvp in listaDionica[inStockName.ToUpper()].timePrice)
            {
                if (kvp.Key <= inTimeStamp)
                {
                    price = kvp.Value;
                }
                else
                {
                    break;
                }
            }

            if (price < 0)
            {
                throw new StockExchangeException("Vrijednost dionice u danom trenutku nije definirana.");
            }
            else
            {
                return price;
            }
        }

        /// <summary>
        /// Dohva�a po�etnu cijenu dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Po�etna cijena dionice</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            return listaDionica[inStockName.ToUpper()].timePrice.First().Value;
        }

        /// <summary>
        /// Dohva�a zadnju cijenu dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Zadnja cijena dionice</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            return listaDionica[inStockName.ToUpper()].timePrice.Last().Value;
        }

        /// <summary>
        /// Stvara novi indeks na burzi
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inIndexType">Tip indeksa</param>
        /// <throws>StockExcangeException</throws>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa tim imenom vec postoji.");
            }

            listaIndexa.Add(inIndexName.ToUpper(), new Index(inIndexName, inIndexType));
        }

        /// <summary>
        /// Dodaje dionicu u indeks
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <throws>StockExcangeException</throws>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index s tim imenom ne postoji.");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            Index i = listaIndexa[inIndexName.ToUpper()];
            Dionica d = listaDionica[inStockName.ToUpper()];
            i.listaDionica.Add(inStockName.ToUpper(), d);
        }

        /// <summary>
        /// Bri�e dionicu iz indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <throws>StockExcangeException</throws>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa tim imenom ne postoji.");
            }

            Index i = listaIndexa[inIndexName.ToUpper()];
            if (i.listaDionica.ContainsKey(inStockName.ToUpper()))
            {
                i.listaDionica.Remove(inStockName.ToUpper());
            }
        }

        /// <summary>
        /// Provjerava je li dionica u indeksu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>True ako se dionica nalazi u indeksu, ina�e false</returns>
        /// <throws>StockExcangeException</throws>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa tim imenom ne postoji.");
            }

            Index i = listaIndexa[inIndexName.ToUpper()];
            if (i.listaDionica.ContainsKey(inStockName.ToUpper()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Dohva�a vrijednost indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inTimeStamp">Trenutak za koji se gleda vrijednost</param>
        /// <returns>Vrijednost indeksa ovisno o njegovom tipu</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa tim imenom ne postoji.");
            }

            Index i = listaIndexa[inIndexName.ToUpper()];
            decimal suma = 0;
            decimal broj = 0;

            foreach (KeyValuePair<string, Dionica> kvp in i.listaDionica)
            {
                Dionica d = kvp.Value;
                decimal price = 0;

                foreach (KeyValuePair<DateTime, decimal> kv in d.timePrice)
                {
                    if (kv.Key < inTimeStamp)
                    {
                        price = kv.Value;
                    }
                    else
                    {
                        break;
                    }
                }

                if (i.tip == IndexTypes.AVERAGE)
                {
                    suma += price * d.NumberOfShares;
                    broj += d.NumberOfShares;
                }
                else if (i.tip == IndexTypes.WEIGHTED)
                {
                    broj += price * d.NumberOfShares;
                    suma += price * price * d.NumberOfShares;
                }
            }

            return RoundDouble(suma / broj);
        }

        /// <summary>
        /// Provjerava postoji li tra�eni indeks na burzi
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <returns>True ako postoji indeks na burzi, ina�e false</returns>
        /// <throws>StockExcangeException</throws>
        public bool IndexExists(string inIndexName)
        {
            if (listaIndexa.ContainsKey(inIndexName.ToUpper()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Dohva�a broj indeksa na burzi
        /// </summary>
        /// <returns>Broj indeksa na burzi</returns>
        public int NumberOfIndices()
        {
            return listaIndexa.Count;
        }

        /// <summary>
        /// Dohva�a broj dionica u tra�enom indeksu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <returns>Broj dionica u indeksu</returns>
        /// <throws>StockExcangeException</throws>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index sa tim imenom ne postoji.");
            }

            Index i = listaIndexa[inIndexName.ToUpper()];

            return i.listaDionica.Count;
        }

        /// <summary>
        /// Stvara novi portfolio na burzi
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <throws>StockExcangeException</throws>
        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio sa tim ID-jem vec postoji.");
            }
            listaPortfolia.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }

        /// <summary>
        /// Dodaje odre�eni broj dionica u portfolio 
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="numberOfShares">Broj dionica u portfoliu</param>
        /// <throws>StockExcangeException</throws>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom.");
            }

            if ((listaDionica[inStockName.ToUpper()].NumberOfShares - 
                listaDionica[inStockName.ToUpper()].NumberOfSoldStocks) < numberOfShares)
            {
                throw new StockExchangeException("Ne mo�e se dodati zadani broj dionica jer ih nema toliko.");
            }

            Portfolio p = listaPortfolia[inPortfolioID];
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                int broj = p.dionice[inStockName.ToUpper()];
                broj += numberOfShares;
                p.dionice[inStockName] = broj;
            }
            else
            {
                listaPortfolia[inPortfolioID].dionice.Add(inStockName.ToUpper(), numberOfShares);
            }

            listaDionica[inStockName.ToUpper()].NumberOfSoldStocks += numberOfShares;
        }

        /// <summary>
        /// Uklanja odre�eni broj dionica iz portfolija 
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="numberOfShares">Broj dionica za ukloniti</param>
        /// <throws>StockExcangeException</throws>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }

            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                Portfolio p = listaPortfolia[inPortfolioID];
                int broj = p.dionice[inStockName.ToUpper()];
                broj -= numberOfShares;
                listaDionica[inStockName.ToUpper()].NumberOfSoldStocks -= numberOfShares;

                if (broj <= 0)
                {
                    p.dionice.Remove(inStockName.ToUpper());
                }
                else
                {
                    p.dionice[inStockName.ToUpper()] = broj;
                }

                if (listaDionica[inStockName.ToUpper()].NumberOfSoldStocks < 0)
                {
                    listaDionica[inStockName.ToUpper()].NumberOfSoldStocks = 0;
                }
            }
            else
            {
                throw new StockExchangeException("Dionica se ne nalazi u navedenom portfoliu.");
            }
        }

        /// <summary>
        /// Bri�e dionicu iz portfolia
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <throws>StockExcangeException</throws>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }
            Portfolio p = listaPortfolia[inPortfolioID];
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                p.dionice.Remove(inStockName.ToUpper());
            }
        }

        /// <summary>
        /// Dohva�a broj portfolija na burzi
        /// </summary>
        /// <returns>Broj portfolija</returns>
        public int NumberOfPortfolios()
        {
            return listaPortfolia.Count;
        }

        /// <summary>
        /// Dohva�a broj dionica u tra�enom portfoliju
        /// </summary>
        /// <param name="inPortfolioID">ID portfolija</param>
        /// <returns>Broj dionica u portfoliu</returns>
        /// <throws>StockExcangeException</throws>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }
            return listaPortfolia[inPortfolioID].dionice.Count;
        }

        /// <summary>
        /// Provjerava postoji li tra�eni portfolio na burzi
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <returns>True ako tra�eni portfolio postoji, ina�e false</returns>
        /// <throws>StockExcangeException</throws>
        public bool PortfolioExists(string inPortfolioID)
        {
            if (listaPortfolia.ContainsKey(inPortfolioID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Provjerava nalazi li se dionica u portfoliju
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>True ako se dionica nalazi u portfoliu, ina�e false</returns>
        /// <throws>StockExcangeException</throws>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }

            Portfolio p = listaPortfolia[inPortfolioID];
            if (p.dionice.ContainsKey(inStockName.ToUpper()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Dohva�a broj dionice u tra�enom portfoliju
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Broj dionice</returns>
        /// <throws>StockExcangeException</throws>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }

            Portfolio p = listaPortfolia[inPortfolioID];
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Dionica se ne nalazi u portfoliu.");
            }
            else
            {
                return p.dionice[inStockName.ToUpper()];
            }
        }

        /// <summary>
        /// Dohva�a vrijednost portfolija u odre�enom trenutku
        /// </summary>
        /// <param name="inPortfolioID">ID portfolia</param>
        /// <param name="timeStamp">Odabrani trenutak</param>
        /// <returns>Vrijednost portfolia</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }

            Portfolio p = listaPortfolia[inPortfolioID];
            decimal vrijednost = 0;
            foreach (KeyValuePair<string, int> kvp in p.dionice)
            {
                decimal price = 0;

                foreach (KeyValuePair<DateTime, decimal> kv in listaDionica[kvp.Key].timePrice)
                {
                    if (kv.Key < timeStamp)
                    {
                        price = kv.Value;
                    }
                    else
                    {
                        break;
                    }
                }
                vrijednost += (price * kvp.Value);
            }

            return RoundDouble(vrijednost);
        }

        /// <summary>
        /// Dohva�a mjese�nu promjenu vrijednosti portfolija
        /// </summary>
        /// <param name="inPortfolioID"></param>
        /// <param name="Year">Godina za koju se tra�i promjena vrijednosti portfolija</param>
        /// <param name="Month">Mjesec za koji se tra�i promjena vrijednosti portfolija</param>
        /// <returns>Promjena vrijednosti u postotcima</returns>
        /// <throws>StockExcangeException</throws>
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio ne postoji.");
            }
            Portfolio p = listaPortfolia[inPortfolioID];
            decimal vrijednost = 0, pocetnaCijena, konacnaCijena;
            pocetnaCijena = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0));
            konacnaCijena = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            vrijednost = ((konacnaCijena - pocetnaCijena) / pocetnaCijena) * 100;

            return RoundDouble(vrijednost);
        }

        /// <summary>
        /// Zaokru�uje broj tako da decimalni dio ima 3 znamenke
        /// </summary>
        /// <param name="broj">Broj koji treba zaokru�iti</param>
        /// <returns>zaokru�eni broj na tri decimale</returns>
        private static decimal RoundDouble(decimal broj)
        {
            int brojac = 0;
            long pom = (long)Math.Abs(broj);

            do
            {
                brojac++;
                pom /= 10;
            }
            while (pom > 0);

            return Math.Round(broj, brojac + 3);
        }
    }
}
