using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kalkulator_OO
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        #region operacije
        enum Znakovi
        {
            zarez = ',',
            predznak = 'M',
            sinus = 'S',
            kosinus = 'K',
            tanges = 'T',
            jednako = '=',
            brisanje = 'C',
            reset = 'O',
            memorija = 'P',
            getMem = 'G',
            korijen = 'R',
            kvadrat = 'Q',
            inverz = 'I',
            plus = '+',
            minus = '-',
            puta = '*',
            dijeljenje = '/',
            bezOperacije = '?'
        };

        enum ZadnjaOperacija
        {
            binarniOperator,
            broj,
            rezultat,
            unarniOperator
        };
        #endregion

        #region polja
        private string prviBroj = Basic;
        private string secOper = Basic;
        private string display = Basic;
        private string memory = Basic;

        private bool error = false;

        private char operation = (char)Znakovi.bezOperacije;
        private ZadnjaOperacija znak = ZadnjaOperacija.broj;
        #endregion

        const string Greska = "-E-";
        const string Basic = "0";

        #region zadane funkcije
        public void Press (char press)
        {
            if (error)
            {
                switch (press)
                {
                    case (char)Znakovi.brisanje:Clear();
                        break;
                    case (char)Znakovi.reset:Reset();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (press)
                {
                    case (char)Znakovi.plus: Plus();
                        break;
                    case (char)Znakovi.minus: Minus();
                        break;
                    case (char)Znakovi.puta: Puta();
                        break;
                    case (char)Znakovi.dijeljenje : Dijeljenje();
                        break;
                    case (char)Znakovi.predznak: Predznak();
                        break;
                    case (char)Znakovi.sinus: Sinus();
                        break;
                    case (char)Znakovi.kosinus: Cosinus();
                        break;
                    case (char)Znakovi.tanges: Tanges();
                        break;
                    case (char)Znakovi.kvadrat: Kvadrat();
                        break;
                    case (char)Znakovi.korijen: Korijen();
                        break;
                    case (char)Znakovi.inverz: Inverz();
                        break;
                    case (char)Znakovi.memorija: Mem();
                        break;
                    case (char)Znakovi.getMem: GetMem();
                        break;
                    case (char)Znakovi.brisanje: Clear();
                        break;
                    case (char)Znakovi.reset: Reset();
                        break;
                    case (char)Znakovi.jednako: Izracun();
                        break;
                    case (char)Znakovi.zarez: Zarez();
                        break;
                    default:
                        DodavanjeBroja(press);
                        break;
                }

            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }
        #endregion
        
        #region pomocne funkcije
        //brojac 
        private int Brojac()
        {
            int brojac = 0;
            foreach (char i in display)
            {
                if (i >= '0' && i <= '9') { brojac++; }
            }
            return brojac;
        }

       
        //pomocna funkcija za izracun
        private void PomocnaF(char funkcija)
        {
            switch (operation)
            {
                case (char)Znakovi.plus: Zbroji();
                    break;
                case (char)Znakovi.minus: Oduzmi();
                    break;
                case (char)Znakovi.puta: Pomnozi();
                    break;
                case (char)Znakovi.dijeljenje: Podijeli();
                    break;
                case (char)Znakovi.bezOperacije: MaxZnam(double.Parse(display));
                    break;

            }
            operation = funkcija;
            znak = ZadnjaOperacija.binarniOperator;
            prviBroj = display;
        }

        //funkcija koja provjerava je li broj prelazi max znamenki
        private void MaxZnam(double unos)
        {
            int duzinaBroja = Math.Round(Math.Abs(unos), 0).ToString().Length;
            if (duzinaBroja > 10)
            {
                display = Greska;
            }
            display = ((decimal)Math.Round(unos, 10 - duzinaBroja)).ToString();
        }

        private void Zbroji()
        {
            try
            {
                double broj = double.Parse(prviBroj) + double.Parse(display);
                MaxZnam(broj);
            }
            catch
            {
                display = Greska;
                error = true;
            }
        }

        private void Oduzmi()
        {
            try
            {
                double broj = double.Parse(prviBroj) - double.Parse(display);
                MaxZnam(broj);
            }
            catch
            {
                display = Greska;
                error = true;
            }
        }

        private void Podijeli()
        {
            try
            {
                if (display != Basic)
                {
                    double broj = double.Parse(prviBroj) / double.Parse(display);
                    MaxZnam(broj);
                }
                else
                {
                    display = Greska;
                    error = true;
                }
            }
            catch
            {
                display = Greska;
                error = true;
            }
        }

        private void Pomnozi()
        {
            try
            {
                double broj = double.Parse(prviBroj) * double.Parse(display);
                MaxZnam(broj);
            }
            catch
            {
                display = Greska;
                error = true;
            }
        }
        #endregion

        #region ostale funkcije
        //funkcija koja dodaje novi broj na display
        private void DodavanjeBroja(char noviBroj)
        {
            if (znak == ZadnjaOperacija.broj)
            {
                if (Brojac() < 10)
                {
                    display = display + noviBroj;
                    if (!(noviBroj == '0' && display.Contains(',')))
                    {
                        MaxZnam(double.Parse(display));
                    }
                }
            }
            else
            {
                display = "" + noviBroj;
            }

            znak = ZadnjaOperacija.broj;

        }

        //izracun operacija
        private void Izracun()
        {
            if (znak != ZadnjaOperacija.rezultat)
            {
                secOper = display;
            }
            else
            {
                prviBroj = display;
                display = secOper;
            }
            switch (operation)
            {
                case (char)Znakovi.bezOperacije: MaxZnam(double.Parse(display));
                    break;
                case (char)Znakovi.plus: Zbroji();
                    break;
                case (char)Znakovi.minus: Oduzmi();
                    break;
                case (char)Znakovi.puta: Pomnozi();
                    break;
                case (char)Znakovi.dijeljenje: Podijeli();
                    break;
            }
            znak = ZadnjaOperacija.rezultat;
            prviBroj = Basic;
        }

        //dijeljenje
        private void Dijeljenje()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)Znakovi.bezOperacije)
                {
                    PomocnaF((char)Znakovi.dijeljenje);
                }
                else
                {
                    operation = (char)Znakovi.dijeljenje;
                    prviBroj = display;
                    MaxZnam(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)Znakovi.dijeljenje;
                prviBroj = display;
            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)Znakovi.dijeljenje;
            }
            znak = ZadnjaOperacija.binarniOperator;
        }

        //mnozenje
        private void Puta()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)Znakovi.bezOperacije)
                {
                    PomocnaF((char)Znakovi.puta);
                }
                else
                {
                    operation = (char)Znakovi.puta;
                    prviBroj = display;
                    MaxZnam(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)Znakovi.puta;
                prviBroj = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)Znakovi.puta;
            }
            znak = ZadnjaOperacija.binarniOperator;
        }

        //oduzimanje
        private void Minus()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)Znakovi.bezOperacije)
                {
                    PomocnaF((char)Znakovi.minus);
                }
                else
                {
                    operation = (char)Znakovi.minus;
                    prviBroj = display;
                    MaxZnam(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)Znakovi.minus;
                prviBroj = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)Znakovi.minus;
            }
            znak = ZadnjaOperacija.binarniOperator;
        }

        //zbrajanje
        private void Plus()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)Znakovi.bezOperacije)
                {
                    PomocnaF((char)Znakovi.plus);
                }
                else
                {
                    operation = (char)Znakovi.plus;
                    prviBroj = display;
                    MaxZnam(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)Znakovi.plus;
                prviBroj = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)Znakovi.plus;
            }

            znak = ZadnjaOperacija.binarniOperator;
        }

        //resetiranje kalkulatora
        private void Reset()
        {
            display = Basic;
            memory = Basic;
            error = false;

            prviBroj = Basic;
            operation = (char)Znakovi.bezOperacije;
            znak = ZadnjaOperacija.broj;
            secOper = Basic;

        }

        //ciscenje display-a
        private void Clear()
        {
            if (error)
            {
                operation = (char)Znakovi.bezOperacije;
            }
            display = Basic;
            error = false;
            znak = ZadnjaOperacija.broj;

        }

        //racunanje tangensa
        private void Tanges()
        {
            double broj = double.Parse(display);
            broj = Math.Tan(broj);
            MaxZnam(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        //racunanje kosinusa
        private void Cosinus()
        {
            double broj = double.Parse(display);
            broj = Math.Cos(broj);
            MaxZnam(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        //racunanje sinusa
        private void Sinus()
        {
            double broj = double.Parse(display);
            broj = Math.Sin(broj);
            MaxZnam(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        //stavljanje decimalnog zareza
        private void Zarez()
        {
            if (znak == ZadnjaOperacija.broj)
            {
                if (!display.Contains(','))
                {
                    display = display + ',';
                }
            }
            else
            {
                Clear();
                display = display + ',';
            }
            znak = ZadnjaOperacija.broj;
        }

        //promjena predznaka broja
        private void Predznak()
        {

            if (display.Contains('-'))
            {
                display = display.Replace("-", "");
            }
            else
            {
                display = '-' + display;
            }
        }

        //racunanje inverza broja
        private void Inverz()
        {
            if (display == Basic)
            {
                display = Greska;
                error = true;
            }
            else
            {
                double broj = double.Parse(display);
                broj = 1 / broj;
                MaxZnam((double)broj);
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        //racunanje korijena broja
        private void Korijen()
        {
            double broj = double.Parse(display);
            try
            {
                broj = Math.Sqrt(broj);
                MaxZnam(broj);
            }
            catch
            {
                display = Greska;
                error = true;
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        //kvadriranje broja
        private void Kvadrat()
        {
            double broj = double.Parse(display);
            try
            {
                broj = Math.Pow(broj, 2);
                MaxZnam(broj);
            }
            catch
            {
                display = Greska;
                error = true;
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        //ucitavanje broja iz memorije
        private void GetMem()
        {
            display = memory;
            znak = ZadnjaOperacija.unarniOperator;
        }

        //spremanje broja u memoriju
        private void Mem()
        {
            memory = display;
        }
        #endregion
    }
}
