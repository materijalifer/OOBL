﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Factory
	{
		public static ICalculator CreateCalculator()
		{
			// vratiti kalkulator
			return new Kalkulator();
		}
	}

	public class Kalkulator : ICalculator
	{
		public string CalcDisplay { get; private set; }
		public int DigitsCounter { get; private set; }
		public double ActualNumber { get; private set; }
		public string Memory { get; private set; }
		public string FirstOperand { get; private set; }
		public string SecondOperand { get; private set; }
		public string Operator { get; private set; }
		public bool ResetNeeded { get; private set; }
		public string InternalMemory { get; private set; }
		public bool IsInErrorState { get; private set; }
		public int TimesPressedEquals { get; private set; }
		public string OperatorMemory { get; set; }

		public Kalkulator()
		{
			this.Memory = "";
			this.Operator = "";
			this.FirstOperand = "";
			this.SecondOperand = "";
			this.InternalMemory = "";
			this.OperatorMemory = "";
			this.CalcDisplay = "0";
			this.DigitsCounter = 0;
			this.TimesPressedEquals = 0;
			this.IsInErrorState = false;
		}

		Regex regexNumber = new Regex("[0-9]");
		public void Press(char inPressedDigit)
		{
			if (regexNumber.IsMatch(inPressedDigit.ToString()))
			{
				if (IsInErrorState)
				{
					IsInErrorState = false;
					ResetDisplay();
				}
				if (ResetNeeded == true)
				{
					ResetDisplay();
					OperatorMemory = "";
					ResetNeeded = false;
				}
				if (CalcDisplay == "0") CalcDisplay = "";

				if (DigitsCounter < 10)
				{
					CalcDisplay += inPressedDigit;
					ActualNumber = Double.Parse(CalcDisplay);
					DigitsCounter++;
				}
				if (Operator != "")
				{
					SecondOperand = CalcDisplay;
				}
			}
			else if (inPressedDigit == 'C')
			{
				ResetDisplay();
			}

			else if (!IsInErrorState)
			{
				switch (inPressedDigit)
				{
					case 'M':
						ActualNumber = -ActualNumber;
						DisplayNumber();
						break;
					case ',':
						if (CalcDisplay == "") CalcDisplay = "0";
						ResetNeeded = false;
						CalcDisplay += inPressedDigit;
						break;
					case 'O':
						ResetCalc();
						break;
					case 'P':
						Memory = CalcDisplay;
						break;
					case 'G':
						CalcDisplay = Memory;
						break;
					case 'S':
						Sinus();
						break;
					case 'K':
						Cosines();
						break;
					case 'T':
						Tangens();
						break;
					case '-':
						Subtract();
						ResetNeeded = true;
						break;
					case '+':
						Add();
						ResetNeeded = true;
						break;
					case '/':
						Divide();
						ResetNeeded = true;
						break;
					case '*':
						Multiply();
						ResetNeeded = true;
						break;
					case 'Q':
						Square();
						break;
					case 'R':
						Root();
						break;
					case '=':
						TimesPressedEquals++;
						if (TimesPressedEquals > 1)
						{
							SecondOperand = FirstOperand;
						}
						else if (SecondOperand.Equals(String.Empty) && FirstOperand != "")
						{
							SecondOperand = (Int32.Parse(FirstOperand) * TimesPressedEquals).ToString();
						}
						if (OperatorMemory != "") Operator = OperatorMemory;
						CalculateResult();
						break;
					case 'I':
						Inverse();
						break;
					default:
						break;
				}
			}
		}
		private void Tangens()
		{
			ActualNumber = Math.Tan(ActualNumber);
			DisplayNumber();
		}

		private void Sinus()
		{
			ActualNumber = Math.Sin(ActualNumber);
			DisplayNumber();
		}

		private void Cosines()
		{
			ActualNumber = Math.Cos(ActualNumber);
			DisplayNumber();
		}

		private void Inverse()
		{
			if (CalcDisplay != "0")
			{
				ActualNumber = 1 / Double.Parse(CalcDisplay);
				DisplayNumber();
			}
			else SetErrorState();
		}

		private void Divide()
		{
			OperatorMemory = "";
			ChangeOperator("/");
		}

		private void Add()
		{
			OperatorMemory = "";
			ChangeOperator("+");
		}

		private void Subtract()
		{
			OperatorMemory = "";
			ChangeOperator("-");
		}

		private void Multiply()
		{
			OperatorMemory = "";
			ChangeOperator("*");
		}

		private void Square()
		{
			ActualNumber = Math.Pow(ActualNumber, 2);
			DisplayNumber();
		}

		private void Root()
		{
			ActualNumber = Math.Sqrt(ActualNumber);
			DisplayNumber();
		}

		private void ChangeOperator(string op)
		{
			OperatorMemory = op;
			if (FirstOperand == "") FirstOperand = CalcDisplay;
			if (InternalMemory != "") FirstOperand = InternalMemory;
			if (Operator != "")
			{
				if (FirstOperand != "" && SecondOperand != "") CalculateResult();
				Operator = op;
			}
			else Operator = op;
		}

		private void CalculateResult()
		{
			if (InternalMemory != "") FirstOperand = InternalMemory;
			switch (Operator)
			{
				case "+":
					ActualNumber = Double.Parse(FirstOperand) + Double.Parse(SecondOperand);
					DisplayNumber();
					Operator = "";
					SecondOperand = "";
					break;
				case "/":
					if (SecondOperand != "0")
					{
						ActualNumber = Double.Parse(FirstOperand) / Double.Parse(SecondOperand);
						DisplayNumber();
					}
					else SetErrorState();
					Operator = "";
					SecondOperand = "";
					break;
				case "-":
					ActualNumber = Double.Parse(FirstOperand) - Double.Parse(SecondOperand);
					DisplayNumber();
					Operator = "";
					SecondOperand = "";
					break;
				case "*":
					ActualNumber = Double.Parse(FirstOperand) * Double.Parse(SecondOperand);
					DisplayNumber();
					Operator = "";
					SecondOperand = "";
					break;
				default:
					DisplayNumber();
					break;
			}
			InternalMemory = CalcDisplay;
		}

		private void DisplayNumber()
		{
			CalcDisplay = ActualNumber.ToString();
			if (CalcDisplay.Contains(','))
			{
				if (CalcDisplay.Split(',')[0].Length > 10 || CalcDisplay.Contains('E'))
				{
					SetErrorState();
				}
				else
				{
					string decimalPlaces = CalcDisplay.Split(',')[1];
					if (ActualNumber % 1 == 0)
					{
						CalcDisplay = CalcDisplay.Split(',')[0];
					}
					else
					{
						int roundNumber = decimalPlaces.Length;
						if (roundNumber > 9) roundNumber = 9;
						ActualNumber = Math.Round(ActualNumber, roundNumber);
						CalcDisplay = ActualNumber.ToString();
					}
				}
			}
			else
			{
				if (CalcDisplay.Length > 10)
				{
					SetErrorState();
				}
			}

			if (Operator != "") SecondOperand = CalcDisplay;
		}

		private void ResetDisplay()
		{
			CalcDisplay = "0";
			ActualNumber = 0;
			DigitsCounter = 0;
			IsInErrorState = false;
		}

		private void ResetCalc()
		{
			ResetDisplay();
			FirstOperand = "";
			SecondOperand = "";
			Operator = "";
			Memory = "";
			InternalMemory = "";
			IsInErrorState = false;
		}

		private void SetErrorState()
		{
			CalcDisplay = "-E-";
			this.IsInErrorState = true;
		}

		public string GetCurrentDisplayState()
		{
			return this.CalcDisplay;
		}
	}


}
