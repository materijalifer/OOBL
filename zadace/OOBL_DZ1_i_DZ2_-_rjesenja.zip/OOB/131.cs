﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
	#region Index
	public class Index
	{
		private string _name;
		private IndexTypes _type;
		private List<Stock> _stocks;

		public string Name
		{
			get { return _name; }
		}

		public int NumberOfStocks
		{
			get { return _stocks.Count; }
		}

		public Index(string name, IndexTypes type)
		{
			_name = name;

			if ((type != IndexTypes.AVERAGE) && (type != IndexTypes.WEIGHTED))
				throw new StockExchangeException("Illegal index type!");

			_type = type;
			_stocks = new List<Stock>();
		}

		public void AddStock(Stock stock)
		{
			_stocks.Add(stock);
		}

		public void RemoveStock(Stock stock)
		{
			if (_stocks.Contains(stock))
				_stocks.Remove(stock);
			else
				throw new StockExchangeException("Index does not contain stock!");
		}

		public decimal GetIndexValue(DateTime timeStamp)
		{
			decimal indexValue = new decimal(0.0);

			switch (_type)
			{
				case IndexTypes.AVERAGE:
					foreach (Stock s in _stocks)
						indexValue += s.GetStockPrice(timeStamp);

					indexValue /= new Decimal(3.0);

					break;

				case IndexTypes.WEIGHTED:
					decimal allStocksValue = new decimal(0.0);

					foreach (Stock s in _stocks)
						allStocksValue += s.GetStockPrice(timeStamp) * s.TotalNumberOfShares;

					if (allStocksValue > new decimal(0.0))
					{
						foreach (Stock s in _stocks)
							indexValue += (s.GetStockPrice(timeStamp) * s.GetStockPrice(timeStamp) * s.TotalNumberOfShares / allStocksValue);
					}

					break;
				default:
					throw new StockExchangeException("Illegal index type!");
			}

			return indexValue;
		}

		public bool IsStockPartOfIndex(Stock stock)
		{
			return _stocks.Contains(stock);
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
				return false;

			Index other = obj as Index;
			if (other == null)
				return false;
			else
				return _name.ToLower().Equals(other._name.ToLower());
		}

		public override int GetHashCode()
		{
			return GetType().GetHashCode() ^ _name.ToLower().GetHashCode();
		}
	}
	#endregion

	#region Portfolio
	public class Portfolio
	{
		private string _ID;
		private Dictionary<string, PortfolioStock> _portfolioStocks;

		public string ID
		{
			get { return _ID; }
		}

		public int NumberOfStocks
		{
			get { return _portfolioStocks.Count; }
		}

		public Portfolio(string ID)
		{
			_ID = ID;
			_portfolioStocks = new Dictionary<string, PortfolioStock>();
		}

		public PortfolioStock GetStock(string stockName)
		{
			foreach (string s in _portfolioStocks.Keys)
				if (String.Compare(s, stockName, true) == 0)
					return _portfolioStocks[s];

			throw new StockExchangeException("Portfolio does not contain stock!");
		}

		public bool ContainsStock(string stockName)
		{
			foreach (string s in _portfolioStocks.Keys)
				if (String.Compare(s, stockName, true) == 0)
					return true;

			return false;
		}

		public void AddStock(Stock stock, int numberOfShares)
		{
			if (_portfolioStocks.ContainsKey(stock.Name))
				_portfolioStocks[stock.Name].NumberOfShares += numberOfShares;
			else
				_portfolioStocks.Add(stock.Name, new PortfolioStock(stock, numberOfShares));
		}

		public void RemoveStock(Stock stock, int numberOfShares)
		{
			if (_portfolioStocks.ContainsKey(stock.Name))
			{
				_portfolioStocks[stock.Name].NumberOfShares -= numberOfShares;
				if (_portfolioStocks[stock.Name].NumberOfShares == 0)
					_portfolioStocks.Remove(stock.Name);
				else if (_portfolioStocks[stock.Name].NumberOfShares < 0)
					throw new StockExchangeException("Illegal number of shares!");
			}
			else
				throw new StockExchangeException("Portfolio does not contain stock!");
		}

		public long RemoveStock(Stock stock)
		{
			if (_portfolioStocks.ContainsKey(stock.Name))
			{
				long numberOfShares = _portfolioStocks[stock.Name].NumberOfShares;

				_portfolioStocks.Remove(stock.Name);

				return numberOfShares;
			}
			else
				throw new StockExchangeException("Portfolio does not contain stock!");
		}

		public decimal GetPortfolioValue(DateTime timeStamp)
		{
			decimal totalValue = new decimal(0.0);

			foreach (PortfolioStock stock in _portfolioStocks.Values)
				totalValue += stock.StockInfo.GetStockPrice(timeStamp) * stock.NumberOfShares;

			return totalValue;
		}

		public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
		{
			DateTime monthStart = new DateTime(year, month, 1, 0, 0, 0, 0);
			DateTime monthFinish = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

			decimal valueStart = GetPortfolioValue(monthStart);
			decimal valueFinish = GetPortfolioValue(monthFinish);

			return ((valueFinish - valueStart) / valueStart * 100);
		}
	}
	#endregion

	#region PortfolioStock
	public class PortfolioStock
	{
		private Stock _stock;
		private long _numberOfShares;

		public Stock StockInfo
		{
			get { return _stock; }
		}

		public long NumberOfShares
		{
			get { return _numberOfShares; }
			set { _numberOfShares = value; }
		}

		public PortfolioStock(Stock stock, long numberOfShares)
		{
			_stock = stock;
			_numberOfShares = numberOfShares;
		}
	}
	#endregion

	#region Stock
	public class Stock
	{
		private string _name;
		private long _totalNumberOfShares;
		private List<StockPrice> _prices;

		public string Name
		{
			get { return _name; }
		}

		public long TotalNumberOfShares
		{
			get { return _totalNumberOfShares; }
		}

		public decimal InitialPrice
		{
			get { return _prices[0].Price; }
		}

		public decimal LastPrice
		{
			get { return _prices[_prices.Count - 1].Price; }
		}

		public Stock(string name, long totalNumberOfShares, decimal initialPrice, DateTime timeStamp)
		{
			if (totalNumberOfShares <= 0)
				throw new StockExchangeException("Illegal stock count!");

			if ((double)initialPrice <= 0.0)
				throw new StockExchangeException("Illegal starting price!");

			_name = name;
			_totalNumberOfShares = totalNumberOfShares;

			_prices = new List<StockPrice>();
			_prices.Add(new StockPrice(initialPrice, timeStamp));
		}

		public void AddNewStockPrice(decimal price, DateTime timeStamp)
		{
			foreach (StockPrice p in _prices)
				if (StockPrice.IsEqualTimeStamp(p.TimeStamp, timeStamp))
					throw new StockExchangeException("Price already defined for given time stamp!");

			_prices.Add(new StockPrice(price, timeStamp));
		}

		public decimal GetStockPrice(DateTime timeStamp)
		{
			for (int i = 0; i < _prices.Count - 1; i++)
				if ((_prices[i].TimeStamp <= timeStamp) && (_prices[i + 1].TimeStamp > timeStamp))
					return _prices[i].Price;

			if (_prices[_prices.Count - 1].TimeStamp <= timeStamp)
				return _prices[_prices.Count - 1].Price;
			else
				return StockPrice.DEFAULT_STOCK_PRICE;
		}

		public override bool Equals(object obj)
		{
			if (obj == null)
				return false;

			Stock other = obj as Stock;
			if (other == null)
				return false;
			else
				return _name.ToLower().Equals(other._name.ToLower());
		}

		public override int GetHashCode()
		{
			return GetType().GetHashCode() ^ _name.ToLower().GetHashCode();
		}
	}
	#endregion

	#region Factory
	public static class Factory
	{
		public static IStockExchange CreateStockExchange()
		{
			return new StockExchange();
		}
	}
	#endregion

	#region StockExchange
	public class StockExchange : IStockExchange
	{
		public const int INDEX_VALUE_DECIMAL_PLACES = 3;

		private Dictionary<string, Stock> _stocks;
		private Dictionary<string, Index> _indices;
		private List<Stock> _indexedStocks;
		private Dictionary<string, Portfolio> _portfolios;
		private Dictionary<Stock, long> _availableShares;

		public StockExchange()
		{
			_stocks = new Dictionary<string, Stock>();
			_indices = new Dictionary<string, Index>();
			_indexedStocks = new List<Stock>();
			_portfolios = new Dictionary<string, Portfolio>();
			_availableShares = new Dictionary<Stock, long>();
		}

		#region Stock-managing code
		public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
		{
			string lowCaseName = inStockName.ToLower();

			Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

			if (_stocks.ContainsKey(lowCaseName))
				throw new StockExchangeException("Stock already exists!");
			else
			{
				_stocks.Add(lowCaseName, newStock);
				_availableShares.Add(newStock, inNumberOfShares);
			}
		}

		public void DelistStock(string inStockName)
		{
			Stock stock = GetStock(inStockName);

			foreach(Index i in _indices.Values)
				if (i.IsStockPartOfIndex(stock))
				{
					i.RemoveStock(stock);
					_indexedStocks.Remove(stock);
				}

			foreach(Portfolio p in _portfolios.Values)
				if (p.ContainsStock(stock.Name))
					p.RemoveStock(stock);

			_availableShares.Remove(stock);

			_stocks.Remove(stock.Name.ToLower());
		}

		public bool StockExists(string inStockName)
		{
			return _stocks.ContainsKey(inStockName.ToLower());
		}

		private Stock GetStock(string inStockName)
		{
			string lowCaseName = inStockName.ToLower();

			if (_stocks.ContainsKey(lowCaseName))
				return _stocks[lowCaseName];
			else
				throw new StockExchangeException("Stock does not exist!");
		}

		public int NumberOfStocks()
		{
			return _stocks.Values.Count;
		}

		public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
		{
			GetStock(inStockName).AddNewStockPrice(inStockValue, inIimeStamp);
		}

		public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
		{
			return GetStock(inStockName).GetStockPrice(inTimeStamp);
		}

		public decimal GetInitialStockPrice(string inStockName)
		{
			return GetStock(inStockName).InitialPrice;
		}

		public decimal GetLastStockPrice(string inStockName)
		{
			return GetStock(inStockName).LastPrice;
		}
		#endregion

		#region Index-managing code
		public void CreateIndex(string inIndexName, IndexTypes inIndexType)
		{
			string lowCaseName = inIndexName.ToLower();

			Index newIndex = new Index(inIndexName, inIndexType);

			if (_indices.ContainsKey(lowCaseName))
				throw new StockExchangeException("Index already exists!");
			else
				_indices.Add(lowCaseName, newIndex);
		}

		private Index GetIndex(string inIndexName)
		{
			string lowCaseName = inIndexName.ToLower();

			if (_indices.ContainsKey(lowCaseName))
				return _indices[lowCaseName];
			else
				throw new StockExchangeException("Index does not exist!");
		}

		public void AddStockToIndex(string inIndexName, string inStockName)
		{
			Stock stock = GetStock(inStockName);

			if (_indexedStocks.Contains(stock))
				throw new StockExchangeException("Stock already indexed!");
			else
			{
				GetIndex(inIndexName).AddStock(stock);
				_indexedStocks.Add(stock);
			}
		}

		public void RemoveStockFromIndex(string inIndexName, string inStockName)
		{
			Stock stock = GetStock(inStockName);

			GetIndex(inIndexName).RemoveStock(stock);
			_indexedStocks.Remove(stock);
		}

		public bool IsStockPartOfIndex(string inIndexName, string inStockName)
		{
			return GetIndex(inIndexName).IsStockPartOfIndex(GetStock(inStockName));
		}

		public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
		{
			decimal indexValue = GetIndex(inIndexName).GetIndexValue(inTimeStamp);

			return decimal.Round(indexValue, INDEX_VALUE_DECIMAL_PLACES);
		}

		public bool IndexExists(string inIndexName)
		{
			return _indices.ContainsKey(inIndexName.ToLower());
		}

		public int NumberOfIndices()
		{
			return _indices.Count;
		}

		public int NumberOfStocksInIndex(string inIndexName)
		{
			return GetIndex(inIndexName).NumberOfStocks;
		}
		#endregion

		#region Portfolio-managing code
		public void CreatePortfolio(string inPortfolioID)
		{
			Portfolio newPortfolio = new Portfolio(inPortfolioID);

			_portfolios.Add(inPortfolioID, newPortfolio);
		}

		private Portfolio GetPortfolio(string inPortfolioID)
		{
			if (_portfolios.ContainsKey(inPortfolioID))
				return _portfolios[inPortfolioID];
			else
				throw new StockExchangeException("Portfolio does not exist!");
		}

		public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
		{
			Stock stock = GetStock(inStockName);

			if (_availableShares[stock] >= numberOfShares)
			{
				_availableShares[stock] -= numberOfShares;
				GetPortfolio(inPortfolioID).AddStock(stock, numberOfShares);
			}
			else
				throw new StockExchangeException("Available shares exceeded!");
		}

		public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
		{
			Stock stock = GetStock(inStockName);

			GetPortfolio(inPortfolioID).RemoveStock(stock, numberOfShares);
			_availableShares[stock] += numberOfShares;
		}

		public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
		{
			Stock stock = GetStock(inStockName);

			long numberOfShares = GetPortfolio(inPortfolioID).RemoveStock(stock);
			_availableShares[stock] -= numberOfShares;
		}

		public int NumberOfPortfolios()
		{
			return _portfolios.Count;
		}

		public int NumberOfStocksInPortfolio(string inPortfolioID)
		{
			return GetPortfolio(inPortfolioID).NumberOfStocks;
		}

		public bool PortfolioExists(string inPortfolioID)
		{
			return _portfolios.ContainsKey(inPortfolioID);
		}

		public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
		{
			return GetPortfolio(inPortfolioID).ContainsStock(inStockName);
		}

		public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
		{
			return (int)GetPortfolio(inPortfolioID).GetStock(inStockName).NumberOfShares;
		}

		public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
		{
			return decimal.Round(GetPortfolio(inPortfolioID).GetPortfolioValue(timeStamp), 3);
		}

		public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
		{
			return decimal.Round(GetPortfolio(inPortfolioID).GetPortfolioPercentChangeInValueForMonth(Year, Month), 3);
		}
		#endregion
	}
	#endregion

	#region StockPrice
	public class StockPrice
	{
		public static readonly decimal DEFAULT_STOCK_PRICE = new decimal(0.0);
		public static readonly TimeSpan GRANULARITY = new TimeSpan(10000);

		public static bool IsEqualTimeStamp(DateTime first, DateTime second)
		{
			return ((Math.Abs(first.Ticks - second.Ticks)) < GRANULARITY.Ticks);
		}

		private decimal _price;
		private DateTime _timeStamp;

		public decimal Price
		{
			get { return _price; }
		}

		public DateTime TimeStamp
		{
			get { return _timeStamp; }
		}

		public StockPrice(decimal price, DateTime timeStamp)
		{
			_price = price;
			_timeStamp = timeStamp;
		}
	}
	#endregion
}
