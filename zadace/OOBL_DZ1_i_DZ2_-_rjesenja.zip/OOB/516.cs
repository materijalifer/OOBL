﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {

        private List<Stock> _stocks;
        private List<Index> _indices;
        private List<Portfolio> _portfolios;


        public StockExchange()
        {
            _stocks = new List<Stock>();
            _indices = new List<Index>();
            _portfolios = new List<Portfolio>();
        }



        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToLower();
            if (this.StockExists(inStockName)) throw new StockExchangeException("This stock you were trying to list already exists");
            if (inInitialPrice <= 0) throw new StockExchangeException("The stock value must be a positive decimal");
            if (inNumberOfShares <= 0) throw new StockExchangeException("The number of shares value must be a positive long");

            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            this._stocks.Add(stock);
        }

        public void DelistStock(string inStockName)
        {
            inStockName = inStockName.ToLower();
            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to unlist does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);

            // delete from stocks
            if(this._stocks.Contains(stock))
            {
                this._stocks.Remove(stock);
            }

            // delete from portfolios
            this._portfolios.ForEach(x => {
                if (x.isStockPartOfPortfolio(stock))
                {
                    x.removeStockFromPortfolio(stock);
                }
            });
            // delete from indices
            this._indices.ForEach(x =>
            {
                if (x.isStockPartOfIndex(stock))
                {
                    x.removeStockFromIndex(stock);
                }
            });
            
        }

        public bool StockExists(string inStockName)
        {
            inStockName = inStockName.ToLower();
            return this._stocks.Any(x => x.getStockName() == inStockName);
        }

        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            inStockName = inStockName.ToLower();
            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to set the price for does not exist");
            if (inStockValue <= 0) throw new StockExchangeException("The stock value must be a positive decimal");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            stock.setStockPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToLower();
            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to get the price for does not exist");

            Stock stock = this._stocks.Find(x => (x.getStockName() == inStockName));
            return stock.getStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            inStockName = inStockName.ToLower();
            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to get the initial price for does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            return stock.getInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            inStockName = inStockName.ToLower();
            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to get the last price for does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            return stock.getLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            inIndexName = inIndexName.ToLower();
            if (this.IndexExists(inIndexName)) throw new StockExchangeException("The index you were trying to create already exists");

            Index index = IndexFactory.CreateIndex(inIndexName, inIndexType);
            this._indices.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            inStockName = inStockName.ToLower();
            inIndexName = inIndexName.ToLower();

            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to add to the given index does not exist");
            if (!this.IndexExists(inIndexName)) throw new StockExchangeException("The index to which you were trying to add the given stock does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName().ToLower() == inStockName.ToLower());
            Index index = this._indices.Find(x => x.getIndexName().ToLower() == inIndexName.ToLower());
            index.addStockToIndex(stock);

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            inStockName = inStockName.ToLower();
            inIndexName = inIndexName.ToLower();

            if (!this.StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to remove from the given index does not exist");
            if (!this.IndexExists(inIndexName)) throw new StockExchangeException("The index from which you were trying to remove the given stock does not exist");

            Index index = this._indices.Find(x => x.getIndexName() == inIndexName);
            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            index.removeStockFromIndex(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            inStockName = inStockName.ToLower();
            inIndexName = inIndexName.ToLower();

            if (!this.StockExists(inStockName)) return false;
            if (!this.IndexExists(inIndexName)) throw new StockExchangeException("The index you tried to search for the given stock does not exist");

            Index index = this._indices.Find(x => x.getIndexName() == inIndexName);
            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            return index.isStockPartOfIndex(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            inIndexName = inIndexName.ToLower();

            if (!this.IndexExists(inIndexName)) throw new StockExchangeException("The index you tried to get the value of does not exist");

            Index index = this._indices.Find(x => x.getIndexName() == inIndexName);

            return index.getValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();
            return this._indices.Any(x => x.getIndexName() == inIndexName);
        }

        public int NumberOfIndices()
        {
            return this._indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            if (!this.IndexExists(inIndexName)) throw new StockExchangeException("The index which stocks you tried to count does not exist");

            Index index = this._indices.Find(x => x.getIndexName() == inIndexName);
            return index.getStocks().Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio you tried to create already exists");

            Portfolio portfolio = new Portfolio(inPortfolioID);
            this._portfolios.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inStockName = inStockName.ToLower();

            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio you were trying to add the stock to does not exist");
            if (!StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to add to the given stock does not exist");
            if (numberOfShares <= 0) throw new StockExchangeException("You cannot add 0 or less shares of a stock to a portfolio");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            int totalNumberOfShares = this._portfolios.Sum(x => x.isStockPartOfPortfolio(stock) ? x.getNumberOfStockSharesInPortfolio(stock) : 0);
            if (totalNumberOfShares + numberOfShares > stock.getNumOfStocks())
            {
                int newNumberOfShares = Math.Abs(numberOfShares - (int)stock.getNumOfStocks());
                portfolio.addNumberOfStockSharesToPortfolio(stock, newNumberOfShares);
            }
            else if (totalNumberOfShares == stock.getNumOfStocks())
            {
                return;
            }
            else
            {
                portfolio.addNumberOfStockSharesToPortfolio(stock, numberOfShares);
            }
            
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inStockName = inStockName.ToLower();

            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio you were trying to remove the stock from does not exist");
            if (!StockExists(inStockName)) throw new StockExchangeException("The stock you were trying to remove from the given stock does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            portfolio.removeNumberOfStockSharesFromPortfolio(stock, numberOfShares);

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");
            if (!StockExists(inStockName)) throw new StockExchangeException("The stock does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            portfolio.removeNumberOfStockSharesFromPortfolio(stock, portfolio.getNumberOfStockSharesInPortfolio(stock));
        }

        public int NumberOfPortfolios()
        {
            return this._portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");

            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            return portfolio.getNumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return this._portfolios.Any(x => x.getPortfolioID() == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");
            if (!StockExists(inStockName)) return false;

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            return portfolio.isStockPartOfPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            inStockName = inStockName.ToLower();

            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");
            if (!StockExists(inStockName)) throw new StockExchangeException("The stock does not exist");

            Stock stock = this._stocks.Find(x => x.getStockName() == inStockName);
            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            return portfolio.getNumberOfStockSharesInPortfolio(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");

            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            return portfolio.getValue(timeStamp);

        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("The portfolio does not exist");

            Portfolio portfolio = this._portfolios.Find(x => x.getPortfolioID() == inPortfolioID);

            return portfolio.getPortfolioValueChangeForMonth(Year, Month);
        }

    }


    public class Stock
    {
        private string _stockName;
        private long _numOfStocks;
        private Dictionary<DateTime, decimal> _prices = new Dictionary<DateTime, decimal>();

        public Stock(string stockName, long numOfStocks, decimal initialStockPrice, DateTime timeStamp)
        {
            this._stockName = stockName;
            this._numOfStocks = numOfStocks;
            this._prices.Add(timeStamp, initialStockPrice);
        }

        public string getStockName()
        {
            return this._stockName;
        }
        public void setStockName(string stockName)
        {
            this._stockName = stockName;
        }
        public long getNumOfStocks()
        {
            return this._numOfStocks;
        }
        public void setNumOfStocks(long numOfStocks)
        {
            this._numOfStocks = numOfStocks;
        }
        public decimal getLastStockPrice()
        {
            DateTime latestDate = this._prices.Keys.Max();
            return this._prices[latestDate];
        }
        public decimal getInitialStockPrice()
        {
            DateTime oldestDate = this._prices.Keys.Min();
            return this._prices[oldestDate];
        }
        public decimal getStockPrice(DateTime timestamp)
        {
            IEnumerable<DateTime> priorDates = this._prices.Keys.Where(x => x < timestamp);

            DateTime oldestDate;

            if (this._prices.Keys.Contains(timestamp))
            {
                oldestDate = timestamp;
            }
            else if (priorDates.ToList().Count == 0)
            {
                throw new StockExchangeException("Wrong date");
            }
            else
            {
                oldestDate = priorDates.Max();
            }

            return this._prices[oldestDate];

        }
        public void setStockPrice(decimal price, DateTime timestamp)
        {
            if (!this._prices.ContainsKey(timestamp))
            {
                this._prices.Add(timestamp, price);
            }
            else
            {
                throw new StockExchangeException("Stock price for that date is already set");
            }
        }
    }

    public class Portfolio
    {
        private string _portfolioID;
        private Dictionary<Stock, int> _stocks = new Dictionary<Stock, int>();

        public Portfolio(string portfolioID)
        {
            this._portfolioID = portfolioID;
        }

        public string getPortfolioID()
        {
            return this._portfolioID;
        }
        public void setPortfolioID(string portfolioID)
        {
            this._portfolioID = portfolioID;
        }
        public int getNumberOfStockSharesInPortfolio(Stock stock)
        {
            if (this._stocks.ContainsKey(stock))
            {
                return this._stocks[stock];
            }
            else
            {
                return 0;
            }
        }
        public void addNumberOfStockSharesToPortfolio(Stock stock, int num)
        {
            if (this._stocks.ContainsKey(stock))
            {
                this._stocks[stock] += num;
            }
            else
            {
                this._stocks.Add(stock, num);
            }
        }
        public void removeNumberOfStockSharesFromPortfolio(Stock stock, int num)
        {
            if (this._stocks.ContainsKey(stock))
            {
                if (num >= this._stocks[stock])
                {
                    this._stocks.Remove(stock);
                }
                else
                {
                    this._stocks[stock] -= num;
                }
            }
            else
            {
                throw new StockExchangeException("stock does not exist in portfolio");
            }
        }

        public void removeStockFromPortfolio(Stock stock)
        {
            if (this._stocks.ContainsKey(stock))
            {
                this._stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("stock does not exist in portfolio");
            }
        }

        public bool isStockPartOfPortfolio(Stock stock)
        {
            return this._stocks.ContainsKey(stock);
        }

        public int getNumberOfStocksInPortfolio()
        {
            return this._stocks.Count;
        }

        public decimal getValue(DateTime timeStamp)
        {
            decimal sumValue = 0;

            foreach (Stock st in this._stocks.Keys)
            {
                sumValue += st.getStockPrice(timeStamp) * this._stocks[st];
            }

            return Math.Round(sumValue, 3);
        }

        public decimal getPortfolioValueChangeForMonth(int year, int month)
        {
            // because the DateTime is non nullable type
            DateTime beginning = new DateTime(1990, 1, 1, 0, 0, 0);
            DateTime end = new DateTime(1990, 1, 1, 0, 0, 0);
            try
            {
                beginning = new DateTime(year, month, 1, 0, 0, 0);
                end = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
            }
            catch (Exception ex)
            {
                throw new StockExchangeException("Date invalid");
            }


            decimal endV = getValue(end);
            decimal begV = getValue(beginning);

            decimal portfolioValue;
            if (begV == 0)
            {
                portfolioValue = endV * 100;
            }
            else
            {
                portfolioValue = (getValue(end) - getValue(beginning)) / getValue(beginning) * 100;
            }

            return Math.Round(portfolioValue, 3);
        }
    }

    public abstract class Index
    {
        private string _indexName;
        private List<Stock> _stocks = new List<Stock>();

        public string getIndexName()
        {
            return this._indexName;
        }
        public void setIndexName(string indexName)
        {
            this._indexName = indexName;
        }
        public List<Stock> getStocks()
        {
            return this._stocks;
        }
        public void setStocks(List<Stock> stocks)
        {
            this._stocks = stocks;
        }
        public void addStockToIndex(Stock stock)
        {
            if (!this._stocks.Contains(stock))
            {
                this._stocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Stock is already in the index");
            }
        }
        public void removeStockFromIndex(Stock stock)
        {
            if (this._stocks.Contains(stock))
            {
                this._stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in this index");
            }

        }
        public bool isStockPartOfIndex(Stock stock)
        {
            return this._stocks.Contains(stock);
        }

        public abstract decimal getValue(DateTime timeStamp);
    }

    public class AverageIndex : Index
    {

        public AverageIndex(string indexName)
        {
            base.setIndexName(indexName);
        }

        public override decimal getValue(DateTime timeStamp)
        {
            decimal sum = 0;

            if (getStocks().Count == 0) return 0;

            List<Stock> stocks = getStocks();

            foreach (Stock singleStock in stocks)
            {
                sum += singleStock.getStockPrice(timeStamp);
            }

            return Math.Round(sum / stocks.Count, 3);
        }
    }

    public class WeightedIndex : Index
    {

        public WeightedIndex(string indexName)
        {
            base.setIndexName(indexName);
        }

        public override decimal getValue(DateTime timeStamp)
        {
            List<Stock> stocks = getStocks();
            decimal totalValueOfStocks = 0;

            if (getStocks().Count == 0) return 0;

            foreach (Stock singleStock in stocks)
            {
                totalValueOfStocks += singleStock.getStockPrice(timeStamp) * singleStock.getNumOfStocks();
            }

            decimal finalValue = 0;

            foreach (Stock singleStock in stocks)
            {
                finalValue += singleStock.getStockPrice(timeStamp) * singleStock.getNumOfStocks() * singleStock.getStockPrice(timeStamp) / totalValueOfStocks;
            }

            return Math.Round(finalValue, 3);
        }
    }

    public class IndexFactory
    {
        public static Index CreateIndex(string indexName, IndexTypes indexType)
        {
            if (indexType == IndexTypes.AVERAGE)
            {
                return new AverageIndex(indexName);
            }
            else if (indexType == IndexTypes.WEIGHTED)
            {
                return new WeightedIndex(indexName);
            }
            else
            {
                throw new StockExchangeException("Unsupported index type");
            }

        }
    }


}
