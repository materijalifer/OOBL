﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new MyCalculator();
        }
    }

    public class MyCalculator : ICalculator
    {
        private string displayValue;
        private string presentValue;
        private string oldValue;
        private bool negativeNumberSign;
        private string aritmeticOperator;
        private char lastSign;
        private string memoryValue;
        private bool memoryNegativeSign;

        public MyCalculator()
        {
            string startValue = "0";
            this.displayValue = startValue;
            this.negativeNumberSign = false;
            this.aritmeticOperator = "";
            this.presentValue = "0";
        }

        #region Unos znaka
        public void Press(char inPressedDigit)
        {
            // Ako je ulazni znak broj
            if (Char.IsDigit(inPressedDigit))
            {
                AddDigitToNumber(inPressedDigit);
                ChangeDisplayValue();
            }
            // Ako je ulazni znak nesto drugo
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        SetAritmeticOperator(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case '-':
                        SetAritmeticOperator(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case '*':
                        SetAritmeticOperator(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case '/':
                        SetAritmeticOperator(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case '=':
                        ResolveAritmeticOperation();
                        ChangeDisplayValue();
                        break;
                    case ',':
                        AddDecimalSign(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'S':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'K':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'T':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'Q':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'R':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        break;
                    case 'I':
                        ResolveUnaryOperation(inPressedDigit);
                        ChangeDisplayValue();
                        this.presentValue = "";
                        break;
                    case 'P':
                        PutInMemory(this.presentValue);
                        break;
                    case 'G':
                        GetFromMemory();
                        ChangeDisplayValue();
                        break;
                    case 'M':
                        ChangeNumberSign();
                        ChangeDisplayValue();
                        break;
                    case 'C':
                        ClearDisplay();
                        ChangeDisplayValue();
                        break;
                    case 'O':
                        Power();
                        ChangeDisplayValue();
                        break;
                }
            }
            // Postavljanje zadnjeg ulaznog znaka
            this.lastSign = inPressedDigit;
        }
        #endregion

        public string GetCurrentDisplayState()
        {
            return this.displayValue;
        }

        #region Dodavanje znamenke, predznaka ili decimalnog zareza na postojeci zapis
        // Dodavanje znamenke na postojeci ulazni zapis
        private void AddDigitToNumber(char inPressedDigit)
        {
            try
            {
                if (this.presentValue.Equals("0") && inPressedDigit.Equals('0'))
                    return;
                if (this.presentValue[0].Equals('0') && !this.presentValue[1].Equals(','))
                    this.presentValue = this.presentValue.Substring(1);
                int maxNumberDigits = 10;

                if (this.presentValue.Replace(",", "").Length == maxNumberDigits)
                    return;
            }
            catch { }

            this.presentValue += inPressedDigit;
        }
        // Dodavanje decimalnog zareza
        private void AddDecimalSign(char inPressedDigit)
        {


            if (presentValue.Contains(','))
                return;
            // Ako je trenutna vrijednost 0 ili da vrijednost nije nula ali je prethodna operacija bila unarna ali ne i mjenjanje predznaka
            if (this.presentValue.Equals("") || (!this.presentValue.Equals("") && !Char.IsDigit(this.lastSign) && !this.lastSign.Equals('M')))
                this.presentValue = "0,";
            else
                this.presentValue = this.presentValue + inPressedDigit;
        }
        // Mjenjanje predznaka
        private void ChangeNumberSign()
        {
            if (this.presentValue.Equals("0"))
                return;
            if (this.presentValue[0].Equals('-'))
                this.presentValue = this.presentValue.Substring(1);
            else
                this.presentValue = "-" + this.presentValue;
        }
        #endregion

        #region Prikaz na zaslonu
        // Promjena prikaza na ekranu nakon pritisnute tipke
        private void ChangeDisplayValue()
        {
            if (!this.presentValue.Equals(""))
                this.displayValue = this.presentValue;
            else
                this.displayValue = this.oldValue;
            this.displayValue = PrepareForDisplay(this.displayValue);
        }

        // Prije ispisa na ekran uklanja decimalni zarez i nule ako je to moguce
        private string PrepareForDisplay(string displayValue)
        {
            try
            {
                decimal number = Decimal.Parse(displayValue);
                displayValue = Double.Parse(number.ToString("0.#########")).ToString();
            }
            catch { }

            return displayValue;
        }
        #endregion

        #region Spremanje binarnog operatora
        private void SetAritmeticOperator(char binaryOperator)
        {
            if (!this.aritmeticOperator.Equals("") && !this.presentValue.Equals("") && !(this.lastSign.Equals('='))) // 3+2*4 ---> nakon unosa znaka "*" izracunava se operacija 3+2 i ispisuje se njezin rezultat 5
                ResolveAritmeticOperation();
            if (!this.presentValue.Equals(""))
                this.oldValue = this.presentValue;
            this.aritmeticOperator = binaryOperator.ToString();
            this.presentValue = "";
        }
        #endregion

        #region Izračun binarne operacije
        private void ResolveAritmeticOperation()
        {
            if (this.aritmeticOperator.Equals("")) { return; }

            double firstNumber;
            double secondNumber;
            double resultNumber;
            // Ako je prosli ulazni nije bio "=" izvrsavamo operaciju
            if (!(this.lastSign.Equals('=')))
            {
                firstNumber = double.Parse(this.oldValue);
                if (!this.presentValue.Equals(""))
                {
                    secondNumber = double.Parse(this.presentValue);
                    this.oldValue = this.presentValue;
                }
                else
                    secondNumber = double.Parse(this.oldValue);
            }
            // Ako je zadnji ulazni znak bio "=" moramo ponoviti istu opreaciju sa razlicitim redoslijedom operanada
            else
            {
                firstNumber = double.Parse(this.presentValue);
                secondNumber = double.Parse(this.oldValue);
            }
            switch (this.aritmeticOperator)
            {
                case "+": resultNumber = firstNumber + secondNumber; break;
                case "-": resultNumber = firstNumber - secondNumber; break;
                case "*": resultNumber = firstNumber * secondNumber; break;
                case "/": resultNumber = firstNumber / secondNumber; break;
                default: resultNumber = secondNumber; break;
            }

            FormatResultValue(resultNumber);
        }
        #endregion

        #region Izračun unarne operacije
        private void ResolveUnaryOperation(char unaryOperator)
        {
            double operand;
            try
            {
                operand = double.Parse(presentValue);
            }
            catch
            {
                operand = double.Parse(this.oldValue);
            }

            double result;

            switch (unaryOperator.ToString())
            {
                case "Q": result = Math.Pow(operand, 2); break;
                case "R": result = Math.Sqrt(operand); break;
                case "I": result = 1 / operand; break;
                case "S": result = Math.Sin(operand); break;
                case "K": result = Math.Cos(operand); break;
                case "T": result = Math.Tan(operand); break;
                default: result = 0; break;
            }
            FormatResultValue(result);
        }
        #endregion

        #region Provjera ispravnosti rezultata. U slucaju nedopustene vrijednosti rezultat je -E-
        private void FormatResultValue(double result)
        {
            string number;
            int maxDecimalSpaces = 9;
            number = Math.Round(result, maxDecimalSpaces).ToString();

            if ((number.Replace("-", "").Replace(",", "").Length > 10) || number.Equals("NaN") || number.Equals("Infinity") || number.Equals("-Infinity"))
                number = "-E-";
            this.presentValue = number;
        }
        #endregion

        #region Rad s memorijom
        // Spremanje u memoriju
        private void PutInMemory(string currentValue)
        {
            this.memoryValue = currentValue;
            this.memoryNegativeSign = this.negativeNumberSign;
            this.aritmeticOperator = "";
        }
        // Citanje iz memorije
        private void GetFromMemory()
        {
            this.presentValue = this.memoryValue;
            this.negativeNumberSign = this.memoryNegativeSign;
        }
        #endregion

        #region Paljenje i brisanje zaslona
        // Gasenje/paljenje kalkulatora
        private void Power()
        {
            this.presentValue = "0";
            this.oldValue = "0";
            this.negativeNumberSign = false;
            this.displayValue = "0";
        }
        // Brisanje zaslona
        private void ClearDisplay()
        {
            this.presentValue = "0";
        }
        #endregion

    }
}