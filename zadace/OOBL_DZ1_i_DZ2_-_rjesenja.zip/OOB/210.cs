﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        string memorija = "0";
        string displayState = "0";
        char lastOperation = '\0';
        double lastOperand = 0;
        const double MAX_VALUE = 9999999999;
        char lastPressedDigit = '0';

        public void Press(char inPressedDigit)
        {
            if (displayState == "-E-")
            {
                displayState = "0";
            }
            if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                if ((lastPressedDigit < '0' || lastPressedDigit > '9') && lastPressedDigit != ',' && lastPressedDigit != 'M' && lastPressedDigit != 'P')
                {
                    displayState = "0";
                }
                IsNumber(inPressedDigit - 48);
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/' || inPressedDigit == '=')
            {
                IsBinaryOperation(inPressedDigit);
            }
            else if (inPressedDigit == ',')
            {
                if ((lastPressedDigit < '0' || lastPressedDigit > '9') && lastPressedDigit != ',' && lastPressedDigit != 'M' && lastPressedDigit != 'P')
                {
                    displayState = "0";
                }
                IsZarez();
            }
            else
            {
                IsUnaryOperation(inPressedDigit);
            }
            lastPressedDigit = inPressedDigit;
            CheckDisplayState();
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }


        public void IsNumber(int number)
        {
            if (displayState == "0") displayState = number.ToString();
            else displayState += number.ToString();
            CheckDisplayState();
        }

        public void IsBinaryOperation(char operation)
        {
            if (lastOperation != '\0')
            {
                try
                {
                    lastOperand = Evaluate(lastOperand, lastOperation, Convert.ToDouble(GetCurrentDisplayState()));
                    displayState = lastOperand.ToString();
                }
                catch (Exception e)
                {
                    if (e.Message == "Dijeljenje s nulom nije podrzano")
                    {
                        displayState = "-E-";
                    }
                }
                
            }
            else
            {
                lastOperand = Convert.ToDouble(GetCurrentDisplayState());
            }
            if (operation != '=')
            {
                lastOperation = operation;
            }
            if (displayState.Contains(','))
            {
                if (displayState[displayState.Count() - 1] == ',')
                {
                    displayState = displayState.Remove(displayState.Count() - 1);
                }
                else
                {
                    for (int i = displayState.IndexOf(',') + 1; i <= displayState.Count() - 1; i++)
                    {
                        if (displayState[i] != '0')
                        {
                            break;
                        }
                        displayState = displayState.Split(',')[0];
                    }
                }
            }
            CheckDisplayState();
        }

        public void IsUnaryOperation(char operation)
        {
            switch (operation)
            {
                case 'M':
                    if (displayState[0] != '-')
                    {
                        displayState = "-" + displayState;
                    }
                    else
                    {
                        displayState = displayState.Remove(0);
                    }
                    break;
                case 'S':
                    displayState = Math.Sin(Convert.ToDouble(displayState)).ToString();
                    displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    break;
                case 'K':
                    displayState = Math.Cos(Convert.ToDouble(displayState)).ToString();
                    displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    break;
                case 'T':
                    displayState = Math.Tan(Convert.ToDouble(displayState)).ToString();
                    displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    break;
                case 'Q':
                    displayState = Math.Pow(Convert.ToDouble(displayState),2).ToString();
                    displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    break;
                case 'R':
                    displayState = Math.Sqrt(Convert.ToDouble(displayState)).ToString();
                    displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    break;
                case 'I':
                    if (Convert.ToDouble(displayState) != 0)
                    {
                        displayState = Math.Pow(Convert.ToDouble(displayState), -1).ToString();
                        displayState = Math.Round(Convert.ToDouble(displayState), 10).ToString();
                    }
                    else
                    {
                        displayState = "-E-";
                    }
                    break;
                case 'P':
                    memorija = GetCurrentDisplayState();
                    break;
                case 'G':
                    displayState = memorija;
                    break;
                case 'C':
                    displayState = "0";
                    break;
                case 'O':
                    displayState = "0";
                    memorija = "";
                    lastOperand = 0;
                    lastOperation = '\0';
                    break;
            }
            CheckDisplayState();
        }

        public void IsZarez()
        {
            if (!displayState.Contains(','))
            {
                displayState += ',';
            }
        }
        public double Evaluate(double lastOperand, char operation, double newOperand)
        {
            switch (operation)
            {
                case '+':
                    return Math.Round(lastOperand + newOperand, 10);
                case '-':
                    return Math.Round(lastOperand - newOperand, 10);
                case '*':
                    return Math.Round(lastOperand * newOperand,10);
                case '/':
                    if(newOperand == 0) throw new Exception("Dijeljenje s nulom nije podrzano");
                    return Math.Round(lastOperand / newOperand,10);
                default:
                    throw new ArgumentException("Nepodrzana operacija!");
            }
        }

        public void CheckDisplayState()
        {
            int duljina = 0;
            
            if (displayState.Contains(',')) duljina++;
            if(displayState.Contains('-')) duljina++;

            if(displayState.Count() > 10 + duljina)
            {
                displayState = displayState.Remove(displayState.Count() - 1);
            }
            if (displayState != "-E-")
            {
                if (Convert.ToDouble(displayState) > MAX_VALUE || Convert.ToDouble(displayState) < -MAX_VALUE)
                {
                    displayState = "-E-";
                }
            }

        }
    }
}
