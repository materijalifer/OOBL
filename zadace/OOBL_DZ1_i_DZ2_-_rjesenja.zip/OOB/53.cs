﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string memorija = null;

        private bool isInsertedDigit = true;
        private Display currentDisplay = new Display();
        private Digits classDigits = new Digits();
        private Operation operation = new Operation();

        private bool isBinaryOperation = false;

        private char binaryOperation = ' ';

        private double internResault = 0;

        /*
         * Metoda press
         * 
         */
        public void Press(char inPressedDigit)
        {
            if (!IsBinOperation(inPressedDigit))
            {
                ChooseAction(inPressedDigit);
            }

        }

        /*
         * Metoda dohvata trenutnog stanja ekrana
         * 
         */
        public string GetCurrentDisplayState()
        {
            return this.currentDisplay.CurrentlyDisplay;

        }

        /*
         * Metoda koja provjerava da li je unesen binarni operator. Unutar metode se vrši provjera
         * unosa više zaredanih dobro strukturiranih bin operacija te  u slučaju pozitivnog odgovora
         * vrši internu pohranu rezultata.
         * 
         */
        private bool IsBinOperation(char inPressedDigit)
        {
            string pattern = "[" + Regex.Escape("+") + Regex.Escape("*") + "/" + "-]";
            Regex regOperation = new Regex(pattern);
            if (regOperation.IsMatch(inPressedDigit.ToString()))
            {
                if (this.isBinaryOperation)
                {
                    if (this.isInsertedDigit)
                    {
                        doInternalBinaryOp();
                    }

                    this.isBinaryOperation = true;
                    this.isInsertedDigit = false;
                    this.binaryOperation = inPressedDigit;
                }
                else
                {
                    string intenalStingNum = this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay);
                    this.internResault = double.Parse(intenalStingNum);
                    this.isBinaryOperation = true;
                    this.isInsertedDigit = false;
                    this.binaryOperation = inPressedDigit;

                }
                return true;

            }
            return false;

        }

        /*
         * Metoda koja odabire metodu ovisno o ulazu. Ovisno o ulazu vrši ispis na ekran, obavlja unutarnje operacije te resetiranje.
         * 
         */
        private void ChooseAction(char inPressedDigit)
        {
            double resault = 0;
            switch (inPressedDigit)
            {
                case ',':
                    this.currentDisplay.CurrentlyDisplay += inPressedDigit.ToString();

                    break;

                case '=':
                    if (this.isBinaryOperation)
                    {
                        DoBinaryOperation();
                        this.isBinaryOperation = false;
                        this.binaryOperation = ' ';
                        if (!this.classDigits.CheckLengthResult(this.currentDisplay.CurrentlyDisplay))
                        {
                            setError();
                            break;
                        }

                    }
                    this.currentDisplay.CurrentlyDisplay = this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay);
                    this.isInsertedDigit = false;
                    break;

                case 'M':
                    string changedSing = this.classDigits.ChangeSing(this.currentDisplay.CurrentlyDisplay);
                    this.currentDisplay.CurrentlyDisplay = this.classDigits.ControlDigits(changedSing);
                    break;

                case 'S':
                    resault = this.operation.Sin(double.Parse(
                            this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                    ChangeDisplay(resault);
                    break;

                case 'K':
                    resault = this.operation.Cos(double.Parse(
                            this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                    ChangeDisplay(resault);
                    break;
                case 'T':
                    resault = this.operation.Tangens(double.Parse(
                            this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                    ChangeDisplay(resault);
                    break;
                case 'Q':
                    resault = this.operation.Quadrat(double.Parse(
                            this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                    ChangeDisplay(resault);
                    break;

                case 'R':
                    resault = this.operation.Root(double.Parse(
                            this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                    ChangeDisplay(resault);
                    break;

                case 'I':
                    if (this.currentDisplay.CurrentlyDisplay.Equals("0"))
                    {
                        setError();
                    }
                    else
                    {
                        resault = this.operation.Invers(double.Parse(
                                this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay)));
                        ChangeDisplay(resault);
                    }
                    break;

                case 'P':
                    this.memorija = this.currentDisplay.CurrentlyDisplay;
                    break;

                case 'G':
                    this.currentDisplay.CurrentlyDisplay = this.memorija;
                    break;

                case 'C':
                    this.currentDisplay.Reset();
                    break;

                case 'O':
                    this.currentDisplay.Reset();
                    this.isBinaryOperation = false;
                    this.isInsertedDigit = true;
                    this.memorija = null;
                    this.binaryOperation = ' ';
                    this.internResault = 0;
                    break;
                    //upis znamenke
                default:
                    if (isInsertedDigit)
                    {
                        this.currentDisplay.CurrentlyDisplay += inPressedDigit.ToString();
                    }
                    else
                    {
                        this.currentDisplay.CurrentlyDisplay = inPressedDigit.ToString();
                        this.isInsertedDigit = true;
                    }
                    this.currentDisplay.CurrentlyDisplay = this.classDigits.EraseLeadingZero(this.currentDisplay.CurrentlyDisplay);
                    break;
            }

        }

        /*
         * Metoda koja vrši unutarnju binarnu operaciju. Interno pamti rezultat oeracije za daljnju upotrebu.
         * 
         */
        private void doInternalBinaryOp()
        {
            switch (this.binaryOperation)
            {
                case '+':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.internResault = this.operation.Add(
                                this.internResault, double.Parse(lastNum));
                    }
                    else
                    {
                        this.internResault = this.operation.Add(
                               this.internResault, this.internResault);
                    }
                    break;
                case '-':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.internResault = this.operation.Substract(
                                this.internResault, double.Parse(lastNum));
                    }
                    else
                    {
                        this.internResault = this.operation.Substract(
                               this.internResault, this.internResault);
                    }
                    break;
                case '/':
                    if (isInsertedDigit)
                    {
                        //provjera 0
                        if (this.currentDisplay.CurrentlyDisplay.Equals("0"))
                        {
                            setError();
                        }
                        else
                        {
                            string lastNum = GetNumberFromDisplay();
                            this.internResault = this.operation.Divide(
                                    this.internResault, double.Parse(lastNum));
                        }
                    }
                    else
                    {
                        if (this.currentDisplay.CurrentlyDisplay.Equals("0"))
                        {
                            setError();
                        }
                        else
                        {
                            this.internResault = this.operation.Divide(
                                   this.internResault, this.internResault);
                        }
                    }
                    break;
                case '*':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.internResault = this.operation.Multiplay(
                                this.internResault, double.Parse(lastNum));
                    }
                    else
                    {
                        this.internResault = this.operation.Multiplay(
                               this.internResault, this.internResault);
                    }
                    break;
            }
          
        }

        /*
         * Metoda dohvata ispisa sa ekrana.
         * 
         */
        private string GetNumberFromDisplay()
        {
            string lastNum = this.classDigits.ControlDigits(this.currentDisplay.CurrentlyDisplay);
            return lastNum;
        }

        /*
         * Metoda koja se poziva u slučaju greške te ispisuje na ekran "-E-"
         * 
         */
        private void setError()
        {
            this.currentDisplay.CurrentlyDisplay = "-E-";
        }


        /*
         * Metoda koja obavlja binarnu operaciju. U slučaju da nema 2 broja upisana izvršava operaciju na osnovu podataka interne memorije 
         * dok u slučaju upisana 2 broja vrši operciju ta 2 broja.
         * 
         */
        private void DoBinaryOperation()
        {
            switch (this.binaryOperation)
            {
                case '+':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.currentDisplay.CurrentlyDisplay = this.operation.Add(
                                this.internResault, double.Parse(lastNum)).ToString();
                    }
                    else
                    {
                        this.currentDisplay.CurrentlyDisplay = this.operation.Add(
                               this.internResault, this.internResault).ToString();
                    }
                    break;
                case '-':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.currentDisplay.CurrentlyDisplay = this.operation.Substract(
                                this.internResault, double.Parse(lastNum)).ToString();
                    }
                    else
                    {
                        this.currentDisplay.CurrentlyDisplay = this.operation.Substract(
                               this.internResault, this.internResault).ToString();
                    }
                    break;
                case '/':
                    if (isInsertedDigit)
                    {
                        //provjera 0
                        if (this.currentDisplay.CurrentlyDisplay.Equals("0"))
                        {
                            setError();
                        }
                        else
                        {
                            string lastNum = GetNumberFromDisplay();
                            this.currentDisplay.CurrentlyDisplay = this.operation.Divide(
                                    this.internResault, double.Parse(lastNum)).ToString();
                        }
                    }
                    else
                    {
                        if (this.currentDisplay.CurrentlyDisplay.Equals("0"))
                        {
                            setError();
                        }
                        else
                        {
                            this.currentDisplay.CurrentlyDisplay = this.operation.Divide(
                                   this.internResault, this.internResault).ToString();
                        }
                    }
                    break;
                case '*':
                    if (isInsertedDigit)
                    {
                        string lastNum = GetNumberFromDisplay();
                        this.currentDisplay.CurrentlyDisplay = this.operation.Multiplay(
                                this.internResault, double.Parse(lastNum)).ToString();
                    }
                    else
                    {
                        this.currentDisplay.CurrentlyDisplay = this.operation.Multiplay(
                               this.internResault, this.internResault).ToString();
                    }
                    break;

            }

        }

        /*
         * Metoda koja postavlja rezultat na ekran. Formatira ispis.
         * 
         */
        private void ChangeDisplay(double resault)
        {
            this.currentDisplay.CurrentlyDisplay = this.classDigits.ControlDigits(resault.ToString());
        }


    }

    /*
     *Klasa koja reprezentira ekran. Ima opcije dohvata i postavljanja podataka na ekran.
     */
    class Display
    {
        private string currentlyDisplay;
        //property
        public string CurrentlyDisplay
        {
            get { return currentlyDisplay; }
            set { currentlyDisplay = value; }
        }

        /*
         * Konstruktor pri stvaranju postavlja display na 0...
         * 
         */
        public Display()
        {
            this.Reset();
        }

        /*
         * Metoda koja resetira ekran na 0
         * 
         */
        public void Reset()
        {
            this.CurrentlyDisplay = "0";
        }

    }

    /*
     * Klasa Digits koja realizira objekt brojki koji sadrži metode za obradu brojki koje se prikazuju na ekranu.
     * 
     */
    class Digits
    {
        private int lengthDigits = 10;
        private int lengthSingedDigits = 11;
        private int lengthDecilmalDigits = 11;
        private int lengthDecilmalSingedDigits = 12;

        /*
         * Konstruktor koji stvara razred Digits.
         */
        public Digits()
        {
        }

        /*
         * Metoda promjene predznaka.
         * 
         */
        public string ChangeSing(string strDigits)
        {
            if (strDigits.StartsWith("-"))
            {
                return strDigits.Substring(1, strDigits.Length - 1);
            }
            return "-" + strDigits;
        }

        /*
         * Metoda koja kontrolira zapis brojeva na ekranu. Provjera se vrši pomoću nekoliko metoda.
         * 
         */
        public string ControlDigits(string strDigits)
        {
            strDigits = ControlGoodInput(ref strDigits);

            strDigits = EraseTrailingZero(ref strDigits);

            strDigits = EraseLeadingZero(ref strDigits);

            strDigits = ControlLength(ref strDigits);

            strDigits = Recovery(ref strDigits);

            return strDigits;
        }

        /**
         * Kontrola i postavljanje na 0 u slucaju loseg formata broja.
         * 
         */
        private string ControlGoodInput(ref string strDigits)
        {
            Regex regDigits = null;
            if (strDigits.Contains(","))
            {
                regDigits = new Regex("^-*[0-9]+,[0-9]*$");

            }
            else
            {
                regDigits = new Regex("^-*[0-9]+$");

            }
            if (!regDigits.IsMatch(strDigits))
            {
                return "0";

            }
            return strDigits;
        }

        /*
         * Metoda koja oporavlja string u slucaju da se izbrise nula ispred decimalnog zareza ili ako su sve brojke izbrisane.
         * 
         */
        private string Recovery(ref string strDigits)
        {
            Regex regRecovery = new Regex("^,");
            if (regRecovery.IsMatch(strDigits))
            {
                strDigits = "0" + strDigits;

            }
            if (strDigits.Equals(""))
            {
                strDigits = "0";
            }

            return strDigits;
        }

        /*
         * Metoda koja briše početne nule.
         * 
         */
        private static string EraseLeadingZero(ref string strDigits)
        {
            Regex regLeadingZero = new Regex("^0+");
            strDigits = regLeadingZero.Replace(strDigits, "");

            Regex regRecovery = new Regex("^,");
            if (regRecovery.IsMatch(strDigits))
            {
                strDigits = "0" + strDigits;
            }




            return strDigits;
        }

        /*
         * Metoda koja briše nule koje se nalaze na kraju.
         * 
         */
        private static string EraseTrailingZero(ref string strDigits)
        {
            Regex regTrailingZero = new Regex(",*0+$");
            strDigits = regTrailingZero.Replace(strDigits, "");
            return strDigits;
        }

        /*
         * Metoda koja kontrolira duljinu brojki koje se mogu prikazati.
         * Duzina ne smije prelaziti 12 elemenata te 10 brojki.
         * 
         */
        private string ControlLength(ref string strDigits)
        {
            if (strDigits.Length <= lengthDigits)
            {
                return strDigits;
            }
            int lengthExtra = 0;
            string[] strSplitedDigits = null;
            if (strDigits.StartsWith("-"))
            {
                if (strDigits.Length <= lengthSingedDigits)
                {
                    return strDigits;
                }
                strSplitedDigits = strDigits.Split(',');
                if (strSplitedDigits.Length == 2)
                {
                    if (strDigits.Length > lengthDecilmalSingedDigits)//slucaj kada je predznak u pitanju decimalnog broja a preveliki
                    {
                        lengthExtra = strDigits.Length - lengthDecilmalSingedDigits;
                        strDigits = strSplitedDigits[0] + "," + RoundNumber(strSplitedDigits[1], lengthExtra);

                    }
                    return strDigits;

                }
                lengthExtra = strDigits.Length - lengthSingedDigits;
                return RoundNumber(strDigits, lengthExtra);

            }
            strSplitedDigits = strDigits.Split(',');
            if (strSplitedDigits.Length == 2)
            {
                if (strDigits.Length > lengthDecilmalDigits)//slucaj kada je predznak u pitanju decimalnog broja a preveliki
                {
                    lengthExtra = strDigits.Length - lengthDecilmalDigits;
                    strDigits = strSplitedDigits[0] + "," + RoundNumber(strSplitedDigits[1], lengthExtra);

                }
                return strDigits;
            }
            lengthExtra = strDigits.Length - lengthDigits;
            return RoundNumber(strDigits, lengthExtra);
        }

        /*
         *  Metoda koja zaokruzuje broj ako je zapis predugacak. 
         * 
         */
        private string RoundNumber(string strDigits, int lengthExtra)
        {
            string refactoredStrDigits = strDigits.Substring(0, strDigits.Length - lengthExtra - 1);
            string digitRounding = strDigits.Substring(strDigits.Length - 1 - lengthExtra, 1);
            string digitChecking = strDigits.Substring(strDigits.Length - lengthExtra, 1);
            string finishedDigit = "";
            if (int.Parse(digitChecking) < 5 || int.Parse(digitRounding) == 9)
            {
                finishedDigit += digitRounding;

            }
            else
            {
                finishedDigit += (int.Parse(digitRounding) + 1).ToString();

            }
            return refactoredStrDigits + finishedDigit;

        }

        /*
         * Provjera da li je rezultatski cijelobrojni dio podoban za ispis.
         * 
         */
        internal bool CheckLengthResult(string result)
        {
            string[] strDecimal = result.Split(',');
            if (strDecimal[0].StartsWith("-"))
            {
                if (strDecimal[0].Length > this.lengthSingedDigits)
                {
                    return false;
                }
            }
            else
            {
                if (strDecimal[0].Length > this.lengthDigits)
                {
                    return false;
                }
            }
            return true;
  
        }

        /*
         * Metoda koja briše nule ispred zapisa, koje su nepotrebe. Metoda može biti pozvana iz druge klase.
         * 
         */
        internal string EraseLeadingZero(string strDigits)
        {
            Regex regLeadingZero = new Regex("^0+");
            strDigits = regLeadingZero.Replace(strDigits, "");

            Regex regRecovery = new Regex("^,");
            if (regRecovery.IsMatch(strDigits))
            {
                strDigits = "0" + strDigits;
            }
            if (strDigits.Equals(""))
            {
                strDigits = "0";
            }


            return strDigits;
        }
    }

    /*
     * Klasa koja sadrži sve operacije.
     * 
     */
    class Operation
    {
        /*
         * Konstruktor.
         * 
         */
        public Operation()
        {
        }

        public double Add(double firstNum, double secNum)
        {
            return firstNum + secNum;
        }

        public double Substract(double firstNum, double secNum)
        {
            return firstNum - secNum;
        }

        public double Multiplay(double firstNum, double secNum)
        {
            return firstNum * secNum;
        }

        public double Divide(double firstNum, double secNum)
        {
            return firstNum / secNum;
        }

        public double Invers(double num)
        {
            return 1 / num;
        }

        public double Root(double num)
        {
            return Math.Sqrt(num);
        }

        public double Quadrat(double num)
        {
            return Math.Pow(num, 2.0);
        }

        public double Tangens(double num)
        {
            return Math.Tan(num);
        }

        public double Cos(double num)
        {
            return Math.Cos(num);
        }

        public double Sin(double num)
        {
            return Math.Sin(num);
        }

        public double changeSing(double num)
        {
            return -num;

        }

    }
}

