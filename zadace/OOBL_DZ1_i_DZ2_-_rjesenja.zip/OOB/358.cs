﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Price
    {
        private Dictionary<DateTime, decimal> _prices = new Dictionary<DateTime, decimal>();

        public void AddNewPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Cijena dionice ne smije biti jednaka ili manja od 0.");
            }
            else if (_prices.Keys.Contains(inTimeStamp))
            {
                throw new StockExchangeException("Greška! Cijena za odabrani datum je već definirana.");
            }
            else
            {
                _prices.Add(inTimeStamp, inStockValue);
            }
        }

        public decimal GetPriceByTimeStamp(DateTime inTimeStamp)
        {
            foreach (KeyValuePair<DateTime, decimal> price in _prices.OrderByDescending(x => x.Key))
            {
                if (price.Key <= inTimeStamp)
                {
                    return price.Value;
                }
            }

            throw new StockExchangeException("Greška! Cijena nije definirana za odabrani datum.");
        }

        public decimal GetOldestPrice()
        {
            decimal oldestPrice = _prices.OrderBy(x => x.Key).ElementAt(0).Value;
            return oldestPrice;
        }

        public decimal GetNewestPrice()
        {
            decimal newestPrice = _prices.OrderByDescending(x => x.Key).ElementAt(0).Value;
            return newestPrice;
        }
    }

    public class Stock
    {
        public string name { get; private set; }
        public long numberOfShares { get; private set; }
        private Price _price = new Price();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica ne smije biti jednak ili manji od 0.");
            }
            else
            {
                _price.AddNewPrice(inTimeStamp, inInitialPrice);
                name = inStockName.ToUpper();
                numberOfShares = inNumberOfShares;
            }
        }

        public void SetPrice(DateTime inTimeStamp, decimal inNewPrice)
        {
            _price.AddNewPrice(inTimeStamp, inNewPrice);
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            return _price.GetPriceByTimeStamp(inTimeStamp);
        }

        public decimal GetInitialPrice()
        {
            return _price.GetOldestPrice();
        }

        public decimal GetLastPrice()
        {
            return _price.GetNewestPrice();
        }

    }

    public abstract class Index
    {
        public string name { get; protected set; }
        protected Dictionary<string, Stock> _indexedStocks;

        public void AddStock(Stock stock)
        {
            if (ContainsStock(stock.name))
            {
                throw new StockExchangeException("Indeks već sadrži unesenu dionicu.");
            }
            else
            {
                _indexedStocks.Add(stock.name, stock);
            }
        }

        public void RemoveStock(string inStockName)
        {
            if (ContainsStock(inStockName))
            {
                _indexedStocks.Remove(inStockName.ToUpper());
            }
            else
            {
                throw new StockExchangeException("Indeks ne sadrži odabranu dionicu");
            }
        }

        public bool ContainsStock(string inStockName)
        {
            return _indexedStocks.Keys.Contains(inStockName.ToUpper());
        }

        public int NumberOfStocks()
        {
            return _indexedStocks.Count;
        }

        public abstract decimal GetValue(DateTime inTimeSTamp);

    }

    public class AverageIndex : Index
    {
        private const int DIGITS_AFTER_DECIMAL_POINT = 3;

        public AverageIndex(string inIndexName)
        {
            name = inIndexName.ToUpper();
            _indexedStocks = new Dictionary<string, Stock>();
        }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal value = 0;
            decimal totalPrice = 0;
            long totalStockCount = 0;

            foreach (KeyValuePair<string, Stock> stock in _indexedStocks)
            {
                totalPrice += stock.Value.GetPrice(inTimeStamp);
                totalStockCount++;
            }

            value = totalPrice / totalStockCount;
            value = Math.Round(value, DIGITS_AFTER_DECIMAL_POINT);

            return value;
        }
    }

    public class WeightedIndex : Index
    {
        private const int DIGITS_AFTER_DECIMAL_POINT = 3;

        public WeightedIndex(string inIndexName)
        {
            name = inIndexName.ToUpper();
            _indexedStocks = new Dictionary<string, Stock>();
        }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal index = 0;
            if (_indexedStocks.Count > 0)
            {
                decimal totalPrice = 0;
                foreach (KeyValuePair<string, Stock> stock in _indexedStocks)
                {
                    totalPrice += stock.Value.numberOfShares * stock.Value.GetPrice(inTimeStamp);
                }

                decimal stockPrice;
                foreach (KeyValuePair<string, Stock> stock in _indexedStocks)
                {
                    stockPrice = stock.Value.GetPrice(inTimeStamp);
                    index += (stockPrice / totalPrice) * stock.Value.numberOfShares * stockPrice;
                }
                index = Math.Round(index, DIGITS_AFTER_DECIMAL_POINT);
            }
            return index;
        }
    }

    public static class IndexFactory
    {
        public static Index CreatIndex(string IndexName, IndexTypes IndexType)
        {
            switch (IndexType)
            {
                case IndexTypes.WEIGHTED:
                    return new WeightedIndex(IndexName);
                case IndexTypes.AVERAGE:
                    return new AverageIndex(IndexName);
                default:
                    throw new StockExchangeException("Odabran je nedopušteni tip indeksa.\nDozvoljeni tipovi: AVERAGE i WEIGHTED.");
            }

        }
    }

    public class Portfolio
    {
        private const int DIGITS_AFTER_DECIMAL_POINT = 3;

        public string PortfolioID { get; private set; }

        private Dictionary<string, Stock> _stocksInPortfolio = new Dictionary<string, Stock>();
        private Dictionary<string, int> _stockSharesInPortfolio = new Dictionary<string, int>();

        public Portfolio(string inPortfolioID)
        {
            PortfolioID = inPortfolioID;
        }

        public bool ContainsStock(string inStockName)
        {
            return _stockSharesInPortfolio.Keys.Contains(inStockName.ToUpper());
        }

        public int GetNumberOfSharesOfStock(string inStockName)
        {
            if (ContainsStock(inStockName))
            {
                return _stockSharesInPortfolio[inStockName.ToUpper()];
            }
            else
            {
                return 0;
            }
        }

        public int GetNumberOfStocks()
        {
            return _stockSharesInPortfolio.Count;
        }

        public void RemoveStock(string inStockName)
        {
            _stockSharesInPortfolio.Remove(inStockName.ToUpper());
            _stocksInPortfolio.Remove(inStockName.ToUpper());
        }

        public void RemoveStock(string inStockName, int numberOfShares)
        {
            if (numberOfShares > _stockSharesInPortfolio[inStockName.ToUpper()])
            {
                throw new StockExchangeException("Ne postoji toliko dionica u portfeljeu.");
            }
            else if (numberOfShares == _stockSharesInPortfolio[inStockName.ToUpper()])
            {
                RemoveStock(inStockName);
            }
            else
            {
                _stockSharesInPortfolio[inStockName.ToUpper()] -= numberOfShares;
            }
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (ContainsStock(stock.name))
            {
                _stockSharesInPortfolio[stock.name] += numberOfShares;
            }
            else
            {
                _stocksInPortfolio.Add(stock.name, stock);
                _stockSharesInPortfolio.Add(stock.name, numberOfShares);
            }
        }

        public decimal GetValue(DateTime inTimeStamp)
        {
            decimal portfolioValue = 0;
            if (GetNumberOfStocks() > 0)
            {
                decimal priceOfTheStockInTimeStamp;
                foreach (KeyValuePair<string, int> stockShares in _stockSharesInPortfolio)
                {
                    try
                    {
                        priceOfTheStockInTimeStamp = _stocksInPortfolio[stockShares.Key].GetPrice(inTimeStamp);
                        portfolioValue += stockShares.Value * priceOfTheStockInTimeStamp;
                    }
                    catch (StockExchangeException e)
                    {
                        throw new StockExchangeException("Portfelj sadrži dionice koje nemaju definiranu cijenu u zadanom vremenu.");
                    }
                }
            }
            return portfolioValue;
        }

        public decimal GetPercentChangeInValueForMonth(int Year, int Month)
        {
            decimal portfolioPercentChangeInValueForMonth = 0;
            if (GetNumberOfStocks() > 0)
            {
                decimal portfolioValueInTheBeginingOfTheMonth;
                decimal portfolioValueInTheEndOfTheMonth;
                decimal difference;
                DateTime beginingOfTheMonth = new DateTime(Year, Month, 1, 0, 0, 0);
                DateTime endOfTheMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

                try
                {
                    portfolioValueInTheBeginingOfTheMonth = GetValue(beginingOfTheMonth);
                    portfolioValueInTheEndOfTheMonth = GetValue(endOfTheMonth);
                    difference = portfolioValueInTheEndOfTheMonth - portfolioValueInTheBeginingOfTheMonth;
                    portfolioPercentChangeInValueForMonth = difference * 100 / portfolioValueInTheBeginingOfTheMonth;
                }
                catch (StockExchangeException e)
                {
                    throw new StockExchangeException("Portfelj sadrži dionice koje nemaju definiranu " +
                                                        "cijenu na početku i kraju zadanog mjeseca.");
                }

            }
            return Math.Round(portfolioPercentChangeInValueForMonth, DIGITS_AFTER_DECIMAL_POINT);
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> _listedStocks = new Dictionary<string, Stock>();
        private Dictionary<string, Index> _indices = new Dictionary<string, Index>();
        private Dictionary<string, Portfolio> _portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica je već uknjižena.");
            }
            else
            {
                Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                _listedStocks.Add(newStock.name, newStock);
            }   
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                _listedStocks.Remove(inStockName.ToUpper());
                RemoveStockFromAllIndices(inStockName);
                RemoveStockFromAllPortfolios(inStockName);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji na burzi.");
            }
        }

        public bool StockExists(string inStockName)
        {
            return _listedStocks.Keys.Contains(inStockName.ToUpper());
        }

        public int NumberOfStocks()
        {
            return _listedStocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName))
            {
                _listedStocks[inStockName.ToUpper()].SetPrice(inTimeStamp, inStockValue);
            }
            else
            {
                throw new StockExchangeException("Greška! Cijena se postavlja ne postojećoj dionici.");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                return _listedStocks[inStockName.ToUpper()].GetPrice(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Greška! Traži se cijena ne postojećoj dionici.");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return _listedStocks[inStockName.ToUpper()].GetInitialPrice();
            }
            else
            {
                throw new StockExchangeException("Greška! Traži se cijena ne postojećoj dionici.");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return _listedStocks[inStockName.ToUpper()].GetLastPrice();
            }
            else
            {
                throw new StockExchangeException("Greška! Traži se cijena ne postojećoj dionici.");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Indeks je već stvoren.");
            }
            else
            {
                Index newIndex = IndexFactory.CreatIndex(inIndexName, inIndexType);
                _indices.Add(inIndexName.ToUpper(), newIndex);
            } 
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName))
            {
                _indices[inIndexName.ToUpper()].AddStock(_listedStocks[inStockName.ToUpper()]);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći indeks ili nepostojeća dionica.");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName))
            {
                _indices[inIndexName.ToUpper()].RemoveStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći indeks ili nepostojeća dionica.");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName))
            {
                return _indices[inIndexName.ToUpper()].ContainsStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći indeks ili nepostojeća dionica.");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (IndexExists(inIndexName))
            {
                return _indices[inIndexName.ToUpper()].GetValue(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći indeks.");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return _indices.Keys.Contains(inIndexName.ToUpper());
        }

        public int NumberOfIndices()
        {
            return _indices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return _indices[inIndexName.ToUpper()].NumberOfStocks();
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći indeks.");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj je već stvoren.");
            }
            else
            {
                _portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                if (_listedStocks[inStockName.ToUpper()].numberOfShares - NumberOfSharesAddedToPortfolios(inStockName) >= numberOfShares && numberOfShares > 0)
                {
                    if (StockAlreadyAddedToAPortfolio(inPortfolioID, inStockName))
                    {
                        throw new StockExchangeException("Odabrani dionica je već dodana u drugi portfelje.");
                    }
                    else
                    {
                        _portfolios[inPortfolioID].AddStock(_listedStocks[inStockName.ToUpper()], numberOfShares);
                    }
                }
                else
                {
                    throw new StockExchangeException("Odabrani broj dionica nije dostupan.");
                }
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj ili nepostojeća dionica.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                _portfolios[inPortfolioID].RemoveStock(inStockName, numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj ili nepostojeća dionica.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                _portfolios[inPortfolioID].RemoveStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj ili nepostojeća dionica.");
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolios[inPortfolioID].GetNumberOfStocks();
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj.");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.Keys.Contains(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                return _portfolios[inPortfolioID].ContainsStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj ili nepostojeća dionica.");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                return _portfolios[inPortfolioID].GetNumberOfSharesOfStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj ili nepostojeća dionica.");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolios[inPortfolioID].GetValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj.");
            }

        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolios[inPortfolioID].GetPercentChangeInValueForMonth(Year, Month);
            }
            else
            {
                throw new StockExchangeException("Koristi se nepostojeći portfelj.");
            }
        }

        private int NumberOfSharesAddedToPortfolios(string inStockName)
        {
            int numberOfSharesAdded = 0;
            foreach (KeyValuePair<string, Portfolio> portfolio in _portfolios)
            {
                numberOfSharesAdded += portfolio.Value.GetNumberOfSharesOfStock(inStockName);
            }

            return numberOfSharesAdded;
        }

        private bool StockAlreadyAddedToAPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (KeyValuePair<string, Portfolio> portfolio in _portfolios)
            {
                if (portfolio.Key != inPortfolioID && portfolio.Value.ContainsStock(inStockName))
                { 
                    return true;
                }
            }
            return false;
        }

        private void RemoveStockFromAllIndices(string inStockName)
        {
            List<string> indexNames = new List<string>();
            foreach( KeyValuePair<string, Index> indices in _indices )
            {
                indexNames.Add(indices.Key);
            }

            foreach (string indexName in indexNames)
            {
                RemoveStockFromIndex(indexName, inStockName);
            }
        }

        private void RemoveStockFromAllPortfolios(string inStockName)
        {
            List<string> portfolioIDs = new List<string>();
            foreach (KeyValuePair<string, Portfolio> portfolios in _portfolios)
            {
                portfolioIDs.Add(portfolios.Key);
            }

            foreach (string portfolioID in portfolioIDs)
            {
                RemoveStockFromPortfolio(portfolioID, inStockName);
            }
        }
    }
}
