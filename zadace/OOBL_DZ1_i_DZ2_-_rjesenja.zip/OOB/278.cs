﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        #region varijable
        char[] broj = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        char[] dualOper = { '+', '-', '*', '/' };
        char[] unarOper = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };

        bool _operPostoji = false;

        bool _zarezUnesen = false;
        bool _brojUnesen = false;

        bool _unarUnesen = false;
        bool _binUnesen = false;

        bool _prviUnos = true;

        bool _error = false;
        bool _final = false;
        bool _repeat = false;

        char zadnjiOper = '\0';
        char zadnjiZnak;

        double prib;
        double rezultat;

        string pribS;

        double mem;
        string memS;
        #endregion

        /// <summary>
        /// Metoda za obrađivanje pritisnute tipke
        /// </summary>
        /// <param name="inPressedDigit">Pritisnuta tipka</param>
        public void Press(char inPressedDigit)
        {

            if (inPressedDigit == 'O')
            {
                SetClear();
                _error = false;
            }

            if (inPressedDigit == 'C')
            {
                prib = 0;
                pribS = string.Empty;
            }

            if (inPressedDigit == 'P')
            {
                mem = prib;
                memS = pribS;
            }

            if (inPressedDigit == 'G')
            {
                pribS = memS;
                prib = mem;
            }

            //if (inPressedDigit == 'W')
            //{
            //    Console.WriteLine("I: " + GetCurrentDisplayState());
            //}

            if (inPressedDigit == ',')
            {
                if (_brojUnesen == true)
                {
                    pribS += ',';
                }
                if (_unarUnesen == false && _brojUnesen == false)
                {
                    pribS = "0,";
                    _brojUnesen = true;
                }
                if (_unarUnesen == true)
                { 
                pribS = "0,";
                }
            }

            if (broj.Contains(inPressedDigit))
            {

                if (_brojUnesen == false)
                {
                    prib = 0;
                    pribS = string.Empty;
                }

                if (_final == true)
                {
                    prib = 0;
                    pribS = string.Empty;
                    _final = false;
                }

                _brojUnesen = true;
                _binUnesen = false;

                if (_unarUnesen == true)
                {
                    pribS = String.Empty;
                    pribS += inPressedDigit;
                    _unarUnesen = false;
                }
                else
                {
                    int duljina;
                    if (pribS.IndexOf(",") != -1) duljina = 11;
                    else duljina = 10;
                    if ((Math.Abs(prib)).ToString().Length < duljina)
                    {
                        pribS = pribS + inPressedDigit;
                    }
                }

                prib = Convert.ToDouble(pribS);

                if (_prviUnos == true)
                    rezultat = prib;

            }

            if (unarOper.Contains(inPressedDigit) || dualOper.Contains(inPressedDigit))
            {
                _brojUnesen = false;

                if (unarOper.Contains(inPressedDigit))
                {
                    _unarUnesen = true;
                    UnarnaOperacija(inPressedDigit, prib);
                }

                if (dualOper.Contains(inPressedDigit) && !dualOper.Contains(zadnjiZnak))
                {
                    _binUnesen = true;

                    if (_operPostoji == true )
                    {
                        DualnaOperacija(inPressedDigit, prib);
                    }
                    else
                    {
                        rezultat = prib;
                        _operPostoji = true;
                    }
                    zadnjiOper = inPressedDigit;
                    _prviUnos = false;
                }

            }

            if (inPressedDigit == '=')
            {
                _final = true;
                if (zadnjiOper != '\0')
                {
                    DualnaOperacija(zadnjiOper, prib);
                }
            }
            zadnjiZnak = inPressedDigit;
        }

        /// <summary>
        /// Prikaz stanja na ekranu
        /// </summary>
        /// <returns></returns>
        public string GetCurrentDisplayState()
        {
            if (rezultat > 9999999999 || rezultat < -9999999999 || _error == true)
                return "-E-";
            else if (_unarUnesen == true)
            {
                return prib.ToString();
            }
            else if (_prviUnos == false && _binUnesen == true || _final == true)
                return rezultat.ToString();
            else
                return prib.ToString();

        }

        /// <summary>
        /// Reset kalkulatora
        /// </summary>
        public void SetClear()
        {
            rezultat = 0;
            prib = 0;
            pribS = string.Empty;
        }

        /// <summary>
        /// Metoda za izvođenje unarnih operacija
        /// </summary>
        /// <param name="oper"></param>
        /// <param name="broj"></param>
        private void UnarnaOperacija(char oper, double broj)
        {

            switch (oper)
            {
                case 'S':
                    if (_prviUnos == true) { rezultat = zaokruzi(Math.Sin(broj)); prib = zaokruzi(Math.Sin(broj)); }
                    else prib = zaokruzi(Math.Sin(broj));
                    break;

                case 'K':
                    if (_prviUnos == true) { rezultat = zaokruzi(Math.Cos(broj)); prib = zaokruzi(Math.Cos(broj)); }
                    else prib = zaokruzi(Math.Cos(broj));
                    break;

                case 'T':
                    if (_prviUnos == true) { rezultat = zaokruzi(Math.Tan(broj)); prib = zaokruzi(Math.Tan(broj)); }
                    else prib = zaokruzi(Math.Tan(broj));
                    break;

                case 'Q':
                    if (_prviUnos == true) { rezultat = zaokruzi(Math.Pow(broj, 2)); prib = zaokruzi(Math.Pow(broj, 2)); }
                    else prib = zaokruzi(Math.Pow(broj, 2));
                    break;

                case 'R':
                    if (_prviUnos == true) { rezultat = zaokruzi(Math.Pow(broj, 1 / 2)); prib = zaokruzi(Math.Pow(broj, 1 / 2)); }
                    else prib = zaokruzi(Math.Pow(broj, 2));
                    break;

                case 'M':
                    if (_prviUnos == true) { rezultat = 0 - broj; prib = 0 - broj; pribS = prib.ToString(); }
                    else { prib = 0 - broj; pribS = prib.ToString(); }
                    _unarUnesen = false;
                    _brojUnesen = true;
                    break;

                case 'I':
                    if (broj == 0)
                    {
                        _error = true;
                        break;
                    }
                    if (_prviUnos == true) { rezultat = zaokruzi(1 / broj); prib = zaokruzi(1 / broj); }
                    else prib = zaokruzi(1 / broj);
                    break;

                default:
                    break;
            }
        }

        /// <summary>
        /// Metoda za izvođenje binarnih operacija
        /// </summary>
        /// <param name="oper">Operator</param>
        /// <param name="broj">Operand nad kojim se izvodi operacija u paru s rezultatom</param>
        private void DualnaOperacija(char oper, double broj)
        {

            switch (zadnjiOper)
            {
                case '+':
                    rezultat = rezultat + broj;
                    if (rezultat > 9999999999 || rezultat < -9999999999)
                    {
                        _error = true;
                        break;
                    }
                    rezultat = zaokruzi(rezultat);
                    zadnjiOper = oper;
                    break;

                case '-':
                    rezultat = rezultat - broj;
                    if (rezultat > 9999999999 || rezultat < -9999999999)
                    {
                        _error = true;
                        break;
                    }
                    rezultat = zaokruzi(rezultat);
                    zadnjiOper = oper;
                    break;

                case '*':
                    rezultat = rezultat * broj;
                    if (rezultat > 9999999999 || rezultat < -9999999999)
                    {
                        _error = true;
                        break;
                    }
                    rezultat = zaokruzi(rezultat);
                    zadnjiOper = oper;
                    break;

                case '/':
                    if (broj == 0)
                    {
                        _error = true;
                        break;
                    }
                    rezultat = rezultat / broj;
                    rezultat = zaokruzi(rezultat);
                    zadnjiOper = oper;
                    break;
            }

        }

        /// <summary>
        /// Metoda za zaokruživanje ispravno broja
        /// </summary>
        /// <param name="broj">nesređeni broj</param>
        /// <returns>zaokruženi broj</returns>
        private double zaokruzi(double broj)
        {
            int cijeliBroj = Convert.ToInt32(Math.Truncate(Math.Abs(broj)));
            int len = (cijeliBroj.ToString()).Length;
            double rez = Math.Round(broj, 10 - len);
            return rez;
        }

    }

}
