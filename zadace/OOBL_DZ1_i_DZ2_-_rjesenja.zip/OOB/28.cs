﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }


    /*
     * 
     * Change List: 
     *              ctor : SetResult()
     *              Pressed Digit() : SetResult after SELECT CASE
     *              SetResult():
     */

    class Calculator : ICalculator
    {
        private const int MAX_LENGTH = 10;

        private const string CLEAR_SCREEN = "0";

        private const string ERROR = "-E-";

        private const char DECIMAL_POINT = ',';

        private const char SIGN = '-';

        private bool allowDecimalCheck;

        private bool disableOperations;

        private bool displayOperand;

        private bool operatorSet;

        string decimalResult;

        string operation;

        string display;

        string operand;

        string memory;

        private System.Text.RegularExpressions.Regex FALSE_DECIMAL = new System.Text.RegularExpressions.Regex(@"^(\d+),0+$");

        private System.Text.RegularExpressions.Regex OVER_ZEROED_DECIMAL = new System.Text.RegularExpressions.Regex(@"^(\d+,\d*)0$");

        private System.Text.RegularExpressions.Regex UNDER_ZEROED_DECIMAL = new System.Text.RegularExpressions.Regex(@"^(-?)0(\d)$");

        private System.Text.RegularExpressions.Regex UNSIGN_DECIMAL_NUM = new System.Text.RegularExpressions.Regex(@"^-?(\d+,?\d*)$");

        public Calculator()
        {
            TurnPower();
            SetResult();
        }

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'O':
                    TurnPower();
                    break;
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    NewDigit(inPressedDigit);
                    break;
                case ',':
                    PlaceDecimalPoint(inPressedDigit);
                    break;
                case 'M':
                    ChangeSign('-');
                    break;
                case 'C':
                    ClearScreen();
                    break;
                case 'P':
                    if (!disableOperations)
                    {
                        ToMemory();
                    }
                    break;
                case 'G':
                    FromMemory();
                    break;
                case '+':
                case '-':
                case '*':
                case '/':
                    if (!disableOperations)
                    {
                        if (operatorSet)
                        {
                            operation = inPressedDigit.ToString();
                            displayOperand = true;
                        }
                        else
                        {
                            operatorSet = true;
                            if (operation == ERROR)
                            {
                                operand = display;
                                display = CLEAR_SCREEN;
                                displayOperand = true;

                                operation = inPressedDigit.ToString();
                            }
                            else
                            {
                                Operate();
                                operation = inPressedDigit.ToString();
                            }
                        }
                    }
                    break;
                case '=':
                    if (!disableOperations)
                    {
                        Equality();
                    }
                    break;
                case 'S':
                case 'K':
                case 'T':
                case 'Q':
                case 'R':
                case 'I':
                    OperateUnary(inPressedDigit);
                    break;
                default:
                    throw new Exception("Argument is not valid mathematical oprator");
            }
            SetResult();
        }

        private void TurnPower()
        {
            /**/
            display = CLEAR_SCREEN;
            memory = CLEAR_SCREEN;

            allowDecimalCheck = false;
            disableOperations = false;
            displayOperand = false;
            operatorSet = false;

            operation = ERROR;
            operand = ERROR;
        }

        private void NewDigit(char digit)
        {
            /*
             * Don't allow 2,0 to be reduced to 2
             * If ERROR occured operations were disabled, enable them
             */
            allowDecimalCheck = false;
            disableOperations = false;

            if (operatorSet)
            {
                /*
                 * operator is set => display 0
                 */
                display = CLEAR_SCREEN;
            }
            if (display == CLEAR_SCREEN || display == ERROR)
            {
                /*
                 * If display == 0 replace 0 with new digit
                 * If display == -E- replace -E- with new digit
                 */
                display = digit.ToString();
            }
            else
            {
                /*
                 * Display has one or more digits
                 * Calculate display's maximal allowed length
                 */
                int currentMaxLength = MAX_LENGTH;
                currentMaxLength = display.Contains(DECIMAL_POINT) ? currentMaxLength + 1 : currentMaxLength;
                currentMaxLength = display.Contains(SIGN) ? currentMaxLength + 1 : currentMaxLength;

                if (display.Length < currentMaxLength)
                {
                    /*
                     * Display can fit more digits => append pressed one
                     */
                    display += digit;
                }
            }
            /*
             * If operator was set and digit was entered => opeartor is now not set 
             */
            operatorSet = false;
        }

        private void PlaceDecimalPoint(char decimalPoint)
        {
            if (display == ERROR)
            {
                /*
                 * Display shows ERROR => set display to 0,
                 */
                display = CLEAR_SCREEN + ',';
            }
            else
            {
                /*
                 * Display shows natural or decimal number
                 */
                if (!display.Contains(','))
                {
                    /*
                     * Display shows natural number, append decimal point
                     */
                    display += decimalPoint.ToString();
                }
            }
        }

        private void ChangeSign(char sign)
        {
            if (operatorSet)
            {
                /*
                 * If operator is set, invert sign on left operand
                 * Set display to active operand
                 * If left operand is negative make it positive
                 */
                operatorSet = false;
                if (operand.Contains(SIGN))
                {
                    display = operand.Remove(0, 1);
                }
                else
                {
                    display = operand.Insert(0, SIGN.ToString());
                }
            }
            else
            {
                /*
                 * Else, invert sign on display
                 */
                if (display == ERROR)
                {
                    display = SIGN + CLEAR_SCREEN;
                }
                else
                {
                    if (display.Contains(SIGN))
                    {
                        display = display.Remove(0, 1);
                    }
                    else
                    {
                        display = display.Insert(0, sign.ToString());
                    }
                }
            }
        }

        private void ClearScreen()
        {
            display = CLEAR_SCREEN;
            operatorSet = false;
            disableOperations = false;
        }

        private void ToMemory()
        {
            if (operatorSet)
            {
                memory = operand;
            }
            else
            {
                memory = display;
            }
        }

        private void FromMemory()
        {
            /* 
             * Set active operand to display
             * Update display
             */
            operatorSet = false;
            display = memory;
        }

        private void Operate()
        {
            allowDecimalCheck = true;
            switch (operation)
            {
                case "+":
                    Add();
                    break;
                case "-":
                    Subtract();
                    break;
                case "*":
                    Multiply();
                    break;
                case "/":
                    Divide();
                    break;
                case ERROR:
                default:
                    throw new Exception("Argument is not valid mathematical operator : " + operation);
            }
        }

        private void OperateUnary(char operation)
        {
            if (display != ERROR)
            {
                allowDecimalCheck = true;
                switch (operation)
                {
                    case 'S':
                        Sinus();
                        break;
                    case 'K':
                        Cosinus();
                        break;
                    case 'T':
                        Tangens();
                        break;
                    case 'Q':
                        Square();
                        break;
                    case 'R':
                        Sqrt();
                        break;
                    case 'I':
                        Invert();
                        break;
                    default:
                        throw new Exception("Argument is not valid mathematical operator : " + operation);
                }
            }
        }

        private void Add()
        {
            operand = (operand == ERROR) ? display : (Decimal.Parse(display) + Decimal.Parse(operand)).ToString();
            display = CLEAR_SCREEN;
            displayOperand = true;
        }

        private void Subtract()
        {
            operand = (operand == ERROR) ? display : (Decimal.Parse(operand) - Decimal.Parse(display)).ToString();
            display = CLEAR_SCREEN;
            displayOperand = true;
        }

        private void Multiply()
        {
            operand = (operand == ERROR) ? display : (Decimal.Parse(operand) * Decimal.Parse(display)).ToString();
            display = CLEAR_SCREEN;
            displayOperand = true;
        }

        private void Divide()
        {
            try
            {
                operand = (operand == ERROR) ? display : (Decimal.Parse(operand) / Decimal.Parse(display)).ToString();
                display = CLEAR_SCREEN;
                displayOperand = true;
            }
            catch (DivideByZeroException ex)
            {
                disableOperations = true;
                operatorSet = false;
                operand = ERROR;
                display = ERROR;
            }
        }

        private void Sinus()
        {
            double result = operatorSet ? Math.Sin(double.Parse(operand.ToString())) : Math.Sin(double.Parse(display.ToString()));
            display = result.ToString();
        }

        private void Cosinus()
        {
            double result = operatorSet ? Math.Cos(double.Parse(operand.ToString())) : Math.Cos(double.Parse(display.ToString()));
            display = result.ToString();
        }

        private void Tangens()
        {
            double result = operatorSet ? Math.Tan(double.Parse(operand.ToString())) : Math.Tan(double.Parse(display.ToString()));
            display = result.ToString();
        }

        private void Square()
        {
            double result = operatorSet ? Math.Pow(double.Parse(operand.ToString()), 2) : Math.Pow(double.Parse(display.ToString()), 2);
            display = result.ToString();
        }

        private void Sqrt()
        {
            double result = operatorSet ? Math.Pow(double.Parse(operand.ToString()), 1 / 2) : Math.Pow(double.Parse(display.ToString()), 1 / 2);
            display = result.ToString();
        }

        private void Invert()
        {
            double result = operatorSet ? Math.Pow(double.Parse(operand.ToString()), -1) : Math.Pow(double.Parse(display.ToString()), -1);
            if (result.ToString() == "+Infini" || result.ToString() == "Infinity")
            {
                disableOperations = true;
                operatorSet = false;
                operand = ERROR;
                display = ERROR;
            }
            else
            {
                display = result.ToString();
            }
        }

        private void Equality()
        {
            /*
             * Allow to check result for FALSE_DECIMAL and OVER_ZEROED_DECIMAL
             */

            allowDecimalCheck = true;

            /*
             * If ERROR didn't occured
             */
            if (operand != ERROR)
            {
                /*
                 * If left operand was active, set display to left operand
                 */
                if (operatorSet)
                {
                    display = operand;
                }

                /*
                 * Do last operation
                 */
                Operate();

                displayOperand = false;
                operatorSet = false;

                operation = ERROR;
                display = operand;
                operand = ERROR;
                SetResult();
            }
            else
            {
                if (operatorSet)
                {

                }
            }
        }

        private void SetResult()
        {
            if (displayOperand)
            {
                CheckResult(ref operand);
                displayOperand = false;
                decimalResult = operand;
            }
            else
            {
                CheckResult(ref display);
                decimalResult = display;
            }
        }

        public string GetCurrentDisplayState()
        {
            return decimalResult;
        }

        public void CheckResult(ref string result)
        {
            if (result != ERROR)
            {
                if (UNDER_ZEROED_DECIMAL.IsMatch(result))
                {
                    result = UNDER_ZEROED_DECIMAL.Match(result).Groups[1].ToString() + UNDER_ZEROED_DECIMAL.Match(result).Groups[2].ToString();
                }

                string temp = UNSIGN_DECIMAL_NUM.Match(result).Groups[1].Value.ToString();

                if (temp.Contains(DECIMAL_POINT))
                {
                    if (temp.IndexOf(DECIMAL_POINT) > 10)
                    {
                        SetError();
                        return;
                    }
                    else
                    {
                        if (temp.Length > 12)
                        {
                            result = Math.Round(decimal.Parse(result), 9).ToString();
                        }
                    }
                }
                else
                {
                    if (temp.Length > 10)
                    {
                        SetError();
                        return;
                    }
                }

                if (allowDecimalCheck)
                {
                    if (FALSE_DECIMAL.IsMatch(temp))
                    {
                        result = result.Contains(SIGN) ? SIGN.ToString() : "";
                        result += FALSE_DECIMAL.Match(temp).Groups[1].Value.ToString();
                        temp = result;
                    }
                    if (OVER_ZEROED_DECIMAL.IsMatch(temp))
                    {
                        result = result.Contains(SIGN) ? SIGN.ToString() : "";
                        result += OVER_ZEROED_DECIMAL.Match(temp).Groups[1].Value.ToString();
                    }
                }
            }
        }

        public void SetError()
        {
            display = ERROR;
            operand = ERROR;
            operatorSet = false;
        }
    }
}