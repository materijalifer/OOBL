﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private class Operand
        {
            private double  _number;
            public  bool    error;
            private bool    _minus;

            public void set(string num)
            {
                int dec = 0 ;
                CultureInfo culture = CultureInfo.CreateSpecificCulture("HR");
                if (num.EndsWith(","))
                {
                    num = num.Remove(num.Length - 1);
                }
                _number = double.Parse(num, culture);
                foreach (char c in _number.ToString())
                {
                    if (c == '-')
                        continue;
                    else if (c != ',')
                        dec++;
                    else break;
                }
                if (dec > 10)
                {
                    error = true;
                    return;
                }
                dec = 10 - dec;
                _number = Math.Round(_number, dec);
                if (_minus)
                    _number = -_number;
            }
            public double get()
            {
                return _number;
            }

            public void changeSign()
            {
                _number = -_number;
                _minus = true;
            }
            internal void sinus()
            {
                this.set(Math.Sin(_number).ToString());
                //_number = Math.Sin(_number);
            }
            internal void cosinus()
            {
                this.set(Math.Cos(_number).ToString());
                //_number = Math.Cos(_number);
            }
            internal void tangens()
            {
                this.set(Math.Tan(_number).ToString());
                //_number = Math.Tan(_number);
            }
            internal void square()
            {
                this.set(Math.Pow(_number,2).ToString());
                //_number = Math.Pow(_number, 2);
            }
            internal void root()
            {
                this.set(Math.Sqrt(_number).ToString());
                _number = Math.Sqrt(_number);
            }
            internal bool invers()
            {
                if (_number != 0)
                {
                    _number = 1 / _number;
                    return true;
                }
                else
                    return false;
            }
        }

        private bool        _flag;
        private bool        _binary;
        private string      _operand;
        private string      _displayState;
        private double      _memory;
        private char        _command;
        private Operand     _op1;
        private Operand     _op2;

        public Kalkulator()
        {
            _op1 = new Operand();
            _op2 = new Operand();
            _op1.set("0");
            _op2.set("0");
            resetKalkulator();
        }

        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit) || (inPressedDigit.Equals(',')))
            {
                _operand += inPressedDigit;
                _displayState = _operand;
            }
            else if (inPressedDigit.Equals('O'))
            {
                resetKalkulator();
                return;
            }
            else if (inPressedDigit.Equals('C'))
            {
                _operand = "";
                _displayState = "0";
                return;
            }
            else if (inPressedDigit.Equals('='))
            {
                if (_flag)
                {
                    if (_operand != "")
                    {
                        _op2.set(_operand);
                        execute(_command);
                        _operand = "";
                        flipFlag();
                    }
                    else
                    {
                        _op2.set(_op1.get().ToString());
                        execute(_command);
                        _operand = "";
                        flipFlag();
                    }
                }
                //throw new NotImplementedException();
            }
            else
            {
                if (checkUnary(inPressedDigit))
                {
                    if (_binary)
                    {
                        string temp = _op1.get().ToString();
                        Operand tmp = new Operand();
                        tmp.set(temp);
                        dealWithUnary(inPressedDigit, ref tmp);
                        tmp = null;
                    }
                    if (_operand != "")
                    {
                        if (!_flag)
                        {
                            _op1.set(_operand);
                            dealWithUnary(inPressedDigit, ref _op1);
                            if (!inPressedDigit.Equals('P'))
                                _operand = "";
                            //flipFlag();
                        }
                        else
                        {
                            _op2.set(_operand);
                            dealWithUnary(inPressedDigit, ref _op2);
                            _operand = _op2.get().ToString();
                        }
                    }
                    //dealWithUnary(inPressedDigit, re);
                    //if (!inPressedDigit.Equals('G'))
                    //     _displayState = _op1.get().ToString();
                }
                else
                {
                    if (checkBinary(inPressedDigit))
                    {
                        _binary = true;
                        if (!_flag)
                        {
                            if (_operand != "")
                            {
                                _op1.set(_operand);
                            }
                            _command = inPressedDigit;
                            //_displayState = "";
                            _operand = "";
                            flipFlag();
                        }
                        else
                        {
                            if (_operand != "")
                            {
                                _op2.set(_operand);
                                execute(_command);
                                _binary = false;
                            }
                            _command = inPressedDigit;
                            _operand = "";
                        }
                    }
                }
            }
        }

        private void execute(char command)
        {
            double operator1 = _op1.get();
            double operator2 = _op2.get();
            switch (command)
            {
                case '+':
                    _op1.set((operator1 + operator2).ToString());
                    break;
                case '-':
                    _op1.set((operator1 - operator2).ToString());
                    break;
                case '*':
                    _op1.set((operator1 * operator2).ToString());
                    break;
                case '/':
                    _op1.set((operator1 / operator2).ToString());
                    break;
            }
            _displayState = _op1.get().ToString();
         }

        private bool checkBinary(char pressedDigit)
        {
            string binary = "+-*/";

            //char.ToUpper(pressedDigit);
            if (binary.Contains(pressedDigit))
                return true;
            else
                return false;
        }

        private void flipFlag()
        {
            if (_flag)
                _flag = false;
            else
                _flag = true;
        }

        public string GetCurrentDisplayState()
        {
            if (_op1.error)
                return "-E-";
            else
            {
                CultureInfo culture = CultureInfo.CreateSpecificCulture("HR");
                int dec = 0;
                string display = "0";
                if (_displayState != "0")
                    display = clearZeros();
                foreach (char c in display)
                {
                    if ((c != ',') && (c != '-'))
                        dec++;
                    else if (c == '-')
                        continue;
                    else break;
                }
                dec = 10 - dec;
                if (display.Equals("-E-"))
                    return display;
                else
                {
                    display = Math.Round(double.Parse(display, culture), dec).ToString();
                    return display;
                }
            }
        }

        private bool checkUnary(char pressedDigit)
        {
            string unary = "SKTQRIPGM";

            char.ToUpper(pressedDigit);
            if(unary.Contains(pressedDigit))
                return true;
            else
                return false;
        }

        private void dealWithUnary(char command, ref Operand op)
        {
            switch (command)
            {
                case 'M':
                    op.changeSign();
                    _displayState = op.get().ToString();
                    break;
                case 'S':
                    op.sinus();
                    _displayState = op.get().ToString();
                    break;
                case 'K':
                    op.cosinus();
                    _displayState = op.get().ToString();
                    break;
                case 'T':
                    op.tangens();
                    _displayState = op.get().ToString();
                    break;
                case 'Q':
                    op.square();
                    _displayState = op.get().ToString();
                    break;
                case 'R':
                    op.root();
                    _displayState = op.get().ToString();
                    break;
                case 'I':
                    if(!op.invers()) _displayState="-E-";
                    else _displayState = op.get().ToString();
                    break;
                case 'P':
                    memory(command);
                    break;
                case 'G':
                    memory(command);
                    break;
            }
        }

        private void memory(char PG)
        {
            if (PG.Equals('P'))
                if (!_flag)
                    _memory = _op1.get();
                else
                    _memory = _op2.get();
            else if (PG.Equals('G'))
                _displayState = _memory.ToString();
        }

        private string clearZeros()
        {
            string display=string.Empty;
            bool flag = true;
            int i = 0;

            foreach(char c in _displayState)
            {
                if ((c.Equals('0')) && (flag))
                    continue;
                else if ((c.Equals('0')) && (!flag))
                    display += c;
                else if ((c.Equals(',')&&(flag)))
                    display = "0"+c;
                else
                {
                    display += c;
                    flag = false;
                }
            }
            if (display.Length==0) display = "0";
            int cnt = 2;
            char[] splitOn = { ',' };
            string[] split = display.Split(splitOn, cnt, StringSplitOptions.None);
            if (split.Length>1)
            {
                foreach (char c in split[1])
                {
                 if (c=='0') i++;
                }
                if (i == split[1].Length)
                    display = split[0];
            }
            
            return display;
        }

        private void resetKalkulator()
        {
            //_position = 0;
            _displayState = "0";
            _operand = "";
            _memory = 0;
            _flag = false;
            _binary = false;
        }
    }
}