﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string allowedInput;
        public Display display;
        public Memory memory;
        public Operator procesor; 

        public Kalkulator() {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            allowedInput = "0123456789+-*/=,MSKTQRIPGCO";
            display = new Display();
            memory = new Memory();
            procesor = new Operator();
        }
        
        public void Press(char inPressedDigit)
        {
            if (!allowedInput.Contains(inPressedDigit))
            {
                display.setErrorMsg();
            }
            if (char.IsNumber(inPressedDigit))
            {
                procesor.numberAdd(inPressedDigit, display, memory);
            }
            else
            {
                procesor.operation(inPressedDigit, display, memory);
            }
        }

        public string GetCurrentDisplayState()
        {
            
            return display.getDisplay();
        }


    }

    public class Display {

       private double currentDisplay;
       public bool decimalPoint;
       private bool error;

        public Display() {
            this.currentDisplay = 0;
            this.decimalPoint = false;
            this.error = false;
        }
        
        public string getDisplay(){
            if (!this.error)
            {   
                if(!decimalPoint)
                    return this.currentDisplay.ToString();
                else
                    return this.currentDisplay.ToString()+",";
            }
            else return "-E-";
        }
       
        public double getDisplayNum()
        {
            return this.currentDisplay;
        }
        
        public void setDisplay(double num) {
            this.currentDisplay = this.formatDisplay(num);    
        }

        public void setErrorMsg() {
            this.error = true;
        }

        public void reset() {
            this.error = false;
            this.currentDisplay = 0;
        }

        public bool fullDisplay() {
            if (Math.Ceiling(Math.Log10(Math.Abs(getDisplayNum()))) == 10){
                return true;
            }
            else {
                return false;
            }
        }

        private double formatDisplay( double num) 
        {

            double numberOfDigis = Math.Abs(num).ToString().Replace(",", "").Length;
            if (numberOfDigis <= 10)
            {
                return num;
            }

            else {
                int nonDecimalDigitNum = Math.Abs(num).ToString().Split(',')[0].Length;

                if (nonDecimalDigitNum > 10 || num.ToString().Contains("+"))
                {
                    error = true;
                    return 0;
                }

                else 
                {
                    return Math.Round(num, 10 - nonDecimalDigitNum);
                }
            }
        }

        }

    public class Operator {

        public Operator() { 
            
        }

        public void numberAdd(char inPressedDigit, Display display,Memory memory) {
            string numberAdd = "";
            if (memory.repeatNumFlag)
            {
                if ((display.getDisplayNum() != 0 || inPressedDigit != '0') && !display.fullDisplay())
                    {

                    if (display.decimalPoint) {
                        numberAdd += ",";
                        display.decimalPoint = false;
                        }
                    numberAdd += inPressedDigit.ToString();
                    display.setDisplay(double.Parse(display.getDisplay() + numberAdd));
                    
                    }
            }

            else if (!display.fullDisplay() && !display.decimalPoint)
            {
                display.setDisplay(double.Parse(inPressedDigit.ToString()));
                
            }

            else if (!display.fullDisplay() && display.decimalPoint)
            {
                display.setDisplay(double.Parse(inPressedDigit.ToString())/10);
                display.decimalPoint = false;
            }
            memory.repeatNumFlag = true;
            memory.repeatOperationFlag = false;
            memory.lastOperationUnary = false;
        }
        
        public void operation(char inPressedDigit, Display display, Memory memory) {
            switch (inPressedDigit.ToString()) { 
                case "+":
                case "*":
                case "/":
                case "-":
                    display.decimalPoint = false;
                    if (!memory.repeatOperationFlag)
                    {
                        memory.lastOperator = display.getDisplayNum();
                        binaryOperation(display, memory);

                    }
                    memory.lastOperationUnary = false;
                    memory.lastOperation = inPressedDigit;
                    memory.repeatOperationFlag = true;
                    memory.repeatNumFlag = false;
                    memory.repeatEqualFlag = false;
                    break;

                case "M":
                    display.setDisplay(display.getDisplayNum()*-1);
                    break;

                case "S":
                    display.setDisplay(Math.Sin(display.getDisplayNum()));
                    memory.lastOperationUnary = true;
                    break;

                case "K":
                    display.setDisplay(Math.Cos(display.getDisplayNum()));
                    memory.lastOperationUnary = true;
                    break;

                case "T":
                    display.setDisplay(Math.Tan(display.getDisplayNum()));
                    memory.lastOperationUnary = true;
                    break;
                
                case "Q":
                    display.setDisplay(Math.Pow(display.getDisplayNum(),2));
                    memory.lastOperationUnary = true;
                    break;

                case "R":
                    if (display.getDisplayNum() < 0)
                    {
                        display.setErrorMsg();
                    }
                    else
                    {
                        display.setDisplay(Math.Sqrt(display.getDisplayNum()));
                        memory.lastOperationUnary = true;
                    }
                    break;

                case "I":
                    if (display.getDisplayNum() != 0)
                    {
                        display.setDisplay(Math.Pow(display.getDisplayNum(), -1));
                        memory.lastOperationUnary = true;
                    }
                    else 
                    {
                        display.setErrorMsg();
                    }
                    break;
                
                case "P":
                    memory.savedNum = display.getDisplayNum();
                    break;

                case "G":
                    memory.repeatNumFlag = false;
                    display.setDisplay(memory.savedNum);
                    break;
                
                case "C":
                    display.setDisplay(0);
                    break;
                
                case "O":
                    display.setDisplay(0);
                    display.reset();
                    memory.reset();
                    break;
                
                case ",":
                    if (!display.getDisplay().Contains(","))
                    {
                        display.decimalPoint = true;
                        if (memory.lastOperationUnary)
                        {
                            display.setDisplay(0);
                            memory.lastOperationUnary = false;
                        }
                    }
                    break;

                case "=":
                    if (!memory.repeatEqualFlag)
                    {
                        memory.lastOperator = display.getDisplayNum();
                    }
                    binaryOperation(display, memory);
                    
                    //memory.lastOperation = '+';
                    memory.repeatNumFlag = false;
                    memory.repeatOperationFlag = true;;
                    memory.repeatEqualFlag = true;

                    break;
                
            }

        }

        public void binaryOperation( Display display, Memory memory) {
            
           switch (memory.lastOperation) 
            { 

               case '+':
                    memory.ram += memory.lastOperator;
                    display.setDisplay(memory.ram); 
                    break;
                case '-':
                    memory.ram -= memory.lastOperator;
                    display.setDisplay(memory.ram); 
                    break;
                case '*':
                    memory.ram *= memory.lastOperator;
                    display.setDisplay(memory.ram); 
                    break;
                case '/':
                    if(memory.lastOperator != 0)
                    {
                        memory.ram /= memory.lastOperator;
                        display.setDisplay(memory.ram); 
                    }
                    
                    else {
                        display.setErrorMsg();
                    }
                    break;
            }
        }

    }

    public class Memory {

        public double ram;
        public double savedNum;
        public char lastOperation;
        public double lastOperator;
        public bool repeatNumFlag;
        public bool repeatOperationFlag;
        public bool repeatEqualFlag;
        public bool lastOperationUnary;
        

        public Memory() {
            reset();
        }

        public void reset() {
            this.ram = 0;
            this.savedNum = 0;
            this.lastOperator = 0;
            this.repeatNumFlag = false;
            this.repeatOperationFlag = true;
            this.lastOperation = '+';
            this.repeatEqualFlag = false;
            this.lastOperationUnary = false;
        }

    }
}
