﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    class Stock
    {
        String name;
        long shares;
        Dictionary<DateTime, Decimal> priceAtTime;

        public Stock(String name, long shares, Decimal initPrice, DateTime initTime)
        {
            this.name = name.ToLower();
            this.shares = shares;
            this.priceAtTime = new Dictionary<DateTime, decimal>();
            SetPrice(initPrice, initTime);
        }

        public String Name
        {
            get { return this.name; }
            set { this.name = value.ToLower(); }
        }

        public long Shares
        {
            get { return this.shares; }
            set
            {
                if (value <= 0)
                {
                    throw new StockExchangeException("Shares <= 0");
                }
                else { this.shares = value; }
            }
        }

        public void SetPrice(Decimal price, DateTime time)
        {
            if (price <= 0)
            {
                throw new StockExchangeException("Price <= 0");
            }

            this.priceAtTime.Add(time, price);
        }

        public Decimal GetPrice(DateTime time)
        {

            List<DateTime> keys = this.priceAtTime.Keys.ToList();
            keys.Sort();

            DateTime firstBefore = keys[0];
            foreach (DateTime key in keys)
            {
                if (key <= time)
                {
                    firstBefore = key;
                }

            }
            return this.priceAtTime[firstBefore];

        }

        public Decimal GetInitPrice()
        {
            List<DateTime> keys = this.priceAtTime.Keys.ToList();
            keys.Sort();

            DateTime first = keys[0];

            return this.priceAtTime[first];
        }

        public Decimal GetLastPrice()
        {
            List<DateTime> keys = this.priceAtTime.Keys.ToList();
            keys.Sort();
            keys.Reverse();

            DateTime last = keys[0];
            return this.priceAtTime[last];
        }
    }

    class Index
    {
        private Dictionary<string, Stock> indexStocks;
        string name;
        IndexTypes type;

        public Index(string name, IndexTypes type)
        {
            if (name == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null");
            }
            this.name = name.ToLower();

            /*potpuno bezvezna provijera, ali zadatku se traži :/ */
            if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Pajdo, pogrešan tip indexa.");
            }
            this.type = type;

            this.indexStocks = new Dictionary<string, Stock>();
        }

        public void AddStock(String stockName, Stock stock)
        {
            if (stockName == null || stock == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null.");
            }

            if (ContainsStock(stockName))
            {
                throw new StockExchangeException("Pajdo, već si dodao tu dionicu");
            }

            this.indexStocks.Add(stockName.ToLower(), stock);
        }

        public void RemoveStock(String stockName)
        {
            if (stockName == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null.");
            }

            if (!ContainsStock(stockName))
            {
                throw new StockExchangeException("Pajdo, nisi ni dodao tu dionicu");
            }

            this.indexStocks.Remove(stockName);
        }

        public bool ContainsStock(String stockName)
        {
            if (stockName == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null.");
            }

            return this.indexStocks.ContainsKey(stockName.ToLower());
        }

        public Decimal GetValue(DateTime time)
        {
            if (this.type == IndexTypes.AVERAGE)
            {
                return getAverage(time);
            }
            else
            {
                return getWeighted(time);
            }
        }

        private Decimal getAverage(DateTime time)
        {
            if (Stocks() == 0)
            {
                return 0;
            }
            else
            {
                Decimal stockSum = 0;
                foreach (Stock stock in this.indexStocks.Values)
                {
                    stockSum += stock.GetPrice(time);
                }
                return stockSum / Stocks();
            }
        }

        private Decimal getWeighted(DateTime time)
        {
            if (this.indexStocks.Count == 0)
            {
                return 0;
            }

            List<Decimal> factors = new List<Decimal>();
            List<string> keys = this.indexStocks.Keys.ToList();
            keys.Sort();

            for (int i = 0; i < keys.Count; i++)
            {
                factors.Add(this.indexStocks[keys[i]].GetPrice(time) * this.indexStocks[keys[i]].Shares);
            }

            Decimal factorsSum = factors.Sum();
            for (int i = 0; i < keys.Count; i++)
            {
                factors[i] = factors[i] / factorsSum;
            }

            Decimal retVal = 0;

            for (int i = 0; i < keys.Count; i++)
            {
                retVal += factors[i] * this.indexStocks[keys[i]].GetPrice(time);
            }

            return Math.Round(retVal, 3);
        }

        public int Stocks()
        {
            return this.indexStocks.Count;
        }
    }

    class Portfolio
    {
        string id;
        Dictionary<string, Stock> stocks;
        Dictionary<string, int> stockCount;
        public Portfolio(string id)
        {
            this.id = id;
            this.stocks = new Dictionary<string, Stock>();
            this.stockCount = new Dictionary<string, int>();
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Pogrešan broj udijela");
            }
            this.stocks.Add(stock.Name, stock);
            this.stockCount.Add(stock.Name, numberOfShares);
        }

        public void RemoveStock(string stockName)
        {
            if (stocks.Keys.Contains(stockName))
            {
                stocks.Remove(stockName);
            }
            else
            {
                throw new StockExchangeException("Ne postoji takva dionica");
            }
        }

        public void AddShares(string stockName, int numberOfShares)
        {
            if (stockCount.ContainsKey(stockName) && numberOfShares >= 0)
            {
                stockCount[stockName] += numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Ne postoji dionica s tim brojem udjela");
            }
        }

        public void RemoveShares(string stockName, int numberOfShares)
        {
            if (stockCount.ContainsKey(stockName) && (stockCount[stockName] - numberOfShares >= 0))
            {
                stockCount[stockName] -= numberOfShares;
                if (stockCount[stockName] == 0)
                {
                    RemoveStock(stockName);
                }
            }
            else
            {
                throw new StockExchangeException("Nema dovoljno takvih dionica za uklanjanje");
            }
        }

        public int GetSharesCount(string stockName)
        {
            if (stockCount.ContainsKey(stockName))
            {
                return stockCount[stockName];
            }
            else
            {
                throw new StockExchangeException("Pogrešno ime dionice");
            }
        }

        public bool IsStockPartOfPortfolio(string stockName)
        {
            bool retVal = false;
            if (stockCount.ContainsKey(stockName))
            {
                retVal = true;
            }
            return retVal;
        }

        public Decimal GetValue(DateTime timeStamp)
        {
            Decimal value = 0;
            foreach (Stock stock in stocks.Values)
            {
                value += stock.GetPrice(timeStamp) * stockCount[stock.Name];
            }
            return value;
        }

        public Decimal GetPercentChangeInValueForMonth(int Year, int Month)
        {
            Decimal startMonth = GetValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
            Decimal endMonth = GetValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            Decimal retVal = 0;
            if (startMonth != 0)
            {
                retVal = (endMonth - startMonth) / startMonth;
            }

            return 100 * retVal;
        }

        public int Count
        {
            get { return this.stocks.Count; }
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> stocks;
        private Dictionary<string, Index> indexes;
        private Dictionary<string, Portfolio> portfolio;

        public StockExchange()
        {
            this.stocks = new Dictionary<string, Stock>();
            this.indexes = new Dictionary<string, Index>();
            this.portfolio = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName.ToLower()))
            {
                throw new StockExchangeException("Pajdo, već si dodao tu dionicu");
            }
            Stock newStock = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
            this.stocks.Add(inStockName.ToLower(), newStock);
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName.ToLower()))
            {
                foreach (Index index in this.indexes.Values)
                {
                    index.RemoveStock(inStockName.ToLower());
                }

                foreach (Portfolio portfolio in this.portfolio.Values)
                {
                    portfolio.RemoveStock(inStockName.ToLower());
                }

                this.stocks.Remove(inStockName.ToLower());
            }

            throw new StockExchangeException("Pajdo, tu dionicu nisi ni dodao.");

        }

        public bool StockExists(string inStockName)
        {
            if (inStockName != null)
            {
                return this.stocks.ContainsKey(inStockName.ToLower());
            }

            throw new StockExchangeException("Pajdo, pazi na null!");

        }

        public int NumberOfStocks()
        {
            return this.stocks.Keys.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName.ToLower()))
            {
                this.stocks[inStockName.ToLower()].SetPrice(inStockValue, inIimeStamp);
            }
            else
            {
                throw new StockExchangeException("Pajdo, tu dionicu nisi ni dodao.");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName.ToLower()))
            {
                return this.stocks[inStockName.ToLower()].GetPrice(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Pajdo, tu dionicu nisi ni dodao.");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName.ToLower()))
            {
                return this.stocks[inStockName.ToLower()].GetInitPrice();
            }
            else
            {
                throw new StockExchangeException("Pajdo, tu dionicu nisi ni dodao.");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName.ToLower()))
            {
                return this.stocks[inStockName.ToLower()].GetLastPrice();
            }
            else
            {
                throw new StockExchangeException("Pajdo, tu dionicu nisi ni dodao.");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null.");
            }

            Index newIndex = new Index(inIndexName.ToLower(), inIndexType);
            this.indexes.Add(inIndexName.ToLower(), newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
            {
                throw new StockExchangeException("Pajdo pazi na nazive.");
            }

            if (IndexExists(inIndexName) && this.indexes[inIndexName.ToLower()].ContainsStock(inStockName.ToLower()))
            {
                throw new StockExchangeException("Pajdo, u ovaj index si već dodao tu dionicu");
            }

            this.indexes[inIndexName.ToLower()].AddStock(inStockName.ToLower(), this.stocks[inStockName.ToLower()]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
            {
                throw new StockExchangeException("Pajdo pazi na nazive.");
            }

            if (!IndexExists(inIndexName.ToLower()))
            {
                throw new StockExchangeException("Pajdo, ne možeš brisati dionicu iz indexa, koja nije u indexu");
            }

            this.indexes[inIndexName].RemoveStock(inStockName.ToLower());
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName) || !StockExists(inStockName))
            {
                throw new StockExchangeException("Pajdo pazi na nazive.");
            }

            return this.indexes[inIndexName.ToLower()].ContainsStock(inStockName.ToLower());
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (IndexExists(inIndexName))
            {
                return this.indexes[inIndexName.ToLower()].GetValue(inTimeStamp);
            }

            throw new StockExchangeException("Pajdo, ne postoji ti index s time imenom.");
        }

        public bool IndexExists(string inIndexName)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null");
            }

            return this.indexes.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return this.indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (inIndexName == null || !IndexExists(inIndexName.ToLower()))
            {
                throw new StockExchangeException("Pajdo pazi na null i na postojanje indexa");
            }

            return this.indexes[inIndexName.ToLower()].Stocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null");
            }

            this.portfolio.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    if (enoughFreeStockShares(inStockName, numberOfShares))
                    {
                        this.portfolio[inPortfolioID].AddStock(this.stocks[inStockName.ToLower()], numberOfShares);
                    }
                }
                else
                {
                    if (enoughFreeStockShares(inStockName, numberOfShares))
                    {
                        this.portfolio[inPortfolioID].AddShares(inStockName.ToLower(), numberOfShares);
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena dionica i portofila");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()))
            {
                this.portfolio[inPortfolioID].RemoveShares(inStockName.ToLower(), numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena dionica i portofila");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()))
            {
                this.portfolio[inPortfolioID].RemoveStock(inStockName.ToLower());
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena dionica i portofila");
            }
        }

        public int NumberOfPortfolios()
        {
            return this.portfolio.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return this.portfolio[inPortfolioID].Count;
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena portofila");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Pajdo, pazi na null");
            }

            return this.portfolio.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()))
            {
                return this.portfolio[inPortfolioID].IsStockPartOfPortfolio(inStockName.ToLower());
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena dionica i portofila");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()))
            {
                return this.portfolio[inPortfolioID].GetSharesCount(inStockName.ToLower());
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena dionica i portofila");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return this.portfolio[inPortfolioID].GetValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena portofila");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return this.portfolio[inPortfolioID].GetPercentChangeInValueForMonth(Year, Month);
            }
            else
            {
                throw new StockExchangeException("Pajdo, pazi na imena portofila");
            }
        }

        private bool enoughFreeStockShares(string stockName, int shareCount)
        {
            int soldShares = 0;
            foreach (Portfolio portfolio in this.portfolio.Values)
            {
                if (portfolio.IsStockPartOfPortfolio(stockName.ToLower()))
                {
                    soldShares += portfolio.GetSharesCount(stockName.ToLower());
                }
            }

            bool retVal = false;
            if (StockExists(stockName.ToLower()))
            {
                if (stocks[stockName.ToLower()].Shares - soldShares >= shareCount)
                {
                    retVal = true;
                }
            }

            return retVal;
        }
    }
}
