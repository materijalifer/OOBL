using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        #region Vars
        /// <summary>
        /// Lista dionica
        /// </summary>
        List<Stock> _stocks = new List<Stock>();

        /// <summary>
        /// Lista indeksa
        /// </summary>
        List<Index> _indices = new List<Index>();
        
        /// <summary>
        /// Popis portfolia
        /// </summary>
        Dictionary<string, Portfolio> _portfolios = new Dictionary<string,Portfolio>();
        #endregion

        #region Stocks
        /// <summary>
        /// Dodavanje dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inNumberOfShares">Broj dionica</param>
        /// <param name="inInitialPrice">Početna cijena</param>
        /// <param name="inTimeStamp">Početak ponude</param>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (this.StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica sa zadanim imenom već postoji");
            }
            else
            {
                this._stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
        }

        /// <summary>
        /// Micanje dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        public void DelistStock(string inStockName)
        {
            Stock stock = this.GetStock(inStockName);

            foreach (Index index in this._indices)
            {
                if (index.HasStock(stock))
                {
                    index.RemoveStock(stock);
                }
            }
            foreach (KeyValuePair<string, Portfolio> portfolio in this._portfolios)
            {
                if (portfolio.Value.HasStock(stock))
                {
                    portfolio.Value.RemoveStock(stock);
                }
            }

            this._stocks.Remove(stock);
        }

        /// <summary>
        /// Dohvati dionicu prema imenu
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Tražena dionica</returns>
        private Stock GetStock(string inStockName)
        {
            foreach (Stock stock in this._stocks)
            {
                if (stock.CheckName(inStockName))
                {
                    return stock;
                }
            }
            throw new StockExchangeException("Dionica nije nađena");
        }

        /// <summary>
        /// Provjera postoji li dionica u sustavu
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>true ukoliko dionica postoji, false u suprotnom</returns>
        public bool StockExists(string inStockName)
        {
            foreach (Stock stock in this._stocks)
            {
                if (stock.CheckName(inStockName))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Broj dionica u sustavu
        /// </summary>
        /// <returns>Broj dionica</returns>
        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

        /// <summary>
        /// Postavljanje cijene dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inIimeStamp">Početak važenja cijene</param>
        /// <param name="inStockValue">Cijena dionice</param>
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            this.GetStock(inStockName).SetPrice(inStockValue, inIimeStamp);
        }

        /// <summary>
        /// Dohvaćanje cijene dionice za određeni trenutak
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <param name="inTimeStamp">Vrijeme u koje nas zanima cijena dionice</param>
        /// <returns>Cijena dionice</returns>
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return this.GetStock(inStockName).GetPrice(inTimeStamp);
        }

        /// <summary>
        /// Dohvaćanje početne cijene dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Početna cijena dionice</returns>
        public decimal GetInitialStockPrice(string inStockName)
        {
            return this.GetStock(inStockName).GetInitialStockPrice();
        }

        /// <summary>
        /// Dohvaćanje zadnje cijene dionice
        /// </summary>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Zadnja cijena dionice</returns>
        public decimal GetLastStockPrice(string inStockName)
        {
            return this.GetStock(inStockName).GetLastStockPrice();
        }
        #endregion

        #region Indices
        /// <summary>
        /// Dodavanje indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inIndexType">Vrsta indeksa</param>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (this.IndexExists(inIndexName))
            {
                throw new StockExchangeException("Indeks sa zadanim imenom već postoji");
            }
            else if (inIndexType == IndexTypes.AVERAGE)
            {
                this._indices.Add(new AverageIndex(inIndexName));
            }
            else if (inIndexType == IndexTypes.WEIGHTED)
            {
                this._indices.Add(new WeightedIndex(inIndexName));
            }
            else
            {
                throw new StockExchangeException("Zadana vrsta indeksa ne postoji");
            }
        }

        /// <summary>
        /// Dohvaćanje indeksa prema imenu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <returns>Traženi indeks</returns>
        private Index GetIndex(string inIndexName)
        {
            foreach (Index index in this._indices)
            {
                if (index.CheckName(inIndexName))
                {
                    return index;
                }
            }
            throw new StockExchangeException("Indeks nije nađen");
        }

        /// <summary>
        /// Dodavanje dionice u indeks
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv dionice</param>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            this.GetIndex(inIndexName).AddStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Micanje dionice iz indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv dionice</param>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            this.GetIndex(inIndexName).RemoveStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Provjera sadrži li zadani indeks traženu dionicu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inStockName">Naziv tražene dionice</param>
        /// <returns>true ukoliko indeks sadrži dionicu, false u suprotnom</returns>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return this.GetIndex(inIndexName).HasStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Dohvaćanje vrijednosti indeksa u nekom trenutku
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <param name="inTimeStamp">Vrijeme u koje nas zanima vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return this.GetIndex(inIndexName).IndexValue(inTimeStamp);
        }

        /// <summary>
        /// Provjera postoji li indeks u sustavu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <returns>true ukoliko indeks postoji, false u suprotnom</returns>
        public bool IndexExists(string inIndexName)
        {
            foreach (Index index in this._indices)
            {
                if (index.CheckName(inIndexName))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Broj indeksa u sustavu
        /// </summary>
        /// <returns>Broj indeksa u sustavu</returns>
        public int NumberOfIndices()
        {
            return this._indices.Count;
        }

        /// <summary>
        /// Dohvaćanje broja dionica u indeksu
        /// </summary>
        /// <param name="inIndexName">Naziv indeksa</param>
        /// <returns>Broj dionica u indeksu</returns>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            return this.GetIndex(inIndexName).NumberOfStocks();
        }
        #endregion

        #region Portfolios
        /// <summary>
        /// Kreiranje portfolia
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        public void CreatePortfolio(string inPortfolioID)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio već postoji");
            }
            else
            {
                this._portfolios.Add(inPortfolioID, new Portfolio());
            }
        }

        /// <summary>
        /// Dodavanje dionica u portfolio
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="inStockName">Naziv dionice koja se dodaje</param>
        /// <param name="numberOfShares">Broj dionica koje se dodaju</param>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = this.GetPortfolio(inPortfolioID);

            Stock stock = this.GetStock(inStockName);
            long number = stock.GetNumberOfShares() - numberOfShares;
            foreach (KeyValuePair<string, Portfolio> portf in this._portfolios)
            {
                number -= portf.Value.HasStock(stock) ? portf.Value.NumberOfSharesOfStock(stock) : 0;
            }

            if (number < 0)
            {
                throw new StockExchangeException("U portfolijima se nalazi više dionica nego ih je dostupno");
            }
            else
            {
                portfolio.AddStock(stock, numberOfShares);
            }
        }

        /// <summary>
        /// Micanje dionica iz portfolia
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="inStockName">Naziv dionice koja se miče</param>
        /// <param name="numberOfShares">Broj dionica koje se miču</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            this.GetPortfolio(inPortfolioID).RemoveStock(this.GetStock(inStockName), numberOfShares);
        }

        /// <summary>
        /// Micanje svih dionica zadanog naziva iz portfolia
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="inStockName">Naziv dionice koja se miče</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            this.GetPortfolio(inPortfolioID).RemoveStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Dohvaća broj portfolia u sustavu
        /// </summary>
        /// <returns></returns>
        public int NumberOfPortfolios()
        {
            return this._portfolios.Count;
        }

        /// <summary>
        /// Dohvaća broj dionica u portfoliu
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <returns>Broj dionica u portfoliu</returns>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return this.GetPortfolio(inPortfolioID).NumberOfStocks();
        }

        /// <summary>
        /// Provjera postoji li portfolio sa zadanim nazivom u sustavu
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <returns>true ako portfolio postoji, false u suprotnom</returns>
        public bool PortfolioExists(string inPortfolioID)
        {
            return this._portfolios.ContainsKey(inPortfolioID);
        }

        /// <summary>
        /// Dohvaća portfolio prema nazivu
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <returns>Traženi portfolio</returns>
        private Portfolio GetPortfolio(string inPortfolioID)
        {
            if (this._portfolios.ContainsKey(inPortfolioID))
            {
                return this._portfolios[inPortfolioID];
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji");
            }
        }

        /// <summary>
        /// Provjerava je li zadana dionica sadržana u portfoliu
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>true ako portfolio sadržava dionicu, false u suprotnom</returns>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return this.GetPortfolio(inPortfolioID).HasStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Dohvaća broj dionica zadanog naziva u portfoliu
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="inStockName">Naziv dionice</param>
        /// <returns>Broj dionica u portfoliu</returns>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return this.GetPortfolio(inPortfolioID).NumberOfSharesOfStock(this.GetStock(inStockName));
        }

        /// <summary>
        /// Dohvaća vrijednost portfolia u zadanim trenutku
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="timeStamp">Vrijeme u koje nas zanima vrijednost portfolia</param>
        /// <returns>Vrijednost portfolia</returns>
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return this.GetPortfolio(inPortfolioID).GetValue(timeStamp);
        }

        /// <summary>
        /// Dohvaća promjenu vrijednosti portfolia u mjesecu (u postocima)
        /// </summary>
        /// <param name="inPortfolioID">Naziv portfolia</param>
        /// <param name="Year">Godina koja nas zanima</param>
        /// <param name="Month">Mjesec koji nas zanima</param>
        /// <returns>Promjena vrijednosti portfolia</returns>
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return this.GetPortfolio(inPortfolioID).GetPercentChangeInValueForMonth(Year, Month);
        }
        #endregion
    }
    
    
    /// <summary>
    /// Dionica
    /// </summary>
    public class Stock
    {
        /// <summary>
        /// Naziv dionice
        /// </summary>
        private string _name;

        /// <summary>
        /// Broj dionica
        /// </summary>
        private long _numberOfShares;

        /// <summary>
        /// Početna cijena dionica
        /// </summary>
        private decimal _inInitialPrice;

        /// <summary>
        /// Cijena dionica kroz vrijeme
        /// </summary>
        private Dictionary<DateTime, decimal> _value = new Dictionary<DateTime,decimal>();

        /// <summary>
        /// Dionica
        /// </summary>
        /// <param name="name">Naziv dionice</param>
        /// <param name="numberOfShares">Broj dionica</param>
        /// <param name="inInitialPrice">Početna cijena dionica</param>
        /// <param name="inTimeStamp">Vrijeme početka trgovanja dionicama</param>
        public Stock(string name, long numberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena dionice mora biti pozitivna");
            }

            else if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica mora biti pozitivan");
            }

            this._name = name;
            this._numberOfShares = numberOfShares;
            this._inInitialPrice = inInitialPrice;
            this._value.Add(inTimeStamp, inInitialPrice);
        }

        /// <summary>
        /// Provjera imena dionice
        /// </summary>
        /// <param name="name">Ime dionice koja se provjerava</param>
        /// <returns>Vraća true ako je to dionica koja se traži</returns>
        public bool CheckName(string name)
        {
            return this._name.ToUpper() == name.ToUpper();
        }

        /// <summary>
        /// Postavljanje nove vrijednosti dionica
        /// </summary>
        /// <param name="inStockValue">Nova vrijednost dionica</param>
        /// <param name="inTimeStamp">Vrijeme kada cijena počinje vrijediti</param>
        public void SetPrice(decimal inStockValue, DateTime inTimeStamp)
        {
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Cijena dionice mora biti pozitivna");
            }

            if (this._value.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Cijena dionice je već definirana za ovo vrijeme");
            }

            this._value.Add(inTimeStamp, inStockValue);
        }

        /// <summary>
        /// Dohvaćanje cijene dionica u određenom trenutku
        /// </summary>
        /// <param name="inTimeStamp">Vrijeme za koje nas zanima cijena dionica</param>
        /// <returns>Cijena dionica</returns>
        public decimal GetPrice(DateTime inTimeStamp)
        {
            decimal? price = null;

            foreach (KeyValuePair<DateTime, decimal> value in this._value.OrderBy(p => p.Key))
            {
                if (value.Key <= inTimeStamp)
                {
                    price = value.Value;
                }
                else
                {
                    break;
                }
            }

            if (price == null)
            {
                throw new StockExchangeException("Za zadano vrijeme nije definirana cijena dionice");
            }
            else
            {
                return Math.Round((decimal)price, 3);
            }
        }

        /// <summary>
        /// Broj dionica
        /// </summary>
        /// <returns>Broj dionica</returns>
        public long GetNumberOfShares()
        {
            return this._numberOfShares;
        }

        /// <summary>
        /// Početna cijena dionica
        /// </summary>
        /// <returns>Početna cijena dionica</returns>
        public decimal GetInitialStockPrice()
        {
            return Math.Round(this._inInitialPrice, 3);
        }

        /// <summary>
        /// Zadnja cijena dionica
        /// </summary>
        /// <returns>Zadnja cijena dionica</returns>
        public decimal GetLastStockPrice()
        {
            return Math.Round(this._value.OrderBy( p => p.Key ).Last().Value, 3);
        }
    }
    
    
    /// <summary>
    /// Burzovni indeks
    /// </summary>
    public abstract class Index
    {
        /// <summary>
        /// Naziv indeksa
        /// </summary>
        protected string _name;

        /// <summary>
        /// Popis dionica koje indeks sadrži
        /// </summary>
        protected List<Stock> _stocks = new List<Stock>();

        /// <summary>
        /// Provjera imena indeksa
        /// </summary>
        /// <param name="name">Ime indeksa koji se provjerava</param>
        /// <returns>Vraća true ako je to indeks koji se traži</returns>
        public bool CheckName(string name)
        {
            return this._name.ToUpper() == name.ToUpper();
        }

        /// <summary>
        /// Dodavanje dionice u indeks
        /// </summary>
        /// <param name="stock">Dionica koja se dodaje</param>
        public void AddStock(Stock stock)
        {
            if (this._stocks.Contains(stock))
            {
                throw new StockExchangeException("Dionica već postoji u indeksu");
            }
            else
            {
                this._stocks.Add(stock);
            }
        }

        /// <summary>
        /// Brisanje dionice iz indeksa
        /// </summary>
        /// <param name="stock">Dionica koja se briše</param>
        public void RemoveStock(Stock stock)
        {
            if (this._stocks.Contains(stock))
            {
                this._stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji u indeksu");
            }
        }

        /// <summary>
        /// Provjera sadrži li indeks dionicu
        /// </summary>
        /// <param name="stock">Dionica koja se provjerava</param>
        /// <returns>True ako indeks sadrži dionicu, false u suprotnom</returns>
        public bool HasStock(Stock stock)
        {
            return this._stocks.Contains(stock);
        }

        /// <summary>
        /// Vraća broj dionica u indeksu
        /// </summary>
        /// <returns>Broj dionica u indeksu</returns>
        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

        /// <summary>
        /// Izračunava vrijenosti indeksa sa zadani datum
        /// </summary>
        /// <param name="inTimeStamp">Datum za koji se izračunava vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public abstract decimal IndexValue(DateTime inTimeStamp);
    }

    /// <summary>
    /// Burzovni indeks čija se vrijednost računa kao jednostavan prosjek cijene svih dionica u indeksu
    /// </summary>
    public class AverageIndex : Index
    {
        /// <summary>
        /// Konstruktor burzovnog indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv burzovnog indeksa</param>
        public AverageIndex(string inIndexName)
        {
            this._name = inIndexName;
        }

        /// <summary>
        /// Izračunava vrijenosti indeksa sa zadani datum
        /// </summary>
        /// <param name="inTimeStamp">Datum za koji se izračunava vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public override decimal IndexValue(DateTime inTimeStamp)
        {
            decimal stockValueSum = 0;
            int stockCount = 0;

            foreach (Stock stock in this._stocks)
            {
                stockValueSum += stock.GetPrice(inTimeStamp);
                stockCount++;
            }

            if (stockCount > 0)
            {
                return Math.Round(stockValueSum / stockCount, 3);
            }
            else
            {
                return 0;
            }
        }
    }

    /// <summary>
    /// Burzovni indeks čija se vrijednost računa kao težinski prosjek cijene svih dionica u indeksu,
    /// gdje je težinski faktor za pojedinu dionicu definiran kao omjer ukupne vrijednosti
    /// te dionice na burzi (cijena dionice * broj dionica) i ukupne vrijednosti svih dionica unutar indeksa
    /// </summary>
    public class WeightedIndex : Index
    {
        /// <summary>
        /// Konstruktor burzovnog indeksa
        /// </summary>
        /// <param name="inIndexName">Naziv burzovnog indeksa</param>
        public WeightedIndex(string inIndexName)
        {
            this._name = inIndexName;
        }
        
        /// <summary>
        /// Izračunava vrijenosti indeksa sa zadani datum
        /// </summary>
        /// <param name="inTimeStamp">Datum za koji se izračunava vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public override decimal IndexValue(DateTime inTimeStamp)
        {
            decimal stockValueSum = 0;

            // Ukupna vrijednost dionica
            foreach (Stock stock in this._stocks)
            {
                stockValueSum += stock.GetPrice(inTimeStamp) * stock.GetNumberOfShares();
            }

            decimal weightdStockValueSum = 0;

            foreach (Stock stock in this._stocks)
            {
                decimal price = stock.GetPrice(inTimeStamp);
                weightdStockValueSum += stock.GetPrice(inTimeStamp) * stock.GetPrice(inTimeStamp) * stock.GetNumberOfShares() / stockValueSum;
            }

            return Math.Round(weightdStockValueSum, 3);
        }
    }
    
    
    /// <summary>
    /// Portfolio
    /// </summary>
    class Portfolio
    {
        /// <summary>
        /// Popis dionica i njihovog broja u portfoliu
        /// </summary>
        Dictionary<Stock, long> _stocks = new Dictionary<Stock, long>();

        /// <summary>
        /// Dodavanje dionica u portfolio
        /// </summary>
        /// <param name="stock">Dionica koja se dodaje</param>
        /// <param name="numberOfShares">Koliko ih se dodaje</param>
        public void AddStock(Stock stock, long numberOfShares)
        {
            if (this._stocks.ContainsKey(stock))
            {
                this._stocks[stock] += numberOfShares;
            }
            else
            {
                this._stocks.Add(stock, numberOfShares);
            }
        }

        /// <summary>
        /// Micanje dionica iz portfolia
        /// </summary>
        /// <param name="stock">Dionica koja se miče</param>
        /// <param name="numberOfShares">Koliko ih se miče</param>
        public void RemoveStock(Stock stock, long numberOfShares)
        {
            if (this._stocks.ContainsKey(stock))
            {
                if (this._stocks[stock] <= numberOfShares)
                {
                    throw new StockExchangeException("Broj dionica mora biti pozitivan");
                }
                else
                {
                    this._stocks[stock] -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Dionice nema u portfoliu");
            }
        }

        /// <summary>
        /// Micanje svih dionica iz portfolia
        /// </summary>
        /// <param name="stock">Dionica koja se miče</param>
        public void RemoveStock(Stock stock)
        {
            if (this._stocks.ContainsKey(stock))
            {
                this._stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Dionice nema u portfoliu");
            }
        }

        /// <summary>
        /// Broj dionica u portfoliu
        /// </summary>
        /// <returns></returns>
        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

        /// <summary>
        /// Provjera sadrži li portfolio dionicu
        /// </summary>
        /// <param name="stock">Dionica koja se provjerava</param>
        /// <returns>True ako portfolio sadrži dionicu, false u suprotnom</returns>
        public bool HasStock(Stock stock)
        {
            return this._stocks.ContainsKey(stock);
        }

        /// <summary>
        /// Broj dionica jedne vrste u portfelju
        /// </summary>
        /// <param name="stock">Tražena dionica</param>
        /// <returns>Broj dionica</returns>
        public int NumberOfSharesOfStock(Stock stock)
        {
            if (this._stocks.ContainsKey(stock))
            {
                return (int)this._stocks[stock];
            }
            else
            {
                throw new StockExchangeException("Dionice nema u portfoliu");
            }
        }

        /// <summary>
        /// Vrijednost portfolia u nekom zadanom trenutku
        /// </summary>
        /// <param name="inTimeStamp">Vrijeme u kojem nas zanima vrijednost</param>
        /// <returns>Vrijednost portfolia</returns>
        public decimal GetValue(DateTime inTimeStamp)
        {
            decimal value = 0;

            foreach (KeyValuePair<Stock, long> stock in this._stocks)
            {
                value += stock.Value * stock.Key.GetPrice(inTimeStamp);
            }

            return Math.Round(value, 3);
        }

        /// <summary>
        /// Promjena vrijednosti portfolia u mjesecu (u postocima)
        /// </summary>
        /// <param name="year">Godina koja nas zanima</param>
        /// <param name="month">Mjesec koji nas zanima</param>
        /// <returns>Promjena vrijednosti portfolia</returns>
        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            DateTime start = new DateTime(year, month, 1, 0, 0, 0);
            decimal startValue = this.GetValue(start);

            DateTime end = new DateTime(year, month, 1, 0, 0, 0).AddMonths(1).AddSeconds(-1);
            decimal endValue = this.GetValue(end);

            return Math.Round((startValue - endValue) / startValue * 100, 3);
        }
    }
}
