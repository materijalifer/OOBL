﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Portfolio
     {
     }

     class Stock
     {
         private StockExchangeException _ex;

         private readonly string _name;
         private readonly SortedDictionary<DateTime, decimal> _dicPrices;

         public long NumberOfShares
         {
             get { return _numberOfShares; }
         }

         private readonly long _numberOfShares;

         /*      public decimal StartingPrice
               {
                   get { return _startingPrice; }
               }
               */
         public string Name
         {
             get { return _name; }
         }


         /* private readonly decimal _startingPrice;
          private DateTime _definingDate;*/


         /**
          * Konstuktor koji stvara novi objekt dionice.
          * Ime dionice je postavljeno na mala slova.
          * 
          */
         public Stock(string name, long numberOfShares, decimal startingPrice, DateTime definingDate)
         {
             CheckData(numberOfShares, startingPrice);
             _name = name;
             _numberOfShares = numberOfShares;
             //_startingPrice = startingPrice;
             //_definingDate = definingDate;
             _dicPrices = new SortedDictionary<DateTime, decimal> { { definingDate, startingPrice } };
         }

         public Stock(string inStockName)
         {
             _name = inStockName;
             _numberOfShares = 0;
             //            _startingPrice = 0;
             //            _definingDate = new DateTime();
             _dicPrices = null;

         }

         private void CheckData(long numberOfStocks, decimal startingPrice)
         {
             if (numberOfStocks < 0)
             {
                 _ex = new StockExchangeException("Inserted negative number of stocks!!");
                 throw _ex;
             }
             if (startingPrice > 0) return;
             _ex = new StockExchangeException("Price of stock is zero or negative!!");
             throw _ex;
         }

         /**
          * Metoda koja dodaje cijenu dionice za odredjeno vrijeme.
          * 
          * throws exception u slucaju dodavanja cijene u isto vrijeme
          * 
          */
         public void SetPriceOnDate(decimal price, DateTime date)
         {
             if (_dicPrices.ContainsKey(date))
             {
                 _ex = new StockExchangeException("Already contains defining price for that time...");
                 throw _ex;
             }
             _dicPrices.Add(date, price);

         }

         /**
          * Metoda koja vraca vrijednost dionice za odredeno vrijeme.
          * 
          */
         public decimal GetPriceOnDate(DateTime date)
         {
             var maxDate = GetMaximumLowerDateIndex(date);
             return _dicPrices[maxDate];

         }

         private DateTime GetMaximumLowerDateIndex(DateTime checkingDate)
         {
             if (!(_dicPrices.Keys.First().CompareTo(checkingDate) < 0))
             {
                 throw new StockExchangeException("Price was not defined for that date");

             }
             foreach (var date in _dicPrices.Keys.Where(date => !(date.CompareTo(checkingDate) < 0)))
             {
                 return date;
             }
             return _dicPrices.Keys.Last();
         }

         /**
          * Metoda koja vraca zadnju vrijednost dionice.
          * 
          */
         public decimal GetLastPrice()
         {
             return _dicPrices.Last().Value;

         }

         /**
          * Metoda koja vraca inicialnu vrijednost.
          */
         public decimal GetInitialPrice()
         {
             return _dicPrices.First().Value;

         }

         public override int GetHashCode()
         {
             return Convert.ToInt32(_name.ToLower());
         }

         public override bool Equals(object obj)
         {
             var other = obj as Stock;
             return other != null && _name.ToLower().Equals(other._name.ToLower());
         }
     }

     class Index
     {
         private readonly string _nameOfIndex;
         private readonly IndexTypes _type;
         private readonly List<Stock> _listStocks;

         public Index(string nameOfIndex, IndexTypes type)
         {
             _nameOfIndex = nameOfIndex;
             if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Type of index is not good!!");

             }
             _type = type;
             _listStocks = new List<Stock>();

         }

         public Index(string inIndexName)
         {
             _nameOfIndex = inIndexName;
             _type = 0;
             _listStocks = null;
         }

         public bool ContainsStock(Stock stock)
         {
             return _listStocks.Contains(stock);

         }

         public void AddStock(Stock stock)
         {
             if (_listStocks.Contains(stock))
             {
                 throw new StockExchangeException("Stock already exists in index");

             }
             _listStocks.Add(stock);
             //IndexValue = _type.Equals(IndexTypes.AVERAGE) ? CalculateIndexValueAverage() : CalculateIndexValueWeighted();


         }

         public decimal GetIndexValue(DateTime date)
         {
             return _type.Equals(IndexTypes.AVERAGE) ? GetIndexValueAverage(date) : GetIndexValueWeighted(date);

         }

         private decimal GetIndexValueWeighted(DateTime date)
         {
             var sumPrice = _listStocks.Sum(stock => stock.NumberOfShares * stock.GetPriceOnDate(date));
             var listWeightedFact = _listStocks.Select(stock => stock.GetPriceOnDate(date) / sumPrice).ToList();
             var index = 0;
             var weightedValue = 0m;
             foreach (var stock in _listStocks)
             {
                 for (var i = 0; i < stock.NumberOfShares; i++)
                 {
                     weightedValue += stock.GetPriceOnDate(date) * listWeightedFact[index];

                 }
                 index++;

             }
             return weightedValue;

         }

         private decimal GetIndexValueAverage(DateTime date)
         {
             var sumPrice = _listStocks.Sum(stock => stock.GetPriceOnDate(date));
             return sumPrice / _listStocks.Count;

         }

         public void RemoveStock(Stock stock)
         {
             if (!_listStocks.Contains(stock))
             {
                 throw new StockExchangeException("Trying to delete not existing stock!!");
             }
             _listStocks.Remove(stock);
         }


         public override int GetHashCode()
         {
             return Convert.ToInt32(_nameOfIndex.ToLower());
         }

         public override bool Equals(object obj)
         {
             var other = obj as Index;
             return other != null && _nameOfIndex.ToLower().Equals(other._nameOfIndex.ToLower());

         }


         internal int GetNumberOfStockes()
         {
             return _listStocks.Count;
         }
     }

     public class StockExchange : IStockExchange
     {

         private readonly List<Stock> _listStocks;
         private readonly List<Index> _listIndex;
         private List<Portfolio> _listPortfolio;
         //private StockExchangeException _ex;

         public StockExchange()
         {
             _listPortfolio = new List<Portfolio>();
             _listIndex = new List<Index>();
             _listStocks = new List<Stock>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Stock already exists in stock market!!");

             }
             var newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp); 
             _listStocks.Add(newStock);
             
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {

                 throw new StockExchangeException("Trying to delete stock that does not exist on stock market!!");

             }
             var stock = new Stock(inStockName);
             foreach (var index in _listIndex.Where(index => index.ContainsStock(stock)))
             {
                 index.RemoveStock(stock);

             }
             _listStocks.Remove(stock);
             

         }

         public bool StockExists(string inStockName)
         {
             var stock = new Stock(inStockName);
             return _listStocks.Contains(stock);

         }

         public int NumberOfStocks()
         {
             return _listStocks.Count;

         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             var index = _listStocks.IndexOf(new Stock(inStockName));
             _listStocks[index].SetPriceOnDate(inStockValue, inIimeStamp);

         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             var index = _listStocks.IndexOf(new Stock(inStockName));
             return _listStocks[index].GetPriceOnDate(inTimeStamp);

         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             var index = _listStocks.IndexOf(new Stock(inStockName));
             return _listStocks[index].GetInitialPrice();

         }

         public decimal GetLastStockPrice(string inStockName)
         {
             var index = _listStocks.IndexOf(new Stock(inStockName));
             return _listStocks[index].GetLastPrice();
         }

         //TODO
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index already exists!!");

             }
             _listIndex.Add(new Index(inIndexName, inIndexType));

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             CheckExistance(inIndexName, inStockName);
             var iStock = _listStocks.IndexOf(new Stock(inStockName));
             var iIndex = _listIndex.IndexOf(new Index(inIndexName));
             
             _listIndex[iIndex].AddStock(_listStocks[iStock]);

         }

         private void CheckExistance(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Trying to add stock that does not exists on stock market to index!!");
             }
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Trying to add stock to index that does not exists!!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             CheckExistance(inIndexName, inStockName);
             var stock = GetStockOfName(inStockName);
             
             var index = GetIndexOutOfName(inIndexName);
             index.RemoveStock(stock);
             
         }

         private Index GetIndexOutOfName(string inIndexName)
         {
             var iIndex = _listIndex.IndexOf(new Index(inIndexName));
             return _listIndex[iIndex];
              
         }

         private Stock GetStockOfName(string inStockName)
         {
             var iStock = _listStocks.IndexOf(new Stock(inStockName));
             return _listStocks[iStock];
              
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndexOutOfName(inIndexName).ContainsStock(GetStockOfName(inStockName));

         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return GetIndexOutOfName(inIndexName).GetIndexValue(inTimeStamp);

         }

         public bool IndexExists(string inIndexName)
         {
             return _listIndex.Contains(new Index(inIndexName));
         }

         public int NumberOfIndices()
         {
             return _listIndex.Count;

         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             var index = GetIndexOutOfName(inIndexName);
             return index.GetNumberOfStockes();

         }

         public void CreatePortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfPortfolios()
         {
             return _listPortfolio.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
     }
}
