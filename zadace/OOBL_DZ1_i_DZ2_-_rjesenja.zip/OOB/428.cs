﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private State currentState;
        private String display;
        private IBinaryOper prevOperation;
        private String firstOperand;
        private String memory;

        
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                currentState.pressDigit(this, inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case('+'): 
                        currentState.pressBinaryOperation(this, OperAddition.Instance);
                        break;
                    case('-'):
                        currentState.pressBinaryOperation(this, OperSubtraction.Instance);
                        break;
                    case('*'):
                        currentState.pressBinaryOperation(this, OperMultiplication.Instance);
                        break;
                    case('/'):
                        currentState.pressBinaryOperation(this, OperDivision.Instance);
                        break;
                    case('='):
                        currentState.pressEqual(this);
                        break;
                    case(','):
                        currentState.pressPoint(this);
                        break;
                    case('M'):
                        currentState.pressUnaryOperation(this, OperMinus.Instance);
                        break;
                    case('S'):
                        currentState.pressUnaryOperation(this, OperSinus.Instance);
                        break;
                    case('K'):
                        currentState.pressUnaryOperation(this, OperKosinus.Instance);
                        break;
                    case('T'):
                        currentState.pressUnaryOperation(this, OperTangens.Instance);
                        break;
                    case('Q'):
                        currentState.pressUnaryOperation(this, OperQuadrat.Instance);
                        break;
                    case('R'):
                        currentState.pressUnaryOperation(this, OperRoot.Instance);
                        break;
                    case('I'):
                        currentState.pressUnaryOperation(this, OperInverse.Instance);
                        break;
                    case('P'):
                        currentState.pressPut(this);
                        break;
                    case('G'):
                        currentState.pressGet(this);
                        break;
                    case('C'):
                        currentState.pressClear(this);
                        break;
                    case('O'):
                        currentState.pressReset(this);
                        break;
                    default:
                        currentState.pressReset(this);
                        break;

                }
            }
                
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        public Kalkulator()
        {
            currentState = StartState.Instance;
            display = "0";
            memory = "";
        }

        // getters and setters

        public State CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }
        

        public String Display
        {
            get { return display; }
            set { display = value; }
        }
        

        public IBinaryOper PrevOperation
        {
            get { return prevOperation; }
            set { prevOperation = value; }
        }

        public String Memory
        {
            get { return memory; }
            set { memory = value; }
        }


        public String FirstOperand
        {
            get { return firstOperand; }
            set { firstOperand = value; }
        }
        
    }

    public abstract class State
    {
        // abstract class which other states inherit
        // some methods are common for all of the states, but most of them are overriden by every concrete state, to provide adequate functionality 

        public abstract void pressDigit(Kalkulator calc, char digit);
        public abstract void pressPoint(Kalkulator calc);
        public abstract void pressEqual(Kalkulator calc);

        public virtual void pressBinaryOperation(Kalkulator calc, IBinaryOper operation)
        {
            // if there is some operation waiting, first execute that operation
            if (calc.PrevOperation != null)
            {
                double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
                if (Double.IsInfinity(res) || Double.IsNaN(res))
                {
                    calc.Display = "-E-";
                    calc.CurrentState = ErrorState.Instance;
                    return;
                }
                calc.Display = res.ToString();
                calc.Display = roundResult(calc, calc.Display);
            }
            // move the unneccessary zeros after the decimal point if there are any
            calc.Display = Double.Parse(calc.Display).ToString();
            calc.PrevOperation = operation;
            calc.FirstOperand = calc.Display;
            calc.CurrentState = ComputeState.Instance;
        }

        public virtual void pressUnaryOperation(Kalkulator calc, IUnaryOper operation)
        {
            double res = operation.compute(Double.Parse(calc.Display));
            if (Double.IsInfinity(res) || Double.IsNaN(res))
            {
                calc.Display = "-E-";
                calc.CurrentState = ErrorState.Instance;
                return;
            }
            calc.Display = res.ToString();
            calc.Display = roundResult(calc, calc.Display);
        }

        public virtual void pressClear(Kalkulator calc)
        {
            calc.Display = "0";
        }

        public virtual void pressReset(Kalkulator calc)
        {
            calc.CurrentState = StartState.Instance;
            calc.Display = "0";
            calc.PrevOperation = null;
            calc.Memory = "";
        }

        public virtual void pressPut(Kalkulator calc)
        {
            calc.Memory = calc.Display;
        }

        public virtual void pressGet(Kalkulator calc)
        {
            if (!String.IsNullOrEmpty(calc.Memory))
            {
                calc.Display = calc.Memory;
                calc.CurrentState = AccumulateState.Instance;
            }

        }

        /// <summary>
        /// method which checks if integer part of a number is over 10 digits
        /// (in that case, go to the error state)
        /// if the integer part is ok, method checks rounds the fractional part if neccessary
        /// </summary>
        public virtual String roundResult(Kalkulator calc, String x)
        {
            String[] number = x.Split(',');
            String integerPart = number[0];
            int lengthInteger = integerPart.Replace("-", "").Length;

            if (lengthInteger > 10)
            {
                calc.CurrentState = ErrorState.Instance;
                return "-E-";
            }

            if (x.Contains(','))
            {
                String fractionalPart = number[1];
                x = Math.Round(Double.Parse(x), 10 - lengthInteger).ToString();
                return x;

            }
            return integerPart;
        }
    }

    public class StartState : State
    {
        // starting state
        // this state represents the initial condition
        private static readonly StartState instance = new StartState();
        private StartState() { }

        public static StartState Instance
        {
            get
            {
                return instance;
            }
        }


        
        public override void pressDigit(Kalkulator calc, char digit)
        {
            // if the digit isn't zero, go to the accumulate state
            if (!digit.Equals('0'))
            {
                calc.Display = digit.ToString();
                calc.CurrentState = AccumulateState.Instance;
            }
        }

        public override void pressPoint(Kalkulator calc)
        {
            // if the decimal point is pressed, add it to the number and go to the decimal state
            calc.Display += ",";
            calc.CurrentState = DecimalState.Instance;
        }


        public override void pressEqual(Kalkulator calc)
        {
            if (calc.PrevOperation != null)
            {
                double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
                if (Double.IsInfinity(res) || Double.IsNaN(res))
                {
                    calc.Display = "-E-";
                    calc.CurrentState = ErrorState.Instance;
                    return;
                }
                calc.Display = res.ToString();
                calc.PrevOperation = null;
            }

        }
    }


    public class AccumulateState : State
    {
        // in the accumulate state, it's neccessary to enter this state when the digits must concatenate and the number doesn't contain the decimal point
        private static readonly AccumulateState instance = new AccumulateState();
        private AccumulateState() { }

        public static AccumulateState Instance
        {
            get
            {
                return instance;
            }
        }


        public override void pressDigit(Kalkulator calc, char digit)
        {
            // calculator works with only 10 digits, digits entered after that limit are ignored
            if (calc.Display.Replace(",", "").Replace("-", "").Length < 10)
            {
                calc.Display += digit.ToString();
            }

        }

        public override void pressPoint(Kalkulator calc)
        {
            // condition is for case that number in memory has decimal point already ("G" case), so the current state must be decimal state without adding the decimal point
            if (!calc.Display.Contains(','))
            {
                calc.Display += ",";
            }
            calc.CurrentState = DecimalState.Instance;
        }

        public override void pressEqual(Kalkulator calc)
        {
            if (calc.PrevOperation != null)
            {
                double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
                if (Double.IsInfinity(res) || Double.IsNaN(res))
                {
                    calc.Display = "-E-";
                    calc.CurrentState = ErrorState.Instance;
                    return;
                }
                calc.Display = res.ToString();
                calc.Display = roundResult(calc, calc.Display);
                calc.PrevOperation = null;
            }
        }
    }

    public class ComputeState : State
    {

        // compute state is entered when one of the binary operators is pressed
        private static readonly ComputeState instance = new ComputeState();
        private ComputeState() { }

        public static ComputeState Instance
        {
            get
            {
                return instance;
            }
        }


        public override void pressDigit(Kalkulator calc, char digit)
        {
            calc.Display = digit.ToString();
            calc.CurrentState = AccumulateState.Instance;
        }

        public override void pressPoint(Kalkulator calc)
        {
            calc.Display = "0,";
            calc.CurrentState = DecimalState.Instance;
        }


        public override void pressEqual(Kalkulator calc)
        {
            double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
            if (Double.IsInfinity(res) || Double.IsNaN(res))
            {
                calc.Display = "-E-";
                calc.CurrentState = ErrorState.Instance;
                return;
            }
            calc.Display = res.ToString();
            calc.CurrentState = StartState.Instance;
            calc.Display = roundResult(calc, calc.Display);
        }

        // In compute state, the base method for pressing the binary operation must be overriden,
        // because compute state means that the last entry was operation, and in case of multiple operations,
        // every operation except the last one is ignored 
        public override void pressBinaryOperation(Kalkulator calc, IBinaryOper operation)
        {
            calc.Display = Double.Parse(calc.Display).ToString();
            calc.PrevOperation = operation;
            calc.FirstOperand = calc.Display;
            calc.CurrentState = ComputeState.Instance;
        }

        // pressing the unary operation must also be overriden, because the state must change to computing unary operations

        public override void pressUnaryOperation(Kalkulator calc, IUnaryOper operation)
        {
            calc.CurrentState = ComputeStateUnary.Instance;
            base.pressUnaryOperation(calc, operation);
        }

    }

    public class ComputeStateUnary : State
    {
        // this state is almost like the compute state for binary operations, except it inherits the pressBinaryOperation from the base class
        // in this case, last binary operation is not ignored- it is also executed

        private static readonly ComputeStateUnary instance = new ComputeStateUnary();
        private ComputeStateUnary() { }

        public static ComputeStateUnary Instance
        {
            get
            {
                return instance;
            }
        }


        public override void pressDigit(Kalkulator calc, char digit)
        {
            calc.Display = digit.ToString();
            calc.CurrentState = AccumulateState.Instance;
        }

        public override void pressPoint(Kalkulator calc)
        {
            calc.Display = "0,";
            calc.CurrentState = DecimalState.Instance;
        }


        public override void pressEqual(Kalkulator calc)
        {
            double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
            if (Double.IsInfinity(res) || Double.IsNaN(res))
            {
                calc.Display = "-E-";
                calc.CurrentState = ErrorState.Instance;
                return;
            }
            calc.Display = res.ToString();
            calc.CurrentState = StartState.Instance;
            calc.Display = roundResult(calc, calc.Display);
        }
    }

    public class DecimalState : State
    {
        // this is the state to enter when the number has decimal point. 
        private static readonly DecimalState instance = new DecimalState();
        private DecimalState() { }

        public static DecimalState Instance
        {
            get
            {
                return instance;
            }
        }

        public override void pressDigit(Kalkulator calc, char digit)
        {
            int g = calc.Display.Replace(",", "").Replace("-", "").Length;
            // calculator works with only 10 digits, digits entered after that limit are ignored
            if (calc.Display.Replace(",", "").Replace("-", "").Length < 10)
            {
                calc.Display += digit.ToString();
            }
        }

        public override void pressPoint(Kalkulator calc)
        {
            // point is already there, nothing to do
        }

        public override void pressEqual(Kalkulator calc)
        {
            if (calc.PrevOperation != null)
            {
                double res = calc.PrevOperation.compute(Double.Parse(calc.FirstOperand), Double.Parse(calc.Display));
                if (Double.IsInfinity(res) || Double.IsNaN(res))
                {
                    calc.Display = "-E-";
                    calc.CurrentState = ErrorState.Instance;
                    return;
                }
                calc.Display = res.ToString();
                calc.CurrentState = ComputeState.Instance;
                calc.Display = roundResult(calc, calc.Display);
            }
            else
            {
                // move the unneccessary zeros after the decimal point if there are any
                calc.Display = Double.Parse(calc.Display).ToString();
                calc.CurrentState = StartState.Instance;
            }
        }
    }

    public class ErrorState : State
    {
        // in error state, nothing except reset and clear has an effect

        private static readonly ErrorState instance = new ErrorState();
        private ErrorState() { }

        public static ErrorState Instance
        {
            get
            {
                return instance;
            }
        }


        // pressing clear in error state has the same function as pressing the reset 
        public override void pressClear(Kalkulator calc)
        {
            base.pressReset(calc);
        }

        public override void pressBinaryOperation(Kalkulator calc, IBinaryOper operation)
        {
        }

        public override void pressUnaryOperation(Kalkulator calc, IUnaryOper operation)
        {
        }

        public override void pressDigit(Kalkulator calc, char digit)
        {
        }

        public override void pressPoint(Kalkulator calc)
        {
        }

        public override void pressEqual(Kalkulator calc)
        {
        }

        public override void pressGet(Kalkulator calc)
        {
        }

        public override void pressPut(Kalkulator calc)
        {
        }
    }

    public interface IBinaryOper
    {
        double compute(double x, double y);
    }

    public interface IUnaryOper
    {
        double compute(double x);
    }


    public class OperAddition : IBinaryOper
    {
        private static readonly OperAddition instance = new OperAddition();
        private OperAddition() { }

        public static OperAddition Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x, double y)
        {
            return x + y;
        }

    }

    public class OperDivision : IBinaryOper
    {
        private static readonly OperDivision instance = new OperDivision();
        private OperDivision() { }

        public static OperDivision Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x, double y)
        {
            return x / y;
        }
    }

    public class OperInverse : IUnaryOper
    {
        private static readonly OperInverse instance = new OperInverse();
        private OperInverse() { }

        public static OperInverse Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return 1 / x;
        }
    }

    public class OperKosinus : IUnaryOper
    {
        private static readonly OperKosinus instance = new OperKosinus();
        private OperKosinus() { }

        public static OperKosinus Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return Math.Cos(x);
        }
    }

    public class OperMinus : IUnaryOper
    {
        private static readonly OperMinus instance = new OperMinus();
        private OperMinus() { }

        public static OperMinus Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return x * (-1);
        }
    }

    public class OperMultiplication : IBinaryOper
    {
        private static readonly OperMultiplication instance = new OperMultiplication();
        private OperMultiplication() { }

        public static OperMultiplication Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x, double y)
        {
            return x * y;
        }
    }

    public class OperQuadrat : IUnaryOper
    {
        private static readonly OperQuadrat instance = new OperQuadrat();
        private OperQuadrat() { }

        public static OperQuadrat Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return Math.Pow(x, 2);
        }
    }

    public class OperRoot : IUnaryOper
    {
        private static readonly OperRoot instance = new OperRoot();
        private OperRoot() { }

        public static OperRoot Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return Math.Sqrt(x);
        }
    }

    public class OperSinus : IUnaryOper
    {
        private static readonly OperSinus instance = new OperSinus();
        private OperSinus() { }

        public static OperSinus Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return Math.Sin(x);
        }
    }

    public class OperSubtraction : IBinaryOper
    {
        private static readonly OperSubtraction instance = new OperSubtraction();
        private OperSubtraction() { }

        public static OperSubtraction Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x, double y)
        {
            return x - y;
        }
    }

    public class OperTangens : IUnaryOper
    {
        private static readonly OperTangens instance = new OperTangens();
        private OperTangens() { }

        public static OperTangens Instance
        {
            get
            {
                return instance;
            }
        }

        public double compute(double x)
        {
            return Math.Tan(x);
        }
    }


}
