using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
   

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private char[] ekran = { '0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' }; //stanje na ekranu
        private double rezultat = Double.NaN;
        private double memorija = Double.NaN;
        private char posljednjiOperator = '\0';
        private bool ocistiEkranPrijeUnosaZnamenke = false;
        private bool kalkulatorUpaljen = true;
              

        public void Press(char inPressedDigit)
        {

            //throw new NotImplementedException();
            //char tipka = inPressedDigit;

            if (this.znakJeZnamenka(inPressedDigit))
            {
                char zadnjiZnak = reciZadnjiZnakEkrana();
                //if (znakJeBinarniOperator(zadnjiZnak))
                //{
                //    this.posljednjiOperator = zadnjiZnak;
                //    this.brisiEkran();
                //}

                if (this.ocistiEkranPrijeUnosaZnamenke)
                {
                    //if (this.stisnutBinarniOperator)
                    //{
                       // this.osvjeziRezultat();
                    //    this.stisnutBinarniOperator = false;
                    //}
                    this.ocistiEkranPrijeUnosaZnamenke = false;
                    this.brisiEkran();
                }
                this.dodajZnamenkuNaEkran(inPressedDigit);

            }
            else if (inPressedDigit == ',')
            {
                this.dodajZarezNaEkran();
            }
            else if (inPressedDigit == 'C')
            {
                this.brisiEkran();
            }
            /*
            else if (this.znakJePredznak(inPressedDigit))
            {
                if (inPressedDigit == '-')//mjenjam predznak               {
                {
                    this.promijeniPredznak();
                }//ako je '+', ne radim nista jer na ekranu vec jest samo 0 (pozitivna nula)
            }
             * */
            else if (this.znakJeBinarniOperator(inPressedDigit))
            {
                //if (this.znakJeBinarniOperator(this.reciZadnjiZnakEkrana()))
                //{
                //    dogodioSeError();
                //    return;
                //}
                this.ocistiEkranPrijeUnosaZnamenke = true;
                this.posljednjiOperator = inPressedDigit;

                this.osvjeziRezultat(); //veliki upitnik????????????????
                //this.stisnutBinarniOperator = true;

                this.brisiKrajnjeNuleSEkrana();
                //this.posljednjiOperator = inPressedDigit;

                //this.dodajOperatorNaEkran(inPressedDigit);
            }
            else if (this.znakJeUnarniOperator(inPressedDigit))
            {
                
                this.ocistiEkranPrijeUnosaZnamenke = true;
                double temp = this.ekranUVarijablu();
                double trezultat;

                if (inPressedDigit == 'M')
                {
                    if (this.naEkranuSamoNula())
                    {
                        return;
                    }
                    else
                    {
                        ocistiEkranPrijeUnosaZnamenke = false;
                        this.promijeniPredznak();
                    }
                }
                else if (inPressedDigit == 'Q')
                {
                    trezultat = temp * temp;
                    if (this.brojViseOd10Znamenki(trezultat))
                    {
                        this.dogodioSeError();
                        return;
                    }
                    this.varijablaUEkran(trezultat);
                }
                else if (inPressedDigit == 'R')
                {
                    if (temp < 0)
                    {
                        this.dogodioSeError();
                        return;
                    }
                    else
                    {
                        trezultat = Math.Sqrt(temp);
                        if (this.brojViseOd10Znamenki(trezultat))
                        {
                            this.dogodioSeError();
                            return;
                        }
                        this.varijablaUEkran(trezultat);
                    }
                }
                else if (inPressedDigit == 'I')
                {
                    trezultat = 1 / temp;
                    if (this.brojViseOd10Znamenki(trezultat))
                    {
                        this.dogodioSeError();
                        return;
                    }
                    this.varijablaUEkran(trezultat);
                }
                else if (inPressedDigit == 'S')
                {
                    trezultat = Math.Sin(temp);
                    if (this.brojViseOd10Znamenki(trezultat))
                    {
                        this.dogodioSeError();
                        return;
                    }
                    this.varijablaUEkran(trezultat);
                }
                else if (inPressedDigit == 'K')
                {
                    trezultat = Math.Cos(temp);
                    if (this.brojViseOd10Znamenki(trezultat))
                    {
                        this.dogodioSeError();
                        return;
                    }
                    this.varijablaUEkran(trezultat);
                }
                else if (inPressedDigit == 'T')
                {
                    trezultat = Math.Tan(temp);
                    if (this.brojViseOd10Znamenki(trezultat))
                    {
                        this.dogodioSeError();
                        return;
                    }
                    this.varijablaUEkran(trezultat);
                }



            }
            else if (inPressedDigit == '=')
            {
                this.ocistiEkranPrijeUnosaZnamenke = true;

                if (skraceniZapis())
                {
                    //this.posljednjiOperator = skiniZadnjiZnakEkrana();

                    //Console.WriteLine(GetCurrentDisplayState() + "ds---");
                    this.rezultat = ekranUVarijablu();
                    //Console.WriteLine(GetCurrentDisplayState() + "ds--2");
                    //Console.WriteLine(this.rezultat + "rz--2");
                }
                this.osvjeziRezultat();
                //Console.WriteLine(GetCurrentDisplayState() + "--3");
                //Console.WriteLine(this.rezultat + "rz--3");
                this.brisiEkran();
                //this.varijablaUEkran(this.rezultat);
                if (this.zaokruziRezultat() == false) //prevelik broj
                {
                    this.dogodioSeError();
                    this.rezultat = Double.NaN;
                    return;
                }
                this.varijablaUEkran(this.rezultat);
                this.rezultat = Double.NaN;
            }
            else if (inPressedDigit == 'P')
            {
                if (this.znakJeZnamenka(this.reciZadnjiZnakEkrana()) == false)
                {
                    this.dogodioSeError();
                    return;
                }
                this.memorija = this.ekranUVarijablu();
            }
            else if (inPressedDigit == 'G')
            {
                if (this.memorija == Double.NaN)
                {
                    this.dogodioSeError();
                    return;
                }

                char zadnjiZnak = this.reciZadnjiZnakEkrana();
                if (this.znakJeBinarniOperator(zadnjiZnak))
                {
                    this.posljednjiOperator = zadnjiZnak;
                    this.brisiEkran();
                }

                this.varijablaUEkran(this.memorija);
            }
            else if (inPressedDigit == 'O')
            {
                if (this.kalkulatorUpaljen)
                {
                    this.ugasiKalkulator();
                }
                else
                {
                    this.upaliKalkulator();
                }
            }
            else
            {
                //Console.WriteLine("Dovrsi.");
            }





            this.zaokruziEkran();
            if (inPressedDigit == '=')
            {
                this.brisiKrajnjeNuleSEkrana();
            }
            return;

        }

        public string GetCurrentDisplayState()
        {
            //throw new NotImplementedException();

            short brojac = 0;

            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == '\0')
                {
                    //brojac++;
                    break;
                }
                brojac++;
            }

            char[] temp = new char[brojac];

            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == '\0')
                {
                    //temp[i] = this.ekran[i];
                    break;
                }
                temp[i] = this.ekran[i];
            }

            return new string(temp);
        }
        private void dogodioSeError() //ispis "-E-" na ekran
        {
            this.brisiEkran();
            this.ekran[0] = '-';
            this.ekran[1] = 'E';
            this.ekran[2] = '-';
            return;
        }

        private bool naEkranuSamoNula() //da znam kako cu dodati znamenku i je li '-' operator ili predznak koji ide na ekran
        {
            if (this.ekran[0] == '0' && this.ekran[1] == '\0')//ostale znamenke su sigurno '\0'
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool naEkranuManjeOd10Znamenki()
        {

            short brZn = 0;
            foreach (char temp in ekran)
            {
                if (temp >= '0' && temp <= '9')
                {
                    brZn++;
                }

            }

            if (brZn > 9)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        private void dodajZnamenkuNaEkran(char znamenka)
        {
            if (this.naEkranuSamoNula())
            {
                this.ekran[0] = znamenka;
                return;
            }
            if (this.ekran[0] == '-' && this.ekran[1] == '0' && this.ekran[2] == '\0') //negativna nula
            {
                this.ekran[1] = znamenka;
                return;
            }
            if (this.naEkranuManjeOd10Znamenki())
            {
                for (short i = 0; i < 12; i++)
                {
                    if (this.ekran[i] == '\0')
                    {
                        this.ekran[i] = znamenka;
                        return;
                    }
                }
            }
            else
            {
                //zaokruzi?
                return;
            }

        }

        private void dodajZarezNaEkran()
        {
            if (this.brojNaEkranuJeDecimalan())
            {
                //this.dogodioSeError();
                return;
            }
            else
            {
                for (short i = 0; i < 12; i++)
                {
                    if (this.ekran[i] == '\0')
                    {
                        this.ekran[i] = ',';
                        return;
                    }

                }
            }
        }

        private bool znakJeZnamenka(char znak)
        {
            if (znak >= '0' && znak <= '9')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void brisiEkran()
        {
            this.ekran[0] = '0';
            for (short i = 1; i < 12; i++)
            {
                this.ekran[i] = '\0';
            }
            return;
        }
        /*
        private bool znakJePredznak(char znak)
        {
            if ((znak == '+' || znak == '-') && this.naEkranuSamoNula())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
         * */
        private void promijeniPredznak()
        {
            if (this.ekran[0] == '-')
            {
                for (short i = 0; i < 11; i++)
                {
                    this.ekran[i] = this.ekran[i + 1];
                }
                this.ekran[11] = '\0';
                // -0,123456789
                // 0,123456789
            }
            else
            {
                for (short i = 11; i > 0; i--)
                {
                    this.ekran[i] = this.ekran[i - 1];
                }
                this.ekran[0] = '-';
            }
            return;
        }
        private bool znakJeBinarniOperator(char znak)
        {
            //if (this.znakJePredznak( znak ))
            //{
            //    return false;
            //}
            if (znak == '+' || znak == '-' || znak == '*' || znak == '/')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool znakJeUnarniOperator(char znak)
        {
            if (znak == 'M' || znak == 'S' || znak == 'K' || znak == 'T' || znak == 'Q' || znak == 'R' || znak == 'I')
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        private double ekranUVarijablu()
        {
            
            if (this.ekran[0] == '\0')
            {
                return 0;
            }
            
            string temp = new string(this.ekran);
            string temp2 = temp.Replace(',', '.');
            return System.Convert.ToDouble(temp2);
            
        }
        private void varijablaUEkran(double var)
        {
            this.brisiEkran();
            var = Math.Round(var, 10 - this.reciKolikoZnamenkiImaCjelobrojniDioBroja(var));
            string temp = var.ToString();
            string temp2 = temp.Replace('.', ',');
            short i = 0;
            foreach (char c in temp2)
            {
                this.ekran[i] = c;
                i++;
                if (i > 11)//ne stane
                {
                    break;
                }
            }
            return;
        }

        private char skiniZadnjiZnakEkrana()
        {
            if (this.ekran[0] == '\0')
            {
                return '\0';
            }
            char zadnjiZnak = '\0';
            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == '\0')
                {
                    this.ekran[i - 1] = '\0';
                    break;
                }
                zadnjiZnak = this.ekran[i];
            }
            return zadnjiZnak;
        }

        private void dodajZnakNaKrajEkrana(char znak)
        {
            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == '\0')
                {
                    this.ekran[i] = znak;
                    break;
                }
            }
        }

        private void brisiKrajnjeNuleSEkrana()
        {

            if (this.brojNaEkranuJeDecimalan())
            {
                for (short i = 11; i > 0; i--)
                {
                    if (this.ekran[i] == '0' || this.ekran[i] == '\0')
                    {
                        this.ekran[i] = '\0';
                    }
                    else if (this.ekran[i] == ',')
                    {
                        this.ekran[i] = '\0';
                        break;
                    }
                    else
                    {
                        break;
                    }
                }
            }

        }

        private void upaliKalkulator()
        {
            this.ekran = new char[] { '0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' }; //stanje na ekranu
            this.rezultat = Double.NaN;
            this.memorija = Double.NaN;
            this.posljednjiOperator = '\0';
            this.ocistiEkranPrijeUnosaZnamenke = false;
            this.kalkulatorUpaljen = true;
        }
        private void ugasiKalkulator()
        {
            this.ekran = new char[] { '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' }; //stanje na ekranu
            this.rezultat = Double.NaN;
            this.memorija = Double.NaN;
            this.posljednjiOperator = '\0';
            this.ocistiEkranPrijeUnosaZnamenke = false;
            this.kalkulatorUpaljen = false;
        }



        private void zaokruziEkran() //ako je rezultat nakon neke operacije premasio 10 znamenki, popravit treba
        {

            char zadnjiZnak = this.skiniZadnjiZnakEkrana();
            bool vratiKasnije = false;
            if (this.znakJeBinarniOperator(zadnjiZnak))
            {
                vratiKasnije = true;
            }
            else
            {
                this.dodajZnakNaKrajEkrana(zadnjiZnak);
            }

            //Console.WriteLine("VVV");
            //Console.WriteLine(this.GetCurrentDisplayState());
            //Console.WriteLine("AAA");


            if (this.brojNaEkranuJeDecimalan() && this.ekran[0] == '-')
            {
                //za sad ne diram nista. Moze biti i ekran[11] != '\0'
            }
            else if ((this.brojNaEkranuJeDecimalan() && this.ekran[0] != '-')
                  || (this.brojNaEkranuJeDecimalan() == false && this.ekran[0] == '-')) // ekran[11] ne smije biti znamenka!!!
            {
                this.ekran[11] = '\0';
                //this.rezultat = this.ekranUVarijablu();
            }
            else if (this.brojNaEkranuJeDecimalan() == false && this.ekran[0] != '-') // ni ekran[10] ne smije biti znamenka!
            {
                this.ekran[11] = '\0';
                this.ekran[10] = '\0';
                //this.rezultat = this.ekranUVarijablu();
            }




            if (vratiKasnije)
            {
                this.dodajZnakNaKrajEkrana(zadnjiZnak);
            }

        }
        private bool zaokruziRezultat() //varijabla rezultat mora isto imati 10 znamenki. Ako zaokruzujem cjelobrojni dio vraca false!
        {
            if (Double.IsNaN(this.rezultat))
            {
                return true;
            }
            if (this.reciKolikoZnamenkiImaCjelobrojniDioBroja(this.rezultat) > 10)
            {
                //Console.WriteLine("dakdasdlasdkj");
                return false;
            }
            /*
            string temp = this.rezultat.ToString();
            
            short dozvoljenaDuzinaNiza = 12;
            bool nemaDecToc = false;

            
            Console.WriteLine(temp);

            if (temp.Contains('.') == false) //broj nema decimalne tocke
            {
                nemaDecToc = true;
                dozvoljenaDuzinaNiza--;
            }
            if (temp.Contains('-') == false) //broj nema minus u sebi
            {
                dozvoljenaDuzinaNiza--;
            }

            //char[] temp2 = { '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0' };

            if (temp.Length > dozvoljenaDuzinaNiza && nemaDecToc) //znaci broj je cjelobrojan i veci od 10 znamenki. Ne smije se to.
            {
                return false;
            }
            */

            this.rezultat = Math.Round(this.rezultat, 10 - this.reciKolikoZnamenkiImaCjelobrojniDioBroja(this.rezultat));
            return true;
        }
        private short reciKolikoZnamenkiImaCjelobrojniDioBroja(double broj)
        {
            string temp = broj.ToString();
            short cjelobrojniDio = 0;
            for (short i = 0; i < temp.Length; i++)
            {
                if (temp[i] == '.' || temp[i] == ',')
                {
                    break;
                }
                if (temp[i] != '-')
                {
                    cjelobrojniDio++;
                }
            }
            return cjelobrojniDio;
        }

        private bool brojNaEkranuJeDecimalan()
        {
            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == ',')
                {
                    return true;
                }
            }
            return false;

        }
        private void dodajOperatorNaEkran(char oper)
        {
            for (short i = 0; i < 12; i++)
            {
                if (this.ekran[i] == '\0')
                {
                    this.ekran[i] = oper;
                    return;
                }
            }
        }
        private char reciZadnjiZnakEkrana()
        {
            for (short i = 0; i < 11; i++)
            {
                if (this.ekran[i] != '\0' && this.ekran[i + 1] == '\0')
                {
                    return this.ekran[i];
                }
            }
            return this.ekran[11];
        }
        private void osvjeziRezultat() // znaci: rezultat <- rezultat posljednjiOperator ekran 
        {                               // dogodi se nakon sto netko stisne binarni operator ili '='
            if (this.posljednjiOperator == '+')
            {
                if (Double.IsNaN(this.rezultat))
                {
                    this.rezultat = this.ekranUVarijablu();
                }
                else
                {
                    this.rezultat += this.ekranUVarijablu();
                }
            }
            else if (this.posljednjiOperator == '-')
            {

                //Console.WriteLine(this.GetCurrentDisplayState() + "ds--4");
                //Console.WriteLine(this.rezultat + "rz--4");
                if (Double.IsNaN(this.rezultat))
                {
                    this.rezultat = this.ekranUVarijablu();
                }
                else
                {
                    this.rezultat -= this.ekranUVarijablu();
                    //Console.WriteLine(this.rezultat + "rz--555");
                }
            }
            else if (this.posljednjiOperator == '*')
            {
                if (Double.IsNaN(this.rezultat))
                {
                    this.rezultat = this.ekranUVarijablu();
                }
                else
                {
                    this.rezultat *= this.ekranUVarijablu();
                }
            }
            else if (this.posljednjiOperator == '/')
            {
                if (Double.IsNaN(this.rezultat))
                {
                    this.rezultat = this.ekranUVarijablu();
                }
                else
                {
                    this.rezultat /= this.ekranUVarijablu();
                }
            }
            else if (this.posljednjiOperator == '\0')
            {
                this.rezultat = this.ekranUVarijablu();
            }

        }
        private bool brojViseOd10Znamenki(double broj)
        {
            if (broj <= -9999999999.5 || broj >= 9999999999.5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool skraceniZapis()
        {
            if (this.znakJeBinarniOperator(this.reciZadnjiZnakEkrana()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
