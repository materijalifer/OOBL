﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza {
    public static class Factory {
        public static IStockExchange CreateStockExchange() {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange {
        Dictionary<string, StockWithMarketCount> stocksAvalible = new Dictionary<string, StockWithMarketCount>();
        Dictionary<string, Index> indexesAvalible = new Dictionary<string, Index>();
        Dictionary<string, Portfolio> portfoliosAvalible = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp) {
            if (!stocksAvalible.ContainsKey(inStockName.ToLower())) {
                StockWithMarketCount newStock = new StockWithMarketCount(inStockName, inNumberOfShares, inTimeStamp, inInitialPrice);
                stocksAvalible.Add(inStockName.ToLower(), newStock);
            }
            else {
                throw new StockExchangeException("Stock already exists");
            }
        }

        public void DelistStock(string inStockName) {
            try {
                stocksAvalible.Remove(inStockName);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }

        }

        public bool StockExists(string inStockName) {
            try {
                return stocksAvalible.ContainsKey(inStockName.ToLower());

            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public int NumberOfStocks() {
            return stocksAvalible.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue) {
            try {
                StockWithMarketCount stockToModify = this.findStock(inStockName);
                stockToModify.setNewPrice(inIimeStamp, inStockValue);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                return stockSearch.getStockValue(inTimeStamp);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public decimal GetInitialStockPrice(string inStockName) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                return stockSearch.getInitialStockValue();
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public decimal GetLastStockPrice(string inStockName) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                return stockSearch.getLastStockValue();
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType) {
            if (!indexesAvalible.ContainsKey(inIndexName.ToLower())) {
                Index newIndex = new Index(inIndexName, inIndexType);
                this.indexesAvalible.Add(inIndexName.ToLower(), newIndex);
            }
            else {
                throw new StockExchangeException("Index postoji");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                Index indexSearch = this.findIndex(inIndexName);
                indexSearch.addStock(stockSearch);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                Index indexSearch = this.findIndex(inIndexName);
                indexSearch.removeStock(stockSearch);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName) {
            try {
                StockWithMarketCount stockSearch = this.findStock(inStockName);
                Index indexSearch = this.findIndex(inIndexName);
                return indexSearch.hasStock(stockSearch);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp) {
            try {
                Index indexSearch = this.findIndex(inIndexName);
                return indexSearch.getValue(inTimeStamp);
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public bool IndexExists(string inIndexName) {
            return indexesAvalible.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices() {
            return this.indexesAvalible.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName) {
            try {                
                Index indexSearch = this.findIndex(inIndexName);;
                return indexSearch.getStockCount();
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        public void CreatePortfolio(string inPortfolioID) {
            if (!portfoliosAvalible.ContainsKey(inPortfolioID)) {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                this.portfoliosAvalible.Add(inPortfolioID, portfolio);
            }
            else {
                throw new StockExchangeException("Portfolio already exists");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares) {
            StockWithMarketCount stock = this.findStock(inStockName);
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            stock.transferToPortfolio(portfolio, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares) {
            StockWithMarketCount stock = this.findStock(inStockName);
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            stock.transferFromPortfolio(portfolio, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName) {
            StockWithMarketCount stock = this.findStock(inStockName);
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            stock.removeFromPortfolio(portfolio);
        }

        public int NumberOfPortfolios() {
            return portfoliosAvalible.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID) {
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            return portfolio.numberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID) {
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            return (portfolio != null);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName) {
            StockWithMarketCount stock = this.findStock(inStockName);
            Portfolio portfolio = this.findPortfolio(inPortfolioID);

            return portfolio.hasStock(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName) {
            StockWithMarketCount stock = this.findStock(inStockName);
            Portfolio portfolio = this.findPortfolio(inPortfolioID);

            return portfolio.numberOfShares(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp) {
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            return decimal.Round(portfolio.getPortfolioValue(timeStamp));
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month) {
            Portfolio portfolio = this.findPortfolio(inPortfolioID);
            decimal startValue = portfolio.getPortfolioValue(new DateTime(Year, Month,                                1 , 0 , 0 , 00, 000));
            decimal endValue = portfolio.getPortfolioValue(  new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            return decimal.Round(100 - ((startValue / endValue) * 100), 3);
        }

        private Portfolio findPortfolio(string name) {
            try {
                Portfolio portfolioSearch = portfoliosAvalible[name];
                return portfolioSearch;
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }            
        }

        private Index findIndex(string name) {
            try {
                Index indexoSearch = indexesAvalible[name.ToLower()];
                return indexoSearch;
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }

        private StockWithMarketCount findStock(string name) {
            try {
                StockWithMarketCount stockSearch = stocksAvalible[name.ToLower()];
                return stockSearch;
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }
        }
    }

    class Stock : IComparable<Stock> {

        private class StockValue : IComparable<StockValue> {
            DateTime time;

            public DateTime Time {
                get {
                    return time;
                }
            }

            decimal value;

            public decimal Value {
                get {
                    return this.value;
                }
            }

            public StockValue(DateTime time, decimal value) {
                this.time = time;
                this.value = value;
            }

            public int CompareTo(StockValue other) {
                return this.time.CompareTo(other.time);
            }

            public bool isValid(DateTime time) {
                if (this.time <= time)
                    return true;
                else
                    return false;
            }

        };

        private string stockName;
        private long stockCount;


        private List<StockValue> prices;

        public Stock(string stockName, long stockCount, DateTime validirtyStart, decimal stockValue) {
            if (stockValue <= 0)
                throw new StockExchangeException("Stock price not valid");
            if (stockCount < 0)
                throw new StockExchangeException("Stock count not valid");

            this.stockName = stockName;
            this.stockCount = stockCount;
            this.prices = new List<StockValue>();
            this.prices.Add(new StockValue(validirtyStart, stockValue));
        }

        public void setNewPrice(DateTime validirtyStart, decimal stockValue) {
            try {
                if (this.prices.Exists(stock => stock.Time == validirtyStart)) 
                    throw new StockExchangeException("Time exists");
                this.prices.Add(new StockValue(validirtyStart, stockValue));
            }
            catch (ArgumentException ex) {
                throw new StockExchangeException(ex.Message);
            }
            this.prices.Sort();
        }

        public decimal getStockValue(DateTime time) {
            try {
                StockValue validValue = prices.Last<StockValue>(stockValue => stockValue.isValid(time));
                return validValue.Value;
            }
            catch (Exception ex) {
                throw new StockExchangeException(ex.Message);
            }

        }


        public decimal getWeightStockValue(DateTime time) {
            return this.getStockValue(time) * stockCount;

        }

        public int CompareTo(Stock other) {
            return this.stockName.ToLower().CompareTo(other.stockName.ToLower());
        }

        public bool Equals(string name) {
            return this.stockName.ToLower().Equals(name.ToLower());
        }

        public decimal getInitialStockValue() {
            return prices[0].Value;
        }

        public decimal getLastStockValue() {
            return prices[prices.Count - 1].Value;
        }

        public long getStockCount() {
            return this.stockCount;
            ;
        }
    }

    class StockWithMarketCount : Stock {
        private long stockMarketCount;

        public StockWithMarketCount(string stockName, long stockCount, DateTime validirtyStart, decimal stockValue)
            : base(stockName, stockCount, validirtyStart, stockValue) {

            this.stockMarketCount = stockCount;
        }

        public void transferToPortfolio(Portfolio portfolio, int numberOfStocks) {
            if (!(stockMarketCount <= numberOfStocks)) {
                portfolio.addStock(this, numberOfStocks);
                stockMarketCount -= numberOfStocks;
            }
            else
                throw new StockExchangeException("Invalud number of stocks");
        }

        public void transferFromPortfolio(Portfolio portfolio, int numberOfStocks) {
            if (!(portfolio.numberOfShares(this) < numberOfStocks)) {
                portfolio.removeStock(this, numberOfStocks);
                stockMarketCount += numberOfStocks;
            }
            else
                throw new StockExchangeException("Invalud number of stocks");
        }

        public void removeFromPortfolio(Portfolio portfolio) {

        }
    }

    class Portfolio {
        Dictionary<Stock, int> stocksInPortfolio = new Dictionary<Stock, int>();

        string portfolioName;

        public Portfolio(string name) {
            this.portfolioName = name;

        }
        public void addStock(Stock stock, int count) {
            int value;
            if (stocksInPortfolio.TryGetValue(stock, out value)) {
                stocksInPortfolio[stock] = value + count;
            }
            else {
                stocksInPortfolio.Add(stock, count);
            }

        }

        public void removeStock(Stock stock, int count) {
            int value;
            if (stocksInPortfolio.TryGetValue(stock, out value)) {
                if (value - count < 0)
                    throw new StockExchangeException("Not enaugh stocks");

                stocksInPortfolio[stock] = value - count;
                if (value - count == 0)
                    stocksInPortfolio.Remove(stock);
            }
            else {
                throw new StockExchangeException("Stock doesn't exist");
            }
        }

        public bool hasStock(Stock stock) {
            return stocksInPortfolio.ContainsKey(stock);
        }

        public int numberOfShares(Stock stock) {
            int value;
            if (stocksInPortfolio.TryGetValue(stock, out value))
                return value;
            else
                throw new StockExchangeException("Stock doesn't exist");
        }

        public decimal getPortfolioValue(DateTime timestamp) {
            decimal sum = 0;
            foreach (Stock stock in stocksInPortfolio.Keys)
                sum += stock.getStockValue(timestamp) * stocksInPortfolio[stock];
            return sum;
        }

        public int numberOfStocks() {
            return this.stocksInPortfolio.Count;
        }

        public bool Equals(string name) {
            return this.portfolioName.ToLower().Equals(name.ToLower());
        }
    }

    class Index {
        private HashSet<Stock> stocks = new HashSet<Stock>();
        private IndexTypes indexType;
        private string indexName;

        public Index(string indexName, IndexTypes type) {
            if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Unknown index type");
            this.indexType = type;
            this.indexName = indexName;
        }

        public bool Equals(string name) {
            return this.indexName.ToLower().Equals(name.ToLower());
        }

        public void addStock(Stock stock) {
            if (!stocks.Add(stock)) {
                throw new StockExchangeException("Stock already exists");
            }
        }

        public void removeStock(Stock stock) {
            if (!stocks.Remove(stock)) {
                throw new StockExchangeException("Stock removal failed");
            }
        }

        public bool hasStock(Stock stock) {
            return stocks.Contains(stock);
        }

        public int numberOfStocks() {
            return stocks.Count;
        }

        public decimal getValue(DateTime timeStamp) {
            if (indexType.Equals(IndexTypes.AVERAGE)) {
                return decimal.Round(getAverageValue(timeStamp), 3);
            }
            else {
                return decimal.Round(getWeightedvalue(timeStamp), 3);
            }
        }

        private decimal getAverageValue(DateTime timeStamp) {
            decimal sum = this.getTotalValue(timeStamp);
            return sum / this.stocks.Count;
        }

        private decimal getWeightedvalue(DateTime timeStamp) {
            decimal weightSum = 0;
            decimal sumOfValues = getTotalValue(timeStamp);
            decimal result = 0;

            foreach (Stock stock in stocks) {
                weightSum += stock.getWeightStockValue(timeStamp);
            }

            foreach (Stock stock in stocks) {
                decimal stockValue = stock.getStockValue(timeStamp);
                result += (stockValue / weightSum) * sumOfValues;
            }

            return result;

        }

        private decimal getTotalValue(DateTime timeStamp) {
            decimal sum = 0;
            foreach (Stock stock in stocks) {
                sum += stock.getStockValue(timeStamp);
            }

            return sum;
        }

        public int getStockCount() {
            return this.stocks.Count;
        }
    }
}


