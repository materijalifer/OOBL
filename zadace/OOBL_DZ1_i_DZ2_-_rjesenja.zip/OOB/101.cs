﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _listStocks = new List<Stock>();
        private List<Index> _listIndices = new List<Index>();
        private List<Portfolio> _listPortfolios = new List<Portfolio>();

        public StockExchange()
        {
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName)) throw new StockExchangeException("Dionica već postoji na burzi!");

            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

            _listStocks.Add(newStock);
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = GetStockByName(inStockName);

            foreach (Index index in _listIndices)
            {
                if (IsStockPartOfIndex(index.IndexName, inStockName))
                    index.RemoveStockFromIndex(stock);
            }

            foreach (Portfolio portfolio in _listPortfolios)
            {
                if (IsStockPartOfPortfolio(portfolio.PortfolioID, stock.StockName))
                    portfolio.RemoveStockFromPortfolio(stock);
            }

            RemoveStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock stock in _listStocks)
            {
                if (stock.StockName == inStockName.ToUpper()) return true;
            }

            return false;
        }

        public int NumberOfStocks()
        {
            return _listStocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = GetStockByName(inStockName);

            stock.SetPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = GetStockByName(inStockName);

            return stock.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = GetStockByName(inStockName);

            return stock.InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = GetStockByName(inStockName);

            return stock.CurrentPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName)) throw new StockExchangeException("Indeks već postoji na burzi!");

            Index newIndex = new Index(inIndexName, inIndexType);

            _listIndices.Add(newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock stock = GetStockByName(inStockName);
            Index index = GetIndexByName(inIndexName);

            index.AddStockToIndex(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stock = GetStockByName(inStockName);
            Index index = GetIndexByName(inIndexName);

            index.RemoveStockFromIndex(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = GetIndexByName(inIndexName);

            return index.StockExists(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = GetIndexByName(inIndexName);

            return index.GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (Index index in _listIndices)
            {
                if (index.IndexName == inIndexName.ToUpper()) return true;
            }

            return false;
        }

        public int NumberOfIndices()
        {
            return _listIndices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = GetIndexByName(inIndexName);

            return index.NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfelj već postoji!");

            Portfolio newPortfolio = new Portfolio(inPortfolioID);

            _listPortfolios.Add(newPortfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);
            Stock stock = GetStockByName(inStockName);

            int totalNumberOfStockShares = 0;
            foreach (Portfolio p in _listPortfolios)
            {
                if (p.IsStockInPortfolio(stock))
                    totalNumberOfStockShares += p.NumberOfSharesOfStock(stock);
            }
            if (totalNumberOfStockShares + numberOfShares > stock.NumberOfShares)
                throw new StockExchangeException("Nedovoljan broj dionica na burzi!");

            portfolio.AddStockToPortfolio(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);
            Stock stock = GetStockByName(inStockName);

            portfolio.RemoveStockFromPortfolio(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);
            Stock stock = GetStockByName(inStockName);

            portfolio.RemoveStockFromPortfolio(stock);
        }

        public int NumberOfPortfolios()
        {
            return _listPortfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);

            return portfolio.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio portfolio in _listPortfolios)
            {
                if (portfolio.PortfolioID == inPortfolioID) return true;
            }

            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);
            Stock stock = GetStockByName(inStockName);

            return portfolio.IsStockInPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);
            Stock stock = GetStockByName(inStockName);

            return portfolio.NumberOfSharesOfStock(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);

            return portfolio.GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = GetPortfolioByID(inPortfolioID);

            return portfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
        }

        public void RemoveStock(string inName)
        {
            if (!StockExists(inName)) throw new StockExchangeException("Dionica ne postoji na burzi!");

            Stock stock = GetStockByName(inName);

            _listStocks.Remove(stock);
        }

        public Stock GetStockByName(string inName)
        {
            foreach (Stock stock in _listStocks)
            {
                if (stock.StockName == inName.ToUpper()) return stock;
            }

            throw new StockExchangeException("Dionica ne postoji na burzi!");
        }

        public Index GetIndexByName(string inName)
        {
            foreach (Index index in _listIndices)
            {
                if (index.IndexName == inName.ToUpper())
                    return index;
            }

            throw new StockExchangeException("Indeks ne postoji!");
        }

        public Portfolio GetPortfolioByID(string inPortfolioID)
        {
            foreach (Portfolio portfolio in _listPortfolios)
            {
                if (portfolio.PortfolioID == inPortfolioID) return portfolio;
            }

            throw new StockExchangeException("Portfelj ne postoji!");
        }
    }

    public class Stock
    {
        private decimal _initialPrice;
        private long _numberOfShares;
        private decimal _currentPrice;
        private string _stockName;

        private Dictionary<DateTime, decimal> _stockPriceDate = new Dictionary<DateTime, decimal>();

        #region Properties
        public DateTime TimeCreated { get; set; }

        public decimal InitialPrice
        {
            get { return _initialPrice; }
            set
            {
                if (value > 0) _initialPrice = value;
                else throw new StockExchangeException("Cijena dionice mora biti pozitivna!");
            }
        }

        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set
            {
                if (value > 0) _numberOfShares = value;
                else throw new StockExchangeException("Broj dionica mora biti pozitivan!");
            }
        }

        public decimal CurrentPrice
        {
            get { return _currentPrice; }
            set
            {
                if (value > 0) _currentPrice = value;
                else throw new StockExchangeException("Cijena dionice mora biti pozitivna!");
            }
        }

        public string StockName
        {
            get { return _stockName; }
            set { _stockName = value.ToUpper(); }
        }
        #endregion

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockName = inStockName;
            NumberOfShares = inNumberOfShares;
            InitialPrice = inInitialPrice;
            TimeCreated = inTimeStamp;

            SetPrice(InitialPrice, TimeCreated);
        }

        public void SetPrice(decimal inPrice, DateTime inTimeStamp)
        {
            if (_stockPriceDate.ContainsKey(inTimeStamp)) throw new StockExchangeException("Za taj trenutak je već definirana cijena dionice!");
            _stockPriceDate.Add(inTimeStamp, inPrice);

            if(!_stockPriceDate.Keys.Any(d => d.CompareTo(inTimeStamp) > 0))
                CurrentPrice = inPrice;
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            if (_stockPriceDate.ContainsKey(inTimeStamp))
                return _stockPriceDate[inTimeStamp];
            else
            {
                DateTime latestDate = DateTime.MinValue;
                foreach (DateTime date in _stockPriceDate.Keys)
                {
                    if (DateTime.Compare(date, inTimeStamp) < 0 && DateTime.Compare(date, latestDate) > 0)
                    {
                        latestDate = date;
                    }
                }

                if (_stockPriceDate.ContainsKey(latestDate))
                    return _stockPriceDate[latestDate];
                else throw new StockExchangeException("Ne postoji cijena za zadani datum!");
            }
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;

        private List<Stock> _listStocks = new List<Stock>();

        #region Properties
        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value.ToUpper(); }
        }

        public IndexTypes IndexType
        {
            get { return _indexType; }
            set
            {
                if (Enum.GetNames(typeof(IndexTypes)).Any(i => i.Equals(value.ToString()))) _indexType = value;
                else throw new StockExchangeException("Ne postoji traženi tip indeksa!");
            }
        }
        #endregion

        public Index(string inName, IndexTypes inType)
        {
            IndexName = inName;
            IndexType = inType;
        }

        public void AddStockToIndex(Stock inStock)
        {
            if (StockExists(inStock.StockName)) throw new StockExchangeException("Dionica već postoji u indeksu!");

            _listStocks.Add(inStock);
        }

        public void RemoveStockFromIndex(Stock inStock)
        {
            if (StockExists(inStock.StockName))
                _listStocks.Remove(inStock);

            else throw new StockExchangeException("Dionica ne postoji u indeksu!");
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock stock in _listStocks)
            {
                if (stock.StockName == inStockName.ToUpper())
                    return true;
            }

            return false;
        }

        public int NumberOfStocks()
        {
            return _listStocks.Count;
        }

        public decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal sumStockValues = 0.0m;
            foreach (Stock stock in _listStocks)
            {
                sumStockValues += stock.GetPrice(inTimeStamp) * stock.NumberOfShares;
            }

            switch (IndexType)
            {
                case IndexTypes.AVERAGE:
                    return Decimal.Round(sumStockValues / NumberOfStocks(), 3);

                case IndexTypes.WEIGHTED:
                    decimal sumWeightedValues = 0.0m;
                    foreach (Stock stock in _listStocks)
                    {
                        sumWeightedValues += (stock.NumberOfShares * stock.GetPrice(inTimeStamp) / sumStockValues) *
                                             stock.GetPrice(inTimeStamp);
                    }
                    return Decimal.Round(sumWeightedValues, 3);
            }
            throw new StockExchangeException("Ne postoji traženi indeks!");
        }
    }

    public class Portfolio
    {
        private Dictionary<Stock, int> _numberOfStockShares = new Dictionary<Stock, int>();

        public string PortfolioID { get; set; }

        public Portfolio(string inID)
        {
            PortfolioID = inID;
        }

        public void AddStockToPortfolio(Stock inStock, int inNumberOfShares)
        {
            if (IsStockInPortfolio(inStock))
            {
                int totalNumberOfShares = _numberOfStockShares[inStock] + inNumberOfShares;
                _numberOfStockShares.Remove(inStock);
                _numberOfStockShares.Add(inStock, totalNumberOfShares);
            }
            else
            {
                _numberOfStockShares.Add(inStock, inNumberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(Stock inStock, int inNumberOfShares)
        {
            if (IsStockInPortfolio(inStock))
            {
                int remainingNumberOfShares = _numberOfStockShares[inStock] - inNumberOfShares;
                if (remainingNumberOfShares > 0)
                {
                    _numberOfStockShares.Remove(inStock);
                    _numberOfStockShares.Add(inStock, remainingNumberOfShares);
                }
                else _numberOfStockShares.Remove(inStock);
            }
            else throw new StockExchangeException("Dionica ne postoji u portfelju!");
        }

        public void RemoveStockFromPortfolio(Stock inStock)
        {
            if (IsStockInPortfolio(inStock)) _numberOfStockShares.Remove(inStock);
            else throw new StockExchangeException("Dionica ne postoji u portfelju!");
        }

        public bool IsStockInPortfolio(Stock inStock)
        {
            if (_numberOfStockShares.ContainsKey(inStock)) return true;

            else return false;
        }

        public int NumberOfStocks()
        {
            return _numberOfStockShares.Count;
        }

        public int NumberOfSharesOfStock(Stock inStock)
        {
            return _numberOfStockShares[inStock];
        }

        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            decimal totalValueOfStocks = 0.0m;

            foreach (KeyValuePair<Stock, int> entry in _numberOfStockShares)
            {
                totalValueOfStocks += entry.Value * entry.Key.GetPrice(inTimeStamp);
            }

            return Decimal.Round(totalValueOfStocks, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int inYear, int inMonth)
        {
            DateTime firstDayOfMonth = new DateTime(inYear, inMonth, 1, 00, 00, 00, 00);
            DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddMilliseconds(-1);

            decimal priceFirstDay = GetPortfolioValue(firstDayOfMonth);
            decimal priceLastDay = GetPortfolioValue(lastDayOfMonth);

            decimal changeInValue = ((priceLastDay - priceFirstDay) / priceFirstDay) * 100;
            return Decimal.Round(changeInValue, 3);
        }
    }
}
