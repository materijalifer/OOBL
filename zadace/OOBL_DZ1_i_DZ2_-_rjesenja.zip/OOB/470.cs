﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string currentState = "0";
        private string firstOperator;
        private bool secondOperatorInserted = false;
        private string memory;
        private char operation = '\0';

        public void Press(char inPressedDigit)
        {
            if ((inPressedDigit >= '0' && inPressedDigit <= '9') || inPressedDigit == ',' || inPressedDigit == 'M')
            {
                if (operation != '\0' && secondOperatorInserted == false)
                {
                    currentState = "0";
                    secondOperatorInserted = true;
                }

                currentState = inputOperator(currentState, inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        if (operation == '\0')
                        {
                            firstOperator = currentState;
                            operation = '+';
                        }
                        else if (secondOperatorInserted)
                        {
                            executeBinaryOperation();
                            operation = '+';
                        }
                        else
                        {
                            operation = '+';
                        }
                        break;

                    case '-':
                        if (operation == '\0')
                        {
                            firstOperator = currentState;
                            operation = '-';
                        }
                        else if (secondOperatorInserted)
                        {
                            executeBinaryOperation();
                            operation = '-';
                        }
                        else
                        {
                            operation = '-';
                        }
                        break;

                    case '*':
                        if (operation == '\0')
                        {
                            firstOperator = currentState;
                            operation = '*';
                        }
                        else if (secondOperatorInserted)
                        {
                            executeBinaryOperation();
                            operation = '*';
                        }
                        else
                        {
                            operation = '*';
                        }
                        break;

                    case '/':
                        if (operation == '\0')
                        {
                            firstOperator = currentState;
                            operation = '/';
                        }
                        else if (secondOperatorInserted)
                        {
                            executeBinaryOperation();
                            operation = '/';
                        }
                        else
                        {
                            operation = '/';
                        }
                        break;

                    case '=':
                        executeBinaryOperation();
                        break;
                    case 'S':
                        currentState = Math.Sin(System.Convert.ToDouble(currentState)).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        break;
                    case 'K':
                        currentState = Math.Cos(System.Convert.ToDouble(currentState)).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        break;
                    case 'T':
                        currentState = Math.Tan(System.Convert.ToDouble(currentState)).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        break;
                    case 'Q':
                        currentState = Math.Pow(System.Convert.ToDouble(currentState), 2).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        break;
                    case 'R':
                        currentState = Math.Pow(System.Convert.ToDouble(currentState), 1 / 2).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        break;
                    case 'I':
                        if (System.Convert.ToDouble(currentState) == 0.0)
                        {
                            currentState = "-E-";
                        }
                        else
                        {
                            currentState = (1 / System.Convert.ToDouble(currentState)).ToString();
                            currentState = roundResultToFitScreen(currentState);
                        }
                        break;
                    case 'P':
                        memory = currentState;
                        break;
                    case 'G':
                        if (operation != '\0')
                        {
                            secondOperatorInserted = true;
                        }

                        currentState = memory;
                        break;
                    case 'C':
                        currentState = "0";
                        break;
                    case 'O':
                        currentState = "0";
                        firstOperator = null;
                        secondOperatorInserted = false;
                        memory = null;
                        operation = '\0';
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            try
            {
                return double.Parse(currentState).ToString();
            }
            catch
            {
                return currentState;
            }
        }

        private string inputOperator(string state, char inPressedDigit)
        {
            if (inPressedDigit == ',' && !state.Contains(","))
            {
                state += inPressedDigit;
            }

            else if (inPressedDigit == 'M')
            {
                if (state.ElementAt(0) == '-')
                {
                    state = state.Remove(0);
                }
                else
                {
                    if (state != "0")
                    {
                        state = "-" + state;
                    }
                }
            }

            else if (state != "0" && inPressedDigit != '0')
            {
                int border = 10;

                if (state.Contains(','))
                {
                    border++;
                }

                if (state.Contains('-'))
                {
                    border++;
                }

                if (state.Count() < border)
                {
                    state += inPressedDigit;
                }
            }

            else if (state == "0" && inPressedDigit != '0')
            {
                state = inPressedDigit.ToString();
            }

            return state;
        }

        private void executeBinaryOperation()
        {
            switch (operation)
            {
                case '+':
                    currentState = (System.Convert.ToDecimal(firstOperator) + System.Convert.ToDecimal(currentState)).ToString();
                    currentState = roundResultToFitScreen(currentState);
                    firstOperator = currentState;
                    secondOperatorInserted = false;
                    operation = '\0';
                    break;

                case '-':
                    currentState = (System.Convert.ToDecimal(firstOperator) - System.Convert.ToDecimal(currentState)).ToString();
                    currentState = roundResultToFitScreen(currentState);
                    firstOperator = currentState;
                    secondOperatorInserted = false;
                    operation = '\0';
                    break;

                case '*':
                    currentState = (System.Convert.ToDecimal(firstOperator) * System.Convert.ToDecimal(currentState)).ToString();
                    currentState = roundResultToFitScreen(currentState);
                    firstOperator = currentState;
                    secondOperatorInserted = false;
                    operation = '\0';
                    break;

                case '/':
                    if (System.Convert.ToDouble(currentState) == 0.0)
                    {
                        currentState = "-E-";
                    }
                    else 
                    {
                        currentState = (System.Convert.ToDecimal(firstOperator) / System.Convert.ToDecimal(currentState)).ToString();
                        currentState = roundResultToFitScreen(currentState);
                        firstOperator = currentState;
                        secondOperatorInserted = false;
                        operation = '\0';
                    }

                    break;
            }
        }

        private string roundResultToFitScreen(string state)
        {
            if (state.Contains(','))
            {
                int commaPosition = state.IndexOf(',');

                if (state.Contains('-'))
                {
                    if (commaPosition >= 12)
                    {
                        return "-E-";
                    }
                    else 
                    {
                        return Math.Round(double.Parse(state), 11 - commaPosition).ToString();
                    }
                }

                else
                {
                    if (commaPosition >= 11)
                    {
                        return "-E-";
                    }

                    else
                    {
                        return Math.Round(double.Parse(state), 10 - commaPosition).ToString();
                    }
                }
            }

            else
            {
                if (state.Contains('-'))
                {
                    if (state.Count() >= 11)
                    {
                        return "-E-";
                    }
                    else 
                    {
                        return state;
                    }
                }
                else
                {
                    if (state.Count() >= 10)
                    {
                        return "-E-";
                    }
                    else
                    {
                        return state;
                    }
                }
            }
        }
    }
}
