using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string currentState1 = null;
        string currentState2 = null;
        double firstResultNum;
        string resultNum;
        string memory;
        string numSin;
        string numCos;
        string numTan;

        bool getMemory, boolSin, boolCos, boolTan, setMemory, boolOperator, add, substract, product, divide, squere, equal; 

        bool dot, pred;

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit.ToString() == "P")
            {
                memory = currentState1;
            }
            else if (inPressedDigit.ToString() == "G")
            {
                getMemory = true;
            }
            else if (inPressedDigit.ToString() == "S")
            {
                double res = Convert.ToDouble(currentState1);
                double sin = Math.Sin(res);
                numSin = transformTri(sin);
                numSin = numSin.Replace(',', '.');
                boolSin = true;
            }

            else if (inPressedDigit.ToString() == "K")
            {
                double res = Convert.ToDouble(currentState1);
                double cos = Math.Cos(res);
                numCos = transformTri(cos);
                numCos = numCos.Replace(',', '.');
                boolCos = true;
            }

            else if (inPressedDigit.ToString() == "T")
            {
                double res = Convert.ToDouble(currentState1);
                double tan = Math.Tan(res);
                numTan = transformTri(tan);
                numTan = numTan.Replace(',', '.');
                boolTan = true;
            }

            else
            {
                boolOperator = switchOperator(inPressedDigit.ToString());

                if (boolOperator)
                {
                    boolOperator = false;
                }

                else
                {

                    if (currentState1 != null)
                    {
                        if (inPressedDigit.ToString() == ",")
                            dot = true;
                        if (inPressedDigit.ToString() == "M")
                        {
                            if (pred == true)
                                pred = false;
                            else
                                pred = true;
                        }
                    }

                    if (currentState2 != null)
                    {
                        if (inPressedDigit.ToString() == ",")
                            dot = true;
                        if (inPressedDigit.ToString() == "M")
                        {
                            if (pred == true)
                                pred = false;
                            else
                                pred = true;
                        }
                    }

                    if (add || substract || product || divide || squere)
                    {
                        if (currentState2 == null)
                        {
                            if (inPressedDigit.ToString() == ",")
                                currentState2 = "0,";
                            else
                                currentState2 = inPressedDigit.ToString();
                        }
                        else
                            currentState2 = insertValues(inPressedDigit.ToString(), currentState2.ToString());
                    }
                    else
                    {
                        if (currentState1 == null)
                        {
                            if (inPressedDigit.ToString() == ",")
                                currentState1 = "0,";
                            else
                                currentState1 = inPressedDigit.ToString();
                        }
                        else
                            currentState1 = insertValues(inPressedDigit.ToString(), currentState1.ToString());
                    }
                }
            }
        }

        /*
         * Kada se upiše M pretvara broj u negativan
         */
        public string moveString(string values)
        {
            string newString = "-";
            newString = newString.Insert(1, values);
            newString.Insert(0, "-");
            pred = false;

            return newString;
        }

        string newValues; 
        public string insertValues(string inPressedDigit, string values)
        {
            if (values.Length == 1 && values[0].ToString() == "0" && inPressedDigit.ToString() == "0")
            {
                newValues = values;
            }
         
            else if (values.Length < 11)
            {
                if (inPressedDigit.ToString() == ",")
                {
                    values += ".";
                    dot = false;
                }
                else
                {
                    values += inPressedDigit.ToString();
                }
            }

            else if (values.Length == 11)
            {
                if (dot && pred)
                {
                    values = moveString(values);
                    values.Remove(values.Length - 1);
                }
            }

            return values;
        }

        public bool switchOperator(string inPressedDigit)
        {
            switch(inPressedDigit.ToString())
            {
                case "+":
                    {
                        boolOperator = true;
                        if(currentState1.ToString() != null)
                        {
                            if(!add)
                                add = true;
                            else if(currentState1.ToString() != null && currentState2.ToString() != null)
                            {
                                firstResultNum = addFunc(currentState1.ToString(), currentState2.ToString());
                            }
                        }
                        break;
                    }
                case "-":
                    {
                        boolOperator = true;
                        if (currentState1.ToString() != null)
                        {
                            if (!substract)
                                substract = true;
                            else if (currentState1.ToString() != null && currentState2.ToString() != null)
                            {
                                firstResultNum = substractFunc(currentState1.ToString(), currentState2.ToString());
                            }
                        }
                        break;
                    }
                case "*": 
                    {
                        boolOperator = true;
                        if (currentState1.ToString() != null)
                        {
                            if (!product)
                                product = true;
                            else if (currentState1.ToString() != null && currentState2.ToString() != null)
                            {
                                firstResultNum = productFunc(currentState1.ToString(), currentState2.ToString());
                            }
                        }
                        break;
                    }
                case "/":
                    {
                        boolOperator = true;
                        if (currentState1.ToString() != null)
                        {
                            if (!divide)
                                divide = true;
                            else if (currentState1.ToString() != null && currentState2.ToString() != null)
                            {
                                firstResultNum = divideFunc(currentState1.ToString(), currentState2.ToString());
                            }
                        }
                        break;
                    }
                case "=":
                    {
                        equal = true;
                        if (add)
                        {
                            add = false;
                            firstResultNum = addFunc(currentState1.ToString(), currentState2.ToString());
                            resultNum = transformNum(firstResultNum);
                        }
                        else if (substract)
                        {
                            substract = false;
                            firstResultNum = substractFunc(currentState1.ToString(), currentState2.ToString());
                            resultNum = transformNum(firstResultNum);
                        }
                        else if (product)
                        {
                            product = false;
                            firstResultNum = productFunc(currentState1.ToString(), currentState2.ToString());
                            resultNum = transformNum(firstResultNum);
                        }
                        else if (divide)
                        {
                            divide = false;
                            firstResultNum = divideFunc(currentState1.ToString(), currentState2.ToString());
                            resultNum = transformNum(firstResultNum);
                        }
                        else if (squere)
                        {
                            squere = false;
                            firstResultNum = squereFunc(currentState1.ToString(), currentState1.ToString());
                            resultNum = transformNum(firstResultNum);
                        }
                        
                        if (currentState1 != null)
                        {
                            if (currentState1.Contains(".") || currentState2.Contains(".") )
                            {
                                if (currentState1[currentState1.IndexOf(".") + 1] == '0')
                                    resultNum = currentState1.Remove(currentState1.IndexOf("."));
                           
                            }
                        }

                        if (currentState2 != null)
                        {
                            if (currentState2.Contains(".") || currentState2.Contains("."))
                            {
                                if (currentState2[currentState2.IndexOf(".") + 1] == '0')
                                    resultNum = currentState2.Remove(currentState2.IndexOf("."));

                            }
                        }
                        break;
                    }
                case "M":
                    {
                        boolOperator = true;
                        pred = true;
                        if (add || substract || product)
                            currentState2 = moveString(currentState2.ToString());
                        else
                            currentState1 = moveString(currentState1.ToString());
                        break;
                    }
                case "S":
                    {
                    }
                    break;
                case "K":
                    {}
                    break;
                case "T":
                    {}
                    break;
                case "Q":
                    {
                        boolOperator = true;
                        if (currentState1.ToString() != null)
                        {
                            if (!squere)
                                squere = true;
                            else if (currentState1.ToString() != null && currentState2.ToString() != null)
                            {
                                firstResultNum = squereFunc(currentState1.ToString(), currentState1.ToString());
                            }
                        }
                        break;
                    }
                case "R":
                    {}
                    break;
                case "I":
                    {}
                    break;
                case "G":
                    {}
                    break;
                case "C":
                    {

                    }
                    break;
                case "O":
                    {
                        boolOperator = true;
                        add = false;
                        substract = false;
                        product = false;
                        divide = false;
                        squere = false;
                        currentState1 = "0";
                        currentState2 = "0";
                        resultNum = "0";
                    }
                    break;
            }
            return boolOperator;
        }

        static double Evaluate(string expression)
        {
            double res;
            var loDataTable = new DataTable();
            var loDataColumn = new DataColumn("Eval", typeof(double), expression);
            try { loDataTable.Columns.Add(loDataColumn); }
            catch { loDataTable = null; }
            try { loDataTable.Rows.Add(0); }
            catch { loDataTable = null; }
            if (loDataTable == null)
                res = 00000;
            else
                res = (double)(loDataTable.Rows[0]["Eval"]);
            return res;
        }
        
        static string transformNum(double resultNum)
        {
            // Ako je  rezultat veći od dopuštenog pretvara u dopušteni            
            bool min = false;
            bool zar = false;
            int i;
            string num;
            if (resultNum == 00000)
                num = "-E-";
            else
            {
                num = resultNum.ToString(CultureInfo.GetCultureInfo("hr-HR"));
                for (i = 0; i < num.Length; i++)
                {
                    if (num[i].ToString() == "-")
                        min = true;

                    if (num[i].ToString() == ",")
                        zar = true;
                }

                if (num.Length == 11)
                {
                    if (!min || !zar)
                        num = "-E-";
                }
                else if (num.Length == 12)
                {
                    if (!min && !zar)
                        num = "-E-";
                }
                else if (num.Length > 12)
                {
                    num = "-E-";
                }
            }
            return num;            
        }

        static string transformTri(double resultNum)
        {
            // Ako je  rezultat veći od dopuštenog pretvara u dopušteni            
            bool min = false;
            bool zar = false;
            int i;
            string num;
           
            num = resultNum.ToString(CultureInfo.GetCultureInfo("hr-HR"));
            for (i = 0; i < num.Length; i++)
            {
                if (num[i].ToString() == "-")
                    min = true;

                if (num[i].ToString() == ",")
                    zar = true;
            }
       
            if(num.Length > 11)
            {
                if (min && zar)
                    num = num.Remove(12);
                else if (min || zar)
                    num = num.Remove(11);
            }

            return num;
        }

        public double addFunc(string value1, string value2)
        {
            if ((currentState1.ToString() != null) && (currentState2.ToString() != null))
            {
                string exp = currentState1.ToString() + "+" + currentState2.ToString();
                firstResultNum = Evaluate(exp);
            }
            return firstResultNum;
        }

        public double substractFunc(string value1, string value2)
        {
            if ((currentState1.ToString() != null) && (currentState2.ToString() != null))
            {
                string exp = currentState1.ToString() + "-" + currentState2.ToString();
                firstResultNum = Evaluate(exp);
            }

            return firstResultNum;
        }

        public double productFunc(string value1, string value2)
        {
            if ((currentState1.ToString() != null) && (currentState2.ToString() != null))
            {
                string exp = currentState1.ToString() + "*" + currentState2.ToString();
                firstResultNum = Evaluate(exp);
            }

            return firstResultNum;
        }

        public double squereFunc(string value1, string value2)
        {
            if ((currentState1.ToString() != null))
            {
                string exp = currentState1.ToString() + "*" + currentState1.ToString();
                firstResultNum = Evaluate(exp);
            }

            return firstResultNum;
        }

        public double divideFunc(string value1, string value2)
        {
            if ((currentState1.ToString() != null) && (currentState2.ToString() != null))
            {
                string exp = currentState1.ToString() + "/" + currentState2.ToString();
                firstResultNum = Evaluate(exp);
            }

            return firstResultNum;
        }

        public string GetCurrentDisplayState()
        {
            if (getMemory)
                return memory;
            if(currentState1 == null)
                currentState1 = "0";
            if (add || substract || squere || divide || product)
            {
                if (currentState2 == null)
                {
                    if (currentState1.Contains("."))
                    {
                        currentState1 = currentState1.Replace('.', ',');

                        if (currentState1[currentState1.IndexOf(",") + 1] == '0')
                            currentState1 = currentState1.Remove(currentState1.IndexOf(","));
                    }
                    return currentState1;
                }
                else
                {
                    if (currentState2.Contains("."))
                    {
                        currentState2 = currentState2.Replace('.', ',');

                        if (currentState2[currentState2.IndexOf(",") + 1] == '0')
                            currentState2 = currentState2.Remove(currentState2.IndexOf(","));
                    }
                    return currentState2;
                }
            }
            else if (boolSin)
                return numSin;
            else if (equal)
                return resultNum;
            else if (boolCos)
                return numCos;
            else if (boolTan)
                return numTan;
            else
                return currentState1;
        }
    }
}
