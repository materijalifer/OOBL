﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,StockObject> _stockRepository;
         private Dictionary<string, Index> _indices;
         private Dictionary<string, Portfolio> _portfolios;

         public StockExchange()
         {
             this._stockRepository = new Dictionary<string, StockObject>();
             this._indices = new Dictionary<string, Index>();
             this._portfolios = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name already exists in the Exchange!!");
             if (inInitialPrice <= 0.0m) throw new StockExchangeException("Stock price is below or equals zero! I'm afraid that is impossible...");
             if (inNumberOfShares <= 0) throw new StockExchangeException("Stock share number can't be below or equals zero!");
             StockObject newStock = new StockObject(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
             this._stockRepository.Add(inStockName.ToUpper(), newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");

             

             foreach (Index ind in this._indices.Values)
             {
                 if (this.IsStockPartOfIndex(ind.Name, inStockName))
                 {
                     RemoveStockFromIndex(ind.Name, inStockName);
                 }
             }

             foreach (Portfolio port in this._portfolios.Values)
             {
                 if (this.IsStockPartOfPortfolio(port.ID, inStockName))
                 {
                     RemoveStockFromPortfolio(port.ID, inStockName);
                 }
             }

             this._stockRepository.Remove(inStockName.ToUpper());
         }

         public bool StockExists(string inStockName)
         {
             return this._stockRepository.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return this._stockRepository.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (inIimeStamp < this._stockRepository[inStockName.ToUpper()].InitialDate) throw new StockExchangeException("Stock wasn't enlisted at that time!");
             if (inStockValue <= 0.0m) throw new StockExchangeException("Stock price is below or equals zero! I'm afraid that is impossible...");
             this._stockRepository[inStockName.ToUpper()].AddNewStockValue(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (inTimeStamp < this._stockRepository[inStockName.ToUpper()].InitialDate) throw new StockExchangeException("Stock wasn't enlisted at that time!");
             return this._stockRepository[inStockName.ToUpper()].PriceWithTimeStamp(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             return this._stockRepository[inStockName.ToUpper()].InitialPrice;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             return this._stockRepository[inStockName.ToUpper()].LastPrice;
         }


         // INDEXIIII
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name already exists in the Exchange!!");
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED) throw new StockExchangeException("False definition of index type!");
             Index newIndex = new Index(inIndexName.ToUpper(), inIndexType);
             this._indices.Add(inIndexName.ToUpper(), newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (IsStockPartOfIndex(inIndexName.ToUpper(), inStockName.ToUpper())) throw new StockExchangeException("Stock with that name already exists in the selected Index!!");

             StockObject stockToAdd = this._stockRepository[inStockName.ToUpper()];
             this._indices[inIndexName.ToUpper()].AddStock(stockToAdd);
                

         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (!IsStockPartOfIndex(inIndexName.ToUpper(),inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the selected Index!!");

             this._indices[inIndexName.ToUpper()].RemoveStock(inStockName.ToUpper());
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             return this._indices[inIndexName.ToUpper()].ContainsStock(inStockName.ToUpper());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name does not exist in the Exchange!!");
             Index ind = this._indices[inIndexName.ToUpper()];
             return ind.ValueIndexInSpecificTime(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return this._indices.Keys.Contains(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return this._indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName.ToUpper())) throw new StockExchangeException("Index with that name does not exist in the Exchange!!");
             return this._indices[inIndexName.ToUpper()].ReturnNumOfStocks();
         }

         // PORTFELJI!!!!!!!

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID already exists in the Exchange!!");
             Portfolio newPort = new Portfolio(inPortfolioID);
             this._portfolios.Add(inPortfolioID, newPort);

         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (numberOfShares <= 0) throw new StockExchangeException("Number of shares below or equals zero.");
             if (numberOfShares > this._stockRepository[inStockName.ToUpper()].NumOfShares) throw new StockExchangeException("You've added more shares to portfolio than enlisted on the Exchange.");
             if (!CheckSumOfSharesInPortfolios(numberOfShares, inStockName)) throw new StockExchangeException("You've added more shares to portfolio than available on the Exchange.");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()))
             {
                 StockObject stockToAdd = this._stockRepository[inStockName.ToUpper()];
                 this._portfolios[inPortfolioID].AddStock(stockToAdd, numberOfShares);
             }
             else
             {
                 this._portfolios[inPortfolioID].stockShareNumSet[inStockName.ToUpper()] += numberOfShares;
             }
         }
         // provjerava da se slucajno ne dogodi da portfelji sadrze nepostojeci visak dionica
         private bool CheckSumOfSharesInPortfolios(int numberOfShares, string inStockName)
         {
             long max = this._stockRepository[inStockName.ToUpper()].NumOfShares;
             long sum = numberOfShares;
             foreach (Portfolio port in this._portfolios.Values)
             {
                 if (port.stockShareNumSet.Keys.Contains(inStockName.ToUpper()))
                     sum = port.stockShareNumSet[inStockName.ToUpper()];
             }
             if (sum > max)
                 return false;
             else
                 return true;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper())) throw new StockExchangeException("Stock is not enlisted in the portfolio!");

             this._portfolios[inPortfolioID].stockShareNumSet[inStockName.ToUpper()] -= numberOfShares;
             if (this._portfolios[inPortfolioID].stockShareNumSet[inStockName.ToUpper()] <= 0) RemoveStockFromPortfolio(inPortfolioID, inStockName);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper())) throw new StockExchangeException("Stock is not enlisted in the portfolio!");

             this._portfolios[inPortfolioID].RemoveStock(inStockName.ToUpper());
         }

         public int NumberOfPortfolios()
         {
             return this._portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             return this._portfolios[inPortfolioID].ReturnNumOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this._portfolios.Keys.Contains(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             return this._portfolios[inPortfolioID].ContainsStock(inStockName.ToUpper());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             if (!StockExists(inStockName.ToUpper())) throw new StockExchangeException("Stock with that name does not exist in the Exchange!!");
             if(!IsStockPartOfPortfolio(inPortfolioID,inStockName)) throw new StockExchangeException("Stock is not enlisted in the portfolio!");
             return this._portfolios[inPortfolioID].stockShareNumSet[inStockName.ToUpper()];
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             return this._portfolios[inPortfolioID].TotalValueInSpecificTime(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio with that ID does not exist in the Exchange!!");
             DateTime StartDate = new DateTime(Year, Month, 1, 0,0,0,0);
             DateTime EndDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year,Month), 23, 59, 59, 999);

             decimal startValue = GetPortfolioValue(inPortfolioID, StartDate);
             decimal endValue = GetPortfolioValue(inPortfolioID, EndDate);
             if (startValue == 0) return 0;
             decimal change = endValue / startValue - 1.0m;
            
             return Math.Round(change * 100, 3);
         }
     }

    // klasa dionice
     public class StockObject
     {
         public string StockName { get; set; }
         public long NumOfShares { get; set; }
         public DateTime InitialDate { get; set; }
         public decimal InitialPrice { get; set; }
         public DateTime LastDate { get; set; }
         public decimal LastPrice { get; set; }
         private SortedDictionary<DateTime, decimal> PriceSet;


         public StockObject(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             this.StockName = inStockName;
             this.NumOfShares = inNumberOfShares;
             this.InitialPrice = inInitialPrice;
             this.InitialDate = inTimeStamp;
             this.LastDate = inTimeStamp;
             this.LastPrice = inInitialPrice;
             this.PriceSet = new SortedDictionary<DateTime, decimal>();
             this.PriceSet.Add(this.LastDate, this.InitialPrice);
         }
         //cijena uz vremenski otisak
         internal decimal PriceWithTimeStamp(DateTime inTimeStamp)
         {  
             DateTime requested = this.InitialDate;
             foreach (DateTime tStamp in PriceSet.Keys)
             {
                 if (tStamp > inTimeStamp) break;
                 requested = tStamp;
             }
             return this.PriceSet[requested];
         }


         internal void AddNewStockValue(DateTime inIimeStamp, decimal inStockValue)
         {
             if (this.PriceSet.Keys.Contains(inIimeStamp)) throw new StockExchangeException("Price already defined for current TimeStamp!");
             this.PriceSet.Add(inIimeStamp, inStockValue);
             if (inIimeStamp < this.InitialDate)
             {
                 this.InitialPrice = inStockValue;
                 this.InitialDate = inIimeStamp;
             }

             if (inIimeStamp > this.LastDate)
             {
                 this.LastPrice = inStockValue;
                 this.LastDate = inIimeStamp;
             }
             this.LastPrice = inStockValue;
         }
   
     }
    //interface za laki repozitorijski rad s dionicama za indekse i portfelje
     interface IStockRepository
     {
         int ReturnNumOfStocks();
         bool ContainsStock(string inStockName);
         void RemoveStock(string inStockName);
         void AddStock(StockObject stockToAdd);
     }



     public class Index : IStockRepository
     {
         public string Name { get; set; }
         private IndexTypes _type;
         private Dictionary<string, StockObject> _stockSet;

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             this.Name = inIndexName;
             this._type = inIndexType;
             this._stockSet = new Dictionary<string, StockObject>();
         }

         public int ReturnNumOfStocks()
         {
             return _stockSet.Count;
         }

         public bool ContainsStock(string inStockName)
         {
             return _stockSet.Keys.Contains(inStockName.ToUpper());
         }

         public void AddStock(StockObject stockToAdd)
         {
             this._stockSet.Add(stockToAdd.StockName.ToUpper(), stockToAdd);
         }

         public void RemoveStock(string inStockName)
         {
             _stockSet.Remove(inStockName.ToUpper());
         }

         internal decimal ValueIndexInSpecificTime(DateTime inTimeStamp)
         {
             if (this._type == IndexTypes.AVERAGE)
             {
                 decimal sum = 0.0m;
                 long count = 0;
                 foreach (StockObject stock in this._stockSet.Values)
                 {
                     sum += stock.PriceWithTimeStamp(inTimeStamp);
                     count++;
                 }
                 if (count == 0) return 0;
                 return Math.Round(sum / count, 3);
             }
             else
             {
                 decimal indexSumValue = 0.0m;
                 foreach (StockObject stock in this._stockSet.Values)
                 {
                     indexSumValue += stock.PriceWithTimeStamp(inTimeStamp) * stock.NumOfShares;
                 }
                 if (indexSumValue == 0.0m) return 0;
                 decimal sum = 0.0m;
                 foreach (StockObject stock in this._stockSet.Values)
                 {
                     decimal factor = (stock.PriceWithTimeStamp(inTimeStamp)*stock.NumOfShares)/indexSumValue;
                     sum += stock.PriceWithTimeStamp(inTimeStamp)*factor;
                 }
                 return Math.Round(sum, 3);
             }
         }
     }

     public class Portfolio : IStockRepository
     {
         public string ID { get; set; }
         private Dictionary<string, StockObject> _stockSet;
         public Dictionary<string, int> stockShareNumSet;
         public Portfolio(string inID)
         {
             this.ID = inID;
             this._stockSet = new Dictionary<string, StockObject>();
             this.stockShareNumSet = new Dictionary<string, int>();
         }

         public void AddStock(StockObject stockToAdd)
         {
             this._stockSet.Add(stockToAdd.StockName.ToUpper(), stockToAdd);
         }
         public int ReturnNumOfStocks()
         {
             return _stockSet.Count;
         }

         public bool ContainsStock(string inStockName)
         {
             return _stockSet.Keys.Contains(inStockName.ToUpper());
         }

         public void AddStock(StockObject stockToAdd, int num)
         {
             this.AddStock(stockToAdd);
             this.stockShareNumSet.Add(stockToAdd.StockName.ToUpper(), num);
         }

         public void RemoveStock(string inStockName)
         {
             this._stockSet.Remove(inStockName.ToUpper());
             this.stockShareNumSet.Remove(inStockName);
         }


         internal decimal TotalValueInSpecificTime(DateTime timeStamp)
         {
             decimal sum = _stockSet.Values.Sum(stock => stock.PriceWithTimeStamp(timeStamp)*this.stockShareNumSet[stock.StockName]);
             return Math.Round(sum,3);
         }
     }
}
