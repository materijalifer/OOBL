﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char BinaryOperation;                   //zapisuje se znak binarne operacije 'na cekanju'
        private string CurrentDisplay = "0";            //pocetno stanje ekrana

        private string Input = "";                      //niz ulaznih znakova

        private bool IsBinaryOperationOn = false;       //postoji li binarna operacija 'na cekanju'
        private bool IsErrorOn = false;                 //je li generirana greska
        private bool IsDecimalMarkOn = false;           //da li u broju koji se trenutno unosi vec postoji zarez
                                                        //ako je 'true' ne dopusta se unos jos jednog zareza

        private double Memory = 0;                      //broj koji se zapisuje u memoriju
        private double firstNum=0;                      //prvi broj kod binarnih operacija
        private double secondNum=0;                     //drugi broj kod binarnih operacija


       
        //******************************************************************************************//
        //                           Metoda unosi znak u kalkulator
        //******************************************************************************************//
        public void Press(char inPressedDigit)
        {
            if (IsErrorOn == false)
                //ako nije generirana greska, tj. na ekranu se ne nalazi "-E-" dopusti unos novih znakova
            {
                if (System.Char.IsDigit(inPressedDigit))
                    //je li uneseni znak broj
                {
                    PressedIsDigit(inPressedDigit);
                }
                else if (IsBinaryOperation(inPressedDigit))
                    //je li uneseni znak binarna operacija
                {
                    PressedIsBinaryOperation(inPressedDigit);
                }
                else if (IsUnaryOperation(inPressedDigit))
                    //je li uneseni znak unarna operacija
                {
                    PressedIsUnaryOperation(inPressedDigit);
                }
                else if (inPressedDigit == ',')
                {
                    PressedIsDecimalMark();
                }
                else if (inPressedDigit == 'M')
                {
                    PressedIsMinusPlus();
                }
                else if (inPressedDigit == '=')
                {
                    PressedIsEquals();
                }
                else if (inPressedDigit == 'P')
                {
                    PressedIsPutInMemory();
                }
                else if (inPressedDigit == 'G')
                {
                    PressedIsGetFromMemory();
                }
                else if (inPressedDigit == 'C')
                {
                    PressedIsClearDisplay();
                }
                else if (inPressedDigit == 'O')
                {
                    PressedIsOffOn();
                }
            }
            else
                //ako je generirana greska, tj. na ekranu se nalazi "-E-" ne prihvacaj unos novih znakova sve
                //dok se ne unese znak O kojim se kalkulator resetira
            {
                if (inPressedDigit == 'O')
                {
                    PressedIsOffOn();
                }
            }

            Input += inPressedDigit;        //dodaj novouneseni znak u ulazni niz znakova
        }



        //******************************************************************************************//
        //                  Metoda vraća trenutno stanje ekrana kalkulatora
        //******************************************************************************************//
        public string GetCurrentDisplayState()
        {
            return (CurrentDisplay);
        }



        //******************************************************************************************//
        //                  Metoda se izvršava ako je unesen znak jednakosti
        //******************************************************************************************//
        private void PressedIsEquals()
        {
            if (IsBinaryOperationOn == true)
                //ako postoji binarna operacija 'na cekanju', tj. prvi broj je vec unesen a drugi se nalazi
                //na ekranu, obavi binarnu operaciju
            {
                secondNum = Convert.ToDouble(CurrentDisplay);
                switch (BinaryOperation)
                {
                    case '+':
                        firstNum = firstNum + secondNum;
                        break;
                    case '-':
                        firstNum = firstNum - secondNum;
                        break;
                    case '*':
                        firstNum = firstNum * secondNum;
                        break;
                    case '/':
                        firstNum = firstNum / secondNum;
                        break;
                }
                CurrentDisplay=FormatNumber(firstNum, 10);
            }
            else
                //ako nema binarne operacije 'na cekanju' samo ispisi ponovno ono sto se nalazilo na ekranu
            {
                CurrentDisplay = Convert.ToDouble(CurrentDisplay).ToString();   //u slucaju da se na ekranu nalazi  
                                                                                //npr. "2," na ovaj ce se nacin nakon
                                                                                //znaka jednakosti ispisati samo "2"
            }

            IsBinaryOperationOn = false;    //pritiskom znaka jednakosti binarna operacija na cekanju je izvrsena
            IsDecimalMarkOn = false;        //unosenje zareza je ponovno dozvoljeno
        }



        //******************************************************************************************// 
        //                      Metoda se izvrsava ako je uneseni znak broj
        //******************************************************************************************//
        private void PressedIsDigit(char inPressedDigit)
        {
            if (Input.Length>0)     //ako su vec unoseni znakovi u kaltulator, tj. trenutni znak nije prvi uneseni
            {
                char PreviousInput1=Input[Input.Length-1];   //prethodno uneseni znak
                char PreviousInput2=' ';
                if (Input.Length>1) PreviousInput2 = Input[Input.Length - 2];   //znak prije prethodno unesenog

                if (
                    System.Char.IsDigit(PreviousInput1) || PreviousInput1 == ',' || PreviousInput1 == 'P' ||
                    (PreviousInput1 == 'M' && !IsBinaryOperation(PreviousInput2) && !IsUnaryOperation(PreviousInput2))
                    )
                {
                    if (DisplayFull(10)==false)
                        //ako je prethodno uneseni znak broj, zarez, 'P' ili 'M' (a da ispred 'M' nije binarna
                        //ili unarna operacija i ako ekran nije popunjen (nema vise od 10 znamenaka), nastavi
                        //unosenje znakova na postojeci niz
                        //U slucaju da je ekran pun ne unosi se novi broj - ispis ekrana ostaje isti
                    {
                        if (CurrentDisplay == "0") CurrentDisplay = inPressedDigit.ToString();
                        else CurrentDisplay+=inPressedDigit.ToString();
                    }
                }
                else
                {
                    CurrentDisplay=inPressedDigit.ToString();
                }
            }
            else 
            {
                CurrentDisplay=inPressedDigit.ToString(); //ako je ovo prvi znak koji se unosi samo ga ispisi na ekran
            }
        }



        //******************************************************************************************//
        //                  Metoda se izvrsava ako je unesen decimalni zarez
        //******************************************************************************************//
        private void PressedIsDecimalMark()
        {
            if (Input.Length > 0)   //ako su prethodno vec unoseni znakovi
            {
                char PreviousInput1 = Input[Input.Length - 1];   //prethodno uneseni znak
                char PreviousInput2 = ' ';
                if (Input.Length > 1) PreviousInput2 = Input[Input.Length - 2];   //znak prije prethodno unesenog

                if (
                    IsBinaryOperation(PreviousInput1) || IsUnaryOperation(PreviousInput1) ||
                    PreviousInput1 == '=' || PreviousInput1 == 'G' || PreviousInput1 == 'C' || PreviousInput1 == 'O' ||
                    (PreviousInput1 == 'M' && (IsBinaryOperation(PreviousInput2) || IsUnaryOperation(PreviousInput2)))
                    )
                        //ako je prethodno uneseni znak znak binarne ili unarne operacije, znak jednakosti, 'G', 'C',
                        //'O', ili znak 'M' ispred kojeg je binarna ili unarna operacija, zanemari ono sto je na 
                        //ekranu i zapocni s ipisivanjem novog decimalnog broja
                {
                    CurrentDisplay = "0,";
                }
                else
                {
                    if (IsDecimalMarkOn == false)
                        //ako je prethodno uneseni znak broj, 'M' ili 'P' i u trenutnom broju nema zareza dodaj zarez
                        //na kraj zapisa koju se nalazi na ekranu
                    {
                        CurrentDisplay += ",";
                    }
                }
            }
            else
            {
                CurrentDisplay = "0,";  //prvi uneseni znak je znak zareza pa se na ekranu prikazuje "0,"
            }

            IsDecimalMarkOn = true;     //u broju koji je trenutno na ekranu vec postoji zarez
        }



        
        //******************************************************************************************//
        //       Metoda se izvrsava ako je unesen znak binarne operacije (+, -, * ili /)
        //******************************************************************************************//
        private void PressedIsBinaryOperation(char inPressedDigit)
        {
            if (Input.Length > 0)
            {
                char PreviousInput = Input[Input.Length - 1];   //prethodno uneseni znak

                if (IsBinaryOperationOn == false)
                    //ako ne postoji bin. operacija na cekanju upisi broj na ekranu kao prvi operand (cak i ako je nula)
                {
                    firstNum = Convert.ToDouble(CurrentDisplay);
                }
                else if (IsBinaryOperationOn == true && IsBinaryOperation(PreviousInput)==false)
                    //ako postoji bin. operacija na cekanju i prethodni znak nije znak bin. operacije upisi broj
                    //koji je na ekranu kao drugi operand i izvrsi bin. operaciju prvog i drugog operanda
                {

                    secondNum = Convert.ToDouble(CurrentDisplay);
                    switch (BinaryOperation)
                    {
                        case '+':
                            firstNum = firstNum + secondNum;
                            break;
                        case '-':
                            firstNum = firstNum - secondNum;
                            break;
                        case '*':
                            firstNum = firstNum * secondNum;
                            break;
                        case '/':
                            firstNum = firstNum / secondNum;
                            break;
                    }
                    
                    secondNum = 0;      //prvi operand jednak rezultatu bin. operacije, 
                                        //a drugi se operand postavlja u nulu
                    CurrentDisplay = FormatNumber(firstNum, 10);    //formatiraj ispis na ekran prema zadanim pravilima
                                                                    //dopusteno je prikazivanje 10 znamenaka
                }
            }                

            BinaryOperation = inPressedDigit;   //upisani znak postaje binarna operacija na cekanju
            

            IsBinaryOperationOn = true;     //upisani znak postaje binarna operacija na cekanju
            IsDecimalMarkOn = false;        //unosenje zareza je ponovno dozvoljeno
        }



        //******************************************************************************************//
        //      Metoda se izvrsava ako je unesen znak unarne operacije (S, K, T, Q, R ili I)
        //******************************************************************************************//
        private void PressedIsUnaryOperation(char inPressedDigit)
        {
            double NumberOnScreen = Convert.ToDouble(CurrentDisplay);
            double AfterOperation=0;

            switch (inPressedDigit)
            {
                case 'S':
                    AfterOperation = Math.Sin(NumberOnScreen);
                    break;
                case 'K':
                    AfterOperation = Math.Cos(NumberOnScreen);
                    break;
                case 'T':
                    AfterOperation = Math.Tan(NumberOnScreen);
                    break;
                case 'Q':
                    AfterOperation = NumberOnScreen * NumberOnScreen;
                    break;
                case 'R':
                    AfterOperation = Math.Sqrt(NumberOnScreen);
                    break;
                case 'I':
                    AfterOperation = 1 / NumberOnScreen;
                    break;
            }

            CurrentDisplay = FormatNumber(AfterOperation, 10);  //formatiraj ispis na ekran prema zadanim pravilima
                                                                //dopusteno je prikazivanje 10 znamenaka

            IsDecimalMarkOn = false;
        }



        //******************************************************************************************//
        //              Metoda se izvrsava ako je unesen znak promjene predznaka - 'M'
        //******************************************************************************************//
        private void PressedIsMinusPlus()
        {
            decimal NumberOnScreen = Convert.ToDecimal(CurrentDisplay);
            if (NumberOnScreen < 0) CurrentDisplay = CurrentDisplay.Substring(1, CurrentDisplay.Length - 1);
                //ako je broj na ekranu manji od nule, izbaci prvi znak tj. znak minusa
            else if (NumberOnScreen > 0) CurrentDisplay = "-" + CurrentDisplay;
                //ako je broj na ekranu veci od nule dodaj mu minus na pocetak 
            else if (CurrentDisplay == "0,") CurrentDisplay = "-0,";
                //ako je trenutni broj nula ali za decimalnim zarezom (ceka se unos decimala) <dodaj minus na početak
            else if (CurrentDisplay == "-0,") CurrentDisplay = "0,";
                //ako je trenutni broj minus nula sa decimalnim zarezom (ceka se unos decimala) makni znak minusa
        }



        //******************************************************************************************//
        //                  Metoda se izvrsava ako je unesen znak spremanja u memoriju
        //******************************************************************************************//
        private void PressedIsPutInMemory()
        {
            Memory = Convert.ToDouble(CurrentDisplay);
        }



        //******************************************************************************************//
        //                  Metoda se izvrsava ako je unesen znak dohvacanja iz memorije
        //******************************************************************************************//
        private void PressedIsGetFromMemory()
        {
            CurrentDisplay = Memory.ToString();

            IsDecimalMarkOn = false;    //ponovno je dopusteno unosenje decimalnog zareza
        }



        //******************************************************************************************//
        //                  Metoda se izvrsava ako je unesen znak brisanja ekrana
        //******************************************************************************************//
        private void PressedIsClearDisplay()
        {
            CurrentDisplay = "0";

            IsDecimalMarkOn = false;    //ponovno je dopusteno unosenje decimalnog zareza
        }



        //******************************************************************************************//
        //                  Metoda se izvrsava ako je unesen znak resetiranja kalkulatora
        //******************************************************************************************//
        private void PressedIsOffOn()
        {
            CurrentDisplay = "0";          //pocetno stanje ekrana

            Input = "";                  //niz ulaznih znakova


            //sve zastavice i varijable postavljaju se u pocetno stanje
            IsBinaryOperationOn = false;
            IsDecimalMarkOn = false;
            IsErrorOn = false;

            Memory = 0;
            firstNum=0;
            secondNum=0;
        }



        //******************************************************************************************//
        //                              Metoda formatira broj za ispis
        //******************************************************************************************//
        private string FormatNumber (double Number, int MaxNumberOfDigits)
        {
            string FormatedNumber="";
            int NumberLength = Number.ToString().Length;    //od koliko se znakova sastoji broj koji je potrebno
                                                            //formatirati (ukljucujuci predznak i zarez)
            double maxNumber = Math.Pow(10, MaxNumberOfDigits)-0.5;  //broj za jedan veci od maksimalnog koji se moze
                                                                    //prikazati na ekranu (u slucaju ekrana sa 10
                                                                    //znamenki to je broj 10000000000 - uzima se broj za
                                                                    //0.5 manji jer će svaki broj veći od toga biti 
                                                                    //zaokruzen na 10000000000

            double minNumber = Math.Pow(10, -(MaxNumberOfDigits - 1));  //minimalni broj koji se moze prikazati

            if (Number == 0)
            {
                FormatedNumber = "0";
            }
            else if ((Math.Abs(Number) >= maxNumber) || (Math.Abs(Number) < minNumber))
                //ako je broj jednak ili veci maksimalnom ili manji od minimalnog generiraj gresku
            {
                FormatedNumber = "-E-";
                IsErrorOn = true;
            }
            else
            {
                string NumberString = Number.ToString("F10").TrimEnd('0').TrimEnd(',');   
                    //spremi broj kao string uz 10 decimala da se ukloni moguci eksponencijalni zapis
                    //zatim ukloni sve nule s desna koje su viska i zarez koji ostaje ako je broj bio cijeli

                bool isDecimal = NumberString.Contains(",");    //ako broj za ispis sadrzi zarez onda je decimalan
                bool isPositive = Number > 0;                   //je li broj za ispis veci od nule

                if (isPositive && isDecimal && NumberLength > (MaxNumberOfDigits + 1))
                    //ako je broj pozitivan i decimalan (nema predznak i ima zarez) onda ispis moze imati max.
                    //MaxNumberOfDigits znakova, a u slucaju da ima vise znakova potrebno ga je formatirati
                {
                    string wholePart = Math.Floor(Math.Abs(Number)).ToString(); //uzima samo cijeli dio decimalnog broja
                    int wholePartLength = wholePart.Length;     //koliko znamenaka ima cijeli dio decimalnog broja

                    if (wholePartLength < MaxNumberOfDigits)
                        //ako cijeli dio ima manje od MaxNumberOfDigits znamenaka izracunaj 
                        //koliki je preostali moguci broj decimala
                    {
                        int numberOfDecimals = MaxNumberOfDigits - wholePartLength;
                        Number = Math.Round(Number, numberOfDecimals);  //zaokruzi broj na izracunati broj decimala
                        FormatedNumber = Number.ToString();
                    }
                    else
                    //ako cijeli broj ima tocno MaxNumberOfDigits znamenaka zaokruzi ga i ispisi samo cijeli dio
                    {
                        Number = Math.Round(Number);
                        FormatedNumber = Number.ToString();
                    }
                }
                else if (isPositive == false && isDecimal && NumberLength > (MaxNumberOfDigits + 2))
                    //ako je broj negativan i decimalan (ima predznak i ima zarez) onda ispis moze imati max. 
                    //MaxNumberOfDigits+2 znaka, a u slucaju da ima vise znakova potrebno ga je formatirati
                {
                    string wholePart = Math.Floor(Math.Abs(Number)).ToString();     //uzmi cijeli dio apsolutne 
                                                                                    //vrijednosti broja
                    int wholePartLength = wholePart.Length;

                    if (wholePartLength < MaxNumberOfDigits)
                        //ako cijeli dio ima manje od MaxNumberOfDigits znamenaka izracunaj koliki je 
                        //preostali moguci broj decimala
                    {
                        int numberOfDecimals = MaxNumberOfDigits - wholePartLength;
                        Number = Math.Round(Number, numberOfDecimals);  //zaokruzi broj na izracunati broj decimala
                        FormatedNumber = Number.ToString();
                    }
                    else
                        //ako cijeli broj ima tocno MaxNumberOfDigits znamenaka zaokruzi ga i ispisi samo cijeli dio
                    {
                        Number = Math.Round(Number);
                        FormatedNumber = Number.ToString();
                    }
                }
                else
                {
                    FormatedNumber = NumberString;
                }
            }
            return FormatedNumber;
        }



        //******************************************************************************************//
        // Metoda provjerava je li ekran pun tj. da li je na njemu zadani maksimalni broj znamenaka
        //******************************************************************************************//
        private bool DisplayFull(int MaxNumberOfDigits)
        {
            bool isFull = false;
            int NumberLength = CurrentDisplay.Length;
            decimal number = Convert.ToDecimal(CurrentDisplay);
            bool isDecimal = CurrentDisplay.Contains(",");
            bool isPositive = number > 0;

            //Broj je pozitivan i decimalan (nema predznak, ima zarez) -> ekran sadrzava max. MaxNumberOfDigits+1 znak
            //Broj je negativan i decimalan (ima predznak, ima zarez) -> ekran sadrzava max. MaxNumberOfDigits+2 znaka
            //Broj pozitivan i nije decimalan (nema predznak, nema zarez) -> ekran sadrzava max. MaxNumberOfDigits znakova
            //Broj negativan i nije decimalan (ima predznak, nema zarez) -> ekran sadrzava max. MaxNumberOfDigits+1 znak
            // Ako za bilo koji od gornjih slucajeva broj znakova ekrana ima max. vrijednost, ekran je pun
            if (
                (isPositive && isDecimal && NumberLength == (MaxNumberOfDigits+1)) ||
                (isPositive == false && isDecimal && NumberLength == (MaxNumberOfDigits+2)) ||
                (isPositive && isDecimal == false && NumberLength == MaxNumberOfDigits) ||
                (isPositive == false && isDecimal == false && NumberLength == (MaxNumberOfDigits+1))
               )
            { isFull = true; }

            return isFull;
        }



        //******************************************************************************************//
        //              Metoda provjerava je li dobiveni znak znak binarne operacije
        //******************************************************************************************//
        private bool IsBinaryOperation(char Operation)
        {
            bool Result = false;
            if (Operation == '+' || Operation == '-' || Operation == '*' || Operation == '/') Result = true;

            return Result;
        }



        //******************************************************************************************//
        //              Metoda provjerava je li dobiveni znak znak unarne operacije
        //******************************************************************************************//
        private bool IsUnaryOperation(char Operation)
        {
            bool Result = false;
            if (Operation == 'S' || Operation == 'K' || Operation == 'T' ||
                Operation == 'Q' || Operation == 'R' || Operation == 'I') Result = true;

            return Result;
        }
    }
}
