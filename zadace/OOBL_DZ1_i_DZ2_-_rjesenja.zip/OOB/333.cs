﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        Dictionary<string, Index> Indexes;
        Dictionary<string, Portofolio> Portofolios;
        Dictionary<string, Stock> Stocks;

        public StockExchange()
        {
            Stocks = new Dictionary<string, Stock>(new NameEqualityComparer());
            Indexes = new Dictionary<string, Index>(new NameEqualityComparer());
            Portofolios = new Dictionary<string, Portofolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0 || inInitialPrice <= 0.0m)
            {
                throw new StockExchangeException("Cijena i broj dionica ne mogu biti nenegativni niti 0.");
            }
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica već postoji na burzi!");
            }
            Stocks.Add(inStockName, new Stock(inStockName, inInitialPrice, inTimeStamp, inNumberOfShares));
        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " se ne nalazi na burzi!");
            }

            Stocks.Remove(inStockName);
            foreach (string indexName in Indexes.Keys)
            {
                if (IsStockPartOfIndex(indexName, inStockName))
                {
                    RemoveStockFromIndex(indexName, inStockName);
                }
            }
            foreach (string portofolioId in Portofolios.Keys)
            {
                if (IsStockPartOfPortfolio(portofolioId, inStockName))
                {
                    RemoveStockFromPortfolio(portofolioId, inStockName);
                }
            }
        }

        public bool StockExists(string inStockName)
        {
            if (Stocks.ContainsKey(inStockName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return Stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " se ne nalazi na burzi!");
            }
            Stocks[inStockName].AddPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return Decimal.Round(findStock(inStockName).GetPrice(inTimeStamp), 3);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return Decimal.Round(findStock(inStockName).GetInitialPrice(), 3);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return Decimal.Round(findStock(inStockName).GetLastPrice(), 3);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index" + inIndexName + " već postoji na burzi!");
            }
            Indexes.Add(inIndexName, new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock s = findStock(inStockName);
            Index ind = findIndex(inIndexName);
            ind.AddStock(s);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index ind = findIndex(inIndexName);
            if (!IsStockPartOfIndex(inIndexName, inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " se ne nalazi u indeksu!");
            }
            ind.RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return findIndex(inIndexName).ContainsStock(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index ind = findIndex(inIndexName);
            return Decimal.Round(ind.CalculateIndexValue(inTimeStamp), 3);
        }

        public bool IndexExists(string inIndexName)
        {
            if (Indexes.ContainsKey(inIndexName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return Indexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index ind = findIndex(inIndexName);
            return ind.GetIndexStocks().Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portefelj " + inPortfolioID + " se vec nalazi na burzi!");
            }
            Portofolios.Add(inPortfolioID, new Portofolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            Stock s = findStock(inStockName);
            if (numberOfShares > s.GetNumberOfShares() || (p.PortofolioContainsShare(inStockName) && (numberOfShares + p.NumberOfSharesOfStock(inStockName) > s.GetNumberOfShares())))
            {
                throw new StockExchangeException("Ne mogu dodati u portefelj vise dionica no sto ih ima na burzi!");
            }
            p.AddStock(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            Stock s = findStock(inStockName);
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " nije dio portefelja!");
            }
            p.RemoveShare(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            Stock s = findStock(inStockName);
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " nije dio portefelja!");
            }
            p.RemoveStock(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return Portofolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            return p.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (!Portofolios.ContainsKey(inPortfolioID))
            {
                return false;
            }
            return true;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            Stock s = findStock(inStockName);
            return p.PortofolioContainsShare(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            Stock s = findStock(inStockName);
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                return p.NumberOfSharesOfStock(inStockName);
            }
            throw new StockExchangeException("Dionica " + inStockName + " nije dio portefelja!");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            return Decimal.Round(p.GetPortofolioValue(timeStamp, Stocks), 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portofolio p = findPortofolio(inPortfolioID);
            return Decimal.Round(p.GetPortofolioPercentChange(Year, Month, Stocks), 3);
        }

        private Stock findStock(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " se ne nalazi na burzi!");
            }
            return Stocks[inStockName];
        }

        private Index findIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Indeks " + inIndexName + " se ne nalazi na burzi!");
            }
            return Indexes[inIndexName];
        }

        private Portofolio findPortofolio(string inPortofolioName)
        {
            if (!PortfolioExists(inPortofolioName))
            {
                throw new StockExchangeException("Portofolio " + inPortofolioName + " se ne nalazi na burzi!");
            }
            return Portofolios[inPortofolioName];
        }
    }

    class Stock
    {
        private string Name;
        private Dictionary<DateTime, Decimal> Prices;
        private long NumberOfShares;

        public Stock(string inName, Decimal inInitialPrice, DateTime inTimeStamp, long inNumberOfShares)
        {
            SetName(inName);
            SetNumberOfShares(inNumberOfShares);
            Prices = new Dictionary<DateTime, decimal>()
            {
                {inTimeStamp, inInitialPrice},       
            };
        }

        public void AddPrice(Decimal inPrice, DateTime inTimeStamp)
        {
            if (Prices.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Za odredeni trenutak nije moguce unijeti vise zapisa cijena!");
            }
            Prices.Add(inTimeStamp, inPrice);
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            List<DateTime> times = Prices.Keys.ToList();
            times.Sort();
            if (inTimeStamp < times[0])
            {
                throw new StockExchangeException("Za datum " + inTimeStamp.ToString() + " nije definirana cijena!");
            }
            for (int i = 1; i < times.Count; i++)
            {
                if (inTimeStamp < times[i])
                {
                    return Prices[times[i - 1]];
                }
            }
            return Prices[times[times.Count - 1]];
        }

        public decimal GetLastPrice()
        {
            List<DateTime> times = Prices.Keys.ToList();
            times.Sort();
            return Prices[times[times.Count - 1]];
        }

        public void SetName(string name)
        {
            this.Name = name;
        }

        public string GetName()
        {
            return this.Name;
        }

        public decimal GetInitialPrice()
        {
            List<DateTime> times = Prices.Keys.ToList();
            times.Sort();
            return Prices[times[0]];
        }

        public void SetNumberOfShares(long inNumberOfShares)
        {
            this.NumberOfShares = inNumberOfShares;
        }

        public long GetNumberOfShares()
        {
            return this.NumberOfShares;
        }
    }

    class Index
    {
        private string Name;
        private IndexTypes IndexType;
        private Dictionary<string, Stock> Stocks;

        public Index(string inName, IndexTypes inIndexType)
        {
            Stocks = new Dictionary<string, Stock>(new NameEqualityComparer());
            SetName(inName);
            SetIndexType(inIndexType);
        }

        public void AddStock(Stock inStock)
        {
            if (Stocks.ContainsKey(inStock.GetName()))
            {
                throw new StockExchangeException("Dionica " + inStock.GetName() + " se vec nalazi u indeksu!");
            }
            Stocks.Add(inStock.GetName(), inStock);
        }

        public void RemoveStock(string inStockName)
        {
            Stocks.Remove(inStockName);
        }

        public Dictionary<string, Stock> GetIndexStocks()
        {
            return Stocks;
        }

        public bool ContainsStock(string inStockName)
        {
            if (Stocks.ContainsKey(inStockName))
            {
                return true;
            }
            return false;
        }

        public Decimal CalculateIndexValue(DateTime inTimeStamp)
        {
            decimal value = 0.0m;
            if (IndexType == IndexTypes.AVERAGE)
            {
                decimal sumOfShares = 0m;
                foreach (Stock s in Stocks.Values)
                {
                    value += s.GetPrice(inTimeStamp) * s.GetNumberOfShares();
                    sumOfShares += s.GetNumberOfShares();
                }
                value /= sumOfShares;
            }
            else
            {   // weighted
                decimal sum = 0.0m;
                foreach (Stock s in Stocks.Values)
                {
                    sum += s.GetPrice(inTimeStamp) * s.GetNumberOfShares();
                }
                foreach (Stock s in Stocks.Values)
                {
                    value += (s.GetPrice(inTimeStamp) * s.GetNumberOfShares() / sum) * s.GetPrice(inTimeStamp);
                }
            }
            return value;
        }

        public void SetName(string inName)
        {
            this.Name = inName;
        }

        public void SetIndexType(IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Tip indeksa je neispravan!");
            }
            this.IndexType = inIndexType;
        }
    }

    class Portofolio
    {
        private string Id;
        private Dictionary<string, long> Shares;

        public Portofolio(string inPortofolioID)
        {
            Shares = new Dictionary<string, long>(new NameEqualityComparer());
            setPortofolioID(inPortofolioID);
        }

        public decimal GetPortofolioValue(DateTime inTimeStamp, Dictionary<string, Stock> Stocks)
        {
            decimal value = 0.0m;
            foreach (string key in Shares.Keys)
            {
                value += Shares[key] * Stocks[key].GetPrice(inTimeStamp);
            }
            return value;
        }

        public decimal GetPortofolioPercentChange(int Year, int Month, Dictionary<string, Stock> Stocks)
        {
            DateTime beginDate = new DateTime(Year, Month, 1, 0, 0, 0, 000);
            DateTime endDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            decimal beginValue = GetPortofolioValue(beginDate, Stocks);
            decimal endValue = GetPortofolioValue(endDate, Stocks);

            return 100 * (endValue - beginValue) / beginValue;
        }

        public void AddStock(string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0 && !Shares.ContainsKey(inStockName))
            {
                throw new StockExchangeException("Ne mogu dodati dionicu " + inStockName + ", " + numberOfShares + " u portefelj!");
            }
            if (Shares.ContainsKey(inStockName))
            {
                Shares[inStockName] += numberOfShares;
            }
            else
            {
                Shares.Add(inStockName, numberOfShares);
            }
        }

        public void RemoveStock(string inStockName)
        {
            if (!Shares.ContainsKey(inStockName))
            {
                throw new StockExchangeException("Dionica " + inStockName + " nije dio portefelja!");
            }
            Shares.Remove(inStockName);
        }

        public void RemoveShare(string inShareName, int inNumberOfShares)
        {
            if (!Shares.ContainsKey(inShareName))
            {
                throw new StockExchangeException("Dionica " + inShareName + " nije dio portefelja!");
            }
            if (Shares[inShareName] < inNumberOfShares)
            {
                throw new StockExchangeException("Ne mogu maknuti vise dionica " + inShareName + " no sto ih ima u portefelju!");
            }
            if (inNumberOfShares < 0)
            {
                throw new StockExchangeException("Zadan je negativni broj...");
            }

            Shares[inShareName] -= inNumberOfShares;
            if (Shares[inShareName] == 0)
            {
                Shares.Remove(inShareName);
            }
        }

        public bool PortofolioContainsShare(string inShareName)
        {
            if (Shares.ContainsKey(inShareName))
            {
                return true;
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return Shares.Count;
        }

        public int NumberOfSharesOfStock(string inStockName)
        {
            return (int)Shares[inStockName];
        }

        public void setPortofolioID(string inPortofolioID)
        {
            this.Id = inPortofolioID;
        }
    }

    class NameEqualityComparer : IEqualityComparer<string>
    {
        public bool Equals(string s1, string s2)
        {
            if (s1.ToLower().Equals(s2.ToLower()))
            {
                return true;
            }
            return false;
        }

        public int GetHashCode(string s)
        {
            return s.ToLower().GetHashCode();
        }
    }
}
