﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string name { get; private set; }
        public long numberOfShares { get; private set; }
        List<StockPrice> _listPrices = new List<StockPrice>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Krivi broj dionica");
            }
            checkDuplicateDate(inTimeStamp);
            _listPrices.Add(new StockPrice(inInitialPrice, inTimeStamp));
            this.name = inStockName.ToLower();
            this.numberOfShares = inNumberOfShares;

        }

        private void checkDuplicateDate(DateTime inTimeStamp)
        {
            try
            {
                if ((from price in _listPrices
                     where price.timeStamp == inTimeStamp
                     select price).Count() > 0)
                    throw new StockExchangeException("Dupli datum za cijenu");
            }
            catch
            {
            }
        }

        public void setStockPrice(DateTime inTimeStamp, decimal inPrice)
        {
            checkDuplicateDate(inTimeStamp);
            _listPrices.Add(new StockPrice(inPrice, inTimeStamp));
        }

        public decimal getStockPrice(DateTime inTimeStamp)
        {
            try
            {
                return (from stockPrice in _listPrices
                        where stockPrice.timeStamp <= inTimeStamp
                        orderby stockPrice.timeStamp descending
                        select stockPrice.price).First();
            }
            catch
            {
                throw new StockExchangeException("Cijena nije definirana");
            }
        }

        public decimal getInitialStockPrice()
        {
            try
            {
                return (from stockPrice in _listPrices
                        orderby stockPrice.timeStamp ascending
                        select stockPrice.price).First();
            }
            catch
            {
                throw new StockExchangeException("Cijena nije definirana");
            }
        }
        public decimal getLastStockPrice()
        {
            try
            {
                return (from stockPrice in _listPrices
                        orderby stockPrice.timeStamp descending
                        select stockPrice.price).First();
            }
            catch
            {
                throw new StockExchangeException("Cijena nije definirana");
            }
        }
    }

    public class StockPrice
    {
        public decimal price { get; private set; }
        
        public DateTime timeStamp { get; private set; }
        public StockPrice(decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena nije ispravna");
            }

            this.price = inInitialPrice;
            this.timeStamp = inTimeStamp;
        }
    }

    public class Portfolio
    {
        public string ID {get; private set;}
        public List<StockShare> _listShares = new List<StockShare>();

        public Portfolio(string ID)
        {
            this.ID = ID.ToLower();
        }

        public void addStock(Stock stock, int shares)
        {
            try
            {
                (from share in _listShares
                 where share.stock.name == stock.name
                 select share).First().shares += shares;
            }
            catch
            {
                _listShares.Add(new StockShare(stock, shares));
            }
        }

        public void removeStock(Stock stock, int shares)
        {
            try
            {
                (from share in _listShares
                 where share.stock.name == stock.name
                 select share).First().shares -= shares;
                
                if (stockShareCount(stock) == 0)
                {
                    removeStock(stock);
                }
            }
            catch
            {
                throw new StockExchangeException("Udio ne postoji");
            }
        }

        public void removeStock(Stock stock)
        {
            if (isStockPartOfPortfolio(stock) == false)
                throw new StockExchangeException("Dionica ne postoji");
            _listShares.RemoveAll(x => x.stock.name == stock.name);
        }

        public int stocksCount()
        {
            return _listShares.Count;
        }

        public decimal portfolioValue(DateTime timeStamp )
        {
            try
            {
                return (from share in _listShares
                        select share.shares * share.stock.getStockPrice(timeStamp)).Sum();
            }
            catch
            {
                return 0m;
            }
        }

        public decimal percentChangeInValueForMonth(int Year, int Month)
        {
            decimal poc = portfolioValue(new DateTime(Year, Month, 0, 0, 0, 0, 0));
            decimal kraj = portfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            return  (kraj - poc) / poc * 100 ;
        }

        public int stockShareCount(Stock stock)
        {
            try
            {
                return (from share in _listShares
                        where share.stock.name == stock.name
                        select share.shares).First();
            }
            catch
            {
                return 0;
            }
        }

        public bool isStockPartOfPortfolio(Stock stock)
        {
            try
            {
                return (from share in _listShares
                        where share.stock.name == stock.name
                        select share).Count() > 0;
            }
            catch
            {
                return false;
            }

        }
    }

    public class StockShare
    {
        private int _shares;
        public int shares 
        { 
            get {
                return _shares;
            }
            set
            { 
                if (value <= 0) 
                    throw new StockExchangeException("Cijena nije ispravna");
                _shares = value;
            } 
        }
        public Stock stock {get; private set;}

        public StockShare(Stock stock, int shares)
        {
            this.stock = stock;
            this.shares = shares;
        }
    }

    public class Index
    {
        public IndexTypes type { get; private set; }
        public string name { get; private set; }
        private List<Stock> _stocksInIndex = new List<Stock>();

        public Index(string inName, IndexTypes type)
        {
            if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Krivi tip indexa");
            }
            this.name = inName.ToLower();
            this.type = type;
        }

        public void addStock(Stock stock)
        {
            if (getStockByName(stock.name) != null)
                throw new StockExchangeException("Dionica vec postoji");
            _stocksInIndex.Add(stock);
        }

        public void deleteStock(Stock stock)
        {
            if (getStockByName(stock.name) == null)
                throw new StockExchangeException("Dionica ne postoji");
            _stocksInIndex.Remove(stock);
        }

        public int countStocks()
        {
            return _stocksInIndex.Count;
        }

        public decimal getIndexValue(DateTime inTimeStamp)
        {
            if (this.type == IndexTypes.WEIGHTED)
            {
                return Math.Round( (from stock in _stocksInIndex
                        select stock.numberOfShares * stock.getStockPrice(inTimeStamp) * stock.getStockPrice(inTimeStamp)).Sum()
                        /
                        (from stock in _stocksInIndex
                         select stock.numberOfShares * stock.getStockPrice(inTimeStamp)).Sum(), 3);

            }
            else
            {
                return Math.Round((from stock in _stocksInIndex
                        select stock.numberOfShares * stock.getStockPrice(inTimeStamp)).Sum() / _stocksInIndex.Count, 3);
            }
        }

        public Stock getStockByName(string inStockName)
        {
            try
            {
                return (from stock in _stocksInIndex
                        where stock.name == inStockName.ToLower()
                        select stock).First();
            }
            catch
            {
                return null;
            }
        }
    }

    public class StockRepository
    {
        private static StockRepository _instance = null;

        List<Stock> _listStocks = new List<Stock>();

        public static StockRepository getInstance()
        {
            if (_instance == null)
                _instance = new StockRepository();

            return _instance;
        }

        public int Count()
        {
            return _listStocks.Count;
        }

        public void Add(Stock stock)
        {
            if (stockExists(stock.name))
                throw new StockExchangeException("Ime vec postoji");
            _listStocks.Add(stock);
        }

        public void Remove(string stockName)
        {
            _listStocks.RemoveAll(x => x.name == stockName.ToLower());
        }

        public bool stockExists(string stockName)
        {
            try
            {
                getStockByName(stockName);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Stock getStockByName(string stockName)
        {
            for (int i = 0; i < _listStocks.Count; i++)
                if (_listStocks[i].name == stockName.ToLower())
                    return _listStocks[i];
            throw new StockExchangeException("Dionica ne postoji");
        }

    }

    public class PortfolioRepository
    {
        private static PortfolioRepository _instance = null;

        List<Portfolio> _listPortfolios = new List<Portfolio>();

        public static PortfolioRepository getInstance()
        {
            if (_instance == null)
                _instance = new PortfolioRepository();

            return _instance;
        }

        public int Count()
        {
            return _listPortfolios.Count;
        }

        public void Add(Portfolio portfolio)
        {
            if(portfolioExists(portfolio.ID))
                throw new StockExchangeException("Portfolio vec postoji");
            _listPortfolios.Add(portfolio);
        }

        public int countStockSharesInAllPortfolios(string inStockName)
        {
            try
            {
                return (from portfolio in _listPortfolios
                        from share in portfolio._listShares
                        where share.stock.name == inStockName.ToLower()
                        select share.shares).Sum();
            }
            catch
            {
                return 0;
            }
        }

        public bool portfolioExists(string ID)
        {
            try
            {
                getPortfolioByID(ID);
                return true;
            }
            catch
            {
                return false;
            }

        }
        public Portfolio getPortfolioByID(string ID)
        {
            try
            {
                return (from portfolio in _listPortfolios
                        where portfolio.ID == ID.ToLower()
                        select portfolio).First();
            }
            catch
            {
                throw new StockExchangeException("Portfolio ne postoji");
            }
        }

    }

    public class IndexRepository
    {
        private static IndexRepository _instance = null;

        List<Index> _listIndexes = new List<Index>();

        public static IndexRepository getInstance()
        {
            if (_instance == null)
                _instance = new IndexRepository();

            return _instance;
        }

        public int Count()
        {
            return _listIndexes.Count;
        }

        public Index getIndexByName(string indexName)
        {
            for (int i = 0; i < _listIndexes.Count; i++)
                if (_listIndexes[i].name == indexName.ToLower())
                    return _listIndexes[i];
            throw new StockExchangeException("Index ne postoji");
        }

        public bool indexExists(string indexName)
        {
            try
            {
                getIndexByName(indexName);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void Add(Index index)
        {
            if (indexExists(index.name))
                throw new StockExchangeException("ime vec postoji");
            _listIndexes.Add(index);
        }

    }

    public class StockExchange : IStockExchange
    {

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockRepository.getInstance().Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            StockRepository.getInstance().Remove(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return StockRepository.getInstance().stockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return StockRepository.getInstance().Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            StockRepository.getInstance().getStockByName(inStockName).setStockPrice(inTimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return StockRepository.getInstance().getStockByName(inStockName).getStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return StockRepository.getInstance().getStockByName(inStockName).getInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return StockRepository.getInstance().getStockByName(inStockName).getLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            IndexRepository.getInstance().Add(new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            IndexRepository.getInstance().getIndexByName(inIndexName).addStock(StockRepository.getInstance().getStockByName(inStockName));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            IndexRepository.getInstance().getIndexByName(inIndexName).deleteStock(StockRepository.getInstance().getStockByName(inStockName));
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return IndexRepository.getInstance().getIndexByName(inIndexName).getStockByName(inStockName) != null;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return IndexRepository.getInstance().getIndexByName(inIndexName).getIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return IndexRepository.getInstance().indexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return IndexRepository.getInstance().Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return IndexRepository.getInstance().getIndexByName(inIndexName).countStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            PortfolioRepository.getInstance().Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares + PortfolioRepository.getInstance().countStockSharesInAllPortfolios(inStockName) > StockRepository.getInstance().getStockByName(inStockName).numberOfShares)
                throw new StockExchangeException("Nema dovoljno dionica");
            PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).addStock(StockRepository.getInstance().getStockByName(inStockName),numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).removeStock(StockRepository.getInstance().getStockByName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).removeStock(StockRepository.getInstance().getStockByName(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return PortfolioRepository.getInstance().Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).stocksCount();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return PortfolioRepository.getInstance().portfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).isStockPartOfPortfolio(StockRepository.getInstance().getStockByName(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).stockShareCount(StockRepository.getInstance().getStockByName(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).portfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return PortfolioRepository.getInstance().getPortfolioByID(inPortfolioID).percentChangeInValueForMonth(Year, Month);
        }
    }
}
