﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
     public class StockExchange : IStockExchange
     {
         private StockContainer _sc; 
         private IndexContainer _ic ;
         private PortfolioContainer _pc; 
         public StockExchange()
         {
             _sc = new StockContainer();
             _ic = new IndexContainer(_sc);
             _pc = new PortfolioContainer(_sc);
         }
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _sc.ListStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
         }

         public void DelistStock(string inStockName)
         {
             _sc.DelistStock(inStockName);
         }

         public bool StockExists(string inStockName)
         {
            return _sc.StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return _sc.StockCount();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             _sc.SetPrice(inStockName, inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return _sc.GetPrice(inStockName, inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return _sc.GetInitialPrice(inStockName);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return _sc.GetLastPrice(inStockName);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             _ic.CreateIndex(inIndexName, inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             _ic.AddStock(inIndexName, inStockName);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             _ic.RemoveStock(inIndexName, inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _ic.IsStockPartOfIndex(inIndexName, inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return _ic.GetIndexValue(inIndexName, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _ic.IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _ic.IndexCount();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _ic.StockInIndexCuont(inIndexName);
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             _pc.CreatePortfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _pc.AddStockToPortfolio(inPortfolioID, inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _pc.RemoveStockFromPortfolio(inPortfolioID, inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             _pc.RemoveStockFromPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _pc.NumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return _pc.NumberOfStocksInPortfolio(inPortfolioID);
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _pc.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return _pc.IsStockPartOfPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return _pc.NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return _pc.GetPortfolioValue(inPortfolioID, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return _pc.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
         }
     }
     public class Stock
     {
         public Stock(string name, long numberOfShares, DateTime timeStamp, decimal initialPrice)
         {
             Name = name;
             NumberOfShares = numberOfShares;
             PriceChanges = new List<PriceChange>();
             PriceChanges.Add(new PriceChange() { TimeStamp = timeStamp, Price = initialPrice });
         }
         public string Name { get; private set; }
         public long NumberOfShares { get; private set; }
         public List<PriceChange> PriceChanges { get; set; }
     }
     public class PriceChange
     {
         public DateTime TimeStamp { get; set; }
         public Decimal Price { get; set; }
     }

     public class StockContainer
     {
         public delegate void StockRemoveDelegate(Stock removedStock);
         public event StockRemoveDelegate StockRemoved;

         private List<Stock> _stocks;
         public StockContainer()
         {
             _stocks = new List<Stock>();
         }
         public void ListStock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp)
         {
             string upperCaseName = name.ToUpper();
             if (initialPrice <= 0) throw new StockExchangeException("Vrijednost dionice mora biti veća od 0");
             if (numberOfShares <= 0) throw new StockExchangeException("Količina dionice mora biti veća od 0");
             if (_stocks.Any(x => x.Name == upperCaseName)) throw new StockExchangeException("Postoji dionica sa danim imenom");
             _stocks.Add(new Stock(upperCaseName, numberOfShares, timeStamp, initialPrice));
         }
         public Stock FindStock(string name)
         {
             return GetStock(name);
         }
         public void DelistStock(string name)
         {
             var stock = GetStock(name);
             _stocks.Remove(stock);
             OnStockRemoved(stock);
         }
         public bool StockExists(string name)
         {
             return _stocks.Any(x => x.Name == name.ToUpper());
         }
         public int StockCount()
         {
             return _stocks.Count();
         }
         public void SetPrice(string name, DateTime timeStamp, decimal value)
         {
             if (value < 0) throw new StockExchangeException("Vrijednost dionice mora biti veća od 0");
             var stock = GetStock(name);
             if (stock.PriceChanges.Any(x => x.TimeStamp == timeStamp)) throw new StockExchangeException("Postoji cijena definirana u danom trnutku");
             stock.PriceChanges.Add(new PriceChange { TimeStamp = timeStamp, Price = value });
         }
         public Decimal GetPrice(string name, DateTime timeStamp)
         {
             var stock = GetStock(name);
             var priceChange = stock.PriceChanges.Where(x => x.TimeStamp <= timeStamp).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
             if (priceChange == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
             return priceChange.Price;
         }
         public Decimal GetInitialPrice(string name)
         {
             var stock = GetStock(name);
             return stock.PriceChanges.OrderBy(x => x.TimeStamp).FirstOrDefault().Price;
         }
         public Decimal GetLastPrice(string name)
         {
             var stock = GetStock(name);
             return stock.PriceChanges.OrderByDescending(x => x.TimeStamp).FirstOrDefault().Price;
         }
         private Stock GetStock(string name)
         {
             var stock = _stocks.Find(x => x.Name == name.ToUpper());
             if (stock == null) throw new StockExchangeException("Ne postoji dionica sa danim imenom");
             return stock;
         }
         protected void OnStockRemoved(Stock removedStock)
         {
             if (StockRemoved != null)
             {
                 StockRemoved(removedStock);
             }
         }
     }
     public abstract class Index
     {
         protected static int numberOfFractionalDigits = 3;
         public Index(string name)
         {
             Name = name;
             Stocks = new List<Stock>();
         }
         public string Name { get; private set; }
         public List<Stock> Stocks { get; set; }
         abstract public decimal Value(DateTime timeStamp);
     }
     public class IndexFactory
     {
         static public Index getIndex(string name, IndexTypes type)
         {
             if (type == IndexTypes.AVERAGE) return new AverageIndex(name);
             else if (type == IndexTypes.WEIGHTED) return new WeightedIndex(name);
             else throw new StockExchangeException("Nepodržan tip indeksa");
         }
     }
     public class AverageIndex : Index
     {
         public AverageIndex(string name) : base(name) { }
         public override decimal Value(DateTime timeStamp)
         {
             decimal stockPriceSum = 0;
             foreach (var stock in Stocks)
             {
                 var priceChange = stock.PriceChanges.Where(x => x.TimeStamp <= timeStamp).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
                 if (priceChange == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
                 var Price = priceChange.Price;
                 stockPriceSum += priceChange.Price;
             }
             return Math.Round(stockPriceSum / Stocks.Count, numberOfFractionalDigits);
         }
     }
     public class WeightedIndex : Index
     {
         public WeightedIndex(string name) : base(name) { }
         class StockPriceAndNumber
         {
             public Decimal Price { get; set; }
             public long NumberOfShares { get; set; }
         }
         public override decimal Value(DateTime timeStamp)
         {
             decimal stockValueSum = 0;
             List<StockPriceAndNumber> stockPrices = new List<StockPriceAndNumber>();
             foreach (var stock in Stocks)
             {
                 var priceChange = stock.PriceChanges.Where(x => x.TimeStamp <= timeStamp).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
                 if (priceChange == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
                 var Price = priceChange.Price;
                 stockValueSum += priceChange.Price * stock.NumberOfShares;
                 stockPrices.Add(new StockPriceAndNumber { Price = priceChange.Price, NumberOfShares = stock.NumberOfShares });
             }
             decimal veightedValue = 0;
             foreach (var stockPrice in stockPrices)
             {
                 veightedValue += stockPrice.NumberOfShares * stockPrice.Price * stockPrice.Price / stockValueSum;
             }
             return Math.Round(veightedValue, numberOfFractionalDigits);
         }
     }
     class IndexContainer
     {
         private StockContainer _stockContainer;
         private List<Index> _indexes;
         public IndexContainer(StockContainer stockContainer)
         {
             _stockContainer = stockContainer;
             _indexes = new List<Index>();
             StockContainer.StockRemoveDelegate delegateMethod = new StockContainer.StockRemoveDelegate(stockRemovedFromStockcontainer);
             _stockContainer.StockRemoved += delegateMethod;
         }
         public void CreateIndex(string name, IndexTypes type)
         {
             if (_indexes.Any(x => x.Name == name.ToUpper())) throw new StockExchangeException("Postoji indeks sa danim imenom");
             _indexes.Add(IndexFactory.getIndex(name.ToUpper(), type));
         }
         public void AddStock(string indexName, string stockName)
         {
             var index = _indexes.Find(x => x.Name == indexName.ToUpper());
             if (index == null) throw new StockExchangeException("Ne postoji indeks sa danim imenom");
             var stock = _stockContainer.FindStock(stockName);
             if (index.Stocks.Any(x => x.Name == stock.Name)) throw new StockExchangeException("Indeks već sadrži dionicu");
             index.Stocks.Add(stock);
         }
         public void RemoveStock(string indexName, string stockName)
         {
             var index = GetIndex(indexName);
             var stock = _stockContainer.FindStock(stockName);
             if (!index.Stocks.Any(x => x.Name == stock.Name)) throw new StockExchangeException("Dionica ne postoji u indeksu");

             index.Stocks.Remove(stock);
         }
         public bool IsStockPartOfIndex(string indexName, string stockName)
         {
             if (!_stockContainer.StockExists(stockName.ToUpper())) throw new StockExchangeException("Ne postoji dionica sa danim imenom");
             var index = GetIndex(indexName);
             return index.Stocks.Any(x => x.Name == stockName.ToUpper());
         }
         public decimal GetIndexValue(string indexName, DateTime timeStamp)
         {
             var index = GetIndex(indexName);
             return index.Value(timeStamp);
         }
         public bool IndexExists(string indexName)
         {
             return _indexes.Any(x => x.Name == indexName.ToUpper());
         }
         public int IndexCount()
         {
             return _indexes.Count;
         }
         public int StockInIndexCuont(string indexName)
         {
             var index = GetIndex(indexName);
             return index.Stocks.Count;
         }
         private Index GetIndex(string indexName)
         {
             var index = _indexes.Find(x => x.Name == indexName.ToUpper());
             if (index == null) throw new StockExchangeException("Ne postoji indeks sa danim imenom");
             return index;
         }
         private void stockRemovedFromStockcontainer(Stock stock)
         {
             foreach (var index in _indexes)
             {
                 if (index.Stocks.Contains(stock)) index.Stocks.Remove(stock);
             }
         }
     }
     public class Portfolio
     {
         public Portfolio(string id)
         {
             Id = id;
             StockShares = new List<StockShare>();
         }
         public string Id { get; private set; }
         public List<StockShare> StockShares { get; set; }
     }
     public class StockShare
     {
         public Stock Stock { get; set; }
         public int NumberOfShares { get; set; }
     }
     class PortfolioContainer
     {
         protected static int numberOfFractionalDigitsForCalculation = 3;
         private List<Portfolio> _portfolios;
         private StockContainer _stockContainer;
         public PortfolioContainer(StockContainer stockContainer)
         {
             _stockContainer = stockContainer;
             _portfolios = new List<Portfolio>();
             StockContainer.StockRemoveDelegate delegateMethod = new StockContainer.StockRemoveDelegate(stockRemovedFromStockcontainer);
             _stockContainer.StockRemoved += delegateMethod;
         }
         public void CreatePortfolio(string portfolioId)
         {
             if (_portfolios.Any(x => x.Id == portfolioId)) throw new StockExchangeException("Portfolio sa danim id-jem već postoji");
             _portfolios.Add(new Portfolio(portfolioId));
         }
         public void AddStockToPortfolio(string portfolioId, string stockName, int numberOfShares)
         {
             var portfolio = getPortfolio(portfolioId);
             var stock = _stockContainer.FindStock(stockName);
             if (numberOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od 0");
             int numberOfAllSharesInPortfolios = _portfolios.Sum(x => x.StockShares.Sum(ss => ss.NumberOfShares));
             if (numberOfAllSharesInPortfolios + numberOfShares > stock.NumberOfShares)
             {
                 numberOfShares = (int)stock.NumberOfShares - numberOfAllSharesInPortfolios; // add as much as possible
             }
             var existingShare = portfolio.StockShares.Find(x => x.Stock == stock);
             if (existingShare == null)
             {
                 portfolio.StockShares.Add(new StockShare { Stock = stock, NumberOfShares = numberOfShares });
             }
             else
             {
                 existingShare.NumberOfShares += numberOfShares;
             }
         }
         public void RemoveStockFromPortfolio(string portfolioID, string stockName, int numberOfShares)
         {
             var portfolio = getPortfolio(portfolioID);
             var stock = _stockContainer.FindStock(stockName);
             if (numberOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od 0");
             var existingShare = portfolio.StockShares.Find(x => x.Stock == stock);
             if (existingShare == null) throw new StockExchangeException("Portfolio ne sadrži dane dionice");
             existingShare.NumberOfShares -= numberOfShares;
             if (existingShare.NumberOfShares <= 0) portfolio.StockShares.Remove(existingShare);
         }
         public void RemoveStockFromPortfolio(string portfolioID, string stockName)
         {
             var portfolio = getPortfolio(portfolioID);
             var stock = _stockContainer.FindStock(stockName);
             var existingShare = portfolio.StockShares.Find(x => x.Stock == stock);
             if (existingShare == null) throw new StockExchangeException("Portfolio ne sadrži dane dionice");
             portfolio.StockShares.Remove(existingShare);
         }
         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }
         public int NumberOfStocksInPortfolio(string portfolioID)
         {
             var portfolio = getPortfolio(portfolioID);
             return portfolio.StockShares.Count;
         }
         public bool PortfolioExists(string portfolioID)
         {
             return _portfolios.Any(x => x.Id == portfolioID);
         }
         public bool IsStockPartOfPortfolio(string portfolioID, string stockName)
         {
             var portfolio = getPortfolio(portfolioID);
             // var stock = _stockContainer.FindStock(stockName); - navodno se ne treba provjeravati da li stock postoji...
             return portfolio.StockShares.Any(x => x.Stock.Name == stockName.ToUpper());
         }
         public int NumberOfSharesOfStockInPortfolio(string portfolioID, string stockName)
         {
             var portfolio = getPortfolio(portfolioID);
             var stock = _stockContainer.FindStock(stockName);
             var existingShare = portfolio.StockShares.Find(x => x.Stock == stock);
             if (existingShare == null) throw new StockExchangeException("Portfolio ne sadrži dane dionice");
             return existingShare.NumberOfShares;
         }
         public Decimal GetPortfolioValue(string portfolioID, DateTime timeStamp)
         {
             var portfolio = getPortfolio(portfolioID);
             decimal portfolioValue = 0;
             foreach (var share in portfolio.StockShares)
             {
                 var priceChange = share.Stock.PriceChanges.Where(x => x.TimeStamp <= timeStamp).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
                 if (priceChange == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
                 portfolioValue += priceChange.Price * share.NumberOfShares;
             }
             return portfolioValue;
         }
         public Decimal GetPortfolioPercentChangeInValueForMonth(string portfolioID, int year, int month)
         {
             DateTime startDateTime;
             DateTime endDateTime;
             try
             {
                 startDateTime = new DateTime(year, month, 1, 0, 0, 0);
                 endDateTime = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
             }
             catch
             {
                 throw new StockExchangeException("krivo unesen datum");
             }
             var portfolio = getPortfolio(portfolioID);
             decimal startPortfolioValue = 0;
             decimal endPortfolioValue = 0;
             foreach (var share in portfolio.StockShares)
             {
                 var startPrice = share.Stock.PriceChanges.Where(x => x.TimeStamp <= startDateTime).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
                 if (startPrice == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
                 startPortfolioValue += Math.Round(startPrice.Price, numberOfFractionalDigitsForCalculation);

                 var endPrice = share.Stock.PriceChanges.Where(x => x.TimeStamp <= endDateTime).OrderByDescending(x => x.TimeStamp).FirstOrDefault();
                 if (endPrice == null) throw new StockExchangeException("Cijena dionice nije postavljena za dano vrijeme");
                 endPortfolioValue += Math.Round(endPrice.Price, numberOfFractionalDigitsForCalculation);
             }
             return Decimal.Truncate(((endPortfolioValue - startPortfolioValue) / startPortfolioValue) * 100);
         }
         private Portfolio getPortfolio(string portfolioID)
         {
             var portfolio = _portfolios.Find(x => x.Id == portfolioID);
             if (portfolio == null) throw new StockExchangeException("Portfolio sa danim id-jem ne postoji");
             return portfolio;
         }

         private void stockRemovedFromStockcontainer(Stock stock)
         {
             foreach (var portfolio in _portfolios)
             {
                 var share = portfolio.StockShares.Find(x => x.Stock == stock);
                 if (share != null) portfolio.StockShares.Remove(share);
             }
         }
     }
}
