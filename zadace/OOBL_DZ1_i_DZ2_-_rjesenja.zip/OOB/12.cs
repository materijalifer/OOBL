﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private Ekran ekran;
        public Memorija mem;
        private double rezultat;
        private string strOperand;
        private double operand;
        private char zadnjePritisnuto;
        private char zadnjaBinarnaOp;

        public Kalkulator()
        {
            ekran = new Ekran();
            mem = new Memorija();
            rezultat = 0;
            strOperand = "0";
            operand = 0;
            zadnjaBinarnaOp = 'n';

            ekran.SetSadrzaj(operand);
        }

        public void Press(char inPressedDigit)
        {
            ///
            if ( ekran.GetSadrzaj() != "-E-" ||
                (ekran.GetSadrzaj() == "-E-" && inPressedDigit == 'C') ||
                (ekran.GetSadrzaj() == "-E-" && inPressedDigit == 'O'))
            {
            ///

                // napravit case za stisnutu tipku
                //    ako je BROJKA obradit operand
                //    ako je UNARNA operacija obradit operand
                //    ako je BINARNA operacija pospremit prvi operand urezultat i operaciju
                //          te nastavit s unosom ili ako je vec postavljen
                //          prvi operand i postoji operacija te je ovo
                //          kraj unosa drugog operanda izracunat prvu operaciju
                //          u rezultat te postupati kao da je prvi slucaj

                if (inPressedDigit >= '0' && inPressedDigit <= '9') ObradiBroj(inPressedDigit);
                else if (IsBinaryOperator(inPressedDigit)) ObradiBinarni(inPressedDigit);
                else if (IsUnarOperator(inPressedDigit)) ObradiUnarni(inPressedDigit);
                else if (IsMemOperator(inPressedDigit)) ObradiMemOp(inPressedDigit);
                else
                    switch (inPressedDigit)
                    {
                        case ',':
                            UbaciZarez();
                            break;
                        case '=':
                            Izracunaj();
                            break;
                        case 'C':
                            BrisanjeEkrana();
                            break;
                        case 'O':
                            Reset();
                            break;
                    }

                zadnjePritisnuto = inPressedDigit;
            }

        }

        public string GetCurrentDisplayState()
        {
            return ekran.GetSadrzaj();
        }

        private void ObradiBroj(char broj)
        {
            if ( (IsUnarOperator(zadnjePritisnuto) && zadnjePritisnuto != 'M') ||
                  IsBinaryOperator(zadnjePritisnuto) )      
            {
                operand = 0;
                strOperand = "0";
            }

            if (zadnjePritisnuto == '=' )
            {
                operand = 0;
                strOperand = "0";
                rezultat = 0;
                zadnjaBinarnaOp = 'n';
            }

            if (  (!strOperand.Contains(",") && !strOperand.Contains("-") && strOperand.Length <= 9) ||
                  ( strOperand.Contains(",") && !strOperand.Contains("-") && strOperand.Length <= 10) ||
                  (!strOperand.Contains(",") &&  strOperand.Contains("-") && strOperand.Length <= 10) ||
                  ( strOperand.Contains(",") &&  strOperand.Contains("-") && strOperand.Length <= 11)  )
            {
                strOperand += broj;
            }

            //makni vodeće nule
            while (strOperand[0] == '0' &&  Math.Abs(Double.Parse(strOperand)) >= 1)
                strOperand = strOperand.Substring(1, strOperand.Length - 1);

            //višak nula još uklanjaj
            if (strOperand[0] == '0' && strOperand[1] == '0')
                strOperand = strOperand.Substring(1, strOperand.Length - 1);

            operand = Double.Parse(strOperand);
            ekran.SetSadrzaj(strOperand);
        }

        private void ObradiUnarni(char op)
        {
            switch (op)
            {
                case 'M':
                    operand *= -1;
                    break;

                case 'S':
                    operand = Math.Sin(operand);
                    break;

                case 'K':
                    operand = Math.Cos(operand);
                    break;

                case 'T':
                    operand = Math.Tan(operand);
                    break;

                case 'Q':
                    operand *= operand;
                    break;

                case 'R':
                    operand = Math.Sqrt(operand);
                    break;

                case 'I':
                    // pazi na dijeljenje s 0
                    if (operand != 0) operand = 1 / operand;
                    else operand = Double.MaxValue;
                    break;
            }

            strOperand = operand.ToString("G10", CultureInfo.CreateSpecificCulture("hr-HR"));
            if ((strOperand.Contains(",") && strOperand[1] == ',') ||
                 (strOperand[0] == '-' && strOperand.Contains(",") && strOperand[2] == ','))
                strOperand = operand.ToString("G9", CultureInfo.CreateSpecificCulture("hr-HR"));

            operand = Double.Parse(strOperand);

            ekran.SetSadrzaj(operand);
        }

        private void ObradiBinarni(char op)
        {
            string strRezultat;
            
            if (IsBinaryOperator(zadnjePritisnuto))
            {
                zadnjaBinarnaOp = op;
            }

            else
            {
                if (zadnjePritisnuto == '=')
                {
                    zadnjaBinarnaOp = 'n';
                    operand = rezultat;
                }

                switch (zadnjaBinarnaOp)
                {
                    case '+':
                        rezultat += operand;
                        break;

                    case '-':
                        rezultat -= operand;
                        break;

                    case '*':
                        rezultat *= operand;
                        break;

                    case '/':
                        if (operand != 0) rezultat /= operand;
                        else rezultat = Double.MaxValue;
                        break;

                    case 'n':
                        rezultat = operand;
                        break;
                }

                strRezultat = rezultat.ToString("G10", CultureInfo.CreateSpecificCulture("hr-HR"));
                if ( (strRezultat.Contains(",") && strRezultat[1] == ',') ||
                     (strRezultat[0] == '-' && strRezultat.Contains(",") && strRezultat[2] == ','))
                    strRezultat = rezultat.ToString("G9", CultureInfo.CreateSpecificCulture("hr-HR"));

                rezultat = Double.Parse(strRezultat);

                operand = rezultat;
                ekran.SetSadrzaj(rezultat);
                zadnjaBinarnaOp = op;
            }
        }

        private void ObradiMemOp(char op)
        {
            switch(op)
            {
                case 'P':
                    mem.SetSadrzaj(operand);
                    break;

                case 'G':
                    operand = mem.GetSadrzaj();
                    ekran.SetSadrzaj(operand);
                    break;
            }
        }

        private bool IsBinaryOperator(char op)
        {
            if (op == '+' || op == '-' || op == '*' || op == '/') return true;
            else return false;
        }

        private bool IsUnarOperator(char op)
        {
            if (op == 'M' || op == 'S' || op == 'K' || op == 'T' || op == 'Q' || op == 'R' || op == 'I') return true;
            else return false;
        }

        private bool IsMemOperator(char op)
        {
            if (op == 'P' || op == 'G') return true;
            else return false;
        }

        private void UbaciZarez()
        {
            if (strOperand.Length <= 11 && !strOperand.Contains(","))
            {
                strOperand += ',';
                ekran.SetSadrzaj(strOperand);
            }
        }
        
        private void Izracunaj()
        {
            string strRezultat;
            
            switch (zadnjaBinarnaOp)
            {
                case '+':
                    rezultat += operand;
                    break;

                case '-':
                    rezultat -= operand;
                    break;

                case '*':
                    rezultat *= operand;
                    break;

                case '/':
                    if (operand != 0) rezultat /= operand;
                    else rezultat = Double.MaxValue;
                    break;

                case 'n':
                    rezultat = operand;
                    break;
            }

            strRezultat = rezultat.ToString("G10", CultureInfo.CreateSpecificCulture("hr-HR"));
            if ((strRezultat.Contains(",") && strRezultat[1] == ',') ||
                 (strRezultat[0] == '-' && strRezultat.Contains(",") && strRezultat[2] == ','))
                strRezultat = rezultat.ToString("G9", CultureInfo.CreateSpecificCulture("hr-HR"));

            rezultat = Double.Parse(strRezultat);

            ekran.SetSadrzaj(rezultat);
        }

        private void BrisanjeEkrana()
        {
            //rezultat = 0;
            strOperand = "0";
            operand = 0;
            //zadnjaBinarnaOp = 'n';

            ekran.SetSadrzaj(operand);
        }

        private void Reset()
        {
            rezultat = 0;
            strOperand = "0";
            operand = 0;
            zadnjaBinarnaOp = 'n';

            mem.SetSadrzaj(0);

            ekran.SetSadrzaj(operand);
        }

    }

    public class Ekran
    {
        private string sadrzaj;

        public int SetSadrzaj(double ulaz)
        {
            string temp = ulaz.ToString("G10", CultureInfo.CreateSpecificCulture("hr-HR"));
            if ( (temp.Contains(",") && temp[1] == ',') ||
                 (temp[0] == '-' && temp.Contains(",") && temp[2] == ',') )
                temp = ulaz.ToString("G9", CultureInfo.CreateSpecificCulture("hr-HR"));

            if (temp.Contains("E"))
            {
                sadrzaj = "-E-";
                return -1;
            }
            else
            {
                sadrzaj = temp;
                return 0;
            }
        }

        public int SetSadrzaj(string s)
        {
            sadrzaj = s;
            return 0;
        }

        public string GetSadrzaj()
        {
            return sadrzaj;
        }
    }

    public class Memorija
    {
        private double sadrzaj = 0;

        public void SetSadrzaj(double s)
        {
            sadrzaj = s;
        }

        public double GetSadrzaj()
        {
            return sadrzaj;
        }
    }
}
