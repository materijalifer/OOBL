﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class StockExchange : IStockExchange
    {
        private readonly StockRepository _stockRep = new StockRepository();
        private readonly IndexRepository _indexRep = new IndexRepository();
        private readonly PortfolioRepository _portfolioRep = new PortfolioRepository();




        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockRep.ListStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            _stockRep.DelistStock(inStockName);

        }

        public bool StockExists(string inStockName)
        {
            return _stockRep.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {

            return _stockRep.GetCount();
        }
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            _stockRep.GetStockWithName(inStockName).setStockPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockRep.GetStockWithName(inStockName).stockPriceForDate(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockRep.GetStockWithName(inStockName).GetInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return _stockRep.GetStockWithName(inStockName).GetLastStockPrice();
        }





        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indexRep.CreateIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {

            if (IndexExists(inIndexName) && StockExists(inStockName) && !IsStockPartOfIndex(inIndexName, inStockName))
            {
                _indexRep.GetIndexWithName(inIndexName).AddStock(_stockRep.GetStockWithName(inStockName));
            }
            else
            {
                throw new StockExchangeException("");
            }

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName) && IsStockPartOfIndex(inIndexName, inStockName))
            {
                _indexRep.GetIndexWithName(inIndexName).RemoveStock(_stockRep.GetStockWithName(inStockName));
            }
            else
            {
                throw new StockExchangeException("");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("blaba");
            }
            else if (!StockExists(inStockName))
            {
                return false;
            }
            return _indexRep.GetIndexWithName(inIndexName).IsStockPart(_stockRep.GetStockWithName(inStockName));

        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("");
            }


            return _indexRep.GetIndexWithName(inIndexName).GetValue(inTimeStamp);

        }

        public bool IndexExists(string inIndexName)
        {
            return _indexRep.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indexRep.GetCount();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("");
            }
            return (int)_indexRep.GetIndexWithName(inIndexName).NumberOfStocks();
        }






        public void CreatePortfolio(string inPortfolioID)
        {
            _portfolioRep.CreatePortfolio(inPortfolioID);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
            {
                throw new StockExchangeException("");
            }
            _portfolioRep.GetPortfolioWithID(inPortfolioID).AddStockToPortfolio(_stockRep.GetStockWithName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
            {
                throw new StockExchangeException("");
            }
            _portfolioRep.GetPortfolioWithID(inPortfolioID).RemoveStockFromPortfolio(_stockRep.GetStockWithName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {

            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
            {
                throw new StockExchangeException("");
            }
            _portfolioRep.GetPortfolioWithID(inPortfolioID).RemoveStockFromPortfolio(_stockRep.GetStockWithName(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return _portfolioRep.GetCount();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("");
            }
            return _portfolioRep.GetPortfolioWithID(inPortfolioID).NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioRep.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("");
            }
            else if (!StockExists(inStockName))
            {
                return false;
            }
            return _portfolioRep.GetPortfolioWithID(inPortfolioID).IsStockPartOfPortfolio(_stockRep.GetStockWithName(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
            {
                throw new StockExchangeException("");
            }
            return
                _portfolioRep.GetPortfolioWithID(inPortfolioID).NumberOfSharesOfStockInPortfolio(_stockRep.GetStockWithName(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("");
            }
            return _portfolioRep.GetPortfolioWithID(inPortfolioID).GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {


            if (!PortfolioExists(inPortfolioID) || Month <= 0 || Month > 12 || Year <= 0)
            {
                throw new StockExchangeException("");
            }
            return _portfolioRep.GetPortfolioWithID(inPortfolioID).GetPortfolioPercentChangeInValueForMonth(Year, Month);
        }

    }




    public interface IObserver
    {
        void Update(Object param);
    }

    public abstract class Subject
    {
        List<IObserver> _listObservers = new List<IObserver>();

        public void Attach(IObserver obs)
        {
            _listObservers.Add(obs);
        }
        public void Delete(IObserver obs)
        {
            _listObservers.Remove(obs);
        }
        public void NotifyObservers(Object param)
        {
            foreach (IObserver obs in _listObservers)
                obs.Update(param);
        }
    }


    public class Stock : Subject
    {

        private String _name;
        private long _numberOfShares;
        private long _numberOfAvailableShares;
        private SortedList<DateTime, StockPriceForSpecificTime> _priceHistory;



        public String Name
        {
            get { return this._name; }
        }
        public long NumberOfShares
        {
            get { return this._numberOfShares; }
        }
        public long NumberOfAvailableShares
        {
            get { return _numberOfAvailableShares; }
            set { _numberOfAvailableShares = value; }
        }



        public Stock(String name, long numberOfShares, DateTime startDate, decimal startPrice)
        {
            if (startPrice <= 0 || numberOfShares <= 0)
            {
                throw new StockExchangeException("Illegal price or share number");
            }

            _priceHistory = new SortedList<DateTime, StockPriceForSpecificTime>();
            _name = name;
            _numberOfShares = numberOfShares;
            _numberOfAvailableShares = numberOfShares;
            var initialStockPrice = new StockPriceForSpecificTime(startDate, startPrice);
            _priceHistory.Add(startDate, initialStockPrice);
        }

        protected bool Equals(Stock other)
        {
            return string.Equals(_name, other._name);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Stock)obj);
        }

        public override int GetHashCode()
        {
            return (_name != null ? _name.GetHashCode() : 0);
        }

        public void setStockPrice(DateTime timeStamp, decimal price)
        {
            if (price <= 0)
                throw new StockExchangeException("Illegal price!");
            if (isPriceForTimeAlreadySetted(timeStamp))
            {
                throw new StockExchangeException("Price for time " + timeStamp + " is already setted");
            }
            else
            {
                _priceHistory.Add(timeStamp, new StockPriceForSpecificTime(timeStamp, price));
            }
        }

        public decimal stockPriceForDate(DateTime date)
        {



            if (date < _priceHistory.First().Key)
                throw new StockExchangeException("");

            if (date >= _priceHistory.Last().Key)
            {
                return _priceHistory.Last().Value.Price;
            }

            DateTime bigestLower = _priceHistory.First().Key;
            foreach (KeyValuePair<DateTime, StockPriceForSpecificTime> kvpPricehist in _priceHistory)
            {
                if (kvpPricehist.Key >= date)
                {
                    return _priceHistory[bigestLower].Price;
                }
                bigestLower = kvpPricehist.Key;

            }

            throw new StockExchangeException("Illegal date");

        }

        public decimal GetInitialStockPrice()
        {
            return _priceHistory.First().Value.Price;
        }

        public decimal GetLastStockPrice()
        {
            return _priceHistory.Last().Value.Price;
        }


        private bool isPriceForTimeAlreadySetted(DateTime time)
        {
            foreach (KeyValuePair<DateTime, StockPriceForSpecificTime> iter in _priceHistory)
            {
                if (iter.Value.TimeStapm == time)
                {
                    return true;
                }

            }
            return false;
        }


    }
    public class StockPriceForSpecificTime
    {
        private DateTime _timeStamp;
        private decimal _price;

        public DateTime TimeStapm
        {
            get { return _timeStamp; }
        }

        public decimal Price
        {
            get { return _price; }
        }

        public StockPriceForSpecificTime(DateTime startDate, decimal price)
        {
            _timeStamp = startDate;
            _price = price;
        }

    }

    public abstract class Index : IObserver
    {
        protected string _name;
        protected List<Stock> _stocks;
        public string Name
        {
            get { return _name; }
        }

        protected Index(string name)
        {
            _name = name;
            _stocks = new List<Stock>();
        }

        public void AddStock(Stock inStock)
        {
            inStock.Attach(this);
            _stocks.Add(inStock);
        }
        public void RemoveStock(Stock inStock)
        {
            inStock.Delete(this);
            _stocks.Remove(inStock);

        }
        public bool IsStockPart(Stock inStock)
        {
            return _stocks.Contains(inStock);
        }

        public long NumberOfStocks()
        {
            return _stocks.Count;
        }

        public abstract decimal GetValue(DateTime inTimeStamp);

        public void Update(object param)
        {
            _stocks.Remove(param as Stock);
        }

        protected bool Equals(Index other)
        {
            return string.Equals(_name, other._name);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Index)obj);
        }

        public override int GetHashCode()
        {
            return (_name != null ? _name.GetHashCode() : 0);
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string name)
            : base(name)
        {
        }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal sumValue = 0, retSum = 0;
            if (_stocks.Count == 0)
            {
                return 0m;
            }

            foreach (var iterStock in _stocks)
            {
                sumValue += iterStock.stockPriceForDate(inTimeStamp) * iterStock.NumberOfShares;
            }
            foreach (var iterStock in _stocks)
            {
                retSum += iterStock.stockPriceForDate(inTimeStamp) * ((iterStock.stockPriceForDate(inTimeStamp) * iterStock.NumberOfShares) / sumValue);
            }
            return Math.Round(retSum, 3);

        }
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string name)
            : base(name)
        {
        }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal sum = 0, counter = 0;
            if (_stocks.Count == 0)
            {
                return 0m;
            }
            foreach (var iterStock in _stocks)
            {
                counter++;
                sum += iterStock.stockPriceForDate(inTimeStamp);
            }
            return Math.Round(sum / counter, 3);
        }
    }

    public class Portfolio : IObserver
    {
        private string _id;
        private Dictionary<Stock, long> _stocks;

        public string ID
        {
            get { return _id; }
        }

        public Portfolio(string id)
        {
            _id = id;
            _stocks = new Dictionary<Stock, long>();
        }

        public void AddStockToPortfolio(Stock inStock, int numberOfShares)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("");
            }

            if (inStock.NumberOfAvailableShares - numberOfShares < 0)
            {
                if (!_stocks.ContainsKey(inStock))
                {
                    inStock.Attach(this);
                    _stocks.Add(inStock, inStock.NumberOfAvailableShares);
                    inStock.NumberOfAvailableShares = 0;

                }
                else
                {
                    _stocks[inStock] += inStock.NumberOfAvailableShares;
                    inStock.NumberOfAvailableShares = 0;
                }

            }

            else if (_stocks.ContainsKey(inStock))
            {
                _stocks[inStock] += numberOfShares;
                inStock.NumberOfAvailableShares -= numberOfShares;
            }
            else
            {
                inStock.Attach(this);
                _stocks.Add(inStock, numberOfShares);
                inStock.NumberOfAvailableShares -= numberOfShares;

            }
        }

        public void RemoveStockFromPortfolio(Stock inStock, int numberOfShares)
        {
            
            
            
            if (_stocks[inStock] - numberOfShares <= 0)
            {
                inStock.NumberOfAvailableShares += _stocks[inStock];
                _stocks.Remove(inStock);
                inStock.Delete(this);
            }
            else
            {
                _stocks[inStock] -= numberOfShares;
                inStock.NumberOfAvailableShares += numberOfShares;
            }

        }

        public void RemoveStockFromPortfolio(Stock inStock)
        {
            inStock.NumberOfAvailableShares += _stocks[inStock];
            _stocks.Remove(inStock);
            inStock.Delete(this);

        }

        public int NumberOfStocksInPortfolio()
        {
            return _stocks.Count;
        }

        public bool IsStockPartOfPortfolio(Stock inStock)
        {
            return _stocks.ContainsKey(inStock);
        }

        public int NumberOfSharesOfStockInPortfolio(Stock inStock)
        {
            if (!_stocks.ContainsKey(inStock))
            {
                return 0;
            }
            return (int)_stocks[inStock];
        }

        public Decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (KeyValuePair<Stock, long> kvpStock in _stocks)
            {
                sum += (kvpStock.Value * kvpStock.Key.stockPriceForDate(timeStamp));
            }
            return Math.Round(sum, 3);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime first = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime last = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            foreach (KeyValuePair<Stock, long> iterStock in _stocks)
            {
                iterStock.Key.stockPriceForDate(first);
                iterStock.Key.stockPriceForDate(last);
            }

            decimal sumFirst = 0, sumLast = 0, retVal;
            foreach (KeyValuePair<Stock, long> iterStock in _stocks)
            {
                sumFirst += iterStock.Key.stockPriceForDate(first) * iterStock.Value;
                sumLast += iterStock.Key.stockPriceForDate(last) * iterStock.Value;
            }
            if (_stocks.Count == 0)
            {
                retVal = 0;
            }
            else
            {
                retVal = ((sumLast - sumFirst) / sumFirst) * 100;
            }

            return Math.Round(retVal, 3);
        }


        public void Update(object param)
        {
            _stocks.Remove(param as Stock);
        }
    }


    public class IndexFactory
    {

        public static Index CreateIndex(IndexTypes indexTypes, string indexName)
        {
            Index retIndex = null;
            if (indexTypes == IndexTypes.AVERAGE)
            {
                retIndex = new AverageIndex(indexName);

            }
            else if (indexTypes == IndexTypes.WEIGHTED)
            {
                retIndex = new WeightedIndex(indexName);

            }
            else
            {
                throw new StockExchangeException("");
            }
            return retIndex;
        }

    }

    public class IndexRepository
    {
        private List<Index> _activeIndices;



        public IndexRepository()
        {
            _activeIndices = new List<Index>();
        }


        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {
                _activeIndices.Add(IndexFactory.CreateIndex(inIndexType, inIndexName));

            }
            else
            {

                throw new StockExchangeException("");
            }
        }
        public bool IndexExists(string inIndexName)
        {
            foreach (Index iterIndex in _activeIndices)
            {
                if (iterIndex.Name.ToLower().Equals(inIndexName.ToLower()))
                    return true;
            }
            return false;
        }
        public Index GetIndexWithName(string inName)
        {
            foreach (var iterIndex in _activeIndices)
            {
                if (iterIndex.Name.ToLower().Equals(inName.ToLower()))
                    return iterIndex;
            }

            throw new StockExchangeException("");
        }

        public int GetCount()
        {
            return _activeIndices.Count;
        }
    }
    public class StockRepository
    {
        private List<Stock> _activeStocks;


        public StockRepository()
        {
            _activeStocks = new List<Stock>();
        }


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Stock with name " + inStockName + " already exist!");
            }
            var newStock = new Stock(inStockName, inNumberOfShares, inTimeStamp, inInitialPrice);
            _activeStocks.Add(newStock);
        }
        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                Stock delSt = GetStockWithName(inStockName);
                delSt.NotifyObservers(delSt);
                _activeStocks.Remove(delSt);
            }
            else
            {
                throw new StockExchangeException("");
            }
        }
        public bool StockExists(string inStockName)
        {
            foreach (Stock st in _activeStocks)
            {
                if (st.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }
        public Stock GetStockWithName(String name)
        {
            foreach (Stock st in _activeStocks)
            {
                if (st.Name.ToLower().Equals(name.ToLower()))
                {

                    return st;
                }
            }
            throw new StockExchangeException("Stock with name " + name + " doesn't exist");
        }

        public int GetCount()
        {
            return _activeStocks.Count;
        }

    }
    public class PortfolioRepository
    {
        private List<Portfolio> _activePortfolios;


        public PortfolioRepository()
        {
            _activePortfolios = new List<Portfolio>();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("");
            _activePortfolios.Add(new Portfolio(inPortfolioID));
        }
        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (var iterPort in _activePortfolios)
            {
                if (iterPort.ID.Equals(inPortfolioID))
                    return true;
            }
            return false;
        }
        public Portfolio GetPortfolioWithID(String idPort)
        {
            foreach (var activePortfolio in _activePortfolios)
            {
                if (activePortfolio.ID.Equals(idPort))
                    return activePortfolio;
            }
            throw new StockExchangeException("");
        }



        public int GetCount()
        {
            return _activePortfolios.Count;
        }
    }
}
