﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string currentDisplayState;
        private double leftOperator;
        private string lastOperator = string.Empty;
        private string savedNumber;
        private bool clearScreenNeeded = false;
        private bool canDoOperation = false;


        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            resetCalculator();
        }

        public void Press(char inPressedDigit)
        {
            if (Char.IsNumber(inPressedDigit))
            {
                if (clearScreenNeeded == true)
                {
                    clearScreen();
                    clearScreenNeeded = false;
                }

                canDoOperation = true;

                if (currentDisplayState == "0")
                    currentDisplayState = inPressedDigit.ToString();
                else
                    currentDisplayState += inPressedDigit;
            }
            else if (inPressedDigit == ',')
            {
                if (clearScreenNeeded == true)
                {
                    clearScreen();
                    clearScreenNeeded = false;
                }

                if (currentDisplayState.Contains(','))
                    currentDisplayState = "-E-";
                else
                    currentDisplayState += inPressedDigit;
            }
            else if (inPressedDigit == '+')
            {
                binaryOperation('+');
            }
            else if (inPressedDigit == '-')
            {
                binaryOperation('-');
            }
            else if (inPressedDigit == '*')
            {
                binaryOperation('*');
            }
            else if (inPressedDigit == '/')
            {
                binaryOperation('/');
            }
            else if (inPressedDigit == 'M' || inPressedDigit == 'm')
            {
                signChange();
            }
            else if (inPressedDigit == 'S' || inPressedDigit == 's')
            {
                sine();
            }
            else if (inPressedDigit == 'K' || inPressedDigit == 'k')
            {
                cosine();
            }
            else if (inPressedDigit == 'T' || inPressedDigit == 't')
            {
                tangent();
            }
            else if (inPressedDigit == 'Q' || inPressedDigit == 'q')
            {
                powerOfTwo();
            }
            else if (inPressedDigit == 'R' || inPressedDigit == 'r')
            {
                squareRoot();
            }
            else if (inPressedDigit == 'I' || inPressedDigit == 'i')
            {
                inverse();
            }
            else if (inPressedDigit == 'P' || inPressedDigit == 'p')
            {
                savedNumber = currentDisplayState;
            }
            else if (inPressedDigit == 'G' || inPressedDigit == 'g')
            {
                currentDisplayState = savedNumber;
            }
            else if (inPressedDigit == 'C' || inPressedDigit == 'c')
            {
                clearScreen();
            }
            else if (inPressedDigit == 'O' || inPressedDigit == 'o')
            {
                resetCalculator();
            }
            else if (inPressedDigit == '=')
            {
                canDoOperation = true;
                binaryOperation('=');
            }

            formatDisplay();
        }

        public void add()
        {
            double rightOperator = double.Parse(currentDisplayState);
            double result = leftOperator + rightOperator;

            currentDisplayState = result.ToString();
            leftOperator = result;
        }

        public void subtract()
        {
            double rightOperator = double.Parse(currentDisplayState);
            double result = leftOperator - rightOperator;

            currentDisplayState = result.ToString();
            leftOperator = result;
        }

        public void multiply()
        {
            double rightOperator = double.Parse(currentDisplayState);
            double result = leftOperator * rightOperator;

            currentDisplayState = result.ToString();
            leftOperator = result;
        }

        public void divide()
        {
            double rightOperator = double.Parse(currentDisplayState);
            double result = leftOperator / rightOperator;

            currentDisplayState = result.ToString();
            leftOperator = result;
        }

        public void sine()
        {
            double number = double.Parse(currentDisplayState);
            number = Math.Sin(number);

            currentDisplayState = number.ToString();
            clearScreenNeeded = true;
        }

        public void cosine()
        {
            double number = double.Parse(currentDisplayState);
            number = Math.Cos(number);

            currentDisplayState = number.ToString();
            clearScreenNeeded = true;
        }

        public void tangent()
        {
            double number = double.Parse(currentDisplayState);
            number = Math.Tan(number);

            currentDisplayState = number.ToString();
            clearScreenNeeded = true;
        }

        public void powerOfTwo()
        {
            double number = double.Parse(currentDisplayState);
            number = Math.Pow(number, 2);

            currentDisplayState = number.ToString();
            clearScreenNeeded = true;
        }

        public void squareRoot()
        {
            double number = double.Parse(currentDisplayState);
            if (number >= 0)
            {
                number = Math.Sqrt(number);
                currentDisplayState = number.ToString();
                clearScreenNeeded = true;
            }
            else
            {
                currentDisplayState = "-E-";
            }
        }

        public void signChange()
        {
            if (!currentDisplayState.Contains('-'))
                currentDisplayState = "-" + currentDisplayState;
            else
                currentDisplayState = currentDisplayState.Substring(1, currentDisplayState.Length - 1);
        }

        public void inverse()
        {
            double number = double.Parse(currentDisplayState);

            if (!(number == 0))
            {
                number = 1 / number;
                currentDisplayState = number.ToString();
            }
            else
            {
                currentDisplayState = "-E-";
            }

            clearScreenNeeded = true;
        }


        public void binaryOperation(char binaryOperator)
        {
            decimal number = decimal.Parse(currentDisplayState);
            int intNumber = (int)number;

            if (number == intNumber)
                currentDisplayState = intNumber.ToString();

            if (lastOperator == string.Empty)
            {
                lastOperator = binaryOperator.ToString();
                leftOperator = double.Parse(currentDisplayState);
                clearScreenNeeded = true;
            }
            else
            {
                if (canDoOperation)
                {
                    switch (lastOperator)
                    {
                        case "+":
                            add();
                            break;
                        case "-":
                            subtract();
                            break;
                        case "*":
                            multiply();
                            break;
                        case "/":
                            divide();
                            break;
                    }
                }

                clearScreenNeeded = true;
                if (binaryOperator.ToString() != "=")
                    lastOperator = binaryOperator.ToString();
            }
            canDoOperation = false;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayState;
        }

        private void resetCalculator()
        {
            leftOperator = 0;
            clearScreen();
        }

        private void clearScreen()
        {
            currentDisplayState = "0";
        }

        private void formatDisplay()
        {
            if (currentDisplayState == "-E-")
                return;


            int numberOfDigits = 0;

            for (int i = 0; i < currentDisplayState.Length; i++)
            {
                if (Char.IsNumber(currentDisplayState[i]))
                    numberOfDigits++;

                if ((numberOfDigits > 10) && (currentDisplayState.Contains(',')))
                {
                    double result = double.Parse(currentDisplayState);
                    int decimalLeftSide;
                    if (!currentDisplayState.Contains('-'))
                        decimalLeftSide = currentDisplayState.Split(',')[0].Length;
                    else
                        decimalLeftSide = currentDisplayState.Split('-')[1].Split(',')[0].Length;

                    result = Math.Round(result, 10 - decimalLeftSide);
                    currentDisplayState = result.ToString();
                }
                else if ((numberOfDigits > 10) && !(currentDisplayState.Contains(',')))
                {
                    currentDisplayState = "-E-";
                }
            }
        }
    }
}
