﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,Stock> stocks= new Dictionary<string,Stock>();
         private Dictionary<string, Index> indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
                 throw new StockExchangeException("Dionica vec postoji");
             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica mora biti pozitivan");
             if (inInitialPrice <= 0)
                 throw new StockExchangeException("cijena mora biti pozitivan broj");
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(inStockName.ToUpper(), stock);

         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             stocks.Remove(inStockName.ToUpper());

         }

         public bool StockExists(string inStockName)
         {
             return stocks.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             stocks[inStockName].newValue(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return stocks[inStockName.ToUpper()].getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return stocks[inStockName.ToUpper()].getInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return GetStockPrice(inStockName, DateTime.MaxValue);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks postoji");
             Index index =new Index(inIndexName,inIndexType);
             indices.Add(inIndexName.ToUpper(),index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             indices[inIndexName].addStock(inStockName);

         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             indices[inIndexName].removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             return indices[inIndexName].containsStock(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             decimal result = 0;
             long numOfStokes=0;
             decimal overalValue = 0;
             if (indices[inIndexName].getType() == IndexTypes.AVERAGE)
             {
                 foreach (string stockName in indices[inIndexName].getStockList(inTimeStamp))
                 {
                     result += GetStockPrice(stockName, inTimeStamp);
                     numOfStokes++;
                 }
                 return result/numOfStokes;
             }
             if (indices[inIndexName].getType() == IndexTypes.WEIGHTED)
             {
                 foreach (string stockName in indices[inIndexName].getStockList(inTimeStamp))
                 {
                     result += GetStockPrice(stockName, inTimeStamp)*
                         GetStockPrice(stockName, inTimeStamp)*stocks[stockName].getNoOfShares();
                     overalValue += GetStockPrice(stockName, inTimeStamp) * stocks[stockName].getNoOfShares();
                 }
                 return result/overalValue;
             }
             throw new StockExchangeException("kriva definicija indexa");
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.ContainsKey(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             return indices[inIndexName].getNumOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (IndexExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj postoji");
             Portfolio portfolio = new Portfolio(inPortfolioID);
             portfolios.Add(inPortfolioID,  portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             portfolios[inPortfolioID].addStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
         
     }
    public class StockValue
    {
        private decimal value;
        private DateTime timeStamp;
        public DateTime getTimeStamp()
        {
            return this.timeStamp;
        }
        public decimal getValue()
        {
            return this.value;
        }
        public StockValue(decimal inValue, DateTime inTimeStamp)
        {
            this.value = inValue;
            this.timeStamp = inTimeStamp;
        }
    }
    public class Stock
     {
         private string stockName;
         private long numberOfShares;
         private long availableShares;
         private DateTime initial;
         private List<StockValue> stockValueList; 
         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             this.stockName=inStockName;
             stockValueList = new List<StockValue>();
             StockValue price = new StockValue(inInitialPrice, inTimeStamp);
             this.stockValueList.Add(price);
             this.numberOfShares = inNumberOfShares;
             this.availableShares = inNumberOfShares;
             this.initial = inTimeStamp;
         }
         public DateTime GetInitialDateTime()
         {
             return this.initial;
         }
         public long getNoOfShares()
         {
             return this.numberOfShares;
         }
        public void newValue(decimal inValue,DateTime inTimeStamp)
        {
            StockValue value = new StockValue(inValue,inTimeStamp);
            stockValueList.Add(value);
        }
        public decimal getInitialPrice()
        {
            return getPrice(initial);
        }
        public decimal getPrice(DateTime inTimeStamp)
        {
            int maxIndex=0;
            for (int i = 1; i < stockValueList.Count; i++)
            {
                if (stockValueList[i].getTimeStamp() <= inTimeStamp &&
                    stockValueList[i].getTimeStamp() > stockValueList[maxIndex].getTimeStamp())
                    maxIndex = i;
            }
            return stockValueList[maxIndex].getValue();
        }
    
     }
    public class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private List<string> indexStockList;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.indexName = inIndexName;
            this.indexType = inIndexType;
            indexStockList=new List<string>();
        }
        public void addStock(string inStock)
        {
            if (indexStockList.Contains(inStock.ToUpper()))
                throw new StockExchangeException("Dionica postoji u indeksu");
            indexStockList.Add(inStock.ToUpper());
        }
        public void removeStock(string inStock)
        {
            if (!indexStockList.Contains(inStock.ToUpper()))
                throw new StockExchangeException("Dionica ne postoji u indeksu");
            indexStockList.Remove(inStock.ToUpper());
        }

        public int getNumOfStocks()
        {
            return indexStockList.Count;
        }
        public bool containsStock(string inStock)
        {
            return indexStockList.Contains(inStock);
        }
        public List<string> getStockList(DateTime inTimeStamp)
        {
            return this.indexStockList;
        }
        public IndexTypes getType()
        {
            return this.indexType;
        }
    }
    public class Portfolio
    {
        string portfolioID;
        List<Stock> portfolioStockList;
        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
            portfolioStockList = new List<Stock>();
        }
        public void addStock(string stock, int num)
        {
            throw new NotImplementedException();
        }

    }


}
