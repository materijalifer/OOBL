﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public string display="0";


        #region varijableKalkulatora
        private char[] buffer = new char[12];
        
        private int brZnam=0;
        private double operand1, rezultat=0;
        private string memorija = "", funkcija = "", posljednjiStisnut = "";
        private bool zabrana = false, operandi = false, jednakoStisnut = false;
        #endregion

        #region binarne
        private void _jednako()
        {
            jednakoStisnut = true;

            switch (funkcija)
            {
                case "+": rezultat = operand1 + double.Parse(this.display); zaokruzi(rezultat.ToString()); break;
                case "-": rezultat = operand1 - double.Parse(this.display); zaokruzi(rezultat.ToString()); break;
                case "*": rezultat = operand1 * double.Parse(this.display); zaokruzi(rezultat.ToString()); break;
                case "/": rezultat = operand1 / double.Parse(this.display); zaokruzi(rezultat.ToString()); break;
                default: break;
            }
        }

        private void _oduzimanje()
        {
            if (!operandi)
            {
                operand1 = double.Parse(this.display);
                operandi = true;
                ocistiBuffer();
            }
            else if(!"+-*/".Contains(posljednjiStisnut)&&jednakoStisnut==false)
            {
               _jednako();
                operand1 = rezultat;
                this.display = rezultat.ToString();
                ocistiBuffer();
            }
            posljednjiStisnut = "-";
            this.funkcija = "-";
            if (jednakoStisnut == true)
            {
                jednakoStisnut = false;
                ocistiBuffer();
                operand1 = rezultat;
            }
        }

        private void _zbrajanje()
        {
            if (!operandi)
            {
                operand1 = double.Parse(this.display);
                operandi = true;
                ocistiBuffer();

            }
            else if(!"+-*/".Contains(posljednjiStisnut) && jednakoStisnut==false)
            {
                _jednako();
                operand1 = rezultat;
                this.display = rezultat.ToString();
                ocistiBuffer();
            }
            posljednjiStisnut = "+";
            this.funkcija = "+";
            if (jednakoStisnut == true)
            {
                jednakoStisnut = false;
                ocistiBuffer();
                operand1 = rezultat;
            }
        }

        private void _dijeljenje()
        {
            if (!operandi)
            {
                operand1 = double.Parse(this.display);
                operandi = true;
                ocistiBuffer();
            }
            else if (!"+-*/".Contains(posljednjiStisnut) && jednakoStisnut==false)
            {
                _jednako();
                operand1 = rezultat;
                this.display = rezultat.ToString();
                ocistiBuffer();
                
            }
            posljednjiStisnut = "/";
            this.funkcija = "/";
            if (jednakoStisnut == true)
            {
                jednakoStisnut = false;
                ocistiBuffer();
                operand1 = rezultat;
            }
        }

        private void _mnozenje()
        {
            if (!operandi)
            {
                operand1 = double.Parse(this.display);
                operandi = true;
                ocistiBuffer();   

            }
            else if (!"+-*/".Contains(posljednjiStisnut) && jednakoStisnut==false)
            {
                _jednako();
                operand1 = rezultat;
                this.display = rezultat.ToString();
                ocistiBuffer();
            }
            posljednjiStisnut = "*";
            this.funkcija = "*";
            if (jednakoStisnut == true)
            {
                jednakoStisnut = false;
                ocistiBuffer();
                operand1 = rezultat;
            }
        }

        #endregion

        #region unarne
        private void _inverz()
        {
            this.posljednjiStisnut = "I";
            if (double.Parse(this.display) == 0)
            {
                this.display = "-E-";
                zabrana = true;
                return;
            }
            double inverz = 1 / double.Parse(this.display);
            string test= inverz.ToString();
            zaokruzi(test);
        }
       
        private void _korjenovanje()
        {
            this.posljednjiStisnut = "R";
            if((double.Parse(this.display))<0)
            {
                this.display="-E-";
                zabrana=true;
                return;
            }
            string izracun = Math.Sqrt(double.Parse(this.display)).ToString();
            zaokruzi(izracun);

        }
        private void _kvadriranje()
        {
            this.posljednjiStisnut = "Q";
            string izracun= Math.Pow((double.Parse(this.display)), 2).ToString();
            zaokruzi(izracun);
        }
        private void _tangens()
        {
            this.posljednjiStisnut = "T";
            if (double.Parse(this.display) % 90 == 0)
            {
                this.display = "-E";
                zabrana = true;
                return;
            }
            double tangens = Math.Tan(double.Parse(this.display));
            string test = tangens.ToString();
            zaokruzi(test);
        }
        private void _kosinus()
        {
            this.posljednjiStisnut = "K";
                string izracun= Math.Cos(double.Parse(this.display)).ToString();
                zaokruzi(izracun);
        }
        private void _sinus()
        {
            this.posljednjiStisnut = "S";
           string izracun = Math.Sin(double.Parse(this.display)).ToString();
           zaokruzi(izracun);
        }

        #endregion

        #region pomocneFunkcije

        private void ucitajBuffer()
        {
            ocistiBuffer();
            int j = 11;
            bool predznak = false;
            for (int i = this.display.Length - 1; i >= 0; i--)
            {

                if (this.display[i] >= '0' && this.display[i] <= '9' || this.display[i] == ',')
                {
                    buffer[j] = this.display[i];
                }
                else if (this.display[i] == '-')
                {
                    predznak = true;
                }
                j--;
            }

            if (predznak)
            {
                buffer[0] = '-';
            }


        }
        private void _ispuniDisplay()
        {
            string s = new string(this.buffer);
            string novi = s.Replace("\0", "");
            if (novi.Contains(","))
            {
                decimal test = decimal.Parse(novi);
                test = test / 1.000000000000000000000000000000000m;
                novi = test.ToString();

            }
            this.display = novi;
        }

        private void _pomakni(char[] buff)
        {
            if (display.Contains(','))
            {
                for (int i = 1; i < 11; i++)
                {
                    buff[i] = buff[i + 1];
                }
            }
            else if (!display.Contains(','))
            {
                for (int i = 2; i < 11; i++)
                {
                    buff[i] = buff[i + 1];
                }

            }
            else
            {

            }
        }
        private void ocistiBuffer()
        {
            if (!zabrana)
            {
                this.brZnam = 0;
                for (int i = 0; i < 12; i++)
                {
                    this.buffer[i] = '\0';
                }
            }
        }
        #endregion

        #region ostaleFunkcije
        private void _zarez()
        {
                if (this.display.Length == 1 && this.display.Contains("0"))
                {
                    this.buffer[11] = '0';
                    brZnam++;
                }
                else if (brZnam == 10 || this.display.Contains(","))
                {
                    return;
                }
                _pomakni(this.buffer);
                this.buffer[11] = ',';
                _ispuniDisplay();
        }

        private void _resetKalk()
        {
            this.display = "0";
            this.zabrana = false;
            this.operand1 = 0;
            this.rezultat = 0;
            this.funkcija = "";
            this.memorija = "";
            ocistiBuffer();
        }

        private void _brisanjeEkrana()
        {
            this.display = "0";
            if (this.zabrana == true)
            {
                this.zabrana = false;
                this.operandi = false;
                this.rezultat = 0;
            }
            ocistiBuffer();
        }

        private void _dohvatMemorija()
        {
            this.display = this.memorija;
        }

        private void _spremanjeMemorija()
        {
            this.memorija = this.display;
        }

        private void _promijeniPredznak()
        {
            if (this.display != "0" && !jednakoStisnut && !"SKTQRI".Contains(this.posljednjiStisnut))
            {
                
                if (this.buffer[0].Equals('\0'))
                {
                    this.buffer[0] = '-';
                    _ispuniDisplay();
                }
                else
                {
                    this.buffer[0] = '\0';
                    _ispuniDisplay();
                }
            }
            else if (jednakoStisnut)
            {
                ucitajBuffer();

                if (this.buffer[0].Equals('\0'))
                {
                    this.buffer[0] = '-';
                    _ispuniDisplay();
                    string a = new string(this.buffer);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
                else
                {
                    this.buffer[0] = '\0';
                    _ispuniDisplay();
                    string a = new string(this.buffer);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
            }
            else
            {
                this.display = "-" + this.display;
            }
        }
        #endregion
        
        #region zaokruzivanjeRezultata
        private void zaokruzi(string rezultat)
        {

            double test = double.Parse(rezultat);
            if (test < -9999999999 || test > 9999999999)
            {
                this.display = "-E-";
                this.zabrana = true;
                return;
            }
            else
            {
                if (rezultat.Contains(","))
                {
                    int zarez = rezultat.IndexOf(',');
                    int broj;
                    if (rezultat.Contains("-"))
                    {
                        broj = 11;
                    }
                    else
                    {
                        broj = 10;
                    }
                    broj = broj - zarez;
                    double roundedNumber = double.Parse(rezultat);
                    roundedNumber = Math.Round(roundedNumber, broj);
                    this.display = roundedNumber.ToString();
                    rezultat = roundedNumber.ToString();
                }

            }
          

               this.display = rezultat;
            
        }
        #endregion

        #region unos
        public void Press(char inPressedDigit)
        {
            if (!zabrana || inPressedDigit.Equals('C') || inPressedDigit.Equals('O'))
            {
                switch (inPressedDigit)
                {
                    case '0': _unosNule(); break;
                    case '1': _unosBroj(inPressedDigit); break;
                    case '2': _unosBroj(inPressedDigit); break;
                    case '3': _unosBroj(inPressedDigit); break;
                    case '4': _unosBroj(inPressedDigit); break;
                    case '5': _unosBroj(inPressedDigit); break;
                    case '6': _unosBroj(inPressedDigit); break;
                    case '7': _unosBroj(inPressedDigit); break;
                    case '8': _unosBroj(inPressedDigit); break;
                    case '9': _unosBroj(inPressedDigit); break;
                    case '+': _zbrajanje(); break;
                    case '-': _oduzimanje(); break;
                    case '*': _mnozenje(); break;
                    case '/': _dijeljenje(); break;
                    case '=': _jednako(); break;
                    case ',': _zarez(); break;
                    case 'M': _promijeniPredznak(); break;
                    case 'S': _sinus(); break;
                    case 'K': _kosinus(); break;
                    case 'T': _tangens(); break;
                    case 'Q': _kvadriranje(); break;
                    case 'R': _korjenovanje(); break;
                    case 'I': _inverz(); break;
                    case 'P': _spremanjeMemorija(); break;
                    case 'G': _dohvatMemorija(); break;
                    case 'C': _brisanjeEkrana(); break;
                    case 'O': _resetKalk(); break;

                }
            }
        }
        private void _unosNule()
        {
            if (brZnam < 10)
            {

                if ((brZnam == 0 && this.display == "0"))
                {

                }
                else
                {
                    posljednjiStisnut = "0";
                    _pomakni(this.buffer);
                    this.buffer[11] = '0';
                    brZnam++;
                    _ispuniDisplay();
                }
            }
            else
            {

            }
        }

        private void _unosBroj(char broj)
        {
            if (brZnam < 10)
            {
                posljednjiStisnut = broj.ToString();
                _pomakni(this.buffer);
                this.buffer[11] = broj;
                brZnam++;
                _ispuniDisplay();

            }
            else
            {
            }
        }
        #endregion

        
        public string GetCurrentDisplayState()
        {
            return this.display;
        }


 
    }


}
