using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator 
{


    class Calculator : ICalculator
    {
        private Register registerCurrent;
        private Register registerLast;
        private Register memory;
        private IOperator operation;
        private bool invalidOperation;

        public Calculator()
        {
            registerCurrent = new Register();
            registerLast = new Register();
            memory = new Register();
            operation = null;
            invalidOperation = false;
        }

        void ICalculator.Press(char inPressedDigit)
        {
            invalidOperation = false;
            try
            {

                if (!Char.IsDigit(inPressedDigit))
                {                   
                    processOperation(inPressedDigit);
                }
                else
                {
                    registerCurrent.accpetChar(inPressedDigit);
                }
            }
            catch (Exception inputError)
            {
                invalidOperation = true;
                registerCurrent.reset();
                registerLast.reset();
            }
        }

        string ICalculator.GetCurrentDisplayState()
        {
            double content = registerCurrent.getContent();
            /*if (registerCurrent.isEmpty())
            {
                content = registerLast.getContent();
            }*/
            if (invalidOperation)
            {
                return "-E-";
            }
            int contentLength = 10;
            if (content < 0) contentLength++;
            string contentString = content.ToString();
            int decimalIndex = contentString.IndexOf(".");
            if (decimalIndex > 11 || (decimalIndex == -1 && contentString.Length > contentLength) || Double.IsInfinity(content)) return "-E-";
            if (decimalIndex != -1) contentLength++;
            content = Math.Round(content, 11 - decimalIndex + contentString.IndexOf("-"));
            return content.ToString().Replace('.', ',');
        }

        private void processOperation(char inPressedDigit)
        {

            switch (inPressedDigit)
            {
                case '=':
                    if (registerCurrent.isEmpty())
                    {
                        registerCurrent = new Register(registerLast);
                    }
                    if (operation != null) operation.operate(registerCurrent, registerLast);
                    break;
                case 'P':
                    memory = new Register(registerCurrent);
                    break;
                case 'G':
                    registerCurrent = new Register(memory);
                    break;
                case 'C':
                    registerCurrent.reset();
                    break;
                case 'O':
                    registerCurrent.reset();
                    registerLast.reset();
                    memory.reset();
                    operation = null;
                    break;
                default:
                    IOperator newOperation = OperatorFactory.createOperation(inPressedDigit);
                    if (newOperation.isImidiate())
                    {
                        if (registerCurrent.isEmpty())
                        {
                            
                            registerCurrent = new Register(registerLast);
                            newOperation.operate(registerCurrent, registerLast);
                        }
                        else
                        {
                            newOperation.operate(registerCurrent, registerLast);
                        }
                    }
                    else
                    {
                        if (registerCurrent.isEmpty())
                        {
                            registerCurrent.reset();
                        }
                        if (!registerCurrent.isEmpty())
                        {
                            if (operation != null) operation.operate(registerCurrent, registerLast);
                            registerLast = new Register(registerCurrent);
                            registerCurrent.reset();
                            registerCurrent = new Register(registerLast);
                        }
                        operation = newOperation;
                    }
                    break;

            }
        }


    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }

    class Register
    {
        private double content;
        private int decimalCount;
        private bool isDecimal;
        private int digitCount;
        private bool empty=true;

        public Register()
        {
            content = 0;
            decimalCount = 1;
            isDecimal = false;
            digitCount = 0;
            empty = true;
        }

        public Register(Register r)
        {
            content = r.content;
            decimalCount = r.decimalCount;
            isDecimal = r.isDecimal;
            digitCount = r.digitCount;
        }

        public void accpetChar(char inputNumber)
        {
            if (empty) this.reset();
            empty = false;
            if (digitCount == 10) return;
            double number = Double.Parse(inputNumber.ToString());

            if (content <= 0 && BitConverter.DoubleToInt64Bits(content) != BitConverter.DoubleToInt64Bits(0.0))
            {
                if (isDecimal)
                {
                    content -= Math.Pow(0.1, decimalCount) * number;
                    decimalCount++;
                }
                else
                {
                    content = content * 10 - number;
                }
            }
            else
            {
                if (isDecimal)
                {
                    content += Math.Pow(0.1, decimalCount) * number;
                    decimalCount++;
                }
                else
                {
                    content = content * 10 + number;
                }
            }

            digitCount++;
        }

        public double getContent()
        {
            return content;
        }

        public void setContent(double content)
        {
            this.content = content;
        }

        public void setDecimal(bool state)
        {
            isDecimal = state;
        }

        public void reset()
        {
            content = 0;
            isDecimal = false;
            decimalCount = 1;
            digitCount = 0;
            empty = true;
        }

        public void resetDigitCount()
        {
            digitCount = 0;
        }

        public bool getIsDecimal()
        {
            return isDecimal;
        }

        public bool isEmpty()
        {
            return empty;
        }

        public void setEmpty(bool empty)
        {
            this.empty = empty;
        }



    }

    interface IOperator
    {
        void operate(Register current, Register last);
        bool isImidiate();
    }

    class OperatorPlus : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(current.getContent() + last.getContent());
        }

        bool IOperator.isImidiate()
        {
            return false;
        }
    }

    class OperatorMinus : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(last.getContent() - current.getContent());
        }

        bool IOperator.isImidiate()
        {
            return false;
        }
    }

    class OperatorMultiply : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(current.getContent() * last.getContent());
        }

        bool IOperator.isImidiate()
        {
            return false;
        }
    }

    class OperatorDivide : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(last.getContent() / current.getContent());
        }

        bool IOperator.isImidiate()
        {
            return false;
        }
    }

    class OperatorDecimal : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setDecimal(true);
            current.setEmpty(false);
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorNegative : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(current.getContent() * (-1));
            current.setEmpty(false);
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorSine : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(Math.Sin(current.getContent()));
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorCosine : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(Math.Cos(current.getContent()));
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorTan : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(Math.Tan(current.getContent()));
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorSquare : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(current.getContent() * current.getContent());
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorSqrt : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(Math.Sqrt(current.getContent()));
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorInverse : IOperator
    {
        void IOperator.operate(Register current, Register last)
        {
            current.setContent(1 / current.getContent());
        }

        bool IOperator.isImidiate()
        {
            return true;
        }
    }

    class OperatorFactory
    {
        public static IOperator createOperation(char input)
        {
            switch (input)
            {
                case '+':
                    return new OperatorPlus();
                case '-':
                    return new OperatorMinus();
                case '*':
                    return new OperatorMultiply();
                case '/':
                    return new OperatorDivide();
                case ',':
                    return new OperatorDecimal();
                case 'M':
                    return new OperatorNegative();
                case 'S':
                    return new OperatorSine();
                case 'K':
                    return new OperatorCosine();
                case 'T':
                    return new OperatorTan();
                case 'Q':
                    return new OperatorSquare();
                case 'R':
                    return new OperatorSqrt();
                case 'I':
                    return new OperatorInverse();
                default:
                    throw new Exception();
            }

        }
    }
}

