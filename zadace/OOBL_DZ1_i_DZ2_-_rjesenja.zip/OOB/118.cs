﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        #region fields
        StockRepository _stockRepository = new StockRepository();
        IndexRepository _indexRepository = new IndexRepository();
        PortfolioRepository _portfolioRepository = new PortfolioRepository();
        #endregion

        #region methodes
        //
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockRepository.addStock(inStockName, inInitialPrice, inNumberOfShares, inTimeStamp);
        }

        //
        public void DelistStock(string inStockName)
        {
            _stockRepository.removeStock(inStockName);
        }

        //
        public bool StockExists(string inStockName)
        {
            return _stockRepository.Existes(inStockName);
        }

        //
        public int NumberOfStocks()
        {
            return _stockRepository.StockCount();
        }

        //
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            _stockRepository.setPrice(inStockName, inIimeStamp, inStockValue);
        }

        //
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockRepository.getStockPrice(inStockName, inTimeStamp);
        }

        //
        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockRepository.getInitialStockPrice(inStockName);
        }

        //
        public decimal GetLastStockPrice(string inStockName)
        {
            return _stockRepository.getLatestStockPrice(inStockName);
        }

        //
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indexRepository.addIndex(inIndexName, inIndexType);
        }

        //
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            foreach (var stock in _stockRepository.GetAllStocks(inStockName))
            {
                _indexRepository.addStockToIndex(inIndexName, stock);
            }
        }
        
        //
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            _indexRepository.removeStockFromIndex(inIndexName, inStockName);
        }

        //
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _indexRepository.isStockInIndex(inIndexName, inStockName);
        }

        //
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return _indexRepository.GetIndexValue(inIndexName, inTimeStamp);
        }

        //
        public bool IndexExists(string inIndexName)
        {
            return _indexRepository.Existes(inIndexName);
        }

        //
        public int NumberOfIndices()
        {
            return _indexRepository.Count();
        }

        //
        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _indexRepository.CountStocksIndex(inIndexName);
        }

        //
        public void CreatePortfolio(string inPortfolioID)
        {
            _portfolioRepository.addPortfolio(inPortfolioID);
        }

        //
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            for (int i = 0; i < numberOfShares; i++)
            {
                _portfolioRepository.AddStockToPortfolio(inPortfolioID, _stockRepository.GetAvailableStock(inStockName));
            }
        }

        //
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            for (int i = 0; i < numberOfShares; i++)
            {
                _stockRepository.AddAvailableStock(_portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, inStockName));
            }
        }

        //
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            _stockRepository.AddAvailableStock(_portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, inStockName));
        }

        //
        public int NumberOfPortfolios()
        {
            return _portfolioRepository.Count();
        }

        //
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _portfolioRepository.StockCountInPortfolio(inPortfolioID);
        }

        //
        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioRepository.Existes(inPortfolioID);
        }

        //
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioRepository.StockPartOfPortfolio(inPortfolioID, inStockName);
        }

        //
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioRepository.StockCountInPortfolio(inPortfolioID, inStockName);
        }

        //
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return _portfolioRepository.Value(inPortfolioID, timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
    
    public class StockRepository
    {
        #region fields
        //Lista svih dionica
        List<Stock> _stocksInRepository;
        //Lista slobodnih dionica koje mogu biti pridodjeljene portfoliu
        List<Stock> _availebleStocks;
        #endregion

        #region constructors
        public StockRepository()
        {
            _stocksInRepository = new List<Stock>();
            _availebleStocks = new List<Stock>();
        }
        #endregion

        #region methodes
        /// <summary>
        /// Dodaje dionicu u listu svih dionica i u listu slobodnih dionica
        /// </summary>
        public void addStock(string name,decimal price, long numberOfStocks, DateTime startTime)
        {
            if(Existes(name))
                throw new StockExchangeException("Postoji dionica sa tim imenom!");
            if (price <= 0m)
                throw new StockExchangeException("Cijena mora biti veca od 0");

            Stock stock;
            for (long i = 0; i < numberOfStocks; i++)
            {
                stock = new Stock(name, price, startTime);
                _stocksInRepository.Add(stock);
                _availebleStocks.Add(stock);
            }
        }
        /// <summary>
        /// Brise dionicu
        /// </summary>
        public void removeStock(string stockName)
        {
            //Ako nema dionice sa tim imenom baci exceptcion
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica ne postoji u listi!");

            //brise sve dionice iz liste _stocksInRepository
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if(_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    _stocksInRepository.RemoveAt(i);
                    i--;
                }
            }

            //brise sve dionice iz liste _availebleStocks
            for (int i = 0; i < _availebleStocks.Count; i++)
            {
                if (_availebleStocks[i].NameLowCase == stockName.ToLower())
                {
                    _availebleStocks.RemoveAt(i);
                    i--;
                }
            }
        }
        /// <summary>
        /// Provjera postoji li dionica s navedenim nazivom
        /// </summary>
        public bool Existes(string stockName)
        {
            //pregledava postoji li dionica u repositoriju
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if (_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    return true;
                }
            }

            return false;
        }
        /// <summary>
        /// Broj svih dionica
        /// </summary>
        public int StockCount()
        {
            List<string> dionice = new List<string>();

            foreach (var dionica in _stocksInRepository)
            {
                if(!dionice.Contains(dionica.NameLowCase))
                    dionice.Add(dionica.NameLowCase);
            }

            return dionice.Count;
        }
        /// <summary>
        /// Dodaje novu cijenu dionici
        /// </summary>
        public void setPrice(string stockName, DateTime from, decimal newPrice)
        {
            //Ako nema dionice sa tim imenom baci exceptcion
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji u listi!");

            //dodaje novu cijenu dionice za sve dionice navedenog imena
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if (_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    _stocksInRepository[i].setPrice(newPrice, from);
                }
            }
        }
        /// <summary>
        /// Racuna cijenu dionice
        /// </summary>
        public decimal getStockPrice(string stockName, DateTime time)
        {
            //Ako nema dionice sa tim imenom baci exceptcion
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji u listi!");

            //prolazi kroz dionice dok ne nadje trazenu te vrati njenu cijenu
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if (_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    return _stocksInRepository[i].getPrice(time);
                }
            }

            //Do ovog dijela ne bi smjelo biti moguce doci
            throw new StockExchangeException("Doslo je do greske!");
        }
        /// <summary>
        /// Vraca pocetnu cijenu dionice
        /// </summary>
        public decimal getInitialStockPrice(string stockName)
        {
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji!");

            //prolazi kroz dionice dok ne nadje trazenu te vrati njenu pocetnu cijenu
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if (_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    return _stocksInRepository[i].StartingPrice;
                }
            }

            //Do ovog dijela ne bi smjelo biti moguce doci
            throw new StockExchangeException("Doslo je do greske!");
        }
        /// <summary>
        /// Vraca posljednju cijenu dionice
        /// </summary>
        public decimal getLatestStockPrice(string stockName)
        {
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji!");

            //prolazi kroz dionice dok ne nadje trazenu te vrati njenu pocetnu cijenu
            for (int i = 0; i < _stocksInRepository.Count; i++)
            {
                if (_stocksInRepository[i].NameLowCase == stockName.ToLower())
                {
                    return _stocksInRepository[i].LastPrice;
                }
            }

            //Do ovog dijela ne bi smjelo biti moguce doci
            throw new StockExchangeException("Doslo je do greske!");
        }
        /// <summary>
        /// Vraca listu svih dionica zadanog imena
        /// </summary>
        public List<Stock> GetAllStocks(string stockName)
        {
            //Ako nema dionice sa tim imenom baci exceptcion
            if (!Existes(stockName))
                throw new StockExchangeException("Dionica sa tim imenom ne postoji u listi!");

            List<Stock> stocks = new List<Stock>();

            foreach (var stock in _stocksInRepository)
            {
                if (stock.NameLowCase == stockName.ToLower())
                    stocks.Add(stock);
            }

            return stocks;
        }
        /// <summary>
        /// Dohvaca jednu dionicu trazenog imena
        /// </summary>
        public Stock GetAvailableStock(string stockName)
        {
            for (int i = 0; i < _availebleStocks.Count; i++)
            {
                if (_availebleStocks[i].NameLowCase == stockName.ToLower())
                {
                    Stock temp = _availebleStocks[i];
                    _availebleStocks.RemoveAt(i);
                    return temp;
                }
            }

            throw new StockExchangeException("Dionica sa trazenim imenom nije pronadjena!");
        }
        /// <summary>
        /// Dodaje dionicu medju slobodne dionice
        /// </summary>
        public void AddAvailableStock(Stock stock)
        {
            _availebleStocks.Add(stock);
        }
        #endregion
    }

    public class Stock
    {
        #region fields
        string _name = String.Empty;
        List<Price> _prices;
        #endregion

        #region constructors
        public Stock(string name, decimal startingPrice, DateTime startTime)
        {
            _name = name;
            _prices = new List<Price>();
            
            //pocetna cijena i otkad pocije ta cijena
            _prices.Add(new Price
            {
                StartTime = startTime,
                Value = startingPrice
            });
            //do kada vrijedi pocetna cijena
            _prices.Add(new Price
            {
                StartTime = DateTime.MaxValue,
                Value = 0
            });
        }
        #endregion

        #region attributes
        /// <summary>
        /// Naziv dionice
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        /// <summary>
        /// Naziv dionice prikazan samo malim slovima abecede
        /// </summary>
        public string NameLowCase
        {
            get { return _name.ToLower(); }
        }
        /// <summary>
        /// Pocetna cijena dionice
        /// </summary>
        public decimal StartingPrice
        {
            get { return _prices[0].Value; }
        }
        /// <summary>
        /// Posljednja cijena dionice
        /// </summary>
        public decimal LastPrice
        {
            get
            {
                return _prices[_prices.Count - 2].Value;
            }
        }
        #endregion

        #region methodes
        /// <summary>
        /// Cijena dionice za zadano vrijeme
        /// </summary>
        public decimal getPrice(DateTime time)
        {
            for (int i = 0; i < _prices.Count; i++)
            {
                if (_prices[i].StartTime > time)
                {
                    if (i == 0)
                        throw new StockExchangeException("Ne postoji cijena za odabrani datum i vrijeme!");

                    return _prices[i - 1].Value;
                }
            }

            //Do ovog dijela ne bi smijelo nikad doci
            throw new StockExchangeException("Došlo je do greške!");
        }
        /// <summary>
        /// Dodaje novu dionicu u listu
        /// </summary>
        public void setPrice(decimal price, DateTime startTime)
        {
            if (price <= 0)
                throw new StockExchangeException("Vrijednost dionice mora biti veca od 0!");

            for (int i = 0; i < _prices.Count; i++)
            {
                if (_prices[i].StartTime > startTime)
                {
                    _prices.Insert(i, new Price
                    {
                        StartTime = startTime,
                        Value = price
                    });
                    break;
                }
            }
        }
        #endregion
    }

    public class IndexRepository
    {
        #region fields
        Dictionary<string, Index> _indexes;
        #endregion

        #region constructors
        public IndexRepository()
        {
            _indexes = new Dictionary<string, Index>();
        }
        #endregion

        #region methodes
        /// <summary>
        /// Dodaje novi indeks u listu
        /// </summary>
        public void addIndex(string name, IndexTypes type)
        {
            //Ako  postoji indeks sa tim imenom izbaci se exception
            if (Existes(name))
                throw new StockExchangeException("Vec postoji indeks sa tim imenom");

            if (type == IndexTypes.AVERAGE)
            {
                _indexes.Add(name.ToLower(), new IndexAVERAGE
                {
                    Name = name,
                    Type = type
                });
            }
            else
            {
                _indexes.Add(name.ToLower(), new IndexWEIGHTED
                {
                    Name = name,
                    Type = type
                });
            }
        }
        /// <summary>
        /// Brise indeks iz liste
        /// </summary>
        public void removeIndex(string indexName)
        {
            //Ako ne postoji indeks sa tim imenom izbaci se exception
            if (!Existes(indexName))
                throw new StockExchangeException("Ne postoji indeks sa tim imenom");


            _indexes.Remove(indexName.ToLower());
        }
        /// <summary>
        /// Dodaje dionicu u indeks
        /// </summary>
        public void addStockToIndex(string indexName, Stock stock)
        {
            if (!Existes(indexName))
                throw new StockExchangeException("Index ne postoji!");

            _indexes[indexName.ToLower()].addStock(stock);
        }
        /// <summary>
        /// Brise dionicu iz indeksa
        /// </summary>
        public void removeStockFromIndex(string indexName, string stockName)
        {
            if (!Existes(indexName))
                throw new StockExchangeException("Index ne postoji!");

            _indexes[indexName.ToLower()].removeStock(stockName);
        }
        /// <summary>
        /// Provjerava je li dionica dio indeksa
        /// </summary>
        public bool isStockInIndex(string indexName, string stockName)
        {
            if (!Existes(indexName))
                throw new StockExchangeException("Index ne postoji!");

            return _indexes[indexName.ToLower()].ExistesStock(stockName);
        }
        /// <summary>
        /// Vrijednost indeksa
        /// </summary>
        public decimal GetIndexValue(string indexName, DateTime time)
        {
            if (!Existes(indexName))
                throw new StockExchangeException("Index ne postoji!");

            return _indexes[indexName.ToLower()].GetValue(time);
        }
        /// <summary>
        /// Broj indeksa u listi
        /// </summary>
        /// <returns></returns>
        public int Count()
        {
            return _indexes.Count;
        }
        /// <summary>
        /// Broj dionica u indeksu
        /// </summary>
        public int CountStocksIndex(string indexName)
        {
            if (!Existes(indexName))
                throw new StockExchangeException("Index ne postoji!");

            int count = 0;
            foreach (var index in _indexes)
            {
                count += index.Value.StockCount;
            }

            return count;
        }
        /// <summary>
        /// Provjerava postoji li indeks sa zadanim imenom
        /// </summary>
        public bool Existes(string indexName)
        {
            if (_indexes.ContainsKey(indexName.ToLower()))
                return true;
            else
                return false;
        }
        #endregion
    }

    public abstract class Index
    {
        #region fields
        string _name;
        IndexTypes _type;
        protected List<Stock> _stocks;
        #endregion

        #region constructors
        public Index()
        {
            _stocks = new List<Stock>();
        }
        #endregion

        #region attributes
        /// <summary>
        /// Naziv indeksa
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        /// <summary>
        /// Naziv indeksa prikazan samo malim slovima abecede
        /// </summary>
        public string NameToLower
        {
            get { return _name.ToLower(); }
        }
        /// <summary>
        /// Tip indeksa
        /// </summary>
        public IndexTypes Type
        {
            get { return _type; }
            set { _type = value; }
        }
        /// <summary>
        /// Broj dionica u indeksu. Moguce je samo dohvatiti broj
        /// </summary>
        public int StockCount
        {
            get
            {
                List<string> dionice = new List<string>();

                foreach (var dionica in _stocks)
                {
                    if (!dionice.Contains(dionica.NameLowCase))
                        dionice.Add(dionica.NameLowCase);
                }

                return dionice.Count;
            }
        }
        #endregion

        #region methodes
        /// <summary>
        /// Dodaje dionicu u index
        /// </summary>
        /// <param name="stock">Dionica koja se dodaje</param>
        public void addStock(Stock stock)
        {
            _stocks.Add(stock);
        }
        /// <summary>
        /// Izbacuje sve dionice s navedenim imenom iz indeksa
        /// </summary>
        /// <param name="stockName">naziv dionica koje se izbacuju</param>
        public void removeStock(string stockName)
        {
            if (!ExistesStock(stockName))
                throw new StockExchangeException("U indexu ne postoji trazena dionica!");

            for (int i = 0; i < _stocks.Count; i++)
            {
                if (_stocks[i].NameLowCase == stockName.ToLower())
                {
                    _stocks.RemoveAt(i);
                    i--;
                }
            }
        }
        /// <summary>
        /// Provjerava da li dionica sa zadanim imenom postoji
        /// </summary>
        /// <param name="stockName">Naziv za koji se provjerava postoji li dionica s tim imenom</param>
        /// <returns>Ako dionica postoji vraca true, ako ne postoji vraca false</returns>
        public bool ExistesStock(string stockName)
        {
            for (int i = 0; i < _stocks.Count; i++)
            {
                if (_stocks[i].NameLowCase == stockName.ToLower())
                    return true;
            }

            return false;
        }
        /// <summary>
        /// Vraca cijenu dionice za trazeno vrijeme, mora se nadjacati pri nasljedjivanju
        /// </summary>
        /// <param name="time">Vrijeme za koje se trazi cijena</param>
        /// <returns>Cijena u zadano vrijeme</returns>
        public abstract decimal GetValue(DateTime time);
        #endregion
    }

    public class IndexAVERAGE : Index
    {
        /// <summary>
        /// Racuna AVERAGE vrijednost indeksa
        /// </summary>
        public override decimal GetValue(DateTime time)
        {
            decimal sum = 0.0M;
            foreach (var stock in _stocks)
            {
                sum += stock.getPrice(time);
            }
            return decimal.Round(sum / _stocks.Count, 3);
        }
    }
    
    public class IndexWEIGHTED : Index
    {
        /// <summary>
        /// Racuna WEIGHTED  vrijednost indeksa
        /// </summary>
        public override decimal GetValue(DateTime time)
        {
            List<string> dionice = new List<string>();
            decimal sumAll = 0;

            foreach (var dionica in _stocks)
            {
                if (!dionice.Contains(dionica.NameLowCase))
                    dionice.Add(dionica.NameLowCase);

                sumAll += dionica.getPrice(time);
            }

            decimal value = 0;
            foreach (string dionicaName in dionice)
            {
                decimal sumCijenaDionice = 0;
                decimal cijenaDionice = 0;
                foreach (var dionica in _stocks)
                {
                    if (dionica.NameLowCase == dionicaName)
                    {
                        if(cijenaDionice == 0)
                        {
                            cijenaDionice += dionica.getPrice(time);
                        }

                        sumCijenaDionice += cijenaDionice;
                    }
                }
                decimal faktor = sumCijenaDionice / sumAll;
                value += faktor * cijenaDionice;
            }

            return decimal.Round(value,3);
        }
    }

    public class PortfolioRepository
    {
        #region fields
        Dictionary<string, Portfolio> _portfolios;
        #endregion

        #region constructos
        public PortfolioRepository()
        {
            _portfolios = new Dictionary<string,Portfolio>();
        }
        #endregion 

        #region methodes
        /// <summary>
        /// Dodaje novi portfolio
        /// </summary>
        /// <param name="portfolioName">Naziv portfolia</param>
        public void addPortfolio(string portfolioName)
        {
            if (Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom postoji!");

            _portfolios.Add(portfolioName, new Portfolio 
            {
                Name = portfolioName
            });
        }
        /// <summary>
        /// Briše portfolio iz liste
        /// </summary>
        /// <param name="portfolioName">Naziv portfolia koji se brise</param>
        public void removePortfolio(string portfolioName)
        {
            if(!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            _portfolios.Remove(portfolioName);
        }
        /// <summary>
        /// Broj portfolia u listi
        /// </summary>
        public int Count()
        {
            return _portfolios.Count;
        }
        /// <summary>
        /// Provjerava postoji li portfolio s zadanim imenom
        /// </summary>
        /// <param name="portfolioName">Naziv portfolia kojeg provjeravamo da li postoji</param>
        public bool Existes(string portfolioName)
        {
            if(_portfolios.ContainsKey(portfolioName))
                return true;
            else
                return false;
        }
        /// <summary>
        /// Dodaje dionicu u portfolio
        /// </summary>
        /// <param name="portfolioName">Naziv portfolia u kojeg dodajemo dionicu</param>
        /// <param name="stock">Dinica koju dodajemo</param>
        public void AddStockToPortfolio(string portfolioName, Stock stock)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            _portfolios[portfolioName].AddStock(stock);
        }
        /// <summary>
        /// Briše dionicu iz portfolia i vraca njenu referencu
        /// </summary>
        public Stock RemoveStockFromPortfolio(string portfolioName, string stockName)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            return _portfolios[portfolioName].RemoveStock(stockName);
        }
        /// <summary>
        /// Vraca broj dionica u portfoliu
        /// </summary>
        public int StockCountInPortfolio(string portfolioName)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            return _portfolios[portfolioName].AllStockCount;
        }
        /// <summary>
        /// Broj dionica sa zadanim imenom u portfoliu
        /// </summary>
        public int StockCountInPortfolio(string portfolioName, string stockName)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            return _portfolios[portfolioName].StockCount(stockName);
        }
        /// <summary>
        /// Provjerava da li je dionica dio portfolia
        /// </summary>
        public bool StockPartOfPortfolio(string portfolioName, string stockName)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            return _portfolios[portfolioName].IsStockPartOfPortfolio(stockName);
        }
        /// <summary>
        /// Vrijednost portfolia
        /// </summary>
        public decimal Value(string portfolioName, DateTime time)
        {
            if (!Existes(portfolioName))
                throw new StockExchangeException("Portfolio s tim imenom ne postoji!");

            return _portfolios[portfolioName].GetValue(time);
        }
        #endregion
    }

    public class Portfolio
    {
        #region fields
        string _name;
        List<Stock> _stocks;
        #endregion

        #region constructors
        public Portfolio()
        {
            _stocks = new List<Stock>();
        }
        #endregion

        #region attributes
        /// <summary>
        /// Naziv portfolia
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        /// <summary>
        /// Broj svih dionica u portfoliu
        /// </summary>
        public int AllStockCount
        {
            get 
            {
                List<string> dionice = new List<string>();

                foreach (var dionica in _stocks)
                {
                    if (!dionice.Contains(dionica.NameLowCase))
                        dionice.Add(dionica.NameLowCase);
                }

                return dionice.Count; 
            }
        }
        #endregion

        #region methodes
        /// <summary>
        /// Dodaje dionicu u portfolio
        /// </summary>
        public void AddStock(Stock stock)
        {
            _stocks.Add(stock);
        }
        /// <summary>
        /// Izbacuje dionicu iz liste i vraca njenu referencu
        /// </summary>
        public Stock RemoveStock(string stockName)
        {
            for (int i = 0; i < _stocks.Count; i++)
            {
                if (_stocks[i].NameLowCase == stockName.ToLower())
                {
                    Stock tempStock = _stocks[i];
                    _stocks.RemoveAt(i);
                    return tempStock;
                }
            }

            throw new StockExchangeException("Dionica sa navedenim imenom nije dio portfelja!");
        }
        /// <summary>
        /// Provjerava je li dionica dio portfolia
        /// </summary>
        public bool IsStockPartOfPortfolio(string stockName)
        {
            for (int i = 0; i < _stocks.Count; i++)
            {
                if (_stocks[i].NameLowCase == stockName.ToLower())
                {
                    return true;
                }
            }

            return false;
        }
        /// <summary>
        /// Broj dionica u portfoliu sa zadanim imenom
        /// </summary>
        public int StockCount(string stockName)
        {
            int count = 0;

            foreach (var stock in _stocks)
            {
                if (stock.NameLowCase == stockName.ToLower())
                    count++;
            }

            return count;
        }
        /// <summary>
        /// Vraca vrijednost portfolia za odredjeno vrijeme
        /// </summary>
        public decimal GetValue(DateTime time)
        {
            decimal sum = 0;

            foreach (var stock in _stocks)
            {
                sum += stock.getPrice(time);
            }

            return sum;
        }
        /// <summary>
        /// Vraca postotak promjene u zadanam mjesecu
        /// </summary>
        public int getMonthChange(int year, int month)
        {
            decimal valueBeginingOfMonth = GetValue(new DateTime(year, month, 0));
            decimal valueEndOfMonth = GetValue(new DateTime(year, month, 0) - new TimeSpan(0, 0, 0, 0, 1));

            return (int)((valueEndOfMonth - valueBeginingOfMonth) / valueBeginingOfMonth) * 100;
        }
        #endregion
    }

    public class Price
    {
        /// <summary>
        /// DAtum od kada cijena pocinje vrijediti
        /// </summary>
        public DateTime StartTime { get; set; }
        /// <summary>
        /// Vrijednost dionice
        /// </summary>
        public decimal Value { get; set; }
    }
}