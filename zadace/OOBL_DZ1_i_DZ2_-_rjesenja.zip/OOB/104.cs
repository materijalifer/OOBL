﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        List<Stock> stockList = new List<Stock>();
        List<Portfolio> portfolioList = new List<Portfolio>();
        List<Indeks> indexList = new List<Indeks>();


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName) == false)
                stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            else
                throw new StockExchangeException("Dionica vec postoji na burzi");
        }

        public void DelistStock(string inStockName)
        {
            int position = StockPosition(inStockName);
            stockList.RemoveAt(position);
        }

        public bool StockExists(string inStockName)
        {
            try
            {
                int position = StockPosition(inStockName);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        int StockPosition(string inStockName)
        {
            int position = -1;

            foreach (var item in stockList)
            {
                if (item.InStockName == inStockName.ToLower())
                {
                    position = stockList.IndexOf(item);
                    break;
                }
            }

            if (position != -1)
                return position;
            else
                throw new StockExchangeException("Nema trazene dionice na burzi");
        }

        int IndexPosition(string inIndexName)
        {
            int position = -1;

            foreach (var item in indexList)
            {
                if (item.InIndexName == inIndexName)
                {
                    position = indexList.IndexOf(item);
                    break;
                }
            }

            if (position != -1)
                return position;
            else
                throw new StockExchangeException("Nema trazenog indeksa na burzi");
        }

        int PortfolioPosition(string inPortfoliolName)
        {
            int position = -1;

            foreach (var item in portfolioList)
            {
                if (item.InPortfolioID == inPortfoliolName)
                {
                    position = portfolioList.IndexOf(item);
                    break;
                }
            }

            if (position != -1)
                return position;
            else
                throw new StockExchangeException("Nema trazenog indeksa na burzi");
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            int position = StockPosition(inStockName);

            stockList[position].setStockPrice(inTimeStamp, inStockValue);

            foreach (var item in indexList )
            {
                item.SetStockPrice(inStockName.ToLower(), inTimeStamp, inStockValue);
                   
            }

            foreach (var item in portfolioList)
            {
                item.SetStockPrice(inStockName.ToLower(), inTimeStamp, inStockValue);

            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            int position = StockPosition(inStockName);

            return stockList[position].getStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            int position = StockPosition(inStockName);

            return stockList[position].GetInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            int position = StockPosition(inStockName);

            return stockList[position].GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            indexList.Add(new Indeks(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            int stockposition = StockPosition(inStockName.ToLower());
            int indexPosition = IndexPosition(inIndexName.ToLower());
            indexList[indexPosition].AddStockToIndex(stockList[stockposition]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            int stockposition = StockPosition(inStockName.ToLower());
            int indexPosition = IndexPosition(inIndexName.ToLower());
            indexList[indexPosition].RemoveStockFromIndex(stockList[stockposition]);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            int stockposition = StockPosition(inStockName.ToLower());
            int indexPosition = IndexPosition(inIndexName.ToLower());
            return indexList[indexPosition].IsStockPartOfIndex(stockList[stockposition]);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            int indexPosition = IndexPosition(inIndexName.ToLower());
            return indexList[indexPosition].GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            try
            {
                int position = IndexPosition(inIndexName.ToLower());
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            int indexPosition = IndexPosition(inIndexName.ToLower());
            return indexList[indexPosition].NumberOfStocksInIndex();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            portfolioList.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            int stockposition = StockPosition(inStockName);
            int portfolioPosition = PortfolioPosition(inPortfolioID);

            if (numberOfShares > stockList[stockposition].InNumberOfShares)
                throw new StockExchangeException("Nema dovoljno dionica za kupnju");
            else
            {
                
                if (portfolioList[portfolioPosition].IsStockPartOfPortfolio(inStockName))
                {
                    int numberOfStockShares = portfolioList[portfolioPosition].NumberOfSharesOfStockInPortfolio(inStockName);
                    portfolioList[portfolioPosition].AddStockToPortfolio(inStockName, numberOfShares);
                }
                else
                {
                    Stock newStock = stockList[stockposition].Clone();
                    newStock.InNumberOfShares = numberOfShares;
                    portfolioList[portfolioPosition].AddStockToPortfolio(newStock);
                }
                stockList[stockposition].InNumberOfShares -= numberOfShares;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            int stockposition = StockPosition(inStockName);
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            portfolioList[portfolioPosition].RemoveStockFromPortfolio(inStockName, numberOfShares);
            stockList[stockposition].InNumberOfShares += numberOfShares;

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            int stockposition = StockPosition(inStockName);
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            int numberOfStockShares = portfolioList[portfolioPosition].NumberOfSharesOfStockInPortfolio(inStockName);
            portfolioList[portfolioPosition].RemoveStockFromPortfolio(inStockName);
            stockList[stockposition].InNumberOfShares += numberOfStockShares;

        }

        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            return portfolioList[portfolioPosition].NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            try
            {
                int portfolioPosition = PortfolioPosition(inPortfolioID);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            return portfolioList[portfolioPosition].IsStockPartOfPortfolio(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            int numberOfStockShares = portfolioList[portfolioPosition].NumberOfSharesOfStockInPortfolio(inStockName);
            return numberOfStockShares;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime inTimeStamp)
        {
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            return portfolioList[portfolioPosition].GetPortfolioValue(inTimeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            int portfolioPosition = PortfolioPosition(inPortfolioID);
            return portfolioList[portfolioPosition].GetPortfolioPercentageChangeInValueForMonth(Year, Month);
        }
    }
    public class Stock
    {
        string inStockName;

        public string InStockName
        {
            get { return inStockName; }
            set { inStockName = value; }
        }
        long inNumberOfShares;

        public long InNumberOfShares
        {
            get { return inNumberOfShares; }
            set { inNumberOfShares = value; }
        }

        SortedList<DateTime, Decimal> priceList;

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0) throw new StockExchangeException("Cijena ne moze biti negativna ili 0.");
            if (inNumberOfShares <= 0) throw new StockExchangeException("Broj dionica ne moze biti negativan ili 0.");
            this.inStockName = inStockName.ToLower();
            this.inNumberOfShares = inNumberOfShares;
            priceList = new SortedList<DateTime, decimal>();
            priceList.Add(inTimeStamp, inInitialPrice);
        }

        public Stock(string inStockName, long inNumberOfShares)
        {
            if (inNumberOfShares <= 0) throw new StockExchangeException("Broj dionica ne moze biti negativan ili 0.");
            this.inStockName = inStockName.ToLower();
            this.inNumberOfShares = inNumberOfShares;
            priceList = new SortedList<DateTime, decimal>();
        }

        public Stock Clone()
        {
            Stock newStock = new Stock(inStockName, inNumberOfShares);

            foreach (var item in priceList)
            {
                newStock.priceList.Add(item.Key, item.Value);
            }
            return newStock;
        }

        public void setStockPrice(DateTime inTimeStamp, Decimal price)
        {

            if (price <= 0) throw new StockExchangeException("Cijena ne moze biti negativna ili 0.");
            try
            {
                priceList.Add(inTimeStamp, price);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Vec postoji cijena za ovaj tenutak");
            }
        }



        public Decimal getStockPrice(DateTime inTimeStamp)
        {
            DateTime dt = DateTime.MinValue;
            foreach (var item in priceList)
            {
                if (item.Key > dt && item.Key < inTimeStamp)
                    dt = item.Key;
            }

            return priceList[dt];
        }

        public Decimal GetInitialStockPrice()
        {
            return priceList.Values.First();
        }

        public Decimal GetLastStockPrice()
        {
            return priceList.Values.Last();
        }
    }

    public class Indeks
    {
        string inIndexName;

        public string InIndexName
        {
            get { return inIndexName; }
            set { inIndexName = value; }
        }
        IndexTypes inIndexType;
        List<Stock> indexStockList = new List<Stock>();

        public void AddStockToIndex(Stock stock)
        {
            if (indexStockList.IndexOf(stock) == -1)
                indexStockList.Add(stock);
            else
                throw new StockExchangeException("Dionica je vec u indeksu");
        }

       

        public void RemoveStockFromIndex(Stock stock)
        {
            try
            {
                indexStockList.Remove(stock);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Dionice nema u indeksu");
            }
        }

        public Decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (this.inIndexType == IndexTypes.AVERAGE)
            {
                Decimal averageValue = 0;
                foreach (var item in indexStockList)
                {
                    averageValue += item.getStockPrice(inTimeStamp);
                }
                return averageValue / indexStockList.Count;
            }
            else
            {
                Decimal totalValue = 0;
                Decimal weightedValue = 0;

                foreach (var item in indexStockList)
                {
                    totalValue += item.getStockPrice(inTimeStamp) * item.InNumberOfShares;
                }

                foreach (var item in indexStockList)
                {
                    weightedValue += item.getStockPrice(inTimeStamp) * item.InNumberOfShares / totalValue * item.getStockPrice(inTimeStamp);
                }

                return weightedValue;
            }

        }
        public bool IsStockPartOfIndex(Stock stock)
        {
            if (indexStockList.IndexOf(stock) == -1)
                return false;
            else
                return true;
        }

        public void SetStockPrice(string stockName, DateTime timeStamp, Decimal price)
        {
            foreach (var item in indexStockList )
            {
                if (item.InStockName == stockName)
                    item.setStockPrice(timeStamp, price);
            }
        }


        public int NumberOfStocksInIndex()
        {
            return indexStockList.Count;
        }

        public Indeks(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Krivi tip indeksa");

            this.inIndexName = inIndexName.ToLower();
            this.inIndexType = inIndexType;
        }
    }

    public class Portfolio
    {

        string inPortfolioID;

        public string InPortfolioID
        {
            get { return inPortfolioID; }
            set { inPortfolioID = value; }
        }
        List<Stock> portfolioStockList = new List<Stock>();

        public Portfolio(string inPortfolioID)
        {
            this.inPortfolioID = inPortfolioID;
        }

        public void AddStockToPortfolio(Stock stock)
        {
            if (portfolioStockList.IndexOf(stock) == -1)
                portfolioStockList.Add(stock);
            else
                throw new StockExchangeException("Dionica je vec u portfelju");
        }

        public void AddStockToPortfolio(string inStockName, int numberOfShares)
        {
            foreach (var item in portfolioStockList)
            {
                if (item.InStockName == inStockName.ToLower())
                    item.InNumberOfShares += numberOfShares;
            }
        }

        public void SetStockPrice(string stockName, DateTime timeStamp, Decimal price)
        {
            foreach (var item in portfolioStockList )
            {
                if (item.InStockName == stockName)
                    item.setStockPrice(timeStamp, price);
            }
        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            int position = -1;

            foreach (var item in portfolioStockList)
            {
                if (item.InStockName == inStockName.ToLower())
                {
                    position = portfolioStockList.IndexOf(item);
                    break;
                }
            }
            if (position == -1)
                throw new StockExchangeException("Dionica ne postoji u portfelju");

            portfolioStockList.RemoveAt(position);
        }

        public void RemoveStockFromPortfolio(string inStockName, int inNumberOfShares)
        {

            int position = -1;

            foreach (var item in portfolioStockList)
            {
                if (item.InStockName == inStockName.ToLower())
                {
                    position = portfolioStockList.IndexOf(item);
                    break;
                }
            }
            if (position == -1)
                throw new StockExchangeException("Dionica ne postoji u portfelju");

            if (inNumberOfShares < portfolioStockList[position].InNumberOfShares)
                portfolioStockList[position].InNumberOfShares -= inNumberOfShares;
            else if (inNumberOfShares == portfolioStockList[position].InNumberOfShares)
                portfolioStockList.RemoveAt(position);
            else throw new StockExchangeException("Nema toliko dionica u portfelju");
        }

        public int NumberOfStocksInPortfolio()
        {
            return portfolioStockList.Count;
        }

        public bool IsStockPartOfPortfolio(string inStockName)
        {
            foreach (var item in portfolioStockList)
            {
                if (item.InStockName == inStockName.ToLower())
                    return true;
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            foreach (var item in portfolioStockList)
            {
                if (item.InStockName == inStockName.ToLower())
                    return (int)item.InNumberOfShares;
            }
            throw new StockExchangeException("Nema dionice u portfelju");
        }

        public Decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            Decimal value = 0;
            foreach (var item in portfolioStockList)
            {
                value += item.getStockPrice(inTimeStamp) * item.InNumberOfShares;
            }
            return value;
        }

        public Decimal GetPortfolioPercentageChangeInValueForMonth(int inYear, int inMonth)
        {
            DateTime startTimeStamp = new DateTime(inYear, inMonth, 1, 0, 0, 0, 0);
            DateTime endTimeStamp = new DateTime(inYear, inMonth, DateTime.DaysInMonth(inYear, inMonth), 23, 59, 59, 999);

            Decimal startValue = GetPortfolioValue(startTimeStamp);
            Decimal endValue = GetPortfolioValue(endTimeStamp);

            Decimal percentageChange = (endValue - startValue) / startValue * 100;
            return Decimal.Round(percentageChange, 3);
        }
    }
}
