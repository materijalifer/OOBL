﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private const string ERROR = "-E-";
        private const int DEFAULT_LENGTH = 10;

        private string displayState;


        public string DisplayState
        {
            get { return displayState; }
            set { displayState = value; }
        }
        private string lastEntrance;

        public string LastEntrance
        {
            get { return lastEntrance; }
            set { lastEntrance = value; }
        }
        private string memory;

        private string firstNumber;

        public string FirstNumber
        {
            get { return firstNumber; }
            set { firstNumber = value; }
        }
        private string memoryOperatorSign;

        public string MemoryOperatorSign
        {
            get { return memoryOperatorSign; }
            set { memoryOperatorSign = value; }
        }
        private string secondNumber;

        public string SecondNumber
        {
            get { return secondNumber; }
            set { secondNumber = value; }
        }
        public string Memory
        {
            get { return memory; }
            set { memory = value; }
        }
        private string operatorSign;

        public string OperatorSign
        {
            get { return operatorSign; }
            set { operatorSign = value; }
        }
        private bool decimalPoint = false;

        public bool DecimalPoint
        {
            get { return decimalPoint; }
            set { decimalPoint = value; }
        }
        private bool minusSign;

        public bool MinusSign
        {
            get { return minusSign; }
            set { minusSign = value; }
        }

        //konstruktor
        public Kalkulator() 
        {
            this.DisplayState = "0";
            this.Memory = "0";
            this.DecimalPoint = false;
            this.MinusSign = false;
            this.OperatorSign = "";
            this.LastEntrance= "";
            this.FirstNumber = "";
            this.SecondNumber = "";
        }
        public void Press(char inPressedDigit)
        {
            if (LastEntrance == "ERROR")//ako se na ekranu javio error, resetira se kalk i nastavlja rad
            {
                Reset();
            }
            //obrada ulaznih znakova
            switch (inPressedDigit)
            {
                case '0':
                    AddDigit("0");
                    break;
                case '1':
                    AddDigit("1");
                    break;
                case '2':
                    AddDigit("2");
                    break;
                case '3':
                    AddDigit("3");
                    break;
                case '4':
                    AddDigit("4");
                    break;
                case '5':
                    AddDigit("5");
                    break;
                case '6':
                    AddDigit("6");
                    break;
                case '7':
                    AddDigit("7");
                    break;
                case '8':
                    AddDigit("8");
                    break;
                case '9':
                    AddDigit("9");
                    break;
                case '+':
                    Plus();
                    break;
                case '-':
                    Minus();
                    break;
                case '*':
                    Multiplication();
                    break;
                case '/':
                    Division();
                    break;
                case '=':
                    Equal();
                    break;
                case ',':
                    PointEntered();
                    break;
                case 'M':
                    MinusSignEntered();
                    break;
                case 'S':
                    Sinus();
                    break;
                case 'K':
                    Kosinus();
                    break;
                case 'T':
                    Tangens();
                    break;
                case 'Q':
                    Quadrat();
                    break;
                case 'R':
                    Root();
                    break;
                case 'I':
                    Invers();
                    break;
                case 'P':
                    PutInMemory();
                    break;
                case 'G':
                    GetMemory();
                    break;
                case 'C':
                    Clear();
                    break;
                case 'O':
                    Reset();
                    break;
                default:
                    ErrorHappend(); //ako se javi znak za koji nije definirano ponasanje, javiti error
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return DisplayState;
        }
        private void Reset() 
        {
            this.DisplayState="0";
            this.Memory="0";
            this.DecimalPoint = false;
            this.MinusSign = false;
            //this.DigitCounter = 0;
            this.OperatorSign = "";
            this.LastEntrance = "";
            FirstNumber = "";
            this.SecondNumber = "";
        }
        private void AddDigit(string digit)
        {
            if ((DisplayState=="0")&&(digit=="0"))//zanemari unošenje nula koje nemaju znacenje
            {
                DisplayState = "0";
            }else
                if (DisplayState == "0")
                {
                    DisplayState = digit;//unos prve znamenke prebrise nulu
                }
                else
                    if (IsNumberLengthAcceptable() &&
                        (LastEnteredDigit() || (LastEntrance == ",") || 
                        (LastEntrance == "P"))) //nastavi dodavanje na trenutno stanje ekrana
                    {
                        DisplayState += digit;
                    }
                    else
                        if ((LastEntrance=="+")||(LastEntrance=="-")||
                            (LastEntrance=="*")||(LastEntrance=="/")||
                            (LastEntrance == "G") || (LastEntrance == "ERROR") ||
                            (LastEntrance == "S") || (LastEntrance == "K") ||
                            (LastEntrance == "Q") || (LastEntrance == "R") ||
                            (LastEntrance == "I") || (LastEntrance == "T") ||
                            (LastEntrance=="="))
                        {
                            //unos se novi broj
                            DisplayState = digit;
                        }
            LastEntrance = digit;
        }
        private bool LastEnteredDigit()
        {
            switch (LastEntrance)
            {
                case "1":
                    return true;
                case "2":
                    return true;
                case "3":
                    return true;
                case "4":
                    return true;
                case "5":
                    return true;
                case "6":
                    return true;
                case "7":
                    return true;
                case "8":
                    return true;
                case "9":
                    return true;
                case "0":
                    return true;
                default:
                    return false;
            }

        }
        private void PointEntered()
        {
            
            if (!DecimalPoint)
            {
                DecimalPoint = true;
                if (LastEntrance == "=" || LastEntrance == "+" || LastEntrance == "-" || LastEntrance == "*" || LastEntrance == "/")
                    DisplayState = "0,";
                else
                DisplayState += ",";
            }
            LastEntrance = ",";
            
        }
        private void MinusSignEntered()//promjena predznaka
        {
            if (!MinusSign)
            {
                DisplayState = "-" + DisplayState;
                MinusSign = true;
            }
            else
            {
                DisplayState = DisplayState.Substring(1);
                MinusSign=false;
            }
        }
        private bool IsNumberLengthAcceptable()
        {
            if (DisplayState.Length < (DEFAULT_LENGTH + Convert.ToInt16(DecimalPoint) + Convert.ToInt16(MinusSign)))
                return true;
            else
                return false;
        }
        private void PutInMemory()
        {
            LastEntrance = "P";
            if (IsNumberLengthAcceptable())
            {
                double inputNumber = Convert.ToDouble(DisplayState);
                Memory = inputNumber.ToString();
            }
        }
        private void GetMemory()
        {
            LastEntrance = "G";
            DisplayState = Memory;
        }
        private void Round(string result)
        {
            MinusSign = false;
            DecimalPoint = false;
            if (Convert.ToDouble(result) > 9999999999)
            {
                //pozitivan broj veci od mogucnosti prikaza
                ErrorHappend();
            }
            else
            {
                if (result.Length > DEFAULT_LENGTH)
                {//obrada i zaokruzivanje rjesenja na 10 (12) znakova
                    int displayLength = DEFAULT_LENGTH;
                    if (result.StartsWith("-"))
                    {
                        displayLength++;
                        MinusSign = true;
                    }
                    string watchedNumber = result.Substring(0, displayLength);
                    int hasPoint = watchedNumber.IndexOf(",");
                    if (hasPoint > 0)
                    {
                        displayLength++;
                        DecimalPoint = true;
                    }
                    if (result.Length > displayLength)
                    {
                        if (DecimalPoint == false)
                        {
                            ErrorHappend();
                        }
                        else
                        {
                            int digitsBeforePoint = result.IndexOf(",") - Convert.ToInt16(MinusSign);
                            int roundingNumber = DEFAULT_LENGTH - digitsBeforePoint;
                            double rez = Convert.ToDouble(result);
                            rez = Math.Round(rez, roundingNumber);
                            DisplayState = rez.ToString();
                        }
                    }
                    else
                    {
                        DisplayState = result;
                    }
                }
                else
                {
                    DisplayState = result;
                }
            }
        }
  
        private void Plus()
        {
            BinaryOperators();
            LastEntrance = "+";
            OperatorSign = "+";
            MemoryOperatorSign = "+";
            FirstNumber = DisplayState;
            DecimalPoint = false;
            minusSign = false;
        }
        private void Minus()
        {
            BinaryOperators();
            LastEntrance = "-";
            OperatorSign = "-";
            MemoryOperatorSign = "-";
            FirstNumber = DisplayState;
            DecimalPoint = false;
            minusSign = false;
        }
        private void Multiplication()
        {
            BinaryOperators();
            LastEntrance = "*";
            OperatorSign = "*";
            MemoryOperatorSign = "*";
            FirstNumber = DisplayState;
            DecimalPoint = false;
            minusSign = false;
        }
        private void Division()
        {
            BinaryOperators();
            LastEntrance = "/";
            OperatorSign = "/";
            MemoryOperatorSign = "/";
            FirstNumber = DisplayState;
            DecimalPoint = false;
            minusSign = false;
        }
        private void Sinus()
        {
            LastEntrance = "S";
            string rez = (Math.Sin(Convert.ToDouble(DisplayState))).ToString();
            Round(rez);
        }
        private void Kosinus()
        {
            LastEntrance = "K";
            string rez = (Math.Cos(Convert.ToDouble(DisplayState))).ToString();
            Round(rez);
        }
        private void Tangens()
        {
            LastEntrance = "T";
            string rez = (Math.Tan(Convert.ToDouble(DisplayState))).ToString();
            Round(rez);
        }
        private void Quadrat()
        {
            LastEntrance = "Q";
            string rez = (Math.Pow((Convert.ToDouble(DisplayState)),2)).ToString();
            Round(rez);
        }
        private void Root()
        {
            LastEntrance = "R";
            string rez = (Math.Sqrt(Convert.ToDouble(DisplayState))).ToString();
            Round(rez);
        }
        private void Invers()
        {
            LastEntrance = "I";
            if (DisplayState != "0")
            {
                string rez = (1 / (Convert.ToDouble(DisplayState))).ToString();
                Round(rez);
            }
            else
                ErrorHappend();
        }
        private void Clear()
        {
            LastEntrance = "C";
            DisplayState = "0";
            this.DecimalPoint = false;
            this.MinusSign = false;
            //FirstNumber = "";
        }
        private void BinaryOperatorAction()
        {
            MemoryOperatorSign = OperatorSign;
            switch (OperatorSign)
            {
                case "+":
                    {
                        double first = Convert.ToDouble(FirstNumber);
                        SecondNumber = DisplayState;
                        double second = Convert.ToDouble(DisplayState);
                        double res = (first) + (second);
                        Round(res.ToString());
                        operatorSign = "";
                        break;
                    }
                case "-":
                    {
                        double first = Convert.ToDouble(FirstNumber);
                        SecondNumber = DisplayState;
                        double second = Convert.ToDouble(DisplayState);
                        double res = (first) - (second);
                        Round(res.ToString());
                        operatorSign = "";
                        break;
                    }
                case "*":
                    {
                        double first = Convert.ToDouble(FirstNumber);
                        SecondNumber = DisplayState;
                        double second = Convert.ToDouble(DisplayState);
                        double res = (first) * (second);
                        Round(res.ToString());
                        operatorSign = "";
                        break;
                    }
                case "/":
                    {
                        if (DisplayState == "0"||DisplayState=="-E-")
                        {
                            ErrorHappend();
                            break;
                        }
                        else
                        {
                            double first = Convert.ToDouble(FirstNumber);
                            SecondNumber = DisplayState;
                            double second = Convert.ToDouble(DisplayState);
                            double res = (first) / (second);
                            Round(res.ToString());
                            operatorSign = "";
                            break;
                        }
                    }
            }
        }
        private void SuccessiveEqual(string secondOperand, string operation)
        {
            MemoryOperatorSign = operation;
            switch (operation)
            {
                case "+":
                    {
                        double first = Convert.ToDouble(DisplayState);
                        double second = Convert.ToDouble(secondOperand);
                        double res = (first) + (second);
                        Round(res.ToString());
                        break;
                    }
                case "-":
                    {
                        double first = Convert.ToDouble(DisplayState);
                        double second = Convert.ToDouble(secondOperand);
                        double res = (first) - (second);
                        Round(res.ToString());
                        break;
                    }
                case "*":
                    {
                        double first = Convert.ToDouble(DisplayState);
                        double second = Convert.ToDouble(secondOperand);
                        double res = (first) * (second);
                        Round(res.ToString());
                        break;
                    }
                case "/":
                    {
                        if (DisplayState == "0" || DisplayState == "-E-")
                        {
                            ErrorHappend();
                            break;
                        }
                        else
                        {
                            double first = Convert.ToDouble(DisplayState);
                            double second = Convert.ToDouble(secondOperand);
                            double res = (first) / (second);
                            Round(res.ToString());
                            break;
                        }
                    }
            }
        }
        private void Equal()
        {
            if (DisplayState == "-E-")
            {
                DisplayState = "0";
            }
            else
            if ((LastEntrance == "=") && (DisplayState!="-E-"))
            {
                SuccessiveEqual(SecondNumber, MemoryOperatorSign);
            }
            else if ((FirstNumber.Length) > 0)
            {
                MemoryOperatorSign = OperatorSign;
                BinaryOperatorAction();
            }
                else
                {
                    operatorSign = "";
                    if (DisplayState.IndexOf(",") > 0)
                    { 
                        int pointPosition=DisplayState.IndexOf(",");
                        string firstPart = DisplayState.Substring(0, pointPosition);
                        string secondPart = DisplayState.Substring(pointPosition + 1);
                        if (secondPart.Length > 0)
                        {
                            int rest = Convert.ToInt16(secondPart);
                            if (rest == 0) DisplayState = firstPart;                        
                        }
                        else 
                        {
                            DisplayState = firstPart;
                        }
                    }
                }
            LastEntrance = "=";
        }


        private void ErrorHappend() 
        {
            DisplayState = ERROR;
            MemoryOperatorSign = "";
            this.DecimalPoint = false;
            this.MinusSign = false;
            LastEntrance = "ERROR";
            OperatorSign = "";
            FirstNumber = "";
        }

        //zbrajanje dijeljenje.... ako se ponovo javljaju binarni operatori prije jednako
        private void BinaryOperators()
        {
            if ((OperatorSign.Length > 0) && ((LastEntrance != "+") && (LastEntrance != "-") && (LastEntrance != "/") && (LastEntrance != "*")))
            {
                BinaryOperatorAction();
                FirstNumber = DisplayState;
            }           
        }
    }


}
