﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }


    public class Kalkulator:ICalculator
    {
        string display;
        bool plus = true; //to je +
        bool dec = false; //cijeli broj
        int maxDis = 10;
        int poDec = 0;
        string memory = "";

        string meduRez = "";
        string opera = ""; //operator
        double operand = 0; // prvi broj u operaciji
        bool prijeI = false;


       public Kalkulator()
        {
            this.display = "0";
        }

        public void Press(char inPressedDigit)
        {
            bool isNum = Char.IsNumber(inPressedDigit);     

            if (isNum) //unesen je broj
            {
                if (display.Length == 1 && display.Equals("0")) display = "";
                if (prijeI) { display = ""; prijeI = false; }

                if (display.Length < maxDis)
                {
                    if (display.Equals("0") && inPressedDigit.Equals("0")) display = "0";
                    else display += inPressedDigit.ToString();
                }

            }
            else  if (inPressedDigit.Equals(',')) //unesen zarez
                {
                   if (!dec) //ako jos nema decemilanog zareza
                    {
                        if (display.Length == 0) display += "0,";
                        else display += ",";
                        maxDis++;
                        dec = true;
                    }
                    
                }//dovde unos zareza

           else if (inPressedDigit.Equals('M')) //unesena M (promjena predznaka)
                {
                    if (plus)
                    {
                        plus = false;
                        display = "-" + display;
                        maxDis++;
                        display = zaokruzi(display);                      
                    }
                    else
                    {
                        plus = true;
                        display = display.Substring(1, display.Length);
                        maxDis--;
                        display = zaokruzi(display);
                    }

                }//dovde unos M

           //memorija
           else if (inPressedDigit.Equals('P'))
            {
                    memory = display;
            }
           else if (inPressedDigit.Equals('G'))
            {
                    display = memory;
            }
            else if (inPressedDigit.Equals('C'))
            {
                display = "";
            }

           //reset
            else if (inPressedDigit.Equals('O'))
            {
                display = "0";
                plus = true; //to je +
                dec = false; //cijeli broj
                maxDis = 10;
                poDec = 0;
                memory = "";
                opera = ""; //operator
                operand = 0; // prvi broj u operaciji
                meduRez = "";
            }
            //sinus
            else if (inPressedDigit.Equals('S'))
            {
                double d = str_to_numb(display);
                double rez = Math.Sin(d);
                display = zaokruzi(rez.ToString());
            }
            //kosinus
            else if (inPressedDigit.Equals('K'))
            {
                double d = str_to_numb(display);
                double rez = Math.Cos(d);
                display = zaokruzi(rez.ToString());
            }
            //tangens
            else if (inPressedDigit.Equals('T'))
            {
                double d = str_to_numb(display);
                double rez = Math.Tan(d);
                display = zaokruzi(rez.ToString());
            }
            //kvadrat
            else if (inPressedDigit.Equals('Q'))
            {
                double d = str_to_numb(display);
                double rez = Math.Pow(d, 2);
                display = zaokruzi(rez.ToString());
            }
            //korijen
            else if (inPressedDigit.Equals('R'))
            {
                double d = str_to_numb(display);
                double rez = Math.Sqrt(d);
                display = zaokruzi(rez.ToString());
            }
            //inverz
            else if (inPressedDigit.Equals('I'))
            {
                double d;
                prijeI = true;
                if (display.Equals(""))
                {
                    d = str_to_numb(meduRez);
                }
                else
                {
                    d = str_to_numb(display);
                }

                if (d == 0) display = "-E-";

                else
                {
                    double rez = 1 / d;
                    display = zaokruzi(rez.ToString());
                }
            }

            // za oduzimanje
            else if (inPressedDigit.Equals('-'))
            {
                operand = str_to_numb(display);

                if (!display.Equals(""))
                {
                    if (meduRez.Equals(""))
                    {
                        meduRez = display;
                    }
                    else 
                    {   //treba provjeriti za sve ostale operacije koje su bile prije
                        double med = 0;
                        if (opera.Equals("-")) med = str_to_numb(meduRez) - operand;
                        else if (opera.Equals("+")) med = operand + str_to_numb(meduRez);
                        else if (opera.Equals("*")) med = operand * str_to_numb(meduRez);

                        else if (opera.Equals("/") && operand !=0 ) med = str_to_numb(meduRez) / operand;
                        if (operand == 0 && opera.Equals("/")) meduRez = "-E-";
                        else
                            meduRez = zaokruzi(med.ToString());
                    }
                    if (operand == 0 && opera.Equals("/")) display = "-E-";
                    else
                    display = "";
                }

                opera = "-";
                resetZaNoviBroj();

            }
            // za zbrajanje
            else if (inPressedDigit.Equals('+'))
            {
                operand = str_to_numb(display);
                if (!display.Equals(""))
                {
                    if (meduRez.Equals(""))
                    {
                        meduRez = display;
                    }
                    else //vec ima nekih medurezultata
                    {
                        double med = 0;
                        if (opera.Equals("-")) med = str_to_numb(meduRez) - operand;
                        else if (opera.Equals("+")) med = operand + str_to_numb(meduRez);
                        else if (opera.Equals("*")) med = operand * str_to_numb(meduRez);
                        else if (opera.Equals("/")) med =  str_to_numb(meduRez) / operand;
                        meduRez = zaokruzi(med.ToString());
                    }
               
                display = "";
                }
                opera = "+";

                resetZaNoviBroj();
            }
            // za mnozenje
            else if (inPressedDigit.Equals('*'))
            {
                operand = str_to_numb(display);

                if (!display.Equals(""))
                {
                    if (meduRez.Equals(""))
                    {
                        meduRez = zaokruzi(display);
                    }
                    else //vec ima nekih medurezultata
                    {
                        double med = 0;
                        if (opera.Equals("-")) med = str_to_numb(meduRez) - operand;
                        else if (opera.Equals("+")) med = operand + str_to_numb(meduRez);
                        else if (opera.Equals("*")) med = operand * str_to_numb(meduRez);
                        else if (opera.Equals("/")) med = str_to_numb(meduRez) / operand;
                        meduRez = zaokruzi(med.ToString());
                    }

                    display = "";
                }
                opera = "*";

                resetZaNoviBroj();
            }
            // za djeljenje   TREBA PROVJERIT DA SE NE DJELI S 0
            else if (inPressedDigit.Equals('/'))
            {
                operand = str_to_numb(display);
                if (!display.Equals(""))
                {
                    if (meduRez.Equals(""))
                    {
                        meduRez = display;
                    }
                    else //vec ima nekih medurezultata
                    {
                        double med = 0;
                        if (opera.Equals("-")) med = str_to_numb(meduRez) - operand;
                        else if (opera.Equals("+")) med = operand + str_to_numb(meduRez);
                        else if (opera.Equals("*")) med = operand * str_to_numb(meduRez);
                        else if (opera.Equals("/") && operand != 0) med = str_to_numb(meduRez) / operand;

                        if (operand == 0 && opera.Equals("/")) meduRez = "-E-";
                        else
                            meduRez = zaokruzi(med.ToString());
                   
                    }

                    if (operand == 0 && opera.Equals("/")) display = "-E-";
                    else
                        display = "";
                }
                opera = "/";

                resetZaNoviBroj();
            }

            //kad se stisne jednako
            else if (inPressedDigit.Equals('='))
            {
                double o2 = str_to_numb(display);
                //treba izvest oduzimanje
                if (opera.Equals("-"))
                {
                    if (display.Equals(""))
                    {
                        double rez = str_to_numb(meduRez) - str_to_numb(meduRez);
                        display = zaokruzi(rez.ToString());

                       // meduRez = display;
                    }
                    else
                    {
                        double rez = str_to_numb(meduRez) - o2;
                        display = zaokruzi(rez.ToString());

                        //meduRez = display;
                    }
                }
                //treba izvest zbrajanje
                else if (opera.Equals("+"))
                {
                    if (display.Equals(""))
                    {
                        double rez = str_to_numb(meduRez) + str_to_numb(meduRez);
                        display = zaokruzi(rez.ToString());
                       // meduRez = display;
                    }
                    else
                    {
                        double rez = str_to_numb(meduRez) + o2;
                        display = zaokruzi(rez.ToString());
                       // meduRez = display;
                    }
                }
                else if (opera.Equals("*"))
                {
                     if (display.Equals(""))
                    {
                        double rez = str_to_numb(meduRez) * str_to_numb(meduRez);
                        display = zaokruzi(rez.ToString());
                       // meduRez = display;
                    }
                    else
                    {
                    double rez = str_to_numb(meduRez) * o2;
                    display = zaokruzi(rez.ToString());
                    //meduRez = display;
                    }
                }
                else if (opera.Equals("/"))
                {
                    if (display.Equals(""))
                    {
                        if (!meduRez.Equals("0"))
                        {
                            double rez = str_to_numb(meduRez) / str_to_numb(meduRez);
                            display = zaokruzi(rez.ToString());
                        }
                        else display = "-E-";
                      //  meduRez = display;
                    }
                    else
                    {
                        if (o2 != 0)
                        {
                            double rez = str_to_numb(meduRez) / o2;
                            display = zaokruzi(rez.ToString());
                        }
                        else display = "-E-";
                      //  meduRez = display;
                    }
                }
                else if (opera.Equals("") && dec)
                {
                    display = zaokruzi(display);
                }

            }
        }

        public string GetCurrentDisplayState()
        {
            if (display.Equals("") && !meduRez.Equals("")) return zaokruzi(meduRez.ToString());
            return display;
           // return meduRez;
            
        }

        public static string zaokruzi(string s)
        {
            s = staviDecTocku(s);
            double d = str_to_numb(s);

            int a = nadiDec(s);
            if (a == -1)
            {
                //nema decimala
                if (s.Length <= 10) return s;
                else return "-E-";

            }
            else
            {
                string pom = Math.Round(d, 10 - nadiDec(s)).ToString();
                return staviDecZarez(pom);
            }  

        }

        public static string staviDecTocku(string s) //umjesto zareza stavi tocku
        {
            string novi = "";
            foreach (char c in s)
            {
                if (c.Equals(',')) novi += '.';
                else novi += c;
            }
            return novi;
        }

        public static string staviDecZarez(string s) //umjesto tocke stavi zarez
        {
            string novi = "";
            foreach (char c in s)
            {
                if (c.Equals('.')) novi += ',';
                else novi += c;
            }
            return novi;
        }

        public static double str_to_numb(string s) //pretvara string u broj
        {
            s = staviDecTocku(s);

            double number;
            bool mozeSe = Double.TryParse(s, out number);
            if (mozeSe) return number;

            return -1.2503;
        }

        public static int nadiDec(string s) //nalazi mjesto na kojem se nalazi decimalna tocka ili zarez
        {
            int i = 0;
            foreach (char c in s)
            {
                if (i == 0 && c.Equals('-')) i--;

                if (c.Equals(',') || c.Equals('.')) return i;
                else i++;
            }
            return -1;
        }

        void resetZaNoviBroj()
        {
            dec = false;
            plus = true;
            maxDis = 10;
            poDec = 0;
        }

    }


}
