﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        #region CONSTANTS
        // <Objasnjenje>
        //ove konstante "stoje" da imam operatore/tipke na okupu. ali, 
        //reference tipovi ne mogu ici u konstante, pa koristim akcesor da bude isti efekt.
        // </Objasnjenje>

        //mijenjam stil pisanja zbog slicnosti operand i operators
        private static char[] memory_operators = { 'P', 'G' };
        private static char[] single_operand_operators = { 'S', 'K', 'T', 'Q', 'R', 'I' };
        private static char[] double_operand_operators = { '+', '-', '*', '/' };
        private static char[] misc_operators = { 'C', 'O' };
        //zarez ne brojim kao operator!

        //akcesori za operatore
        public static char[] MEMORY_OPERATORS
        {
            get { return memory_operators; }
        }
        public static char[] SINGLE_OPERAND_OPERATORS
        {
            get { return single_operand_operators; }
        }
        public static char[] DOUBLE_OPERAND_OPERATORS
        {
            get { return double_operand_operators; }
        }
        public static char[] MISC_OPERATORS
        {
            get { return misc_operators; }
        }
        #endregion

        #region CALCULATOR COMPONENTS AND OPERATIONS
        //sto ako zelimo vise display-a (tesko za vjerovati), ili vise memorija(moguce!)?
        private class Display
        {
            private string displayState;

            public Display()
            {
                displayState = "0";
            }

            public string GetDisplayState()
            {
                return displayState;
            }

            public double GetDisplayStateDouble()
            {
                //double displayStatedouble = double.Parse(displayState.Replace(',', '.'));
                double displayStatedouble = double.Parse(displayState);
                return displayStatedouble;
            }

            public void AddCharToDisplay(char newCharacter)
            {
                bool isNumeric = (int)char.GetNumericValue(newCharacter) >= 0 && (int)char.GetNumericValue(newCharacter) <= 9;
                bool isComma = newCharacter == ',';
                bool isMinus = newCharacter == 'M';

                if (displayState != "0")
                {
                    if (isNumeric)
                    {
                        if ((displayState.Contains('-') && displayState.Length < 12) ||
                            (!displayState.Contains('-') && displayState.Length < 11))
                        {
                            displayState = displayState + newCharacter;
                        }
                    }
                    else if (isComma && !displayState.Contains(','))
                    {
                        //provjeriti jos ovaj uvjet!
                        if ((displayState.Contains('-') && displayState.Length < 11) ||
                            (!displayState.Contains('-') && displayState.Length < 10))
                        {
                            displayState = displayState + newCharacter;
                        }
                    }
                    else if (isMinus)
                    {
                        if (displayState.Contains('-'))
                        {
                            displayState = displayState.TrimStart('-');
                        }
                        else
                        {
                            displayState = '-' + displayState;
                        }
                    }
                }
                else if (displayState == "0")
                {
                    if (!isComma)
                    {
                        displayState = newCharacter.ToString();
                    }
                    else
                    {
                        displayState = displayState + newCharacter.ToString();
                    }
                }
            }

            public void SetDisplay(string newDisplayState)
            {
                displayState = newDisplayState;
            }

            public void ResetDisplay()
            {
                displayState = "0";
            }
        }

        private class Memory
        {
            private decimal memoryContent;

            //provjeravati cemo da li je privremena memorija postavljena za slucajeve broj= i broj+=
            //stoga formiramo ovu zastavicu
            private bool isMemorySet;
            public bool IsMemorySet
            {
                get
                {
                    return isMemorySet;
                }
            }

            public Memory()
            {
                isMemorySet = false;
            }

            public void StoreToMemory(string display)
            {
                memoryContent = decimal.Parse(display);
                isMemorySet = true;
            }

            public void ResetMemory()
            {
                memoryContent = 0;
                isMemorySet = false;
            }

            public string RetrieveMemory()
            {
                return memoryContent.ToString();
            }

            public double RetrieveMemoryForOperation()
            {
                return (double)memoryContent;
            }
        }

        private static class MathOperations
        {
            public static string Calculate(double operand1, char equationOperator)
            {
                switch (equationOperator)
                {
                    case 'S':
                        return SingleOperandOperations.CalculateSine(operand1);
                    case 'K':
                        return SingleOperandOperations.CalculateCosine(operand1);
                    case 'T':
                        return SingleOperandOperations.CalculateTangent(operand1);
                    case 'Q':
                        return SingleOperandOperations.CalculateSquare(operand1);
                    case 'R':
                        return SingleOperandOperations.CalculateSquareRoot(operand1);
                    case 'I':
                        return SingleOperandOperations.CalculateInverse(operand1);
                    default:
                        return "0";
                }
            }

            public static string Calculate(double operand1, double operand2, char equationOperator)
            {
                switch (equationOperator)
                {
                    case '+':
                        return DoubleOperandOperations.CalculateAddition(operand1, operand2, equationOperator);
                    case '-':
                        return DoubleOperandOperations.CalculateSubtraction(operand1, operand2, equationOperator);
                    case '*':
                        return DoubleOperandOperations.CalculateMultiplication(operand1, operand2, equationOperator);
                    case '/':
                        return DoubleOperandOperations.CalculateDivision(operand1, operand2, equationOperator);
                    default:
                        return "0";
                }
            }

            private static class SingleOperandOperations
            {
                public static string CalculateSine(double operand1)
                {
                    //sinus i kosinus ce ionako imati 9 decimala, pa tu ne trebam provjeravati nista
                    return Math.Round(Math.Sin(operand1), 9).ToString("R");
                }
                public static string CalculateCosine(double operand1)
                {
                    return Math.Round(Math.Cos(operand1), 9).ToString("R");
                }
                public static string CalculateTangent(double operand1)
                {
                    string stringResult = Math.Tan(operand1).ToString("R");
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateSquare(double operand1)
                {
                    string stringResult = ((decimal)operand1 * (decimal)operand1).ToString();
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateSquareRoot(double operand1)
                {
                    string stringResult = Math.Sqrt(operand1).ToString("R");
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateInverse(double operand1)
                {
                    string stringResult = Math.Pow(operand1, -1).ToString("R");
                    return ReturnFinalResultOfOperation(stringResult);
                }
            }

            private static class DoubleOperandOperations
            {
                public static string CalculateAddition(double operand1, double operand2, char equationOperator)
                {
                    string stringResult;
                    stringResult = ((decimal)operand1 + (decimal)operand2).ToString();
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateSubtraction(double operand1, double operand2, char equationOperator)
                {
                    string stringResult;
                    stringResult = ((decimal)operand1 - (decimal)operand2).ToString();
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateMultiplication(double operand1, double operand2, char equationOperator)
                {
                    string stringResult;
                    stringResult = ((decimal)operand1 * (decimal)operand2).ToString();
                    return ReturnFinalResultOfOperation(stringResult);
                }
                public static string CalculateDivision(double operand1, double operand2, char equationOperator)
                {
                    string stringResult;
                    stringResult = ((decimal)operand1 / (decimal)operand2).ToString();
                    return ReturnFinalResultOfOperation(stringResult);
                }
            }

            private static string ReturnFinalResultOfOperation(string inputResult)
            {
                string stringResult = "";
                string wholePartOfNumber;
                string decimalPartOfNumber;

                if (inputResult == "Infinity" || inputResult == "NaN")
                {
                    stringResult = "-E-";
                    return stringResult;
                }

                if (inputResult.Contains(','))
                {
                    wholePartOfNumber = inputResult.Split(',').ElementAt(0);
                    decimalPartOfNumber = inputResult.Split(',').ElementAt(1);
                }
                else
                {
                    wholePartOfNumber = inputResult;
                    decimalPartOfNumber = "";
                }

                //skidamo trailing nule
                decimalPartOfNumber = decimalPartOfNumber.TrimEnd('0');

                if (wholePartOfNumber.Length + decimalPartOfNumber.Length > 10)
                {
                    if (wholePartOfNumber.Length >= 10)
                    {
                        stringResult = "-E-";
                    }
                    else
                    {
                        double decimalPartOfNumberdouble = double.Parse("0," + decimalPartOfNumber);
                        //paziti na ovaj dio, pri zaokruzivanju prve decimale! provjeriti jos
                        decimalPartOfNumber = Math.Round(decimalPartOfNumberdouble, 10 - wholePartOfNumber.Length).ToString("R");
                        stringResult = wholePartOfNumber + decimalPartOfNumber.Substring(1);
                    }
                }
                else
                {
                    stringResult = wholePartOfNumber + ',' + decimalPartOfNumber;
                }

                //skidamo decimalni zarez, ako je ostao
                stringResult = stringResult.TrimEnd(',');

                return stringResult;
            }
        }
        #endregion

        #region VARIABLES AND INSTANCES
        //zadnji uneseni znak
        private char lastInputChar;
        public char LastInputChar
        {
            get
            {
                return lastInputChar;
            }
            set
            {
                lastInputChar = value;
            }
        }

        //zadnji operator koristen
        private char lastOperator;
        public char LastOperator
        {
            get
            {
                return lastOperator;
            }
            set
            {
                lastOperator = value;
            }
        }

        //trenutni operator koji se koristi
        private char equationOperator;
        public char EquationOperator
        {
            get
            {
                return equationOperator;
            }
            set
            {
                equationOperator = value;
            }
        }

        private Display display;
        //privremena i stalna memorija
        private Memory tempMemory;
        private Memory permanentMemory;
        #endregion

        public Kalkulator()
        {
            display = new Display();
            tempMemory = new Memory();
            permanentMemory = new Memory();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
        }

        public void Press(char inPressedDigit)
        {
            //reduciramo prikazani broj do prve ne-nule i ne-zareza cim se stisne +-*/ ili ==
            if (DOUBLE_OPERAND_OPERATORS.Contains(inPressedDigit) || inPressedDigit == '=')
            {
                display.SetDisplay(display.GetDisplayState().TrimEnd('0').TrimEnd(','));
            }

            //operacije koje se dobivaju pritiskom tipaka
            if (MISC_OPERATORS.Contains(inPressedDigit))
            {
                if (inPressedDigit == 'C')
                {
                    display.ResetDisplay();
                }
                else
                {
                    display.ResetDisplay();
                    equationOperator = new char();
                    tempMemory.ResetMemory();
                }
            }
            else if (MEMORY_OPERATORS.Contains(inPressedDigit))
            {
                if (inPressedDigit == 'G')
                {
                    display.SetDisplay(permanentMemory.RetrieveMemory());
                }
                else
                {
                    permanentMemory.StoreToMemory(display.GetDisplayState());
                }
            }
            else if (SINGLE_OPERAND_OPERATORS.Contains(inPressedDigit))
            {
                display.SetDisplay(MathOperations.Calculate(display.GetDisplayStateDouble(), inPressedDigit));
                lastOperator = inPressedDigit;
            }
            else if (DOUBLE_OPERAND_OPERATORS.Contains(inPressedDigit))
            {
                lastOperator = inPressedDigit;

                if (equationOperator == '\0')
                {
                    equationOperator = inPressedDigit;
                    tempMemory.StoreToMemory(display.GetDisplayState());
                }
                else
                {
                    //ako imamo vise uzastopnih operatora, uzimamo zadnjeg
                    if (!SINGLE_OPERAND_OPERATORS.Contains(inPressedDigit) && !DOUBLE_OPERAND_OPERATORS.Contains(inPressedDigit))
                    {
                        tempMemory.StoreToMemory(MathOperations.Calculate(tempMemory.RetrieveMemoryForOperation(), display.GetDisplayStateDouble(), equationOperator));
                    }
                    else
                    {
                        lastOperator = equationOperator;
                        equationOperator = inPressedDigit;

                        //ako je nakon nekoliko uzastopnih znakova neki drugi broj od onoga spremljenog u temp, racunamo
                        if (DOUBLE_OPERAND_OPERATORS.Contains(inPressedDigit) && display.GetDisplayState() != tempMemory.RetrieveMemory() && lastOperator != equationOperator)
                        {
                            tempMemory.StoreToMemory(MathOperations.Calculate(tempMemory.RetrieveMemoryForOperation(), display.GetDisplayStateDouble(), lastOperator));
                            display.SetDisplay(tempMemory.RetrieveMemory());
                        }
                    }
                }

            }
            //znak minus nije racunska operacija, pa nije u skupu konstanti
            else if (inPressedDigit == 'M')
            {
                if (display.GetDisplayState().Contains('-'))
                {
                    display.SetDisplay(GetCurrentDisplayState().TrimStart('-'));
                }
                else
                {
                    display.SetDisplay('-' + display.GetDisplayState());
                }
            }
            else if (inPressedDigit == '=')
            {
                //ako je pritisnuta on/off tipka
                if (display.GetDisplayState() == "")
                {
                    display.ResetDisplay();
                }

                if (equationOperator == '\0' && tempMemory.IsMemorySet && lastOperator == '\0' && !SINGLE_OPERAND_OPERATORS.Contains(lastOperator))
                {
                    display.SetDisplay(tempMemory.RetrieveMemory());
                }
                else if (equationOperator == '\0' && tempMemory.IsMemorySet && lastOperator != '\0' && !SINGLE_OPERAND_OPERATORS.Contains(lastOperator))
                {
                    display.SetDisplay(MathOperations.Calculate(display.GetDisplayStateDouble(), tempMemory.RetrieveMemoryForOperation(), lastOperator));
                    if (display.GetDisplayState() != "-E-" && !DOUBLE_OPERAND_OPERATORS.Contains(lastInputChar))
                    {
                        tempMemory.StoreToMemory(display.GetDisplayState());
                    }
                }
                else if (equationOperator != '\0' && tempMemory.IsMemorySet)
                {
                    display.SetDisplay(MathOperations.Calculate(tempMemory.RetrieveMemoryForOperation(), display.GetDisplayStateDouble(), equationOperator));
                    if (display.GetDisplayState() != "-E-" && !DOUBLE_OPERAND_OPERATORS.Contains(lastInputChar))
                    {
                        tempMemory.StoreToMemory(display.GetDisplayState());
                    }
                }

                equationOperator = new char();
            }
            else
            {
                //ako je prvi operand unesen u memoriju i stisnuta je neka operacija, stavi display na "0"
                //ili ako smo koristili neki singularni operator nakon operatora sa 2 operanda.
                //ili ako smo stisnuli zarez nakon neke operacije
                //PREVISE UVJETA! :(
                if ((equationOperator != '\0' && display.GetDisplayState() == tempMemory.RetrieveMemory())
                    || (lastOperator != equationOperator && 
                    !(!SINGLE_OPERAND_OPERATORS.Contains(lastInputChar) && !DOUBLE_OPERAND_OPERATORS.Contains(lastInputChar))))
                {
                    display.ResetDisplay();
                }
                display.AddCharToDisplay(inPressedDigit);
            }

            //ako je trenutni operator različit od prošlog, zapamti broj s kojim se racuna
            if (display.GetDisplayState() != "-E-" && equationOperator != lastOperator && display.GetDisplayState() == tempMemory.RetrieveMemory())
            {
                tempMemory.StoreToMemory(display.GetDisplayState());
            }

            //pamtimo zadnji upisani znak
            lastInputChar = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            //return Display.ToString();
            return display.GetDisplayState();
        }
    }
}
