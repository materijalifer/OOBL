using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }

    }
	
	public class Calculator : ICalculator
    {
        private const int MAXBROJZNAMENKI = 10;

        private string display;

        private int brojZnamenki;

        private double rezultat;

        private char znak;

        private string memorija;

        private bool unarnaOperacija = false;

        private bool jednakoVisePuta = false;

        private double pamtiBrojZaJednako;

        private char pamtiZnakZaJednako;

        private List<char> znakoviOperacija = new List<char>();

        private List<char> znamenke = new List<char>();

        private List<char> znakoviUnarnihOperacija = new List<char>();

        /// <summary>
        /// Konstruktor razreda. Inicijalizacija varijabli te postavljanje znakova.
        /// </summary>
        public Calculator()
        {
            postaviZnakoveOperacija();
            postaviZnamenke();
            PostaviZnakoveUnarnihOperacija();
            ResetCalculator();
        }

        /// <summary>
        ///  Znakovi operacija koje se izvode nad dva operanda.
        /// </summary>
        private void postaviZnakoveOperacija()
        {
            znakoviOperacija.Add('+');
            znakoviOperacija.Add('-');
            znakoviOperacija.Add('*');
            znakoviOperacija.Add('/');
        }

        
        /// <summary>
        /// Znamenke dekadskog sustava. Zarez je dodan u ovu skupinu jer se 
        /// ispisuje na ekranu zajedno sa znamenkama.
        /// </summary>
        private void postaviZnamenke()
        {
            znamenke.Add('0');
            znamenke.Add('1');
            znamenke.Add('2');
            znamenke.Add('3');
            znamenke.Add('4');
            znamenke.Add('5');
            znamenke.Add('6');
            znamenke.Add('7');
            znamenke.Add('8');
            znamenke.Add('9');
            znamenke.Add(',');
        }

        /// <summary>
        /// Unarne operacije koje rade s operandom koji je prikazan na displayu.
        /// Ako se unese nova znamenka nakon ove operacije display se prebri�e.
        /// </summary>
        private void PostaviZnakoveUnarnihOperacija()
        {
            znakoviUnarnihOperacija.Add('S');
            znakoviUnarnihOperacija.Add('K');
            znakoviUnarnihOperacija.Add('T');
            znakoviUnarnihOperacija.Add('Q');
            znakoviUnarnihOperacija.Add('R');
            znakoviUnarnihOperacija.Add('I');
        }

        /// <summary>
        /// Po�etno stanje kalkulatora.
        /// </summary>
        private void ResetCalculator()
        {
            display = "0";
            brojZnamenki = 0;
            rezultat = 0;
            znak = '+';
            memorija = "0";
        }

        public void Press(char inPressedDigit)
        {
            // Ako je u pro�lom koraku do�lo do gre�ke, resetiraj kalkulator.
            if (display.Contains("-E-")) 
            {
                ResetCalculator();
            }

            int funkcija = ProvjeriFunkciju(inPressedDigit);

            // Try - catch blok koji hvata sve gre�ke pri radu kalkulatora 
            // te ispisuje "-E-" na display ukoliko je do�lo do gre�ke
            try
            {
                switch (funkcija)
                {
                    case 0: // Znamenka ili zarez
                        if (unarnaOperacija)
                        {
                            unarnaOperacija = false;
                            brojZnamenki = 0;   // "resetiraj" display
                        }
                        ZnamenkaIliZarez(inPressedDigit);
                        jednakoVisePuta = false;
                        break;
                    case 1: // Binarna operacija
                        if (brojZnamenki > 0 || unarnaOperacija)
                        {
                            Operacija();
                        }
                        unarnaOperacija = false;
                        jednakoVisePuta = false;
                        znak = inPressedDigit;
                        break;
                    case 2: // Unarna operacija
                        jednakoVisePuta = false;
                        UnarnaOperacija(inPressedDigit);
                        break;
                    case 3: // Ostale operacije
                        unarnaOperacija = false;
                        OstaleOperacije(inPressedDigit);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception)
            {
                display = "-E-";
            }
        }

        /// <summary>
        /// Provjerava unesenu znamenku
        /// </summary>
        /// <param name="inPressedDigit">Pritisnuti znak</param>
        /// <returns></returns>
        private int ProvjeriFunkciju(char inPressedDigit)
        {
            if (znamenke.Contains(inPressedDigit))
            {
                return 0;
            }
            else if (znakoviOperacija.Contains(inPressedDigit))
            {
                return 1;
            }
            else if (znakoviUnarnihOperacija.Contains(inPressedDigit))
            {
                return 2;
            }
            else
            {
                return 3;
            }
        }

        /// <summary>
        /// Zapisuje znamenku ili zarez na ekran.
        /// </summary>
        /// <param name="digit">Pritisnuta znamenka ili zarez.</param>
        private void ZnamenkaIliZarez(char digit)
        {
            if (digit == ',')
            {
                if (brojZnamenki == 0)
                {
                    display = "0,";
                    brojZnamenki++;
                }
                else if (!display.Contains(',')) // broj moze imati samo jednu decimalnu tocku
                {
                    display += digit;
                }
            }
            else if (brojZnamenki < MAXBROJZNAMENKI) // moguce je unijeti samo MAXBROJZNAMENKI
            {
                if (brojZnamenki == 0)
                {
                    if (digit != '0')
                    {
                        display = digit.ToString();
                        brojZnamenki++;
                    }
                    return;
                }
                display += digit;
                brojZnamenki++;
            }
        }

        /// <summary>
        /// Operacije koje se izvode nad dva operanda te se rezultat sprema u 
        /// varijablu "rezultat", me�urezultat prilikom uno�enja znakova.
        /// </summary>
        private void Operacija()
        {
            switch (znak)
            {
                case '+':
                    rezultat = Funkcije.OperacijaZbrajanje(rezultat, display);
                    break;
                case '-':
                    rezultat = Funkcije.OperacijaOduzimanje(rezultat, display);
                    break;
                case '*':
                    rezultat = Funkcije.OperacijaMnozenje(rezultat, display);
                    break;
                case '/':
                    rezultat = Funkcije.OperacijaDijeljenje(rezultat, display);
                    break;
                default:
                    break;
            }

            brojZnamenki = 0;   // "resetiraj" display
        }

        /// <summary>
        /// Operacije koje se ne pona�aju ni kao klasi�ne unarne 
        /// operacije, a ni kao binarne operacije.
        /// </summary>
        /// <param name="op"></param>
        private void OstaleOperacije(char op)
        {
            switch (op)
            {
                case 'O':
                    ResetCalculator();
                    break;
                case 'C':
                    display = "0";
                    brojZnamenki = 0;   // "resetiraj" display
                    break;
                case 'P':
                    memorija = display;
                    break;
                case 'G':
                    display = memorija;
                    unarnaOperacija = true; // pona�a se kao unarna operacija
                    break;
                case 'M':
                    if (brojZnamenki == 0)
                    {
                        return;
                    }
                    display = Funkcije.OperacijaPredznak(display);
                    break;
                case '=':
                    OperacijaJednako();
                    return;
                default:
                    break;
            }

            jednakoVisePuta = false;
        }

        private void OperacijaJednako()
        {
            if (!jednakoVisePuta)
            {
                jednakoVisePuta = true;
                pamtiBrojZaJednako = double.Parse(display);
                pamtiZnakZaJednako = znak;
                Operacija();
                display = rezultat.ToString();
                rezultat = 0;
                znak = '+';
            }
            else
            {
                rezultat = double.Parse(display);
                display = pamtiBrojZaJednako.ToString();
                znak = pamtiZnakZaJednako;
                Operacija();
                display = rezultat.ToString();
                rezultat = 0;
                znak = '+';
            }
            unarnaOperacija = true;
        }

        /// <summary>
        /// Operacije koje se izvode s brojem koji se nalazi na ekranu.
        /// </summary>
        /// <param name="op">Znak operacije za izvo�enje.</param>
        private void UnarnaOperacija(char op)
        {
            switch (op)
            {
                case 'S':
                    display = Funkcije.OperacijaSinus(display);
                    break;
                case 'K':
                    display = Funkcije.OperacijaKosinus(display);
                    break;
                case 'T':
                    display = Funkcije.OperacijaTangens(display);
                    break;
                case 'Q':
                    display = Funkcije.OperacijaKvadriranje(display);
                    break;
                case 'R':
                    display = Funkcije.OperacijaKorjenovanje(display);
                    break;
                case 'I':
                    display = Funkcije.OperacijaInverz(display);
                    break;
                default:
                    break;
            }

            unarnaOperacija = true;
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }
    }

    static class Funkcije
    {
        // Konstanta - maksimalan broj znamenki na displayu
        private const int MAXBRZNAMENKI = 10;

        // Broj za 1 ve�i od najve�eg broja koji stane na displayu
        private static double MAXBROJ = Math.Pow(10, MAXBRZNAMENKI);

        /// <summary>
        /// Zbraja dva broja. Domena funkcije je R. Slika funkcije je R. 
        /// Rezultat mora biti u dozvoljenom intervalu.
        /// </summary>
        /// <param name="rezultat">Prvi operand</param>
        /// <param name="display">Drugi operand</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static double OperacijaZbrajanje(double rezultat, string display)
        {
            double broj = rezultat + double.Parse(display);

            broj = RoundDouble(broj);

            if (Math.Abs(broj) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return broj;
        }

        /// <summary>
        /// Oduzima dva broja. Domena funkcije je R. Slika funkcije je R. 
        /// Rezultat mora biti u dozvoljenom intervalu.
        /// </summary>
        /// <param name="rezultat">Prvi operand</param>
        /// <param name="display">Drugi operand</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static double OperacijaOduzimanje(double rezultat, string display)
        {
            double broj = rezultat - double.Parse(display);

            broj = RoundDouble(broj);

            if (Math.Abs(broj) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return broj;
        }

        /// <summary>
        /// Mno�i dva broja. Domena funkcije je R. Slika funkcije je R. 
        /// Rezultat mora biti u dozvoljenom intervalu.
        /// </summary>
        /// <param name="rezultat">Prvi operand</param>
        /// <param name="display">Drugi operand</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static double OperacijaMnozenje(double rezultat, string display)
        {
            double broj = rezultat * double.Parse(display);

            broj = RoundDouble(broj);

            if (Math.Abs(broj) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return broj;
        }

        /// <summary>
        /// Dijeli dva broja. Djelitelj (drugi operand) ne smije biti 0. 
        /// Domena funkcije je R. Slika funkcije je R. Rezultat mora biti u 
        /// dozvoljenom intervalu.
        /// </summary>
        /// <param name="rezultat">Prvi operand</param>
        /// <param name="display">Drugi operand</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala</returns>
        /// <throws>DivideByZeroException, ArgumentOutOfRangeException</throws>
        public static double OperacijaDijeljenje(double rezultat, string display)
        {
            double broj = double.Parse(display);

            if (broj == 0)
            {
                throw new DivideByZeroException("Nije dozvoljeno dijeljenje s 0!");
            }

            broj = rezultat / broj;

            broj = RoundDouble(broj);

            if (Math.Abs(broj) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return broj;
        }

        /// <summary>
        /// Vra�a sinus broja. Domena funkcije je R. Slika funkcije je (-1, 1).
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost kao niz znakova</returns>
        public static string OperacijaSinus(string display)
        {
            double rezultat = Math.Sin(double.Parse(display));

            return String.Format("{0:0.#########}", RoundDouble(rezultat));
        }

        /// <summary>
        /// Vra�a kosinus broja. Domena funkcije je R. Slika funkcije je (-1, 1).
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost kao niz znakova</returns>
        public static string OperacijaKosinus(string display)
        {
            double rezultat = Math.Cos(double.Parse(display));

            return String.Format("{0:0.#########}", RoundDouble(rezultat));
        }

        /// <summary>
        /// Vra�a tangens broja. Domena funkcije je R \ {k*PI}, k � Z. 
        /// Slika funkcije je R.
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala kao niz znakova</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static string OperacijaTangens(string display)
        {
            double rezultat = Math.Tan(double.Parse(display));

            rezultat = RoundDouble(rezultat);

            if (Math.Abs(rezultat) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return String.Format("{0:0.#########}", rezultat);
        }

        /// <summary>
        /// Vra�a kvadrat broja. Domena funkcije je R. 
        /// Slika funkcije je (0, +inf).
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost ukoliko je u granicama intervala kao niz znakova</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static string OperacijaKvadriranje(string display)
        {
            double rezultat = Math.Pow(double.Parse(display), 2.0);

            rezultat = RoundDouble(rezultat);

            if (Math.Abs(rezultat) >= MAXBROJ)
            {
                throw new ArgumentOutOfRangeException("Broj ne stane na ekran!");
            }

            return String.Format("{0:0.#########}", rezultat);
        }

        /// <summary>
        /// Vra�a korijen broja. Domena funkcije je (0, +inf). 
        /// Slika funkcije je (0, +inf). Broj mora biti pozitivan.
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost kao niz znakova</returns>
        /// <throws>ArgumentOutOfRangeException</throws>
        public static string OperacijaKorjenovanje(string display)
        {
            double rezultat = double.Parse(display);

            if (rezultat < 0)
            {
                throw new ArgumentOutOfRangeException("Broj ispod korijena mora biti pozitivan!");
            }

            rezultat = Math.Sqrt(double.Parse(display));

            return String.Format("{0:0.#########}", RoundDouble(rezultat));
        }

        /// <summary>
        /// Vra�a inverz broja. Broj ne smije biti 0.
        /// </summary>
        /// <param name="rezultat">Operand nad kojim se vr�i operacija</param>
        /// <returns>Izra�unata vrijednost kao niz znakova</returns>
        /// <throws>DivideByZeroException</throws>
        public static string OperacijaInverz(string display)
        {
            double rezultat = double.Parse(display);

            if (rezultat == 0)
            {
                throw new DivideByZeroException("Nije dozvoljeno dijeliti s 0!");
            }

            rezultat = 1 / rezultat;

            return String.Format("{0:0.#########}", RoundDouble(rezultat));
        }

        /// <summary>
        /// Mijenja predznak.
        /// </summary>
        /// <param name="display">Operand nad kojim se vr�i operacija</param>
        /// <returns>izra�unata vrijednost kao niz znakova</returns>
        public static string OperacijaPredznak(string display)
        {
            if (display.Contains('-'))
            {
                display = display.Substring(1, display.Length - 1);
            }
            else
            {
                display = "-" + display;
            }

            return display;
        }

        /// <summary>
        /// Zaokru�uje broj tako da decimalni i 
        /// </summary>
        /// <param name="broj"></param>
        /// <returns></returns>
        private static double RoundDouble(double broj)
        {
            int brojac = 0;
            long pom = (long) Math.Abs(broj);

            do
            {
                brojac++;
                pom /= 10;
            }
            while (pom > 0);

            return Math.Round(broj, MAXBRZNAMENKI - brojac);
        }
    }
}
