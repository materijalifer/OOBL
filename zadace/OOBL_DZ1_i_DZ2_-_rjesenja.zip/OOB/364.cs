﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string stockName;
        private long numberOfShares;
        private Dictionary<DateTime, decimal> datePrice;
        private bool onMarket;
        private bool inIndex;

        public string StockName
        {
            get { return stockName; }
            set { stockName = value; }
        }

        public long NumberOfShares
        {
            get { return numberOfShares; }
            set
            {
                numberOfShares = value;
                if (numberOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od 0");
            }
        }

        public Dictionary<DateTime, decimal> DatePrice
        {
            get { return datePrice; }
            set { datePrice = value; }
        }

        public bool OnMarket
        {
            get { return onMarket; }
            set { onMarket = value; }
        }

        public bool InIndex
        {
            get { return inIndex; }
            set { inIndex = value; }
        }
    }

    public class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private List<Stock> indexTypeStocks;
        private decimal indexTypeValue;

        public string IndexName
        {
            get { return indexName; }
            set { indexName = value; }
        }

        public IndexTypes IndexType
        {
            get { return indexType; }
            set { indexType = value; }
        }

        public decimal IndexTypeValue
        {
            get { return indexTypeValue; }
            set { indexTypeValue = value; }
        }

        public List<Stock> IndexTypeStocks
        {
            get { return indexTypeStocks; }
            set { indexTypeStocks = value; }
        }

    }

    public class Portfolio
    {
        private string portofolioName;
        private Dictionary<string, int> portofilioStocks;

        public string PortofolioName
        {
            get { return portofolioName; }
            set { portofolioName = value; }
        }

        public Dictionary<string, int> PortofilioStocks
        {
            get { return portofilioStocks; }
            set { portofilioStocks = value; }
        }


    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stockList = null;
        private List<Index> indexList = null;
        private List<Portfolio> portfolioList = null;

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock newStock;
            if (stockList != null)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                        throw new StockExchangeException("Već postoji dionica pod tim nazivom");
                }
            }
            else
                stockList = new List<Stock>();
            if (inStockName == null)
                throw new StockExchangeException("Vrijednost imena dionice mora biti zadana");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Nedopuštena cijena dionice");
            newStock = new Stock()
                {
                    StockName = inStockName,
                    NumberOfShares = inNumberOfShares,
                    OnMarket = true,
                    InIndex = false
                };

            if (newStock.DatePrice == null)
                newStock.DatePrice = new Dictionary<DateTime, decimal>();

            newStock.DatePrice.Add(inTimeStamp, inInitialPrice);
            stockList.Add(newStock);
        }

        public void DelistStock(string inStockName)
        {
            if (stockList.Count > 0)
            {
                bool foundStock = false;
                foreach (Stock existingStock in stockList)
                {

                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        existingStock.OnMarket = false;
                        foundStock = true;
                        break;
                    }
                }
                if (!foundStock)
                    throw new StockExchangeException("Burza ne sadrži navedenu dionicu");
            }
            else
                throw new StockExchangeException("Burza ne sadrži dionice");
        }

        public bool StockExists(string inStockName)
        {
            if (stockList.Count > 0)
            {
                foreach (Stock existingStock in stockList)
                {
                    if ((existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0) &&
                        existingStock.OnMarket)
                        return true;
                }
            }
            return false;
        }

        public int NumberOfStocks()
        {
            int number = 0;
            if (stockList != null)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.OnMarket)
                        number++;
                }
                return number;
            }
            return 0;
         }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (stockList.Count > 0)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        if (existingStock.DatePrice.ContainsKey(inIimeStamp))
                            throw new StockExchangeException(
                                "Promjena nije moguća jer već postoji cijena za točno navedeni datum");
                        existingStock.DatePrice.Add(inIimeStamp, inStockValue);
                        break;
                    }
                }
            }
            else
                throw new StockExchangeException("Burza ne sadrži dionice");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            DateTime maxMinimumTime = DateTime.MinValue;
            decimal price = 0.0M;
            if (stockList.Count > 0)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        foreach (KeyValuePair<DateTime, decimal> pair in existingStock.DatePrice)
                        {
                            if (pair.Key <= inTimeStamp)
                                if (pair.Key > maxMinimumTime)
                                {
                                    maxMinimumTime = pair.Key;
                                    price = pair.Value;
                                }
                        }
                        break;
                    }

                }
                if (maxMinimumTime == DateTime.MinValue || price == 0.0M)
                    throw new StockExchangeException("Tražena dionica za dohvat cijene za određeno vrijeme ne postoji");
                else
                    return price;
            }
            else
                throw new StockExchangeException("Burza ne sadrži dionice");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            DateTime minimumTime = DateTime.MaxValue;
            DateTime testTime = minimumTime;
            decimal price = 0.0M;
            if (stockList.Count > 0)
            {
                foreach (Stock existingStock in stockList)
                {

                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        foreach (KeyValuePair<DateTime, decimal> pair in existingStock.DatePrice)
                        {
                            if (pair.Key <= minimumTime)
                            {
                                minimumTime = pair.Key;
                                price = pair.Value;
                            }
                        }
                        break;
                    }
                }
                if (minimumTime == testTime || price == 0.0M)
                    throw new StockExchangeException("Tražena dionica nema inicijaliziranu cijenu");
                else
                    return price;
            }
            else
                throw new StockExchangeException("Burza ne sadrži dionice");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            DateTime minimumTime = DateTime.MinValue;
            DateTime testTime = minimumTime;
            decimal price = 0.0M;

            if (stockList.Count > 0)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        foreach (KeyValuePair<DateTime, decimal> pair in existingStock.DatePrice)
                        {
                            if (pair.Key >= minimumTime)
                            {
                                minimumTime = pair.Key;
                                price = pair.Value;
                            }
                        }
                        break;
                    }
                }
                if (minimumTime == DateTime.MinValue || price == 0.0M)
                    throw new StockExchangeException("Tražena dionica nema inicijaliziranu zadnju promjenu cijene");
                else
                    return price;
            }
            else
                throw new StockExchangeException("Burza ne sadrži dionice");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index;

            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                        throw new StockExchangeException("Neuspješno kreiranje indexa, index pod tim imenom već postoji");
                }
            }
            else
                indexList = new List<Index>();

            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Pokušaj stvaranja indexa nedozvoljenog tipa");

            index = new Index() {IndexName = inIndexName, IndexType = inIndexType};
            if (index.IndexTypeStocks == null)
                index.IndexTypeStocks = new List<Stock>();
            indexList.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            bool found = false;
            foreach (Stock existingStock in stockList)
            {
                if (!existingStock.OnMarket)
                    continue;

                if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                {
                    if (existingStock.InIndex)
                        throw new StockExchangeException("Neuspješno dodavanje, dionica je prethodno dodana indexu");
                    else
                    {
                        foreach (Index existingIndex in indexList)
                        {
                            if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                            {
                                existingIndex.IndexTypeStocks.Add(existingStock);
                                existingStock.InIndex = true;
                                found = true;
                                break;
                            }
                        }
                    }
                }
                if (found)
                    break;
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            bool remove = false;
            foreach (Index existingIndex in indexList)
            {
                if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                {
                    foreach (Stock existingStock in stockList)
                    {
                        if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                            existingIndex.IndexTypeStocks.Remove(existingStock);
                        remove = true;
                        break;
                    }
                }
                if (remove)
                    break;
            }
            if (!remove)
                throw new StockExchangeException("Navedena dionica ne postoji u indexu");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                    {
                        foreach (Stock existingStock in stockList)
                        {
                            if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                            {
                                if (existingIndex.IndexTypeStocks.Contains(existingStock))
                                    return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                    {
                        if (existingIndex.IndexType == IndexTypes.AVERAGE)
                            return AverageIndexValue(inIndexName, inTimeStamp);
                        return WeightIndexValue(inIndexName, inTimeStamp);
                    }
                }
            }
            throw new StockExchangeException("Indeks ne postoji");
        }

        public bool IndexExists(string inIndexName)
        {
            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                        return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            int number = 0;
            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    number++;
                }
                return number;
            }
            return 0;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            int numberOfStocks = 0;
            if (indexList != null)
            {
                foreach (Index existingIndex in indexList)
                {
                    if (existingIndex.IndexName.ToLower().CompareTo(inIndexName.ToLower()) == 0)
                        numberOfStocks = existingIndex.IndexTypeStocks.Count();
                }
            }
            return numberOfStocks;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio newPortfolio = null;
            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofolioName == inPortfolioID)
                        throw new StockExchangeException("ID novog portfelja nije jedinstven");
                }
            }
            else
                portfolioList = new List<Portfolio>();
            newPortfolio = new Portfolio() {PortofolioName = inPortfolioID};
            portfolioList.Add(newPortfolio);


        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!FreeToAddStocks(inStockName, numberOfShares))
                throw new StockExchangeException("Nedovoljno velik broj slobodnih dionica");

            Portfolio newPortofilio = null;
            string name1 = "";
            string name2 = " ";
            int stock = 0;
            bool add = false;

            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofolioName == inPortfolioID)
                    {
                        if (existingPortfolio.PortofilioStocks != null)
                        {
                            foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                            {
                                name1 = pair.Key.ToLower();
                                name2 = pair.Key;
                                if (name1 == inStockName.ToLower())
                                {
                                    stock = pair.Value + numberOfShares;
                                    existingPortfolio.PortofilioStocks.Remove(name2);
                                    existingPortfolio.PortofilioStocks.Add(name2, stock);
                                    add = true;
                                    break;
                                }
                            }
                            if(!add)
                                existingPortfolio.PortofilioStocks.Add(inStockName, numberOfShares);
                        }
                        else
                        {
                            existingPortfolio.PortofilioStocks = new Dictionary<string, int>();
                            existingPortfolio.PortofilioStocks.Add(inStockName, numberOfShares);
                            break;
                        }
                    }
                }
            }
            else
            {
                newPortofilio = new Portfolio() {PortofolioName = inPortfolioID};
                if (newPortofilio.PortofilioStocks == null)
                    newPortofilio.PortofilioStocks = new Dictionary<string, int>();
                newPortofilio.PortofilioStocks.Add(inStockName, numberOfShares);
                portfolioList.Add(newPortofilio);
            }
        }
        
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofolioName == inPortfolioID)
                    {
                        if (existingPortfolio.PortofilioStocks != null)
                        {
                            foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                            {
                                if (pair.Key.ToLower().CompareTo(inStockName.ToLower()) == 0)
                                {
                                    if ((pair.Value - numberOfShares) == 0)
                                        existingPortfolio.PortofilioStocks.Remove(pair.Key);
                                    else
                                        existingPortfolio.PortofilioStocks[pair.Key] = pair.Value - numberOfShares;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (portfolioList != null)
             {
                 foreach (Portfolio existingPortfolio in portfolioList)
                 {
                     if (existingPortfolio.PortofolioName == inPortfolioID)
                     {
                         if (existingPortfolio.PortofilioStocks != null)
                         {
                             existingPortfolio.PortofilioStocks.Remove(inStockName);
                         }
                     }
                 }
             }
         }

         public int NumberOfPortfolios()
         {
             if (portfolioList != null)
                 return portfolioList.Count;
             return 0;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             List<string> list = null;
             if (portfolioList != null)
             {
                 foreach (Portfolio existingPortfolio in portfolioList)
                 {
                     if (existingPortfolio.PortofolioName == inPortfolioID)
                     {
                         if (existingPortfolio.PortofilioStocks != null)
                         {
                             list = new List<string>(existingPortfolio.PortofilioStocks.Keys);
                             return list.Count;
                         }
                         
                     }
                 }
             }
             return 0;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (portfolioList != null)
             {
                 foreach (Portfolio existingPortfolio in portfolioList)
                 {
                     if (existingPortfolio.PortofolioName == inPortfolioID)
                         return true;
                 }
             }
             return false;
         }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            string name1 = "";
            string name2 = " ";

            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofilioStocks != null)
                    {
                        foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                        {
                            name1 = pair.Key.ToLower();
                            name2 = inStockName.ToLower();
                            if (name1 == name2)
                                return true;
                        }
                    }
                }
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofilioStocks != null)
                    {
                        foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                        {
                            if (pair.Key.ToLower().CompareTo(inStockName.ToLower()) == 0)
                                return pair.Value;
                        }
                    }
                }
            }
            return 0;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal totalSum = 0.0M;

            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofolioName == inPortfolioID)
                    {
                        foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                            totalSum += pair.Value * GetStockPrice(pair.Key, timeStamp);
                    }
                }
            }
            return totalSum;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }

         public decimal AverageIndexValue(string name, DateTime time)
         {
             int numberOfStocks = 0;
             decimal totalSum = 0.0M;
             decimal value = 0;
             foreach (Index existingIndex in indexList)
             {
                 if (existingIndex.IndexName.ToLower().CompareTo(name.ToLower()) == 0)
                 {
                     foreach (Stock existingStock in existingIndex.IndexTypeStocks)
                     {
                         numberOfStocks++;
                         totalSum += GetStockPrice(existingStock.StockName, time);
                     }
                     if (numberOfStocks == 0)
                         return 0.0M;
                     return totalSum/numberOfStocks;
                 }
             }
             value = Math.Truncate(value*1000)/1000M;
             return value;
         }

         public decimal WeightIndexValue(string name, DateTime time)
         {
             decimal totalSum = 0.0M;
             decimal value = 0.0M;

             foreach (Index existingIndex in indexList)
             {
                 if (existingIndex.IndexName.ToLower().CompareTo(name.ToLower()) == 0)
                 {
                     foreach (Stock existingStock in existingIndex.IndexTypeStocks)
                     {
                         for (int i = 0; i < existingStock.NumberOfShares; i++)
                             totalSum += GetStockPrice(existingStock.StockName, time);
                     }
                     foreach (Stock existingStock in existingIndex.IndexTypeStocks)
                     {
                         for (int i = 0; i < existingStock.NumberOfShares; i++)
                             value += (GetStockPrice(existingStock.StockName, time)/totalSum)* GetStockPrice(existingStock.StockName, time);
                         
                     }
                 }
             }
             value = Math.Truncate(value * 1000) / 1000M;
             return value;
         }

         public bool FreeToAddStocks(string inStockName, int numberOfStocks)
         {
            long totalNumberOfStocks = 0;
            long addedStocks = 0;
            if (stockList != null)
            {
                foreach (Stock existingStock in stockList)
                {
                    if (existingStock.StockName.ToLower().CompareTo(inStockName.ToLower()) == 0)
                    {
                        totalNumberOfStocks = existingStock.NumberOfShares;
                        break;
                    }
                }
            }
            if (portfolioList != null)
            {
                foreach (Portfolio existingPortfolio in portfolioList)
                {
                    if (existingPortfolio.PortofilioStocks != null)
                    {
                        foreach (KeyValuePair<string, int> pair in existingPortfolio.PortofilioStocks)
                        {
                            if (pair.Key.ToLower().CompareTo(inStockName.ToLower()) == 0)
                                addedStocks += pair.Value;
                        }
                    }
                }
            }
            if (totalNumberOfStocks - (addedStocks + numberOfStocks) >= 0)
                return true;
            return false;
        }
     }
}
