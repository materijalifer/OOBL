﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    static class CalcOperations
    {
        public static double Action(double x, double y, char znak)
        {
            double result;
            switch (znak)
            {
                case Constants.ZBRAJANJE:
                    result = x + y;
                    break;
                case Constants.ODUZIMANJE:
                    result = x - y;
                    break;
                case Constants.MNOZENJE:
                    result = x * y;
                    break;
                case Constants.DIJELJENJE:
                    result = x / y;
                    break;
                default:
                    throw new Exception("Nije binarni operator");
            }
            return result;
        }
        public static double Action(double x, char znak)
        {
            double result;
            switch (znak)
            {
                case Constants.INVERZ:
                    result = 1 / x;
                    break;
                case Constants.SINUS:
                    result = Math.Sin(x);
                    break;
                case Constants.KOSINUS:
                    result = Math.Cos(x);
                    break;
                case Constants.TANGENS:
                    result = Math.Tan(x);
                    break;
                case Constants.KVADRAT:
                    result = x * x;
                    break;
                case Constants.KORIJEN:
                    result = Math.Sqrt(x);
                    break;
                case Constants.BRISIEKRAN:
                    result = 0;
                    break;
                default:
                    throw new Exception("Nije unarni operator");
            }
            return result;
        }
    }
    public static class Constants
    {
        // kratice gumba na kalkulatoru
        public const char ZBRAJANJE = '+';
        public const char ODUZIMANJE = '-';
        public const char MNOZENJE = '*';
        public const char DIJELJENJE = '/';
        public const char JEDNAKO = '=';
        public const char ZAREZ = ',';
        public const char PROMJENAPREDZNAKA = 'M';
        public const char SINUS = 'S';
        public const char KOSINUS = 'K';
        public const char TANGENS = 'T';
        public const char KVADRAT = 'Q';
        public const char KORIJEN = 'R';
        public const char INVERZ = 'I';
        public const char SPREMI = 'P';
        public const char DOHVATI = 'G';
        public const char BRISIEKRAN = 'C';
        public const char RESET = 'O';
        public const int BROJDOPUSTENIHZNAMENKI = 10;
        public const char NEINICIJALIZIRANO = '\0';

        //grupe operatora
        private static char[] _binarni = new char[4] { ZBRAJANJE, ODUZIMANJE, MNOZENJE, DIJELJENJE };
        private static char[] _unarni = new char[7] { SINUS, KORIJEN, KOSINUS, KVADRAT, TANGENS, INVERZ, BRISIEKRAN };
        private static char[] _znamenke = new char[10] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        public static char[] BINARNI
        {
            get { return _binarni; }
        }
        public static char[] UNARNI
        {
            get { return _unarni; }
        }
        public static char[] ZNAMENKE
        {
            get { return _znamenke; }
        }
    }
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {


        //pomocne varijable
        private double _memorija;
        private double _mnoziteljzadecimalne;
        private double _operand;
        private double _brojnaekranu = 0;
        private double _trenutni_broj;
        private bool _pritisnutaoperacija;
        private bool _pritisnutojednako;
        private char _znakpritisnuteoperacije;
        private double _znamenka;
        private bool _brojznamenkidobar;
        private bool _greska;
        private string _znamenkeizbroja;
        private string _znamenkeizoperanda;
        private bool _operacijaukljucena;

        public Kalkulator()
        {
            _greska = false;
            _brojznamenkidobar = true;
            _memorija = 0;
            _mnoziteljzadecimalne = 1;
            _operand = 0;
            _trenutni_broj = 0;
            _brojnaekranu = 0;
            _pritisnutaoperacija = false;
            _pritisnutojednako = false;
            _znakpritisnuteoperacije = Constants.NEINICIJALIZIRANO;
            _operacijaukljucena = false;
            
        }
        public void Press(char inPressedDigit)
        {
            
            if (_pritisnutaoperacija)
                _znamenkeizbroja = "";
            else
                _znamenkeizbroja = _trenutni_broj.ToString().Replace(",", "").Replace("-", "");
            _brojznamenkidobar = (_znamenkeizbroja.Length <= Constants.BROJDOPUSTENIHZNAMENKI - 1);
            if (_greska == false)
            {
                if (Constants.ZNAMENKE.Contains(inPressedDigit) & _brojznamenkidobar)
                {
                    _znamenka = Convert.ToInt32(inPressedDigit) - 48;

                    if (_pritisnutaoperacija)
                    {
                        _trenutni_broj = 0;
                        _pritisnutaoperacija = false;
                    }
                    if (_pritisnutojednako)
                    {
                        _trenutni_broj = 0;
                        _operand = 0;
                        _pritisnutojednako = false;
                    }
                    if (_mnoziteljzadecimalne == 1)
                    {
                        if (_trenutni_broj >= 0)
                            _trenutni_broj = _trenutni_broj * 10 + _znamenka;
                        else
                            _trenutni_broj = _trenutni_broj * 10 - _znamenka;
                    }
                    else
                    {
                        if (_trenutni_broj >= 0)
                            _trenutni_broj = _trenutni_broj + _znamenka * _mnoziteljzadecimalne;
                        else
                            _trenutni_broj = _trenutni_broj - _znamenka * _mnoziteljzadecimalne;
                        _mnoziteljzadecimalne /= 10;
                    }
                    _trenutni_broj = Math.Round(_trenutni_broj, 9);
                    _brojnaekranu = _trenutni_broj;
                }
                if (Constants.ZAREZ == inPressedDigit)
                {
                    _mnoziteljzadecimalne /= 10;
                }
                if (Constants.BINARNI.Contains(inPressedDigit))
                {
                    _operacijaukljucena = true;
                    _pritisnutojednako = false;
                    _mnoziteljzadecimalne = 1;
                    if (_operand != 0 )
                    {
                        if (_pritisnutaoperacija == false)
                        {
                            _operand = CalcOperations.Action(_operand, _trenutni_broj, _znakpritisnuteoperacije);
                            _operand = Math.Round(_operand, 9);
                        }
                    }
                    else
                    {
                        _operand = _trenutni_broj;
                    }
                    _pritisnutaoperacija = true;
                    _znakpritisnuteoperacije = inPressedDigit;
                    _znamenkeizoperanda = _operand.ToString().Replace(",", "").Replace("-", "");
                    if (_znamenkeizoperanda.Length <= Constants.BROJDOPUSTENIHZNAMENKI & 
                        !Double.IsInfinity(_operand))
                        _brojnaekranu = _operand;
                    else
                        _greska = true;
                }
                if (Constants.UNARNI.Contains(inPressedDigit))
                {
                    if (!_operacijaukljucena)
                        _pritisnutojednako = true;
                    _mnoziteljzadecimalne = 1;
                    _trenutni_broj = CalcOperations.Action(_trenutni_broj, inPressedDigit);
                    _trenutni_broj = Math.Round(_trenutni_broj, 9);
                    _znamenkeizbroja = _trenutni_broj.ToString().Replace(",", "").Replace("-", "");
                    if (_znamenkeizbroja.Length <= Constants.BROJDOPUSTENIHZNAMENKI &
                        !Double.IsInfinity(_trenutni_broj))
                        _brojnaekranu = _trenutni_broj;
                    else
                        _greska = true;
                    
                }
                if (Constants.JEDNAKO == inPressedDigit)
                {
                    if (_pritisnutaoperacija == true)
                    {
                        _operand = CalcOperations.Action(_trenutni_broj, _trenutni_broj, _znakpritisnuteoperacije);
                        _operand = Math.Round(_operand, 9);
                        _znamenkeizoperanda = _operand.ToString().Replace(",", "").Replace("-", "");
                        if (_znamenkeizoperanda.Length <= Constants.BROJDOPUSTENIHZNAMENKI &
                            !Double.IsInfinity(_operand))
                            _brojnaekranu = _operand;
                        else
                            _greska = true;
                    }
                    else
                    {
                        if (_znakpritisnuteoperacije != Constants.NEINICIJALIZIRANO)
                        {
                            _operand = CalcOperations.Action(_operand, _trenutni_broj, _znakpritisnuteoperacije);
                            _operand = Math.Round(_operand, 9);
                            _pritisnutojednako = true;
                            _znamenkeizoperanda = _operand.ToString().Replace(",", "").Replace("-", "");
                            if (_znamenkeizoperanda.Length <= Constants.BROJDOPUSTENIHZNAMENKI)
                                _brojnaekranu = _operand;
                            else
                                _greska = true;
                        }
                    }
                    _mnoziteljzadecimalne = 1;
                }
                if (Constants.SPREMI == inPressedDigit)
                {
                    _memorija = _trenutni_broj;
                }
                if (Constants.DOHVATI == inPressedDigit)
                {
                    _trenutni_broj = _memorija;
                    _brojnaekranu = _trenutni_broj;
                }

                if (Constants.PROMJENAPREDZNAKA == inPressedDigit)
                {
                    _trenutni_broj *= -1;
                    _brojnaekranu = _trenutni_broj;
                }
            }
            if (Constants.RESET == inPressedDigit)
            {
                _brojznamenkidobar = true;
                _greska = false;
                _memorija = 0;
                _mnoziteljzadecimalne = 1;
                _operand = 0;
                _trenutni_broj = 0;
                _brojnaekranu = 0;
                _pritisnutaoperacija = false;
                _pritisnutojednako = false;
                _znakpritisnuteoperacije = Constants.NEINICIJALIZIRANO;
            }
        }

        public string GetCurrentDisplayState()
        {
            if (_greska == false)
                return _brojnaekranu.ToString();
            else
                return "-E-";
        }
    }


}
