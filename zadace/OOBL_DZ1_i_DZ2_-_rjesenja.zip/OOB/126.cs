using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Class that represents stock
    /// </summary>
    public class Stock
    {
      private string _stockName;
      private long _numberShares;

      public Stock(string stockName, long numberShares)
      {
        if (numberShares <= 0) throw new StockExchangeException("Number of shares cannot be smaller than zero");
        _stockName = stockName.ToUpper();
        _numberShares = numberShares;
      }

      public long NumberShares
      {
        get { return _numberShares; }
        set { _numberShares = value; }
      }

      public string Name
      {
        get { return _stockName; }
      }
    }

    /// <summary>
    /// Transaction represents stock price change for given timestamp
    /// </summary>
    public class Transaction
    {
      private DateTime _timeStamp;
      private Decimal _price;
      private Stock _stock;

      public Transaction(Stock stock, Decimal price, DateTime timeStamp)
      {
        if (price <= 0) throw new StockExchangeException("Number cannot be smaller than zero");
        _stock = stock;
        _price = price;
        _timeStamp = timeStamp;
      }

      public Stock Stock
      {
        get { return _stock; }
      }
      public Decimal Price
      {
        get { return _price; }
      }
      public DateTime TimeStamp
      {
        get { return _timeStamp; }
      }
    }

    public class StockRepository
    {
      private static StockRepository _instance = null;

      List<Stock> _listStocks = new List<Stock>();

      public static StockRepository GetInstance()
      {       
        if (_instance == null)
          _instance = new StockRepository();

        return _instance;
      }

      public void AddStock(Stock inStock)
      {
        if (ContainsStockName(inStock.Name) == false)
          _listStocks.Add(inStock);
        else throw new StockExchangeException("Stock already exists");
      }

      public bool ContainsStockName(string name)
      {
        foreach (Stock stock in _listStocks)
          if (stock.Name == name.ToUpper())
            return true;
        return false;
      }

      public Stock GetByName(string name)
      {
        foreach (Stock stock in _listStocks)
          if (stock.Name == name.ToUpper())
            return stock;
        throw new StockExchangeException("Stock doesn't exists");
      }

      public int Count()
      {
        return _listStocks.Count;
      }

      public void Clear()
      {
        _listStocks.Clear();
      }

      public void DelistStock(string inStockName)
      {
        foreach (Stock stock in _listStocks)
          if (stock.Name == inStockName.ToUpper())
          {
            _listStocks.Remove(stock);
            return;
          }
        throw new StockExchangeException("Stock isn't listed on Stock Exchange");
      }
    }

    /// <summary>
    /// Class contains historical data about stocks and transactions (stock prices)
    /// </summary>
    public class TradingData
    {
      private Dictionary<Stock, List<Transaction>> _history;

      public TradingData()
      {
        _history = new Dictionary<Stock, List<Transaction>>();
      }

      public void AddTransaction(Transaction transaction)
      {
        if (_history.ContainsKey(transaction.Stock))
        {
          _history[transaction.Stock].Add(transaction);
          _history[transaction.Stock].Sort((x, y) => y.TimeStamp.CompareTo(x.TimeStamp));
        }
        else
        {
          List<Transaction> transactionsList = new List<Transaction>();
          transactionsList.Add(transaction);
          _history.Add(transaction.Stock, transactionsList);
        }
      }

      public decimal GetPrice(Stock stock, DateTime timeStamp)
      {
        foreach (Transaction transaction in _history[stock])
        {
          if (transaction.TimeStamp < timeStamp)
            return transaction.Price;
        }
        throw new StockExchangeException("No trading data");
      }

      public decimal GetInitalPrice(Stock stock)
      {
        List<Transaction> transactionsList = _history[stock];
        return transactionsList[transactionsList.Count - 1].Price;
      }

      public decimal GetLastPrice(Stock stock)
      {
        List<Transaction> transactionsList = _history[stock];
        return transactionsList[0].Price;
      }

    }


    /// <summary>
    /// Index implementation
    /// </summary>
    public class Index
    {
      private string _name;
      private IndexTypes _indexType;
      private Dictionary<string, bool> _indexStocks;

      public Index(string name, IndexTypes type)
      {
        _name = name;
        _indexType = type;
        _indexStocks = new Dictionary<string, bool>();
      }

      public string Name
      {
        get { return _name; }
        set { _name = value; }
      }

      public IndexTypes Type
      {
        get { return _indexType; }
        set { _indexType = value; }
      }

      public void AddStock(Stock stock)
      {
        if (_indexStocks.ContainsKey(stock.Name)) throw new StockExchangeException("Stock already in index");
        _indexStocks.Add(stock.Name, true);
      }

      public Dictionary<string, bool> Stocks()
      {
        return _indexStocks;
      }

      public bool HasStock(Stock stock)
      {
        return _indexStocks.ContainsKey(stock.Name);
      }

      public int Count()
      {
        return _indexStocks.Count;
      }


      public void RemoveStock(string inStockName)
      {
        if (_indexStocks.ContainsKey(inStockName))
          _indexStocks.Remove(inStockName);
        else throw new StockExchangeException("Stock is not included in index");
      }
    }

    public class IndexRepository
    {
      private static IndexRepository _instance = null;

      List<Index> _listIndices = new List<Index>();

      public static IndexRepository GetInstance()
      {
        if (_instance == null)
          _instance = new IndexRepository();

        return _instance;
      }

      public void AddIndex(Index index)
      {
        if (ContainsIndexName(index.Name) == false)
          _listIndices.Add(index);
        else throw new StockExchangeException("Index already exists");
      }

      public bool ContainsIndexName(string name)
      {
        foreach (Index index in _listIndices)
          if (index.Name == name.ToUpper())
            return true;
        return false;
      }

      public Index GetByName(string name)
      {
        foreach (Index index in _listIndices)
          if (index.Name == name.ToUpper())
            return index;
        throw new StockExchangeException("Index doesn't exists");
      }

      public int Count()
      {
        return _listIndices.Count;
      }

      public void Clear()
      {
        _listIndices.Clear();
      }


    }

    /// <summary>
    /// Portfolio implementation
    /// </summary>
    public class Portfolio
    {
      private string _porfolioID;
      private Dictionary<string, int> _portfolioStocks;

      public string PorfolioID
      {
        get { return _porfolioID; }
        set { _porfolioID = value; }
      }

      public Portfolio(string portfolioID)
      {
        _porfolioID = portfolioID;
        _portfolioStocks = new Dictionary<string, int>();
      }

      public bool ContainsStock(string stockName)
      {
        return _portfolioStocks.ContainsKey(stockName);
      }

      public void AddStocks(string stockName, int numberShares)
      {
        if (_portfolioStocks.ContainsKey(stockName))
          _portfolioStocks[stockName] += numberShares;
        else
          _portfolioStocks.Add(stockName, numberShares);
      }

      public void RemoveStocks(string stockName, int numberShares)
      {
        stockName = stockName.ToUpper();
        if (_portfolioStocks.ContainsKey(stockName))
        {
          if (_portfolioStocks[stockName] > numberShares)
            _portfolioStocks[stockName] -= numberShares;
          else if (_portfolioStocks[stockName] == numberShares) this.RemoveStocks(stockName);
          else throw new StockExchangeException("Not enough stocks in portfolio");
        }
        else throw new StockExchangeException("Stock not in portfolio");
      }

      public void RemoveStocks(string inStockName)
      {
        _portfolioStocks.Remove(inStockName.ToUpper());
      }

      public int CountStocks()
      {
        return _portfolioStocks.Count;
      }

      public bool StockExists(string inStockName)
      {
        return _portfolioStocks.ContainsKey(inStockName.ToUpper());
      }

      public int NumberOfShares(string inStockName)
      {
        inStockName = inStockName.ToUpper();
        if (_portfolioStocks.ContainsKey(inStockName))
          return _portfolioStocks[inStockName];
        else return 0;
      }

      public Dictionary<string, int> Stocks()
      {
        return _portfolioStocks;
      }
    }
    
    

    public class PortfolioRepository
    {
      private static PortfolioRepository _instance = null;

      List<Portfolio> _listPortfolios = new List<Portfolio>();

      public static PortfolioRepository GetInstance()
      {
        if (_instance == null)
          _instance = new PortfolioRepository();

        return _instance;
      }

      public void CreatePortfolio(string portfolioID)
      {
        if (PortfolioExists(portfolioID)) throw new StockExchangeException("Portfolio already exists");
        Portfolio portfolio = new Portfolio(portfolioID);
        _listPortfolios.Add(portfolio);
      }

      public bool PortfolioExists(string portfolioID)
      {
        foreach (Portfolio portfolio in _listPortfolios)
        {
          if (portfolio.PorfolioID == portfolioID)
            return true;
        }
        return false;
      }

      public Portfolio GetByPortfolioID(string porftolioID)
      {
        foreach (Portfolio porfolio in _listPortfolios)
          if (porfolio.PorfolioID == porftolioID)
            return porfolio;
        throw new StockExchangeException("Portfolio doesn't exists");
      }

      public void Clear()
      {
        _listPortfolios.Clear();
      }


      internal int Count()
      {
        return _listPortfolios.Count();
      }
    }

    /// <summary>
    /// Stock Exchange implementation
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private TradingData _tradingData;
        private StockRepository _stockRep;
        private IndexRepository _indexRep;
        private PortfolioRepository _portfolioRep;

        public StockExchange()
        {
          _stockRep = StockRepository.GetInstance();
          _stockRep.Clear();
          _indexRep = IndexRepository.GetInstance();
          _indexRep.Clear();
          _portfolioRep = PortfolioRepository.GetInstance();
          _portfolioRep.Clear();
          _tradingData = new TradingData();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
          Stock stock = new Stock(inStockName, inNumberOfShares);
          _stockRep.AddStock(stock);
          Transaction transaction = new Transaction(stock, inInitialPrice, inTimeStamp);
          _tradingData.AddTransaction(transaction);
        }

        public void DelistStock(string inStockName)
        {
          _stockRep.DelistStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
          return _stockRep.ContainsStockName(inStockName.ToUpper());          
        }

        public int NumberOfStocks()
        {
          return _stockRep.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
          if (!_stockRep.ContainsStockName(inStockName.ToUpper())) throw new StockExchangeException("Stock doesn't exist");
          Stock stock = _stockRep.GetByName(inStockName.ToUpper());

          Transaction transaction = new Transaction(stock, inStockValue, inIimeStamp);
          _tradingData.AddTransaction(transaction);          
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
          if (!_stockRep.ContainsStockName(inStockName.ToUpper())) throw new StockExchangeException("Stock doesn't exist");
          Stock stock = _stockRep.GetByName(inStockName.ToUpper());

          return _tradingData.GetPrice(stock, inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
          Stock stock = _stockRep.GetByName(inStockName);
          return _tradingData.GetInitalPrice(stock);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
          Stock stock = _stockRep.GetByName(inStockName);
          return _tradingData.GetLastPrice(stock);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
          Index index = new Index(inIndexName, inIndexType);
          _indexRep.AddIndex(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
          Index index = _indexRep.GetByName(inIndexName);
          Stock stock = _stockRep.GetByName(inStockName);

          index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
          Index index = _indexRep.GetByName(inIndexName);
          index.RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
          Index index = _indexRep.GetByName(inIndexName);
          Stock stock = _stockRep.GetByName(inStockName);

          return index.HasStock(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
          Index index = _indexRep.GetByName(inIndexName);
          decimal value = 0;
          decimal sum = 0;
          decimal weightedSum = 0;
          decimal totalValue = 0;
          decimal factor;
          Stock stock;

          foreach (string stockName in index.Stocks().Keys)
          {
            stock = _stockRep.GetByName(stockName);
            sum += _tradingData.GetLastPrice(stock);
            totalValue += _tradingData.GetLastPrice(stock) * stock.NumberShares;
          }  
          value = sum / index.Count();
          if (index.Type == IndexTypes.WEIGHTED)
          {
            foreach (string stockName in index.Stocks().Keys)
            {
              stock = _stockRep.GetByName(stockName);
              factor = _tradingData.GetLastPrice(stock) * stock.NumberShares / totalValue;
              weightedSum += factor * _tradingData.GetLastPrice(stock);
              value = weightedSum;
          }
        }
          return Decimal.Round(value, 3);
        }

        public bool IndexExists(string inIndexName)
        {
          return _indexRep.ContainsIndexName(inIndexName);
        }

        public int NumberOfIndices()
        {
          return _indexRep.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
          Index index = _indexRep.GetByName(inIndexName);
          return index.Count();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
          _portfolioRep.CreatePortfolio(inPortfolioID);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          portfolio.AddStocks(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          portfolio.RemoveStocks(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          portfolio.RemoveStocks(inStockName);
        }

        public int NumberOfPortfolios()
        {
          return _portfolioRep.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          return portfolio.CountStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
          return _portfolioRep.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          return portfolio.StockExists(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          return portfolio.NumberOfShares(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          decimal value = 0;
          
          foreach (string stockName in portfolio.Stocks().Keys)
          {
            Stock stock = _stockRep.GetByName(stockName);
            value += _tradingData.GetPrice(stock, timeStamp) * portfolio.Stocks()[stockName];
          }
          return value;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
          decimal portfolioChange = 0;
          Portfolio portfolio = _portfolioRep.GetByPortfolioID(inPortfolioID);
          DateTime monthStart = new DateTime(Year, Month, 1, 0, 0, 0, 0);
          int daysInMonth = DateTime.DaysInMonth(Year, Month);
          DateTime monthEnd = new DateTime(Year, Month, daysInMonth, 23, 59, 59, 999);
          decimal startValue = this.GetPortfolioValue(inPortfolioID, monthStart);
          decimal endValue = this.GetPortfolioValue(inPortfolioID, monthEnd);
          portfolioChange = Decimal.Round((endValue / startValue) * 100, 3);
          return portfolioChange;
        }
    }
}
