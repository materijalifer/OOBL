﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        Ekran ekran = new Ekran();
        Tipka tipka = new Tipka();


        public void Press(char inPressedDigit)
        {
            tipka.setTipka(inPressedDigit, ekran);
        }

        public string GetCurrentDisplayState()
        {
            return ekran.getResult();
        }
    }

    public class Tipka
    {

        Ekran ekran;

        public void setTipka(char pressedButton, Ekran ekran)
        {
            this.ekran = ekran;

            if (Char.IsNumber(pressedButton))
            {
                //ukoliko se pritisne 0 a 0 je već na ekranu onda se ne dodaju 0!, tj. ništa se ne dogodi!
                if (ekran.getResult() == "0" && pressedButton == '0')
                {

                }
                else
                {
                    ekran.setResult(pressedButton);
                }
            }
            else if (pressedButton == ',')
            {
                if (!ekran.getResult().Contains(','))
                {
                    ekran.setResult(pressedButton);
                }
            }
            else
            {

                ekran.cutZeroDecimals();
                //MINUS - promjeni predznak
                if (pressedButton == 'M')
                {
                    ekran.promjenaPredznaka();
                }

                //ON/OFF - resetiranje kalkulatora
                if (pressedButton == 'O')
                {
                    ekran.resetiranjeKalkulatora();
                }

                //PUT - spremanje broja u memoriju
                if (pressedButton == 'P')
                {
                    ekran.spremiUMemoriju();
                }
                if (pressedButton == 'G')
                {
                    ekran.vratiIzMemorije();
                }

                //SINUS - računanje sinusa od trenutnog broja
                if (pressedButton == 'S')
                {
                    ekran.sinus();
                }

                if (pressedButton == '+')
                {
                    ekran.zbroji();
                }

                //ODUZIMANJE
                if (pressedButton == '-')
                {
                    ekran.oduzmi();
                }
                if (pressedButton == '=')
                {
                    ekran.izracunaj();
                }

                if (pressedButton == '*')
                {
                    ekran.mnozi();
                }

                //QUADRAT - kvadriranje trenutnog broja
                if (pressedButton == 'Q')
                {
                    ekran.kvadriraj();
                }

                if (pressedButton == 'I')
                {
                    ekran.inverz();
                }

                //CLEAR - brisanje ekrana
                if (pressedButton == 'C')
                {
                    ekran.ocisti();
                }

                if (pressedButton == 'K')
                {
                    ekran.kosinus();
                }

                if (pressedButton == 'T')
                {
                    ekran.tangens();
                }

                //SQUARE ROOT - korijenovanje broja
                if (pressedButton == 'R')
                {
                    ekran.korijenuj();
                }

                if (pressedButton == '/')
                {
                    ekran.dijeli();
                }


            }

            ekran.setProsliZnak(pressedButton);
        }

    }

    public class Ekran
    {

        const int MAX_DIGITS = 10;
        const int MAX_DECIMAL = 2;


        string firstNumber = "";
        string secondNumber = "";

        string result;

        char znak = '#';
        char prosliZnak = '#';

        string memorija;

        Operacije operacije = new Operacije();

        public Ekran()
        {
            this.result = "0";
        }

        public string getResult()
        {
            
            return result;
        }

        public void setProsliZnak(char prosliZnak)
        {
            this.prosliZnak = prosliZnak;
        }

        /// <summary>
        /// Metoda koja sprema broj na ekran
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public string setResult(char num)
        {
            checkForBinaryOperations();
            var builder = new StringBuilder();
            builder.Append(num);
            if (result == "0" && Char.IsNumber(num))
            {
                result = "";
            }
            if (Char.IsNumber(num))
            {
                if (checkNumberOfDigits(result) < 10)
                {
                    result = result + builder;
                }
            }
            else
            {
                result = result + builder;
            }
            return result;
        }


        private void checkForBinaryOperations()
        {
            if (prosliZnak == '+' || prosliZnak == '-' || prosliZnak == '*' || prosliZnak == '\\' || prosliZnak == 'I')
            {
                result = "0";
            }
        }

        private bool checkForUnaryOperations()
        {
            if (prosliZnak == 'Q' || prosliZnak == 'R' || prosliZnak == 'T' || prosliZnak == 'S' || prosliZnak == 'K'
                || prosliZnak == 'I' || prosliZnak == 'P' || prosliZnak == 'O' || prosliZnak == 'G' || prosliZnak == 'C' ||
                prosliZnak == 'M' || prosliZnak == ',')
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Metoda koja provjerava broj znamenki na ekranu.
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        private int checkNumberOfDigits(string res)
        {
            int counter = 0;
            for (int i = 0; i < res.Length; i++)
            {
                char c = res[i];
                if (Char.IsNumber(c))
                {
                    counter++;
                }
            }
            return counter;
        }


        public void promjenaPredznaka()
        {
            if(result.Contains('-'))
            {
                result = result.Remove(0, 1);
            }
            else{
                this.result = "-" + result;
            }
        }

        public void resetiranjeKalkulatora()
        {
            this.result = "0";
            this.znak = '#';
            this.firstNumber = "";
            this.secondNumber = "";
            this.prosliZnak = '#';
            this.memorija = "";
        }

        public void spremiUMemoriju()
        {
            memorija = result;
        }

        public void vratiIzMemorije()
        {
            result = memorija;
        }

        public void sinus()
        {
            double broj = Convert.ToDouble(result);
            broj = operacije.calculateSin(broj);
            result = broj.ToString();
        }

        public void kosinus()
        {
            double broj = Convert.ToDouble(result);
            broj = operacije.calculateCos(broj);
            result = broj.ToString();
        }

        public void tangens()
        {
            double broj = Convert.ToDouble(result);
            broj = operacije.calculateTan(broj);
            result = broj.ToString();
        }

        private void spremiPrviBroj()
        {
            firstNumber = result;

        }

        public void oduzmi()
        {
            if (result != "0" && firstNumber != "" && znak != '#' && (Char.IsNumber(prosliZnak) || checkForUnaryOperations()))
            {
                izracunaj();
            }
            spremiPrviBroj();
            znak = '-';
        }

        public void zbroji()
        {
            if (result != "0" && firstNumber != "" && znak != '#' && (Char.IsNumber(prosliZnak) || checkForUnaryOperations()))
            {
                izracunaj();
            }
            spremiPrviBroj();
            znak = '+';
        }

        public void mnozi()
        {
            if (result != "0" && firstNumber != "" && znak != '#' && (Char.IsNumber(prosliZnak) || checkForUnaryOperations()))
            {
                izracunaj();
            }
            spremiPrviBroj();
            znak = '*';
        }

        public void dijeli()
        {
            if (result != "0" && firstNumber != "" && znak != '#' && (Char.IsNumber(prosliZnak) || checkForUnaryOperations()))
            {
                izracunaj();
            }
            spremiPrviBroj();
            znak = '/';
        }

        public void kvadriraj()
        {
            double broj = Convert.ToDouble(result);
            broj = operacije.calculateQuadrat(broj);
            if (checkIntegerNumbers(broj.ToString()) < 10)
            {
                result = broj.ToString();
            }
            else
            {
                result = "-E-";
            }
        }

        public void korijenuj()
        {
            double broj = Convert.ToDouble(result);
            broj = operacije.calculteSquareRoot(broj);
            if (checkIntegerNumbers(broj.ToString()) < 10)
            {
                result = broj.ToString();
            }
            else
            {
                result = "-E-";
            }
        }

        public void inverz()
        {
            double broj = Convert.ToDouble(result);
            if (broj == 0)
            {
                result = "-E-";
            }
            else
            {
                broj = operacije.calculateInvers(broj);
                result = broj.ToString();
            }

        }




        public void izracunaj()
        {

            if (znak == '-')
            {
                if (Char.IsNumber(prosliZnak) || checkForUnaryOperations())
                {
                    secondNumber = result;
                }

                else if (prosliZnak == '-')
                {
                    secondNumber = firstNumber;
                }
                else
                {
                    return;
                }


                double num1 = Convert.ToDouble(firstNumber);
                double num2 = Convert.ToDouble(secondNumber);
                double res = operacije.calculateSubtract(num1, num2);
                result = res.ToString();
                znak = '#';
                firstNumber = "";
                secondNumber = "";
            }

            if (znak == '+')
            {
                if (Char.IsNumber(prosliZnak) || checkForUnaryOperations())
                {
                    secondNumber = result;
                }

                else if (prosliZnak == '+')
                {
                    secondNumber = firstNumber;
                }
                else
                {
                    return;
                }


                double num1 = Convert.ToDouble(firstNumber);
                double num2 = Convert.ToDouble(secondNumber);
                double res = operacije.calculateAddition(num1, num2);
                result = res.ToString();
                znak = '#';
                firstNumber = "";
                secondNumber = "";
            }

            if (znak == '*')
            {
                if (Char.IsNumber(prosliZnak) || checkForUnaryOperations())
                {
                    secondNumber = result;
                }

                else if (prosliZnak == '*')
                {
                    secondNumber = firstNumber;
                }
                else
                {
                    return;
                }


                double num1 = Convert.ToDouble(firstNumber);
                double num2 = Convert.ToDouble(secondNumber);
                double res = operacije.calculteMultiplication(num1, num2);
                int num = checkIntegerNumbers(res.ToString());
                if (num < 10)
                {
                    result = res.ToString();
                }
                else
                {
                    result = "-E-";
                }
                znak = '#';
                firstNumber = "";
                secondNumber = "";
            }
            if (znak == '/')
            {
                if (Char.IsNumber(prosliZnak) || checkForUnaryOperations())
                {
                    secondNumber = result;
                }

                else if (prosliZnak == '/')
                {
                    secondNumber = firstNumber;
                }
                else
                {
                    return;
                }


                double num1 = Convert.ToDouble(firstNumber);
                double num2 = Convert.ToDouble(secondNumber);
                if (num2 == 0)
                {
                    result = "-E-";
                    znak = '#';
                    firstNumber = "";
                    secondNumber = "";
                    return;
                }

                double res = operacije.calculteFraction(num1, num2);
                int num = checkIntegerNumbers(res.ToString());
                if (num < 10)
                {
                    result = res.ToString();
                }
                else
                {
                    result = "-E-";
                }
                znak = '#';
                firstNumber = "";
                secondNumber = "";
            }

        }


        private int checkIntegerNumbers(string res)
        {
            int counter = 0;
            for (int i = 0; i < res.Length; i++)
            {
                char c = res[i];
                if (c != ',')
                {
                    if (Char.IsNumber(c))
                    {
                        counter++;
                    }
                }
                else
                {
                    return counter;
                }
            }
            return counter;
        }


        public void ocisti()
        {
            result = "0";
        }


        /// <summary>
        /// Metoda koja uklanja nepotrebne nule u decimalnom prostoru.
        /// </summary>
        public void cutZeroDecimals()
        {
            result = Double.Parse(result).ToString();

        }




    }


    public class Operacije
    {

        public double calculateSin(double num)
        {
            double res = Math.Sin(num);
            return Math.Round(res, 9);
        }

        public double calculateCos(double num)
        {
            double res = Math.Cos(num);
            return Math.Round(res, 9);
        }

        public double calculateTan(double num)
        {
            double res = Math.Tan(num);
            return Math.Round(res, 9);
        }

        public double calculateSubtract(double num1, double num2)
        {
            double res = num1 - num2;
            return res;
        }

        public double calculateAddition(double num1, double num2)
        {
            double res = num1 + num2;
            return res;
        }

        public double calculteMultiplication(double num1, double num2)
        {
            double res = num1 * num2;
            return Math.Round(res, 9);
        }

        public double calculteFraction(double num1, double num2)
        {
            double res = num1 / num2;
            return Math.Round(res, 9);
        }

        public double calculteSquareRoot(double num)
        {
            double res = Math.Sqrt(num);
            return Math.Round(res, 9);
        }

        public double calculateQuadrat(double num)
        {
            double res = Math.Pow(num, 2);
            return Math.Round(res, 9);
        }

        public double calculateInvers(double num)
        {
            double res = 1 / num;
            return Math.Round(res, 9);
        }

    }


}
