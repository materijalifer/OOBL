﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string Display = "0";
        private string Error = "-E-";

        private Operation currentOp = Operation.None;
        private Operation lastOp = Operation.None;
        private Number memory;
        private Number active;

        private List<Number> operands;

        private bool switchOperands = false;
        private bool unarni = false;
        private bool error = false;

        private enum Operation
        {
            None,
            Add,
            Substract,
            Multiply,
            Divide,
        }

        public Kalkulator()
        {
            this.operands = new List<Number>();
            this.active = new Number();
        }

        public void Press(char inPressedDigit)
        {
            Check(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return this.Display;
        }

        private void Check(char sign)
        {
            if (this.Display == this.Error) Reset();

            if (sign >= '0' && sign <= '9')
            {
                if (this.switchOperands || this.unarni)
                {
                    this.active.Reset();
                    this.switchOperands = false;
                    this.unarni = false;
                    this.operands.Add(this.active);
                }

                this.active.Add(sign);
                this.RefreshDisplay(this.active.ToString());
            }
            else
            {
                switch (sign)
                {
                    case '+':
                        {
                            this.currentOp  = Operation.Add;
                            AddOperand();
                            break;
                        }
                    case '-':
                        {
                            this.currentOp = Operation.Substract;
                            AddOperand();
                            break;
                        }
                    case '*':
                        {
                            this.currentOp  = Operation.Multiply;
                            AddOperand();
                            break;
                        }
                    case '/':
                        {
                            this.currentOp = Operation.Divide;
                            AddOperand();
                            break;
                        }
                    case '=':
                        {
                            this.switchOperands = true;
                            Result(this.currentOp);
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case ',':
                        {
                            //decimal
                            this.active.MakeDecimal();
                            RefreshDisplay(this.active.ToString());
                            break;

                        }
                    case 'M':
                        {
                            //mjenjaj predznak
                            this.active.M();
                            RefreshDisplay(this.active.ToString());
                            break;

                        }
                    case 'I':
                        {
                            //inverz
                            if (this.active.I())
                            {
                                this.unarni = true;
                                RefreshDisplay(this.active.ToString());
                            }
                            else
                            {
                                RefreshDisplay(this.Error);
                                //Reset();
                            }
                            break;
                        }
                    case 'Q':
                        {
                            //kvadrat
                            this.active.Q();
                            this.unarni = true;
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'R':
                        {
                            //korijen
                            if (this.active.R())
                            {
                                this.unarni = true;
                                RefreshDisplay(this.active.ToString());
                            }
                            else
                            {
                                RefreshDisplay(this.Error);
                                //Reset();
                            }
                            break;
                        }
                    case 'S':
                        {
                            //sinus
                            this.active.S();
                            this.unarni = true;
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'K':
                        {
                            //kosinus
                            this.active.K();
                            this.unarni = true;
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'T':
                        {
                            //tangens
                            this.active.T();
                            this.unarni = true;
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'P':
                        {
                            //spremi u memoriju
                            this.memory = this.active.Copy();
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'G':
                        {
                            //uzmi iz memorije
                            if (this.memory != null)
                            {
                                this.active = this.memory.Copy();
                                RefreshDisplay(this.active.ToString());
                            }
                            else
                            {
                                this.error = true;
                                RefreshDisplay(this.Error);
                            }
                            break;
                        }
                    case 'C':
                        {
                            //ocisti ekran
                            this.active.Reset();
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                    case 'O':
                        {
                            //iskljuci ukljuci kalkulator
                            Reset();
                            RefreshDisplay(this.active.ToString());
                            break;
                        }
                }
            }
        }

        private void AddOperand()
        {
            if (this.switchOperands)
            {
                if (this.operands.Count == 2)
                {
                    this.operands.RemoveAt(1);
                }
            }

            if (this.operands.Count == 2)
            {
                Result(this.lastOp);

                this.switchOperands = true;

                if (this.operands.Count == 2)
                {
                    this.operands.RemoveAt(1);
                }
            }

            this.lastOp = this.currentOp;

            if (!this.switchOperands)
            {
                this.operands.Add(this.active.Copy());
                this.switchOperands = true;
            }
        }

        private void Reset()
        {
            this.Display = "0"; ;

            this.currentOp = Operation.None;
            this.lastOp = Operation.None;
            this.memory = null;

            this.operands.Clear();

            this.active.Reset();

            this.switchOperands = false;
            this.unarni = false;
            this.error = false;
        }

        private void RefreshDisplay(string number)
        {
            if (number == this.Error || this.error)
            {
                this.error = false;
                this.Display = Error;
            }

            if (number.Contains('.') && number.Contains('-'))
            {
                if (CheckTrailingZero(double.Parse(number, CultureInfo.InvariantCulture))) number.Remove(number.IndexOf('.'));

                if (number.Length > 12)
                {
                    int index = number.IndexOf('.');
                    number = Math.Round(double.Parse(number, CultureInfo.InvariantCulture), (11 - index)).ToString();

                }

                this.Display = number.Replace('.', ',');
                return;
            }

            if (number.Contains('.'))
            {
                if (CheckTrailingZero(double.Parse(number, CultureInfo.InvariantCulture))) number = number.Remove(number.IndexOf('.'));

                if (number.Length > 11)
                {
                    int index = number.IndexOf('.');
                    number = Math.Round(double.Parse(number, CultureInfo.InvariantCulture), (10 - index)).ToString();
                }

                this.Display = number.Replace('.', ',');
                return;
            }

            if (number.Contains('-'))
            {
                if (number.Length > 11)
                {
                    this.Display = this.Error;
                }
                else
                {
                    this.Display = number;
                }
                return;
            }

            if (number.Length > 10)
            {
                this.Display = this.Error;
                return;
            }
            else
            {
                this.Display = number;
            }
        }

        private bool CheckTrailingZero(double number)
        {
            if (number % 1 == 0)
            {
                return true;
            }

            return false;
        }

        private void Result(Operation operation)
        {
            if (this.operands.Count == 1)
            {
                this.operands.Add(this.operands[0].Copy());
            }

            if(this.operands.Count == 2)
            {
                this.operands[0].GetNumber = Calculate(this.operands[0].GetNumber, this.operands[1].GetNumber, operation);
            }
            if (this.operands.Count >= 1)
            {
                this.active = this.operands[0].Copy();
            }


        }

        private double Calculate(double first, double second, Operation op)
        {
            switch (op)
            {
                case Operation.Add:
                    {
                        return (first + second);
                    }
                case Operation.Substract:
                    {
                        return (first - second);
                    }
                case Operation.Multiply:
                    {
                        return (first * second);
                    }
                case Operation.Divide:
                    {
                        if (first != 0.0 && second != 0.0)
                        {
                            return (first / second);
                        }
                        else
                        {
                            this.error = true;
                            return 0;
                        }
                    }
                default:
                    {
                        return 0;
                    }
            }
        }

        private double Calculate(double first, Operation op)
        {
            switch (op)
            {
                case Operation.Add:
                    {
                        return (first * 2);
                    }
                case Operation.Substract:
                    {
                        return 0;
                    }
                case Operation.Multiply:
                    {
                        return (first * first);
                    }
                case Operation.Divide:
                    {
                        if (first != 0.0)
                        {
                            return 1;
                        }
                        else
                        {
                            this.error = true;
                            return 0;
                        }
                    }
                default:
                    {
                        return 0;
                    }
            }
        }
    }

    public class Number
    {
        private bool isDecimal = false;
        private bool isNegative = false;
        private bool isDisabled = false; // don't allow adding any more digits
        private string _number = "0";
        private double number = 0;
        private int numberOfDigits = 0;

        public Number()
        {
        }

        public Number(bool dec, bool negative, string snumber, double dnumber, int numberofdigits)
        {
            this.isNegative = negative;
            this.isDecimal = dec;
            this._number = snumber;
            this.number = dnumber;
            this.numberOfDigits = numberofdigits;
        }

        public void Add(char number)
        {
            if (!this.isDisabled)
            {
                if (this.numberOfDigits == 0)
                {
                    if (number != '0')
                    {
                        this._number = number.ToString();
                        this.numberOfDigits++;
                    }
                }
                else
                {
                    this._number += number;
                    this.numberOfDigits++;
                }

                //if (this.numberOfDigits >= 10) this.isDisabled = true;

                Refresh();
            }
        }

        private void Refresh()
        {
            this.number = double.Parse(this._number, CultureInfo.InvariantCulture);
        }

        public void M()
        {
            this.number = this.number * -1.0;
            this._number = this.number.ToString().Replace(',', '.');
            if (this.isNegative)
            {
                this.isNegative = false;
            }
            else
            {
                this.isNegative = true;
            }
        }

        public bool I()
        {
            if (this.number == 0.0)
            {
                return false;
            }
            else
            {
                this.number = 1 / this.number;
                this.isDisabled = true;
                return true;
            }
        }

        public void MakeDecimal()
        {
            if (!this.isDecimal)
            {
                this._number = this._number + '.';
                this.isDecimal = true;
                if (this.numberOfDigits == 0) this.numberOfDigits++;
                Refresh();
            }
        }

        public void Q()
        {
            this.number = Math.Pow(this.number, 2.0);
            this.isDisabled = true;
        }

        public bool R()
        {
            if (this.isNegative)
            {
                return false;
            }
            else
            {
                this.number = Math.Pow(this.number, 0.5);
                this.isDisabled = true;
                return true;
            }
        }

        public void S()
        {
            this.number = Math.Sin(this.number);
            this.isDisabled = true;
        }

        public void K()
        {
            this.number = Math.Cos(this.number);
            this.isDisabled = true;
        }

        public void T()
        {
            this.number = Math.Tan(this.number);
            this.isDisabled = true;
        }

        public void Reset()
        {
            this.isDecimal = false;
            this.isNegative = false;
            this.isDisabled = false;

            this.number = 0;
            this._number = "0";
            this.numberOfDigits = 0;
        }

        public bool Disabled
        {
            get { return this.isDisabled; }
        }

        public bool Negative
        {
            get { return this.isNegative; }
        }

        public bool Decimal
        {
            get { return this.isDecimal; }
        }

        public double GetNumber
        {
            get { return this.number; }
            set { this.number = value; 
                this.isDisabled = true;
                this._number = this.number.ToString().Replace(',', '.');
            }
        }

        public Number Copy()
        {
            return new Number(this.isDecimal, this.isNegative, this._number, this.number, this.numberOfDigits);
        }

        public override string ToString()
        {
            return this.number.ToString().Replace(',', '.');
        }
    }

}
