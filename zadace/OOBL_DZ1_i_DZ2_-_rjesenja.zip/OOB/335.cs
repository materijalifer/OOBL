﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public class StockExchange : IStockExchange
    {
        private Functions _functions;

        public StockExchange()
        {
            _functions = new Functions();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _functions.AddStock(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            throw new NotImplementedException();
        }

        public bool StockExists(string inStockName)
        {
            return _functions.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return _functions.NumberOfStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            throw new NotImplementedException();
            
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            throw new NotImplementedException();
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            throw new NotImplementedException();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            throw new NotImplementedException();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _functions.AddIndex(new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock fetchedStock = _functions.FetchStock(inStockName);
            Index fetchedIndex = _functions.FetchIndex(inIndexName);
            _functions.AddStockToIndex(fetchedIndex.IndexName, fetchedStock.StockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock fetchedStock = _functions.FetchStock(inStockName);
            Index fetchedIndex = _functions.FetchIndex(inIndexName);
            _functions.RemoveStockFromIndex(fetchedIndex.IndexName, fetchedStock.StockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index fetchedIndex = _functions.FetchIndex(inIndexName);
            return _functions.IsStockPartOfIndex(fetchedIndex.IndexName, inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            throw new NotImplementedException();
        }

        public bool IndexExists(string inIndexName)
        {
            return _functions.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _functions.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index fetchedIndex = _functions.FetchIndex(inIndexName);
            return fetchedIndex.NumberOfStocksInIndex();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            _functions.AddPortfolio(new Portfolio(inPortfolioID));
        }

        //tu sam zapeo, trebalo bi sloziti da se dodaje objekt tipa stock u portfolio kod poziva funkcije...
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock fetchedStock = _functions.FetchStock(inStockName);
            Portfolio fetchedPortfolio = _functions.FetchPortfolio(inPortfolioID);
            _functions.AddStockToPortfolio(fetchedPortfolio.PortfolioID, fetchedStock.StockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            
            Stock requestedStock = _functions.FetchStock(inStockName);
            Portfolio fetchedPortfolio = _functions.FetchPortfolio(inPortfolioID);
            _functions.RemoveStockFromPortfolio(fetchedPortfolio.PortfolioID, requestedStock.StockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Stock requestedStock = _functions.FetchStock(inStockName);
            Portfolio fetchedPortfolio = _functions.FetchPortfolio(inPortfolioID);
            _functions.RemoveStockFromPortfolio(fetchedPortfolio.PortfolioID, requestedStock.StockName);
        }

        public int NumberOfPortfolios()
        {
            return _functions.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio fetchedPortfolio = _functions.FetchPortfolio(inPortfolioID);
            return fetchedPortfolio.NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _functions.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio fetchedPortfolio = _functions.FetchPortfolio(inPortfolioID);
            return _functions.IsStockPartOfPortfolio(fetchedPortfolio.PortfolioID, inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }

    }

    public class Stock
    {
        #region Private members
        private string stockName;
        private long numberOfShares;
        private Decimal initialPrize;
        DateTime timeStamp;
        #endregion

        
        public Stock(string stockName, long numberOfShares, Decimal initialPrize, DateTime timeStamp)
        {
            if (numberOfShares > 0 && initialPrize > 0)
            {
                this.stockName = stockName;
                this.numberOfShares = numberOfShares;
                this.initialPrize = initialPrize;
                this.timeStamp = timeStamp;
            }
            else
            {
                throw new StockExchangeException("Input data of a new stock is not correct - number of shares or price of stock is negative!");
            }
        }
      

        #region Properties
        public string StockName
        {
            get { return stockName; }
            set { stockName = value; }
        }
        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }
        public Decimal InitialPrize
        {
            get { return initialPrize; }
            set { initialPrize = value; }
        }
        public DateTime TimeStamp
        {
            get { return timeStamp; }
            set { timeStamp = value; }
        }
        #endregion
    }

    public class Index
    {
        #region Private members
        private string indexName;
        private IndexTypes indexType;
        private List<Stock> stocksInIndex;
        #endregion

        #region Constructors
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if (Enum.Equals(inIndexType, IndexTypes.AVERAGE) || Enum.Equals(inIndexType, IndexTypes.WEIGHTED))
            {
                this.indexName = inIndexName;
                this.indexType = inIndexType;
                this.stocksInIndex = new List<Stock>();
            }
            else
            {
                throw new StockExchangeException("Index type of a new index is not allowed!");
            }
        }
        #endregion

        #region Properties
        public string IndexName
        {
            get { return indexName; }
            set { indexName = value; }
        }
        public IndexTypes IndexType
        {
            get { return indexType; }
            set { indexType = value; }
        }
     
        #endregion

        public void AddStockToIndex(Stock inStock)
        {
                if (IsStockPartOfIndex(inStock.StockName))
                {
                    throw new StockExchangeException("Stock '" + inStock.StockName + "' already exists in index '"
                                                     + this.indexName + "'!");
                }
                else
                {
                    stocksInIndex.Add(inStock);
                }
        }
    
        public void RemoveStockFromIndex(string inStockName)
        {
            for (int i = 0; i < this.stocksInIndex.Count; i++)
            {
                if (this.stocksInIndex[i].StockName.Equals(inStockName))
                {
                    this.stocksInIndex.RemoveAt(i);
                    return;
                }
            }

            throw new StockExchangeException("Stock '" + inStockName + "' does not exist in index '"
                + this.indexName + "'!");
        }

        public int NumberOfStocksInIndex()
        {
            return this.stocksInIndex.Count;
        }

        public bool IsStockPartOfIndex(string inStockName)
       {
            foreach (Stock stock in this.stocksInIndex)
            {
                if (stock.StockName.Equals(inStockName))
                {
                    return true;
                }
            }

            return false;
        }
    }

    public class Portfolio
    {
        #region Private members
        private string portfolioID;
        private List<Stock> stocksInPortfolio;
        #endregion

        #region Constructors
        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
            this.stocksInPortfolio = new List<Stock>();
        }
        #endregion

        #region Properties
        public string PortfolioID
        {
            get { return portfolioID; }
            set { portfolioID = value; }
        }
        public List<Stock> StocksInPortfolio
        {
            get { return stocksInPortfolio; }
            set { stocksInPortfolio = value; }
        }
        #endregion

        // tu bi trebalo sloziti na nacin da dohvaca dionicu i onda bi dodali...treba neka kolekcija
        // koja bi spremala stocks i broj sharea...
        public void AddStockToPortfolio(string inStockName, int inNumberOfShares)
        {
            for (int i = 0; i < this.stocksInPortfolio.Count; i++)
            {
                if (this.stocksInPortfolio[i].StockName.Equals(inStockName))
                {
                    this.stocksInPortfolio[i].NumberOfShares += inNumberOfShares;
                }
                
            }
        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            for (int i = 0; i < this.stocksInPortfolio.Count; i++)
            {
                if (this.stocksInPortfolio[i].StockName.Equals(inStockName))
                {
                    this.stocksInPortfolio.RemoveAt(i);
                    return;
                }
            }

            throw new StockExchangeException("Stock '" + inStockName + "' does not exist in portfolio '"
                + this.portfolioID + "'!");
        }
        public void RemoveStockFromPortfolio(string inStockName, int inNumberOfShares)
        {
            for (int i = 0; i < this.StocksInPortfolio.Count; i++)
            {
                if (this.stocksInPortfolio[i].StockName.Equals(inStockName))
                {
                    if (this.stocksInPortfolio[i].NumberOfShares >= inNumberOfShares)
                    {
                        this.stocksInPortfolio[i].NumberOfShares -= inNumberOfShares;

                        if (this.stocksInPortfolio[i].NumberOfShares == 0)
                        {
                            this.stocksInPortfolio.RemoveAt(i);
                        }

                        return;
                    }
                    else
                    {
                        throw new StockExchangeException("Number of shares to be removed is to large!");
                    }
                }
            }

            throw new StockExchangeException("Stock '" + inStockName + "' does not exist in portfolio '"
                + this.portfolioID + "'!");
        }

        public int NumberOfStocksInPortfolio()
        {
            return this.StocksInPortfolio.Count;
        }

        public bool IsStockPartOfPortfolio(string inStockName)
        {
            foreach (Stock stock in this.stocksInPortfolio)
            {
                if (stock.StockName.Equals(inStockName))
                {
                    return true;
                }
            }

            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            foreach (Stock stock in this.stocksInPortfolio)
            {
                if (stock.StockName.Equals(inStockName))
                {
                    return (int)stock.NumberOfShares;
                }
            }

            throw new StockExchangeException("Stock '" + inStockName + "' does not exist in portfolio '"
                + this.portfolioID + "'!");
        }
    }

    public class Functions
    {
        private List<Stock> stocksOnStockExchange = new List<Stock>();
        private List<Index> indexesOnStockExchange = new List<Index>();
        private List<Portfolio> portfoliosOnStockExchange = new List<Portfolio>();

        #region STOCK

        public int NumberOfStocks()
        {
            return stocksOnStockExchange.Count;
        }

        public void AddStock(Stock stock)
        {
            if (StockExists(stock.StockName))
            {
                throw new StockExchangeException("Stock already exists!");
            }     
                stocksOnStockExchange.Add(stock);
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock stock in this.stocksOnStockExchange)
            {
                if (stock.StockName.Equals(inStockName))
                {
                    return true;
                }
            }

            return false;
        }

        public Stock FetchStock(string inStockName)
        {
            foreach (Stock stock in this.stocksOnStockExchange)
            {
                if (stock.StockName.Equals(inStockName))
                    return stock;

            }

            throw new StockExchangeException("Wanted stock does not exist");
        }
        // probati ovaj dio rijesiti...malo zeznutije...
       /* public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            Stock stock = this.FetchStock(inStockName);
        }*/

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            foreach (Index index in this.indexesOnStockExchange)
            {
                if (index.IndexName.Equals(inIndexName))
                {
                    return index.IsStockPartOfIndex(inStockName);
                }
            }

            throw new StockExchangeException("Index '" + inIndexName + "' does not exist on stock exchange!");
        }

        #endregion

        #region INDEX

        public int NumberOfIndices()
        {
            return indexesOnStockExchange.Count;
        }

        public void AddIndex(Index index)
        {
            if (IndexExists(index.IndexName))
            {
                throw new StockExchangeException("Index already exists!");
            }
                indexesOnStockExchange.Add(index);
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (Index index in this.indexesOnStockExchange)
            {
                if (index.IndexName.Equals(inIndexName))
                {
                    return true;
                }
            }

            return false;
        }

        public Index FetchIndex(string inIndexName)
        {
            foreach (Index index in this.indexesOnStockExchange)
            {
                if (index.IndexName.Equals(inIndexName))
                    return index;

            }

            throw new StockExchangeException("Wanted index does not exist");
        }
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            foreach (Index index in this.indexesOnStockExchange)
            {
                if (index.IndexName.Equals(inIndexName))
                {

                    foreach (Stock stock in this.stocksOnStockExchange)
                    {
                        if (stock.StockName.Equals(inStockName))
                        {
                            index.AddStockToIndex(stock);
                            return;
                        }
                    }
                }
            }

            throw new StockExchangeException("Index '" + inIndexName + "' does not exist on stock exchange!");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            foreach (Index index in this.indexesOnStockExchange)
            {
                if (index.IndexName.Equals(inIndexName))
                {
                    index.RemoveStockFromIndex(inStockName);
                    return;
                }
            }

            throw new StockExchangeException("Index '" + inIndexName + "' does not exist on stock exchange!");
        }

        #endregion

        #region PORTFOLIO

        public int NumberOfPortfolios()
        {
            return portfoliosOnStockExchange.Count;
        }

        public void AddPortfolio(Portfolio portfolio)
        {
            if (PortfolioExists(portfolio.PortfolioID))
            {
                throw new StockExchangeException("Portfolio already exists!");
            }    
            portfoliosOnStockExchange.Add(portfolio);        
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                {
                    return true;
                }
            }

            return false;
        }
        public  Portfolio FetchPortfolio(string inPortfolioID)
        {
           {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                    return portfolio;

            }

            throw new StockExchangeException("Wanted portfolio does not exist");
        }
        }
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                {
                    portfolio.AddStockToPortfolio(inStockName, numberOfShares);
                }
            }

            throw new StockExchangeException("Portfolio '" + inPortfolioID + "' does not exist on stock exchange!");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                {
                    portfolio.RemoveStockFromPortfolio(inStockName, numberOfShares);
                }
            }

            throw new StockExchangeException("Portfolio '" + inPortfolioID + "' does not exist on stock exchange!");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                {
                    portfolio.RemoveStockFromPortfolio(inStockName);
                }
            }

            throw new StockExchangeException("Portfolio '" + inPortfolioID + "' does not exist on stock exchange!");
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (Portfolio portfolio in this.portfoliosOnStockExchange)
            {
                if (portfolio.PortfolioID.Equals(inPortfolioID))
                {
                    return portfolio.IsStockPartOfPortfolio(inStockName);
                }
            }

            throw new StockExchangeException("Portfolio '" + inPortfolioID + "' does not exist on stock exchange!");
        }

        #endregion PORTFOLIO

    }

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

}
