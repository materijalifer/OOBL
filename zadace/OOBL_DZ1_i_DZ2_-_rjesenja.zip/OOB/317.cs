﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string Name;
        public long NumberOfStock;
        public long NumberOfStockLeft;
        public List<decimal> PriceList = new List<decimal>();
        public List<DateTime> DateList = new List<DateTime>();

        public Stock()
        {
            throw new StockExchangeException("Error creating stock! Missing arguments.");
        }

        public Stock(string stockName, long stockNumber, decimal stockPrice, DateTime stockInitialTime)
        {

            if ((stockPrice <= 0) || (stockNumber <= 0))
            {
                throw new StockExchangeException("Error creating stock! Stock price and number of stocks must be greater than 0!");
            }

            this.Name = stockName.ToLower();
            this.NumberOfStock = stockNumber;
            this.NumberOfStockLeft = stockNumber;
            this.PriceList.Add(stockPrice);
            this.DateList.Add(stockInitialTime);

        }

    }

    public class Index
    {
        public string Name;
        public IndexTypes Type;
        public List<Stock> Stocks = new List<Stock>();

        public Index()
        {
            throw new StockExchangeException("Error creating index! Missing arguments.");
        }

        public Index(string nameIndex, IndexTypes typeIndex)
        {
            this.Name = nameIndex.ToLower();
            if (typeIndex != IndexTypes.AVERAGE && typeIndex != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Error creating index! Incorrect type!"); 
            }
                
            this.Type = typeIndex;
        }

    }

    public class Portfolio
    {
        public string ID;
        public List<Stock> Stocks = new List<Stock>();
        public List<int> NumberOfStock = new List<int>();

        public Portfolio(string portfolioId)
        {
            this.ID = portfolioId;
        }
    }

    public class StockExchange : IStockExchange
    {

        public List<Stock> StockList = new List<Stock>();
        public List<Index> IndexList = new List<Index>();
        public List<Portfolio> PortfolioList = new List<Portfolio>();


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Error adding stock! Stock with that name already exists.");
            }
            
            StockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));

        }

        public void DelistStock(string inStockName)
        {
            inStockName = inStockName.ToLower();

            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Error deleting stock that don't exist!");
            }

            // provjera u kojim indeksima i portfeljima postoji pa izbrisat iz njih
            foreach (Index aIndex in IndexList)
            {
                if (IsStockPartOfIndex(aIndex.Name, inStockName))
                {
                    RemoveStockFromIndex(aIndex.Name, inStockName);
                }
            }

            foreach (Portfolio aPortfolio in PortfolioList)
            {
                if (IsStockPartOfPortfolio(aPortfolio.ID, inStockName))
                {
                    RemoveStockFromPortfolio(aPortfolio.ID, inStockName);
                }
            }

            StockList.Remove(StockList.Where(i => i.Name == inStockName).First());
        }

        public bool StockExists(string inStockName)
        {
            inStockName = inStockName.ToLower();
            
            if ( StockList.Find(i => i.Name == inStockName) != null)
                return true;

            return false;
        }

        public int NumberOfStocks()
        {
            return StockList.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName))
            {
                Stock tmp = StockList.Find(i => i.Name == inStockName.ToLower());

                if (tmp.DateList.Contains(inTimeStamp))
                {
                    throw new StockExchangeException("Error setting stock price! Time stamp collision!");
                }

                tmp.DateList.Add(inTimeStamp);
                tmp.PriceList.Add(inStockValue);
            }
            else
            {
                throw new StockExchangeException("Error setting stock price! Stock with that name don't exist.");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Error! Stock with that name don't exist.");
            }

            int idx;
            Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
            DateTime tmpTimeMax = tmpStock.DateList.Min();

            foreach (DateTime aTime in tmpStock.DateList)
            {
                if (DateTime.Compare(aTime, inTimeStamp) <= 0)
                {
                    if (tmpTimeMax < aTime)
                    {
                        tmpTimeMax = aTime;
                    }
                }
            }

            idx = tmpStock.DateList.IndexOf(tmpTimeMax);
            if (idx == -1)
            {
                throw new StockExchangeException("Error! No recorded price before that date.");
            }
            return tmpStock.PriceList[idx];

        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Error! Stock with that name don't exist.");
            }

            Stock tmp = StockList.Find(i => i.Name == inStockName.ToLower());
            int idx = tmp.DateList.IndexOf(tmp.DateList.Min());
            return tmp.PriceList[idx];

        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Error! Stock with that name don't exist.");
            }
            Stock tmp = StockList.Find(i => i.Name == inStockName.ToLower());
            int idx = tmp.DateList.IndexOf(tmp.DateList.Max());
            return tmp.PriceList[idx];

        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Error adding index! Index with that name already exists.");
            }

            IndexList.Add(new Index(inIndexName, inIndexType));

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                if (IsStockPartOfIndex(inIndexName, inStockName))
                {
                    throw new StockExchangeException("Error! Adding stock that already exist in index.");
                }

                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
                Index tmpIndex = IndexList.Find(i => i.Name == inIndexName.ToLower());
                    
                tmpIndex.Stocks.Add(tmpStock);
            }
            else
            {
                throw new StockExchangeException("Error! Stock or index don't exist.");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName) && IsStockPartOfIndex(inIndexName, inStockName))
            {
                Index tmpIndex = IndexList.Find(i => i.Name == inIndexName.ToLower());
                Stock tmpStock = tmpIndex.Stocks.Find(i => i.Name == inStockName.ToLower());
                tmpIndex.Stocks.Remove(tmpStock);
                //tmpIndex.Stocks.Remove(StockList.Find(i => i.Name == inStockName.ToLower()));
            }
            else
            {
                throw new StockExchangeException("Error! Stock or index don't exist.");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
                Index tmpIndex = IndexList.Find(i => i.Name == inIndexName.ToLower());

                if (tmpIndex.Stocks.Contains(tmpStock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            else
            {
                throw new StockExchangeException("Error! Stock or index don't exist.");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal indexValue = 0;
            
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Error! Index don't exist.");
            }

            inIndexName = inIndexName.ToLower();
            Index tmpIndex = IndexList.Find(i => i.Name == inIndexName);
            
            if (!tmpIndex.Stocks.Any())
            {
                return 0;
            }
            if (tmpIndex.Stocks.Count() == 1)
            {
                return GetStockPrice(tmpIndex.Stocks.First().Name, inTimeStamp);
            }

            Stock tmpStock;

            if (tmpIndex.Type != IndexTypes.AVERAGE && tmpIndex.Type != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Error! Incorrect type of index.");
            }

            if (tmpIndex.Type == IndexTypes.AVERAGE)
            {
                for (int i = 0; i < tmpIndex.Stocks.Count(); i++)
                {
                    tmpStock = tmpIndex.Stocks[i];
                    indexValue += Math.Round(GetStockPrice(tmpStock.Name, inTimeStamp), 3);
                }
                indexValue /= tmpIndex.Stocks.Count();
            }

            if (tmpIndex.Type == IndexTypes.WEIGHTED)
            {
                decimal totalValue = 0;
                decimal weightFactor = 0;

                for (int i = 0; i < tmpIndex.Stocks.Count(); i++)
                {
                    tmpStock = tmpIndex.Stocks[i];
                    totalValue += Math.Round(tmpStock.NumberOfStock * GetStockPrice(tmpStock.Name, inTimeStamp), 3);
                }

                for (int i = 0; i < tmpIndex.Stocks.Count(); i++)
                {
                    tmpStock = tmpIndex.Stocks[i];
                    weightFactor = Math.Round((GetStockPrice(tmpStock.Name, inTimeStamp) / totalValue), 3); 

                    indexValue += Math.Round(tmpStock.NumberOfStock * GetStockPrice(tmpStock.Name, inTimeStamp) * weightFactor, 3);
                }
            }

            return indexValue;
        }

        public bool IndexExists(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            if (IndexList.Find(i => i.Name == inIndexName) != null)
                return true;

            return false;
        }

        public int NumberOfIndices()
        {
            return IndexList.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();

            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Error! Index don't exist.");
            }

            Index tmpIndex = IndexList.Find(i => i.Name == inIndexName);

            return tmpIndex.Stocks.Count();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Error creating portfolio! Portfolio with that ID already exists.");

            PortfolioList.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());

                // provjeri ako ima toliko dionica za dodat na portfelj
                if (tmpStock.NumberOfStockLeft == 0 || tmpStock.NumberOfStockLeft < numberOfShares)
                {
                    throw new StockExchangeException("Error! Not enough shares on stock!");
                }

                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    int idx = tmpPortfolio.Stocks.IndexOf(tmpStock);
                    tmpPortfolio.NumberOfStock[idx] += numberOfShares;
                    tmpStock.NumberOfStockLeft -= numberOfShares;
                }
                else
                {
                    tmpPortfolio.Stocks.Add(tmpStock);
                    tmpPortfolio.NumberOfStock.Add(numberOfShares);
                    tmpStock.NumberOfStockLeft -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Error! Stock or portfolio don't exist.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName) && IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
                
                int idx = tmpPortfolio.Stocks.IndexOf(tmpStock);
                // pokusaj oduzimanja vise udjela dionica nego sto ima u portfoliou
                if (numberOfShares > tmpPortfolio.NumberOfStock[idx])
                {
                    throw new StockExchangeException("Error! Not enough shares in portfolio!");
                }
                else
                {
                    tmpPortfolio.NumberOfStock[idx] -= numberOfShares;
                    tmpStock.NumberOfStockLeft += numberOfShares;
                }
                if (tmpPortfolio.NumberOfStock[idx] <= 0)
                {
                    tmpPortfolio.NumberOfStock.Remove(tmpPortfolio.NumberOfStock[idx]);
                    tmpPortfolio.Stocks.Remove(tmpStock);
                }
            }
            else
            {
                throw new StockExchangeException("Error! Stock or portfolio don't exist.");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName) && IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());

                int idx = tmpPortfolio.Stocks.IndexOf(tmpStock);

                tmpStock.NumberOfStockLeft = tmpStock.NumberOfStock;
                tmpPortfolio.Stocks.Remove(tmpStock);
                tmpPortfolio.NumberOfStock.Remove(tmpPortfolio.NumberOfStock[idx]);

            }
            else
            {
                throw new StockExchangeException("Error! Stock or portfolio don't exist.");
            }
        }

        public int NumberOfPortfolios()
        {
            return PortfolioList.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Error! Portfolio don't exist.");
            }

            return PortfolioList.Find(i => i.ID == inPortfolioID).Stocks.Count();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (PortfolioList.Find(i => i.ID == inPortfolioID) != null)
                return true;

            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
                Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);

                if (tmpPortfolio.Stocks.Contains(tmpStock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                Stock tmpStock = StockList.Find(i => i.Name == inStockName.ToLower());
                Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);

                int idx = tmpPortfolio.Stocks.IndexOf(tmpStock);

                return tmpPortfolio.NumberOfStock[idx];
            }
            else
            {
                throw new StockExchangeException("Error! Stock or portfolio don't exist.");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal portfolioValue = 0;

            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Error! Portfolio don't exist.");
            }

            Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);

            for (int i = 0; i < NumberOfStocksInPortfolio(inPortfolioID); i++)
            {
                portfolioValue += tmpPortfolio.NumberOfStock[i] * GetStockPrice(tmpPortfolio.Stocks[i].Name, timeStamp);
            }

            portfolioValue = Math.Round(portfolioValue, 3);
            return portfolioValue;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal startValue = 0;
            decimal endValue = 0;
            decimal percentage = 0;

            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Error! Portfolio don't exist.");
            }

            Portfolio tmpPortfolio = PortfolioList.Find(i => i.ID == inPortfolioID);

            if (!tmpPortfolio.Stocks.Any())
            {
                return 0;
            }

            // vrijednost na pocetku
            //for (int i = 0; i < NumberOfStocksInPortfolio(inPortfolioID); i++)
            //{
            //    startValue += GetStockPrice(tmpPortfolio.Stocks[i].Name, new DateTime(Year, Month, 0, 0, 0, 0, 0))*
            //                  tmpPortfolio.NumberOfStock[i];
            //}

            // vrijednost na kraju
            //for (int i = 0; i < NumberOfStocksInPortfolio(inPortfolioID); i++)
            //{
            //    endValue += GetStockPrice(tmpPortfolio.Stocks[i].Name, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59 ,999)) *
            //                  tmpPortfolio.NumberOfStock[i];
            //}

            List<int> index = new List<int>();
            Stock tmpStock; 
            for (int i = 0; i < tmpPortfolio.Stocks.Count(); i++)
            {
                tmpStock = tmpPortfolio.Stocks[i];
                // prvi dan u mjesecu
                if (tmpStock.DateList.Contains(new DateTime(Year, Month, 1, 00, 00, 00, 000)))
                {
                    // zadnji dan u mjesecu
                    if (tmpStock.DateList.Contains(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59 ,999)))
                    {
                        index.Add(i);
                    }
                }
            }

            // lista index sadrzi sve indekse dionica unutar portfelja koje imaju definiranu 
            // cijenu u prvom (00:00:00) i zadnjem danu u mjesecu (23:59:59:999)
            // svi ostali indeksi dionica su izbaceni unutar gornje for petlje if uvjetima

            if (!index.Any())
            {
                return 0;
            }

            for (int i = 0; i < index.Count(); i++ )
            {
                startValue += GetStockPrice(tmpPortfolio.Stocks[index[i]].Name, new DateTime(Year, Month, 1, 0, 0, 0, 0)) * tmpPortfolio.NumberOfStock[index[i]];
                endValue += GetStockPrice(tmpPortfolio.Stocks[index[i]].Name, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) * tmpPortfolio.NumberOfStock[index[i]];
            }
            
            percentage = 100 * ((Math.Round(endValue, 3) - Math.Round(startValue, 3)) / (Math.Round(startValue, 3)));
            percentage = Math.Round(percentage, 3);

            return percentage;
        }
    }
}
