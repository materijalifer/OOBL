﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Calculator : ICalculator
	{
		public static readonly int SizeOfDisplay = 10;
		private readonly static int numberOfRegisters = 2;

		private List<NumberRepresentation> registers;
		private int activeRegisterNumber = 0;

		private IBinaryOperator currentBinaryOperator;
		private OperationType previousOperationType;
		private bool currentBinaryOperatorExecuted = false;

		private double memory;
		private bool isLocked;

		public Calculator()
		{
			initializeRegisters();
			previousOperationType = OperationType.None;
			memory = 0d;
			isLocked = false;
		}

		public void Press(char inPressedDigit)
		{
			bool digitIsPartOfNumber = char.IsNumber(inPressedDigit) || inPressedDigit.Equals(',');
			if (digitIsPartOfNumber)
			{
				processNumber(inPressedDigit);
			}
			else
			{
				processOperator(inPressedDigit);
			}
		}


		public string GetCurrentDisplayState()
		{
			if (isLocked)
			{
				return "-E-";
			}
			double content = registers[activeRegisterNumber].AsDouble();
			if (content >= Math.Pow(10, SizeOfDisplay))
			{
				isLocked = true;
				return "-E-";
			}
			else
			{
				return registers[activeRegisterNumber].AsString();
			}
		}

		private void processNumber(char inPressedDigit)
		{
			if (previousOperationType == OperationType.BinaryOperator ||
							previousOperationType == OperationType.Equals)
			{
				activeRegisterNumber = 1;
				registers[activeRegisterNumber].Reset();
			}
			if (previousOperationType == OperationType.UnaryOperator)
			{
				registers[activeRegisterNumber].Reset();
			}
			registers[activeRegisterNumber].AddDigit(inPressedDigit);
			previousOperationType = OperationType.Digit;
		}
	
		private void processOperator(char inPressedDigit)
		{
			switch (char.ToLower(inPressedDigit))
			{
				case '+':
					processBinaryOperator(new AdditionOperator());
					break;
				case '-':
					processBinaryOperator(new SubtractionOperator());
					break;
				case '*':
					processBinaryOperator(new MultiplicationOperator());
					break;
				case '/':
					processBinaryOperator(new DivisionOperator());
					break;
				case '=':
					processEqual();
					break;
				case 'm':
					registers[activeRegisterNumber].ChangeSign();
					break;
				case 's':
					processUnaryOperator(new SineOperator());
					break;
				case 'k':
					processUnaryOperator(new CosineOperator());
					break;
				case 't':
					processUnaryOperator(new TangentOperator());
					break;
				case 'q':
					processUnaryOperator(new SquareOperator());
					break;
				case 'r':
					processUnaryOperator(new SquareRootOperator());
					break;
				case 'i':
					processUnaryOperator(new InverseOperator());
					break;
				case 'p':
					memory = registers[activeRegisterNumber].AsDouble();
					break;
				case 'g':
					registers[activeRegisterNumber].SetNumber(memory);
					previousOperationType = OperationType.Digit;
					break;
				case 'c':
					activeRegisterNumber = 1;
					registers[activeRegisterNumber].Reset();
					isLocked = false;
					break;
				case 'o':
					initializeRegisters();
					previousOperationType = OperationType.None;
					currentBinaryOperator = null;
					memory = 0d;
					isLocked = false;
					break;
				default:
					break;
			}
		}

		private void processBinaryOperator(IBinaryOperator binaryOperator)
		{
			if (previousOperationType == OperationType.BinaryOperator)
			{
				currentBinaryOperator = binaryOperator;
				previousOperationType = OperationType.BinaryOperator;
				return;
			}
			else
			{
				if (currentBinaryOperator == null)
				{
					currentBinaryOperator = binaryOperator;
					currentBinaryOperatorExecuted = false;
				}
				else if (currentBinaryOperator != null && !currentBinaryOperatorExecuted)
				{
					double result = currentBinaryOperator.ExecuteOperation(registers[0].AsDouble(), registers[1].AsDouble());
					double roundedResult = roundNumber(result);
					try
					{
						registers[0].SetNumber(roundedResult);
					}
					catch (ArgumentException)
					{
						isLocked = true;
					}
					currentBinaryOperator = binaryOperator;
					activeRegisterNumber = 0;
				}
			}
			previousOperationType = OperationType.BinaryOperator;
		}

		private void processUnaryOperator(IUnaryOperator unaryOperator)
		{
			if (previousOperationType == OperationType.BinaryOperator)
			{
				if (activeRegisterNumber == 0)
				{
					activeRegisterNumber = 1;
					try
					{
						registers[activeRegisterNumber].SetNumber(registers[0].AsDouble());
					}
					catch (ArgumentException)
					{
						isLocked = true;
					}
				}
			}
			try
			{
				registers[activeRegisterNumber].SetNumber(roundNumber(unaryOperator.ExecuteOperation(registers[activeRegisterNumber].AsDouble())));
			}
			catch (ArgumentException)
			{
				isLocked = true;
			}
			previousOperationType = OperationType.UnaryOperator;
		}

		private void processEqual()
		{
			if (previousOperationType == OperationType.Digit && currentBinaryOperator != null && currentBinaryOperatorExecuted == false)
			{
				try
				{
					registers[0].SetNumber(roundNumber(currentBinaryOperator.ExecuteOperation(registers[0].AsDouble(), registers[1].AsDouble())));
				}
				catch (ArgumentException)
				{
					isLocked = true;
				}
				currentBinaryOperatorExecuted = true;
			}
			else if (previousOperationType == OperationType.BinaryOperator)
			{
				try
				{
					registers[0].SetNumber(roundNumber(currentBinaryOperator.ExecuteOperation(registers[0].AsDouble(), registers[0].AsDouble())));
				}
				catch (ArgumentException)
				{
					isLocked = true;
				}
			}
			else if (currentBinaryOperator != null && currentBinaryOperatorExecuted == false)
			{
				try
				{
					registers[0].SetNumber(roundNumber(currentBinaryOperator.ExecuteOperation(registers[0].AsDouble(), registers[1].AsDouble())));
				}
				catch (ArgumentException)
				{
					isLocked = true;
				}
				currentBinaryOperatorExecuted = true;
				previousOperationType = OperationType.BinaryOperator;
			}
			activeRegisterNumber = 0;
		}

		private void initializeRegisters()
		{
			registers = new List<NumberRepresentation>(numberOfRegisters);
			for (int i = 0; i < numberOfRegisters; i++)
			{
				registers.Add(new NumberRepresentation());
			}
		}

		private double roundNumber(double number)
		{
			int digitsBeforeDecimal = ((int)number).ToString().Length;
			try
			{
				return Math.Round(number, SizeOfDisplay - digitsBeforeDecimal, MidpointRounding.AwayFromZero);
			}
			catch (Exception)
			{
				return number;
			}
		}
	}

	public class Factory
	{
		public static ICalculator CreateCalculator()
		{
			return new Calculator();
		}
	}

	public class NumberRepresentation
	{
		private StringBuilder numberStringBuilder;
		private int decimalSeparatorPlace;
		private char sign;

		public NumberRepresentation()
		{
			sign = '+';
			decimalSeparatorPlace = -1;
			numberStringBuilder = new StringBuilder(Calculator.SizeOfDisplay);
		}

		public void Reset()
		{
			sign = '+';
			decimalSeparatorPlace = -1;
			numberStringBuilder = new StringBuilder(Calculator.SizeOfDisplay);
		}

		public void AddDigit(char digit)
		{
			if (numberStringBuilder.Length < Calculator.SizeOfDisplay)
			{
				bool digitIsNumber = char.IsNumber(digit);
				if (digitIsNumber)
				{
					bool decimalSeparatorExists = decimalSeparatorPlace != -1;
					bool digitIsZero = digit == '0';
					bool numberContainsMoreThanZeroDigits = numberStringBuilder.Length > 0;
					if (!decimalSeparatorExists && digitIsZero && numberContainsMoreThanZeroDigits)
					{
						if (double.Parse(numberStringBuilder.ToString()) == 0d)
						{
							return;
						}
					}
					numberStringBuilder.Append(digit);
				}
				else if (digit.Equals(','))
				{
					setDecimalSeparatorPlace();
				}
				else
				{
					// Error
				}
			}
		}


		public void ChangeSign()
		{
			if (sign.Equals('+'))
			{
				sign = '-';
			}
			else if (sign.Equals('-'))
			{
				sign = '+';
			}
			else
			{
				// Error occured
			}
		}

		public double AsDouble()
		{
			if (numberStringBuilder.Length == 0)
			{
				return 0d;
			}
			StringBuilder numberString = new StringBuilder(Calculator.SizeOfDisplay + 2);
			numberString.Append(sign);
			if (decimalSeparatorPlace == -1)
			{
				numberString.Append(numberStringBuilder);
			}
			else
			{
				numberString.Append(numberStringBuilder.ToString(), 0, decimalSeparatorPlace);
				numberString.Append('.');
				numberString.Append(numberStringBuilder.ToString(), decimalSeparatorPlace, numberStringBuilder.Length - decimalSeparatorPlace);
			}
			return double.Parse(numberString.ToString());
		}

		public void SetNumber(double number)
		{
			bool numberFitsDisplay = (number < Math.Pow(10, Calculator.SizeOfDisplay) && number > -Math.Pow(10, Calculator.SizeOfDisplay));
			if (!numberFitsDisplay)
			{
				throw new ArgumentOutOfRangeException();
			}
			if (number < 0)
			{
				sign = '-';
			}
			else
			{
				sign = '+';
			}
			var unsignedNumber = Math.Abs(number);
			numberStringBuilder = new StringBuilder(new string(unsignedNumber.ToString().Take(11).ToArray()));

			if (unsignedNumber == (int)unsignedNumber)
			{
				decimalSeparatorPlace = -1;
				if (numberStringBuilder.Length > Calculator.SizeOfDisplay)
				{
					numberStringBuilder.Remove(Calculator.SizeOfDisplay + 1, numberStringBuilder.Length - Calculator.SizeOfDisplay);
				}
			}
			else
			{
				decimalSeparatorPlace = unsignedNumber.ToString().IndexOf('.');
				numberStringBuilder.Remove(decimalSeparatorPlace, 1);
			}
		}

		public string AsString()
		{
			if (numberStringBuilder.Length == 0)
			{
				return "0";
			}
			StringBuilder numberString = new StringBuilder(Calculator.SizeOfDisplay + 2);
			if (sign.Equals('-'))
			{
				numberString.Append(sign);
			}

			if (decimalSeparatorPlace == -1)
			{
				numberString.Append(numberStringBuilder.ToString().TrimStart("0".ToCharArray()));
			}
			else
			{
				numberString.Append(numberStringBuilder.ToString(), 0, decimalSeparatorPlace);
				numberString.Append(",");
				numberString.Append(numberStringBuilder.ToString(), decimalSeparatorPlace, numberStringBuilder.Length - decimalSeparatorPlace);
				numberString = new StringBuilder(numberString.ToString().TrimStart("0".ToCharArray()).TrimEnd("0,".ToCharArray()));
				if (numberString[0] == ',')
				{
					numberString.Insert(0, '0');
				}

			}
			if (numberString.Length == 0)
			{
				return "0";
			}
			return numberString.ToString();
		}

		private void setDecimalSeparatorPlace()
		{
			if (decimalSeparatorPlace == -1)
			{
				if (numberStringBuilder.Length == 0)
				{
					numberStringBuilder.Append('0');
					decimalSeparatorPlace = 1;
				}
				else
				{
					decimalSeparatorPlace = numberStringBuilder.Length;
				}
			}
		}
	}
	
	public class AdditionOperator : IBinaryOperator
	{
		public  double ExecuteOperation(double firstNumber, double secondNumber)
		{
			return firstNumber + secondNumber;
		}
	}

	public class SubtractionOperator : IBinaryOperator
	{
		public double ExecuteOperation(double firstNumber, double secondNumber)
		{
			return firstNumber - secondNumber;
		}
	}
	
	public class MultiplicationOperator : IBinaryOperator
	{
		public double ExecuteOperation(double firstNumber, double secondNumber)
		{
			return firstNumber * secondNumber;
		}
	}
	
	public class DivisionOperator : IBinaryOperator
	{
		public double ExecuteOperation(double firstNumber, double secondNumber)
		{
			return firstNumber / secondNumber;
		}
	}
	
	public class CosineOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return Math.Cos(number);
		}
	}

	public class InverseOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return 1 / number;
		}
	}

	public class SineOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return Math.Sin(number);
		}
	}

	public class SquareOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return Math.Pow(number, 2);
		}
	}

	public class SquareRootOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return Math.Sqrt(number);
		}
	}

	public class TangentOperator : IUnaryOperator
	{
		public double ExecuteOperation(double number)
		{
			return Math.Tan(number);
		}
	}
	
	public interface IBinaryOperator
	{
		double ExecuteOperation(double firstNumber, double secondNumber);
	}

	public interface IUnaryOperator
	{
		double ExecuteOperation(double number);
	}

	public enum OperationType
	{
		None,
		Digit,
		UnaryOperator,
		BinaryOperator,
		Equals
	};
}
