﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new MojKalkulatorDK();
        }
    }

    public class MojKalkulatorDK:ICalculator
    {
        /// <summary>
        /// Sadržaj memorije kalkulatora
        /// </summary>
        private Prikaz memorija;

        /// <summary>
        /// Spremnik podataka za binarne operacije
        /// </summary>
        private Prikaz prethodni;

        /// <summary>
        /// Podatak koji je prikazan na ekranu
        /// </summary>
        private Prikaz ekran;

        /// <summary>
        /// Binarna operacija koja se treba izvršiti
        /// </summary>
        private char operacija = ' ';

        /// <summary>
        /// U slučaju da se dogodi neka greška, ova varijabla će tražiti da se obriše sadržaj sa ekrana
        /// </summary>
        private bool greska = false;

        /// <summary>
        /// Uključuje kalkulator
        /// </summary>
        public MojKalkulatorDK()
        {
            this.ekran = new Prikaz();

            this.prethodni = new Prikaz();
            this.prethodni.ukljucen = false;

            this.memorija = new Prikaz();
        }

        /// <summary>
        /// Simulira pritisak tipke na kalkulatoru
        /// </summary>
        /// <param name="inPressedDigit">Kôd pritisnute tipke</param>
        public void Press(char inPressedDigit)
        {
            try
            {
                if ("0123456789,".Contains(inPressedDigit))
                {
                    this.unos(inPressedDigit);
                }
                else if ("SKTMQRI".Contains(inPressedDigit))
                {
                    this.unarna(inPressedDigit);
                }
                else if ("+-*/".Contains(inPressedDigit))
                {
                    this.binarna(inPressedDigit);
                }
                else if ("PGCO".Contains(inPressedDigit))
                {
                    this.sistemskaOperacija(inPressedDigit);
                }
                else if (inPressedDigit == '=')
                {
                    this.izracunaj();
                }
            }
            catch (Exception)
            {
                // Dogodila se greška kod računanja - ispisati grešku na ekranu
                this.greska = true;
            }
        }

        /// <summary>
        /// Prikazuje što je trenutno na ekranu
        /// </summary>
        /// <returns>Prikaz na ekranu</returns>
        public string GetCurrentDisplayState()
        {
            if (!this.greska)
            {
                try
                {
                    return this.ekran.ToString();
                }
                catch (Exception)
                {
                    // Broj za prikaz ima više od 10 znamenaka ili je došlo do neke greške kod ispisa broja

                    // Resetiraj kalkulator
                    this.sistemskaOperacija('O');
                    return "-E-";
                }
            }

            // Dogodila se greška kod neke prijašnje operacije
            // Resetiraj kalkulator
            this.sistemskaOperacija('O');
            return "-E-";
        }

        /// <summary>
        /// Izračunavanje upisanog izraza
        /// </summary>
        private void izracunaj()
        {
            this.ekran.unos = "";

            if (!this.ekran.ukljucen && this.prethodni.ukljucen)
            {
                this.ekran = this.prethodni.clone();
            }

            if (this.operacija == '+')
            {
                this.ekran.broj += this.prethodni.broj;
            }
            else if (this.operacija == '-')
            {
                this.ekran.broj = this.prethodni.broj - this.ekran.broj;
            }
            else if (this.operacija == '*')
            {
                this.ekran.broj *= this.prethodni.broj;
            }
            else if (this.operacija == '/')
            {
                this.ekran.broj = this.prethodni.broj / this.ekran.broj;
            }

            this.ekran.round();
            this.ekran.updatePotencije();

            this.prethodni = new Prikaz();
            this.prethodni.ukljucen = false;
            this.operacija = ' ';
        }

        /// <summary>
        /// Upisivanje znaka na ekran
        /// </summary>
        /// <param name="znak">Znak koji treba biti dodan na ekran</param>
        private void unos(char znak)
        {
            if (!this.ekran.ukljucen)
            {
                this.ekran = new Prikaz();
            }

            if (znak == ',')
            {
                if (this.ekran.potencija == 0)
                {
                    this.ekran.potencija = 1;
                }
            }
            else if (znak == '0')
            {
                if (this.ekran.potencija == 0)
                {
                    if (this.ekran.broj * 10 < 10000000000)
                    {
                        this.ekran.broj *= 10;
                    }
                }
                else
                {
                    this.ekran.unos += "0";
                }
            }
            else
            {
                if (this.ekran.potencija == 0)
                {
                    double backup = this.ekran.broj;

                    this.ekran.broj *= 10;
                    if (this.ekran.broj < 0)
                    {
                        this.ekran.broj -= (int)znak - 48;
                    }
                    else
                    {
                        this.ekran.broj += (int)znak - 48;
                    }

                    if (Math.Abs(this.ekran.broj) > 9999999999)
                    {
                        // Ignorira se cjeloborojna znamenka iza desete
                        this.ekran.broj = backup;
                    }
                }
                else
                {
                    double dodatak = Math.Pow(10, -(this.ekran.potencija + this.ekran.unos.Length)) * ((int)znak - 48);
                    if (this.ekran.broj < 0)
                    {
                        this.ekran.broj -= dodatak;
                    }
                    else
                    {
                        this.ekran.broj += dodatak;
                    }
                    this.ekran.potencija += 1 + this.ekran.unos.Length;
                    this.ekran.unos = "";
                }
            }
        }

        /// <summary>
        /// Izračunava se odabrana unara operacija
        /// </summary>
        /// <param name="operacija">Oznaka unarne operacije</param>
        private void unarna(char operacija)
        {
            if (!this.ekran.ukljucen)
            {
                this.ekran = this.prethodni.clone();
                this.ekran.ukljucen = false;
            }
            if (operacija == 'S')
            {
                this.ekran.broj = Math.Sin(this.ekran.broj);
            }
            else if (operacija == 'K')
            {
                this.ekran.broj = Math.Cos(this.ekran.broj);
            }
            else if (operacija == 'T')
            {
                this.ekran.broj = Math.Tan(this.ekran.broj);
            }
            else if (operacija == 'M')
            {
                this.ekran.broj *= -1;
            }
            else if (operacija == 'Q')
            {
                this.ekran.broj = Math.Pow(this.ekran.broj, 2);
            }
            else if (operacija == 'R')
            {
                this.ekran.broj = Math.Sqrt(this.ekran.broj);
            }
            else if (operacija == 'I')
            {
                this.ekran.broj = 1 / this.ekran.broj;
            }
            this.ekran.updatePotencije();
        }

        /// <summary>
        /// Priprema se na izvršavanje odabrane binarne operacije
        /// </summary>
        /// <param name="oper">Oznaka binarne operacije</param>
        private void binarna(char oper)
        {
            if (!this.ekran.ukljucen)
            {
                this.operacija = oper;
            }
            else
            {
                if (this.operacija != ' ')
                {
                    this.izracunaj();
                }

                this.prethodni = this.ekran.clone();
                this.ekran.ukljucen = false;

                this.operacija = oper;
            }
        }

        /// <summary>
        /// Izvršava neku od sistemskih operacija
        /// </summary>
        /// <param name="operacija">Oznaka sistemske operacije</param>
        private void sistemskaOperacija(char operacija)
        {
            if (operacija == 'P')
            {
                this.memorija = this.ekran.clone();
                this.memorija.ukljucen = true;
            }
            else if (operacija == 'G')
            {
                this.ekran = this.memorija.clone();
            }
            else if (operacija == 'C')
            {
                // Brisanje
                this.ekran = new Prikaz();

                this.greska = false;
            }
            else if (operacija == 'O')
            {
                // Reset
                this.ekran = new Prikaz();

                this.prethodni = new Prikaz();
                this.prethodni.ukljucen = false;

                this.memorija = new Prikaz();

                this.greska = false;
            }
        }

        /// <summary>
        /// Razred za spremanje i prikaz podatakak koji se mogu prikazati na ekranu ili spreiti u memoriju
        /// </summary>
        class Prikaz
        {
            /// <summary>
            /// Označava stanje prikaza
            /// </summary>
            public bool ukljucen = true;

            /// <summary>
            /// Označava je li u tijeku upis broja
            /// </summary>
            public string unos = "";

            /// <summary>
            /// Broj bez decimalnog zareza
            /// </summary>
            public double broj = 0;

            /// <summary>
            /// Potencija koja se koristi za zapisivanje nove znamenke
            /// </summary>
            public int potencija = 0;

            /// <summary>
            /// Priprema broj za prikaz na ekranu
            /// </summary>
            public override string ToString()
            {
                if (Math.Abs(this.broj) > 10000000000)
                {
                    // Broj je prevelik za prikaz
                    throw new Exception();
                }
                else
                {
                    // Zaokruži broj
                    string prikaz = this.broj.ToString().Replace(".", ",");
                    int znam = prikaz.Split(',')[0].Length;
                    if (this.broj < 0)
                    {
                        znam--;
                    }
                    prikaz = Math.Round(this.broj, 10 - znam).ToString().Replace(".", ",");

                    // Na raj dodaj nepotrebne nule
                    if (prikaz != "0" && this.unos.Length > 0)
                    {
                        if (!prikaz.Contains(","))
                        {
                            prikaz += ",";
                        }
                        prikaz += this.unos;
                    }

                    // Obriši decimale koje ne stanu na ekran
                    int krati = 10;
                    if (prikaz.Contains('-'))
                    {
                        krati++;
                    }
                    if (prikaz.Contains(','))
                    {
                        krati++;
                    }
                    if (prikaz.Length > krati)
                    {
                        prikaz = prikaz.Substring(0, krati);
                    }

                    return prikaz;
                }
            }

            /// <summary>
            /// Radi se kopija objekta
            /// </summary>
            /// <returns>duboka kopija objekta</returns>
            public Prikaz clone()
            {
                Prikaz kopija = new Prikaz();
                kopija.broj = this.broj;
                kopija.ukljucen = this.ukljucen;
                kopija.unos = this.unos;
                kopija.potencija = this.potencija;
                return kopija;
            }

            /// <summary>
            /// Ponovno prebroji potencije nakon neke operacije
            /// </summary>
            public void updatePotencije()
            {
                this.potencija = 0;
                double br = this.broj;
                while (Math.Round(br) != br)
                {
                    this.potencija++;
                    br *= 10;
                }
                this.unos = "";
            }

            /// <summary>
            /// Zaokružuje broj na 10 znamenaka
            /// </summary>
            public void round()
            {
                string prikaz = this.broj.ToString().Replace(".", ",");
                int znam = prikaz.Split(',')[0].Length;
                if (this.broj < 0)
                {
                    znam--;
                }
                this.broj = Math.Round(this.broj, 10 - znam);
                this.updatePotencije();
            }
        }
    }
}
