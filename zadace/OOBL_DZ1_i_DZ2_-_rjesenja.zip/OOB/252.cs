﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        #region vars

        string ekran;
        double trenutni;
        double memorija;
        double ans;
        char binarniOperator;
        bool danBinarniOperator;
        bool prethodniBinarniOperator;
        bool pogreska;

        #endregion

        #region Constructor & Reset

        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            Reset();
        }

        private void Reset()
        {
            ekran = null;
            trenutni = 0;
            memorija = 0;
            ans = 0;
            binarniOperator = ' ';
            danBinarniOperator = false;
            prethodniBinarniOperator = false;
            pogreska = false;
            OsvjeziIspis();
        }

        #endregion

        #region Methods

        private double PretvoriBroj(string broj)
        {
            if (broj != "-E-")
            {
                return Convert.ToDouble(broj);
            }
            else { return 0; }
        }

        private string UrediString(double broj)
        {
            if (broj > 9999999999 || broj < -9999999999 || pogreska)
            {
                pogreska = true;
                return "-E-";
            }
            string izlaz = null;
            int mjestaPrijeZareza = 0;
            bool nasaoZarez = false;
            foreach (char c in broj.ToString())
            {
                if (!nasaoZarez) { mjestaPrijeZareza++; }
                if (c == System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator[0]) { nasaoZarez = true; }
            }
            if (nasaoZarez && broj >= 0) { broj = Math.Round(broj, (11 - mjestaPrijeZareza)); }
            else if (nasaoZarez && broj < 0) { broj = Math.Round(broj, (12 - mjestaPrijeZareza)); }
            izlaz = izlaz + broj.ToString();
            return izlaz;
        }

        private void BinarniOperator(char pressedKey)
        {
            if (!pogreska)
            {
                if (!prethodniBinarniOperator) { KlikJednako(); }
                binarniOperator = pressedKey;
                ans = trenutni;
                danBinarniOperator = true;
                prethodniBinarniOperator = true;
            }
        }

        private void PromjenaPredznaka()
        {
            if (trenutni != 0 && !pogreska)
            {
                prethodniBinarniOperator = false;
                trenutni = trenutni * -1;
                ekran = UrediString(trenutni);

            }
        }

        private void UnarniOperator(char pressedKey)
        {
            if (!pogreska)
            {
                switch (pressedKey)
                {
                    case 'S':
                        trenutni = Math.Sin(trenutni);
                        OsvjeziIspis();
                        break;
                    case 'K':
                        trenutni = Math.Cos(trenutni);
                        OsvjeziIspis();
                        break;
                    case 'T':
                        trenutni = Math.Tan(trenutni);
                        OsvjeziIspis();
                        break;
                    case 'Q':
                        trenutni = trenutni * trenutni;
                        OsvjeziIspis();
                        break;
                    case 'R':
                        trenutni = Math.Sqrt(trenutni);
                        OsvjeziIspis();
                        break;
                    case 'I':
                        if (trenutni != 0) { trenutni = 1 / trenutni; }
                        else { pogreska = true; }
                        OsvjeziIspis();
                        break;
                    default:
                        break;
                }
            }
        }

        private void UnesiUMemoriju()
        {
            if (!pogreska) { memorija = trenutni; }
        }

        private void DohvatiIzMemorije()
        {
            prethodniBinarniOperator = false;
            trenutni = memorija;
            OsvjeziIspis();
        }

        private void BrisanjeEkrana()
        {
            prethodniBinarniOperator = false;
            trenutni = 0;
            OsvjeziIspis();
        }

        private void OsvjeziIspis()
        {
            ekran = UrediString(trenutni);
            trenutni = PretvoriBroj(ekran);
        }

        private void KlikJednako()
        {
            prethodniBinarniOperator = false;
            if (!pogreska)
            {
                double rezultat = 0;
                if (danBinarniOperator)
                {
                    switch (binarniOperator)
                    {
                        case '+':
                            rezultat = ans + trenutni;
                            break;
                        case '-':
                            rezultat = ans - trenutni;
                            break;
                        case '*':
                            rezultat = ans * trenutni;
                            break;
                        case '/':
                            rezultat = ans / trenutni;
                            break;
                        default:
                            break;
                    }
                }
                else
                { rezultat = trenutni; }
                trenutni = PretvoriBroj(UrediString(rezultat));
                OsvjeziIspis();
            }
        }

        #endregion

        #region Interface

        public void Press(char inPressedDigit)
        {
            string privremeni = null;
            switch (inPressedDigit)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    if (prethodniBinarniOperator) { ekran = "0"; }
                    prethodniBinarniOperator = false;
                    privremeni = ekran + inPressedDigit;
                    trenutni = PretvoriBroj(privremeni);
                    if (trenutni < 9999999999 && trenutni > -9999999999)
                    { OsvjeziIspis(); }
                    else
                    {
                        trenutni = PretvoriBroj(ekran);
                    }
                    pogreska = false;
                    break;
                case ',':
                    if (prethodniBinarniOperator) { ekran = "0"; }
                    prethodniBinarniOperator = false;
                    ekran = ekran + inPressedDigit;
                    break;
                case '-':
                case '+':
                case '*':
                case '/':
                    BinarniOperator(inPressedDigit);
                    break;
                case '=':
                    KlikJednako();
                    break;
                case 'M':
                    PromjenaPredznaka();
                    break;
                case 'S':
                case 'K':
                case 'T':
                case 'Q':
                case 'R':
                case 'I':
                    UnarniOperator(inPressedDigit);
                    break;
                case 'P':
                    UnesiUMemoriju();
                    break;
                case 'G':
                    DohvatiIzMemorije();
                    pogreska = false;
                    break;
                case 'C':
                    BrisanjeEkrana();
                    pogreska = false;
                    break;
                case 'O':
                    Reset();
                    break;
                default:
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }

        #endregion
    }



}
