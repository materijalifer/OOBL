﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    
    public class Kalkulator : ICalculator
    {
        private enum Operation
        {
            plus, minus, multi, part, none
        }

        #region CALCULATOR FIELDS

        private String display = "0";
        private double tempResult = 0;
        private double memory = 0;
        private Operation lastOperation = Operation.none;
        private bool insertedNumber = false;

        #endregion

        public void Press(char inPressedDigit)
        {
            if (display.Equals("-E-")) display = "0";


            int cijelo;

            if (inPressedDigit < '0' || inPressedDigit > '9')
            {
                #region NON_NUMERIC_INPUT

                switch (inPressedDigit)
                {
                    case 'M':
                        if (display.Contains('-'))
                            display.Replace("-", "");
                        else
                            display = '-' + display;
                        insertedNumber = true;
                        break;
                    case ',':
                        if (!display.Contains(','))
                        {
                            display += ',';
                            insertedNumber = true;
                        }
                        break;
                    case '+':
                        if (!insertedNumber)
                        {
                            lastOperation = Operation.plus;
                            insertedNumber = false;
                            break;
                        }
                        insertedNumber = false;
                        updateResult(display);
                        lastOperation = Operation.plus;
                        break;
                    case '-':
                        if (!insertedNumber)
                        {
                            lastOperation = Operation.minus;
                            insertedNumber = false;
                            break;
                        }
                        insertedNumber = false;

                        updateResult(display);
                        lastOperation = Operation.minus;
                        break;
                    case '*':
                        if (!insertedNumber)
                        {
                            lastOperation = Operation.multi;
                            insertedNumber = false;
                            break;
                        }
                        insertedNumber = false;

                        updateResult(display);
                        lastOperation = Operation.multi;
                        break;
                    case '/':
                        if (!insertedNumber)
                        {
                            lastOperation = Operation.part;
                            insertedNumber = false;
                            break;
                        }
                        insertedNumber = false;

                        updateResult(display);
                        lastOperation = Operation.part;
                        break;
                    case '=':
                        updateResult(display);
                        cijelo = Math.Abs((long)tempResult).ToString().Length;
                        if (cijelo <= 10)
                            tempResult = Math.Round(tempResult, 10 - cijelo);
                        display = tempResult.ToString();
                        lastOperation = Operation.none;
                        tempResult = 0;
                        insertedNumber = false;
                        break;
                    case 'Q':
                        double q = double.Parse(display);
                        q = Math.Pow(q, 2);
                        cijelo = Math.Abs((long)q).ToString().Length;
                        if (cijelo <= 10)
                        q = Math.Round(q, 10 - cijelo);
                        display = q.ToString();
                        break;
                    case 'R':
                        double r = double.Parse(display);
                        if (r >= 0)
                        {
                            r = Math.Sqrt(r);
                            cijelo = Math.Abs((long)r).ToString().Length;
                            if (cijelo <= 10)
                            r = Math.Round(r, 10 - cijelo);
                            display = r.ToString();
                            break;
                        }
                        else display = "-E-";
                        break;

                    case 'S':
                        double sinNum = double.Parse(display);
                        double sinValue = Math.Sin(sinNum);
                        cijelo = Math.Min(10, Math.Abs((long)sinValue).ToString().Length);
                        display = Math.Round(sinValue, 10 - cijelo).ToString();
                        break;
                    case 'K':
                        double cosNum = double.Parse(display);
                        double cosValue = Math.Cos(cosNum);
                        cijelo = Math.Min(10, Math.Abs((long)cosValue).ToString().Length);
                        display = Math.Round(cosValue, 10 - cijelo).ToString();
                        break;
                    case 'T':
                        double tanNum = double.Parse(display);
                        double tanValue = Math.Tan(tanNum);
                        cijelo = Math.Min(10, Math.Abs((long)tanValue).ToString().Length);
                        display = Math.Round(tanValue, 10 - cijelo).ToString();
                        break;
                    case 'I':
                        double invNum = double.Parse(display);
                        if (invNum == 0) display = "-E-";
                        else
                        {
                            double invValue = 1 / invNum;
                            cijelo = Math.Min(10, Math.Abs((long)invValue).ToString().Length);
                            display = Math.Round(invValue, 10 - cijelo).ToString();
                        }
                        break;
                    case 'P':
                        memory = double.Parse(display);
                        break;
                    case 'G':
                        display = memory.ToString();
                        break;
                    case 'O':
                        tempResult = 0;
                        display = "0";
                        lastOperation = Operation.none;
                        insertedNumber = false;
                        break;
                    case 'C':
                        display = "0";
                        break;
                }

                int c = Math.Abs((long)tempResult).ToString().Length;
                if (c <= 10)
                    tempResult = Math.Round(tempResult, 10 - c);
                    
                

                 #endregion

                int len = 10;
                if (display.Contains(',')) len++;
                if (display.Contains('-')) len++;

                if (!display.Equals("-E-") && (double.Parse(display).CompareTo(9999999999) > 0 || double.Parse(display).CompareTo(-9999999999) < 0))
                {
                    display = "-E-";
                    tempResult = 0;
                    lastOperation = Operation.none;
                    insertedNumber = false;
                }
                else if (display.Length > len) display = display.Remove(len, display.Length - len);
            }
            else
            {
                #region NUMERIC_INPUT
                int maxDispSize = 10;
                if (display.Contains('-')) maxDispSize++;
                if (display.Contains(',')) maxDispSize++;
                if (display.Length < maxDispSize)
                {

                    if (display.Equals("0")) display = inPressedDigit.ToString();
                    else display += inPressedDigit.ToString();
                }
                if (!insertedNumber) display = inPressedDigit.ToString();
                insertedNumber = true;

                #endregion
            }

        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        private void updateResult(String newNum)
        {
            double newNumber = double.Parse(newNum);
            switch (lastOperation)
            {
                case Operation.plus:
                    tempResult += newNumber;

                    break;
                case Operation.minus:
                    tempResult -= newNumber;

                    break;
                case Operation.multi:
                    tempResult *= newNumber;

                    break;
                case Operation.part:
                    if (newNumber == 0)
                    {
                        display = "-E-";
                        tempResult = 0;
                    }
                    else tempResult /= newNumber;

                    break;
                case Operation.none:
                    tempResult = double.Parse(display);
                    break;
            }
            display = tempResult.ToString();
        }
    }

}
