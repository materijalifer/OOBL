﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        bool slabiY = false;
        char opera = '+';
        double mem;   
        double x=0;
        double pom;
        StringBuilder y = new StringBuilder();
        bool error = false;
        bool rezultat = false;
        double rez;


        void Operacije(char ch)
        {
            double pom;
            if (y.Length == 0)
            {
                pom = x;
                if (ch != '=')
                {
                    opera = '+';
                    pom = 0;
                }
            }
            else
            {
                pom = Convert.ToDouble(y.ToString());
            }
            switch (opera)
            {
                case '+':
                    x = x + pom;
                    break;
                case '-':
                    x = x - pom;
                    break;
                case '*':
                    x = x * pom;
                    break;
                case '/':
                    if (pom == 0)
                    {
                        error = true;
                    }
                    else
                    {
                        x = x / pom;
                    }
                    break;       
            }
            x = ProvjeriDuzinu(x);
            if (ch == '=')
            {
                rez = x;
                rezultat = true;

            }
            else
            {
                opera = ch;
                y = new StringBuilder();
            }
        }
        void SpremiUY(double pom)
        {
            y = new StringBuilder();
            foreach (char i in pom.ToString())
            {
                y.Append(i);
            }
        }
        double ProvjeriDuzinu(double pom)
        {
            int ukupna = 0;
            foreach(char i in pom.ToString())
            {
                if (Char.IsNumber(i))
                {
                    ukupna++;
                }
            }
            if (ukupna > 10)
            {
                pom = Math.Round(pom, (ukupna - 8));
                ukupna = 0;
                foreach (char i in pom.ToString())
                {
                    if (Char.IsNumber(i))
                    {
                        ukupna++;
                    }
                }
                if (ukupna > 10)
                {
                    error = true;
                }
            }
            return pom;
        }
       
        public void Press(char ch)
        {
            if (rezultat && ch != '=')
            {
                rezultat = false;
                y = new StringBuilder();
            }
            if (Char.IsNumber(ch))
            {
                if (slabiY)
                {
                    y = new StringBuilder();
                    slabiY = false;
                }
                y.Append(ch);     
            }
            else
            {        
                switch (ch)
                {                         
                    case ',':
                        if (slabiY)
                        {
                            y = new StringBuilder();
                            slabiY = false;
                        }
                        if (y.Length == 0)
                        { y.Append('0'); }
                        if (!y.ToString().Contains(','))
                        {
                            y.Append(ch);
                        }
                        break;
                    case 'M': //promjena predznaka
                        pom = Convert.ToDouble(y.ToString());                       
                        pom = 0 - pom;
                        pom = ProvjeriDuzinu(pom);                     
                        SpremiUY(pom);
                        break;
                    case 'S': //sinus
                        slabiY = true;
                        pom = Math.Sin(Convert.ToDouble(y.ToString()));
                        pom = Math.Round(pom, 9);
                        SpremiUY(pom);
                        break;
                    case 'K': //kosinus
                        slabiY = true;
                        pom = Math.Cos(Convert.ToDouble(y.ToString()));
                        pom = Math.Round(pom, 9);
                        SpremiUY(pom);
                        break;
                    case 'T': //tangens
                        slabiY = true;
                        pom = Math.Tan(Convert.ToDouble(y.ToString()));
                        pom = Math.Round(pom, 9);
                        SpremiUY(pom);
                        break;
                    case 'Q': //kvadiranje
                        slabiY = true;
                        pom = Convert.ToDouble(y.ToString());
                        pom = pom * pom;
                        pom = ProvjeriDuzinu(pom);
                        SpremiUY(pom);
                        break;
                    case 'R': //korjenovanje
                        slabiY = true;
                        double xxx = Convert.ToDouble(y.ToString());
                        if (xxx >= 0)
                        {
                            pom = Math.Sqrt(xxx);
                        }
                        else
                        {
                            error = true;
                        }
                        pom = ProvjeriDuzinu(pom);
                        SpremiUY(pom);
                        break;
                    case 'I': //inverz    
                        slabiY = true;
                        if (y.Length == 0)
                        {
                            pom = x;
                        }
                        else { pom = Convert.ToDouble(y.ToString()); }                    
                        if (pom == 0)
                        { error = true; }
                        else
                        {
                            pom = 1 / pom;
                            pom = ProvjeriDuzinu(pom);
                           SpremiUY(pom); 
                            
                        }
                        break;
                    case 'P': //spremanje u memoriju
                        mem = Convert.ToDouble(y.ToString());
                        break;
                    case 'G': //dohvaćanje iz memorije
                        SpremiUY(mem);                                                          
                        break;
                    case 'C': //brisanje ekrana
                        y = new StringBuilder();      
                        break;
                    case 'O': //resetiranje
                         slabiY = false;
                         opera = '+';                
                         mem = 0;   
                         x=0;       
                         y = new StringBuilder();                  
                         error = false;
                         pom = 0;
                         rezultat = false;
                         rez=0;

                        break;
                    default: //+ - * /
                        slabiY = false;
                        Operacije(ch);
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            if (error)
            {
                return "-E-";
            }
            if (y.Length == 0)
            {
                return x.ToString();
            }
            if (rezultat)
            {
                return rez.ToString();
            }
            
            return Convert.ToDouble(y.ToString()).ToString();
        }
    }


}