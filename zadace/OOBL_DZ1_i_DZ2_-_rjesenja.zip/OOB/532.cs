﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        // list of stocks, indexes and portfolios
        private List<Stock> _listStock;
        private List<Index> _listIndex;
        private List<Portfolio> _listPortfolio;

        public StockExchange()
        {
            _listStock = new List<Stock>();
            _listIndex = new List<Index>();
            _listPortfolio = new List<Portfolio>();
        }

        // helper function, returns list index of a given string or raises exception
        public int ReturnStockIndex(string inStockName)
        {
            int stockIndex = _listStock.FindIndex(st => st.GetStockName() == inStockName.ToUpper());
            if (stockIndex < 0)
                throw new StockExchangeException("Stock with a given name doesn't exist!");
            return stockIndex;
        }

        // helper function, returns list (index) index of a given string or raises exception
        public int ReturnIndexIndex(string inIndexName)
        {
            int indexIndex = _listIndex.FindIndex(ind => ind.GetIndexName() == inIndexName.ToUpper());
            if (indexIndex < 0)
                throw new StockExchangeException("Index with a given name doesn't exist!");
            return indexIndex;
        }

        // helper function, returns list (index) index of a given string or raises exception
        public int ReturnPortfolioIndex(string inPortfolioID)
        {
            int portfolioIndex = _listPortfolio.FindIndex(ind => ind.GetPortfolioID() == inPortfolioID);
            if (portfolioIndex < 0)
                throw new StockExchangeException("Portfolio with a given name doesn't exist!");
            return portfolioIndex;
        }

        // helper function, raises exception if stock doesn't exist on stock exchange
        public void RaiseExceptionIfStockExists(string inStockName)
        {
            if (_listStock.Exists(st => st.GetStockName() == inStockName.ToUpper()))
                throw new StockExchangeException("Stock with a given name already exists on stock exchange!");
        }

        // helper function, raises exception if stock doesn't exist on stock exchange
        public void RaiseExceptionIfStockDoesntExist(string inStockName)
        {
            if (!_listStock.Exists(st => st.GetStockName() == inStockName.ToUpper()))
                throw new StockExchangeException("Stock with a given name doesn't exist on stock exchange!");
        }

        // helper function, raises exception if index already exists on stock exchange
        public void RaiseExceptionIfIndexExists(string inIndexName)
        {
            if (_listIndex.Exists(ind => ind.GetIndexName() == inIndexName.ToUpper()))
                throw new StockExchangeException("Index with a given name already exists on stock exchange!");
        }

        // helper function, raises exception if index doesn't exist on stock exchange
        public void RaiseExceptionIfIndexDoesntExist(string inIndexName)
        {
            if (!_listIndex.Exists(ind => ind.GetIndexName() == inIndexName.ToUpper()))
                throw new StockExchangeException("Index with a given name doesn't exist on stock exchange!");
        }

        // helper function, raises exception if portfolio already exists on stock exchange
        public void RaiseExceptionIfPortfolioExists(string inPortfolioID)
        {
            if (_listPortfolio.Exists(por => por.GetPortfolioID() == inPortfolioID))
                throw new StockExchangeException("Portfolio with a given ID already exists on stock exchange!");
        }

        // helper function, raises exception if portfolio doesn't exist on stock exchange
        public void RaiseExceptionIfPortfolioDoesntExist(string inPortfolioID)
        {
            if (!_listPortfolio.Exists(por => por.GetPortfolioID() == inPortfolioID))
                throw new StockExchangeException("Portfolio with a given ID doesn't exist on stock exchange!");
        }

        // adds stock to a list if stock with the same name doesn't already exist or if initial price is set below zero
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            RaiseExceptionIfStockExists(inStockName);
            if (inInitialPrice <= 0) // price cannot be negative
                throw new StockExchangeException("Stock was given negative price!");

            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Stock was given negative number of shares!");

            _listStock.Add(new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        // deletes stock with a given name
        public void DelistStock(string inStockName)
        {
            RaiseExceptionIfStockDoesntExist(inStockName);
            int stockIndex = ReturnStockIndex(inStockName.ToUpper());
            Stock st = _listStock[stockIndex];
            _listStock.RemoveAt(stockIndex);

            // removing stocks from indexes
            foreach (Index ind in _listIndex)
            {
                if (ind.IsStockPartOfIndex(st))
                    ind.RemoveStockFromIndex(st);
            }

            // removing stocks from portfolios
            foreach (Portfolio por in _listPortfolio)
            {
                if (por.IsStockPartOfPortfolio(st))
                    por.RemoveStockFromPortfolio(st);
            }
        }

        // returns true if stock with given name exists, else returns false
        public bool StockExists(string inStockName)
        {
            if (_listStock.Exists(st => st.GetStockName() == inStockName.ToUpper()))
                return true;
            else
                return false;
        }

        // returns number of stocks (duh)
        public int NumberOfStocks()
        {
            return _listStock.Count;
        }

        // sets stock price for a given stock name 
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            RaiseExceptionIfStockDoesntExist(inStockName);
            _listStock[ReturnStockIndex(inStockName.ToUpper())].SetStockPrice(inIimeStamp, inStockValue);
        }

        // returns stock price in given time 
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            RaiseExceptionIfStockDoesntExist(inStockName);
            return _listStock[ReturnStockIndex(inStockName)].GetStockPrice(inTimeStamp);
        }

        // returns initial stock price for given stock name
        public decimal GetInitialStockPrice(string inStockName)
        {
            RaiseExceptionIfStockDoesntExist(inStockName);
            return _listStock[ReturnStockIndex(inStockName)].GetInitialStockPrice();
        }

        // reuturns last stock price for given stock name
        public decimal GetLastStockPrice(string inStockName)
        {
            RaiseExceptionIfStockDoesntExist(inStockName);
            return _listStock[ReturnStockIndex(inStockName)].GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            RaiseExceptionIfIndexExists(inIndexName);
            _listIndex.Add(new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            int indexIndex = ReturnIndexIndex(inIndexName);
            int stockIndex = ReturnStockIndex(inStockName);

            _listIndex[indexIndex].AddStockToIndex(_listStock[stockIndex]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            int indexIndex = ReturnIndexIndex(inIndexName);
            int stockIndex = ReturnStockIndex(inStockName);

            _listIndex[indexIndex].RemoveStockFromIndex(_listStock[stockIndex]);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            int indexIndex = ReturnIndexIndex(inIndexName);
            try
            {
                int stockIndex = ReturnStockIndex(inStockName);
                return _listIndex[indexIndex].IsStockPartOfIndex(_listStock[stockIndex]);
            }
            catch (StockExchangeException)
            {
                return false;
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            int indexIndex = ReturnIndexIndex(inIndexName);
            return _listIndex[indexIndex].GetIndexValue();
        }

        public bool IndexExists(string inIndexName)
        {
            if (_listIndex.Exists(ind => ind.GetIndexName() == inIndexName.ToUpper()))
                return true;
            else
                return false;
        }

        public int NumberOfIndices()
        {
            return _listIndex.Count;
        }

        // returns number of stocks in a given index
        public int NumberOfStocksInIndex(string inIndexName)
        {
            int indexIndex = ReturnIndexIndex(inIndexName);
            return _listIndex[indexIndex].NumberOfStocksInIndex();
        }

        // adds new portfolio on stock exchange
        public void CreatePortfolio(string inPortfolioID)
        {
            RaiseExceptionIfPortfolioExists(inPortfolioID);
            _listPortfolio.Add(new Portfolio(inPortfolioID));
        }

        // returns number of shares of stock in all portfolios
        public int NumberOfStocksInAllPortfolios(string inStockName)
        {
            int sumOfStocks = 0;
            foreach (Portfolio por in _listPortfolio)
                sumOfStocks += por.NumberOfSharesOfStockInPortfolio(inStockName);
            return sumOfStocks;
        }

        // adds stock to portfolio
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            int stockIndex = ReturnStockIndex(inStockName);
            Stock st = _listStock[stockIndex];

            if (numberOfShares < 0)
                throw new StockExchangeException("Given negative number of shares!");

            if (NumberOfStocksInAllPortfolios(inStockName) + numberOfShares > st.GetNumberOfShares())
                _listPortfolio[portfolioIndex].AddStockToPortfolio(_listStock[stockIndex], (int)st.GetNumberOfShares() - NumberOfStocksInAllPortfolios(inStockName));
                //throw new StockExchangeException("Number of stocks in all portfolios exceed number of stock shares on stock exchange!");
            else
                _listPortfolio[portfolioIndex].AddStockToPortfolio(_listStock[stockIndex], numberOfShares);
        }

        // remove certain amount of shares of stock from portfolio
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            int stockIndex = ReturnStockIndex(inStockName);

            _listPortfolio[portfolioIndex].RemoveStockFromPortfolio(_listStock[stockIndex], numberOfShares);
        }

        // remove stock from portfolio
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            int stockIndex = ReturnStockIndex(inStockName);

            _listPortfolio[portfolioIndex].RemoveStockFromPortfolio(_listStock[stockIndex]);
        }

        public int NumberOfPortfolios()
        {
            return _listPortfolio.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            return _listPortfolio[portfolioIndex].NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (_listPortfolio.Exists(ind => ind.GetPortfolioID() == inPortfolioID))
                return true;
            else
                return false;
        }

        // checks whether stock is already in portfolio
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            
            try
            {
                int stockIndex = ReturnStockIndex(inStockName);
                return _listPortfolio[portfolioIndex].IsStockPartOfPortfolio(_listStock[stockIndex]);
            }
            catch (StockExchangeException)
            {
                return false;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            return _listPortfolio[portfolioIndex].NumberOfSharesOfStockInPortfolio(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);
            return _listPortfolio[portfolioIndex].GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            DateTime tBegin, tEnd;

            try
            {
                tBegin = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                tEnd = new DateTime(Year, Month, 1, 23, 59, 59, 999).AddMonths(1).AddDays(-1);
            }
            catch (System.ArgumentOutOfRangeException)
            {
                throw new StockExchangeException("Invalid date input!");
            }

            decimal vBegin, vEnd, result;
            int portfolioIndex = ReturnPortfolioIndex(inPortfolioID);

            vBegin = _listPortfolio[portfolioIndex].GetPortfolioValue(tBegin);
            vEnd = _listPortfolio[portfolioIndex].GetPortfolioValue(tEnd);

            if (vEnd - vBegin == 0)
                return 0.000m;
            else
            {
                result = ((vEnd - vBegin) / vBegin) * 100;
                return Math.Truncate(result * 1000m) / 1000m;
            }
        }
    }

    public class Stock
    {
        private string _stockName;
        private long _numberOfShares;
        private SortedDictionary<DateTime, decimal> _sortedPrices;

        // constructor for Stock class
        public Stock(string inStockName, long inNumberOfShares, decimal inStockPrice, DateTime inTimeStamp)
        {
            _stockName = inStockName.ToUpper(); // case insensitive 
            _numberOfShares = inNumberOfShares;
            _sortedPrices = new SortedDictionary<DateTime, decimal>();
            _sortedPrices[inTimeStamp] = inStockPrice; // key: time , value: stock price (initial stock price)
        }

        // sets stock price
        public void SetStockPrice(DateTime inTimeStamp, decimal inStockPrice)
        {
            if (_sortedPrices.ContainsKey(inTimeStamp))  // checking whether given time stamp already exists
                throw new StockExchangeException("Invalid time given, already exists!");
      
            _sortedPrices[inTimeStamp] = inStockPrice;
        }

        // returns stock name
        public string GetStockName()
        {
            return _stockName;
        }

        // returns stock price for given time
        public decimal GetStockPrice(DateTime inTime)
        {
            DateTime inInterval = _sortedPrices.First().Key;
            foreach (KeyValuePair<DateTime, decimal> entry in _sortedPrices)
            {
                if (DateTime.Compare(entry.Key, inTime) > 0)
                    break;
                inInterval = entry.Key;
            }
            return _sortedPrices[inInterval];
        }

        // returns first defined stock price
        public decimal GetInitialStockPrice()
        {
            return _sortedPrices.Values.First();
        }

        // returns last defined stock price
        public decimal GetLastStockPrice()
        {
            return _sortedPrices.Values.Last();
        }

        // returns number of shares of stock
        public long GetNumberOfShares()
        {
            return _numberOfShares;
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<Stock> _listStock;

        // constructor for class index
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.WEIGHTED && inIndexType != IndexTypes.AVERAGE)
                throw new StockExchangeException("Wrong index type!");

            _indexName = inIndexName.ToUpper();
            _indexType = inIndexType;
            _listStock = new List<Stock>();
        }

        // helper function, raises exception if stock doesn't exist in index
        public void RaiseExceptionIfStockDoesntExist(Stock st)
        {
            if (!_listStock.Contains(st))
                throw new StockExchangeException("Stock with a given name doesn't exist in this index!");
        }

        // helper function, raises exception if stock exists in this index
        public void RaiseExceptionIfStockExists(Stock st)
        {
            if (_listStock.Contains(st))
                throw new StockExchangeException("Stock with a given name already exists in this index!");
        }

        // returns index name
        public string GetIndexName()
        {
            return _indexName;
        }

        // returns index type
        public IndexTypes GetIndexType()
        {
            return _indexType;
        }

        // adds stock to index
        public void AddStockToIndex(Stock st)
        {
            RaiseExceptionIfStockExists(st);
            _listStock.Add(st);
        }

        // removes stock from index
        public void RemoveStockFromIndex(Stock st)
        {
            RaiseExceptionIfStockDoesntExist(st);
            _listStock.Remove(st);
        }

        // checks whether the given stock is part of index, returns bool value accordingly
        public bool IsStockPartOfIndex(Stock st)
        {
            if (_listStock.Contains(st))
                return true;
            else
                return false;
        }

        // returns number of stocks in index
        public int NumberOfStocksInIndex()
        {
            return _listStock.Count;
        }

        // returns total sum of stock prices (number of shares * stock price)
        public decimal TotalStockPrice()
        {
            decimal totalPrice = 0;
            foreach (Stock st in _listStock)
                totalPrice += st.GetNumberOfShares() * st.GetLastStockPrice();
            return totalPrice;
        }

        // calculates and returns total number of shares
        public long TotalStockShares()
        {
            long sumStocks = 0;
            foreach (Stock st in _listStock)
                sumStocks += st.GetNumberOfShares();
            return sumStocks;
        }

        // calculates weighted index value
        private decimal WeightedValue()
        {
            decimal wValue = 0;
            decimal wFactor = 0;
            decimal totalPrice = TotalStockPrice();
            foreach (Stock st in _listStock)
            {
                wFactor = st.GetLastStockPrice() / totalPrice;
                wValue += st.GetLastStockPrice() * st.GetNumberOfShares() * wFactor;
            }
            return wValue;
        }

        // returns averaged index value
        private decimal AverageValue()
        {
            if (NumberOfStocksInIndex() == 0)
                return 0;
            decimal avSum = 0;
            foreach (Stock st in _listStock)
                avSum += st.GetLastStockPrice();
            return avSum / NumberOfStocksInIndex();
        }

        // calculates index values based on its type
        public decimal GetIndexValue()
        {
            switch (_indexType)
            {
                case IndexTypes.WEIGHTED:
                    return Decimal.Round(WeightedValue(), 3);
                case IndexTypes.AVERAGE:
                    return Decimal.Round(AverageValue(), 3);
                default:
                    throw new StockExchangeException("Wrong index type!");
            }
        }
    }

    class Portfolio
    {
        private string _portfolioID;
        private List<Stock> _listStock;
        private List<int> _listShares; // keeps track of number of shares for given stock in portfolio

        // constructor for Portfolio class
        public Portfolio(string inPortfolioID)
        {
            _portfolioID = inPortfolioID;
            _listStock = new List<Stock>();
            _listShares = new List<int>();
        }

        public int ReturnStockIndex(string inStockName)
        {
            return _listStock.FindIndex(st => st.GetStockName() == inStockName.ToUpper());
        }

        // helper function, raises exception if stock doesn't exist in index
        public void RaiseExceptionIfStockDoesntExist(Stock st)
        {
            if (!_listStock.Contains(st))
                throw new StockExchangeException("Stock with a given name doesn't exist in this portfolio!");
        }

        // helper function, raises exception if stock exists in this index
        public void RaiseExceptionIfStockExists(Stock st)
        {
            if (_listStock.Contains(st))
                throw new StockExchangeException("Stock with a given name already exists in this portfolio!");
        }

        // returns portfolio ID
        public string GetPortfolioID()
        {
            return _portfolioID;
        }

        // adds stocks to portfolio
        public void AddStockToPortfolio(Stock st, int numberOfShares)
        {
            //RaiseExceptionIfStockExists(st);
            if (!_listStock.Contains(st))
            {
                _listStock.Add(st);
                _listShares.Add(numberOfShares);
            }
            else
            {
                int stockIndex = ReturnStockIndex(st.GetStockName());
                _listShares[stockIndex] += numberOfShares;
            }
        }

        // removes stock from portfolio
        public void RemoveStockFromPortfolio(Stock st)
        {
            RaiseExceptionIfStockDoesntExist(st);
            int stockIndex = ReturnStockIndex(st.GetStockName());
            _listStock.Remove(st);
            _listShares.RemoveAt(stockIndex);
        }

        // removes certain amount of stocks from portfolio
        public void RemoveStockFromPortfolio(Stock st, int inNumberOfShares)
        {
            RaiseExceptionIfStockDoesntExist(st);
            int stockIndex = ReturnStockIndex(st.GetStockName());
            if (_listShares[stockIndex] <= inNumberOfShares) // all shares
            {
                _listStock.Remove(st);
                _listShares.RemoveAt(stockIndex);
            }
            else
            {
                _listShares[stockIndex] -= inNumberOfShares;
            }

        }

        // checks whether the given stock is part of portfolio, returns bool value accordingly
        public bool IsStockPartOfPortfolio(Stock st)
        {
            if (_listStock.Contains(st))
                return true;
            else
                return false;
        }

        // returns number of stocks in portfolio
        public int NumberOfStocksInPortfolio()
        {
            return _listStock.Count;
        }

        // returns number of shares for a given stock in portfolio
        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            int stockIndex = ReturnStockIndex(inStockName);
            if (stockIndex != -1)
                return _listShares[stockIndex];
            else
                return 0;
        }

        // returns value of portfolio for a given time
        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            decimal totalValue = 0;
            int ind = 0;
            foreach (Stock element in _listStock)
            {
                decimal stockPrice = element.GetStockPrice(inTimeStamp);
                totalValue += _listShares[ind] * stockPrice;
                ind += 1;
            }

            return totalValue;
        }
    }
}
