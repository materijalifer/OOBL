﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string Name { get; set; }
        public long Amount { get; set; }
        public decimal InitialPrice { get; set; }
        public DateTime InitDate { get; set; }
        public List<decimal> Price = new List<decimal>();
        public List<DateTime> Date = new List<DateTime>();

        public Stock(string name, long amount, decimal initPrice, DateTime date)
        {
            this.Name = name;
            this.Amount = amount;
            this.InitialPrice = initPrice;
            this.InitDate = date;
        }
        public Stock()
        { }

        public Stock getStockWithName(ArrayList stockList1, string inStockName)
        {
            Stock returnStock = null;

            foreach (Stock stock in stockList1)
            {
                if (Regex.IsMatch(stock.Name, inStockName, RegexOptions.IgnoreCase))
                {
                    return stock;
                }
            }

            return returnStock;
        }
    }

    public class Index
    {
        public string Name { get; set; }
        public IndexTypes Type { get; set; }
        public List<Stock> StockIndexList = new List<Stock>();

        public Index(string name, IndexTypes type)
        {
            this.Name = name;
            this.Type = type;
        }

        public Index()
        { }
    }

    public class Portfolio
    {
        public string PortfolioIndex { get; set; }
        public List<Stock> PortfolioStockList = new List<Stock>();

        public Portfolio(string index)
        {
            this.PortfolioIndex = index;
        }
        public Portfolio()
        { }

        public int nOfStockInPortfolio(ArrayList portList, string stockName)
        {
            int numOfStocks = 0;

            foreach(Portfolio port in portList)
            {
                foreach(Stock stockPort in port.PortfolioStockList)
                {
                    if(stockPort.Name == stockName)
                    {
                        numOfStocks += (int)stockPort.Amount;
                    }
                }
            }

            return numOfStocks;
        }

        public Portfolio getPortfolioWithName(ArrayList portfolioList, string inPortfolioID)
        {
            Portfolio returnPortfolio = null;

            foreach (Portfolio portfolio in portfolioList)
            {
                if ((portfolio.PortfolioIndex == inPortfolioID))
                {
                    return portfolio;
                }
            }
            return returnPortfolio;
        }
    }

    public class StockExchange : IStockExchange
    {
        ArrayList stockList = new ArrayList();
        Stock stock = new Stock();

        ArrayList indexList = new ArrayList();
        Index index = new Index();

        ArrayList portfolioList = new ArrayList();
        Portfolio portfolio = new Portfolio();

        #region StockFunction

        // Dodaje dionicu s početnom cijenom na burzu
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock addStock = null;

            if (inNumberOfShares > 0 && inInitialPrice > 0)
            {
                if (stockList.Count > 0)
                {
                    addStock = stock.getStockWithName(stockList, inStockName);

                    if (addStock != null)
                    {
                        throw new StockExchangeException("Stock already exsists");
                    }
                    else
                    {
                        stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
                    }
                }
                else
                    stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
                throw new StockExchangeException("Wrong data!!!");
        }

        // Briše dionicu s burze
        public void DelistStock(string inStockName)
        {
            Stock stock1 = null;

            if (stockList.Count > 0)
            {
                stock1 = stock.getStockWithName(stockList, inStockName);
                if (stock1 != null)
                {
                    StockListHasChanged(inStockName);
                    stockList.Remove(stock1);
                }
                else
                    throw new StockExchangeException("Stock doesn't exsists so it can't be deleted!");
            }
            else
                throw new StockExchangeException("StockList is empty!");
        }

        public void StockListHasChanged(string inStockName)
        {
            Stock stock1 = null;

            if (stockList.Count > 0)
            {
                stock1 = stock.getStockWithName(stockList, inStockName);
                if (stock1 != null)
                {
                    if (indexList.Count > 0)
                    {
                        foreach (Index index1 in indexList)
                        {
                            if(index1.StockIndexList.Count > 0)
                            {
                                foreach (Stock stock2 in index1.StockIndexList)
                                {
                                    if (inStockName == stock2.Name)
                                    {
                                        RemoveStockFromIndex(index1.Name, inStockName);
                                        foreach (Portfolio port in portfolioList)
                                        {
                                            if (port.PortfolioStockList.Count > 0)
                                            {
                                                foreach (Stock stock3 in port.PortfolioStockList)
                                                {
                                                    if (inStockName == stock3.Name)
                                                    {
                                                        RemoveStockFromPortfolio((string)port.PortfolioIndex, inStockName);
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    else if (portfolioList.Count > 0)
                    {
                        foreach (Portfolio port in portfolioList)
                        {
                            if (port.PortfolioStockList.Count > 0)
                            {
                                foreach (Stock stock3 in port.PortfolioStockList)
                                {
                                    if (inStockName == stock3.Name)
                                    {
                                        RemoveStockFromPortfolio((string)port.PortfolioIndex, inStockName);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Provjerava postoji li tražena dionica na burzi
        public bool StockExists(string inStockName)
        {
            Stock stock1 = null;
            bool consist = false;

            if (stockList.Count > 0)
            {
                stock1 = stock.getStockWithName(stockList, inStockName);
                if (stock1 != null)
                    consist = true;
                else
                    consist = false;
            }
            else
                throw new StockExchangeException("StockList is empty!");

            return consist;
        }

        // Vraća broj dionica na burzi
        public int NumberOfStocks()
        {
            int nStock = 0;
            nStock = stockList.Count;

            return nStock;
        }
        
        // Postavlja cijenu dionice za određeno vrijeme
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            bool addPrice = false;
            Stock stockAdd = null;

            if (stockList.Count > 0)
            {
                if (inStockValue > 0)
                {
                    foreach (Stock stock in stockList)
                    {
                        if (Regex.IsMatch(stock.Name, inStockName, RegexOptions.IgnoreCase))
                        {
                            if (stock.Date.Count() != 0)
                            {
                                foreach (DateTime dat in stock.Date)
                                {
                                    if (dat != inIimeStamp)
                                    {
                                        addPrice = true;
                                        stockAdd = stock;
                                    }
                                    else
                                    {
                                        addPrice = false;
                                    }
                                }
                            }
                            else
                            {
                                addPrice = true;
                                stockAdd = stock;
                            }                            
                        }
                    }
                }
                else
                    throw new StockExchangeException("StockValue is wrong!");
            }
            else
                throw new StockExchangeException("StockList is empty!");

            if (addPrice)
            {
                stockAdd.Price.Add(inStockValue);
                stockAdd.Date.Add(inIimeStamp);
                SetPriceChanged(inStockName, inIimeStamp, inStockValue);
            }
            else
                throw new StockExchangeException("Price for time already exsists!");
        }

        public void SetPriceChanged(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock1 = null;
            int inNumOfShares = 0;

            if (stockList.Count > 0)
            {
                stock1 = stock.getStockWithName(stockList, inStockName);
                if (stock1 != null)
                {
                    if (indexList.Count > 0)
                    {
                        foreach (Index index1 in indexList)
                        {
                            if (index1.StockIndexList.Count > 0)
                            {
                                foreach (Stock stock2 in index1.StockIndexList)
                                {
                                    if (inStockName == stock2.Name)
                                    {
                                        RemoveStockFromIndex(index1.Name, inStockName);
                                        AddStockToIndex(index1.Name, inStockName);
                                        foreach (Portfolio port in portfolioList)
                                        {
                                            if (port.PortfolioStockList.Count > 0)
                                            {
                                                foreach (Stock stock3 in port.PortfolioStockList)
                                                {
                                                    if (inStockName == stock3.Name)
                                                    {
                                                        inNumOfShares = (int)stock3.Amount;
                                                        RemoveStockFromPortfolio((string)port.PortfolioIndex, inStockName);
                                                        AddStockToPortfolio(port.PortfolioIndex, inStockName, inNumOfShares); 
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dohvaća cijenu dionice za neko vrijeme
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            decimal price = 0;
            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;

            fileDate = inTimeStamp;       //set to the file date
            Stock stockMin = (Stock)stockList[0];

                if (stockMin.Date.Count > 0)
                {
                    min = Math.Abs(fileDate.Ticks - stockMin.Date[0].Ticks);

                    foreach (Stock stock1 in stockList)
                    {
                        if (stock1.Name == inStockName)
                        {
                            foreach (DateTime date in stock1.Date)
                            {
                                diff = Math.Abs(fileDate.Ticks - date.Ticks);
                                if (diff <= min)
                                {
                                    min = diff;
                                    closestDate = date;
                                }
                                indexOfDate = stock1.Date.IndexOf(closestDate);
                            }
                        }

                        foreach (decimal pr in stock1.Price)
                        {
                            if (stock1.Price.IndexOf(pr) == indexOfDate)
                                price = pr;
                        }
                    }
                }
                else
                {
                    price = stock.InitialPrice;
                    return price;
                }

            return price;
        }

        // Dohvaća početnu cijenu dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            decimal initPrice = 0;

            if (stockList.Count > 0)
            {
                foreach (Stock stock in stockList)
                {
                    if (Regex.IsMatch(stock.Name, inStockName, RegexOptions.IgnoreCase))
                    {
                        initPrice = stock.InitialPrice;
                    }
                }
            }
            else
                throw new StockExchangeException("StockList is empty!");

            return initPrice;

            //throw new NotImplementedException();
        }

        // Dohvaća zadnju cijenu dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            int indexOfLastDate;
            decimal price = 0;

            if (stockList.Count > 0)
            {
                foreach (Stock stock in stockList)
                {
                    if (Regex.IsMatch(stock.Name, inStockName, RegexOptions.IgnoreCase))
                    {
                        if (stock.Date.Count > 0)
                        {
                            indexOfLastDate = stock.Date.Count;
                            price = stock.Price.Last();
                        }
                        else
                            price = stock.InitialPrice;
                    }
                }
            }
            else
                throw new StockExchangeException("StackList is empty!!!");

            return price;

            //throw new NotImplementedException();
        }
        
        #endregion

        #region IndexFunctions
        
        //stvara novi indeks na burzi
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            bool addNew = false;

            if(inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
            {
                if (indexList.Count > 0)
                {
                    foreach (Index index in indexList)
                    {
                        if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                        {
                            throw new StockExchangeException("Index already exsists!!!");
                        }
                        else
                        {
                            addNew = true;
                        }
                    }
                }
                else
                {
                    indexList.Add(new Index(inIndexName, inIndexType));
                }

                if(addNew)
                    indexList.Add(new Index(inIndexName, inIndexType));
            }
            else
                throw new StockExchangeException("Wrong index import data!!!");
        }

        //dodaje dionicu u indeks
        public void AddStockToIndex(string inIndexName, string inStockName)
        {    
            Stock stockForIndex = null;
            Index addStock = null;
            bool add = false;
            bool indexExsists = false;

            if (indexList.Count > 0 && stockList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                    if (StockExists(inStockName))
                    {
                        if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                        {
                            stockForIndex = stock.getStockWithName(stockList, inStockName);

                            if (stockForIndex != null)
                            {
                                if (index.StockIndexList.Count > 0)
                                {
                                    foreach (Stock stock1 in index.StockIndexList)
                                    {
                                        if (stock1 != stockForIndex)
                                        {
                                            add = true;
                                            addStock = index;
                                        }
                                        else
                                            add = false;
                                    }
                                }
                                else
                                {
                                    add = true;
                                    addStock = index;
                                }

                                indexExsists = true;
                            }
                        }
                    }
                    else
                        throw new StockExchangeException("Stock doesn't exsists!");
                }
                
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");
            
            if (indexExsists == false)
                throw new StockExchangeException("Index doesn't exsists!");
            
            if(add)
                addStock.StockIndexList.Add(stockForIndex);
        }

        //briše dionicu iz indeksa
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stockForIndex;

            if (indexList.Count > 0 && stockList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                    if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                    {
                        stockForIndex = stock.getStockWithName(stockList, inStockName);

                        if(stockForIndex != null)
                            index.StockIndexList.Remove(stockForIndex);
                        else
                            throw new StockExchangeException("There is no stock with required name");
                    }
                }
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");
        }

        //provjerava je li dionica u indeksu
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stockForIndex;
            bool partOf = false;

            if (indexList.Count > 0 && stockList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                    if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                    {
                        stockForIndex = stock.getStockWithName(stockList, inStockName);

                        if (stockForIndex != null)
                        {
                            if (index.StockIndexList.Contains(stockForIndex))
                            {
                                partOf = true;
                                return partOf;
                            }
                            else
                                partOf = false;
                        }
                    }
                }
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");

            return partOf;
        }

        //dohvaća vrijednost indeksa
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal averageValue = 0;
            decimal weightedValue = 0;
            int nAverage = 0;
            decimal addStocks = 0;
            decimal sumOfStock = 0;
            decimal divi = 0;
            bool w = false;
            bool a = false;
            decimal returnValue;
            Stock stockMin = null;

            List<decimal> array = new List<decimal>();
            int j = 0;

            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;

            fileDate = inTimeStamp;

            if (indexList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                        if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                        {
                            if (index.StockIndexList.Count > 0)
                            {
                                if (index.Type == IndexTypes.WEIGHTED)
                                    w = true;
                                else if (index.Type == IndexTypes.AVERAGE)
                                    a = true;
                                if (index.StockIndexList.Count > 0)
                                {
                                    stockMin = (Stock)index.StockIndexList[0];

                                    foreach (Stock stock1 in index.StockIndexList)
                                    {
                                        if (stock1.Date.Count > 0)
                                        {
                                            min = Math.Abs(fileDate.Ticks - stockMin.Date[0].Ticks);
                                            foreach (DateTime date in stock1.Date)
                                            {
                                                diff = Math.Abs(fileDate.Ticks - date.Ticks);

                                                if ((inTimeStamp.Ticks - stockMin.InitDate.Ticks) < (Math.Abs(inTimeStamp.Ticks - stock1.Date[0].Ticks)))
                                                {
                                                    for (int i = 0; i < stock1.Amount; i++)
                                                    {
                                                        averageValue += stock1.InitialPrice;
                                                        nAverage++;

                                                        addStocks = stock1.Amount * stock1.InitialPrice;
                                                        sumOfStock += addStocks;
                                                        array.Add(stock1.InitialPrice);

                                                        foreach (decimal p in array)
                                                        {
                                                            divi = p / sumOfStock;
                                                            weightedValue += p * divi;
                                                        }

                                                        if (w)
                                                            returnValue = Math.Round(weightedValue, 3);
                                                        else
                                                            returnValue = Math.Round(averageValue, 3);

                                                        return returnValue;
                                                    }
                                                }

                                                if (diff <= min)
                                                {
                                                    min = diff;
                                                    closestDate = date;
                                                }
                                                indexOfDate = stock1.Date.IndexOf(closestDate);
                                            }

                                            foreach (decimal pr in stock1.Price)
                                            {
                                                if (stock1.Price.IndexOf(pr) == indexOfDate)
                                                {
                                                    averageValue += pr;
                                                    nAverage++;

                                                    addStocks = stock1.Amount * pr;
                                                    sumOfStock += addStocks;
                                                    for (int i = 0; i < stock1.Amount; i++)
                                                    {
                                                        array.Add(pr);
                                                    }
                                                }
                                            }
                                        }

                                        else
                                        {
                                            j++;
                                            if (j < index.StockIndexList.Count)
                                            {
                                                stockMin = (Stock)index.StockIndexList[j];
                                            }
                                            averageValue += stock1.InitialPrice;
                                            nAverage++;

                                            addStocks = stock1.Amount * (decimal)stock1.InitialPrice;
                                            sumOfStock += addStocks;
                                            for (int i = 0; i < stock1.Amount; i++)
                                            {
                                                array.Add(stock1.InitialPrice);
                                            }
                                        }
                                    }
                                }

                                else
                                    return 0;

                                foreach (decimal p in array)
                                {
                                    divi = p / sumOfStock;
                                    weightedValue += p * divi;
                                }
                            }
                            else
                                return 0;
                        }
                    }
                }
            
            averageValue = averageValue / nAverage;
            if (w)
                returnValue = Math.Round(weightedValue, 3);
            else
                returnValue = Math.Round(averageValue, 3);

            return returnValue;
        }

        //provjerava postoji li traženi indeks na burzi
        public bool IndexExists(string inIndexName)
        {
            bool exsists = false; 

            if (indexList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                    if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                    {
                        exsists = true;
                        return exsists;
                    }
                    else
                        exsists = false;
                }
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");

            return exsists;
        }

        //dohvaća broj indeksa na burzi
        public int NumberOfIndices()
        {
            int nIndex = 0;
            nIndex = indexList.Count;

            return nIndex;
        }

        //dohvaća broj dionica u traženom indeksu
        public int NumberOfStocksInIndex(string inIndexName)
        {
            int nStockInIndex = 0;
            if (indexList.Count > 0)
            {
                foreach (Index index in indexList)
                {
                    if (Regex.IsMatch(index.Name, inIndexName, RegexOptions.IgnoreCase))
                    {
                        if (index.StockIndexList.Count > 0)
                        {
                            foreach (Stock stock in index.StockIndexList)
                            {
                                nStockInIndex++;
                            }
                        }
                        else
                            return 0;
                    }
                }
            }
            else
                throw new StockExchangeException("IndexList is empty!!!");

            return nStockInIndex;
        }

        #endregion

        #region PortfolioFunctions

        // Stvara novi portfelj na burzi
        public void CreatePortfolio(string inPortfolioID)
        {
            bool addNew = false;

            if (portfolioList.Count > 0)
            {
                foreach (Portfolio portfolio in portfolioList)
                {
                    if (portfolio.PortfolioIndex == inPortfolioID)
                    {
                        throw new StockExchangeException("Portfolio already exsists!!!");
                    }
                    else
                    {
                        addNew = true;
                    }
                }
            }
            else
            {
                portfolioList.Add(new Portfolio(inPortfolioID));
            }

            if (addNew)
                portfolioList.Add(new Portfolio(inPortfolioID));
 
        }

        // Dodaje određeni broj dionica u portfelju 
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock portStock = null;
            Stock portStock1 = null;
            Portfolio porfo = null;
            int numShare;
            int numOnStock = 0;
            int newNumShare = 0;
            int shareInSpecificPort = 0;
            Stock newStock = new Stock();
            bool addStock = false;
            bool removeStock = false;
            bool ex = false;

            Portfolio po = new Portfolio(inPortfolioID);

            if (portfolioList.Count > 0)
            {
                foreach (Portfolio p in portfolioList)
                {
                    if (p.PortfolioIndex == inPortfolioID)
                        ex = true;
                }

                if (ex)
                {
                    // Provjerava koliko je dionica sa određenim imenom u svim portfolijima
                    numShare = portfolio.nOfStockInPortfolio(portfolioList, inStockName);

                    //Provjerava koliko ima dionica sa određenim imenom na burzi
                    if (stockList.Count > 0)
                    {
                        portStock1 = stock.getStockWithName(stockList, inStockName);
                        if (portStock1 != null)
                        {
                            numOnStock = (int)portStock1.Amount;
                        }
                    }

                    if ((numberOfShares + numShare) > numOnStock)
                    {
                        throw new StockExchangeException("There is no more stocks");
                    }
                    else
                    {
                        if (stockList.Count > 0)
                        {
                            portStock = stock.getStockWithName(stockList, inStockName);
                            if (portStock != null)
                            {
                                porfo = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);

                                if (porfo != null)
                                {
                                    if (porfo.PortfolioStockList.Count > 0)
                                    {
                                        foreach (Stock stockinPor in porfo.PortfolioStockList)
                                        {
                                            if (stockinPor.Name == inStockName)
                                            {
                                                shareInSpecificPort = (int)stockinPor.Amount;
                                                newNumShare = (int)stockinPor.Amount;
                                                newStock = stockinPor;
                                                removeStock = true;
                                                //porfo.PortfolioStockList.Remove(stockinPor);
                                                newNumShare += numberOfShares;
                                                newStock.Name = portStock.Name;
                                                newStock.Amount = numberOfShares + shareInSpecificPort;
                                                newStock.Date = portStock.Date;
                                                newStock.InitDate = portStock.InitDate;
                                                newStock.InitialPrice = portStock.InitialPrice;
                                                newStock.Price = portStock.Price;
                                                addStock = true;
                                            }
                                            else
                                            {
                                                newStock.Name = portStock.Name;
                                                newStock.Amount = numberOfShares + shareInSpecificPort;
                                                newStock.Date = portStock.Date;
                                                newStock.InitDate = portStock.InitDate;
                                                newStock.InitialPrice = portStock.InitialPrice;
                                                newStock.Price = portStock.Price;
                                                addStock = true;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        newStock.Name = portStock.Name;
                                        newStock.Amount = numberOfShares;
                                        newStock.Date = portStock.Date;
                                        newStock.InitDate = portStock.InitDate;
                                        newStock.InitialPrice = portStock.InitialPrice;
                                        newStock.Price = portStock.Price;
                                        addStock = true;
                                    }
                                }
                                else
                                    throw new StockExchangeException("Portfolio doesn't exsists");
                            }
                            else
                                throw new StockExchangeException("Stock doesn't exsits on stockMarket");
                        }
                        else
                            throw new StockExchangeException("StockList is empty!");
                    }
                }
                else
                    throw new StockExchangeException("Portfolio doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if(addStock && removeStock == false)
                porfo.PortfolioStockList.Add(newStock);
            else if (addStock && removeStock)
            {
                porfo.PortfolioStockList.Remove(newStock);
                porfo.PortfolioStockList.Add(newStock);
            }
        }

        // Briše određeni broj dionica iz portfelja 
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock portStock = null;
            Portfolio porfo = null;
            int numShare;
            int newNumShare = 0;
            Stock newStock = new Stock();
            Stock removeStock = null;
            bool removeStockBool = false;

            if (portfolioList.Count > 0)
            {
                numShare = portfolio.nOfStockInPortfolio(portfolioList, inStockName);
                if (numberOfShares >= numShare)
                {
                    throw new StockExchangeException("There is no more stocks");
                }
                else
                {
                    if (stockList.Count > 0)
                    {
                        portStock = stock.getStockWithName(stockList, inStockName);
                        if (portStock != null)
                        {
                            porfo = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
                            if (porfo != null)
                            {
                                if (porfo.PortfolioStockList.Count > 0)
                                {
                                    foreach (Stock stockinPor in porfo.PortfolioStockList)
                                    {
                                        if (stockinPor.Name == inStockName)
                                        {
                                            newNumShare = (int)stockinPor.Amount - numberOfShares;
                                            removeStockBool = true;
                                            //porfo.PortfolioStockList.Remove(stockinPor);
                                            removeStock = stockinPor;
                                        }
                                    }
                                }
                                else
                                {
                                    throw new StockExchangeException("No stock in portfolio");
                                }
                            }
                            else
                                throw new StockExchangeException("Portfolio doesn't exsists");
                        }
                        else
                            throw new StockExchangeException("Stock doesn't exsits on stockMarket");
                    }
                    else
                        throw new StockExchangeException("StockList is empty!");
                }
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if (removeStockBool)
            {
                if (newNumShare == 0)
                    porfo.PortfolioStockList.Remove(removeStock);
                else
                {
                    newStock.Amount = newNumShare;
                    newStock.Date = removeStock.Date;
                    newStock.InitDate = removeStock.InitDate;
                    newStock.InitialPrice = removeStock.InitialPrice;
                    newStock.Name = removeStock.Name;
                    newStock.Price = removeStock.Price;
                    porfo.PortfolioStockList.Remove(removeStock);
                    porfo.PortfolioStockList.Add(newStock);
                }
            }
        }

        // Briše dionicu iz portfelja 
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio porfo = null;

            Stock removeStock = null;
            bool removeStockBool = false;

            if (portfolioList.Count > 0)
            {
                porfo = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
                if (porfo != null)
                {
                    if (porfo.PortfolioStockList.Count > 0)
                    {
                        foreach (Stock stock1 in porfo.PortfolioStockList)
                        {
                            if (Regex.IsMatch(stock1.Name, inStockName, RegexOptions.IgnoreCase))
                            {
                                removeStock = stock1;
                                removeStockBool = true;
                            }
                        }
                    }
                    else
                        throw new StockExchangeException("Portfolio stackList is empty");
                }
                else
                    throw new StockExchangeException("Stock doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if (removeStockBool)
            {
                porfo.PortfolioStockList.Remove(removeStock);
            }
            
        }

        // Dohvaća broj portfelja na burzi
        public int NumberOfPortfolios()
        {
            int numOfPortfolios = 0;
            numOfPortfolios = portfolioList.Count;

            return numOfPortfolios;
        }

        // Dohvaća broj dionica u traženom portfelju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int numOfStocks = 0;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
                numOfStocks = portf.PortfolioStockList.Count;
            }
            else
                return 0;

            return numOfStocks;
        }

        // Provjerava postoji li traženi portfelj na burzi
        public bool PortfolioExists(string inPortfolioID)
        {
            bool exsists;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
                if (portf != null)
                {
                    exsists = true;
                }
                else
                    exsists = false;
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            return exsists;
        }

        // Provjerava nalazi li se dionica u portfelju
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            bool exsists = false;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
                if (portf != null)
                {
                    foreach (Stock stock1 in portf.PortfolioStockList)
                    {
                        if (Regex.IsMatch(stock1.Name, inStockName, RegexOptions.IgnoreCase))
                        {
                            exsists = true;
                            return true;
                        }
                        else
                            exsists = false;
                    }
                }
                else
                    throw new StockExchangeException("Portfolio doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            return exsists;
        }

        // Dohvaća broj dionice u traženom portfelj
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            int numOfStockShares = 0;
            Portfolio portf = null;

            portf = portfolio.getPortfolioWithName(portfolioList, inPortfolioID);
            if (portf != null)
            {
                foreach (Stock stock1 in portf.PortfolioStockList)
                {
                    if (Regex.IsMatch(stock1.Name, inStockName, RegexOptions.IgnoreCase))
                    {
                        numOfStockShares = (int)stock1.Amount;
                        return numOfStockShares;
                    }
                }
            }
            else
                throw new StockExchangeException("Portfolio doesn't exsists!");

            return numOfStockShares;
        }

        // Dohvaća vrijednost portfelja u određenom trenutku
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal sum = 0;
            Stock stockMin = null;

            List<decimal> array = new List<decimal>();
            int j = 0;

            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;
            fileDate = timeStamp;
            bool cal = false;
            bool changed = false;
            bool exs = false;

            foreach (Portfolio portfolio in portfolioList)
            {
                if (portfolio.PortfolioIndex == inPortfolioID)
                {
                    exs = true;
                    if (portfolio.PortfolioStockList.Count > 0)
                    {
                        if (portfolio.PortfolioStockList[j].Date.Count > 0)
                        {
                            stockMin = (Stock)portfolio.PortfolioStockList[j];
                            cal = true;
                        }

                        foreach (Stock stock1 in portfolio.PortfolioStockList)
                        {
                            if (changed)
                            {
                                stockMin = (Stock)portfolio.PortfolioStockList[j];
                                if (stockMin.Date.Count > 0)
                                    cal = true;
                            }

                            if (cal)
                            {
                                min = Math.Abs(fileDate.Ticks - stockMin.Date[0].Ticks);
                                foreach (DateTime date in stock1.Date)
                                {
                                    diff = Math.Abs(fileDate.Ticks - date.Ticks);

                                    if ((timeStamp.Ticks - stockMin.InitDate.Ticks) < (Math.Abs(timeStamp.Ticks - stock1.Date[0].Ticks)))
                                    {
                                        closestDate = stock1.InitDate;
                                        for (int i = 0; i < stock1.Amount; i++)
                                            sum += stock1.InitialPrice;

                                        return sum;
                                    }
                                    else if (diff <= min)
                                    {
                                        min = diff;
                                        closestDate = date;
                                    }
                                    indexOfDate = stock1.Date.IndexOf(closestDate);
                                }

                                foreach (decimal pr in stock1.Price)
                                {
                                    if (stock1.Price.IndexOf(pr) == indexOfDate)
                                    {
                                        for (int i = 0; i < stock1.Amount; i++)
                                            sum += pr;
                                    }
                                }

                                cal = false;
                                changed = false;
                            }

                            else
                            {
                                j++;
                                for (int k = 0; k < stock1.Amount; k++)
                                    sum += stock1.InitialPrice;
                                changed = true;
                            }
                        }
                    }
                    else
                        return 0;
                }
            }

            if(exs == false)
                throw new StockExchangeException("Portfolio doesn't exsists");
            
            return sum;
        }

        // Dohvaća mjeseću promjenu vrijednosti portfelja
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal sum = 0;
            Stock stockMin = null;

            List<decimal> array = new List<decimal>();
            int j = 0;

            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;
            bool hasInitDate = false;
            bool changed = false;
            bool ex = false;
            decimal cijenaPrvog = 0;
            decimal cijenaZadnjeg = 0;
            decimal cijena = 0;

            foreach (Portfolio portfolio in portfolioList)
            {
                if (portfolio.PortfolioIndex == inPortfolioID)
                {
                    ex = true;
                    if (portfolio.PortfolioStockList.Count > 0)
                    {
                        foreach (Stock stock in portfolio.PortfolioStockList)
                        {
                            if (stock.InitDate.Year == Year && stock.InitDate.Month == Month)
                            {
                                if (stock.InitDate.Date.Day == 30 || stock.InitDate.Date.Day == 31)
                                {
                                    cijenaPrvog = stock.InitialPrice;
                                    hasInitDate = true;
                                }
                                else
                                    throw new StockExchangeException("Nije definirana cijena!");
                            }

                            if (stock.Date.Count > 0)
                            {
                                foreach (DateTime da in stock.Date)
                                {
                                    if (da.Year == Year && da.Month == Month)
                                    {
                                        if (stock.InitDate.Date.Day == 30 || stock.InitDate.Date.Day == 31)
                                        {
                                            if (!hasInitDate)
                                            {
                                                cijenaPrvog = stock.Price[j];
                                                hasInitDate = false;
                                            }
                                            cijenaZadnjeg = stock.Price[j];

                                            j++;
                                        }
                                    }
                                    else
                                        throw new StockExchangeException("Nije definirana cijena!");
                                }
                            }
                            if (j == 1)
                                cijena += cijenaPrvog;
                            else
                                cijena += ((cijenaZadnjeg - cijenaPrvog) / cijenaPrvog) * 100;
                            cijenaPrvog = 0;
                            cijenaZadnjeg = 0;
                            j = 0;
                        }
                    }

                    else
                        return 0;
                }
            }

            if (!ex)
                throw new StockExchangeException("Portfolio doesn't exsists!");
            
            return cijena;
        }

        #endregion
    }
}