﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        //konstante
        public static String ERROR = "-E-";
        public static int MAX_DIGITS = 10;


        private string _displayState;
        private double _currentOperand;
        private double _lastOperand;
        private bool _readyForDisplayClear = false;
        private string _operandInMemory;
        private IBinarOperation _lastOperation;
        private Dictionary<char, IBinarOperation> binarOperations;


        public static void Main()
        {
        }

        public Kalkulator()
        {
            _displayState = "0";
            binarOperations = new Dictionary<char, IBinarOperation>();
            binarOperations.Add('+', new Plus());
            binarOperations.Add('-', new Minus());
            binarOperations.Add('*', new Multiply());
            binarOperations.Add('/', new Division());
        }

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '+':
                case '-':
                case '*':
                case '/':
                    HandleBinaryOperator(inPressedDigit);
                    break;
                case '=':
                    Calculate();
                    break;
                case ',':
                    AddDecimalPoint();
                    break;
                case 'M':
                    SwitchSign();
                    break;
                case 'S':
                    ApplySinus();
                    break;
                case 'K':
                    ApplyCosinus();
                    break;
                case 'T':
                    ApplyTangens();
                    break;
                case 'Q':
                    Square();
                    break;
                case 'R':
                    ApplyRoot();
                    break;
                case 'I':
                    ApplyInverse();
                    break;
                case 'P':
                    PutInMemory();
                    break;
                case 'G':
                    GetFromMemory();
                    break;
                case 'C':
                    ClearScreen();
                    break;
                case 'O':
                    ResetCalc();
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    HandleDigit(inPressedDigit);
                    break;
                default:
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return _displayState;
        }


        //privatne metode

        private void HandleBinaryOperator(char inPressedDigit)
        {
            if (_lastOperation != null && !_readyForDisplayClear)
            {
                _lastOperand = _lastOperation.execute(_lastOperand, _currentOperand);
                _displayState = _lastOperand.ToString();
                _currentOperand = _lastOperand;
                _readyForDisplayClear = true;
            }
            else
            {
                _lastOperand = _currentOperand;
            }
            _lastOperation = binarOperations[inPressedDigit];
            _readyForDisplayClear = true;
        }

        private void HandleDigit(char digit)
        {
            if (_displayState.Count(Char.IsDigit) == MAX_DIGITS && !_readyForDisplayClear) return;
            if (_readyForDisplayClear)
            {
                _displayState = "";
                _readyForDisplayClear = false;
            }
            _displayState += digit;
            _currentOperand = Double.Parse(_displayState);
            _displayState = _currentOperand.ToString();
        }

        private void ApplyInverse()
        {
            _displayState = _currentOperand == 0.0 ? ERROR : (1 / _currentOperand).ToString();
        }

        private void SwitchSign()
        {
            _displayState = "-" + _displayState;
        }

        private void Calculate()
        {
            if (_lastOperation != null)
            {
                try
                {
                    _currentOperand = _lastOperation.execute(_lastOperand, _currentOperand);
                    _displayState = _currentOperand.ToString();
                }
                catch (ArgumentException)
                {
                    _displayState = ERROR;
                }
            }
        }

        private void ApplyRoot()
        {
            _currentOperand = Math.Round(Math.Sqrt(_currentOperand), 9);
            _displayState = _currentOperand.ToString();
        }

        private void ApplyTangens()
        {
            _currentOperand = Math.Round(Math.Tan(_currentOperand), 9);
            _displayState = _currentOperand.ToString();
        }

        private void ApplyCosinus()
        {
            _currentOperand = Math.Round(Math.Cos(_currentOperand), 9);
            _displayState = _currentOperand.ToString();
        }

        private void ApplySinus()
        {
            _currentOperand = Math.Round(Math.Sin(_currentOperand), 9);
            _displayState = _currentOperand.ToString();
        }

        private void GetFromMemory()
        {
            _displayState = _operandInMemory;
        }

        private void Square()
        {
            _currentOperand = Math.Pow(_currentOperand, 2);
            _displayState = _currentOperand.ToString();
        }

        private void PutInMemory()
        {
            _operandInMemory = _displayState;
        }

        private void AddDecimalPoint()
        {
            _displayState += ',';
        }

        private void ClearScreen()
        {
            _displayState = "0";
            _currentOperand = 0.0;
        }

        private void ResetCalc()
        {
            _displayState = "0";
            _lastOperation = null;
            _lastOperand = 0.0;
        }
    }


    //sučelje za operacije +, -, *, /
    public interface IBinarOperation
    {
        double execute(double a, double b);
    }

    public class Plus : IBinarOperation
    {
        public double execute(double a, double b)
        {
            double result = a + b;
            if (result.ToString().Count(Char.IsDigit) > 10)
            {
                throw new ArgumentException("Result is bigger than allowed!");
            }
            return result;
        }
    }

    public class Minus : IBinarOperation
    {
        public double execute(double a, double b)
        {
            double result = a - b;
            if (result.ToString().Count(Char.IsDigit) > 10)
            {
                throw new ArgumentException("Result is bigger than allowed!");
            }
            return result;
        }
    }

    public class Multiply : IBinarOperation
    {
        public double execute(double a, double b)
        {
            double result = a * b;
            if (result.ToString().Count(Char.IsDigit) > 10)
            {
                throw new ArgumentException("Result is bigger than allowed!");
            }
            return result;
        }
    }

    public class Division : IBinarOperation
    {
        public double execute(double a, double b)
        {
            double result = a / b;
            if (result.ToString().Count(Char.IsDigit) > 10)
            {
                throw new ArgumentException("Result is bigger than allowed!");
            }
            return result;
        }
    }

}