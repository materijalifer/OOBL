﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public Broj prosliBroj = new Broj(0);
        public Broj trenutniBroj = new Broj(0);
        public Broj displayBroj = new Broj(0);
        public Broj memorija = new Broj(0);
        private int zadnjiUnos = 0;

        public BinarnaOperacija zadnjaOperacija = new BinarnaOperacija('+');

        public Kalkulator()
        {
            displayBroj = new Broj(0);
        }

        public void Press(char inPressedDigit)
        {
            Tipka tipka = new Tipka(inPressedDigit);

            if (tipka.UnarnaOperacija)
            {
                if (zadnjiUnos == 1)
                {
                    displayBroj.IzvrsiUnarnuOperaciju(tipka.TipkaChar);
                    return;
                }
                trenutniBroj.IzvrsiUnarnuOperaciju(tipka.TipkaChar);

                displayBroj = trenutniBroj.Copy();
                zadnjiUnos = 5;
            }

            // Za nadodavanje znamenke.
            if (tipka.JeZnamenka)
            {
                zadnjiUnos = 4;
                trenutniBroj.DodajZnamenku(tipka);
                displayBroj = trenutniBroj.Copy(); ;
            }

            //Za nadodavanje zareza.
            if (tipka.JeZarez)
            {
                zadnjiUnos = 3;
                trenutniBroj.DodajZarez();
                displayBroj = trenutniBroj.Copy();
            }
            
            // Izračunaj --> samo ako nisu unesene 2 binarne operacije zaredom
            if (tipka.JeJednako || (tipka.BinarnaOperacija && zadnjiUnos != 1 && zadnjiUnos != 2))
            {
                if (tipka.JeJednako && (zadnjiUnos == 1 || zadnjiUnos == 2))
                {
                    
                    prosliBroj.IzvrsiBinarnuOperaciju(prosliBroj.Vrijednost, zadnjaOperacija.TipOperacije);
                }
                else
                {
                    prosliBroj.IzvrsiBinarnuOperaciju(trenutniBroj.Vrijednost, zadnjaOperacija.TipOperacije);
                    trenutniBroj = new Broj(0);   
                }
            }

            // Samo pamti da nije zadnji unos binarana operacija
            if (tipka.JeJednako)
            {
                zadnjiUnos = 2;
                displayBroj = prosliBroj.Copy();
            }

            // Pamti da je zadnji unos binarna operacija, zapamti koja i izradi novi broj za unos
            if (tipka.BinarnaOperacija)
            {
                
                zadnjiUnos = 1;
                zadnjaOperacija = new BinarnaOperacija(inPressedDigit);
                //trenutniBroj = new Broj(0);
            }


            if (tipka.TipkaChar == 'P')
            {
                zadnjiUnos = 6;
                memorija = displayBroj.Copy();
                //displayBroj = new Broj(0);
                
            }

            if (tipka.TipkaChar == 'G')
            {
                zadnjiUnos = 7;
                displayBroj = memorija.Copy();
                trenutniBroj = memorija.Copy();
            }

            if (tipka.TipkaChar == 'O')
            {
                zadnjiUnos = 8;
                trenutniBroj = new Broj(0);
                prosliBroj = new Broj(0);
                displayBroj = new Broj(0);
                memorija = new Broj(0);
            }

            if (tipka.TipkaChar == 'C')
            {
                zadnjiUnos = 9;
                trenutniBroj = new Broj(0);
                displayBroj = new Broj(0);
            }
            //throw new NotImplementedException();
        }

        public string GetCurrentDisplayState()
        {
            // Zamjeni decimalnu točku sa decimalnim zarezom

            // Ispiši maksimalno 10 znamenaka
            if (displayBroj.Vrijednost >= 10000000000)
            {
                return "-E-";
            }

            if (displayBroj.String() == "Infinity")
            {
                return "-E-";
            }
            return displayBroj.String();
            //throw new NotImplementedException();
        }
    }

    public class Broj
    {
        private double vrijednost;
        private string vrijednostString;
        private bool korisnikovUnos = true;
        private bool convertedToDouble = true;
        private int brojDecimala = 0;

        public Broj(double vrijednost)
        {
            this.vrijednost = vrijednost;
        }

        public Broj Copy()
        {
            Broj vrati = new Broj(0);
            vrati.vrijednost = vrijednost;
            vrati.korisnikovUnos = korisnikovUnos;
            vrati.convertedToDouble = convertedToDouble;
            vrati.brojDecimala = brojDecimala;

            return vrati;
        }

        public void IzvrsiUnarnuOperaciju(char value)
        {
            korisnikovUnos = false;
            UnarnaOperacija operacija = new UnarnaOperacija(value);

            switch (operacija.TipOperacije)
            {
                case TipUnarneOperacije.PromjenaPredznaka:
                    this.PromijeniPredznak();
                    break;

                case TipUnarneOperacije.Sinus:
                    this.Sinus();
                    break;
                
                case TipUnarneOperacije.Kosinus:
                    this.Kosinus();
                    break;

                case TipUnarneOperacije.Tangens:
                    this.Tangens();
                    break;

                case TipUnarneOperacije.Kvadriranje:
                    this.Kvadriranje();
                    break;

                case TipUnarneOperacije.Korjenovanje:
                    this.Korijenovanje();
                    break;

                case TipUnarneOperacije.Inverz:
                    this.Reciprocan();
                    break;
            }

            odreziVisakDecimala();
        }

        public void IzvrsiBinarnuOperaciju(double broj, TipBinarneOperacije tipOperacije)
        {
            korisnikovUnos = false;

            switch (tipOperacije)
            {
                case TipBinarneOperacije.Zbrajanje:
                    this.Zbroji(broj);
                    break;

                case TipBinarneOperacije.Oduzimanje:
                    this.Oduzmi(broj);
                    break;
                    
                case TipBinarneOperacije.Mnozenje:
                    this.Pomnozi(broj);
                    break;

                case TipBinarneOperacije.Dijeljenje:
                    this.Podijeli(broj);
                    break;
            }

            odreziVisakDecimala();
        }

        private void odreziVisakDecimala()
        {
            if (vrijednost >= 1000000000)
            {

                // GREŠKAAAAAAAAAAAAAA više od 10 znamenaka
            }
            else
            {
                string vrijed = vrijednost.ToString();
                if (vrijed.Contains(","))
                {
                    int cijelihZnamenaka = vrijed.Replace("-", "").IndexOf(",");
                    int decimalnihTreba = 10 - cijelihZnamenaka;
                    vrijednost = Math.Round(vrijednost, decimalnihTreba);
                }
            }
        }

        public string String()
        {
            if (!convertedToDouble)
            {
                return vrijednostString;
            }
            else
            {
                if (korisnikovUnos)
                {
                    if (brojDecimala == 0)
                    {
                        return vrijednost.ToString("F0");
                    }
                    else
                        if (brojDecimala == 1)
                        {
                            return vrijednost.ToString("F0") + ',';
                        }
                    return vrijednost.ToString("F" + (brojDecimala - 1).ToString());
                }
                
                string vrijed = vrijednost.ToString();
                int pozicija = 10;
                if (vrijed.Contains('-'))
                    pozicija++;

                if (vrijed.Contains(','))
                    pozicija++;

                if (vrijednost.ToString() == "Infinity")
                {
                    return "-E-";
                }
                string vrati = vrijednost.ToString("F10").Substring(0, pozicija);
                int toRemove = 0;
                if (vrati.Contains(','))
                {
                    foreach (char slovo in vrati.Reverse())
                    {
                        if (slovo == '0')
                        {
                            toRemove++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                vrati = vrati.Substring(0,vrati.Length-toRemove);

                if (vrati[vrati.Length - 1] == ',')
                {
                    vrati = vrati.Substring(0, vrati.Length - 1);
                }

                return vrati;

            }
        }

        public void DodajZnamenku(Tipka tipka)
        {
            double znamenka = double.Parse(tipka.TipkaChar.ToString());
            if (vrijednost.ToString().Replace(",", "").Replace("-", "").Length == 10)
            {
                return;
            }


            if (brojDecimala == 0)
            {
                vrijednost = vrijednost * 10;
            }
            else
            {
                znamenka = Math.Pow(10, ((-1)*brojDecimala)) * znamenka ;
                brojDecimala++;

            }

            if (vrijednost >= 0)
            {
                vrijednost += znamenka;
            }
            else
            {
                vrijednost -= znamenka;
            }
        }

        public void DodajZarez()
        {
            brojDecimala = 1;
        }

        public bool Pozitivan
        {
            get
            {
                if (vrijednost >= 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public double Vrijednost
        {
            get
            {
                vrijednost = Math.Round(vrijednost, 10);
             /*   
                if (vrijednostString.Contains(','))
                {
                    vrijednostString = vrijednostString.Replace("-", "");

                    if (vrijednostString.Length > 12)
                    {
                        vrijednostString = vrijednostString.Remove(12);

                        vrijednost = double.Parse(vrijednostString);
                    }

                    if (vrijednost < 0)
                    {
                        vrijednostString = "-" + vrijednostString;
                    }
                }    */            
                return this.vrijednost;
            }
            set
            {
                this.vrijednost = value;
            }
        }

        #region Operacije
        private double Zbroji(double broj)
        {
            
            vrijednost += broj;
            return broj;
        }

        private double Oduzmi(double broj)
        {
            vrijednost -= broj;
            return vrijednost;
        }

        private double Pomnozi(double broj)
        {
            vrijednost *= (broj *1.0);
            return vrijednost;
        }

        private double Podijeli(double broj)
        {
            vrijednost /= (broj * 1.0);
            return vrijednost;
        }

        private double PromijeniPredznak()
        {
            this.vrijednost *= -1;
            return this.vrijednost;
        }

        private double Sinus()
        {
            this.vrijednost = Math.Sin(this.vrijednost);
            return this.vrijednost;
        }

        private double Kosinus()
        {
            this.vrijednost = Math.Cos(this.vrijednost);
            return this.vrijednost;
        }

        private double Tangens()
        {
            this.vrijednost = Math.Tan(this.vrijednost);
            return this.vrijednost;
        }

        private double Kvadriranje()
        {
            this.vrijednost = Math.Pow(this.vrijednost, 2);
            return this.vrijednost;
        }

        private double Korijenovanje()
        {
            this.vrijednost = Math.Sqrt(this.vrijednost);
            return this.vrijednost;
        }

        private double Reciprocan()
        {
            this.vrijednost = (double) 1 / this.vrijednost;
            return Vrijednost;
        }
        #endregion

    }

    public enum TipBinarneOperacije
    {
        Zbrajanje = 1,
        Mnozenje,
        Dijeljenje,
        Oduzimanje,
        Nepoznato
    };

    public class BinarnaOperacija
    {
        private char value;

        public BinarnaOperacija(char value)
        {
            this.value = value;
        }

        public TipBinarneOperacije TipOperacije
        {
            get{
                if (value == '+')
                {
                    return TipBinarneOperacije.Zbrajanje;
                }
                if (value == '*')
                {
                    return TipBinarneOperacije.Mnozenje;
                }
                if (value == '/'){
                    return TipBinarneOperacije.Dijeljenje;
                }
                if (value == '-')
                {
                    return TipBinarneOperacije.Oduzimanje;
                }
                return TipBinarneOperacije.Nepoznato;
            }
        }
    }

    public enum TipUlaza
    {
        Znamenka = 1,
        Zarez,
        BinarnaOperacija,
        UnarnaOperacija
    }

    public enum TipUnarneOperacije
    {
        PromjenaPredznaka = 1,
        Sinus,
        Kosinus,
        Tangens,
        Kvadriranje,
        Korjenovanje,
        Inverz,
        Nista
    }

    public class UnarnaOperacija
    {
        private char value;

        public UnarnaOperacija (char value)
        {
            this.value = value;
        }

        public TipUnarneOperacije TipOperacije
        {
            get
            {
                if (this.value == 'M')
                {
                    return TipUnarneOperacije.PromjenaPredznaka;
                }

                if (this.value == 'S')
                {
                    return TipUnarneOperacije.Sinus;
                }

                if (this.value == 'K')
                {
                    return TipUnarneOperacije.Kosinus;
                }

                if (this.value == 'T')
                {
                    return TipUnarneOperacije.Tangens;
                }

                if (this.value == 'Q')
                {
                    return TipUnarneOperacije.Kvadriranje;
                }

                if (this.value == 'R')
                {
                    return TipUnarneOperacije.Korjenovanje;
                }

                if (this.value == 'I')
                {
                    return TipUnarneOperacije.Inverz;
                }

                return TipUnarneOperacije.Nista;
            }

        }
    }

    public class Tipka
    {
        private char tipka;

        public Tipka(char tipka)
        {
            this.tipka = tipka;
        }

        public char TipkaChar
        {
            get
            {
                return this.tipka;
            }
        }

        public int TipkaInt
        {
            get
            {
                return (int)this.tipka;
            }
        }

        public bool BinarnaOperacija
        {
            get
            {
                if (tipka == '*' || tipka == '+' || tipka == '-' || tipka == '/')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool UnarnaOperacija
        {
            get
            {
                if (tipka == 'S' || tipka == 'M' || tipka == 'K' || tipka == 'T' || tipka == 'Q' || tipka == 'R' || tipka == 'I')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool MemorijskaOperacija
        {
            get
            {
                if (tipka == 'P' || tipka == 'G')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool BrisanjeEkrana
        {
            get{
                if (tipka == 'C')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ResetKalkulatora
        {
            get
            {
                if (tipka == 'O')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool JeJednako
        {
            get
            {
                if (tipka == '=')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool JeZnamenka
        {
            get
            {
                if (TipkaInt >= 48 && TipkaInt <= 57)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool JeZarez
        {
            get
            {
                if (tipka == ',')
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public int Znamenka
        {
            get
            {
                if (JeZnamenka)
                {
                    return TipkaInt - 48;
                }
                else
                {
                    return -1;
                }
            }
        }
    }

    public class Memorija
    {
        private Broj pohranjenaVrijednost;

        public bool SadrziVrijednost
        {
            get
            {
                if (pohranjenaVrijednost != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public Broj Vrijednost
        {
            get
            {
                return this.pohranjenaVrijednost;
            }
        }

        public void PohraniVrijednost(Broj broj)
        {
            this.pohranjenaVrijednost = broj;
        }
    }
}
