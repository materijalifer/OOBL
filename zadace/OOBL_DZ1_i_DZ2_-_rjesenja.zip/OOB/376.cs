﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string _id;
        long _numberOfShares;
        SortedList<DateTime, decimal> _priceAtTime;

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="inStockName">Ime dionice</param>
        /// <param name="inNumberOfShares">Broj dionica</param>
        /// <param name="inInitialPrice">Inicijalna cijena</param>
        /// <param name="inTimeStamp">Vrijeme zadavanja cijene</param>
        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Number of shares is <=0!");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Initial price is <=0!");
             
            _priceAtTime = new SortedList<DateTime, decimal>();
            _id = stringToId(inStockName);
            _numberOfShares = inNumberOfShares;
            _priceAtTime.Add(inTimeStamp, inInitialPrice);
        }

        /// <summary>
        /// Static metoda za predvaranje imena dionice u kljuc
        /// </summary>
        /// <param name="stockName">Ime dionice</param>
        /// <returns>Kljuc dionice</returns>
        public static string stringToId(string stockName)
        {
            return stockName.ToLower();
        }

        /// <summary>
        /// Dohvati Id dionice
        /// </summary>
        public string Id
        {
            get { return _id; }
        }

        /// <summary>
        /// Dohvati broj dionica
        /// </summary>
        public long NumberOfShares
        {
            get
            {
                return _numberOfShares;
            }
        }

        /// <summary>
        /// Dodaje se cijena za odredjeno vrijeme
        /// </summary>
        /// <param name="time">Vrijeme</param>
        /// <param name="value">Cijena</param>
        public void addTimePrice(DateTime time, decimal value)
        {
            if (_priceAtTime.ContainsKey(time))
                throw new StockExchangeException("For this time value is already set!");
            if(value<=0)
                throw new StockExchangeException("Price is <=0!");
            _priceAtTime.Add(time, value);
        }

        /// <summary>
        /// Dohvati cijenu za odredjeno vrijeme
        /// </summary>
        /// <param name="time">Vrijeme</param>
        /// <returns>Cijena</returns>
        public decimal getTimePrice(DateTime time)
        {
            if (_priceAtTime.First().Key > time)
                throw new StockExchangeException("Time is smaller than initial time!");

            decimal ret = 0;
            foreach(KeyValuePair<DateTime, decimal> timeValue in _priceAtTime)
            {
                if (timeValue.Key <= time)
                    ret = timeValue.Value;
            }
            
            return ret;
        }

        /// <summary>
        /// Dohvati incijalnu cijenu - po vremenu prva cijena (ne mora biti ista kao i u konstruktoru)
        /// </summary>
        /// <returns>Inicijalna cijena</returns>
        public decimal getInitialPrice()
        {
            return _priceAtTime.First().Value;
        }

        /// <summary>
        /// Dohvati zadnju cijenu po vremenu
        /// </summary>
        /// <returns>Cijena</returns>
        public decimal getLastPrice()
        {
            return _priceAtTime.Last().Value;
        }
    }

    public abstract class Index
    {
        protected string _id;
        protected Dictionary<string, Stock> _stockSet;

        /// <summary>
        /// Konstruktor
        /// </summary>
        public Index()
        { 
            _stockSet = new Dictionary<string,Stock>();
        }

        /// <summary>
        /// Static metoda koja pretvara ime indeksa u kljuc
        /// </summary>
        /// <param name="indexName">Ime indeksa</param>
        /// <returns>Kljuc</returns>
        public static string stringToId(string indexName)
        {
            return indexName.ToLower();
        }

        /// <summary>
        /// Dohvati Id indeksa
        /// </summary>
        public string Id
        {
            get
            {
                return _id;
            }
        }

        /// <summary>
        /// Dodavanje dionice u indeks
        /// </summary>
        /// <param name="newStock">Dionica</param>
        public void addStock(Stock newStock)
        {
            if (_stockSet.ContainsKey(newStock.Id))
                throw new StockExchangeException("Stock is already in index!");
            _stockSet.Add(newStock.Id, newStock);
        }

        /// <summary>
        /// Brisanje dionice iz indeksa
        /// </summary>
        /// <param name="oldStock">Dionica koja se brise</param>
        public void removeStock(Stock oldStock)
        {
            if (!_stockSet.ContainsKey(oldStock.Id))
                throw new StockExchangeException("Stock is not in index!");
            _stockSet.Remove(oldStock.Id);
        }

        /// <summary>
        /// Provjera da li je dionica u indeksu
        /// </summary>
        /// <param name="checkStock">Dionica</param>
        /// <returns>Vraca true ako je, inace false</returns>
        public bool isStockIn(Stock checkStock)
        {
            if (_stockSet.ContainsKey(checkStock.Id))
                return true;
            return false;
        }

        /// <summary>
        /// Dohvaca se broj dionica u indeksu
        /// </summary>
        /// <returns>Broj dionica</returns>
        public int getNumOfStocks()
        {
            return _stockSet.Count;
        }

        public abstract decimal getIndexValue(DateTime priceTime);
    }

    public class AverageIndex : Index
    { 
        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="indexName">Ime indeksa</param>
        public AverageIndex(string indexName)
        {
            _id = Index.stringToId(indexName);
        }

        /// <summary>
        /// Racuna se vrijednost indeksa (AVERAGE) za odredjeno vrijeme
        /// </summary>
        /// <param name="priceTime">Vrijeme</param>
        /// <returns>Vrijednost indeksa</returns>
        public override decimal getIndexValue(DateTime priceTime)
        {
            decimal ret = 0;
            
            foreach (KeyValuePair<string, Stock> stockIter in _stockSet)
            {
                ret += stockIter.Value.getTimePrice(priceTime);    
            }

            if (_stockSet.Count != 0) 
                ret /= _stockSet.Count;
            
            return decimal.Round(ret, 3);
        }
    }

    public class WeightedIndex : Index
    { 
        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="indexName">Ime indeksa</param>
        public WeightedIndex(string indexName)
        {
            _id = Index.stringToId(indexName);
        }


        /// <summary>
        /// Racuna se vrijednost indeksa (WEIGHTED) za odredjeno vrijeme
        /// </summary>
        /// <param name="priceTime">Vrijeme</param>
        /// <returns>Vrijednost indeksa</returns>
        public override decimal getIndexValue(DateTime priceTime)
        {
            decimal ret = 0;
            decimal sum = 0;

            foreach (KeyValuePair<string, Stock> stockIter in _stockSet)
            {
                sum += stockIter.Value.getTimePrice(priceTime)*stockIter.Value.NumberOfShares;
            }
            
            decimal tmpTimePrice;
            decimal tmpNumberOf;
            foreach (KeyValuePair<string, Stock> stockIter in _stockSet)
            {
                tmpTimePrice = stockIter.Value.getTimePrice(priceTime);
                tmpNumberOf = Convert.ToDecimal(stockIter.Value.NumberOfShares);
                ret += tmpTimePrice*(tmpTimePrice*tmpNumberOf)/sum;
            }

            return decimal.Round(ret, 3);
        }
    }

    public class Portfolio
    {
        private static Dictionary<string, long> _stockCounter;

        /// <summary>
        /// Inicjalizacija portfolia, potrebno je uvijek napraviti kada se pokrece aplikacija
        /// </summary>
        public static void Init()
        {
            _stockCounter = new Dictionary<string, long>();
        }

        /// <summary>
        /// Static metoda za dohvacanje broja vrsta dionica u svim portfolima zajedno
        /// </summary>
        /// <param name="findStock">Dionica</param>
        /// <returns>Broj dionica</returns>
        private static long getStockCounter(Stock findStock) 
        {
            if (!_stockCounter.ContainsKey(findStock.Id))
                return 0;
            return _stockCounter[findStock.Id];
        }

        /// <summary>
        /// Static metoda koja povecava brojace za dionice, gdje se prati broj dionica
        /// </summary>
        /// <param name="findStock">Dionica</param>
        /// <param name="numberOfShares">Broj pojedinacnih dionica</param>
        private static void setStockCounter(Stock findStock, long numberOfShares)
        {
            if (!_stockCounter.ContainsKey(findStock.Id))
                _stockCounter[findStock.Id] = numberOfShares;
            else
                _stockCounter[findStock.Id] += numberOfShares;
        }

        /// <summary>
        /// Static metoda koja smanjuje broj dionica, gdje se prati broj dionica
        /// </summary>
        /// <param name="findStock">Dionica</param>
        /// <param name="numberOfShares">Broj pojedinacnih dionica</param>
        private static void removeStockCounter(Stock findStock, long numberOfShares)
        {
            _stockCounter[findStock.Id] -= numberOfShares;
            if (_stockCounter[findStock.Id] == 0)
                _stockCounter.Remove(findStock.Id);
        }

        private string _id;
        private Dictionary<string, long> _numberOfStockShares;

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="Portfolio"></param>
        public Portfolio(string Portfolio)
        {
            _id = Portfolio;
            _numberOfStockShares = new Dictionary<string, long>();
        }

        /// <summary>
        /// Dodaje se dionica u portfolio
        /// </summary>
        /// <param name="newStock">Dionica</param>
        /// <param name="numberOfShares">Broj pojedinacnih dionica</param>
        public void addStock(Stock newStock, long numberOfShares)
        {
            if (newStock.NumberOfShares < numberOfShares + getStockCounter(newStock))
                throw new StockExchangeException("To much shares for stock!");

            setStockCounter(newStock, numberOfShares);
            
            if (!_numberOfStockShares.ContainsKey(newStock.Id))
                _numberOfStockShares.Add(newStock.Id, numberOfShares);
            else
                _numberOfStockShares[newStock.Id] += numberOfShares;
        }

        /// <summary>
        /// Brisanje dionice s portfolia
        /// </summary>
        /// <param name="oldStock">Dionica</param>
        /// <param name="numberOfShares">Broj pojedinacnih dionica</param>
        public void removeStock(Stock oldStock, long numberOfShares)
        {
            if (!_numberOfStockShares.ContainsKey(oldStock.Id))
              throw new StockExchangeException("Stock doesn't exists in portfolio!");
            
            numberOfShares = Math.Min(numberOfShares, _numberOfStockShares[oldStock.Id]);
        
            if (_numberOfStockShares[oldStock.Id] <= numberOfShares)
                _numberOfStockShares.Remove(oldStock.Id);
            else
                _numberOfStockShares[oldStock.Id] -= numberOfShares;

            removeStockCounter(oldStock, numberOfShares);
        }

        /// <summary>
        /// Brisanje dionice s portfolia, brisu se sve pojedinacne
        /// </summary>
        /// <param name="oldStock">Dionica</param>
        public void removeStock(Stock oldStock)
        {
            if (!_numberOfStockShares.ContainsKey(oldStock.Id))
                throw new StockExchangeException("Stock doesn't exists in portfolio!");

            long numberOfShares = numberOfSharesOfStock(oldStock);

            _numberOfStockShares.Remove(oldStock.Id);
            removeStockCounter(oldStock, numberOfShares);
        }

        /// <summary>
        /// Dohvaca se broj dionica
        /// </summary>
        /// <returns>Broj dionica</returns>
        public int numberOfStocks()
        {
            return _numberOfStockShares.Count;
        }

        /// <summary>
        /// Provjera da li je dionica u portfoliu
        /// </summary>
        /// <param name="findStock">Dionica</param>
        /// <returns>Ako je dionica unutra vraca true inace false</returns>
        public bool isStockIn(Stock findStock)
        {
            if (_numberOfStockShares.ContainsKey(findStock.Id))
                return true;
            return false;
        }

        /// <summary>
        /// Dohvaca se broj pojedinacnih dionica u portfoliu
        /// </summary>
        /// <param name="findStock">Dionica</param>
        /// <returns>Broj pojedinacnih dionica</returns>
        public long numberOfSharesOfStock(Stock findStock)
        {
            if (!_numberOfStockShares.ContainsKey(findStock.Id))
                return 0;
            return _numberOfStockShares[findStock.Id];
        }

        /// <summary>
        /// Dohvaca se vrijednost portfolia u odredjenu vremenu
        /// </summary>
        /// <param name="timeStamp">Vrijeme</param>
        /// <param name="stockSet">Skup dionica</param>
        /// <returns>Vrijednost portfolia</returns>
        public decimal getValue(DateTime timeStamp, Dictionary<string, Stock> stockSet)
        {
            decimal ret = 0;
            foreach (KeyValuePair<string, long> stockIter in _numberOfStockShares)
            {
                ret += stockIter.Value * stockSet[stockIter.Key].getTimePrice(timeStamp);
            }
            return decimal.Round(ret, 3);
        }

        /// <summary>
        /// Postotna mjesecna promijena
        /// </summary>
        /// <param name="Year">Godina</param>
        /// <param name="Month">Mjesec</param>
        /// <param name="_stockSet">Skup dionica</param>
        /// <returns>Vrijednos posotne mjesecne promijene</returns>
        public decimal getPercentChangeInValueForMonth(int Year, int Month, Dictionary<string, Stock>  _stockSet)
        {
            if (Year < 0)
                throw new StockExchangeException("Invalid Year value!");
            
            if (Month <= 0 || Month > 12)
                throw new StockExchangeException("Invalid Month value!");

            if (_numberOfStockShares.Count == 0) 
                return 0;

            DateTime beginOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime endOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            decimal ret = getValue(endOfMonth, _stockSet) - getValue(beginOfMonth, _stockSet);
            ret /= getValue(beginOfMonth, _stockSet);
            ret *= 100;
            return decimal.Round(ret, 3);
        }
    }

     public class StockExchange : IStockExchange
     {
         //skup dionica
         private Dictionary<string, Stock> _stockSet;
         
         //skup indeksa
         private Dictionary<string, Index> _indexSet;
         
         //skup portfolia
         private Dictionary<string, Portfolio> _portfolioSet;

         public StockExchange()
         {
             _stockSet = new Dictionary<string, Stock>();
             _indexSet = new Dictionary<string, Index>();
             _portfolioSet = new Dictionary<string, Portfolio>();
             Portfolio.Init(); //obavezan poziv inicjalizacije portfolia
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock id already exist!");
             
             Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             _stockSet.Add(Stock.stringToId(inStockName), newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("This stock id doesn't exist!");

             Stock dStock = _stockSet[(Stock.stringToId(inStockName))];

             foreach (KeyValuePair<string, Index> indexIter in _indexSet)
             { 
                if (indexIter.Value.isStockIn(dStock))
                    indexIter.Value.removeStock(dStock);
             }
             
             foreach (KeyValuePair<string, Portfolio> portfolioIter in _portfolioSet)
             { 
                if (portfolioIter.Value.isStockIn(dStock))
                    portfolioIter.Value.removeStock(dStock);
             }

             _stockSet.Remove(Stock.stringToId(inStockName));
         }

         public bool StockExists(string inStockName)
         {
             return _stockSet.ContainsKey(Stock.stringToId(inStockName));
         }

         public int NumberOfStocks()
         {
             return _stockSet.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");
             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             stockRef.addTimePrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");
             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             return stockRef.getTimePrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");
             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             return stockRef.getInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");
             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             return stockRef.getLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 throw new StockExchangeException("Index already exists!");

             Index newIndex;
             if (inIndexType == IndexTypes.AVERAGE)
                 newIndex = new AverageIndex(inIndexName);
             else if (inIndexType == IndexTypes.WEIGHTED)
                 newIndex = new WeightedIndex(inIndexName);
             else
                 throw new StockExchangeException("Index type doesn't exists!");
             _indexSet.Add(newIndex.Id, newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");

             if (!_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 throw new StockExchangeException("Index doesn't exists!");

             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             Index indexRef = _indexSet[Index.stringToId(inIndexName)];
             
             if (indexRef.isStockIn(stockRef))
                throw new StockExchangeException("Stock is already in index!"); 
             

             indexRef.addStock(stockRef);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exists!");

             if (!_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 throw new StockExchangeException("Index doesn't exists!");

             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             Index indexRef = _indexSet[Index.stringToId(inIndexName)];

             indexRef.removeStock(stockRef);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 throw new StockExchangeException("Index doesn't exists!");

             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 return false;
             
             Stock stockRef = _stockSet[Stock.stringToId(inStockName)];
             Index indexRef = _indexSet[Index.stringToId(inIndexName)];

             return indexRef.isStockIn(stockRef);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 throw new StockExchangeException("Index doesn't exists!");

             Index indexRef = _indexSet[Index.stringToId(inIndexName)];

             return indexRef.getIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                 return true;
             return false;
         }

         public int NumberOfIndices()
         {
             return _indexSet.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
            if (!_indexSet.ContainsKey(Index.stringToId(inIndexName)))
                throw new StockExchangeException("Index doesn't exists!");
            
             Index indexRef = _indexSet[Index.stringToId(inIndexName)];
             return indexRef.getNumOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio already exists!");
             
             Portfolio newPortfolio = new Portfolio(inPortfolioID);
             _portfolioSet.Add(inPortfolioID, newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exist!");

             if (numberOfShares <= 0)
                 throw new StockExchangeException("Number of shares is <= 0!");
             
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             _portfolioSet[inPortfolioID].addStock(_stockSet[Stock.stringToId(inStockName)], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exist!");

             if (numberOfShares <= 0)
                 throw new StockExchangeException("Number of shares is <= 0!");

             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             _portfolioSet[inPortfolioID].removeStock(_stockSet[Stock.stringToId(inStockName)], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 throw new StockExchangeException("Stock doesn't exist!");

             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             _portfolioSet[inPortfolioID].removeStock(_stockSet[Stock.stringToId(inStockName)]);
         }

         public int NumberOfPortfolios()
         {
             return _portfolioSet.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");
             return _portfolioSet[inPortfolioID].numberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (_portfolioSet.ContainsKey(inPortfolioID))
                 return true;
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 return false;
             
             return _portfolioSet[inPortfolioID].isStockIn(_stockSet[Stock.stringToId(inStockName)]);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             if (!_stockSet.ContainsKey(Stock.stringToId(inStockName)))
                 return 0;
             else
                return Convert.ToInt32(_portfolioSet[inPortfolioID].numberOfSharesOfStock(_stockSet[Stock.stringToId(inStockName)]));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             return _portfolioSet[inPortfolioID].getValue(timeStamp, _stockSet);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!_portfolioSet.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio doesn't exists!");

             return _portfolioSet[inPortfolioID].getPercentChangeInValueForMonth(Year, Month, _stockSet);
         }
     }
}
