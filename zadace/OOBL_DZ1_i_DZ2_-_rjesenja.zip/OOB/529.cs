﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         StockRepository stockRepository = new StockRepository();
         IndexRepository indexRepository = new IndexRepository();
         PortfolioRepository portfolioRepository = new PortfolioRepository();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (stockRepository.StockExists(inStockName) == true)
             {
                 throw new StockExchangeException("Stock allready exists.");
             }
             Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stockRepository.AddStock(newStock);
         }

         //deletes stock from stockRepository, indices and portfolio
         public void DelistStock(string inStockName)
         {
             if (stockRepository.StockExists(inStockName) == false)
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }

             stockRepository.DeleteStock(inStockName);

             foreach (Index index in indexRepository.indexList)
             {
                 if (index.IsPartOfIndex(inStockName) == true)
                 {
                     index.RemoveStock(inStockName);
                 }
             }

             foreach (Portfolio portfolio in portfolioRepository.portfolioList)
             {
                 if (portfolio.IsPartOfPortfolio(inStockName) == true)
                 {
                     portfolio.RemoveStock(inStockName);
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             return stockRepository.StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return stockRepository.NumberOfStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = stockRepository.GetStock(inStockName);
             stock.SetStockPrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = stockRepository.GetStock(inStockName);
             return stock.GetStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = stockRepository.GetStock(inStockName);
             return stock.GetInitialStockPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = stockRepository.GetStock(inStockName);
             return stock.GetLastStockPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (indexRepository.IndexExists(inIndexName) == true)
             {
                 throw new StockExchangeException("Index allready exists.");
             }

             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Unsupported index type.");
             }

             Index newIndex = new Index(inIndexName, inIndexType);
             indexRepository.AddIndex(newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index = indexRepository.GetIndex(inIndexName);
             Stock stock = stockRepository.GetStock(inStockName);
             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = indexRepository.GetIndex(inIndexName);
             index.RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = indexRepository.GetIndex(inIndexName);
             return index.IsPartOfIndex(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = indexRepository.GetIndex(inIndexName);
             return index.GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return indexRepository.IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return indexRepository.NumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = indexRepository.GetIndex(inIndexName);
             return index.NumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolioRepository.PortfolioExists(inPortfolioID) == true)
             {
                 throw new StockExchangeException("Portfolio allready exists.");
             }

             Portfolio newPortfolio = new Portfolio(inPortfolioID);
             portfolioRepository.AddPortfolio(newPortfolio);
         }

         //adds shares to portfolio
         //checks if number of shares in portfolios is bigger than total number
         //of shares
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int sharesSum = 0;

             foreach (Portfolio port in portfolioRepository.portfolioList)
             {
                 if (port.IsPartOfPortfolio(inStockName) == true)
                 {
                     sharesSum += port.NumberOfSharesInPortfoilo(inStockName);
                 }
             }

             Stock stock = stockRepository.GetStock(inStockName);

             if ((sharesSum + numberOfShares) > stock.numberOfShares)
             {
                 throw new StockExchangeException("Number of shares in portfolios bigger then number of shares in StockExchange.");
             }

             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             portfolio.AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             portfolio.RemoveStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             portfolio.RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return portfolioRepository.NumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             return portfolio.NumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolioRepository.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             return portfolio.IsPartOfPortfolio(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             return portfolio.NumberOfSharesInPortfoilo(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             return portfolio.GetPortfolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = portfolioRepository.GetPortfolio(inPortfolioID);
             return portfolio.GetMonthlyChange(Year, Month);
         }
     }

     public class StockRepository
     {
         private List<Stock> stockList = new List<Stock>();

         public void AddStock(Stock stock)
         {
             stockList.Add(stock);
         }

         public void DeleteStock(string stockName)
         {
             Stock stock = stockList.Find(x => x.name.ToLower() == stockName.ToLower());
             stockList.Remove(stock);
         }

         public bool StockExists(string stockName)
         {
             return stockList.Exists(x => x.name.ToLower() == stockName.ToLower());
         }

         //returns the Stock of a name stockName
         public Stock GetStock(string stockName)
         {
             if (stockList.Exists(x => x.name.ToLower() == stockName.ToLower()) == true)
             {
                 return stockList.Find(x => x.name.ToLower() == stockName.ToLower());
             }
             else
             {
                 throw new StockExchangeException("Stock doesn't exist.");
             }
         }

         public int NumberOfStocks()
         {
             return stockList.Count;
         }

     }

     public class Stock
     {
         public string name;
         public long numberOfShares { get; set; }
         private DateTime creationTime;
         private SortedDictionary<DateTime, Decimal> stockPrice = new SortedDictionary<DateTime,decimal>();

         public Stock(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
         {
             this.name = stockName;

             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Number of shares out of scope.");
             }

             this.numberOfShares = numberOfShares;
             this.creationTime = timeStamp;

             if (initialPrice <= 0)
             {
                 throw new StockExchangeException("Stock value out of scope.");
             }

             stockPrice.Add(timeStamp, initialPrice);
         }

         //sets price 
         //checks if timeStamp is after creation time and stock value is positive
         public void SetStockPrice(DateTime timeStamp, Decimal stockValue)
         {
             if (stockValue > 0 && timeStamp > creationTime)
             {
                 stockPrice.Add(timeStamp, stockValue);
             }
             else if (stockValue <= 0)
             {
                 throw new StockExchangeException("Stock value out of scope.");
             }
             else
             {
                 throw new StockExchangeException("Time stamp out of scope.");
             }
         }

         public Decimal GetStockPrice(DateTime timeStamp)
         {
             if (timeStamp < creationTime)
             {
                 throw new StockExchangeException("");
             }

             KeyValuePair<DateTime, Decimal> lowerLimit = stockPrice.First();

             foreach (KeyValuePair<DateTime, Decimal> interval in stockPrice)
             {
                 if (interval.Key > timeStamp)
                 {
                     return lowerLimit.Value;
                 }

                 lowerLimit = interval;
             }

             return stockPrice.Last().Value;
         }

         public Decimal GetInitialStockPrice()
         {
             return stockPrice.First().Value;
         }

         public Decimal GetLastStockPrice()
         {
             return stockPrice.Last().Value;
         }
     }

     public class IndexRepository
     {
         public List<Index> indexList = new List<Index>();


         public void AddIndex(Index index)
         {
             indexList.Add(index);
         }

         public bool IndexExists(string indexName)
         {
             return indexList.Exists(x => x.name.ToLower() == indexName.ToLower());
         }

         public Index GetIndex(string indexName)
         {
             if (indexList.Exists(x => x.name.ToLower() == indexName.ToLower()) == true)
             {
                 return indexList.Find(x => x.name.ToLower() == indexName.ToLower());
             }
             else
             {
                 throw new StockExchangeException("Index doesn't exist.");
             }
         }

         public int NumberOfIndices()
         {
             return indexList.Count;
         }

     }

     public class Index
     {
         public string name;
         public IndexTypes type;
         private List<Stock> stockList = new List<Stock>();

         public Index(string indexName, IndexTypes indexType)
         {
             this.name = indexName;
             this.type = indexType;
         }

         public void AddStock(Stock stock)
         {
             if (IsPartOfIndex(stock.name) == false)
             {
                 stockList.Add(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock allready part of index.");
             }
         }

         public bool IsPartOfIndex(string stockName)
         {
             return stockList.Exists(x => x.name.ToLower() == stockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return stockList.Count;
         }

         //gets index value for different types of indices
         public Decimal GetIndexValue(DateTime timeStamp)
         {
             if (this.type == IndexTypes.AVERAGE)
             {
                 Decimal sum = 0;

                 foreach (Stock stock in stockList)
                 {
                     sum += stock.GetStockPrice(timeStamp);
                 }

                 if (NumberOfStocks() == 0)
                 {
                     return 0;
                 }

                 return Math.Round((sum/ NumberOfStocks()), 3);
             }
             else
             {
                 Decimal sum = 0;
                 Decimal weightFactor;
                 Decimal allStocksValue = 0;

                 foreach (Stock stock in stockList)
                 {
                     allStocksValue += stock.GetStockPrice(timeStamp) * stock.numberOfShares; 
                 }

                 foreach (Stock stock in stockList)
                 {
                     weightFactor = stock.GetStockPrice(timeStamp) * stock.numberOfShares / allStocksValue;
                     sum += stock.GetStockPrice(timeStamp) * weightFactor;
                 }

                 return Math.Round(sum, 3);
             }
         }

         public void RemoveStock(string stockName)
         {
             if (stockList.Exists(x => x.name.ToLower() == stockName.ToLower()) == true)
             {
                 Stock stock = stockList.Find(x => x.name.ToLower() == stockName.ToLower());
                 stockList.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock isn't in index.");
             }
         }
     }

     public class PortfolioRepository
     {
         public List<Portfolio> portfolioList = new List<Portfolio>();

         public void AddPortfolio(Portfolio portfolio)
         {
             portfolioList.Add(portfolio);
         }

         public bool PortfolioExists(string portfolioID)
         {
             return portfolioList.Exists(x => x.ID == portfolioID);
         }


         public Portfolio GetPortfolio(string portfolioID)
         {
             if (portfolioList.Exists(x => x.ID == portfolioID) == true)
             {
                 return portfolioList.Find(x => x.ID == portfolioID);
             }
             else
             {
                 throw new StockExchangeException("Portfolio doesn't exist.");
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }
     }

     public class Portfolio
     {
         public string ID;
         private List<KeyValuePair<Stock, int>> stockList = new List<KeyValuePair<Stock, int>>();

         public Portfolio(string portfolioID)
         {
             this.ID = portfolioID;
         }

         //adds shares to portfolio
         //if stock exists shares are added to Value property of KeyValuePair<Stock, int> from stockList
         //if not new KeyValuePair<Stock, int> is added to the list, Key property - stock object, 
         //Value property - num of shares
         public void AddStock(Stock stock, int numberOfShares)
         {
             if (stockList.Exists(x => x.Key.name.ToLower() == stock.name.ToLower()) == true)
             {
                 KeyValuePair<Stock, int> stockPom = stockList.Find(x => x.Key.name.ToLower() == stock.name.ToLower());
                 RemoveStock(stockPom.Key.name);
                 stockList.Add(new KeyValuePair<Stock, int>(stock, numberOfShares + stockPom.Value));
             }
             else
             {
                 stockList.Add(new KeyValuePair<Stock, int>(stock, numberOfShares));
             }
         }

         public void RemoveStock(string stockName)
         {
             if (stockList.Exists(x => x.Key.name.ToLower() == stockName.ToLower()) == true)
             {
                 KeyValuePair<Stock, int> stock = stockList.Find(x => x.Key.name.ToLower() == stockName.ToLower());
                 stockList.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock isn't in portfolio.");
             }
         }

         //removes stock shares
         //if 0 shares left stock is removed from stockList
         public void RemoveStock(string stockName, int numberOfShares)
         {
             if (stockList.Exists(x => x.Key.name.ToLower() == stockName.ToLower()) == true)
             {
                 KeyValuePair<Stock, int> stock = stockList.Find(x => x.Key.name.ToLower() == stockName.ToLower());

                 if (stock.Value > numberOfShares)
                 {
                     RemoveStock(stock.Key.name);
                     stockList.Add(new KeyValuePair<Stock, int>(stock.Key, stock.Value - numberOfShares));
                 }
                 else if (stock.Value == numberOfShares)
                 {
                     RemoveStock(stockName);
                 }
                 else
                 {
                     throw new StockExchangeException("Not enough stocks in portfolio.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Stock isn't in portfolio.");
             }
         }

         public int NumberOfStocks()
         {
             return stockList.Count;
         }

         public bool IsPartOfPortfolio(string stockName)
         {
             return stockList.Exists(x => x.Key.name.ToLower() == stockName.ToLower());
         }

         public int NumberOfSharesInPortfoilo(string stockName)
         {
             if (stockList.Exists(x => x.Key.name.ToLower() == stockName.ToLower()) == true)
             {
                 KeyValuePair<Stock, int> stock = stockList.Find(x => x.Key.name.ToLower() == stockName.ToLower());
                 return (int)stock.Value;
             }
             else
             {
                 throw new StockExchangeException("Stock isn't in portfolio.");
             }
         }

         public Decimal GetPortfolioValue(DateTime timeStamp)
         {
             Decimal sum = 0;

             foreach (KeyValuePair<Stock, int> stock in stockList)
             {
                 sum += stock.Key.GetStockPrice(timeStamp) * stock.Value;
             }

             return sum;
         }

         //gets monthly change for a month of a year
         //if portfolio value of the beginning of a month is 0 - exception
         public Decimal GetMonthlyChange(int year, int month)
         {
             DateTime monthBeg = new DateTime(year, month, 1, 0, 0, 0, 0);
             DateTime monthEnd = new DateTime(year, month + 1, 1, 0, 0, 0, 0);
             monthEnd.Subtract(new TimeSpan(0, 0, 0, 0, 1));

             Decimal monthBegValue = GetPortfolioValue(monthBeg);
             Decimal monthEndValue = GetPortfolioValue(monthEnd);

             if (monthBegValue == 0)
             {
                 throw new StockExchangeException("Portfolio value 0 at a begging of the month.");
             }

             return  Math.Round((monthEndValue - monthBegValue) / monthBegValue * 100, 3);
         }
     }
}

