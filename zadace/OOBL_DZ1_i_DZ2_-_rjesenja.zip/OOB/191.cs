﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator {
    public class Factory {
        public static ICalculator CreateCalculator() {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
  
    public enum LastOperation { UnaryOperator, BinaryOperator, None };

    public enum BinaryOperator { Sumation, Subtraction, Multiplication, Division, None };

    public class Kalkulator : ICalculator {

        string _displayState;
        string _previousState;
        string _memoryState;

        LastOperation _lastOperation;
        BinaryOperator _binaryOperator;

        bool isSecondBinaryOperator;

        public Kalkulator() {
            this._displayState = "0";
            this._previousState = "0";
            this._memoryState = "0";
            _lastOperation = LastOperation.None;
            _binaryOperator = BinaryOperator.None;
        }

        public void Press(char inPressedDigit) {

            if (isDigit(inPressedDigit)) {
                onDigit(inPressedDigit); 
            }
            else if (isComma(inPressedDigit)) {
                onComma();
            }
            else if (isUnaryOperator(inPressedDigit)) {
                onUnaryOperator(inPressedDigit);
                if (!_displayState.Equals("-E-")) {
                    round();
                }  
            }
            else if (isBinaryOperator(inPressedDigit)) {
                if (isSecondBinaryOperator) {
                    onEquality();
                    round();
                    isSecondBinaryOperator = false;
                }
                onBinaryOperator(inPressedDigit);
                round();
            }
            else if (isEquality(inPressedDigit)) {
                onEquality();
                if (!_displayState.Equals("-E-")) {
                    round();
                }  
            }
        }

        public string GetCurrentDisplayState() {
            return this._displayState;
        }

        private bool isDigit(char inPressed) {
            bool isDigit = Char.IsDigit(inPressed);
            return isDigit;
        }

        private void onDigit(char pressedDigit) {

            string pressed = pressedDigit.ToString();

            if ((_lastOperation == LastOperation.UnaryOperator && _binaryOperator != BinaryOperator.None)) {
                _displayState = "0";
            }

            if (_lastOperation == LastOperation.BinaryOperator) {
                _displayState = "0";
                  isSecondBinaryOperator = true;
                _lastOperation = LastOperation.None;
            }



            bool isZeroOnDisplay = _displayState.Equals("0");

            if (isZeroOnDisplay) {
                _displayState = pressed;
            }
            else {
                _displayState += pressed;
            }

            checkDisplayLength();
        }

        private void checkDisplayLength() {
            bool isStartingWithMinus = _displayState.StartsWith("-");
            bool isContainingComma = _displayState.Contains(",");
            int displayStateLength = _displayState.Length;

            if (isStartingWithMinus && isContainingComma) {
                if (displayStateLength > 12) {
                    _displayState = _displayState.Remove(12);
                }
            }
            else if (isStartingWithMinus || isContainingComma) {
                if (displayStateLength > 11) {
                    _displayState = _displayState.Remove(11);
                }
            }
            else {
                if (displayStateLength > 10) {
                    _displayState = _displayState.Remove(10);
                }
            }
        }

        private bool isComma(char inPressed) {
            bool isComma = inPressed.Equals(',');
            return isComma;
       }

        private void onComma() {
            if (!_displayState.Contains(",")) {
                _displayState += ",";
            }  
            checkDisplayLength();
        }

        private bool isUnaryOperator(char inPressed) {
            bool isUnaryOperator = false;

            switch (inPressed) {
                case 'M':
                    isUnaryOperator = true;
                    break;
                case 'S':
                    isUnaryOperator = true;
                    break;
                case 'K':
                    isUnaryOperator = true;
                    break;
                case 'T':
                    isUnaryOperator = true;
                    break;
                case 'Q':
                    isUnaryOperator = true;
                    break;
                case 'R':
                    isUnaryOperator = true;
                    break;
                case 'I':
                    isUnaryOperator = true;
                    break;
                case 'P':
                    isUnaryOperator = true;
                    break;
                case 'G':
                    isUnaryOperator = true;
                    break;
                case 'C':
                    isUnaryOperator = true;
                    break;
                case 'O':
                    isUnaryOperator = true;
                    break;
                default:
                    isUnaryOperator = false;
                    break;
            }
            return isUnaryOperator;
        }

        private void onUnaryOperator(char pressedUnaryOperator) {

            double displayState = 0;

            if (_lastOperation == LastOperation.BinaryOperator) {
                displayState = Double.Parse(this._previousState);
            }
            else {
                displayState = Double.Parse(this._displayState);
            }

            switch (pressedUnaryOperator) {
                case 'M':
                    displayState = - displayState;
                    this._displayState = displayState.ToString();
                    return;
                case 'S':
                    displayState = Math.Sin(displayState);
                    break;
                case 'K':
                    displayState = Math.Cos(displayState);
                    break;
                case 'T':
                    displayState = Math.Tan(displayState);
                    break;
                case 'Q':
                    displayState = Math.Pow(displayState, 2);
                    break;
                case 'R':
                    if (displayState >= 0) {
                        displayState = Math.Sqrt(displayState);
                    }
                    else {
                        this._displayState = "-E-";
                        return;
                    }
                    break;
                case 'I':
                    if (displayState != 0) {
                        displayState = 1 / displayState;
                    }
                    else {
                        this._displayState = "-E-";
                        return;
                    }
                    break;
                case 'P':
                    this._memoryState = displayState.ToString();
                    return;
                case 'G':
                    displayState = Double.Parse(this._memoryState);
                    break;
                case 'C':
                    onClear();
                    return;
                case 'O':
                    onRestart();
                    return;
                default:
                    break;
            }

            this._displayState = displayState.ToString();
            this._lastOperation = LastOperation.UnaryOperator;
        }

        private bool isBinaryOperator(char inPressed) {
            bool isBinaryOperator = false;

            switch (inPressed) {
                case '+':
                    isBinaryOperator = true;
                    break;
                case '-':
                    isBinaryOperator = true;
                    break;
                case '*':
                    isBinaryOperator = true;
                    break;
                case '/':
                    isBinaryOperator = true;
                    break;
                default:
                    isBinaryOperator = false;
                    break;
            }

            return isBinaryOperator;
        }

        private void onBinaryOperator(char pressedBinaryOperator) {

            this._previousState = this._displayState;

            switch (pressedBinaryOperator) {
                case '+':
                    this._binaryOperator = BinaryOperator.Sumation;
                    break;
                case '-':
                    this._binaryOperator = BinaryOperator.Subtraction;
                    break;
                case '*':
                    this._binaryOperator = BinaryOperator.Multiplication;
                    break;
                case '/':
                    this._binaryOperator = BinaryOperator.Division;
                    break;
            }

            this._lastOperation = LastOperation.BinaryOperator;
        }

        private bool isEquality(char inPressed) {
            bool isEquality = inPressed.Equals('=');
            return isEquality;
        }

        public void onEquality() {

            double displayState = Double.Parse(this._displayState);
            double previousState = Double.Parse(this._previousState);

            switch (_binaryOperator) {
                case BinaryOperator.Sumation:
                    displayState += previousState;
                    break;
                case BinaryOperator.Subtraction:
                    displayState = previousState - displayState;
                    break;
                case BinaryOperator.Multiplication:
                    displayState *= previousState;
                    break;
                case BinaryOperator.Division:
                    if (displayState != 0) {
                        displayState = previousState / displayState;
                    }
                    else {
                        this._displayState = "-E-";
                        return;
                    }
                    break;
            }

            this._displayState = displayState.ToString();
            this._binaryOperator = BinaryOperator.None;
        }

        public void round() {

            double displayState = Double.Parse(this._displayState);
            int displayStateLength = this._displayState.Length;
            double integerPart = Math.Truncate(displayState);

            int integerPartLength = 1;
            if (integerPart != 0) {
                integerPartLength = (int) Math.Floor(Math.Log10(Math.Abs(integerPart)) + 1);
            }

            if (integerPartLength > 10) {
                this._displayState = "-E-";
                return;
            }

            if (this._displayState.StartsWith("-") && this._displayState.Contains(",") && displayStateLength > 12) {
                displayState = Math.Round(displayState, 12 - integerPartLength - 2);
            }
            else if ((this._displayState.StartsWith("-") || this._displayState.Contains(",")) && displayStateLength > 11) {
                displayState = Math.Round(displayState, 11 - integerPartLength - 1);
            }
            else if (this._displayState.Length > 10) {
                displayState = Math.Round(displayState, 10 - integerPartLength);
            }

            this._displayState = displayState.ToString();
        }

        private void onClear() {
            this._displayState = "0";
        }

        private void onRestart() {
            this._displayState = "0";
            this._previousState = "0";
            this._memoryState = "0";
            this._lastOperation = LastOperation.None;
            this._binaryOperator = BinaryOperator.None;
        }
    }
}