﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {

        private double prviOperand;
        private double drugiOperand;
        private string stanjeNaDisplayu;
        private UnarnaOperacija obavioUnarnuOp;
        private string brojUmemoriji;

        private BinarnaOperacija binarnaOpNaCekanju;


        private StanjeKalkulatora trenutnoStanje;




        public Kalkulator()
        {
            resetiranje();
        }


        public void postaviStanje(StanjeKalkulatora stanje)
        {
            this.trenutnoStanje = stanje;
        }

        public StanjeKalkulatora stanje()
        {
            return this.trenutnoStanje;
        }

        public void postaviObavioUnarnu(UnarnaOperacija obavljena)
        {
            this.obavioUnarnuOp = obavljena;
        }

        public UnarnaOperacija obavioUnarnu()
        {
            return this.obavioUnarnuOp;
        }

        public void postaviDisplay(string display)
        {
            int brZnamenki = display.Count(x => Char.IsDigit(x));

            if (brZnamenki > 10)
            {
                string decDijelovi = display.Split(',')[0];

                int brIspredTocke = decDijelovi.Count(x => Char.IsDigit(x));
                double zaokruzeni = Math.Round(Double.Parse(display), 10 - brIspredTocke);

                display = "" + zaokruzeni;
            }

            this.stanjeNaDisplayu = display;
        }

        public string dohvatiStanjeNaDisplayu()
        {
            return this.stanjeNaDisplayu;
        }


        public void postaviPrviOperand(double znam)
        {
            this.prviOperand = znam;
        }

        public double dohvatiPrviOperand()
        {
            return this.prviOperand;
        }


        public double dohvatiDrugiOperand()
        {
            return this.drugiOperand;
        }

        public void postaviDrugiOperand(double znam)
        {
            this.drugiOperand = znam;
        }



        public void postaviBinOpNaCekanju(BinarnaOperacija op)
        {
            this.binarnaOpNaCekanju = op;
        }

        public BinarnaOperacija dohvatiBinOpNaCekanju()
        {
            return this.binarnaOpNaCekanju;
        }




        public string resetiranje()
        {
            this.prviOperand = 0.0D;
            this.trenutnoStanje = PocetnoStanje.dohvatiStanje();
            this.binarnaOpNaCekanju = null;
            this.stanjeNaDisplayu = "0";
            this.brojUmemoriji = "";
            this.obavioUnarnuOp = null;

            return dohvatiStanjeNaDisplayu();
        }



        public string unosUmemoriju()
        {
            this.brojUmemoriji = dohvatiStanjeNaDisplayu();
            return dohvatiStanjeNaDisplayu();
        }

        public string dohvatIzMemorije()
        {
            if (this.brojUmemoriji != "")
            {
                postaviStanje(StanjePridodavanjaZnamenki.dohvatiStanje());
                return this.brojUmemoriji;
            }

            return dohvatiStanjeNaDisplayu();
        }



        public string brisanjeEkrana()
        {
            if (this.trenutnoStanje != StanjeGreske.dohvatiStanje())
            {
                this.stanjeNaDisplayu = "0";
                return dohvatiStanjeNaDisplayu();
            }
            return dohvatiStanjeNaDisplayu();

        }

        public string unesenBroj(char broj)
        {
            this.trenutnoStanje.unesenBroj(this, broj);
            return dohvatiStanjeNaDisplayu();
        }

        public string unesenDecimalniZarez()
        {
            this.trenutnoStanje.unesenDecimalniZarez(this);
            return dohvatiStanjeNaDisplayu();

        }


        public string unesenaBinarnaOp(BinarnaOperacija op)
        {
            this.trenutnoStanje.unesenaBinarnaOp(this, op);
            return dohvatiStanjeNaDisplayu();
        }


        public string unesenaUnarnaOp(UnarnaOperacija op)
        {
            this.trenutnoStanje.unesenaUnarnaOp(this, op);
            return dohvatiStanjeNaDisplayu();
        }

        public string unesenoJednako()
        {
            this.trenutnoStanje.unesenZnakJednako(this);
            return dohvatiStanjeNaDisplayu();
        }


        /*************************************/

        public void Press(char inPressedDigit)
        {

            if (Char.IsDigit(inPressedDigit))
            {
                postaviDisplay(unesenBroj(inPressedDigit));
                return;
            }

            if (inPressedDigit == ',')
            {
                postaviDisplay(unesenDecimalniZarez());
                return;
            }

            if (inPressedDigit == '=')
            {
                postaviDisplay(unesenoJednako());
                return;
            }

            if (inPressedDigit == 'S')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaSinus.dohvatiOp()));
                return;
            }
            if (inPressedDigit == 'K')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaKosinus.dohvatiOp()));
                return;
            }
            if (inPressedDigit == 'T')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaTangens.dohvatiOp()));
                return;
            }

            if (inPressedDigit == 'Q')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaKvadrat.dohvatiOp()));
                return;
            }
            if (inPressedDigit == 'R')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaKorijen.dohvatiOp()));
                return;
            }
            if (inPressedDigit == 'I')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaInverz.dohvatiOp()));
                return;
            }

            if (inPressedDigit == 'P')
            {
                postaviDisplay(unosUmemoriju());
                return;
            }

            if (inPressedDigit == 'G')
            {
                postaviDisplay(dohvatIzMemorije());
                return;
            }

            if (inPressedDigit == 'M')
            {
                postaviDisplay(unesenaUnarnaOp(OperacijaPromjenaPredznaka.dohvatiOp()));
                return;
            }

            if (inPressedDigit == '+')
            {
                postaviDisplay(unesenaBinarnaOp(OperacijaZbrajanja.dohvatiOp()));
                return;
            }
            if (inPressedDigit == '-')
            {
                postaviDisplay(unesenaBinarnaOp(OperacijaOduzimanja.dohvatiOp()));
                return;

            }
            if (inPressedDigit == '*')
            {
                postaviDisplay(unesenaBinarnaOp(OperacijaMnozenja.dohvatiOp()));
                return;
            }
            if (inPressedDigit == '/')
            {
                postaviDisplay(unesenaBinarnaOp(OperacijaDijeljenja.dohvatiOp()));
                return;
            }

            if (inPressedDigit == 'O')
            {
                postaviDisplay(resetiranje());
                return;
            }

            if (inPressedDigit == 'C')
            {
                postaviDisplay(brisanjeEkrana());
                return;
            }
            else
            {

            }

        }


        public string baciGresku()
        {
            return "-E-";
        }



        public string GetCurrentDisplayState()
        {
            return this.dohvatiStanjeNaDisplayu();
        }

        public string nazivStanja()
        {
            return this.trenutnoStanje.GetType().ToString();
        }


        /*************************************/

    }





    public abstract class BinarnaOperacija
    {
        public abstract double izracunaj(double prvi, double drugi);
    }


    public abstract class UnarnaOperacija
    {
        public abstract double izracunaj(double prvi);
    }




    // BINARNE OPERACIJE
    // zbrajanje
    // oduzimanje
    // mnozenje
    // dijeljenje

    public class OperacijaZbrajanja : BinarnaOperacija
    {
        public static OperacijaZbrajanja instanca;

        private OperacijaZbrajanja() { }

        public static OperacijaZbrajanja dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaZbrajanja();
            }
            return instanca;
        }
        override public double izracunaj(double prvi, double drugi)
        {
            if (Math.Floor(Math.Log10(prvi + drugi) + 1) > 10)
            {
                throw new Exception();
            }
            return prvi + drugi;
        }
    }

    public class OperacijaOduzimanja : BinarnaOperacija
    {
        public static OperacijaOduzimanja instanca;
        private OperacijaOduzimanja() { }
        public static OperacijaOduzimanja dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaOduzimanja();
            }
            return instanca;
        }
        override public double izracunaj(double prvi, double drugi)
        {
            if (Math.Floor(Math.Log10(prvi - drugi) + 1) > 10)
            {
                throw new Exception();
            }
            return prvi - drugi;
        }
    }


    public class OperacijaMnozenja : BinarnaOperacija
    {
        public static OperacijaMnozenja instanca;
        private OperacijaMnozenja() { }
        public static OperacijaMnozenja dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaMnozenja();
            }
            return instanca;
        }
        override public double izracunaj(double prvi, double drugi)
        {
            if (Math.Floor(Math.Log10(prvi * drugi) + 1) > 10)
            {
                throw new Exception();
            }
            return prvi * drugi;
        }
    }


    public class OperacijaDijeljenja : BinarnaOperacija
    {
        public static OperacijaDijeljenja instanca;
        private OperacijaDijeljenja() { }
        public static OperacijaDijeljenja dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaDijeljenja();
            }
            return instanca;
        }
        override public double izracunaj(double prvi, double drugi)
        {
            if (drugi.CompareTo(0.0) == 0)
            {
                throw new DivideByZeroException();

            }

            if (Math.Floor(Math.Log10(prvi / drugi) + 1) > 10)
            {
                throw new Exception();
            }

            return prvi / drugi;
        }
    }






    // UNARNE OPERACIJE
    // sinus
    // kosinus
    // tangens
    // kvadrat
    // korijen
    // inverz
    // promjena predznaka

    public class OperacijaSinus : UnarnaOperacija
    {
        public static OperacijaSinus instanca;
        private OperacijaSinus() { }
        public static OperacijaSinus dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaSinus();
            }
            return instanca;
        }


        public override double izracunaj(double prvi)
        {
            return Math.Sin(prvi);
        }
    }


    public class OperacijaKosinus : UnarnaOperacija
    {
        public static OperacijaKosinus instanca;
        private OperacijaKosinus() { }
        public static OperacijaKosinus dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaKosinus();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            return Math.Cos(prvi);
        }
    }


    public class OperacijaTangens : UnarnaOperacija
    {
        public static OperacijaTangens instanca;
        private OperacijaTangens() { }
        public static OperacijaTangens dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaTangens();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            if (Math.Floor(Math.Log10(Math.Tan(prvi)) + 1) > 10)
            {
                throw new Exception();
            }
            return Math.Tan(prvi);
        }
    }


    public class OperacijaKvadrat : UnarnaOperacija
    {
        public static OperacijaKvadrat instanca;
        private OperacijaKvadrat() { }
        public static OperacijaKvadrat dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaKvadrat();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            if (Math.Floor(Math.Log10(Math.Pow(prvi, 2.0)) + 1) > 10)
            {
                throw new Exception();
            }
            return Math.Pow(prvi, 2.0);
        }
    }


    public class OperacijaKorijen : UnarnaOperacija
    {
        public static OperacijaKorijen instanca;
        private OperacijaKorijen() { }
        public static OperacijaKorijen dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaKorijen();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            if (prvi < 0)
            {
                throw new Exception();
            }
            return Math.Sqrt(prvi);
        }
    }

    public class OperacijaInverz : UnarnaOperacija
    {
        public static OperacijaInverz instanca;
        private OperacijaInverz() { }
        public static OperacijaInverz dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaInverz();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            if (prvi.CompareTo(0.0) == 0)
            {
                throw new DivideByZeroException();
            }

            if (Math.Floor(Math.Log10(1 / (prvi)) + 1) > 10)
            {
                throw new Exception();
            }
            return 1 / (prvi);
        }
    }


    public class OperacijaPromjenaPredznaka : UnarnaOperacija
    {
        public static OperacijaPromjenaPredznaka instanca;
        private OperacijaPromjenaPredznaka() { }
        public static OperacijaPromjenaPredznaka dohvatiOp()
        {
            if (instanca == null)
            {
                instanca = new OperacijaPromjenaPredznaka();
            }
            return instanca;
        }
        public override double izracunaj(double prvi)
        {
            return -(prvi);
        }
    }



    public abstract class StanjeKalkulatora
    {
        public abstract void unesenBroj(Kalkulator kalkulator, char broj);
        public abstract void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op);
        public abstract void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op);
        public abstract void unesenZnakJednako(Kalkulator kalkulator);
        public abstract void unesenDecimalniZarez(Kalkulator kalkulator);

    }



    /* POČETNO STANJE KALKULATORA*/
    class PocetnoStanje : StanjeKalkulatora
    {

        public static PocetnoStanje instancaStanja;
        private PocetnoStanje() { }
        public static PocetnoStanje dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new PocetnoStanje();
            }
            return instancaStanja;
        }


        override public void unesenBroj(Kalkulator kalkulator, char broj)
        {
            if (kalkulator.dohvatiStanjeNaDisplayu().Count(x => Char.IsDigit(x)) < 10)
            {
                kalkulator.postaviDisplay("" + broj);
                if (!broj.Equals('0'))
                {
                    kalkulator.postaviStanje(StanjePridodavanjaZnamenki.dohvatiStanje());
                }
            }
        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {
            kalkulator.postaviDisplay("0,");
            kalkulator.postaviStanje(StanjeUnesenZarez.dohvatiStanje());
        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {
                    kalkulator.postaviPrviOperand(kalkulator.dohvatiBinOpNaCekanju().izracunaj(
                        kalkulator.dohvatiPrviOperand(), Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));

                }
                else
                {
                    kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                }
                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());
                kalkulator.postaviBinOpNaCekanju(op);
                kalkulator.postaviStanje(StanjeRacunanja.dohvatiStanje());
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {
            try
            {
                kalkulator.postaviDisplay("" + op.izracunaj(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                kalkulator.postaviObavioUnarnu(op);
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }


        public override void unesenZnakJednako(Kalkulator kalkulator)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {
                    kalkulator.postaviPrviOperand(kalkulator.dohvatiBinOpNaCekanju().izracunaj(
                        kalkulator.dohvatiPrviOperand(), Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));

                }
                else
                {
                    kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                }
                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());
                //kalkulator.postaviBinOpNaCekanju(null);
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }

    }
    /* KRAJ POČETNOG!!!!*/



    /* STANJE PRIDODAVANJA ZNAMENKI */
    class StanjePridodavanjaZnamenki : StanjeKalkulatora
    {
        public static StanjePridodavanjaZnamenki instancaStanja;
        private StanjePridodavanjaZnamenki() { }
        public static StanjePridodavanjaZnamenki dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new StanjePridodavanjaZnamenki();
            }
            return instancaStanja;
        }


        override public void unesenBroj(Kalkulator kalkulator, char broj)
        {
            if (kalkulator.dohvatiStanjeNaDisplayu().Count(x => Char.IsDigit(x)) < 10)
            {
                if (kalkulator.obavioUnarnu() == null || kalkulator.obavioUnarnu() == OperacijaPromjenaPredznaka.dohvatiOp())
                {
                    kalkulator.postaviDisplay(kalkulator.dohvatiStanjeNaDisplayu() + broj);
                }
                else
                {
                    kalkulator.postaviDisplay("" + broj);
                    kalkulator.postaviObavioUnarnu(null);
                }
            }
        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {

            if (kalkulator.obavioUnarnu() == null || kalkulator.obavioUnarnu() == OperacijaPromjenaPredznaka.dohvatiOp())
            {
                kalkulator.postaviDisplay(kalkulator.dohvatiStanjeNaDisplayu() + ",");
                kalkulator.postaviStanje(StanjeUnesenZarez.dohvatiStanje());
            }
            else
            {
                kalkulator.postaviDisplay("0,");
                kalkulator.postaviStanje(StanjeUnesenZarez.dohvatiStanje());
                kalkulator.postaviObavioUnarnu(null);
            }



        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {
                    kalkulator.postaviPrviOperand(kalkulator.dohvatiBinOpNaCekanju().izracunaj(kalkulator.dohvatiPrviOperand(),
                        Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                }
                else
                {
                    kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                }

                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());
                kalkulator.postaviBinOpNaCekanju(op);
                kalkulator.postaviStanje(StanjeRacunanja.dohvatiStanje());

            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());

            }
        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {
            try
            {
                kalkulator.postaviDisplay("" + op.izracunaj(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                kalkulator.postaviObavioUnarnu(op);

            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }



        public override void unesenZnakJednako(Kalkulator kalkulator)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {

                    kalkulator.postaviPrviOperand(kalkulator.dohvatiBinOpNaCekanju().izracunaj(kalkulator.dohvatiPrviOperand(),
                        Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                    kalkulator.postaviDrugiOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                    kalkulator.postaviStanje(IzracunatoStanje.dohvatiStanje());
                }
                else
                {
                    kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                    kalkulator.postaviStanje(PocetnoStanje.dohvatiStanje());
                }

                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());

            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }
    }
    /* KRAJ STANJA PRIDODAVANJA ZNAMENKI */



    /* IZRAČUNATO STANJE */
    class IzracunatoStanje : StanjeKalkulatora
    {

        public static IzracunatoStanje instancaStanja;
        private IzracunatoStanje() { }
        public static IzracunatoStanje dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new IzracunatoStanje();
            }
            return instancaStanja;
        }

        override public void unesenBroj(Kalkulator kalkulator, char broj)
        {
            if (kalkulator.dohvatiStanjeNaDisplayu().Count(x => Char.IsDigit(x)) < 10)
            {
                kalkulator.postaviDisplay("" + broj);
                if (!broj.Equals('0'))
                {
                    kalkulator.postaviStanje(StanjePridodavanjaZnamenki.dohvatiStanje());
                }

            }
        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {
            kalkulator.postaviDisplay("0,");
            kalkulator.postaviStanje(StanjeUnesenZarez.dohvatiStanje());
        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {
            try
            {

                kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));

                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());
                kalkulator.postaviBinOpNaCekanju(op);
                kalkulator.postaviStanje(StanjeRacunanja.dohvatiStanje());
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {
            try
            {
                kalkulator.postaviDisplay("" + op.izracunaj(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                kalkulator.postaviObavioUnarnu(op);
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }


        public override void unesenZnakJednako(Kalkulator kalkulator)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {
                    kalkulator.postaviPrviOperand(kalkulator.dohvatiBinOpNaCekanju().izracunaj(
                        Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()), kalkulator.dohvatiDrugiOperand()));
                }
                else
                {
                    kalkulator.postaviPrviOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                }
                kalkulator.postaviDisplay("" + kalkulator.dohvatiPrviOperand());

            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }

    }
    /* KRAJ IZRAČUNATO*/



    /* STANJE KALKULATORA KADA JE UPISAN DEC. ZAREZ /**/
    class StanjeUnesenZarez : StanjeKalkulatora
    {

        public static StanjeUnesenZarez instancaStanja;
        static StanjePridodavanjaZnamenki stanjePridodavanjaBrojeva = StanjePridodavanjaZnamenki.dohvatiStanje();
        private StanjeUnesenZarez() { }
        public static StanjeUnesenZarez dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new StanjeUnesenZarez();
            }
            return instancaStanja;
        }


        public override void unesenBroj(Kalkulator kalkulator, char broj)
        {
            if (kalkulator.dohvatiStanjeNaDisplayu().Count(x => Char.IsDigit(x)) < 10)
            {
                stanjePridodavanjaBrojeva.unesenBroj(kalkulator, broj);
            }
        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {

        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {
            stanjePridodavanjaBrojeva.unesenaBinarnaOp(kalkulator, op);
        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {
            stanjePridodavanjaBrojeva.unesenaUnarnaOp(kalkulator, op);
        }


        public override void unesenZnakJednako(Kalkulator kalkulator)
        {
            stanjePridodavanjaBrojeva.unesenZnakJednako(kalkulator);
        }
    }
    /* KRAJ STANJA UPISANOG DEC. ZAREZA */



    /* STANJE RAČUNANJA */
    class StanjeRacunanja : StanjeKalkulatora
    {

        public static StanjeRacunanja instancaStanja;
        static StanjeRacunanja stanjePridodavanjaBrojeva = StanjeRacunanja.dohvatiStanje();
        private StanjeRacunanja() { }
        public static StanjeRacunanja dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new StanjeRacunanja();
            }
            return instancaStanja;
        }

        public override void unesenBroj(Kalkulator kalkulator, char broj)
        {
            kalkulator.postaviDisplay("" + broj);
            if (broj != '0')
            {
                kalkulator.postaviStanje(StanjePridodavanjaZnamenki.dohvatiStanje());
            }
            else
            {
                kalkulator.postaviStanje(PocetnoStanje.dohvatiStanje());
            }
        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {
            kalkulator.postaviDisplay("0.");
            kalkulator.postaviStanje(StanjeUnesenZarez.dohvatiStanje());
        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {
            try
            {
                kalkulator.postaviBinOpNaCekanju(op);
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {
            try
            {
                kalkulator.postaviDisplay("" + op.izracunaj(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                kalkulator.postaviObavioUnarnu(op);
            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }


        public override void unesenZnakJednako(Kalkulator kalkulator)
        {
            try
            {
                if (kalkulator.dohvatiBinOpNaCekanju() != null)
                {
                    kalkulator.postaviDrugiOperand(Double.Parse(kalkulator.dohvatiStanjeNaDisplayu()));
                    kalkulator.postaviDisplay("" + kalkulator.dohvatiBinOpNaCekanju().izracunaj(
                        kalkulator.dohvatiPrviOperand(), Double.Parse(kalkulator.dohvatiStanjeNaDisplayu())));
                    kalkulator.postaviStanje(IzracunatoStanje.dohvatiStanje());
                }

            }
            catch
            {
                kalkulator.postaviDisplay(kalkulator.baciGresku());
                kalkulator.postaviStanje(StanjeGreske.dohvatiStanje());
            }
        }
    }
    /* KRAJ STANJE RAČUNANJA */




    class StanjeGreske : StanjeKalkulatora
    {

        public static StanjeGreske instancaStanja;
        static StanjeGreske stanjePridodavanjaBrojeva = StanjeGreske.dohvatiStanje();
        private StanjeGreske() { }
        public static StanjeGreske dohvatiStanje()
        {
            if (instancaStanja == null)
            {
                instancaStanja = new StanjeGreske();
            }
            return instancaStanja;
        }

        public override void unesenBroj(Kalkulator kalkulator, char broj)
        {

        }

        public override void unesenDecimalniZarez(Kalkulator kalkulator)
        {

        }

        public override void unesenaBinarnaOp(Kalkulator kalkulator, BinarnaOperacija op)
        {

        }

        public override void unesenaUnarnaOp(Kalkulator kalkulator, UnarnaOperacija op)
        {

        }

        public override void unesenZnakJednako(Kalkulator kalkulator)
        {

        }
    }
}
