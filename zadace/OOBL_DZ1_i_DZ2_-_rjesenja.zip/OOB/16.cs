﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private String stanjeKalk = "0";
        private char binOperacija;
        private double operand;
        private char predzadnjiUnos;
        private char predzadnjaOperacija;
        private String memorija="0";
        private int brojUnesenihoperanada;
        private int zastavica; //1 za +, 2 za -, 3 za *, 4 za /, 11 za ponovni +, 22 za ponovni -,33 za ponovni *,44 za ponovni /,


        public void Press(char inPressedDigit)
        {
            if (stanjeKalk == "-E-") pressResetirajCalc();
            if (inPressedDigit == 'M') pressPromjenaPredznaka();
            else if (inPressedDigit == ',') pressZarez();
            else if (inPressedDigit == 'O') pressResetirajCalc();
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                zaokruziNa10CijeliBroj();
                if (brojUnesenihoperanada != 0)
                {
                    izracunaj();
                    stanjeKalk = operand.ToString();
                }
                if (brojUnesenihoperanada == 0)
                {
                    operand = Convert.ToDouble(stanjeKalk);
                    brojUnesenihoperanada++;
                    postaviZastavicu(inPressedDigit);
                    izracunaj();
                }


                postaviZastavicu(inPressedDigit); ;
            }
            else if (inPressedDigit == '=') pressJednako();
            else if (inPressedDigit == 'P') pressMemorija();
            else if (inPressedDigit == 'S') pressSinus();
            else if (inPressedDigit == 'K') pressCosinus();
            else if (inPressedDigit == 'T') pressTangens();
            else if (inPressedDigit == 'Q') pressKvadriranje();
            else if (inPressedDigit == 'R') pressKorjenovanje();
            else if (inPressedDigit == 'I') pressInverz();
            else if (inPressedDigit == 'G') stanjeKalk = memorija;
            else if (inPressedDigit == 'C') stanjeKalk = "0";
            else if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                if (zastavica == 1)
                {
                    stanjeKalk = "0";
                    zastavica = 11;
                }
                if (zastavica == 2)
                {
                    stanjeKalk = "0";
                    zastavica = 22;
                }
                if (zastavica == 3)
                {
                    stanjeKalk = "0";
                    zastavica = 33;
                }
                if (zastavica == 4)
                {
                    stanjeKalk = "0";
                    zastavica = 44;
                }
                pressBrojevi(inPressedDigit);
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-' ||
                inPressedDigit == '*' || inPressedDigit == '/' || inPressedDigit == ',') predzadnjaOperacija = inPressedDigit;
            predzadnjiUnos = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            provjeriNajveci();
            provjeriNajmanji();
            zaokruziNa10();
            return stanjeKalk;
        }

        #region  ************ PRESS **************

        private void pressBrojevi(char broj)
        {
            if (stanjeKalk =="-E-") stanjeKalk = "0";
            stanjeKalk += broj;
            double stanjeKalkDouble;
            if (broj != '0' && predzadnjaOperacija != ',')
            {
                stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
                stanjeKalk = stanjeKalkDouble.ToString();
            }
            
        }
        private void pressZarez()
        {
            stanjeKalk += ",";
        }
        private void pressPromjenaPredznaka()
        {
            double stanjeKalkDouble;
            stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
            stanjeKalkDouble = -1 * stanjeKalkDouble;
            stanjeKalk = stanjeKalkDouble.ToString();
        }
        private void pressResetirajCalc()
        {
            memorija = "0";
            stanjeKalk = "0";
            operand = 0;
        }
        private void pressMemorija()
        {
            zaokruziNa10CijeliBroj();
            memorija = stanjeKalk;
        }
        private void pressSinus()
        {
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble = Math.Sin(Convert.ToDouble(stanjeKalk));
            stanjeKalk = stanjeKalkDouble.ToString();
            zaokruziNa10();
        }
        private void pressCosinus()
        {
            zaokruziNa10CijeliBroj();
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble = Math.Cos(Convert.ToDouble(stanjeKalk));
            stanjeKalk = stanjeKalkDouble.ToString();
            zaokruziNa10();
        }
        private void pressTangens()
        {
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble = Math.Tan(Convert.ToDouble(stanjeKalk));
            stanjeKalk = stanjeKalkDouble.ToString();
            zaokruziNa10();
        }
        private void pressKvadriranje()
        {
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble = (Convert.ToDouble(stanjeKalk)) * (Convert.ToDouble(stanjeKalk));
            stanjeKalk = stanjeKalkDouble.ToString();
        }
        private void pressKorjenovanje()
        {
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble =(Convert.ToDouble(stanjeKalk));
            if (stanjeKalkDouble >= 0)
            {
                stanjeKalkDouble = Math.Sqrt(stanjeKalkDouble);
                stanjeKalk = stanjeKalkDouble.ToString();
            }
            else stanjeKalk = "-E-";
            zaokruziNa10();
        }
        private void pressInverz()
        {
            zaokruziNa10CijeliBroj();
            double stanjeKalkDouble;
            stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
            if (stanjeKalkDouble != 0)
            {
                stanjeKalkDouble = 1 / stanjeKalkDouble;
                stanjeKalk = stanjeKalkDouble.ToString();
            }
            else stanjeKalk = "-E-";
        }
        private void pressJednako()
        {
            provjeriNajveci();
            provjeriNajmanji();
            zaokruziNa10();
            zaokruziNa10CijeliBroj();
            try
            {
                izracunaj();
            }
            catch (Exception e)
            {
                stanjeKalk = "-E-";
            }
            // za racunanje 2+=....
            if (predzadnjiUnos == '+')
            {
                zastavica = 11;
                izracunaj();
            }
            if (predzadnjiUnos == '-')
            {
                zastavica = 22;
                izracunaj();
            }
            if (predzadnjiUnos == '*')
            {
                zastavica = 33;
                izracunaj();
            }
            if (predzadnjiUnos == '/')
            {
                zastavica = 44;
                izracunaj();
            }
            if(zastavica!=0) stanjeKalk = operand.ToString();
            provjeriNajveci();
            provjeriNajmanji();
            zaokruziNa10();
            zaokruziNa10CijeliBroj();
           
        }

        #endregion

        #region ********** PROVJERA I ZAOKRUZIVANJE **********

        private void provjeriNajveci()
        {
            double parsirano;
            if (double.TryParse(stanjeKalk,out parsirano)==true)
            {
                double stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
                if (stanjeKalkDouble > 9999999999) stanjeKalk = "-E-";
            }
        }
        private void provjeriNajmanji()
        {
            double parsirano;
            if (double.TryParse(stanjeKalk, out parsirano) == true)
            {
                double stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
                if (stanjeKalkDouble < -9999999999) stanjeKalk = "-E-";
            }
        }
        private int provjeriVelicinuBroja()
        {
            int i = 0;
            double stanjeKalkDouble;
            stanjeKalkDouble = Convert.ToDouble(stanjeKalk);

            if (stanjeKalkDouble < 0)
            {
                stanjeKalkDouble *= -1;
            }

            do
            {
                stanjeKalkDouble /= 10;
              i++;
            } while (stanjeKalkDouble > 1);
            return i;
        }
        private void zaokruziNa10()
        {
            double parsirano;
            if (double.TryParse(stanjeKalk, out parsirano)==true)
            {
                double stanjeKalkDouble;
                stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
                stanjeKalkDouble = Math.Round(stanjeKalkDouble, (10 - provjeriVelicinuBroja()));
                stanjeKalk = stanjeKalkDouble.ToString();
            }
        }

        private void zaokruziNa10CijeliBroj()
        {
            double parsirano;
            double stanjeKalkDouble;
            if (double.TryParse(stanjeKalk, out parsirano) == true)
            {
                stanjeKalkDouble = Convert.ToDouble(stanjeKalk);
                if (stanjeKalkDouble > 9999999999)
                {
                    do
                    {
                        stanjeKalkDouble /= 10;
                    } while (stanjeKalkDouble > 9999999999);
                    stanjeKalk = Math.Truncate(stanjeKalkDouble).ToString();
                }
            }
        }

        #endregion 



        private void postaviZastavicu(char binOperac)
        {
            if (binOperac == '+') zastavica = 1;
            if (binOperac == '-') zastavica = 2;
            if (binOperac == '*') zastavica = 3;
            if (binOperac == '/') zastavica = 4;
        }
        private void izracunaj()
        {
            if (zastavica == 11) operand += Convert.ToDouble(stanjeKalk);
            if (zastavica == 22) operand -= Convert.ToDouble(stanjeKalk);
            if (zastavica == 33) operand *= Convert.ToDouble(stanjeKalk);
            if (zastavica == 44) operand /= Convert.ToDouble(stanjeKalk);
            provjeriNajmanji();
            provjeriNajveci();
            zaokruziNa10();
        }
    }


}
