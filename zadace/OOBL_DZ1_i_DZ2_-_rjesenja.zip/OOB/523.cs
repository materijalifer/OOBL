﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class StockExchange : IStockExchange
    {

        private const int accuracy = 3;

        ////////////////////////
        /////////////
        //////         Stocks  Begin
        /////////////
        ///////////////////////

        private readonly Dictionary<string, IStock> StockRegister = new Dictionary<string, IStock>();

        public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice,
                    DateTime inTimeStamp)
        {
            inStockName = inStockName.ToUpper();
            if (CheckKey(StockRegister.Keys, inStockName) && CheckPrice(inInitialPrice) && CheckNumberOfShares(inNumberOfShares))
                StockRegister.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            inStockName = CheckName(StockRegister.Keys, inStockName);
            
            foreach (var index in IndexRegister)
                if (IndexRegister[index.Key].ContainsStock(StockRegister[inStockName].Name))
                    IndexRegister[index.Key].RemoveStock(inStockName);

            foreach (var portfolio in PortfolioRegister)
                if (PortfolioRegister[portfolio.Key].ContainsStock(StockRegister[inStockName].Name))
                {    
                    PortfolioRegister[portfolio.Key].RemoveStock(inStockName);
                    PortfolioRegister[portfolio.Key].RemoveFromNumberOfSharesOfStock(inStockName, (int)StockRegister[inStockName].NumberOfShares);
                }
            StockRegister.Remove(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return StockRegister.ContainsKey(inStockName.ToUpper());
        }

        public int NumberOfStocks()
        {
            return StockRegister.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if ((!StockRegister[inStockName].CheckEqualTimeStamp(inIimeStamp)))
                StockRegister[inStockName].SetPrice(inIimeStamp, inStockValue);
            else
                throw new StockExchangeException("Problem with timestamp");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if ((inTimeStamp < StockRegister[inStockName].CreationTime))
                throw new StockExchangeException("Problem with timestamp");
            return decimal.Round(StockRegister[inStockName].GetPrice(inTimeStamp), accuracy);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            inStockName = CheckName(StockRegister.Keys, inStockName);
            return decimal.Round(StockRegister[inStockName].InitialPrice, accuracy);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            inStockName = CheckName(StockRegister.Keys, inStockName);
            return decimal.Round(StockRegister[inStockName].CurrentPrice, accuracy);
        }

        ////////////////////////
        /////////////
        //////         Stocks  End
        /////////////
        ///////////////////////

        private bool CheckPrice(Decimal price)
        {
            Decimal minimalPrice = 0;
            if (price <= minimalPrice)
                throw new StockExchangeException("Price must be greater than 0!");
            return true;
        }

        private bool CheckNumberOfShares(long inNumberOfShares)
        {
            long minimalNumberOfShares = 0;
            if (inNumberOfShares <= minimalNumberOfShares)
                throw new StockExchangeException("Number must be greater than 0!");
            return true;
        }

        private bool CheckKey(IEnumerable<string> names, string inName)
        {
            if (string.IsNullOrEmpty(inName))
                throw new StockExchangeException("Invalid name!");

            if (names.Any(str => str == inName))
                throw new StockExchangeException("(" + inName + ") already exists!!");

            return true;
        }

        private string CheckName(IEnumerable<string> names, string inName)
        {
            inName = inName.ToUpper();
            if (!names.Any(str => str == inName))
                throw new StockExchangeException("(" + inName + ") doesn't exist!!");

            return inName;
        }

        ////////////////////////
        /////////////
        //////         Index  Begin
        /////////////
        ///////////////////////


        private readonly Dictionary<string, IIndex> IndexRegister = new Dictionary<string, IIndex>();

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            inIndexName = inIndexName.ToUpper();
            if (CheckKey(IndexRegister.Keys, inIndexName))
            {
                if (inIndexType == IndexTypes.AVERAGE)
                    IndexRegister.Add(inIndexName, new AverageIndex(inIndexName));
                else if (inIndexType == IndexTypes.WEIGHTED)
                    IndexRegister.Add(inIndexName, new WeightedIndex(inIndexName));
                else
                    throw new StockExchangeException("Incorrect index type");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            inIndexName = CheckName(IndexRegister.Keys, inIndexName);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if (!IndexRegister[inIndexName].ContainsStock(StockRegister[inStockName].Name))
                IndexRegister[inIndexName].AddStock(StockRegister[inStockName]);
            else
                throw new StockExchangeException("Index already contains stock!");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            inIndexName = CheckName(IndexRegister.Keys, inIndexName);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if (IndexRegister[inIndexName].ContainsStock(StockRegister[inStockName].Name))
                IndexRegister[inIndexName].RemoveStock(StockRegister[inStockName].Name);
            else
                throw new StockExchangeException("Index doesn't contain the stock!");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            inIndexName = CheckName(IndexRegister.Keys, inIndexName);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            return IndexRegister[inIndexName].ContainsStock(StockRegister[inStockName].Name);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            inIndexName = CheckName(IndexRegister.Keys, inIndexName);
            return decimal.Round(IndexRegister[inIndexName].GetValue(inTimeStamp), accuracy);
        }

        public bool IndexExists(string inIndexName)
        {
            return IndexRegister.ContainsKey(inIndexName.ToUpper());
        }

        public int NumberOfIndices()
        {
            return IndexRegister.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            inIndexName = CheckName(IndexRegister.Keys, inIndexName);

            return IndexRegister[inIndexName].NumberOfStocks;
        }

        ////////////////////////
        /////////////
        //////         Index  End
        /////////////
        ///////////////////////


        private string CheckPortfolioName(IEnumerable<string> names, string inName)
        {
            if (!names.Any(str => str == inName))
                throw new StockExchangeException("Portfolio (" + inName + ") doesn't exist!!");

            return inName;
        }

        ////////////////////////
        /////////////
        //////         Portfolio  Begin
        /////////////
        ///////////////////////

        private readonly Dictionary<string, IPortfolio> PortfolioRegister = new Dictionary<string, IPortfolio>();

        public void CreatePortfolio(string inPortfolioID)
        {
            if (CheckKey(PortfolioRegister.Keys, inPortfolioID))
                PortfolioRegister.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            inStockName = CheckName(StockRegister.Keys, inStockName);

            if (CheckNumberOfShares(numberOfShares))
            {
                if (PortfolioRegister[inPortfolioID].ContainsStock(StockRegister[inStockName].Name))
                {
                    int sum = 0;
                    foreach (var portfolio in PortfolioRegister)
                    {
                        sum += PortfolioRegister[portfolio.Key].GetNumberOfSharesOfStock(inStockName);
                        int max = sum + numberOfShares;
                        if (sum + numberOfShares > StockRegister[inStockName].NumberOfShares)
                            max = (int)StockRegister[inStockName].NumberOfShares;
                        PortfolioRegister[portfolio.Key].SetNumberOfSharesOfStock(inStockName, max);
                    }
                }
                else
                {
                    PortfolioRegister[inPortfolioID].AddStock(StockRegister[inStockName]);
                    if((numberOfShares < StockRegister[inStockName].NumberOfShares))
                        PortfolioRegister[inPortfolioID].AddNumberOfSharesOfStock(inStockName, numberOfShares);
                    else
                        PortfolioRegister[inPortfolioID].AddNumberOfSharesOfStock(inStockName, (numberOfShares - (int)StockRegister[inStockName].NumberOfShares));
                }
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            PortfolioRegister[inPortfolioID].RemoveFromNumberOfSharesOfStock(inStockName, numberOfShares);
            PortfolioRegister[inPortfolioID].RemoveStock(inStockName);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if (PortfolioRegister[inPortfolioID].ContainsStock(StockRegister[inStockName].Name))
                PortfolioRegister[inPortfolioID].RemoveStock(StockRegister[inStockName].Name);
            else
                throw new StockExchangeException("Portfolio doesn't contain the stock!");
        }

        public int NumberOfPortfolios()
        {
            return PortfolioRegister.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);

            return PortfolioRegister[inPortfolioID].NumberOfStocks;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return PortfolioRegister.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            return PortfolioRegister[inPortfolioID].ContainsStock(StockRegister[inStockName].Name);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            inStockName = CheckName(StockRegister.Keys, inStockName);
            if (PortfolioRegister[inPortfolioID].ContainsStock(StockRegister[inStockName].Name))
                return PortfolioRegister[inPortfolioID].GetNumberOfSharesOfStock(inStockName);
            else
                throw new StockExchangeException("Portfolio doesn't contain the stock!");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            return decimal.Round(PortfolioRegister[inPortfolioID].GetValue(timeStamp), accuracy);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            inPortfolioID = CheckPortfolioName(PortfolioRegister.Keys, inPortfolioID);
            if(Month<1 && Month>12 && Year<1)
                throw new StockExchangeException("DateTime is incorrect!");
            DateTime firstDayOfTheMonth = new DateTime(Year, Month, 1);
            DateTime lastDayOfTheMonth = firstDayOfTheMonth.AddMonths(1).AddDays(-1);
            return ((PortfolioRegister[inPortfolioID].GetValue(lastDayOfTheMonth) - PortfolioRegister[inPortfolioID].GetValue(firstDayOfTheMonth)) / (PortfolioRegister[inPortfolioID].GetValue(firstDayOfTheMonth))) * 100;
        }
    }

    ////////////////////////
    /////////////
    //////         Portfolio  End
    /////////////
    ///////////////////////

    public interface IStock
    {
        string Name { get; }

        long NumberOfShares { get; }

        DateTime CreationTime { get; }

        Decimal InitialPrice { get; }

        Decimal CurrentPrice { get; }

        void SetPrice(DateTime time, decimal price);

        decimal GetPrice(DateTime time);

        bool CheckEqualTimeStamp(DateTime timeStamp);

    }

    public class Stock : IStock
    {
        public string Name { get; private set; }

        public long NumberOfShares { get; private set; }

        public Decimal InitialPrice { get; private set; }

        public DateTime CreationTime { get; private set; }

        public Decimal CurrentPrice { get; private set; }

        private readonly SortedDictionary<DateTime, Decimal> _diary = new SortedDictionary<DateTime, Decimal>();

        public Stock(string name, long numberOfShares, Decimal initPrice, DateTime timeStamp)
        {
            Name = name;
            InitialPrice = initPrice;
            NumberOfShares = numberOfShares;
            CreationTime = timeStamp;
            CurrentPrice = InitialPrice;
            _diary.Add(timeStamp, initPrice);
        }

        public void SetPrice(DateTime timeStamp, Decimal price)
        {
            _diary.Add(timeStamp, price);

            if (timeStamp > _diary.Keys.Last())
                CurrentPrice = price;

            if (timeStamp < CreationTime)
                CreationTime = timeStamp;
            CurrentPrice = InitialPrice;
            InitialPrice = price;
        }

        public Decimal GetPrice(DateTime timeStamp)
        {
            if (_diary.ContainsKey(timeStamp))
                return _diary[timeStamp];

            DateTime proximate = _diary.Keys.Last(time => time <= timeStamp);
            return _diary[proximate];
        }

        public bool CheckEqualTimeStamp(DateTime timeStamp)
        {
            if (_diary.ContainsKey(timeStamp)) return true;
            return false;
        }
    }

    interface IStockCollection
    {
        string Name { get; }

        int NumberOfStocks { get; }

        List<IStock> Stocks { get; }

        void AddStock(IStock stock);

        void RemoveStock(string stockName);

        bool ContainsStock(string stockName);
    }

    abstract class StockCollection : IStockCollection
    {
        private readonly string _name;

        public string Name { get { return _name; } }

        private readonly List<IStock> _stocks = new List<IStock>();

        public int NumberOfStocks { get { return _stocks.Count; } }

        public List<IStock> Stocks { get { return new List<IStock>(_stocks); } }

        internal protected StockCollection(string name)
        {
            _name = name;
        }

        public void AddStock(IStock stock)
        {
            _stocks.Add(stock);
        }

        public void RemoveStock(string stockName)
        {
            int index = 0;
            for (int i = 0; i < _stocks.Count; i++)
                if (_stocks[i].Name == stockName)
                {
                    index = i;
                    break;
                }
            _stocks.RemoveAt(index);
        }

        public bool ContainsStock(string stockName)
        {
            return _stocks.Any(a => a.Name == stockName);
        }
    }

    interface IIndex : IStockCollection
    {
        decimal GetValue(DateTime time);
    }

    sealed class AverageIndex : StockCollection, IIndex
    {
        internal AverageIndex(string name) : base(name){ }

        public decimal GetValue(DateTime timeStamp)
        {
            var stocks = Stocks;
            decimal stockValueSum = 0;
            for (int i = 0; i < NumberOfStocks; i++)
            {
                var stockValue = stocks[i].GetPrice(timeStamp);
                stockValueSum += stockValue;
            }
            return stockValueSum / NumberOfStocks;
        }
    }

    sealed class WeightedIndex : StockCollection, IIndex
    {
        internal WeightedIndex(string name) : base(name){ }

        public decimal GetValue(DateTime timeStamp)
        {
            var stockValues = new decimal[NumberOfStocks];
            var stocks = Stocks;
            decimal stockValueSum = 0;
            for (int i = 0; i < NumberOfStocks; i++)
            {
                var stockValue = stocks[i].GetPrice(timeStamp);
                stockValues[i] = stockValue;
                stockValueSum += stockValue * stocks[i].NumberOfShares;
            }

            decimal indexValue = 0;
            for (int i = 0; i < NumberOfStocks; i++)
                indexValue += (stockValues[i] / stockValueSum) * stockValues[i] * stocks[i].NumberOfShares;
            return indexValue;
        }
    }

    interface IPortfolio : IStockCollection
    {
        decimal GetValue(DateTime time);

        void SetNumberOfSharesOfStock(string stockName, int SharesOfStock);

        void AddNumberOfSharesOfStock(string stockName, int SharesOfStock);

        void RemoveFromNumberOfSharesOfStock(string stockName, int SharesOfStock);

        int GetNumberOfSharesOfStock(string stockName);

        bool CheckContainsStock(string stockName);
    }

    class Portfolio : StockCollection, IPortfolio
    {
        internal Portfolio(string name) : base(name){ }

        private Dictionary<string, int> _numberOfSharesOfStock = new Dictionary<string, int>();

        public decimal GetValue(DateTime timeStamp)
        {
            var stocks = Stocks;
            decimal stockValueSum = 0;
            for (int i = 0; i < NumberOfStocks; i++)
            {
                var stockValue = stocks[i].GetPrice(timeStamp);
                stockValueSum += stockValue*_numberOfSharesOfStock[stocks[i].Name];
            }
            return stockValueSum;
        }

        public void SetNumberOfSharesOfStock(string stockName, int SharesOfStock)
        {
            _numberOfSharesOfStock[stockName] = SharesOfStock;
        }

        public void AddNumberOfSharesOfStock(string stockName, int SharesOfStock)
        {
            _numberOfSharesOfStock.Add(stockName, SharesOfStock);
        }

        public int GetNumberOfSharesOfStock(string stockName)
        {
            if (_numberOfSharesOfStock.ContainsKey(stockName))
                return _numberOfSharesOfStock[stockName];
            throw new StockExchangeException("Cannot get number of shares of stock!");
        }

       public void RemoveFromNumberOfSharesOfStock(string stockName, int SharesOfStock) 
        {
            int dif = 0;
            if (_numberOfSharesOfStock.ContainsKey(stockName))
                dif = SharesOfStock - _numberOfSharesOfStock[stockName];
                if(dif > 0 )
                    _numberOfSharesOfStock[stockName] = dif;
                else
                    _numberOfSharesOfStock.Remove(stockName);
        }

        public bool CheckContainsStock(string stockName)
        {
            if (_numberOfSharesOfStock.ContainsKey(stockName))
                return true;
            return false;
        }
    }
}