﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{

    /*
     * Razred koji stvara novu burzu.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public static class Factory
    {

        /*
         * Metoda koja stvara novu burzu.
         * 
         * vraća: burzu
         */
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }

    }

    /*
     * Razred koji predstavlja dionicu.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class Dionica
    {

        /*
         * Ukupan broj ovih dionica.
         */
        private long broj;

        /*
         * Trenutačni broj dionica.
         */
        private long trenutacniBroj;

        /*
         * Povijesni pregled cijene dionice.
         */
        private IList<decimal> cijene = new List<decimal>();

        /*
         * Povijet zadavanja cijene dionice.
         */
        private List<DateTime> vremenskeOznake = new List<DateTime>();

        /*
         * Konstruktor.
         * 
         * parametar broj: broj dionica
         * parametar pocetnaCijena: početna cijena dionice
         * parametar vremenskaOznaka: vrijeme zadavanja početne cijene dionice
         * baca StockArgumentException: ako je broj manji od nule ili jednak ili je početna cijena manja od nule ili jednaka
         */
        public Dionica(long broj, decimal pocetnaCijena, DateTime vremenskaOznaka)
        {
            if (broj <= 0)
            {
                throw new StockExchangeException("Broj je manji od nule ili jednak!");
            }
            this.broj = broj;
            trenutacniBroj = broj;
            if (pocetnaCijena <= 0)
            {
                throw new StockExchangeException("Početna je cijena manja od nule ili jednaka!");
            }
            cijene.Add(pocetnaCijena);
            vremenskeOznake.Add(vremenskaOznaka);
        }

        /*
         * Svojstvo dohvaća ukupan broj ovih dionica.
         */
        public long Broj
        {
            get
            {
                return broj;
            }
        }

        /*
         * Metoda postavlja cijenu dionice.
         * 
         * parametar vremenskaOznaka: vrijeme zadavanja cijene dionice
         * parametar vrijednost: cijena dionice
         * baca StockArgumentException: ako je vrijednost manja od nule ili jednaka
         */
        public void PostaviCijenu(DateTime vremenskaOznaka, decimal vrijednost)
        {
            int i = vremenskeOznake.FindIndex(o => o >= vremenskaOznaka);

            if (vrijednost <= 0)
            {
                throw new StockExchangeException("Vrijednost je manja od nule ili jednaka!");
            }
            if (i < 0)
            {
                vremenskeOznake.Add(vremenskaOznaka);
                cijene.Add(vrijednost);
            }
            else if (vremenskeOznake[i] == vremenskaOznaka)
            {
                cijene[i] = vrijednost;
            }
            else
            {
                vremenskeOznake.Insert(i, vremenskaOznaka);
                cijene.Insert(i, vrijednost);
            }
        }

        /*
         * Metoda dohvaća cijenu dionice.
         * 
         * parametar vremenskaOznaka: vrijeme za koje se dohvaća cijena
         * vraća: cijenu dionice
         * baca StockArgumentException: ako je vrijeme manje od početnoga ili veće od sadašnjega
         */
        public decimal DohvatiCijenu(DateTime vremenskaOznaka)
        {
            int i = vremenskeOznake.FindIndex(o => o > vremenskaOznaka);

            if (vremenskaOznaka < vremenskeOznake[0] || vremenskaOznaka > DateTime.Now)
            {
                throw new StockExchangeException("Vrijeme je manje od početnoga ili veće od sadašnjega!");
            }
            return i >= 0 ? cijene[i - 1] : cijene.Last();
        }

        /*
         * Svojstvo dohvaća početnu cijenu dionice.
         */
        public decimal PocetnaCijena
        {
            get
            {
                return cijene.First();
            }
        }

        /*
         * Svojstvo dohvaća posljednju cijenu dionice.
         */
        public decimal PosljednjaCijena
        {
            get
            {
                return cijene.Last();
            }
        }

        /*
         * Metoda kupuje dionicu.
         * 
         * parametar broj: broj dionica za kupovanje
         * baca StockArgumentException: ako je broj prevelik
         */
        public void Kupi(int broj)
        {
            if (broj > trenutacniBroj)
            {
                throw new StockExchangeException("Broj je prevelik!");
            }
            trenutacniBroj -= broj;
        }

        /*
         * 
         * Metoda prodaje dionicu.
         * 
         * parametar broj: broj dionica za prodavanje
         */
        public void Prodaj(int broj)
        {
            trenutacniBroj += broj;
        }

    }

    /*
     * Razred koji predstavlja indeks.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public abstract class Indeks
    {

        /*
         * Sve dionice u indeksu.
         */
        protected IDictionary<string, Dionica> dionice = new Dictionary<string, Dionica>(StringComparer.OrdinalIgnoreCase);

        /*
         * Metoda dodaje dionicu u indeks.
         * 
         * parametar nazivDionice: naziv dionice
         * parametar dionica: ta dionica
         * baca StockArgumentException: ako dionica već postoji u indeksu
         */
        public void DodajDionicu(string nazivDionice, Dionica dionica)
        {
            try
            {
                dionice.Add(nazivDionice, dionica);
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException("Dionica već postoji!");
            }
        }

        /*
         * Metoda uklanja dionicu iz indeksa.
         * 
         * parametar nazivDionice: naziv dionice
         * baca StockArgumentException: ako dionica ne postoji u indeksu
         */
        public void UkloniDionicu(string nazivDionice)
        {
            if (!dionice.Remove(nazivDionice))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda provjerava postoji li dionica u indeksu.
         * 
         * parametar nazivDionice: naziv dionice
         * vraća: postoji li dionica
         */
        public bool DionicaJeDio(string nazivDionice)
        {
            return dionice.ContainsKey(nazivDionice);
        }

        /*
         * Metoda dohvaća vrijednost indeksa.
         * 
         * parametar vremenskaOznaka: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost indeksa
         */
        public abstract decimal DohvatiVrijednost(DateTime vremenskaOznaka);

        /*
         * Svojstvo koje dohvaća broj dionica u indeksu.
         */
        public int BrojDionica
        {
            get
            {
                return dionice.Count;
            }
        }

    }

    /*
     * Razred koji predstavlja prosječni indeks.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class ProsjecniIndeks : Indeks
    {

        /*
         * Metoda dohvaća vrijednost prosječnoga indeksa.
         * 
         * parametar vremenskaOznaka: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost indeksa
         */
        public override decimal DohvatiVrijednost(DateTime vremenskaOznaka)
        {
            decimal cijena = 0;

            foreach (var item in dionice)
            {
                cijena += item.Value.DohvatiCijenu(vremenskaOznaka);
            }
            return decimal.Round(cijena / dionice.Count, 3);
        }

    }

    /*
     * Razred koji predstavlja težinski indeks.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class TezinskiIndeks : Indeks
    {

        /*
         * Metoda dohvaća vrijednost težinskoga indeksa.
         * 
         * parametar vremenskaOznaka: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost indeksa
         */
        public override decimal DohvatiVrijednost(DateTime vremenskaOznaka)
        {
            decimal vrijednost = 0, odredenaCijena, ukupnaCijena = 0;

            foreach (var item in dionice)
            {
                vrijednost += item.Value.Broj * item.Value.DohvatiCijenu(vremenskaOznaka);
            }
            foreach (var item in dionice)
            {
                odredenaCijena = item.Value.DohvatiCijenu(vremenskaOznaka);
                ukupnaCijena += item.Value.Broj * odredenaCijena * odredenaCijena / vrijednost;
            }
            return decimal.Round(ukupnaCijena, 3);
        }

    }

    /*
     * Razred koji predstavlja portfelj.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class Portfelj
    {

        /*
         * Sve dionice u portfelju.
         */
        private IDictionary<string, Dionica> dionice = new Dictionary<string, Dionica>(StringComparer.OrdinalIgnoreCase);

        /*
         * Brojevi dionica portfelja.
         */
        private IDictionary<string, int> brojeviDionica = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        /*
         * Metoda dodaje dionicu u portfelj.
         * 
         * parametar nazivDionice: naziv dionice
         * parametar dionica: ta dionica
         * parametar brojDionica: broj dionica za dodavanje
         * baca StockArgumentException: ako je broj dionica manji od nule ili jednak
         */
        public void DodajDionicu(string nazivDionice, Dionica dionica, int brojDionica)
        {
            if (brojDionica <= 0)
            {
                throw new StockExchangeException("Broj je dionica manji od nule ili jednak!");
            }
            dionica.Kupi(brojDionica);
            if (dionice.ContainsKey(nazivDionice))
            {
                brojeviDionica[nazivDionice] += brojDionica;
            }
            else
            {
                dionice.Add(nazivDionice, dionica);
                brojeviDionica.Add(nazivDionice, brojDionica);
            }
        }

        /*
         * Metoda uklanja dionicu iz portfelja.
         * 
         * parametar nazivDionice: naziv dionice
         * parametar brojDionice: broj dionica za uklanjanje
         * baca StockArgumentException: ako je broj dionica manji od nule ili jednak, prevelik je ili dionica ne postoji u portfelju
         */
        public void UkloniDionicu(string nazivDionice, int brojDionica)
        {
            if (brojDionica <= 0)
            {
                throw new StockExchangeException("Broj je dionica manji od nule ili jednak!");
            }
            try
            {
                if (brojeviDionica[nazivDionice] < brojDionica)
                {
                    throw new StockExchangeException("Broj je dionica prevelik!");
                }
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            dionice[nazivDionice].Prodaj(brojDionica);
            if (brojeviDionica[nazivDionice] == brojDionica)
            {
                dionice.Remove(nazivDionice);
                brojeviDionica.Remove(nazivDionice);
            }
            else
            {
                brojeviDionica[nazivDionice] -= brojDionica;
            }
        }

        /*
         * Metoda uklanja dionicu iz portfelja.
         * 
         * parametar nazivDionice: naziv dionice
         * baca StockArgumentException: ako dionica ne postoji u portfelju
         */
        public void UkloniDionicu(string nazivDionice)
        {
            try
            {
                dionice[nazivDionice].Prodaj(brojeviDionica[nazivDionice]);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            dionice.Remove(nazivDionice);
            brojeviDionica.Remove(nazivDionice);
        }

        /*
         * Svojstvo koje dohvaća broj dionica.
         */
        public int BrojDionica
        {
            get
            {
                return dionice.Count;
            }
        }

        /*
         * Metoda provjerava postoji li dionica u portfelju.
         * 
         * parametar nazivDionice: naziv dionice
         * vraća: postoji li dionica
         */
        public bool DionicaJeDio(string nazivDionice)
        {
            return dionice.ContainsKey(nazivDionice);
        }

        /*
         * Metoda koja dohvaća broj određenih dionica u portfelju.
         * 
         * parametar nazivDionice: naziv određene dionice
         * baca StockArgumentException: ako dionica ne postoji u portfelju
         */
        public int DohvatiBrojDionica(string nazivDionice)
        {
            try
            {
                return brojeviDionica[nazivDionice];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda dohvaća vrijednost portfelja.
         * 
         * parametar vremenskaOznaka: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost portfelja
         */
        public decimal DohvatiVrijednost(DateTime vremenskaOznaka)
        {
            decimal zbroj = 0;

            foreach (var item in dionice)
            {
                zbroj += brojeviDionica[item.Key] * item.Value.DohvatiCijenu(vremenskaOznaka);
            }
            return decimal.Round(zbroj, 3);
        }

        /*
         * Metoda dohvaća postotnu promjenu vrijednosti portfelja u mjesecu.
         * 
         * parametar godina: godina za koju se dohvaća promjena
         * parametar mjesec: mjesec za koju se dohvaća promjena
         * vraća: promjenu vrijednosti
         */
        public decimal DohvatiPromjenuVrijednosti(int godina, int mjesec)
        {
            DateTime prvi = new DateTime(godina, mjesec, 1);
            DateTime posljednji = new DateTime(godina, mjesec, 1, 23, 59, 59, 999).AddMonths(1).AddDays(-1);
            decimal pocetak = 0;
            decimal kraj = 0;

            foreach (var item in dionice)
            {
                pocetak += brojeviDionica[item.Key] * item.Value.DohvatiCijenu(prvi);
                kraj += brojeviDionica[item.Key] * item.Value.DohvatiCijenu(posljednji);
            }
            return decimal.Round((kraj - pocetak) / pocetak * 100, 3);
        }

    }

    /*
     * Razred koji predstavlja burzu.
     * 
     * tvorac: Luka Milić
     * inačica: 1.0
     */
    public class StockExchange : IStockExchange
    {

        /*
         * Sve dionice na burzi.
         */
        private IDictionary<string, Dionica> dionice = new Dictionary<string, Dionica>(StringComparer.OrdinalIgnoreCase);

        /*
         * Svi indeksi na burzi.
         */
        private IDictionary<string, Indeks> indeksi = new Dictionary<string, Indeks>(StringComparer.OrdinalIgnoreCase);

        /*
         * Svi portfelji na burzi.
         */
        private IDictionary<string, Portfelj> portfelji = new Dictionary<string, Portfelj>();

        /*
         * Metoda dodaje dionicu na burzu.
         * 
         * parametar inStockName: naziv dionice
         * parametar inNumberOfShares: ukupan broj ovih dionica
         * parametar inInitialPrice: početna cijena dionice
         * parametar inTimeStamp: vrijeme zadavanja početne cijene dionice
         * baca StockArgumentException: ako dionica već postoji na burzi
         */
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                dionice.Add(inStockName, new Dionica(inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException("Dionica već postoji!");
            }
        }

        /*
         * Metoda uklanja dionicu s burze.
         * 
         * parametar inStockName: naziv dionice
         * baca StockArgumentException: ako dionica ne postoji na burzi
         */
        public void DelistStock(string inStockName)
        {
            if (!dionice.Remove(inStockName))
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
            foreach (var item in indeksi)
            {
                item.Value.UkloniDionicu(inStockName);
            }
            foreach (var item in portfelji)
            {
                item.Value.UkloniDionicu(inStockName);
            }
        }

        /*
         * Metoda provjerava postoji li dionica na burzi.
         * 
         * parametar inStockName: naziv dionice
         * vraća: postoji li dionica
         */
        public bool StockExists(string inStockName)
        {
            return dionice.ContainsKey(inStockName);
        }

        /*
         * Metoda dohvaća broj dionica na burzi.
         * 
         * vraća: broj dionica
         */
        public int NumberOfStocks()
        {
            return dionice.Count;
        }

        /*
         * Metoda postavlja cijenu dionice.
         * 
         * parametar inStockName: naziv dionice
         * parametar inTimeStamp: vrijeme zadavanja cijene dionice
         * parametar inStockValue: cijena dionice
         * baca StockArgumentException: ako dionica ne postoji na burzi
         */
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            try
            {
                dionice[inStockName].PostaviCijenu(inTimeStamp, inStockValue);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda dohvaća cijenu dionice.
         * 
         * parametar inStockName: naziv dionice
         * parametar inTimeStamp: vrijeme za koje se dohvaća cijena
         * vraća: cijenu dionice
         * baca StockArgumentException: ako dionica ne postoji na burzi
         */
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                return dionice[inStockName].DohvatiCijenu(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda dohvaća početnu cijenu dionice.
         * 
         * parametar inStockName: naziv dionice
         * vraća: početnu cijenu dionice
         * baca StockArgumentException: ako dionica ne postoji na burzi
         */
        public decimal GetInitialStockPrice(string inStockName)
        {
            try
            {
                return dionice[inStockName].PocetnaCijena;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda dohvaća posljednju cijenu dionice.
         * 
         * parametar inStockName: naziv dionice
         * vraća: posljednju cijenu dionice
         * baca StockArgumentException: ako dionica ne postoji na burzi
         */
        public decimal GetLastStockPrice(string inStockName)
        {
            try
            {
                return dionice[inStockName].PosljednjaCijena;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        /*
         * Metoda stvara nov indeks na burzi.
         * 
         * parametar inIndexName: naziv indeksa
         * parametar inIndexType: tip indeksa
         * baca StockArgumentException: ako indeks već postoji na burzi
         */
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType == IndexTypes.AVERAGE)
            {
                try
                {
                    indeksi.Add(inIndexName, new ProsjecniIndeks());
                }
                catch (ArgumentException)
                {
                    throw new StockExchangeException("Indeks već postoji!");
                }
            }
            else if (inIndexType == IndexTypes.WEIGHTED)
            {
                try
                {
                    indeksi.Add(inIndexName, new TezinskiIndeks());
                }
                catch (ArgumentException)
                {
                    throw new StockExchangeException("Indeks već postoji!");
                }
            }
            else
            {
                throw new StockExchangeException("Tip indeksa ne postoji!");
            }
        }

        /*
         * Metoda dodaje dionicu u indeks.
         * 
         * parametar inIndexName: naziv indeksa
         * parametar inStockName: naziv dionice
         * baca StockArgumentException: ako indeks ili dionica ne postoji na burzi
         */
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                indeksi[inIndexName].DodajDionicu(inStockName, dionice[inStockName]);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Indeks ili dionica ne postoji!");
            }
        }

        /*
         * Metoda uklanja dionicu iz indeksa.
         * 
         * parametar inIndexName: naziv indeksa
         * parametar inStockName: naziv dionice
         * baca StockArgumentException: ako indeks ne postoji na burzi
         */
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try
            {
                indeksi[inIndexName].UkloniDionicu(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Indeks ne postoji!");
            }
        }

        /*
         * Metoda provjerava postoji li dionica u indeksu.
         * 
         * parametar inIndexName: naziv indeksa
         * parametar inStockName: naziv dionice
         * vraća: postoji li dionica
         * baca StockExchangeException: ako indeks ne postoji na burzi
         */
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                return indeksi[inIndexName].DionicaJeDio(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Indeks ne postoji!");
            }
        }


        /*
         * Metoda dohvaća vrijednost indeksa.
         * 
         * parametar inIndexName: naziv indeksa
         * parametar inTimeStamp: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost indeksa
         * baca StockExchangeException: ako indeks ne postoji na burzi
         */
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                return indeksi[inIndexName].DohvatiVrijednost(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Indeks ne postoji!");
            }
        }

        /*
         * Metoda provjerava postoji li indeks na burzi.
         * 
         * parametar inIndexName: naziv indeksa
         * vraća: postoji li indeks
         */
        public bool IndexExists(string inIndexName)
        {
            return indeksi.ContainsKey(inIndexName);
        }

        /*
         * Metoda dohvaća broj indekasa na burzi.
         * 
         * vraća: broj indekasa
         */
        public int NumberOfIndices()
        {
            return indeksi.Count;
        }

        /*
         * Metoda provjerava broj dionica u indeksu.
         * 
         * parametar inIndexName: naziv indeksa
         * vraća: broj dionica
         * baca StockExchangeException: ako indeks ne postoji na burzi
         */
        public int NumberOfStocksInIndex(string inIndexName)
        {
            try
            {
                return indeksi[inIndexName].BrojDionica;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Indeks ne postoji!");
            }
        }

        /*
         * Metoda stvara nov portfelj na burzi.
         * 
         * parametar inPortfolioID: naziv portfelja
         * baca StockArgumentException: ako portfelj već postoji na burzi
         */
        public void CreatePortfolio(string inPortfolioID)
        {
            try
            {
                portfelji.Add(inPortfolioID, new Portfelj());
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException("Portfelj već postoji!");
            }
        }

        /*
         * Metoda dodaje dionicu u portfelj.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar inStockName: naziv dionice
         * parametar numberOfShares: broj dionica za dodavanje
         * baca StockArgumentException: ako portfelj ili dionica ne postoji na burzi
         */
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                portfelji[inPortfolioID].DodajDionicu(inStockName, dionice[inStockName], numberOfShares);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ili dionica ne postoji!");
            }
        }

        /*
         * Metoda uklanja dionicu iz portfelja.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar inStockName: naziv dionice
         * parametar numberOfShares: broj dionica za uklanjanje
         * baca StockArgumentException: ako portfelj ne postoji na burzi
         */
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                portfelji[inPortfolioID].UkloniDionicu(inStockName, numberOfShares);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * 
         * Metoda uklanja dionicu iz portfelja.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar inStockName: naziv dionice
         * baca StockArgumentException: ako portfelj ne postoji na burzi
         */
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                portfelji[inPortfolioID].UkloniDionicu(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * 
         * Metoda dohvaća broj portfelja na burzi.
         * 
         * vraća: broj portfelja
         */
        public int NumberOfPortfolios()
        {
            return portfelji.Count;
        }

        /*
         * Metoda dohvaća broj dionica u portfelju.
         * 
         * parametar inPortfolioID: naziv portfelja
         * vraća: broj dionica
         * baca StockExchangeException: ako portfelj ne postoji na burzi
         */
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try
            {
                return portfelji[inPortfolioID].BrojDionica;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * Metoda provjerava postoji li portfelj na burzi.
         * 
         * parametar inPortfolioID: naziv portfelja
         * vraća: postoji li portfelj
         */
        public bool PortfolioExists(string inPortfolioID)
        {
            return portfelji.ContainsKey(inPortfolioID);
        }

        /*
         * Metoda provjerava postoji li dionica u portfelju.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar inStockName: naziv dionice
         * vraća: postoji li dionica
         * baca StockExchangeException: ako portfelj ne postoji na burzi
         */
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                return portfelji[inPortfolioID].DionicaJeDio(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * Metoda dohvaća broj određenih dionica u portfelju.
         * 
         * parametar inPortfolioID: naziv portfelja
         * vraća: broj određenih dionica
         * baca StockExchangeException: ako portfelj ne postoji na burzi
         */
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                return portfelji[inPortfolioID].DohvatiBrojDionica(inStockName);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * Metoda dohvaća vrijednost portfelja.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar inTimeStamp: vrijeme za koje se dohvaća vrijednost
         * vraća: vrijednost portfelja
         * baca StockExchangeException: ako portfelj ne postoji na burzi
         */
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            try
            {
                return portfelji[inPortfolioID].DohvatiVrijednost(timeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

        /*
         * Metoda dohvaća postotnu promjenu vrijednosti portfelja u mjesecu.
         * 
         * parametar inPortfolioID: naziv portfelja
         * parametar year: godina za koju se dohvaća promjena
         * parametar month: mjesec za koji se dohvaća promjena
         * vraća: promjenu vrijednosti
         * baca StockExchangeException: ako portfelj ne postoji na burzi
         */
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int year, int month)
        {
            try
            {
                return portfelji[inPortfolioID].DohvatiPromjenuVrijednosti(year, month);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Portfelj ne postoji!");
            }
        }

    }

}