using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock 
     {
         string name;

    public string Name
    {
         get { return name; }
         set { name = value; }
    }

         public long NumOfShares
         {
             get { return numOfShares; }
             set { numOfShares = value; }
         }

         private long numOfShares;
         List<StockValChangeLog> valsLog;

         //konstruktor
         public Stock(string name, long numOfShares, Decimal initPrice, DateTime timeSet)
         {

             if ((initPrice <= 0) || (numOfShares <=0))
             {
                 throw  new StockExchangeException("Nedopu�tena cijena i/li broj dionice");
             }


            
             this.name = name; //postavlja ime
             this.NumOfShares = numOfShares; //koliko ih ima
             valsLog = new List<StockValChangeLog>(); //povijest promjena cijena
             StockValChangeLog tmp = new StockValChangeLog();
             tmp.TimeSet = timeSet;
             tmp.Price = initPrice;
             this.valsLog.Add(tmp);
             valsLog.Sort();
             valsLog.Reverse(); //sortirano po vremenu za kojeg je cijena unesena

         }

         public void setPrice(DateTime timeSet, Decimal stockPrice)
         {
   

             if (stockPrice < 0)
             {
                 throw new StockExchangeException("Nedopusten unos negativne cijene!");
             }

             foreach (var p in valsLog)
             {
                 if (p.TimeSet == timeSet)
                 {
                     throw new StockExchangeException("Cijena je vec unesena za to vrijeme!");
                 }
             }
             StockValChangeLog tmp = new StockValChangeLog();
             tmp.TimeSet = timeSet;
             tmp.Price = stockPrice;
             this.valsLog.Add(tmp);
             valsLog.Sort();
             valsLog.Reverse();
         }

         public Decimal getPriceAtTime(DateTime time)
         {
             int i = 0;

             if (this.valsLog[0].TimeSet > time)
             {
                 throw new StockExchangeException("Nemoguce dohvacanje cijene dionice za vrijeme"); //nije bila definirana uopce u tom trenutku
             }
             while ((i < this.valsLog.Count()) && (this.valsLog[i].TimeSet < time))
             {
                 i++;

             } //iteriramo po sortiranoj listi
             if (i == this.valsLog.Count())
             {
                 return this.valsLog[i-1].Price;
             }

             if (time == this.valsLog[i].TimeSet)
             {
                 return this.valsLog[i].Price; //ako smo na�li jednako vrijeme - vrati to
             }
             else
             {
                 return this.valsLog[i - 1].Price; //inace, vrati prethodnu
             }
         }

         public Decimal getInitPrice()
         {
             valsLog.Sort();
             valsLog.Reverse();
             return this.valsLog[0].Price; //prva cijena za koju je dionica definirana
         }

         public Decimal getLastPrice()
         {
             return this.valsLog[valsLog.Count() - 1].Price; //zadnja cijena za koju je definirana dionica
         }

 
     }

     public class StockValChangeLog : IComparable
     {
         public DateTime TimeSet;
         public Decimal Price;

         public int CompareTo(object other)
         {
             StockValChangeLog obj = other as StockValChangeLog;
             return obj.TimeSet.CompareTo(this.TimeSet); //IComparable je implementirano kako bi mogli sortirati po vremenu
         }


     }

     public class PortStockItem
     {
         //struktura s kojom radimok u Portfoliu - refenenca na origirnalnu dionicu + broj share-ova u portfoliju konkretnom
         public Stock OriginStock;
         int sharesInPortfolio; 

         public int SharesInPortfolio
         {
             get { return sharesInPortfolio; }
             set { sharesInPortfolio = value; }
         }

         public PortStockItem(Stock originStock, int numOfShares)
         {
             this.OriginStock = originStock;
             this.sharesInPortfolio = numOfShares;
         }
     }

    public class Portfolio
    {
        private string portID;
        private Dictionary<string, PortStockItem> PortStockList = new Dictionary<string, PortStockItem>();

        public Portfolio(string ID)
        {
            this.portID = ID;
        }

        public void addStock(Stock s, int numShares)
        {

            if (this.PortStockList.ContainsKey(s.Name.ToLower()))
            {

                int update = this.PortStockList[s.Name.ToLower()].SharesInPortfolio + numShares;

                if (update > PortStockList[s.Name.ToLower()].OriginStock.NumOfShares)
                {
                    throw new StockExchangeException("Nedopu�ten broj dionica u portfelju");
                }
                else
                {
                    PortStockList[s.Name.ToLower()].SharesInPortfolio = update;

                }
                return;
            }


            if (numShares > s.NumOfShares)
            {
                throw new StockExchangeException("Nedopu�ten broj dionica u portelju");
            }
            PortStockItem tmp = new PortStockItem(s, numShares);
            this.PortStockList.Add(s.Name, tmp);

        }

        public void removeStockShares(string stockName, int numShares)
        {
            int update;

            if (!this.PortStockList.ContainsKey(stockName.ToLower()))
            {
                throw new StockExchangeException("Dionica se nenalazi u portfelju");
            }

            int current = this.PortStockList[stockName.ToLower()].SharesInPortfolio;
            update = current - numShares;
            if (update < 0)
                update = 0; //oduzimanje vi�e od postojecih - kao da oduzimamo sve

            if (update == 0)
            {
                this.removeStock(stockName.ToLower());
                return; //bri�emo dionicu iz portfelja ako je broj dionica postao nula nakon update-a
            }
            this.PortStockList[stockName.ToLower()].SharesInPortfolio = update;
        }

        public void removeStock(string stockName)
        {
            if (!(this.checkIfPartOf(stockName.ToLower())))
            {
                throw new StockExchangeException("Dionica se ne nalazi u portelju");
            }

            this.PortStockList.Remove(stockName);

            //bri�e cijelu dionicu iz ovog portfolija
        }

        public int getStockNum()
        {
            return this.PortStockList.Count(); //vraca broj dionica u portfelju
        }

        public bool checkIfPartOf(string stockName)
        {
            return this.PortStockList.ContainsKey(stockName.ToLower());
        }

        public int numOfSharesStock(string stockName)
        {
            if (this.PortStockList.ContainsKey(stockName.ToLower()))
            {
                return this.PortStockList[stockName.ToLower()].SharesInPortfolio;
            }

            else
            {
                return 0;
            }
        }

        public Decimal getPortValue(DateTime timeSet)
        {
            Decimal sum = 0;
            Decimal tmp = 0;

            foreach (var pair in PortStockList)
            {
                tmp = pair.Value.OriginStock.getPriceAtTime(timeSet);
                tmp *= pair.Value.SharesInPortfolio;
                sum += tmp;
            }
            return decimal.Round(sum, 3);

            //ukupna vrijednost portfolija


        }

        public Decimal getPortPerc(int Year, int Month)
        {
            try
            {
                DateTime initTime = new DateTime(Year, Month, 1, 0, 0, 0, 0, 0);

                DateTime endTime = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
                Decimal initValue = 0;
                Decimal endValue = 0;
                Decimal percentage = 0;

                initValue = this.getPortValue(initTime);
                endValue = this.getPortValue(endTime);


                percentage = (endValue - initValue)/initValue;
                percentage *= 100;
                return decimal.Round(percentage, 3);
            }
            catch
            {
                throw new StockExchangeException("Nedopu�teni datum");
            }
        }
    }

    public abstract class IndexTypeAlgorithm
    {
        public abstract Decimal calculateIndexValue(DateTime timeSet, Index index);
    }

    public  class IndexAVGAlgorithm : IndexTypeAlgorithm
    {
        public override decimal calculateIndexValue(DateTime timeSet, Index index)
        {
            Decimal avg = 0;
            Decimal sum = 0;
            
            foreach (Stock stock in index.IndexStockList.Values)
            {
                sum += stock.getPriceAtTime(timeSet);
            }

            avg = sum/index.getStockNum();

            return decimal.Round(avg, 3);

        }
    }

    public class IndexWthAlgoritm : IndexTypeAlgorithm
    {
        public override decimal calculateIndexValue(DateTime timeSet, Index index)
        {
            Decimal totalSum = 0;
            Decimal wFactor = 0;
            Decimal totalWdth = 0;

            foreach (Stock stock in index.IndexStockList.Values)
            {
                totalSum += (stock.getPriceAtTime(timeSet)*stock.NumOfShares);

            }

            foreach (Stock stock in index.IndexStockList.Values)
            {
                wFactor = (stock.getPriceAtTime(timeSet))/totalSum;
                totalWdth += wFactor*(stock.getPriceAtTime(timeSet)*stock.NumOfShares);
            }

            return decimal.Round(totalWdth, 3);

        }
        
    }
    public class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private IndexTypeAlgorithm algorithm;

        public Dictionary<string, Stock> IndexStockList = new Dictionary<string, Stock>();

        public Index(string indName, IndexTypes inType)
        {
            if (!(Enum.IsDefined(typeof (IndexTypes), inType)))
            {
                throw  new StockExchangeException("Nedopu�ten tip indeksa");
            }
            this.indexName = indName.ToLower();
            this.indexType = inType;

            //logika koja kreira algoritam racuna ovisno o tipu
            if (indexType == IndexTypes.AVERAGE)
            {
                this.algorithm = new IndexAVGAlgorithm();
                return;
            }

            if (indexType == IndexTypes.WEIGHTED)
            {
                this.algorithm = new IndexWthAlgoritm();
                return;
            }

        }

        public void addStock(string inStockName, Stock s)
        {
            if (!this.IndexStockList.ContainsKey(inStockName.ToLower()))
            {
                this.IndexStockList.Add(inStockName.ToLower(), s);
            }

            else
            {
                throw new StockExchangeException("Dionica se vec nalazi u indeksu");
            }
        }

        public void removeStock(string stockName)
        {
            if (this.IndexStockList.ContainsKey(stockName.ToLower()))
            {
                this.IndexStockList.Remove(stockName.ToLower());
            }

            else
            {
                throw new StockExchangeException("Dionica se ne nalazi u indeksu");
            }
            
        }

        public bool checkIfPartOf(string stockName)
        {
            string key = stockName.ToLower();
            return this.IndexStockList.ContainsKey(key);
        }

        public int getStockNum()
        {
            return this.IndexStockList.Count();
        }

        public Decimal getIndexValue(DateTime timeSet)
        {
            if (this.getStockNum() == 0)
                return 0;
            return this.algorithm.calculateIndexValue(timeSet, this); //poziva nas sobom algoritam odgovarajuci
        }
    }




     public class StockExchange : IStockExchange
     {
         Dictionary<string, Stock> StockList = new Dictionary<string, Stock>();
         Dictionary<string, Portfolio> PortfolioList = new Dictionary<string, Portfolio>();
         Dictionary<string, Index> IndexList = new Dictionary<string, Index>();


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stock = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
             //kreiram dionicu
             if (this.StockList.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Dionica je vec na burzi!");
             this.StockList.Add(inStockName.ToLower(), stock);
             //dodam ju u dictionary
         }
         //uzimamo sve uvijek .toLower da bude case insensitive


         public void DelistStock(string inStockName)
         {
             string key = inStockName.ToLower();
             if (!StockList.ContainsKey(key)) //umjesto ovih provjera po Dictionaryju, mogu se pozivati implementirane metode :) 
             {
                 throw new StockExchangeException("Dionica se ne nalazi na burzi");
             }

             //kada se bri�e s burze, bri�e se i iz svih portfelja i indeksa
             StockList.Remove(key);

             foreach (var pair in PortfolioList)
             {
                 if (pair.Value.checkIfPartOf(key))
                 {
                     pair.Value.removeStock(key);
                 }
             }

             foreach (var pair in IndexList )
             {
                 if (pair.Value.checkIfPartOf(key))
                 {
                     pair.Value.removeStock(key);
                 }

             }
    
         }


         public bool StockExists(string inStockName)
         {
             string key = inStockName.ToLower();
             if (StockList.ContainsKey(key))
             {
                 return true;
             }
             else return false;
         }

         public int NumberOfStocks()
         {
             return StockList.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             this.StockList[inStockName.ToLower()].setPrice(inIimeStamp, inStockValue);
         }



         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             string key = inStockName.ToLower();
             return this.StockList[key].getPriceAtTime(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             string key = inStockName.ToLower();
             return this.StockList[key].getInitPrice();

         }

         public decimal GetLastStockPrice(string inStockName)
         {
             string key = inStockName.ToLower();
             if (this.StockList.ContainsKey(key))

             {
                 return this.StockList[key].getLastPrice();
             }

             else
             {
                 throw  new StockExchangeException("Dionica se ne nalazina burzi");
             }
         }
         


//------------------------------------------------------------------------
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {

             Index tmp = new Index(inIndexName, inIndexType);
             if(!this.IndexList.ContainsKey(inIndexName.ToLower()))
             {
                 this.IndexList.Add(inIndexName.ToLower(),tmp);
             }
             else
             {
                throw new StockExchangeException("Postoji vec takav indeks");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
            if (this.IndexList.ContainsKey(inIndexName.ToLower()))
            {
                this.IndexList[inIndexName.ToLower()].addStock(inStockName.ToLower(),
                                                               this.StockList[inStockName.ToLower()]);
            }

            else
            {
                throw new StockExchangeException("Indeks se ne nalazi na burzi");            }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (this.IndexList.ContainsKey(inIndexName.ToLower()))
             {
                 this.IndexList[inIndexName.ToLower()].removeStock(inStockName.ToLower());
             }

             else
             {
                 throw new StockExchangeException("Indeks se ne nalazi na burzi");
             }
            
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (this.IndexList.ContainsKey(inIndexName.ToLower()))
             {
                 return this.IndexList[inIndexName.ToLower()].checkIfPartOf(inStockName.ToLower());
             }

             else
             {
                 throw new StockExchangeException("Indeks se ne nalazi na burzi");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
            if (this.IndexExists(inIndexName))
            {
                return this.IndexList[inIndexName.ToLower()].getIndexValue(inTimeStamp);
            }

            else
            {
                throw new StockExchangeException("Indeks se ne nalazi na burzi");
            }
         }

         public bool IndexExists(string inIndexName)
         {
             string key = inIndexName.ToLower();
             return this.IndexList.ContainsKey(key);
         }

         public int NumberOfIndices()
         {
             return this.IndexList.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (this.IndexList.ContainsKey(inIndexName.ToLower()))
             {
                 return this.IndexList[inIndexName.ToLower()].getStockNum();
             }

             else
             {
                 throw new StockExchangeException("Indeks se ne nalazi na burzi");
             }
         }


//--------------------------------------------------------------------------------------------

         public void CreatePortfolio(string inPortfolioID)
         {
             //provjeriti da vec nema s tim ID-om!

             if (!PortfolioList.ContainsKey(inPortfolioID))
             {
                 Portfolio tmp = new Portfolio(inPortfolioID);
                 this.PortfolioList.Add(inPortfolioID, tmp);
             }

             else
             {
                 throw new StockExchangeException("Na burzi se vec nalazi portfelj s tim imenom");
             }

         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             string key = inStockName.ToLower();
             long sum = 0;

             if (!(this.StockExists(key)))
             {
                 throw new StockExchangeException("Ne postoji takav portfolio na burzi");
             }


             //prvo provjera je li dopu�teno dodati toliko share-ova

             foreach (var pair in PortfolioList)
             {
                 sum += pair.Value.numOfSharesStock(key);
             }

             sum += numberOfShares;

             if (sum > StockList[key].NumOfShares)
             {
                 throw new StockExchangeException("Nedopu�ten broj dionica");
             }

            this.PortfolioList[inPortfolioID].addStock(this.StockList[key], numberOfShares);
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!this.PortfolioList[inPortfolioID].checkIfPartOf(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji");
                 return;
             }
             this.PortfolioList[inPortfolioID].removeStockShares(inStockName, numberOfShares);


         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.PortfolioList.ContainsKey(inPortfolioID))
             {
                 this.PortfolioList[inPortfolioID].removeStock(inStockName.ToLower());
             }

             else
             {
                 throw new StockExchangeException("Portfolio ne postoji na burzi");
             }
         }

         public int NumberOfPortfolios()
         {
             return this.PortfolioList.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return this.PortfolioList[inPortfolioID].getStockNum();
         }


         public bool PortfolioExists(string inPortfolioID)
         {
             return this.PortfolioList.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return this.PortfolioList[inPortfolioID].checkIfPartOf(inStockName.ToLower());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return this.PortfolioList[inPortfolioID].numOfSharesStock(inStockName.ToLower());
         }



         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return this.PortfolioList[inPortfolioID].getPortValue(timeStamp);
         }

         public Decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (this.PortfolioExists(inPortfolioID))
             {
                 return this.PortfolioList[inPortfolioID].getPortPerc(Year, Month);
             }

             else
             {
                 throw new StockExchangeException("Ne postoji takav portfelj na burzi");
             }

  
         }
     }
}
