﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stockList;
         private List<Index> indexList;
         private List<Portfolio> portfolioList;

         public StockExchange()
         {
             stockList = new List<Stock>();
             indexList = new List<Index>();
             portfolioList = new List<Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             int indexOfStockToAdd = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());//traži indeks dionice sa zadanim imenom
             if (indexOfStockToAdd == -1 && inNumberOfShares>=1 && inInitialPrice>=1)//provjera postoji li vec ta dionica i jesu li parametri ispravno zadani
             {
                 stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
                 
             }
             else
             {
                 throw new StockExchangeException("Nije moguće dodati dionicu. Ili već postoji dionica s tim imenom ili su broj dionica ili početna cijena nedopuštene vrijednosti.");
             }
 
         }

         public void DelistStock(string inStockName)
         {
             int indexOfStockToRemove = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStockToRemove != -1)//ako se dionica nalazi na burzi
             {
                 Stock selectedStock = stockList[indexOfStockToRemove];
                 foreach (Index index in indexList)//brise dionicu iz svih indexa
                 {
                     if (index.IsStockPartOfIndex(selectedStock))
                     {
                         index.RemoveStockFromIndex(selectedStock);
                     }
                 }
                 foreach (Portfolio portfolio in portfolioList)//brise dionicu iz svih portfolia
                 {
                     if (portfolio.IsStockPartOfPortfolio(selectedStock))
                     {
                         portfolio.RemoveStock(selectedStock);
                     }
                 }
                 stockList.Remove(selectedStock);//brise dionicu sa burze
             }
             else
             {
                 throw new StockExchangeException("Zadana dionica se ne nalazi na burzi");
             }
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int indexOfStock = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStock != -1)
             {
                 return true;
             }
             else return false;
         }

         public int NumberOfStocks()
         {
             return stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             int indexOfStockToEdit = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStockToEdit != -1)//dionica postoji na burzi
             {
                 Stock oldStock = stockList[indexOfStockToEdit];//stara verzija
                 stockList[indexOfStockToEdit].SetStockPrice(inIimeStamp, inStockValue);//update dionice
                 Stock newStock = stockList[indexOfStockToEdit];//nova verzija

                 foreach (Index index in indexList)
                 {
                     if (index.IsStockPartOfIndex(oldStock))
                     {
                         index.EditStock(oldStock, newStock);//update dionice u indexu (znam da bi ovo bilo bolje da se updatea samo na jedom mjestu, ali
                     }                                       //ako u index stavim samo string ime dionice, onda index ništa ne zna računati sam i burza 
                 }                                              //sve izračune radi sama kopajuči po njegovim podacima. To mi se u početku nije sviđalo i odna sam kasnije skužio da 
                 foreach (Portfolio portfolio in portfolioList)//ovo sa dionicama na više mjesto jednostavno nije dobro, ali nije bilo vremena za promjene. Biti će neki service patch =)
                 {
                     if (portfolio.IsStockPartOfPortfolio(oldStock))
                     {
                         portfolio.EditStock(oldStock, newStock);
                     }
                 }
                 
             }
             else
             {
                 throw new StockExchangeException("Zadana dionica ne postoji na burzi ili ste upisali negativnu cijenu.");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             int indexOfStockToCheck = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStockToCheck != -1)//postoji li dionica na burzi?
             {
                 return stockList[indexOfStockToCheck].GetStockPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Zadana dionica ne postoji na burzi.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             int indexOfStockToCheck = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStockToCheck != -1)
             {
                 return stockList[indexOfStockToCheck].GetInitialStockPrice();
             }
             else
             {
                 throw new StockExchangeException("Zadana dionica ne postoji na burzi");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             int indexOfStockToCheck = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfStockToCheck != -1)
             {
                return stockList[indexOfStockToCheck].GetLastStockPrice();
             }
             else
             {
                throw new StockExchangeException("Zadana dionica ne postoji na burzi");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             int indexOfOndexToAdd = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper());
             if (indexOfOndexToAdd == -1 && (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED))//ako index ne postoji && indexType je ispravno zadan
             {
                 indexList.Add(new Index(inIndexName, inIndexType));
             }
             else
             {
                 throw new StockExchangeException("Nije moguće dodati index. Postoji index sa zadanim imenom ili tip indexa nije ispravno zadan.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             int indexOfIndexToAddTo = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper());
             int indexOfStockToAdd = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfIndexToAddTo != -1 && indexOfStockToAdd != -1)//i index i dionica postoje na burzi
             {
                 indexList[indexOfIndexToAddTo].AddStockToIndex(stockList[indexOfStockToAdd]);
             }
             else
             {
                 throw new StockExchangeException("Zadani index ili dionica ne postoje na burzi");
             }

         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             int indexOfIndexToRemoveFrom = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper()); 
             int indexOfStockToRemove = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfIndexToRemoveFrom != -1 && indexOfStockToRemove != -1)
             {
                 indexList[indexOfIndexToRemoveFrom].RemoveStockFromIndex(stockList[indexOfStockToRemove]);
             }
             else
             {
                 throw new StockExchangeException("Zadani index ili dionica ne postoje na burzi");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             int indexOfIndexToCheck = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper());
             int indexOfStockToCheck = stockList.FindIndex(x => x.StockName == inStockName.ToUpper());
             if (indexOfIndexToCheck != -1 && indexOfStockToCheck != -1)
             {
                 return indexList[indexOfIndexToCheck].IsStockPartOfIndex(stockList[indexOfStockToCheck]);
             }
             else
             {
                 throw new StockExchangeException("Zadani index ili dionica ne postoje na burzi.");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             int indexOfIndexToCheck = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper());
             if (indexOfIndexToCheck != -1)
             {
                 return indexList[indexOfIndexToCheck].GetIndexValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Zadani index ne postoji u burzi.");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             if (indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper()) != -1)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int indexOfIndexToCheck = indexList.FindIndex(x => x.IndexName == inIndexName.ToUpper());
             if (indexOfIndexToCheck != -1)
             {
                 return indexList[indexOfIndexToCheck].GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Zadani index ne psotoji na burzi.");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolioList.FindIndex(p => p.PortfolioID == inPortfolioID) == -1)//ako ne postoji takav portfolio na burzi
             {
                 portfolioList.Add(new Portfolio(inPortfolioID));
             }
             else
             {
                 throw new StockExchangeException("Na burzi već postoji portfolio s tim ID-em");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int indexOfSelectedStock = stockList.FindIndex(x=>x.StockName==inStockName);
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);

             if (indexOfSelectedPortfolio != -1 && indexOfSelectedStock != -1)//postoje dionica i portfolio
             {
                 Stock selectedStock = stockList[indexOfSelectedStock];
                 int numberOfSoldShares = 0;
                 foreach (Portfolio portfolio in portfolioList)
                 {
                     numberOfSoldShares += portfolio.ReturnNumberOfSharesForStock(selectedStock);//zbroj do sada prodane količine zadane dionice
                 }

                 if (numberOfSoldShares + numberOfShares <= selectedStock.NumberOfShares)//ako ima dovoljno dionice, dodaj u portfolio
                 {

                     portfolioList[indexOfSelectedPortfolio].AddStock(selectedStock, numberOfShares);
                 }
                 else
                 {
                     throw new StockExchangeException("Ne postoje dovoljne količine zadane dionice.");//ako nema dovoljno dionice
                 }
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ili dionica ne postoje na burzi.");
             }

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int indexOfSelectedStock = stockList.FindIndex(x => x.StockName == inStockName);
             Stock selectedStock = stockList[indexOfSelectedStock];
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != 1 && indexOfSelectedStock != -1)
             {
                 portfolioList[indexOfSelectedPortfolio].RemoveStock(selectedStock, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ili dionica ne postoje na burzi.");
             }

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             int indexOfSelectedStock = stockList.FindIndex(x => x.StockName == inStockName);
             Stock selectedStock = stockList[indexOfSelectedStock];
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);

             if (indexOfSelectedPortfolio != 1 && indexOfSelectedStock != -1)
             {
                 portfolioList[indexOfSelectedPortfolio].RemoveStock(selectedStock);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ili dionica ne postoje na burzi.");
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);//exceptioni
             if (indexOfSelectedPortfolio != -1)
             {
                 return portfolioList[indexOfSelectedPortfolio].GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ne postoji na burzi.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != -1)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             int indexOfSelectedStock = stockList.FindIndex(x => x.StockName == inStockName);
             Stock selectedStock = stockList[indexOfSelectedStock];

             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != -1 && indexOfSelectedStock != -1)
             {
                 return portfolioList[indexOfSelectedPortfolio].IsStockPartOfPortfolio(selectedStock);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ili dionica ne postoje na burzi.");
             }

         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int indexOfSelectedStock = stockList.FindIndex(x => x.StockName == inStockName);
             Stock selectedStock = stockList[indexOfSelectedStock];
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != -1 && indexOfSelectedStock != -1)
             {
                 return portfolioList[indexOfSelectedPortfolio].ReturnNumberOfSharesForStock(selectedStock);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ili dionica ne postoje na burzi.");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != -1)
             {
                 return portfolioList[indexOfSelectedPortfolio].GetPortfolioValue(timeStamp);
             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ne postoji na burzi.");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             int indexOfSelectedPortfolio = portfolioList.FindIndex(x => x.PortfolioID == inPortfolioID);
             if (indexOfSelectedPortfolio != -1)
             {
                 if (Month >= 1 && Month <= 12)
                 {
                     DateTime timeStampStart = new DateTime(Year, Month, 1, 0, 0, 0, 0);//stvaranje timestampa za pocetak mejseca
                     DateTime timeStampEnd = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);//isto to, za kraj mjeseca
                     Decimal startValue = portfolioList[indexOfSelectedPortfolio].GetPortfolioValue(timeStampStart);//vrijednost portfolia na početku mjeseca
                     Decimal endValue = portfolioList[indexOfSelectedPortfolio].GetPortfolioValue(timeStampEnd);//vrijednost na kraju
                     Decimal endStartChange = ((endValue - startValue) / startValue) * 100;//mjesecna promjena
                     return Decimal.Round(endStartChange, 3);
                 }
                 else
                 {
                     throw new StockExchangeException("Mjeseci u godini ima samo 12. Vjeruj.");//Month nije e[1,12]
                 }

             }
             else
             {
                 throw new StockExchangeException("Zadani portfolio ne postoji na burzi.");
             }
         }
     }

     #region stock_index_portfolioclasses

     public class Stock
     {
         public string StockName { get; private set; }
         public long NumberOfShares { get; private set; }
         private SortedDictionary<DateTime, Decimal> prices;//uređeni i sortirani parovi (Timestamp, Cijena)

         public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             StockName = inStockName.ToUpper();
             prices = new SortedDictionary<DateTime,Decimal>();
             prices.Add(inTimeStamp,inInitialPrice);
             NumberOfShares = inNumberOfShares;
         }

         public void SetStockPrice(DateTime inTimeStamp, Decimal inStockValue)
         {
             if (!prices.ContainsKey(inTimeStamp))
             {
                 prices.Add(inTimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Već postoji definirana cijena za taj timestamp.");
             }
         }

         public Decimal GetStockPrice(DateTime inTimeStamp)
         {
             Decimal returnPrice = 0;
             foreach (DateTime key in prices.Keys) 
             {
                 if (key <= inTimeStamp)//ako je slijedeci timestamp prije zadanog, to je trenutna vrijednost.
                 {
                     returnPrice = prices[key];
                 }
                 else//to radimo dok ne na iđemo na prvi timestamp koji je poslije zadanog. tada vraćamo vrijednost za zadnji timestamp. Ovo radi zato sto je dictionary sortiran po ključu
                 {
                     break;
                 }
             }
             if (returnPrice == 0)
             {
                 throw new StockExchangeException("U to vrijeme dionica nije postojala na burzi.");
             }
             else
             {
                 return returnPrice;
             }
         }

         public Decimal GetInitialStockPrice()
         {
             return prices.First().Value;
         }

         public Decimal GetLastStockPrice()
         {
             Decimal returnPrice = 0;//Ista metoda kao i getstockprice samo sa DateTime.Now
             foreach (DateTime key in prices.Keys)
             {
                 if (key <= DateTime.Now)
                 {
                     returnPrice = prices[key];
                 }
                 else
                 {
                     break;
                 }
             }
             if (returnPrice == 0)
             {
                 throw new StockExchangeException("U to vrijeme dionica nije postojala na burzi.");
             }
             else
             {
                 return returnPrice;
             }
         }
     }

     public class Index
     {
         public string IndexName { get; private set; }
         public IndexTypes IndexType { get; private set; }
         private List<Stock> stockList;

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             stockList = new List<Stock>();
             IndexName = inIndexName.ToUpper();
             IndexType = inIndexType;
         }

         public void AddStockToIndex(Stock inStock)
         {
             if (!stockList.Contains(inStock))
             {
                 stockList.Add(inStock);
             }
             else
             {
                 throw new StockExchangeException("Zadana dionica već se nalazi u zadanom indexu");
             }
         }

         public void RemoveStockFromIndex(Stock inStock)
         {
             if (stockList.Contains(inStock))
             {
                 stockList.Remove(inStock);
             }
             else
             {
                 throw new StockExchangeException("Index ne sadrži zadanu dionicu");
             }
         }

         public bool IsStockPartOfIndex(Stock inStock)
         {
             return stockList.Contains(inStock);
         }

         public int GetNumberOfStocks()
         {
             return stockList.Count;
         }

         public void EditStock(Stock inOldStock, Stock inNewStock)
         {
             
             stockList.Remove(inOldStock);//zamjenjuje staru verziju dionice sa novom (nova ima dodanu cijenu)
             stockList.Add(inNewStock);
         }

         public decimal GetIndexValue(DateTime inTimeStamp)
         {
             decimal indexValue=0;
             
             if (IndexType == IndexTypes.AVERAGE)
             {
                 decimal allStocksValue = 0;
                 foreach (Stock stock in stockList)
                 {
                     allStocksValue += stock.GetStockPrice(inTimeStamp);//zbroj vrijednosti svih dionica
                 }
                 indexValue = allStocksValue / stockList.Count;

             }
             else
             {
                 decimal allStocksValueWeighted = 0;
                 foreach (Stock stock in stockList)
                 {
                     allStocksValueWeighted += stock.GetStockPrice(inTimeStamp) * stock.NumberOfShares;//zbrog vrijednosti svih dionica weighted
                 }
                 foreach (Stock stock in stockList)
                 {
                     
                     decimal factor = stock.NumberOfShares * stock.GetStockPrice(inTimeStamp)/allStocksValueWeighted;//faktor za svaku dionicu
                     indexValue += factor * stock.GetStockPrice(inTimeStamp);//pribrajanje vrijednosti
                 }
             }
             return Decimal.Round(indexValue, 3);
         }
     }

     public class Portfolio
     {
         public string PortfolioID { get; private set; }
         private Dictionary<Stock,int> stockDictionary;

         public Portfolio(string inPortfolioID)
         {
             PortfolioID = inPortfolioID;
             stockDictionary = new Dictionary<Stock,int>();
         }

         public void AddStock(Stock inStock, int inNumberOfShares)
         {
             if (stockDictionary.ContainsKey(inStock))//ako dionica vec postoji u portfolio, samo joj dodamo neki broj u kolicinu
             {
                 stockDictionary[inStock] += inNumberOfShares;
             }
             else
             {
                 stockDictionary.Add(inStock, inNumberOfShares);//ako ne postoji, dodamo ju u portfolio
             }
         }

         public int ReturnNumberOfSharesForStock(Stock inStock)
         {
             if (stockDictionary.ContainsKey(inStock))
             {
                 return stockDictionary[inStock];
             }
             else
             {
                 return 0;//ako portfolio ne sadrži dionicu, količina je 0
             }
         }

         public void RemoveStock(Stock inStock, int inNumberOfShares)
         {
             if (stockDictionary.ContainsKey(inStock))
             {
                 if (stockDictionary[inStock] > inNumberOfShares)
                 {
                     stockDictionary[inStock] -= inNumberOfShares;//ako u portfoliu ima veca kolicina dionice nego sto oduzimamo, oduzimanje prolazi
                 }
                 else if (stockDictionary[inStock] == inNumberOfShares)//Ako ih ima jednako, automatski brisemo dionicu iz portfolia
                 {
                     stockDictionary.Remove(inStock);
                 }
                 else
                 {
                     throw new StockExchangeException("Želite maknuti više dionica nego što ih u portfelju ima.");//Ako zelimo obrisati vise nego sto ima, exception
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionica se ne nalazi u portfelju.");
             }
         }

         public void RemoveStock(Stock inStock)
         {
             if (stockDictionary.ContainsKey(inStock))
             {
                 stockDictionary.Remove(inStock);
             }
             else
             {
                 throw new StockExchangeException("Dionica se ne nalazi u portfelju.");
             }
         }

         public int GetNumberOfStocks()
         {
             return stockDictionary.Count;
         }

         public bool IsStockPartOfPortfolio(Stock insStock)
         {
             return stockDictionary.ContainsKey(insStock);
         }

         public Decimal GetPortfolioValue(DateTime inTimeStamp)
         {
             Decimal portfolioValue = 0;
             foreach (Stock stock in stockDictionary.Keys)
             {
                     portfolioValue += stock.GetStockPrice(inTimeStamp) * stockDictionary[stock];//zbrajamo vrijednost portfolia
             }
             return portfolioValue;

         }

         public void EditStock(Stock inOldStock, Stock inNewStock)
         {
             int numberOfShares = stockDictionary[inOldStock];
             stockDictionary.Remove(inOldStock);//mijenjamo staru verziju dionice novom.
             stockDictionary.Add(inNewStock, numberOfShares);
         }

     }

    #endregion



}
