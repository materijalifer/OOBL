﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        
        #region Varijable
        private string tmpValue;
        private string resultString = string.Empty;
        private string tmpString;
        private double resultNumber = 0;
        private double memory;
        private char calcFunc;
        private char calcFuncMySelf;
        private string txtInput = "0";
        private double brInput = 0;
        private char comaDecimal = ',';
        private char reset = 'O';
        private char clear = 'C';
        private char minusPlusChange = 'M';
        private char getFromMemory = 'G';
        private char putInMemory = 'P';
        private char[] numbers =  {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        private char[] operationTwoNumbers = { '+', '-', '/', '*' };
        private char[] operationOneNumber =  { 'Q', 'S', 'K', 'R', 'I' };
        #endregion

        public void Press(char inPressedDigit)
        {
            try
            {
                #region Clear i reset kalkulatora
                if (inPressedDigit == clear)
                {
                    resultString = string.Empty;
                    txtInput = "0";
                    brInput = 0;
                }

                if (inPressedDigit == reset)
                {
                    memory = 0;
                    resultString = string.Empty;
                    resultNumber = 0;
                    txtInput = "0";
                    brInput = 0;
                    calcFunc = '\0';
                }
                #endregion

                #region Promjena predznaka
                if (inPressedDigit == minusPlusChange)
                {
                    brInput = Convert.ToDouble((-1) * brInput);
                    NumberFormatInfo currencyFormat = new CultureInfo(CultureInfo.CurrentCulture.ToString()).NumberFormat;
                    currencyFormat.CurrencyNegativePattern = 1;
                    txtInput = String.Format(currencyFormat, this.Pretty(brInput));
                }
                #endregion

                #region Pritisnuta tipka
                if (numbers.Contains(inPressedDigit))
                {
                    resultString += Convert.ToString(inPressedDigit);
                    brInput = Convert.ToDouble(resultString);
                    txtInput = Convert.ToString(brInput);
                }
                #endregion

                #region spremanje i dohvat iz memorije
                if (inPressedDigit == putInMemory)
                {
                    memory = brInput;
                }

                if (inPressedDigit == getFromMemory)
                {
                    brInput = memory;
                    txtInput = brInput.ToString();
                    resultString = string.Empty;
                }
                #endregion

                #region Provjera decimalnog zareza
                if (inPressedDigit == comaDecimal)
                {
                    if (resultString.Contains(","))
                    {
                        return;
                    }
                    resultString += comaDecimal.ToString();
                }
                #endregion

                #region Operacije s jednim brojem tj. sin, cos ...
                if (operationOneNumber.Contains(inPressedDigit))
                {
                    if (inPressedDigit == 'I' && brInput == 0)
                    {
                        txtInput = "-E-";
                        return;
                    }
                    calcFuncMySelf = inPressedDigit;
                    brInput = this.CalculateOne(calcFuncMySelf, brInput);
                    tmpString = this.Pretty(brInput);
                    if (tmpString == "-E-")
                    {
                        txtInput = "-E-";
                        return;
                    }
                    brInput = Convert.ToDouble(tmpString);
                    txtInput = brInput.ToString();
                }
                #endregion

                #region Operacije s dva broja tj. + - itd...
                if (operationTwoNumbers.Contains(inPressedDigit))
                {
                    if ((resultString.Length > 0) && (resultNumber != 0))
                    {
                        resultNumber = this.CalculateTwo(brInput, calcFunc, resultNumber);
                        tmpString = this.Pretty(resultNumber);
                        if (tmpString == "-E-")
                        {
                            txtInput = "-E-";
                            return;
                        }
                        resultNumber = Convert.ToDouble(tmpString);
                        brInput = resultNumber;
                        txtInput = Convert.ToString(brInput);
                        calcFunc = inPressedDigit;
                        resultString = string.Empty;
                        return;
                        
                    }
                    else
                    {
                        calcFunc = inPressedDigit;
                        tmpString = this.Pretty(brInput);
                        if (tmpString == "-E-")
                        {
                            txtInput = "-E-";
                            return;
                        }
                        resultNumber = Convert.ToDouble(tmpString);
                        resultString = string.Empty;
                        return;
                    }
                }
                #endregion

                #region Izračun
                if ((inPressedDigit == '=') && (operationTwoNumbers.Contains(calcFunc)))
                {
                    if ((brInput == 0) && (calcFunc == '/'))
                    {
                        txtInput = "-E-";
                        return;
                    }

                    resultNumber = this.CalculateTwo(brInput, calcFunc, resultNumber);
                    brInput = resultNumber;
                    tmpString = this.Pretty(brInput);
                    if (tmpString == "-E-")
                    {
                        txtInput = "-E-";
                        return;
                    }
                    brInput = Convert.ToDouble(this.Pretty(brInput));
                    txtInput = Convert.ToString(brInput);
                    resultNumber = 0;
                    resultString = string.Empty;
                    calcFunc = '\0';
                    return;

                }

                if (inPressedDigit == '=')
                {
                    calcFunc = '\0';
                    resultString = string.Empty;
                    resultNumber = 0;
                }
                #endregion

            }
            catch
            {
                txtInput = "-E-";
            }

        }

        #region Pomoćne metode za računanje i zaokruživanje
        private double CalculateOne(char oper, double current)
        {
            switch (oper)
            {
                case 'I':
                    current = 1 / current;
                    break;
                case 'K':
                    current = Math.Cos(current);
                    break;
                case 'T':
                    current = Math.Tan(current);
                    break;
                case 'R':
                    current = Math.Sqrt(current);
                    break;
                case 'Q':
                    current = Math.Pow(current, 2);
                    break;
                case 'S':
                    current = Math.Sin(current);
                    break;
                default:
                    break;
            }
            return current;

        }
        private double CalculateTwo(double current, char oper, double result)
        {
            switch (oper)
            {
                case '+':
                    result += current;
                    break;
                case '-':
                    result -= current;
                    break;
                case '*':
                    result *= current;
                    break;
                case '/':
                    result /= current;
                    break;
                default:
                    break;
            }

            return result;
        }
        private string Pretty(double _resultNumber)
        {
            string _result = Convert.ToString(_resultNumber);
            int length = _result.Length;
            int index;
            int indexTwo;

            if ((_resultNumber > 0) && (length > 11) && _result.Contains(","))
            {
                string tmp = _result.Substring(0, 11);
                index = _result.IndexOf(',');
                indexTwo = 10 - index;
                _resultNumber = Math.Round(_resultNumber, indexTwo);
                _result = Convert.ToString(_resultNumber);
                return _result;
            }

            else if ((_resultNumber < 0) && (length > 11) && (!_result.Contains(",")))
            {
                string tmp = _result.Substring(0, 11);
                index = _result.IndexOf(',');
                indexTwo = 10 - index;
                _resultNumber = Math.Round(_resultNumber, indexTwo);
                _result = Convert.ToString(_resultNumber);
                return _result;
            }

            else if (((!_result.Contains(",")) && (length > 11) && (_resultNumber > 0)))
            {
                return "-E-";
            }
            else if ((!_result.Contains(",")) && (length > 10) && (_resultNumber > 0))
            {
                return "-E-";
            }
            else if ((!_result.Contains(",")) && (length > 12) && (_resultNumber < 0))
            {
                return "-E-";
            }
                            

            else if ((_resultNumber < 0) && (length > 12) && (_result.Contains(",")))
            {
                index = _result.IndexOf(',');
                indexTwo = 11 - index;
                _resultNumber = Math.Round(_resultNumber, indexTwo);
                _result = Convert.ToString(_resultNumber);
                return _result;
            }

            else
            {
                return _result;
            }
        }
        #endregion

        public string GetCurrentDisplayState()
        {
            return txtInput;
        }
    }


}
