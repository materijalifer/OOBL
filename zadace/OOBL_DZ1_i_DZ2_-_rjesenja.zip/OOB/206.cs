﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory 
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string ekran;
        private string pohranjeniBroj;
        private string operacija;
        private string prviOperand;
        private string drugiOperand;
        private bool upisOperanda;

        #region Funkcije

        private bool IsBrojSaPomicnimZarezom(string broj)
        {
            if (broj.Contains(','))
            {
                return true;
            }
            return false;
        }

        private bool IsUnarniOperator(char znak)
        {
            if (znak.Equals('=') || znak.Equals(',')
                 || znak.Equals('M') || znak.Equals('S') || znak.Equals('K') || znak.Equals('T') || znak.Equals('Q')
                 || znak.Equals('R') || znak.Equals('I') || znak.Equals('P') || znak.Equals('G') || znak.Equals('C')
                 || znak.Equals('O'))
            {
                return true;
            }
            return false;
        }

        private string PripremiIspis(string zaslon)
        {
            try
            {
                if ((Decimal.Parse(zaslon) > (-10000000000)) && (Decimal.Parse(zaslon) < (10000000000)))
                {
                    if (IsBrojSaPomicnimZarezom(zaslon))
                    {
                        int pozicija = zaslon.IndexOf(',');
                        if (zaslon[0].Equals('-'))
                        {
                            return PobrisiNule(String.Format("{0:0.#}", Math.Round(Decimal.Parse(zaslon), (11 - pozicija)).ToString()));
                        }
                        else
                        {
                            return PobrisiNule(String.Format("{0:0.#}", Math.Round(Decimal.Parse(zaslon), (10 - pozicija)).ToString()));
                        }
                    }
                    return zaslon;
                }
            }
            catch
            {
                return "-E-";
            }
            return "-E-";
        }

        private string PobrisiNule(string broj)
        {
            char nula = '1';
            if (broj.Length > 1)
            {
                nula = broj[broj.Length - 1];
            }
            while (nula.Equals('0') && broj.Length > 1)
            {
                broj = broj.Remove(broj.Length - 1, 1);
                nula = broj[broj.Length - 1];
            }
            if(nula.Equals(','))
            {
                broj = broj.Remove(broj.Length - 1);
            }
            return broj;
        }

        private bool IsOperacija(char znak)
        {
            if (znak.Equals('+') || znak.Equals('-') || znak.Equals('*') || znak.Equals('/'))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Operacije

        //metoda koja računa rezultat
        private void Izracunaj(char funkcija)
        {
            if (funkcija.Equals('+'))
            {
                ekran = Zbroji(prviOperand, drugiOperand);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('-'))
            {
                ekran = Oduzmi(prviOperand, drugiOperand);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('*'))
            {
                ekran = Pomnozi(prviOperand, drugiOperand);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('/'))
            {
                ekran = Podijeli(prviOperand, drugiOperand);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('='))
            {
                if (operacija.Equals("NOP"))
                {
                    ekran = PripremiIspis(ekran);
                }
                if (!operacija.Equals("NOP"))
                {
                    drugiOperand = ekran;
                    Izracunaj(operacija[0]);
                    operacija = "NOP";
                    prviOperand = drugiOperand = String.Empty;
                    upisOperanda = false;
                }
                else
                {
                    ekran = PripremiIspis(ekran);
                }
                return;
            }
            if (funkcija.Equals(','))
            {
                ekran = DecimalniZarez(ekran);
                upisOperanda = true;
                return;
            }
            if (funkcija.Equals('M'))
            {
                ekran = PromijeniPredznak(ekran);
                ekran = PripremiIspis(ekran);
                upisOperanda = true;
                return;
            }
            if (funkcija.Equals('S'))
            {
                ekran = IzracunajSinus(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('K'))
            {
                ekran = IzracunajKosinus(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('T'))
            {
                ekran = IzracunajTangens(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('Q'))
            {
                ekran = Kvadriraj(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('R'))
            {
                ekran = IzracunajKorijen(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('I'))
            {
                ekran = IzracunajInverz(ekran);
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('P'))
            {
                PohraniUMemoriju(ekran);
                ekran = PripremiIspis(ekran);
                upisOperanda = true;
                return;
            }
            if (funkcija.Equals('G'))
            {
                ekran = ProcitajMemoriju();
                ekran = PripremiIspis(ekran);
                return;
            }
            if (funkcija.Equals('C'))
            {
                ObrisiEkran();
                upisOperanda = true;
                return;
            }
            if (funkcija.Equals('O'))
            {
                ResetCalculator();
                return;
            }
        }

        //metoda koja zbraja dva broja
        private string Zbroji(string prviPribrojnik, string drugiPribrojnik)
        {
            try
            {
                return (Decimal.Add(Decimal.Parse(prviPribrojnik), Decimal.Parse(drugiPribrojnik))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja oduzima dva broja
        private string Oduzmi(string umanjenik, string umanjitelj)
        {
            try
            {
                return (Decimal.Subtract(Decimal.Parse(umanjenik), Decimal.Parse(umanjitelj))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja mnozi dva broja
        private string Pomnozi(string mnozenik, string mnozitelj)
        {
            try
            {
                return (Decimal.Multiply(Decimal.Parse(mnozenik), Decimal.Parse(mnozitelj))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja dijeli dva broja
        private string Podijeli(string djeljenik, string djelitelj)
        {
            try
            {
                return (Decimal.Divide(Decimal.Parse(djeljenik), Decimal.Parse(djelitelj))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja upravlja decimalnim zarezima
        private string DecimalniZarez(string screen)
        {
            if (screen.Contains(","))
            {
                return screen;
            }
            else
            {
                return screen.Insert((screen.Length), ","); ;
            }
        }

        //metoda koja mijenja predznak broja
        private string PromijeniPredznak(string broj)
        {
            if (Char.IsDigit(broj[0]))
            {
                return broj.Insert(0, "-");
            }
            else if (broj[0].Equals("-"))
            {
                return broj.Remove(0, 1);
            }
            else
            {
                return "-E-";
            }
        }

        //metoda koja racuna sinus broja
        private string IzracunajSinus(string kut)
        {
            try
            {
                return (Math.Sin(Double.Parse(kut))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja racuna kosinus broja
        private string IzracunajKosinus(string kut)
        {
            try
            {
                return (Math.Cos(Double.Parse(kut))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja racuna tangens broja
        private string IzracunajTangens(string kut)
        {
            try
            {
                return (Math.Tan(Double.Parse(kut))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja racuna kvadrat broja
        private string Kvadriraj(string broj)
        {
            try
            {
                return (Math.Pow(Double.Parse(broj), 2)).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja racuna korijen broja
        private string IzracunajKorijen(string broj)
        {
            try
            {
                return (Math.Sqrt(Double.Parse(broj))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja racuna inverz broja
        private string IzracunajInverz(string broj)
        {
            try
            {
                return (Math.Pow(Double.Parse(broj), (-1))).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        //metoda koja pohranjuje podatak u memoriju
        private void PohraniUMemoriju(string broj)
        {
            pohranjeniBroj = broj;
        }

        //metoda koja čita podatak iz memorije
        private string ProcitajMemoriju()
        {
            return pohranjeniBroj;
        }

        //metoda koja briše pohranjene znakove na ekranu
        private void ObrisiEkran()
        {
            ekran = "0";
        }

        //metoda koja resetira kalkulator i postavlja ga u početno stanje
        private void ResetCalculator()
        {
            ekran = "0";
            pohranjeniBroj = "0";
            prviOperand = String.Empty;
            drugiOperand = String.Empty;
            upisOperanda = true;
            operacija = "NOP";
        }

        #endregion

        public void Press(char inPressedDigit)
        {
            if(Char.IsDigit(inPressedDigit))
            {
                if (!upisOperanda)
                {
                    ObrisiEkran();
                    upisOperanda = true;
                }
                if (upisOperanda)
                {
                    if (ekran.Equals("0"))
                    {
                         ekran = inPressedDigit.ToString();
                    }
                    else
                    {
                         ekran = ekran + inPressedDigit.ToString();
                         PripremiIspis(ekran);
                    }
                }
            }
            if (IsOperacija(inPressedDigit))
            {
                if (String.IsNullOrEmpty(prviOperand))
                {
                    prviOperand = ekran;
                    operacija = inPressedDigit.ToString();
                    upisOperanda = false;
                    ekran = PripremiIspis(ekran);
                }
                if ((upisOperanda && !String.IsNullOrEmpty(prviOperand)) || (!ekran.Equals(PobrisiNule(prviOperand))))
                {
                    if (String.IsNullOrEmpty(drugiOperand))
                    {
                        drugiOperand = ekran;
                    }
                    prviOperand = PobrisiNule(prviOperand);
                    drugiOperand = PobrisiNule(drugiOperand);
                    Izracunaj(operacija[0]);
                    operacija = inPressedDigit.ToString();
                    
                    prviOperand = ekran;
                    drugiOperand = String.Empty;
                    upisOperanda = false;
                }
                if (!upisOperanda)
                {
                    operacija = inPressedDigit.ToString();
                }
            }
            if (IsUnarniOperator(inPressedDigit))
            {
                upisOperanda = false;
                Izracunaj(inPressedDigit);
            }
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }

        public Kalkulator()
        {
            ResetCalculator();
        }
    }
}
