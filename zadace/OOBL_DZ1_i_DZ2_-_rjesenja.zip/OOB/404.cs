﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            Kalkulator k = new Kalkulator();

            k.calcState = new State();
            k.tipke=new Dictionary<char,Button>();

            //Stvaranje i dodavanje tipki
            Button b = new NumberButton('0');
            k.tipke.Add(b.name, b);

            b = new NumberButton('1');
            k.tipke.Add(b.name, b);

            b = new NumberButton('2');
            k.tipke.Add(b.name, b);

            b = new NumberButton('3');
            k.tipke.Add(b.name, b);

            b = new NumberButton('4');
            k.tipke.Add(b.name, b);

            b = new NumberButton('5');
            k.tipke.Add(b.name, b);

            b = new NumberButton('6');
            k.tipke.Add(b.name, b);

            b = new NumberButton('7');
            k.tipke.Add(b.name, b);

            b = new NumberButton('8');
            k.tipke.Add(b.name, b);

            b = new NumberButton('9');
            k.tipke.Add(b.name, b);

            b = new DecDotButton();
            k.tipke.Add(b.name, b);

            b = new SignButton();
            k.tipke.Add(b.name, b);

            b = new SineButton();
            k.tipke.Add(b.name, b);

            b = new CosineButton();
            k.tipke.Add(b.name, b);

            b = new TangentButton();
            k.tipke.Add(b.name, b);

            b = new SquareButton();
            k.tipke.Add(b.name, b);

            b = new SqrtButton();
            k.tipke.Add(b.name, b);

            b = new InvButton();
            k.tipke.Add(b.name, b);

            b = new PutButton();
            k.tipke.Add(b.name, b);

            b = new GetButton();
            k.tipke.Add(b.name, b);

            b = new ClearButton();
            k.tipke.Add(b.name, b);

            b = new OffOnButton();
            k.tipke.Add(b.name, b);

            b = new PlusButton();
            k.tipke.Add(b.name, b);

            b = new MinusButton();
            k.tipke.Add(b.name, b);

            b = new MultiButton();
            k.tipke.Add(b.name, b);

            b = new DivButton();
            k.tipke.Add(b.name, b);

            b = new EqButton();
            k.tipke.Add(b.name, b);

            return k;
        }
    }

    public abstract class Button
    {
        public char name;
        public abstract void action(State s);
    }

    public class NumberButton : Button 
    {
        public override void action(State s) 
        {
            if (!s.enteringNumbersAllowed) return;
            if (s.newNumber) 
            {
                s.newNumber = false;
                s.screen = "0";
            }

            if (s.enteringDecimal && !s.screen.Contains(','))
                s.screen = String.Concat(s.screen, ',');

            s.screen = String.Concat(s.screen, this.name);
            s.screen = Kalkulator.convertToString(Double.Parse(s.screen));
        }

        public NumberButton(char c) 
        {
            this.name = c;
        }
    }

    public class DecDotButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            s.enteringDecimal = true;
        }

        public DecDotButton() 
        {
            this.name = ',';
        }
    }

    public class SignButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            s.screen = Kalkulator.convertToString(Double.Parse(s.screen) * -1);
        }

        public SignButton()
        {
            this.name = 'M';
        }
    }

    public class SineButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            s.screen = Kalkulator.convertToString(Math.Sin(Double.Parse(s.screen)));
            s.enteringDecimal = false;
        }

        public SineButton()
        {
            this.name = 'S';
        }
    }

    public class CosineButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            s.screen = Kalkulator.convertToString(Math.Cos(Double.Parse(s.screen)));
            s.enteringDecimal = false;
        }

        public CosineButton()
        {
            this.name = 'K';
        }
    }

    public class TangentButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            if (Double.Parse(s.screen)%Math.PI/2 == 0.0D)
            {
                s.screen = Kalkulator.errorString;
            }
            else
            {
                s.screen = Kalkulator.convertToString(Math.Tan(Double.Parse(s.screen)));
            }

            s.enteringDecimal = false;
        }

        public TangentButton()
        {
            this.name = 'T';
        }
    }

    public class SquareButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            s.screen = Kalkulator.convertToString(Math.Pow(Double.Parse(s.screen), 2.0D));
            s.enteringDecimal = false;
        }

        public SquareButton()
        {
            this.name = 'Q';
        }
    }

    public class SqrtButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            if (Double.Parse(s.screen) >= 0)
                s.screen = Kalkulator.convertToString(Math.Sqrt(Double.Parse(s.screen)));
            else
                s.screen = Kalkulator.errorString;

            s.enteringDecimal = false;
        }

        public SqrtButton()
        {
            this.name = 'R';
        }
    }

    public class InvButton : Button
    {
        public override void action(State s)
        {
            if (!s.enteringNumbersAllowed) return;
            if (Double.Parse(s.screen) != 0.0)
                s.screen = Kalkulator.convertToString(1/(Double.Parse(s.screen)));
            else
                s.screen = Kalkulator.errorString;

            s.enteringDecimal = false;
        }

        public InvButton()
        {
            this.name = 'I';
        }
    }

    public class PutButton : Button
    {
        public override void action(State s)
        {
            s.memory = String.Copy(s.screen);

            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public PutButton()
        {
            this.name = 'P';
        }
    }

    public class GetButton : Button
    {
        public override void action(State s)
        {
            if (s.memory == null) return;
            s.screen = String.Copy(s.memory);

            s.enteringDecimal = false;
            s.enteringNumbersAllowed = false;
        }

        public GetButton()
        {
            this.name = 'G';
        }
    }

    public class ClearButton : Button
    {
        public override void action(State s)
        {
            s.screen = "0";
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public ClearButton()
        {
            this.name = 'C';
        }
    }

    public class OffOnButton : Button
    {
        public override void action(State s)
        {
            s.screen = "0";
            s.memory = "0";
            s.reg = "0";
            s.operation = '0';
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public OffOnButton()
        {
            this.name = 'O';
        }
    }

    public class PlusButton : Button
    {
        public override void action(State s)
        {
            if (s.screen.Equals(Kalkulator.errorString))
                return;

            s.screen=Kalkulator.binaryOps(s);

            s.reg = String.Copy(s.screen);
            s.operation = '+';
            s.newNumber = true;
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public PlusButton()
        {
            this.name = '+';
        }
    }

    public class MinusButton : Button
    {
        public override void action(State s)
        {
            if (s.screen.Equals(Kalkulator.errorString))
                return;

            s.screen=Kalkulator.binaryOps(s);

            s.reg = String.Copy(s.screen);
            s.operation = '-';
            s.newNumber = true;
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public MinusButton()
        {
            this.name = '-';
        }
    }

    public class MultiButton : Button
    {
        public override void action(State s)
        {
            if (s.screen.Equals(Kalkulator.errorString))
                return;

            s.screen=Kalkulator.binaryOps(s);

            s.reg = String.Copy(s.screen);
            s.operation = '*';
            s.newNumber = true;
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public MultiButton()
        {
            this.name = '*';
        }
    }

    public class DivButton : Button
    {
        public override void action(State s)
        {
            if (s.screen.Equals(Kalkulator.errorString))
                return;

            s.screen=Kalkulator.binaryOps(s);

            s.reg = String.Copy(s.screen);
            s.operation = '/';
            s.newNumber = true;
            s.enteringDecimal = false;
            s.enteringNumbersAllowed = true;
        }

        public DivButton()
        {
            this.name = '/';
        }
    }

    public class EqButton : Button
    {
        public override void action(State s)
        {
            String result = Kalkulator.binaryOps(s);
            if ((long)Double.Parse(result) > 9999999999)
            {
                s.screen = Kalkulator.errorString;
                s.operation = '0';
                s.reg = "0";
                s.newNumber = true;

                return;
            }

            s.screen = String.Copy(result);
            s.operation = '0';
            s.reg = String.Copy(result);
            s.enteringNumbersAllowed = true;
            s.enteringDecimal = false;
        }

        public EqButton()
        {
            this.name = '=';
        }
    }

    public class State
    {
        public String screen;
        public String reg;
        public String memory;
        public bool enteringDecimal;
        public char operation;
        public bool enteringNumbersAllowed;
        public bool newNumber;

        public State() 
        {
            screen = "0";
            memory = "0";
            reg = "0";
            operation = '0';
            enteringDecimal = false;
            enteringNumbersAllowed = true;
            newNumber = true;
        }
    }

    public class Kalkulator:ICalculator
    {
        public Dictionary<char, Button> tipke;

        public State calcState;

        public static String errorString = "-E-";

        public static String convertToString (double number) 
        {
            String s = null;

            long wholePart = (long)number;

            if (Math.Abs(number - (int)number) < 1E-10)
            {
                s = wholePart.ToString();
            }
            else
            {
                //Kolika je duljina cijelobrojnog dijela?
                wholePart = (wholePart < 0 ? wholePart * -1 : wholePart);
                wholePart = wholePart.ToString().Length;

                number = Math.Round(number, 10 - wholePart.ToString().Length);

                s = number.ToString();
            }

            return s;
        }

        public static String binaryOps(State s) 
        {
            String ret;

            switch (s.operation) 
            { 
                case '+':
                    ret = convertToString(Double.Parse(s.screen) + Double.Parse(s.reg));
                    break;
                case '-':
                    ret = convertToString(Double.Parse(s.screen) - Double.Parse(s.reg));
                    break;
                case '*':
                    ret = convertToString(Double.Parse(s.screen) * Double.Parse(s.reg));
                    break;
                case '/':
                    if (Double.Parse(s.screen) == 0.0D) 
                    {
                        s.screen = Kalkulator.errorString;
                        s.enteringNumbersAllowed = false;
                        s.enteringDecimal = false;
                        s.reg = "0";
                        return Kalkulator.errorString;
                    }

                    ret = convertToString(Double.Parse(s.screen) / Double.Parse(s.reg));
                    break;
                case '0':
                    return s.screen;
                    break;
                default:
                    ret = Kalkulator.errorString;
                    break;
            }

            return ret;
        }

        public void Press(char inPressedDigit)
        {
            Button b = tipke[inPressedDigit];

            if(calcState.screen.Equals(Kalkulator.errorString) && !b.name.Equals('C') && !b.name.Equals('O')){
                calcState.operation='0';
                calcState.reg="0";
                calcState.enteringNumbersAllowed=false;
                calcState.enteringDecimal=false;
                return;
            }

            b.action(calcState);
        }

        public string GetCurrentDisplayState()
        {
            return calcState.screen;
        }
    }
}