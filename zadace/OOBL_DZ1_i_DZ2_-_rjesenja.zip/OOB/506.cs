﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public List<Dionica> dionice = new List<Dionica>();
         public List<Indeks> indeksi = new List<Indeks>();
         public List<Portfolio> portfelji = new List<Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 Dionica novaDionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 dionice.Add(novaDionica);
             }
             else 
             {
                 throw new StockExchangeException("Dionica već postoji");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 foreach(Indeks i in indeksi.ToList())
                 {
                     if (IsStockPartOfIndex(i.Naziv, inStockName))
                     {
                         RemoveStockFromIndex(i.Naziv, inStockName);
                     }
                 }
                 foreach(Portfolio p in portfelji.ToList())
                 {
                     RemoveStockFromPortfolio(p.Naziv, inStockName);
                 }
                 Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                 dionice.Remove(d);
             }
             else 
             {
                 throw new StockExchangeException("Dionica ne postoji");
             }
         }

         public bool StockExists(string inStockName)
         {             
             if(dionice.Any(dionica => dionica.Ime.ToLower() == inStockName.ToLower()))
             {
                return true;
             }
             else
             {
                return false;
             }
         }

         public int NumberOfStocks()
         {
             return dionice.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                 foreach(CijenaITimeStamp cit in d.cijenaDionica)
                 {
                     if(inTimeStamp == cit.DateTime)
                     {
                         throw new StockExchangeException("Već postoji ovaj timestamp.");
                     }   
                 }

                d.cijenaDionica.Add(new CijenaITimeStamp(inStockValue, inTimeStamp));

                foreach(Indeks i in indeksi)
                {
                    Dionica di = i.inDionice.Find(dionica => dionica.Ime.ToLower() == d.Ime.ToLower());
                    int z = 0;
                    foreach (CijenaITimeStamp cit in di.cijenaDionica)
                    {
                        if (inTimeStamp == cit.DateTime)
                        {
                            z = 1;
                        }
                    }
                    if (z == 0) 
                    {
                        di.cijenaDionica.Add(new CijenaITimeStamp(inStockValue, inTimeStamp));
                    }
                }
                foreach(Portfolio p in portfelji)
                {
                    DionicaUPortfoliu dup = p.pDionice.Find(dionica => dionica.Ime.ToLower() == d.Ime.ToLower());
                    int z = 0;
                    foreach (CijenaITimeStamp cit in dup.cijenaDionica)
                    {
                        if (inTimeStamp == cit.DateTime)
                        {
                            z = 1;
                        }
                    }
                    if (z == 0)
                    {
                        dup.cijenaDionica.Add(new CijenaITimeStamp(inStockValue, inTimeStamp));
                    }
                }
             }
             else 
             {
                 throw new StockExchangeException("Dionica ne postoji");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
             return GetStockPriceAtSpecificMoment(d, inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
             decimal rezultat = (decimal)d.cijenaDionica[0].Price;
             DateTime initDateTime = (DateTime)d.cijenaDionica[0].DateTime;

             foreach (CijenaITimeStamp cit in d.cijenaDionica)
             {
                if (initDateTime > cit.DateTime) 
                {
                    rezultat = cit.Price;
                }
             }
             return rezultat;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
             decimal rezultat = (decimal)d.cijenaDionica[0].Price;
             DateTime initDateTime = (DateTime)d.cijenaDionica[0].DateTime;

             foreach (CijenaITimeStamp cit in d.cijenaDionica)
             {
                 if (initDateTime < cit.DateTime)
                 {
                     rezultat = cit.Price;
                 }
             }
             return rezultat;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!IndexExists(inIndexName) && (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED))
             {
                 Indeks noviIndeks = new Indeks(inIndexName, inIndexType);
                 indeksi.Add(noviIndeks);
             }
             else
             {
                 throw new StockExchangeException("Indeks već postoji ili ste zadali krivi indexType.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 if (!IsStockPartOfIndex(inIndexName, inStockName))
                 {
                     Indeks i = indeksi.Find(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower());
                     Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     i.inDionice.Add(d);
                 }
                 else
                 {
                    throw new StockExchangeException("Već postoji dionica u ovom indeksu.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Indeks i/ili dionica ne postoje.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName) && IndexExists(inIndexName))
             {
                 if (IsStockPartOfIndex(inIndexName, inStockName))
                 {
                     Indeks i = indeksi.Find(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower());
                     Dionica d = i.inDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     i.inDionice.Remove(d);
                 }
                 else
                 {
                     throw new StockExchangeException("Već postoji dionica u ovom indeksu.");
                 }
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica ili index.");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Indeks i = indeksi.Find(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower());
             if (!i.inDionice.Any(dionica => dionica.Ime.ToLower() == inStockName.ToLower()))
             {
                 return false;
             }
             else
             {
                 return true;
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 Indeks i = indeksi.Find(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower());

                 decimal suma = 0;
                 if (i.Tip == IndexTypes.AVERAGE)
                 {
                     foreach (Dionica d in i.inDionice)
                     {
                         suma += GetStockPriceAtSpecificMoment(d, inTimeStamp);
                     }
                     suma /= i.inDionice.Count;
                 }
                 else
                 {
                     decimal sumaSvega = 0;
                     foreach (Dionica d in i.inDionice)
                     {
                         sumaSvega += GetStockPriceAtSpecificMoment(d, inTimeStamp) * d.Broj;
                     }
                     foreach (Dionica d in i.inDionice)
                     {
                         suma += GetStockPriceAtSpecificMoment(d, inTimeStamp) * GetStockPriceAtSpecificMoment(d, inTimeStamp) * d.Broj / sumaSvega;
                     }
                 }
                 return suma;
             }
             else 
             {
                 throw new StockExchangeException("Index ne postoji.");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             if (indeksi.Any(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower()))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return indeksi.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Indeks i = indeksi.Find(indeks => indeks.Naziv.ToLower() == inIndexName.ToLower());
             return i.inDionice.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio već postoji.");
             }
             else
             {
                Portfolio noviPortfolio = new Portfolio(inPortfolioID);
                portfelji.Add(noviPortfolio);
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Nevažeći broj dionica.");
             }
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Dionica d = dionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                 long sumaDionica = 0;
                 foreach (Portfolio por in portfelji)
                 {
                     if(por.pDionice.Any(dionica => dionica.Ime.ToLower() == inStockName.ToLower()))
                     {
                         DionicaUPortfoliu di = por.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                         sumaDionica += di.BrojDionicaUPortfoliju;
                     }
                 }
                 long brojPreostalihDionica = d.Broj - sumaDionica;

                 if (brojPreostalihDionica < numberOfShares)
                 {
                     numberOfShares = (int)brojPreostalihDionica;
                 }

                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     p.pDionice.Add(new DionicaUPortfoliu(d.Ime, d.Broj, d.cijenaDionica, numberOfShares));
                     DionicaUPortfoliu pDionica = p.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     pDionica.BrojDionicaUPortfoliju = numberOfShares;
                 }
                 else 
                 {
                     DionicaUPortfoliu dp = p.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     dp.BrojDionicaUPortfoliju += numberOfShares;
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfolio ili dionica ne postoje.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     DionicaUPortfoliu pDionica = p.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     if (pDionica.BrojDionicaUPortfoliju - numberOfShares > 0)
                     {
                         pDionica.BrojDionicaUPortfoliju -= numberOfShares;
                     }
                     else{
                         p.pDionice.Remove(pDionica);
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Dionice nema u portfoliju.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     DionicaUPortfoliu pDionica = p.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                     p.pDionice.Remove(pDionica);
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         public int NumberOfPortfolios()
         {
             return portfelji.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 return p.pDionice.Count;
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (portfelji.Any(portfolio => portfolio.Naziv == inPortfolioID))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 if (p.pDionice.Any(dionica => dionica.Ime.ToLower() == inStockName.ToLower()))
                 {
                     return true;
                 }
                 else 
                 {
                     return false;
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 DionicaUPortfoliu dp = p.pDionice.Find(dionica => dionica.Ime.ToLower() == inStockName.ToLower());
                 return (int)dp.BrojDionicaUPortfoliju;
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 decimal suma = 0;
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 foreach (DionicaUPortfoliu dp in p.pDionice) 
                 {
                     suma += dp.BrojDionicaUPortfoliju * GetStockPriceAtSpecificMoment(dp, timeStamp);
                 }
                 return suma;
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if(Month < 1 || Month > 12)
             {
                 throw new StockExchangeException("Pogrešan datum.");
             }
             if (PortfolioExists(inPortfolioID))
             {
                 Portfolio p = portfelji.Find(por => por.Naziv == inPortfolioID);
                 decimal startValue = 0;
                 decimal endValue = 0;
                 foreach(DionicaUPortfoliu dp in p.pDionice)
                 {
                     startValue += dp.BrojDionicaUPortfoliju * GetStockPriceAtSpecificMoment(dp, new DateTime(Year, Month, 1, 0, 0, 0, 0));
                     endValue += dp.BrojDionicaUPortfoliju * GetStockPriceAtSpecificMoment(dp, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
                 }

                 return 100 * (endValue - startValue) / startValue;
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne postoji.");
             }
         }

         private decimal GetStockPriceAtSpecificMoment(DionicaUPortfoliu dp, DateTime dateTime)
         {
             DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0);
             decimal cijena = 0;
             foreach (CijenaITimeStamp cit in dp.cijenaDionica)
             {
                 if (cit.DateTime > dt && cit.DateTime <= dateTime)
                 {
                     dt = cit.DateTime;
                     cijena = cit.Price;
                 }
             }
             return cijena;
         }

         private decimal GetStockPriceAtSpecificMoment(Dionica d, DateTime dateTime)
         {
             DateTime dt = new DateTime(1970,1,1,0,0,0);
             decimal cijena = 0;
             foreach(CijenaITimeStamp cit in d.cijenaDionica)
             {
                 if (cit.DateTime > dt && cit.DateTime <= dateTime)
                 {
                     dt = cit.DateTime;
                     cijena = cit.Price;
                 }
             }
             return cijena;
         }
     }

    public class Dionica 
    {
        public Dionica(string ime, long broj, decimal cijena, DateTime trenutak)
        {
            if (cijena <= 0 || broj <= 0)
            {
                throw new StockExchangeException("Cijena ne može bit negativna, niti može biti negativan broj dionica.");
            }
            _ime = ime;
            _broj = broj;
            cijenaDionica.Add(new CijenaITimeStamp(cijena, trenutak));
        }

         private string _ime;
         private long _broj;
         public List<CijenaITimeStamp> cijenaDionica = new List<CijenaITimeStamp>();

         public string Ime
         {
             get { return _ime; }
             set { _ime = value; }
         }
         
         public long Broj
         {
             get { return _broj; }
             set { _broj = value; }
         }
         public Dionica() { }
     }

    public class Indeks
    {
        private string _naziv;
        private IndexTypes _tip;
        public List<Dionica> inDionice = new List<Dionica>();

        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        public IndexTypes Tip
        {
            get { return _tip; }
            set { _tip = value; }
        }

        public Indeks(string naziv, IndexTypes tip){
            _naziv = naziv;
            _tip = tip;
        }

    }

    public class Portfolio
    {
        private string _naziv;
        public List<DionicaUPortfoliu> pDionice = new List<DionicaUPortfoliu>();

        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        public Portfolio(string naziv)
        {
            _naziv = naziv;
        }
    }

    public class DionicaUPortfoliu : Dionica
    {
        private long _brojDionicaUPortfoliju;

        public long BrojDionicaUPortfoliju
        {
            get { return _brojDionicaUPortfoliju; }
            set { _brojDionicaUPortfoliju = value; }
        }

        public DionicaUPortfoliu(string ime, long broj, List<CijenaITimeStamp> cDionice, long brojDionicaUPortfoliju)
        {
            Ime = ime;
            Broj = broj;
            cijenaDionica = cDionice;
            BrojDionicaUPortfoliju = brojDionicaUPortfoliju;
        }

    }

    public class CijenaITimeStamp 
    {
        private decimal _price;
        private DateTime _dateTime;

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public DateTime DateTime
        {
            get { return _dateTime; }
            set { _dateTime = value; }
        }

        public CijenaITimeStamp(decimal cijena, DateTime dt)
        {
            _price = cijena;
            _dateTime = dt;
        }
    }

}
