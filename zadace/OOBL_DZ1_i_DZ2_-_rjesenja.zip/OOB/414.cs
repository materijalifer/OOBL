﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string display="0";
        private char[] brojevi = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        private int z = 0;
        private double memory;
        private int isOn = 1;
        private double rezultat = 0, spremljen = 0;
        private int br = 0;
        private char op;
        private string error;
        private int brOpr = 0, proslaOpr = 0;

        

        public void Press(char inPressedDigit)
        {
            if (display != "" && display[0] == '0')
            {
                display = display.Substring(1);
            }
            int flag = 0;
            if (inPressedDigit == ',')
                z = 1;
            if (inPressedDigit == ',' && display == "")
                display += '0';
            foreach (char br in brojevi)
            {
                if (inPressedDigit == br || inPressedDigit == ',')
                {
                    flag = 1;
                }
            }
            if (flag == 1 && isOn == 1 && z == 0) //unos znamenke ili zareza
            {
                br++;
                if (br <= 10)
                {
                    display += inPressedDigit;
                    rezultat = Convert.ToDouble(display);
                }

            }
            if (flag == 1 && isOn == 1 && z == 1) //unos znamenke ili zareza
            {
                br++;
                if (br <= 11)
                {
                    display += inPressedDigit;
                    rezultat = Convert.ToDouble(display);
                }

            }
            if (flag == 0 && isOn == 1) //unos operacije
            {
                z = 0;
                br = 0;
                if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
                    brOpr++;

                switch (inPressedDigit)
                {
                    case '+':
                        op = '+';
                        if (brOpr == 1)
                            spremljen = rezultat;
                        if (brOpr > 1)
                        {
                            rezultat = spremljen + rezultat;
                            spremljen = rezultat;
                        }
                        display = "0";
                        break;
                    case '-':
                        op = '-';
                        if (brOpr == 1)
                            spremljen = rezultat;
                        if (brOpr > 1)
                        {
                            rezultat = spremljen - rezultat;
                            spremljen = rezultat;
                        }
                        spremljen = rezultat;
                        display = "0";
                        break;
                    case '*':
                        op = '*';
                        if (brOpr == 1)
                            spremljen = rezultat;
                        if (brOpr > 1)
                        {
                            rezultat = spremljen * rezultat;
                            spremljen = rezultat;
                        }
                        spremljen = rezultat;
                        display = "0";
                        break;
                    case '/':
                        op = '/';
                        if (brOpr == 1)
                            spremljen = rezultat;
                        if (brOpr > 1)
                        {
                            rezultat = spremljen / rezultat;
                            spremljen = rezultat;
                        }
                        spremljen = rezultat;
                        display = "0";
                        break;
                    case 'M':
                        if (display == "0")
                            break;
                        else
                        {
                            rezultat = -rezultat;
                            display = '-' + display;
                            break;
                        }
                    case 'S':
                        rezultat = Math.Sin(rezultat);
                        break;
                    case 'K':
                        rezultat = Math.Cos(rezultat);
                        break;
                    case 'T':
                        rezultat = Math.Tan(rezultat);
                        break;
                    case 'Q':
                        rezultat = rezultat * rezultat;
                        break;
                    case 'R':
                        rezultat = Math.Sqrt(rezultat);
                        break;
                    case 'I':
                        if (rezultat != 0)
                            rezultat = 1 / rezultat;
                        else
                            error = "-E-";
                        break;
                    case 'P':
                        memory = rezultat;
                        break;
                    case 'G':
                        rezultat = memory;
                        break;
                    case 'C':
                        display = "0";
                        break;
                    case 'O':
                        isOn = 0;
                        break;
                    case '=':
                        switch (op)
                        {
                            case '+':
                                rezultat = spremljen + rezultat;
                                break;
                            case '-':
                                rezultat = spremljen - rezultat;
                                break;
                            case '*':
                                rezultat = spremljen * rezultat;
                                break;
                            case '/':
                                rezultat = spremljen / rezultat;
                                break;
                        }
                        break;
                }

            }
            if (isOn == 0)
            {
                display = "0";
                memory = 0;
                rezultat = 0;
            }

        }

        public string GetCurrentDisplayState()
        {
            string ekran = rezultat.ToString();
            if (error == "-E-")
                return ekran = "-E-";
            if (ekran.Length > 10)
            {
                int zarez = 0;
                foreach (char c in ekran)
                {

                    if (c != ',')
                    {
                        zarez ++;
                    }
                    else
                        break;
                }

                if (ekran.Contains(',') && ekran.Contains('-'))
                {
                    return ekran = Math.Round(rezultat, 11 - zarez).ToString();
                }
                if (ekran.Contains(',') && !ekran.Contains('-'))
                {
                    return ekran = Math.Round(rezultat, 10 - zarez).ToString();
                }
                if (!ekran.Contains(',') && !ekran.Contains('-'))
                {
                    return ekran = "-E-";
                }
                else
                    return ekran;
            }
            
            else
                return ekran;

        }

        
        
    }


}
