using System;
using System.Collections.Generic;
using System.Linq;


namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class StockExchange : IStockExchange
    {
        private List<Stock> _stockList;
        private List<Index> _indexList;
        private List<Portfolio> _portfolioList;

        public StockExchange()
        {
            _stockList = new List<Stock>();
            _indexList = new List<Index>();
            _portfolioList = new List<Portfolio>();
        }


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (_stockList.Exists(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)))
                throw new StockExchangeException("Dionica vec postoji!");
            var stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            _stockList.Add(stock);
        }

        public void DelistStock(string inStockName)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu

            if (tmpStock != null) //provjera postoji li dionica 
            {
                _stockList.Remove(tmpStock);
                RemoveDeletedStockFromEverywhere(tmpStock.GetName());
            }

            else
                throw new StockExchangeException("Dionica ne postoji!");
        }

        public bool StockExists(string inStockName)
        {
            return _stockList.Exists(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase));
        }

        public int NumberOfStocks()
        {
            return _stockList.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu

            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            tmpStock.SetStockPriceTime(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            return tmpStock.GetStockPriceTime(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            return tmpStock.GetStockInitPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            return tmpStock.GetStockPriceTime(DateTime.Now);
        }


        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (_indexList.Exists(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)))
                throw new StockExchangeException("Index vec postoji!");
            var index = new Index(inIndexName, inIndexType);
            _indexList.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var tmpIndex = _indexList.Find(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)); //dohvati indeks
            if (tmpIndex == null)
                throw new StockExchangeException("Indeks ne postoji!");
            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            tmpIndex.AddStockToStockList(tmpStock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var tmpIndex = _indexList.Find(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)); //dohvati indeks
            if (tmpIndex == null)
                throw new StockExchangeException("Indeks ne postoji!");
            tmpIndex.RemoveStockFromStockList(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var tmpIndex = _indexList.Find(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)); //dohvati indeks

            if (tmpIndex == null)
                throw new StockExchangeException("Indeks ne postoji!");
            return tmpIndex.IsStockInStockList(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var tmpIndex = _indexList.Find(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)); //dohvati indeks
            if (tmpIndex == null)
                throw new StockExchangeException("Indeks ne postoji!");
            return tmpIndex.GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return _indexList.Exists(x => x.GetName() == inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indexList.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            var tmpIndex = _indexList.Find(x => x.GetName().Equals(inIndexName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu

            if (tmpIndex == null)
                throw new StockExchangeException("Indeks ne postoji!");
            return tmpIndex.StockListCount();
        }



        public void CreatePortfolio(string inPortfolioID)
        {
            if (_portfolioList.Exists(x => x.GetName().Equals(inPortfolioID)))
                throw new StockExchangeException("Portfolio vec postoji!");
            var portfolio = new Portfolio(inPortfolioID);
            _portfolioList.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            //provjera da se dodaje >0 dionica
            if (numberOfShares <= 0)
                throw new StockExchangeException("Nije moguce dodati u portfelj <=0 dionica!");

            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati indeks
            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");

            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            tmpPortfolio.ModifyPortfolioStockList(tmpStock, numberOfShares);

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati indeks
            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");

            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            tmpPortfolio.ModifyPortfolioStockList(tmpStock, (0 - numberOfShares));  //vidi definiciji ModifyPortfolioStockList(...)
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati indeks
            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");

            var tmpStock = _stockList.Find(x => x.GetName().Equals(inStockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            tmpPortfolio.RemoveFromPortfolioStockList(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return _portfolioList.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati portfelj

            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");
            return tmpPortfolio.StockListCount();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioList.Exists(x => x.GetName().Equals(inPortfolioID));
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati portfelj

            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");
            return tmpPortfolio.IsStockInStockList(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati portfelj

            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");
            return tmpPortfolio.StockListSharesCount(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati portfelj
            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfolio ne postoji!");
            return tmpPortfolio.GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var tmpPortfolio = _portfolioList.Find(x => x.GetName().Equals(inPortfolioID)); //dohvati portfelj
            if (tmpPortfolio == null)
                throw new StockExchangeException("Portfelj ne postoji!");


            decimal result = tmpPortfolio.GetPortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) - tmpPortfolio.GetPortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0));
            result /= tmpPortfolio.GetPortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0));
            result *= 100;
            return decimal.Round(result, 3);
        }

        /// <summary>
        /// Uklanja obrisanu dionicu s burze iz svih lista
        /// </summary>
        private void RemoveDeletedStockFromEverywhere(string stockName)
        {
            foreach (var index in _indexList)
            {
                if (index.IsStockInStockList(stockName))
                {
                    index.RemoveStockFromStockList(stockName);
                }

            }

            foreach (var portfolio in _portfolioList)
            {
                if (portfolio.IsStockInStockList(stockName))
                    portfolio.RemoveFromPortfolioStockList(stockName);
            }
        }

    }

	/// <summary>
    /// Klasa koja implementira funkcionalnosti dionice
    /// </summary>
    public class Stock
    {
        private string _name;
        private long _numberOfShares;
        private long _availableShares;      //broj slobodnih dionica koje moze preuzeti neki portfelj
        private List<StockPrice> _stockPrice;     //lista datum - vrijednost dionice od tog datuma


        public Stock(string name, long numberOfShares, decimal stockPrice, DateTime timeStamp)
        {
            if (name == null)
                throw new StockExchangeException("Ime dionice ne moze biti NULL!");
            _name = name;
            if (numberOfShares <= 0)
                throw new StockExchangeException("Neispravna vrijednost broja dionica!");
            _numberOfShares = numberOfShares;
            _availableShares = _numberOfShares;
            var sp = new StockPrice(stockPrice, timeStamp);
            _stockPrice = new List<StockPrice> { sp };
        }



        public string GetName()
        {
            return _name;
        }

        public long GetNumberOfShares()
        {
            return _numberOfShares;
        }

        public long GetAvailableShares()
        {
            return _availableShares;
        }

        public void SetAvailableShares(long shares)
        {
            if (shares > _numberOfShares || shares < 0)
                throw new StockExchangeException("Ne moze se postaviti vise dionica od maksimuma ili manje od 0!");
            _availableShares = shares;
        }

        /// <summary>
        /// Dohva?anje po?etne cijene dionice - prvi element liste _stockPrice
        /// </summary>
        public decimal GetStockInitPrice()
        {
            return _stockPrice.First().GetValue();
        }


        /// <summary>
        /// Dohva?anje cijene dionice za odre?eni datum i vrijeme
        /// </summary>
        public decimal GetStockPriceTime(DateTime timeStamp)
        {
            StockPrice prevStockPrice = null;

            foreach (var paramse in _stockPrice)
            {
                if (prevStockPrice == null)     //prvi prolaz kroz petlju
                {
                    if (paramse.GetTimeStamp() > timeStamp) //ako je zadan datum prije prvog definiranja cijene
                        throw new StockExchangeException("Za ovo vrijeme nema definirane cijene!");
                    prevStockPrice = paramse;
                    continue;
                }

                if (prevStockPrice.GetTimeStamp() <= timeStamp && paramse.GetTimeStamp() > timeStamp)
                    break;  //prosla vrijednost je tra?ena

                if (paramse == null)
                    break;

                prevStockPrice = paramse;
            }

            return prevStockPrice.GetValue();
        }


        /// <summary>
        /// Postavljanje cijene dionice za odre?eni datum i vrijeme
        /// i 
        /// sortiranje liste po vremenu
        /// </summary>
        public void SetStockPriceTime(decimal stockPrice, DateTime timeStamp)
        {
            if (_stockPrice.Exists(x => x.GetTimeStamp().Equals(timeStamp)))   //provjera postoji li vec zapis za taj trenutak
                throw new StockExchangeException("Za zadano vrijeme vec postoji unos");

            var sp = new StockPrice(stockPrice, timeStamp);
            _stockPrice.Add(sp);
            _stockPrice.Sort((x, y) => x.GetTimeStamp().CompareTo(y.GetTimeStamp())); //sortiranje
        }


    }
	
	/// <summary>
    /// Klasa koja enkapsulira parametre cijene dionice:
    /// cijenu (_value) i
    /// vrijeme od kojeg vrijedi (_timeStamp)
    /// </summary>
    public class StockPrice
    {
        private decimal _value;
        private DateTime _timeStamp;

        public StockPrice(decimal value, DateTime timeStamp)
        {
            if (value <= 0)
                throw new StockExchangeException("Cijena dionice mora biti veca od 0!");
            _value = value;

            if (timeStamp == null)
                throw new StockExchangeException("Vrem. oznaka ne smije biti NULL!");
            _timeStamp = timeStamp;
        }

        public decimal GetValue()
        {
            return _value;
        }

        public DateTime GetTimeStamp()
        {
            return _timeStamp;
        }

    }

	/// <summary>
    /// Klasa koja implementira funkcionalnosti burzovnog indeksa
    /// </summary>
    public class Index
    {
        private string _name;
        private IndexTypes _type;
        private List<Stock> _stockList;     //lista dionica koje pripadaju indeksu

        public Index(string name, IndexTypes type)
        {
            if (name == null)
                throw new StockExchangeException("Ime indeksa ne smije biti NULL");
            _name = name;

            if (!Enum.IsDefined(typeof(IndexTypes), type))
                throw new StockExchangeException("Nepodrzani tip indeksa!");
            _type = type;

            _stockList = new List<Stock>();
        }

        public string GetName()
        {
            return _name;
        }

        /// <returns>Vraca broj dionica u listi indeksa</returns>
        public int StockListCount()
        {
            return _stockList.Count();
        }

        /// <summary>
        /// Dodavanje dionice u listu
        /// </summary>
        public void AddStockToStockList(Stock stock)
        {
            if (_stockList.Exists(x => x.GetName().Equals(stock.GetName(), StringComparison.OrdinalIgnoreCase)))
                throw new StockExchangeException("Dionica je vec dodana u indeks");
            _stockList.Add(stock);
        }

        /// <summary>
        /// Brisanje dionice iz liste
        /// </summary>
        public void RemoveStockFromStockList(string stockName)
        {
            var tmpStock = _stockList.Find(x => x.GetName().Equals(stockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!"); ;
            _stockList.Remove(tmpStock);
        }

        /// <summary>
        /// Upit je li dionica u listi
        /// </summary>
        public bool IsStockInStockList(string stockName)
        {
            return _stockList.Exists(x => x.GetName().Equals(stockName, StringComparison.OrdinalIgnoreCase)); //pronadi dionicu
        }

        /// <summary>
        /// Izracun vrijednosti indeksa ovisno o tipu indeksa
        /// </summary>
        public decimal GetIndexValue(DateTime timeStamp)
        {
            decimal sum = 0.0m;
            decimal totalSum = 0.0m;


            //prema tipu indeksa izracunati prosjek
            switch (_type)
            {
                case IndexTypes.AVERAGE:
                    sum = 0;
                    foreach (var stock in _stockList)
                    {
                        sum += stock.GetStockPriceTime(timeStamp);

                    }

                    if(_stockList.Any())
                        sum /= _stockList.Count();  //obican prosjek
                    break;

                default:
                    sum = 0;
                    totalSum = 0;
                    //najprije odrediti ukupnu sumu svih dionica
                    foreach (var stock in _stockList)
                        totalSum += stock.GetStockPriceTime(timeStamp) * stock.GetNumberOfShares();


                    foreach (var stock in _stockList)
                        sum += (stock.GetStockPriceTime(timeStamp) * stock.GetNumberOfShares() / totalSum) *
                               stock.GetStockPriceTime(timeStamp);  //suma tezinskih prosjeka

                    break;
            }

            return decimal.Round(sum, 3);
        }
    }
	
	/// <summary>
    /// Klasa koja modelira portfelj
    /// </summary>
    public class Portfolio
    {
        private string _name;
        private List<PortfolioStockParams> _stockParamsList;

        public Portfolio(string name)
        {
            if (name == null)
                throw new StockExchangeException("Ime portfelja ne smije biti NULL!");
            _name = name;
            _stockParamsList = new List<PortfolioStockParams>();
        }

        public string GetName()
        {
            return _name;
        }


        /// <returns>Vraca broj dionica u portfelju</returns>
        public int StockListCount()
        {
            return _stockParamsList.Count();
        }

        ///  <returns>Vraca broj shareova za dionicu zadanu ulaznim parametrom</returns>
        public int StockListSharesCount(string stockName)
        {
            var tmpStock = _stockParamsList.Find(x => x.GetStockName().Equals(stockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            return (int)tmpStock.GetSharesOwned();
        }

        /// <summary>
        /// Provjerava je li cijena definirana za neki vremenski trenutak.
        /// Hvata iznimke koje baca klasa Stock kada cijena nije definirana
        /// </summary>
        /// <returns>Vraca true ako je cijena definirana, false ako nije</returns>
        public bool IsStockPriceDefinedForTimeStamp(DateTime timeStamp)
        {
            foreach (var stock in _stockParamsList)
                try
                {
                    stock.GetStockPriceTime(timeStamp);
                }
                catch (StockExchangeException)
                {
                    return false;
                }
            return true;
        }

        ///  <returns>Daje odgovor je li dionica u portfelju</returns>
        public bool IsStockInStockList(string stockName)
        {
            return _stockParamsList.Exists(x => x.GetStockName().Equals(stockName, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Funkcija za dodavanje dionica u portfelj i brisanje iz njega
        /// </summary>
        /// <param name="stock"> Dionica ciji se shareovi dodaju/brisu</param>
        /// <param name="numberOfShares">Broj shareova, pozitivan ako se dodaju u portfelj, negativan kada se brisu</param>
        public void ModifyPortfolioStockList(Stock stock, long numberOfShares)
        {
            var tmpStock = _stockParamsList.Find(x => x.GetStockName().Equals(stock.GetName(), StringComparison.OrdinalIgnoreCase)); //dohvati dionicu

            if (tmpStock != null)   //ako dionica vec postoji u portfelju promijeni broj shareova
            {
                if (tmpStock.GetSharesOwned() < (0 - numberOfShares))   //provjera za neg. broj dionica (oslobadanje)
                    throw new StockExchangeException("Ne moze se vratiti vise dionica nego sto ima u portfelju!");
                tmpStock.SetSharesOwned(tmpStock.GetSharesOwned() + numberOfShares);

                if (tmpStock.GetSharesOwned() == 0)                 //ako je u portfelju nakon izmjene ostalo 0 dionica,
                    RemoveFromPortfolioStockList(stock.GetName());  //obrisi dionicu
            }
            else
            {   //ako se dionica dodaje prvi put dodaj je u listu portfelja
                var tmpParams = new PortfolioStockParams(stock, numberOfShares);
                _stockParamsList.Add(tmpParams);
            }

            //ako je bilo sve OK promijeni broj dostupnih dionica na burzi
            stock.SetAvailableShares(stock.GetAvailableShares() - numberOfShares);
        }

        /// <summary>
        /// Brise dionicu iz portfelja i korigira broj slobodnih dionica
        /// </summary>
        public void RemoveFromPortfolioStockList(string stockName)
        {
            var tmpStock = _stockParamsList.Find(x => x.GetStockName().Equals(stockName, StringComparison.OrdinalIgnoreCase)); //dohvati dionicu
            if (tmpStock == null)
                throw new StockExchangeException("Dionica ne postoji!");
            _stockParamsList.Remove(tmpStock);
            tmpStock.SetStockAvailableShares(tmpStock.GetStockAvailableShares() + tmpStock.GetSharesOwned());  //ispravi broj slobodnih dionica
        }

        /// <summary>
        /// Racuna ukupnu vrijednost portfelja za odredeni vremenski trenutak
        /// </summary>
        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal sum = 0.0m;

            //odrediti ukupnu sumu svih dionica
            foreach (var stock in _stockParamsList)
                sum += stock.GetStockPriceTime(timeStamp) * stock.GetSharesOwned();

            return decimal.Round(sum, 3);
        }


    }
	
	/// <summary>
    /// Ova klasa u sebi sadr?i informaciju o postoje?oj dionici
    /// te informaciju koliko dijelova dionice (shares) je u portfelju
    /// </summary>
    public class PortfolioStockParams
    {
        private Stock _stock;
        private long _sharesOwned;  //broj dijelova dionice u portfelju

        public PortfolioStockParams(Stock stock, long sharesPurchased)
        {
            _stock = stock;
            if (sharesPurchased <= 0)  //provjera ispravnosti broja dionica
                throw new StockExchangeException("Nije moguce kupiti <=0 dionica!");
            _sharesOwned = sharesPurchased;
        }

        public long GetSharesOwned()
        {
            return _sharesOwned;
        }

        public void SetSharesOwned(long sharesPurchased)
        {
            _sharesOwned = sharesPurchased;
        }


        /// <summary>
        /// Sve nize definirane metode zapravo su omot oko metoda klase Stock ?ije metode pozivaju.
        /// Sluze tome da se preko ove klase izvana ne moze direktno manipulirati s parametrima klase Stock
        /// </summary>

        public string GetStockName()
        {
            return _stock.GetName();    //ime dionice
        }

        public long GetTotalShares()
        {
            return _stock.GetNumberOfShares();  //ukupni broj shares
        }

        public long GetStockAvailableShares()
        {
            return _stock.GetAvailableShares();     //dostupni broj shares
        }

        public void SetStockAvailableShares(long shares)
        {
            _stock.SetAvailableShares(shares);      //modifikacija dostupnih shares
        }

        public decimal GetStockPriceTime(DateTime timeStamp)
        {
            return _stock.GetStockPriceTime(timeStamp);     //cijena dionice
        }


    }
}
