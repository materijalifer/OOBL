﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            StockExchange se = new StockExchange();
            return se;
        }
    }

    public class Stock
    {
        private string _StockName;
        private decimal _InitialStockPrice;
        private DateTime _InitialTimeStamp;
        private Dictionary<TimetFrameSet, decimal> _StockPrices = new Dictionary<TimetFrameSet, decimal>();
        private decimal _LastStockPrice;
        private DateTime _LastTimeStamp;
        private long _NumberOfShares;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _StockName = inStockName;
            _InitialStockPrice = inInitialPrice;
            _InitialTimeStamp = inTimeStamp;
            _StockPrices.Add(new TimetFrameSet() { startTime = DateTime.Now, endTime = inTimeStamp }, inInitialPrice);
            _LastStockPrice = inInitialPrice;
            _LastTimeStamp = inTimeStamp;
            _NumberOfShares = inNumberOfShares;
        }

        public void SetPrice(decimal value, DateTime timeStamp)
        {
            _StockPrices.Add(new TimetFrameSet() { startTime = DateTime.Now, endTime = timeStamp }, value);
            _LastStockPrice = value; _LastTimeStamp = timeStamp;
            _StockPrices.Add(new TimetFrameSet() { startTime = DateTime.Now, endTime = timeStamp }, value);
        }

        public string GetName(){ return _StockName; }

        public decimal GetInitialPrice() { return _InitialStockPrice; }

        public decimal GetLastPrice() { return _LastStockPrice; }

        public long GetNumberOfShares() { return _NumberOfShares; }

        public Dictionary<TimetFrameSet, decimal> GetStockPricesHystory() { return _StockPrices; }

        public decimal GetPriceForDate(DateTime date)
        {
            foreach (TimetFrameSet ts in _StockPrices.Keys)
                if (date >= ts.startTime && date <= ts.endTime)
                    return _StockPrices[ts];
            return 0;
        }

        public void SetNumberOfShares(long number) { _NumberOfShares = number; }

        public Dictionary<TimetFrameSet, decimal> GetTimeFrameSet() { return _StockPrices; }

    }

    public class TimetFrameSet
    {
        public DateTime startTime { get; set; }
        public DateTime endTime { get; set; }
    }

    public class Index
    {
        private string _IndexName;
        private IndexTypes _IndexType;
        private decimal _IndexValue;
        private Dictionary<string, Stock> _IndexStocks = new Dictionary<string, Stock>();

        public Index(string name, IndexTypes indexType)
        {
            _IndexName = name;
            _IndexType = indexType;
        }

        public string GetName() { return _IndexName; }

        public void SetStock(Stock stock) { _IndexStocks.Add(stock.GetName(), stock); }

        public Stock GetStock(string name) { return _IndexStocks[name];}

        public Dictionary<string, Stock> GetStocks() { return _IndexStocks; }

        public void RemoveStock(string name) { _IndexStocks.Remove(name); }

        public void CalculateIndex()
        {
            decimal sum = 0;
            if (_IndexType == IndexTypes.AVERAGE)
            {
                foreach (Stock stock in _IndexStocks.Values)
                    sum += stock.GetLastPrice();
                sum = sum / _IndexStocks.Values.Count;
            }
            else
            {
                decimal stockSum = 0;
                foreach (Stock stock in _IndexStocks.Values)
                    stockSum += (stock.GetLastPrice() * stock.GetNumberOfShares());
                Dictionary<decimal, decimal> factorList = new Dictionary<decimal, decimal>();
                foreach (Stock stock in _IndexStocks.Values)
                    factorList.Add(stock.GetLastPrice() / stockSum, stock.GetLastPrice());
                foreach (decimal key in factorList.Keys)
                    sum += (key * factorList[key]);
            }
            _IndexValue = decimal.Round(sum, 3);
        }
    }

    public class Portfolio
    {
        private string _ID;
        private Dictionary<string, Stock> _StockList = new Dictionary<string, Stock>();
        private decimal _value;

        public Portfolio(string id)
        {
            _ID = id;
        }

        public void AddStock(Stock stock) { _StockList.Add(stock.GetName(), stock); }

        public void RemoverStock(string name) { _StockList.Remove(name); }

        public Dictionary<string, Stock> GetStocks() { return _StockList; }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> _Stocks = null;
        private Dictionary<string, Index> _Indexs = new Dictionary<string,Index>();
        private Dictionary<string, Portfolio> _Portfolios = new Dictionary<string,Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                if (_Stocks == null)
                    _Stocks = new Dictionary<string, Stock>();
                if (!_Stocks.Keys.Contains(inStockName.ToUpper()))
                    _Stocks.Add(inStockName.ToUpper(), new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            catch (Exception e)
            {
                throw new StockExchangeException(e.ToString());
            }
            
        }

        public void DelistStock(string inStockName)
        {
            try { _Stocks.Remove(inStockName.ToUpper()); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public bool StockExists(string inStockName)
        {
            try
            {
                if (_Stocks.Keys.Contains(inStockName.ToUpper()))
                    return true;
                else
                    return false;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public int NumberOfStocks()
        {
            try { return _Stocks.Keys.Count; }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            try
            {
                if (_Stocks.Keys.Equals(inStockName.ToUpper()))
                    _Stocks[inStockName.ToUpper()].SetPrice(inStockValue, inIimeStamp);
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                decimal price = (from d in _Stocks.Values where d.GetName().Equals(inStockName.ToUpper()) select d.GetPriceForDate(inTimeStamp)).Single();
                return price;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            try { return _Stocks[inStockName.ToUpper()].GetInitialPrice(); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            try { return _Stocks[inStockName.ToUpper()].GetLastPrice(); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            try
            {
                if (_Indexs.Keys.Count > 0)
                    if (!_Indexs.Keys.Contains(inIndexName.ToUpper()))
                        _Indexs.Add(inIndexName.ToUpper(), new Index(inIndexName.ToUpper(), inIndexType));
                    else
                        _Indexs.Add(inIndexName.ToUpper(), new Index(inIndexName.ToUpper(), inIndexType));
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                if (_Stocks.Keys.Contains(inStockName.ToUpper()))
                    _Indexs[inIndexName.ToUpper()].SetStock(_Stocks[inStockName.ToUpper()]);
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try { _Indexs[inIndexName.ToUpper()].RemoveStock(inStockName.ToUpper()); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                if (_Indexs[inIndexName.ToUpper()].GetStock(inStockName.ToUpper()).GetName().Equals(inStockName.ToUpper()))
                    return true;
                return false;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                decimal sum = 0;
                foreach (Stock stock in _Indexs[inIndexName.ToUpper()].GetStocks().Values)
                    sum += stock.GetNumberOfShares() * stock.GetPriceForDate(inTimeStamp);
                return sum;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public bool IndexExists(string inIndexName)
        {
            try
            {
                if (_Indexs.Keys.Contains(inIndexName.ToUpper()))
                    return true;
                return false;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public int NumberOfIndices() { try { return _Indexs.Keys.Count(); } catch (Exception e) { throw new StockExchangeException(e.ToString()); } }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            try { return _Indexs[inIndexName].GetStocks().Keys.Count; }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            try
            {
                if (!_Portfolios.Keys.Contains(inPortfolioID))
                    _Portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                if (numberOfShares <= Convert.ToInt32(_Stocks[inStockName.ToUpper()].GetNumberOfShares()))
                {
                    Stock stock = _Stocks[inStockName.ToUpper()];
                    stock.SetNumberOfShares(Convert.ToInt64(numberOfShares));
                    _Portfolios[inPortfolioID].AddStock(stock);
                }
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                int stockShares = Convert.ToInt32(_Portfolios[inPortfolioID].GetStocks()[inStockName.ToUpper()].GetNumberOfShares()) - numberOfShares;
                if (stockShares > 0)
                    _Portfolios[inPortfolioID].GetStocks()[inStockName.ToUpper()].SetNumberOfShares(Convert.ToInt64(stockShares));
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            try { _Portfolios[inPortfolioID].RemoverStock(inStockName.ToUpper()); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public int NumberOfPortfolios()
        {
            try { return _Portfolios.Keys.Count; }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try { return _Portfolios[inPortfolioID].GetStocks().Values.Count; }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            try
            {
                if (_Portfolios.Keys.Contains(inPortfolioID))
                    return true;
                return false;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                if (_Portfolios[inPortfolioID].GetStocks().Keys.Contains(inStockName.ToUpper()))
                    return true;
                return false;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            try { return Convert.ToInt32(_Portfolios[inPortfolioID].GetStocks()[inStockName.ToUpper()].GetNumberOfShares()); }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            try
            {
                decimal sum = 0;
                foreach (Stock stock in _Portfolios[inPortfolioID].GetStocks().Values)
                    sum += stock.GetNumberOfShares() * stock.GetPriceForDate(timeStamp);
                return sum;
            }
            catch (Exception e) { throw new StockExchangeException(e.ToString()); }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }
    }
}