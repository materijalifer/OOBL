﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Kalkulator : ICalculator
    {
        #region interne varijable
        private string display = "0";
        private string memorija = "";
        private char[] spremnik = new char[12];
        private int brZnamenaka = 0;
        private string zadnjiUnesen = "";
        private double broj;
        private double rezultat;
        private string operacija = "";
        private bool postojiBroj = false;
        private bool unesenJednako = false;

        #endregion

        #region interface metode
        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '0':
                    {
                        unesenaNula();
                        break;
                    }
                case '1':                    
                case '2':                    
                case '3':                   
                case '4':                    
                case '5':                    
                case '6':                    
                case '7':                    
                case '8':                   
                case '9':
                    {
                        unesenBroj(inPressedDigit);
                        break;
                    }
                case '+':
                    {
                        zbrajanje(inPressedDigit);
                        break;
                    }
                case '-':
                    {
                        oduzimanje(inPressedDigit);
                        break;
                    }
                case '*':
                    {
                        mnozenje(inPressedDigit);
                        break;
                    }
                case '/':
                    {
                        dijeljenje(inPressedDigit);
                        break;
                    }
                case '=':
                    {
                        jednako();
                        break;
                    }
                case ',':
                    {
                        decimalniZarez(inPressedDigit);
                        break;
                    }
                case 'M':
                    {
                        promjeniPredznak(inPressedDigit);
                        break;
                    }
                case 'S':
                    {
                        izracunajSinus(inPressedDigit);
                        break;
                    }
                case 'K':
                    {
                        izracunajKosinus(inPressedDigit);
                        break;
                    }
                case 'T':
                    {
                        izracunajTangens(inPressedDigit);
                        break;
                    }
                case 'Q':
                    {
                        izracunajKvadrat(inPressedDigit);
                        break;
                    }
                case 'R':
                    {
                        izracunajKorijen(inPressedDigit);
                        break;
                    }
                case 'I':
                    {
                        izracunajInverz(inPressedDigit);
                        break;
                    }
                case 'P':
                    {
                        spremiUMemoriju(inPressedDigit);
                        break;
                    }
                case 'G':
                    {
                        dohvatiIzMemorije(inPressedDigit);
                        break;
                    }
                case 'C':
                    {
                        obrisiEkran(inPressedDigit);
                        break;
                    }
                case 'O':
                    {
                        resetKalkulatora(inPressedDigit);
                        break;
                    }

            }
        }

        public string GetCurrentDisplayState()
        {
            return this.display;
        }
        #endregion

        #region ostale metode
        private void resetKalkulatora(char inPressedDigit)
        {
            this.display = "0";
            this.memorija = "";
            this.brZnamenaka = 0;
            this.zadnjiUnesen = "";
            this.broj = 0;
            this.rezultat = 0;
            this.operacija = "";
            
            isprazniSpremnik();
        }

        private void obrisiEkran(char inPressedDigit)
        {
            this.display = "0";
            this.rezultat = 0;
            this.postojiBroj = false;
     
            isprazniSpremnik();
        }

        private void dohvatiIzMemorije(char inPressedDigit)
        {
            this.display = this.memorija;
        }

        private void spremiUMemoriju(char inPressedDigit)
        {
            this.memorija = this.display;
        }

        private void izracunajInverz(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double inverzBroja;

            this.zadnjiUnesen = "I";
            if(brojNaDisplayu != 0)
            {
                inverzBroja = 1 / brojNaDisplayu;
                zaokruziRezultat(inverzBroja);
            }
            else
            {
                this.display = "-E-";
            }
        }

        private void izracunajKorijen(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double korijenBroja;

            this.zadnjiUnesen = "R";
            if (brojNaDisplayu >= 0)
            {
                korijenBroja = Math.Sqrt(brojNaDisplayu);
                zaokruziRezultat(korijenBroja);
            }
            else
            {
                this.display = "-E-";
            }
        }

        private void izracunajKvadrat(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double kvadratBroja;

            this.zadnjiUnesen = "Q";
            kvadratBroja = Math.Pow(brojNaDisplayu, 2);
            zaokruziRezultat(kvadratBroja);
           
        }

        private void izracunajSinus(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double sinusBroja;

            this.zadnjiUnesen = "S";
            sinusBroja = Math.Sin(brojNaDisplayu);
            zaokruziRezultat(sinusBroja);
            
          
        }

        private void izracunajKosinus(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double kosinusBroja;

            this.zadnjiUnesen = "K";
            kosinusBroja = Math.Cos(brojNaDisplayu);
            zaokruziRezultat(kosinusBroja);
        }

        private void izracunajTangens(char inPressedDigit)
        {
            double brojNaDisplayu = double.Parse(this.display);
            double tangensBroja;

            this.zadnjiUnesen = "T";

            if (!((brojNaDisplayu == 90) || (brojNaDisplayu == 270) || (brojNaDisplayu == -90) || (brojNaDisplayu == -270)))
            {
                tangensBroja = Math.Tan(brojNaDisplayu);         
                zaokruziRezultat(tangensBroja);              
            }
            else
            {
                this.display = "-E";
            }
           
        }

        private void promjeniPredznak(char inPressedDigit)
        {

            if ((this.display != "0") && (!"IQRSKT".Contains(this.zadnjiUnesen)) && (!unesenJednako))
            {
                
                if (this.spremnik[0].Equals('-'))
                {
                    this.spremnik[0] = '\0';
                    ispisiNaEkran();
                }
                else
                {
                    this.spremnik[0] = '-';
                    ispisiNaEkran();
                }
            }
            else if (unesenJednako)
            {
                napuniSpremnik();

                if (this.spremnik[0].Equals('-'))
                {
                    this.spremnik[0] = '\0';
                    ispisiNaEkran();

                    string a = new string(this.spremnik);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
                else
                {
                    this.spremnik[0] = '\0';
                    ispisiNaEkran();

                    string a = new string(this.spremnik);
                    a = a.Replace("\0", "");
                    this.rezultat = double.Parse(a);
                }
            }
            else
            {
                this.display = "-" + this.display;
            }
        }

        private void decimalniZarez(char inPressedDigit)
        {
            if ((this.display.Contains("0")) && (this.display.Length == 1))
            {
                this.spremnik[11] = '0';
                brZnamenaka++;
            }
            else if ((this.display.Contains(",")) || (brZnamenaka == 10))
            {
                return;
            }
            pomakZnamenki(this.spremnik);
            this.spremnik[11] = ',';
            ispisiNaEkran();
        }

        private void jednako()
        {
            unesenJednako = true;
            double drugiBroj = double.Parse(this.display);

            switch (operacija)
            {
                case "+": 
                    {
                        rezultat = broj + drugiBroj;
                        break;
                    }
                case "-":
                    {
                        rezultat = broj - drugiBroj;
                        break;
                    }
                case "*":
                    {
                        rezultat = broj * drugiBroj;
                        break;
                    }
                case "/":
                    {
                        rezultat = broj / drugiBroj;
                        break;
                    }
            }

            if ((rezultat > 9999999999) || (rezultat < -9999999999))
            {
                this.display = "-E-";
                return;
            }

            zaokruziRezultat(rezultat);
        }

        private void dijeljenje(char inPressedDigit)
        {
            if (!postojiBroj)
            {
                postojiBroj = true;
                broj = double.Parse(this.display);
                isprazniSpremnik();
            }
            else if (!"+-*/".Contains(zadnjiUnesen))
            {
                if (unesenJednako == false)
                {
                    jednako();
                    broj = rezultat;
                    this.display = broj.ToString();
                    isprazniSpremnik();
                }
            }


            this.operacija = "/";
            zadnjiUnesen = "/";

            if (unesenJednako == true)
            {
                isprazniSpremnik();
                broj = rezultat;
                unesenJednako = false;
            }
        }

        private void mnozenje(char inPressedDigit)
        {
            if (!postojiBroj)
            {
                postojiBroj = true;
                broj = double.Parse(this.display);
                isprazniSpremnik();
            }
            else if (!"+-*/".Contains(zadnjiUnesen))
            {
                if (unesenJednako == false)
                {
                    jednako();
                    broj = rezultat;
                    this.display = broj.ToString();
                    isprazniSpremnik();
                }
            }


            this.operacija = "*";
            zadnjiUnesen = "*";

            if (unesenJednako == true)
            {
                isprazniSpremnik();
                broj = rezultat;
                unesenJednako = false;
            }
        }

        private void oduzimanje(char inPressedDigit)
        {
            if (!postojiBroj)
            {
                postojiBroj = true;
                broj = double.Parse(this.display);
                isprazniSpremnik();
            }
            else if (!"+-*/".Contains(zadnjiUnesen))
            {
                if (unesenJednako == false)
                {
                    jednako();
                    broj = rezultat;
                    this.display = broj.ToString();
                    isprazniSpremnik();
                }
            }


            this.operacija = "-";
            zadnjiUnesen = "-";

            if (unesenJednako == true)
            {
                isprazniSpremnik();
                broj = rezultat;
                unesenJednako = false;
            }
        }

        private void zbrajanje(char inPressedDigit)
        {
            if (!postojiBroj)
            {
                postojiBroj = true;
                broj = double.Parse(this.display);
                isprazniSpremnik();
            }
            else if (!"+-*/".Contains(zadnjiUnesen)) 
            {
                if (unesenJednako == false)
                {
                    jednako();
                    broj = rezultat;
                    this.display = broj.ToString();
                    isprazniSpremnik();
                }
            }


            this.operacija = "+";    
            zadnjiUnesen = "+";

            if (unesenJednako == true)
            {             
                isprazniSpremnik();
                broj = rezultat;
                unesenJednako = false;
            }
        }

        private void zaokruziRezultat(double rez) 
        {
            string rezKaoString = rez.ToString();
            int zarez;
            int broj;
            double zaokruzenRez;

            if ((rez < -9999999999) || (rez > 9999999999))
            {
                this.display = "-E-";
                return;
            }

            else 
            {
                if (rezKaoString.Contains(","))
                {
                    zarez = rezKaoString.IndexOf(',');

                    if (rezKaoString.Contains("-"))
                    {
                        broj = 11;
                    }
                    else
                    {
                        broj = 10;
                    }

                    broj = broj - zarez;

                    zaokruzenRez = Math.Round(rez, broj);
                    this.display = zaokruzenRez.ToString();
                    rezultat = zaokruzenRez;
                }
                
            }

     

        }
        
        //metoda koja unosi novi broj u spremnik i ispisuje ju na ekran
        private void unesenBroj(char inPressedDigit){
            if (brZnamenaka <= 10)
            {
                brZnamenaka++;
                zadnjiUnesen = inPressedDigit.ToString();
                pomakZnamenki(this.spremnik);
                spremnik[11] = inPressedDigit;
                ispisiNaEkran();

            }
        }

        //nakon sto je unesena 0 gleda se postoji li vec nesto u spremniku, i ako
        //ne postoji onda se nista ne dogadja, inace se ispisuje 0 na ekran
        private void unesenaNula() 
        {
            if (brZnamenaka > 0)
            {
                zadnjiUnesen = "0";
                brZnamenaka++;
                pomakZnamenki(this.spremnik);
                spremnik[11] = '0';
                ispisiNaEkran();
            }
        }

        //metoda koja pomice znamenke u spremniku prema lijevo nakon sto se unese novi broj
        private void pomakZnamenki(char[] spremnik) 
        {
            if (!display.Contains(','))
            {
                for (int i = 2; i < 11; i++)
                {
                    spremnik[i] = spremnik[i + 1];
                }

            }  
            else if (display.Contains(','))
            {
                for (int i = 1; i < 11; i++)
                {
                    spremnik[i] = spremnik[i + 1];
                }
            }
           
        }

        //metoda koja ispisuje sve sto je u spremniku na ekran
        private void ispisiNaEkran()
        {
    
            string a = new string(this.spremnik);
            string novi = a.Replace("\0", "");

            if (novi.Contains(","))
            {
                decimal test = decimal.Parse(novi);
                test = test / 1.000000000000000000000000000000000m;
                novi = test.ToString();

            }
            this.display = novi;
        }

        //metoda koja prazni spremnik; svi elementi se postavljaju na \0
        private void isprazniSpremnik()
        {
            for (int i = 0; i < 12; i++)
            {
                this.spremnik[i] = '\0';
            }
            this.brZnamenaka = 0;
        }

        private void napuniSpremnik()
        {
            int duljinaZnakovaNaEkranu = this.display.Length;
            bool predznak = false;

            isprazniSpremnik();

            for (int i = duljinaZnakovaNaEkranu - 1, j = 11; i >= 0; i--, j--)
            {

                if (this.display[i] == '-')
                {
                    predznak = true;                 
                }
                else if ((this.display[i] == ',') || ((this.display[i] >= '0') && (this.display[i] <= '9'))) 
                {
                    spremnik[j] = this.display[i];
                }
                
            }

            if (predznak)
            {
                spremnik[0] = '-';
            }
        }

        #endregion


    }

    
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
}
