﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator{
        private readonly HashSet<string> _operations;
        private readonly HashSet<string> _unaryOperations;
        private readonly string ERROR_MESSAGE = "-E-";

        private StringBuilder ekran;
        private StringBuilder radnaMemorija;
        private StringBuilder internaMemorija;

        private string trenutnaOperacija;
        private bool binarnaOperacija;
        private string zadnjaBinarnaOperacija;

        private bool isSaved;
        private bool readyToCalculate;
        private bool isShortOperation;

        public Kalkulator(){
            _operations = new HashSet<string> { "+", "-", "*", "/", "=", "M", "S", "K", "T", "Q", "R", "I", "P", "G", "C", "O" };
            _unaryOperations = new HashSet<string> { "M", "S", "K", "T", "Q", "R", "I", "P", "G", "C", "O" };
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");

            this.ekran = new StringBuilder("0", 12);
            this.radnaMemorija = new StringBuilder("", 12);
            this.internaMemorija = new StringBuilder("", 12);
            this.trenutnaOperacija = "";
            this.zadnjaBinarnaOperacija = null;
            this.binarnaOperacija = false;
            this.isSaved = false;
            this.readyToCalculate = false;
            this.isShortOperation = false;
        }

        public void Press(char inPressedDigit){
            if ((ekran.ToString().Contains(",") && ekran.ToString().Contains("-") && ekran.ToString().Length < 12) ||
               (!ekran.ToString().Contains(",") && ekran.ToString().Contains("-") && ekran.ToString().Length < 11) ||
               (ekran.ToString().Contains(",") && !ekran.ToString().Contains("-") && ekran.ToString().Length < 11) ||
               (!ekran.ToString().Contains(",") && !ekran.ToString().Contains("-") && ekran.ToString().Length < 10)){ //Pokušava li se unijeti više znamenki nego što stane na ekran

                if (!_operations.Contains(inPressedDigit.ToString()) || (inPressedDigit.ToString().Equals(",") && !ekran.ToString().Contains(","))){ //Provjera radi li se o unosu broja
                    if (this.ekran.ToString().Equals("0") && !inPressedDigit.ToString().Equals(",")){ //Provjera je li ekran u početnom stanju
                        if (char.IsNumber(inPressedDigit) && !inPressedDigit.Equals('0')){
                            this.ekran.Length = 0;
                            ekran.Append(inPressedDigit.ToString());
                        }
                    }else{
                        if (isSaved){ // true ukoliko je prvi operand spremljen u radnoj memoriji, kreće unos sljedećeg operanda
                            readyToCalculate = true;
                            isSaved = false;
                            this.ekran.Length = 0;
                        }
                        ekran.Append(inPressedDigit.ToString());
                    }
                }else{
                    if (!_unaryOperations.Contains(inPressedDigit.ToString()) && readyToCalculate){ // Unešen je sljedeći binarni operator. Računanje prethodnog međurezultata
                        this.binarnaOperacija = true;
                        ObradaOperacije();
                        this.zadnjaBinarnaOperacija = inPressedDigit.ToString();
                    }else{
                        if (inPressedDigit.ToString().Equals("=") && !_unaryOperations.Contains(trenutnaOperacija) &&
                            _operations.Contains(trenutnaOperacija)){ //Traži li se izračun skraćene operacije
                            this.isShortOperation = true;
                        }
                        this.trenutnaOperacija = inPressedDigit.ToString();
                        ObradaOperacije();
                    }
                }
            }else if (_operations.Contains(inPressedDigit.ToString())){
                if (!_unaryOperations.Contains(inPressedDigit.ToString())){
                    this.binarnaOperacija = true;
                    if (!inPressedDigit.ToString().Equals("=")){
                        this.zadnjaBinarnaOperacija = inPressedDigit.ToString();
                    }
                }
                this.trenutnaOperacija = inPressedDigit.ToString();
                ObradaOperacije();
            }else{
                if (isSaved){
                    isSaved = false;
                    this.ekran.Length = 0;
                    ekran.Append(inPressedDigit.ToString());
                }
            }
        }

        public string GetCurrentDisplayState(){
            String diplayState = this.ekran.ToString();
            return diplayState;
        }

        private void ObradaOperacije(){
            if (binarnaOperacija && !ekran.ToString().Equals("0") && (this.radnaMemorija.ToString().Length > 0) &&
                (trenutnaOperacija.Equals("=") || readyToCalculate)){
                IzracunajBinarnuOperaciju();

                ProvjeriRezultatVelicina();
                this.binarnaOperacija = false;
                this.readyToCalculate = false;
                this.isSaved = true;
                this.radnaMemorija.Length = 0;
                this.radnaMemorija.Append(this.ekran.ToString());
                return;
            }

            char operacija = '|';
            if (!trenutnaOperacija.Equals("")){
                operacija = Char.Parse(trenutnaOperacija);
            }
            switch (operacija){
                case '=':
                    if (!binarnaOperacija){
                        ZaokruziBroj();
                    }

                    if (isShortOperation){
                        IzracunajSkracenuOperaciju();
                        isShortOperation = false;
                    }
                    break;
                case '+':
                    SpremiPrviOperand();
                    zadnjaBinarnaOperacija = "+";
                    break;
                case '-':
                    SpremiPrviOperand();
                    zadnjaBinarnaOperacija = "-";
                    break;
                case '*':
                    SpremiPrviOperand();
                    zadnjaBinarnaOperacija = "*";
                    break;
                case '/':
                    SpremiPrviOperand();
                    zadnjaBinarnaOperacija = "/";
                    break;
                case 'M':
                    PromjeniPredznak();
                    trenutnaOperacija = "";
                    break;
                case 'S':
                    Sinus();
                    trenutnaOperacija = "";
                    break;
                case 'K':
                    Kosinus();
                    trenutnaOperacija = "";
                    break;
                case 'T':
                    Tangens();
                    trenutnaOperacija = "";
                    break;
                case 'Q':
                    Kvadriraj();
                    trenutnaOperacija = "";
                    ProvjeriRezultatVelicina();
                    break;
                case 'R':
                    Korjenuj();
                    trenutnaOperacija = "";
                    break;
                case 'I':
                    Inverz();
                    trenutnaOperacija = "";
                    break;
                case 'P':
                    SpremiUMemoriju();
                    break;
                case 'G':
                    DohvatiIzMemorije();
                    break;
                case 'C':
                    BrisiEkran();
                    break;
                case 'O':
                    Reset();
                    break;
                default:
                    IspisiGresku();
                    break;
            }
        }

        #region Izračun operacija
        private void IzracunajBinarnuOperaciju(){
            double prviBroj = double.Parse(this.radnaMemorija.ToString());
            double drugiBroj = double.Parse(this.ekran.ToString());
            double rezultat = 0.0d;

            char operacija = Char.Parse(this.zadnjaBinarnaOperacija);
            switch (operacija){
                case '+':
                    rezultat = prviBroj + drugiBroj;
                    break;
                case '-':
                    rezultat = prviBroj - drugiBroj;
                    break;
                case '*':
                    rezultat = prviBroj * drugiBroj;
                    break;
                case '/':
                    rezultat = prviBroj / drugiBroj;
                    break;
                default:
                    IspisiGresku();
                    break;
            }

            this.internaMemorija.Length = 0;
            this.ekran.Length = 0;
            this.ekran.Append(rezultat.ToString());
        }

        private void IzracunajSkracenuOperaciju(){
            double broj = double.Parse(this.ekran.ToString());
            double rezultat = 0.0d;

            char operacija = Char.Parse(this.zadnjaBinarnaOperacija);
            switch (operacija){
                case '+':
                    rezultat = broj + broj;
                    break;
                case '-':
                    rezultat = broj - broj;
                    break;
                case '*':
                    rezultat = broj * broj;
                    break;
                case '/':
                    rezultat = broj / broj;
                    break;
                default:
                    break;
            }

            this.internaMemorija.Length = 0;
            this.ekran.Length = 0;
            this.ekran.Append(rezultat.ToString());
        }

        private void PromjeniPredznak(){
            double sadrzajEkrana = double.Parse(this.ekran.ToString());
            sadrzajEkrana = -sadrzajEkrana;
            this.ekran.Length = 0;
            this.ekran.Append(sadrzajEkrana.ToString());
        }

        private void Kvadriraj(){
            double sadrzajEkrana = double.Parse(this.ekran.ToString());
            sadrzajEkrana = Math.Pow(sadrzajEkrana, 2);
            this.ekran.Length = 0;
            this.ekran.Append(sadrzajEkrana.ToString());
        }

        private void Korjenuj(){
            double sadrzajEkrana = double.Parse(this.ekran.ToString());
            sadrzajEkrana = Math.Sqrt(sadrzajEkrana);
            this.ekran.Length = 0;
            this.ekran.Append(sadrzajEkrana.ToString());
        }

        private void Inverz(){
            if (this.ekran.ToString().Equals("0")){
                IspisiGresku();
                return;
            }

            double sadrzajEkrana = double.Parse(this.ekran.ToString());
            sadrzajEkrana = 1 / sadrzajEkrana;
            this.ekran.Length = 0;
            this.ekran.Append(sadrzajEkrana.ToString());
        }

        private void Sinus(){
            double broj = double.Parse(this.ekran.ToString());
            double rezultat = Math.Sin(broj);
            int brZnam = OdrediOblikDecBroja(rezultat);
            rezultat = Math.Round(rezultat, brZnam);
            this.ekran.Length = 0;
            this.ekran.Append(rezultat.ToString());
        }

        private void Kosinus(){
            double broj = double.Parse(this.ekran.ToString());
            double rezultat = Math.Cos(broj);
            int brZnam = OdrediOblikDecBroja(rezultat);
            rezultat = Math.Round(rezultat, brZnam);
            this.ekran.Length = 0;
            this.ekran.Append(rezultat.ToString());
        }

        private void Tangens(){
            double broj = double.Parse(this.ekran.ToString());
            double rezultat = Math.Tan(broj);
            int brZnam = OdrediOblikDecBroja(rezultat);
            rezultat = Math.Round(rezultat, brZnam);
            this.ekran.Length = 0;
            this.ekran.Append(rezultat.ToString());
        }

        private void SpremiUMemoriju(){
            this.internaMemorija.Length = 0;
            this.internaMemorija.Append(this.ekran.ToString());
        }

        private void DohvatiIzMemorije(){
            this.ekran.Length = 0;
            this.ekran.Append(this.internaMemorija.ToString());
        }
        #endregion

        #region Sistemske funkcije
        private void BrisiEkran(){
            this.ekran.Length = 0;
            this.ekran.Append("0");
        }

        private void IspisiGresku(){
            this.ekran.Length = 0;
            this.ekran.Append(ERROR_MESSAGE);
        }

        private void SpremiPrviOperand(){
            ZaokruziBroj();
            this.radnaMemorija.Length = 0;
            this.radnaMemorija.Append(this.ekran.ToString());
            this.isSaved = true;
        }

        private void Reset(){
            this.ekran.Length = 0;
            this.ekran.Append("0");
            this.radnaMemorija.Length = 0;
            this.internaMemorija.Length = 0;
        }
        #endregion

        #region Zaokruživanje, provjera oblika rezultata
        private int OdrediOblikDecBroja(double broj){
            String[] rezultat = broj.ToString().Split(',');
            int brZnam = rezultat[0].Length;
            if (rezultat[0].Contains("-")){
                brZnam--;
            }
            return 10 - brZnam;
        }

        private void ZaokruziBroj(){
            double broj = double.Parse(this.ekran.ToString());
            int rez = (int)Math.Round(broj);

            if (Math.Abs(broj - rez) == 0){
                this.ekran.Length = 0;
                this.ekran.Append(broj.ToString());
            }
        }

        private void ProvjeriRezultatVelicina(){
            double broj = double.Parse(this.ekran.ToString());
            int brZnam = OdrediOblikDecBroja(broj);
            if (brZnam < 0){
                IspisiGresku();
                return;
            }

            broj = Math.Round(broj, brZnam);
            this.ekran.Length = 0;
            this.ekran.Append(broj.ToString());

            if (this.ekran.ToString().Length > 12){
                IspisiGresku();
            }
        }
        #endregion
    }
}
