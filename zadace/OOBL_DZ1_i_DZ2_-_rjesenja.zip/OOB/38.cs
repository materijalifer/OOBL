﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string naEkranu;
        private string memorija;
        private double medurezultat;
        private string operacija;
        private bool brisiEkran;
        private bool uzastopniBinarniOp;

        public Kalkulator()
        {
            naEkranu = "0";
            operacija = "";
            memorija = "0";
            medurezultat = 0;
            brisiEkran = false;
            uzastopniBinarniOp = false;
        }


        public void Press(char inPressedDigit)
        {
            //ako sljedeći znak nije +, -, * ili / onda postavimo uzastopniBinarniOp na false
            //to znaci da nema uzastopnih operatora
            if (inPressedDigit != '+' && inPressedDigit != '-' && inPressedDigit != '*' && inPressedDigit != '/')
            {
                uzastopniBinarniOp = false;
            }

            switch (inPressedDigit)
            {
                case '+':
                case '-':
                case '*':
                case '/':
                    binarnaOp(inPressedDigit);
                    break;
                case '=':
                    obaviPrethodnuOperaciju();
                    operacija = "";
                    medurezultat = 0;
                    uzastopniBinarniOp = false;
                    naEkranu = provjeri(naEkranu);
                    break;
                case 'M':
                    naEkranu = provjeri((Convert.ToDouble(naEkranu) * (-1)).ToString("0.#########"));
                    break;
                case 'S':
                    naEkranu = provjeri(Math.Sin(Convert.ToDouble(naEkranu)).ToString("0.#########"));
                    break;
                case 'K':
                    naEkranu = provjeri(Math.Cos(Convert.ToDouble(naEkranu)).ToString("0.#########"));
                    break;
                case 'T':
                    naEkranu = provjeri(Math.Tan(Convert.ToDouble(naEkranu)).ToString("0.#########"));
                    break;
                case 'Q':
                    naEkranu = provjeri(Math.Pow(Convert.ToDouble(naEkranu), 2).ToString("0.#########"));
                    break;
                case 'R':
                    if (Convert.ToDouble(naEkranu) > 0)
                        naEkranu = provjeri(Math.Sqrt(Convert.ToDouble(naEkranu)).ToString("0.#########"));
                    else
                        naEkranu = "-E-";
                    break;
                case 'I':
                    if (naEkranu != "0")
                        naEkranu = provjeri((1 / Convert.ToDouble(naEkranu)).ToString("0.#########"));
                    else
                        naEkranu = "-E-";
                    break;
                case 'P':
                    memorija = naEkranu;
                    break;
                case 'G':
                    naEkranu = memorija;
                    break;
                case 'C':
                    naEkranu = "0";
                    //medurezultat = 0;
                    break;
                case 'O':
                    naEkranu = "0";
                    medurezultat = 0;
                    memorija = "0";
                    break;
                default:

                    //ono sto je na ekranu treba pobrisati ako je prije znamenke dosla operacija
                    //tako da se novi broj nebi prikeljio na stari!!!
                    if (brisiEkran)
                        naEkranu = "0";

                    if ((Char.IsDigit(inPressedDigit) || inPressedDigit == ','))
                    {
                        brisiEkran = false;

                        if (naEkranu == "0" || naEkranu == "-E-" || uzastopniBinarniOp)
                        {
                            naEkranu = (inPressedDigit == ',') ? "0" + inPressedDigit.ToString() : inPressedDigit.ToString();
                        }
                        else
                        {
                            int br = 0, br2 = 0;
                            char[] splitStr = naEkranu.ToCharArray();

                            foreach (char c in splitStr)
                            {
                                if (Char.IsDigit(c))
                                {
                                    br += 1;
                                }
                                else if (c == ',')
                                {
                                    br2 += 1;
                                }
                            }

                            if ((Char.IsDigit(inPressedDigit) && br < 10) || (inPressedDigit == ',' && br2 < 1))
                            {
                                naEkranu += inPressedDigit;
                            }
                        }
                    }
                    else if (naEkranu == "0" && inPressedDigit == '-')
                    {
                        naEkranu = inPressedDigit.ToString();
                    }
                    else if (naEkranu == "-" && inPressedDigit == '-')
                    {
                        return;
                    }
                    break;
            }
        }

        private void binarnaOp(char inPressedDigit)
        {
            obaviPrethodnuOperaciju();
            operacija = inPressedDigit.ToString();
            uzastopniBinarniOp = true;
        }

        private void obaviPrethodnuOperaciju()
        {
            //ova funkcija se poziva kaka dodje nova operacija, a to je znak da se ekran treba pobrisati sljedeci
            //put kada se pozove press funkcija!!
            brisiEkran = true;

            if (operacija == "")
            {
                if (naEkranu[naEkranu.Length - 1] == ',')
                {
                    naEkranu = naEkranu.Split(',')[0];
                }
                medurezultat = Convert.ToDouble(naEkranu);
            }
            else if (!uzastopniBinarniOp)
            {
                //ako dode operacija, a prije toga je bio zarez, onda treba ukloniti zarez
                if (naEkranu[naEkranu.Length - 1] == ',')
                {
                    naEkranu = naEkranu.Split(',')[0];
                }

                switch (operacija)
                {
                    case "+":
                        medurezultat += Convert.ToDouble(naEkranu);
                        naEkranu = provjeri(medurezultat.ToString("0.#########"));
                        break;
                    case "-":
                        medurezultat -= Convert.ToDouble(naEkranu);
                        naEkranu = provjeri(medurezultat.ToString("0.#########"));
                        break;
                    case "*":
                        medurezultat *= Convert.ToDouble(naEkranu);
                        naEkranu = provjeri(medurezultat.ToString("0.#########"));
                        break;
                    case "/":
                        if (naEkranu == "0")
                        {
                            naEkranu = "-E-";
                        }
                        else
                        {
                            medurezultat /= Convert.ToDouble(naEkranu);
                            naEkranu = provjeri(medurezultat.ToString("0.#########"));
                        }
                        break;
                }
            }
        }

        private string provjeri(string s)
        {
            if (naEkranu == "-E-")
            {
                return naEkranu;
            }

            int brPrije = 0, brZarez = 0, brPoslije = 0;
            bool prije = true;

            char[] splitStr = s.ToCharArray();

            foreach (char c in splitStr)
            {
                if (Char.IsDigit(c) && prije)
                {                    //broj znamenki prije dec. tocke
                    brPrije += 1;
                }
                else if (Char.IsDigit(c) && !prije)
                {                   //broj znamenki nakon dec. tocke
                    brPoslije += 1;
                }
                else if (c == ',')
                {                   //broj zareza (moze biti 0 ili 1)
                    brZarez += 1;
                    prije = false;
                }
            }

            //  1. ako je cijelobrojni dio (bio cijeli ili dec broj) veci od 10 znamenki -> error
            //  2. ako je decimalni broj sa vise od 10 znamenki -> zaokruzi broj
            //  3. inače vrati dobiveni string

            if (brPrije > 10)
            {
                return "-E-";
            }
            else if (brZarez == 1 && (brPrije + brPoslije) > 10)
            {
                return Math.Round(Convert.ToDouble(s), 10 - brPrije).ToString();
            }
            else
                return Convert.ToDouble(s).ToString();
        }

        public string GetCurrentDisplayState()
        {
            return naEkranu.ToString().Replace('.', ',');
        }
    }
}
