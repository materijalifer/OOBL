﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class StockExchange : IStockExchange
    {
        public StockExchange()
        {
            StockRepository.getInstance().reset();
            IndexRepository.getInstance().reset();
            PortfolioRepository.getInstance().reset();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName) || inNumberOfShares <= 0 || inInitialPrice <= 0)
            {
                throw new StockExchangeException("Stock data not valid.");
            }

            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            StockRepository.getInstance().addStock(stock);
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            //remove stock from all indexes
            foreach (Index ind in IndexRepository.getInstance().getAll())
            {
                foreach (Stock s in ind.getStocks())
                {
                    if (stock.StockName.Equals(s.StockName))
                    {
                        ind.removeStock(s);
                        break;
                    }
                }
            }
            //remove stock from all portfolios
            foreach (Portfolio p in PortfolioRepository.getInstance().getAll())
            {
                foreach (Stock s in p.Stocks.Keys)
                {
                    if (stock.StockName.Equals(s.StockName))
                    {
                        p.removeStockEntirely(stock);
                        break;
                    }
                }
            }
            StockRepository.getInstance().deleteStock(stock);
        }

        public bool StockExists(string inStockName)
        {
            return StockRepository.getInstance().exists(inStockName);
        }

        public int NumberOfStocks()
        {
            return StockRepository.getInstance().count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            StockRepository.getInstance().getStock(inStockName).addStockPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return StockRepository.getInstance().getStock(inStockName).getStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return StockRepository.getInstance().getStock(inStockName).getInitialStockPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return StockRepository.getInstance().getStock(inStockName).getLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index already exists.");
            }
            else if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Index type error.");
            }

            Index index = new Index(inIndexName, inIndexType);
            IndexRepository.getInstance().addIndex(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IsStockPartOfIndex(inIndexName, inStockName))
            {
                throw new StockExchangeException("Index already contains given stock.");
            }
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            Index index = IndexRepository.getInstance().getIndex(inIndexName);
            index.addStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IsStockPartOfIndex(inIndexName, inStockName))
            {
                throw new StockExchangeException("Index doesn't contain given stock.");
            }
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            Index index = IndexRepository.getInstance().getIndex(inIndexName);
            index.removeStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = IndexRepository.getInstance().getIndex(inIndexName);
            return index.hasStock(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = IndexRepository.getInstance().getIndex(inIndexName);
            return index.getValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return IndexRepository.getInstance().exists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return IndexRepository.getInstance().count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = IndexRepository.getInstance().getIndex(inIndexName);
            return index.getNumOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio with given name already exists.");
            }
            Portfolio portfolio = new Portfolio(inPortfolioID);
            PortfolioRepository.getInstance().addPortfolio(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be greater than 0.");
            }

            decimal sum = 0;
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            foreach (Portfolio p in PortfolioRepository.getInstance().getAll())
            {
                if (p.hasStock(inStockName))
                {
                    sum += p.getNumOfShares(stock);
                }
            }

            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            if (numberOfShares > stock.NumberOfShares || (sum + numberOfShares) > stock.NumberOfShares)
            {
                //throw new StockExchangeException("Number of shares must be greater than 0.");
                portfolio.addStock(stock, (int)(stock.NumberOfShares - sum));
                return;
            }

            portfolio.addStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Portfolio doesn't contain given stock.");
            }
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            portfolio.removeStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Portfolio doesn't contain given stock.");
            }
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            portfolio.removeStockEntirely(stock);
        }

        public int NumberOfPortfolios()
        {
            return PortfolioRepository.getInstance().count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            return portfolio.getNumOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return PortfolioRepository.getInstance().exists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            return portfolio.hasStock(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            Stock stock = StockRepository.getInstance().getStock(inStockName);
            return portfolio.getNumOfShares(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            return portfolio.getValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = PortfolioRepository.getInstance().getPortfolio(inPortfolioID);
            DateTime dt;
            if (!DateTime.TryParse(string.Format("{0}-{1}", Year, Month), out dt))
            {
                throw new StockExchangeException("Month or Year input not valid.");
            }
            return portfolio.getPercentChange(Year, Month);
        }
    }

    public class Stock
    {

        private string stockName;
        private long numberOfShares;
        private Dictionary<DateTime, decimal> values = new Dictionary<DateTime, decimal>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.stockName = inStockName;
            this.numberOfShares = inNumberOfShares;
            if (values.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Datetime already exists.");
            }
            values.Add(inTimeStamp, inInitialPrice);
        }

        public void addStockPrice(DateTime timeStamp, decimal price)
        {
            if (values.ContainsKey(timeStamp))
            {
                throw new StockExchangeException("Datetime already exists.");
            }
            values.Add(timeStamp, price);
        }

        public decimal getStockPrice(DateTime timeStamp)
        {
            decimal result = 0;
            List<DateTime> olderDates = new List<DateTime>();
            foreach (KeyValuePair<DateTime, decimal> kvp in values)
            {
                DateTime currDate = kvp.Key;
                if (currDate <= timeStamp)
                {
                    olderDates.Add(currDate);
                    if (currDate == olderDates.Max())
                    {
                        result = kvp.Value;
                    }
                }
            }
            if (olderDates.Count == 0)
            {
                throw new StockExchangeException("Stock price not defined for the given timestamp.");
            }
            return result;
        }

        public decimal getInitialStockPrice()
        {
            return values[values.Keys.Min()];
        }

        public decimal getLastStockPrice()
        {
            return values[values.Keys.Max()];
        }

        public string StockName
        {
            get { return stockName; }
            set { stockName = value; }
        }


        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }


    }

    public class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private List<Stock> stocks = new List<Stock>();

        public Index(string indexName, IndexTypes indexType)
        {
            this.indexName = indexName;
            this.indexType = indexType;
        }

        public decimal getValue(DateTime timeStamp)
        {
            decimal result = 0;
            switch (indexType)
            {
                case (IndexTypes.AVERAGE):
                    result = computeAverageValue(timeStamp);
                    break;
                case (IndexTypes.WEIGHTED):
                    result = computeWeightedValue(timeStamp);
                    break;
                default:
                    break;
            }
            return result;
        }

        private decimal computeAverageValue(DateTime timeStamp)
        {
            decimal result = 0;
            decimal sumPrice = stocks.Sum(x => x.getStockPrice(timeStamp));
            if (getNumOfStocks() > 0)
            {
                result = sumPrice / getNumOfStocks();
            }
            return Math.Round(result, 3);
        }

        private decimal computeWeightedValue(DateTime timeStamp)
        {
            decimal result = 0;
            decimal sumStocks = 0;
            foreach (Stock s in stocks)
            {
                sumStocks += s.NumberOfShares * s.getStockPrice(timeStamp);
            }

            foreach (Stock s in stocks)
            {
                decimal currPrice = s.getStockPrice(timeStamp);
                result += s.NumberOfShares * currPrice * (currPrice / sumStocks);
            }

            return Math.Round(result, 3);
        }

        public List<Stock> getStocks()
        {
            return stocks;
        }

        public int getNumOfStocks()
        {
            return stocks.Count;
        }

        public void addStock(Stock stock)
        {
            stocks.Add(stock);
        }

        public void removeStock(Stock stock)
        {
            stocks.Remove(stock);
        }

        public bool hasStock(string stockName)
        {
            return stocks.SingleOrDefault(x => x.StockName.Equals(stockName.ToLower())) != null;
        }

        public IndexTypes IndexType
        {
            get { return indexType; }
            set { indexType = value; }
        }

        public string IndexName
        {
            get { return indexName; }
            set { indexName = value; }
        }
    }
    public class Portfolio
    {
        string portfolioName;

        Dictionary<Stock, int> stocks = new Dictionary<Stock, int>();

        public Dictionary<Stock, int> Stocks
        {
            get { return stocks; }
            set { stocks = value; }
        }

        public Portfolio(string portfolioName)
        {
            this.portfolioName = portfolioName;
        }

        public decimal getValue(DateTime timeStamp)
        {
            decimal result = 0;
            foreach (Stock s in stocks.Keys)
            {
                result += stocks[s] * s.getStockPrice(timeStamp);
            }
            return Math.Round(result,3);
        }

        public decimal getPercentChange(int year, int month)
        {
            decimal priceFirstDay = getValue(new DateTime(year, month, 1, 00, 00, 00));
            decimal priceLastDay = getValue(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
            if (priceFirstDay == 0)
            {
                return priceLastDay * 100;
            }
            decimal result = ((priceLastDay - priceFirstDay) / priceFirstDay) * 100;
            return Math.Round(result,3);
        }

        public int getNumOfStocks()
        {
            return stocks.Count;
        }
        public void addStock(Stock stock, int numOfShares)
        {
            if (hasStock(stock.StockName))
            {
                stocks[stock] += numOfShares;
            }
            else
            {
                stocks.Add(stock, numOfShares);
            }
        }

        public void removeStock(Stock stock, int numOfShares)
        {
            if (stocks[stock] > numOfShares)
            {
                stocks[stock] -= numOfShares;
            }
            else
            {
                removeStockEntirely(stock);
            }
        }

        public void removeStockEntirely(Stock stock)
        {
            stocks.Remove(stock);
        }

        public bool hasStock(string stockName)
        {
            return stocks.Keys.SingleOrDefault(x => x.StockName.Equals(stockName.ToLower())) != null;
        }

        public int getNumOfShares(Stock stock)
        {
            if (hasStock(stock.StockName))
            {
                return stocks[stock];
            }
            else
            {
                return 0;
                //throw new StockExchangeException("No stock with given name.");
            }
        }

        public string PortfolioName
        {
            get { return portfolioName; }
            set { portfolioName = value; }
        }
    }

    public class StockRepository
    {
        private static StockRepository instance = null;
        private List<Stock> stockList = new List<Stock>();

        private StockRepository() { }

        public static StockRepository getInstance()
        {
            if (instance == null)
            {
                instance = new StockRepository();
            }

            return instance;
        }

        public int count()
        {
            return stockList.Count;
        }

        public bool exists(string name)
        {
            return stockList.SingleOrDefault(x => x.StockName.Equals(name.ToLower())) != null;
        }
 

        public Stock getStock(string name)
        {
            if (exists(name))
            {
                return stockList.First(x => x.StockName.Equals(name.ToLower()));
            }
            else
            {
                throw new StockExchangeException("No stock found with the given name.");
            }

        }

        public List<Stock> getAll()
        {
            return stockList;
        }

        public void addStock(Stock stock)
        {
            if (exists(stock.StockName))
            {
                throw new StockExchangeException("Stock already exists.");
            }
            else
            {
                stock.StockName = stock.StockName.ToLower();
                stockList.Add(stock);
            }
        }
        
        public void deleteStock(Stock stock)
        {
            stockList.Remove(stock);
        }

        public void reset()
        {
            stockList = new List<Stock>();
        }
    }

    public class IndexRepository
    {
        private static IndexRepository instance = null;
        private List<Index> indexList = new List<Index>();

        private IndexRepository() { }

        public static IndexRepository getInstance()
        {
            if (instance == null)
            {
                instance = new IndexRepository();
            }
            return instance;
        }

        public int count()
        {
            return indexList.Count;
        }

        public bool exists(string name)
        {
            return indexList.SingleOrDefault(x => x.IndexName.Equals(name.ToLower())) != null;
        }

        public Index getIndex(string name)
        {
            if (exists(name))
            {
                return indexList.First(x => x.IndexName.Equals(name.ToLower()));
            }
            else
            {
                throw new StockExchangeException("No stock found with the given name.");
            }
        }

        public List<Index> getAll()
        {
            return indexList;
        }

        public void addIndex(Index index)
        {
            index.IndexName = index.IndexName.ToLower();
            indexList.Add(index);
        }

        public void reset()
        {
            indexList = new List<Index>();
        }

    }

    public class PortfolioRepository
    {
        private static PortfolioRepository instance = null;
        private List<Portfolio> portfolioList = new List<Portfolio>();

        private PortfolioRepository() { }

        public static PortfolioRepository getInstance()
        {
            if (instance == null)
            {
                instance = new PortfolioRepository();
            }
            return instance;
        }

        public int count()
        {
            return portfolioList.Count;
        }

        public bool exists(string name)
        {
            return portfolioList.SingleOrDefault(x => x.PortfolioName.Equals(name)) != null;
        }

        public Portfolio getPortfolio(string name)
        {
            if (exists(name))
            {
                return portfolioList.First(x => x.PortfolioName.Equals(name));
            }
            else
            {
                throw new StockExchangeException("No portfolio found with the given name.");
            }
        }

        public List<Portfolio> getAll()
        {
            return portfolioList;
        }

        public void addPortfolio(Portfolio portfolio)
        {
            portfolioList.Add(portfolio);
        }

        public void reset()
        {
            portfolioList = new List<Portfolio>();
        }
    }

}
