﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Coolculator();
        }
    }

    public class Coolculator : ICalculator
    {
        protected static Dictionary<char, ICalculatorAction> actionMap = new Dictionary<char, ICalculatorAction> {
            {'0', new DigitInput('0')},
            {'1', new DigitInput('1')},
            {'2', new DigitInput('2')},
            {'3', new DigitInput('3')},
            {'4', new DigitInput('4')},
            {'5', new DigitInput('5')},
            {'6', new DigitInput('6')},
            {'7', new DigitInput('7')},
            {'8', new DigitInput('8')},
            {'9', new DigitInput('9')},
            {',', new DecimalPointInput()},
            {'M', new MinusToggle()},
            {'+', new OperationAdd()},
            {'-', new OperationSubtract()},
            {'*', new OperationMultiply()},
            {'/', new OperationDivide()},
            {'=', new ActionEquals()},
            {'S', new OperationSine()},
            {'K', new OperationCosine()},
            {'T', new OperationTangent()},
            {'Q', new OperationSquare()},
            {'R', new OperationSqRoot()},
            {'I', new OperationInvert()},
            {'P', new ActionSaveMemory()},
            {'G', new ActionFetchMemory()},
            {'C', new ActionClear()},
            {'O', new ActionReset()}
        };

        protected CalculatorState state = new CalculatorState();

        public void Press(char inPressedDigit)
        {
            try
            {
                ICalculatorAction action = (ICalculatorAction)actionMap[inPressedDigit].Clone();
                action.execute(state);
                System.Diagnostics.Debug.WriteLine(GetCurrentDisplayState());
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
                state.error = true;
            }
        }

        public string GetCurrentDisplayState()
        {
            return (state.error? "-E-" : state.screenContents.ToString());
        }

        protected class RoundedNumber : ICloneable
        {
            public static int maxDigits = 10;

            private string integralPart;
            private string fractionalPart;
            private bool decimalPoint;
            public bool sign {get; private set;}

            public RoundedNumber()
            {
                this.integralPart = "0";
                this.fractionalPart = "";
                this.decimalPoint = false;
                this.sign = false;
            }
            public RoundedNumber(double number) : this()
            {
                if (Double.IsInfinity(number) || Double.IsNaN(number))
                {
                    throw new ArgumentOutOfRangeException("Number is infinity or NaN!");
                }
                if (number > Math.Pow(10.0, maxDigits + 2))
                {
                    throw new ArgumentOutOfRangeException("Number much too large for maxDigits!");
                }
                for (int currentRound = maxDigits; currentRound >= 0; --currentRound)
                {
                    string numString = number.ToString("0" + ((currentRound > 0)? "." + new String('#', currentRound) : "") + "");
                    if (numString[0] == '-')
                    {
                        sign = true;
                        numString = numString.Substring(1);
                    }
                    else
                    {
                        sign = false;
                    }
                    string[] splitNum = (numString + ".").Split(new char[] { '.', ',' });
                    integralPart = splitNum[0];
                    fractionalPart = splitNum[1];
                    decimalPoint = (fractionalPart.Length > 0);

                    if (numDigits() <= maxDigits) break;
                }
                if (numDigits() > maxDigits)
                {
                    throw new ArgumentOutOfRangeException("Number too large for maxDigits!");
                }
            }

            public override string ToString()
            {
 	            return (sign? "-" : "") + integralPart + (decimalPoint? "," + fractionalPart : "");
            }
            public double ToDouble()
            {
                return Double.Parse(ToString().Replace(',', '.'), CultureInfo.InvariantCulture);
            }
            public int numDigits()
            {
                return integralPart.Length + fractionalPart.Length;
            }

            public void setSign(bool newSign)
            {
                sign = newSign;
            }
            public void addDecimalPoint()
            {
                decimalPoint = true;
            }
            public void addDigit(char digit)
            {
                if (numDigits() < maxDigits)
                {
                    if (decimalPoint)
                    {
                        fractionalPart = fractionalPart + digit;
                    }
                    else
                    {
                        integralPart = integralPart + digit;
                    }
                }
            }
            public void trimLeadingZeros()
            {
                integralPart = integralPart.TrimStart('0');
                if (integralPart.Length == 0)
                {
                    integralPart = "0";
                }
            }
            public void trimTrailingZeros()
            {
                fractionalPart = fractionalPart.TrimEnd('0');
                if (fractionalPart.Length == 0)
                {
                    decimalPoint = false;
                }
            }

            public virtual Object Clone()
            {
                return MemberwiseClone();
            }
        }

        protected class CalculatorState
        {
            public bool error = false;
            public bool inputContinue = false;
            public bool inputSinceBinary = true;
            public RoundedNumber screenContents = new RoundedNumber();
            public RoundedNumber memory = new RoundedNumber();
            public BinaryOperation pendingOperation = null;

            public void clear()
            {
                if (error)
                {
                    pendingOperation = null;
                }
                error = false;
                inputContinue = false;
                inputSinceBinary = true;
                screenContents = new RoundedNumber();
            }
            public void reset()
            {
                clear();
                memory = new RoundedNumber();
                pendingOperation = null;
            }
        }

        protected interface ICalculatorAction : ICloneable
        {
            void execute(CalculatorState calcState);
        }

        protected abstract class MasterControlCalculatorAction : ICalculatorAction
        {
            public abstract void execute(CalculatorState calcState);

            public virtual Object Clone()
            {
                return (MasterControlCalculatorAction)MemberwiseClone();
            }
        }
        protected class ActionClear : MasterControlCalculatorAction
        {
            public override void execute(CalculatorState calcState)
            {
                calcState.clear();
            }
        }
        protected class ActionReset : MasterControlCalculatorAction
        {
            public override void execute(CalculatorState calcState)
            {
                calcState.reset();
            }
        }

        protected abstract class ErrorCheckedCalculatorAction : ICalculatorAction
        {
            protected abstract void protectedExecute(CalculatorState calcState);

            public void execute(CalculatorState calcState)
            {
                if (!calcState.error)
                {
                    protectedExecute(calcState);
                }
            }

            public virtual Object Clone()
            {
                return MemberwiseClone();
            }
        }

        protected class ActionSaveMemory : ErrorCheckedCalculatorAction
        {
            protected override void protectedExecute(CalculatorState calcState)
            {
                calcState.memory = (RoundedNumber)calcState.screenContents.Clone();
                calcState.memory.trimTrailingZeros();
            }
        }
        protected class ActionFetchMemory : ErrorCheckedCalculatorAction
        {
            protected override void protectedExecute(CalculatorState calcState)
            {
                calcState.screenContents = (RoundedNumber)calcState.memory.Clone();
                calcState.inputContinue = false;
                calcState.inputSinceBinary = true;
            }
        }

        protected class MinusToggle : ErrorCheckedCalculatorAction
        {
            protected override void protectedExecute(CalculatorState calcState)
            {
                if (calcState.inputContinue)
                {
                    calcState.screenContents.setSign(!calcState.screenContents.sign);
                }
            }
        }

        protected abstract class NumberInput : ErrorCheckedCalculatorAction
        {
            protected abstract void addSymbol(CalculatorState calcState);

            protected override void protectedExecute(CalculatorState calcState)
            {
                if (!calcState.inputContinue)
                {
                    calcState.clear();
                }
                addSymbol(calcState);
                calcState.screenContents.trimLeadingZeros();
                calcState.inputContinue = true;
                calcState.inputSinceBinary = true;
            }
        }
        protected class DecimalPointInput : NumberInput
        {
            protected override void addSymbol(CalculatorState calcState)
            {
                calcState.screenContents.addDecimalPoint();
            }
        }
        protected class DigitInput : NumberInput
        {
            private char digit;

            public DigitInput(char digit)
            {
                this.digit = digit;
            }

            protected override void addSymbol(CalculatorState calcState)
            {
                calcState.screenContents.addDigit(digit);
            }
        }

        protected abstract class UnaryOperation : ErrorCheckedCalculatorAction
        {
            public abstract double calculate(double arg);

            protected override void protectedExecute(CalculatorState calcState)
            {
                calcState.screenContents = new RoundedNumber(calculate(calcState.screenContents.ToDouble()));
                calcState.inputContinue = false;
                calcState.inputSinceBinary = true;
            }
        }
        protected class OperationSine : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return Math.Sin(arg);
            }
        }
        protected class OperationCosine : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return Math.Cos(arg);
            }
        }
        protected class OperationTangent : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return Math.Tan(arg);
            }
        }
        protected class OperationSquare : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return arg * arg;
            }
        }
        protected class OperationSqRoot : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return Math.Sqrt(arg);
            }
        }
        protected class OperationInvert : UnaryOperation
        {
            public override double calculate(double arg)
            {
                return 1.0 / arg;
            }
        }

        protected abstract class BinaryOperation : ErrorCheckedCalculatorAction
        {
            private RoundedNumber leftOperand = new RoundedNumber();

            public abstract double calculate(double argLeft, double argRight);

            public double calculateWithRight(double rightArg)
            {
                return calculate(leftOperand.ToDouble(), rightArg);
            }

            protected override void protectedExecute(CalculatorState calcState)
            {
                if (calcState.inputSinceBinary && (calcState.pendingOperation != null))
                {
                    calcState.screenContents = new RoundedNumber(
                        calcState.pendingOperation.calculateWithRight(calcState.screenContents.ToDouble())
                    );
                }
                else
                {
                    calcState.screenContents.trimTrailingZeros();
                }
                leftOperand = (RoundedNumber)calcState.screenContents.Clone();
                calcState.pendingOperation = this;
                calcState.inputContinue = false;
                calcState.inputSinceBinary = false;
            }

            public override Object Clone()
            {
                BinaryOperation clone = (BinaryOperation)MemberwiseClone();
                clone.leftOperand = (RoundedNumber)leftOperand.Clone();
                return clone;
            }
        }
        protected class OperationAdd : BinaryOperation
        {
            public override double calculate(double argLeft, double argRight)
            {
                return argLeft + argRight;
            }
        }
        protected class OperationSubtract : BinaryOperation
        {
            public override double calculate(double argLeft, double argRight)
            {
                return argLeft - argRight;
            }
        }
        protected class OperationMultiply : BinaryOperation
        {
            public override double calculate(double argLeft, double argRight)
            {
                return argLeft * argRight;
            }
        }
        protected class OperationDivide : BinaryOperation
        {
            public override double calculate(double argLeft, double argRight)
            {
                return argLeft / argRight;
            }
        }

        protected class ActionEquals : ErrorCheckedCalculatorAction
        {
            protected override void protectedExecute(CalculatorState calcState)
            {
                if (calcState.pendingOperation != null)
                {
                    calcState.screenContents = new RoundedNumber(
                        calcState.pendingOperation.calculateWithRight(calcState.screenContents.ToDouble())
                    );
                }
                else
                {
                    calcState.screenContents.trimTrailingZeros();
                }
                calcState.pendingOperation = null;
                calcState.inputContinue = false;
                calcState.inputSinceBinary = true;
            }
        }

    }

}
