﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string prviBroj;
        private string drugiBroj;
        private string treciBroj;
        private char operacija;
        private char operacijaProsla;
        private string zamjena;
        private bool prvi = false;
        private bool drugi = false;
        private bool drugiProl = false;
        private bool nula = true;
        private bool m = true;
        private Izracun izracun = new Izracun();
        private UpravljanjeMemorijom memorija = new UpravljanjeMemorijom();
        private OperacijaM opM = new OperacijaM();
        private PrikazBroja prikaziBroj = new PrikazBroja();
        private Broj unosBroja = new Broj();


        public string GetCurrentDisplayState()
        {
            string vracam = "";
            if (nula)
                return "0";
            if (drugi)
            {
                if (drugiBroj != "0")
                    vracam = prikaziBroj.prikazi(drugiBroj);
            }
            else if (prviBroj == "")
            {
                if (treciBroj != "0")
                    vracam = prikaziBroj.prikazi(treciBroj);
                else vracam = "0";
            }
            else if (Convert.ToDouble(prviBroj) != 0)
            {
                vracam = prikaziBroj.prikazi(prviBroj);
            }
            else vracam = "0";

            return vracam;
        }

        private class PrikazBroja
        {
            public string prikazi(string broj)
            {
                broj = broj.TrimStart('0');
                if (broj.Contains(','))
                    broj = broj.TrimEnd('0').TrimEnd(',');
                if (broj.Length > 0)
                {
                    if (broj[0] == ',')
                        broj = '0' + broj;
                }
                return broj;
            }
        }

        private class Broj
        {
            private odreziBroj skratiBroj = new odreziBroj();
            private class odreziBroj
            {
                public string odrezi(string broj)
                {
                    bool t = false;
                    int br = 0;
                    foreach (char c in broj)
                    {
                        if (c == ',')
                            t = true;
                        if (c == '-')
                            br = 1;
                    }
                    if (t)
                    {
                        if (broj.Length > 11 + br)
                        {
                            broj = broj.Remove(11 + br);
                        }
                    }
                    else
                        broj = broj.Remove(10 + br);

                    return broj;
                }

            }

            public string unos(string nesto, char znak)
            {
                nesto = nesto + znak;
                if (nesto[0] == ',')
                    nesto = "0" + nesto;
                if (nesto.Length > 10)
                {
                    nesto = skratiBroj.odrezi(nesto);
                }
                return nesto;
            }
        }


        public void Press(char broj)
        {
            nula = false;
            drugi = false;

            if ((broj >= '0' && broj <= '9') || broj == ',')
            {
                prvi = true;
                prviBroj = unosBroja.unos(prviBroj, broj);
            }
            else
            {

                drugi = true;
                if (!drugiProl)
                {
                    drugiBroj = prviBroj;
                    if(broj!='M')
                        prviBroj = "";
                }
                else
                {
                    if (treciBroj == "" || treciBroj == null)
                        treciBroj = prviBroj;
                }
                operacija = broj;

                if (broj == 'S' || broj == 'K' || broj == 'T' || broj == 'Q' || broj == 'I' || broj == 'R')
                {

                    prviBroj = "";
                    zamjena = "";

                    if (operacijaProsla == '+' || operacijaProsla == '-' || operacijaProsla == '*' || operacijaProsla == '/')
                    {
                        operacija = operacijaProsla;
                        zamjena = drugiBroj;
                        drugiBroj = treciBroj;
                    }

                    operacijaProsla = broj;

                    if (operacijaProsla == 'I')
                    {
                        if (drugiBroj == "")
                            drugiBroj = zamjena;
                    }
                    if (drugiBroj == "")
                        drugiBroj = treciBroj;
                    drugiBroj = izracun.izracunaj(operacijaProsla, drugiBroj);
                    treciBroj = "";
                    treciBroj = drugiBroj;

                    if (drugiBroj != "-E-")
                    {
                        drugiBroj = zamjena;
                        drugi = false;
                    }
                    else
                    {
                        drugi = true;
                    }
                    operacijaProsla = operacija;
                }
                else if (broj == 'M')
                {
                    prviBroj = opM.predznak(prviBroj);
                    drugi = false;
                    if (!drugiProl)
                        m = false;
                    treciBroj = "";
                    operacija = operacijaProsla;
                }
                else if (broj == 'P' || broj == 'G')
                {
                    drugi = false;
                    if (!drugiProl)
                    {
                        prviBroj = drugiBroj;
                    }
                    if (broj == 'P')
                        prviBroj = memorija.postavi(GetCurrentDisplayState());
                    else
                    {
                        prviBroj = memorija.dohvati();
                        drugiBroj = memorija.dohvati();
                    }
                }
                else if (broj == 'C')
                {
                    prviBroj = "";
                    treciBroj = "";
                    nula = true;
                }
                else if (broj == 'O')
                {
                    prviBroj = "";
                    drugiBroj = "";
                    treciBroj = "";
                    memorija.postavi("");
                    nula = true;
                    drugiProl = false;
                }
                else if (broj == '=')
                {
                    if (drugiBroj == "")
                        drugiBroj = prviBroj;

                    if (!drugiProl && drugiBroj == "")
                        nula = true;

                    if (operacijaProsla == 'O')
                        nula = true;

                    if (!(operacijaProsla == 'S' || operacijaProsla == 'K' || operacijaProsla == 'T' || operacijaProsla == 'Q' || operacijaProsla == 'I' || operacijaProsla == 'R' || operacijaProsla == 'M'))
                    {

                        if (prvi == true)
                        {
                            treciBroj = prviBroj;
                        }
                        if ((operacijaProsla == '+' || operacijaProsla == '-' || operacijaProsla == '*' || operacijaProsla == '/') && treciBroj == "")

                            if (prvi == true)
                            {
                                treciBroj = prviBroj;
                            }
                            else
                            {
                                treciBroj = drugiBroj;
                            }
                        drugiBroj = izracun.izracunaj(operacijaProsla, drugiBroj, treciBroj);
                        treciBroj = "";
                    }
                    else
                    {
                        drugi = false;
                    }
                    prviBroj = drugiBroj;


                }
                else if (drugiProl)
                {
                    if (prvi == true)
                    {
                        treciBroj = prviBroj;
                    }
                    prviBroj = "";
                    if ((treciBroj != "") && !(operacijaProsla == 'S' || operacijaProsla == 'K' || operacijaProsla == 'T' || operacijaProsla == 'Q' || operacijaProsla == 'I' || operacijaProsla == 'R' || operacijaProsla == 'M'))
                    {
                        drugiBroj = izracun.izracunaj(operacijaProsla, drugiBroj, treciBroj);
                        treciBroj = "";
                    }
                }

                if (operacija != 'C')
                    operacijaProsla = operacija;

                if(m)
                    drugiProl = true;
                m = true;
                prvi = false;

            }

        }



        private class OperacijaM
        {
            public string predznak(string broj)
            {
                if (!(Convert.ToDouble(broj) < 0))
                {
                    broj = "-" + broj;
                }
                else
                    broj = broj.Remove(0, 1);

                return broj;
            }
        }



        private class UpravljanjeMemorijom
        {
            private string memorija;
            public string postavi(string broj)
            {
                memorija = broj;
                return memorija;
            }
            public string dohvati()
            {
                return memorija;
            }
        }

        private class Izracun
        {
            //public abstract void izracunaj();
            private SrediBroj sredi = new SrediBroj();

            public class SrediBroj
            {
                public string sredi(string drugiBroj)
                {
                    if (drugiBroj != "-E-" && drugiBroj != "")
                    {
                        drugiBroj = Convert.ToString(Math.Round(Convert.ToDecimal(drugiBroj), 9));
                    }
                    if (!drugiBroj.Contains(','))
                    {
                        if (drugiBroj.Length > 10)
                            drugiBroj = "-E-";
                    }

                    drugiBroj = drugiBroj.TrimStart('0');
                    if (drugiBroj.Contains(','))
                        drugiBroj = drugiBroj.TrimEnd('0').TrimEnd(',');

                    return drugiBroj;
                }
            }

            public string izracunaj(char operacija, string drugiBroj, string treciBroj)
            {

                if (operacija == '+')
                {
                    drugiBroj = Convert.ToString(Convert.ToDouble(drugiBroj) + Convert.ToDouble(treciBroj));
                }
                else if (operacija == '-')
                {
                    drugiBroj = Convert.ToString(Convert.ToDouble(drugiBroj) - Convert.ToDouble(treciBroj));
                }
                else if (operacija == '/')
                {
                    drugiBroj = Convert.ToString(Convert.ToDouble(drugiBroj) / Convert.ToDouble(treciBroj));
                }
                else if (operacija == '*')
                {
                    drugiBroj = Convert.ToString(Convert.ToDouble(drugiBroj) * Convert.ToDouble(treciBroj));
                }

                drugiBroj = sredi.sredi(drugiBroj);
                return drugiBroj;
            }

            public string izracunaj(char operacija, string drugiBroj)
            {
                if (operacija == 'S')
                {
                    drugiBroj = Convert.ToString(Math.Sin(Convert.ToDouble(drugiBroj)));
                }
                else if (operacija == 'K')
                {
                    drugiBroj = Convert.ToString(Math.Cos(Convert.ToDouble(drugiBroj)));
                }
                else if (operacija == 'T')
                {
                    drugiBroj = Convert.ToString(Math.Tan(Convert.ToDouble(drugiBroj)));
                }
                else if (operacija == 'Q')
                {
                    drugiBroj = Convert.ToString(Convert.ToDouble(drugiBroj) * Convert.ToDouble(drugiBroj));
                }
                else if (operacija == 'R')
                {
                    drugiBroj = Convert.ToString(Math.Sqrt(Convert.ToDouble(drugiBroj)));
                }
                else if (operacija == 'I')
                {
                    if (drugiBroj == "0")
                    {
                        drugiBroj = "-E-";
                    }
                    else
                    {
                        drugiBroj = Convert.ToString(1 / Convert.ToDouble(drugiBroj));
                    }
                }

                drugiBroj = sredi.sredi(drugiBroj);
                return drugiBroj;
            }


        }



    }


}
