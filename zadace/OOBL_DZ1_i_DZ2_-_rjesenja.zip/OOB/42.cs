﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }



    public abstract class Binary
    {

        public abstract double Calculate(double lhs, double rhs);

    }

    public abstract class Unary
    {
        public abstract double Calculate(double oper);
    }

    public class Plus : Binary
    {


        public override double Calculate(double lhs, double rhs)
        {
            return lhs + rhs;
        }


    }

    public class Minus : Binary
    {

        public override double Calculate(double lhs, double rhs)
        {
            return lhs - rhs;
        }

    }

    public class Times : Binary
    {

        public override double Calculate(double lhs, double rhs)
        {
            return lhs * rhs;
        }

    }

    public class Divide : Binary
    {

        public override double Calculate(double lhs, double rhs)
        {
            if (rhs == 0) throw new ArgumentOutOfRangeException();
            return lhs / rhs;
        }

    }

    public class Sinus : Unary
    {

        public override double Calculate(double oper)
        {
            return Math.Sin(oper);
        }

    }

    public class Cosinus : Unary
    {

        public override double Calculate(double oper)
        {
            return Math.Cos(oper);
        }

    }

    public class Tangens : Unary
    {

        public override double Calculate(double oper)
        {
            return Math.Tan(oper);
        }

    }

    public class Square : Unary
    {

        public override double Calculate(double oper)
        {
            return Math.Pow(oper, 2);
        }

    }

    public class SquareRoot : Unary
    {

        public override double Calculate(double oper)
        {
            if (oper < 0) throw new ArgumentOutOfRangeException();
            return Math.Pow(oper, 0.5);
        }

    }

    public class Inverse : Unary
    {

        public override double Calculate(double oper)
        {
            if (oper == 0) throw new ArgumentOutOfRangeException();

            return 1 / oper;
        }

    }
    public class Kalkulator : ICalculator
    {

        enum CalculatorState
        {

            Reset, //Digit press will start new number
            Continue, //Digit press will continue adding digits to the current displayed number
            ResetContinueOP, //Digit press will start new number, binary operator will execute previous binary operator

        };


        private CalculatorState currentState;

        private double currentValue;
        private double memory;
        
        //holds second operand
        private double register;

        private String displayState;
        private Binary currentOperation;
        private System.Globalization.NumberFormatInfo nrFormatInfo;

        //allows multiple execution of last binary operator ( "3+2===" => "9" )
        private bool registerIsRHS;

        public Kalkulator()
        {

            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InstalledUICulture;
            this.nrFormatInfo = (System.Globalization.NumberFormatInfo)ci.NumberFormat.Clone();
            this.nrFormatInfo.NumberDecimalSeparator = ",";

            this.Initialize();
        }

        private void Initialize()
        {
            this.currentState = CalculatorState.Reset;
            this.currentValue = 0;
            this.UpdateDisplayState();
            this.currentOperation = null;
            this.memory = 0;
            this.register = 0;
            this.registerIsRHS = false;
        }



        public void Press(char inPressedDigit)
        {

            switch (inPressedDigit)
            {
                case '+':
                    this.PressBinary(new Plus());
                    break;
                case '-':
                    this.PressBinary(new Minus());
                    break;
                case '*':
                    this.PressBinary(new Times());
                    break;
                case '/':
                    this.PressBinary(new Divide());
                    break;
                case 'S':
                    this.PressUnary(new Sinus());
                    break;
                case 'K':
                    this.PressUnary(new Cosinus());
                    break;
                case 'I':
                    this.PressUnary(new Inverse());
                    break;
                case 'T':
                    this.PressUnary(new Tangens());
                    break;
                case 'Q':
                    this.PressUnary(new Square());
                    break;
                case 'R':
                    this.PressUnary(new SquareRoot());
                    break;
                case 'O':
                    PressO();
                    break;
                case 'C':
                    PressC();
                    break;
                case ',':
                    PressComma();
                    break;
                case '=':
                    PressEquals();
                    break;
                case 'P':
                    PressPut();
                    break;
                case 'G':
                    PressGet();
                    break;
                case 'M':
                    PressMinus();
                    break;
                default:
                    if (Char.IsDigit(inPressedDigit))
                    {
                        PressDigit(inPressedDigit);
                    }
                    break;
            }
        }

        private void PressUnary(Unary op)
        {

            try
            {
                this.currentValue = op.Calculate(this.ParseCurrentDisplay());
            }
            catch
            {
                this.currentValue = Double.NaN;
            }

            this.UpdateDisplayState();
            this.currentState = CalculatorState.ResetContinueOP;

        }

        private void PressBinary(Binary op)
        {

            if (this.currentOperation != null && (this.currentState == CalculatorState.Continue || this.currentState == CalculatorState.ResetContinueOP) && !this.registerIsRHS) this.CalculateSubResult();

            this.register = this.ParseCurrentDisplay();
            this.registerIsRHS = false;
            this.currentOperation = op;
            this.currentState = CalculatorState.Reset;
       

        }
        private void PressDigit(char inPressedDigit)
        {

            if (this.currentState == CalculatorState.Reset || this.currentState == CalculatorState.ResetContinueOP)
            {
                this.displayState = inPressedDigit.ToString();
                this.currentState = CalculatorState.Continue;
            }
            else
            {
                if (this.displayState == "0" && inPressedDigit == '0') return;
                if (this.displayState == "0") this.displayState = "";
                int currentLength = this.displayState.Length;
                if (this.displayState.IndexOf('-') > -1) currentLength--;
                if (this.displayState.IndexOf(',') > -1) currentLength--;
                if (currentLength >= 10) return;
                this.displayState += inPressedDigit.ToString();
           
            }

        }

        private void PressComma()
        {
            if (this.currentState == CalculatorState.Reset || this.currentState == CalculatorState.ResetContinueOP)
            {
                this.displayState = "0,";
                this.currentState = CalculatorState.Continue;
            }
            else
            {
                if (this.displayState.IndexOf(",") < 0)
                {
                    this.displayState += ",";
                }
            }
        }

        private void CalculateSubResult() {

            if (this.currentOperation == null)
            {
                this.currentValue = this.ParseCurrentDisplay();
                this.UpdateDisplayState();
                return;
            }
            try
            {
             
                 this.currentValue = this.currentOperation.Calculate(this.register, this.ParseCurrentDisplay());
             
            }
            catch
            {
                this.currentValue = Double.NaN;
            }

      
            this.UpdateDisplayState();
            this.currentState = CalculatorState.Reset;

        }

        private void PressEquals()
        {
            if (this.currentOperation == null)
            {
                this.currentValue = this.ParseCurrentDisplay();
                this.currentState = CalculatorState.Reset;
                this.UpdateDisplayState();
                return;
            }
            try
            {
                if (!this.registerIsRHS)
                {
                    this.currentValue = this.currentOperation.Calculate(this.register, this.ParseCurrentDisplay());
                }
                else
                {
                    this.currentValue = this.currentOperation.Calculate(this.ParseCurrentDisplay(), this.register);
                }
            }
            catch
            {
                this.currentValue = Double.NaN;
            }

            if (!this.registerIsRHS)
            {
                this.registerIsRHS = true;
                this.register = this.ParseCurrentDisplay();
            }
            this.UpdateDisplayState();
            this.currentState = CalculatorState.Reset;
        }

        private void PressPut()
        {
            this.memory = this.ParseCurrentDisplay();
        }

        private void PressGet()
        {
            if (this.memory != Double.NaN)
            {
                this.currentValue = this.memory;
                this.UpdateDisplayState();
                this.currentState = CalculatorState.ResetContinueOP;
            }

        }
        private void PressMinus()
        {
            if (this.displayState == "0,")
            {
                this.displayState = ("-0,");
                return;
            }
            if (this.displayState == "-0,")
            {
                this.displayState = ("0,");
                return;
            }
            this.currentValue = -this.ParseCurrentDisplay();
            this.UpdateDisplayState();

        }

        private void PressC()
        {
            this.displayState = "0";
            this.currentState = CalculatorState.Reset;
        }

        private void PressO()
        {
            this.Initialize();
        }




        private double ParseCurrentDisplay()
        {


            if (this.GetCurrentDisplayState() == "-E-") return Double.NaN;

            String displayString = this.GetCurrentDisplayState();

            if (displayString[displayString.Length - 1] == ',')
            {
                displayString = displayString.Substring(0, displayString.Length - 1);
            }


            return Double.Parse(displayString, this.nrFormatInfo);


        }

        public void UpdateDisplayState()
        {



            if (Double.IsNaN(this.currentValue))
            {
                this.displayState = "-E-";

            }
            else
            {
                this.displayState = Math.Floor(Math.Abs(this.currentValue)).ToString(this.nrFormatInfo);
                if (this.displayState[0] == '-') this.displayState = this.displayState.Substring(1, this.displayState.Length - 1);
                if (this.displayState.Length > 10)
                {
                    this.displayState = "-E-";

                }
                else if (this.displayState.Length <= 10)
                {

                    this.displayState = Math.Round(this.currentValue, 10 - this.displayState.Length).ToString("F" + (10 - this.displayState.Length).ToString(),this.nrFormatInfo);
                    String tmp;
                    tmp = this.displayState.Replace("-", "");
                    tmp = tmp.Replace(",", "");
                    if (tmp.Length > 10) this.displayState = "-E-";
                }
        

                //delete zeros
                if (this.displayState.IndexOf(",") > -1)
                {
                    while (this.displayState.Length > 1)
                    {
                        if (this.displayState[this.displayState.Length - 1] == '0' || this.displayState[this.displayState.Length - 1] == ',')
                        {
                            if (this.displayState[this.displayState.Length - 1] == '0')
                            {
                                this.displayState = this.displayState.Substring(0, this.displayState.Length - 1);
                            }
                            else
                            {
                                this.displayState = this.displayState.Substring(0, this.displayState.Length - 1);
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }

                    }
                }


            }


        }

        public string GetCurrentDisplayState()
        {
            return this.displayState;
        }
    }


}
