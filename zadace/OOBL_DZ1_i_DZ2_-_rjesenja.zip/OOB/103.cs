﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stockList = new List<Stock>();
         private List<Index> indexList = new List<Index>(); 
         private List<PortFolio> portFolioList= new List<PortFolio>(); 


         #region ************************ S U Č E LJ E**************************************

         //*************************************************** D I O N I C E*******************************************************
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if((StockExists(inStockName)==false) && inNumberOfShares>0 && inInitialPrice>0)
             {
                 stockList.Add(new Stock(inStockName, inNumberOfShares,inInitialPrice,inTimeStamp));
             }else
             {
                 throw new StockExchangeException("Can't add stock");
             }
         }

         public void DelistStock(string inStockName)
         {
             if(StockExists(inStockName))
             {
                 stockList.Remove(GetStockByName(inStockName));
                 DeleteStockFromIndex(inStockName);
                 DeleteStockFromPortFolio(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Can't delete stock");
             }
         }

         public bool StockExists(string inStockName)
         {
             for (int i = 0; i < stockList.Count; i++)
             {
                 if (stockList.ElementAt(i).GetInStockName().ToUpper() == inStockName.ToUpper())
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return stockList.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             GetStockByName(inStockName).SetStockPriceInCertainTime(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return GetStockByName(inStockName).GetStockPriceInCertainTime(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return GetStockByName(inStockName).GetInInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return GetStockByName(inStockName).GetLastStockPrice();
         }
         //********************************************************************************************************************
         //**************************************************** I N D E X I****************************************************
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if((IndexExists(inIndexName)==false) && (inIndexType==IndexTypes.AVERAGE || inIndexType== IndexTypes.WEIGHTED))
             {
                 indexList.Add(new Index(inIndexName, inIndexType));
             }
             else
             {
                 throw new StockExchangeException("Can't add index");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if((IsStockPartOfIndex(inIndexName,inStockName)==false) && StockExists(inStockName))
             {
                 GetIndexByName(inIndexName).AddStock(GetStockByName(inStockName));
             }
             else
             {
                 throw new StockExchangeException("Can't add stock to index");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if(IsStockPartOfIndex(inIndexName,inStockName))
             {
                 GetIndexByName(inIndexName).RemoveStock(GetStockByName(inStockName));
             }
             else
             {
                 throw new StockExchangeException("Stock is not in index");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (GetIndexByName(inIndexName).GetStocks().Contains(GetStockByName(inStockName)))
                 return true;
             else return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if(GetIndexByName(inIndexName).GetInIndexType()==IndexTypes.AVERAGE)
             {
                 return GetIndexByName(inIndexName).GetAverageValue(inTimeStamp);
             }
             else
             {
                 return GetIndexByName(inIndexName).GetWeightedValue(inTimeStamp);
             }
         }

         public bool IndexExists(string inIndexName)
         {
             for (int i = 0; i < indexList.Count; i++)
             {
                   if (indexList.ElementAt(i).GetInIndexName().ToUpper() == inIndexName.ToUpper())
                         return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return indexList.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return GetIndexByName(inIndexName).GetStocks().Count();
         }
         //************************************************************************************************************
         //******************************************* P O R T F O L I O **********************************************
         public void CreatePortfolio(string inPortfolioID)
         {
             if(PortfolioExists(inPortfolioID)==false)
             {
                 portFolioList.Add(new PortFolio(inPortfolioID));
             }
             else
             {
                 throw new StockExchangeException("PortFolio already exsist");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if((GetStockByName(inStockName).GetInNumberOfShares()>=numberOfShares) || 
                    (IsStockPartOfPortfolio(inPortfolioID,inStockName) && GetStockByName(inStockName).GetInNumberOfShares()>=GetPortFolioByID(inPortfolioID).GetShares(GetStockByName(inStockName))+numberOfShares))
             {
                 GetPortFolioByID(inPortfolioID).AddStockAndShares(GetStockByName(inStockName), numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Too many shares");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             GetPortFolioByID(inPortfolioID).RemoveStockAndShares(GetStockByName(inStockName), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if(PortfolioExists(inPortfolioID))
             {
                 GetPortFolioByID(inPortfolioID).RemoveStock(GetStockByName(inStockName));
             }
         }

         public int NumberOfPortfolios()
         {
             return portFolioList.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return GetPortFolioByID(inPortfolioID).GetStocksAndShares().Count();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             for (int i = 0; i < portFolioList.Count; i++)
             {
                 if (portFolioList.ElementAt(i).GetInPortFolioID().ToUpper() == inPortfolioID.ToUpper())
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if(GetPortFolioByID(inPortfolioID).GetStocksAndShares().ContainsKey(GetStockByName(inStockName)))
                 return true;
             else return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortFolioByID(inPortfolioID).GetShares(GetStockByName(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return GetPortFolioByID(inPortfolioID).GetPortFolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return ((GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month))) -
                     GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1))) / GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1)))*100;
         }
         #endregion

         
         #region *********************** I M P L E M E N T A C I J A **********************************
         private Stock GetStockByName(String inStockName)
         {
             Stock tempStock=null;
              for (int i = 0; i < stockList.Count; i++ )
              {
                  if(stockList.ElementAt(i).GetInStockName().ToUpper() == inStockName.ToUpper())
                  {
                      tempStock = stockList.ElementAt(i);
                  }
              }
             return tempStock;
         }
         private Index GetIndexByName(String inIndexName)
         {
             Index tempIndex = null;
             for(int i=0; i<indexList.Count;i++)
             {
                 if(indexList.ElementAt(i).GetInIndexName().ToUpper()== inIndexName.ToUpper())
                 {
                     tempIndex = indexList.ElementAt(i);
                 }
             }
             return tempIndex;
         }
         private PortFolio GetPortFolioByID(String inPortfolioID)
         {
             PortFolio tempPortFolio = null;
             for(int i=0; i<portFolioList.Count;i++)
             {
                 if(portFolioList.ElementAt(i).GetInPortFolioID()== inPortfolioID)
                 {
                     tempPortFolio = portFolioList.ElementAt(i);
                 }
             }
             return tempPortFolio;
         }

         private void DeleteStockFromIndex(String inStockName)
         {
             foreach (Index index in indexList)
             {
                 if (IsStockPartOfIndex(index.GetInIndexName(), inStockName))
                     RemoveStockFromIndex(index.GetInIndexName(), inStockName);
             }
         }

         private void DeleteStockFromPortFolio(String inStockName)
         {
             foreach (PortFolio portFolio in portFolioList)
             {
                 if(IsStockPartOfPortfolio(portFolio.GetInPortFolioID(),inStockName))
                     RemoveStockFromPortfolio(portFolio.GetInPortFolioID(),inStockName);
             }
         }

         #endregion
     }






    public class Stock
    {
        private String inStockName;
        private long inNumberOfShares;
        private Decimal inInitialPrice;
        private DateTime inTimeStamp;

        private Decimal lastStockPrice;
        private Dictionary<DateTime, Decimal> stockPriceInCertainTime= new Dictionary<DateTime,Decimal>(); 

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.inStockName = inStockName;
            this.inNumberOfShares = inNumberOfShares;
            this.inInitialPrice = inInitialPrice;
            this.inTimeStamp = inTimeStamp;
            this.lastStockPrice = inInitialPrice;
            this.stockPriceInCertainTime.Add( inTimeStamp,inInitialPrice);
        }
        public void SetStockPriceInCertainTime(DateTime inIimeStamp, Decimal inStockValue)
        {
            stockPriceInCertainTime.Add(inIimeStamp,inStockValue);
        }

        public decimal GetStockPriceInCertainTime(DateTime inTimeStamp)
        {
            DateTime max = new DateTime(1000, 1, 10, 15, 40, 00);
            for(int i=0; i< stockPriceInCertainTime.Count-1; i++)
            {
                var iterator = stockPriceInCertainTime.ElementAt(i);
                var iterator2 = stockPriceInCertainTime.ElementAt(i+1);
                var key = iterator.Key;
                var nextKey = iterator2.Key;
                if (inTimeStamp < key && i == 0)
                    return 0;
                if(inTimeStamp>=key && inTimeStamp<nextKey)
                    return stockPriceInCertainTime[key];
            }
            return FindGreatestTimeStamp();
        }

        public Decimal GetLastStockPrice()
        {
            return this.FindGreatestTimeStamp();
        }
        public void SetLastStockPrice(Decimal lastStockPrice)
        {
            this.lastStockPrice = lastStockPrice;
        }
        public String GetInStockName()
        {
            return this.inStockName;
        }
        public decimal GetInInitialPrice()
        {
            return this.inInitialPrice;
        }
        public decimal GetInNumberOfShares()
        {
            return this.inNumberOfShares;
        }
        public decimal FindGreatestTimeStamp()
        {
            DateTime max = new DateTime(1000, 1, 10, 15, 40, 00);
            foreach (var time in stockPriceInCertainTime)
            {
                if(time.Key>max) max = time.Key;
            }
            return stockPriceInCertainTime[max];
        }
    }


    public class Index
    {
        private string inIndexName;
        private IndexTypes inIndexType;
        private List<Stock> stocks= new List<Stock>(); 

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.inIndexName = inIndexName;
            this.inIndexType = inIndexType;
        }


        public String GetInIndexName()
        {
            return this.inIndexName;
        }
        public void AddStock(Stock stock)
        {
            stocks.Add(stock);
        }
        public void RemoveStock(Stock stock)
        {
            stocks.Remove(stock);
        }
        public List<Stock> GetStocks()
        {
            return this.stocks;
        } 
        public IndexTypes GetInIndexType()
        {
            return this.inIndexType;
        }
        public decimal GetAverageValue(DateTime inTimeStamp)
        {
            decimal priceSum = 0;
            for(int i=0;i <this.stocks.Count();i++)
            {
                priceSum += stocks.ElementAt(i).GetStockPriceInCertainTime(inTimeStamp);
            }
            return Math.Round(priceSum/this.stocks.Count(),3);
        }
        public decimal GetWeightedValue(DateTime inTimeStamp)
        {
            decimal sumStockValue = 0;
            decimal sumIndexValue = 0;
            decimal sumWeightedIndexValue = 0;
            for (int i = 0; i < this.stocks.Count(); i++)
            {
                sumStockValue += stocks.ElementAt(i).GetStockPriceInCertainTime(inTimeStamp) *stocks.ElementAt(i).GetInNumberOfShares();
            }
            for (int i = 0; i < this.stocks.Count(); i++ )
            {
                sumIndexValue = (stocks.ElementAt(i).GetStockPriceInCertainTime(inTimeStamp) * stocks.ElementAt(i).GetInNumberOfShares()) / sumStockValue;
                sumWeightedIndexValue += sumIndexValue * stocks.ElementAt(i).GetStockPriceInCertainTime(inTimeStamp);
            }

            return Math.Round(sumWeightedIndexValue,3);
        }


    }


    public class PortFolio
    {
        private String inPortfolioID;
        private Dictionary<Stock, int> stocksAndShares= new Dictionary<Stock, int>(); 

        public PortFolio(string inPortfolioId)
        {
            inPortfolioID = inPortfolioId;
        }

        public String GetInPortFolioID()
        {
            return this.inPortfolioID;
        }
        public void AddStockAndShares(Stock stock, int share )
        {
            if(stocksAndShares.ContainsKey(stock)==false)
            {
                stocksAndShares.Add(stock, share);
            }
            else
            {
                stocksAndShares[stock] += share;
            }
            
        }
        public Dictionary<Stock,int> GetStocksAndShares()
        {
            return stocksAndShares;
        }
        public void RemoveStock(Stock stock)
        {
            stocksAndShares.Remove(stock);
        }
        public void RemoveStockAndShares(Stock stock, int shares)
        {
            int a = stocksAndShares[stock];
            if(stocksAndShares[stock]>shares)
            {
                stocksAndShares[stock] -= shares;
            }
            else if (stocksAndShares[stock]==shares)
            {
                stocksAndShares.Remove(stock);
            }
            else if(stocksAndShares[stock]<shares)
            {
                throw new StockExchangeException("Too many shares");
            }
        }
        public int GetShares(Stock stock)
        {
            return stocksAndShares[stock];
        }
        public decimal GetPortFolioValue(DateTime inTimeStamp)
        {
            decimal sumPortFolioValue = 0;
            for (int i = 0; i < this.stocksAndShares.Count(); i++)
            {
                sumPortFolioValue += stocksAndShares.ElementAt(i).Key.GetStockPriceInCertainTime(inTimeStamp) * stocksAndShares.ElementAt(i).Key.GetInNumberOfShares();
            }
            return sumPortFolioValue;
        }
    }
}
