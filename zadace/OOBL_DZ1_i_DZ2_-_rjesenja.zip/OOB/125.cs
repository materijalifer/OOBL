﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock {

        string stockName;
        public string StockName
        {
            get { return stockName; }
        }

        long numberOfShares;
        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        Dictionary<DateTime,decimal> price;

        DateTime issueTime;

        public DateTime IssueTime
        {
            get { return issueTime; }
        }

        public Stock(String name, long numberOfShares, decimal initialPrice, DateTime issueTime) {
            this.stockName = name;
            this.numberOfShares = numberOfShares;
            this.price = new Dictionary<DateTime, decimal>();
            this.price.Add(issueTime, initialPrice);
            this.issueTime = issueTime;
        }

        public void SetPrice(DateTime changeTime, decimal newPrice) {
            
            if (this.price.ContainsKey(changeTime))
            {
                throw new StockExchangeException("Price is already defined!");
            }

            if (this.issueTime>changeTime)
            {
                throw new StockExchangeException("Stock does not exist in given period.");
            }
           
                
            this.price.Add(changeTime, newPrice);
            
        }

        public Decimal GetInitialPrice() {
            if (this.price == null || this.price.Count == 0)
            {
                throw new StockExchangeException("Stock price is not defined!");
            }
            else
            {
                return this.price[this.IssueTime];

            }
        }

        public Decimal GetCurrentPrice()
        {
            if (this.price == null || this.price.Count == 0)
            {
                throw new StockExchangeException("Stock price is not defined!");
            }
            else
            {
                DateTime newestChange = this.IssueTime;
                foreach (DateTime d in this.price.Keys) {
                    if (d > newestChange) newestChange = d;
                }

                return this.price[newestChange];
            }
        }

        public Decimal GetPrice(DateTime date)
        {
            if (this.price == null || this.price.Count == 0)
            {
                throw new StockExchangeException("Stock price is not defined!");
            }
            if (date < this.IssueTime)
            {
                throw new StockExchangeException("Stock was not defined at requested time.");
            }
            else
            {
                DateTime newestChange = this.IssueTime;
                foreach (DateTime d in this.price.Keys)
                {
                    if (d > newestChange && d<=date) newestChange = d;
                }

                return this.price[newestChange];
            }
        }

        
    }

    public abstract class Index {

        private string indexName;
        protected string IndexName
        {
            get { return indexName; }
        }


        protected List<Stock> stocks;

        public int NumberOfStocks {
            get { return this.stocks.Count; }
        }

        public Index(String indexName) {
            this.indexName = indexName;
            this.stocks = new List<Stock>();
        }

        public void AddStock(Stock stock) {
            if (!this.stocks.Contains(stock))
            {
                this.stocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Stock is already in index!");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (this.stocks.Contains(stock))
            {
                this.stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Stock is not in index!");
            }
        }

        public bool ContainsStock(Stock stock) { 
            return this.stocks.Contains(stock);
        }

        public abstract decimal GetPrice(DateTime time);

    }

    public class AverageIndex : Index {

        public AverageIndex(string indexName) : base(indexName) { 
        
        }

        public override decimal GetPrice(DateTime time)
        {
            if (this.stocks.Count == 0) return 0;

            decimal sum = 0;
            foreach (Stock stock in this.stocks){
                sum+=stock.GetPrice(time);
            }

            return sum / this.stocks.Count;
        }

    }

    public class WeightedIndex : Index
    {

        public WeightedIndex(string indexName)
            : base(indexName)
        { 
        
        }

        public override decimal GetPrice(DateTime time)
        {
            if (this.stocks.Count == 0) return 0;

            decimal sum = 0;

            foreach (Stock stock in this.stocks)
            {
                sum += (stock.GetPrice(time)*stock.GetPrice(time)*stock.NumberOfShares);
            }

            return sum / this.IndexValue(time);
        }

        private decimal IndexValue(DateTime time) {
            
            decimal totalValue = 0;
            foreach (Stock stock in this.stocks) { 
                totalValue+=(stock.GetPrice(time)*stock.NumberOfShares);
            }

            return totalValue;
        }

    }

    public class Portfolio {

        private string id;

        public string ID
        {
            get { return id; }
        }
        private Dictionary<Stock, int> stocks;

        public int NumberOfStocks {
            get { return this.stocks.Count;  }
        }

        public Portfolio(String portfolioId) {
            this.id = portfolioId;
            this.stocks = new Dictionary<Stock, int>();
        }

        public void AddStock(Stock stock, int count) {

            if (this.stocks.ContainsKey(stock))
            {
                this.stocks[stock] += count;
            }
            else
            {
                this.stocks.Add(stock, count);
            }
        }

        public void RemoveStock(Stock stock, int count)
        {

            if (this.stocks.ContainsKey(stock))
            {
                if (this.stocks.Count >= count)
                {
                    this.stocks[stock] -= count;
                    if (this.stocks[stock] == 0)
                    {
                        this.RemoveStock(stock);
                    }
                }
                else
                {
                    throw new StockExchangeException("To many shares for removing");
                }
            }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio!");
            }
        }


        public bool ContainsStock(Stock stock) { 
            
            return this.stocks.Keys.Contains(stock);
        }

        public void RemoveStock(Stock stock)
        {

            if (this.stocks.ContainsKey(stock))
            {
                this.stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio!");
            }
        }

        public int NumberOfShares(Stock stock) {
            if (this.stocks.ContainsKey(stock))
            {
                return this.stocks[stock];
            }
            else
            {
                return 0;
            }
        }

        public decimal GetValue(DateTime time) {
            decimal totalValue = 0;
            foreach (Stock stock in this.stocks.Keys) { 
                totalValue+=(stock.GetPrice(time)*this.stocks[stock]);
            }

            return totalValue;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month) {
            DateTime firstDay = new DateTime(year, month, 1, 0, 0, 0);
            DateTime lastDay = new DateTime(year, month, DateTime.DaysInMonth(year,month), 23, 59, 59,999);

            if (this.GetValue(firstDay) != 0)
            {
                return (this.GetValue(lastDay) - this.GetValue(firstDay)) / (this.GetValue(firstDay))*100;
            }
            else
            {
                throw new Exception("Chane cannot be calculated");
            }
        }

    }

    public class StockExchange : IStockExchange
    {

        Dictionary<String, Stock> stocks;
        Dictionary<String, Index> indices;
        Dictionary<String, Portfolio> portfolios;

        public StockExchange() {
            this.stocks = new Dictionary<string, Stock>();
            this.indices = new Dictionary<string, Index>();
            this.portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0) throw new StockExchangeException("Illegal price");
            if (this.StockExists(inStockName))
            {
                throw new StockExchangeException("Stock is alredy listed!");
            }
            else
            { 
                this.stocks.Add(inStockName.ToLower(),new Stock(inStockName.ToLower(),inNumberOfShares,inInitialPrice,inTimeStamp));
            }
        }



        public void DelistStock(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                this.RemoveStockFromIndices(this.GetStock(inStockName));
                this.RemoveStockFromPortfolios(this.GetStock(inStockName));
                this.stocks.Remove(inStockName);
              
            }
            else {
                throw new StockExchangeException("Stocke does not exists!");
            }
        }

        private void RemoveStockFromIndices(Stock stock) {
            
            foreach (Index index in this.indices.Values) {
                if (index.ContainsStock(stock)) {
                    index.RemoveStock(stock);
                }
            }
        }

        private void RemoveStockFromPortfolios(Stock stock)
        {

            foreach (Portfolio portfolio in this.portfolios.Values)
            {
               
                if (portfolio.ContainsStock(stock))
                {
                    portfolio.RemoveStock(stock);
                }
            }
        }

        public int NumberOfStocks()
        {
            return this.stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0) throw new StockExchangeException("Illegal price");
            if (this.StockExists(inStockName))
            {
                this.GetStock(inStockName).SetPrice(inIimeStamp, inStockValue);
            }
            else
            {
                throw new StockExchangeException("Stock does not exists!");
            }
        }

        private Stock GetStock(String stockName) {
            if (this.StockExists(stockName))
            {
                return this.stocks[stockName.ToLower()];
            }
            else
            {
                throw new StockExchangeException("Stock not exists!");
            }
        }
        public bool StockExists(string inStockName)
        {
            if (this.stocks.ContainsKey(inStockName.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private Index GetIndex(String indexName)
        {
            if (this.IndexExists(indexName))
            {
                return this.indices[indexName.ToLower()];
            }
            else
            {
                throw new StockExchangeException("Stock not exists!");
            }
        }
        public bool IndexExists(string inIndexName)
        {
            if (this.indices.ContainsKey(inIndexName.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (this.StockExists(inStockName))
            {
                return Math.Round(this.GetStock(inStockName).GetPrice(inTimeStamp),3);
            }
            else
            {
                throw new StockExchangeException("Stock not exists");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                return Math.Round(this.GetStock(inStockName).GetInitialPrice(),3);
            }
            else
            {
                throw new StockExchangeException("Stock not exists");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                return Math.Round(this.GetStock(inStockName).GetCurrentPrice(),3);
            }
            else
            {
                throw new StockExchangeException("Stock not exists");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!this.IndexExists(inIndexName))
            {
                switch (inIndexType)
                {
                    case IndexTypes.AVERAGE:
                        this.indices.Add(inIndexName.ToLower(), new AverageIndex(inIndexName));
                        break;
                    case IndexTypes.WEIGHTED:
                        this.indices.Add(inIndexName.ToLower(), new WeightedIndex(inIndexName));
                        break;
                    default:
                        throw new StockExchangeException("Wrong index type");

                }
            }
            else
            {
                throw new StockExchangeException("Index already exists.");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (this.IndexExists(inIndexName)) {
                if (this.StockExists(inStockName))
                {
                    this.GetIndex(inIndexName).AddStock(this.GetStock(inStockName));
                }
                else 
                {
                    throw new StockExchangeException("Stock does not exists!");
                }
            }
            else
            {
                throw new StockExchangeException("Index does not exists!");
            }

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (this.IndexExists(inIndexName))
            {
                if (this.StockExists(inStockName))
                {
                    this.GetIndex(inIndexName).RemoveStock(this.GetStock(inStockName));
                }
                else
                {
                    throw new StockExchangeException("Stock does not exists!");
                }
            }
            else
            {
                throw new StockExchangeException("Index does not exists!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (this.IndexExists(inIndexName))
            {
                if (this.StockExists(inStockName))
                {
                    return this.GetIndex(inIndexName).ContainsStock(this.GetStock(inStockName));
                }
                else
                {
                    throw new StockExchangeException("Stock does not exists!");
                }
            }
            else
            {
                throw new StockExchangeException("Index does not exists!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (this.IndexExists(inIndexName))
            {
                return Math.Round(this.GetIndex(inIndexName).GetPrice(inTimeStamp),3);
            }
            else
            {
                throw new StockExchangeException("Index does not exists!");
            }
        }

        public int NumberOfIndices()
        {
            return this.indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (this.IndexExists(inIndexName))
            {
                return this.GetIndex(inIndexName).NumberOfStocks;
            }
            else
            {
                throw new StockExchangeException("Stock does not exists!");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                this.portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
            }
            else
            {
                throw new StockExchangeException("Portfolio already exists!");
            }
        }

        private long AvailabelShares(String inStockName) {

            if (this.StockExists(inStockName))
            {
                long count = this.GetStock(inStockName).NumberOfShares;
                foreach (Portfolio portfolio in this.portfolios.Values) {
                    count -= portfolio.NumberOfShares(this.GetStock(inStockName));
                }
                return count;
            }
            else
            {
                throw new Exception("Stcok does not exists");
            }

        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                if (this.AvailabelShares(inStockName) >= numberOfShares)
                {
                    this.portfolios[inPortfolioID].AddStock(this.GetStock(inStockName), numberOfShares);
                }
                else
                {
                    throw new Exception("There is not enough shares!");
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                this.portfolios[inPortfolioID].RemoveStock(this.GetStock(inStockName), numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                this.portfolios[inPortfolioID].RemoveStock(this.GetStock(inStockName));
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public int NumberOfPortfolios()
        {
            return this.portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                return this.portfolios[inPortfolioID].NumberOfStocks;
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return this.portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                return this.portfolios[inPortfolioID].NumberOfShares(this.GetStock(inStockName)) != 0;
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.PortfolioExists(inPortfolioID) )
            {
                if (this.IsStockPartOfPortfolio(inPortfolioID,inStockName))
                {
                    return this.portfolios[inPortfolioID].NumberOfShares(this.GetStock(inStockName));
                }
                else
                {
                    throw new Exception("Stock is not part of protfolio!");
                }
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                return Math.Round(this.portfolios[inPortfolioID].GetValue(timeStamp),3);
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (this.PortfolioExists(inPortfolioID))
            {
                return Math.Round(this.portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month),3);
            }
            else
            {
                throw new StockExchangeException("Portfolio not exists!");
            }
        }
    }
}
