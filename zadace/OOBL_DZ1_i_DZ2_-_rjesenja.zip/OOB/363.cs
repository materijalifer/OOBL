﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,Stock> allStocks = new Dictionary<string,Stock>();
         private Dictionary<string, AbstractIndex> allIndices = new Dictionary<string, AbstractIndex>();
         private Dictionary<string, Portfolio> allPortfolios = new Dictionary<string, Portfolio>();
         private Dictionary<string, long> stocksLeftForDistribution = new Dictionary<string, long>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToLower();
             if(allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Dionica s tim imenom vec postoji");
             if(inInitialPrice <= 0)
                 throw new StockExchangeException("Cijena dionice ne moze biti negativna niti 0!");
             if(inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionca ne moze biti negativan niti 0!");
              //stock name is always lower case
             allStocks.Add(inStockName.ToLower(), 
                 new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp));
             stocksLeftForDistribution.Add(inStockName.ToLower(), inNumberOfShares);
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne moze se obrisati dionica s nepostojecim imenom");
             allStocks.Remove(inStockName);
             try
             {
                 foreach (KeyValuePair<string, AbstractIndex> pair in allIndices)
                 {
                     RemoveStockFromIndex(pair.Key,inStockName);
                 }
                 foreach (KeyValuePair<string, Portfolio> pair in allPortfolios)
                 {
                     RemoveStockFromPortfolio(pair.Key,inStockName);
                 }
                 stocksLeftForDistribution.Remove(inStockName);
             }
             catch 
             {}

         }

         public bool StockExists(string inStockName)
         {
             return allStocks.ContainsKey(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return allStocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Ne postoji dionica s tim imenom te se ne moze postaviti cijena!");
             allStocks[inStockName.ToLower()].SetNewPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Ne postoji dionica s tim imenom te se ne moze procitati cijena!");
             return allStocks[inStockName.ToLower()].getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Ne postoji dionica s tim imenom te se ne moze procitati inicijalna cijena!");
             return allStocks[inStockName.ToLower()].initialPrice;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Ne postoji dionica s tim imenom te se ne moze procitati zadnja cijena!");
             return allStocks[inStockName.ToLower()].getLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToLower();
             if(allStocks.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Indeks s tim imenom vec postoji!");
             if(inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                 throw new StockExchangeException("Ne postoji takav tip indeksa!");

             switch(inIndexType)
             {
                 case IndexTypes.AVERAGE:
                     allIndices.Add(inIndexName.ToLower(), new AverageIndex(inIndexName.ToLower(), allStocks));
                     break;
                 case IndexTypes.WEIGHTED:
                     allIndices.Add(inIndexName.ToLower(), new WeightedIndex(inIndexName.ToLower(), allStocks));
                     break;
             }  
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if ( ! allStocks.ContainsKey(inStockName.ToLower()))
             { 
                 throw new StockExchangeException("Ne postoji takva dionica na burzi");
             }

             if (!allIndices.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Ne postoji indeks s tim imenom te se ne mogu dodati dionice");

             allIndices[inIndexName].addStock(inStockName);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if (!allStocks.ContainsKey(inStockName.ToLower()))
                 throw new StockExchangeException("Ne postoji takva dionica na burzi");
             if (!allIndices.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Ne postoji indeks s tim imenom te se ne moze obrisati dionica");
             allIndices[inIndexName].removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if (!allIndices.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Ne postoji indeks s tim imenom");
             return allIndices[inIndexName].isPartOf(inStockName.ToLower());
         }
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToLower();
 
             if (!allIndices.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Ne postoji indeks s tim imenom te se ne moze dohvatiti njegova vrijednost");
             return allIndices[inIndexName].GetValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToLower();
       
             return allIndices.ContainsKey(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return allIndices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToLower();
             if (!allIndices.ContainsKey(inIndexName.ToLower()))
                 throw new StockExchangeException("Ne postoji indeks s tim imenom");
             return allIndices[inIndexName].numberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Postoji takav portfelj!");
             allPortfolios.Add(inPortfolioID, new Portfolio(inPortfolioID,allStocks));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToLower();
             if(!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije  moguce dodati portfelj u njega");
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne postoji ta dionica na burzi pa je nije moguce dodati u portfelj");

             if(stocksLeftForDistribution[inStockName] < numberOfShares)
                throw new StockExchangeException("Nije moguce dodijeliti toliko dionica tom portfelju!");
             allPortfolios[inPortfolioID].addStocks(inStockName, numberOfShares);
             stocksLeftForDistribution[inStockName] -= numberOfShares;
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToLower();
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije  moguce brisati iz njega");
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne postoji ta dionica na burzi pa je nije moguce brisati iz portfelja");
             allPortfolios[inPortfolioID].removeStocks(inStockName,numberOfShares);
             stocksLeftForDistribution[inStockName] += numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije  moguce brisati iz njega2");
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne postoji ta dionica na burzi pa je nije moguce brisati iz portfelja2");
             int numberToFree = allPortfolios[inPortfolioID].removeAllStocksOfThatName(inStockName);
             stocksLeftForDistribution[inStockName] += numberToFree;
         }

         public int NumberOfPortfolios()
         {
             return allPortfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije moguce prebrojati njegove dionice");
             return allPortfolios[inPortfolioID].numberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return allPortfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije moguce ispitati je li dionica unutar portfelja.");
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne postoji ta dionica na burzi pa je nije moguce ispitati je li dionica unutar portfelja.");
             return allPortfolios[inPortfolioID].isStockPartOf(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije moguce ispitati broj dionica unutar portfelja.");
             if (!allStocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne postoji ta dionica na burzi pa je nije moguce ispitati broj dionica unutar portfelja.");
             return allPortfolios[inPortfolioID].numberOfShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije moguce pronaci njegovu vrijednost.");
             return allPortfolios[inPortfolioID].calculateValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!allPortfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postoji taj portfolio na burzi pa nije moguce ispitati njegovu promjenu.");
             return allPortfolios[inPortfolioID].calculateChange(Year, Month);
         }
     }

    /// <summary>
    /// Klasa koja enkapsulira podatke za jednu dionicu
    /// </summary>
     class Stock
     {
         private string stockName;
         public long numberOfShares {get; private set;}
         public Decimal initialPrice {get; private set;}
         private DateTime timeStamp;

         List<Decimal> allPrices = new List<Decimal>();
         List<DateTime> allTimes = new List<DateTime>();


         public Stock(
             string inStockName, 
             long inNumberOfShares, 
             Decimal inInitialPrice, 
             DateTime inTimeStamp)
         {
         
            stockName = inStockName;
            numberOfShares = inNumberOfShares;
            initialPrice = inInitialPrice;
            timeStamp = inTimeStamp;
         }

         //postavlja novu cijenu dionici
         public void SetNewPrice(Decimal newPrice, DateTime inTimeStamp)
         {
             allPrices.Add(newPrice);
             allTimes.Add(inTimeStamp);
         }

         //vraca cijenu dionice u nekom trenutku
         public Decimal getPrice(DateTime inTimeStamp)
         {
             int n = allPrices.Count();
             if ( n == 0)
                 return initialPrice;
             int i;
             for (i = 0; i < n; i++)
             {
                 if (inTimeStamp < allTimes[i])
                     break;
             }

             if (i > 0)
                 return allPrices[i - 1];
             else if (inTimeStamp < timeStamp)
                 return 0;
             else
                 return initialPrice;
         }

         //vraca aktualnu cijenu
         public Decimal getLastPrice()
         {
             if (allPrices.Count() == 0)
                 return initialPrice;
             else
                 return allPrices[allPrices.Count() - 1];
         }

     }

    /// <summary>
    /// Klasa koja enkapsulira podatke indeksa
    /// </summary>
     abstract class AbstractIndex
     {
         protected HashSet<string> allStocksInIndex = new HashSet<string>();
         protected Dictionary<string, Stock> stocks;

         //dodaje dionicu
         public void addStock(string stockName)
         {
             if (allStocksInIndex.Contains(stockName.ToLower()))
                 throw new StockExchangeException("Dodavanje neuspjesno! Postoji dionica s danim imenom u indeksu!");

             allStocksInIndex.Add(stockName.ToLower());
         }

         //brise dionicu
         public void removeStock(string stockName)
         {
             if (!allStocksInIndex.Contains(stockName.ToLower()))
                 throw new StockExchangeException("Ne postoji ime dionice u tom indeksu te se ne moze obrisati");
             allStocksInIndex.Remove(stockName.ToLower());
         }

         //projverava je li dionica untar indeksa
         public bool isPartOf(string stockName)
         {
             return allStocksInIndex.Contains(stockName);
         }

         //broj dionica
         public int numberOfStocks()
         {
             return allStocksInIndex.Count();
         }

         public string Name { get; private set; }

         protected AbstractIndex(string name, Dictionary<string, Stock> stocks)
         {
             this.Name = name.ToLower();
             this.stocks = stocks;
         }

         public abstract Decimal GetValue(DateTime inTimeStamp);
     }

     class AverageIndex : AbstractIndex
     {
         public override decimal GetValue(DateTime inTimeStamp)
         {
             decimal sum = 0m;
             decimal n = allStocksInIndex.Count();
             foreach (string stockname in allStocksInIndex)
             {
                 sum += stocks[stockname].getLastPrice();
             }
             return decimal.Round(sum / n, 3, MidpointRounding.AwayFromZero);
         }

         public AverageIndex(string name, Dictionary<string,Stock> stocks)
             : base(name, stocks)
         {  }
     }

     class WeightedIndex : AbstractIndex
     {
         public override decimal GetValue(DateTime inTimeStamp)
         {
             decimal sum = 0m;
             foreach (string stockname in allStocksInIndex)
             {
                 sum += stocks[stockname].getLastPrice() * stocks[stockname].numberOfShares;
             }
             decimal result = 0;
             foreach (string stockname in allStocksInIndex)
             {
                 decimal cijena = stocks[stockname].getLastPrice();
                 result += cijena / sum * cijena * stocks[stockname].numberOfShares;
             }
             return decimal.Round(result, 3, MidpointRounding.AwayFromZero);
         }

         public WeightedIndex(string name, Dictionary<string, Stock> stocks)
             : base(name, stocks)
         { }
     }

    /// <summary>
    /// Klasa koja enkapsulira podatke portfelja
    /// </summary>
     class Portfolio
     {
         private string portfolioID;
         private Dictionary<string, Stock> globalStocks;
         private Dictionary<string, int> stocks = new Dictionary<string, int>();

         //konstruktor
         public Portfolio(string portfolioID, Dictionary<string, Stock> globalStocks)
         {
             this.portfolioID = portfolioID;
             this.globalStocks = globalStocks;
         }

         //dodaje dionice s navedenim imenom
         public void addStocks(string stockName, int numberOfShares)
         {
             if (stocks.ContainsKey(stockName))
                 stocks[stockName] += numberOfShares;
             else
                 stocks.Add(stockName, numberOfShares);
         }

         // brise odreden broj dionica odredene dionice
         public void removeStocks(string stockName, int numberOfShares)
         {
             if (stocks.ContainsKey(stockName))
             {
                 if (stocks[stockName] >= numberOfShares)
                     stocks[stockName] -= numberOfShares;
                 else
                     throw new StockExchangeException("Pokusali ste obrisati vise dionica nego sto postoji u portfelju");
                 //brisanje iz portfelja u slucaju 0 dionica
                 if(stocks[stockName] == 0)
                    stocks.Remove(stockName);
             }
             else
                 throw new StockExchangeException("Pokusali ste obrisati dionice koje ne postoje u portfelju");
         }

         //brise dinoice sa zadanim imenom
         public int removeAllStocksOfThatName(string stockName)
         { 
            if (! stocks.ContainsKey(stockName))
                throw new StockExchangeException("Pokusali ste obrisati dionice koje ne postoje u portfelju");
            int result = stocks[stockName];
             stocks.Remove(stockName);
             return result;
         }

         //vraca broj  dionica u portfoliju
         public int numberOfStocks()
         {
             return stocks.Count();
         }

         //vraca ukoliko portfelj sadrzi trazenu dionicu
         public bool isStockPartOf(string stockName)
         {
             return stocks.ContainsKey(stockName);
         }

         //vraca broj dionica neke dionice
         public int numberOfShares(string stockName)
         {

             if (!stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Ne postoji ta dionica unutar porfolija pa se ne moze saznati koliko ih ima");
             else
                 return stocks[stockName];
         }

         //izracunava vrijednost portfelja
         public decimal calculateValue(DateTime timeStamp)
         {
             decimal sum = 0;
             foreach(var pair in stocks)
             {
                sum += pair.Value * globalStocks[pair.Key].getPrice(timeStamp);
             }
             return sum;
         }

         //racuna razliku na pocetku i kraju mjeseca
         public decimal calculateChange(int year, int month)
         {
             DateTime start = new DateTime(year, month, 1, 0, 0, 0, 0);
             DateTime end = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
             decimal startV = calculateValue(start);
             if (startV == 0m)
                 throw new StockExchangeException("Pocetna vrijednost u mjesecu ne smije biti 0!");
             decimal endV = calculateValue(end);
             decimal result = (endV - startV) / startV;
             result *= 100;
             //zaokruzivanje
             return decimal.Round(result, 3, MidpointRounding.AwayFromZero);
         }
     }
}
