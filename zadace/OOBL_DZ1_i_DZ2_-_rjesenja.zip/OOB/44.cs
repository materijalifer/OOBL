﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private List<char> broj1 = new List<char>();
        private List<char> broj2 = new List<char>();
        private List<char> tempBroj = new List<char>();
        private List<char> prikaz = new List<char>();

        private char zadnjaOperacija;
        private char operacija;
        private string rezultat;
        bool eq = false;
        bool nule = true;
        private List<char> pohranjeniBroj = new List<char>();

        private char[] brojevi = new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };

        public Kalkulator()
        {
            prikaz.Add('0');
        }
        
        
        public void Press(char inPressedDigit)
        {
            if (brojevi.Contains(inPressedDigit))
                this.UnesenBroj(inPressedDigit);            

            switch (inPressedDigit)
            {
                case '+':
                    {
                        if ((zadnjaOperacija == '+') || (zadnjaOperacija == '-') || (zadnjaOperacija == '*') || (zadnjaOperacija == '/'))
                        {
                            operacija = '+';
                            return;
                        }
                        this.Plus();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                case ',':
                    {
                        this.Zarez(inPressedDigit);
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                case 'C':
                    {
                        this.Clear();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                case '-':
                    {
                        if ((zadnjaOperacija == '+') || (zadnjaOperacija == '-') || (zadnjaOperacija == '*') || (zadnjaOperacija == '/'))
                        {
                            operacija = '-';
                            return;
                        }
                        this.Minus(inPressedDigit);
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                 case '=':
                    {
                        this.Jednako();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                 case '*':
                    {
                        if ((zadnjaOperacija == '+') || (zadnjaOperacija == '-') || (zadnjaOperacija == '*') || (zadnjaOperacija == '/'))
                        {
                            operacija = '*';
                            return;
                        }
                        this.Puta();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                 case '/':
                    {
                        if ((zadnjaOperacija == '+') || (zadnjaOperacija == '-') || (zadnjaOperacija == '*') || (zadnjaOperacija == '/'))
                        {
                            operacija = '/';
                            return;
                        }
                        this.Podijeljeno();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                 case 'M':
                    {
                        this.Predznak();
                        zadnjaOperacija = inPressedDigit;
                        return;
                    }
                 case 'S':
                    {
                        this.Sinus();
                        return;
                    }
                 case 'K':
                    {
                        this.Kosinus();
                        return;
                    }
                 case 'Q':
                    {
                        this.Kvadrat();
                        return;
                    }
                 case 'I':
                    {
                        this.Inverz();
                        return;
                    }
                 case 'R':
                    {
                        this.Korjen();
                        return;
                    }
                 case 'T':
                    {
                        this.Tangens();
                        return;
                    }
                 case 'P':
                    {
                        this.Put();
                        return;
                    }
                 case 'G':
                    {
                        this.Get();
                        return;
                    }
                 case 'O':
                    {
                        this.Reset();
                        return;
                    }
                default: 
                    {                        
                        return;
                    }
            }
            
        }

        public string GetCurrentDisplayState()
        {            
            return string.Join("", prikaz);        
        }

        private void UnesenBroj(char uneseniZnak)
        {
            zadnjaOperacija = uneseniZnak;
            int i = 0;
            foreach (char znak in tempBroj)
                if ((znak == '0') || (znak == '1') || (znak == '2') || (znak == '3') || (znak == '4') || (znak == '5') || (znak == '6') || (znak == '7') || (znak == '8') || (znak == '9'))
                {
                    i++;
                    if (i == 10) return;
                }
            if (tempBroj.Count == 1)
                if ((tempBroj[0] == '0') && (uneseniZnak == '0'))
                    return;
            //if (!((tempBroj.Count == 0) && (uneseniZnak == '0')))
                tempBroj.Add(uneseniZnak);
            prikaz = new List<char>(tempBroj);
            
        }

        private void Plus()
        {
            if (tempBroj.Count > 0) broj2 = new List<char>(tempBroj);
            tempBroj.Clear();
            if (eq == true)
            {
                operacija = ' ';
                broj2 = new List<char>(broj1);
            }
            this.IzracunajBinarno('+');
            eq = false;
            if ( broj1.Count> 0) operacija = '+';
            
        }

        private void Minus(char uneseniZnak)
        {
            if (prikaz.Count == 0)
                tempBroj.Add(uneseniZnak);
            else
            {
                if (tempBroj.Count > 0) broj2 = new List<char>(tempBroj);
                tempBroj.Clear();
                if (eq == true)
                {
                    operacija = ' ';
                    broj2 = new List<char>(broj1);
                }
                this.IzracunajBinarno('-');
                eq = false;
                if (broj1.Count > 0) operacija = '-';
            }

        }

        private void Puta()
        {
            if (tempBroj.Count > 0) broj2 = new List<char>(tempBroj);
            tempBroj.Clear();
            if (eq == true)
            {
                operacija = ' ';
                broj2 = new List<char>(broj1);
            }
            this.IzracunajBinarno('*');
            eq = false;
            if (broj1.Count > 0) operacija = '*';
        }

        private void Podijeljeno()
        {
            if (tempBroj.Count > 0) broj2 = new List<char>(tempBroj);
            tempBroj.Clear();
            if (eq == true)
            {
                operacija = ' ';
                broj2 = new List<char>(broj1);
            }
            this.IzracunajBinarno('/');
            eq = false;
            if (broj1.Count > 0) operacija = '/';
        }

        private void Kvadrat()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString((this.Pretvorba(tempBroj)) * (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') ||(operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString((this.Pretvorba(broj1)) * (this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString((this.Pretvorba(tempBroj)) * (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }
        
        private void Korjen()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString(Math.Sqrt(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') ||(operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString(Math.Sqrt(this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString(Math.Sqrt(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }
        
        private void Inverz()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString(1 / (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') ||(operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString(1 / (this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString(1 / (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }
        
        private void Sinus()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString(Math.Sin(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') ||(operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString(Math.Sin(this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString(Math.Sin(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }
        
        private void Kosinus()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString(Math.Cos(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString(Math.Cos(this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString(Math.Cos(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }
        
        private void Tangens()
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString(Math.Tan(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString(Math.Tan(this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString(Math.Tan(this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }

        private void Put()
        {
            if (tempBroj.Count > 0)
            {
                pohranjeniBroj = new List<char>(tempBroj);
            }
            else if (broj1.Count > 0)
            {
                pohranjeniBroj = new List<char>(broj1);
            }
        }

        private void Get()
        {
            if (tempBroj.Count > 0)
            {
                tempBroj = new List<char>(pohranjeniBroj);
                prikaz = new List<char>(pohranjeniBroj);
            }
            else if (broj1.Count > 0)
            {
                broj1 = new List<char>(pohranjeniBroj);
                prikaz = new List<char>(pohranjeniBroj);
            }
        }

        private void Predznak()
        {
            if (tempBroj.Count > 0)
            {
                if (tempBroj[0] == '-')
                    tempBroj.Remove('-');
                else tempBroj.Insert(0, '-');
                prikaz = new List<char>(tempBroj);
            }
            else if (broj1.Count > 0)
            {
                if (broj1[0] == '-')
                    broj1.Remove('-');
                else broj1.Insert(0, '-');
                prikaz = new List<char>(broj1);
            }
        }

        private void Zarez(char uneseniZnak)
        {
            if (!tempBroj.Contains(','))
                if (tempBroj.Count == 0)
                {
                    tempBroj.Add('0');
                    tempBroj.Add(uneseniZnak);
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    tempBroj.Add(uneseniZnak);
                    prikaz = new List<char>(tempBroj);
                }                
        }

        private void Jednako()
        {
            eq = true;
            if (tempBroj.Count > 0) broj2 = new List<char>(tempBroj);
            tempBroj.Clear();
            
            this.IzracunajBinarno('+');
            
        }
        
        private void IzracunajBinarno(char binarno)
        {
           
            switch (operacija)
            {
                
                
                case '+':
                    {
                        if (broj1.Count != 0)
                        {
                            rezultat = Convert.ToString(this.Pretvorba(broj1) + this.Pretvorba(broj2));
                            broj1.Clear();
                            broj1 = rezultat.ToList<char>();
                            broj1 = new List<char>(this.Sredi(broj1));

                            prikaz = new List<char>(broj1);
                            return;
                            
                        }
                        else
                        {                            
                            return;
                        }
                    }
                    
                case '-':
                    {

                        if (broj1.Count != 0)
                        {
                            rezultat = Convert.ToString(this.Pretvorba(broj1) - this.Pretvorba(broj2));
                            broj1.Clear();
                            broj1 = rezultat.ToList<char>();
                            broj1 = new List<char>(this.Sredi(broj1));

                            prikaz = new List<char>(broj1);
                            return;

                        }
                        else
                        {
                            return;
                        }

                    }
                case '*':
                    {

                        if (broj1.Count != 0)
                        {
                            rezultat = Convert.ToString(this.Pretvorba(broj1) * this.Pretvorba(broj2));
                            broj1.Clear();
                            broj1 = rezultat.ToList<char>();
                            broj1 = new List<char>(this.Sredi(broj1));

                            prikaz = new List<char>(broj1);
                            return;

                        }
                        else
                        {
                            return;
                        }

                    }
                case '/':
                    {

                        if (broj1.Count != 0)
                        {
                            rezultat = Convert.ToString(this.Pretvorba(broj1) / this.Pretvorba(broj2));
                            broj1.Clear();
                            broj1 = rezultat.ToList<char>();
                            broj1 = new List<char>(this.Sredi(broj1));

                            prikaz = new List<char>(broj1);
                            return;

                        }
                        else
                        {
                            return;
                        }

                    }

                default:
                    {                        
                        broj1 = new List<char>(broj2);
                        if ((broj1.Count > 0) && (eq == true))
                        {
                            rezultat = Convert.ToString(this.Pretvorba(broj1));
                            broj1.Clear();
                            broj1 = rezultat.ToList<char>();
                            broj1 = new List<char>(this.Sredi(broj1));
                            prikaz = new List<char>(broj1);
                        }
                        return;
                    }
            }
                
        }

        private void IzracunaUnarno(char unarno)
        {
            if (tempBroj.Count > 0)
            {
                rezultat = Convert.ToString((this.Pretvorba(tempBroj)) * (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                    tempBroj = new List<char>(prikaz);
                }

                return;
            }
            else if (broj1.Count > 0)
            {
                rezultat = Convert.ToString((this.Pretvorba(broj1)) * (this.Pretvorba(broj1)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    broj1.Clear();
                    broj1 = rezultat.ToList<char>();
                    broj1 = new List<char>(this.Sredi(broj1));
                    prikaz = new List<char>(broj1);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }
            }
            else
            {
                tempBroj = new List<char>(prikaz);
                rezultat = Convert.ToString((this.Pretvorba(tempBroj)) * (this.Pretvorba(tempBroj)));
                if ((operacija == ' ') || (operacija == '\0'))
                {
                    tempBroj.Clear();
                    tempBroj = rezultat.ToList<char>();
                    tempBroj = new List<char>(this.Sredi(tempBroj));
                    prikaz = new List<char>(tempBroj);
                }
                else
                {
                    prikaz.Clear();
                    tempBroj.Clear();
                    prikaz = rezultat.ToList<char>();
                    prikaz = new List<char>(this.Sredi(prikaz));
                    broj2 = new List<char>(prikaz);
                }

                return;
            }

        }

        private void Clear()
        {
            tempBroj.Clear();
            prikaz.Clear();
        }

        private void Reset()
        {           
            broj1.Clear();
            broj2.Clear();
            tempBroj.Clear();
            prikaz.Clear();
            operacija = ' ';
            eq = false;
            prikaz.Add('0');
        }

        private double Pretvorba(List<char> zadaniBroj)
        {
            return double.Parse(string.Join("", zadaniBroj));
        }

        private List<char> Sredi(List<char> zadaniBroj)
        {
            int maxBrojZnakova;
            char zadnji = '0';

            if (zadaniBroj.Contains(',') && zadaniBroj.Contains('-'))
            {
                maxBrojZnakova = 12;
                while (zadaniBroj.Count > maxBrojZnakova)
                {
                    zadnji = zadaniBroj[zadaniBroj.Count - 1];
                    zadaniBroj.RemoveAt(zadaniBroj.Count - 1);
                    if ((zadaniBroj[zadaniBroj.Count - 1] == ',') && (zadaniBroj.Count > 12))
                    {
                        zadaniBroj.Clear();
                        zadaniBroj.Add('-'); zadaniBroj.Add('E'); zadaniBroj.Add('-');
                        return zadaniBroj;                        
                    }
                }
                if ((int)char.GetNumericValue(zadnji) > 4) zadaniBroj[zadaniBroj.Count - 1] = ((int)char.GetNumericValue(zadaniBroj[zadaniBroj.Count - 1]) + 1).ToString()[0];
                while (zadaniBroj[zadaniBroj.Count - 1] == '0')
                {
                    zadaniBroj.RemoveAt(zadaniBroj.Count - 1);
                }
            }
                

            else if (zadaniBroj.Contains(','))
            {
                maxBrojZnakova = 11;
                while (zadaniBroj.Count > maxBrojZnakova)
                {
                    zadnji = zadaniBroj[zadaniBroj.Count - 1];                    
                    zadaniBroj.RemoveAt(zadaniBroj.Count - 1);
                    if ((zadaniBroj[zadaniBroj.Count - 1] == ',') && (zadaniBroj.Count > 11))
                    {
                        zadaniBroj.Clear();
                        zadaniBroj.Add('-'); zadaniBroj.Add('E'); zadaniBroj.Add('-');
                        return zadaniBroj;
                    }
                }
                if ((int)char.GetNumericValue(zadnji) > 4) zadaniBroj[zadaniBroj.Count - 1] = ((int)char.GetNumericValue(zadaniBroj[zadaniBroj.Count - 1]) + 1).ToString()[0];
                while (zadaniBroj[zadaniBroj.Count - 1] == '0')
                {
                    zadaniBroj.RemoveAt(zadaniBroj.Count - 1);
                }
                
            }

            else if (zadaniBroj.Contains('-'))
            {
                maxBrojZnakova = 11;
                if (zadaniBroj.Count > maxBrojZnakova)
                {
                    zadaniBroj.Clear();
                    zadaniBroj.Add('-'); zadaniBroj.Add('E'); zadaniBroj.Add('-');
                    return zadaniBroj;
                }
            }

            else if (zadaniBroj.Contains('I'))
            {
                zadaniBroj.Clear();
                zadaniBroj.Add('-'); zadaniBroj.Add('E'); zadaniBroj.Add('-');
                return zadaniBroj;
            }

            else
            {
                maxBrojZnakova = 10;
                if (zadaniBroj.Count > 10)
                {
                    zadaniBroj.Clear();
                    zadaniBroj.Add('-'); zadaniBroj.Add('E'); zadaniBroj.Add('-');
                    return zadaniBroj;
                }
            } 

            return zadaniBroj;

            
        }
    }

    
}
