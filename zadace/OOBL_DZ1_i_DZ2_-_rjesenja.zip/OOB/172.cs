﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string currentOperator = null; //trenutni operator koji se treba izvršiti (+-*/)
        private string calculatorMemory = null; 
        private string currentDisplayState = null; 
        private string firstOperand = null; //prva varijabla kod racunanja
        private string secondOperand = null; //druga var kod racunanja
        private bool isDecimal = false; 
        private string lastKeyPressed = null; 

        public void Press(char inPressedDigit)
        {
            if (char.IsNumber(inPressedDigit))
                this.NumberPressed(inPressedDigit); //poziva metodu koja obradjuje pritisak znamenke
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
                this.OperatorPressed(inPressedDigit); //poziva metodu koja obradjuje pritisak operatora
            else if (char.IsLetter(inPressedDigit))
                this.FunctionPressed(inPressedDigit); //poziva metodu koja obradjuje pritisak fje(sin, cos..)
            else if (inPressedDigit == ',') //obrada pritiska zareza, ne dopusta vise zareza
            {
                if (!this.isDecimal)
                {
                    if (this.currentDisplayState == null || this.lastKeyPressed == "Fun")
                    {
                        this.currentDisplayState = "0,";
                        this.isDecimal = true;
                    }
                    else
                    {
                        this.currentDisplayState += ",";
                        this.isDecimal = true;
                    }
                }
                this.lastKeyPressed = "Comma";
            }
            else if (inPressedDigit == '=') //obrada pritiska =, poziva metodu koja racuna
            {
                this.secondOperand = this.GetCurrentDisplayState();
                this.Calculate('=');
                this.lastKeyPressed = "=";
            }
        }

        public string GetCurrentDisplayState()
        {
            if (this.currentDisplayState == null)
                return "0";
            //nakon pritiska operatora ili zareza, provjera nalaze li se nule viska
            else if ((lastKeyPressed == "Op" || lastKeyPressed == "=" || lastKeyPressed == "Comma") && this.currentDisplayState.Contains(','))
            {
                this.RoundDigitsOnDisplay();
                string tmpDisplayState = this.currentDisplayState.Substring(this.currentDisplayState.IndexOf(','), this.currentDisplayState.Length - this.currentDisplayState.IndexOf(','));
                //ako u podstringu od zareza(ukljucujuci) postoje samo nule, brisi decimalni dio
                if ((tmpDisplayState.Count(p => p == '0') == tmpDisplayState.Length - 1) && tmpDisplayState.Length != 1)
                {
                    this.currentDisplayState = this.currentDisplayState.Substring(0, this.currentDisplayState.IndexOf(','));
                    return this.currentDisplayState;
                }
                else
                {
                    while ((this.currentDisplayState[this.currentDisplayState.Length - 1] == '0') || (this.currentDisplayState[this.currentDisplayState.Length - 1] == ','))
                    {
                        this.currentDisplayState = this.currentDisplayState.Substring(0, this.currentDisplayState.Length - 1);
                    }
                    return this.currentDisplayState;
                }
            }
            else
            {
                this.RoundDigitsOnDisplay();
                return this.currentDisplayState;
            }
        }
        /// <summary>
        ///  metoda obrade pritiska znamenke
        /// </summary>
        private void NumberPressed(char inPressedDigit)
        {
            if (this.currentDisplayState != null && this.lastKeyPressed != "Op" && this.currentDisplayState != "0")
                this.currentDisplayState += inPressedDigit.ToString();
            else if (inPressedDigit != '0')
                this.currentDisplayState = inPressedDigit.ToString();
            this.lastKeyPressed = "Num";
        }
        /// <summary>
        /// metoda obrade pritiska operatora +-*/
        /// </summary>
        private void OperatorPressed(char inPressedDigit)
        {
            if (this.currentOperator == null)
            {
                this.firstOperand = this.GetCurrentDisplayState();
                this.currentOperator = inPressedDigit.ToString();
                this.isDecimal = false;
            }
            else if(this.lastKeyPressed == "Op") //uzastopni pritisak vise operatora, pamti se zadnji
            {
                this.currentOperator = inPressedDigit.ToString();
            }
            else 
            {
                this.secondOperand = this.GetCurrentDisplayState();
                this.Calculate(inPressedDigit);
            }
            this.lastKeyPressed = "Op";
        }
        /// <summary>
        /// metoda koja se poziva kada imamo dvije varijable i operator te se pritisne novi operator
        /// -potrebno izracunati prijasnje
        /// </summary>
        private void Calculate(char newOperator)
        {
            decimal result = 0;
            switch (this.currentOperator)
            {
                case "+":
                    result = Convert.ToDecimal(this.firstOperand) + Convert.ToDecimal(this.secondOperand);
                    break;
                case "-":
                    result = Convert.ToDecimal(this.firstOperand) - Convert.ToDecimal(this.secondOperand);
                    break;
                case "*":
                    result = Convert.ToDecimal(this.firstOperand) * Convert.ToDecimal(this.secondOperand);
                    break;
                case "/":
                    if (this.secondOperand == "0")
                        this.currentDisplayState = "-E-";
                    else
                        result = Convert.ToDecimal(this.firstOperand) + Convert.ToDecimal(this.secondOperand);
                    break;
                default:
                    this.isDecimal = false;
                    this.firstOperand = null;
                    this.secondOperand = null;
                    return;
            }
            if (this.currentDisplayState != "-E-")
            {
                this.firstOperand = result.ToString();
                if (newOperator != '=')
                    this.currentOperator = newOperator.ToString();
                else
                    this.currentOperator = null;
                this.currentDisplayState = result.ToString();
                this.secondOperand = null;
                this.isDecimal = false;
            }
            else //ako je greska, reset sve
            {
                this.currentDisplayState = null;
                this.isDecimal = false;
                this.currentOperator = null;
                this.firstOperand = null;
                this.secondOperand = null;
            }
        }
        /// <summary>
        /// metoda koja obradjuje pritisak funkcijskih tipki (sin, cos...)
        /// ako je prije pritisnut operator (+-*/), dobiveni rezultat funkcijom se ne racuna u zbrajanju, oduzimanju etc
        /// </summary>
        private void FunctionPressed(char function)
        {
            switch (function)
            {
                case 'M':
                    if (this.currentDisplayState[0] == '-')
                        this.currentDisplayState = this.currentDisplayState.Remove(0, 1);
                    else
                        this.currentDisplayState = "-" + this.currentDisplayState;
                    break;
                case 'S':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    this.currentDisplayState = Math.Sin(Convert.ToDouble(this.currentDisplayState)).ToString();
                    break;
                case 'K':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    this.currentDisplayState = Math.Cos(Convert.ToDouble(this.currentDisplayState)).ToString();
                    break;
                case 'T':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    try
                    {
                        this.currentDisplayState = Math.Tan(Convert.ToDouble(this.currentDisplayState)).ToString();
                    }
                    catch (Exception e)         // tangens kuta pi/2 je invalid
                    {
                        this.currentDisplayState = "-E-";
                    }
                    break;
                case 'Q':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    this.currentDisplayState = (Convert.ToDecimal(this.currentDisplayState) * Convert.ToDecimal(this.currentDisplayState)).ToString();
                    break;
                case 'R':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    this.currentDisplayState = Math.Sqrt(Convert.ToDouble(this.currentDisplayState)).ToString();
                    break;
                case 'I':
                    if (lastKeyPressed == "Op")
                        this.firstOperand = this.currentDisplayState;
                    else
                        this.lastKeyPressed = "Fun";
                    if (this.currentDisplayState == "0" || this.currentDisplayState == null)
                        this.currentDisplayState = "-E-";
                    else
                        this.currentDisplayState = (1 / Convert.ToDecimal(this.currentDisplayState)).ToString();
                    break;
                case 'P':
                    this.calculatorMemory = this.currentDisplayState;
                    break;
                case 'G':
                    this.currentDisplayState = this.calculatorMemory;
                    break;
                case 'C':
                    this.currentDisplayState = null; //clear brise samo ekran
                    break;
                case 'O':
                    this.currentDisplayState = null; //on/off tipka, resetira sve
                    this.firstOperand = null;
                    this.secondOperand = null;
                    this.isDecimal = false;
                    this.currentOperator = null;
                    this.calculatorMemory = null;
                    break;
            }
        }
        /// <summary>
        /// metoda koja provjerava koliko je znamenaka prikazano na ekranu
        /// mora bit manje od 10; - i , se ne ubrajaju
        /// </summary>
        private void RoundDigitsOnDisplay()
        {
            int numberOfDecimals;
            decimal tmpDecimal;
            if (this.currentDisplayState.Contains(',') == false)
            {
                if (this.currentDisplayState.Length > 10) //ako je cjelobrojni dio >10, greska
                {
                    this.currentDisplayState = "-E-";
                    return;
                }
                else return;
            }
            else if (this.currentDisplayState.IndexOf(',') > 10) //ako je cjelobrojni dio >10, greska
            {
                this.currentDisplayState = "-E-";
                return;
            }
            else
            {
                //dok ima vise od 10 znamenaka, zaokruzuj na jednu manje decimalu
                while (this.currentDisplayState.Count(p => char.IsNumber(p)) > 10)
                {
                    if (this.currentDisplayState[this.currentDisplayState.Length - 1] == ',')
                        this.currentDisplayState = this.currentDisplayState.Substring(0, this.currentDisplayState.Length - 1);
                    else
                    {
                        numberOfDecimals = this.currentDisplayState.Length - this.currentDisplayState.IndexOf(',') - 1;
                        tmpDecimal = Convert.ToDecimal(this.currentDisplayState);
                        tmpDecimal = Math.Round(tmpDecimal, (numberOfDecimals - 1));
                        this.currentDisplayState = tmpDecimal.ToString();
                    }
                }
            }
        }
    }
}