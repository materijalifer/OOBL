﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        public Dictionary<string, Stock> listOfStocks = new Dictionary<string, Stock>();
        public Dictionary<string, Index> listOfIndices = new Dictionary<string, Index>();
        public Dictionary<string, Portfolio> listOfPortfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                throw new StockExchangeException("error");
            }
            else
            {
                Stock s = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                this.listOfStocks.Add(s.Name, s);
            }
        }

        public void DelistStock(string inStockName)
        {
            string name = inStockName.ToUpperInvariant();

            if (listOfStocks.ContainsKey(name))
            {
                this.listOfStocks.Remove(name);

                foreach (string i in listOfIndices.Keys.Where(i => listOfIndices[i].IsStockPartOfIndex(name)))
                {
                    listOfIndices[i].RemoveStock(name);
                }

                foreach (string j in from string j in listOfPortfolios.Keys where listOfPortfolios[j].IsStockPartOfPortfolio(name) select j)
                {
                    listOfPortfolios[j].RemoveStockFromPortfolio(name);
                }

            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public bool StockExists(string inStockName)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfStocks()
        {
            return this.listOfStocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                this.listOfStocks[inStockName.ToUpperInvariant()].SetStockPrice(inIimeStamp, inStockValue);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                return this.listOfStocks[inStockName.ToUpperInvariant()].CurrentPrice(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("error");
            }
            
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                return this.listOfStocks[inStockName.ToUpperInvariant()].GetInitialStockPrice();
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
            {
                return this.listOfStocks[inStockName.ToUpperInvariant()].GetLastStockPrice();
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            string indexName = inIndexName.ToUpperInvariant();

            if (this.listOfIndices.ContainsKey(indexName))
            {
                throw new StockExchangeException("error");
            }
            else
            {
                if (inIndexType == IndexTypes.AVERAGE)
                {
                    this.listOfIndices.Add(indexName, new Average(inIndexName));
                }
                else if (inIndexType == IndexTypes.WEIGHTED)
                {
                    this.listOfIndices.Add(indexName, new Weighted(inIndexName));
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            string name = inStockName.ToUpperInvariant();
            string indexName = inIndexName.ToUpperInvariant();

            if (this.listOfStocks.ContainsKey(name))
            {
                if (this.listOfIndices.ContainsKey(indexName))
                {
                    this.listOfIndices[indexName].AddStock(this.listOfStocks[name]);
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            string name = inStockName.ToUpperInvariant();
            string indexName = inIndexName.ToUpperInvariant();

            if (this.listOfStocks.ContainsKey(name))
            {
                if (this.listOfIndices.ContainsKey(indexName))
                {
                    this.listOfIndices[indexName].RemoveStock(name);
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            string indexName = inIndexName.ToUpperInvariant();

            if (this.listOfIndices.ContainsKey(indexName))
            {
                return this.listOfIndices[indexName].IsStockPartOfIndex(inStockName);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (this.listOfIndices.ContainsKey(inIndexName.ToUpperInvariant()))
            {
                return this.listOfIndices[inIndexName.ToUpperInvariant()].GetIndexValue(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            if (this.listOfIndices.ContainsKey(inIndexName.ToUpperInvariant()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfIndices()
        {
            return this.listOfIndices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (this.listOfIndices.ContainsKey(inIndexName.ToUpperInvariant()))
            {
                return this.listOfIndices[inIndexName.ToUpperInvariant()].NumberOfStocksInIndex();
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("error");
            }
            else
            {
                this.listOfPortfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string name = inStockName.ToUpperInvariant();

            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                if (this.listOfStocks.ContainsKey(name))
                {
                    if (this.listOfStocks[name].Available >= numberOfShares)
                    {
                        this.listOfStocks[name].Available -= numberOfShares;
                        Stock s = new Stock(inStockName, numberOfShares, this.listOfStocks[name].Value);
                        this.listOfPortfolios[inPortfolioID].AddStockToPortfolio(s);
                    }
                    else
                    {
                        throw new StockExchangeException("error");
                    }
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                string name = inStockName.ToUpperInvariant();

                if (this.listOfStocks.ContainsKey(name))
                {
                    this.listOfPortfolios[inPortfolioID].RemoveStockFromPortfolio(inStockName, numberOfShares);
                    this.listOfStocks[name].Available += numberOfShares;
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                if (this.listOfStocks.ContainsKey(inStockName.ToUpperInvariant()))
                {
                    this.listOfPortfolios[inPortfolioID].RemoveStockFromPortfolio(inStockName);
                }
                else
                {
                    throw new StockExchangeException("error");
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public int NumberOfPortfolios()
        {
           return this.listOfPortfolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return this.listOfPortfolios[inPortfolioID].NumberOfStocksInPortfolio();
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return this.listOfPortfolios[inPortfolioID].IsStockPartOfPortfolio(inStockName);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return this.listOfPortfolios[inPortfolioID].NumberOfSharesOfStockInPortfolio(inStockName);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return this.listOfPortfolios[inPortfolioID].GetPortfolioValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (this.listOfPortfolios.ContainsKey(inPortfolioID))
            {
                return this.listOfPortfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }
    }

    public class Stock
    {
        private string name;
        private long numberOfShares;
        private long available;

        private Dictionary<DateTime, decimal> value = new Dictionary<DateTime, decimal>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares < 0 || inNumberOfShares == 0 || inInitialPrice < 0 || inInitialPrice == 0)
            {
                throw new StockExchangeException("error");
            }
            else
            {
                this.name = inStockName.ToUpperInvariant();
                this.numberOfShares = this.available = inNumberOfShares;
                this.value.Add(inTimeStamp, inInitialPrice); 
            }     
        }

        public Stock(string inStockName, long inNumberOfShares, Dictionary<DateTime, decimal> value)
        {
            if (inNumberOfShares < 0 || inNumberOfShares == 0)
            {
                throw new StockExchangeException("error");
            }
            else
            {
                this.name = inStockName.ToUpperInvariant();
                this.numberOfShares = this.available = inNumberOfShares;
                this.value = value;
            }
        }

        public void SetStockPrice(DateTime inIimeStamp, decimal inStockValue)
        {
           if (this.value.Keys.Contains(inIimeStamp) || inStockValue < 0)
           {
               throw new StockExchangeException("error");
           }
           else
           {
               this.value.Add(inIimeStamp, inStockValue);
           }
        }

        public decimal CurrentPrice(DateTime time)
        {
            DateTime currentClose = DateTime.MinValue;

            foreach (DateTime t in this.value.Keys)
            {
                if (t <= time)
                {
                    if (t >= currentClose)
                    {
                        currentClose = t;
                    }
                }
            }

            return this.value[currentClose];
        }

        //Vraća prvu unesenu vrijednost dionice; trenutno nejasno
        public decimal GetInitialStockPrice()
        {
            var list = this.value.Keys.ToList();
            list.Sort();

            return this.value[list.First()];
        }

        //Vraća zadnju unesenu vrijednost dionice; trenutno nejasno
        public decimal GetLastStockPrice()
        {
            var list = this.value.Keys.ToList();
            list.Sort();
            return this.value[list.Last()];
        }

        public string Name
        {
            get { return this.name; }
        }

        public Dictionary<DateTime, decimal> Value
        {
            get { return this.value; }
        }

        public long Available
        {
            get { return this.available; }
            set { this.available = value; }
        }

        public long NumberOfShares
        {
            get { return this.numberOfShares; }
            set { this.numberOfShares = value; }
        }
    }

    public abstract class Index
    {
        public string name;

        public Dictionary<string, Stock> stockList = new Dictionary<string, Stock>();

        public Index(string name)
        {
            this.name = name.ToUpperInvariant();
        }

        public void AddStock(Stock stock)
        {
            if (this.stockList.ContainsKey(stock.Name))
            {
                throw new StockExchangeException("error");
            }
            else
            {
                this.stockList.Add(stock.Name, stock);
            }
        }

        public void RemoveStock(string inStockName)
        {
            if (this.stockList.ContainsKey(inStockName))
            {
                this.stockList.Remove(inStockName
                    );
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public bool IsStockPartOfIndex(string inStockName)
        {
            if (this.stockList.Keys.Contains(inStockName.ToUpperInvariant()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfStocksInIndex()
        {
            return this.stockList.Count();
        }

        public abstract decimal GetIndexValue(DateTime inTimeStamp);

    }

    public class Average : Index
    {
        public Average(string name)
            : base(name)
        {

        }

        public override  decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal average = stockList.Keys.Sum(key => stockList[key].CurrentPrice(inTimeStamp));

            try
            {
                if (stockList.Count == 0)
                {
                    return 0;
                }
                else
                {
                    return Math.Round((average / stockList.Count()), 3);
                }
            }
            catch (Exception e)
            {
                throw new StockExchangeException("error");
            }
        }
    }

    public class Weighted: Index
    {
        public Weighted(string name)
            : base(name)
        {

        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            //decimal average = stockList.Keys.Sum(key => stockList[key].CurrentPrice(inTimeStamp));

            decimal weight = stockList.Keys.Sum(key => stockList[key].CurrentPrice(inTimeStamp)*stockList[key].NumberOfShares);

            decimal result = stockList.Keys.Sum(key => (((stockList[key].CurrentPrice(inTimeStamp)/weight)*stockList[key].CurrentPrice(inTimeStamp))*stockList[key].NumberOfShares));

            try
            {
                if (stockList.Count == 0)
                {
                    return 0;
                }
                else
                {
                    return Math.Round(result, 3);
                }
            }
            catch (Exception e)
            {
                throw new StockExchangeException("error");
            }
            
        }
    }

    public class Portfolio
    {
        private Dictionary<string, Stock> stockList = new Dictionary<string, Stock>();
        private string name;

        public Portfolio(string inPortfolioID)
        {
            this.name = inPortfolioID;
        }

        public void AddStockToPortfolio(Stock stock)
        {
            if (this.stockList.ContainsKey(stock.Name))
            {
                this.stockList[stock.Name].NumberOfShares += stock.NumberOfShares;
            }
            else
            {
                this.stockList.Add(stock.Name, stock);
            }
        }

        public void RemoveStockFromPortfolio(string inStockName, int numberOfShares)
        {
            string name = inStockName.ToUpperInvariant();

            if (this.stockList.ContainsKey(name))
            {
                if ((this.stockList[name].NumberOfShares - numberOfShares) == 0)
                {
                    this.stockList.Remove(name);
                }
                else if ((this.stockList[name].NumberOfShares - numberOfShares) < 0)
                {
                    throw new StockExchangeException("error");
                }
                else
                {
                    this.stockList[name].NumberOfShares -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            string name = inStockName.ToUpperInvariant();

            if (this.stockList.ContainsKey(name))
            {
                this.stockList.Remove(name);
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public int NumberOfStocksInPortfolio()
        {
            return this.stockList.Count();
        }

        public bool IsStockPartOfPortfolio(string inStockName)
        {
            if (this.stockList.ContainsKey(inStockName.ToUpperInvariant()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            string name = inStockName.ToUpperInvariant();

            if (this.stockList.ContainsKey(name))
            {
                return (int)this.stockList[name].NumberOfShares;
            }
            else
            {
                throw new StockExchangeException("error");
            }
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            return this.stockList.Keys.Sum(key => stockList[key].CurrentPrice(timeStamp) * stockList[key].NumberOfShares);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime start = new DateTime(Year, Month, 1, 0,0,0,0);
            DateTime end = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23,59,59,999);

            decimal startMonth = this.stockList.Keys.Sum(key => stockList[key].CurrentPrice(start) * stockList[key].NumberOfShares);
            decimal endMonth = this.stockList.Keys.Sum(key => stockList[key].CurrentPrice(start) * stockList[key].NumberOfShares);

            try
            {
                return (((endMonth - startMonth)/startMonth)*100);
            }
            catch (Exception e)
            {
                throw new StockExchangeException("error");
            }
        }

        public string Name
        {
            get { return this.name; }
        }
    }
}
