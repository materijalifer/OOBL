﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Dionica
    {
        public string Naziv { get; set; }
        public long Broj { get; set; }
        public decimal Cijena { get; set; }
        public DateTime Datum { get; set; }

        public Dionica(string naziv, long broj, decimal cijena, DateTime datum)
        {
            this.Naziv = naziv;
            this.Broj = broj;
            this.Cijena = cijena;
            this.Datum = datum;
        }
    }

    public class ZapisCijenaDatum
    {
        public string Naziv { get; set; }
        public decimal Cijena { get; set; }
        public DateTime Datum { get; set; }

        public ZapisCijenaDatum(string naziv, decimal cijena, DateTime datum)
        {
            this.Naziv = naziv;
            this.Cijena = cijena;
            this.Datum = datum;
        }
    }

    public class Index
    {
        public string Naziv { get; set; }
        public IndexTypes TipIndeksa { get; set; }
           
        public Index(string naziv, IndexTypes tip)
        {
            this.Naziv = naziv;
            this.TipIndeksa = tip;
        }
    }

    public class DioniceIndexi
    {
        public string NazivIndeksa { get; set; }
        public string NazivDionice { get; set; }

        public DioniceIndexi(string nazivIndeksa, string nazivDionice)
        {
            this.NazivIndeksa = nazivIndeksa;
            this.NazivDionice = nazivDionice;
        }
    }

    public class Portfolio
    {
        public string PortfolioId { get; set; }

        public Portfolio(string id)
        {
            this.PortfolioId = id;
        }
    }

    public class DionicePortfoli
    {
        public string PortfolioId { get; set; }
        public string NazivDionice { get; set; }
        public int BrojDionica { get; set; }

        public DionicePortfoli(string portfolioId, string nazivDionice, int brojDionica)
        {
            this.PortfolioId = portfolioId;
            this.NazivDionice = nazivDionice;
            this.BrojDionica = brojDionica;
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Dionica> burza = new List<Dionica>();
         List<ZapisCijenaDatum> historyCijenaDionice = new List<ZapisCijenaDatum>();
         List<Index> listaIndexa = new List<Index>();
         List<DioniceIndexi> listaDionicaPridjeljenihIndexu = new List<DioniceIndexi>();
         List<Portfolio> listaPortfolia = new List<Portfolio>();
         List<DionicePortfoli> listaDionicaPridjeljenihPortfoliu = new List<DionicePortfoli>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (burza.Find(x => x.Naziv == inStockName.ToUpper()) != null)
             {
                 throw new StockExchangeException("Pogreška!!");
             }
             else if (inNumberOfShares <= 0 || inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Nedozvoljena vrijednost unosa!");
             }
             else
             {
                 Dionica dionica = new Dionica(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
                 burza.Add(dionica);
                 ZapisCijenaDatum zapis = new ZapisCijenaDatum(inStockName.ToUpper(), inInitialPrice, inTimeStamp);
                 historyCijenaDionice.Add(zapis);
             }
         }

         public void DelistStock(string inStockName)
         {
             if (burza.Find(x => x.Naziv == inStockName.ToUpper()) != null)
             {
                 burza.Remove(burza.Find(x => x.Naziv == inStockName.ToUpper()));

                 List<DioniceIndexi> pomocnaLista =
                     listaDionicaPridjeljenihIndexu.FindAll(x => x.NazivDionice == inStockName.ToUpper());
                 foreach (DioniceIndexi dioniceIndexi in pomocnaLista)
                 {
                     RemoveStockFromIndex(dioniceIndexi.NazivIndeksa, inStockName);
                 }

                 List<DionicePortfoli> pomocna =
                     listaDionicaPridjeljenihPortfoliu.FindAll(x => x.NazivDionice == inStockName.ToUpper());
                 foreach (DionicePortfoli dionicePortfoli in pomocna)
                 {
                     RemoveStockFromPortfolio(dionicePortfoli.PortfolioId, inStockName);
                 }
                 
                 historyCijenaDionice.RemoveAll(x => x.Naziv == inStockName.ToUpper());
                 
             }
             else
             {
                 throw new StockExchangeException("Nepostojeći zapis!");
             }
         }

         public bool StockExists(string inStockName)
         {
             if (burza.Find(x => x.Naziv == inStockName.ToUpper()) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
             
         }

         public int NumberOfStocks()
         {
             return burza.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 ZapisCijenaDatum zapis = new ZapisCijenaDatum(inStockName.ToUpper(), inStockValue, inIimeStamp);

                 if (GetStockPrice(inStockName, inIimeStamp) > 0)
                 {  //ako ne postoji zapis sa istim datumom i vremenom => dodaj zapis u listu
                     historyCijenaDionice.Add(zapis);
                     historyCijenaDionice = historyCijenaDionice.OrderBy(x => x.Naziv).ThenBy(x => x.Datum).ToList();
                     Dionica dionicaZaUsporedbu = burza.Find(x => x.Naziv == inStockName.ToUpper());

                     if (dionicaZaUsporedbu.Datum <= inIimeStamp)
                     {   //ukoliko je novi zapis najsvjeziji izmjeni cijenu i datum dionice
                         burza.Remove(burza.Find(x => x.Naziv == inStockName.ToUpper()));
                         ListStock(inStockName.ToUpper(), dionicaZaUsporedbu.Broj, inStockValue, inIimeStamp);
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Nepostojeći zapis!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             ZapisCijenaDatum pomocniZapis = null;
             List<ZapisCijenaDatum> pomocnaLista = historyCijenaDionice.FindAll(x => x.Naziv == inStockName.ToUpper());
             if (pomocnaLista.Count > 0)
             {
                 foreach (var zapisCijenaDatum in pomocnaLista)
                 {
                     if (zapisCijenaDatum.Datum <= inTimeStamp)
                     {
                         pomocniZapis = zapisCijenaDatum;
                     }
                 }
                 if (pomocniZapis != null)
                 {
                     return pomocniZapis.Cijena;
                 }
                 else
                 {
                     throw new StockExchangeException("Nepostojeći zapis!");
                 }
             }
             else
             {
                 throw new StockExchangeException("Nepostojeći zapis!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             List<ZapisCijenaDatum> pomocnaLista = historyCijenaDionice.FindAll(x => x.Naziv == inStockName.ToUpper());
             if (pomocnaLista.Count > 0)
             {
                 pomocnaLista = pomocnaLista.OrderBy(x => x.Datum).ToList();
                 return pomocnaLista.First().Cijena;
             }
             else
             {
                 throw new StockExchangeException("Nepostojeći zapis!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Dionica pomocna = burza.Find(x => x.Naziv == inStockName.ToUpper());
             if (pomocna != null)
             {
                 return pomocna.Cijena;
             }
             else
             {
                 throw new StockExchangeException("Nepostojeći zapis!");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if ((inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED) && !IndexExists(inIndexName))
             {
                 Index indeks = new Index(inIndexName.ToUpper(), inIndexType);
                 listaIndexa.Add(indeks);
             }
             else
             {
                 throw new StockExchangeException("Nedozvoljeni unos!");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName) && IndexExists(inIndexName) && !IsStockPartOfIndex(inIndexName, inStockName))
             {
                 DioniceIndexi noviZapis = new DioniceIndexi(inIndexName.ToUpper(), inStockName.ToUpper());
                 listaDionicaPridjeljenihIndexu.Add(noviZapis);
             }
             else
             {
                 throw new StockExchangeException("Nedozvoljeni unos!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 listaDionicaPridjeljenihIndexu.Remove(
                     listaDionicaPridjeljenihIndexu.Find(
                         x => x.NazivIndeksa == inIndexName.ToUpper() && x.NazivDionice == inStockName.ToUpper()));
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             List<DioniceIndexi> pomocnaLista =
                 listaDionicaPridjeljenihIndexu.FindAll(x => x.NazivIndeksa == inIndexName.ToUpper());
             DioniceIndexi pomocna = pomocnaLista.Find(x => x.NazivDionice == inStockName.ToUpper());
             
             if (pomocna != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             decimal indexValue;
             if (IndexExists(inIndexName.ToUpper()))
             {
                 Index pomocna = listaIndexa.Find(x => x.Naziv == inIndexName.ToUpper());
                 if (pomocna.TipIndeksa == IndexTypes.AVERAGE)
                 {
                     indexValue = GetIndexValueAverage(inIndexName, inTimeStamp);
                 }
                 else
                 {
                     indexValue = GetIndexValueWeighted(inIndexName, inTimeStamp);
                 }
                 return indexValue;
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public decimal GetIndexValueAverage(string inIndexName, DateTime inTimeStamp)
         {
             decimal indexValue = 0;
             List<DioniceIndexi> pomocnaLista =
                 listaDionicaPridjeljenihIndexu.FindAll(x => x.NazivIndeksa == inIndexName.ToUpper());
             foreach (var dioniceIndexi in pomocnaLista)
             {
                 indexValue += historyCijenaDionice.FindLast(x => x.Naziv == dioniceIndexi.NazivDionice && x.Datum <= inTimeStamp).Cijena;
                 
             }
             if (NumberOfStocksInIndex(inIndexName) > 0)
             {
                 indexValue /= NumberOfStocksInIndex(inIndexName);
             }
             else
             {
                 indexValue = 0;
             }

             return Math.Round(indexValue, 3);
             
         }

         public decimal GetIndexValueWeighted(string inIndexName, DateTime inTimeStamp)
         {
             decimal indexValue = 0;
             decimal ukupnaVrijednostDionicaUnutarIndexa = 0;
             decimal[] tezinskiFaktorDionice = new decimal[burza.Count];
             int i = 0;
             List<DioniceIndexi> pomocnaLista =
                 listaDionicaPridjeljenihIndexu.FindAll(x => x.NazivIndeksa == inIndexName.ToUpper());
             foreach (var dioniceIndexi in pomocnaLista)
             {
                 ukupnaVrijednostDionicaUnutarIndexa +=
                     historyCijenaDionice.FindLast(x => x.Naziv == dioniceIndexi.NazivDionice && x.Datum <= inTimeStamp).Cijena* 
                     burza.Find(x => x.Naziv == dioniceIndexi.NazivDionice).Broj;
             }

             foreach (var dioniceIndexi in pomocnaLista)
             {  //racuna tezinski faktor za svaku dionicu
                 tezinskiFaktorDionice[i] =
                     historyCijenaDionice.FindLast(x => x.Naziv == dioniceIndexi.NazivDionice && x.Datum <= inTimeStamp).Cijena/
                     ukupnaVrijednostDionicaUnutarIndexa;
                 i++;
             }

             i = 0;

             foreach (var dioniceIndexi in pomocnaLista)
             {
                 indexValue += historyCijenaDionice.FindLast(x => x.Naziv == dioniceIndexi.NazivDionice && x.Datum <= inTimeStamp).Cijena*
                               burza.Find(x => x.Naziv == dioniceIndexi.NazivDionice).Broj*
                               tezinskiFaktorDionice[i];
                 i++;
             }
             return Math.Round(indexValue, 3);
         }

         public bool IndexExists(string inIndexName)
         {
             if (listaIndexa.Find(x => x.Naziv == inIndexName.ToUpper()) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return listaIndexa.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 List<DioniceIndexi> pomocnaLista =
                     listaDionicaPridjeljenihIndexu.FindAll(x => x.NazivIndeksa == inIndexName.ToUpper());
                 return pomocnaLista.Count;
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 listaPortfolia.Add(portfolio);
             }
             else
             {
                 throw new StockExchangeException("Zapis vec postoji!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (StockExists(inStockName) && PortfolioExists(inPortfolioID) && numberOfShares > 0)
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()))
                 {
                     numberOfShares = numberOfShares +
                                      NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName.ToUpper());
                     if (numberOfShares > burza.Find(x => x.Naziv == inStockName.ToUpper()).Broj)
                     {
                         throw new StockExchangeException("Nema toliko dionica na raspolaganju!");
                     }
                     RemoveStockFromPortfolio(inPortfolioID, inStockName.ToUpper());
                 }
                 DionicePortfoli nova = new DionicePortfoli(inPortfolioID, inStockName.ToUpper(), numberOfShares);
                 listaDionicaPridjeljenihPortfoliu.Add(nova);
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()) && numberOfShares > 0)
             {
                 DionicePortfoli pomocna = listaDionicaPridjeljenihPortfoliu.Find(
                     x => x.NazivDionice == inStockName.ToUpper() && x.PortfolioId == inPortfolioID);
                 if ((pomocna.BrojDionica - numberOfShares) <= 0)
                 {
                     RemoveStockFromPortfolio(inPortfolioID, inStockName.ToUpper());
                 }
                 else
                 {
                     pomocna.BrojDionica = pomocna.BrojDionica - numberOfShares;
                     RemoveStockFromPortfolio(inPortfolioID, inStockName.ToUpper());
                     listaDionicaPridjeljenihPortfoliu.Add(pomocna);
                 }
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()))
             {
                 listaDionicaPridjeljenihPortfoliu.Remove(
                     listaDionicaPridjeljenihPortfoliu.Find(
                         x => x.NazivDionice == inStockName.ToUpper() && x.PortfolioId == inPortfolioID));
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public int NumberOfPortfolios()
         {
             return listaPortfolia.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 int brojDionica = 0;
                 List<DionicePortfoli> pomocna =
                     listaDionicaPridjeljenihPortfoliu.FindAll(x => x.PortfolioId == inPortfolioID);
                 foreach (var x in pomocna)
                 {
                     brojDionica++;
                 }
                 return brojDionica;
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (listaPortfolia.Find(x => x.PortfolioId == inPortfolioID) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (listaDionicaPridjeljenihPortfoliu.Find(
                 x => x.PortfolioId == inPortfolioID && x.NazivDionice == inStockName.ToUpper()) != null)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()))
                 {
                     DionicePortfoli pomocna =
                         listaDionicaPridjeljenihPortfoliu.Find(x => x.PortfolioId == inPortfolioID && x.NazivDionice == inStockName.ToUpper());
                     return pomocna.BrojDionica;
                 }
                 else
                 {
                     throw new StockExchangeException("Nepostojeci zapis!");
                 }
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 decimal vrijednostPortfelja = 0;
                 List<DionicePortfoli> pomocnaLista =
                     listaDionicaPridjeljenihPortfoliu.FindAll(x => x.PortfolioId == inPortfolioID);
                 foreach (DionicePortfoli dionicePortfoli in pomocnaLista)
                 {
                     vrijednostPortfelja +=
                         historyCijenaDionice.FindLast(
                             x => x.Naziv == dionicePortfoli.NazivDionice && x.Datum <= timeStamp).Cijena*
                         NumberOfSharesOfStockInPortfolio(dionicePortfoli.PortfolioId, dionicePortfoli.NazivDionice);
                 }
                 return Math.Round(vrijednostPortfelja, 3);
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 List<DionicePortfoli> pomocnaLista =
                     listaDionicaPridjeljenihPortfoliu.FindAll(x => x.PortfolioId == inPortfolioID);
                 foreach (DionicePortfoli dionicePortfoli in pomocnaLista)
                 {
                     if (historyCijenaDionice.FindLast(
                         x =>
                         x.Naziv == dionicePortfoli.NazivDionice.ToUpper() &&
                         x.Datum <= new DateTime(Year, Month, 1, 00, 00, 00, 00)) == null)
                     {
                         throw new StockExchangeException("Nije moguce izracunati mjesecnu promjenu!");
                     }
                 }
                 if (GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 00)) > 0)
                 {
                     decimal mjesecnaPromjena =
                         (GetPortfolioValue(inPortfolioID,
                                            new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) -
                          GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 00)))/
                         GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 00))*100;

                     return Math.Round(mjesecnaPromjena, 3);
                 }
                 else
                 {
                     return 0;
                 }
             }
             else
             {
                 throw new StockExchangeException("Nepostojeci zapis!");
             }
         }
     }
}
