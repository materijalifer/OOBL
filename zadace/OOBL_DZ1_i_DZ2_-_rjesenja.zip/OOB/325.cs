﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    /// <summary>
    /// Klasa tvornica koja stvara objekt za burzu.
    /// </summary>
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
	
    public class StockExchange : IStockExchange
    {
        private static Dictionary<string, StockExtra> _stocks;
        private Dictionary<string, Index> indices;
        private Dictionary<string, Portfolio> portfolios;

        public StockExchange()
        {
            _stocks = new Dictionary<string, StockExtra>();
            indices = new Dictionary<string, Index>();
            portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            var stockNameLowercase = inStockName.ToLower();
            if(_stocks.ContainsKey(stockNameLowercase)) throw new StockExchangeException("Dionica '" + inStockName + 
                "'vec postoji na burzi!");
            
            _stocks.Add(stockNameLowercase,
                new StockExtra(stockNameLowercase, inNumberOfShares, inTimeStamp, inInitialPrice));
        }

        public void DelistStock(string inStockName)
        {
            // treba li bacit exception ako ta dionica ne postoji?!?!?!
            // integritet burze? Sta s indeksima i portfeljima koji sadrze tu dionicu?!?!?!?!
            var stockNameLowercase = inStockName.ToLower();
            foreach(var key in indices.Keys)
            {
                if(indices[key].ContainsStock(stockNameLowercase))
                    indices[key].RemoveStock(stockNameLowercase);
            }
            foreach (var key in portfolios.Keys)
            {
                if(portfolios[key].ContainsStock(stockNameLowercase))
                    portfolios[key].RemoveStock(stockNameLowercase);
            }
            _stocks.Remove(stockNameLowercase);
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.ContainsKey(inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var stockNameLowercase = inStockName.ToLower();
            if (!_stocks.ContainsKey(stockNameLowercase)) throw new StockExchangeException("Dionica '" + inStockName + 
                "'ne postoji na burzi!");

            _stocks[stockNameLowercase].AddNewPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stockNameLowercase = inStockName.ToLower();
            if (!_stocks.ContainsKey(stockNameLowercase)) throw new StockExchangeException("Dionica '" + inStockName +
                "'ne postoji na burzi!");

            return _stocks[stockNameLowercase].GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            var stockNameLowercase = inStockName.ToLower();
            if (!_stocks.ContainsKey(stockNameLowercase)) throw new StockExchangeException("Dionica '" + inStockName +
                "'ne postoji na burzi!");

            return _stocks[stockNameLowercase].GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            var stockNameLowercase = inStockName.ToLower();
            if (!_stocks.ContainsKey(stockNameLowercase)) throw new StockExchangeException("Dionica '" + inStockName +
                "'ne postoji na burzi!");

            return _stocks[stockNameLowercase].GetLatestPrice();
        }

        public static decimal StaticGetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stockNameLower = inStockName.ToLower();

            if(!_stocks.Any()) throw new StockExchangeException("Ne postoje dionice na burzi!");
            if(!_stocks.ContainsKey(stockNameLower)) throw new StockExchangeException("Ne postoji dionica " + inStockName);

            return _stocks[stockNameLower].GetPrice(inTimeStamp);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            var indexNameLower = inIndexName.ToLower();
            if(indices.ContainsKey(indexNameLower)) throw new StockExchangeException("Indeks " + inIndexName
                + " vec postoji");

            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    indices.Add(indexNameLower,
                        new IndexAverage(indexNameLower));
                    break;
                case IndexTypes.WEIGHTED:
                    indices.Add(indexNameLower,
                        new IndexWeighted(indexNameLower));
                    break;
                default:
                    throw new StockExchangeException("Ne postoji takav indeks!");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var stockNameLower = inStockName.ToLower();
            var indexNameLower = inIndexName.ToLower();
            if(!indices.ContainsKey(indexNameLower)) throw new StockExchangeException("Ne postoji indeks " + inIndexName);
            if(!_stocks.ContainsKey(stockNameLower)) throw new StockExchangeException("Ne postoji dionica " + inStockName);

            indices[indexNameLower].AddStock(new Stock(_stocks[stockNameLower].Stock));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var stockNameLower = inStockName.ToLower();
            var indexNameLower = inIndexName.ToLower();
            if (!indices.ContainsKey(indexNameLower)) throw new StockExchangeException("Ne postoji indeks " + inIndexName);
            if (!_stocks.ContainsKey(stockNameLower)) throw new StockExchangeException("Ne postoji dionica " + inStockName);

            indices[indexNameLower].RemoveStock(stockNameLower);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var stockNameLower = inStockName.ToLower();
            var indexNameLower = inIndexName.ToLower();
            if (!indices.ContainsKey(indexNameLower)) throw new StockExchangeException("Ne postoji indeks " + inIndexName);
            if (!_stocks.ContainsKey(stockNameLower)) throw new StockExchangeException("Ne postoji dionica " + inStockName);

            return indices[indexNameLower].ContainsStock(stockNameLower);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var indexNameLower = inIndexName.ToLower();
            if (!indices.ContainsKey(indexNameLower)) throw new StockExchangeException("Ne postoji indeks " + inIndexName);

            return indices[indexNameLower].CalculateAverage(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return indices.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if(!indices.ContainsKey(inIndexName.ToLower())) throw new StockExchangeException("Indeks " +
                inIndexName + " ne postoji!");

            return indices[inIndexName.ToLower()].NumOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if(portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " vec postoji!");

            portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                 inPortfolioID + " ne postoji!");

            var stockNameLower = inStockName.ToLower();
            if(!_stocks.ContainsKey((stockNameLower))) throw new StockExchangeException("Dionica " + 
                inStockName + " ne postoji!");
            // moga bi izbacit ovu provjeru posto ionako provjeravan u metodi Sell
            /*if(_stocks[stockNameLower]. < numberOfShares) throw new StockExchangeException(
                "Nema dovoljno dionica! " + 
                "Dionica " + inStockName + " ima samo " + _stocks[stockNameLower].Stock.Total + " 'udjela'.");*/

            _stocks[stockNameLower].Sell(numberOfShares);
            portfolios[inPortfolioID].AddStock(new Stock(stockNameLower, numberOfShares));
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");
            var stockNameLower = inStockName.ToLower();
            if (!_stocks.ContainsKey((stockNameLower))) throw new StockExchangeException("Dionica " +
                 inStockName + " ne postoji!");

            _stocks[stockNameLower].Buy(numberOfShares);
            portfolios[inPortfolioID].RemoveStock(stockNameLower, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");
            var stockNameLower = inStockName.ToLower();
            if (!_stocks.ContainsKey((stockNameLower))) throw new StockExchangeException("Dionica " +
                 inStockName + " ne postoji!");

            portfolios[inPortfolioID].RemoveStock(stockNameLower);
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");

            return portfolios[inPortfolioID].NumOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");
            var stockNameLower = inStockName.ToLower();
            if (!_stocks.ContainsKey((stockNameLower))) throw new StockExchangeException("Dionica " +
                 inStockName + " ne postoji!");

            return portfolios[inPortfolioID].ContainsStock(stockNameLower);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");
            var stockNameLower = inStockName.ToLower();
            if (!_stocks.ContainsKey((stockNameLower))) throw new StockExchangeException("Dionica " +
                 inStockName + " ne postoji!");

            return portfolios[inPortfolioID].NumOfSharesOfStock(stockNameLower);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");

            return portfolios[inPortfolioID].GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!portfolios.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio " +
                inPortfolioID + " ne postoji!");

            return portfolios[inPortfolioID].GetPercentChangeInValueForMonth(Year, Month);
        }
    }

    /// <summary>
    /// Klasa koja sadrzi najosnovnije informacije o dionici kao sto
    /// su ime i broj dionica.
    /// </summary>
    public class Stock
    {
        public string Name { get; set; }
        public long Total { get; set; }

        public Stock(string name, long total)
        {
            Name = name;
            Total = total;
        }

        /// <summary>
        /// Copy constructor.
        /// </summary>
        /// <param name="old">Objekt koji se kopira</param>
        public Stock(Stock old)
        {
            Name = old.Name;
            Total = old.Total;
        }
    }

    public class DatePrice
    {
        public DateTime Time { get; private set; }
        public decimal Price { get; private set; }

        public DatePrice(DateTime time, decimal price)
        {
            Time = time;
            Price = price;
        }
    }

    /// <summary>
    /// Klasa koja nadopunjuje klasu Stock. (Mogla bi se i naslijediti iz te klase)
    /// Sadrzi informacije o dionicama koje su bitne za burzu
    /// </summary>
    public class StockExtra
    {
        private long howManyLeftForSale;
        private List<DatePrice> prices;

        /// <summary>
        /// Indikator soritranosti cijena. Cijene se sortiraju ulazno po datumu.
        /// Lista cijena se sortira po potrebi i zbog toga je potreban ovaj indikator.
        /// </summary>
        private bool pricesSorted;

        /// <summary>
        /// Indikator koji govori je li dionica pridjeljena
        /// nekom indeksu.
        /// </summary>
        public bool CoupledWithIndex { get; set; }

        public Stock Stock { get; private set; }

        public StockExtra(string stockName, long numOfShares, DateTime timeStamp, decimal initialPrice)
        {
            Stock = new Stock(stockName.ToLower(), numOfShares);
            howManyLeftForSale = numOfShares;

            if(!(numOfShares > 0)) throw new StockExchangeException("Broj dionica mora biti veca od 0!");
            if(!(initialPrice > 0)) throw new StockExchangeException("Cijena dionice mora biti veca od 0!");

            prices = new List<DatePrice>
            {
                new DatePrice(timeStamp, initialPrice)
            };
            pricesSorted = true;
            CoupledWithIndex = false;
        }

        public void AddNewPrice(DateTime timeStamp, decimal price)
        {
            if(!(price > 0)) throw new StockExchangeException("Cijena dionice mora biti veca od 0!");

            var alreadyExists = prices.Where(p => p.Time.Equals(timeStamp));
            if(alreadyExists.Any()) throw new StockExchangeException("Vec postoji cijena za datum " + timeStamp.ToShortTimeString());

            prices.Add(new DatePrice(timeStamp, price));
            pricesSorted = false;
        }

        public decimal GetPrice(DateTime timeStamp)
        {
            if (pricesSorted == false)
            {
                prices = prices.OrderBy(o => o.Time).ToList();
                pricesSorted = true;
            }
            
            if(prices[0].Time > timeStamp) throw new StockExchangeException("Nije definirana cijena za datum " + timeStamp.ToShortDateString());
            // ovdi sad cuda sa foreach petljon
            for (var i = 1; i < prices.Count; i++)
                if (prices[i].Time > timeStamp) return prices[i - 1].Price;

            return prices.Last().Price;
        }

        public decimal GetInitialPrice()
        {
            if (pricesSorted == false)
            {
                prices = prices.OrderBy(o => o.Time).ToList();
                pricesSorted = true;
            }

            return prices.First().Price;
        }

        public decimal GetLatestPrice()
        {
            if (pricesSorted == false)
            {
                prices = prices.OrderBy(o => o.Time).ToList();
                pricesSorted = true;
            }

            return prices.Last().Price;
        }

        public void Sell(int numOfShares)
        {
            if(numOfShares > howManyLeftForSale) throw new StockExchangeException("Nema dovoljno dionica za prodaju! "
                + "Dionica " + Stock.Name + " je preostalo samo " + howManyLeftForSale + ", a ne " + numOfShares);

            howManyLeftForSale -= numOfShares;
        }

        public void Buy(int numOfShares)
        {
            if(numOfShares > (Stock.Total - howManyLeftForSale)) throw new StockExchangeException(
                "Nije moguce kupiti toliko dionica! Dionica " + Stock.Name + " je izdano " + Stock.Total);

            howManyLeftForSale += numOfShares;
        }
    }

    public abstract class Index
    {
        public string Name { get; private set; }
        // mozda da ipak bude lista stringova
        // ionako mi tribaju samo imena
        // uvik moran pitat burzu za cijene i te pizdarije
        // ovako mi je Stock beskoristan. Bit ce mi dobar samo za portfolio,
        // tako da mogu pratit koliko svaki portfolio ima dionica.
        protected List<Stock> stocks; 

        protected Index(string name)
        {
            Name = name;
            stocks = new List<Stock>();
        }

        public void AddStock(Stock stock)
        {
            stocks.Add(stock);
        }

        public void RemoveStock(string stockName)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower())).First();

            if(stock != null)
            {
                stocks.Remove(stock);
                
            }
            else
            {
                // Ista stvar kao i ranije, triba li bacat exception ako ga nema?!?!?!!
                throw new StockExchangeException("Indeks " + this.Name + " ne sadrzi dionicu " + stockName);
            }
        }

        public bool ContainsStock(string stockName)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower()));
            return stock.Any();
        }

        public int NumOfStocks()
        {
            return stocks.Count;
        }

        public abstract decimal CalculateAverage(DateTime timeStamp);
    }

    public class IndexAverage : Index
    {
        public IndexAverage(string name) : base(name) {}

        public override decimal CalculateAverage(DateTime timeStamp)
        {
            var returnValue = stocks.Sum(s => s.Total)/
                              stocks.Sum(s => s.Total*StockExchange.StaticGetStockPrice(s.Name, timeStamp));

            return Math.Round(new decimal((float) returnValue), 3);
        }
    }

    public class IndexWeighted : Index
    {
        public IndexWeighted(string name) : base(name) {}

        public override decimal CalculateAverage(DateTime timeStamp)
        {
            var sumOfStocks = stocks.Sum(s => s.Total*StockExchange.StaticGetStockPrice(s.Name, timeStamp));
            var weightsForStocks =
                from s in stocks
                select new {StockName = s.Name,
                    Weight = s.Total * StockExchange.StaticGetStockPrice(s.Name, timeStamp) / sumOfStocks,
                    Value = StockExchange.StaticGetStockPrice(s.Name, timeStamp)};

            var returnValue = weightsForStocks.Sum(w => w.Weight*w.Value) / weightsForStocks.Sum(w => w.Weight);

            return Math.Round(new decimal((float) returnValue), 3);
        }
    }

    public class Portfolio
    {
        public string Name { get; private set; }
        private List<Stock> stocks;

        public Portfolio(string name)
        {
            Name = name;
            stocks = new List<Stock>();
        }

        public void AddStock(Stock stock)
        {
            var stck = stocks.Where(s => s.Name == stock.Name);
            if (stck.Any())
            {
                stck.First().Total += stock.Total;
            }
            else
            {
                stocks.Add(stock);
            }
        }

        public void RemoveStock(string stockName)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower()));
            if(!stock.Any()) throw new StockExchangeException("Portfolio " + Name +
                " nema dionicu " + stockName);

            stocks.Remove(stock.First());
        }

        public void RemoveStock(string stockName, int numOfShares)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower()));
            if (!stock.Any()) throw new StockExchangeException("Portfolio " + Name +
                 " nema dionicu " + stockName);
            if(stock.First().Total < numOfShares) throw new StockExchangeException("Nema dovoljno dionica na prodaju!");

            if (stock.First().Total == numOfShares)
                stocks.Remove(stock.First());
            else
            {
                stock.First().Total -= numOfShares;
            }
        }

        public int NumOfStocks()
        {
            return stocks.Count;
        }

        public bool ContainsStock(string stockName)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower()));

            return stock.Any();
        }

        public int NumOfSharesOfStock(string stockName)
        {
            var stock = stocks.Where(s => s.Name.Equals(stockName.ToLower()));
            if(!stock.Any()) throw new StockExchangeException("Portfolio " + Name +
                " ne sadrzi dionicu " + stockName);

            return (int)stock.First().Total;
        }

        public decimal GetValue(DateTime timeStamp)
        {
            var sum = stocks.Sum(s => s.Total*StockExchange.StaticGetStockPrice(s.Name, timeStamp));

            return Math.Round(sum, 3);
        }

        public decimal GetPercentChangeInValueForMonth(int Year, int Month)
        {
            if(Year < 0) throw new StockExchangeException("Ne priznajemo vrijeme prije Isusa Krista! Cakija!!!");
            if(Month < 0 || Month > 12) throw new StockExchangeException("Ne postoji mjesec " + Month);

            var firstInTheMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            var lastInTheMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month),
                                              23, 59, 59, 999);

            var sumOnFirst = GetValue(firstInTheMonth);
            var sumOnLast = GetValue(lastInTheMonth);

            var returnValue = ((sumOnLast- sumOnFirst)/sumOnFirst)*100;

            return Math.Round(returnValue, 3);
        }
    }
}
