﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {
        //varijable vezane za display
        private char _pressedKey;                //trenutno uneseni znak
        private char _prevPressedKey;            //prethodno uneseni znak
        private string _displayState;            //stanje displaya
        private bool _firstDigitReady;           //spremnost za upis prve znamenke novog broja
        private bool _positiveSignSet;           //stanje predznaka

        //varijable za operacije
        private bool _prevOperationSet;          //je li postavljen prethodni bin. operator
        private char _prevOperation;             //pamti prethodni binarni operator
        private bool _currScoreSet;              //postoji li zapamcen rezultat
        private double _currScore;               //trenutni rezultat
        private double _tmpScore;                //privremeni rezultat - pomocna varijabla za unarne operacije
        private string _memBuff;                 //memorija kalkulatora

        //rjecnici operacija
        private Dictionary<char, Delegate> _binOps = new Dictionary<char, Delegate>();   //bin. operacije
        private Dictionary<char, Delegate> _unOps = new Dictionary<char, Delegate>();    //unarne operacije
        private Dictionary<char, Delegate> _conOps = new Dictionary<char, Delegate>()    //razne kontrole
        {
        };

        public Kalkulator()
        {

            _displayState = "0";
            _firstDigitReady = true;
            _positiveSignSet = true;

            _prevOperationSet = false;
            _currScoreSet = false;
            _currScore = 0.0;
            _tmpScore = 0.0;
            _memBuff = "0";

            _binOps['+'] = new Func<double, double, double>(funSum);
            _binOps['-'] = new Func<double, double, double>(funSub);
            _binOps['*'] = new Func<double, double, double>(funMul);
            _binOps['/'] = new Func<double, double, double>(funDiv);

            _unOps['S'] = new Func<double, double>(funSin);
            _unOps['K'] = new Func<double, double>(funCos);
            _unOps['T'] = new Func<double, double>(funTan);
            _unOps['Q'] = new Func<double, double>(funQuad);
            _unOps['R'] = new Func<double, double>(funRoot);
            _unOps['I'] = new Func<double, double>(funInv);

            _conOps[','] = new Action(addDecimal);
            _conOps['M'] = new Action(changeSig);
            _conOps['='] = new Action(funEq);
            _conOps['O'] = new Action(rstCalc);
            _conOps['C'] = new Action(clrScreen);
            _conOps['G'] = new Action(getMemory);
            _conOps['P'] = new Action(putMemory);
        }

        /// <summary>
        /// Unos tipke
        /// </summary>
        public void Press(char inPressedDigit)
        {
            _prevPressedKey = _pressedKey;
            _pressedKey = inPressedDigit;
            processInput(_pressedKey);
        }

        /// <summary>
        /// Dohvat stanja displaya
        /// </summary>
        public string GetCurrentDisplayState()
        {
            return _displayState;
        }

        /// <summary>
        /// Prepoznavanje i obrada unesenog znaka
        /// </summary>
        private void processInput(char znak)
        {
            //provjeri je li uneseni znak broj, kontrola (tu pripada i dec. zarez) ili operator

            if (znak > 47 && znak < 58)
            {
                inputNumber(znak);                 //unesi znamenku
            }
            else if (_conOps.ContainsKey(znak))
            {
                _conOps[znak].DynamicInvoke();      //obavi kontrolnu operaciju

            }
            else if (_unOps.ContainsKey(znak))
            {
                doUnaryOP(znak);                    //obavi unarnu operaciju
            }
            else if (_binOps.ContainsKey(znak))
            {
                doBinaryOP(znak);                   //obavi binarnu operaciju
            }
            else
            {
                _displayState = "-E-";              //unesen je nepostojeci znak
            }

        }

        /// <summary>
        /// Upis znamenke na display
        /// </summary>
        private void inputNumber(char num)
        {
            if (_firstDigitReady)
            {
                _displayState = num.ToString();
                _firstDigitReady = false;
            }
            else
            {
                if (haveSpaceOnDisplay()) //ako ima mjesta na ekranu upisi znamenku
                {
                    if (_displayState == "0" && num == '0')
                    {
                        //ako je nula na ekranu i korisnik stisce nulu, ne radi nista
                    }
                    else
                    {
                        _displayState = _displayState + num;
                    }
                }
            }
        }

        /// <summary>
        /// Prepoznavanje i izvođenje unarne operacije
        /// </summary>
        private void doUnaryOP(char operation)
        {
            //izracun privremenog rezultata
            _tmpScore = Math.Round((double)_unOps[operation].DynamicInvoke(double.Parse(_displayState)), 9);

            //provjeri je li broj u dozvoljenom opsegu
            if (isNumberValid(_tmpScore))
            {
                _displayState = _tmpScore.ToString("0.#########", System.Globalization.CultureInfo.CreateSpecificCulture("hr-HR"));
            }
            else
            {
                _displayState = "-E-"; //javi gresku                    
            }

            //pripremi se za unos slijedeceg broja
            prepareForNewNumber();
        }

        /// <summary>
        /// Prepoznavanje i izvođenje binarne operacije
        /// </summary>
        private void doBinaryOP(char operation)
        {
            //najprije makni viska nule i zarez ako je potrebno               
            _displayState = Math.Round(double.Parse(_displayState), 9).ToString("0.#########", System.Globalization.CultureInfo.CreateSpecificCulture("hr-HR"));

            //zatim odredi postoji li vec operacija koju sada treba izvrsiti ili je ovo prvi operand
            if (_prevOperationSet && !_binOps.ContainsKey(_prevPressedKey))   //drugi uvjet je kontrola da prethodni znak također nije bio operator
            {
                //ako je vec prije bio binarni operator, obavi sada tu operaciju
                _currScore = (double)_binOps[_prevOperation].DynamicInvoke(_currScore, double.Parse(_displayState));
            }
            else if (!_prevOperationSet)
            {
                //inace zapamti broj na ekranu i čekaj drugi operand             
                _currScore = double.Parse(_displayState);
                _currScoreSet = true;
            }

            //zapamti zadnji operator
            _prevOperation = operation;
            _prevOperationSet = true;

            //pripremi se za unos slijedeceg broja
            prepareForNewNumber();

        }


        /// <summary>
        /// Provjera je li broj u zadanom opsegu
        /// </summary>
        private bool isNumberValid(double number)
        {
            if (number > 9999999999 || number < -9999999999)
            {
                return false; //broj je izvan opsega                    
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Priprema za unos novog broja
        /// </summary>
        private void prepareForNewNumber()
        {
            // sve kontorne parametre za unos broja postavi na pocetne vrijednosti
            _firstDigitReady = true;
            _positiveSignSet = true;
        }

        /// <summary>
        /// Funkcija za provjeru ima li na ekranu mjesta za jos jednu znamenku
        /// </summary>
        private bool haveSpaceOnDisplay()
        {
            /* duljina stringa koji predstavlja display ovisi o tome sadrži li predznak '-' i/ili dec. zarez
             * 
             * ako ne sadrzi nijedan od tih znakova max. dozvoljena duljina stringa je 10
             * 
             * ako sadrzi jedan od tih znakova max. dozvoljena duljina stringa je 11
             * 
             * ako sadrzi oba ta znaka max. dozvoljena duljina stringa je 12
             * 
             * a to se provjerava kroz slijedece uvjete
             */

            if (!_displayState.Contains('-') && !_displayState.Contains(',') && _displayState.Length < 10)
            {
                return true;
            }
            else if (!_displayState.Contains('-') && _displayState.Contains(',') && _displayState.Length < 11)
            {
                return true;
            }
            else if (_displayState.Contains('-') && !_displayState.Contains(',') && _displayState.Length < 11)
            {
                return true;
            }
            else if (_displayState.Contains('-') && _displayState.Contains(',') && _displayState.Length < 12)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /*
         * Funkcije iz rječnika za binarne operacije, rade s punom preciznošću
         */
        private double funSum(double a, double b)
        {
            return a + b;
        }
        private double funSub(double a, double b)
        {
            return a - b;
        }
        private double funMul(double a, double b)
        {
            return a * b;
        }
        private double funDiv(double a, double b)
        {
            return a / b;
        }

        /*
         * Funkcije iz rječnika za unarne operacije, rade s punom preciznošću
         */
        private double funSin(double a)
        {
            return Math.Sin(a);
        }
        private double funCos(double a)
        {
            return Math.Cos(a);
        }
        private double funTan(double a)
        {
            return Math.Tan(a);
        }
        private double funQuad(double a)
        {
            return a * a;
        }
        private double funRoot(double a)
        {
            return Math.Sqrt(a);
        }
        private double funInv(double a)
        {
            return 1 / a;
        }


        /*
         * Kontrolne funkcije
         */

        /// <summary>
        /// Promjena predznaka
        /// </summary>
        private void changeSig()
        {
            if (_positiveSignSet)
            {
                _positiveSignSet = false;
                _displayState = '-' + _displayState;
            }
            else
            {
                _positiveSignSet = true;
                _displayState = _displayState.TrimStart('-');
            }
        }

        /// <summary>
        /// Decimalni zarez
        /// </summary>
        private void addDecimal()
        {
            if (_displayState.Length < 10)   //ako ima mjesta za jos bar jednu decimalu na ekranu
            {
                if (!_displayState.Contains(','))    //ako do sada nije postavljen dec. zarez registriraj ga
                {
                    if (_firstDigitReady)
                    {
                        _firstDigitReady = false;
                        if (_positiveSignSet) _displayState = "0,";
                        else _displayState = "-0,";
                    }
                    else
                    {
                        _displayState = _displayState + ',';
                    }
                }
            }
        }

        /// <summary>
        /// Funkcionalnost tipke '='
        /// </summary>
        private void funEq()
        {
            if (!_currScoreSet)      //ako jos nije pohranjen nikakav rezultat u memoriji, pohrani stanje na ekranu
            {
                _currScore = double.Parse(_displayState);
            }

            if (_prevOperationSet)   //ako vec imamo operator u memoriji, obavi binarnu operaciju
            {
                _currScore = Math.Round((double)_binOps[_prevOperation].DynamicInvoke(_currScore, double.Parse(_displayState)), 9);
                _prevOperationSet = false;
                _currScoreSet = true;
            }

            //provjeri je li broj u dozvoljenom opsegu
            if (isNumberValid(_currScore))
            {
                _displayState = _currScore.ToString("0.#########", System.Globalization.CultureInfo.CreateSpecificCulture("hr-HR"));
                _currScoreSet = false;
            }
            else
            {
                _displayState = "-E-"; //javi gresku
                _currScoreSet = false;
            }

            //pripremi se za unos slijedeceg broja
            prepareForNewNumber();
        }

        /// <summary>
        /// Reset
        /// </summary>
        private void rstCalc()
        {
            _displayState = "0";
            _firstDigitReady = true;
            _positiveSignSet = true;

            _currScore = 0.0;
            _currScoreSet = false;
            _prevOperationSet = false;
            _tmpScore = 0.0;
            _memBuff = "0";
        }

        /// <summary>
        /// Brisanje ekrana
        /// </summary>
        private void clrScreen()
        {
            _displayState = "0";

            //pripremi se za unos slijedeceg broja
            prepareForNewNumber();
        }

        /// <summary>
        /// Dohvat iz memorije
        /// </summary>
        private void getMemory()
        {
            _displayState = _memBuff;

            //pripremi se za unos slijedeceg broja
            prepareForNewNumber();
        }

        /// <summary>
        /// Spremanje u memoriju
        /// </summary>
        private void putMemory()
        {
            _memBuff = _displayState;
        }

    }


}
