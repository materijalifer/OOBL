﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> allStocks;
        private Dictionary<string, Index> allIndexes;
        private Dictionary<string, Portfolio> allPortfolios;
        private Dictionary<string, long> availableShares;  //key--> stock name, value--> number of available shares
 
        public StockExchange()
        {
            allStocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
            allIndexes = new Dictionary<string, Index>(StringComparer.InvariantCultureIgnoreCase);
            allPortfolios = new Dictionary<string, Portfolio>();
            availableShares = new Dictionary<string, long>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name. Already exists!");

            allStocks.Add( inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp) );
            availableShares.Add(inStockName, inNumberOfShares);
        }

        public void DelistStock(string inStockName)
        {
            if (! StockExists(inStockName) )
                throw new StockExchangeException("Invalid stock name!");
                
            allStocks.Remove(inStockName);
            availableShares.Remove(inStockName);

            //Delete from indexes
            foreach (Index index in allIndexes.Values)
            {
                if ( index.ContainsStock(inStockName) )
                    index.RemoveStock(inStockName);
            }
            
            //Delete from portfolios
            foreach (Portfolio portfolio in allPortfolios.Values)
            {
                if (portfolio.ContainsStock(inStockName))
                    portfolio.RemoveStock(inStockName);
            }
        }

        public bool StockExists(string inStockName)
        {
            if (allStocks.ContainsKey(inStockName))
                return true;
            
           return false;
        }

        public int NumberOfStocks()
        {
            return allStocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, Decimal inStockValue)
        {
            if (!StockExists(inStockName) )
                throw new StockExchangeException("Invalid stock name!");

            allStocks[inStockName].SetStockPrice(inIimeStamp, inStockValue);
        }

        public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            return allStocks[inStockName].GetStockPrice(inTimeStamp);
        }

        public Decimal GetInitialStockPrice(string inStockName)
        {
            if (! StockExists(inStockName) )
                throw new StockExchangeException("Invalid stock name!");

            return allStocks[inStockName].GetInitialStockPrice();
        }

        public Decimal GetLastStockPrice(string inStockName)
        {
            if (! StockExists(inStockName) )
                throw new StockExchangeException("Invalid stock name!");

            return allStocks[inStockName].GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if ( IndexExists(inIndexName) )
                throw new StockExchangeException("Invalid index name. Already exists!");

            allIndexes.Add( inIndexName, new Index(inIndexName, inIndexType) );
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (! IndexExists(inIndexName) )
                throw new StockExchangeException("Invalid index name!");
            if (! StockExists(inStockName) )
                throw new StockExchangeException("Invalid stock name!");

            allIndexes[inIndexName].AddStock( allStocks[inStockName] );
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Invalid index name!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            allIndexes[inIndexName].RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Invalid index name!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            return allIndexes[inIndexName].ContainsStock(inStockName);
        }

        public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Invalid index name!");

            return allIndexes[inIndexName].GetIndexValue( inTimeStamp );
        }

        public bool IndexExists(string inIndexName)
        {
            if (allIndexes.ContainsKey(inIndexName))
                return true;

            return false;
        }

        public int NumberOfIndices()
        {
            return allIndexes.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Invalid index name!");

            return allIndexes[inIndexName].NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id. Already exists!");

            allPortfolios.Add( inPortfolioID, new Portfolio(inPortfolioID) );
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");
            if (numberOfShares > allStocks[inStockName].NumberOfShares)
                throw new StockExchangeException("There is not enough available shares!");

            allPortfolios[inPortfolioID].AddStock( allStocks[inStockName], numberOfShares);
            availableShares[inStockName] -= numberOfShares;
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            allPortfolios[inPortfolioID].RemoveStock(inStockName, numberOfShares);
            availableShares[inStockName] += numberOfShares;
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");
            
            int numberOfShares = allPortfolios[inPortfolioID].RemoveStock(inStockName);
            availableShares[inStockName] += numberOfShares;
        }

        public int NumberOfPortfolios()
        {
            return allPortfolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");

            return allPortfolios[inPortfolioID].NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (allPortfolios.ContainsKey(inPortfolioID))
                return true;

            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            return allPortfolios[inPortfolioID].ContainsStock(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            return allPortfolios[inPortfolioID].NumberOfShares(inStockName);
        }

        public Decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");

            Decimal value = allPortfolios[inPortfolioID].GetValue(timeStamp);
            return Decimal.Round(value, 3);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Invalid portfolio id!");

            Decimal value = allPortfolios[inPortfolioID].GetPercentChangeInValueForMonth(Year, Month);
            return Decimal.Round(value, 3);
        }
    }

    //******************************************************************************************************************
    //----------------------------------------------Stock implementation-------------------------------------------------
    //******************************************************************************************************************

    public interface IStock
    {
        void SetStockPrice(DateTime inIimeStamp, Decimal price);
        Decimal GetStockPrice(DateTime inTimeStamp);
        Decimal GetCurrentStockPrice();
        Decimal GetInitialStockPrice();
        Decimal GetLastStockPrice();
    }

    public class Stock : IStock
    {
        private string name;
        private long numberOfShares;
        private Decimal price;
        private DateTime inTimeStamp;

        private StockPriceHistory priceHistory;

        //Constructor
        public Stock(string name, long numberOfShares, Decimal price, DateTime inTimeStamp)
        {
            //Preconditions
            if (name.Equals(""))
                throw new StockExchangeException("Invalid stock name!");
            if (numberOfShares <= 0)
                throw new StockExchangeException("Invalid number of shares!");
            if (price <= 0)
                throw new StockExchangeException("Invalid price!");
            if (inTimeStamp.Equals(null))
                throw new StockExchangeException("Invalid time!");

            this.name = name;
            this.numberOfShares = numberOfShares;
            this.price = price;
            this.inTimeStamp = inTimeStamp;

            this.priceHistory = new StockPriceHistory(inTimeStamp, price);
        }

        //Properties
        public string Name
        {
            get { return name; }
        }
        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        //Public methods
        public void SetStockPrice(DateTime inIimeStamp, Decimal price)
        {
            if (price <= 0)
                throw new StockExchangeException("Invalid price!");
            if (inTimeStamp.Equals(null))
                throw new StockExchangeException("Invalid time!");

            this.price = price;
            this.inTimeStamp = inIimeStamp;

            this.priceHistory.AddStockPrice(inTimeStamp, price);
        }

        public Decimal GetCurrentStockPrice()
        {
            return price;
        }

        public Decimal GetInitialStockPrice()
        {
            return priceHistory.GetInitialPrice();
        }

        public Decimal GetLastStockPrice()
        {
            return priceHistory.GetLastPrice();
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp.Equals(null))
                throw new StockExchangeException("Invalid time!");

            return priceHistory.GetStockPrice(inTimeStamp);
        }
    }

    public class StockPriceHistory
    {
        private Dictionary<DateTime, Decimal> priceHistory;

        public StockPriceHistory()
        {
            this.priceHistory = new Dictionary<DateTime, Decimal>();
        }

        public StockPriceHistory(DateTime inTimeStamp, Decimal price)  : this()
        {
            this.priceHistory.Add(inTimeStamp, price);
        }

        public void AddStockPrice(DateTime inTimeStamp, Decimal price)
        {
            priceHistory.Add(inTimeStamp, price);
        }

        public Decimal GetInitialPrice()
        {
            //The oldest date time
            return priceHistory[priceHistory.Keys.Min()];
        }

        public Decimal GetLastPrice()
        {
            //The most new date time
            return priceHistory[priceHistory.Keys.Max()];
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            try
            {
                //find appropriate date time and retrun stock price
                return priceHistory.Where(pair => pair.Key <= inTimeStamp).Last().Value;
            }
            catch (Exception exception)
            {
                throw new StockExchangeException("Error: " + exception.Message);
            }
            
        }
    }


    //******************************************************************************************************************
    //----------------------------------------------Index implementation-------------------------------------------------
    //******************************************************************************************************************

    public class Index
    {
        private string name;
        private IndexTypes type;
        private Dictionary<string, Stock> stocks;

        //Constructors
        public Index(string name, IndexTypes type)
        {
            if (! (type.Equals(IndexTypes.AVERAGE) || type.Equals(IndexTypes.WEIGHTED)) )
                throw new StockExchangeException("Invalid index type!");

            this.name = name;
            this.type = type;

            this.stocks = new Dictionary<string, Stock>();
        }

        //Properties
        public Dictionary<string, Stock> Stocks
        {
            get { return stocks; }
        }

        //Public methodes
        public Decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (inTimeStamp.Equals(null))
                throw new StockExchangeException("Invalid time!");

            Decimal weight = new IndexWeight(this).CalculateWeight(type, inTimeStamp);
            return Decimal.Round(weight, 3);
        }

        public void AddStock(Stock stock)
        {
            if ( ContainsStock(stock.Name) )
                throw new StockExchangeException("Invalid stock name, already exists in this index!");

            stocks.Add(stock.Name, stock);
        }

        public void RemoveStock(string inStockName)
        {
            if ( ! ContainsStock(inStockName) )
                throw new StockExchangeException("Invalid stock name!");

            stocks.Remove(inStockName);
        }

        public bool ContainsStock(string inStockName)
        {
            return stocks.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

    }

    public class IndexWeight
    {
        private Index index;

        //Constructor
        public IndexWeight(Index index)
        {
            this.index = index;
        }

        //Public methods
        public Decimal CalculateWeight(IndexTypes type, DateTime inTimeStamp)
        {
            switch (type)
            {
                case IndexTypes.AVERAGE:
                    return CalculateAverageWeight(inTimeStamp);
                    break;
                case IndexTypes.WEIGHTED:
                    return CalculateWeightedWeight(inTimeStamp);
                    break;
                default:
                    throw new StockExchangeException("Invalid index type");
            }
        }

        //Private methods
        private Decimal CalculateAverageWeight(DateTime inTimeStamp)
        {
            if (index.Stocks.Count.Equals(0))
                return 0;
            
            Decimal averageWeight = 0;

            foreach (Stock stock in index.Stocks.Values)
            {
                averageWeight += stock.GetStockPrice(inTimeStamp);
            }

            return averageWeight/index.Stocks.Count;
        }

        private Decimal CalculateWeightedWeight(DateTime inTimeStamp)
        {
            if (index.Stocks.Count.Equals(0))
                return 0;

            Decimal totalWeight = 0;
            Decimal weightedWeight = 0;

            try
            {
                //foreach stock --> number of shares * price
                foreach (Stock stock in index.Stocks.Values)
                {
                    totalWeight += (stock.NumberOfShares*stock.GetStockPrice(inTimeStamp));
                }

                //foreach stock --> number of shares * ( price * price/totalWeight)
                foreach (Stock stock in index.Stocks.Values)
                {
                    weightedWeight += stock.NumberOfShares*
                                      (stock.GetStockPrice(inTimeStamp)*(stock.GetStockPrice(inTimeStamp)/totalWeight));
                }

            }
            catch (Exception exception)
            {
                throw new StockExchangeException("Error: " + exception.Message);
            }
           
            return weightedWeight;
        }
    }



    //******************************************************************************************************************
    //----------------------------------------------Portfolio implementation--------------------------------------------
    //******************************************************************************************************************

    public class Portfolio
    {
        private string id;
        private Dictionary<string, Stock> stocks;
        private Dictionary<string, int> stocksInShares;   //Key --> stock name, value --> number of shares in this portfolio

        //Constructor
        public Portfolio(string id)
        {
            this.id = id;
            this.stocks = new Dictionary<string, Stock>();
            this.stocksInShares = new Dictionary<string, int>();
        }

        //Public methods
        public bool ContainsStock(string inStockName)
        {
            return stocksInShares.ContainsKey(inStockName);
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if(numberOfShares <= 0)
                throw new StockExchangeException("Invalid number of shares!");

            if (ContainsStock(stock.Name))
            {
                stocksInShares[stock.Name] += numberOfShares;
            }
            else
            {
                stocksInShares.Add(stock.Name, numberOfShares);
                stocks.Add(stock.Name, stock);
            }
        }

        public int RemoveStock(string inStockName)
        {
            if (!ContainsStock(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            int numberOfShares = stocksInShares[inStockName];
            stocksInShares.Remove(inStockName);
            stocks.Remove(inStockName);

            return numberOfShares;
        }

        public void RemoveStock(string inStockName, int numberOfShares)
        {
            if (!ContainsStock(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            if(numberOfShares > stocksInShares[inStockName])
                throw new StockExchangeException("Too large number of shares!");

            stocksInShares[inStockName] -= numberOfShares;

            //Number of shares can not be 0
            if (stocksInShares[inStockName].Equals(0))
            {
                stocksInShares.Remove(inStockName);
                stocks.Remove(inStockName);
            }
        }

        public int NumberOfStocks()
        {
            return stocksInShares.Count();
        }

        public int NumberOfShares(string inStockName)
        {
            if (!ContainsStock(inStockName))
                throw new StockExchangeException("Invalid stock name!");

            return stocksInShares[inStockName];
        }

        public Decimal GetValue(DateTime inTimeStamp)
        {
            if (inTimeStamp.Equals(null))
                throw new StockExchangeException("Invalid time!");

            Decimal value = 0;
            //foreach stock --> Number of shares * price
            foreach (Stock stock in stocks.Values)
                value += ( stock.GetStockPrice(inTimeStamp) * stocksInShares[stock.Name] );

            return value;
        }

        public Decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            try
            {
                DateTime start = new DateTime(year, month, 1, 0, 0, 0, 0);
                DateTime end = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

                Decimal startValue = GetValue(start);
                Decimal endValue = GetValue(end);

                //return value in percentage
                return Math.Abs( ( endValue - startValue) / startValue * 100 );
            }
            catch (Exception exception)
            {
                throw new StockExchangeException("Error: " + exception.Message);
            }
            
        }

    }
}
