﻿using System;
using System.Collections.Generic;
using System.Linq;


    namespace DrugaDomacaZadaca_Burza
    {
        public static class Factory
        {
            public static IStockExchange CreateStockExchange()
            {
                return new StockExchange();
            }
        }

        public class StockExchange : IStockExchange
        {
            IndexHandler _indexHandler = new IndexHandler();
            StockHandler _stockHandler = new StockHandler();
            PortfolioHandler _portfolioHandler = new PortfolioHandler();

            public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
            {
                if (StockExists(inStockName))
                {
                    throw new StockExchangeException("Vec postoji dionica sa zadanim imenom.");
                }
                else
                {
                    if (!(inInitialPrice > 0)) throw new StockExchangeException("cijena nije pozitivna");
                    if (!(inNumberOfShares > 0)) throw new StockExchangeException("broj dionica nije pozitivan");
                    Stock s = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                    _stockHandler.Add(s);
                }
            }

            public void DelistStock(string inStockName)
            {
                if (StockExists(inStockName))
                {
                    _stockHandler.Remove(inStockName);
                }
                else
                    throw new StockExchangeException("Dionica ne postoji");
            }

            public bool StockExists(string inStockName)
            {
                return _stockHandler.Exsist(inStockName);
            }

            public int NumberOfStocks()
            {
                return _stockHandler.Count();
            }

            public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
            {
                if (!(inStockValue > 0)) throw new StockExchangeException("cijena nije pozitivna");
                _stockHandler.AddPrice(inStockName, inTimeStamp, inStockValue);
            }

            public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
            {
                if (StockExists(inStockName))
                {
                    return decimal.Round(_stockHandler.GetPrice(inStockName, inTimeStamp), 2, MidpointRounding.AwayFromZero);
                }
                else
                    throw new StockExchangeException("ne postoji dionica"); ;
            }

            public decimal GetInitialStockPrice(string inStockName)
            {
                if (StockExists(inStockName))
                {
                    return decimal.Round(_stockHandler.GetInitialPrice(inStockName), 2, MidpointRounding.AwayFromZero);
                }
                else
                    throw new StockExchangeException("ne postoji dionica"); ;
            }

            public decimal GetLastStockPrice(string inStockName)
            {
                if (StockExists(inStockName))
                {
                    return decimal.Round(_stockHandler.GetLastPrice(inStockName), 2, MidpointRounding.AwayFromZero);
                }
                else
                    throw new StockExchangeException("ne postoji dionica");
            }

            public void CreateIndex(string inIndexName, IndexTypes inIndexType)
            {
                if (IndexExists(inIndexName))
                {
                    throw new StockExchangeException("index vec postoji");
                }
                else
                    if (!(inIndexType != IndexTypes.AVERAGE || inIndexType != IndexTypes.WEIGHTED)) throw new StockExchangeException("ne postoji index takvog tipa");
                    else
                        _indexHandler.Add(inIndexName, inIndexType);
            }

            public void AddStockToIndex(string inIndexName, string inStockName)
            {
                if (!IndexExists(inIndexName))
                {
                    throw new StockExchangeException("ne postoji index");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock stock = _stockHandler.GetStockByName(inStockName);
                        _indexHandler.AddStockToIndex(inIndexName, stock);
                    }
            }

            public void RemoveStockFromIndex(string inIndexName, string inStockName)
            {
                if (!IndexExists(inIndexName))
                {
                    throw new StockExchangeException("ne postoji index");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock stock = _stockHandler.GetStockByName(inStockName);
                        _indexHandler.RemoveStockFromIndex(inIndexName, stock);
                    }
            }

            public bool IsStockPartOfIndex(string inIndexName, string inStockName)
            {
                if (!IndexExists(inIndexName))
                {
                    throw new StockExchangeException("ne postoji index");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock stock = _stockHandler.GetStockByName(inStockName);
                        return _indexHandler.IsStockPartOfIndex(inIndexName, stock);
                    }
            }

            public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
            {
                if (!IndexExists(inIndexName))
                {
                    throw new StockExchangeException("ne postoji index");
                }
                else
                    return decimal.Round((_indexHandler.GetIndexValue(inIndexName, inTimeStamp)), 2, MidpointRounding.AwayFromZero);
            }

            public bool IndexExists(string inIndexName)
            {
                return _indexHandler.Exsist(inIndexName);
            }

            public int NumberOfIndices()
            {
                return _indexHandler.Count();
            }

            public int NumberOfStocksInIndex(string inIndexName)
            {
                if (!IndexExists(inIndexName))
                {
                    throw new StockExchangeException("ne postoji index");
                }
                else
                    return _indexHandler.NumerOFStocks(inIndexName);
            }

            public void CreatePortfolio(string inPortfolioID)
            {
                if (PortfolioExists(inPortfolioID))
                {
                    throw new StockExchangeException("portfolio vec postoji");
                }
                else
                {
                    _portfolioHandler.AddPortfolio(inPortfolioID);
                }
            }

            public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
            {


                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock s = _stockHandler.GetStockByName(inStockName);
                        if (numberOfShares > s.BrojDionica) throw new StockExchangeException("pokusava se dodati vise dionica nego ih postoji");
                        _portfolioHandler.AddStockToPortfolio(inPortfolioID, s, numberOfShares);
                    }
            }

            public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock s = _stockHandler.GetStockByName(inStockName);
                        _portfolioHandler.RemoveStockFromPortfolio(inPortfolioID, s, numberOfShares);
                    }
            }

            public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock s = _stockHandler.GetStockByName(inStockName);
                        _portfolioHandler.DeleteStock(inPortfolioID, s);
                    }
            }

            public int NumberOfPortfolios()
            {
                return _portfolioHandler.Count();
            }

            public int NumberOfStocksInPortfolio(string inPortfolioID)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                {
                    return _portfolioHandler.NumberOfStocks(inPortfolioID);
                }
            }

            public bool PortfolioExists(string inPortfolioID)
            {
                return _portfolioHandler.Exsist(inPortfolioID);
            }

            public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock s = _stockHandler.GetStockByName(inStockName);
                        return _portfolioHandler.IsStockPart(inPortfolioID, s);
                    }
            }

            public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                    if (!StockExists(inStockName))
                    {
                        throw new StockExchangeException("Ne postoji dionica sa zadanim imenom.");
                    }
                    else
                    {
                        Stock s = _stockHandler.GetStockByName(inStockName);
                        return _portfolioHandler.NumberOfSharesOfStockInPortfolio(inPortfolioID, s);
                    }
            }

            public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                {
                    return decimal.Round((_portfolioHandler.PortfolioValue(inPortfolioID, timeStamp)), 2, MidpointRounding.AwayFromZero);
                }
            }

            public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
            {
                if (!(PortfolioExists(inPortfolioID)))
                {
                    throw new StockExchangeException("portfolio ne postoji");
                }
                else
                {
                    DateTime startDate = new DateTime(Year, Month, 1, 00, 00, 00, 00);
                    DateTime endDate = new DateTime(Year, Month, 1, 23, 59, 59, 999);
                    endDate = endDate.AddMonths(1).AddDays(-1);
                    decimal startValue = GetPortfolioValue(inPortfolioID, startDate);
                    decimal endValue = GetPortfolioValue(inPortfolioID, endDate);
                    return decimal.Round(((endValue - startValue) / startValue * 100), 2, MidpointRounding.AwayFromZero);
                }
            }
        }

        public class Index
        {
            string _indexName;

            public string IndexName
            {
                get { return _indexName; }
                set { _indexName = value; }
            }
            IndexTypes _indexType;

            public IndexTypes IndexType
            {
                get { return _indexType; }
                set { _indexType = value; }
            }
            List<Stock> _stocksList;

            public List<Stock> StocksList
            {
                get { return _stocksList; }
                set { _stocksList = value; }
            }
            decimal _indexValue;

            public decimal IndexValue
            {
                get { return _indexValue; }
                set { _indexValue = value; }
            }
            public Index(string name, IndexTypes type)
            {
                this._indexName = name.ToUpper();
                this._indexType = type;
                this._stocksList = new List<Stock>();
            }
            public void CalculateValue(DateTime inDateTime)
            {
                decimal suma = 0;
                foreach (Stock s in _stocksList)
                {
                    decimal price = s.GetPrice(inDateTime);
                    suma = suma + (price * s.BrojDionica);
                }
                if (_indexType == IndexTypes.AVERAGE)
                {
                    _indexValue = suma / _stocksList.Count;
                }
                else
                    if (_indexType == IndexTypes.WEIGHTED)
                    {
                        decimal weightedValue = 0;
                        foreach (Stock s in _stocksList)
                        {
                            decimal stockPrice = s.GetPrice(inDateTime);
                            weightedValue = weightedValue + (((stockPrice * s.BrojDionica) / suma) * stockPrice);
                        }
                        _indexValue = weightedValue;
                    }
            }
        }

        public class IndexHandler
        {
            List<Index> _indexList;

            public IndexHandler()
            {
                this._indexList = new List<Index>();
            }

            public int Count()
            {
                return _indexList.Count;
            }

            public void Clear()
            {
                _indexList.Clear();
            }

            public void Add(string indexName, IndexTypes i)
            {
                Index index = new Index(indexName, i);
                _indexList.Add(index);
            }
            public bool Exsist(string name)
            {
                return _indexList.Any(i => i.IndexName.ToUpper() == name.ToUpper());
            }

            public void AddStockToIndex(string indexName, Stock stock)
            {
                Index index = _indexList.Find(q => q.IndexName == indexName.ToUpper());
                index.StocksList.Add(stock);
            }

            public bool IsStockPartOfIndex(string indexName, Stock stock)
            {
                Index index = _indexList.Find(q => q.IndexName == indexName.ToUpper());
                return index.StocksList.Any(s => s == stock);
            }

            public int NumerOFStocks(string indexName)
            {
                Index index = _indexList.Find(q => q.IndexName == indexName.ToUpper());
                return index.StocksList.Count;
            }

            public void RemoveStockFromIndex(string indexName, Stock stock)
            {
                Index index = _indexList.Find(q => q.IndexName == indexName.ToUpper());
                index.StocksList.Remove(stock);
            }

            public decimal GetIndexValue(string indexName, DateTime inDateTime)
            {
                Index index = _indexList.Find(q => q.IndexName == indexName.ToUpper());
                index.CalculateValue(inDateTime);
                return index.IndexValue;
            }
        }

        public class Portfolio
        {
            string _ID;

            public string ID
            {
                get { return _ID; }
                set { _ID = value; }
            }
            Dictionary<Stock, int> _stocksAndShares;

            public Dictionary<Stock, int> StocksAndShares
            {
                get { return _stocksAndShares; }
                set { _stocksAndShares = value; }
            }

            public Portfolio(string ID)
            {
                this._ID = ID;
                this._stocksAndShares = new Dictionary<Stock, int>();
            }

            public void AddStock(Stock stock, int shares)
            {
                if (_stocksAndShares.ContainsKey(stock))
                {
                    int novoStanje = _stocksAndShares[stock] + shares;
                    _stocksAndShares[stock] = novoStanje;
                }
                else
                {
                    _stocksAndShares.Add(stock, shares);
                }
            }
            public void RemoveStock(Stock stock, int shares)
            {
                if (!(_stocksAndShares.Any(q => q.Key == stock))) throw new StockExchangeException("u portfoliju ne postoji dionica");
                int novoStanje = _stocksAndShares[stock] - shares;
                if (novoStanje < 0)
                {
                    throw new StockExchangeException("pokušava se ukloniti previse dionica");
                }
                else if (novoStanje == 0)
                {
                    _stocksAndShares.Remove(stock);
                }
                else
                {
                    _stocksAndShares[stock] = novoStanje;
                }
            }
            public void DeleteStock(Stock stock)
            {
                if (!(_stocksAndShares.Any(q => q.Key == stock))) throw new StockExchangeException("u portfoliju ne postoji dionica");
                _stocksAndShares.Remove(stock);
            }
            public decimal CalculateValue(DateTime date)
            {
                decimal bufferValue = 0;
                foreach (var i in _stocksAndShares)
                {
                    Stock stock = i.Key;
                    decimal price = stock.GetPrice(date);
                    bufferValue = bufferValue + (price * i.Value);
                }
                return bufferValue;
            }
        }

        public class PortfolioHandler
        {
            List<Portfolio> _portfolioList;

            public PortfolioHandler()
            {
                this._portfolioList = new List<Portfolio>();
            }

            public int Count()
            {
                return _portfolioList.Count;
            }

            public void Clear()
            {
                _portfolioList.Clear();
            }

            public void Add(Portfolio p)
            {
                _portfolioList.Add(p);
            }
            public bool Exsist(string ID)
            {
                return _portfolioList.Any(p => p.ID == ID);
            }

            public void AddPortfolio(string portfolioID)
            {
                Portfolio p = new Portfolio(portfolioID);
                _portfolioList.Add(p);
            }

            public void AddStockToPortfolio(string portfolioID, Stock stock, int shares)
            {
                long raspoloziviBrojDionica = stock.BrojDionica;
                long brojDionicaNakonDodavanja = 0;
                foreach (Portfolio portfolio in _portfolioList)
                {
                    if (portfolio.StocksAndShares.Any(q => q.Key == stock))
                    {
                        brojDionicaNakonDodavanja = brojDionicaNakonDodavanja + portfolio.StocksAndShares[stock];
                    }
                }
                brojDionicaNakonDodavanja = brojDionicaNakonDodavanja + shares;
                if (brojDionicaNakonDodavanja > raspoloziviBrojDionica) throw new StockExchangeException("pokusava se dodati vise dionica nego ih postoji");
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                p.AddStock(stock, shares);
            }

            public void RemoveStockFromPortfolio(string portfolioID, Stock stock, int shares)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                p.RemoveStock(stock, shares);
            }

            public void DeleteStock(string portfolioID, Stock stock)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                p.DeleteStock(stock);
            }

            public bool IsStockPart(string portfolioID, Stock stock)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                if (p.StocksAndShares.ContainsKey(stock))
                    return true;
                else
                    return false;
            }
            public int NumberOfStocks(string portfolioID)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                return p.StocksAndShares.Count;
            }

            public int NumberOfSharesOfStockInPortfolio(string portfolioID, Stock stock)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                return p.StocksAndShares[stock];
            }

            public decimal PortfolioValue(string portfolioID, DateTime date)
            {
                Portfolio p = _portfolioList.Find(q => q.ID == portfolioID);
                return p.CalculateValue(date);
            }
        }

        public class Price : IComparable<Price>
        {
            decimal _value;

            public decimal Value
            {
                get { return _value; }
                set { _value = value; }
            }
            DateTime _validStartDate;

            public DateTime ValidStartDate
            {
                get { return _validStartDate; }
                set { _validStartDate = value; }
            }
            public Price(decimal cijena, DateTime datum)
            {
                this._value = cijena;
                this._validStartDate = datum;
            }

            public int CompareTo(Price p)
            {
                return this._validStartDate.CompareTo(p.ValidStartDate);
            }
        }

        public class Stock
        {
            string _stockName;

            public string StockName
            {
                get { return _stockName; }
                set { _stockName = value; }
            }


            long _brojDionica;

            public long BrojDionica
            {
                get { return _brojDionica; }
                set { _brojDionica = value; }
            }


            List<Price> _priceList;

            internal List<Price> PriceList
            {
                get
                {
                    _priceList.Sort();
                    return _priceList;
                }
                set
                {
                    _priceList = value;
                }
            }

            public Stock(string name, long broj, decimal cijena, DateTime datum)
            {
                this._stockName = name.ToUpper();
                this._brojDionica = broj;
                this._priceList = new List<Price>();
                Price p = new Price(cijena, datum);
                _priceList.Add(p);
            }

            public decimal GetPrice(DateTime date)
            {
                decimal stockPrice = 0;
                foreach (Price price in PriceList.Where(p => p.ValidStartDate < date))
                {
                    stockPrice = price.Value;
                }
                return stockPrice;
            }

            public decimal GetInitialPrice()
            {
                return PriceList[0].Value;
            }

            public decimal GetLastPrice()
            {
                return PriceList[PriceList.Count - 1].Value;
            }
        }

        public class StockHandler
        {
            List<Stock> _stockList;

            public StockHandler()
            {
                this._stockList = new List<Stock>();
            }

            public int Count()
            {
                return _stockList.Count;
            }

            public void Clear()
            {
                _stockList.Clear();
            }

            public void Add(Stock s)
            {
                _stockList.Add(s);
            }

            public bool Exsist(string name)
            {
                return _stockList.Any(stock => stock.StockName.ToUpper() == name.ToUpper());
            }

            public void Remove(string name)
            {
                Stock s = _stockList.Find(q => q.StockName == name.ToUpper());
                _stockList.Remove(s);
            }

            public void AddPrice(string stockName, DateTime time, decimal price)
            {
                Stock s = _stockList.Find(q => q.StockName == stockName.ToUpper());
                Price p = new Price(price, time);
                if (s.PriceList.Any(q => q.ValidStartDate == time))
                {
                    Price pr = s.PriceList.Find(q => q.ValidStartDate == time);
                    s.PriceList.Remove(pr);
                    s.PriceList.Add(p);
                }
                else
                {
                    s.PriceList.Add(p);
                }
            }

            public decimal GetPrice(string name, DateTime date)
            {
                Stock s = _stockList.Find(q => q.StockName == name.ToUpper());
                return s.GetPrice(date);
            }

            public decimal GetInitialPrice(string stockName)
            {
                Stock s = _stockList.Find(q => q.StockName == stockName.ToUpper());
                return s.GetInitialPrice();
            }
            public decimal GetLastPrice(string stockName)
            {
                Stock s = _stockList.Find(q => q.StockName == stockName.ToUpper());
                return s.GetLastPrice();

            }
            public Stock GetStockByName(string stockName)
            {
                Stock s = _stockList.Find(q => q.StockName == stockName.ToUpper());
                return s;
            }

        }
    }


