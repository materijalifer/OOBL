﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;


namespace PrvaDomacaZadaca_Kalkulator{
    public class Factory{
        public static ICalculator CreateCalculator(){
            return new Kalkulator();
        }
    }
   
    public class Kalkulator : ICalculator
    {

        #region varijable
        private string Screen { get; set; }
        private double Memory { get; set; }
        private bool NewNumber { get; set; }
        public double FirstNumber { get; set; }
        private bool Clear { get; set; }
        public String Operation { get; set; }        
        public bool Error { get; set; }
        private int MaxDigits = 10;
        #endregion

        public Kalkulator(){
            this.Screen = "0";
            this.Memory = 0;
            this.NewNumber = false;
            this.FirstNumber = 0;
            this.Clear = false;
            this.Operation = "wait";
            this.Error = false;
        }

        //metode klase kalkulator

        public void Press(char PressedDigit){

            Double number;

            if (Double.TryParse(PressedDigit.ToString(), out number)){
                Digit(PressedDigit);
            }

            else{          
                switch (PressedDigit){
                
                    case '+':
                        BinaryOperation("plus");
                        break;
                    case '-':
                        BinaryOperation("minus");
                        break;
                    case '*':
                        BinaryOperation("times");
                        break;
                    case '/':
                        BinaryOperation("divide");
                        break;

                    case '=':
                        Equal();
                        break;
                    case ',':
                        DecimalDot();
                        break;
                    case 'M':
                        Sign();
                        break;

                    case 'S':
                        UnaryOperation("sinus");
                        break;
                    case 'K':
                        UnaryOperation("cosinus");
                        break;
                    case 'T':
                        UnaryOperation("tangens");
                        break;
                    case 'Q':
                        UnaryOperation("square");
                        break;
                    case 'R':
                        UnaryOperation("root");
                        break;
                    case 'I':
                        UnaryOperation("inverse");
                        break;

                    case 'P':
                        Save();
                        break;
                    case 'G':
                        Get();
                        break;
                    case 'C':
                        ClearScreen();
                        break;
                    case 'O':
                        Reset();
                        break;
                }
            }
        }
           
        public string GetCurrentDisplayState(){
            return this.Screen;
        }      

        private void Reset(){

            this.Screen = "0";
            this.Memory = 0; 

            this.FirstNumber = 0;
            this.NewNumber = false;

            this.Operation = "wait";
            this.Clear = false;
            this.Error = false;
        }
                


        private void Digit(Char digit){

            if (this.Clear || this.Screen == "0")
            {
                Screen = digit.ToString();
                this.Clear = false;
                this.NewNumber = true;
            }
            
            else
            {
                int numberOfExtraPlaces = 0;
                if (Screen.Contains(','))
                {
                    numberOfExtraPlaces++;
                }
                if (Screen.Contains('-'))
                {
                    numberOfExtraPlaces++;
                }

                if (Screen.Length - numberOfExtraPlaces < MaxDigits) Screen += digit;
            }

        }

        private void DecimalDot(){

            if (!Clear && !Screen.Contains(','))
            {
                Screen += ",";
            }
        }

        private void Sign(){

            if (!Error)
            {
                if (Convert.ToDouble(Screen) > 0)
                {
                    Screen = "-" + Screen;
                }
                else
                {
                    Screen = Screen.Substring(1);
                }
            }
        }



        private void UnaryOperation(String operation){

            double result = CalculateUnary(operation);
            Result(result);
        }

        private double CalculateUnary(String operation){

            double number = 0;
            try{
                number = Convert.ToDouble(Screen);
            }
            catch{
                return Double.NaN;
            }



            if (operation == "sinus"){
                number = Math.Sin(number);
            }
            else if (operation == "cosinus"){
                number = Math.Cos(number);
            }
            else if (operation == "tangens"){
                number = Math.Tan(number);
            }
            if (operation == "square")
            {
                number = Math.Pow(number, 2);
            }
            else if (operation == "root") {
                number = Math.Pow(number, 0.5);
            } 
            else if (operation == "inverse"){
                number = 1 / number;
            }

            return number;
        }

        

        private void BinaryOperation(String operation){

            String firstOperation = Operation;

            if (firstOperation != "wait" && this.NewNumber)
            {
                Double result = CalculateBinary(operation);
                Result(result);
            }

            SaveForBinaryOperation(operation);
            NewNumber = false;
            Clear = true;
            
        }

        private double BinaryOperation(){

            Double SecondNumber = 0;
            try{
                SecondNumber = Convert.ToDouble(Screen);
            }
            catch{
                return Double.NaN;
            }

            Double result = 0;

            switch (this.Operation){

                case "plus":
                    result = FirstNumber + SecondNumber;
                    break;
                case "minus":
                    result = FirstNumber - SecondNumber;
                    break;
                case "times":
                    result = FirstNumber * SecondNumber;
                    break;
                case "divide":
                    result = FirstNumber / SecondNumber;
                    break;
                default: break;
            }
            ResetScreen();
            return result;
        }

        private double CalculateBinary(String operation){
            double SecondNumber = 0;
            try{
                SecondNumber = Convert.ToDouble(Screen);
            }
            catch{
                return Double.NaN;
            }

            Double result = 0;

            if (this.Operation == "plus") {
                result = FirstNumber + SecondNumber;           
            }
            else if (this.Operation == "minus") {
                result = FirstNumber - SecondNumber;            
            }
            else if (this.Operation == "times")
            {
                result = FirstNumber * SecondNumber;
            }
            else if (this.Operation == "divide")
            {
                result = FirstNumber / SecondNumber;
            }
          
            ResetScreen();

            return result;
        }

        private void SaveForBinaryOperation(String operation){
            try{
                FirstNumber = Convert.ToDouble(Screen);
                Operation = operation;
            }
            catch{
                FirstNumber = Double.NaN;
            }
        }



        private void Equal(){
            double result = 0;

            if (Operation == "wait"){

                try{
                    Double.TryParse(this.Screen, out result);
                    this.Screen = result.ToString();
                }
                catch (Exception){
                    this.Screen = "-E-";
                }
            }
            else{
                result = BinaryOperation();
                Result(result);
            }
        }

        private void Result(double result){

            if (Double.IsInfinity(result) || Double.IsNaN(result)){
                HandleError();
            }
            else{
                long number = Math.Abs((long)result);
                int digitsNumberDot = number.ToString().Length;
                int digitsNumber = result.ToString().Length;


                if (digitsNumber > MaxDigits){
                    if (result.ToString().Contains(',') && digitsNumberDot < MaxDigits){
                        result = Math.Round(result, MaxDigits - digitsNumberDot);
                        Screen = result.ToString();
                    }
                    else{
                        HandleError();
                        Error = true;
                    }
                }
                else{
                    Screen = result.ToString();
                    Error = false;
                }
            }
            Clear = true;
        }

    

        private void Save(){
            double number;

            if(double.TryParse(Screen, out number)){
                Memory = number;
            }
            else{
                Memory = 0;
            }

        }

        private void Get(){
            Result(Memory);
        }

        
        
        private void ClearScreen(){
            Screen = "0";
            Error = false;
        }

        private void HandleError(){
            Screen = "-E-";
            Error = true;
            
        }

        private void ResetScreen(){
            Operation = "wait";
            FirstNumber = 0;           
        }        

    }
}
