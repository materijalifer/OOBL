﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string displayState, memory, operand;
        private char binaryOperator;
        private bool clearDispalyOnWrite, binaryOperatorSet, binaryOperatorConfirm, error;
        private char[] binaryOperators = { '+', '-', '*', '/' };
        private char[] unaryOperators = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G' };

        public Kalkulator()
        {
            displayState = "0";
            clearDispalyOnWrite = true;
            binaryOperatorSet = false;
            binaryOperatorConfirm = false;
            error = false;
            memory = operand = null;
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit) && !error) // Ako je znamenka
            {
                if (!(displayState.Equals("0") && inPressedDigit.Equals('0')))
                {
                    if (clearDispalyOnWrite)
                    {
                        displayState = inPressedDigit.ToString();
                        clearDispalyOnWrite = false;
                    }
                    else
                    {
                        if (hasSpaceForDigit())
                        {
                            displayState += inPressedDigit.ToString();
                        }
                    }
                }
                if (binaryOperatorSet)
                    binaryOperatorConfirm = true;
            }
            else if (inPressedDigit.Equals(',') && !error) // Ako je ,
            {
                if (clearDispalyOnWrite)
                {
                    displayState = "0,";
                    clearDispalyOnWrite = false;
                    binaryOperatorSet = false;
                }
                else
                {
                    if (hasSpaceForDigit() && !displayState.Contains(","))
                    {
                        displayState += inPressedDigit.ToString();
                    }
                }
                if (binaryOperatorSet)
                    binaryOperatorConfirm = true;
            }
            else if (unaryOperators.Contains(inPressedDigit) && !error) // striktno unarni operator
            {
                clearDispalyOnWrite = true;
                doUnaryOperation(inPressedDigit);
                checkDisplay();
            }
            else if (binaryOperators.Contains(inPressedDigit) && !error) // binarni operatori
            {
                if (binaryOperatorSet && binaryOperatorConfirm)
                {
                    doBinaryOperation(true);
                }
                else
                {
                    operand = displayState;
                }
                binaryOperatorConfirm = false;
                binaryOperator = inPressedDigit;
                binaryOperatorSet = true;
                clearDispalyOnWrite = true;
                checkDisplay();
            }
            else if (inPressedDigit.Equals('=') && !error) // Ako je =
            {
                if (binaryOperatorSet)
                {
                    doBinaryOperation(false);
                }
                clearDispalyOnWrite = true;
                binaryOperatorConfirm = false;
                checkDisplay();
            }
            else if (inPressedDigit.Equals('C')) // Clear
            {
                displayState = "0";
                clearDispalyOnWrite = true;
                error = false;
            }
            else if (inPressedDigit.Equals('O')) // Reset
            {
                displayState = "0";
                memory = operand = null;
                binaryOperatorSet = false;
                binaryOperatorConfirm = false;
                error = false;
            }
        }

        //Funkcija za provjeru da li ima mjesta za novu znamenku
        private bool hasSpaceForDigit()
        {
            int i = 0;
            foreach (char c in displayState)
            {
                if (Char.IsDigit(c))
                    i++;
            }
            if (i < 10)
                return true;
            else
                return false;
        }

        /*
         * Funkcija za izvođenje unarne operacije
         * Unarne operacije 'M','P' i 'G' moraju osigurati nastavak unosa brojeva
         */
        private void doUnaryOperation(char inPressedDigit)
        {
            double number = Double.Parse(displayState);
            switch (inPressedDigit)
            {
                case 'M':
                    if (displayState.StartsWith("-"))
                        displayState.Substring(1, displayState.Length);
                    else
                        displayState = "-" + displayState;
                    clearDispalyOnWrite = false;
                    break;
                case 'S':
                    displayState = Math.Sin(number).ToString();
                    break;
                case 'K':
                    displayState = Math.Cos(number).ToString();
                    break;
                case 'T':
                    displayState = Math.Tan(number).ToString();
                    break;
                case 'Q':
                    displayState = Math.Pow(number, 2).ToString();
                    break;
                case 'R':
                    if (number < 0)
                        displayState = "-E-";
                    else
                        displayState = Math.Sqrt(number).ToString();
                    break;
                case 'I':
                    if (number == 0)
                    {
                        displayState = "-E-";
                    }
                    else
                    {
                        displayState = (1 / number).ToString();
                    }
                    break;
                case 'P':
                    memory = displayState;
                    clearDispalyOnWrite = false;
                    break;
                case 'G':
                    if (memory != null)
                    {
                        displayState = memory;
                        clearDispalyOnWrite = false;
                    }
                    break;
                default:
                    displayState = "-E-";
                    break;
            }
        }

        /*
         * Funkcija za izvođenje binarne operacije nad spremljenim operandom i trenutnim stanjem ekrana
         * bool next označava dali se operacije nastavljaju ili je uzrok poziva funkcije "="
         * Ako se nastavalja (true) osim sto se rezultat prikazuje na ekranu sprema se i u operand
         * inače samo se ispisuje na ekranu 
         */
        private void doBinaryOperation(bool next)
        {
            string temp;
            switch (binaryOperator)
            {
                case '+':
                    temp = (Double.Parse(operand) + Double.Parse(displayState)).ToString();
                    break;
                case '-':
                    temp = (Double.Parse(operand) - Double.Parse(displayState)).ToString();
                    break;
                case '/':
                    if (Double.Parse(displayState).Equals(0))
                        temp = "-E-";
                    else
                        temp = (Double.Parse(operand) / Double.Parse(displayState)).ToString();
                    break;
                case '*':
                    temp = (Double.Parse(operand) * Double.Parse(displayState)).ToString();
                    break;
                default:
                    temp = "-E-";
                    break;
            }
            displayState = temp;
            if (next)
                operand = temp;
        }

        /*
         * Funkcija za ispravak stanja ekrana ako je on ne ispravan
         * Neispravnosti:
         *      - broj veći od 9999999999
         *      - decimalni broj završava sa više nula
         *      - decimalni broj koji nije zaokružen na ukupno 10 znamenaka
         */
        private void checkDisplay()
        {
            if (displayState.Equals("-E-"))
            {
                error = true;
                return;
            }

            double number = Double.Parse(displayState);
            int n = (int)(number), d = 0;

            if (number > 9999999999)
            {
                displayState = "-E-";
                error = true;
                return;
            }

            // zaokruživanje
            do
            {
                n /= 10;
                d++;
            } while (n > 0);
            displayState = Math.Round(number, 10 - d).ToString();

            // Ukloni višak 0 ako je broj decimalni
            if (displayState.Contains(","))
            {
                string[] s = displayState.Split(',');
                if (s[1].Length > 1)
                {
                    while (s[1].EndsWith("0"))
                        s[1] = s[1].Substring(0, s[1].Length - 1);
                }
                displayState = s[0];
                if (s[1].Length > 0)
                {
                    displayState += "," + s[1];
                }
            }
        }
    }
}
