﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> _listOfStocks;
         private List<Index> _listOfIndices;
         private List<Portfolio> _listOfPortfolios; 

         public  StockExchange()
         {
             _listOfStocks = new List<Stock>();
             _listOfIndices = new List<Index>();
             _listOfPortfolios = new List<Portfolio>();
         }

         /// <summary>
         /// Dodaje dionicu s početnom cijenom na burzu.
         /// Ako dionica već postoji ili su cijena ili broj share manji ili jednaki nuli baca exception.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <param name="inNumberOfShares"></param>
         /// <param name="inInitialPrice"></param>
         /// <param name="inTimeStamp"></param>
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock name exists!");
             }
             if (inInitialPrice <= 0 || inNumberOfShares <= 0)
             {
                 throw new StockExchangeException("Error! Initial price or number of shares are negative number or 0!");
             }
             _listOfStocks.Add(new Stock( inStockName.ToLower(),inNumberOfShares,inInitialPrice,inTimeStamp));
         }

         /// <summary>
         /// Briše dionicu s burze.
         /// Briše dionicu iz indexa i portfelja u kojima postoji.
         /// Ako dionica ne postoji baca exception.
         /// </summary>
         /// <param name="inStockName"></param>
         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                throw  new StockExchangeException("Error! Stock name doesn't exist!");
             }

             foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
             {
                 
                 foreach (Index index in _listOfIndices.Where(index => IsStockPartOfIndex(index.IndexName,inStockName)))
                 {
                     RemoveStockFromIndex(index.IndexName,inStockName);
                 }
                 foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName)))
                 {
                     RemoveStockFromPortfolio(portfolio.PortfolioID,inStockName);
                 }
                 _listOfStocks.Remove(stock);
                 break;
             }
         }

         /// <summary>
         /// Provjerava postoji li tražena dionica na burzi.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public bool StockExists(string inStockName)
         {
             return _listOfStocks.Any() && _listOfStocks.Any(stock => stock.StockName == inStockName.ToLower());
         }

         /// <summary>
         /// Vraća broj dionica na buri.
         /// </summary>
         /// <returns></returns>
         public int NumberOfStocks()
         {
             return _listOfStocks.Count();
         }

         /// <summary>
         /// Postavlja cijenu dionice za određeno vrijeme.
         /// Ako dionica ne postoji na burzi, vrijeme je već definirano
         /// ili je cijena negativni broj ili nula baca exception.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <param name="inIimeStamp"></param>
         /// <param name="inStockValue"></param>
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock name doesn't exist!");
             }
             
             foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
             {
                 if (stock.ListOfStockPrices.Any(stockPrice => stockPrice.TimeStamp.Ticks == inIimeStamp.Ticks))
                 {
                    throw new StockExchangeException("Stock price for this timestamp exists!");                    
                 }
                 if (inStockValue <= 0)
                 {
                     throw new StockExchangeException("Error! Price is negative number or 0!");
                 }
                 stock.ListOfStockPrices.Add(new StockPrice(inIimeStamp, inStockValue));
                 break;
             }
         }

         /// <summary>
         /// Dohvaća cijenu dionice za neko vrijeme.
         /// Ako dionice nema na burzi baca exception.
         /// Ako cijena dionice nije definirana za zadano vrijeme baca exception.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <param name="inTimeStamp"></param>
         /// <returns></returns>
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock name doesn't exist!");
             }
             foreach (var stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
             {
                 decimal price = stock.GetPrice(inTimeStamp);
                 if (price == 0)
                 {
                     throw new StockExchangeException("Stock price doesn't exist!"); 
                 }
                 return price;
             }
             throw new StockExchangeException("Error!");
         }

         /// <summary>
         /// Dohvaća početnu cijenu dionice.
         /// Ako dionice nema na burzi baca exception.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock name doesn't exist!");
             }
             foreach (var stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
             {
                 return stock.GetInitalPrice();
             }
             throw new StockExchangeException("Stock doesn't exist!");
         }

         /// <summary>
         /// Dohvaća zadnju cijenu dionice.
         /// Ako dionice nema na burzi vraća exception.
         /// </summary>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock name doesn't exist!");
             }
             foreach (var stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
             {
                 return stock.GetLastPrice();
             }

             throw new StockExchangeException("Stock doesn't exist!");
         }

         /// <summary>
         /// Stvara novi indeks na burzi.
         /// Ako postoji već takav indeks baca exception.
         /// Ako tip ne odgovara AVERAGE ili WEIGHTED tipu baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inIndexType"></param>
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Error! Index name exists!");
             }
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Error! Index type doesn't exist!");
             }
             _listOfIndices.Add(new Index(inIndexName.ToLower(),inIndexType));
         }

         /// <summary>
         /// Dodaje dionicu u indeks.
         /// Ako dionica ili indeks ne postoje ili je dionica već u indeksu
         /// baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inStockName"></param>
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Error! Index  doesn't exist!");
             }
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 throw new StockExchangeException("Error! Stock  is part of index!");
             }
             bool add = false;
             foreach (Index index in _listOfIndices.Where(index => index.IndexName == inIndexName.ToLower()))
             {
                 foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
                 {
                     index.ListOfStocks.Add(stock);
                     add = true;
                     break;
                 }
                 if (add) break;
             }
         }

         /// <summary>
         /// Briše dionicu iz indeksa.
         /// Ako dionica ili indeks ne postoje ili  dionica nije u indeksu
         /// baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inStockName"></param>
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             if (!IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Error! Index  doesn't exist!");
             }
             if (!IsStockPartOfIndex(inIndexName, inStockName))
             {
                 throw new StockExchangeException("Error! Stock  is not part of index!");
             }
             bool remove = false;
             foreach (Index index in _listOfIndices.Where(index => index.IndexName == inIndexName.ToLower()))
             {
                 foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
                 {
                     index.ListOfStocks.Remove(stock);
                     remove = true;
                     break;
                 }
                 if (remove) break;
             }
         }

         /// <summary>
         /// Provjerava je li dionica u indeksu.
         /// Ako ne postoji indeks ili dionica baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Error! Index  doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }

             foreach (Index index in _listOfIndices.Where(index=> index.IndexName == inIndexName.ToLower()))
             {
                 return index.IsStockPartOfIndex(inStockName.ToLower());
             }

             return false;
         }

         /// <summary>
         /// Dohvaća vrijednost indeksa.
         /// Ako indeks ne postoji baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inTimeStamp"></param>
         /// <returns></returns>
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Error! Index  doesn't exist!");
             }
             foreach (Index index in _listOfIndices.Where(index => index.IndexName == inIndexName.ToLower()))
             {
                 return index.GetIndexValue(inTimeStamp);
             }

             throw new StockExchangeException("Error! Index  doesn't exist!");
         }

         /// <summary>
         /// Provjerava postoji li traženi indeks na burzi.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <returns></returns>
         public bool IndexExists(string inIndexName)
         {
             return _listOfIndices.Any() && _listOfIndices.Any(index => index.IndexName == inIndexName.ToLower());
         }

         /// <summary>
         /// Dohvaća broj indeksa na burzi.
         /// </summary>
         /// <returns></returns>
         public int NumberOfIndices()
         {
             return _listOfIndices.Count();
         }

         /// <summary>
         /// Dohvaća broj dionica u traženom indeksu.
         /// Ako indeks ne postoji baca exception.
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <returns></returns>
         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Error! Index  doesn't exist!");
             }
             foreach (Index index in _listOfIndices.Where(index => index.IndexName == inIndexName.ToLower()))
             {
                 return index.NumberOfStocks();
             }

             throw new StockExchangeException("Error! Index doesn't exist!");
         }

         /// <summary>
         /// Stvara novi portfelj na burzi.
         /// Ako isti već postoji baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio exists!");
             }
             _listOfPortfolios.Add(new Portfolio(inPortfolioID));
         }

         /// <summary>
         /// Dodaje određeni broj dionica u portfelj.
         /// Ako portfelj ili dionice ne postoje baca exception.
         /// Ako je broj dionica manji ili jednak nuli ili veći od sveukupnog broja dionica
         /// baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="inStockName"></param>
         /// <param name="numberOfShares"></param>
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }

             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
                 {
                     if (stock.NumberOfShares < numberOfShares || numberOfShares <= 0)
                     {
                         throw new StockExchangeException("Error! Not enough shares!");
                     }

                     stock.NumberOfShares -= numberOfShares;
                     if(IsStockPartOfPortfolio(inPortfolioID,inStockName))
                     {
                         foreach (PortfolioStock portfolioStock in portfolio.ListOfStockInPf.Where(portfolioStock => portfolioStock.Stock.StockName == inStockName.ToLower()))
                         {
                             portfolioStock.NumberOfShares += numberOfShares;
                             return;
                         }
                     }                     
                     portfolio.ListOfStockInPf.Add(new PortfolioStock(stock,numberOfShares));
                     return;
                 }
             } 
         }

         /// <summary>
         /// Briše određeni broj dionica iz portfelja.
         /// Ako portfelj ili dionica ne postoje baca exception.
         /// Ako dionica nije dio portfelja baca exception.
         /// Ako je broj dionica veći od broja dionica u portfelju ili negativan ili jednak nuli
         /// baca exception.
         /// U slučaju da je broj jednak dionica se briše iz portfelja.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="inStockName"></param>
         /// <param name="numberOfShares"></param>
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             if(!IsStockPartOfPortfolio(inPortfolioID,inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist in portfolio!");
             }

             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 foreach (PortfolioStock portfolioStock in portfolio.ListOfStockInPf.Where(portfolioStock => portfolioStock.Stock.StockName == inStockName.ToLower()))
                 {
                     if(portfolioStock.NumberOfShares < numberOfShares || numberOfShares <= 0)
                     {
                         throw new StockExchangeException("Error!");
                     }

                     foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
                     {
                         stock.NumberOfShares += numberOfShares;
                     }
                     if (portfolioStock.NumberOfShares == numberOfShares)
                     {
                         portfolio.ListOfStockInPf.Remove(portfolioStock);
                         break;
                     }
                     else
                     {
                         portfolioStock.NumberOfShares -= numberOfShares;
                         break;
                     }
                 }
             } 
         }

         /// <summary>
         /// Briše dionicu iz portfelja.
         /// U slučaju da portfelj ili dionica ne postoje baca exception.
         /// Ako dionica nije dio portfelja baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="inStockName"></param>
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist in portfolio!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 foreach (PortfolioStock portfolioStock in portfolio.ListOfStockInPf)
                 {
                     if (portfolioStock.Stock.StockName == inStockName.ToLower())
                     {
                         foreach (Stock stock in _listOfStocks.Where(stock => stock.StockName == inStockName.ToLower()))
                         {
                             stock.NumberOfShares += portfolioStock.Stock.NumberOfShares;
                         }
                         portfolio.ListOfStockInPf.Remove(portfolioStock);
                         break;
                     }
                 }
             }
         }

         /// <summary>
         /// Dohvaća broj portfelja na burzi.
         /// </summary>
         /// <returns></returns>
         public int NumberOfPortfolios()
         {
             return _listOfPortfolios.Count();
         }

         /// <summary>
         /// Dohvaća broj dionica u traženom portfelju.
         /// Ako portfelj ne postoji baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <returns></returns>
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio =>portfolio.PortfolioID == inPortfolioID))
             {
                 return portfolio.GetNumberOfPortfolioStock();
             }

             throw new StockExchangeException("Error!");
         }

         /// <summary>
         /// Provjerava postoji li traženi portfelj na burzi.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <returns></returns>
         public bool PortfolioExists(string inPortfolioID)
         {
             return _listOfPortfolios.Any() && _listOfPortfolios.Any(portfolios => portfolios.PortfolioID == inPortfolioID);
         }

         /// <summary>
         /// Provjerava nalazi li se dionica u portfelju.
         /// Ako dionica ili portfelj ne postoje na burzi baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 return portfolio.IsStockPartOfPortfolio(inStockName);
             }

             throw new StockExchangeException("Error!");
         }

         /// <summary>
         /// Dohvaća broj dionica u traženom porfelju.
         /// Ako portfelj ne postoji baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="inStockName"></param>
         /// <returns></returns>
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Error! Stock doesn't exist!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 return portfolio.GetNumberOfShares(inStockName);
             }

             throw new StockExchangeException("Error!");
         }

         /// <summary>
         /// Dohvaća vrijednost portfelja.
         /// Ako portfelj ne postoji baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="timeStamp"></param>
         /// <returns></returns>
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 return portfolio.GetPortfolioValue(timeStamp);
             }

             throw new StockExchangeException("Error!");
         }

         /// <summary>
         /// Dohvaća mjesečnu promjenu vrijednosti portfelja.
         /// Ako ikoja dionica nema definiranu cijenu za traženi mjesec baca exception.
         /// </summary>
         /// <param name="inPortfolioID"></param>
         /// <param name="Year"></param>
         /// <param name="Month"></param>
         /// <returns></returns>
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Error! Portfolio doesn't exist!");
             }
             foreach (Portfolio portfolio in _listOfPortfolios.Where(portfolio => portfolio.PortfolioID == inPortfolioID))
             {
                 return portfolio.GetPortfolioPercantage(Year,Month);
             }

             throw new StockExchangeException("Error!");
         }
     }

    /// <summary>
    /// Klasa zaliha. Sadrži ime zalihe, broj dionica i listu definiranih cijena dionica.
    /// </summary>
    public class Stock
    {
        public string StockName { get; set; }

        public long NumberOfShares { get; set; }

        public List<StockPrice> ListOfStockPrices { get; set; }

        public Stock(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
        {
            StockName = stockName;
            NumberOfShares = numberOfShares;
            ListOfStockPrices = new List<StockPrice> {new StockPrice(timeStamp, initialPrice)};
        }

        /// <summary>
        /// Vraća početnu cijenu dionice
        /// </summary>
        /// <returns></returns>
        public decimal GetInitalPrice()
        {
            DateTime initialTime = ListOfStockPrices[0].TimeStamp;
            decimal lastPrice = ListOfStockPrices[0].Price;

            foreach (StockPrice stockPrice in ListOfStockPrices.Where(stockPrice => stockPrice.TimeStamp < initialTime))
            {
                lastPrice = stockPrice.Price;
            }

            return lastPrice;
        }

        /// <summary>
        /// Vraća cijenu dionice za određeno vrijeme.
        /// Ako je cijena nedefinirana za to vrijeme baca exception.
        /// </summary>
        /// <param name="inTimeStamp"></param>
        /// <returns></returns>
        public decimal GetPrice(DateTime inTimeStamp)
        {
            long min = 0;
            decimal price = 0;
           
          
            foreach (StockPrice stockPr in ListOfStockPrices)
            {
                if (inTimeStamp.Ticks - stockPr.TimeStamp.Ticks >= 0)
                {
                    min = inTimeStamp.Ticks - stockPr.TimeStamp.Ticks;
                    price = stockPr.Price;
                    break;
                }
            }
            foreach (StockPrice stockPrice in ListOfStockPrices)
            {
                if (inTimeStamp.Ticks - stockPrice.TimeStamp.Ticks < min &&
                    inTimeStamp.Ticks - stockPrice.TimeStamp.Ticks >= 0)
                {
                    price = stockPrice.Price;
                    min = inTimeStamp.Ticks - stockPrice.TimeStamp.Ticks;
                }
            }
            if (price == 0) throw new StockExchangeException("Error!");
            return price;
        }

        /// <summary>
        /// Vraća zadnju cijenu.
        /// </summary>
        /// <returns></returns>
        public decimal GetLastPrice()
        {
            DateTime newestTime = ListOfStockPrices[0].TimeStamp;
            decimal lastPrice = ListOfStockPrices[0].Price;

            foreach (StockPrice stockPrice in ListOfStockPrices.Where(stockPrice => stockPrice.TimeStamp > newestTime))
            {
                lastPrice = stockPrice.Price;
            }

            return lastPrice;
        }
    }

    /// <summary>
    /// Klasa cijena dionice sadrži cijenu i vrijeme kada je definirana ta cijena.
    /// </summary>
    public class StockPrice
    {
        public decimal Price { get; set;}

        public DateTime TimeStamp { get; set; }

        public StockPrice(DateTime timeStamp, decimal price)
        {
            Price = price;
            TimeStamp = timeStamp;
        }
    }

    /// <summary>
    /// Klasa indeks sadrži naziv, tip i listu dionica od kojih se sastoji.
    /// </summary>
    public class Index
    {
        public string IndexName { get; set; }

        public IndexTypes IndexType { get; set; }

        public List<Stock> ListOfStocks { get; set; } 

        public Index(string indexName, IndexTypes type)
        {
            IndexName = indexName;
            IndexType = type;
            ListOfStocks = new List<Stock>();
        }
        
        /// <summary>
        ///  vraća broj dionica
        /// </summary>
        /// <returns></returns>
        public int NumberOfStocks()
        {
            return ListOfStocks.Count();
        }

        /// <summary>
        /// provjerava da li je dionica u indeksu.
        /// </summary>
        /// <param name="stockName"></param>
        /// <returns></returns>
        public bool IsStockPartOfIndex(string stockName)
        {
            return ListOfStocks.Any(stock => stock.StockName == stockName.ToLower());
        }

        /// <summary>
        /// vraća vrijednost indexa ovisno o tipu indeksa
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public decimal GetIndexValue(DateTime timeStamp)
        {
            decimal indexValue = 0;

            switch (IndexType)
            {
              case IndexTypes.AVERAGE:
                    indexValue = GetAverageValue(timeStamp);
                    break;
              case IndexTypes.WEIGHTED:
                    indexValue = GetWeightedValue(timeStamp);
                    break;
            }

            return indexValue;
        }

        /// <summary>
        /// vraća vrijednost indexa koji je tipa average
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        private decimal GetAverageValue(DateTime timeStamp)
        {
            decimal value = 0;
            int counter = 0;

            foreach (Stock stock in ListOfStocks)
            {
                value += stock.GetPrice(timeStamp);
                counter++;
            }
            if (counter == 0) return 0;
            return Math.Round(value/counter,3);
        }

        /// <summary>
        /// vraća vrijednost indeksa koji je tipa weigthed
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        private decimal GetWeightedValue(DateTime timeStamp)
        {
            decimal weightValue = 0;

            decimal totalValue = ListOfStocks.Sum(stock => stock.NumberOfShares*stock.GetPrice(timeStamp));
            
            foreach (Stock stock in ListOfStocks)
            {
                decimal price = stock.GetPrice(timeStamp);
                decimal weightFactor = (price*stock.NumberOfShares)/totalValue;
                weightValue += price*weightFactor;
            }

            return Math.Round(weightValue,3);
        }
    }

    /// <summary>
    /// Klasa portfelj. Sadrži id i listu dionica u portfelju
    /// </summary>
    public class Portfolio
    {
        public string PortfolioID { get; set; }
        public List<PortfolioStock> ListOfStockInPf { get; set; }

        public Portfolio(string portfolioID)
        {
            PortfolioID = portfolioID;
            ListOfStockInPf = new List<PortfolioStock>();
        }

        /// <summary>
        /// vraća broj dionica u portfelju
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfPortfolioStock()
        {
            return ListOfStockInPf.Count();
        }

        /// <summary>
        /// provjerava je li dionica dio portfelja
        /// </summary>
        /// <param name="stockName"></param>
        /// <returns></returns>
        public bool IsStockPartOfPortfolio(string stockName)
        {
            return ListOfStockInPf.Any(portfolioStock => portfolioStock.Stock.StockName == stockName.ToLower());
        }

        /// <summary>
        /// vraća broj dionica.
        /// </summary>
        /// <param name="stockName"></param>
        /// <returns></returns>
        public int GetNumberOfShares(string stockName)
        {
            foreach (PortfolioStock portfolioStock in ListOfStockInPf.Where(portfolioStock => portfolioStock.Stock.StockName == stockName.ToLower()))
            {
                
                return portfolioStock.NumberOfShares;
            }
            throw new StockExchangeException("Error!");
        }

        /// <summary>
        /// vraća vrijednost portfelja
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal totalValue = 0;
            foreach (PortfolioStock portfolioStock in ListOfStockInPf)
            {
                totalValue +=portfolioStock.Stock.GetPrice(timeStamp)*portfolioStock.NumberOfShares;
            }
            return Math.Round(totalValue,3);
        }

        /// <summary>
        /// vraća mjesečnu promjenu portfelja
        /// </summary>
        /// <param name="Year"></param>
        /// <param name="Month"></param>
        /// <returns></returns>
        public decimal GetPortfolioPercantage(int Year, int Month)
        {
            DateTime firstOfMonth = new DateTime(Year,Month,1,0,0,0,0);
            int daysInMonth = DateTime.DaysInMonth(Year, Month);
            DateTime lasttOfMonth = new DateTime(Year,Month,daysInMonth,23,59,59,999);
            decimal totalValueFirst = 0;
            decimal totalValueLast = 0;

            foreach (PortfolioStock portfolioStock in ListOfStockInPf)
            {
                totalValueFirst += portfolioStock.Stock.GetPrice(firstOfMonth);
                totalValueLast  += portfolioStock.Stock.GetPrice(lasttOfMonth);
            }
            if (totalValueLast == 0) return 0;
            return Math.Round(((totalValueLast-totalValueFirst)/totalValueFirst)*100, 3);
        }
    }
    
    /// <summary>
    /// Klasa porfelj dionica sadrži dionicu i broj koliko ih ima.
    /// </summary>
    public class PortfolioStock
    {
        public Stock Stock { get; set; }
        public int NumberOfShares { get; set; }

        public PortfolioStock(Stock stock, int numberOfShares)
        {
            Stock = stock;
            NumberOfShares = numberOfShares;
        }
    }

}
