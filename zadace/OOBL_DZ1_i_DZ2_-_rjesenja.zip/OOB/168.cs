﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public enum UnaryOperator
    {
        Sine = (int)('S'),
        Cosine = (int)('K'),
        Tangent = (int)('T'),
        Square = (int)('Q'),
        Root = (int)('R'),
        Inverse = (int)('I'),
        Minus = (int)('M')

    }

    public enum BinaryOperator
    {
        Plus = (int)('+'),
        Minus = (int)('-'),
        Multiplication = (int)('*'),
        Division = (int)('/')
    }

    public enum MemoryOperator
    {
        Put = (int)('P'),
        Get = (int)('G'),
        Clear = (int)('C'),
        OnOff = (int)('O')
    }

    public class Kalkulator : ICalculator
    {

        public const string STR_ERROR = "-E-";
        public const int MAX_DIGIT_COUNT = 10;


        private string _currentDisplayState = "0";
        private string _memoryField;
        private int _digitCount = 0;
        private bool _isPreviousInputBinaryOperator; //kontrolna varijabla prilikom unosa više binarnih operatora za redom
        private double _finalSum = 0;
        private BinaryOperator _prevoiusBinaryOperator = BinaryOperator.Plus;


        public void Press(char inPressedDigit)
        {
            if (_digitCount == 0 && Char.IsDigit(inPressedDigit)) //unos prve znamenke
            {
                if (Int32.Parse(inPressedDigit.ToString()) != 0)
                {
                    _currentDisplayState = inPressedDigit.ToString();
                    _digitCount++;
                    _isPreviousInputBinaryOperator = false;
                }
            }
            else if (_digitCount <= MAX_DIGIT_COUNT && Char.IsDigit(inPressedDigit)) //unos ostalih znamenki
            {
                _currentDisplayState += inPressedDigit;
                _digitCount++;
                _isPreviousInputBinaryOperator = false;
            }
            else if (inPressedDigit == ',') //unos zareza
            {
                if (!_currentDisplayState.Contains(','))
                {
                    if (_digitCount == 0)
                    {
                        _currentDisplayState = "0,";
                        _digitCount++;
                    }
                    else
                        _currentDisplayState += inPressedDigit;
                    _isPreviousInputBinaryOperator = false;
                }
            }
            else if (inPressedDigit == '=') //unos znaka jednakosti
            {
                ExecuteBinaryOperation();
                _currentDisplayState = (_finalSum.ToString()).Replace('.', ',');
                RemoveExtraZeroes();
                RoundDispayedNumber();
                InitializeCalculator(null); //postavke za slučaj da se isti kalkulator koristi za ponovni izračun     
            }
            else //operatori
            {
                RemoveExtraZeroes();

                if (Enum.IsDefined(typeof(UnaryOperator), (int)inPressedDigit)) //unarni operator
                {
                    _currentDisplayState = ExecuteUnaryOperation((UnaryOperator)Enum.Parse(typeof(UnaryOperator), ((int)inPressedDigit).ToString()));
                    RemoveExtraZeroes();
                    RoundDispayedNumber();
                    _isPreviousInputBinaryOperator = false;
                }
                else if (Enum.IsDefined(typeof(BinaryOperator), (int)inPressedDigit)) //binarni operator
                {
                    if (!_isPreviousInputBinaryOperator)
                    {
                        ExecuteBinaryOperation();
                        _digitCount = 0;
                        _isPreviousInputBinaryOperator = true;
                    }
                    _prevoiusBinaryOperator = (BinaryOperator)Enum.Parse(typeof(BinaryOperator), ((int)inPressedDigit).ToString());
                }
                else if (Enum.IsDefined(typeof(MemoryOperator), (int)inPressedDigit)) //memorijski operator
                {
                    ExecuteMemoryOperation((MemoryOperator)Enum.Parse(typeof(MemoryOperator), ((int)inPressedDigit).ToString()));
                }
            }
        }


        private string ExecuteUnaryOperation(UnaryOperator unaryOperator)
        {
            double _currentDisplayStateInt = Convert.ToDouble(_currentDisplayState);
            switch (unaryOperator)
            {
                case UnaryOperator.Cosine:
                    _currentDisplayStateInt = Math.Cos(_currentDisplayStateInt);
                    break;
                case UnaryOperator.Inverse:
                    if (_currentDisplayStateInt != 0)
                    {
                        _currentDisplayStateInt = (1 / _currentDisplayStateInt);
                        break;
                    }
                    else
                    {
                        return STR_ERROR;
                    }
                case UnaryOperator.Minus:
                    _currentDisplayStateInt *= -1;
                    break;
                case UnaryOperator.Root:
                    _currentDisplayStateInt = Math.Sqrt(_currentDisplayStateInt);
                    break;
                case UnaryOperator.Sine:
                    _currentDisplayStateInt = Math.Sin(_currentDisplayStateInt);
                    break;
                case UnaryOperator.Square:
                    _currentDisplayStateInt = Math.Pow(_currentDisplayStateInt, 2);
                    break;
                case UnaryOperator.Tangent:
                    _currentDisplayStateInt = Math.Tan(_currentDisplayStateInt);
                    break;
                default:
                    return STR_ERROR;
            }
            return (_currentDisplayStateInt.ToString()).Replace('.', ',');

        }

        private void ExecuteBinaryOperation()
        {
            double _currentDisplayStateInt = Convert.ToDouble(_currentDisplayState);
            switch (_prevoiusBinaryOperator)
            {
                case BinaryOperator.Plus:
                    _finalSum += _currentDisplayStateInt;
                    break;
                case BinaryOperator.Minus:
                    _finalSum -= _currentDisplayStateInt;
                    break;
                case BinaryOperator.Multiplication:
                    _finalSum *= _currentDisplayStateInt;
                    break;
                case BinaryOperator.Division:
                    _finalSum /= _currentDisplayStateInt;
                    break;
            }
        }

        private void ExecuteMemoryOperation(MemoryOperator memoryOperator)
        {
            switch (memoryOperator)
            {
                case MemoryOperator.Clear:
                    _digitCount = 0;
                    break;
                case MemoryOperator.OnOff:
                    InitializeCalculator(MemoryOperator.OnOff);
                    break;
                case MemoryOperator.Put:
                    _memoryField = _currentDisplayState;
                    break;
                case MemoryOperator.Get:
                    _currentDisplayState = _memoryField;
                    break;
            }
        }

        private void RoundDispayedNumber()
        {
            if (_currentDisplayState.Count(x => Char.IsDigit(x)) <= MAX_DIGIT_COUNT)
            {
                return;
            }
            else if (!_currentDisplayState.Contains(',')) //cjelobrojni dio je duži od 10 znamenki
            {
                _currentDisplayState = STR_ERROR;
            }
            else
            {
                bool containsMinus = _currentDisplayState.Contains('-');
                bool containsComma = _currentDisplayState.Contains(',');
                int commaIndex = _currentDisplayState.IndexOf(',');
                _currentDisplayState = Math.Round(Double.Parse(_currentDisplayState), MAX_DIGIT_COUNT + Convert.ToInt32(containsMinus) + Convert.ToInt32(containsComma) - 1 - commaIndex).ToString();
                // Math.Round(Double.Parse(_currentDisplayState), posljednji (dopušteni) indeks niza - indeks zareza)
            }

        }

        private void RemoveExtraZeroes()
        {
            while (_currentDisplayState[_currentDisplayState.Length - 1] == '0' && _currentDisplayState.Contains(',') || _currentDisplayState[_currentDisplayState.Length - 1] == ',')
            {
                switch (_currentDisplayState[_currentDisplayState.Length - 1])
                {
                    case '0':
                        _currentDisplayState = _currentDisplayState.Remove(_currentDisplayState.Length - 1);
                        break;
                    case ',':
                        _currentDisplayState = _currentDisplayState.Remove(_currentDisplayState.Length - 1);
                        return;
                }
            }
        }

        private void InitializeCalculator(Object sender)
        {
            _digitCount = 0;
            _isPreviousInputBinaryOperator = false;
            _prevoiusBinaryOperator = BinaryOperator.Plus;
            _finalSum = 0;

            if (sender is MemoryOperator)
            {
                //if ((MemoryOperator)Enum.Parse(typeof(MemoryOperator), sender.ToString()) == MemoryOperator.OnOff)
                _currentDisplayState = "0";
                _memoryField = String.Empty;
            }
        }

        public string GetCurrentDisplayState()
        {
            return _currentDisplayState;
        }
    }
}
