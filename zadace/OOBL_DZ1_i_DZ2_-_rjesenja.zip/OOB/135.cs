﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        // za svaku burzu stvaraju se repozitoriji dionica, indeksa i portfelja
        StockRepository stockRepository = new StockRepository();
        IndexRepository indexRepository = new IndexRepository();
        PortfolioRepository portfolioRepository = new PortfolioRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stockRepository.AddNewStock(newStock);
        }

        public void DelistStock(string inStockName)
        {
            stockRepository.DeleteStockByName(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return stockRepository.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return stockRepository.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            stockRepository.GetStockByName(inStockName).SetNewStockPrice(inTimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return stockRepository.GetStockByName(inStockName).GetStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return stockRepository.GetStockByName(inStockName).InitialStockPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return stockRepository.GetStockByName(inStockName).GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index newIndex = new Index(inIndexName, inIndexType);
            indexRepository.AddNewIndex(newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            indexRepository.GetIndexByName(inIndexName).AddStockToIndex(stockRepository.GetStockByName(inStockName));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            indexRepository.GetIndexByName(inIndexName).RemoveStockFromIndex(stockRepository.GetStockByName(inStockName));
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return indexRepository.GetIndexByName(inIndexName).StockExistsInIndex(stockRepository.GetStockByName(inStockName).Name);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return indexRepository.GetIndexByName(inIndexName).GetIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return indexRepository.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return indexRepository.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return indexRepository.GetIndexByName(inIndexName).NumberOfContainedStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio newPortfolio = new Portfolio(inPortfolioID);
            portfolioRepository.AddNewPortfolio(newPortfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = stockRepository.GetStockByName(inStockName);
            // ukoliko ima slobodnih numberOfShares dionica ove vrste dodaj dionice u portfelj
            if (stock.NumberOfShares >= numberOfShares)
            {
                stock.NumberOfShares -= numberOfShares;
                portfolioRepository.GetPortfolioById(inPortfolioID).AddStock(stock, numberOfShares);
            }
            else
            // inače baci iznimku
            {
                throw new StockExchangeException("Ne postoji toliko dionica!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            portfolioRepository.GetPortfolioById(inPortfolioID).RemoveStock(stockRepository.GetStockByName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            portfolioRepository.GetPortfolioById(inPortfolioID).RemoveStock(stockRepository.GetStockByName(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return portfolioRepository.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return portfolioRepository.GetPortfolioById(inPortfolioID).NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolioRepository.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return portfolioRepository.GetPortfolioById(inPortfolioID).IsStockPartOfPortfolio(stockRepository.GetStockByName(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return portfolioRepository.GetPortfolioById(inPortfolioID).NumberOfSharesOfStockInPortfolio(stockRepository.GetStockByName(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return portfolioRepository.GetPortfolioById(inPortfolioID).GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return portfolioRepository.GetPortfolioById(inPortfolioID).GetPortfolioPercentChangeInValueForMonth(Year, Month);
        }
    }

    // Za dionice, indekse i portfelje potrebni su nam repozitoriji.
    // Svaki repozitoriji ima metode za dodavanje, brisanje, dohvaćanje, provjeru postojanja i brojanja odgovrajućih elemenata u kolekciji

    /// <summary>
    /// Repozitorij dionica
    /// </summary>
    public class StockRepository
    {
        List<Stock> listStocks = new List<Stock>();

        public void AddNewStock(Stock newStock)
        {
            foreach (Stock stock in listStocks)
                if (stock.Name == newStock.Name.ToLower())
                    throw new StockExchangeException("Već postoji dionica s imenom '" + newStock.Name + "'!");

            listStocks.Add(newStock);
        }

        public Stock GetStockByName(string inStockName)
        {
            foreach (Stock stock in listStocks)
                if (stock.Name == inStockName.ToLower())
                    return stock;

            throw new StockExchangeException("Ne postoji dionica s imenom '" + inStockName + "'!");
        }

        public void DeleteStockByName(string inStockName)
        {
            Stock stockToBeDeleted = null;

            foreach (Stock stock in listStocks)
                if (stock.Name == inStockName.ToLower())
                {
                    stockToBeDeleted = stock;
                    break;
                }

            if (stockToBeDeleted != null)
            {
                listStocks.Remove(stockToBeDeleted);
            }
            else
            {
                throw new StockExchangeException("Ne postoji dionica s imenom '" + inStockName + "'!");
            }
        }

        public bool StockExists(string inStockName)
        {
            bool stockExists = false;
            foreach (Stock stock in listStocks)
            {
                if (stock.Name == inStockName.ToLower())
                {
                    stockExists = true;
                    break;
                }
                                
            }

            return stockExists;
        }

        public int Count()
        {
            return listStocks.Count;
        }

    }

    /// <summary>
    /// Repozitorij indeksa
    /// </summary>
    public class IndexRepository
    {
        List<Index> listIndex = new List<Index>();

        public void AddNewIndex(Index newIndex)
        {
            foreach (Index index in listIndex)
                if (index.Name == newIndex.Name.ToLower())
                    throw new StockExchangeException("Već postoji index s imenom '" + newIndex.Name + "'!");

            listIndex.Add(newIndex);
        }

        public Index GetIndexByName(string inIndexName)
        {
            foreach (Index index in listIndex)
                if (index.Name == inIndexName.ToLower())
                    return index;

            throw new StockExchangeException("Ne postoji index s imenom '" + inIndexName + "'!");
        }

        public void DeleteIndexByName(string inIndexName)
        {
            Index indexToBeDeleted = null;

            foreach (Index index in listIndex)
                if (index.Name == inIndexName.ToLower())
                {
                    indexToBeDeleted = index;
                    break;
                }

            if (indexToBeDeleted != null)
            {
                listIndex.Remove(indexToBeDeleted);
            }
            else
            {
                throw new StockExchangeException("Ne postoji index s imenom '" + inIndexName + "'!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            bool indexExists = false;
            foreach (Index index in listIndex)
            {
                if (index.Name == inIndexName.ToLower())
                {
                    indexExists = true;
                    break;
                }

            }

            return indexExists;
        }

        public int Count()
        {
            return listIndex.Count;
        }
    }

    /// <summary>
    /// Repozitorij porfelja (case sensitive Id)
    /// </summary>
    public class PortfolioRepository
    {
        List<Portfolio> listPortfolio = new List<Portfolio>();

        public void AddNewPortfolio(Portfolio newPortfolio)
        {
            foreach (Portfolio portfolio in listPortfolio)
                if (portfolio.Id == newPortfolio.Id)
                    throw new StockExchangeException("Već postoji portfolio s id-em '" + newPortfolio.Id + "'!");

            listPortfolio.Add(newPortfolio);
        }

        public Portfolio GetPortfolioById(string inPortfolioId)
        {
            foreach (Portfolio portfolio in listPortfolio)
                if (portfolio.Id == inPortfolioId)
                    return portfolio;

            throw new StockExchangeException("Ne postoji portfolio s id-em '" + inPortfolioId + "'!");
        }

        public void DeletePortfolioById(string inPortfolioId)
        {
            Portfolio portfolioToBeDeleted = null;

            foreach (Portfolio portfolio in listPortfolio)
                if (portfolio.Id == inPortfolioId)
                {
                    portfolioToBeDeleted = portfolio;
                    break;
                }

            if (portfolioToBeDeleted != null)
            {
                listPortfolio.Remove(portfolioToBeDeleted);
            }
            else
            {
                throw new StockExchangeException("Ne postoji portfolio s id-em '" + inPortfolioId + "'!");
            }
        }

        public bool PortfolioExists(string inPortfolioId)
        {
            bool portfolioExists = false;
            foreach (Portfolio portfolio in listPortfolio)
            {
                if (portfolio.Id == inPortfolioId)
                {
                    portfolioExists = true;
                    break;
                }

            }

            return portfolioExists;
        }

        public int Count()
        {
            return listPortfolio.Count;
        }
    }

    // U nastavku modelirane su dionice, indeksi i portfelji odgovarajućim klasama

    /// <summary>
    /// Klasa Stock modelira dionicu na burzi.
    /// </summary>
    public class Stock
    {
        // atributi klase Stock
        string name;
        long numberOfShares;    // broj SLOBODNIH (one koje nisu u niti jednom portfelju) dionica na burzi
        decimal initialStockPrice;
        DateTime initialStockPriceTimeStap;

        public string Name 
        { 
            get { return this.name; }
        }

        public long NumberOfShares 
        {
            get { return this.numberOfShares; }
            set { this.numberOfShares = value; }
        }

        public decimal InitialStockPrice
        {
            get { return this.initialStockPrice; }
        }

        public DateTime InitialStockPriceTimeStamp
        {
            get { return this.initialStockPriceTimeStap; }
        }

        Dictionary<DateTime, decimal> priceAtTime = new Dictionary<DateTime, decimal>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0 || inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena i broj dionica su negativni ili 0.");
            }
            
            this.name = inStockName.ToLower();
            this.numberOfShares = inNumberOfShares;
            this.initialStockPrice = inInitialPrice;
            this.initialStockPriceTimeStap = inTimeStamp;
            priceAtTime.Add(inTimeStamp, inInitialPrice);        
        }

        public void SetNewStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Cijena dionice je manja ili jednaka 0!");
            }
            
            foreach (DateTime timeStamp in priceAtTime.Keys)
            {
                if (timeStamp == inTimeStamp)
                    throw new StockExchangeException("Već je definirana cijena za zadani trenutak!");
            }

            priceAtTime.Add(inTimeStamp, inStockValue);
            
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp < priceAtTime.Keys.Min<DateTime>())
            {
                throw new StockExchangeException("Cijena za zadano razdoblje nije definirana!");
            }

            DateTime maxTimeStamp = priceAtTime.Keys.Min<DateTime>();
            foreach (DateTime timeStamp in priceAtTime.Keys)
            {
                if (timeStamp <= inTimeStamp && timeStamp >= maxTimeStamp)
                    maxTimeStamp = timeStamp;
            }

            return priceAtTime[maxTimeStamp];
        }

        public decimal GetLastStockPrice()
        {
            return priceAtTime[priceAtTime.Keys.Max<DateTime>()];
        }
    }

    /// <summary>
    /// Klasa Index modelira indeks na burzi.
    /// </summary>
    public class Index
    {
        // atributi klase Index
        string name;
        IndexTypes type;
        List<Stock> listStocks = new List<Stock>();     // dionice koje indeks sadrži

        public string Name
        {
            get { return this.name; }
        }

        public IndexTypes Type
        {
            get { return this.type; }
        }

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.name = inIndexName.ToLower();
            this.type = inIndexType;
        }

        public bool StockExistsInIndex(string inStockName)
        {
            bool stockExists = false;
            foreach (Stock stock in listStocks)
            {
                if (stock.Name == inStockName)
                {
                    stockExists = true;
                    break;
                }
            }

            return stockExists;
        }

        public void AddStockToIndex(Stock inStock)
        {
            if (StockExistsInIndex(inStock.Name) == true)
            {
                throw new StockExchangeException("Index već sadrži dionicu s imenom '" + inStock.Name + "'!");
            }

            listStocks.Add(inStock);
        }

        public void RemoveStockFromIndex(Stock inStock)
        {
            if (StockExistsInIndex(inStock.Name) != true)
            {
                throw new StockExchangeException("Index ne sadrži dionicu s imenom '" + inStock.Name + "'!");
            }

            listStocks.Remove(inStock);
        }

        public int NumberOfContainedStocks()
        {
            return listStocks.Count;
        }

        public decimal GetIndexValue(DateTime timeStamp)
        {
            decimal indexValue = 0;

            if (this.type == IndexTypes.AVERAGE)
            {
                decimal sumOfPrices = 0;
                foreach (Stock stock in listStocks)
                {
                    sumOfPrices += stock.GetStockPrice(timeStamp);
                }

                indexValue = sumOfPrices / listStocks.Count;
            }
            else if (this.type == IndexTypes.WEIGHTED)
            {
                decimal totalValueOfStockInIndex = 0;
                foreach (Stock stock in listStocks)
                {
                    totalValueOfStockInIndex += stock.GetStockPrice(timeStamp) * stock.NumberOfShares;
                }

                decimal weightedSumOfPrices = 0;
                decimal totalSumOfWeightFactors = 0;
                foreach (Stock stock in listStocks)
                {
                    decimal weightFactor = (stock.GetStockPrice(timeStamp) * stock.NumberOfShares) / totalValueOfStockInIndex;
                    totalSumOfWeightFactors += weightFactor;
                    weightedSumOfPrices += weightFactor * stock.GetStockPrice(timeStamp);
                }

                indexValue = weightedSumOfPrices / totalSumOfWeightFactors;
            }

            return Math.Round(indexValue, 3);
        }
    }

    /// <summary>
    /// Klasa Portfolio modelira portfelje.
    /// </summary>
    public class Portfolio
    {
        // atributi klase Portfolio
        string id;
        Dictionary<Stock, int> listStocks = new Dictionary<Stock, int>();   // za svaku dodanu vrstu dionice bilježi se broj dionica u portfelju

        public string Id
        {
            get { return this.id; }
        }

        public Portfolio(string inPortfolioId)
        {
            this.id = inPortfolioId; 
        }

        public void AddStock(Stock inStock, int inNumberOfShares)
        {
            // ukoliko već postoje dionice ove vrste dodaj inNumberOfShares dionica u listStocks[inStock]
            if (listStocks.ContainsKey(inStock))
            {
                listStocks[inStock] += inNumberOfShares;
            }
            else
            // inače dodaj novu vrstu dionica u listu listStocks
            {
                listStocks.Add(inStock, inNumberOfShares);
            }
        }

        public void RemoveStock(Stock inStock, int inNumberOfShares)
        {
            if (listStocks.ContainsKey(inStock) == false)
            {
                throw new StockExchangeException("Ne postoji dionica u portfelju!");
            }

            if (listStocks[inStock] < inNumberOfShares)
            {
                throw new StockExchangeException("Preveliki broj dionica za brisanje!");
            }

            listStocks[inStock] -= inNumberOfShares;

            if (listStocks[inStock] == 0)
                listStocks.Remove(inStock);

            inStock.NumberOfShares += inNumberOfShares;
        }

        public void RemoveStock(Stock inStock)
        {
            if (listStocks.ContainsKey(inStock) == false)
            {
                throw new StockExchangeException("Ne postoji dionica u portfelju!");
            }

            listStocks.Remove(inStock);
        }

        public int NumberOfStocks()
        {
            return listStocks.Keys.Count;
        }

        public bool IsStockPartOfPortfolio(Stock inStock)
        {
            return listStocks.ContainsKey(inStock);
        }

        public int NumberOfSharesOfStockInPortfolio(Stock inStock)
        {
            if (listStocks.ContainsKey(inStock) == false)
            {
                throw new StockExchangeException("Ne postoji takve dionice!");
            }

            return listStocks[inStock];
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal value = 0;
            foreach (Stock stock in listStocks.Keys)
            {
                value += listStocks[stock] * stock.GetStockPrice(timeStamp);
            }

            return Math.Round(value, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime firstTimeStamp = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            int daysInMonth = System.DateTime.DaysInMonth(Year, Month);
            DateTime secondTimeStamp = new DateTime(Year, Month, daysInMonth, 23, 59, 59, 999);

            return Math.Round(((GetPortfolioValue(secondTimeStamp) - GetPortfolioValue(firstTimeStamp))/ GetPortfolioValue(firstTimeStamp))*100, 3);

        }
    }

    
}
