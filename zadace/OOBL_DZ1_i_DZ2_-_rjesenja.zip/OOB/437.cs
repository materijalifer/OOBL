﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Display
    {

        public string showDisplay;

        public Display()
        {

            showDisplay = "0";

        }

        public void setCharacter(char character) { 
        
            //provjeravam da li se radi o broju

            if (showDisplay != "0")
            {

                if ((int)char.GetNumericValue(character) >= 0 && (int)char.GetNumericValue(character) <= 9)
                {
                    if ((showDisplay.Contains('-') && showDisplay.Length < 12) || (!showDisplay.Contains('-') && showDisplay.Length < 11))
                        showDisplay = showDisplay + character;
                }else if(character == ',' && !showDisplay.Contains(',') && showDisplay.Length < 12){ 
                    showDisplay = showDisplay + character;
                }
                else if (character == 'M') {
                    if (showDisplay.Contains('-'))
                        showDisplay = showDisplay.TrimStart('-');
                    else
                        showDisplay = '-' + showDisplay;
                }

            }
            else if (showDisplay == "0")
            {
                if(character != ',')
                    showDisplay = character.ToString(); 
                else
                {
                    showDisplay = showDisplay + character;
                }
            }
            

        }

        public void resetDisplay() {
            showDisplay = "0";
        }
        
        public void setCalculation(string digit){
            showDisplay = digit;
        }

        public string DisplayStatus()
        {
            return showDisplay;
        }

    }

    public class Calculation {

        public string Calculate(double value, char Operator)
        {
            switch (Operator)
            {
                case 'S':
                    return Math.Round(Math.Sin(value), 9).ToString("R");
                case 'K':
                    return Math.Round(Math.Cos(value), 9).ToString("R");
                case 'T':
                    return Math.Round(Math.Tan(value), 9).ToString("R");
                case 'Q':
                    //return Math.Round(Math.Sin(value), 9).ToString("R");
                case 'R':
                    return Math.Round(Math.Sqrt(value), 9).ToString("R");
                case 'I':
                    return Math.Round(Math.Pow(value, -1), 9).ToString("R");
                default:
                    return "0";
            }
        }

        public string Subtract(double value1, double value2) {

            return "oduzimam";
        }
    
    }

    public class Kalkulator : ICalculator
    {
        public static char[] operators = { 'S', 'K', 'T', 'Q', 'R', 'I' };
        Display display;
        Calculation calc;

        public Kalkulator()
        {
            display = new Display();
            calc = new Calculation();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
        }
       

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'O'){
                display.resetDisplay();
            }else if(display.DisplayStatus() == "0" && inPressedDigit == '='){
                display.resetDisplay();
            }else if(operators.Contains(inPressedDigit)){

                switch (inPressedDigit) {
                    case 'S': 
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'S'));
                        break;
                    case 'K':
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'K'));
                        break;
                    case 'T':
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'T'));
                        break;
                    case 'Q':
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'Q'));
                        break;
                    case 'R':
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'R'));
                        break;
                    case 'I':
                        display.setCalculation(calc.Calculate(Convert.ToDouble(display.DisplayStatus()), 'I'));
                        break;
                    default: break;
                }
              
            }
            else
                display.setCharacter(inPressedDigit); //stavljam character na display
        }

        public string GetCurrentDisplayState()
        {
            return display.DisplayStatus();
        }
    }


}
