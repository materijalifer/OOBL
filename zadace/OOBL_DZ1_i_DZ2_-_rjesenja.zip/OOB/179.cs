﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string memory = "";
        private string screen = "";
        private string background = "";
        private char operand = '!';
        private string sign = "";
        private double number = 0;
        private bool rewrite;
        private bool previousOperator;

        public Kalkulator()
        {
            memory = "";
            screen = "0";
            background = "";
            operand = '!';
            number = 0;
            rewrite = true;
            previousOperator = false;
        }

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '+':
                    if (!previousOperator) doOperation();
                    operand = '+';
                    rewrite = true;
                    previousOperator = true;
                    break;
                case '-':
                    if (!previousOperator) doOperation();
                    operand = '-';
                    rewrite = true;
                    previousOperator = true;
                    break;
                case '*':
                    if (!previousOperator) doOperation();
                    operand = '*';
                    rewrite = true;
                    previousOperator = true;
                    break;
                case '/':
                    if (!previousOperator) doOperation();
                    operand = '/';
                    rewrite = true;
                    previousOperator = true;
                    break;
                case '=':
                    doOperation();
                    operand = '!';
                    rewrite = true;
                    previousOperator = false;
                    break;
                case ',': // decimalni zarez
                    if (rewrite)
                    {
                        screen = "0";
                        updateNumber();
                    }
                    screen += inPressedDigit;
                    updateNumber();
                    rewrite = false;
                    previousOperator = false;
                    break;
                case 'M': // promjena predznaka
                    number *= -1;
                    updateScreen();
                    previousOperator = false;
                    break;
                case 'S': // sinus
                    number = Math.Sin(number);
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'K': // kosinus
                    number = Math.Cos(number);
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'T': // tangens
                    number = Math.Tan(number);
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'Q': // kvadriranje
                    number *= number;
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'R': // korjenovanje
                    number = Math.Sqrt(number);
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'I': // inverz
                    number = 1 / number;
                    updateScreen();
                    rewrite = true;
                    previousOperator = false;
                    break;
                case 'P': // spremanje u memoriju
                    memory = screen;
                    break;
                case 'G': // dohvaćanje iz memorije
                    screen = memory;
                    updateNumber();
                    rewrite = true;
                    break;
                case 'C': // brisanje ekrana
                    screen = "0";
                    rewrite = true;
                    updateNumber();
                    previousOperator = false;
                    break;
                case 'O': // reset
                    memory = "";
                    screen = "0";
                    background = "";
                    operand = '!';
                    rewrite = true;
                    updateNumber();
                    previousOperator = false;
                    break;
                default: // znamenka
                    if (rewrite)
                    {
                        screen = "0";
                        updateNumber();
                    }
                    rewrite = false;
                    screen += inPressedDigit;
                    updateNumber();
                    previousOperator = false;
                    break;
            }

        }

        private void doOperation()
        {
            double bgNumber = 0;
            switch (operand)
            {

                case '+':
                    bgNumber = Double.Parse(background);
                    number += bgNumber;
                    updateScreen();
                    background = screen.ToString();
                    break;
                case '-':
                    bgNumber = Double.Parse(background);
                    number = bgNumber - number;
                    updateScreen();
                    background = screen.ToString();
                    break;
                case '*':
                    bgNumber = Double.Parse(background);
                    number = number * bgNumber;
                    updateScreen();
                    background = screen.ToString();
                    break;
                case '/':
                    bgNumber = Double.Parse(background);
                    number = bgNumber / number;
                    updateScreen();
                    background = screen.ToString();
                    break;
                case '=':
                    // to implement;
                    // probably never going to happen
                    break;
                default:
                    background = screen.ToString();
                    break;
            }
        }

        private void updateScreen()
        {
            screen = number.ToString();
        }

        private void updateNumber()
        {
            number = Double.Parse(screen);
        }

        public string getScreen()
        {
            return screen;
        }

        public string GetCurrentDisplayState()
        {
            string output = "";
            int nums = 0;
            int commas = 0;
            bool error = false;
            bool firstNum = true;
            if (number >= 1000000000) return "-E-";
            
            for (int i = 0; i < screen.Length; i++)
            {
                if (screen[i] == '-' && i != 0)
                {
                    error = true;
                    break;
                }
                if (screen[i] == ',') commas++;

                if (nums == 9 && screen[i] != ',')
                {
                    if (screen.Length > i + 1)
                    {
                        if (screen[i + 1] < 5)
                        {
                            output += screen[i];
                            break;
                        }

                    }
                    else output += screen[i];

                }
                if (firstNum && screen[i].Equals('0')) continue;
                if (firstNum && screen[i].Equals(',')) output += '0';
                firstNum = false;
                if (screen[i] != ',') nums++;
                if (nums > 10 && commas == 0)
                {
                    error = true;
                    break;
                }
                output += screen[i];

            }
            if (firstNum) return "0";
            if (error) return "-E-";
            int counter = 0;
            bool leadingZero = true;
            for (int i = 0; i < screen.Length; i++)
            {
                if (screen[i] == ',') break;
                if (leadingZero && screen[i] == '0') continue;
                if (screen[i] == '-') continue;
                leadingZero = false;
                counter++;
            }
            if (leadingZero) output = Math.Round(number, 9).ToString();
            else output = Math.Round(number, 10 - counter).ToString();
            return output;
        }
    }
}
