﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string lastBinaryOperation;
        private string memory;
        private string display;
        private string firstOperand;
        private string secondOperand;    
        private bool operationPressed;
        private bool numberPressed;
        private bool equalsPressed;

        private const int NUMBER_OF_DIGITS = 10;
        //binarne operacije
        private const string SUM = "+";
        private const string SUBTRACT = "-";
        private const string MULTIPLY = "*";
        private const string DJELJENJE = "/";
        private const string EQUALS = "=";
        //znak
        private const string DECIMAL_POINT = ",";
        //unarne operacije
        private const string CHANGE_PREFIX = "M";
        private const string SINUS = "S";
        private const string COSINUS = "K";
        private const string TANGENS = "T";
        private const string SQUARE = "Q";
        private const string ROOT = "R";
        private const string INVERSE = "I";
        //memorija
        private const string SAVE = "P";
        private const string GET = "G";
        private const string CLEAR = "C";
        private const string RESET = "O";
        private const string ERROR = "-E-";        
        private readonly List<string> operations;
        private readonly List<string> binaryOperations;
        private List<string> unaryOperations;

        public Kalkulator()
        {
            this.Reset();
            this.operationPressed = false;
            this.numberPressed = false;
            this.equalsPressed = false;
            this.operations = new List<string>(){SUM,SUBTRACT,MULTIPLY,DJELJENJE,EQUALS,
                DECIMAL_POINT,CHANGE_PREFIX,SINUS,COSINUS,TANGENS,SQUARE,ROOT,
            INVERSE,SAVE,GET,CLEAR,RESET};
            this.binaryOperations = new List<string>() { SUM, SUBTRACT, MULTIPLY, DJELJENJE };
            this.unaryOperations = new List<string>(){CHANGE_PREFIX,SINUS,COSINUS,TANGENS,SQUARE,ROOT,
            INVERSE};
        }
        public void Press(char inPressedDigit)
        {
            if (IsDigit(inPressedDigit))
            {
                this.DigitPressed(inPressedDigit.ToString());
            }
            else if (this.IsDecimalPoint(inPressedDigit))
            {
                this.DecimalPointPressed();
            }
            else if (this.IsOnOff(inPressedDigit))
            {
                this.OnOffPressed();
            }
            else if (this.IsMemoryGet(inPressedDigit))
            {
                this.GetFromMemory();
            }
            else if (this.IsMemorySet(inPressedDigit))
            {
                this.SetMemory();
            }
            else if (this.IsBinaryOperation(inPressedDigit)) {
                this.BinaryOperationPressed(inPressedDigit);
            }
            else if (this.IsUnaryoperation(inPressedDigit))
            {
                this.UnaryOperationPressed(inPressedDigit);
            }
            else if (this.IsPressedEqual(inPressedDigit))
            {
                this.EqualPressed();   
            }
            else if (this.IsClearPressed(inPressedDigit))
            {
                this.ClearPressed();
            }
        }
        public string GetCurrentDisplayState()
        {
            return this.display;
        }
        private void DigitPressed(string digit)
        {
            if (this.display == ERROR)
            {
                return;
            }
            if (equalsPressed)
            {
                this.firstOperand = string.Empty;
                this.lastBinaryOperation = string.Empty;
            }
            if (this.operationPressed)
            {
                this.display = "0";
                this.operationPressed = false;
            }
            if (display.Equals("0") || this.equalsPressed)
            {
                this.display = digit;
            }
            else if (CountDigits())
            {
                this.display += digit;
            }
            this.numberPressed = true;
            this.equalsPressed = false;
        }
        private static bool IsDigit(char pressed)
        {
            return char.IsDigit(pressed);
        }
        private bool IsBinaryOperation(char pressed)
        {
            return this.binaryOperations.Contains(pressed.ToString());
        }
        
        private void BinaryOperationPressed(char pressed)
        {
            
            //ako nema prvog operanda i nema binarne operacije, pokupi sa ekrana i upisi operaciju
            if (this.display == ERROR) {
                return;
            }
            
            if (this.lastBinaryOperation == string.Empty && this.firstOperand == string.Empty && this.display != ERROR)
            {
                this.firstOperand = this.display;
                this.lastBinaryOperation = pressed.ToString();
            }
                //ako je prvi operand unesen i nema operacije pokupi operaciju
            else if (this.firstOperand != string.Empty && this.lastBinaryOperation == string.Empty)
            {                                        
                this.lastBinaryOperation = pressed.ToString();
            }
            else if (this.firstOperand != string.Empty && this.lastBinaryOperation != string.Empty && this.numberPressed) {//&& this.secondOperand != string.Empty) {
                //this.numberPressed = false;
                string result = this.Calculate(this.firstOperand, this.display, this.lastBinaryOperation);
                if (result == ERROR) {
                    this.firstOperand = string.Empty;
                    //this.secondOperand = ERROR;
                    this.lastBinaryOperation = string.Empty;
                    this.display = ERROR;
                }
                else {
                    this.lastBinaryOperation = pressed.ToString();
                    this.firstOperand = result;
                   // this.secondOperand = string.Empty;
                    this.display = result;
                }
            }
            else if (this.firstOperand != string.Empty && this.lastBinaryOperation !=string.Empty )
            {
                this.lastBinaryOperation = pressed.ToString();
            }
            //ako postoje operandi i operacija i stisnutaje nova
                //izracuna se, upise na ekran, brise se operacija i prvi operand postaje ono ca je na ekranu
    
            //this.ClearDisplay();
            this.operationPressed = true;
            this.numberPressed = false;
            this.equalsPressed = false;
        }
        private string Calculate(string firstOperand, string secondOperand, string operation)
        {
            double firstOperandDouble = double.Parse(firstOperand);
            double secondOperandDouble = double.Parse(secondOperand);
            string result = "";
            if (operation == SUM)
            {
                result = (firstOperandDouble + secondOperandDouble).ToString();
            }
            else if (operation == SUBTRACT)
            {
                result = (firstOperandDouble - secondOperandDouble).ToString();
            }
            else if (operation == DJELJENJE)
            {
                if (secondOperandDouble == 0)
                {
                    return ERROR;
                }
                else
                {
                    result = (firstOperandDouble/secondOperandDouble).ToString();
                }
            }
            else if (operation == MULTIPLY)
            {
                result = (firstOperandDouble*secondOperandDouble).ToString();
            }
            if (this.CheckTooBigNumber(result))
            {
                result = ERROR;
            }
            return result;
        }
        private bool IsOnOff(char pressed)
        {
            return pressed.ToString() == RESET;
        }
        private void OnOffPressed()
        {
            this.Reset();
        }
        private bool IsMemorySet(char pressed)
        {
            return pressed.ToString() == SAVE;
        }
        private void SetMemory()
        {
            if (this.display == ERROR) {
                return;
            }
            if (this.display.Contains(DECIMAL_POINT))
            {
                this.memory = this.RoundDecimalNumber(this.display);
            }
            else
            {
                this.memory = this.display;
            }
        }
        private bool IsMemoryGet(char pressed)
        {
            return pressed.ToString() == GET;
        }
        private void GetFromMemory()
        {
            if (this.display == ERROR) {
                return;
            }
            if (this.memory != string.Empty)
            {
                this.display = this.memory;
            }
            else
            {
                this.display = "0";
            }
        }
        private bool IsUnaryoperation(char pressed)
        {
            return this.unaryOperations.Contains(pressed.ToString());
        }
        private void UnaryOperationPressed(char pressed)
        {
            if (this.display == ERROR) {
                return;
            }
            string calculatedOperation = "";
            if (pressed.ToString() == SINUS)
            {
                calculatedOperation = Math.Sin(double.Parse(this.display)).ToString();
            }
            else if (pressed.ToString() == COSINUS)
            {
                calculatedOperation = Math.Cos(double.Parse(this.display)).ToString();
            }
            else if (pressed.ToString() == ROOT) {
                calculatedOperation = Math.Sqrt(double.Parse(this.display)).ToString();
            }
            else if (pressed.ToString() == SQUARE) {
                calculatedOperation = Math.Pow(double.Parse(this.display),2).ToString();
            }
            else if (pressed.ToString() == TANGENS) {
                calculatedOperation = Math.Tan(double.Parse(this.display)).ToString();
            }
            else if (pressed.ToString() == INVERSE) {
                if (this.display == "0") {
                    calculatedOperation = ERROR;
                }
                else
                {
                    calculatedOperation = Math.Pow(double.Parse(this.display), -1).ToString();
                }
            }
            else if (pressed.ToString() == CHANGE_PREFIX)
            {
                if (!this.display.StartsWith("-"))
                {
                    if (this.display != "0")
                    {
                        calculatedOperation += "-" + this.display;
                    }
                    else
                    {
                        calculatedOperation =this.display;
                    }                                        
                }
                else
                {
                    calculatedOperation = this.display.Substring(1);
                }
            }
            if (calculatedOperation != ERROR && !CheckTooBigNumber(calculatedOperation))
            {
                calculatedOperation = this.RoundDecimalNumber(calculatedOperation);
                this.display = calculatedOperation;
                //if (decimalPoint)
                //{
                    
                //}
            }
            else
            {
                this.display = ERROR;
            }
            this.equalsPressed = false;
           // this.operationPressed = false;
            //this.numberPressed = true;
        }
        private bool IsPressedEqual(char pressed)
        {
            return pressed.ToString() == EQUALS;
        }
        
        private void EqualPressed()
        {
            if (this.display == ERROR) {
                return;
            }
            if (operationPressed && this.firstOperand != string.Empty)
            {
                this.secondOperand = this.display;
                this.display = this.RoundDecimalNumber(Calculate(this.firstOperand, this.secondOperand, this.lastBinaryOperation));
            }
            else if (numberPressed && this.firstOperand != string.Empty)
            {
                this.secondOperand = this.display;
                this.display = this.RoundDecimalNumber(Calculate(this.firstOperand, this.secondOperand, this.lastBinaryOperation));
               // this.lastBinaryOperation = string.Empty;
            }
            else if (equalsPressed)
            {
                this.firstOperand = this.display;
                this.display = this.RoundDecimalNumber(Calculate(this.firstOperand, this.secondOperand, this.lastBinaryOperation));
            }
            /*
            if (this.firstOperand != string.Empty &&
                operationPressed &&
               this.lastBinaryOperation != string.Empty) {
                   this.display = this.RoundDecimalNumber(Calculate(this.display, this.firstOperand, this.lastBinaryOperation));
                //this.firstOperand = string.Empty;
                //this.lastBinaryOperation = string.Empty;
                //this.secondOperand = string.Empty;
            }
            else if (this.firstOperand != string.Empty && 
                //this.secondOperand != string.Empty &&
                this.lastBinaryOperation != string.Empty)
            {
                this.display = this.RoundDecimalNumber(Calculate(this.firstOperand, this.display, this.lastBinaryOperation));
                //this.firstOperand = string.Empty;
                this.lastBinaryOperation = string.Empty;
                //this.secondOperand = string.Empty;
            }*/
            else
            {
                this.display = this.RoundDecimalNumber(this.display);
            }
            this.firstOperand = string.Empty;            
            this.operationPressed = false;
            this.equalsPressed = true;
            this.numberPressed = false;
        }
        private bool CheckTooBigNumber(string number)
        {
            double numberDouble = double.Parse(number);
            return numberDouble > 999999999;
            //int numberOfDigitsBeforeDecimalPoint = 0;
            //foreach (char s in number)
            //{
            //    if (s.ToString() == DECIMALNI_ZAREZ)
            //    {
            //        break;
            //    }
            //    else
            //    {
            //        numberOfDigitsBeforeDecimalPoint += 1;
            //    }
            //}
            //return numberOfDigitsBeforeDecimalPoint > NUMBER_OF_DIGITS;
        }        
        private string RoundDecimalNumber(string decimalNumber)
        {
            string trimmedDecimalnumber = "";
            if (decimalNumber.Contains(DECIMAL_POINT)) {
                if (decimalNumber.EndsWith(DECIMAL_POINT)) {
                    trimmedDecimalnumber = decimalNumber.Substring(0, decimalNumber.Length - 1);
                }
                else if (this.DecimalNumberEndsWithZeros(decimalNumber)) {
                    trimmedDecimalnumber = decimalNumber.Substring(0, decimalNumber.IndexOf(DECIMAL_POINT));
                }
                else if (!this.CountDigits(decimalNumber))
                {
                    int numberOfDigits = this.CountDigitsBeforeDecimalPoint(decimalNumber);
                    double numberDouble = double.Parse(decimalNumber);
                    trimmedDecimalnumber = Math.Round(numberDouble, NUMBER_OF_DIGITS - numberOfDigits + 1).ToString();
                    //if (decimalNumber.StartsWith("-")) {
                    //    trimmedDecimalnumber = decimalNumber.Substring(0, NUMBER_OF_DIGITS + 2);
                    //}
                    //else {
                    //    trimmedDecimalnumber = decimalNumber.Substring(0, NUMBER_OF_DIGITS + 1);
                    //}
                }
                else if(this.CountDigits(decimalNumber))
                {
                    trimmedDecimalnumber = decimalNumber;
                }
            }
            else
            {
                trimmedDecimalnumber = decimalNumber;
            }
            return trimmedDecimalnumber;
        }
        private int CountDigitsBeforeDecimalPoint(string number)
        {
            int numberOfdigits = 0;
            if (number.StartsWith("-"))
            {
                number = number.Substring(1);
            }
            foreach (char c in number)
            {
                numberOfdigits += 1;
                if (c.ToString() == DECIMAL_POINT)
                {
                    break;
                }
            }
            return numberOfdigits;
        }
        private bool DecimalNumberEndsWithZeros(string decimalNumbers)
        {
            bool decimalPointFound = false;
            bool endsWithZeros = true;
            foreach (char decimalNumber in decimalNumbers)
            {
                if (decimalNumber.ToString() == DECIMAL_POINT)
                {
                    decimalPointFound = true;
                    continue;
                }
                if (endsWithZeros && decimalPointFound)
                {
                    if (decimalNumber.ToString() != "0")
                    {
                        endsWithZeros = false;
                    }
                }
            }
            return endsWithZeros;
        }
        private bool CountDigits(string number) {
            int numberOfDigits = 0;
            foreach (char sign in number) {
                if (IsDigit(sign)) {
                    numberOfDigits += 1;
                }
            }
            return numberOfDigits < NUMBER_OF_DIGITS;
        }
        private bool IsDecimalPoint(char pressed)
        {
            return pressed.ToString() == DECIMAL_POINT;
        }  
        private void Reset()
        {
            this.display = "0";
            this.memory = string.Empty;
            this.firstOperand = string.Empty;
            //this.secondOperand = string.Empty;
            this.lastBinaryOperation = string.Empty;            
        }
        private bool CountDigits()
        {
            int numberOfDigits = 0;
            foreach (char sign in this.display)
            {
                if (IsDigit(sign))
                {
                    numberOfDigits += 1;
                }
            }
            return numberOfDigits < NUMBER_OF_DIGITS;
        }
        private void DecimalPointPressed()
        {
            if (this.display == ERROR) {
                return;
            }
            if (!this.display.Contains(DECIMAL_POINT))
            {
                if (operationPressed)
                {
                    this.display = "0,";                    
                }
                else
                {
                    this.display += DECIMAL_POINT;
                }
                             
            }
            this.operationPressed = false;
            this.numberPressed = true;
            this.equalsPressed = false;
        }
        private bool IsClearPressed(char pressed)
        {
            return pressed.ToString() == CLEAR;
        }
        private void ClearPressed()
        {
            if (this.display == ERROR) {
                return;
            }
            this.display = "0";
        }
    }
}
