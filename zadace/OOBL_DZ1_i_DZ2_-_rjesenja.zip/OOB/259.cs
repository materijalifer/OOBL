﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private decimal _rezultat = 0;
        private int _brojDecimala = 0;
        private string _displayState = "0";
        private char _zadnjaOperacija = ' ';
        private decimal _prviOperand;
        private bool _unosBrojeva = true;
        private decimal _memorija = 0;

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '=':
                    if (this._unosBrojeva)
                    {
                        this.Izracunaj();
                    }
                    else
                    {
                        this.IzracunajSaSobom();
                    }
                    this.OsvjeziDisplay();
                    break;
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                case '0':
                    if (this._unosBrojeva != true)
                    {
                        this._rezultat = 0;
                        this._brojDecimala = 0;
                    }
                    this._unosBrojeva = true;
                    this.DodajZnamenku((int)Char.GetNumericValue(inPressedDigit));
                    this.OsvjeziDisplay();
                    break;
                case ',':
                    this._brojDecimala = 1;
                    break;
                case 'M':
                    this._rezultat *= -1;
                    this.OsvjeziDisplay();
                    break;
                case '/':
                case '*':
                case '-':
                case '+':
                    if (this._unosBrojeva)
                    {
                        if (this._zadnjaOperacija != ' ')
                        {
                            this.Izracunaj();
                        }
                        this._prviOperand = this._rezultat;
                        this._unosBrojeva = false;
                    }
                    this._zadnjaOperacija = inPressedDigit;
                    break;
                case 'O':
                    this.Resetiraj();
                    this.OsvjeziDisplay();
                    break;
                case 'P':
                    this._memorija = this._rezultat;
                    break;
                case 'G':
                    this._rezultat = this._memorija;
                    this.OsvjeziDisplay();
                    break;
                case 'S':
                    this._rezultat = (decimal) Math.Round(Math.Sin((double)this._rezultat), 9);
                    this.OsvjeziDisplay();
                    break;
                case 'K':
                    this._rezultat = (decimal)Math.Round(Math.Cos((double)this._rezultat), 9);
                    this.OsvjeziDisplay();
                    break;
                case 'T':
                    this._rezultat = (decimal)Math.Round(Math.Tan((double)this._rezultat), 9);
                    this.OsvjeziDisplay();
                    break;
                case 'Q':
                    this._rezultat = (decimal)Math.Pow((double)this._rezultat, 2);
                    this.OsvjeziDisplay();
                    break;
                case 'R':
                    this._rezultat = (decimal)Math.Sqrt((double)this._rezultat);
                    this.OsvjeziDisplay();
                    break;
                case 'I':
                    try
                    {
                        this._rezultat = 1 / this._rezultat;
                        this.OsvjeziDisplay();
                    }
                    catch
                    {
                        this._displayState = "-E-";
                    }
                    break;
                case 'C':
                    this._rezultat = 0;
                    this._brojDecimala = 0;
                    this.OsvjeziDisplay();
                    break;
            }

        }

        private void Resetiraj()
        {
            this._rezultat = 0;
            this._brojDecimala = 0;
            this._prviOperand = 0;
            this._zadnjaOperacija = ' ';
            this._unosBrojeva = false;
        }

        public string GetCurrentDisplayState()
        {
            return this._displayState;
        }

        public void OsvjeziDisplay()
        {
            if (this._rezultat > 9999999999)
            {
                this._displayState = "-E-";
            }
            else
            {
                this._displayState = Math.Round(this._rezultat, 9).ToString("G10");
            }
        }

        private int IzracunajBrojZnamenki()
        {
            decimal pomocna = this._rezultat;
            int povratnaVrijednost = 1;
            while (pomocna > 10)
            {
                pomocna /= 10;
                povratnaVrijednost++;
            }
            return povratnaVrijednost;
        }

        private void DodajZnamenku(int znamenka)
        {
           
            if (this.IzracunajBrojZnamenki() + this._brojDecimala == 11)
            {
                return;
            }
            if (this._brojDecimala == 0)
            {
                this._rezultat = this._rezultat * 10;
                if (this._rezultat < 0)
                {
                    this._rezultat -= znamenka;
                }
                else
                {
                    this._rezultat += znamenka;
                }
            }
            else
            {
                if (this._rezultat < 0)
                {
                    this._rezultat -= (decimal)znamenka / (decimal)(Math.Pow(10, this._brojDecimala));
                }
                else
                {
                    this._rezultat += (decimal)znamenka / (decimal)(Math.Pow(10, this._brojDecimala));
                }
                this._brojDecimala++;
            }
        }

        private void Izracunaj()
        {
            switch (this._zadnjaOperacija)
            {
                case '+':
                    this._rezultat += this._prviOperand;
                    break;
                case '-':
                    this._rezultat = this._prviOperand - this._rezultat;
                    break;
                case '*':
                    this._rezultat *= this._prviOperand;
                    break;
                case '/':
                    this._rezultat = this._prviOperand / this._rezultat;
                    break;
            }
        }

        private void IzracunajSaSobom()
        {
            switch (this._zadnjaOperacija)
            {
                case '+':
                    this._rezultat = this._prviOperand + this._prviOperand;
                    break;
                case '-':
                    this._rezultat = this._prviOperand - this._prviOperand;
                    break;
                case '*':
                    this._rezultat = this._prviOperand * this._prviOperand;
                    break;
                case '/':
                    this._rezultat = this._prviOperand / this._prviOperand;
                    break;
            }
        }

    }


}
