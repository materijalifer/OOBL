﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private string display = "0";
        private string displayPrvi = "0";
        private string displayDrugi = "";
        private string errorDisplay = "-E-";

        private string displayMemory = "0";

        private bool ispravno = true;

        private char[] binarniOperatori = {'+','-','*','/'};
        private char[] unarniOperatori = {'M','S','K','T','Q','R','I','P','G','C','O' };
        private char[] stanjeUnarni = { 'S', 'K', 'T', 'Q', 'R', 'I' };
        private double izracunati = 0;
        private double trenutni = 0;
        private string prosliOperator = "";
        

        private char zadnjaVrsta = 'z';

        private bool bioZarez = false;
        private bool predznakMinus = false;



        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                ObradaZnamenke(inPressedDigit);
                zadnjaVrsta = 'z';
            }
            else if (Char.IsLetter(inPressedDigit))
            {
                ObradaUnarnogOperatora(inPressedDigit);
                if (inPressedDigit != 'P' && inPressedDigit != 'G' && inPressedDigit != 'M')
                    zadnjaVrsta = 'u';
            }
            else if (binarniOperatori.Contains(inPressedDigit))
            {
                ObradaBinarnogOperatora(inPressedDigit);
                zadnjaVrsta = 'b';
            }
            else if (inPressedDigit == '=')
            {
                ObradaZnakaJednako();
                zadnjaVrsta = '=';
            }
            else if (inPressedDigit == ',')
            {
                ObradaZnakaZarez();
                zadnjaVrsta = 'z';
            }
            else
            {
                ispravno = false;
            }

        }

        

        private void ObradaZnamenke(char digit)
        {
       
            if (bioZarez == false)
            {
                if (displayPrvi == "0")
                    displayPrvi = Convert.ToString(digit);
                else
                    displayPrvi = displayPrvi + digit;
            }
            else
            {
                displayDrugi = displayDrugi + digit;
            }
                
            if (displayDrugi.Length > 0)
            {
                display = displayPrvi + "," + displayDrugi;
            }
            else
            {
                display = displayPrvi;
            }
            if (predznakMinus == true)
                if (display[0] != '-')
                    display = '-' + display;

            if (displayPrvi.Length + displayDrugi.Length > 10)
            {

                int x = Convert.ToInt32(bioZarez) + Convert.ToInt32(predznakMinus);
                display = display.Substring(0, 10+x);
            }
            trenutni = Convert.ToDouble(display);
            

        }



        private void ObradaUnarnogOperatora(char letter)
        {
            letter = Char.ToUpper(letter);
            switch (letter)
            {
                case 'M':
                    predznakMinus = !predznakMinus;
                    trenutni = -trenutni;
                    trenutni = popraviTrenutni(trenutni);
                    break;
                case 'S':
                    trenutni = Math.Sin(trenutni);
                    trenutni = popraviTrenutni(trenutni);
                    break;
                case 'K':
                    trenutni = Math.Cos(trenutni);
                    trenutni = popraviTrenutni(trenutni);
                    break;
                case 'T':
                    if (Math.Cos(trenutni) != 0)
                    {
                        trenutni = Math.Tan(trenutni);
                        trenutni = popraviTrenutni(trenutni);
                    }
                    else
                        ispravno = false;
                    break;
                case 'Q':
                    trenutni = Math.Pow(trenutni,2);
                    trenutni = popraviTrenutni(trenutni);
                    break;
                case 'R':
                    if (trenutni >= 0)
                    {
                        trenutni = Math.Sqrt(trenutni);
                        trenutni = popraviTrenutni(trenutni);
                    }
                    else
                        ispravno = false;
                    break;
                case 'I':
                    try
                    {
                        trenutni = 1 / trenutni;
                        trenutni = popraviTrenutni(trenutni);
                    }
                    catch (DivideByZeroException e)
                    {
                        ispravno = false;
                    }
                    break;
                case 'P': 
                    displayMemory = display;
                    break;
                case 'G':
                    display = displayMemory;
                    //ispravno = false,? nije specificiran slucaj kad se dohvaca prazna memorija, pa sam stavio kao u windows kalkulatoru
                    trenutni = Convert.ToDouble(displayMemory);
                    break;
                case 'C': 

                    displayPrvi = "0";
                    displayDrugi = "";
                    trenutni = 0;
                    bioZarez = false;
                    predznakMinus = false;

                    break;
                case 'O': 
                    display = "0";
                    displayPrvi = "0";
                    displayDrugi = "";
                    displayMemory = "0";
                    ispravno = true;
                    izracunati = 0;
                    trenutni = 0;
                    prosliOperator = "";
                    bioZarez = false;
                    predznakMinus = false;
                    break;

            }
            if (stanjeUnarni.Contains(letter))
            {
                displayPrvi = "0";
                displayDrugi = "";
                bioZarez = false;
            }
        }
        
        private void ObradaBinarnogOperatora(char binarniOperator)
        {
            if (zadnjaVrsta == 'z' || zadnjaVrsta == 'u')
            {
                Izracunaj();
                display = Convert.ToString(izracunati);
                FormatirajDisplay();
                displayPrvi = "0";
                displayDrugi = "";
                bioZarez = false;
                predznakMinus = false;
            }
            prosliOperator = Convert.ToString(binarniOperator);
            bioZarez = false;
        }
        
        private void ObradaZnakaJednako()
        {
            if (zadnjaVrsta == 'z' || zadnjaVrsta == 'u')
            {
                Izracunaj();
                display = Convert.ToString(izracunati);
                FormatirajDisplay();
            }
            else if (zadnjaVrsta == 'b')
            {
                trenutni = izracunati;
                Izracunaj();
                display = Convert.ToString(izracunati);
                FormatirajDisplay();
            }
        }
        private void ObradaZnakaZarez()
        {
            if (zadnjaVrsta != 'z')
                Press('0');
            bioZarez = true;
        }

        private double popraviTrenutni(double trenutni)
        {
            if (Math.Abs(trenutni) > 9999999999)
            {
                ispravno = false;
                return trenutni;
            }
            else if (Math.Abs(trenutni) < 0.000000001)
            {
                display = "0";
                return 0;
            }
            else
            {
                display = trenutni.ToString();
                FormatirajDisplay();
                
            }
            return Convert.ToDouble(display);
        }

        private void Izracunaj()
        {
            try
            {
                switch (prosliOperator)
                {
                    case "+":
                        izracunati = izracunati + trenutni;
                        break;
                    case "-":
                        izracunati = izracunati - trenutni;
                        break;
                    case "/":
                        if (trenutni != 0)
                            izracunati = izracunati / trenutni;
                        else
                            ispravno = false;
                        break;
                    case "*":
                        izracunati = izracunati * trenutni;
                        break;
                    case "":
                        izracunati = trenutni;
                        break;
                }
            } 
            catch (OverflowException e)
            {
                ispravno = false;
            }
            if (Math.Abs(izracunati) > 9999999999)
            {
                ispravno = false;
            }
        }



        public void FormatirajDisplay()
        {
            if (display.Contains(','))
            {
                while (display[display.Length - 1] == '0')
                {
                    display = display.Remove(display.Length - 1);
                }
                if (display[display.Length - 1] == ',')
                {
                    display = display.Remove(display.Length - 1);
                    bioZarez = false;
                }
                else
                    bioZarez = true;
            }
            if (display.Length > 10)
            {
                if (predznakMinus == true)
                    if (display[0] != '-')
                        display = '-' + display;
                if (display.Contains('-'))
                    predznakMinus = true;
                
                int x = Convert.ToInt32(bioZarez) + Convert.ToInt32(predznakMinus);
                if (bioZarez)
                {
                    int imaMinus = Convert.ToInt32(predznakMinus);
                    int i = display.IndexOf(',');
                    double temp = Math.Round(Convert.ToDouble(display),10-(i-imaMinus));
                    display = temp.ToString();
                    trenutni = temp;
                }
                    
            }
        }

        public string GetCurrentDisplayState()
        {
            if (ispravno == false)
            {
                return errorDisplay;
            }
            else
            {
                return display;
            }
        }
    }


}
