﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        List<char> characterList = new List<char>();
        double memory;
        string display = "0";
        double result = 0;
        char operation = '+';
        bool firstNumberAfterOperation = false;
        bool firstOperation = true;
        char lastDigit = 'E';

        public void Press(char inPressedDigit)
        {
            try
            {
                if (isOperation(inPressedDigit))
                {
                    if (firstOperation)
                    {
                        operation = inPressedDigit;
                        result = Convert.ToDouble(display);
                        firstOperation = false;
                        firstNumberAfterOperation = true;
                    }
                    else if (isOperation(lastDigit))
                    {
                        operation = inPressedDigit;
                    }
                    else
                    {
                        double tempResult;

                        if (double.TryParse(display, out tempResult))
                        {
                            result = izracunajOperaciju(result, operation, tempResult);

                            setResultToDisplay(result);

                            operation = '0';
                            firstNumberAfterOperation = true;
                        }
                        else
                        {
                            Greska();
                            return;
                        }
                        operation = inPressedDigit;
                    }
                }
                else if (isNumber(inPressedDigit))
                {
                    if (display == "0" || firstNumberAfterOperation)
                    {
                        display = inPressedDigit.ToString();
                        firstNumberAfterOperation = false;
                    }
                    else
                    {
                        int numOfNumbers = 0;
                        foreach (char c in display)
                            if (isNumber(c))
                                numOfNumbers++;

                        if (numOfNumbers < 10)
                            display += inPressedDigit;
                    }
                }
                else if (inPressedDigit == 'Q')
                {
                    double temp = Convert.ToDouble(display);
                    temp = temp * temp;
                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'R')
                {
                    double temp = Convert.ToDouble(display);
                    temp = Math.Sqrt(temp);
                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'S')
                {
                    double temp = Convert.ToDouble(display);
                    temp = Math.Sin(temp);
                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'K')
                {
                    double temp = Convert.ToDouble(display);
                    temp = Math.Cos(temp);
                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'T')
                {
                    double temp = Convert.ToDouble(display);
                    temp = Math.Tan(temp);
                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'I')
                {
                    double temp = Convert.ToDouble(display);
                    if (temp == 0)
                    {
                        Greska();
                        return;
                    }
                    else
                    {
                        temp = 1 / temp;
                    }

                    setResultToDisplay(temp);
                }
                else if (inPressedDigit == 'P')
                {
                    memory = Convert.ToDouble(display);
                }
                else if (inPressedDigit == 'G')
                {
                    display = memory.ToString();
                }
                else if (inPressedDigit == 'O')
                {
                    result = 0;
                    display = "0";
                    memory = 0;
                    operation = '0';
                }
                else if (inPressedDigit == 'C')
                {
                    display = "0";
                }
                else if (inPressedDigit == ',')
                {
                    display += ",";
                }
                else if (inPressedDigit == 'M')
                {
                    double temp = Convert.ToDouble(display) * (-1);
                    display = temp.ToString();
                }
                else if (inPressedDigit == '=')
                {
                    double tempResult;

                    if (isOperation(lastDigit))
                    {
                        result = izracunajOperaciju(result, operation, result);

                        setResultToDisplay(result);

                        operation = '0';
                        firstNumberAfterOperation = true;
                    }
                    else
                    {
                        if (double.TryParse(display, out tempResult))
                        {
                            result = izracunajOperaciju(result, operation, tempResult);

                            setResultToDisplay(result);

                            operation = '0';
                            firstNumberAfterOperation = true;
                        }
                        else
                        {
                            Greska();
                            return;
                        }
                    }
                }
                lastDigit = inPressedDigit;
            }
            catch (Exception e)
            {
                Greska();
            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        private void setResultToDisplay(double result)
        {
            if (result != 0)
            {
                int numberOfChar;
                if (Math.Abs(result) > 10)
                    numberOfChar = Convert.ToInt32(Math.Log10(Math.Abs(result)));
                else
                    numberOfChar = 1;

                if (numberOfChar > 10)
                {
                    Greska();
                    return;
                }

                result = Math.Round(result, 10 - numberOfChar);
                display = result.ToString();
            }
            else
            {
                display = "0";
            }
        }

        private void Push()
        {
            double result;
            //string temp = string.Empty;

            //for (int i = 0; i < characterList.Count; i++)
            //{
            //    temp += characterList[i];
            //}
            if (double.TryParse(display, out result))
            {
                memory = result;
            }
            else
            {
                Greska();
            }
        }
        private void setDisplay()
        {
            display = String.Empty;

            foreach (char c in characterList)
                display += c;
        }
        private void Greska()
        {
            display = "-E-";
            memory = 0;
            result = 0;
            lastDigit = 'E';
        }
        private bool isNumber(char c)
        {
            int tempInt;
            string temp = String.Empty + c;
            return int.TryParse(temp, out tempInt);
        }
        private bool isOperation(char c)
        {
            if (c == '+' || c == '*' || c == '/' || c == '-')
                return true;

            return false;
        }
        private double izracunajOperaciju(double first, char operation, double second)
        {
            if (operation == '+')
            {
                return first + second;
            }
            if (operation == '-')
            {
                return first - second;
            }
            if (operation == '*')
            {
                return first * second;
            }
            if (operation == '/')
            {
                return first / second;
            }
            if (operation == '0')
            {
                return Convert.ToDouble(display);
            }

            Greska();
            return double.MinValue;
        }
    }
}
