﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        string screen = "0";
        //rezultat koji ostane nakon brisanja ekrana.
        string lastScreen;
        //dali je postavljena inicijalna vrijednost na kalkulatoru '0'
        bool initialValue = true;
        int numberOfDigits = 0;
        string memory = null;
        //dali je postavljen vec decimani zarez.
        bool decimalPoint = false;
        //dali je zadnja operacija bila +, -. * ili /
        bool lastIsOperator = false;
        //ako je odabran operator između upisa brojeva
        bool operatorSelected = false;
        //označava dali je prije novog pritiska na neki gumb na ekranu bio prikazan rezultat
        bool lastIsResult = false;
        //označava dali je unarni operator iso odmah nakon binarnog.
        bool unarAfterBinar = false;
        char oper;

        public void Press(char inPressedDigit)
        {
            Calculate calculate = new Calculate(this);
            if (Char.IsNumber(inPressedDigit))
            {
                if (lastIsResult)
                {
                    if (!unarAfterBinar)
                    {
                        lastScreen = screen;
                    }
                    unarAfterBinar = false;
                    RestartScreenAfterResult();
                    lastIsResult = false;
                }
                if (initialValue)
                {
                    screen = "";
                    initialValue = false;
                }
                new Digit(this, inPressedDigit);
                lastIsOperator = false;
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-'
              || inPressedDigit == '*' || inPressedDigit == '/')
            {
                //sređujemo broj na ekranu ako nakon decimalne tocke ima samo nulu da se decimalna tocka i nula maknu.
                EditScreenNumber();
                //ako je vec prije odabran operator, ali ne u proslom kliku, onda se na pritisak novog operatora treba izracunat 
                //dosadasnji rezultat kao da smo kliknuli jednako pa onda ovaj operator.
                if (operatorSelected && !lastIsOperator)
                {
                    string result = null;
                    try
                    {
                        result = calculate.Process(oper, GetDecimalFromString(lastScreen), GetDecimalFromString(screen));
                    }
                    catch (FormatException ignorable)
                    {
                    }
                    if (result == null)
                    {
                        screen = "-E-";
                    }
                    else
                    {
                        lastScreen = screen;
                        screen = result;
                    }
                }
                lastIsOperator = true;
                operatorSelected = true;
                oper = inPressedDigit;
            }
            else if (inPressedDigit == ',')
            {
                if (lastIsResult)
                {
                    if (!unarAfterBinar)
                    {
                        lastScreen = screen;
                    }
                    unarAfterBinar = false;
                    RestartScreenAfterResult();
                    lastIsResult = false;
                }
                //ako je vec dodan decimalna tocka odnosno zarez ignoriraj opet dodavanje istog
                if (decimalPoint)
                {
                    return;
                }
                //ako je ekran prazan ili ima samo minus onda se unosom zareza dodaje 0 na pocetku.
                else if (screen == "" || screen == "-" )
                {
                    screen += "0";
                    numberOfDigits++;
                }
                else if (screen == "0" || screen == "-0")
                {
                    initialValue = false;
                    numberOfDigits++;
                }
                decimalPoint = true;
                screen += inPressedDigit;
                lastIsOperator = false;
            }
            else if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T' || inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
            {
                string result = null;
                if (lastIsOperator)
                {
                    lastScreen = screen;
                }
                switch (inPressedDigit)
                {
                    case 'S':
                        result = calculate.Process('S', GetDecimalFromString(screen));
                        break;
                    case 'K':
                        result = calculate.Process('K', GetDecimalFromString(screen));
                        break;
                    case 'T':
                        result = calculate.Process('T', GetDecimalFromString(screen));
                        break;
                    case 'Q':
                        result = calculate.Process('Q', GetDecimalFromString(screen));
                        break;
                    case 'R':
                        result = calculate.Process('R', GetDecimalFromString(screen));
                        break;
                    case 'I':
                        result = calculate.Process('I', GetDecimalFromString(screen));
                        break;
                    default:
                        break;
                }
                if (result == null)
                {
                    screen = "-E-";
                }
                else
                {
                    screen = result;
                }
                lastIsOperator = false;
            }
            else
            {
                string result = null;
                switch (inPressedDigit)
                {
                    case 'M':
                        ChangeNumberSign();
                        return;
                    case 'P':
                        if (screen == "-E-")
                        {
                            break;
                        }
                        memory = screen;
                        return;
                    case 'G':
                        if (memory == null)
                        {
                            break;
                        }
                        lastScreen = screen;
                        screen = memory;
                        lastIsOperator = false;
                        return;
                    case 'C':
                        CleanScreen();
                        lastIsOperator = false;
                        screen = "0";
                        initialValue = true;
                        return;
                    case 'O':
                        Reset();
                        return;
                    case '=':
                        //ako nikakav operator prethodno nije odabran onda nema promjene na ekranu osim ako je zapisno 'nekiBroj,0' pa se to mijenja u 'nekiBroj' bez nule.
                        if (!operatorSelected)
                        {
                            EditScreenNumber();
                            return;
                        }
                        //ako je prije jednako bio operator onda je to skraceni zapis( 2+= 2+2 = 4)
                        if (lastIsOperator)
                        {
                            result = calculate.Process(oper, GetDecimalFromString(screen), GetDecimalFromString(screen));
                        }
                        else
                        {
                            //ako imamo slucaj {broj} {binarni} {unarni} = onda se gledao kao {broj} {binar} {broj} = 
                            if (unarAfterBinar)
                            {
                                result = calculate.Process(oper, GetDecimalFromString(lastScreen), GetDecimalFromString(lastScreen));
                                unarAfterBinar = false;
                            }
                            else
                            {
                                result = calculate.Process(oper, GetDecimalFromString(lastScreen), GetDecimalFromString(screen));
                            }
                        }
                        operatorSelected = false;
                        break;
                    default:
                        break;
                }
                if (result == null)
                {
                    screen = "-E-";
                }
                else
                {
                    screen = result;
                }
                lastIsOperator = false;
            }
        }

        /// <summary>
        /// Funckija za brisanje ekrana nakon sto je na njemu bio prikazan neki rezultat, 
        /// a krenulo se sa upisom nove brojke što znači da se na taj rezultat nista vise ne nadovezuje.
        /// </summary>
        private void RestartScreenAfterResult()
        {
            screen = "";
            numberOfDigits = 0;
            decimalPoint = false;
            lastIsOperator = false;
        }

        private void Reset()
        {
            screen = "0";
            lastScreen = "";
            initialValue = true;
            numberOfDigits = 0;
            decimalPoint = false;
            lastIsOperator = false;
            operatorSelected = false;
            memory = null;
        }

        private void ChangeNumberSign()
        {
            if (screen.StartsWith("-"))
            {
                screen = screen.Substring(1);
            }
            else
            {
                screen = screen.Insert(0, "-");
            }
        }

        /// <summary>
        /// Funckija koja provjerava dali je napisani broj na ekranu napisan kao 'nekiBroj,0' i ako je onda odreže dio sa nulom o ostavi samo 'nekiBroj'
        /// </summary>
        private void EditScreenNumber()
        {
            if (screen.Contains(',') && screen.Length > screen.IndexOf(',') + 1)
            {
                string afterComa = screen.Substring(screen.IndexOf(',') + 1);
                if (afterComa == "0")
                {
                    screen = screen.Substring(0, screen.IndexOf(','));
                    decimalPoint = false;
                }
            }
            else if (screen.EndsWith(","))
            {
                screen = screen.Substring(0, screen.IndexOf(','));
            }
        }

        public string GetCurrentDisplayState()
        {
            return screen;
        }

        public void IncrementNumOfDigits()
        {
            numberOfDigits++;
        }

        public bool IsDigitSpaceFull()
        {
            return numberOfDigits < 10 ? false : true;
        }

        public void AddToScreen(char sign)
        {
            screen += sign;
        }

        public bool DecimalPoint
        {
            get
            {
                return decimalPoint;
            }
            set
            {
                decimalPoint = value;
            }
        }

        public bool LastIsOperator
        {
            get
            {
                return lastIsOperator;
            }
            set
            {
                lastIsOperator = value;
            }
        }

        public bool UnarAfterBinar
        {
            get
            {
                return unarAfterBinar;
            }
            set
            {
                unarAfterBinar = value;
            }
        }

        public bool JustNull()
        {
            return screen == "0" ? true : false;
        }

        public void CleanScreen()
        {
            decimalPoint = false;
            numberOfDigits = 0;
            screen = "";
        }

        public void TransferScreen()
        {
            lastScreen = screen;
        }

        private decimal GetDecimalFromString(string value)
        {
            System.Globalization.CultureInfo culInfo = new System.Globalization.CultureInfo("en-US");
            value = value.Replace(",", ".");
            return decimal.Parse(value, culInfo.NumberFormat);
        }

        public void SetLastIsResult()
        {
            lastIsResult = true;
        }
    }

    /// <summary>
    /// Klasa koju koristimo za sve izračune.
    /// </summary>
    public class Calculate
    {
        Kalkulator kalkulator;

        public Calculate(Kalkulator kalkulator)
        {
            this.kalkulator = kalkulator;
        }

        public string Process(char oper, decimal firstValue, decimal secondValue)
        {
            //obavjestavamo kalkulator da je zadnja operacija bila racunska i da je prikazan nekakav rezultat.
            kalkulator.SetLastIsResult();
            switch (oper)
            {
                case '+':
                    return DoubleToString(Convert.ToDouble(firstValue + secondValue));
                case '-':
                    return DoubleToString(Convert.ToDouble(firstValue - secondValue));
                case '*':
                    return DoubleToString(Convert.ToDouble(firstValue * secondValue));
                case '/':
                    return DoubleToString(Convert.ToDouble(firstValue / secondValue));
                default:
                    return null;
            }
        }

        public string Process(char oper, decimal value)
        {
            //obavjestavamo kalkulator da je zadnja operacija bila racunska i da je prikazan nekakav rezultat.
            kalkulator.SetLastIsResult();
            if (kalkulator.LastIsOperator)
            {
                kalkulator.UnarAfterBinar = true;
            }
            else
            {
                kalkulator.UnarAfterBinar = false;
            }
            switch (oper)
            {
                case 'S':
                    return DoubleToString(Math.Sin(Convert.ToDouble(value)));
                case 'K':
                    return DoubleToString(Math.Cos(Convert.ToDouble(value)));
                case 'T':
                    return DoubleToString(Math.Tan(Convert.ToDouble(value)));
                case 'Q':
                    return DoubleToString(Convert.ToDouble(value * value));
                case 'R':
                    return DoubleToString(Math.Sqrt(Convert.ToDouble(value)));
                case 'I':
                    if (value == 0)
                    {
                        return null;
                    }
                    return DoubleToString(Convert.ToDouble(1 / value));
                default:
                    return null;
            }
        }

        private string DoubleToString(double result)
        {
            if (Double.IsNaN(result))
            {
                return null;
            }
            string resultConv = String.Format("{0:0.#########}", result);
            resultConv = resultConv.Replace('.', ',');
            string roundPart = resultConv;
            //idemo provjerit dali cijelobroini dio ima vise od 10 znamenki
            if (roundPart.Contains(','))
            {
                roundPart = roundPart.Substring(0, resultConv.IndexOf(','));
            }
            if (roundPart.StartsWith("-"))
            {
                roundPart = roundPart.Substring(1);
            }
            if (roundPart.Length > 10)
            {
                return null;
            }
            //ako znamo da cijelobrojni dio nije veci od 10 znamenki onda provjerimo dali ima decimalni zarez i ako ima odrežimo nedozvoljeni dio.
            if (resultConv.Contains(',') && resultConv.StartsWith("-"))
            {
                if (resultConv.Length > 12)
                {
                    resultConv = resultConv.Substring(0, 12);
                }
            }
            else if (resultConv.Contains(','))
            {
                if (resultConv.Length > 11)
                {
                    resultConv = resultConv.Substring(0, 11);
                }
            }
            return resultConv;
        }
    }

    /// <summary>
    /// Klasa koja predstavlja decimalni broj te sadrži metode za obradu unosa decimalnog broja.
    /// </summary>
    public class Digit
    {
        Kalkulator kalkulator;
        char digit;

        public Digit(Kalkulator kalkulator, char digit)
        {
            this.kalkulator = kalkulator;
            this.digit = digit;
            Process();
        }

        /// <summary>
        /// Obrađuje uneseni decimalni broj.
        /// </summary>
        private void Process()
        {
            //provjeravamo dali je zadnji unos bio operator i ako je onda brišemo stanje ekrana i dodajemo novu brojku na ekran.
            if (kalkulator.LastIsOperator)
            {
                kalkulator.TransferScreen();
                kalkulator.CleanScreen();
                kalkulator.IncrementNumOfDigits();
                kalkulator.AddToScreen(digit);
            }
            else if (kalkulator.IsDigitSpaceFull())
            {
                return;
            }
            else
            {
                //ako je na keranu napisana samo nula, a korisnik je upisao jos jednu nulu onda se ne dogodi nista.
                if (digit == '0' && kalkulator.JustNull())
                {
                    return;
                }
                kalkulator.IncrementNumOfDigits();
                kalkulator.AddToScreen(digit);
            }
        }
    }
}
