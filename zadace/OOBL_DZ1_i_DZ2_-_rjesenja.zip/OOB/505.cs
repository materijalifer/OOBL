﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


                              
namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {
        private bool check;
        private string firstNumber;
        private string secondNumber;
        private string displayState = "0";
        private static int maxLength = 10;
        private decimal firstVariable;
        private decimal secondVariable;
        private decimal result;
        private static int equalCounter = 0;
        private static string opr = "";
        private string memoryVariable = "0";
        private bool someFlag = false;
        private decimal temp;

        private bool errorFlag = false;
        private readonly string validDigits = "0123456789";

        /*************************************/

        public void Press(char inPressedDigit)
        {


            if (errorFlag == true && (inPressedDigit != 'C' && inPressedDigit != 'O'))
            {
                return;
            }

            if (inPressedDigit != '=')
            {
                secondVariable = 0;
                equalCounter = 0;
            }
            // provjera ako sadrži decimalni zarez ili -, u odnosu na to postavlja maxLength
            if (displayState.Contains(",") && displayState.Contains("-"))
            {
                maxLength = 12;
            }
            else if (displayState.Contains(","))
            {
                maxLength = 11;
            }
            else if (displayState.Contains("-"))
            {
                maxLength = 11;
            }
            else
            {
                maxLength = 10;
            }

            // unos znamenki je moguć ako je duljina stanja na ekranu manja od maxLength
            //if (displayState.Length < maxLength)
            // {

            // gumb znamenka
            if (validDigits.Contains(inPressedDigit))
            {
                if (displayState.Length < maxLength)
                {
                    if (check == true)
                    {
                        displayState = "";
                    }
                    if (displayState == "0" || someFlag == true) //|| displayState.Length == maxLength)
                    {
                        displayState = "" + inPressedDigit;
                    }
                    else
                    {
                        displayState = displayState + inPressedDigit;
                    }
                    check = false;
                }
                else if (displayState.Length == maxLength && opr != "")
                {
                    displayState = "" + inPressedDigit;
                }
            }
            // }

            // gumb plus
            if (inPressedDigit == '+')
            {
                roundResult();
                opr = "+";
                firstNumber = displayState;
                firstVariable = Convert.ToDecimal(displayState);
                check = true;
            }

            // gumb minus
            if (inPressedDigit == '-')
            {
                roundResult();
                opr = "-";
                firstNumber = displayState;
                firstVariable = Convert.ToDecimal(displayState);
                check = true;
            }

            //gumb dijeljeno
            if (inPressedDigit == '/')
            {
                roundResult();
                opr = "/";
                firstNumber = displayState;
                firstVariable = Convert.ToDecimal(displayState);
                check = true;
            }

            // gumb puta
            if (inPressedDigit == '*')
            {
                roundResult();
                opr = "*";
                firstNumber = displayState;
                firstVariable = Convert.ToDecimal(displayState);
                check = true;
            }

            //gumb decimalni zarez
            if (inPressedDigit == ',')
            {

                if (!displayState.Contains(","))
                {

                    displayState += ",";
                }
            }

            // gumb jednako
            if (inPressedDigit == '=')
            {

                if (equalCounter == 0)
                {
                    result = Convert.ToDecimal(displayState);
                    secondVariable = Convert.ToDecimal(displayState);
                }
                equalCounter++;
                if (opr == "+")
                {
                    if (equalCounter == 0)
                    {
                        result = firstVariable + Convert.ToDecimal(displayState);
                    }
                    else
                    {
                        result = firstVariable + secondVariable;
                        firstVariable = firstVariable + secondVariable;
                    }
                }
                if (opr == "/")
                {
                    if (Convert.ToDouble(displayState) == 0)
                    {
                        errorFlag = true;
                        displayState = "-E-";
                        return;
                    }
                    else
                    {
                        if (equalCounter == 0)
                        {
                            result = firstVariable / Convert.ToDecimal(displayState);
                        }
                        else
                        {
                            result = firstVariable / secondVariable;
                            firstVariable = firstVariable / secondVariable;
                        }
                    }
                }

                if (opr == "*")
                {
                    if (equalCounter == 0)
                    {
                        result = firstVariable * Convert.ToDecimal(displayState);
                    }
                    else
                    {
                        result = firstVariable * secondVariable;
                        firstVariable = firstVariable * secondVariable;
                    }
                }
                if (opr == "-")
                {
                    if (equalCounter == 0)
                    {
                        result = firstVariable - Convert.ToDecimal(displayState);
                    }
                    else
                    {
                        result = firstVariable - secondVariable;
                        firstVariable = firstVariable - secondVariable;
                    }
                } if (displayState.Contains(","))
                {
                    if (Convert.ToString(Math.Round(result, maxLength - Convert.ToString(Math.Truncate(result)).Length - 2, MidpointRounding.AwayFromZero)).Length > maxLength)
                    {
                        errorFlag = true;
                        displayState = "-E-";
                    }
                    else
                    {
                        displayState = Convert.ToString(result);
                        roundResult();
                    }
                }
                else if (Convert.ToString(result).Length > maxLength)
                {
                    errorFlag = true;
                    displayState = "-E-";
                }
                else
                {
                    displayState = Convert.ToString(result);
                    roundResult();
                } if (displayState != "-E-")
                {
                    roundResult();
                }
            }

            //gumb za spremanje u memoriju

            if (inPressedDigit == 'P')
            {
                someFlag = false;
                memoryVariable = displayState;
            }

            //gumb za dohvat varijable iz memorije
            if (inPressedDigit == 'G')
            {
                displayState = memoryVariable;
                someFlag = true;
            }

            //gumb za tangens
            if (inPressedDigit == 'T')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                temp = (decimal)Math.Tan((double)temp);
                displayState = Convert.ToString(temp);
                roundResult();
            }

            //gumb za kosinus
            if (inPressedDigit == 'K')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                temp = (decimal)Math.Cos((double)temp);
                displayState = Convert.ToString(temp);
                roundResult();
            }

            //gumb za sinus
            if (inPressedDigit == 'S')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                temp = (decimal)Math.Sin((double)temp);
                displayState = Convert.ToString(temp);
                roundResult();
            }

            //gumb za kvadriranje
            if (inPressedDigit == 'Q')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                temp = temp * temp;
                displayState = Convert.ToString(temp);
                roundResult();
            }

            //gumb za korijen
            if (inPressedDigit == 'R')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                if (temp < 0)
                {
                    errorFlag = true;
                    displayState = "-E-";
                }
                else
                {
                    temp = (decimal)Math.Sqrt((double)temp);
                    displayState = Convert.ToString(temp);
                    roundResult();
                }
            }

            // gumb za inverz
            if (inPressedDigit == 'I')
            {
                someFlag = true;
                temp = decimal.Parse(displayState);
                if (temp == 0)
                {
                    errorFlag = true;
                    displayState = "-E-";
                }
                else
                {
                    temp = 1 / temp;
                    displayState = Convert.ToString(temp);
                    roundResult();
                }
            }

            // gumb za reset
            if (inPressedDigit == 'O')
            {
                reset();
            }

            //gumb za promjenu predznaka
            if (inPressedDigit == 'M')
            {
                if (displayState != "0")
                {
                    someFlag = false;
                    changeSign();
                }
            }

            // clear gumb
            if (inPressedDigit == 'C')
            {
                reset();
            }


            // if - elseom ili switch - caseovima obradi 
            // koji je char unesen i pozovi pripadajući
            // skup operacija

        }

        private void changeSign()
        {
            if (displayState[0] == '-')
            {
                displayState = displayState.Substring(1);

            }
            else
            {
                displayState = "-" + displayState;
            }
        }

        private void reset()
        {
            firstNumber = "";
            firstVariable = 0;
            secondNumber = "";
            secondVariable = 0;
            memoryVariable = "0";
            opr = "";
            someFlag = false;
            check = false;
            errorFlag = false;
            result = 0;
            displayState = "0";
        }

        private void roundResult()
        {
            int var = 0;
            if (displayState.Contains(",") && displayState.Contains("-"))
            {
                maxLength = 12;
                var = 2;
            }
            else if (displayState.Contains(","))
            {
                maxLength = 11;
                var = 1;
            }
            else if (displayState.Contains("-"))
            {
                maxLength = 11;
                var = 1;

            }
            else
            {
                maxLength = 10;
            }

            temp = decimal.Parse(displayState);
            if (displayState.Contains(","))
            {
                temp = Math.Round(temp, maxLength - Convert.ToString(Math.Truncate(temp)).Length - var);

            }

            displayState = temp.ToString("G29");

            someFlag = false;
        }

        public string GetCurrentDisplayState()
        {

            return this.displayState;
        }


    }


}
