﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Reflection;    //za KeyHandlersFactory


namespace PrvaDomacaZadaca_Kalkulator
{
    /****************************************************************************/
    /*****************   Calculator & Display + Factory  ************************/
    /****************************************************************************/
    
    #region Calculator & Display + Factory

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    public class Calculator : ICalculator
    {
        private Display _display;

        public string Buffer { get; set; }                             //memorija
        public BinaryOperation CurrentOperation { get; set; }         //trenutna operacija
        public CalculatorState CurrentState { get; set; }             //stanje kalkulatora
        public string LastEntry { get; set; }                         //zadnji korisnikov unos

        private static KeyHandlerFactory keyHandlerFactory;

        //konstruktor
        public Calculator()
        {
            _display = new Display(10);     //postavljanje displaya - moze primiti deset znamenki na ekran
            keyHandlerFactory = new KeyHandlerFactory();

            KeyHandler.Initialize(this);            //postavlja KeyHandlerima kalkulator s kojim rade
            Reset();
        }

        //resetira kalkulator - on/off
        public void Reset()
        {
            CurrentState = CalculatorState.Initialize();
            CurrentOperation = new None();
            this.Buffer = null;
            this.LastEntry = null;

            ResetDisplayBuffer();
            ClearScreen();
        }

        /************************** funkcije za rad s displayom   ***********************/

        //dodaje novi broj ili ',' u spremnik displaya ako nije pun
        public void AddToDisplay(char digit)
        {
            //provjerava je li display pun
            if (digit != ',' && _display.IsFull())
                return;

            //ne zapisuje vise zareza
            if (digit == ',' && _display.DisplayBuffer.Contains(','))
                return;

            //decimalni zarez nadopisi na 0, a brojke brisu 0
            if (_display.DisplayBuffer == "0" && digit != ',')
                _display.DisplayBuffer = digit.ToString();
            else
                _display.DisplayBuffer = _display.DisplayBuffer + digit;

            _display.Flush();
        }

        //resetira spremnik displaya, ali ispis na ekranu ostaje isti
        public void ResetDisplayBuffer()
        {
            _display.DisplayBuffer = "0";
        }

        //postavlja "0" na display
        public void ClearScreen()
        {
            _display.ResetDisplayState();
        }

        //ispisuje rezultat operacije, uz brisanje nula i zaokruzivanje
        public void Print(string result)
        {
            //ako je doslo do greske pri racunanju - error
            if (result == "-E-")
            {
                _display.DisplayBuffer = "-E-";
                _display.Flush();
                return;
            }

            result = RemoveZeros(result);
            _display.DisplayBuffer = Round(result);
            _display.Flush();
        }
        //ispisuje postojeci sadrzaj ekrana
        public void Print()
        {
            Print(_display.DisplayState);
        }
        //ispisuje direktno na ekran bez ikakvih zaokruzivanja
        public void RawPrint(string result)
        {
            _display.DisplayBuffer = result;
            _display.Flush();
        }

        //zaokruzuje broj na maksimalan moguci broj decimala
        public string Round(string number)
        {
            if (number == "-E-")
                return number;

            //rijesava se vodecih nula i nula u decimalnom dijelu
            number = RemoveZeros(number);

            string[] parts = number.Split(',');
            int integerLength = NumberOfDigits(parts[0]);

            //ako cjelobrojni dio ima vise od maks znamenki - error
            if (integerLength > _display.MaxNumberOfDigits)
            {
                return "-E-";
            }

            number = Math.Round(Convert.ToDecimal(number),
                               _display.MaxNumberOfDigits - integerLength).ToString();
            return number;
        }

        //vraca broj znamenki u broju - ne broji predznak i zarez
        public static int NumberOfDigits(string number)
        {
            int numberOfDigits = number.Length;
            if (number.Contains(','))
                numberOfDigits--;
            if (number.Contains('-'))
                numberOfDigits--;
            return numberOfDigits;
        }

        //rijesava se vodecih nula i nula u decimalnom dijelu
        public static string RemoveZeros(string number)
        {
            return double.Parse(number).ToString();
        }


        /************************  implementacija sucelja ICalculator *********************/
        public void Press(char inPressedDigit)
        {
            if (char.IsDigit(inPressedDigit))
                CurrentState.HandleKeyPress(keyHandlerFactory.Create('#', inPressedDigit));
            else
                CurrentState.HandleKeyPress(keyHandlerFactory.Create(inPressedDigit));
        }

        public string GetCurrentDisplayState()
        {
            return _display.DisplayState;
        }


    }

    public class Display
    {
        public string DisplayState { get; private set; }        //ekran
        public string DisplayBuffer { get; set; }               //spremnik
        public int MaxNumberOfDigits { get; private set; }       //dozvoljeni broj znamenki

        //konstruktor
        public Display(int maxNumberOfDigits)
        {
            this.DisplayBuffer = "0";
            this.Flush();
            this.MaxNumberOfDigits = maxNumberOfDigits;
        }

        //postavlja DisplayState u 0
        public void ResetDisplayState()
        {
            this.DisplayState = "0";
        }

        //ispisuje sadrzaj iz spremnika na ekran
        public void Flush()
        {
            //ako u bufferu pise tocka, zamijeni je sa zarezom
            if (this.DisplayBuffer.Contains('.'))
                this.DisplayBuffer = this.DisplayBuffer.Replace('.', ',');

            this.DisplayState = this.DisplayBuffer;
        }

        //provjerava je li spremnik sadrzi vise simbola nego sto je dozvoljeno
        public bool IsFull()
        {
            int numberOfDigits = Calculator.NumberOfDigits(this.DisplayBuffer);

            if (numberOfDigits >= this.MaxNumberOfDigits)
                return true;
            return false;
        }
    }

    #endregion

    /****************************************************************************/
    /***********************   Calculator States    *****************************/
    /****************************************************************************/
    
    #region CalculatorStates

    public abstract class CalculatorState
    {
        //vraca pocetno stanje kalkulatora
        public static CalculatorState Initialize()
        {
            return new InitialState();
        }

        //metoda koju pojedinacna stanja implementiraju
        public abstract void HandleKeyPress(KeyHandler keyHandler);
    }

    public class ErrorOccurred : CalculatorState
    {
        public override void HandleKeyPress(KeyHandler keyHandler)
        {
            keyHandler.Handle(this);
        }
    }

    public class InitialState : CalculatorState
    {
        public override void HandleKeyPress(KeyHandler keyHandler)
        {
            keyHandler.Handle(this);
        }
    }

    public class NextEntry : CalculatorState
    {
        public override void HandleKeyPress(KeyHandler keyHandler)
        {
            keyHandler.Handle(this);
        }
    }

    public class ReceivingDigits : CalculatorState
    {
        public override void HandleKeyPress(KeyHandler keyHandler)
        {
            keyHandler.Handle(this);
        }
    }

    public class Result : CalculatorState
    {
        public override void HandleKeyPress(KeyHandler keyHandler)
        {
            keyHandler.Handle(this);
        }
    }

    #endregion

    /****************************************************************************/
    /*************************    Key Handlers    *******************************/
    /****************************************************************************/

    #region KeyHandlers + KeyHandlerFactory
    
    public class KeyHandlerFactory
    {
        //registar svih tipki
        private Dictionary<char, Type> registry = new Dictionary<char, Type>();

        //konstruktor puni registar
        public KeyHandlerFactory()
        {
            Type[] keyTypes = Assembly.GetAssembly(typeof(KeyHandler)).GetTypes();
            foreach (Type keyType in keyTypes)
            {
                if (!typeof(KeyHandler).IsAssignableFrom(keyType) ||
                    keyType == typeof(KeyHandler) ||
                    keyType.IsAbstract)
                {   //klasa nije konkretna ili izvedena iz KeyPressed
                    continue;
                }

                //nalazi oznaku (key) nadjene klase izvedene iz KeyPressed
                FieldInfo fieldInfo = keyType.GetField("key");

                char key = (char)fieldInfo.GetValue(null);

                //sprema klasu u registar
                registry.Add(key, keyType);
            }
        }

        public KeyHandler Create(char key, params object[] args)
        {
            // kreira i vraca tipku
            return (KeyHandler)Activator.CreateInstance(registry[key], args);
        }

    }

    public abstract class KeyHandler
    {
        protected static Calculator _calculator;

        public static void Initialize(Calculator c)
        {
            _calculator = c;
        }

        public abstract void Handle(InitialState state);
        public abstract void Handle(ReceivingDigits state);
        public abstract void Handle(NextEntry state);
        public abstract void Handle(Result state);
        public abstract void Handle(ErrorOccurred state);
    }

    public abstract class BinaryOperatorHandler : KeyHandler
    {
        protected abstract void CreateOperation();

        //ucitava broj s ekrana, kreira operaciju i prelazi u stanje NextEntry
        private void Handle()
        {
            //odstranjuje viska nule i ispisuje takav broj na ekran
            _calculator.Print();

            //preuzima broj s ekrana, postavlja ga kao desni operand i obavlja operaciju
            _calculator.LastEntry = _calculator.GetCurrentDisplayState();
            _calculator.CurrentOperation.SetRightOperand(_calculator.LastEntry);
            string result = _calculator.CurrentOperation.Evaluate();

            //ispisuje rezultat
            _calculator.Print(result);
            _calculator.ResetDisplayBuffer();

            if (_calculator.GetCurrentDisplayState() == "-E-")
            {   //ako je bilo dijeljenje s 0 ili je rezultat veci od 10 znamenki
                _calculator.CurrentState = new ErrorOccurred();
                return;
            }

            //sprema rezultat prethodne operacije kao zadnji entry i lijevi operand iduce
            _calculator.LastEntry = _calculator.GetCurrentDisplayState();
            CreateOperation();
            _calculator.CurrentOperation.SetLeftOperand(_calculator.LastEntry);

            _calculator.CurrentState = new NextEntry();

        }

        //obradi binarni operator - prelazi u stanje NextEntry
        public override void Handle(InitialState state)
        {
            Handle();
        }

        //obradi binarni operator - prelazi u stanje NextEntry
        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        //obradi binarni operator - ne mijenja stanje
        public override void Handle(NextEntry state)
        {
            CreateOperation();
            _calculator.CurrentOperation.SetLeftOperand(_calculator.LastEntry);
        }

        //obradi binarni operator - prelazi u stanje NextEntry
        public override void Handle(Result state)
        {
            _calculator.CurrentOperation = new None();
            Handle();
        }

        //ne radi nista - binarni operatori ne rjesavaju error
        public override void Handle(ErrorOccurred state)
        {
        }
    }

    public class DivideHandler : BinaryOperatorHandler
    {
        public const char key = '/';

        protected override void CreateOperation()
        {
            _calculator.CurrentOperation = new Division();
        }
    }

    public class MinusHandler : BinaryOperatorHandler
    {
        public const char key = '-';

        protected override void CreateOperation()
        {
            _calculator.CurrentOperation = new Subtraction();
        }
    }

    public class MultiplyHandler : BinaryOperatorHandler
    {
        public const char key = '*';

        protected override void CreateOperation()
        {
            _calculator.CurrentOperation = new Multiplication();
        }
    }

    public class PlusHandler : BinaryOperatorHandler
    {
        public const char key = '+';

        protected override void CreateOperation()
        {
            _calculator.CurrentOperation = new Addition();
        }
    }

    public abstract class UnaryOperatorHandler : KeyHandler
    {
        // unarne operacije razlikuju se samo po tome koju operaciju izvode
        // prijelazi izmedju stanja su im jednaki
        protected abstract void PerformUnaryOperation();
        private void Handle()
        {
            PerformUnaryOperation();
            _calculator.ResetDisplayBuffer();
            if (_calculator.GetCurrentDisplayState() == "-E-")
                _calculator.CurrentState = new ErrorOccurred();
        }

        // obavi operaciju - ne mijenja stanje
        public override void Handle(InitialState state)
        {
            Handle();
        }

        // obavi operaciju - mijenja stanje u InitialState
        public override void Handle(ReceivingDigits state)
        {
            _calculator.CurrentState = new InitialState();
            Handle();

        }

        // obavi operaciju - mijenja stanje u InitialState
        public override void Handle(NextEntry state)
        {
            _calculator.CurrentState = new InitialState();
            Handle();
        }

        // obavi operaciju - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        // obavi operaciju - mijenja stanje u InitialState
        public override void Handle(ErrorOccurred state)
        { }
    }

    public class CosineHandler : UnaryOperatorHandler
    {
        public const char key = 'K';

        //ispisuje cosinus(ekran) na ekran
        protected override void PerformUnaryOperation()
        {
            double result = Math.Cos(double.Parse(_calculator.GetCurrentDisplayState()));
            _calculator.Print(result.ToString());
        }
    }

    public class ReciprocalHandler : UnaryOperatorHandler
    {
        public const char key = 'I';

        //ispisuje 1/ekran na ekran ili error ako je na ekranu 0
        protected override void PerformUnaryOperation()
        {
            double displayState = double.Parse(_calculator.GetCurrentDisplayState());

            if (displayState != 0)
                _calculator.Print((1.0d / displayState).ToString());
            else
            {
                _calculator.Print("-E-");
            }
        }
    }

    public class SineHandler : UnaryOperatorHandler
    {
        public const char key = 'S';

        //ispisuje sin(ekran) na ekran
        protected override void PerformUnaryOperation()
        {
            double result = Math.Sin(double.Parse(_calculator.GetCurrentDisplayState()));
            _calculator.Print(result.ToString());
        }
    }

    public class SquareHandler : UnaryOperatorHandler
    {
        public const char key = 'Q';

        //ispisuje ekran^2 na ekran
        protected override void PerformUnaryOperation()
        {
            double result = Math.Pow(double.Parse(_calculator.GetCurrentDisplayState()), 2);
            _calculator.Print(result.ToString());
        }
    }

    public class SquareRootHandler : UnaryOperatorHandler
    {
        public const char key = 'R';

        //ispisuje korijen(ekran) na ekran ili error za ekran < 0
        protected override void PerformUnaryOperation()
        {
            double displayState = double.Parse(_calculator.GetCurrentDisplayState());
            if (displayState >= 0)
                _calculator.Print(Math.Sqrt(displayState).ToString());
            else
            {
                _calculator.Print("-E-");
            }
        }
    }

    public class TangentHandler : UnaryOperatorHandler
    {
        public const char key = 'T';

        //ispisuje tangens ili error za ekran = +-pi/2
        protected override void PerformUnaryOperation()
        {
            string displayState = _calculator.GetCurrentDisplayState();

            if (_calculator.Round(displayState) != _calculator.Round((Math.PI / 2).ToString()) &&
                _calculator.Round(displayState) != _calculator.Round((-Math.PI / 2).ToString()))
            {
                _calculator.Print(Math.Tan(double.Parse(displayState)).ToString());
            }
            else
            {
                _calculator.Print("-E-");
            }
        }
    }

    public class ClearHandler : KeyHandler
    {
        public const char key = 'C';

        //brise display - ne mijenja stanje
        private void Handle()
        {
            _calculator.ResetDisplayBuffer();
            _calculator.ClearScreen();
        }

        //brise display - ne mijenja stanje
        public override void Handle(InitialState state)
        {
            Handle();
        }

        //brise display - prelazi u InitialState
        public override void Handle(ReceivingDigits state)
        {
            Handle();
            _calculator.CurrentState = new InitialState();
        }

        //brise display - prelazi u InitialState
        public override void Handle(NextEntry state)
        {
            Handle();
            _calculator.CurrentState = new InitialState();
        }

        //brise display - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        //brise display, operaciju i last entry - prelazi u InitialState
        public override void Handle(ErrorOccurred state)
        {
            _calculator.Reset();    //unutar Reset se prelazi u InitialState
        }
    }

    public class CommaHandler : KeyHandler
    {
        public const char key = ',';

        // dodaje zarez na ekran
        private void Handle()
        {
            _calculator.AddToDisplay(key);
        }

        // dodaje zarez na screen - prelazi u stanje ReceivingDigits
        public override void Handle(InitialState state)
        {
            Handle();
            _calculator.CurrentState = new ReceivingDigits();
        }

        // dodaje zarez ako vec ne postoji - ne mijenja stanje
        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        // dodaje zarez ako vec ne postoji -  ulazi u stanje ReceivingDigits
        public override void Handle(NextEntry state)
        {
            Handle();
            _calculator.CurrentState = new ReceivingDigits();
        }

        // dodaje zarez ako vec ne postoji - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        // ne radi nista, ',' ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }
    }

    public class DigitHandler : KeyHandler
    {
        public const char key = '#';

        private char _digit;
        public DigitHandler(char digit)
        {
            _digit = digit;
        }

        private void Handle()
        {
            _calculator.AddToDisplay(_digit);
        }

        // dodaje broj na ekran - prelazi u stanje ReceivingDigits
        public override void Handle(InitialState state)
        {
            Handle();
            _calculator.CurrentState = new ReceivingDigits();
        }

        // dodaje broj na ekran ako nije pun - ne mijenja stanje
        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        // dodaje broj na ekran ako nije pun - prelazi u stanje ReceivingDigits
        public override void Handle(NextEntry state)
        {
            Handle();
            _calculator.CurrentState = new ReceivingDigits();
        }

        // dodaje broj na ekran ako nije pun - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        // ne radi nista - brojka ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }
    }

    public class EqualsHandler : KeyHandler
    {
        public const char key = '=';

        //evaluira operaciju i ispisuje rezultat na ekran
        //nakon toga resetira DisplayBuffer
        private void Handle()
        {
            //preuzima broj s ekrana i evaluira operaciju
            _calculator.LastEntry = _calculator.GetCurrentDisplayState();
            _calculator.CurrentOperation.SetRightOperand(_calculator.LastEntry);
            string result = _calculator.CurrentOperation.Evaluate();

            // ispisuje rezultat            
            _calculator.Print(result);
            _calculator.ResetDisplayBuffer();

            if (_calculator.GetCurrentDisplayState() == "-E-")
            {   //ako je bilo dijeljenje s 0 ili je rezultat veci od 10 znamenki
                _calculator.CurrentState = new ErrorOccurred();
                return;
            }

            //_calculator.CurrentOperation.SetRightOperand(_calculator.LastEntry);
            _calculator.CurrentState = new Result();
        }

        public override void Handle(InitialState state)
        {
            Handle();
        }

        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        public override void Handle(NextEntry state)
        {
            Handle();
        }

        public override void Handle(Result state)
        {
            _calculator.CurrentOperation.SetLeftOperand(_calculator.GetCurrentDisplayState());
            string result = _calculator.CurrentOperation.Evaluate();

            // ispisuje rezultat            
            _calculator.Print(result);
            _calculator.ResetDisplayBuffer();

            if (_calculator.GetCurrentDisplayState() == "-E-")
            {   //ako je bilo dijeljenje s 0 ili je rezultat veci od 10 znamenki
                _calculator.CurrentState = new ErrorOccurred();
                return;
            }
        }

        //ne radi nista - '=' ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }


    }

    public class LoadHandler : KeyHandler
    {
        public const char key = 'G';

        //ispisuje podatak memorije na ekran
        private void Handle()
        {
            if (_calculator.Buffer != null)
                _calculator.Print(_calculator.Buffer);
            _calculator.ResetDisplayBuffer();
        }

        //ispisuje podatak memorije na ekran - ne mijenja stanje
        public override void Handle(InitialState state)
        {
            Handle();
        }

        //ispisuje podatak memorije na ekran - prelazi u InitialState        
        public override void Handle(ReceivingDigits state)
        {
            Handle();
            _calculator.CurrentState = new InitialState();
        }

        //ispisuje podatak memorije na ekran - prelazi u InitialState
        public override void Handle(NextEntry state)
        {
            Handle();
            _calculator.CurrentState = new InitialState();
        }

        //ispisuje podatak memorije na ekran - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        //ne radi nista - dohvat iz memorije ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }
    }

    public class OnOffHandler : KeyHandler
    {
        public const char key = 'O';

        //resetira kalkulator
        private void Handle()
        {
            _calculator.Reset();
        }

        //resetira kalkulator - prelazi u InitialState
        public override void Handle(InitialState state)
        {
            Handle();   //unutar Reset se prelazi u InitialState
        }

        //resetira kalkulator - prelazi u InitialState
        public override void Handle(ReceivingDigits state)
        {
            Handle();   //unutar Reset se prelazi u InitialState
        }

        //resetira kalkulator - prelazi u InitialState
        public override void Handle(NextEntry state)
        {
            Handle();   //unutar Reset se prelazi u InitialState            
        }

        //resetira kalkulator - prelazi u InitialState
        public override void Handle(Result state)
        {
            Handle();   //unutar Reset se prelazi u InitialState            
        }

        //resetira kalkulator (rijesava error) - prelazi u InitialState
        public override void Handle(ErrorOccurred state)
        {
            Handle();   //unutar Reset se prelazi u InitialState
        }

    }

    public class SignHandler : KeyHandler
    {
        public const char key = 'M';

        //ispisuje -ekran na ekran
        private void Handle()
        {
            if (_calculator.GetCurrentDisplayState() == "0")
                return;

            //mijenja predznak na displayu
            string displayState = _calculator.GetCurrentDisplayState();

            if (displayState[0] != '-')
                displayState = "-" + displayState;
            else
                displayState = displayState.Substring(1);

            //koristi raw print tako da se na ekranu mijenja samo predznak (nema brisanja nula i sl.)
            _calculator.RawPrint(displayState);
        }

        //ispisuje -ekran na ekran - ne mijenja stanje
        public override void Handle(InitialState state)
        {
            Handle();
        }

        //ispisuje -ekran na ekran - ne mijenja stanje
        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        //ispisuje -ekran na ekran - ne mijenja stanje
        public override void Handle(NextEntry state)
        {
            Handle();
        }

        //ispisuje -ekran na ekran - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        //ne radi nista - minus ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }


    }

    public class StoreHandler : KeyHandler
    {
        public const char key = 'P';

        //sprema ekran u memoriju
        private void Handle()
        {
            _calculator.Buffer = _calculator.GetCurrentDisplayState(); ;
        }

        //sprema ekran u memoriju - ne mijenja stanje
        public override void Handle(InitialState state)
        {
            Handle();
        }

        //sprema ekran u memoriju - ne mijenja stanje
        public override void Handle(ReceivingDigits state)
        {
            Handle();
        }

        //sprema ekran u memoriju - ne mijenja stanje
        public override void Handle(NextEntry state)
        {
            Handle();
        }

        //sprema ekran u memoriju - ne mijenja stanje
        public override void Handle(Result state)
        {
            Handle();
        }

        //ne radi nista - spremanje u memoriju ne rijesava error
        public override void Handle(ErrorOccurred state)
        {
        }
    }

    #endregion


    /****************************************************************************/
    /**********************     Binary Operations    ****************************/
    /****************************************************************************/
    
    #region BinaryOperations

    public abstract class BinaryOperation
    {
        protected string _leftOperand;
        protected string _rightOperand;

        public virtual void SetLeftOperand(string leftOperand)
        {
            _leftOperand = leftOperand;
        }
        public virtual void SetRightOperand(string rightOperand)
        {
            _rightOperand = rightOperand;
        }

        public abstract string Evaluate();
    }

    public class Addition : BinaryOperation
    {
        public override string Evaluate()
        {
            double result = double.Parse(_leftOperand) + double.Parse(_rightOperand);
            return result.ToString();
        }
    }

    public class Subtraction : BinaryOperation
    {
        public override string Evaluate()
        {
            double result = double.Parse(_leftOperand) - double.Parse(_rightOperand);
            return result.ToString();
        }
    }

    public class Multiplication : BinaryOperation
    {
        public override string Evaluate()
        {
            double result = double.Parse(_leftOperand) * double.Parse(_rightOperand);
            return result.ToString();
        }
    }

    public class Division : BinaryOperation
    {
        public override string Evaluate()
        {
            double result;
            if (double.Parse(_rightOperand) != 0)
            {
                result = double.Parse(_leftOperand) / double.Parse(_rightOperand);
                return result.ToString();
            }
            else
                return "-E-";
        }
    }

    public class None : BinaryOperation
    {
        private string _lastSet;

        public override void SetLeftOperand(string leftOperand)
        {
            _lastSet = leftOperand;
        }

        public override void SetRightOperand(string rightOperand)
        {
            _lastSet = rightOperand;
        }

        public override string Evaluate()
        {
            return _lastSet;
        }
    }

    #endregion
}
