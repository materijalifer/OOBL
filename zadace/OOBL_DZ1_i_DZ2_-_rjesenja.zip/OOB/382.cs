﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

////Ivan Tolić 0036434413
namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


     public class StockExchange : IStockExchange
     {

         private StockRepository stockRepository = new StockRepository();
         private IndicesRepository indiciesRepository = new IndicesRepository();
         private PortfolioRepository portfoiloRepository = new PortfolioRepository();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock newStock = new StockExchangeStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stockRepository.Add(newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (stockRepository.Exist(inStockName))
             {
             stockRepository.Delete(inStockName);
             foreach (Index i in indiciesRepository.GetAll())
             {
                 if (i.IsStockPartOfIndex(inStockName))
                 {
                     i.RemoveStock(inStockName);
                 }
             }
             foreach (Portfolio i in portfoiloRepository.GetAll())
             {
                 if (i.StockExist(inStockName))
                 {
                     i.RemoveStock(inStockName);
                 }
             }
             }
             else throw new StockExchangeException("Ne postoji ta dionica");
         }

         public bool StockExists(string inStockName)
         {
             return stockRepository.Exist(inStockName);
         }

         public int NumberOfStocks()
         {
             return stockRepository.GetCount();
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             StockExchangeStock stock = (StockExchangeStock)stockRepository.Get(inStockName);
             stock.SetPrice(inStockValue, inTimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             StockExchangeStock stock = (StockExchangeStock)stockRepository.Get(inStockName);
             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             StockExchangeStock stock = (StockExchangeStock)stockRepository.Get(inStockName);
             return stock.GetInitalPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             StockExchangeStock stock = (StockExchangeStock)stockRepository.Get(inStockName);
             return stock.GetPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index newIndex = IndexFactory.CreateIndex(inIndexName, inIndexType, this.stockRepository);
             indiciesRepository.Add(newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index ind = (Index)indiciesRepository.Get(inIndexName);
             ind.AddStock(inStockName);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index ind = (Index)indiciesRepository.Get(inIndexName);
             ind.RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index ind = (Index)indiciesRepository.Get(inIndexName);
             return ind.IsStockPartOfIndex(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index ind = (Index)indiciesRepository.Get(inIndexName);
             return ind.GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return indiciesRepository.Exist(inIndexName);
         }

         public int NumberOfIndices()
         {
             return indiciesRepository.GetCount();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index ind = (Index)indiciesRepository.Get(inIndexName);
             return ind.NumberOfStocks;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio port = new Portfolio(inPortfolioID, stockRepository);
             portfoiloRepository.Add(port);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             Stock st = new Stock(inStockName, numberOfShares);

             port.AddStock(st);
             

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             port.DeleteStock(inStockName.ToUpper(), numberOfShares);
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             port.RemoveStock(inStockName.ToUpper());
             if (port.NumberOfStocks == 0) portfoiloRepository.Delete(port.ID);
         }

         public int NumberOfPortfolios()
         {
             return portfoiloRepository.GetCount();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             return port.NumberOfStocks;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfoiloRepository.Exist(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             return port.StockExist(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             return port.GetNumberOfShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
             return port.GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
                 Portfolio port = (Portfolio)portfoiloRepository.Get(inPortfolioID);
                 return port.GetPercentChange(Year, Month);
         }
     }

    /// <summary>
    /// Klasa implementira osnovnu dionicu koju koriste portfilio i indeksi (podatke za racunanje obavljaju pomocu trenutnih podataka na burzi)
    /// </summary>
    public class Stock
    {
        private string stockName;
        private long numberOfShares;
       

        public Stock()
        {
        }

        public Stock(string inStockName, int inNumberOfShares)
        {
            this.stockName = inStockName;
            if (inNumberOfShares > 0) this.numberOfShares = inNumberOfShares;
            else throw new StockExchangeException("Broj dionica mora biti veci od 0");
        }

        public Stock(string inStockName)
        {
            this.stockName = inStockName;
        }
                 
        public string StockName
         {
            set { this.stockName = value.ToUpper();}
            get { return this.stockName; }
         }

        public long NumberOfShares
        {
            set
            {
                if (value > 0)
                {
                    this.numberOfShares = value;
                }
                else
                {
                    throw new StockExchangeException("Broj dionica mora biti veci od 0");
                }
            }
            get { return this.numberOfShares; }
        }
    }

    /// <summary>
    /// Klasa koja predstavlja dionicu na burzi kojoj se prati cijena i koliko je prodana
    /// </summary>
    public class StockExchangeStock : Stock
    {
        private long numberOfFreeShares;
        private decimal price;
        private DateTime timeStamp;
        private SortedList<DateTime, decimal> priceHistory = new SortedList<DateTime, decimal>();

        public StockExchangeStock(string inStockName, long inNumberOfShares, decimal inPrice, DateTime inTimeStamp)
         {
             this.StockName = inStockName.ToUpper();
             this.NumberOfShares = inNumberOfShares;
             this.numberOfFreeShares = inNumberOfShares;
             SetPrice(inPrice, inTimeStamp);
             this.timeStamp = inTimeStamp;
         }
        /// <summary>
        /// Postavlja cijenu dionice
        /// </summary>
        /// <param name="inPrice">ulazna cijena</param>
        /// <param name="timeStamp">vrijeme postavljanja cijene</param>
        public void SetPrice(decimal inPrice, DateTime inTimeStamp)
         {
             if (inPrice > 0 && priceHistory.ContainsKey(inTimeStamp) == false) 
             {
                 this.priceHistory.Add(inTimeStamp, inPrice);
                 if (inTimeStamp > this.timeStamp)
                 {
                     this.price = inPrice;
                     this.timeStamp = inTimeStamp;
                 }
             }
             else
             {
                 throw new StockExchangeException("Cijena mora biti veca od 0, a vremenska oznaka mora biti jedisntvena");
             }
         }

        /// <summary>
        /// broj dionica koje se jos smiju preraspodijeliti u portfelje
        /// </summary>
         public long NumberOfFreeShares 
         {
             get { return this.numberOfFreeShares; }
             set { this.numberOfFreeShares = value; }
         }

         public decimal GetPrice()
         {
             return this.price;
         }

         public void SetTimeStamp(DateTime inTimeStamp)
         {
             this.timeStamp = inTimeStamp;
         }

         public DateTime GetTimeStamp()
         {
             return this.timeStamp;
         }
        /// <summary>
        /// vraca cijenu dionice u odredjenom trenutku
        /// </summary>
        /// <param name="inTimeStamp">vremenska oznaka</param>
        /// <returns>cijena dionice</returns>
         public decimal GetPrice(DateTime inTimeStamp)
         {
             if (inTimeStamp >= timeStamp) return price;
             else
             {
                 DateTime prethodniTs = inTimeStamp;
                 Decimal value = 0;
                 foreach (DateTime ts in priceHistory.Keys)
                 {
                     if (ts == inTimeStamp) priceHistory.TryGetValue(ts,out value);
                     else if (ts > inTimeStamp) priceHistory.TryGetValue(prethodniTs, out value);
                     prethodniTs = ts;
                 }
                 return value;
             }
         }

         public decimal GetInitalPrice()
         {
             return priceHistory.Values[0];
         }
    }

     public interface IRepository
     {
         void Add(Object inObject);
         void Delete(string name);
         void DeleteAll();
         bool Exist(string name);
         int GetCount();
         Object Get(string name);
     }

    /// <summary>
    /// repozitorij za dionice
    /// </summary>
     public class StockRepository : IRepository
     {
         private Dictionary<string, Object> stockRepository = new Dictionary<string, Object>();

         public void Add(Object inStock)
         {
             ((Stock)inStock).StockName = ((Stock)inStock).StockName.ToUpper();
             if (Exist(((Stock)inStock).StockName) == false)
             {
                 stockRepository.Add(((Stock)inStock).StockName, (Stock)inStock);
             }
             else
             {
                 throw new StockExchangeException("Dionica tog imena vec postoji");
             }
             
         }

         public void Delete(string inStockName)
         {
             if (Exist(inStockName) == true)
             {
                 stockRepository.Remove(inStockName.ToUpper());
             }
             else
             {
                 throw new StockExchangeException("Dionica tog imena ne postoji");
             }
         }

         public void DeleteAll()
         {
             stockRepository.Clear();
         }
         /// <summary>
         /// da li postoji odredjena dionica
         /// </summary>
         /// <param name="name"></param>
         /// <returns></returns>
         public bool Exist(string name)
         {
             return stockRepository.ContainsKey(name.ToUpper());
         }

         public int GetCount()
         {
             return stockRepository.Count; 
         }

         public Object Get(string inStockName)
         {
             if (Exist(inStockName.ToUpper())) return (Object)stockRepository[inStockName.ToUpper()];
             else throw new StockExchangeException("Dionica navedenog imena ne postoji");
         }

         public List<Object> GetAll()
         {
             return stockRepository.Values.ToList();
         }
     }

    /// <summary>
    /// apstraktna klasa koju nasljedjuju svi indeksi i nudi osnovnu funkcionalnost za rad indeksa
    /// </summary>
     public abstract class Index
     {
         protected string indexName;
         protected IndexTypes indexType;
         protected StockRepository indexStockRepository = new StockRepository();
         protected StockRepository mainRepository;


         public Index(string inIndexName, IndexTypes inIndexType, StockRepository inMainStockRepository)
         {
             this.indexName = inIndexName.ToUpper();
             this.indexType = inIndexType; //todo provjera tipa indeksa
             this.mainRepository = inMainStockRepository;
         }
         public string IndexName
         {
             get { return this.indexName; }
             set { this.indexName = value.ToUpper(); }
         }

         public int NumberOfStocks
         {
             get { 
                 return this.indexStockRepository.GetCount(); }
         }

         public IndexTypes IndexType
         {
             get { return this.indexType; }
             set { this.indexType = value; } 
         }


         public void AddStock(String inStockName)
         {
             Stock inStock = new Stock(inStockName);
             if (mainRepository.Exist(inStockName) == true && indexStockRepository.Exist(inStockName) == false)
             {
                 indexStockRepository.Add(inStock);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji ta dionica na burzi ili je vec dodana u indeks");
             }
         }

         public void RemoveStock(string inStockName)
         {
             indexStockRepository.Delete(inStockName);
         }

         public void RemoveAllStocks()
         {
             indexStockRepository.DeleteAll();
         }

         public abstract decimal GetIndexValue(DateTime inTimeStamp);              //todo IMPLEMENTIRAJ DOHVACANJE VRIJEDNOSTI INDEKSA         

         internal bool IsStockPartOfIndex(string inStockName)
         {
             return indexStockRepository.Exist(inStockName);
         }
     }
    /// <summary>
    /// factory klasa za stvaranje indeksa
    /// </summary>
     public static class IndexFactory
     {
         public static Index CreateIndex(string inIndexName, IndexTypes inIndexType, StockRepository inMainRepository)
         {
             switch (inIndexType)
             {
                 case IndexTypes.AVERAGE: return new AverageIndex(inIndexName, inIndexType, inMainRepository);
                 case IndexTypes.WEIGHTED: return new WeightedIndex(inIndexName, inIndexType, inMainRepository);
                 default: throw new StockExchangeException("Nepostojeci indexType");
             }
         }
     }

    /// <summary>
    /// implementacija average indeksa
    /// </summary>
     public class AverageIndex : Index
     {
         public AverageIndex(string inIndexName, IndexTypes inIndexType, StockRepository inMainStockRepository) : base(inIndexName, inIndexType, inMainStockRepository) { }
         public override decimal GetIndexValue(DateTime inTimeStamp)
         {
             decimal sum = 0;
             int stockNumber = 0;
             foreach (Stock s in indexStockRepository.GetAll())
             {
                 StockExchangeStock st = (StockExchangeStock)mainRepository.Get(s.StockName);
                 sum = sum + st.GetPrice(inTimeStamp);
                 stockNumber++;
             }
             if (stockNumber > 0) return Math.Round(sum/stockNumber, 3);
             else return 0; 
         }
     }

    /// <summary>
    /// implementacija weighted indeksa
    /// </summary>
     public class WeightedIndex : Index
     {
         public WeightedIndex(string inIndexName, IndexTypes inIndexType, StockRepository inMainStockRepository) : base(inIndexName, inIndexType, inMainStockRepository) { }

         public override decimal GetIndexValue(DateTime inTimeStamp)
         {
             decimal sum = 0;
             decimal weightedSum = 0;
             decimal factorSum = 0;
             foreach (Stock s in indexStockRepository.GetAll())
             {
                 StockExchangeStock st = (StockExchangeStock)mainRepository.Get(s.StockName);
                 sum = sum + st.GetPrice(inTimeStamp)*st.NumberOfShares;
             }
             foreach (Stock s in indexStockRepository.GetAll())
             {
                 StockExchangeStock st = (StockExchangeStock)mainRepository.Get(s.StockName);
                 decimal price = st.GetPrice(inTimeStamp);
                 decimal factor = (price * st.NumberOfShares) / sum;
                 factorSum = factorSum + factor;
                 weightedSum = weightedSum + factor * price;
             }
             return Math.Round(weightedSum/factorSum, 3);
         }
     }
    /// <summary>
    /// repozitorij za indekse
    /// </summary>
     public class IndicesRepository : IRepository
     {

         private Dictionary<string, Object> indicesRepository = new Dictionary<string, Object>();

         public void Add(Object inIndex)
         {
             ((Index)inIndex).IndexName = ((Index)inIndex).IndexName.ToUpper();
             if (Exist(((Index)inIndex).IndexName.ToUpper()) == false)
             {
                 indicesRepository.Add(((Index)inIndex).IndexName.ToUpper(), (Index)inIndex);
             }
             else throw new StockExchangeException("Postoji index zadanog imena");
         }

         public void Delete(string inIndexName)
         {
             indicesRepository.Remove(inIndexName.ToUpper());
         }

         public void DeleteAll()
         {
             indicesRepository.Clear();
         }

         public bool Exist(string name)
         {
             return indicesRepository.ContainsKey(name.ToUpper());
         }

         public int GetCount()
         {
             return indicesRepository.Count;
         }

         public Object Get(string indexName)
         {
             if(indicesRepository.ContainsKey(indexName.ToUpper()))
             {
                 return (Object)indicesRepository[indexName.ToUpper()];
             }
             else throw new StockExchangeException("Ne postoji index zadanog imena");
         }

         public List<Object> GetAll()
         {
             return indicesRepository.Values.ToList();
         }
     }

     public class Portfolio
     {
         string id;
         private StockRepository portStockRepository = new StockRepository();
         protected StockRepository mainRepository;

         public Portfolio(string inId, StockRepository mainRepository)
         {
             this.id = inId;
             this.mainRepository = mainRepository;
         }

         public string ID
         {
             get { return this.id;}
             set {this.id = value;}
         }

         public int NumberOfStocks
         {
             get { return portStockRepository.GetCount(); }
         }
         public void AddStock(Stock stock)
         {
             if (stock.NumberOfShares < 0) throw new StockExchangeException("Udio mora biti pozitivan");
             if (mainRepository.Exist(stock.StockName) == false) throw new StockExchangeException("Ne postoji dionica");
             if (thereIsEnoughStocks(stock))
             {
                 if (portStockRepository.Exist(stock.StockName) == false)
                 {
                     portStockRepository.Add(stock);
                 }
                 else
                 {
                     Stock s = (Stock)portStockRepository.Get(stock.StockName);
                     s.NumberOfShares += stock.NumberOfShares;
                 }
             }
             else throw new StockExchangeException("Nema dovoljno dionica");
         }

         public void RemoveStock(string inStockName)
         {
             if (mainRepository.Exist(inStockName))
             {
                 StockExchangeStock st = (StockExchangeStock)mainRepository.Get(inStockName);
                 st.NumberOfFreeShares += ((Stock)portStockRepository.Get(inStockName)).NumberOfShares;
             }
             portStockRepository.Delete(inStockName);

         }

         public bool thereIsEnoughStocks(Stock stock)
         {
             StockExchangeStock s = (StockExchangeStock)mainRepository.Get(stock.StockName);
             if (s.NumberOfFreeShares - stock.NumberOfShares >= 0)
             {
                 s.NumberOfFreeShares -= stock.NumberOfShares;
                 return true;
             }
             return false;
         }

         public void DeleteStock(string inStockName, long inNumberOfShares)
         {
             Stock st = (Stock)portStockRepository.Get(inStockName);
             
             portStockRepository.Delete(inStockName);
             if (st.NumberOfShares - inNumberOfShares > 0)
             {
                 st.NumberOfShares = st.NumberOfShares - inNumberOfShares;
                 portStockRepository.Add(st);
             }
         }

         public bool StockExist(string inStockName)
         {
             return portStockRepository.Exist(inStockName);
         }

         public int GetNumberOfShares(string inStockName)
         {
             if(portStockRepository.Exist(inStockName))
             {
             Stock st = (Stock)portStockRepository.Get(inStockName);
             return (int)st.NumberOfShares;
             }
             else return 0;
         }

         public decimal GetValue(DateTime timestamp)
         {
             decimal value = 0;
             foreach (Stock s in portStockRepository.GetAll())
             {
                 StockExchangeStock real = (StockExchangeStock)mainRepository.Get(s.StockName);
                 value += s.NumberOfShares * real.GetPrice(timestamp);
             }
             return value;
         }

         public decimal GetPercentChange(int inYear, int inMonth)
         {
             if (this.NumberOfStocks == 0) return 0;
             try
             {
             DateTime start = new DateTime(inYear, inMonth, 1, 0, 0, 0, 0);
             DateTime end = new DateTime(inYear, inMonth, DateTime.DaysInMonth(inYear, inMonth), 23, 59, 59, 999);
             return Decimal.Round((((GetValue(end) - GetValue(start)) / GetValue(start)) * 100), 3);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException(e.ToString());
             }
         }
     }
   
    /// <summary>
    /// Repozitorij za portfolio
    /// </summary>
     public class PortfolioRepository : IRepository
     {
         private Dictionary<string, Object> portfolioRepository = new Dictionary<string, Object>();

         public void Add(Object inPortfolio)
         {
             if (Exist(((Portfolio)inPortfolio).ID) == false)
             {
                 portfolioRepository.Add(((Portfolio)inPortfolio).ID, (Portfolio)inPortfolio);
             }
             else throw new StockExchangeException("Portfolio vec postoji");
         }

         public void Delete(string id)
         {
             portfolioRepository.Remove(id);
         }

         public void DeleteAll()
         {
             portfolioRepository.Clear();
         }

         public bool Exist(string name)
         {
             return portfolioRepository.ContainsKey(name);
         }

         public int GetCount()
         {
             return portfolioRepository.Count;
         }

         public Object Get(string name)
         {
             if (portfolioRepository.ContainsKey(name))
             {
                 return (Object)portfolioRepository[name];
             }
             else throw new StockExchangeException("Ne postoji portfolio zadanog imena");
         }
         public List<Object> GetAll()
         {
             return portfolioRepository.Values.ToList();
         }
     }
}
