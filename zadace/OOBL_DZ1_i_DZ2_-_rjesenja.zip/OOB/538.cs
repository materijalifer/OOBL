﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    internal class Stock
    {
        string stockName;
        public string StockName
        {
            get { return stockName; }
        }

        long numberOfShares;
        public long NumberOfShares
        {
            get { return numberOfShares; }
        }

        decimal initialPrice;
        public decimal InitialPrice
        {
            get { return initialPrice; }
        }

        DateTime timeStamp;
        public DateTime TimeStamp
        {
            get { return timeStamp; }
        }

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if ((inInitialPrice <= 0) || (inNumberOfShares <= 0))
            {
                throw new StockExchangeException("Price and Quantity have to be greater than 0!");
            }
            stockName = inStockName;
            numberOfShares = inNumberOfShares;
            initialPrice = inInitialPrice;
            timeStamp = inTimeStamp;
        }

    }

    internal class StockPriceHistory
    {
        Dictionary<string, SortedDictionary<DateTime, decimal>> stockHistory;

        public StockPriceHistory()
        {
            stockHistory = new Dictionary<string, SortedDictionary<DateTime, decimal>>();
        }

        public void stockChange(string stockName, decimal price, DateTime time)
        {
            if (!stockHistory.ContainsKey(stockName))
            {
                SortedDictionary<DateTime, decimal> newPricesHistory = new SortedDictionary<DateTime, decimal>();
                stockHistory[stockName] = newPricesHistory;
            }

            if (!stockHistory[stockName].ContainsKey(time))
            {
                stockHistory[stockName][time] = price;
            }
            else
            {
                throw new StockExchangeException("Price already set!");
            }
        }

        public decimal getInitialPrice(string stockName)
        {
            if (!stockHistory.ContainsKey(stockName))
            {
                throw new StockExchangeException("Stock " + stockName + " is not defined in history!");
            }

            KeyValuePair<DateTime, decimal> element = stockHistory[stockName].First();
            return element.Value;

        }

        public decimal getLastPrice(string stockName)
        {
            if (!stockHistory.ContainsKey(stockName))
            {
                throw new StockExchangeException("Stock " + stockName + " is not defined in history!");
            }

            KeyValuePair<DateTime, decimal> element = stockHistory[stockName].Last();
            return element.Value;

        }

        public decimal getPrice(string stockName, DateTime time)
        {
            if (!stockHistory.ContainsKey(stockName))
            {
                throw new StockExchangeException("Stock " + stockName + " is not defined in history!");
            }

            DateTime firstTime = stockHistory[stockName].First().Key;

            if (time < firstTime)
            {
                throw new StockExchangeException("Stock " + stockName + " for time " + time + " is not defined in history!");
            }

            if (time == firstTime)
            {
                return stockHistory[stockName][firstTime];
            }

            DateTime checkTime = stockHistory[stockName].Last().Key;
            DateTime previousTime = firstTime;

            foreach (DateTime dt in stockHistory[stockName].Keys)
            {
                if (dt >= time)
                {
                    checkTime = previousTime;
                    break;
                }

                previousTime = dt;
            }

            return stockHistory[stockName][checkTime];
        }
    }

    internal abstract class Index
    {
        protected Dictionary<string, Stock> stocks;
        protected string indexName;

        public void AddStockToIndex(Stock stock)
        {
            if (!stocks.ContainsKey(stock.StockName))
            {
                stocks.Add(stock.StockName, stock);
            }
            else
            {
                throw new StockExchangeException("Stock already exists in index!");
            }
        }

        public void RemoveStockFromIndex(string stockName)
        {
            if (stocks.ContainsKey(stockName))
            {
                stocks.Remove(stockName);
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in index!");
            }

        }

        public bool IsStockPartOfIndex(string stockName)
        {
            return stocks.ContainsKey(stockName);
        }

        public int NumberOfStocks
        {
            get { return stocks.Count; }
        }

        public abstract decimal GetIndexValue(StockPriceHistory stockHistory, DateTime time);
    }

    internal class AverageIndex : Index
    {
        public AverageIndex(string name)
        {
            indexName = name;
            stocks = new Dictionary<string, Stock>();
        }

        public override decimal GetIndexValue(StockPriceHistory stockHistory, DateTime time)
        {
            if (stocks.Count == 0)
            {
                throw new StockExchangeException("Index " + indexName + " is empty!");
            }

            decimal value = 0;

            foreach (string key in stocks.Keys)
            {
                value += stockHistory.getPrice(key, time);
            }

            value = value / stocks.Count;
            return decimal.Round(value, 3, MidpointRounding.AwayFromZero);
        }
    }

    internal class WeightedIndex : Index
    {
        public WeightedIndex(string name)
        {
            indexName = name;  //maknuo this
            stocks = new Dictionary<string, Stock>(); //maknuo this
        }

        public override decimal GetIndexValue(StockPriceHistory stockHistory, DateTime time)
        {
            if (stocks.Count == 0)
            {
                throw new StockExchangeException("Index " + indexName + " is empty!");
            }

            decimal total = 0;

            foreach (string key in stocks.Keys)
            {
                total += stockHistory.getPrice(key, time) * stocks[key].NumberOfShares;
            }

            decimal value = 0;

            foreach (string key in stocks.Keys)
            {
                decimal stockValue = stockHistory.getPrice(key, time);
                decimal wfactor = stockValue / total;
                value += wfactor * stockValue * stocks[key].NumberOfShares;
            }

            return decimal.Round(value, 3, MidpointRounding.AwayFromZero);
        }
    }

    internal class IndexFactory
    {
        public static Index CreateIndex(string indexName, IndexTypes indexType)
        {
            if (indexType == IndexTypes.AVERAGE)
            {
                return new AverageIndex(indexName);
            }
            else if (indexType == IndexTypes.WEIGHTED)
            {
                return new WeightedIndex(indexName);
            }
            else
            {
                throw new StockExchangeException("Unknown type of index!");
            }
        }
    }

    internal class Portfolio
    {
        private string portfolioID;
        private Dictionary<string, int> stocks;

        public int this[string key]
        {
            get
            {
                if (stocks.ContainsKey(key))
                {
                    return stocks[key];
                }
                else
                {
                    return 0;
                }
            }
        }

        public Portfolio(string portfolio)
        {
            portfolioID = portfolio.Trim();
            stocks = new Dictionary<string, int>();
        }

        public void AddStock(string stockName, int numberOfShares)
        {
            if (!stocks.ContainsKey(stockName))
            {
                stocks[stockName] = numberOfShares;
            }
            else
            {
                stocks[stockName] += numberOfShares;
            }
        }

        public void RemoveStock(string stockName, int numberOfShares)
        {
            if (stocks.ContainsKey(stockName))
            {
                if (numberOfShares >= stocks[stockName])
                {
                    stocks.Remove(stockName);
                }
                else
                {
                    stocks[stockName] -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Stock " + stockName + " is not in portfolio " + portfolioID + "!");
            }
        }

        public void RemoveStock(string stockName)
        {
            if (stocks.ContainsKey(stockName))
            {
                stocks.Remove(stockName);
            }
            else
            {
                throw new StockExchangeException("Stock " + stockName + " is not in portfolio " + portfolioID + "!");
            }
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public int NumberOfShares(string stockName)
        {
            if (stocks.ContainsKey(stockName))
            {
                return stocks[stockName];
            }
            return 0;
        }

        public bool IsStockPartOfPortfolio(string stockName)
        {
            return stocks.ContainsKey(stockName);
        }

        public decimal GetPortFolioValue(DateTime time, StockPriceHistory stockHistory)
        {
            decimal value = 0;
            foreach (string key in stocks.Keys)
            {
                value += stockHistory.getPrice(key, time) * stocks[key];
            }

            return decimal.Round(value, 3, MidpointRounding.AwayFromZero);
        }


    }

    public class StockExchange : IStockExchange
    {

        private Dictionary<string, Stock> stocks;
        private StockPriceHistory stockHistory;
        private Dictionary<string, Index> indices;
        private Dictionary<string, Portfolio> portfolios;

        public StockExchange()
        {
            stocks = new Dictionary<string, Stock>();
            stockHistory = new StockPriceHistory();
            indices = new Dictionary<string, Index>();
            portfolios = new Dictionary<string, Portfolio>();
        }

        private string uniqueName(string name)
        {
            return name.Trim().ToUpper();
        }

        private void checkStock(string inStockName)
        {
            if (!stocks.ContainsKey(uniqueName(inStockName)))
            {
                throw new StockExchangeException("Stock " + inStockName + " doesn't exist!");
            }
        }

        private void checkIndex(string inIndexName)
        {
            if (!indices.ContainsKey(uniqueName(inIndexName)))
            {
                throw new StockExchangeException("Index " + inIndexName + " doesn't exist!");
            }
        }

        private void checkPortfolio(string inPortfolioName)
        {
            if (!portfolios.ContainsKey(inPortfolioName.Trim()))
            {
                throw new StockExchangeException("Portfolio " + inPortfolioName + " doesn't exist!");
            }
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string stockName = uniqueName(inStockName);
            if (StockExists(stockName))
            {
                throw new StockExchangeException("Stock " + inStockName + " already exists!");
            }

            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException(inInitialPrice + " is not valid initial price!");
            }

            Stock newStock = new Stock(stockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stocks.Add(newStock.StockName, newStock);

            stockHistory.stockChange(newStock.StockName, newStock.InitialPrice, newStock.TimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            checkStock(inStockName);

            foreach (string key in indices.Keys)
            {
                if (indices[key].IsStockPartOfIndex(uniqueName(inStockName)))
                {
                    indices[key].RemoveStockFromIndex(uniqueName(inStockName));
                }
            }

            foreach (string key in portfolios.Keys)
            {
                if (portfolios[key].IsStockPartOfPortfolio(uniqueName(inStockName)))
                {
                    portfolios[key].RemoveStock(uniqueName(inStockName));
                }
            }

            stocks.Remove(uniqueName(inStockName));
        }

        public bool StockExists(string inStockName)
        {
            return stocks.ContainsKey(uniqueName(inStockName));
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {

            checkStock(inStockName);

            if (inStockValue <= 0)
            {
                throw new StockExchangeException(inStockValue + " is not valid price!");
            }

            stockHistory.stockChange(uniqueName(inStockName), inStockValue, inIimeStamp);

        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            checkStock(inStockName);
            return stockHistory.getPrice(uniqueName(inStockName), inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            checkStock(inStockName);
            return stockHistory.getInitialPrice(uniqueName(inStockName));
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            checkStock(inStockName);
            return stockHistory.getLastPrice(uniqueName(inStockName));
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (indices.ContainsKey(uniqueName(inIndexName)))
            {
                throw new StockExchangeException(inIndexName + " index already exists!");
            }
            else
            {
                Index index = IndexFactory.CreateIndex(uniqueName(inIndexName), inIndexType);
                indices.Add(uniqueName(inIndexName), index);
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            checkIndex(inIndexName);
            checkStock(inStockName);
            indices[uniqueName(inIndexName)].AddStockToIndex(stocks[uniqueName(inStockName)]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            checkIndex(inIndexName);
            checkStock(inStockName);
            indices[uniqueName(inIndexName)].RemoveStockFromIndex(uniqueName(inStockName));
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            checkIndex(inIndexName);
            return indices[uniqueName(inIndexName)].IsStockPartOfIndex(uniqueName(inStockName));
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            checkIndex(inIndexName);
            return indices[uniqueName(inIndexName)].GetIndexValue(stockHistory, inTimeStamp);

        }

        public bool IndexExists(string inIndexName)
        {
            return indices.ContainsKey(uniqueName(inIndexName));
        }

        public int NumberOfIndices()
        {
            return indices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            checkIndex(inIndexName);
            return indices[uniqueName(inIndexName)].NumberOfStocks;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!portfolios.ContainsKey(inPortfolioID))
            {
                portfolios[inPortfolioID] = new Portfolio(inPortfolioID);
            }
            else
            {
                throw new StockExchangeException("Portfolio " + inPortfolioID + " already exists!");
            }
        }


        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            checkPortfolio(inPortfolioID);
            checkStock(inStockName);

            if (numberOfShares < 1)
            {
                throw new StockExchangeException("Number of shares must be greater than 0!");
            }

            long usedShares = 0;
            foreach (string key in portfolios.Keys)
            {
                usedShares += portfolios[key][uniqueName(inStockName)];
            }
            long allShares = stocks[uniqueName(inStockName)].NumberOfShares;
            long remainingShares = allShares - usedShares;

            if ((remainingShares > 0) && (numberOfShares > remainingShares))
            {
                numberOfShares = (int)remainingShares;
            }

            portfolios[inPortfolioID].AddStock(uniqueName(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            checkPortfolio(inPortfolioID);

            if (!portfolios[inPortfolioID].IsStockPartOfPortfolio(uniqueName(inStockName)))
            {
                throw new StockExchangeException("Stock " + inStockName + " is not part of a portfolio " + inPortfolioID + "!");
            }

            if (portfolios[inPortfolioID][uniqueName(inStockName)] > numberOfShares)
            {
                portfolios[inPortfolioID].RemoveStock(uniqueName(inStockName), numberOfShares);
            }
            else
            {
                portfolios[inPortfolioID].RemoveStock(uniqueName(inStockName));
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            checkPortfolio(inPortfolioID);

            if (!portfolios[inPortfolioID].IsStockPartOfPortfolio(uniqueName(inStockName)))
            {
                throw new StockExchangeException("Stock " + inStockName + " is not part of a portfolio " + inPortfolioID + "!");
            }

            portfolios[inPortfolioID].RemoveStock(uniqueName(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            checkPortfolio(inPortfolioID);
            return portfolios[inPortfolioID].NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            checkPortfolio(inPortfolioID);
            return portfolios[inPortfolioID].IsStockPartOfPortfolio(uniqueName(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            checkPortfolio(inPortfolioID);
            return portfolios[inPortfolioID][uniqueName(inStockName)];

        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            checkPortfolio(inPortfolioID);
            return portfolios[inPortfolioID].GetPortFolioValue(timeStamp, stockHistory);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            checkPortfolio(inPortfolioID);
            if ((Month > 12) || (Month < 1))
            {
                throw new StockExchangeException("Month has to be value from 1 to 12!");
            }

            DateTime firstDayOfMonth, lastDayOfMonth;

            firstDayOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            lastDayOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            decimal firstValue = portfolios[inPortfolioID].GetPortFolioValue(firstDayOfMonth, stockHistory);
            decimal lastValue = portfolios[inPortfolioID].GetPortFolioValue(lastDayOfMonth, stockHistory);

            decimal returnValue = (lastValue - firstValue) / firstValue * 100;
            return decimal.Round(returnValue, 3, MidpointRounding.AwayFromZero);
        }
    }
}
