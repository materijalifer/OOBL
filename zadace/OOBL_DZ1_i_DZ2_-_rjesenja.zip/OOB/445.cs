﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Factory
	{
		public static ICalculator CreateCalculator()
		{
			// vratiti kalkulator
			return new Kalkulator();
		}
	}
	public class Kalkulator : ICalculator
	{
		/// <summary>
		/// Current display elements
		/// </summary>
		private List<char> Display { get; set; }
		/// <summary>
		/// Maximum number of digits on display
		/// </summary>
		private int DisplayLimit = 10;
		/// <summary>
		/// List of allowed digits. Only characters in this list are allowed to br pressed.
		/// </summary>
		private List<char> AllowedDigits = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '-', '*', '/', '=', ',', 'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G', 'C', 'O' };
		/// <summary>
		/// List of all numbers. Used for easier testing if pressed character is number.
		/// </summary>
		private List<char> Numbers = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
		/// <summary>
		/// List of all binary operands. Used for easier testing if pressed character is binary operand.
		/// </summary>
		private List<char> BinaryOperands = new List<char>() { '+', '-', '*', '/' };
		/// <summary>
		/// List of all Unar operands. Used for easier testing if pressed character is unar operand.
		/// </summary>
		private List<char> UnarOperands = new List<char>() { 'S', 'K', 'T', 'Q', 'R', 'I' };
		/// <summary>
		/// How many numbers are on display, helps define display
		/// </summary>
		private int NumberCounter = 0;
		/// <summary>
		/// imitates calculator memory
		/// </summary>
		private Memory Memory = new Memory();
		/// <summary>
		/// list for saving numbers entered in calculator
		/// </summary>
		private List<double> EnteredNumbers = new List<double>();
		/// <summary>
		/// Last pressed digit
		/// </summary>
		private char LastPressed = ' ';
		/// <summary>
		/// Current operand
		/// </summary>
		private char Operand = ' ';

		public Kalkulator()
		{
			//initialize display containig only 0
			Display = new List<char>();
			Display.Add('0');
		}

		#region Methods implemented from interface

		/// <summary>
		/// Gets pressed digit.
		/// </summary>
		/// <param name="inPressedDigit">Digit that is pressed on calculator</param>
		public void Press(char inPressedDigit)
		{
			AddDigit(inPressedDigit);
		}
		/// <summary>
		/// Retuns current display state.
		/// </summary>
		/// <returns>string with all characters on calculator display</returns>
		public string GetCurrentDisplayState()
		{
			return String.Concat(Display);
		}
		#endregion Methods implemented from interface


		public void AddDigit(char digit)
		{
			//only work with allowed digits
			if (!AllowedDigits.Contains(digit))
			{
				ThrowErrorToDisplay();
				return;
			}

			//Pressed digit is number
			if (Numbers.Contains(digit))
			{
				//chek if operand is pressed before this digit so that it could clean display
				if (Display.Count > 0 && LastPressed != 'D' && EnteredNumbers.Count > 0)
				{
					Display.Clear();
					NumberCounter = 0;
				}

				//if there are more then 10 numbers on display do nothing
				if (NumberCounter >= 10)
					return;
				ClearDisplayIfOnlyZeros();
				Display.Add(digit);
				NumberCounter++;
				LastPressed = 'D';
			}
			else
				//if "special" digit is pressed
				switch (digit)
				{
					case 'M':
						//if it is just zero do nothing
						if (String.Concat(Display) == "0")
							break;
						//if there is '-' in the begining then just remove it. No signum means '+'
						if (Display[0] == '-')
							Display.Remove('-');
						//In all other cases set first character to '-'
						else
							Display.Insert(0, '-');
						break;
					case 'C':
						//Clear display
						Display.Clear();
						Display.Add('0');
						NumberCounter = 0;
						break;
					case ',':
						//if decimal comma is not pressed before this digit add it to display
						if (!Display.Contains(','))
							Display.Add(',');
						break;
					case 'O':
						//clear display and restore entire calculator
						Display.Clear();
						Display.Add('0');
						EnteredNumbers = new List<double>();
						NumberCounter = 0;
						Operand = ' ';
						LastPressed = ' ';
						break;
					case '=':
						//calculate
						EnteredNumbers.Add(ConvertDisplayToNumber());
						ConvertNumberToDisplay(Calculate());
						LastPressed = '=';
						Operand = ' ';
						EnteredNumbers = new List<double>();
						break;
					case 'P':
						//save current display to memory
						this.Memory.Save(Display, NumberCounter);
						break;
					case 'G':
						//gets current display from memory
						var tupple = this.Memory.Get();
						this.Display = tupple.Item1;
						this.NumberCounter = tupple.Item2;
						Operand = ' ';
						LastPressed = Display[Display.Count - 1];
						break;
					case 'S':
						//sinus is pressed
						LastPressed = 'S';
						var resultSinus = Math.Sin(ConvertDisplayToNumber());
						ConvertNumberToDisplay(resultSinus);
						break;
					case 'K':
						//cosinus is pressed
						LastPressed = 'K';
						var resultCosinus = Math.Cos(ConvertDisplayToNumber());
						ConvertNumberToDisplay(resultCosinus);
						break;
					case 'T':
						//tangens is pressed
						LastPressed = 'T';
						var resultTan = Math.Tan(ConvertDisplayToNumber());
						ConvertNumberToDisplay(resultTan);
						break;
					case 'Q':
						//square is pressed
						LastPressed = 'Q';
						var resultSquare = Math.Pow(ConvertDisplayToNumber(), 2);
						ConvertNumberToDisplay(resultSquare);
						break;
					case 'R':
						//root is pressed
						LastPressed = 'R';
						//can not calculate root if number is less then zero
						if (ConvertDisplayToNumber() >= 0)
						{
							var resultRoot = Math.Pow(ConvertDisplayToNumber(), 0.5);
							ConvertNumberToDisplay(resultRoot);
						}
						else
							ThrowErrorToDisplay();
						break;
					case 'I':
						//Invers is pressed
						LastPressed = 'I';
						//check if user is dividing with zero
						if (ConvertDisplayToNumber() != 0)
						{
							var resultInv = 1 / ConvertDisplayToNumber();
							ConvertNumberToDisplay(resultInv);
						}
						else
							ThrowErrorToDisplay();
						break;
					case '-':
						//if last pressed digit was binary operand then do not calculate anything just remembrt the last one pressed
						if (BinaryOperands.Contains(LastPressed))
							LastPressed = Operand = '-';
						else
						{
							EnteredNumbers.Add(ConvertDisplayToNumber());
							if (EnteredNumbers.Count == 2)
							{
								if (BinaryOperands.Contains(Operand))
								{
									ConvertNumberToDisplay(Calculate());
									LastPressed = Operand = '-';
								}
								else
								{
									LastPressed = Operand = '-';
									ConvertNumberToDisplay(Calculate());
								}
							}
							else
								if (EnteredNumbers[0] % 1 == 0)
									ConvertNumberToDisplay(EnteredNumbers[0]);
							LastPressed = Operand = '-';
						}
						break;
					case '+':
						//if last pressed digit was binary operand then do not calculate anything just remembrt the last one pressed
						if (BinaryOperands.Contains(LastPressed))
							LastPressed = Operand = '+';
						else
						{
							EnteredNumbers.Add(ConvertDisplayToNumber());
							if (EnteredNumbers.Count == 2)
								if (BinaryOperands.Contains(Operand))
								{
									ConvertNumberToDisplay(Calculate());
									LastPressed = Operand = '+';
								}
								else
								{
									LastPressed = Operand = '+';
									ConvertNumberToDisplay(Calculate());
								}
							else
								if (EnteredNumbers[0] % 1 == 0)
									ConvertNumberToDisplay(EnteredNumbers[0]);
							LastPressed = Operand = '+';
						}
						break;
					case '*':
						//if last pressed digit was binary operand then do not calculate anything just remembrt the last one pressed
						if (BinaryOperands.Contains(LastPressed))
							LastPressed = Operand = '*';
						else
						{
							EnteredNumbers.Add(ConvertDisplayToNumber());
							if (EnteredNumbers.Count == 2)
								if (BinaryOperands.Contains(Operand))
								{
									ConvertNumberToDisplay(Calculate());
									LastPressed = Operand = '*';
								}
								else
								{
									LastPressed = Operand = '*';
									ConvertNumberToDisplay(Calculate());
								}
							else
								if (EnteredNumbers[0] % 1 == 0)
									ConvertNumberToDisplay(EnteredNumbers[0]);
							LastPressed = Operand = '*';
						}
						break;
					case '/':
						//if last pressed digit was binary operand then do not calculate anything just remembrt the last one pressed
						if (BinaryOperands.Contains(LastPressed))
							LastPressed = Operand = '/';
						else
						{
							EnteredNumbers.Add(ConvertDisplayToNumber());
							if (EnteredNumbers.Count == 2)
								if (BinaryOperands.Contains(Operand))
								{
									ConvertNumberToDisplay(Calculate());
									LastPressed = Operand = '/';
								}
								else
								{
									LastPressed = Operand = '/';
									ConvertNumberToDisplay(Calculate());
								}
							else
								if (EnteredNumbers[0] % 1 == 0)
									ConvertNumberToDisplay(EnteredNumbers[0]);
							LastPressed = Operand = '/';
						}
						break;
					default:
						break;
				}

		}
		/// <summary>
		/// function that calculates binary functions
		/// </summary>
		/// <returns>Result of the calculation</returns>
		public double Calculate()
		{
			double returnValue = ConvertDisplayToNumber();
			switch (Operand)
			{
				case '-':
					if (EnteredNumbers.Count == 1)
						returnValue = EnteredNumbers[0] - EnteredNumbers[0];
					else
						returnValue = EnteredNumbers[0] - EnteredNumbers[1];
					//clear entered numbers and add calculated price in it
					EnteredNumbers = new List<double>() { returnValue };
					Display.Clear();
					NumberCounter = 0;
					break;
				case '+':
					if (EnteredNumbers.Count == 1)
						returnValue = EnteredNumbers[0] + EnteredNumbers[0];
					else
						returnValue = EnteredNumbers[0] + EnteredNumbers[1];
					//clear entered numbers table and add calculated price in it
					EnteredNumbers = new List<double>() { returnValue };
					Display.Clear();
					NumberCounter = 0;
					break;
				case '*':
					if (EnteredNumbers.Count == 1)
						returnValue = EnteredNumbers[0] * EnteredNumbers[0];
					else
						returnValue = EnteredNumbers[0] * EnteredNumbers[1];
					//clear entered numbers table and add calculated price in it
					EnteredNumbers = new List<double>() { returnValue };
					Display.Clear();
					NumberCounter = 0;
					break;
				case '/':
					//check if user is dividing with zero
					if (EnteredNumbers.Count == 1)
					{
						if (EnteredNumbers[0] == 0)
						{
							ThrowErrorToDisplay();
							break;
						}
						else
							returnValue = EnteredNumbers[0] / EnteredNumbers[0];
					}
					else
					{
						if (EnteredNumbers[0] == 0)
						{
							ThrowErrorToDisplay();
							break;
						}
						else
							returnValue = EnteredNumbers[0] / EnteredNumbers[1];
					}
					//clear entered numbers table and add calculated price in it
					EnteredNumbers = new List<double>() { returnValue };
					Display.Clear();
					NumberCounter = 0;
					break;
				default:
					break;
			}

			return returnValue;
		}

		/// <summary>
		/// Clears display  and reset counter if all elements of display are '0'. Used when new digit is pressed
		/// </summary>
		public void ClearDisplayIfOnlyZeros()
		{
			if (Display.All(x => x == '0'))
			{
				Display.Clear();
				NumberCounter = 0;
			}
		}
		/// <summary>
		/// trys to convert display status to number
		/// </summary>
		/// <returns>Number that is on display</returns>
		public double ConvertDisplayToNumber()
		{
			var returnValue = String.Concat(Display);
			try
			{
				return Convert.ToDouble(returnValue);
			}
			catch
			{
				ThrowErrorToDisplay();
				throw new Exception();
			}
		}
		/// <summary>
		/// Trys to convert number to display status and sets display to it
		/// </summary>
		public void ConvertNumberToDisplay(double number)
		{
			var roundingNumber = 0;
			var listNumberParts = number.ToString().Replace("-", "").Split(',').ToList();
			//if whole part of number has more then 10 characters, remove it
			if (listNumberParts[0].Count() > DisplayLimit)
			{
				ThrowErrorToDisplay();
				return;
			}
			else
				roundingNumber = DisplayLimit - listNumberParts[0].Count();

			var displayString = Math.Round(number, roundingNumber).ToString();
			Display = displayString.ToList();
			NumberCounter = Display.Where(x => Numbers.Contains(x)).Count();
		}
		/// <summary>
		/// Clears internal memory, throws "exception" to display
		/// </summary>
		public void ThrowErrorToDisplay()
		{
			Display = "-E-".ToList();
			NumberCounter = 0;
			EnteredNumbers = new List<double>();
			Operand = ' ';
			LastPressed = ' ';
		}
	}
	/// <summary>
	/// helper class that imitates calculator memory
	/// </summary>
	public class Memory
	{
		private List<char> Display { get; set; }
		private int NumberCounter;

		/// <summary>
		/// Save to memory display status
		/// </summary>
		/// <param name="display">Current display status</param>
		/// <param name="numberCounter">Curent number of digits on display</param>
		public void Save(List<char> display, int numberCounter)
		{
			this.Display = new List<char>();
			display.ForEach(x => this.Display.Add(x));
			this.NumberCounter = new int();
			this.NumberCounter = numberCounter;
		}
		/// <summary>
		/// Restore display from memory
		/// </summary>
		/// <returns>Tuple (Display, NumberCounter) from memory</returns>
		public Tuple<List<char>, int> Get()
		{
			return new Tuple<List<char>, int>(this.Display, this.NumberCounter);
		}
	}


}
