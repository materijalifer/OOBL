﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
    #region StockPriceHistory
    /// <summary>
    /// Klasa koja pomaze opisat vremensku valjanost cijene dionice
    /// </summary>
    public class StockPriceHistory
    {
        private DateTime validFrom;
        private DateTime validTo;
        private Decimal price;

        public StockPriceHistory(DateTime validFrom, DateTime validTo, Decimal price)
        {
            this.validFrom = validFrom;
            this.validTo = validTo;
            this.price = price;
        }
        public DateTime ValidFrom
        {
            get { return this.validFrom; }
        }
        public DateTime ValidTo
        {
            get { return this.validTo; }
        }
        public Decimal Price
        {
            get { return this.price; }
            set { this.price = value; }
        }
    }
    #endregion
    #region Dionica
    /// <summary>
    /// Dionica
    /// </summary>
    public class Stock
    {
        #region Private Fields
        private string stockName;
        private long numberOfShares;
        private List<StockPriceHistory> priceHistory;
        private Decimal initialPrice;
        private Decimal lastPrice;
        private DateTime timeStamp;
        #endregion
        #region Constructor
        public Stock(string stockName, long numOfShares, Decimal price, DateTime timeStamp)
        {
            priceHistory = new List<StockPriceHistory>();
            this.stockName = stockName;
            this.numberOfShares = numOfShares;
            this.initialPrice = price;
            this.lastPrice = price;
            this.timeStamp = timeStamp;
        }
        #endregion
        #region Properties
        public long NumberOfShares
        {
            get { return this.numberOfShares; }
        }
        public Decimal InitialPrice
        {
            get { return this.initialPrice; }
        }
        public Decimal LastPrice
        {
            get { return this.lastPrice; }
            set { this.lastPrice = value; }
        }
        public string StockName
        {
            get { return this.stockName; }
            set { this.stockName = value; }
        }
        #endregion
        #region Methods

        /// <summary>
        /// pri zapisu nove cijene stara cijena se stavlja u zapisnik
        /// </summary>
        /// <param name="timeStamp">vrijeme od kad pocinje vrijediti nova cijena</param>
        /// <param name="price">nova cijena</param>
        public void SetPrice(DateTime timeStamp, Decimal price)
        {
            StockPriceHistory priceHistoryZapis = new StockPriceHistory(this.timeStamp, timeStamp, lastPrice);
            foreach (StockPriceHistory sph in priceHistory)
            {
                if (sph.ValidTo == timeStamp) throw new StockExchangeException("Vec postoji zapis za taj time stamp");
            }
            priceHistory.Add(priceHistoryZapis);
            lastPrice = price;
            this.timeStamp = timeStamp;
        }

        /// <summary>
        /// Metoda uzima sadasnju vrijednost dionice ukoliko se radi o aktualnom vremenu ili pretrazuje povijest cijena ako se radi o vremenu prije aktualnog
        /// Vrijeme koje je u polju timeStamp je aktualno, a biljezi se od kreacije dionice
        /// </summary>
        /// <param name="timeStamp">cijena za ovo vrijeme</param>
        /// <returns></returns>
        public Decimal GetPrice(DateTime timeStamp)
        {
            if (timeStamp >= this.timeStamp) return this.lastPrice;
            else
            {
                foreach (StockPriceHistory sph in priceHistory)
                {
                    if (timeStamp >= sph.ValidFrom && timeStamp <= sph.ValidTo) return sph.Price;
                }
            }
            throw new StockExchangeException("Nije pronaden takav zapis");
        }
        #endregion
    }
    #endregion
    #region ApstractIndex
    /// <summary>
    /// Apstrakna klasa za indeks koja definira apstraktnu metodu za dobivanje vrijednosti indeksa i sadrži polja i metoda koji su isti
    /// za obje vrste indeksa(apstraknom klasom pokusava se postici otvorenost nadogradnji)
    /// </summary>
    public abstract class AbstractIndex
    {
        #region Protected Fields
        protected string indexName;
        protected IndexTypes indexType;
        protected List<Stock> listaDionica;
        #endregion

        #region Properties
        public string IndexName
        {
            get { return this.indexName; }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Dodaje se dionica u listu dionica indeksa i pritom se provjerava da li je vec u indeksu
        /// </summary>
        /// <param name="stock"></param>
        public void addStock(Stock stock)
        {
            Stock trazenaDionica = null;
            trazenaDionica = listaDionica.Find(item => stock.StockName == item.StockName);
            if (trazenaDionica != null) throw new StockExchangeException("Dionica vec u indeksu!");
            else listaDionica.Add(stock);
        }
        /// <summary>
        /// Uklanjanje dionice i lista dionica indeksa sto uspijeva samo ako je prethodno dionica bila u indeksu
        /// </summary>
        /// <param name="stock"></param>
        public void removeStock(Stock stock)
        {  
            Stock trazenaDionica = null;
            trazenaDionica = listaDionica.Find(item => stock.StockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Dionica nije u indeksu!");
            else listaDionica.Remove(stock);
        }
        public bool stockInIndex(Stock stock)
        {
            if (listaDionica.Contains(stock)) return true;
            else return false;
        }
        public int numberOfStocks()
        {
            return listaDionica.Count;
        }
        #endregion

        #region Apstract Method
        /// <summary>
        /// Apstrakna metoda koju moraju implementirati klase koje ce biti derivati ove
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public abstract Decimal getIndexValue(DateTime timeStamp);
        #endregion
    }
    #endregion
    #region AverageIndex
    /// <summary>
    /// Derivirana klasa za indeks s average vrijednoscu
    /// </summary>
    public class AverageIndex : AbstractIndex
    {
        public AverageIndex(string indexName)
        {
            this.indexName = indexName;
            this.indexType = IndexTypes.AVERAGE;
            this.listaDionica = new List<Stock>();
        }
        /// <summary>
        /// nadjacana metoda za dobivanje vrijednost indeksa
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public override Decimal getIndexValue(DateTime timeStamp)
        {
            Decimal suma = 0;
            foreach (Stock dionica in listaDionica)
            {
                suma+= dionica.GetPrice(timeStamp);
            }
            return decimal.Round(suma/listaDionica.Count,3);
        }
    }
    #endregion
    #region WeightedIndex
    /// <summary>
    /// Derivirana klasa za indeks s weighted vrijednoscu
    /// </summary>
    public class WeightedIndex : AbstractIndex
    {
        public WeightedIndex(string indexName)
        {
            this.indexName = indexName;
            this.indexType = IndexTypes.WEIGHTED;
            this.listaDionica = new List<Stock>();
        }
        /// <summary>
        /// nadjacana metoda za "malo kompleksniji"  nacin dobivanja vrijednosti indeksa
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public override Decimal getIndexValue(DateTime timeStamp)
        {
            Decimal vrijednostIndeksa = 0;
            foreach (Stock dionica in listaDionica)
            {
                vrijednostIndeksa += dionica.GetPrice(timeStamp) * dionica.NumberOfShares;
            }
            Decimal suma = 0;
            foreach (Stock dionica in listaDionica)
            {
                suma+=dionica.GetPrice(timeStamp)*((dionica.GetPrice(timeStamp)*dionica.NumberOfShares)/vrijednostIndeksa);
            }
            return decimal.Round(suma,3);
        }
    }
    #endregion
    #region Portfolio
    /// <summary>
    /// Klasa koja opisuje dio domene imena portfolio
    /// </summary>
    public class Portfolio
    {
        #region Private Fields
        private string id;
        private Dictionary<Stock,long> listaDionica;
        #endregion

        #region Constructor
        public Portfolio(string id)
        {
            this.id = id;
            listaDionica = new Dictionary<Stock,long>();
        }
        #endregion

        #region Properties
        public string Id
        {
            get { return this.id; }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Vrijednost portfolia po formuli suma(cijene dionice u vremenu * broj dionice)
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public decimal getValue(DateTime timeStamp)
        {
            decimal vrijednost = 0;
            foreach (Stock s in listaDionica.Keys)
            {
                vrijednost += s.GetPrice(timeStamp) * listaDionica[s];
            }
            return decimal.Round(vrijednost, 3);
        }
        /// <summary>
        /// Izracun mjesecne promjene. Da bi metoda prosla treba u povijesti dionica biti zapisana vrijednost dionice za trazeni vremenski period
        /// </summary>
        /// <param name="Year"></param>
        /// <param name="Month"></param>
        /// <returns></returns>
        public decimal getMonthPercentage(int Year, int Month)
        {
            DateTime pocetakMjeseca = new DateTime(Year, Month, 1, 00, 00, 00);
            DateTime zavrsetakMjeseca = new DateTime(Year, Month + 1, 1, 23, 59, 59).AddDays(-1);
            Decimal vrijednostPocetak = getValue(pocetakMjeseca);
            Decimal vrijednostKraj = getValue(zavrsetakMjeseca);
            return decimal.Round(((vrijednostKraj - vrijednostPocetak) / vrijednostPocetak) * 100, 3);
        }
        /// <summary>
        /// Dodavanje nove dionice ili dodavanje jos iste
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void addStock(Stock stock, long numberOfShares)
        {
            long numOfShares;
            if (listaDionica.TryGetValue(stock, out numOfShares))
            {
                listaDionica[stock]+=numberOfShares;
            } 
            else 
            {
                listaDionica[stock]=numberOfShares;
            }
        }
        /// <summary>
        /// Uklanjanje dionice u dijelovima ako ona postoji
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        public void removeStock(Stock stock, long numberOfShares)
        {
            if (listaDionica.ContainsKey(stock)) listaDionica[stock]-=numberOfShares;
            else throw new StockExchangeException("Ne postoji ta dionica u portfoliu");
            if (listaDionica[stock]<=0) listaDionica.Remove(stock);
        }
        /// <summary>
        /// Uklanjanje dionice kompletno
        /// </summary>
        /// <param name="stock"></param>
        public void removeStock(Stock stock)
        {
            if (listaDionica.ContainsKey(stock)) listaDionica.Remove(stock);
            else throw new StockExchangeException("Ne postoji ta dionica u portfoliu");
        }
        /// <summary>
        /// Broj udjela trazene dionice
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public long numberOfShares(Stock stock)
        {
            if (!listaDionica.ContainsKey(stock)) return 0;
            else return listaDionica[stock];
        }
        /// <summary>
        /// Broj razlicith dionica u portfoliu
        /// </summary>
        /// <returns></returns>
        public int numberOfStocks()
        {
            return listaDionica.Keys.Count;
        }
        /// <summary>
        /// Provjera da li je dionica dio portfolia
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool stockPartOf(Stock stock)
        {
            if (listaDionica.ContainsKey(stock)) return true;
            else return false;
        }
        #endregion
    }
    #endregion
    public class StockExchange : IStockExchange
    {
        List<Stock> dioniceNaBurzi = new List<Stock>();
        List<AbstractIndex> indeksiNaBurzi = new List<AbstractIndex>();
        List<Portfolio> portfeljiNaBurzi = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock novaDionica = new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
            if (StockExists(inStockName) || inInitialPrice <= 0 || inNumberOfShares<=0) throw new StockExchangeException("Losa ti je dionica!");
            else dioniceNaBurzi.Add(novaDionica);
        }

        public void DelistStock(string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            foreach (AbstractIndex ai in indeksiNaBurzi)
                ai.removeStock(trazenaDionica);
            foreach (Portfolio p in portfeljiNaBurzi)
                p.removeStock(trazenaDionica);
            dioniceNaBurzi.RemoveAll(item => inStockName == item.StockName);
        }

        public bool StockExists(string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica != null) return true;
            else return false;
        }

        public int NumberOfStocks()
        {
            return dioniceNaBurzi.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            else trazenaDionica.SetPrice(inTimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            else return trazenaDionica.GetPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            else return trazenaDionica.InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            else return trazenaDionica.LastPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            switch(inIndexType){
                case IndexTypes.AVERAGE: 
                    AverageIndex avIndex = new AverageIndex(inIndexName.ToUpper());
                    if (!IndexExists(inIndexName)) indeksiNaBurzi.Add(avIndex);
                    break;
                case IndexTypes.WEIGHTED:
                    WeightedIndex weIndex = new WeightedIndex(inIndexName.ToUpper());
                    if (!IndexExists(inIndexName)) indeksiNaBurzi.Add(weIndex);
                    break;
                default: throw new StockExchangeException("Ne podrzan tip indexa");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) throw new StockExchangeException("Ne postoji taj indeks!");
            trazeniIndeks.addStock(trazenaDionica);           
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) throw new StockExchangeException("Ne postoji taj indeks!");
            trazeniIndeks.removeStock(trazenaDionica);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) throw new StockExchangeException("Ne postoji taj indeks!");
            return trazeniIndeks.stockInIndex(trazenaDionica);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) throw new StockExchangeException("Ne postoji taj indeks!");
            else return trazeniIndeks.getIndexValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) return false;
            else return true;
        }

        public int NumberOfIndices()
        {
            return this.indeksiNaBurzi.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            AbstractIndex trazeniIndeks = null;
            trazeniIndeks = indeksiNaBurzi.Find(item => inIndexName == item.IndexName);
            if (trazeniIndeks == null) throw new StockExchangeException("Ne postoji taj indeks!");
            else return trazeniIndeks.numberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio port = new Portfolio(inPortfolioID);
            if (!PortfolioExists(inPortfolioID)) portfeljiNaBurzi.Add(port);
            else throw new StockExchangeException("Vec postoji taj portfolio");
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            long sumaUPort = 0;
            foreach (Portfolio p in portfeljiNaBurzi)
            {
                sumaUPort += p.numberOfShares(trazenaDionica);
            }
            long slobodnihDionica = trazenaDionica.NumberOfShares - sumaUPort;
            if (slobodnihDionica < numberOfShares) throw new StockExchangeException("Nedovoljno dionica");
            else trazeniPortfolio.addStock(trazenaDionica, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            trazeniPortfolio.removeStock(trazenaDionica, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            trazeniPortfolio.removeStock(trazenaDionica);
        }

        public int NumberOfPortfolios()
        {
            return portfeljiNaBurzi.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            else return trazeniPortfolio.numberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) return false;
            else return true;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            return trazeniPortfolio.stockPartOf(trazenaDionica);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Stock trazenaDionica = null;
            trazenaDionica = dioniceNaBurzi.Find(item => inStockName == item.StockName);
            if (trazenaDionica == null) throw new StockExchangeException("Ne postoji ta dionica!");
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            if (trazeniPortfolio.stockPartOf(trazenaDionica)) return (int)trazeniPortfolio.numberOfShares(trazenaDionica);
            else throw new StockExchangeException("Dionica nije u portfoliu");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            else return trazeniPortfolio.getValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio trazeniPortfolio = null;
            trazeniPortfolio = portfeljiNaBurzi.Find(item => inPortfolioID == item.Id);
            if (trazeniPortfolio == null) throw new StockExchangeException("Ne postoji taj portofolio!");
            else return trazeniPortfolio.getMonthPercentage(Year,Month);
        }
    }
}
