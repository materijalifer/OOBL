﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Stocks stocks = new Stocks();
         private Indices indices = new Indices();
         private Portfolios portfolios = new Portfolios();
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             stocks.AddStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
         }

         public void DelistStock(string inStockName)
         {
             stocks.RemoveStock(inStockName);
             //ukloni i iz indeksa i iz portfelja
         }

         public bool StockExists(string inStockName)
         {
             return stocks.StockInExchange(inStockName);
         }

         public int NumberOfStocks()
         {
             return stocks.NumberOfStocksInExchange();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             stocks.SetStockPrice(inStockName, inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return stocks.GetStockPrice(inStockName, inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return stocks.GetInitialPrice(inStockName);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return stocks.GetLastStockPrice(inStockName);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             indices.AddIndex(inIndexName, inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             indices.AddStockToIndex(inIndexName, stocks.GetStock(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             indices.RemoveStockFromIndex(inIndexName, stocks.GetStock(inStockName));
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return indices.IsStockPartOfTheIndex(inIndexName, inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return indices.GetIndexValue(inIndexName, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return indices.GetNumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return indices.GetNumberOfStocksInIndex(inIndexName);
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             portfolios.AddPortfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock stock = stocks.GetStock(inStockName);
             stock.UseShares(numberOfShares);
             portfolios.AddStockToPortfolio(inPortfolioID, stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock stock = stocks.GetStock(inStockName);
             portfolios.RemoveStockFromPortfolio(inPortfolioID, stock, numberOfShares);
             stock.ReclaimShares(numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Stock stock = stocks.GetStock(inStockName);
             int numOfStocks = portfolios.RemoveStockFromPortfolio(inPortfolioID, stock);
             stock.ReclaimShares(numOfStocks);
         }

         public int NumberOfPortfolios()
         {
             return portfolios.NumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return portfolios.NumberOfStocksInPortfolio(inPortfolioID);
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return portfolios.IsStockPartOfPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Stock s = stocks.GetStock(inStockName);
             return portfolios.NumberOfSharesOfStockInPortfolio(inPortfolioID, s);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return portfolios.GetPortfolioValue(inPortfolioID, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return portfolios.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
         }
     }

    //Sučelje potrebno za implementaciju obrasca promatrač. Kada se dionica miče s burze, ona obavještava sve pretplaćene
    //da ju uklone iz lista
    public interface IStockHolder
    {
        void Remove(Stock stock);
    }

     public class Stock
     {
         private string stockName;
         private long numberOfShares;
         private long usedShares;

         private List<IStockHolder> subscribers = new List<IStockHolder>();

         public string StockName
         {
             get { return stockName; }
         }

         public long NumberOfShares
         {
             get { return numberOfShares; }
         }

         private SortedList<DateTime, decimal> priceHistory;

         public Stock(string stockName, long numberOfShares, decimal price, DateTime timeStamp)
         {
             if (numberOfShares < 1) throw new StockExchangeException("Broj dionica mora biti veći od nule");
             if (price < 1) throw new StockExchangeException("Cijena mora biti veca od nule");
             this.stockName = stockName.ToUpper();
             this.numberOfShares = numberOfShares;
             priceHistory = new SortedList<DateTime, decimal>();
             priceHistory.Add(timeStamp, price);
         }

         public void AddPriceForTime(decimal price, DateTime timeStamp)
         {
             if (price < 1) throw new StockExchangeException("Cijena mora biti veca od nule");
             priceHistory.Add(timeStamp, price);
         }

         public decimal GetPriceForTime(DateTime timeStamp)
         {
             if (priceHistory.Count == 0 || timeStamp < priceHistory.Keys[0]) throw new StockExchangeException("Dionica nema cjenu za to vrijeme!");
             decimal bestFitPrice = priceHistory.Values[0];
             foreach (var entry in priceHistory)
             {
                 if (entry.Key <= timeStamp) bestFitPrice = entry.Value;
                 else break;
             }
             return bestFitPrice;
         }

         public decimal GetInitialPrice()
         {
             if (priceHistory.Count == 0) throw new StockExchangeException("Dionica nema nikakvu cijenu");
             return priceHistory.Values[0];
         }

         public decimal GetLastPrice()
         {
             if (priceHistory.Count == 0) throw new StockExchangeException("Dionica nema nikakvu cijenu");
             return priceHistory.Values[priceHistory.Values.Count - 1];
         }

         public void UseShares(long numOfShares)
         {
             if (this.usedShares + numOfShares > this.NumberOfShares) throw new StockExchangeException("Pokušali ste iskoristiti previše dionica!");
             this.usedShares += numOfShares;
         }

         public void ReclaimShares(long numOfShares)
         {
             if (this.usedShares - numOfShares < 0) throw new StockExchangeException("Pokušali ste vratiti previše dionica!");
             this.usedShares -= numOfShares;
         }

         public void Subscribe(IStockHolder holder)
         {
             if (subscribers.Contains(holder)) return;
             subscribers.Add(holder);
         }

         public void Unsubscribe(IStockHolder holder)
         {
             subscribers.Remove(holder);
         }

         public void RemoveFromExchange()
         {
             foreach (var stockHolder in subscribers)
             {
                 stockHolder.Remove(this);
             }
         }
     }

    //repozitorij dionica
     public class Stocks
     {
         private Dictionary<String, Stock> stocksInExchange = new Dictionary<string, Stock>();

         public void AddStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             string validStockName = inStockName.ToUpper();
             if (stocksInExchange.ContainsKey(validStockName)) throw new StockExchangeException("Duplikat dionice!");
             Stock s = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocksInExchange.Add(validStockName, s);
         }

         public void RemoveStock(string stockName)
         {
             string validStockName = stockName.ToUpper();
             if (!stocksInExchange.ContainsKey(validStockName)) throw new StockExchangeException("Ne postoji ta dionica!");
             Stock s = stocksInExchange[validStockName];
             s.RemoveFromExchange();
             stocksInExchange.Remove(validStockName);
         }

         public int NumberOfStocksInExchange()
         {
             return stocksInExchange.Count();
         }

         public bool StockInExchange(string stockName)
         {
             string validStockName = stockName.ToUpper();
             return stocksInExchange.ContainsKey(validStockName);
         }

         public void SetStockPrice(string stockName, decimal price, DateTime timeStamp)
         {
             Stock s = GetStock(stockName);
             s.AddPriceForTime(price, timeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock s = GetStock(inStockName);
             return s.GetPriceForTime(inTimeStamp);
         }

         public decimal GetInitialPrice(string stockName)
         {
             Stock s = GetStock(stockName);
             return s.GetInitialPrice();
         }

         public decimal GetLastStockPrice(string stockName)
         {
             Stock s = GetStock(stockName);
             return s.GetLastPrice();
         }

         public Stock GetStock(string stockName)
         {
             string validStockName = stockName.ToUpper();
             if (!stocksInExchange.ContainsKey(validStockName)) throw new StockExchangeException("Ne postoji ta dionica!");
             return stocksInExchange[validStockName];
         }
     }

     //repozitorij portfoljia
     public class Portfolios
     {
         private Dictionary<string, Portfolio> portfoliosInExchange = new Dictionary<string, Portfolio>();
         public void AddPortfolio(string id)
         {
             if(portfoliosInExchange.ContainsKey(id)) throw new StockExchangeException("Portfolio s tim id-jem već postoji");
             Portfolio p = new Portfolio(id);
             portfoliosInExchange.Add(id, p);
         }

         public void AddStockToPortfolio(string portfolioId, Stock stock, int numOfShares)
         {
             if (numOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od nula");
             Portfolio p = GetPortfolio(portfolioId);
             p.AddStock(stock, numOfShares);

         }

         public void RemoveStockFromPortfolio(string portfolioId, Stock stock, int numOfShares)
         {
             if (numOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od nula");
             Portfolio p = GetPortfolio(portfolioId);
             p.RemoveStock(stock, numOfShares);
         }

         public int RemoveStockFromPortfolio(string portfolioId, Stock stock)
         {
             Portfolio p = GetPortfolio(portfolioId);
             int heldShares = p.RemoveStock(stock);
             return heldShares;
         }

         public int NumberOfPortfolios()
         {
             return portfoliosInExchange.Count;
         }

         public bool PortfolioExists(string portfolioId)
         {
             return portfoliosInExchange.ContainsKey(portfolioId);
         }

         public int NumberOfStocksInPortfolio(string portfolioId)
         {
             Portfolio p = GetPortfolio(portfolioId);
             return p.NumberOfStocks();
         }

         public bool IsStockPartOfPortfolio(string portfolioId, string stock)
         {
             Portfolio p = GetPortfolio(portfolioId);
             string validStockName = stock.ToUpper();
             return p.ContainsStock(validStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string portfolioId, Stock stock)
         {
             Portfolio p = GetPortfolio(portfolioId);
             return p.NumberOfShares(stock);
         }

         public decimal GetPortfolioValue(string portfolioId, DateTime timeStamp)
         {
             Portfolio p = GetPortfolio(portfolioId);
             return p.GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string portfolioId, int year, int month)
         {
             if (year <=0 || month < 1 || month > 12) throw new StockExchangeException("Krivi datum!");
             Portfolio p = GetPortfolio(portfolioId);
             DateTime start = new DateTime(year, month, 1, 0, 0, 0, 0);
             DateTime end = start.AddMonths(1).AddMilliseconds(-1);
             decimal startValue = p.GetValue(start);
             if (startValue == 0) return 0;
             decimal endingValue = p.GetValue(end);
             decimal perc = ((endingValue - startValue)/startValue)*100;
             return Decimal.Round(perc, 3);
         }

         private Portfolio GetPortfolio(string portfolioId)
         {
             if (!portfoliosInExchange.ContainsKey(portfolioId)) throw new StockExchangeException("Portfolio ne postoji");
             return portfoliosInExchange[portfolioId];
         }

         private class Portfolio : IStockHolder
         {
             private string id;
             private  Dictionary<string, StockWrapper> stocksInPortfolio = new Dictionary<string, StockWrapper>(); 

             public Portfolio(string id)
             {
                 this.id = id;
             }

             public void AddStock(Stock stock, int numOfShares)
             {
                 if (numOfShares <=0) throw new StockExchangeException("Broj dionica mora biti veći od nula");
                 if (stocksInPortfolio.ContainsKey(stock.StockName))
                 {
                     StockWrapper sw = stocksInPortfolio[stock.StockName];
                     sw.NumOfSharesOwning += numOfShares;
                 }
                 else
                 {
                     StockWrapper sw = new StockWrapper(stock, numOfShares);
                     stocksInPortfolio.Add(stock.StockName, sw);
                 }
                 stock.Subscribe(this);
             }

             public void RemoveStock(Stock stock, int numOfShares)
             {
                 if (numOfShares <= 0) throw new StockExchangeException("Broj dionica mora biti veći od nula");
                 if (!stocksInPortfolio.ContainsKey(stock.StockName)) throw new StockExchangeException("Dionica ne postoji u portfoliu");
                 StockWrapper sw = stocksInPortfolio[stock.StockName];
                 if (sw.NumOfSharesOwning < numOfShares) throw new StockExchangeException("Pokušavate ukloniti preveć dionica!");
                 else if (sw.NumOfSharesOwning == numOfShares)
                 {
                     stocksInPortfolio.Remove(stock.StockName);
                     stock.Unsubscribe(this);
                 }
                 else sw.NumOfSharesOwning -= numOfShares;
             }

             public int RemoveStock(Stock stock)
             {
                 if (!stocksInPortfolio.ContainsKey(stock.StockName)) throw new StockExchangeException("Dionica ne postoji u portfoliu");
                 int returnable = stocksInPortfolio[stock.StockName].NumOfSharesOwning;
                 stocksInPortfolio.Remove(stock.StockName);
                 stock.Unsubscribe(this);
                 return returnable;
             }

             public int NumberOfStocks()
             {
                 return stocksInPortfolio.Count;
             }

             public bool ContainsStock(string stock)
             {
                 return stocksInPortfolio.ContainsKey(stock);
             }

             public int NumberOfShares(Stock stock)
             {
                 if (stocksInPortfolio.ContainsKey(stock.StockName))
                     return stocksInPortfolio[stock.StockName].NumOfSharesOwning;
                 else return 0;
             }

             public decimal GetValue(DateTime timeStamp)
             {
                 decimal sum = 0;
                 foreach (var stockWrapper in stocksInPortfolio)
                 {
                     sum += stockWrapper.Value.Stock.GetPriceForTime(timeStamp) * stockWrapper.Value.NumOfSharesOwning;
                 }
                 return sum;
             }

             private class StockWrapper
             {
                 private Stock stock;
                 private int numOfSharesOwning;

                 public StockWrapper(Stock stock, int numOfSharesOwning)
                 {
                     this.stock = stock;
                     this.NumOfSharesOwning = numOfSharesOwning;
                 }

                 public Stock Stock
                 {
                     get { return stock; }
                 }

                 public int NumOfSharesOwning
                 {
                     get { return numOfSharesOwning; }
                     set { numOfSharesOwning = value; }
                 }
             }

             public string Id
             {
                 get { return id; }
             }

             public void Remove(Stock stock)
             {
                 stocksInPortfolio.Remove(stock.StockName);
             }
         }
     }

     //repozitorij indeksa
     public class Indices 
     {
         private Dictionary<string, Index> indicesInExchange = new Dictionary<string, Index>();
         public void AddIndex(string inIndexName, IndexTypes inIndexType)
         {
             string validIndexName = inIndexName.ToUpper();
             int enumIntValue = (int) inIndexType;
             if (enumIntValue != 1 && enumIntValue !=2) throw new StockExchangeException("Krivi tip indexa");
             if (indicesInExchange.ContainsKey(validIndexName)) throw new StockExchangeException("Indeks već postoji");
             Index i = new Index(inIndexName, inIndexType);
             indicesInExchange.Add(validIndexName, i);
         }

         public void AddStockToIndex(string indexName, Stock stock)
         {
             GetIndex(indexName).AddStock(stock);
         }

         public void RemoveStockFromIndex(string indexName, Stock stock)
         {
             GetIndex(indexName).RemoveStock(stock);
         }

         public bool IsStockPartOfTheIndex(string indexName, string stock)
         {
             string validStockName = stock.ToUpper();
             return GetIndex(indexName).HasStock(validStockName);
         }

         public decimal GetIndexValue(string indexName, DateTime timeStamp)
         {
             return GetIndex(indexName).GetValue(timeStamp);
         }

         public bool IndexExists(string indexName)
         {
             string validIndexName = indexName.ToUpper();
             return indicesInExchange.ContainsKey(validIndexName);
         }

         private Index GetIndex(string indexName)
         {
             string validIndexName = indexName.ToUpper();
             if (!indicesInExchange.ContainsKey(validIndexName)) throw new StockExchangeException("Indeks ne postoji");
             return indicesInExchange[validIndexName];
         }

         public int GetNumberOfIndices()
         {
             return indicesInExchange.Count;
         }

         public int GetNumberOfStocksInIndex(string indexName)
         {
             return GetIndex(indexName).GetNumberOfStocks();
         }

         private class Index : IStockHolder
         {
             private string indexName;
             private IndexTypes indexType;
             private Dictionary<string, Stock> stocksInIndex = new Dictionary<string, Stock>();

             public string IndexName
             {
                 get { return indexName; }
             }

             public Index(string indexName, IndexTypes indexType)
             {
                 this.indexName = indexName.ToUpper();
                 this.indexType = indexType;
             }

             public void AddStock(Stock stock)
             {
                 if (stocksInIndex.ContainsKey(stock.StockName)) throw new StockExchangeException("Dionica vec postoji u indexu");
                 stocksInIndex.Add(stock.StockName, stock);
                 stock.Subscribe(this);
             }

             public void RemoveStock(Stock stock)
             {
                 if (!stocksInIndex.ContainsKey(stock.StockName)) throw new StockExchangeException("Dionica ne postoji u indexu");
                 stocksInIndex.Remove((stock.StockName));
                 stock.Unsubscribe(this);
             }

             public bool HasStock(string stock)
             {
                 return stocksInIndex.ContainsKey(stock);
             }

             public int GetNumberOfStocks()
             {
                 return stocksInIndex.Count;
             }

             public decimal GetValue(DateTime timeStamp)
             {
                 if (GetNumberOfStocks() == 0) return 0;
                 if (indexType == IndexTypes.AVERAGE)
                 {
                     decimal sum = 0;
                     foreach (var stock in stocksInIndex.Values)
                     {
                         sum += (stock.GetPriceForTime(timeStamp));
                     }
                     return Decimal.Round(sum/GetNumberOfStocks(), 3);
                 }
                 else if (indexType == IndexTypes.WEIGHTED)
                 {
                     decimal sum = 0;
                     foreach (var stock in stocksInIndex.Values)
                     {
                         sum += (stock.GetPriceForTime(timeStamp) * stock.NumberOfShares);
                     }
                     decimal weighted = 0;
                     foreach (var stock in stocksInIndex.Values)
                     {
                         decimal stockValue = stock.GetPriceForTime(timeStamp);
                         weighted += stock.NumberOfShares*stockValue*stockValue/sum;
                         
                     }
                     return Decimal.Round(weighted, 3);
                 }
                 else throw new StockExchangeException("Neš se čudno dogodilo");
             }


             public void Remove(Stock stock)
             {
                 stocksInIndex.Remove(stock.StockName);
             }
         }
     }



}
