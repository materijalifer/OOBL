﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> listStock;
         private Dictionary<string, Index> listIndex;
         private Dictionary<string, Portfolio> listPortfolio;

         public StockExchange() {
             listStock = new Dictionary<string, Stock>();
             listIndex = new Dictionary<string, Index>();
             listPortfolio = new Dictionary<string, Portfolio>();
         }

         private void CheckStockPrice(decimal inInitialPrice) {
             if (inInitialPrice <= 0){
                 throw new StockExchangeException("Initial price cannot be less than 0.");
             }
         }

         private void CheckStockNumber(long inNumberOfShares) {
             if (inNumberOfShares < 1){
                 throw new StockExchangeException("Number of stocks cannot be less than 1.");
             }
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             String lower = inStockName.ToLower();
             Stock newStock = new Stock(lower, inNumberOfShares, inInitialPrice, inTimeStamp);

             CheckStockNumber(inNumberOfShares);
             CheckStockPrice(inInitialPrice);

             if (!listStock.ContainsKey(lower)){
                 listStock.Add(lower, newStock);
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " already exists.");
             }
         }

         public void DelistStock(string inStockName)
         {
             String lower = inStockName.ToLower();

             if (listStock.ContainsKey(lower)){
                 listStock.Remove(lower);

                 foreach (KeyValuePair<string, Index> kvp in listIndex){
                     kvp.Value.removeStock(lower);
                 }

                 foreach (KeyValuePair<string, Portfolio> kvp in listPortfolio){
                     kvp.Value.removeStock(lower);
                 }
             }else{
                 throw new StockExchangeException("The Stock named " + lower + " does not exist."); 
             }
         }

         public bool StockExists(string inStockName)
         {
             if (listStock.ContainsKey(inStockName.ToLower())){
                 return true;
             } else {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return listStock.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             String lower = inStockName.ToLower();

             if (listStock.ContainsKey(lower)){
                 Stock pStock = listStock[lower];

                 CheckStockPrice(inStockValue);
                 pStock.setPriceTime(inStockValue, inIimeStamp);
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist."); 
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             String lower = inStockName.ToLower();

             if (listStock.ContainsKey(lower)) {
                 Stock pStock = listStock[lower];
                 return pStock.getStockPrice(inTimeStamp);
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist.");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             String lower = inStockName.ToLower();

             if (listStock.ContainsKey(lower)){
                 Stock pStock = listStock[lower];
                 return pStock.getInitialStockPrice();
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist.");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             String lower = inStockName.ToLower();

             if (listStock.ContainsKey(lower)){
                 Stock pStock = listStock[lower];
                 return pStock.getLastStockPrice();
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist.");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             String lower = inIndexName.ToLower();
             Index newIndex = new Index(lower, inIndexType);

             if (!listIndex.ContainsKey(lower)){
                 listIndex.Add(lower, newIndex);
             }else{
                 throw new StockExchangeException("The Index named " + inIndexName + " already exists.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             String lowerStockName = inStockName.ToLower();
             String lowerIndexName = inIndexName.ToLower();

             if (listStock.ContainsKey(lowerStockName)){
                 if (listIndex.ContainsKey(lowerIndexName)){
                     Index pIndex = listIndex[lowerIndexName];
                     Stock pStock = listStock[lowerStockName];
                     pIndex.addStock(lowerStockName, pStock);
                 }else{
                     throw new StockExchangeException("The index named " + inIndexName + " does not exist.");
                 }

             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist.");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             String lowerStockName = inStockName.ToLower();
             String lowerIndexName = inIndexName.ToLower();

             if (listStock.ContainsKey(lowerStockName)){
                 if (listIndex.ContainsKey(lowerIndexName)){
                     Index pIndex = listIndex[lowerIndexName];
                     Stock pStock = listStock[lowerStockName];
                     pIndex.removeStock(lowerStockName);
                 }else{
                     throw new StockExchangeException("The index named " + inIndexName + " does not exist.");
                 }
             }else{
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exist.");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             String lowerStock = inStockName.ToLower();
             String lowerIndexName = inIndexName.ToLower();

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }

             if (listIndex.ContainsKey(lowerIndexName)){
                 Index index = listIndex[lowerIndexName];
                 return index.IsStockContained(lowerStock);
             }else{
                 throw new StockExchangeException("The index named " + lowerIndexName + " does not exists.");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             String lowerIndexName = inIndexName.ToLower();

             if (listIndex.ContainsKey(lowerIndexName)){
                 Index index = listIndex[lowerIndexName];
                 
                 switch (index.getTip()) {
                     case IndexTypes.AVERAGE:
                         return CalculateAverage(index, inTimeStamp);
                     case IndexTypes.WEIGHTED:
                         return CalculateWeighted(index, inTimeStamp);
                 }                 
             }else{
                 throw new StockExchangeException("The index named " + lowerIndexName + " does not exists.");
             }
             return 0m;
         }

         private decimal CalculateAverage(Index index, DateTime inTimeStamp){
            
             decimal sum = 0m;
             decimal no = 0m;
          

             foreach (KeyValuePair<string, Stock> kvp in index.getStocks()){
                 Stock stock = listStock[kvp.Value.getStockName()];
                 decimal price = stock.getStockPrice(inTimeStamp);
                 sum += price;
                 no += 1;
             }

             if (no != 0) {
                 return Math.Round(sum / no, 3);
             } else {
                 return 0m;
             }
         }

         private decimal CalculateWeighted(Index index, DateTime inTimeStamp)
         {
             decimal totalWeight = 0m;
             decimal sum = 0m;

             foreach (KeyValuePair<string, Stock> kvp in index.getStocks())
             {
                 Stock stock = listStock[kvp.Value.getStockName()];
                 decimal price = stock.getStockPrice(inTimeStamp);
                 totalWeight += price * kvp.Value.getNumOfStocks();
             }

             foreach (KeyValuePair<string, Stock> kvp in index.getStocks()){
                 Stock stock = listStock[kvp.Value.getStockName()];
                 decimal price = stock.getStockPrice(inTimeStamp);
                 decimal value = price/totalWeight;
                 sum += value * kvp.Value.getNumOfStocks() * price;
             }

             if (index.getStocks().Count != 0) {
                 return Math.Round(sum, 3);
             } else {
                 return 0m;
             }
         }

         public bool IndexExists(string inIndexName)
         {
             if (listIndex.ContainsKey(inIndexName.ToLower())){
                 return true;
             }else{
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return listIndex.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             String lowerIndexName = inIndexName.ToLower();

             if (listIndex.ContainsKey(lowerIndexName)){
                 Index pIndex = listIndex[lowerIndexName];
                 return pIndex.getNumOfStocks();
             }else{
                 throw new StockExchangeException("The index named " + inIndexName + " does not exist.");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {

             if (!listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio newPortfolio = new Portfolio(inPortfolioID);
                 listPortfolio.Add(inPortfolioID, newPortfolio);
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " already exists.");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             String lowerStock = inStockName.ToLower();

             CheckStockNumber(numberOfShares);

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }


             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Stock stock = listStock[lowerStock];
                 Stock newStock = new Stock(lowerStock, numberOfShares, stock.getStockPrice(stock.getAppliesFrom()), stock.getAppliesFrom());

                 if (IsTotalNumberOfStocksOk(lowerStock, numberOfShares))
                 {
                     Portfolio pPortfolio = listPortfolio[inPortfolioID];
                     pPortfolio.addStock(newStock);
                 }else {
                     throw new StockExchangeException("Number of stocks " + lowerStock +  " being added to portfolio" +
                         inPortfolioID + " exceeds total number of those stocks");
                 }
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }   
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             String lowerStock = inStockName.ToLower();

             CheckStockNumber(numberOfShares);

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }


             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 List<Stock> stockList = pPortfolio.getStockList();

                 foreach (Stock stock in stockList) {
                     if (stock.getStockName().Equals(lowerStock)){
                         int newNo = (int)stock.getNumOfStocks() - numberOfShares;

                         if (newNo > 0) {
                            stock.setNumOfStocks(newNo);
                         } else if (newNo == 0) {
                             RemoveStockFromPortfolio(inPortfolioID, inStockName);
                         } else {
                             throw new StockExchangeException("The number of shares you are trying to remove exceeds their actual number in portfolio.");
                         }
                         break;
                     }    
                 }
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             String lowerStock = inStockName.ToLower();

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }


             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 pPortfolio.removeStock(lowerStock);

                 if (pPortfolio.getStockList().Count() == 0) {
                     listPortfolio.Remove(pPortfolio.getID());
                 }
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public int NumberOfPortfolios()
         {
             return listPortfolio.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 return pPortfolio.getNoOfStocks();
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 return true;
             }else{
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             String lowerStock = inStockName.ToLower();

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 return pPortfolio.IsStockContained(lowerStock);
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             String lowerStock = inStockName.ToLower();

             if (!listStock.ContainsKey(lowerStock)){
                 throw new StockExchangeException("The Stock named " + inStockName + " does not exists.");
             }

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 return pPortfolio.getNoOfShares(inStockName);
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 List<Stock> portfolioStocks = pPortfolio.getStockList();

                 decimal sum = 0m;

                 foreach (Stock pStock in portfolioStocks) {
                     sum += listStock[pStock.getStockName()].getStockPrice(timeStamp)*pStock.getNumOfStocks();
                 }

                 return Math.Round(sum, 3);
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime startTime = new DateTime(Year, Month, 1, 0, 0, 00, 00);
             DateTime endTime = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

             if (listPortfolio.ContainsKey(inPortfolioID)){
                 Portfolio pPortfolio = listPortfolio[inPortfolioID];
                 List<Stock> portfolioStocks = pPortfolio.getStockList();

                 decimal startSum = 0m;
                 decimal endSum = 0m;

                 foreach (Stock pStock in portfolioStocks){
                     decimal startPrice = listStock[pStock.getStockName()].getStockPrice(startTime);
                     decimal endPrice = listStock[pStock.getStockName()].getStockPrice(endTime);
					 
                     if (startPrice==0m) {
                         throw new StockExchangeException("Unable to calculate percent change for portfolio: " + inPortfolioID);
                     }
					 
                     startSum += startPrice * pStock.getNumOfStocks();
                     endSum += endPrice * pStock.getNumOfStocks();
                 }

                 if (portfolioStocks.Count != 0) {
                     return Math.Round(((endSum / startSum) - 1) * 100, 3);
                 } else {
                    return 0m;
                 }
             }else{
                 throw new StockExchangeException("The portfolio named " + inPortfolioID + " does not exists.");
             }
         }

         private bool IsTotalNumberOfStocksOk(string stockName, long newStockNumber) {
             String lower = stockName.ToLower();

             Stock stock = listStock[stockName];

             long totalNo = stock.getNumOfStocks();
             long sum = 0;
             foreach (KeyValuePair<string, Portfolio> kvp in listPortfolio){
                 List<Stock> portfolioStockList = kvp.Value.getStockList();
                 foreach (Stock stockPort in portfolioStockList) {
                     if (stockPort.getStockName().Equals(lower)){
                         sum += stockPort.getNumOfStocks();
                     }
                 }
             }

             if (sum + newStockNumber <= totalNo){
                 return true;
             }else{
                 return false;
             }
         }
     }

     class Index
     {
         private string name;
         private IndexTypes tip;
         private Dictionary<string, Stock> listStock;

         public Index(string pName, IndexTypes pTip)
         {
             this.name = pName;
             this.tip = pTip;
             this.listStock = new Dictionary<string, Stock>();
         }

         public void addStock(string stockName, Stock stock)
         {
             listStock.Add(stockName, stock);
         }

         public void removeStock(string stockName)
         {
             if (listStock.ContainsKey(stockName.ToLower()))
             {
                 listStock.Remove(stockName);
             }
         }

         public int getNumOfStocks()
         {
             return listStock.Count();
         }

         public bool IsStockContained(String id)
         {
             string lowerId = id.ToLower();

             return listStock.ContainsKey(lowerId);
         }

         public IndexTypes getTip()
         {
             return tip;
         }

         public string getName()
         {
             return name;
         }

         public Dictionary<string, Stock> getStocks()
         {
             return listStock;
         }
     }

     class PriceHistoryItem
     {
         private Decimal price;
         private DateTime appliesFrom;

         public PriceHistoryItem(Decimal pPrice, DateTime pApplies)
         {
             this.price = pPrice;
             this.appliesFrom = pApplies;
         }

         public Decimal getPrice()
         {
             return price;
         }

         public DateTime getAppliesFrom()
         {
             return appliesFrom;
         }
     }

     class Stock
     {
         private string name;
         private long numOfStocks;
         private Decimal price;
         private DateTime appliesFrom;
         private List<PriceHistoryItem> priceHistory;

         public Stock(string pName, long pNumOfStocks, Decimal pStartingPrice, DateTime pAppliesFrom)
         {
             this.name = pName;
             this.numOfStocks = pNumOfStocks;
             this.price = pStartingPrice;
             this.appliesFrom = pAppliesFrom;
             this.priceHistory = new List<PriceHistoryItem>();
         }

         public void setPriceTime(Decimal pPrice, DateTime pAppliesFrom)
         {
             PriceHistoryItem oldPrice = new PriceHistoryItem(price, appliesFrom);

             foreach (PriceHistoryItem item in priceHistory)
             {
                 if (item.getAppliesFrom().Equals(pAppliesFrom))
                 {
                     throw new StockExchangeException("The price for that moment has already been defined.");
                 }
             }

             if (appliesFrom.Equals(pAppliesFrom))
             {
                 throw new StockExchangeException("The price for that moment has already been defined.");
             }

             priceHistory.Add(oldPrice);

             this.price = pPrice;
             this.appliesFrom = pAppliesFrom;
         }

         public void setNumOfStocks(long pNumOfStocks)
         {
             this.numOfStocks = pNumOfStocks;
         }

         public Decimal getStockPrice(DateTime pTime)
         {
             Decimal price = new Decimal();
             long dif = pTime.Ticks;

             if (priceHistory.Count() > 0)
             {
                 foreach (PriceHistoryItem item in priceHistory)
                 {
                     if (item.getAppliesFrom() <= pTime)
                     {
                         if (((pTime.Ticks - item.getAppliesFrom().Ticks) < dif) && (pTime.Ticks - item.getAppliesFrom().Ticks) >= 0)
                         {
                             price = item.getPrice();
                             dif = pTime.Ticks - item.getAppliesFrom().Ticks;
                         }
                     }
                 }
             }

             if (appliesFrom <= pTime)
             {
                 price = this.price;
             }

             return price;
         }

         public Decimal getLastStockPrice()
         {
             Decimal lPrice = new Decimal();

            if (priceHistory.Count() > 0){
                DateTime maxTime = priceHistory.ElementAt(0).getAppliesFrom();
                lPrice = priceHistory.ElementAt(0).getPrice();

                foreach (PriceHistoryItem item in priceHistory){
                    if (item.getAppliesFrom() > maxTime){
                        maxTime = item.getAppliesFrom();
                        lPrice = item.getPrice();
                    }
                }

                if (appliesFrom > maxTime){
                    maxTime = appliesFrom;
                    lPrice = this.price;
                }
            }else{
                lPrice = this.price;
            }
            return lPrice;
         }

         public Decimal getInitialStockPrice()
         {

             Decimal lPrice = new Decimal();

             if (priceHistory.Count() > 0)
             {
                 DateTime minTime = priceHistory.ElementAt(0).getAppliesFrom();
                 lPrice = priceHistory.ElementAt(0).getPrice();

                 foreach (PriceHistoryItem item in priceHistory)
                 {
                     if (item.getAppliesFrom() < minTime)
                     {
                         minTime = item.getAppliesFrom();
                         lPrice = item.getPrice();
                     }
                 }

                 if (appliesFrom < minTime)
                 {
                     minTime = appliesFrom;
                     lPrice = this.price;
                 }
             }
             else
             {
                 lPrice = this.price;
             }
             return lPrice;
         }

         public long getNumOfStocks()
         {
             return numOfStocks;
         }

         public string getStockName()
         {
             return name;
         }

         public DateTime getAppliesFrom()
         {
             return appliesFrom;
         }
     }

     class Portfolio
     {
         private string ID;
         private List<Stock> listStock;

         public Portfolio(string pID)
         {
             this.ID = pID;
             this.listStock = new List<Stock>();
         }

         public List<Stock> getStockList()
         {
             return listStock;
         }

         public void addStock(Stock pStock)
         {
             foreach (Stock stock in listStock)
             {
                 if (stock.getStockName().Equals(pStock.getStockName()))
                 {
                     long newNo = stock.getNumOfStocks() + pStock.getNumOfStocks();
                     stock.setNumOfStocks(newNo);
                     return;
                 }
             }
             listStock.Add(pStock);
         }

         public void removeStock(string id)
         {
             listStock.RemoveAll((x) => x.getStockName().Equals(id.ToLower()));
         }

         public bool IsStockContained(String id)
         {
             return listStock.Exists((x) => x.getStockName().Equals(id.ToLower()));
         }

         public int getNoOfStocks()
         {
             return listStock.Count();
         }

         public int getNoOfShares()
         {
             int sum = 0;

             foreach (Stock stock in listStock)
             {
                 sum += (int)stock.getNumOfStocks();
             }

             return sum;
         }

         public int getNoOfShares(string stockName)
         {
             string lowerStockName = stockName.ToLower();

             foreach (Stock stock in listStock)
             {
                 if (stock.getStockName().Equals(lowerStockName))
                 {
                     return (int)stock.getNumOfStocks();
                 }
             }

             return 0;
         }

         public string getID()
         {
             return ID;
         }
     }
}
