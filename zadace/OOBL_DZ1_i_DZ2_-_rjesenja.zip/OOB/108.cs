﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    class Stock : IEquatable<Stock>
    {
        private string stockName;
        private long numberOfShares;
        private long numberOfFreeShares;
        private decimal initialPrice;
        private DateTime initialTimeStamp;
        private SortedDictionary<DateTime, decimal> stockPrices = new SortedDictionary<DateTime, decimal>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.stockName = inStockName;
            this.numberOfShares = inNumberOfShares;
            this.numberOfFreeShares = inNumberOfShares;
            this.initialPrice = inInitialPrice;
            this.initialTimeStamp = inTimeStamp;
            stockPrices.Add(inTimeStamp, inInitialPrice);
        }

        public void setNumberOfFreeShares(int numberOfShares)
        {
            numberOfFreeShares = NumberOfFreeShares - numberOfShares;
        }

        public long NumberOfShares
        {
            get { return this.numberOfShares; }
        }

        public long NumberOfFreeShares
        {
            get { return this.numberOfFreeShares; }
            set { this.numberOfFreeShares = value; }
        }

        public decimal getStockLastPrice()
        {
            return this.stockPrices.Values.Last();
        }

        public decimal InitialStockPrice
        {
            get { return this.initialPrice; }
        }

        public decimal getStockPriceByTime(DateTime inTimeStamp)
        {
            if (stockPrices.First().Key.CompareTo(inTimeStamp) > 0) throw new StockExchangeException("StockPriceByTime exception.");
            DateTime lastTimeStamp = stockPrices.First().Key;
            foreach (KeyValuePair<DateTime, decimal> kvp in stockPrices)
            {
                if (lastTimeStamp.CompareTo(kvp.Key) == 0) continue;
                if (kvp.Key.CompareTo(inTimeStamp) > 0) return stockPrices[lastTimeStamp];
                lastTimeStamp = kvp.Key;
            }
            return stockPrices.Last().Value;
        }

        public bool setStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (stockPrices.ContainsKey(inTimeStamp)) throw new StockExchangeException("SetStockPrice exception. Datum vec postoji.");
            stockPrices.Add(inTimeStamp, inStockValue);
            return true;
        }

        public Stock(string inStockName)
        {
            this.stockName = inStockName;
        }

        public string StockName
        {
            get { return this.stockName; }
        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as Stock);
        }

        public bool Equals(Stock s)
        {
            if (Object.ReferenceEquals(s, null))
                return false;
            if (Object.ReferenceEquals(this, s))
                return true;
            if (this.GetType() != s.GetType())
                return false;
            string upperStockName = s.StockName.ToUpper();
            return this.stockName.ToUpper().Equals(upperStockName);
        }

        public override int GetHashCode()
        {
            return this.stockName.GetHashCode();
        }
    }

    class Index : IEquatable<Index>
    {
        private string indexName;
        private IndexTypes indexType;
        private List<Stock> indexStocks = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.indexName = inIndexName;
            this.indexType = inIndexType;
        }

        public Index(string inIndexName)
        {
            this.indexName = inIndexName;
        }

        public int getNumberOfStocksInIndex()
        {
            return this.indexStocks.Count;
        }

        public decimal getIndexValue(DateTime inTimeStamp)
        {
            if (inTimeStamp == null) throw new StockExchangeException("GetIndexValue exception. DateTime is null.");
            if (this.indexType == IndexTypes.AVERAGE)
            {
                decimal sumValue = 0;
                long numberOfStocks = 0;
                foreach (Stock s in indexStocks)
                {
                    decimal value = s.getStockPriceByTime(inTimeStamp);
                    numberOfStocks += s.NumberOfShares;
                    sumValue = value * s.NumberOfShares;

                }
                return sumValue / numberOfStocks;
            }
            else
            {
                decimal sumOfStockValues = 0;
                decimal factor = 0;
                decimal weightIndex = 0;
                foreach (Stock s in indexStocks)
                {
                    decimal value = s.getStockPriceByTime(inTimeStamp);
                    long numberOfStocks = s.NumberOfShares;
                    sumOfStockValues += value * numberOfStocks;

                }
                foreach (Stock s in indexStocks)
                {
                    decimal value = s.getStockPriceByTime(inTimeStamp);
                    factor = (value * s.NumberOfShares) / sumOfStockValues;
                    weightIndex += factor * value;
                }
                return weightIndex;
            }
        }

        public bool IsStockPartOfIndex(Stock stock)
        {
            return this.indexStocks.Contains(stock);
        }

        public void removeStockFromIndex(Stock stock)
        {
            this.indexStocks.Remove(stock);
        }

        public void addStockToIndex(Stock stock)
        {
            this.indexStocks.Add(stock);
        }

        public string IndexName
        {
            get { return this.indexName; }
        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as Index);
        }

        //jel index ovisi o slovima
        public bool Equals(Index i)
        {
            if (Object.ReferenceEquals(i, null))
                return false;
            if (Object.ReferenceEquals(this, i))
                return true;
            if (this.GetType() != i.GetType())
                return false;
            string upperIndexName = i.IndexName.ToUpper();
            return this.indexName.ToUpper().Equals(upperIndexName);
        }

        public override int GetHashCode()
        {
            return this.indexName.GetHashCode();
        }
    }

    class Portfolio : IEquatable<Portfolio>
    {
        private string portfolioId;
        private Dictionary<Stock, int> portfolioStocks = new Dictionary<Stock, int>();

        public Portfolio(string inPortfolioId)
        {
            this.portfolioId = inPortfolioId;
        }

        public decimal PortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime beginTimeStamp = new DateTime(Year, Month, 1, 0, 0, 0);
            DateTime endTimeStamp = new DateTime(Year, Month, 1, 23, 59, 59, 999).AddMonths(1).AddDays(-1);
            decimal beginValue = this.PortfolioValue(beginTimeStamp);
            decimal endValue = this.PortfolioValue(endTimeStamp);
            return ((endValue / beginValue) - 1) * 100;
        }

        public decimal PortfolioValue(DateTime inTimeStamp)
        {
            if (inTimeStamp == null) throw new StockExchangeException("PortfolioValue exception. Null date.");
            decimal porfolioValue = 0;
            foreach (KeyValuePair<Stock, int> kvp in portfolioStocks)
            {
                Stock s = kvp.Key;
                int numberOfStocks = kvp.Value;
                decimal stockValue = s.getStockPriceByTime(inTimeStamp);
                porfolioValue += stockValue * numberOfStocks;
            }
            return porfolioValue;
        }

        public bool IsStockPartOfPortfolio(Stock s)
        {
            return this.portfolioStocks.ContainsKey(s);
        }

        public int NumberOfStocksInPortfolio
        {
            get { return portfolioStocks.Count; }
        }

        public void RemoveStockFromPortfolio(Stock s)
        {
            int i = portfolioStocks[s];
            s.NumberOfFreeShares = s.NumberOfFreeShares + i;
            portfolioStocks.Remove(s);
        }

        public void RemoveStockFromPortfolio(Stock s, int numberOfShares)
        {
            int i = portfolioStocks[s];
            i = i - numberOfShares;
            if (i == 0)
            {
                s.NumberOfFreeShares = s.NumberOfFreeShares + numberOfShares;
                portfolioStocks.Remove(s);
            }
            else
            {
                s.NumberOfFreeShares = s.NumberOfFreeShares + numberOfShares;
                portfolioStocks[s] = i;
            }
        }

        public int NumberOfStocks(Stock s)
        {
            return portfolioStocks[s];
        }

        public void AddStockToPortfolio(Stock s, int numberOfShares)
        {
            s.setNumberOfFreeShares(numberOfShares);
            if (portfolioStocks.ContainsKey(s))
            {
                int i = portfolioStocks[s];
                i += numberOfShares;
                portfolioStocks[s] = i;
            }
            else
            {
                portfolioStocks.Add(s, numberOfShares);
            }
        }

        public string PortfolioId
        {
            get { return this.portfolioId; }
        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as Portfolio);
        }

        public bool Equals(Portfolio p)
        {
            if (Object.ReferenceEquals(p, null))
                return false;
            if (Object.ReferenceEquals(this, p))
                return true;
            if (this.GetType() != p.GetType())
                return false;
            return this.portfolioId.Equals(p.PortfolioId);
        }

        public override int GetHashCode()
        {
            return this.portfolioId.GetHashCode();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> stocks = new List<Stock>();
         private List<Index> indexes = new List<Index>();
         private List<Portfolio> portfolios = new List<Portfolio>();

         private Stock getStockByName(string inStockName)
         {
             Stock s = stocks.Find(delegate(Stock st)
             {
                 if (st.StockName.ToUpper().Equals(inStockName.ToUpper()))
                     return true;
                 return false;
             });
             return s;
         }

         private Index getIndexByName(string inIndexName)
         {
             Index i = indexes.Find(delegate(Index ix)
                 {
                     if(ix.IndexName.ToUpper().Equals(inIndexName.ToUpper()))
                         return true;
                     return false;
                 });
             return i;
         }

         private Portfolio getPortfolioById(string inPortfolioID)
         {
             Portfolio p = portfolios.Find(delegate(Portfolio pt)
                 {
                     if(pt.PortfolioId.Equals(inPortfolioID))
                         return true;
                     return false;
                 });
             return p;
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (this.StockExists(inStockName)) throw new StockExchangeException("ListStock exception. Dionica vec postoji.");
             if (inNumberOfShares <= 0) throw new StockExchangeException("ListStock exception. Broj dionica je manji od 1.");
             if (inInitialPrice <= (decimal)0) throw new StockExchangeException("ListStock exception. Pocetna cijena je manja od 0.");
             if (inStockName == null) throw new StockExchangeException("ListStock exception. StockName null.");
             stocks.Add(new Stock(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             if (!this.StockExists(inStockName)) throw new StockExchangeException("DelistStock exception. Dionica ne postoji.");
             foreach (Portfolio p in portfolios)
             {
                if (this.IsStockPartOfPortfolio(p.PortfolioId,inStockName))
                    this.RemoveStockFromPortfolio(p.PortfolioId,inStockName);
             }
             foreach (Index i in indexes)
             {
                 if (this.IsStockPartOfIndex(i.IndexName,inStockName))
                     this.RemoveStockFromIndex(i.IndexName,inStockName);
             }
             stocks.Remove(new Stock(inStockName));
         }

         public bool StockExists(string inStockName)
         {
             if (inStockName == null) return false;
             return stocks.Contains(new Stock(inStockName));
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (!this.StockExists(inStockName)) throw new StockExchangeException("SetStockPrice exception. Dionica ne postoji.");
             if (inStockValue <= (decimal)0) throw new StockExchangeException("SetStockPrice exception. Cijena je manja od 0.");
             //ovdje treba dodati provjeru formata datuma
             if (inTimeStamp == null) throw new StockExchangeException("SetStockPrice exception. Pogresan datum.");
             Stock s = this.getStockByName(inStockName);
             s.setStockPrice(inTimeStamp, inStockValue);   
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!this.StockExists(inStockName)) throw new StockExchangeException("GetStockPrice exception. Dionica ne postoji.");
             //provjera datuma i formata
             Stock s = this.getStockByName(inStockName);
             return Decimal.Round(s.getStockPriceByTime(inTimeStamp),3);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!this.StockExists(inStockName)) throw new StockExchangeException("GetInitialStockPrice exception. Dionica ne postoji.");
             Stock s = this.getStockByName(inStockName);
             return Decimal.Round(s.InitialStockPrice,3);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!this.StockExists(inStockName)) throw new StockExchangeException("GetLastStockPrice exception. Dionica ne postoji.");
             Stock s = this.getStockByName(inStockName);
             return Decimal.Round(s.getStockLastPrice(),3);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (this.IndexExists(inIndexName) | inIndexName == null) throw new StockExchangeException("CreateIndex exception. Index vec postoji.");
             if ( !(inIndexType == IndexTypes.AVERAGE) & !(inIndexType == IndexTypes.WEIGHTED)) throw new StockExchangeException("CreateIndex exception. Nepostojeci tip indexa.");
             indexes.Add(new Index(inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!this.IndexExists(inIndexName)) throw new StockExchangeException("AddStockToIndex exception. Index ne postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("AddStockToIndex exception. Dionica ne postoji.");
             Index i = this.getIndexByName(inIndexName);
             Stock s = this.getStockByName(inStockName);
             if ( i.IsStockPartOfIndex(s) ) throw new StockExchangeException("AddStockToIndex exception. Dionica je vec u indexu.");
             i.addStockToIndex(s);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!this.IndexExists(inIndexName)) throw new StockExchangeException("RemoveStockFromIndex exception. Index ne postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("RemoveStockFromIndex exception. Dionica ne postoji.");
             Index i = this.getIndexByName(inIndexName);
             Stock s = this.getStockByName(inStockName);
             if (!i.IsStockPartOfIndex(s)) throw new StockExchangeException("RemoveStockFromIndex exception. Dionica nije u indexu.");
             i.removeStockFromIndex(s);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!this.IndexExists(inIndexName)) throw new StockExchangeException("IsStockPartOfIndex exception. Index ne postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("IsStockPartOfIndex exception. Dionica ne postoji.");
             Index i = this.getIndexByName(inIndexName);
             Stock s = this.getStockByName(inStockName);
             return i.IsStockPartOfIndex(s);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!this.IndexExists(inIndexName)) throw new StockExchangeException("GetIndexValue exception. Index ne postoji.");
             Index i = this.getIndexByName(inIndexName);
             return Decimal.Round(i.getIndexValue(inTimeStamp),3);
         }

         public bool IndexExists(string inIndexName)
         {
             if (inIndexName == null) return false;
             return this.indexes.Contains(new Index(inIndexName));
         }

         public int NumberOfIndices()
         {
             return this.indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!this.IndexExists(inIndexName)) throw new StockExchangeException("GetIndexValue exception. Index ne postoji.");
             Index i = this.getIndexByName(inIndexName);
             return i.getNumberOfStocksInIndex();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (this.PortfolioExists(inPortfolioID) | inPortfolioID == null) throw new StockExchangeException("CreatePortfolio exception. Portfelj vec postoji.");
             portfolios.Add(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("AddStockToPortfolio exception. Portfelj new postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("AddStockToPortfolio exception. Dionice ne postoji.");
             Stock s = this.getStockByName(inStockName);
             long numberOfFreeShare = s.NumberOfFreeShares;
             if ( numberOfShares > numberOfFreeShare | numberOfShares < 1 ) throw new StockExchangeException("AddStockToPortfolio exception. Nema dovoljno dionica.");
             Portfolio p = this.getPortfolioById(inPortfolioID);
             p.AddStockToPortfolio(s, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares < 1) throw new StockExchangeException("RemoveStockFromPortfolio exception. Wrong numberOfShares");
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("RemoveStockFromPortfolio exception. Portfelj new postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("RemoveStockFromPortfolio exception. Dionice ne postoji.");
             Stock s = this.getStockByName(inStockName);
             Portfolio p = this.getPortfolioById(inPortfolioID);
             if ( !p.IsStockPartOfPortfolio(s) ) throw new StockExchangeException("RemoveStockFromPortfolio exception. Dionica nije u portfelju.");
             long numberOfShareInPorfolio = p.NumberOfStocks(s);
             if (numberOfShares > numberOfShareInPorfolio) throw new StockExchangeException("RemoveStockFromPortfolio exception. Nema dovoljno dionica.");
             p.RemoveStockFromPortfolio(s, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("RemoveStockFromPortfolio exception. Portfelj new postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("RemoveStockFromPortfolio exception. Dionice ne postoji.");
             Stock s = this.getStockByName(inStockName);
             Portfolio p = this.getPortfolioById(inPortfolioID);
             if (!p.IsStockPartOfPortfolio(s)) throw new StockExchangeException("RemoveStockFromPortfolio exception. Dionica nije u portfelju.");
             p.RemoveStockFromPortfolio(s);
         }

         public int NumberOfPortfolios()
         {
             return this.portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("NumberOfStocksInPortfolio exception. Portfelj new postoji.");
             Portfolio p = this.getPortfolioById(inPortfolioID);
             return p.NumberOfStocksInPortfolio;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (inPortfolioID == null) return false;
             return portfolios.Contains(new Portfolio(inPortfolioID));
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("IsStockPartOfPortfolio exception. Portfelj new postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("IsStockPartOfPortfolio exception. Dionice ne postoji.");
             Stock s = this.getStockByName(inStockName);
             Portfolio p = this.getPortfolioById(inPortfolioID);
             return p.IsStockPartOfPortfolio(s);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("NumberOfSharesOfStockInPortfolio exception. Portfelj new postoji.");
             if (!this.StockExists(inStockName)) throw new StockExchangeException("NumberOfSharesOfStockInPortfolio exception. Dionice ne postoji.");
             Stock s = this.getStockByName(inStockName);
             Portfolio p = this.getPortfolioById(inPortfolioID);
             if (!p.IsStockPartOfPortfolio(s)) throw new StockExchangeException("NumberOfSharesOfStockInPortfolio exception. Dionica nije dio portfelja.");
             return p.NumberOfStocks(s);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("GetPortfolioValue exception. Portfelj ne postoji.");
             Portfolio p = this.getPortfolioById(inPortfolioID);
             return Decimal.Round(p.PortfolioValue(timeStamp),3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (Year < 1 | Month < 1 | Month > 12) throw new StockExchangeException("GetPortfolioPercentChangeInValueForMonth exception. Pogresno definirano vrijeme.");
             if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("GetPortfolioPercentChangeInValueForMonth exception. Portfelj ne postoji.");
             Portfolio p = this.getPortfolioById(inPortfolioID);
             return Decimal.Round(p.PortfolioPercentChangeInValueForMonth(Year, Month),3);
         }
     }
}
