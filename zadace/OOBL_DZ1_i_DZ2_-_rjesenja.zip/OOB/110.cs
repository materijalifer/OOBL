﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks = new List<Stock>();
        private List<Index> _indices = new List<Index>();
        private List<Portfolio> _portfolios = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                _stocks.Add(stock);
                
            }else{
                throw new StockExchangeException("Pokusaj upisivanja dionice s vec zauzetim imenom.");
            }     
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = fetchStock(inStockName);
            
            //izbrisati dionicu iz svih indeksa i portfelja u kojima se nalazi
            List<Index> indicesContainingStock = _indices.Where( index => index.containsStock(stock)).ToList();
            foreach(Index index in indicesContainingStock){
                RemoveStockFromIndex(index.Name, stock.Name);
            }

            List<Portfolio> portfoliosContainingStock = _portfolios.Where( portf => portf.containsStock(stock)).ToList();
            foreach(Portfolio portfolio in portfoliosContainingStock){
                RemoveStockFromPortfolio(portfolio.ID, stock.Name);
            }

            _stocks.Remove(stock);
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.Any(st => st.isNamed(inStockName));
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = fetchStock(inStockName);
            stock.setPriceAtDate(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = fetchStock(inStockName);
            return stock.getPriceAtDate(inTimeStamp);
      
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = fetchStock(inStockName);
            return stock.getInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = fetchStock(inStockName);
            return stock.getLatestPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if(!IndexExists(inIndexName)){
                Index index = new Index(inIndexName, inIndexType);
                _indices.Add(index);
            }else{
                throw new StockExchangeException("Pokusaj dodavanja vec postojeg indeksa.");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = fetchIndex(inIndexName);
            Stock stock = fetchStock(inStockName);

            index.addStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = fetchIndex(inIndexName);
            Stock stock = fetchStock(inStockName);
            index.removeStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = fetchIndex(inIndexName);
            Stock stock = fetchStock(inStockName);
            return index.containsStock(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = fetchIndex(inIndexName);
            
            switch(index.IndexType){
                case IndexTypes.AVERAGE :
                    return index.getAverageValue(inTimeStamp);
                case IndexTypes.WEIGHTED :
                    return index.getWeigthedValue(inTimeStamp);
                default:
                    //ako se IndexTypes enum proširi, zabranjeno je korištenje dodatnih tipova
                    throw new StockExchangeException("Pokusaj dohvata vrijednosti indeksa nedozvoljenog tipa.");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return _indices.Any( index => index.isNamed(inIndexName));
        }

        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = fetchIndex(inIndexName);
            return index.countStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                Portfolio portf = new Portfolio(inPortfolioID);
                _portfolios.Add(portf);
            }else{
                throw new StockExchangeException("Pokusaj dodajavanja vec postojeceg portfelja.");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            Stock stock = fetchStock(inStockName);

            //izracun koliko je udjela doticne dionice vec u necijem posjedu
            int numOwned = _portfolios.Sum( portf=> portf.numberOfSharesOwned(stock));
            if(numberOfShares + numOwned > stock.NumberOfShares){
                throw new StockExchangeException("Pokusaj unosa dionica u portfelj s nedovoljnim brojem slobodnih udjela.");
            }
            portfolio.addStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            Stock stock = fetchStock(inStockName);

            portfolio.removeStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            Stock stock = fetchStock(inStockName);

            portfolio.removeStock(stock, portfolio.numberOfSharesOwned(stock));
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            return portfolio.countStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.Any(portf => portf.ID.Equals(inPortfolioID));
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            Stock stock = fetchStock(inStockName);
            return portfolio.containsStock(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            Stock stock = fetchStock(inStockName);

            return portfolio.numberOfSharesOwned(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            return portfolio.getValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = fetchPortfolio(inPortfolioID);
            DateTime startDate = new DateTime(Year, Month, 1);
            //izracun zadnjeg dana u mjesecu - prvom danu dodaj mjesec dana i oduzmi jedan dan 
            DateTime endDate = startDate.AddMonths(1).Subtract(new TimeSpan(1, 0, 0, 0));
            return portfolio.getPercentChangeInValue(startDate, endDate);
        }

        private Stock fetchStock(string inStockName){
            if (StockExists(inStockName))
            {
                Stock stock = _stocks.Single(st => st.isNamed(inStockName));
                return stock;
                
            }
            throw new StockExchangeException("Pokusaj dohvata nepostojece dionice.");    
        }

        private Index fetchIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                Index index = _indices.Single(ind => ind.isNamed(inIndexName));
                return index;
            }
            throw new StockExchangeException("Pokusaj dohvata nepostojeceg indeksa.");
        }

        private Portfolio fetchPortfolio(string inPortfolioID){
            if(PortfolioExists(inPortfolioID)){
                Portfolio portfolio = _portfolios.Single(portf => portf.ID.Equals(inPortfolioID));
                return portfolio;
            }
            throw new StockExchangeException("Pokušaj dohvata nepostojeceg portfelja.");
        }
    }

    class Stock
    {
        private string _name;
        private long _numberOfShares;
        private List<StockPrice> _stockPrices = new List<StockPrice>();

        public string Name{
            get { return _name; }
        }

        public long NumberOfShares{
            get { return _numberOfShares; }
        }

        public Stock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp){
            if(numberOfShares <= 0){
                throw new StockExchangeException("Pokusaj unosa nula ili manje udjela dionica.");
            }
            _name = name;
            _numberOfShares = numberOfShares;
            _stockPrices.Add(new StockPrice(initialPrice, timeStamp));
        }

        public override bool Equals(object compareToStock){
            if(!(compareToStock is Stock)){
                throw new StockExchangeException("Pokusaj usporedbe dionice s necim sto nije dionica.");
            }

            return ((Stock)compareToStock).Name.ToLower().Equals(this.Name.ToLower());  
        }

        public bool isNamed(string stockName){
            return stockName.ToLower().Equals(this.Name.ToLower());
        }

        public void setPriceAtDate(decimal price, DateTime timeStamp){
 
            //dohvati sve cijene definirane za trazeni trenutak
            List<StockPrice> existingPrices = _stockPrices.Where( pr => pr.TimeStamp.Equals(timeStamp)).ToList();
            
            if(existingPrices.Count == 0){
                _stockPrices.Add(new StockPrice(price, timeStamp));
            }else{
                throw new StockExchangeException("Pokusaj redefiniranja cijene na zadani datum.");
            } 
        }

        public decimal getPriceAtDate(DateTime timeOfInterest){

            if (timeOfInterest < _stockPrices.Min(price => price.TimeStamp))
            {
                throw new StockExchangeException("Pokusaj citanja vrijednosti dionice prije nego je stvorena.");
            }

            //dohvat skupa svih cijena vrijedecih prije trazenog trenutka
            List<StockPrice> pricesBeforeTimeOfInterest = _stockPrices.Where(stockPrice => stockPrice.TimeStamp <= timeOfInterest).ToList();

            //odabir trenutka posljednje vrijedece cijene - trenutak definicije cijene aktualne u trazenom trenutku
            DateTime latestTimeStampBeforeTimeOfInterest = pricesBeforeTimeOfInterest.Max(stockPrice => stockPrice.TimeStamp);
            StockPrice latestPriceBeforeTimeOfInterest = _stockPrices.Single(stockPrice => stockPrice.TimeStamp.Equals(latestTimeStampBeforeTimeOfInterest));
            return latestPriceBeforeTimeOfInterest.Price;
        }

        public decimal getInitialPrice()
        {
            DateTime firstTimeStamp = _stockPrices.Min(stockPrice => stockPrice.TimeStamp);

            StockPrice firstPrice = _stockPrices.Single(stockPrice => stockPrice.TimeStamp.Equals(firstTimeStamp));
            return firstPrice.Price;
        }

        public decimal getLatestPrice()
        {
            DateTime latestTimeStamp = _stockPrices.Max(stockPrice => stockPrice.TimeStamp);

            StockPrice latestPrice = _stockPrices.Single(stockPrice => stockPrice.TimeStamp.Equals(latestTimeStamp));
            return latestPrice.Price;
        }
    }

    class StockPrice
    {
        private decimal _price;
        private DateTime _timeStamp;

        public decimal Price{
            get { return _price; }
        }

        public DateTime TimeStamp{
            get { return _timeStamp; }
        }

        public StockPrice(decimal price, DateTime timeStamp){
            if( price <= 0){
                throw new StockExchangeException("Pokusaj stvaranja negativne cijene dionice.");
            }
            _price = price;
            _timeStamp = timeStamp;
        }
    }

    class Index
    {
        private string _name;
        private IndexTypes _indexType;
        private List<Stock> _stockList = new List<Stock>();

 
        public string Name{
            get { return _name; }
        }
        
        public IndexTypes IndexType{
            get { return _indexType; }
        }

        public Index(string name, IndexTypes indexType){
            int numIndexType = (int) indexType;

            //indexType ogranicenje s obzirom na zadani enum
            if(new int[2]{1, 2}.Any( num => num == numIndexType)){
                _name = name;
                _indexType = indexType;
            }else{
                throw new StockExchangeException("Pokusaj unosa indeksa neispravne vrste.");
            }
        }

        public bool isNamed(string indexName)
        {
            return indexName.ToLower().Equals(this.Name.ToLower());
        }

        public void addStock(Stock stock){
            if(! _stockList.Any( st => st.Equals(stock))){
                _stockList.Add(stock);
            }else{
                throw new StockExchangeException("Pokusaj dodavanja dionice u index koja je vec u njemu.");
            }
        }

        public void removeStock(Stock stock){
            if(_stockList.Contains(stock)){
                _stockList.Remove(stock);
            }else{
                throw new StockExchangeException("Pokusaj brisanja dionice iz indeksa koji ju ne sadrzi.");
            }
        }

        public bool containsStock(Stock stock){
            return _stockList.Contains(stock);
        }

        public int countStocks(){
            return _stockList.Count;
        }

        public decimal getAverageValue(DateTime timeStamp){

            decimal sumOfPricesAtTime = _stockList.Sum( stock => stock.getPriceAtDate(timeStamp));
            decimal valueAtTimeStamp = sumOfPricesAtTime / _stockList.Count;
            return Decimal.Round(valueAtTimeStamp, 3);
        }

        public decimal getWeigthedValue(DateTime timeStamp){

            decimal sumValueOfStocks = _stockList.Sum(st => st.getPriceAtDate(timeStamp) * st.NumberOfShares);

            List<decimal> weights = new List<decimal>();

            foreach(Stock stock in _stockList){
                decimal valueOfStock = stock.getPriceAtDate(timeStamp) * stock.NumberOfShares;
                
                decimal weight = valueOfStock / sumValueOfStocks;
                weights.Add(weight);
            }

            decimal weightedValue = 0;

            for(int stockPointer = 0; stockPointer < _stockList.Count ; stockPointer++){

                decimal priceOfStock = _stockList[stockPointer].getPriceAtDate(timeStamp);
                decimal weightedValueOfStock = weights[stockPointer] * priceOfStock;
                weightedValue += weightedValueOfStock;
            }

            return Decimal.Round(weightedValue,3);
        }
    }

    class Portfolio
    {
        private string _ID;
        private List<StockOwnership> _stockOwnerships = new List<StockOwnership>();

        public string ID{
            get { return _ID; }
        }
        
        public Portfolio(string ID){
            _ID = ID;
        }

        public void addStock(Stock stock, int numOfShares){
            
            if (!containsStock(stock))
            {
                _stockOwnerships.Add(new StockOwnership(stock, numOfShares));
            }else{
                StockOwnership stockOwn = _stockOwnerships.Single(stOwn => stOwn.Stock.Equals(stock));
                stockOwn.addShares(numOfShares);
            }  
        }

        public void removeStock(Stock stock, int numOfShares){

            if(!containsStock(stock)){
                throw new StockExchangeException("Pokusaj brisanja dionice iz portfelja koji ju ne sadrzi.");
            }

            StockOwnership stockOwn = _stockOwnerships.Single( stOwn => stOwn.Stock.Equals(stock));

            //ukoliko se brisu svi udjeli, brise se i dionica, inace se samo smanjuje broj udjela
            if(numOfShares == stockOwn.NumOfShares){
                _stockOwnerships.Remove(stockOwn);
            }
            else{
                if(numOfShares < stockOwn.NumOfShares){
                    stockOwn.removeShares(numOfShares);
                }       
            }
        }

        public bool containsStock(Stock stock){
            return _stockOwnerships.Any(stOw => stOw.Stock.Equals(stock));
        }

        public int numberOfSharesOwned(Stock stock){
            if(containsStock(stock)){
                return _stockOwnerships.Single(stOwn => stOwn.Stock.Equals(stock)).NumOfShares;
            }else{
                return 0;
            }
        }

        public int countStocks()
        {
            return _stockOwnerships.Count;
        }

        public decimal getValue(DateTime timeStamp){
            return _stockOwnerships.Sum( stOwn => stOwn.Stock.getPriceAtDate(timeStamp) * stOwn.NumOfShares );
        }

        public decimal getPercentChangeInValue(DateTime startDate, DateTime endDate){
            DateTime startMoment = startDate.Date;
            DateTime endMoment = new DateTime(endDate.Year, endDate.Month, endDate.Day, 23, 59, 59, 999);

            decimal startValue = getValue(startMoment);
            decimal endValue = getValue(endMoment);

            decimal percentChange = ((endValue - startValue)/startValue) *100;

            return Decimal.Round(percentChange, 3);   
        }

    }

    class StockOwnership{
        private Stock _stock;
        private int _numOfShares;

        internal Stock Stock
        {
            get { return _stock; }
        }
        
        public int NumOfShares
        {
            get { return _numOfShares; }
        }

        public StockOwnership(Stock stock, int numOfShares){
            if(numOfShares == 0){
                throw new StockExchangeException("Pokusaj unosa dionice s nula djelova u portfelj.");
            }
            _stock = stock;
            _numOfShares = numOfShares;
        }

        public void addShares(int numOfSharesToAdd){
            _numOfShares += numOfSharesToAdd; 
        }

        public void removeShares(int numOfSharesToRemove){
            if(numOfSharesToRemove < _numOfShares){
                    _numOfShares -= numOfSharesToRemove;
            }else{
                throw new Exception("Pokusaj brisanja vise udjela dionica nego sto ih ima u portfelju.");
            }
        }
    }
}
