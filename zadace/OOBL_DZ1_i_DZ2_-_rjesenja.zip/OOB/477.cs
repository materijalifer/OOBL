﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public  class Factory
    {
        public static ICalculator CreateCalculator()
        {
             // vratiti kalkulator
            return new Kalkulator();
         }
    }


   public class Kalkulator:ICalculator
    {
       private bool error = false;       
       private double Rezultat=0;      

       private string prviOperand = null;
       private string drugiOperand = null;
       private char operacija='$';
       private string ulazString="";
       private string TrenutnoStanje="0";
       private string Memorija="";
       private int brojZnamenki=0;
       
      
        public void Press(char inPressedDigit)
        {
            if (error == false)
            {

                if (Char.IsNumber(inPressedDigit))
                {
                    if (brojZnamenki < 10)
                        ulazString += inPressedDigit;
                           brojZnamenki += 1;
                }
                else if (inPressedDigit == ',')
                {
                    ulazString += inPressedDigit;
                    
                }
                else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/' || inPressedDigit == '=')
                {
                    Prelaz(inPressedDigit);
                }
                else if (inPressedDigit == 'S')
                {
                    Sinus();
                }
                else if (inPressedDigit == 'K')
                {
                    Kosinus();
                }
                else if (inPressedDigit == 'T')
                {
                    Tangens();
                }
                else if (inPressedDigit == 'I')
                {
                    Inverz();
                }
                else if (inPressedDigit == 'Q')
                {
                    Kvadrat();
                }
                else if (inPressedDigit == 'R')
                {
                    Korjen();
                }
                else if (inPressedDigit == 'P')
                {
                    Put();
                }
                else if (inPressedDigit == 'G')
                {
                    Get();
                }
                else if (inPressedDigit == 'C')
                {
                    ClearDisplay();
                }
                else if (inPressedDigit == 'O')
                {
                    On();
                }
                else if (inPressedDigit == 'M')
                {
                    PromjenaPredznaka();
                }
            }
            else if (inPressedDigit == 'O')
            {
                On();
            }
            else if (inPressedDigit == 'C')
            {
                ClearDisplay();
            }

        }



        public string GetCurrentDisplayState()
        {
            if (ulazString == "")
                if (error) return TrenutnoStanje;
                else return TrenutnoStanje;//double.Parse(TrenutnoStanje).ToString();
            return double.Parse(ulazString).ToString();
        }




        private void Prelaz(char oper)
        {
            if (oper == '=' )
            {
                if (operacija == '$' && ulazString != "")
                {
                    if (ulazString[ulazString.Length - 1] != ',')
                    {
                        Rezultat = double.Parse(ulazString);
                        TrenutnoStanje = Rezultat.ToString();
                        
                    }
                    else
                    {
                        Rezultat = double.Parse(ulazString.Substring(0, ulazString.Length - 1));
                        TrenutnoStanje = Rezultat.ToString();
                        prviOperand=ulazString.Substring(0, ulazString.Length - 1);
                        ulazString = "";
                    }
                }
                else if (operacija != '$' && prviOperand != null && drugiOperand==null &&  ulazString=="")
                {
                    drugiOperand = prviOperand;
                    switch (operacija)
                    {
                        case '+':
                            Plus();
                            break;

                        case '-':
                            Minus();
                            break;
                        case '*':
                            Puta();
                            break;
                        case '/':
                            Podjeljeno();
                            break;

                    }
                   
                        prviOperand = Rezultat.ToString();
                        TrenutnoStanje = Rezultat.ToString();
                        drugiOperand = null;
                        operacija = '$';
                    
                }
                
            }


            if (prviOperand == null && ulazString !="")
            {
                prviOperand = ulazString;
                TrenutnoStanje = double.Parse(ulazString).ToString();
                ulazString = "";
                brojZnamenki = 0;
                operacija = oper;
            }
            else if (prviOperand!=null && drugiOperand == null && ulazString!="")
            {
                drugiOperand = ulazString;
                ulazString = "";
                brojZnamenki = 0;
                switch (operacija)
                {
                    case '+':
                        Plus();
                       break;

                    case '-':
                        Minus();
                        break;
                    case '*':
                        Puta();
                        break;
                    case '/':
                        Podjeljeno();
                        break;
                                                
                }
                if (error == false)
                {
                    prviOperand = Rezultat.ToString();
                    TrenutnoStanje = Rezultat.ToString();
                    drugiOperand = null;
                    operacija = oper;
                }
                else TrenutnoStanje = "-E-";
            }
            operacija = oper;
        }







        private void Plus()
        {
              Rezultat = double.Parse(prviOperand) + double.Parse(drugiOperand);
              if (Rezultat >= 10000000000) Error();
              Rezultat = Math.Round(Rezultat, 9);
        }

        private void Minus()
        {
            Rezultat = double.Parse(prviOperand) - double.Parse(drugiOperand);
            if(Rezultat>= 10000000000) Error();
            Rezultat = Math.Round(Rezultat, 9);
        }

        private void Puta()
        {
            Rezultat = double.Parse(prviOperand) * double.Parse(drugiOperand);
            if (Rezultat >= 10000000000) Error();
            Rezultat = Math.Round(Rezultat, 9);
        }

        private void Podjeljeno()
        {
            if (drugiOperand == "0")
            {
                Error();

            }
            else Rezultat = double.Parse(prviOperand) / double.Parse(drugiOperand);
            if (Rezultat >= 10000000000) Error();
            Rezultat = Math.Round(Rezultat, 9);
        }

        private void Sinus() 
        {
            if (brojZnamenki == 0)
            {
                ulazString = Math.Round(Math.Sin(0), 9).ToString();
            }
            else ulazString = Math.Round(Math.Sin(double.Parse(ulazString)), 9).ToString();
        }
        private void Kosinus()
        {
            if (brojZnamenki == 0)
            {
                ulazString = Math.Round(Math.Cos(0), 9).ToString();
            }
            else  ulazString = Math.Round(Math.Cos(double.Parse(ulazString)), 9).ToString();
        }
        private void Tangens()
        {
            if (brojZnamenki == 0)
            {
                ulazString = Math.Round(Math.Tan(0), 9).ToString();
            }
            else ulazString = Math.Round(Math.Tan(double.Parse(ulazString)), 9).ToString();
        }
        private void Inverz()
        {
            if (ulazString == "")
            {
                if (prviOperand == "0") Error();
                else TrenutnoStanje = Math.Round((1.0 / double.Parse(prviOperand)), 9).ToString();
            }
            else if (ulazString == "0") Error();
            else ulazString = Math.Round((1.0 / double.Parse(ulazString)), 9).ToString();
        }
        private void Kvadrat()
        {
            ulazString = Math.Round(((double.Parse(ulazString))*(double.Parse(ulazString))), 9).ToString();
            if (double.Parse(ulazString) >= 10000000000) Error();
            
        }
        private void Korjen()
        {
            if (brojZnamenki == 0)
            {
                ulazString = Math.Round(Math.Sqrt(0), 9).ToString();
            }
            else
            ulazString =Math.Round( Math.Sqrt((double.Parse(ulazString))), 9).ToString();
        }
        private void Put()
        {
            Memorija = ulazString;
        }
        private void Get()
        {
            ulazString=Memorija;
        }
        private void ClearDisplay()
        {
            ulazString = "";
            brojZnamenki = 0;
          
        }
        private void On()
        {
            ulazString = "";
            brojZnamenki = 0;
            TrenutnoStanje = "0";
            prviOperand = null;
            drugiOperand = null;
            operacija = '$';
            Memorija = "";
            error = false;
        }
        private void PromjenaPredznaka()
        {
            if (brojZnamenki != 0)
            {
                if (ulazString[0] == '-')
                {
                    ulazString = ulazString.Substring(1, ulazString.Length - 1);


                }
                else ulazString = ulazString.Insert(0, "-");
            }
           
        }

        private void Error()
        {
            error = true;
            Rezultat = 0;
            TrenutnoStanje = "-E-";
            ulazString = "";
            brojZnamenki = 0;
            prviOperand = null;
            drugiOperand = null;
            operacija = '$';
        }
    }


}