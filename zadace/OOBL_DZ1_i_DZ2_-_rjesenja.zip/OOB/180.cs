﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string display = "0";
        private bool on = true;
        private string memory = "";
        private string queue = "";
        private double result = 0;
        private char lastIn = ' ';
        private bool doubleOper = false;


        public void Press(char inPressedDigit)
        {    
            if (on)
            {
                if (isError(inPressedDigit))
                    return;
                doubleOper = false;
                checkOper(inPressedDigit);
                //ako je dupla binarna, radi s novom i uredi red
                if (doubleOper)
                {
                    queue += inPressedDigit;
                    checkQueue();
                    return;
                }
                checkQueue();
                //ako je display 0 i nije unesena operacija
                if (display == "0" && !isBinary(inPressedDigit) && !isUnary(inPressedDigit) && inPressedDigit != '=')
                    display = inPressedDigit.ToString();
                else
                    //ako je operacija zabiljezi ju, ako nije dodaj u display
                    if (Operacije(inPressedDigit))
                    {
                        lastIn = inPressedDigit;
                        if (display[display.Length - 1] == '0' && display.Contains(','))
                            Zaokruzi();
                        return;
                    }
                    else 
                        display += inPressedDigit;

                //zaokruzuje se samo decimalan broj
                lastIn = inPressedDigit;
                if (display.Contains(','))
                    Zaokruzi();
                
            }           
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        private void Zaokruzi()
        {
            //izracunaj broj decimala i zaokruzi broj ako ima vise od 10 znamenaka
            if (display == "0")
                return;
            int digits = 0;
            int decimals = 0;
            string[] digDec = display.Split(',');
            if (digDec[0][0] == '-')
                digits = digDec[0].Count() - 1;
            else
                digits = digDec[0].Count();
            if(digDec.Count() == 2)
                decimals = digDec[1].Count();
            if (digits + decimals > 10)
                display = Math.Round(double.Parse(display), 10 - digits).ToString();
            //makni nepotrebne decimalne nule i po potrebi zarez
            if(display[display.Length-1] == '0' && lastIn != '0')
            for (int i = display.Length - 1; i >= 0; i--)
            {
                if (display[i] == '0')
                    display = display.Remove(i, 1);
                else
                    break;
            }
            if(display.Length > 1)
            if (display[display.Length - 1] == ',')
                display = display.Remove(display.Length - 1, 1);
            return;
        }
            
        private bool Operacije(char input)
        {
            switch (input)
            {
                case '+':
                    if (display != "=")
                        queue += display + "+";
                    return true;

                case '-':
                    if (display != "=")
                        queue += display + "-";
                    return true;

                case '*':
                    if (display != "=")
                        queue += display + "*";
                    return true;

                case '/':
                    if (display == "=")
                        return true;
                    if (display != "0")
                    {
                        queue += display + "/";
                    }
                    else
                    {
                        display = "-E-";
                        queue = "";
                    }
                    return true;

                case '=':
                    if (queue == "")
                        return true;
                    if (isBinary(lastIn))
                    {
                        string firstNum = findFirstNum();
                        queue += firstNum + "=";
                    }
                    else
                        queue += display + "=";
                    izvrsiOperacije();
                    return true;

                case ',':
                    display = display + ",";
                    return true;

                case 'M':
                    if (display[0] != '-')
                        display = '-' + display;
                    return true;

                case 'S':
                    display = Math.Sin(double.Parse(display)).ToString();
                    Zaokruzi();
                    return true;

                case 'T':
                    display = Math.Tan(double.Parse(display)).ToString();
                    Zaokruzi();
                    return true;

                case 'K':
                    display = Math.Cos(double.Parse(display)).ToString();
                    Zaokruzi();
                    return true;

                case 'Q':
                    display = Math.Pow(double.Parse(display), 2).ToString();
                    if (display.Count() > 10)
                        display = "-E-";
                    return true;

                case 'R':
                    if (int.Parse(display) >= 0)
                        display = Math.Sqrt(double.Parse(display)).ToString();
                    else
                        display = "-E-";
                    return true;

                case 'I':
                    if (display != "0")
                    {
                        display = (1 / double.Parse(display)).ToString();
                    }
                    else
                        display = "-E-";
                    return true;

                case 'P':
                    memory = display;
                    return true;

                case 'G':
                    display = memory;
                    return true;

                case 'C':
                    display = "0";
                    return true;

                case 'O':
                    on = !on;
                    display = "0";
                    memory = "";
                    queue = "";
                    lastIn = ' ';
                    result = 0;
                    doubleOper = false;
                    return true;

                default:
                    return false;
            }
        }

        private void izvrsiOperacije()
        {
            checkQueue();
            char lastOper = ' ';
            string operand = "";
            for (int i = 0; i < queue.Length; i++)
            {
                if (queue[i] == '+' || queue[i] == '-' || queue[i] == '/' || queue[i] == '*' || queue[i] == '=')
                    if (lastOper == ' ')
                    {
                        //ako nije predznak zapamti operaciju, broj i skrati red operacija
                        if (i > 0)
                        {
                            lastOper = queue[i];
                            result = double.Parse(queue.Substring(0, i));
                            queue = queue.Remove(0, i + 1);
                            i = 0;
                        }
                    }
                    else
                    {
                        operand = queue.Substring(0,i);
                        izracunajRez(lastOper,double.Parse(operand));
                        lastOper = queue[i];
                        queue = queue.Remove(0, i + 1);
                        i = 0;
                    }
            }
            queue = "";
            if (result < 10000000000)
            {
                display = result.ToString();
                Zaokruzi();
            }
            else
                display = "-E-";
            result = 0;
        }

        private void izracunajRez(char lastOper, double operand)
        {

            switch (lastOper)
            {
                case '+':
                    result += operand;
                    return;
                case '-':
                    result -= operand;
                    return;
                case '*':
                    result *= operand;
                    return;
                case '/':
                    result /= operand;
                    return;
            }
        }

        private void checkQueue()
        {
            queue = queue.Replace("++", "+");
            queue = queue.Replace("--", "+");
            queue = queue.Replace("**", "*");
            queue = queue.Replace("//", "/");

            for(int i = 0; i < queue.Length; i++)
            {
                if((i+1) < queue.Length)
                {
                    if (queue[i] == ',' && isBinary(queue[i + 1]))
                        queue = queue.Remove(i, 1);

                    if (isBinary(queue[i]) && isBinary(queue[i + 1]))
                        queue = queue.Remove(i, 1);
                }
            }
            
        }

        private bool isBinary(char inPress)
        {
            string operatons = "+-/*";
            if (operatons.Contains(inPress))
                return true;
            else
                return false;
        }
                    
        private bool isUnary(char inPress)
        {
            string functions = "STKQRIPGCO,";
            if(functions.Contains(inPress))
                return true;
            else
                return false;
        }

        private string findFirstNum()
        {
            for (int i = 1; i < queue.Length; i++)
            {
                if (isBinary(queue[i])) 
                    return queue.Substring(0, i);
            }
            return "";
        }

        private void checkOper(char inPressedDigit)
        {
            if (isBinary(lastIn) && isBinary(inPressedDigit))
                doubleOper = true;
            //binarne operacije
            if (isBinary(lastIn) && !isBinary(inPressedDigit) && queue != "" && !isUnary(inPressedDigit) && inPressedDigit != '=')
                display = "0";
            //unarne ostavljaju broj na zaslonu
            if (queue.Length > 1 && inPressedDigit != '=')
                if(isUnary(inPressedDigit) && !isUnary(lastIn) && !isBinary(lastIn))
                    return;
            //broj1 binarni unarni broj2
            if(queue.Length > 1)
                if (isUnary(lastIn) && isBinary(queue[queue.Length - 1]) && lastIn != ',' && !isUnary(inPressedDigit) && inPressedDigit != '=' && !isBinary(inPressedDigit))
                    display = "0";

        }

        //ako je -E- moze samo clear ili on/off
        private bool isError(char inPressedDigit)
        {
            string clearOn = "CO";
            if (display == "-E-" && !clearOn.Contains(inPressedDigit))
                return true;
            else
                return false;
        }
    }
}
