﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    using System.Globalization;
    using System.Text.RegularExpressions;

    // Calculator factory
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }

    /// <summary> Enum which holds type of a pressed key </summary>
    public enum InputTypeEnum
    {
        Digit,

        Point,

        UnaryOperator,

        BinaryOperator
    }

    /// <summary> Calculator class </summary>
    public class Calculator : ICalculator
    {
        /// <summary> Holds maxium number of digits on display </summary>
        private const int MaxDigits = 10;

        /// <summary> Holds number of digits currently on display </summary>
        private int digitCount = 0;

        /// <summary> Holds characters that are displayed </summary>
        private string displayState;

        /// <summary> Holds error string </summary>
        private const string Error = "-E-";

        /// <summary> Holds calculation reuslt </summary>
        private string result;

        /// <summary> Holds pending operation </summary>
        private char pendingOperation = '\0';

        /// <summary> Holds second operand </summary>
        private string secondOperand;

        /// <summary> Holds clear flag - if true clear display </summary>
        private bool clear;

        /// <summary> Holds type of a last pressed key </summary>
        private InputTypeEnum lastPressedType;

        /// <summary> Holds last pressed key </summary>
        private string lastPressedKey = "0";
        
        /// <summary> Holds number stored in calculator memory </summary>
        private string memory;

        /// <summary> Constructor </summary>
        public Calculator()
        {
            this.displayState = "0";
            this.result = "0";
            this.clear = false;
        }

        /// <summary> Gets current display state - interface method implementation. </summary>
        /// <returns>Current display state.</returns>
        public string GetCurrentDisplayState()
        {
            return this.displayState;
        }

        /// <summary> Presses the key - interface method implementation. </summary>
        /// <param name="inPressedDigit"></param>
        public void Press(char inPressedDigit)
        {
            // Gets type of a pressed digit
            var type = this.InputType(inPressedDigit);

            // if calculator was in state of error, disable some functionalities
            if (this.displayState == Error)
            {
                if (inPressedDigit == 'C') return;
                if (type == InputTypeEnum.BinaryOperator) return;
                if (type == InputTypeEnum.UnaryOperator) return;

                this.secondOperand = null;
                this.pendingOperation = '\0';
                this.result = "0";
                this.displayState = "0";
            }

            // remember only last pressed binary operator
            if (this.lastPressedType == InputTypeEnum.BinaryOperator && type == InputTypeEnum.BinaryOperator)
            {
                this.pendingOperation = inPressedDigit;
                return;
            }

            // disable appending digits or point to result of an unary operation
            if (Regex.IsMatch(this.lastPressedKey, @"[SKTQRI]") && (type == InputTypeEnum.Point || type == InputTypeEnum.Digit) )
            {
                this.displayState = "0";
            }

            this.lastPressedType = type;
            this.lastPressedKey = "" + inPressedDigit;
            
            switch (type)
            {
                case InputTypeEnum.Digit:
                    if (this.clear)
                    {
                        this.clear = false;
                        this.displayState = "0";
                    }
                    if (this.digitCount == MaxDigits) return;
                    if (this.displayState == "0" && inPressedDigit == '0') return;
                    if (this.displayState == "0")
                    {
                        this.displayState = "" + inPressedDigit;
                    }
                    else
                    {
                        this.displayState += inPressedDigit;
                    }
                    ++this.digitCount;
                    break;
                case InputTypeEnum.Point:
                    {
                        var isPointPressed = this.displayState.Contains(",");
                        if (!isPointPressed) this.displayState += ",";
                    }
                    break;
                case InputTypeEnum.UnaryOperator:
                    {
                        if (inPressedDigit != 'M')
                        {
                            this.digitCount = 0;
                        }

                        var n = double.Parse(this.displayState);

                        switch (inPressedDigit)
                        {
                            case 'M':
                                if (this.displayState == "0") return;
                                if (this.displayState[0] != '-') this.displayState = "-" + this.displayState;
                                else this.displayState = this.displayState.Substring(1);
                                break;
                            case 'O':
                                this.displayState = "0";
                                this.secondOperand = null;
                                this.pendingOperation = '\0';
                                this.memory = null;
                                this.lastPressedKey = "0";
                                this.digitCount = 0;
                                break;
                            case 'C':
                                this.displayState = "0";
                                break;
                            case 'S':
                                this.displayState = Math.Sin(n).ToString(CultureInfo.InvariantCulture).Replace('.', ',');
                                break;
                            case 'K':
                                this.displayState = Math.Cos(n).ToString(CultureInfo.InvariantCulture).Replace('.', ',');
                                break;
                            case 'T':
                                this.displayState = Math.Tan(n).ToString(CultureInfo.InvariantCulture).Replace('.', ',');
                                break;
                            case 'Q':
                                this.displayState = (n * n).ToString(CultureInfo.InvariantCulture).Replace('.',',');
                                break;
                            case 'R':
                                var root = Math.Sqrt(n);
                                this.displayState = double.IsNaN(root) || double.IsPositiveInfinity(root)
                                                        ? Error
                                                        : (root).ToString(CultureInfo.InvariantCulture).Replace('.', ',');

                                break;
                            case 'I':
                                n = 1 / n;
                                this.displayState = double.IsInfinity(n)
                                                        ? Error
                                                        : (n).ToString(CultureInfo.InvariantCulture).Replace('.', ',');
                                break;
                            case 'P':
                                this.memory = this.displayState;
                                break;
                            case 'G':
                                this.displayState = this.memory;
                                break;
                            case '=':
                                this.digitCount = 0;
                                this.clear = true;
                                this.secondOperand = this.displayState;
                                this.Evaluate();
                                this.pendingOperation = inPressedDigit;                        
                                break;
                        }

                        this.Round();
                    }
                    break;
                case InputTypeEnum.BinaryOperator:
                    this.digitCount = 0;
                    this.clear = true;
                    this.secondOperand = this.displayState;
                    this.Evaluate();
                    this.pendingOperation = inPressedDigit;
                    break;
            }
        }

        /// <summary> Gets the type of a pressed key {digit, point, unary op, binary op} </summary>
        /// <param name="c"></param>
        /// <returns>Type of a pressed key.</returns>
        private InputTypeEnum InputType(char c)
        {
            var type = InputTypeEnum.Digit;
            if (c == ',') type = InputTypeEnum.Point;
            if (Regex.IsMatch(c.ToString(CultureInfo.InvariantCulture), @"[\+\-\*\/]")) type = InputTypeEnum.BinaryOperator;
            if (Regex.IsMatch(c.ToString(CultureInfo.InvariantCulture), @"[MSKTQRIPGCO=]")) type = InputTypeEnum.UnaryOperator;

            return type;
        }

        /// <summary>
        /// Does expression evaluation
        /// </summary>
        private void Evaluate()
        {
            if (this.pendingOperation == '\0')
            {
                this.result = this.displayState;
                return;
            }

            this.clear = true;
            var a = double.Parse(this.result);
            var b = double.Parse(this.secondOperand);

            switch (this.pendingOperation)
            {
                case '+':
                    this.result = (a + b).ToString(CultureInfo.InvariantCulture);
                    break;
                case '-':
                    this.result = (a - b).ToString(CultureInfo.InvariantCulture);
                    break;
                case '*':
                    this.result = (a * b).ToString(CultureInfo.InvariantCulture);
                    break;
                case '/':
                    this.result = double.IsInfinity(a / b) ? Error : (a / b).ToString(CultureInfo.InvariantCulture);
                    break;
            }

            this.result = this.result.Replace(".", ",");
            this.displayState = this.result;
            var digits = this.displayState.Count(char.IsDigit);
            if (digits > MaxDigits)
            {
                this.displayState = Error;
            }
        }

        /// <summary>
        /// Rounds number to fit on screen
        /// </summary>
        private void Round()
        {
            // do not try to round if error occured
            if (this.displayState == Error) return;

            // try to remove trailing zeroes
            this.displayState = double.Parse(this.displayState).ToString(CultureInfo.InvariantCulture).Replace(".", ",");
            
            // round number (max 10 digits!)
            var pointPos = this.displayState.IndexOf(",", StringComparison.Ordinal);
            if (pointPos > -1)
            {
                // round!
                var wholePartLenght = this.displayState.Substring(0, pointPos).Length;
                if (this.displayState[0] == '-') --wholePartLenght;
                var fractionLenght = MaxDigits - wholePartLenght;
                var n = double.Parse(this.displayState);
                n = Math.Round(n, fractionLenght);
                this.displayState = n.ToString(CultureInfo.InvariantCulture).Replace(".", ",");
            }
        }
    }
}
