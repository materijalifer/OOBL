﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private StockRepository _stockRepository;
        private IndexRepository _indexRepository;
        private PortfolioRepository _portfolioRepository;

        public StockExchange()
        {
            _stockRepository = new StockRepository();
            _indexRepository = new IndexRepository();
            _portfolioRepository = new PortfolioRepository();
        }
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockRepository.AddStock(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }
        public void DelistStock(string inStockName)
        {
            _stockRepository.RemoveStock(inStockName);
            _indexRepository.RemoveStockFromAllIndices(_stockRepository.GetByName(inStockName));
            _portfolioRepository.RemoveStockFromAllPortfolios(_stockRepository.GetByName(inStockName));
        }
        public bool StockExists(string inStockName)
        {
            return _stockRepository.StockExists(inStockName);
        }
        public int NumberOfStocks()
        {
            return _stockRepository.NumberOfStocks();
        }
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            _stockRepository.GetByName(inStockName).SetStockPrice(inIimeStamp, inStockValue);
        }
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockRepository.GetByName(inStockName).GetStockPrice(inTimeStamp);
        }
        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockRepository.GetByName(inStockName).GetInitialStockPrice();
        }
        public decimal GetLastStockPrice(string inStockName)
        {
            return _stockRepository.GetByName(inStockName).GetLastStockPrice();
        }
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indexRepository.AddIndex(new Index(inIndexName, inIndexType));
        }
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock requested = _stockRepository.GetByName(inStockName);
            _indexRepository.GetByName(inIndexName).AddStockToIndex(requested);
        }
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock requested = _stockRepository.GetByName(inStockName);
            _indexRepository.GetByName(inIndexName).RemoveStock(requested);
        }
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _indexRepository.GetByName(inIndexName).IsStockPartOfIndex(inStockName);
        }
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return _indexRepository.GetByName(inIndexName).GetValue(inTimeStamp);
        }
        public bool IndexExists(string inIndexName)
        {
            return _indexRepository.indexExists(inIndexName);
        }
        public int NumberOfIndices()
        {
            return _indexRepository.NumberOfIndices();
        }
        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _indexRepository.GetByName(inIndexName).NumberOfStocks();
        }
        public void CreatePortfolio(string inPortfolioID)
        {
            _portfolioRepository.AddPortfolio(new Portfolio(inPortfolioID));
        }
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock requestedStock = _stockRepository.GetByName(inStockName);

            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Nemoguće dodati u portfelje negativan broj dionica niti 0 dionica");
            }
            if ((_portfolioRepository.GetNumberOfStocksInAllPortfolios(inStockName) + numberOfShares) <= requestedStock.NumberOfShares)
            {
                _portfolioRepository.GetByID(inPortfolioID).AddStockToPortfolio(requestedStock, numberOfShares);
            }
            else
            {
                throw new StockExchangeException("Nemoguće dodati u portfelje više dionica nego postoji na burzi");
            }
        }
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock requestedStock = _stockRepository.GetByName(inStockName);
            _portfolioRepository.GetByID(inPortfolioID).RemoveStockFromPortfolio(requestedStock, numberOfShares);

        }
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Stock requestedStock = _stockRepository.GetByName(inStockName);
            _portfolioRepository.GetByID(inPortfolioID).RemoveStockFromPortfolio(requestedStock);
        }
        public int NumberOfPortfolios()
        {
            return _portfolioRepository.NumberOfPortfolios();
        }
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _portfolioRepository.GetByID(inPortfolioID).NumberOfStocksInPortfolio();
        }
        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioRepository.PortfolioExists(inPortfolioID);
        }
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioRepository.GetByID(inPortfolioID).IsStockPartOfPortfolio(inStockName);
        }
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioRepository.GetByID(inPortfolioID).NumberOfSharesOfStockInPortfolio(inStockName);
        }
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return _portfolioRepository.GetByID(inPortfolioID).GetPortfolioValue(timeStamp);
        }
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            //DateTime yearAndMonth = new DateTime(Year, Month,1);
            return _portfolioRepository.GetByID(inPortfolioID).GetPortfolioPercentChangeInValueForMonth(new DateTime(Year, Month, 1));
        }
    }

    public class StockRepository
    {
        List<Stock> _listOfStocks = new List<Stock>();
        //        private static StockRepository _instance = null;
        //public static StockRepository getInstance()
        //{
        //    if (_instance == null)
        //        _instance = new StockRepository();
        //    return new StockRepository(); 
        //}

        public void AddStock(Stock stock)
        {
            if (StockExists(stock.StockName))
            {
                throw new StockExchangeException("Dionica već postoji");
            }
            else
            {
                _listOfStocks.Add(stock);
            }
        }
        public int NumberOfStocks()
        {
            return _listOfStocks.Count;
        }
        public bool StockExists(string inStockName)
        {
            bool stockExists = false;
            foreach (Stock s in _listOfStocks)
            {
                if (s.StockName.ToUpper() == inStockName.ToUpper()) stockExists = true;
            }
            return stockExists;
        }
        public Stock GetByName(string StockName)
        {
            foreach (Stock s in _listOfStocks)
            {
                if (StockName.ToUpper() == s.StockName.ToUpper()) return s;

            }
            throw new StockExchangeException("Dionica ne postoji");
        }
        public void RemoveStock(string inStockName)
        {
            bool notRemoved = true;
            foreach (Stock s in _listOfStocks)
            {
                if (s.StockName.ToUpper() == inStockName.ToUpper())
                {
                    _listOfStocks.Remove(s);
                    notRemoved = false;
                    break;
                }
                if (notRemoved) throw new StockExchangeException("Dionica nije izbrisana");
            }
        }
    }

    public class IndexRepository
    {
        List<Index> _listIndices = new List<Index>();

        public void RemoveStockFromAllIndices(Stock stock)
        {
            foreach (Index index in _listIndices)
            {
                index.RemoveStock(stock);
            }
        }
        public void AddIndex(Index index)
        {
            if (!indexExists(index.IndexName))
            {
                _listIndices.Add(index);
            }
            else
            {
                throw new StockExchangeException("Index već postoji");
            }
        }
        public int NumberOfIndices()
        {
            return _listIndices.Count;
        }
        public bool indexExists(string indexName)
        {
            bool indexExists = false;
            foreach (Index s in _listIndices)
            {
                if (s.IndexName.ToUpper() == indexName.ToUpper()) indexExists = true;
            }
            return indexExists;
        }
        public Index GetByName(string indexName)
        {
            foreach (Index s in _listIndices)
            {
                if (indexName.ToUpper() == s.IndexName.ToUpper())
                {
                    return s;
                }
            }
            throw new StockExchangeException("Index ne postoji");
        }
    }

    public class PortfolioRepository
    {
        List<Portfolio> _listPortfolios = new List<Portfolio>();

        public void AddPortfolio(Portfolio portfolio)
        {
            if (PortfolioExists(portfolio.IdPortfolio))
            {
                throw new StockExchangeException("Portfelj već postoji");
            }
            else
            {
                _listPortfolios.Add(portfolio);
            }
        }
        public int NumberOfPortfolios()
        {
            return _listPortfolios.Count;
        }
        public bool PortfolioExists(string idPortfolio)
        {
            bool portfolioExists = false;
            foreach (Portfolio p in _listPortfolios)
            {
                if (p.IdPortfolio == idPortfolio) portfolioExists = true;
            }
            return portfolioExists;
        }
        public Portfolio GetByID(string idPortfolio)
        {
            foreach (Portfolio p in _listPortfolios)
            {
                if (idPortfolio == p.IdPortfolio) return p;

            }
            throw new StockExchangeException("Portfelj ne postoji");
        }
        public void RemoveStockFromAllPortfolios(Stock stock)
        {
            foreach (Portfolio p in _listPortfolios)
            {
                p.RemoveStockFromPortfolio(stock);
            }
        }
        public int GetNumberOfStocksInAllPortfolios(String inStockName)
        {
            int numberOfStocks = 0;
            foreach (Portfolio p in _listPortfolios)
            {
                numberOfStocks += p.NumberOfSharesOfStockInPortfolio(inStockName);
            }
            return numberOfStocks;
        }
    }

    public class Stock
    {
        private string _stockName;
        //private decimal _initialPrice;
        //private DateTime initialTime;
        private long _numberOfShares;
        private Dictionary<DateTime, decimal> _stockValues = new Dictionary<DateTime, decimal>();
        private DateTime _initialTime()//vrijeme s najmanjom vrijednosti, nisam bio siguran dali smijem koristit prvo vrijeme (kad se dodala dionica)
        {
            DateTime startTime = DateTime.Now;
            foreach (KeyValuePair<DateTime, decimal> pair in _stockValues)
            {
                if (pair.Key <= startTime)
                {
                    startTime = pair.Key;
                }
            }
            return startTime;
        }

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0) throw new StockExchangeException("Cijena manja od 0");
            if (inNumberOfShares <= 0) throw new StockExchangeException("Nemoguće dodati negativan broj dionica ili 0 dionica");
            this._stockName = inStockName;
            this._numberOfShares = inNumberOfShares;
            //this._initialPrice = inInitialPrice;
            //this.timeStamp = inTimeStamp;
            _stockValues.Add(inTimeStamp, inInitialPrice);
        }
        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }
        public string StockName
        {
            get { return _stockName; }
            set { _stockName = value; }
        }
        public void SetStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (_initialTime() > inTimeStamp) throw new StockExchangeException("nije moguće zadati vrijednost za vrijeme prije dodavanja na burzu");
            _stockValues.Add(inTimeStamp, inStockValue);
        }
        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            if (_initialTime() > inTimeStamp) throw new StockExchangeException("nije moguće dobiti vrijednost za vrijeme prije dodavanja na burzu");

            //Vraca cijenu za zadani datum
            KeyValuePair<DateTime, decimal> searchedPair = _stockValues.First();
            foreach (KeyValuePair<DateTime, decimal> pair in _stockValues)
            {
                if (pair.Key <= inTimeStamp && pair.Key >= searchedPair.Key) searchedPair = pair;
            }
            return searchedPair.Value;
        }
        public decimal GetInitialStockPrice()
        {
            decimal initialPrice = 0;
            foreach (KeyValuePair<DateTime, decimal> pair in _stockValues)
            {
                DateTime startTime = DateTime.Now;
                if (pair.Key <= startTime)
                {
                    startTime = pair.Key;
                    initialPrice = pair.Value;
                }
            }
            return initialPrice;
        }
        public decimal GetLastStockPrice()
        {
            return GetStockPrice(DateTime.Now);
            //KeyValuePair<DateTime, decimal> searchedPair = stockValues.Last();
            //foreach (KeyValuePair<DateTime, decimal> pair in stockValues)
            //{
            //    if (pair.Key > searchedPair.Key) searchedPair = pair;
            //}
            //return searchedPair.Value;
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<Stock> _listOfStocks = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.IndexName = inIndexName;
            this._indexType = inIndexType;
        }
        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }
        public void AddStockToIndex(Stock stock)
        {
            if (IsStockPartOfIndex(stock.StockName))
            {
                throw new StockExchangeException("Dionica već postoji");
            }
            else
            {
                _listOfStocks.Add(stock);
            }
        }
        public bool IsStockPartOfIndex(string inStockName)
        {
            bool isStockPartOfIndex = false;
            foreach (Stock s in _listOfStocks)
            {
                if (s.StockName.ToUpper() == inStockName.ToUpper())
                {
                    isStockPartOfIndex = true;
                    break;
                }
            }
            return isStockPartOfIndex;
        }
        public int NumberOfStocks()
        {
            return _listOfStocks.Count;
        }
        public void RemoveStock(Stock stock)
        {
            _listOfStocks.Remove(stock);
        }
        public decimal GetValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal sumWeighted = 0;
            switch (_indexType)
            {
                case IndexTypes.AVERAGE:
                    {

                        foreach (Stock s in _listOfStocks)
                        {
                            sum += s.GetStockPrice(inTimeStamp);
                        }
                        return Math.Round((sum / _listOfStocks.Count), 3);
                    }
                case IndexTypes.WEIGHTED:
                    {
                        foreach (Stock s in _listOfStocks)
                        {
                            sum += s.GetStockPrice(inTimeStamp) * s.NumberOfShares;
                        }
                        foreach (Stock s in _listOfStocks)
                        {
                            sumWeighted += s.NumberOfShares * s.GetStockPrice(inTimeStamp) / sum * s.GetStockPrice(inTimeStamp);
                        }
                        return Math.Round(sumWeighted, 3);
                    }
                default:
                    {
                        throw new StockExchangeException("Nije moguće stvoriti index tog tipa");
                    }
            }
        }
    }

    public class Portfolio
    {
        private string _idPortfolio;
        private Dictionary<Stock, int> _listOfStocksAndNumberOfShares = new Dictionary<Stock, int>();

        public Portfolio(string idPortfolio)
        {
            this._idPortfolio = idPortfolio;
        }
        public string IdPortfolio
        {
            get { return _idPortfolio; }
            set { _idPortfolio = value; }
        }
        public void AddStockToPortfolio(Stock stock, int numberOfShares)
        {
            if (IsStockPartOfPortfolio(stock.StockName))
            {
                int numOfStockBeforeAddingNew;
                foreach (KeyValuePair<Stock, int> pair in _listOfStocksAndNumberOfShares)
                {
                    if (pair.Key.StockName.ToUpper() == stock.StockName.ToUpper())
                    {
                        numOfStockBeforeAddingNew = pair.Value;
                        _listOfStocksAndNumberOfShares.Remove(stock);
                        AddStockToPortfolio(stock, (numberOfShares + numOfStockBeforeAddingNew));
                        break;
                    }
                }
            }
            else
            {
                _listOfStocksAndNumberOfShares.Add(stock, numberOfShares);
            }
        }
        public bool IsStockPartOfPortfolio(string inStockName)
        {
            bool isStockPartOfPortfolio = false;
            foreach (KeyValuePair<Stock, int> pair in _listOfStocksAndNumberOfShares)
            {
                if (pair.Key.StockName.ToUpper() == inStockName.ToUpper())
                {
                    isStockPartOfPortfolio = true;
                    break;
                }
            }
            return isStockPartOfPortfolio;
        }
        public void RemoveStockFromPortfolio(Stock stock, int numberOfSharesForRemove)
        {
            //AddStockToPortfolio(stock, (numberOfShares * -1));
            if (IsStockPartOfPortfolio(stock.StockName))
            {
                int numOfStockBeforeRemoving;
                foreach (KeyValuePair<Stock, int> pair in _listOfStocksAndNumberOfShares)
                {
                    if (pair.Key.StockName.ToUpper() == stock.StockName.ToUpper())
                    {
                        numOfStockBeforeRemoving = pair.Value;
                        _listOfStocksAndNumberOfShares.Remove(stock);
                        int newNumberOfShares = numOfStockBeforeRemoving - numberOfSharesForRemove;
                        if (newNumberOfShares > 0)
                        {
                            AddStockToPortfolio(stock, (newNumberOfShares));
                        }
                        else if (newNumberOfShares < 0)
                        {
                            throw new StockExchangeException("Nije moguće obrisati broj dionica veći od broja dionica u portfelju");
                        }
                        break;
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Dionica nije dio portfelja");
            }
        }
        public void RemoveStockFromPortfolio(Stock stock)
        {
            _listOfStocksAndNumberOfShares.Remove(stock);
        }
        public int NumberOfStocksInPortfolio()
        {
            return _listOfStocksAndNumberOfShares.Count;
        }
        public int NumberOfSharesOfStockInPortfolio(string stockName)
        {
            if (IsStockPartOfPortfolio(stockName))
            {
                foreach (KeyValuePair<Stock, int> pair in _listOfStocksAndNumberOfShares)
                {
                    if (pair.Key.StockName == stockName) return pair.Value;
                }
                return 0;
            }
            else
            {
                return 0;
            }
        }
        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal sumValues = 0;
            foreach (KeyValuePair<Stock, int> pair in _listOfStocksAndNumberOfShares)
            {
                sumValues += (pair.Value * pair.Key.GetStockPrice(timeStamp));
            }
            return Math.Round(sumValues, 3);
        }
        public decimal GetPortfolioPercentChangeInValueForMonth(DateTime yearAndMonth)
        {
            decimal change;
            int Year = yearAndMonth.Year;
            int Month = yearAndMonth.Month;
            decimal startValue = GetPortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
            decimal endValue = GetPortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            change = (endValue / startValue - 1) * 100;
            return Math.Round(change, 3);
        }
    }


}
