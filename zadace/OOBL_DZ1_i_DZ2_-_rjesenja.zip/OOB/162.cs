﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string ekran;
        string memorija;
        Stack<string> stog;

        // varijabla je true ako se očekiva unos novog broja
        // na primjer na početku rada ili nakon izračunavanja neke operacije
        bool noviBroj;


        public Kalkulator()
        {
            ekran = "0";
            memorija = "0";
            stog = new Stack<string>();

            noviBroj = true;
        }


        public void Press(char inPressedDigit)
        {
            // unešen je broj?
            if (char.IsNumber(inPressedDigit))
            {
                if (ekran == "0")
                {
                    ekran = inPressedDigit.ToString();
                    noviBroj = false;
                }
                else if (noviBroj == true)
                {
                    ekran = inPressedDigit.ToString();
                    noviBroj = false;
                }
                else if (brojZnamenki(ekran) < 10)
                {
                    ekran = ekran + inPressedDigit;
                }
            }
            // ako nije unešen broj, onda je pozvana funkcija
            else
            {
                funkcija(inPressedDigit.ToString());
            }
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }


        private void funkcija(string funkcija)
        {
            switch (funkcija)
            {
                case ",":
                    zarez();
                    break;
                case "C":
                    clear();
                    break;
                case "M":
                    promjenaPredznaka();
                    break;
                case "O":
                    reset();
                    break;
                case "P":
                    put();
                    break;
                case "G":
                    get();
                    break;
                case "S":
                    sinus();
                    break;
                case "K":
                    kosinus();
                    break;
                case "T":
                    tangens();
                    break;
                case "Q":
                    quadrat();
                    break;
                case "R":
                    root();
                    break;
                case "I":
                    invers();
                    break;
                case "-":
                    oduzimanje();
                    noviBroj = true;
                    break;
                case "+":
                    zbrajanje();
                    noviBroj = true;
                    break;
                case "*":
                    mnozenje();
                    noviBroj = true;
                    break;
                case "/":
                    dijeljenje();
                    noviBroj = true;
                    break;
                case "=":
                    ekran = racunaj();
                    break;
                default:
                    break;
            }
        }

        // funkcija koja se poziva kad se računa neki rezultat i potrebno ga je prikazati na ekranu
        private string racunaj()
        {
            // događa se kad je unešen znak jednakosti, ali ne broj i operacija
            if (stog.Count == 0)
            {
                return skrati(ekran);
            }

            // s stoga se uzima opetator i operandi
            double rezBr = 0;
            string rezStr = "";
            double drugi = Convert.ToDouble(ekran);
            string operacija = stog.Pop();
            double prvi = Convert.ToDouble(stog.Pop());

            switch (operacija)
            {
                case "-":
                    rezBr = prvi - drugi;
                    break;
                case "+":
                    rezBr = prvi + drugi;
                    break;
                case "*":
                    rezBr = prvi * drugi;
                    break;
                case "/":
                    rezBr = prvi / drugi;
                    break;
            }

            // potrebno je rezultat zaokružiti na 9 decimala
            rezBr = Math.Round(rezBr, 9);

            // ako se rezultat ne može prikazati na ekranu prikaži oznaku greške
            // pokriva i dijeljenje s 0 (rezultat je beskonačan)
            if (rezBr > 9999999999)
            {
                rezStr = "-E-";
                return rezStr;
            }

            rezStr = rezBr.ToString();
            return skrati(rezStr);
        }

        // ako su iza zareza sve nule, briši i njega i njih
        private string skrati(string broj)
        {
            bool krati = true;
            string noviBroj = broj;
            int indeksZareza = broj.IndexOf(',');
            if (indeksZareza != -1)
            {
                for (int i = (indeksZareza + 1); i < broj.Length; i++)
                {
                    if (broj.ElementAt(i) != '0')
                    {
                        krati = false;
                        break;
                    }
                }

                if (krati == true)
                {
                    noviBroj = ekran.Substring(0, indeksZareza);
                }
            }

            return noviBroj;
        }

        // prije operacija zbrajanja, oduzimanja, dijeljenja i množenja
        // po potrebi se skrati sadržaj ekrana 
        private void dijeljenje()
        {
            ekran = skrati(ekran);
            if (stog.Count == 0)
            {
                stog.Push(ekran);
                stog.Push("/");
            }
            else if (noviBroj == true)
            {
                stog.Pop();
                stog.Push("/");
            }
            else
            {
                stog.Push(racunaj());
                stog.Push("/");
            }
        }

        private void mnozenje()
        {
            ekran = skrati(ekran);
            if (stog.Count == 0)
            {
                stog.Push(ekran);
                stog.Push("*");
            }
            else if (noviBroj == true)
            {
                stog.Pop();
                stog.Push("*");
            }
            else
            {
                stog.Push(racunaj());
                stog.Push("*");
            }
        }

        private void zbrajanje()
        {
            ekran = skrati(ekran);
            if (stog.Count == 0)
            {
                stog.Push(ekran);
                stog.Push("+");
            }
            else if (noviBroj == true)
            {
                stog.Pop();
                stog.Push("+");
            }
            else
            {
                stog.Push(racunaj());
                stog.Push("+");
            }
        }

        private void oduzimanje()
        {
            ekran = skrati(ekran);
            if (stog.Count == 0)
            {
                stog.Push(ekran);
                stog.Push("-");
            }
            else if (noviBroj == true)
            {
                stog.Pop();
                stog.Push("-");
            }
            else
            {
                stog.Push(racunaj());
                stog.Push("-");
            }
        }

        private void invers()
        {
            // dijeljenje s 0
            if (ekran == "0")
            {
                ekran = "-E-";
            }
            else
            {
                ekran = (1 / Convert.ToDouble(ekran)).ToString();
            }
        }

        private void sinus()
        {
            ekran = Math.Round(Math.Sin(Convert.ToDouble(ekran)), 9).ToString();
        }

        private void kosinus()
        {
            ekran = Math.Round(Math.Cos(Convert.ToDouble(ekran)), 9).ToString();
        }

        private void tangens()
        {
            ekran = Math.Round(Math.Tan(Convert.ToDouble(ekran)), 9).ToString();
        }

        private void quadrat()
        {
            ekran = (Convert.ToDouble(ekran) * Convert.ToDouble(ekran)).ToString();
        }

        public void root()
        {
            ekran = Math.Round(Math.Sqrt(Convert.ToDouble(ekran)), 9).ToString();

            // korjenovanje negativnog broja
            if (ekran == "NaN")
            {
                ekran = "-E-";
            }
        }

        private void put()
        {
            memorija = ekran;
        }

        private void get()
        {
            ekran = memorija;
        }

        private void reset()
        {
            ekran = "0";
            memorija = "0";
            stog.Clear();
        }

        private void clear()
        {
            ekran = "0";
        }

        private void promjenaPredznaka()
        {
            if (ekran.ElementAt(0) == '-')
            {
                ekran = ekran.Substring(1);
            }
            else
            {
                ekran = "-" + ekran;
            }
        }

        private void zarez()
        {
            if ((brojZnamenki(ekran) < 10) && (postojiZarez(ekran) == false))
            {
                ekran = ekran + ",";
                noviBroj = false;
            }
        }

        private bool postojiZarez(string broj)
        {
            bool postoji = false;

            for (int i = 0; i < broj.Length; i++)
            {
                if (broj.ElementAt(i) == ',')
                {
                    postoji = true;
                    break;
                }
            }

            return postoji;
        }

        private int brojZnamenki(string broj)
        {
            int brojac = 0;
            for (int i = 0; i < broj.Length; i++)
            {
                if (char.IsNumber(broj.ElementAt(i))) brojac++;
            }
            return brojac;
        }

    }

}
