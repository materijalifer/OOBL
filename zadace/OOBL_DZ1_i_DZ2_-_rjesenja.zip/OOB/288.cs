﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
     
     public class Stock
     {
         private string _stockName = String.Empty;
         private long _numOfShares = 0;
         private decimal _initialPrice = 0;
         private SortedDictionary<DateTime, decimal> _priceDict = new SortedDictionary<DateTime, decimal>();

         public Stock(string Name, long Number, decimal Price, DateTime Time)
         {
             _stockName = Name;
             _numOfShares = Number;
             _priceDict.Add(Time, Price);
             _initialPrice = Price;
         }

         public string Name
         {
             get { return _stockName; }
         }

         public long NumberOfShares
         {
             get { return _numOfShares; }
         }

         internal void EditStockPrice(DateTime inTimeStamp, decimal inStockValue)
         {
             if (this._priceDict.ContainsKey(inTimeStamp))
                 throw new StockExchangeException("Za zadano vrijeme postoji definirana cijena");
             else 
                 this._priceDict.Add(inTimeStamp, inStockValue);
         }

         internal decimal GetStockPrice(DateTime inTimeStamp)
         {
             DateTime selectedDateTime = DateTime.MinValue;
             foreach (KeyValuePair<DateTime, decimal> priceEntry in this._priceDict)
             {
                 if (priceEntry.Key <= inTimeStamp && priceEntry.Key > selectedDateTime)
                     selectedDateTime = priceEntry.Key;
             }
             if (selectedDateTime == DateTime.MinValue)
                 throw new StockExchangeException("Ne postoji definirana cijena za odabrano vrijeme.");
             else
                 return this._priceDict.Where(x => x.Key == selectedDateTime).FirstOrDefault().Value;
         }

         internal decimal GetInitialPrice()
         {
             return this._initialPrice;
         }

         internal DateTime GetOldestTimeStamp()
         {
             return this._priceDict.Keys.Min();
         }
     }

     public interface IIndexvalue
     {
         decimal GetIndexValue(DateTime inTimeStamp);
     }

     public class Index
     {

         public static int NUMBER_OF_DIGITS = 3;
         protected string _indexName = String.Empty;
         protected List<Stock> _stockList = new List<Stock>();

         public Index(string Name)
         {
             this._indexName = Name;
         }

         public string Name 
         {
             get { return _indexName; }
         }

         internal void AddStock(Stock s)
         {
             this._stockList.Add(s);
         }

         internal void RemoveStock(Stock s)
         {
             this._stockList.Remove(s);
         }

         internal bool ContainsStock(Stock s)
         {
             return this._stockList.Contains(s);
         }

         internal int GetStockCount()
         {
             return this._stockList.Count;
         }
     }

     public class WeightedIndex : Index, IIndexvalue
     {
         internal WeightedIndex(string Name) : base(Name) { }

         public decimal GetIndexValue(DateTime inTimeStamp)
         {
             decimal sum = 0;
             decimal weightedSum = 0;

             foreach (Stock s in this._stockList) 
                 sum += s.GetStockPrice(inTimeStamp) * s.NumberOfShares;

             foreach (Stock s in this._stockList) 
                 weightedSum += Convert.ToDecimal((Math.Pow(Convert.ToDouble(s.GetStockPrice(inTimeStamp)), 2) * s.NumberOfShares)) / sum;

             return Math.Round(weightedSum, NUMBER_OF_DIGITS);
         }
     }

     public class AverageIndex : Index, IIndexvalue
     {
         internal AverageIndex(string Name) : base(Name) { }

         public decimal GetIndexValue(DateTime inTimeStamp)
         {
             decimal sum = 0;
             foreach (Stock s in this._stockList) sum += s.GetStockPrice(inTimeStamp);

             return Math.Round(sum, NUMBER_OF_DIGITS);
         }
     }

     public class Portfolio
     {
         private string _portfolioID = String.Empty;
         private Dictionary<Stock, int> _stockDict = new Dictionary<Stock, int>();

        public Portfolio(string ID)
         {
             _portfolioID = ID;
         }

         public string PortfolioID
         {
             get { return _portfolioID; }
         }

         internal bool ContainsStock(Stock s)
         {
             return this._stockDict.ContainsKey(s);
         }

         internal int GetStockShareNumber(Stock s)
         {
             return this._stockDict.Where(x => x.Key == s).FirstOrDefault().Value;
         }

         internal void AddStock(Stock s, int totalNumOfShares)
         {
             if (this._stockDict.ContainsKey(s)) this._stockDict.Remove(s);
             _stockDict.Add(s, totalNumOfShares);
         }

         internal void RemoveStock(Stock s)
         {
             this._stockDict.Remove(s);
         }

         internal int GetNumberOfStocks()
         {
             return this._stockDict.Count;
         }

         internal decimal GetPortfolioValue(DateTime timeStamp)
         {
             decimal sum = 0M;
             foreach (KeyValuePair<Stock, int> pair in this._stockDict)
             {
                 sum += pair.Key.GetStockPrice(timeStamp) * pair.Value;
             }
             return Math.Round(sum, Index.NUMBER_OF_DIGITS);
         }
     }

     public class StockExchange : IStockExchange
     {
         List<Stock> _seStockList = new List<Stock>();
         List<Index> _seIndexList = new List<Index>();
         List<Portfolio> _sePortfolioList = new List<Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberOfShares <= 0 || inInitialPrice <= 0) throw new StockExchangeException("Cijena i broj dionica moraju biti veci od nula!");
             foreach (Stock s in _seStockList)
             {
                 if (StockExists(inStockName))
                     throw new StockExchangeException("Dionica s navedenim imenom vec postoji!");
             }
             _seStockList.Add(new Stock(inStockName.Trim(), inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName)) 
             {
                 foreach( Index i in _seIndexList)
                 {
                     if (IsStockPartOfIndex(i.Name,inStockName)) 
                     { 
                         RemoveStockFromIndex(i.Name, inStockName); 
                     }
                 }
                 foreach (Portfolio p in _sePortfolioList)
                 {
                     if (IsStockPartOfPortfolio(p.PortfolioID, inStockName)) 
                     {
                         RemoveStockFromPortfolio(p.PortfolioID, inStockName); 
                     }
                 }
                 _seStockList.Remove(GetStockByName(inStockName));
             }
             else throw new StockExchangeException("Dionica sa zadanim imenom ne postoji!");
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock s in _seStockList)
             {
                 if (s.Name.ToUpper() == inStockName.ToUpper().Trim()) 
                     return true;
             }
             return false;
             
         }

         public int NumberOfStocks()
         {
             return _seStockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 s.EditStockPrice(inIimeStamp, inStockValue);
             }
             else
                 throw new StockExchangeException("Dionica sa zadanim imenom ne postoji!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 return s.GetStockPrice(inTimeStamp);
             }
             else
                 throw new StockExchangeException("Dionica sa zadanim imenom ne postoji!");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 return s.GetInitialPrice();
             }
             else
                 throw new StockExchangeException("Dionica sa zadanim imenom ne postoji!");
             
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 return s.GetStockPrice(s.GetOldestTimeStamp());
             }
             else throw new StockExchangeException("Dionica sa zadanim imenom ne postoji!");
         }

         private Stock GetStockByName(string inStockName)
         {
             return _seStockList.Where(x => x.Name.ToUpper() == inStockName.ToUpper()).FirstOrDefault();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks s odabranim imenom vec postoji.");
             switch (inIndexType)
             {
                 case IndexTypes.AVERAGE:
                     _seIndexList.Add(new AverageIndex(inIndexName.Trim()));
                     break;
                 case IndexTypes.WEIGHTED:
                     _seIndexList.Add(new WeightedIndex(inIndexName.Trim()));
                     break;
                 default:
                     throw new StockExchangeException("Upotrebljen nedefinirani tip indeksa.");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!IsStockPartOfIndex(inIndexName,inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 GetIndexByName(inIndexName).AddStock(s);
             }
             else
                 throw new StockExchangeException(String.Format( "Dionica imena {0} i/ili indeks imena {1} ne postoje na burzi.", inStockName, inIndexName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IsStockPartOfIndex(inIndexName, inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 GetIndexByName(inIndexName).RemoveStock(s);

             }
             else throw new StockExchangeException("Zadana dionica ne pripada odabranom indeksu.");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 return GetIndexByName(inIndexName).ContainsStock(s);     
             }
             else
                 throw new StockExchangeException(String.Format("Dionica imena {0} i/ili indeks imena {1} ne postoje na burzi.", inStockName, inIndexName));
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
                 return (GetIndexByName(inIndexName) as IIndexvalue).GetIndexValue(inTimeStamp);
             else throw new StockExchangeException("Traženi indeks ne postoji.");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index i in _seIndexList)
             {
                 if (i.Name.ToUpper() == inIndexName.Trim().ToUpper())
                     return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return _seIndexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
                 return GetIndexByName(inIndexName).GetStockCount();
             else throw new StockExchangeException("Traženi indeks ne postoji.");
         }

         private Index GetIndexByName(string inIndexName)
         {
             return _seIndexList.Where(x => x.Name.ToUpper() == inIndexName.ToUpper().Trim()).FirstOrDefault();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Definirani portfelj već postoji.");
             else
                 _sePortfolioList.Add(new Portfolio(inPortfolioID.Trim()));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {

             Stock s = GetStockByName(inStockName);
             Portfolio p = GetPortfolioByID(inPortfolioID);
             if (IsStockPartOfPortfolio(inPortfolioID,inStockName))
             {
                 int totalNumOfShares = (numberOfShares + p.GetStockShareNumber(s));
                 if (totalNumOfShares <= s.NumberOfShares) p.AddStock(s, totalNumOfShares);
                 else throw new StockExchangeException("Definiran neispravan broj dionica.");
             }
             else 
             {
                 if (numberOfShares <= s.NumberOfShares)
                 {
                     p.AddStock(s, numberOfShares);
                 }
                 else throw new StockExchangeException("Definiran neispravan broj dionica.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 Portfolio p = GetPortfolioByID(inPortfolioID);
                 if (p.GetStockShareNumber(s) > numberOfShares)
                 {
                     p.AddStock(s, p.GetStockShareNumber(s) - numberOfShares);
                 }
                 else if (p.GetStockShareNumber(s) == numberOfShares)
                     RemoveStockFromPortfolio(inPortfolioID, inStockName);
                 else throw new StockExchangeException("Definiran neispravan broj dionica.");

             }
             else throw new StockExchangeException("Dionica nije dio portfelja.");
         }

         private Portfolio GetPortfolioByID(string inPortfolioID)
         {
             return  _sePortfolioList.Where(x => x.PortfolioID == inPortfolioID).FirstOrDefault();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 Portfolio p = GetPortfolioByID(inPortfolioID);
                 p.RemoveStock(s);
             }
             else throw new StockExchangeException("Definiran neispravan broj dionica.");
         }

         public int NumberOfPortfolios()
         {
             return _sePortfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return GetPortfolioByID(inPortfolioID).GetNumberOfStocks();
             }
             else throw new StockExchangeException("Definirani portelj ne postoji.");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio p in _sePortfolioList)
             {
                 if (_sePortfolioList.Contains(p))
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 return GetPortfolioByID(inPortfolioID).ContainsStock(s);
             }
             else throw new StockExchangeException("Definirani portfolio i/ili dionica ne postoje.");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 Stock s = GetStockByName(inStockName);
                 Portfolio p = GetPortfolioByID(inPortfolioID);
                 return p.GetStockShareNumber(s);
             }
             else throw new StockExchangeException("Ne postoje tražene dionice u definiranom portfelju.");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID)) 
             {
                 Portfolio p = GetPortfolioByID(inPortfolioID);
                  return p.GetPortfolioValue(timeStamp);

             }
             else throw new StockExchangeException("Definirani portfelj ne postoji.");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal startOfTheMonthSum = 0, endOfTheMonthSum = 0;
             startOfTheMonthSum = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
             endOfTheMonthSum = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
             if (startOfTheMonthSum == 0M)
                 throw new StockExchangeException("Greska u izracunu.");
             else
             return Math.Round((endOfTheMonthSum / startOfTheMonthSum - 1) * 100, Index.NUMBER_OF_DIGITS);


         }
     }
}
