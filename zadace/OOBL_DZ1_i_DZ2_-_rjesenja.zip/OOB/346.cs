﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public List<Stock> Stocks = new List<Stock>();
         public List<Index> Indices = new List<Index>();
         public List<Portfolio> Portfolios = new List<Portfolio>(); 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
             {
                 if(inNumberOfShares > 0 && inInitialPrice > 0)
                     Stocks.Add(new Stock (inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
                 else
                 {
                     throw new StockExchangeException("Greška u unosu");
                 }
             }
                 
             else
                 throw new StockExchangeException("Greška, dionica već postoji");
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 foreach (Stock findStock in Stocks)
                 {
                     if (findStock.StockName == inStockName)
                     {
                         Stocks.Remove(findStock);
                         break;
                     }
                 }
             }
                 
             else
                throw new StockExchangeException("Tražena dionica ne postoji");
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock findStock in Stocks)
             {
                 if (findStock.StockName == inStockName)
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return Stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             try
             {
                 foreach (Stock item in Stocks)
                 {
                     if (item.StockName == inStockName)
                     {
                         if (inStockValue > 0)
                             item.AddToHistory(inIimeStamp, inStockValue);
                         else
                             throw new StockExchangeException("Greška kod unosa");
                         break;
                     }
                 }
             }
             catch (StockExchangeException e)
             {
                 throw new StockExchangeException("Greška");
             }
             
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             foreach (Stock item in Stocks)
             {
                 if (item.StockName == inStockName)
                     return item.GetFromHistory(inTimeStamp);
             }
             throw new StockExchangeException("Greška");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock item in Stocks)
                 {
                     if (item.StockName == inStockName)
                         return item.InitialPrice;
                 }
             throw new StockExchangeException("Greška");
                 
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Stock item in Stocks)
             {
                 if (item.StockName == inStockName)
                     return item.CurrentPrice;
             }
             throw new StockExchangeException("Greška");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!IndexExists(inIndexName))
             {
                 Indices.Add(new Index(inIndexName, inIndexType));
             }
             else
             {
                 throw new StockExchangeException("Greška, indeks već postoji");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName))
             {
                 foreach (Index item in Indices)
                 {
                     if (item.IndexName == inIndexName)
                     {
                         if (!IsStockPartOfIndex(inIndexName, inStockName))
                         {
                             foreach (Stock stock in Stocks)
                             {
                                 if (stock.StockName == inStockName)
                                 {
                                     item.IndexStocks.Add(stock);
                                     break;
                                 }
                                 
                             }
                         }
                         else
                         {
                             throw new StockExchangeException("Greška, dionica je već u indeksu");
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška, indeks ne postoji");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 foreach (Index item in Indices)
                 {
                     if (item.IndexName == inIndexName)
                     {
                         foreach (Stock stockToRemove in item.IndexStocks)
                         {
                             if (stockToRemove.StockName == inStockName)
                             {
                                 item.IndexStocks.Remove(stockToRemove);
                                 break;
                             } 
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška, indeks ili dionica ne postoje");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index item in Indices)
             {
                 if (item.IndexName == inIndexName)
                 {
                     foreach (Stock stock in item.IndexStocks)
                     {
                         if (stock.StockName == inStockName)
                             return true;
                     }
                 }
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             foreach (Index item in Indices)
                 {
                     if (item.IndexName == inIndexName)
                     {
                         return item.Value(inTimeStamp);
                     }
                 }
            throw new StockExchangeException("Indeks ne postoji");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index item in Indices)
             {
                 if (item.IndexName == inIndexName)
                     return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return Indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index item in Indices)
             {
                 if (item.IndexName == inIndexName)
                     return item.IndexStocks.Count();
             }
             throw new StockExchangeException("Greška");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 Portfolios.Add(new Portfolio(inPortfolioID));
             else
             {
                 throw new StockExchangeException("Greška, portfolio već postoji");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 foreach (Portfolio item in Portfolios)
                 {
                     if (item.ID == inPortfolioID)
                     {
                         foreach (Stock stockToAdd in Stocks)
                         {
                             if (stockToAdd.StockName == inStockName)
                             {
                                 if (numberOfShares <= stockToAdd.SharesRemained)
                                 {
                                     if (item.PortfolioStocks.ContainsKey(inStockName))
                                         item.PortfolioStocks[inStockName] += numberOfShares;
                                     else
                                         item.PortfolioStocks.Add(inStockName, numberOfShares);
                                     stockToAdd.SharesRemained = stockToAdd.SharesRemained - numberOfShares;
                                 }
                                 else
                                 {
                                     throw new StockExchangeException("Greška, nema toliko dionica za dodati u portfolio");
                                 }
                             }
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška, portfolio ili dionica ne postoji");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 int numberOfSharesInPort;
                 foreach (Portfolio item in Portfolios)
                 {
                     if (item.ID == inPortfolioID)
                     {
                         numberOfSharesInPort = item.PortfolioStocks[inStockName];
                         if (numberOfSharesInPort <= numberOfShares)
                         {
                             item.PortfolioStocks.Remove(inStockName);
                             numberOfShares = numberOfSharesInPort;
                         }
                         else
                         {
                             item.PortfolioStocks[inStockName] -= numberOfShares;
                         }
                         foreach (Stock stockToUpdate in Stocks)
                         {
                             if (stockToUpdate.StockName == inStockName)
                                 stockToUpdate.SharesRemained += numberOfShares;
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška...");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 int numberOfShares;
                 foreach (Portfolio item in Portfolios)
                 {
                     if (item.ID == inPortfolioID)
                     {
                         numberOfShares = item.PortfolioStocks[inStockName];
                         item.PortfolioStocks.Remove(inStockName);
                         foreach (Stock stockToUpdate in Stocks)
                         {
                             if (stockToUpdate.StockName == inStockName)
                                 stockToUpdate.SharesRemained += numberOfShares;
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("Greška, dionica nije u portfoliu");
             }
         }

         public int NumberOfPortfolios()
         {
             return Portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             foreach (Portfolio item in Portfolios)
             {
                 if (item.ID == inPortfolioID)
                     return item.PortfolioStocks.Count;
             }
             throw new StockExchangeException("Greška");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio item in Portfolios)
             {
                 if (item.ID == inPortfolioID)
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 foreach (Portfolio item in Portfolios)
                 {
                     if (item.ID == inPortfolioID)
                     {
                         if (item.PortfolioStocks.ContainsKey(inStockName))
                             return true;
                     }
                 }
             }
             
             
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
            foreach (Portfolio item in Portfolios)
                {
                     if (item.ID == inPortfolioID)
                     {
                         return item.PortfolioStocks[inStockName];
                     }
                }
             throw new StockExchangeException("Greška");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal value = 0;
             decimal stockValue = 0;
             if (PortfolioExists(inPortfolioID))
             {
                 foreach (Portfolio item in Portfolios)
                 {
                     if (item.ID == inPortfolioID)
                     {
                         foreach (KeyValuePair<string, int> entry in item.PortfolioStocks)
                         {
                             foreach (Stock stockToFind in Stocks)
                             {
                                 if (stockToFind.StockName == entry.Key)
                                     stockValue = stockToFind.GetFromHistory(timeStamp);
                             }
                             value = value + entry.Value*stockValue;
                         }
                         return Math.Round(value, 3);
                     }
                 }
             }
             throw new StockExchangeException("Greška");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
     }


     public class Stock
     {
         private string _stockName;
         public string StockName
         {
             get { return _stockName; }
             set { _stockName = value.ToUpper(); }
         }

         private long _numberOfShares;
         public long NumberOfShares
         {
             get { return _numberOfShares; }
             set { _numberOfShares = value; }
         }

         private decimal _initialPrice;
         public decimal InitialPrice
         {
             get { return _initialPrice; }
             set { _initialPrice = value; }
         }

         private DateTime _timeStamp;
         public DateTime TimeStamp
         {
             get { return _timeStamp; }
             set { _timeStamp = value; }
         }

         private decimal _currentPrice;
         public decimal CurrentPrice
         {
             get { return _currentPrice; }
             set { _currentPrice = value; }
         }

         private long _sharesRemained;
         public long SharesRemained
         {
             get { return _sharesRemained; }
             set { _sharesRemained = value; }
         }
         
         /// <summary>
         /// Stock history
         /// </summary>
         Dictionary<DateTime, decimal> StockHistory = new Dictionary<DateTime, decimal>();
         
         /// <summary>
         /// Adds new entry to stock history and checks if date is the oldest or the newest
         /// </summary>
         /// <param name="date">Date</param>
         /// <param name="price">Price</param>
         public void AddToHistory(DateTime date, decimal price)
         {
             DateTime dateCheck = _timeStamp;
             foreach (KeyValuePair<DateTime, decimal> entry in StockHistory)
             {
                 if (entry.Key > dateCheck)
                     dateCheck = entry.Key;
             }

             if (dateCheck < date)
                 _currentPrice = price;

             if (_timeStamp > date)
             {
                 _timeStamp = date;
                 _initialPrice = price;
             }

             StockHistory.Add(date, price);
         }

         /// <summary>
         /// Returns stock price at some time
         /// </summary>
         /// <param name="date">Date</param>
         /// <returns>Stock price</returns>
         public decimal GetFromHistory(DateTime date)
         {
             DateTime firstSmaller = _timeStamp;
             if (date < _timeStamp)
                 throw new StockExchangeException("Unešeni datum je stariji od najstarijeg zapisa");
             else
             {
                 foreach (KeyValuePair<DateTime, decimal> entry in StockHistory)
                 {
                     if (entry.Key > firstSmaller && entry.Key < date)
                         firstSmaller = entry.Key;
                 }
                 return StockHistory[firstSmaller];
             }
             
         }

         /// <summary>
         /// Constructor (Creating new stock)
         /// </summary>
         /// <param name="name">Stock name</param>
         /// <param name="numberofshares">Number of stock shares</param>
         /// <param name="price">Stock price</param>
         /// <param name="date">Stock creation date</param>
         public Stock(string name, long numberofshares, decimal price, DateTime date)
         {
             _stockName = name.ToUpper();
             _numberOfShares = numberofshares;
             _initialPrice = price;
             _timeStamp = date;
             _currentPrice = price;
             StockHistory.Add(date, price);
             _sharesRemained = numberofshares;
         }
     }


    public class Index
    {
        public List<Stock> IndexStocks = new List<Stock>();
        private IndexTypes _type;

        public string IndexName { get; set; }

        public Index(string name, IndexTypes type)
        {
            IndexName = name.ToUpper();
            _type = type;
        }

        /// <summary>
        /// Index value at some time
        /// </summary>
        /// <param name="date">date</param>
        /// <returns>value</returns>
        public decimal Value(DateTime date)
        {
            int numberOfStocks = 0;
            decimal accumulatedValue = 0;
            double fullValue = 0;
            double value = 0;

            if (_type == IndexTypes.AVERAGE)
            {
                foreach (Stock stock in IndexStocks)
                {
                    numberOfStocks++;
                    accumulatedValue = accumulatedValue + stock.GetFromHistory(date);
                }
                return Math.Round((accumulatedValue/numberOfStocks), 3);
            }
            else
            {
                foreach (Stock stock in IndexStocks)
                {
                    fullValue = fullValue + (double)stock.NumberOfShares*(double)stock.GetFromHistory(date);
                }
                foreach (Stock item in IndexStocks)
                {
                    value = value + item.NumberOfShares*Math.Pow((double)item.GetFromHistory(date), 2)/fullValue;
                }
                return (decimal)Math.Round(value, 3);
            }
        }

    }

    public class Portfolio
    {
        //public List<Stock> PortfolioStocks = new List<Stock>();
        public Dictionary<string, int> PortfolioStocks = new Dictionary<string, int>(); 
        private string _ID;
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public Portfolio(string name)
        {
            _ID = name;
        }

    }

}
