﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private int displayLenght = 10;
        private string currentDisplayState = "0";
        private string leftOperand = "0";
        private string savedLeftOpreand = "0";
        private string rightOperand = "0";
        private string currentMemoryState = "+";
        private string multipleOperator = "+";
        private string previousOperator = "+";
        private string savedDisplayState = "0";
        private string lastInPressDigit = "";
        private string [] unaryOperators = { "S", "K", "T", "Q", "R", "I" };
        private string [] binaryOperators = { "+", "-", "*", "/" };
        

        public void Press(char inPressedDigit)
        {
            if (Char.IsNumber ( inPressedDigit )) {
                //unesini zank je znamenka
                if (isOperatorBinary ( lastInPressDigit ) || lastInPressDigit == "=" || isOperatorUnary ( lastInPressDigit ) ||
                    lastInPressDigit == "G" || currentDisplayState == "0") {
                    currentDisplayState = inPressedDigit.ToString ();
                } else {
                    if (!isScreenFull ()) {
                        addNewDigit ( inPressedDigit.ToString () );
                    }
                }
            }else if (isOperatorBinary (inPressedDigit.ToString())){
                //uneseni znak je binarni operator
                if (isOperatorBinary ( lastInPressDigit )) {
                    previousOperator = inPressedDigit.ToString();
                } else {
                    rightOperand = currentDisplayState;
                    currentDisplayState = binaryOperation(leftOperand, rightOperand, previousOperator);
                    //currentOperator = inPressedDigit.ToString();
                    previousOperator = inPressedDigit.ToString ();
                    leftOperand = currentDisplayState;
                    savedLeftOpreand = rightOperand;
                    multipleOperator = previousOperator;
                }
            } else if (inPressedDigit == '=') {
                if (lastInPressDigit == "=") {
                    //savedLeftOpreand = currentDisplayState;
                    rightOperand = currentDisplayState;
                    currentDisplayState = binaryOperation ( rightOperand, savedLeftOpreand, multipleOperator );
                } else {
                    //multipleOperator = previousOperator;
                    savedLeftOpreand = currentDisplayState;
                    rightOperand = currentDisplayState;
                    currentDisplayState = binaryOperation ( leftOperand, rightOperand, multipleOperator );
                    rightOperand = currentDisplayState;
                }
                //currentDisplayState = binaryOperation ( leftOperand, rightOperand, previousOperator );  
                rightOperand = currentDisplayState;
                leftOperand = "0";
                previousOperator = "+";
            } else if (inPressedDigit == ',') {
                if (isOperatorBinary ( lastInPressDigit ) || lastInPressDigit == "=" || isOperatorUnary ( lastInPressDigit ) ||
                    lastInPressDigit == "G") {
                    currentDisplayState = "0,";
                } else {
                    if (!isScreenFull ()) {
                        //if (decimal.Parse ( currentDisplayState ) == decimal.Round ( decimal.Parse ( currentDisplayState ) )) {
                        if (!currentDisplayState.Contains(',')) {
                            addNewDigit ( inPressedDigit.ToString () );
                        }
                    }
                }
            } else if (inPressedDigit == 'M') {
                currentDisplayState = formatDisplayState( ( decimal.Parse ( currentDisplayState ) * ( -1 ) ).ToString ());
            } else if (isOperatorUnary(inPressedDigit.ToString())){
                currentDisplayState = unaryOperation ( currentDisplayState, inPressedDigit.ToString () );
            } else if (inPressedDigit == 'P'){
                currentMemoryState = currentDisplayState;
            } else if (inPressedDigit == 'G'){
                if (currentMemoryState != ""){
                    currentDisplayState = currentMemoryState;
                }
            } else if (inPressedDigit == 'C'){
                currentDisplayState = "0";
            }else if (inPressedDigit == 'O'){
                currentDisplayState = "0";
                leftOperand = "0";
                rightOperand = "0";
                currentMemoryState = "";
                multipleOperator = "+";
                previousOperator = "+";
                savedDisplayState = "0";
                lastInPressDigit = "";
            }
            lastInPressDigit = inPressedDigit.ToString ();
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayState;
        }

        private bool isOperatorUnary ( string str ) {
            foreach (string s in unaryOperators) {
                if (s == str) {
                    return true;
                }
            }
            return false;
        }

        private bool isOperatorBinary ( string str) {
            foreach (string s in binaryOperators) {
                if (s == str) {
                    return true;
                }
            }
            return false;
        }

        private bool isScreenFull () {
            decimal numDisplayState = decimal.Parse ( currentDisplayState, CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            if (numDisplayState > 0) {
                if (decimal.Round ( numDisplayState ) == numDisplayState) {
                    //pozitivan cijeli broj
                    if (currentDisplayState.Length < displayLenght) {
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    //pozitivan decimalni broj
                    if (currentDisplayState.Length < displayLenght + 1) {
                        return false;
                    } else {
                        return true;
                    }
                }
            } else {
                if (decimal.Round ( numDisplayState ) == numDisplayState) {
                    //negativan cijeli broj
                    if (currentDisplayState.Length < displayLenght + 1) {
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    //negativan decimalni broj
                    if (currentDisplayState.Length < displayLenght + 2) {
                        return false;
                    } else {
                        return true;
                    }
                }
            }
        }

        private void addNewDigit ( string digit ) {
            currentDisplayState = currentDisplayState + digit;
        }

        private string formatDisplayState ( string str ) {
            decimal numDisplayState = decimal.Parse ( str, CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            if (str == "-E-" || numDisplayState == 0) {
                return str;
            } 
            decimal positiveNumDisplayState;
            if (numDisplayState < 0) {
                positiveNumDisplayState = numDisplayState * ( -1 );
            } else {
                positiveNumDisplayState = numDisplayState;
            }
            if (positiveNumDisplayState >= (decimal)Math.Pow ( 10, displayLenght )) {
                //broj je prevelik
                return "-E-";
            }
            if (positiveNumDisplayState <= 1/(decimal)Math.Pow ( 10, displayLenght)) {
                //broj je premalen
                return "-E-";
            }
            //uklanjanje 0 i , sa kraja ako je broj ispravan
            string formatedString;
            decimal roundedDisplayState = decimal.Round ( numDisplayState, displayLenght - ((int)decimal.Round ( positiveNumDisplayState )).ToString ().Length );
            if (decimal.Round ( numDisplayState ) == numDisplayState && ((int)decimal.Round ( numDisplayState )).ToString ().Length != numDisplayState.ToString ().Length) {
                //brojevi oblika cijeliBroj,000...
                formatedString = roundedDisplayState.ToString ( CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat ).TrimEnd ( '0' ).TrimEnd ( ',' );
            } else if (!( decimal.Round ( numDisplayState ) == numDisplayState && ((int)decimal.Round ( numDisplayState )).ToString ().Length == numDisplayState.ToString ().Length )) {
                formatedString = roundedDisplayState.ToString ( CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat ).TrimEnd ( '0' );
            } else {
                formatedString = roundedDisplayState.ToString ( CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            }
            return formatedString;
        }

        private string unaryOperation ( string operand, string unaryOperator ) {
            decimal decimalOperand = decimal.Parse ( operand, CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            decimal result;
            switch (unaryOperator) {
                case "S":
                    result = (decimal)Math.Sin ( (double)decimalOperand );
                    return formatDisplayState ( result.ToString() );
                case "K":
                    result = (decimal)Math.Cos ( (double)decimalOperand );
                    return formatDisplayState ( result.ToString() );
                case "T":
                    result = (decimal)Math.Tan ( (double)decimalOperand );
                    return formatDisplayState ( result.ToString() );
                case "Q":
                    result = decimalOperand * decimalOperand;
                    return formatDisplayState ( result.ToString() );
                case "R":
                    if (decimalOperand > 0) {
                        result = (decimal)Math.Sqrt ( (double)decimalOperand );
                        return formatDisplayState ( result.ToString () );
                    } else {
                        return "-E-";
                    }
                case "I":
                    if (decimalOperand != 0) {
                        result = 1 / decimalOperand;
                        return formatDisplayState ( result.ToString() );
                    } else {
                        return "-E-";
                    }
                default:
                    return operand;
            }
        }

        private string binaryOperation ( string leftOperand, string rightOperand, string binaryOperator ) {
            decimal firstOperand = decimal.Parse ( leftOperand, CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            decimal secondOperand = decimal.Parse ( rightOperand, CultureInfo.GetCultureInfo ( "hr-HR" ).NumberFormat );
            decimal result;
            switch (binaryOperator) {
                case "+":
                    result = firstOperand + secondOperand;
                    return formatDisplayState ( result.ToString() );
                case "-":
                    result = firstOperand - secondOperand;
                    return formatDisplayState ( result.ToString() );
                case "*":
                    result = firstOperand * secondOperand;
                    return formatDisplayState ( result.ToString() );
                case "/":
                    if (secondOperand != 0) {
                        result = firstOperand / secondOperand;
                        return formatDisplayState ( result.ToString() );
                    } else {
                        return "-E-";
                    }
            }
            return rightOperand;
        }
    }


}
