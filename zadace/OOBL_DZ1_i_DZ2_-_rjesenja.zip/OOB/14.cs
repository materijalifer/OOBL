﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string ekran; 
        string memorija;

        bool noviBroj;

        Stack<string> stog;


        public void Press(char inPressedDigit)
        {         
            // broj
            if (char.IsNumber(inPressedDigit))
            {
                // < 11 znamenki !!!!!
                if ((noviBroj == true) || BrojZnamenki(ekran) < 10)
                {
                    Broj(inPressedDigit.ToString());
                }

                return;
            }

            // ,
            if ((inPressedDigit == ',') && (BrojZnamenki(ekran) < 10))
            {
                Zarez();
            }

            // funkcija
            Funkcija(inPressedDigit.ToString());
            
        }

        public void Sinus()
        {
            ekran = Math.Round(Math.Sin(Convert.ToDouble(ekran)), 9).ToString();
            noviBroj = true;
        }

        public void Kosinus()
        {
            ekran = Math.Round(Math.Cos(Convert.ToDouble(ekran)), 9).ToString();
            noviBroj = true;
        }

        public void Tangens()
        {
            ekran = Math.Round(Math.Tan(Convert.ToDouble(ekran)), 9).ToString();
            noviBroj = true;
        }

        public void Root()
        {
            ekran = Math.Round(Math.Sqrt(Convert.ToDouble(ekran)), 9).ToString();
            noviBroj = true;
        }

        public void Put()
        {
            memorija = ekran;
        }

        public void Get()
        {
            ekran = memorija;
        }

        public void Reset()
        {
            stog.Clear();

            ekran = "0";

            memorija = "0";

            noviBroj = true;
        }

        public void Minus()
        {
            ekran = (0 - Math.Abs(Convert.ToDouble(ekran))).ToString();
        }

        public void Funkcija(string funkcija)
        {
            switch (funkcija)
            {
                case "-":
                    {
                        Oduzimanje();
                        break;
                    }
                case "+":
                    {
                        Zbrajanje();
                        break;
                    }
                case "*":
                    {
                        Mnozenje();
                        break;
                    }
                case "/":
                    {
                        Dijeljenje();
                        break;
                    }
                case "=":
                    {
                        Izracunaj();
                        break;
                    }
                case "C":
                    {
                        Clear();
                        break;
                    }
                case "G":
                    {
                        Get();
                        break;
                    }
                case "I":
                    {
                        Inverz();
                        break;
                    }
                case "K":
                    {
                        Kosinus();
                        break;
                    }
                case "M": 
                    { 
                        Minus(); 
                        break; 
                    }
                case "O":
                    {
                        Reset();
                        break;
                    }
                case "P":
                    {
                        Put();
                        break;
                    }
                case "Q":
                    {
                        Kvadriranje();
                        break;
                    }
                case "S":
                    {
                        Sinus();
                        break;
                    }
            }
        }

        public void Clear()
        {
            ekran = "0";
            noviBroj = true;
        }

        public string Skrati(string rezultat)
        {
            int index = rezultat.Length;
            int brojac = 0;
            for (int i = 0; i < rezultat.Length; i++)
            {
                if (char.IsNumber(rezultat.ElementAt(i)))
                {
                    brojac++;
                }

                if (brojac == 10)
                {
                    index = i;
                    break;
                }
            }

            return rezultat.Substring(0, index); 
        }

        public void Izracunaj()
        {
            noviBroj = true;

            // rezultat binarnih operacija
            string rezultat = "0";

            if (stog.Count == 0)
            {
                ekran = Convert.ToDouble(ekran).ToString();
                return;
            }

            double drugi = Convert.ToDouble(ekran);
            if (ekran == "0")
            {
                ekran = "-E";
                return;
            }
            string operacija = stog.Pop();
            double prvi = Convert.ToDouble(stog.Pop());

            switch (operacija)
            {
                case "-":
                    rezultat = Math.Round((prvi - drugi), 9).ToString();
                    break;
                case "+":
                    rezultat = Math.Round((prvi + drugi), 9).ToString();
                    break;
                case "*":
                    rezultat = Math.Round((prvi * drugi), 9).ToString();
                    break;
                case "/":
                    rezultat = Math.Round((prvi / drugi), 9).ToString();
                    break;
            }

            if ((!rezultat.Contains('E')) && !(Convert.ToDouble(rezultat) > 9999999999) )
            {
                rezultat = Skrati(rezultat);
                ekran = rezultat;
            }
            else
            {
                ekran = "-E-";
            }
        }

        public void Kvadriranje()
        {
            ekran = (Convert.ToDouble(ekran) * Convert.ToDouble(ekran)).ToString();
            noviBroj = true;
        }

        public void Zbrajanje()
        {
            // + -> =
            if ((stog.Count != 0) && (stog.ElementAt(stog.Count - 1) != ekran))
            {
                Izracunaj();
                stog.Push(ekran);
                stog.Push("+");
            }

            if ((stog.Count != 0) && (!char.IsNumber(stog.Peek().ElementAt(0))))
            {
                stog.Pop();
                stog.Push("+");
                noviBroj = true;
                return;
            }
            stog.Push(ekran);
            stog.Push("+");
            noviBroj = true;
        }

        public void Oduzimanje()
        {
            // - -> =
            if ((stog.Count != 0) && (stog.ElementAt(stog.Count - 1) != ekran))
            {
                Izracunaj();
                stog.Push(ekran);
                stog.Push("-");
            }

            if ((stog.Count != 0) && (!char.IsNumber(stog.Peek().ElementAt(0))))
            {
                stog.Pop();
                stog.Push("-");
                noviBroj = true;
                return;
            }
            
            stog.Push(ekran);
            stog.Push("-");
            noviBroj = true;
        }

        public void Mnozenje()
        {
            // - -> =
            if ((stog.Count != 0) && (stog.ElementAt(stog.Count - 1) != ekran))
            {
                Izracunaj();
                stog.Push(ekran);
                stog.Push("*");
            }

            if ((stog.Count != 0) && (!char.IsNumber(stog.Peek().ElementAt(0))))
            {
                stog.Pop();
                stog.Push("*");
                noviBroj = true;
                return;
            }

            stog.Push(ekran);
            stog.Push("*");
            noviBroj = true;
        }

        public void Dijeljenje()
        {
            // - -> =
            if ((stog.Count != 0) && (stog.ElementAt(stog.Count - 1) != ekran))
            {
                Izracunaj();
                stog.Push(ekran);
                stog.Push("/");
            }

            if ((stog.Count != 0) && (!char.IsNumber(stog.Peek().ElementAt(0))))
            {
                stog.Pop();
                stog.Push("/");
                noviBroj = true;
                return;
            }

            stog.Push(ekran);
            stog.Push("/");
            noviBroj = true;
        }

        public void Inverz()
        {
            if (ekran == "0")
            {
                ekran = "-E-";
            }
            else
            {
                ekran = (1 / Convert.ToDouble(ekran)).ToString();
            }
        }

        public void Zarez()
        {
            ekran = ekran + ",";
            noviBroj = false;
        }

        public void Broj(string broj)
        {
            // 0 0
            if ((ekran == "0") && (broj == "0"))
            {
                return;
            }

            //
            if (noviBroj == true)
            {
                ekran = broj;

                noviBroj = false;

                return;
            }
            else
            {
                ekran = ekran + broj;
            }
            
            

        }

        public int BrojZnamenki(string broj)
        {
            int brojac = 0;
            for (int i = 0; i < broj.Length; i++)
            {
                if (char.IsNumber(broj.ElementAt(i))) brojac++;
            }
            return brojac;
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }

        public Kalkulator()
        {
            ekran = "0";
            
            memorija = "0";

            stog = new Stack<string>();
            // stog.Push(ekran);

            noviBroj = true;
        }
    }


}
