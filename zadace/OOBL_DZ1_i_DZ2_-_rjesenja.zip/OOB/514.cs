﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public interface ISubject
    {
        void RegisterObserver(IObserver o);

        void RemoveObserver(IObserver o);

        void NotifyObservers(object removedStockName);
    }

    public interface IObserver
    {
        void Update(object removedStockName);
    }

    class Stock
    {
         private string stockName;
         private long numberOfShares;
         private long remainingShares;
         public string StockName { get { return stockName; } }
         public long NumberOfShares { get { return numberOfShares; } }
         public long RemainingShares { get { return remainingShares; } }

         private Dictionary<DateTime, Decimal> priceList = new Dictionary<DateTime, Decimal>();


         public void TakeShares(int inNumberShares)
         {
             remainingShares -= inNumberShares;
         }

         public void ReturnShares(int inNumberShares)
         {
             remainingShares += inNumberShares;
         }

         public decimal InitialPrice
         {
             get { return priceList.Aggregate((p1, p2) => (p1.Value < p2.Value) ? p1 : p2).Value; }
         }

         public decimal LastPrice
         {
             get { return priceList.Aggregate((p1, p2) => (p1.Value > p2.Value) ? p1 : p2).Value; }
         }

         public decimal GetPrice(DateTime inTimeStamp)
         {
             DateTime min = DateTime.MinValue;
             decimal value = -1;
             foreach (var price in priceList)
             {
                 if (price.Key <= inTimeStamp && price.Key > min)
                 {
                     min = price.Key;
                     value = price.Value;
                 }
             }
             if (value == -1) throw new StockExchangeException("");
             return value;
         }

         public void AddPrice(DateTime inTimeStamp, decimal inInitialPrice)
         {
             this.priceList.Add(inTimeStamp, inInitialPrice);
         }

         public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             this.stockName = inStockName;
             this.numberOfShares = inNumberOfShares;
             this.remainingShares = inNumberOfShares;
             priceList.Add(inTimeStamp, inInitialPrice);
         }
     }

    class Index : IObserver
    {
        public string IndexName { get; set; }
        public IndexTypes IndexType { get; set; }

        List<Stock> stockList = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.IndexName = inIndexName;
            this.IndexType = inIndexType;
        }

        public decimal GetValue(DateTime inTimeStamp)
        {
            if (this.stockList.Count() == 0) return 0;

            if (this.IndexType == IndexTypes.AVERAGE)
            {
                return GetAverageValue(inTimeStamp);
            }
            else
            {
                return GetWeightedValue(inTimeStamp);
            }
            
        }

        public decimal GetWeightedValue(DateTime inTimeStamp)
        {
            decimal retVal = 0;
            foreach (var stock in stockList)
            {
                retVal += (stock.GetPrice(inTimeStamp) * stock.GetPrice(inTimeStamp) * stock.NumberOfShares) / GetTotalValue(inTimeStamp);
            }
            return Math.Round(retVal, 3);
        }

        private decimal GetTotalValue(DateTime inTimeStamp)
        {
            decimal retVal = 0;
            foreach (var stock in stockList)
            {
                retVal += stock.GetPrice(inTimeStamp) * stock.NumberOfShares;
            }
            return retVal;
        }

        public decimal GetAverageValue(DateTime inTimeStamp)
        {
            decimal retVal = 0;
            foreach (var stock in stockList)
            {
                retVal += stock.GetPrice(inTimeStamp);
            }
            return  Math.Round(retVal / stockList.Count());
        }

        public void AddStock(Stock stock)
        {
            stockList.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            stockList.Remove(stock);
        }

        public void RemoveStock(string inStockName)
        {
            var stock = this.GetStock(inStockName);
            if (stock != null)
                stockList.Remove(stock);
            else throw new StockExchangeException("");
        }

        public int CountStocks()
        {
            return stockList.Count();
        }

        public bool StockExists(Stock stock)
        {
            return stockList.Exists(t => t == stock);
        }

        public bool StockExists(string inStockName)
        {
            return stockList.Exists(t => t.StockName == inStockName);
        }

        public Stock GetStock(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                return stockList.Where(t => t.StockName == inStockName).First();
            }
            else 
            {
                return null;
            }
        }

        public void Update(object removedStockName)
        {
            if (this.StockExists(removedStockName.ToString()))
            {
                this.RemoveStock(removedStockName.ToString());
            }
        }
    }

    class Portfolio : IObserver
    {
        private Dictionary<Stock, int> stockContent = new Dictionary<Stock, int>();

        private string portfolioID;
        public string PortfolioID { get { return portfolioID; } }

        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (this.ContainsStock(stock))
            {
                numberOfShares = GetStockShares(stock) + numberOfShares;
                RemoveStock(stock);
                stockContent.Add(stock, numberOfShares);
            }
            else
            {
                stockContent.Add(stock, numberOfShares);
            }
        }

        public void AddStock(string inStockName, int numberOfShares)
        {
            this.AddStock(this.GetStock(inStockName), numberOfShares);
        }

        public bool ContainsStock(Stock stock)
        {
            var stockList = stockContent.Keys.ToList();
            if (stockList.Contains(stock))
            {
                return true;
            }
            else return false;
        }

        public bool ContainsStock(string inStockName)
        {
            var stockList = stockContent.Keys.ToList();
            if (stockList.Exists(t => t.StockName == inStockName))
            {
                return true;
            }
            else return false;
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            numberOfShares = GetStockShares(stock) - numberOfShares;
            RemoveStock(stock);
            if (numberOfShares > 0) AddStock(stock, numberOfShares);
        }

        public void RemoveStock(Stock stock)
        {
            stockContent.Remove(stock);
        }

        public void RemoveStock(string stockName)
        {
            RemoveStock(GetStock(stockName));
        }

        public void RemoveStock(string stockName, int numberofShares)
        {
            RemoveStock(GetStock(stockName), numberofShares);
        }

        public Stock GetStock(string stockName)
        {
            return stockContent.Where(t => t.Key.StockName == stockName).FirstOrDefault().Key;
        }

        public int GetStockShares(string stockName)
        {
            return stockContent.Where(t => t.Key.StockName == stockName).FirstOrDefault().Value;
        }

        public int GetStockShares(Stock stock)
        {
            return stockContent.Where(t => t.Key == stock).FirstOrDefault().Value;
        }

        public int GetNumberOfStocks()
        {
            return stockContent.Count();
        }

        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            decimal retValue = 0;

            foreach (var item in stockContent)
            {
                retValue += item.Key.GetPrice(inTimeStamp) * item.Value;
            }

            return Math.Round(retValue, 3);
        }

        public decimal GetPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime beginning = new DateTime(Year, Month, 1, 0, 0, 0);
            DateTime end = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59);
            decimal begVal = this.GetPortfolioValue(beginning);
            decimal endVal = this.GetPortfolioValue(end);

            try
            {
                return Math.Round((endVal - begVal) / begVal * 100, 3);
            }
            catch
            {
                return 0;
            }

        }

        public void Update(object removedStockName)
        {
            if (this.ContainsStock(removedStockName.ToString()))
            {
                this.RemoveStock(removedStockName.ToString());
            }
        }

    }

    abstract class Repository<T>
     {
         internal List<T> itemList = new List<T>();
         public virtual void Add(T item)
         {
             itemList.Add(item);
         }
         public virtual void Remove(int noItem)
         {
             itemList.RemoveAt(noItem);
         }
         public void Remove(T item)
         {
             if (this.Exists(item))
                 itemList.Remove(item);
             else throw new StockExchangeException("");
         }

         public virtual void Remove(string ID)
         {
             var item = this.Get(ID);
             if (item != null)
                 this.Remove(item);
             else throw new StockExchangeException("");
         }

         public bool Exists(T item)
         {
             return itemList.Contains(item);
         }

         public int Count()
         {
             return itemList.Count();
         }

         public virtual T Get(string ID)
         {
             throw new NotImplementedException();
         }
     }

    class StockRepository : Repository<Stock>, ISubject
     {
         public override Stock Get(string ID)
         {
             if (this.Exists(ID))
             {
                 return itemList.Where(t => t.StockName == ID).First();
             }
             else 
             {
                 return null;
             }
               
         }
         public bool Exists(string ID)
         {
             return itemList.Exists(t => t.StockName.ToLower() == ID.ToLower());
         }
         public override void Add(Stock item)
         {
             if (item.InitialPrice > 0 && !itemList.Exists(t => t.StockName.ToLower() == item.StockName.ToLower()))
             {
                 base.Add(item);
             }
             else
             {
                 throw new StockExchangeException("Greška kod unosa novog Stock-a");
             }
         }

         public override void Remove(string ID)
         {
             base.Remove(ID);
             this.NotifyObservers(ID);
         }

         private List<IObserver> observers = new List<IObserver>();
         public void RegisterObserver(IObserver o)
         {
             observers.Add(o);
         }
         public void RemoveObserver(IObserver o)
         {
             observers.Remove(o);
         }
         public void NotifyObservers(object removedStockName)
         {
             foreach (IObserver o in observers)
             {
                 o.Update(removedStockName);
             }
         }
     }

    class IndexRepository : Repository<Index>
     {
         public override void Add(Index item)
         {
             if (!itemList.Exists(t => t.IndexName.ToLower() == item.IndexName.ToLower()))
             {
                 base.Add(item);
             }
             else
             {
                 throw new StockExchangeException("Greška kod unosa novog Index-a");
             }
         }

         public bool Exists(string ID)
         {
             return itemList.Exists(t => t.IndexName.ToLower() == ID.ToLower());
         }

         public override Index Get(string ID)
         {
             if (this.Exists(ID))
             {
                 return itemList.Where(t => t.IndexName == ID).First();
             }
             else 
             {
                 return null;
             }
             
         }
     }

    class PortfolioRepository : Repository<Portfolio>
     {
         public override void Add(Portfolio item)
         {
             if (!itemList.Exists(t => t.PortfolioID == item.PortfolioID))
             {
                 base.Add(item);
             }
             else
             {
                 throw new StockExchangeException("Greška kod unosa novog Portfolia-a");
             }
         }

         public bool Exists(string ID)
         {
             return itemList.Exists(t => t.PortfolioID == ID);
         }

         public override Portfolio Get(string ID)
         {
             if (this.Exists(ID))
             {
                 return itemList.Where(t => t.PortfolioID == ID).First();
             }
             else 
             {
                 return null;
             }
             
         }

     }

    public class StockExchange : IStockExchange
    {
        #region Stock

        StockRepository stockRepository = new StockRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                stockRepository.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void DelistStock(string inStockName)
        {
            try
            {
                stockRepository.Remove(inStockName);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }

        }

        public bool StockExists(string inStockName)
        {
            try
            {
                return stockRepository.Exists(inStockName);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfStocks()
        {
            try
            {
                return stockRepository.Count();
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            try
            {
                stockRepository.Get(inStockName).AddPrice(inIimeStamp, inStockValue);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                return stockRepository.Get(inStockName).GetPrice(inTimeStamp);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            try
            {
                return stockRepository.Get(inStockName).InitialPrice;
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            try
            {
                return stockRepository.Get(inStockName).LastPrice;
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        #endregion

        #region Index

        IndexRepository indexRepository = new IndexRepository();
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             try
             {
                 var index = new Index(inIndexName, inIndexType);
                 stockRepository.RegisterObserver(index);
                 indexRepository.Add(index);
             }
             catch (StockExchangeException e)
             {
                 throw e;
             }
         }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                var index = indexRepository.Get(inIndexName);
                if (index == null) throw new StockExchangeException("");
                var stock = stockRepository.Get(inStockName);
                if (stock == null) throw new StockExchangeException("");
                index.AddStock(stock);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try
            {
                var index = indexRepository.Get(inIndexName);
                index.RemoveStock(inStockName);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                var index = indexRepository.Get(inIndexName);
                return index.StockExists(inStockName);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                var index = indexRepository.Get(inIndexName);
                return index.GetValue(inTimeStamp);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public bool IndexExists(string inIndexName)
        {

            try
            {
                return indexRepository.Exists(inIndexName);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfIndices()
        {
            try
            {
                return indexRepository.Count();
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            try
            {
                var index = indexRepository.Get(inIndexName);
                return index.CountStocks();
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        #endregion

        #region Portfolio

        PortfolioRepository portfolioRepository = new PortfolioRepository();
        public void CreatePortfolio(string inPortfolioID)
        {
            try
            {
                var portfolio = new Portfolio(inPortfolioID);
                stockRepository.RegisterObserver(portfolio);
                portfolioRepository.Add(portfolio);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                var stock = stockRepository.Get(inStockName);
                if (stock == null) throw new StockExchangeException("");
                var portfolio = portfolioRepository.Get(inPortfolioID);
                if (portfolio == null) throw new StockExchangeException("");
                if (stock.RemainingShares < numberOfShares) throw new FieldAccessException(stock.RemainingShares.ToString());
                portfolio.AddStock(stock, numberOfShares);
                stock.TakeShares(numberOfShares);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                var stock = stockRepository.Get(inStockName);
                var portfolio = portfolioRepository.Get(inPortfolioID);
                if (portfolio.GetStockShares(stock) < numberOfShares) throw new StockExchangeException("");
                portfolio.RemoveStock(stock, numberOfShares);
                stock.ReturnShares(numberOfShares);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                var stock = stockRepository.Get(inStockName);
                if (stock == null) throw new StockExchangeException("");
                var portfolio = portfolioRepository.Get(inPortfolioID);
                if (portfolio == null) throw new StockExchangeException("");
                portfolio.RemoveStock(stock);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfPortfolios()
        {
            try
            {
                return portfolioRepository.Count();
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try
            {
                var portfolio = portfolioRepository.Get(inPortfolioID);
                return portfolio.GetNumberOfStocks();
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            try
            {
                return portfolioRepository.Exists(inPortfolioID);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                var stock = stockRepository.Get(inStockName);
                var portfolio = portfolioRepository.Get(inPortfolioID);
                return portfolio.ContainsStock(stock);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                var stock = stockRepository.Get(inStockName);
                var portfolio = portfolioRepository.Get(inPortfolioID);
                return portfolio.GetStockShares(stock);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            try
            {
                var portfolio = portfolioRepository.Get(inPortfolioID);
                return portfolio.GetPortfolioValue(timeStamp);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            try
            {
                var portfolio = portfolioRepository.Get(inPortfolioID);
                return portfolio.GetPercentChangeInValueForMonth(Year, Month);
            }
            catch (StockExchangeException e)
            {
                throw e;
            }
        }

        #endregion
         
    }
}
