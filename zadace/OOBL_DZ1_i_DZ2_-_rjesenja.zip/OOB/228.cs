﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        #region Fields

        private string displayState;
        private int freeDigits;
        private int maxDigits;
        private double memoryNumber;
        private bool isFractioned;
        private bool isPositive;
        private char currentOperation;
        private double firstOperator, secondOperator;
        private double result;
        private char lastPressed; 

        #endregion

        #region Constructor

        public Kalkulator()
        {
            displayState = "0";
            maxDigits = 10;
            freeDigits = maxDigits;
            isFractioned = false;
            isPositive = true;
            currentOperation = '0';
            firstOperator = 0;
            secondOperator = 0;
            result = 0;
            lastPressed = '0';  
        }

        #endregion

        #region ICalculator
        public void Press(char inPressedDigit)
        {
            switch(inPressedDigit)
            {
                case 'O':
                    OnOff();
                    break;

                case 'C':
                    Clear();
                    lastPressed = '0';
                    break;

                case 'G':
                    Get();
                    lastPressed = '0';
                    break;

                case 'P':
                    Put();
                    lastPressed = '0';
                    break;
                    
                case 'M':
                    Minus();
                    lastPressed = '0';
                    break;

                case ',':
                    Fraction();
                    lastPressed = '0';
                    break;

                case '+':
                    Binary(inPressedDigit);
                    lastPressed = '+';
                    break;

                case '-':
                    Binary(inPressedDigit);
                    lastPressed = '-';
                    break;

                case '*':
                    Binary(inPressedDigit);
                    lastPressed = '*';
                    break;

                case '/':
                    Binary(inPressedDigit);
                    lastPressed = '/';
                    break;

                case '=':
                    Equals();
                    lastPressed = '=';
                    break;

                case 'S':
                    Sin();
                    lastPressed = '0';
                    break;

                case 'K':
                    Cos();
                    lastPressed = '0';
                    break;

                case 'T':
                    Tan();
                    lastPressed = '0';
                    break;

                case 'Q':
                    Square();
                    lastPressed = '0';
                    break;

                case 'R':
                    Root();
                    lastPressed = '0';
                    break;

                case 'I':
                    Inverse();
                    lastPressed = '0';
                    break;

                default:
                    Number(inPressedDigit);
                    lastPressed = '0';
                    break;
            }        
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        #endregion

        #region Basic Functions

        private void OnOff()
        {
            memoryNumber = 0;
            displayState = "0";
            freeDigits = maxDigits;
            isFractioned = false;
            isPositive = true;
            currentOperation = '0';
            firstOperator = 0;
            secondOperator = 0;
            result = 0;
            lastPressed = '0';
        }

        private void Clear()
        {
            displayState = "0";
            freeDigits = maxDigits;
            isFractioned = false;
            isPositive = true;
            if (lastPressed == '=') currentOperation = '0';
        }

        private void Get()
        {
            displayState = memoryNumber.ToString();
            if (lastPressed == '=') currentOperation = '0';
        }

        private void Put()
        {
            if (!Double.TryParse(displayState, out memoryNumber)) displayState = "-E-";
            if (lastPressed == '=') currentOperation = '0';
        }

        private void Minus()
        {
            if (lastPressed == '=') currentOperation = '0';
            if (isPositive)
            {
                displayState = "-" + displayState;
                isPositive = false;
            }

            else
            {
                displayState.Remove(0, 1);
                isPositive = true;
            }
        }

        private void Binary(char _operator)
        {
            if (lastPressed == '=') currentOperation = '0';
            if (currentOperation == '0')
            {
                Double.TryParse(displayState, out firstOperator);
                displayState = GetValidDisplayState(firstOperator);
                currentOperation = _operator;
                freeDigits = maxDigits;
                isPositive = true;
                isFractioned = false;
            }

            else if (lastPressed != '0')
            {
                currentOperation = _operator;
            }

            else
            {
                secondOperator = Convert.ToDouble(displayState);
                result = Calculate(currentOperation, firstOperator, secondOperator);
                displayState = GetValidDisplayState(result);
                firstOperator = result;
                currentOperation = _operator;
                freeDigits = maxDigits;
                isPositive = true;
                isFractioned = false;
            }
        }

        private void Equals()
        {
            if (currentOperation != '0' && lastPressed != '=')
            {
                secondOperator = Convert.ToDouble(displayState);
                result = Calculate(currentOperation, firstOperator, secondOperator);
                displayState = GetValidDisplayState(result);
                if (currentOperation == '-') firstOperator = -secondOperator;  // rusko rješenje :)
                else firstOperator = secondOperator;
                secondOperator = result;
                freeDigits = maxDigits;
                isPositive = displayState[0] != '-';
                isFractioned = false;
            }

            else if (lastPressed == '=')
            {
                result = Calculate(currentOperation, firstOperator, secondOperator);
                displayState = GetValidDisplayState(result);
                secondOperator = result;
                freeDigits = maxDigits;
                isPositive = displayState[0] != '-';
                isFractioned = false;
            }

            else
            {
                Double.TryParse(displayState, out result);
                displayState = GetValidDisplayState(result);
                currentOperation = '0';
                freeDigits = maxDigits;
                isPositive = displayState[0] != '-';
                isFractioned = false;
            }

        }

        private void Sin()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = Math.Sin(value);
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;

        }

        private void Cos()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = Math.Cos(value);
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;

        }

        private void Tan()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = Math.Tan(value);
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;
        }

        private void Square()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = Math.Pow(value, 2);
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;
        }

        private void Root()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = Math.Sqrt(value);
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;
        }

        private void Inverse()
        {
            if (lastPressed == '=') currentOperation = '0';
            double value;
            Double.TryParse(displayState, out value);
            value = 1 / value;
            displayState = GetValidDisplayState(value);
            freeDigits = maxDigits;
            isPositive = displayState[0] != '-';
            isFractioned = false;
        }

        private void Fraction()
        {
            if (lastPressed == '=') currentOperation = '0';
            if (freeDigits > 0 && !isFractioned)
            {
                displayState += ",";
                isFractioned = true;
            }

            else if (freeDigits == maxDigits)
            {
                displayState = "0,";
                freeDigits--;
                isFractioned = true;
            }
        }

        private void Number(char Digit)
        {
            if (lastPressed == '=') currentOperation = '0';
            if (Digit == '0')
            {
                if (freeDigits > 0)
                {
                    if (freeDigits < maxDigits || isFractioned == true)
                    {
                        displayState += Digit.ToString();
                        freeDigits--;
                    }

                    else if (freeDigits == maxDigits && currentOperation != '0')
                    {
                        displayState = Digit.ToString();
                        freeDigits = maxDigits - 1;
                    }
                }
            }

            else if (char.IsDigit(Digit))
            {
                if (freeDigits>0)
                {
                    if (freeDigits == maxDigits && isFractioned == false)
                    {
                        displayState = Digit.ToString();
                        freeDigits = maxDigits - 1;
                    }

                    else
                    {
                        displayState += Digit.ToString();
                        freeDigits--;
                    }
                }
            }
        }

        #endregion

        #region Methods

        private double Calculate(char _operator, double firstNum, double secondNum)
        {
            double result = 0;

            switch (_operator)
            {
                case '+':
                    result = firstNum + secondNum;
                    break;

                case '-':
                    result = firstNum - secondNum;
                    break;

                case '*':
                    result = firstNum * secondNum;
                    break;

                case '/':
                    result = firstNum / secondNum;
                    break;
            }

            return result;
        }

        private string GetValidDisplayState(double value)
        {
            if (double.IsNaN(value)) return "-E-";
            if (Math.Abs(value) > Math.Pow(10, maxDigits) || Math.Abs(value) < Math.Pow(10, -(maxDigits - 1)) && value != 0)
            {
                return "-E-";
            }

            string result = value.ToString();
            int fractions = 0;

            if (result.StartsWith("-"))
            {
                fractions = maxDigits - (result.IndexOf(",") - 1);
            }

            else fractions = maxDigits - result.IndexOf(",");

            value = Math.Round(value, fractions);
            result = value.ToString();

            return result;
        }

        #endregion

    }

}
