﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private CalculatorNumber displayNumber = new CalculatorNumber(0);
        private bool error = false;
        private bool operatorPressed = false;
        private char operatorKey = '0';
        private CalculatorNumber operand;
        private CalculatorNumber memory;

        public void Press(char inPressedDigit)
        {

            switch (inPressedDigit)
            {

                case '=':
                    operatorPressed = false;
                    if (operand != null)
                    {
                        switch (operatorKey)
                        {
                            case '+':
                                displayNumber.Add(operand);
                                operand = null;
                                break;
                            case '-':
                                displayNumber.Substract(operand);
                                operand = null;
                                break;
                            case '*':
                                displayNumber.Multiply(operand);
                                operand = null;
                                break;
                            case '/':
                                displayNumber.Divide(operand);
                                operand = null;
                                break;
                        }
                        
                    }
                    else
                    {
                        switch (operatorKey)
                        {
                            case '+':
                                displayNumber.Add(displayNumber);
                                displayNumber.CheckFormat();
                                break;
                            case '-':
                                displayNumber.Substract(displayNumber);
                                displayNumber.CheckFormat();
                                break;
                            case '*':
                                displayNumber.Multiply(displayNumber);
                                displayNumber.CheckFormat();
                                break;
                            case '/':
                                displayNumber.Divide(displayNumber);
                                displayNumber.CheckFormat();
                                break;
                        }
                        
                    }
                    displayNumber.CheckDecimal();
                    displayNumber.CheckFormat();
                    operatorPressed = false;
                    break;
                case ',':
                    displayNumber.IsDecimal = true;
                    break;
                case 'S':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Sin();
                    break;
                case 'K':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Cos();
                    break;
                case 'T':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Tan();
                    break;
                case 'Q':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Quarat();
                    break;
                case 'R':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Root();
                    break;
                case 'I':
                    if (operatorPressed)
                    {
                        operand = new CalculatorNumber(displayNumber);
                    }
                    displayNumber.Inverse();
                    break;
                case 'M':
                    displayNumber.UnaryMinus();
                    break;
                case 'P':
                    memory = new CalculatorNumber(displayNumber);
                    break;
                case 'G':
                    displayNumber = memory;
                    break;
                case 'C':
                    displayNumber = new CalculatorNumber(0);
                    break;
                case 'O':
                    displayNumber = new CalculatorNumber(0);
                    operand = null;
                    memory = null;
                    break;
                default:
                    if (inPressedDigit >= '0' && inPressedDigit <= '9')
                    {
                        if (operatorPressed)
                        {
                            if (operand == null)
                            {
                                operand = new CalculatorNumber(displayNumber);
                            }
                            displayNumber = new CalculatorNumber(0);
                            operatorPressed = false;
                        }
                        displayNumber.AddDigit(inPressedDigit - '0');
                    }

                    if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
                    {
                        if (operand == null)
                        {
                            operatorPressed = true;
                            operatorKey = inPressedDigit;
                            displayNumber.CheckDecimal();
                            displayNumber.CheckFormat();
                        }
                        else
                        {
                            switch (operatorKey)
                            {
                                case '+':
                                    displayNumber.Add(operand);
                                    displayNumber.CheckFormat();
                                    break;
                                case '-':
                                    displayNumber.Substract(operand);
                                    displayNumber.CheckFormat();
                                    break;
                                case '*':
                                    displayNumber.Multiply(operand);
                                    displayNumber.CheckFormat();
                                    break;
                                case '/':
                                    displayNumber.Divide(operand);
                                    displayNumber.CheckFormat();
                                    break;
                            }
                            displayNumber.CheckDecimal();
                            displayNumber.CheckFormat();
                            operand = null;
                            operatorPressed = true;
                            operatorKey = inPressedDigit;
                        }

                    }
                    break;
                    
            }
            error = displayNumber.Error;
        }

        public string GetCurrentDisplayState()
        {
            if (!error)
            {
                return displayNumber.ToString();
            }
            else
            {
                return "-E-";
            }
        }

    }

    public class CalculatorNumber
    {
        private double value;
        public bool IsDecimal { get; set; }
        private int numberOfDecimals;
        private CalculatorNumber displayNumber;
        public bool Error { get; set; }

        public CalculatorNumber(double p)
        {
            value = p;
            IsDecimal = false;
            numberOfDecimals = 0;
            Error = false;
        }

        public CalculatorNumber(CalculatorNumber displayNumber)
        {
            
            this.value = displayNumber.value;
        }

        public void UnaryMinus()
        {
            value = value * (-1);
        }
        public void AddDigit(int digit)
        {
            double oldValue = value;
            if (!IsDecimal)
            {
                oldValue = value;
                if (value >= 0)
                {
                    value = value * 10 + digit;
                }
                else
                {
                    value = value * 10 - digit;
                }
                CheckFormat();
                if (Error)
                {
                    value = oldValue;
                    Error = false;
                }
            }
            else
            {
                numberOfDecimals++;
                if (value >= 0)
                {
                    value = value + (double)digit / (Math.Pow(10, numberOfDecimals));
                }
                else
                {
                    value = value - (double)digit / (Math.Pow(10, numberOfDecimals));
                }
                CheckFormat();

            }

        }



        public int DigitsInt
        {
            get
            {
                string longString = value.ToString("F99").TrimEnd("0".ToCharArray());
                var numberSplit = longString.Split(',');
                if (!String.IsNullOrEmpty(numberSplit[0]))
                {
                    if (numberSplit[0][0] != '-')
                    {
                        return numberSplit[0].Length;
                    }
                    else
                    {
                        return numberSplit[0].Length - 1;
                    }
                }
                else
                {
                    return 0;
                }

            }
        }


        public void CheckFormat()
        {
            string longString = value.ToString("F99").TrimEnd("0".ToCharArray());
            var numberSplit = longString.Split(',');
            if (DigitsInt > 10)
            {
                Error = true;
            }
            else
            {
                if (IsDecimal)
                {
                    int decimalDigits = 10 - DigitsInt;
                    value = Math.Round(value, decimalDigits);
                    numberOfDecimals = Math.Min(decimalDigits, numberOfDecimals);
                    Error = false;
                    if (numberOfDecimals == 0)
                    {
                        IsDecimal = false;
                    }
                }
            }


        }

        public override string ToString()
        {
            if(IsDecimal && value == ((int)value))
            {
                return value.ToString() + ',' + new string('0', numberOfDecimals);
            }
            return value.ToString();
        }


        internal void Sin()
        {

            value = Math.Sin(value);
            CheckDecimal();
            CheckFormat();
        }

        internal void Cos()
        {

            value = Math.Cos(value);
            CheckDecimal();
            CheckFormat();
        }
        internal void Tan()
        {
            
            value = Math.Tan(value);
            CheckDecimal();
            CheckFormat();
        }

        internal void Quarat()
        {
            value = value * value;
            CheckFormat();
        }

        internal void Root()
        {
            if (value < 0)
            {
                Error = true;
            }
            else
            {
                value = Math.Sqrt(value);
                CheckDecimal();
                CheckFormat();
            }
        }

        public void CheckDecimal()
        {
            if (value == ((int)value))
            {
                IsDecimal = false;
                numberOfDecimals = 0;
            }
            else
            {
                IsDecimal = true;
            }
        }

        internal void Inverse()
        {
            if (value == 0)
            {
                Error = true;
            }
            else
            {
                value = 1 / value;
                CheckDecimal();
                CheckFormat();
            }
        }

        internal void Add(CalculatorNumber operand)
        {
            this.value = this.value + operand.value;
            CheckDecimal();
            CheckFormat();
        }

        internal void Substract(CalculatorNumber operand)
        {
            this.value = operand.value - this.value;
            CheckDecimal();
            CheckFormat();
        }

        internal void Multiply(CalculatorNumber operand)
        {
            this.value = this.value * operand.value;
            CheckDecimal();
            CheckFormat();
        }

        internal void Divide(CalculatorNumber operand)
        {
            if (operand.value == 0)
            {
                Error = true;
            }
            else
            {
                value = operand.value / value;
                CheckDecimal();
                CheckFormat();
            }
        }
    }







}
