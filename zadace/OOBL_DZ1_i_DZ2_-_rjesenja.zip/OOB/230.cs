﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string current_display = "0";
        double temp_number = 0;
        double change_number_pos = 0;
        int num_of_numbers = 0;
        double root = 0.5;
        double MAX_result = 9999999999;
        int prepare_result;
        double result;
        double control_divide;
        double control_num;
        double memory = 0;
        char last_income = 'Y';
        char last_operation = '#';
        bool is_first_operation;

        public void Press(char inPressedDigit)
        {
            is_first_operation = IsFirstOperationCheck();

            switch (inPressedDigit)
            {
                case '+':
                case '-':
                case '*':
                case '/':
                    if (is_first_operation)
                    {
                        last_operation = inPressedDigit;
                        temp_number = Convert.ToDouble(current_display);
                        last_income = inPressedDigit;
                        break;
                    }
                    else if (last_income == '+' || last_income == '-' || last_income == '*' || last_income == '/')
                    {

                        last_operation = inPressedDigit;
                        last_income = inPressedDigit;
                        break;
                    }
                    else
                    {
                        Calculate(last_operation);
                        last_operation = inPressedDigit;
                        last_income = inPressedDigit;
                        break;
                    }

                case 'R':
                    Root();
                    last_income = inPressedDigit;
                    break;

                case 'S':
                    Calculate('S');
                    last_income = 'S';
                    break;

                case 'K':
                    Calculate('K');
                    last_income = 'K';
                    break;

                case '=':
                    Calculate(last_operation);
                    last_operation = inPressedDigit;
                    last_income = inPressedDigit;
                    break;

                case ',':
                    current_display = current_display + inPressedDigit;
                    last_income = inPressedDigit;
                    break;

                case 'Q':
                    result = Convert.ToDouble(current_display);
                    result = Math.Pow(result, 2);
                    current_display = result.ToString();
                    last_income = 'Q';
                    break;

                case 'P':
                    memory = Convert.ToDouble(current_display);
                    last_income = inPressedDigit;
                    break;

                case 'G':
                    current_display = memory.ToString();
                    last_income = inPressedDigit;
                    break;

                case 'M':
                    ChangePositiveNegative();
                    last_income = inPressedDigit;
                    break;

                case 'O':
                    current_display = "0";
                    memory = 0;
                    temp_number = 0;
                    num_of_numbers = 0;
                    break;

                case 'I':
                    Inverse();
                    last_income = inPressedDigit;
                    break;
                
                case 'T':
                    Calculate('T');
                    last_income = 'T';
                    break;

                case 'C':
                    current_display = "0";
                    last_income = inPressedDigit;
                    break;


                default:
                    if ((char.IsNumber(last_income) || last_income == 'P' || last_income == ',' || last_income == 'M') && num_of_numbers < 11)
                    {
                        current_display = current_display + inPressedDigit.ToString();
                        last_income = inPressedDigit;
                        num_of_numbers++;
                    }
                    else if (num_of_numbers > 10)
                        break;
                    else
                    {
                        current_display = inPressedDigit.ToString();
                        last_income = inPressedDigit;
                        num_of_numbers = 2;
                    }
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return CheckAndPrepareResult(current_display);
        }

        private Boolean IsFirstOperationCheck()
        {
            if (last_operation == '#')
                return true;
            return false;
        }

        private void Calculate(char operation_to_do)
        {
            switch (operation_to_do)
            {
                case '+':
                    result = Convert.ToDouble(current_display) + temp_number;
                    temp_number = result;
                    current_display = result.ToString();
                    break;

                case '-':
                    result = temp_number - Convert.ToDouble(current_display);
                    temp_number = result;
                    current_display = result.ToString();
                    break;

                case '*':
                    result = temp_number * Convert.ToDouble(current_display);
                    temp_number = result;
                    current_display = result.ToString();
                    break;

                case '/':
                    control_divide = Convert.ToDouble(current_display);
                    if (control_divide == 0)
                        current_display = "-E-";
                    else
                    {
                        result = temp_number / Convert.ToDouble(current_display);
                        current_display = result.ToString();
                    }
                        
                    temp_number = result;
                    break;

                case 'S':
                    result = Convert.ToDouble(current_display);
                    result = Math.Sin(result);
                    result = Math.Round(result, 9);
                    current_display = result.ToString();
                    break;

                case 'K':
                    result = Convert.ToDouble(current_display);
                    result = Math.Cos(result);
                    result = Math.Round(result, 9);
                    current_display = result.ToString();
                    break;

                case 'T':
                    result = Convert.ToDouble(current_display);
                    result = Math.Tan(result);
                    prepare_result = CountDigitsNatural(Convert.ToInt32(result));
                    prepare_result = 10 - prepare_result;
                    result = Math.Round(result, prepare_result);
                    current_display = result.ToString();
                    break;

                case '#':
                    result = Convert.ToDouble(current_display);
                    current_display = result.ToString();
                    break;
            }
                
        }

        private void ChangePositiveNegative()
        {
            change_number_pos = Convert.ToDouble(current_display);
            change_number_pos = change_number_pos * (-1);
            current_display = change_number_pos.ToString();
        }

        private string CheckAndPrepareResult(string result_for_check)
        {
            if (result_for_check == "-E-")
            {
                return "-E-";
            }
            control_num = Convert.ToDouble(current_display);

            if (control_num > MAX_result || control_num < MAX_result * (-1))
                return "-E-";
            prepare_result = CountDigitsNatural(Convert.ToInt32(control_num));
            prepare_result = 10 - prepare_result;
            control_num = Math.Round(control_num, prepare_result);
            return control_num.ToString();
        }

        private void Inverse()
        {
            control_divide = Convert.ToDouble(current_display);
            if (control_divide == 0)
            {
                current_display = "-E-";
            }
            else
            {
                result = 1 / control_divide;
                current_display = result.ToString();
            }
        }

        private void Root()
        {
            result = Convert.ToDouble(current_display);
            result = Math.Pow(result, root);
            prepare_result = CountDigitsNatural(Convert.ToInt32(result));
            prepare_result = 10 - prepare_result;
            result = Math.Round(result, prepare_result);
            current_display = result.ToString();
        }

        private int CountDigitsNatural(int count_number)
        {
            int count = 1;
            while (count_number > 10)
            {
                count++;
                count_number = count_number / 10;
            }
            return count;
        }
    }


}
