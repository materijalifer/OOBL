﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Share> shares;
        private Dictionary<string, Index> indexes;
        private Dictionary<string, Portfolio> portfolies;

        public StockExchange()
        {
            //spremnik dionica
            shares = new Dictionary<string, Share>();

            //spremnik indeksa
            indexes = new Dictionary<string, Index>();

            //spremnik portfolia
            portfolies = new Dictionary<string, Portfolio>();
        }

        private decimal round3dec(decimal d) 
        {
            return Math.Round(d, 3);
        }

        /*
         * Metoda provjerava dali se dionice sa nazivom inStockName
         * nalaze u spremniku sa dionicama
         */
        private string checkInStockName(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("StockName je null");
            }

            //ignorira se velicina slova
            inStockName = inStockName.ToUpper();

            if (!shares.ContainsKey(inStockName))
            {
                throw new StockExchangeException("Nepostoji dionica sa zadanim imenom");
            }

            return inStockName;
        }

        /*
         * Metoda provjerava dali se index sa nazivom inIndexName
         * nalazi u spremniku sa index-ima
         */
        private string checkInIndexName(string inIndexName)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("IndexName je null");
            }

            //ignorira se velicina slova
            inIndexName = inIndexName.ToUpper();

            if (!indexes.ContainsKey(inIndexName))
            {
                throw new StockExchangeException("Nepostoji index sa zadanim imenom");
            }

            return inIndexName;
        }

        /*
         * Metoda provjerava dali se portfelj sa nazivom inPortfolioID
         * nalazi u spremniku sa portfeljima
         */
        private void checkInPortfolioID(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("PortfolioID je null");
            }

            if (!portfolies.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("Nepostoji portfelj sa zadanim ID-om");
            }
        }

        //dodaje dionicu s početnom cijenom na burzu
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Null ime dionice");
            }

            //ignorira se velicina slova
            inStockName = inStockName.ToUpper();

            Share share = new Share(inNumberOfShares, inInitialPrice, inTimeStamp);

            if (shares.ContainsKey(inStockName))
            {
                throw new StockExchangeException("Vec postoji dionica");
            }

            shares.Add(inStockName, share);
        }

        //briše dionicu s burze
        public void DelistStock(string inStockName)
        {
            inStockName = checkInStockName(inStockName);
            shares.Remove(inStockName);

            //moramo obrisati dionice ako su u nekom index-u
            foreach (var indexPair in indexes)
            {
                if (indexPair.Value.isInIndex(inStockName))
                {
                    indexPair.Value.removeShare(inStockName);
                    break;
                }
            }

            //moramo obrisati dionice ako su u nekim portfolijima
            foreach (var portfolioPair in portfolies)
            {
                if (portfolioPair.Value.isStockIn(inStockName))
                {
                    portfolioPair.Value.removeStock(inStockName);
                }
            }
        }

        //provjerava postoji li tražena dionica na burzi
        public bool StockExists(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Ime dionice je null");
            }

            //ignorira se velicina slova
            inStockName = inStockName.ToUpper();

            return shares.ContainsKey(inStockName);
        }

        //vraća broj dionica na burzi
        public int NumberOfStocks()
        {
            return shares.Count;
        }

        //postavlja cijenu dionice za određeno vrijeme
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            inStockName = checkInStockName(inStockName);

            Share share;
            shares.TryGetValue(inStockName, out share);
            share.setPrice(inTimeStamp, inStockValue);
        }

        //dohvaća cijenu dionice za neko vrijeme
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            inStockName = checkInStockName(inStockName);

            Share share;
            shares.TryGetValue(inStockName, out share);

            return round3dec(share.getPrice(inTimeStamp));
        }

        //dohvaća početnu cijenu dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            inStockName = checkInStockName(inStockName);

            Share share;
            shares.TryGetValue(inStockName, out share);

            return round3dec(share.getInitialPrice());
        }

        //dohvaća zadnju cijenu dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            inStockName = checkInStockName(inStockName);

            Share share;
            shares.TryGetValue(inStockName, out share);

            return round3dec(share.getLastPrice());
        }

        //stvara novi indeks na burzi
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("IndexName je null");
            }

            //ignorira se velicina slova
            inIndexName = inIndexName.ToUpper();

            if (indexes.ContainsKey(inIndexName))
            {
                throw new StockExchangeException("Index vec postoji");
            }

            //tvornica za index
            switch (inIndexType)
            { 
                case IndexTypes.AVERAGE:
                    indexes.Add(inIndexName, new IndexAverage());
                    break;

                case IndexTypes.WEIGHTED:
                    indexes.Add(inIndexName, new IndexWeight());
                    break;

                default:
                    throw new StockExchangeException("Krivi tip indexa");
            }
        }

        //dodaje dionicu u indeks
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            inIndexName = checkInIndexName(inIndexName);
            inStockName = checkInStockName(inStockName);

            Index index;
            indexes.TryGetValue(inIndexName, out index);

            Share share;
            shares.TryGetValue(inStockName, out share);

            index.addShare(inStockName, share);
        }

        //briše dionicu iz indeksa
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            inIndexName = checkInIndexName(inIndexName);
            inStockName = checkInStockName(inStockName);

            Index index;
            indexes.TryGetValue(inIndexName, out index);
            index.removeShare(inStockName);
        }

        //provjerava je li dionica u indeksu
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            inIndexName = checkInIndexName(inIndexName);
            if (inStockName == null)
            {
                throw new StockExchangeException("Null je ime dionice");
            }

            Index index;
            indexes.TryGetValue(inIndexName, out index);

            //ignorira se velicina slova
            inStockName = inStockName.ToUpper();

            return index.isShareInIndex(inStockName);
        }

        //dohvaća vrijednost indeksa
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            inIndexName = checkInIndexName(inIndexName);
            if (inTimeStamp == null)
            {
                throw new StockExchangeException("Null datum/vrijeme");
            }

            Index index;
            indexes.TryGetValue(inIndexName, out index);

            return round3dec(index.getIndexValue(inTimeStamp));

        }

        //provjerava postoji li traženi indeks na burzi
        public bool IndexExists(string inIndexName)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Null IndexName");
            }

            //ignorira se velicina slova
            inIndexName = inIndexName.ToUpper();

            return indexes.ContainsKey(inIndexName);
        }

        //dohvaća broj indeksa na burzi
        public int NumberOfIndices()
        {
            return indexes.Count;
        }

        //dohvaća broj dionica u traženom indeksu
        public int NumberOfStocksInIndex(string inIndexName)
        {
            inIndexName = checkInIndexName(inIndexName);

            Index index;
            indexes.TryGetValue(inIndexName, out index);

            return index.numOfShares();
        }

        //stvara novi portfolio na burzi
        public void CreatePortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Null portfelj ID");
            }

            if (portfolies.ContainsKey(inPortfolioID)) 
            {
                throw new StockExchangeException("Vec postoji portfelj");
            }

            portfolies.Add(inPortfolioID, new Portfolio());
        }

        //dodaje određeni broj dionica u portfolio 
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            checkInPortfolioID(inPortfolioID);
            inStockName = checkInStockName(inStockName);
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Nevaljani broj dionica");
            }

            Share share;
            shares.TryGetValue(inStockName, out share);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            portfolio.addShares(inStockName, share, numberOfShares);

        }

        //briše određeni broj dionica iz portfolija
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            checkInPortfolioID(inPortfolioID);
            inStockName = checkInStockName(inStockName);
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Nevaljani broj dionica");
            }

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            portfolio.removeShares(inStockName, numberOfShares);        
        }

        //briše dionicu iz portfolia 
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            checkInPortfolioID(inPortfolioID);
            inStockName = checkInStockName(inStockName);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            portfolio.removeStock(inStockName);
        }

        //dohvaća broj portfolija na burzi
        public int NumberOfPortfolios()
        {
            return portfolies.Count;
        }

        //dohvaća broj dionica u traženom portfoliju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            checkInPortfolioID(inPortfolioID);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            return portfolio.numberOfStocks();
        }

        //provjerava postoji li traženi portfolio na burzi
        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolies.ContainsKey(inPortfolioID);
        }

        //provjerava nalazi li se dionica u portfoliju
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            checkInPortfolioID(inPortfolioID);
            inStockName = checkInStockName(inStockName);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            return portfolio.isStockIn(inStockName);
        }

        //dohvaća broj dionica u traženom portfoliju
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            checkInPortfolioID(inPortfolioID);
            inStockName = checkInStockName(inStockName);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            return portfolio.numOfSharesOfStock(inStockName);
        }

        //dohvaća vrijednost portfolija u određenom trenutku
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            checkInPortfolioID(inPortfolioID);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            return portfolio.getValue(timeStamp);
        }

        //dohvaća mjeseću promjenu vrijednosti portfolija
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            checkInPortfolioID(inPortfolioID);

            Portfolio portfolio;
            portfolies.TryGetValue(inPortfolioID, out portfolio);

            DateTime startOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime endOfMonth = new DateTime(Year, Month,
                                                DateTime.DaysInMonth(Year, Month),
                                                23, 59, 59, 999);

            Decimal startValue = portfolio.getValue(startOfMonth);
            Decimal endValue = portfolio.getValue(startOfMonth);

            return round3dec(100 * (endValue - startValue) / startValue);
            
        }
    }

    /*
     * Klasa share predstavlja grupu od numberOfShares dionica
     * za dinonicu se definiraju cijene koje vrijede od nekog trenutka (datuma)
     */
    public class Share
    {
        private SortedList<DateTime, decimal> prices;
        private long numberOfShares;
        private decimal initialPrice;
        private long numOfSharesNotInPortfolies;    //broj dionica koji se ne nalazi u nekom portfoliu
        public bool isInIndex;

        public Share(long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inTimeStamp == null || inNumberOfShares <= 0 || inInitialPrice <= 0)
            {
                throw new StockExchangeException("Null datum/vrijeme ili krivi broj ili kriva cijena");
            }

            prices = new SortedList<DateTime, decimal>();
            prices.Add(inTimeStamp, inInitialPrice);
            this.numberOfShares = inNumberOfShares;
            this.initialPrice = inInitialPrice;
            this.numOfSharesNotInPortfolies = inNumberOfShares;
            this.isInIndex = false;
        }

        //vraća broj dionica
        public long getNumberOfShares() 
        {
            return numberOfShares;
        }

        //vraća prvu postavljenu cjenu (ne nužno prvu po datumima)
        public decimal getInitialPrice()
        {
            return initialPrice;
        }

        //vraća zadnju cjenu (ona koja je zadnja po datumu)
        public decimal getLastPrice()
        {
            return prices.Last().Value;
        }

        //u spremik sa cjenama se dodaje nova cjena i trenutak od kojeg vrijedi
        public void setPrice(DateTime inTimeStamp, decimal inStockValue) 
        {
            if (inTimeStamp == null || inStockValue <= 0)
            {
                throw new StockExchangeException("Null datum/vrijeme ili cijena nevaljala");
            }

            if (prices.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Vec postoji cijena za taj trenutak");
            }

            prices.Add(inTimeStamp, inStockValue);
        }

        //vraća cijenu za zadani trenutak
        public decimal getPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp == null)
            {
                throw new StockExchangeException("Null datum/vrijeme");
            }

            //prvi definirani datum se početno uzima kao onaj od kojeg ćemo gledati cijenu
            DateTime lastDateTime = prices.First().Key;

            if (lastDateTime.CompareTo(inTimeStamp) > 0)
            {
                throw new StockExchangeException("Cijena dionice nije definirana za zadani trenutak");
            }

            //gledamo sve datume koji su prije promatranog i koji predefiniraju cijenu
            foreach (var dateTime in prices)
            {
                if (dateTime.Key.CompareTo(inTimeStamp) > 0)
                {
                    break;
                }
                else if (dateTime.Key.CompareTo(lastDateTime) > 0)
                {
                    lastDateTime = dateTime.Key;
                }
            }

            decimal price;
            prices.TryGetValue(lastDateTime, out price);

            return price;
        }

        //numberOfShares dionica se uzima za portfolio
        public void takeAmountOfShares(int numberOfShares)
        {
            if (numberOfShares > numOfSharesNotInPortfolies)
            {
                throw new StockExchangeException("Nedovoljno preostalih dionica");
            }

            numOfSharesNotInPortfolies -= numberOfShares;
        }

        //numberOfShares dionica se vraca iz portfolia
        public void returnAmountOfShares(int numberOfShares)
        {
            if (numberOfShares + numOfSharesNotInPortfolies >
                this.numberOfShares)
            {
                throw new StockExchangeException("Previse vracenih dionica");
            }

            numOfSharesNotInPortfolies += numberOfShares;
        }

    }

    /*
     * Klasa predstavlja index koji će u sebi imati određene skupove dionica
     * i pruža osnovne funkcije da dodavanje, brisanje i ispitivanje sionica, 
     * te izračun samog indexa
     */
    public abstract class Index
    {
        protected Dictionary<string, Share> shares;

        public Index()
        {
            shares = new Dictionary<string, Share>();
        }

        //vraća dali se dionice shareName naleze u indexu
        public bool isInIndex(string shareName)
        {
            return shares.ContainsKey(shareName);
        }

        //u index se dodaju dionice share sa imenom shareName
        public void addShare(string shareName, Share share)
        {
            if (share == null || shareName == null)
            {
                throw new StockExchangeException("Null ime dionice ili dionica");
            }

            if (shares.ContainsKey(shareName))
            {
                throw new StockExchangeException("U indexu vec postoji zadana dionica");
            }

            if (share.isInIndex)
            {
                throw new StockExchangeException("Dionica je već u nekom index-u");
            }

            shares.Add(shareName, share);
            share.isInIndex = true;
        }

        //iz indexa se brisu dionice s nazivom shareName
        public void removeShare(string shareName)
        {
            if (shareName == null)
            {
                throw new StockExchangeException("Null ime dionice u indexu");
            }

            if (!shares.ContainsKey(shareName))
            {
                throw new StockExchangeException("U indexu ne postoji zadana dionica");
            }

            shares.Remove(shareName);

            Share share;
            shares.TryGetValue(shareName, out share);
            share.isInIndex = false;
        }

        //vraća dali se dionice imena shareName nalaze u index-u
        public bool isShareInIndex(string shareName)
        {
            return shares.ContainsKey(shareName);
        }

        //vrać broj skupina dionica
        public int numOfShares()
        {
            return shares.Count;
        }

        //racuna se vrijednost index-a
        public abstract decimal getIndexValue(DateTime inTimeStamp);
    }

    public class IndexAverage : Index
    {
        //racuna prosjek po aritmetičkoj sredini svih dionica
        public override decimal getIndexValue(DateTime inTimeStamp)
        {
            decimal sumPrice = 0;
            decimal numOfShares = 0;

            //ako nema dionica u indexu
            if (shares.Count == 0)
            {
                return 0;
            }

            foreach (var sharePair in shares)
            {
                sumPrice += sharePair.Value.getPrice(inTimeStamp) *
                            sharePair.Value.getNumberOfShares();
                numOfShares += sharePair.Value.getNumberOfShares();

            }

            return sumPrice / numOfShares;
        }
    }

    public class IndexWeight : Index
    {
        //racuna prosjek po težinskoj sredini svih dionica
        public override decimal getIndexValue(DateTime inTimeStamp)
        {
            decimal sumOfWeights = 0;
            decimal sumOfPrices = 0;

            //ako nema dionica u indexu
            if (shares.Count == 0)
            {
                return 0;
            }

            foreach (var sharePair in shares)
            {
                Share share = sharePair.Value;
                Decimal price = share.getPrice(inTimeStamp);
                sumOfWeights += price * price * share.getNumberOfShares();
                sumOfPrices += price * share.getNumberOfShares();
            }

            return sumOfWeights / sumOfPrices;
        }
    }

    /*
     * Klasa predstavlja jedan portfolio u kojemu može biti određen broj 
     * dionica iz pojedinih skupina dionica
     * zna se točno koliko je dionica iz kojeg skupa pridjeljeno u ovaj portfolio
     */
    public class Portfolio
    {
        private Dictionary<string, Share> shares;
        private Dictionary<string, int> numOfSharesIn;

        public Portfolio()
        {
            shares = new Dictionary<string, Share>();
            numOfSharesIn = new Dictionary<string, int>();
        }

        //vraća broj razlicitih dionica
        public int numberOfStocks() 
        {
            return shares.Count;
        }

        //vraća dali su dionice s imenom stockName u portfoliu
        public bool isStockIn(string stockName)
        {
            if (stockName == null)
            {
                throw new StockExchangeException("Null je ime dionica");
            }

            return shares.ContainsKey(stockName);
        }

        //vraća broj dionica ij jednog skupa dionica (iz jednog Share-a)
        public int numOfSharesOfStock(string shareName)
        {
            if (shareName == null)
            {
                throw new StockExchangeException("Null je ime dionica");
            }

            if (numOfSharesIn.ContainsKey(shareName))
            {
                int numberOfIn;
                numOfSharesIn.TryGetValue(shareName, out numberOfIn);
                return numberOfIn;
            }
            else
            {
                return 0;
            }
        }

        //u portfolio se dodaje numberOfShares dionica share s imenom shareName
        public void addShares(string shareName, Share share, int numberOfShares)
        {
            if (shareName == null || share == null)
            {
                throw new StockExchangeException("Null je ime dionice ili dionica");
            }

            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Neveljani broj dionica");
            }

            //pri dodavanju dionica moramo oduzeti broj preostalih slobodnih dionica
            share.takeAmountOfShares(numberOfShares);

            //ako već postoje dionice iz zadanog skupa onda trebamo samo povećati broj
            if (shares.ContainsKey(shareName))
            {
                int numberOfIn;
                numOfSharesIn.TryGetValue(shareName, out numberOfIn);
                numberOfIn += numberOfShares;
                numOfSharesIn.Remove(shareName);
                numOfSharesIn.Add(shareName, numberOfIn);
            }
            //ako se niti jedna dionica imena shareName ne nalazi u portfoliu
            else
            {
                shares.Add(shareName, share);
                numOfSharesIn.Add(shareName, numberOfShares);
            }
        }

        //brise se numberOfShares dionica s imenom shareName
        public void removeShares(string shareName, int numberOfShares)
        {
            if (shareName == null)
            {
                throw new StockExchangeException("Null je ime dionice ili dionica");
            }

            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Neveljani broj dionica");
            }

            if (shares.ContainsKey(shareName))
            {
                int numberOfIn;
                numOfSharesIn.TryGetValue(shareName, out numberOfIn);

                if (numberOfShares > numberOfIn)
                {
                    throw new StockExchangeException("Previse dionica za maknuti iz portfelja");
                }

                numberOfIn -= numberOfShares;
                numOfSharesIn.Remove(shareName);
                numOfSharesIn.Add(shareName, numberOfIn);

                Share share;
                shares.TryGetValue(shareName, out share);

                //u skup dionica vraćamo oduzeti broj 
                share.returnAmountOfShares(numberOfShares);

                //ako nije ostala niti jedna dionica imena shareName onda brisemo taj skup iz portfolia
                if (numberOfIn == 0)
                {
                    shares.Remove(shareName);
                    numOfSharesIn.Remove(shareName);
                }
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji u portfoliu");
            }

        }

        //brisu se sve dionice s imenom shareName
        public void removeStock(string shareName)
        {
            if (shareName == null)
            {
                throw new StockExchangeException("Null je ime dionica");
            }

            if (!shares.ContainsKey(shareName))
            {
                throw new StockExchangeException("Dionica ne postoji u portfoliu");
            }

            int numberOfIn;
            numOfSharesIn.TryGetValue(shareName, out numberOfIn);

            Share share;
            shares.TryGetValue(shareName, out share);

            //vraćamo sve dionice koje su bile u portfoliu da bude slobodne
            share.returnAmountOfShares(numberOfIn);

            shares.Remove(shareName);
            numOfSharesIn.Remove(shareName);
        }

        //vraća se vrijednost portfolia za određeni trenutak timeStamp
        public decimal getValue(DateTime timeStamp) 
        {
            decimal suma = 0;

            foreach (var sharePair in shares)
            {
                int numberOfIn;
                numOfSharesIn.TryGetValue(sharePair.Key, out numberOfIn);
                suma += numberOfIn * sharePair.Value.getPrice(timeStamp);
            }

            return suma;
        }
    
    }
}
