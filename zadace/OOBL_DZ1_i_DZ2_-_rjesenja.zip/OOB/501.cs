﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string display = "0";
        double lastCalculated = 0;
        double previous = 0;
        double current = 0;
        string memorized = "";
        char lastIn = 'N';
        bool isDecimal = false;
        char lastOperator = ' ';
        

        public void Press(char inPressed)
        {
            bool i= Char.IsNumber(inPressed);
            char number = inPressed;
            if (i == true) { inPressed = 'N'; }
            
            char operand=' ';
            if (inPressed.Equals('+') | inPressed.Equals('+') | inPressed.Equals('+') | inPressed.Equals('+'))
            { operand = inPressed; inPressed = 'F'; }
            char uoperand=' ';
            if (inPressed.Equals('S') | inPressed.Equals('K') | inPressed.Equals('T') | inPressed.Equals('Q') | inPressed.Equals('R') | inPressed.Equals('I'))
            { uoperand = inPressed; inPressed = 'H'; }          

            switch (inPressed) {

                case 'C':
                    {
                        display = "0";
                        isDecimal = false;
                        lastIn = 'N';
                        break;
                    }

                case '=':
                    {
                        if (lastIn == 'H') {
                            display = lastCalculated.ToString();
                            break;
                        }
                        isDecimal = false;
                        if (lastIn == 'F')
                        {
                            previous = Convert.ToDouble(display);
                            goto case 'F';
                        }
                        else
                        {
                            goto case 'F';
                        }
                    }

                case 'M':
                    {
                        double result = Convert.ToDouble(display);
                        result *= -1;
                        display = result.ToString();
                        lastIn = 'M';
                        break;
                    }

                case 'P':
                    {
                        
                        isDecimal = false;
                        memorized = display;
                        lastIn = 'P';
                        break;
                    }

                case 'G':
                    {
                        isDecimal = false;
                        display = memorized.ToString();
                        lastIn = 'G';
                        break;
                    }

                case 'O':
                    {
                        display = "0";
                        memorized = "";
                        lastCalculated = 0;
                        lastIn = 'N';
                        isDecimal = false;
                        lastOperator = ' ';
                        previous = 0;
                        current = 0;
                        break;
                    }

                case 'N' : 
                    {
                        if (lastIn == 'F') {
                            display = number.ToString();
                        }

                        int x = display.Count(c => Char.IsNumber(c));
                        
                        if (x < 10)
                        {
                            if (!isDecimal)
                            {
                                double result = Convert.ToDouble(display);
                                display = Math.Round(result).ToString();
                            }
                            display = display + number;
                            
                        }
                        if (Convert.ToDouble(display) > 1)
                        {
                            String s = display.TrimStart(new Char[] { '0' });
                            display = s;
                        }
                        lastIn = 'N';
                        break;
                    }

                case ',':
                    {
                        if ((isDecimal == false) && (lastIn == 'N')) { display += ','; isDecimal = true; }
                        lastIn = ',';
                        break;
                    }

                case 'F':
                    {
                        if (lastOperator == ' ') {
                            lastOperator = operand;
                        }
                        


                        if (lastIn == 'N' || inPressed == '=')
                        {
                            isDecimal = false;
                            char vrati = operand;
                           
                            operand = lastOperator;
                            current = Convert.ToDouble(display);
                            if (inPressed == '=')
                            {
                                previous = current;
                            }
                            if (operand == '+')
                            {
                                previous += current;
                            }
                            if (operand == '-')
                            {
                                previous -= current;
                            }
                            if (operand == '*')
                            {
                                previous *= current;
                            }
                            if (operand == '/')
                            {
                                if (current == 0)
                                {
                                    display = "-E-";
                                }
                                else
                                {
                                    previous /= current;
                                }
                            }
                            if (Math.Abs(previous) > 999999999)
                            {
                                display = "-E-";
                            }
                            if (!display.Equals("-E-"))
                            {
                                display = previous.ToString();
                            }
                            lastOperator = vrati;
                        }

                        else {
                            lastOperator = operand;
                        }
                        lastIn = 'F';
                        break;
                    }
                case 'H':
                    {
                        isDecimal = false;
                        current = Convert.ToDouble(display);
                        if (uoperand== 'S') {
                            double result= Math.Sin(current);
                            lastCalculated = result;
                        }
                        if (uoperand == 'K')
                        {
                            double result = Math.Cos(current);
                            lastCalculated = result;
                        }

                        if (uoperand == 'T')
                        {
                            double result = Math.Tan(current);
                            lastCalculated = result;
                        }
                        if (uoperand == 'Q')
                        {
                            double result = Math.Pow(current,2);
                            lastCalculated = result;
                        }
                        if (uoperand == 'R')
                        {
                            double result = Math.Sqrt(current);
                            lastCalculated = result;
                        }
                        if (uoperand == 'I')
                        {
                            if (current == 0)
                            {
                                display = "-E-";
                            }
                            else
                            {
                                double result = 1 / current;
                                lastCalculated = result;
                            }
                        }
                        if (Math.Abs(lastCalculated) > 999999999) {
                            display = "-E-";
                        }
                        if (display != "-E-")
                        {
                            display = lastCalculated.ToString();
                        }
                        else
                        {
                            if (inPressed == 'N' && inPressed != 'F' && lastOperator == '+' && lastOperator == ' ')
                            {
                                display = lastCalculated.ToString();
                            }
                        }

                        lastIn = 'H';
                        break;
                    }
                default: 
                    {
                        display = "-E-";
                        break;
                    }

            }
            
        }

        public string GetCurrentDisplayState()
        {
            int x = display.Count(c => Char.IsNumber(c));
            if (x > 10)
            {
                double lol = Convert.ToDouble(display);
                lol = Math.Round(lol, x - 10 + display.IndexOf(',')+1);
                display = lol.ToString();
            }

            return display;
        }
    }


}
