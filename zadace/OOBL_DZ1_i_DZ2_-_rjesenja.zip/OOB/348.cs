﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        protected IDictionary<string, Stock> _stocks;
        protected IDictionary<string, Index> _indices;
        protected IDictionary<string, Portfolio> _portfolios;

        public StockExchange()
        {
            _stocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
            _indices = new Dictionary<string, Index>(StringComparer.InvariantCultureIgnoreCase);
            _portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
            {
                Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                _stocks.Add(newStock.Name, newStock);
            }
            else
            {
                throw new StockExchangeException("Stock with the same name already exists.");
            }
        }

        public void DelistStock(string inStockName)
        {
            Stock s = getStock(inStockName);

            foreach (var p in _portfolios.Values)
            {
                if (p.IsStockPartOfPortfolio(s))
                {
                    p.RemoveStock(s);
                }
            }
            foreach (var i in _indices.Values)
            {
                if (i.IsStockPartOfIndex(s))
                {
                    i.RemoveStock(s);
                }
            }

            _stocks.Remove(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            getStock(inStockName).SetStockValue(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return getStock(inStockName).GetStockValue(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return getStock(inStockName).GetInitialValue();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return getStock(inStockName).GetLastValue();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {
                Index newIndex = IndexFactory.CreateIndex(inIndexType, inIndexName);
                _indices.Add(newIndex.Name, newIndex);
            }
            else
            {
                throw new StockExchangeException("Index already exists.");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);
            Stock stock = getStock(inStockName);
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);
            Stock stock = getStock(inStockName);
            index.RemoveStock(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);
            Stock stock = getStock(inStockName);
            return index.IsStockPartOfIndex(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return getIndex(inIndexName).GetValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return _indices.ContainsKey(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return getIndex(inIndexName).NumberOfStocks;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                _portfolios.Add(portfolio.ID, portfolio);
            }
            else
            {
                throw new StockExchangeException("Portfolio already exists.");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = getPortfolio(inPortfolioID);
            var stock = getStock(inStockName);
            portfolio.AddStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = getPortfolio(inPortfolioID);
            var stock = getStock(inStockName);
            portfolio.RemoveStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = getPortfolio(inPortfolioID);
            var stock = getStock(inStockName);
            portfolio.RemoveStock(stock);
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return getPortfolio(inPortfolioID).NumberOfStocks;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = getPortfolio(inPortfolioID);
            var stock = getStock(inStockName);
            return portfolio.IsStockPartOfPortfolio(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = getPortfolio(inPortfolioID);
            var stock = getStock(inStockName);
            return portfolio.NumberOfSharesOfStock(stock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return getPortfolio(inPortfolioID).GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return getPortfolio(inPortfolioID).GetPercentChangeInValueForMonth(Year, Month);
        }

        protected Stock getStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return _stocks[inStockName];
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist.");
            }
        }

        protected Index getIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return _indices[inIndexName];
            }
            else
            {
                throw new StockExchangeException("Index doesn't exist.");
            }
        }

        protected Portfolio getPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolios[inPortfolioID];
            }
            else
            {
                throw new StockExchangeException("Portfolio doesn't exist.");
            }
        }
    }

    public class Stock
    {
        public string Name { get; protected set; }
        public IEnumerable<Share> Shares { get; protected set; }

        public long NumberOfShares 
        {
            get { return Shares.Count(); }
        }

        protected IDictionary<DateTime, StockValue> _stockValues;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be grater than zero.");
            }

            Name = inStockName;
            Shares = Share.CreateShares((int)inNumberOfShares, this);

            _stockValues = new SortedDictionary<DateTime, StockValue>();
            SetStockValue(inTimeStamp, inInitialPrice);
        }

        public void SetStockValue(DateTime inTimeStamp, decimal inStockValue)
        {
            if (!_stockValues.ContainsKey(inTimeStamp))
            {
                _stockValues.Add(inTimeStamp, new StockValue(inStockValue, inTimeStamp));
            }
            else
            {
                throw new StockExchangeException("Stock value is already set for given time.");
            }
        }

        public decimal GetStockValue(DateTime inTimeStamp)
        {
            StockValue stockValue = _stockValues.Values.LastOrDefault(s => s.TimeStamp <= inTimeStamp);

            if (stockValue != null)
            {
                return stockValue.Price;
            }
            else
            {
                throw new StockExchangeException("Stock doesn't have a valid value for given timestamp.");
            }
        }

        public decimal GetInitialValue()
        {
            StockValue stockValue = _stockValues.First().Value;
            return stockValue.Price;
        }

        public decimal GetLastValue()
        {
            StockValue stockValue = _stockValues.Last().Value;
            return stockValue.Price;
        }

        public IEnumerable<Share> GetShares(long numberOfShares, Portfolio portfolio)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be grater than zero.");
            }

            var shares = Shares.Where(s => s.Portfolio == null).Take((int)numberOfShares).ToList();

            if (shares.Count() < numberOfShares)
            {
                throw new StockExchangeException("Not enough available shares.");
            }

            foreach (var share in shares)
            {
                share.Portfolio = portfolio;
            }

            return shares.AsReadOnly();
        }

        public void ReturnShares(IEnumerable<Share> shares)
        {
            foreach (var share in Shares.Intersect(shares))
            {
                share.Portfolio = null;
            }
        }

        public override bool Equals(object obj)
        {
            Stock stock = obj as Stock;

            if (stock == null)
            {
                return false;
            }

            return string.Compare(Name, stock.Name, true) == 0;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }

    public class Share
    {
        public readonly Stock Stock;
        public Portfolio Portfolio { get; set; }

        public Share(Stock stock)
        {
            Stock = stock;
        }

        public static IEnumerable<Share> CreateShares(int numberOfShares, Stock stock)
        {
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be greater than zero.");
            }

            var shares = new List<Share>(numberOfShares);
            for (int i = 0; i < numberOfShares; i++)
            {
                shares.Add(new Share(stock));
            }
            return shares;
        }
    }

    public class StockValue
    {
        public decimal Price { get; protected set; }
        public DateTime TimeStamp { get; protected set; }

        public StockValue(decimal inValue, DateTime inTimeStamp)
        {
            if (inValue <= 0)
            {
                throw new StockExchangeException("Stock value must be grater than zero.");
            }

            Price = inValue;
            TimeStamp = inTimeStamp;
        }
    }

    public class IndexFactory
    {
        public static Index CreateIndex(IndexTypes inIndexTypes, string inIndexName)
        {
            switch (inIndexTypes)
            {
                case IndexTypes.AVERAGE:
                    return new AverageIndex(inIndexName);
                case IndexTypes.WEIGHTED:
                    return new WeightedIndex(inIndexName);
                default:
                    throw new StockExchangeException("Unknown index.");
            }
        }
    }

    public abstract class Index
    {
        public string Name { get; protected set; }
        protected IDictionary<string, Stock> _stocks;

        public int NumberOfStocks
        {
            get { return _stocks.Count; }
        }

        public Index(string inIndexName)
        {
            Name = inIndexName;
            _stocks = new Dictionary<string, Stock>();
        }

        public abstract Decimal GetValue(DateTime inTimeStamp);

        public void AddStock(Stock stock)
        {
            if (!IsStockPartOfIndex(stock))
            {
                _stocks.Add(stock.Name, stock);
            }
            else
            {
                throw new StockExchangeException("Stock is already in index.");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (IsStockPartOfIndex(stock))
	        {
                _stocks.Remove(stock.Name);
	        }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio.");
            }
        }

        public bool IsStockPartOfIndex(Stock stock)
        {
            return _stocks.ContainsKey(stock.Name);
        }

        public override bool Equals(object obj)
        {
            Index index = obj as Index;

            if (index == null)
            {
                return false;
            }

            return string.Compare(Name, index.Name, true) == 0;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }

    public class AverageIndex : Index
    {
        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal index = _stocks.Values.Average(s => s.GetStockValue(inTimeStamp));
            return Math.Round(index, 3, MidpointRounding.AwayFromZero);
        }

        public AverageIndex(string inIndexName)
            : base(inIndexName)
        { }
    }

    public class WeightedIndex : Index
    {
        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal totalStockValue = _stocks.Values.Sum(s => s.GetStockValue(inTimeStamp) * s.NumberOfShares);
            decimal index = _stocks.Values.Sum(s => s.GetStockValue(inTimeStamp) * s.NumberOfShares * s.GetStockValue(inTimeStamp) / totalStockValue);
            return Math.Round(index, 3, MidpointRounding.AwayFromZero);
        }

        public WeightedIndex(string inIndexName)
            : base(inIndexName)
        { }
    }

    public class Portfolio
    {
        public string ID { get; protected set; }
        protected IDictionary<Stock, IEnumerable<Share>> _stocks;

        public int NumberOfStocks
        {
            get { return _stocks.Count(); }
        }

        public Portfolio(string inPortfolioID)
        {
            ID = inPortfolioID;
            _stocks = new Dictionary<Stock, IEnumerable<Share>>();
        }

        public void AddStock(Stock inStock, int numberOfShares)
        {
            var shares = inStock.GetShares(numberOfShares, this);
            
            if (IsStockPartOfPortfolio(inStock))
            {
                _stocks[inStock] = _stocks[inStock].Concat(shares);
            }
            else
            {
                _stocks.Add(inStock, shares);
            }
        }

        public void RemoveStock(Stock inStock, int numberOfShares)
        {
            if (IsStockPartOfPortfolio(inStock))
            {
                //var stock = _stocks[inStock];

                if (numberOfShares <= 0)
                {
                    throw new StockExchangeException("Number of shares must be greater than zero.");
                }

                var shares = _stocks[inStock].Take(numberOfShares).ToList();
                _stocks[inStock] = _stocks[inStock].Skip(numberOfShares).ToList();
                inStock.ReturnShares(shares);

                if (!_stocks[inStock].Any())
                {
                    _stocks.Remove(inStock);
                }
            }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio.");
            }
        }

        public void RemoveStock(Stock inStock)
        {
            if (IsStockPartOfPortfolio(inStock))
            {
                inStock.ReturnShares(_stocks[inStock]);
                _stocks.Remove(inStock);
            }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio.");
            }
        }

        public bool IsStockPartOfPortfolio(Stock inStock)
        {
            return _stocks.ContainsKey(inStock);
        }

        public int NumberOfSharesOfStock(Stock inStock)
        {
            if (IsStockPartOfPortfolio(inStock))
            {
                return _stocks[inStock].Count();
            }
            else
            {
                throw new StockExchangeException("Stock is not in portfolio.");
            }
        }

        public decimal GetValue(DateTime timeStamp)
        {
            return _stocks.Keys.Sum(s => s.GetStockValue(timeStamp) * _stocks[s].Count());
        }

        public decimal GetPercentChangeInValueForMonth(int Year, int Month)
        {
            var startValue = GetValue(new DateTime(Year, Month, 1, 0, 0, 0));
            var endValue = GetValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            if (startValue == 0)
            {
                throw new StockExchangeException("Start value is zero.");
            }

            var change = (endValue / startValue) - 1;
            return Math.Round(change * 100m, 3, MidpointRounding.AwayFromZero);
        }
    }
}
