﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Factory for creating stock index. Currently only Average and weighted indices are supported.
    /// </summary>
    public static class StockIndexFactory
    {
        public static IIndex CreateStockIndex(string indexName, IStockProvider stockProvider, IndexTypes type)
        {
            switch (type)
            {
                case IndexTypes.AVERAGE:
                    return new AverageStockIndex(indexName, stockProvider);
                case IndexTypes.WEIGHTED:
                    return new WeightedStockIndex(indexName, stockProvider);
                default:
                    throw new StockExchangeException("Selected stock index type doesn't exist!");
            }
        }
    }

    /// <summary>
    /// Entry point class for stock exchange.
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private readonly IndexManager _indexManager;
        private readonly StockManager _stockManager;
        private readonly PortfolioManager _portfolioManager;

        public StockExchange()
        {
            _stockManager = new StockManager();
            _indexManager = new IndexManager(_stockManager);
            _portfolioManager = new PortfolioManager(_stockManager);
        }

        public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockManager.ListStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            _stockManager.DelistStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return _stockManager.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return _stockManager.NumberOfStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, Decimal inStockValue)
        {
            _stockManager.SetStockPrice(inStockName, inIimeStamp, inStockValue);
        }

        public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return _stockManager.GetStockPrice(inStockName, inTimeStamp);
        }

        public Decimal GetInitialStockPrice(string inStockName)
        {
            return _stockManager.GetInitialStockPrice(inStockName);
        }

        public Decimal GetLastStockPrice(string inStockName)
        {
            return _stockManager.GetLastStockPrice(inStockName);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indexManager.CreateIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            _indexManager.AddStockToIndex(inIndexName, inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            _indexManager.RemoveStockFromIndex(inIndexName, inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _indexManager.IsStockPartOfIndex(inIndexName, inStockName);
        }

        public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Decimal indexValue = _indexManager.GetIndexValue(inIndexName, inTimeStamp);
            return Math.Round(indexValue, 3, MidpointRounding.AwayFromZero);
        }

        public bool IndexExists(string inIndexName)
        {
            return _indexManager.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indexManager.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _indexManager.NumberOfStocksInIndex(inIndexName);
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            _portfolioManager.CreatePortfolio(inPortfolioID);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            _portfolioManager.AddStockToPortfolio(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            _portfolioManager.RemoveStockFromPortfolio(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            _portfolioManager.RemoveStockFromPortfolio(inPortfolioID, inStockName);
        }

        public int NumberOfPortfolios()
        {
            return _portfolioManager.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _portfolioManager.NumberOfStocksInPortfolio(inPortfolioID);
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioManager.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioManager.IsStockPartOfPortfolio(inPortfolioID, inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return (int)_portfolioManager.NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
        }

        public Decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Decimal portfolioValue = _portfolioManager.GetPortfolioValue(inPortfolioID, timeStamp);
            return Math.Round(portfolioValue, 3, MidpointRounding.AwayFromZero);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Decimal portfolioPercentChange = _portfolioManager.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
            return Math.Round(portfolioPercentChange, 3, MidpointRounding.AwayFromZero);
        }
    }

    /// <summary>
    /// Observer observing stock deletion.
    /// </summary>
    public interface IStockDeletedObserver
    {
        void Update(string deletedStockName);
    }

    /// <summary>
    /// Stock provides. Provides information about stocks and notifies registered stock observers about stock deletion.
    /// </summary>
    public interface IStockProvider
    {
        IMarketStock GetMarketStock(string stockName);
        bool StockExists(string inStockName);
        void RegisterRemovedStocksObserver(IStockDeletedObserver stockDeletedObserver);
        void RemoveRemovedStocksObserver(IStockDeletedObserver stockDeletedObserver);
    }

    /// <summary>
    /// Stock which is currently available on stock exchange.
    /// </summary>
    public interface IMarketStock
    {
        Decimal GetInitialStockPrice();
        Decimal GetLastStockPrice();
        Decimal GetStockPrice(DateTime inTimeStamp);
        long BuyShares(long numberOfShares);
        long SellShares(long numberOfShares);
        long GetNumberOfShares();
    }

    /// <summary>
    /// Manages all stocks currently available on the stock exchange.
    /// </summary>
    public class StockManager : IStockProvider
    {
        readonly Dictionary<string, Stock> _stocks;
        private readonly List<IStockDeletedObserver> _observers;

        public StockManager()
        {
            _stocks = new Dictionary<string, Stock>(StringComparer.OrdinalIgnoreCase);
            _observers = new List<IStockDeletedObserver>();
        }

        public IMarketStock GetMarketStock(string stockName)
        {
            return _stocks[stockName];
        }

        public void ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                var stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                _stocks.Add(inStockName, stock);
            }
            catch (ArgumentNullException)
            {
                throw new StockExchangeException(string.Format("Cannot create stock with no name!"));
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException(string.Format("Stock with name {0} already exists!", inStockName));
            }
        }

        public void DelistStock(string inStockName)
        {
            _stocks.Remove(inStockName);
            NotifyRemovedStocksObservers(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, Decimal inStockValue)
        {
            Stock stock = _stocks[inStockName];
            stock.AddStockPrice(inIimeStamp, inStockValue);
        }

        public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = _stocks[inStockName];
            return stock.GetStockPrice(inTimeStamp);
        }

        public Decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = _stocks[inStockName];
            return stock.GetInitialStockPrice();
        }

        public Decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = _stocks[inStockName];
            return stock.GetLastStockPrice();
        }

        public void RegisterRemovedStocksObserver(IStockDeletedObserver stockDeletedObserver)
        {
            _observers.Add(stockDeletedObserver);
        }

        public void RemoveRemovedStocksObserver(IStockDeletedObserver stockDeletedObserver)
        {
            _observers.Remove(stockDeletedObserver);
        }

        public void NotifyRemovedStocksObservers(string deletedStockName)
        {
            foreach (IStockDeletedObserver observer in _observers)
            {
                observer.Update(deletedStockName);
            }
        }
    }

    /// <summary>
    /// Represents stock. Contains all the information about the stock.
    /// </summary>
    public class Stock : IMarketStock
    {
        private readonly string _name;
        private readonly StockPriceHistory _stockPriceHistory;
        private readonly StockShares _stockShares;

        public Stock(string name, long numberOfShares, Decimal currentPrice, DateTime priceValidSince)
        {
            if (name == null)
            {
                throw new StockExchangeException("Name of stock must not be null.");
            }

            if (name.Length == 0)
            {
                throw new StockExchangeException("Name of stock must not be empty string.");
            }
            _name = name;
            _stockPriceHistory = new StockPriceHistory();
            _stockShares = new StockShares(numberOfShares);
            AddStockPrice(priceValidSince, currentPrice);
        }

        public void AddStockPrice(DateTime inTimeStamp, Decimal inStockValue)
        {
            _stockPriceHistory.AddStockPrice(inTimeStamp, inStockValue);
        }

        public Decimal GetInitialStockPrice()
        {
            return _stockPriceHistory.GetInitialStockPrice();
        }

        public Decimal GetLastStockPrice()
        {
            return _stockPriceHistory.GetLastStockPrice();
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            return _stockPriceHistory.GetStockPrice(inTimeStamp);
        }

        public long BuyShares(long numberOfShares)
        {
            return _stockShares.BuyShares(numberOfShares);
        }

        public long SellShares(long numberOfShares)
        {
            return _stockShares.SellShares(numberOfShares);
        }

        public long GetNumberOfShares()
        {
            return _stockShares.NumberOfShares;
        }

        public override bool Equals(Object obj)
        {
            if (obj == null || obj.GetType() != GetType())
            {
                return false;
            }

            var stockManager = (Stock)obj;

            return (_name.ToLower().Equals(stockManager._name.ToLower()));
        }

        public override int GetHashCode()
        {
            return _name.ToLower().GetHashCode();
        }
    }

    /// <summary>
    /// Contains information about number of shares the stock has available for sale and total number of shares.
    /// </summary>
    public class StockShares
    {
        public long NumberOfShares { get; private set; }
        private long _numberOfSharesAvailableForSale;

        public StockShares(long numberOfShares)
        {
            if (numberOfShares > 0)
            {
                NumberOfShares = numberOfShares;
                _numberOfSharesAvailableForSale = numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Number of shares must be a positive number!");
            }
        }

        public long BuyShares(long numberOfShares)
        {
            if (numberOfShares > _numberOfSharesAvailableForSale || numberOfShares < 0)
            {
                throw new StockExchangeException("Illegal shares buy.");
            }

            _numberOfSharesAvailableForSale -= numberOfShares;

            return numberOfShares;
        }

        public long SellShares(long numberOfShares)
        {
            if (numberOfShares > NumberOfShares || numberOfShares < 0)
            {
                throw new StockExchangeException("Illegal shares sell.");
            }

            _numberOfSharesAvailableForSale -= numberOfShares;

            return numberOfShares;
        }
    }

    /// <summary>
    /// Keeps data about stock price changes for one stock instance.
    /// It has no reference to stock it represents!
    /// </summary>
    public class StockPriceHistory
    {
        private readonly SortedDictionary<DateTime, Decimal> _stockPriceHistory;

        public StockPriceHistory()
        {
            _stockPriceHistory = new SortedDictionary<DateTime, Decimal>();
        }

        public void AddStockPrice(DateTime inTimeStamp, Decimal inStockValue)
        {
            if (inStockValue < 1)
            {
                throw new StockExchangeException("Stock price must be a positive number!");
            }

            if (_stockPriceHistory.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("Price for DateTime is already specified!");
            }

            _stockPriceHistory.Add(inTimeStamp, inStockValue);
        }

        public Decimal GetInitialStockPrice()
        {
            KeyValuePair<DateTime, Decimal> initialStockPrice = _stockPriceHistory.First();
            return initialStockPrice.Value;
        }

        public Decimal GetLastStockPrice()
        {
            KeyValuePair<DateTime, Decimal> initialStockPrice = _stockPriceHistory.Last();
            return initialStockPrice.Value;
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            Decimal? stockPriceBeforeInTimeStamp = null;

            foreach (KeyValuePair<DateTime, Decimal> stockPrice in _stockPriceHistory)
            {
                if (inTimeStamp > stockPrice.Key)
                {
                    stockPriceBeforeInTimeStamp = stockPrice.Value;
                }
            }

            if (stockPriceBeforeInTimeStamp == null)
            {
                throw new StockExchangeException("Stock price is not defined for that time!");
            }

            return stockPriceBeforeInTimeStamp.Value;
        }
    }

    /// <summary>
    /// Manages all indices available on the stock exchange.
    /// </summary>
    public class IndexManager
    {
        private readonly Dictionary<string, IIndex> _stockExchangeIndexes;
        private readonly IStockProvider _stockProvider;

        public IndexManager(IStockProvider stockProvider)
        {
            _stockProvider = stockProvider;
            _stockExchangeIndexes = new Dictionary<string, IIndex>(StringComparer.OrdinalIgnoreCase);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            try
            {
                IIndex index = StockIndexFactory.CreateStockIndex(inIndexName, _stockProvider, inIndexType);
                _stockExchangeIndexes.Add(inIndexName, index);
            }
            catch (ArgumentNullException)
            {
                throw new StockExchangeException(string.Format("Cannot create stock index with no name!"));
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException(string.Format("Stock index with name {0} already exists!", inIndexName));
            }
        }

        private IIndex RetrieveStockIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return _stockExchangeIndexes[inIndexName];
            }

            throw new StockExchangeException(string.Format("Stock index with name {0} doesn't exist!", inIndexName));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!_stockProvider.StockExists(inStockName))
            {
                throw new StockExchangeException(string.Format("Stock added to portfolio doesn't exist on the share market!"));
            }

            IIndex index = RetrieveStockIndex(inIndexName);
            index.AddStockToIndex(inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            IIndex index = RetrieveStockIndex(inIndexName);

            index.RemoveStockFromIndex(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            IIndex index = RetrieveStockIndex(inIndexName);

            return index.IsStockPartOfIndex(inStockName);
        }

        public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            IIndex index = RetrieveStockIndex(inIndexName);
            Decimal indexValue = index.GetIndexValue(inTimeStamp);

            return indexValue;
        }

        public bool IndexExists(string inIndexName)
        {
            return _stockExchangeIndexes.ContainsKey(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _stockExchangeIndexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            IIndex index = RetrieveStockIndex(inIndexName);

            return index.NumberOfStocksInIndex();
        }
    }

    /// <summary>
    /// Interface of a Index.
    /// </summary>
    public interface IIndex
    {
        void AddStockToIndex(string stockName);
        void RemoveStockFromIndex(string stockName);
        bool IsStockPartOfIndex(string stockName);
        Decimal GetIndexValue(DateTime inTimeStamp);
        int NumberOfStocksInIndex();
    }

    /// <summary>
    /// Basic abstract class for all indices.
    /// </summary>
    public abstract class StockIndex : IIndex, IStockDeletedObserver
    {
        private readonly string _name;
        protected readonly HashSet<string> Stocks;
        protected readonly IStockProvider StockProvider;

        protected StockIndex(string name, IStockProvider stockProvider)
        {
            if (name == null)
            {
                throw new StockExchangeException("Name of index must not be null.");
            }

            if (name.Length == 0)
            {
                throw new StockExchangeException("Name of index must not be empty string.");
            }
            _name = name;
            StockProvider = stockProvider;
            StockProvider.RegisterRemovedStocksObserver(this);
            Stocks = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }

        public void AddStockToIndex(string stockName)
        {
            if (Stocks.Add(stockName) == false)
            {
                throw new StockExchangeException(string.Format("Stock {0} is already in the index {1}!", stockName, _name));
            }
        }

        public void RemoveStockFromIndex(string stockName)
        {
            Stocks.Remove(stockName);
        }

        public bool IsStockPartOfIndex(string stockName)
        {
            return Stocks.Contains(stockName);
        }

        public abstract Decimal GetIndexValue(DateTime inTimeStamp);

        public int NumberOfStocksInIndex()
        {
            return Stocks.Count;
        }

        public override bool Equals(Object obj)
        {
            if (obj == null || obj.GetType() != GetType())
            {
                return false;
            }

            var stockManager = (StockIndex)obj;

            return (_name.ToLower().Equals(stockManager._name.ToLower()));
        }

        public override int GetHashCode()
        {
            return _name.ToLower().GetHashCode();
        }

        public void Update(string deletedStockName)
        {
            RemoveStockFromIndex(deletedStockName);
        }
    }

    /// <summary>
    /// Contains algorithm for calculating average stock index.
    /// </summary>
    public class AverageStockIndex : StockIndex
    {
        public AverageStockIndex(string name, IStockProvider stockProvider)
            : base(name, stockProvider)
        {
        }

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            Decimal indexValue = 0;

            foreach (string stockName in Stocks)
            {
                IMarketStock stock = StockProvider.GetMarketStock(stockName);
                indexValue += stock.GetStockPrice(inTimeStamp);
            }

            return indexValue / Stocks.Count;
        }
    }

    /// <summary>
    /// Contains algorithm for calculating weighted stock index.
    /// </summary>
    public class WeightedStockIndex : StockIndex
    {
        public WeightedStockIndex(string name, IStockProvider stockProvider)
            : base(name, stockProvider)
        {
        }

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            Decimal indexValue = 0;

            Decimal totalIndexValue = 0;

            foreach (string stockName in Stocks)
            {
                IMarketStock stock = StockProvider.GetMarketStock(stockName);
                totalIndexValue += stock.GetStockPrice(inTimeStamp) * stock.GetNumberOfShares();
            }

            foreach (string stockName in Stocks)
            {
                IMarketStock stock = StockProvider.GetMarketStock(stockName);
                Decimal stockPrice = stock.GetStockPrice(inTimeStamp);

                stock.GetNumberOfShares();
                Decimal stockValue = stockPrice * stock.GetNumberOfShares();
                Decimal stockWeight = stockValue / totalIndexValue;

                indexValue += stockWeight * stockPrice;
            }

            return indexValue;
        }
    }

    /// <summary>
    /// Manages all portfolios currently available on the stock exchange.
    /// </summary>
    public class PortfolioManager
    {
        readonly Dictionary<string, Portfolio> _portfolios;

        private readonly IStockProvider _stockProvider;

        public PortfolioManager(IStockProvider stockProvider)
        {
            _stockProvider = stockProvider;
            _portfolios = new Dictionary<string, Portfolio>();
        }

        public void CreatePortfolio(string portfolioID)
        {
            try
            {
                var portfolio = new Portfolio(portfolioID, _stockProvider);
                _portfolios.Add(portfolioID, portfolio);
            }
            catch (ArgumentNullException)
            {
                throw new StockExchangeException(string.Format("Cannot create portfolio with no id!"));
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException(string.Format("Portfolio with id {0} already exists!", portfolioID));
            }

        }

        public void AddStockToPortfolio(string portfolioID, string stockName, int numberOfShares)
        {
            if (!_stockProvider.StockExists(stockName))
            {
                throw new StockExchangeException(string.Format("Stock added to portfolio doesn't exist on the share market!"));
            }

            _stockProvider.GetMarketStock(stockName);

            Portfolio portfolio = _portfolios[portfolioID];
            portfolio.AddStockToPortfolio(stockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string portfolioID, string stockName, int numberOfShares)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            portfolio.RemoveStockFromPortfolio(stockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string portfolioID, string stockName)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            portfolio.RemoveStockFromPortfolio(stockName);
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string portfolioID)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            return portfolio.NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string portfolioID)
        {
            return _portfolios.ContainsKey(portfolioID);
        }

        public bool IsStockPartOfPortfolio(string portfolioID, string stockName)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            return portfolio.IsStockPartOfPortfolio(stockName);
        }

        public long NumberOfSharesOfStockInPortfolio(string portfolioID, string stockName)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            return portfolio.NumberOfSharesOfStockInPortfolio(stockName);
        }

        public Decimal GetPortfolioValue(string portfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            return portfolio.GetPortfolioValue(timeStamp);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(string portfolioID, int year, int month)
        {
            Portfolio portfolio = _portfolios[portfolioID];
            return portfolio.GetPortfolioPercentChangeInValueForMonth(year, month);
        }
    }

    /// <summary>
    /// Manages one portfolio instance.
    /// </summary>
    public class Portfolio : IStockDeletedObserver
    {
        private readonly string _name;
        readonly Dictionary<string, long> _ownedShares;
        private readonly IStockProvider _stockProvider;

        public Portfolio(string name, IStockProvider stockProvider)
        {
            if (name == null)
            {
                throw new StockExchangeException("Name of portfolio must not be null.");
            }

            if (name.Length == 0)
            {
                throw new StockExchangeException("Name of portfolio must not be empty string.");
            }
            _name = name;
            _stockProvider = stockProvider;
            _stockProvider.RegisterRemovedStocksObserver(this);
            _ownedShares = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        }

        public void AddStockToPortfolio(string stockName, int numberOfShares)
        {
            IMarketStock stock = _stockProvider.GetMarketStock(stockName);

            if (_ownedShares.ContainsKey(stockName))
            {
                _ownedShares[stockName] += stock.BuyShares(numberOfShares);
            }
            else
            {
                _ownedShares.Add(stockName, stock.BuyShares(numberOfShares));
            }
        }

        public void RemoveStockFromPortfolio(string stockName, int numberOfShares)
        {
            if (numberOfShares > _ownedShares[stockName])
            {
                throw new StockExchangeException("Illegal stock trade. Trying to sell more shares from portfolio than it contains");
            }

            IMarketStock stock = _stockProvider.GetMarketStock(stockName);

            _ownedShares[stockName] -= stock.SellShares(numberOfShares);

            if (_ownedShares[stockName] < 1)
            {
                _ownedShares.Remove(stockName);
            }
        }

        public void RemoveStockFromPortfolio(string stockName)
        {
            if (IsStockPartOfPortfolio(stockName) && _stockProvider.StockExists(stockName))
            {
                IMarketStock stock = _stockProvider.GetMarketStock(stockName);
                stock.SellShares(_ownedShares[stockName]);

            }

            _ownedShares.Remove(stockName);

        }

        public int NumberOfStocksInPortfolio()
        {
            return _ownedShares.Count;
        }

        public bool IsStockPartOfPortfolio(string stockName)
        {
            return _ownedShares.ContainsKey(stockName);
        }

        public long NumberOfSharesOfStockInPortfolio(string stockName)
        {
            return _ownedShares[stockName];
        }

        public Decimal GetPortfolioValue(DateTime timeStamp)
        {
            Decimal indexValue = 0;

            foreach (KeyValuePair<string, long> ownedShare in _ownedShares)
            {
                IMarketStock stock = _stockProvider.GetMarketStock(ownedShare.Key);
                indexValue += stock.GetStockPrice(timeStamp) * ownedShare.Value;
            }

            return indexValue;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
        {
            var monthBeginning = new DateTime(year, month, 1, 0, 0, 0);
            DateTime monthEnd = monthBeginning.AddMonths(1).AddMilliseconds(-1);

            Decimal monthBeginningValue = GetPortfolioValue(monthBeginning);
            Decimal monthEndValue = GetPortfolioValue(monthEnd);

            Decimal change = (monthEndValue - monthBeginningValue) /monthBeginningValue;

            return Math.Abs(change * 100);
        }

        public override bool Equals(Object obj)
        {
            if (obj == null || obj.GetType() != GetType())
            {
                return false;
            }

            var stockManager = (Portfolio)obj;

            return (_name.Equals(stockManager._name));
        }

        public override int GetHashCode()
        {
            return _name.GetHashCode();
        }

        public void Update(string deletedStockName)
        {
            RemoveStockFromPortfolio(deletedStockName);
        }
    }
}