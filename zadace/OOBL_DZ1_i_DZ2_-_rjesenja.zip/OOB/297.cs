﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         Dictionary<string, Stock> existingStocks;
         Dictionary<string, Index> existingIndices;
         Dictionary<string, Portfolio> existingPortfolios;

         public StockExchange()
         {
             this.existingStocks = new Dictionary<string, Stock>();
             this.existingIndices = new Dictionary<string, Index>();
             this.existingPortfolios = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!this.StockExists(inStockName.ToLower()))
             {
                 existingStocks.Add(inStockName.ToLower(), new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp));
             }
             else
             {
                 throw new StockExchangeException("Dionica već postoji");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 foreach (string key in this.existingIndices.Keys)
                 {
                     if (this.existingIndices[key].ContainsStock(inStockName.ToLower()))
                     {
                         this.existingIndices[key].RemoveStock(inStockName.ToLower());
                     }
                 }
                 foreach (string key in this.existingPortfolios.Keys)
                 {
                     if (this.existingPortfolios[key].ContainsStock(inStockName.ToLower())) 
                     {
                         this.existingPortfolios[key].RemoveStock(inStockName.ToLower());
                     }
                 }
                 this.existingStocks.Remove(inStockName.ToLower());
             }
             else
             {
                 throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice");
             }
         }

         public bool StockExists(string inStockName)
         {
             return existingStocks.ContainsKey(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return this.existingStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 existingStocks[inStockName.ToLower()].SetStockPrice(inIimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Pokušaj promjene cijene nepostojeće dionice");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 return this.existingStocks[inStockName.ToLower()].GetStockPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata cijene nepostojeće dionice");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 return this.existingStocks[inStockName.ToLower()].GetInitialPrice();
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata cijene nepostojeće dionice");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 return this.existingStocks[inStockName.ToLower()].GetStockPrice();
             }
             else
             {
                 throw new StockExchangeException("Pokušaj promjene cijene nepostojeće dionice");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks već postoji");
             }
             existingIndices.Add(inIndexName.ToLower(), new Index(inIndexName.ToLower(), inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 this.existingIndices[inIndexName.ToLower()].AddStock(this.existingStocks[inStockName.ToLower()]);
             }
             else
             {
                 if (!this.existingIndices.ContainsKey(inIndexName.ToLower()))
                 {
                     throw new StockExchangeException("Pokušaj dodavanja dionice u nepostojeći indeks");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj dodavanja nepostojeće dionice u indeks");
                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 this.existingIndices[inIndexName.ToLower()].RemoveStock(inStockName.ToLower());
             }
             else
             {
                 if (!this.existingIndices.ContainsKey(inIndexName.ToLower()))
                 {
                     throw new StockExchangeException("Pokušaj brisanja dionice iz nepostojećeg indeksa");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice iz indeksa");
                 }
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 return this.existingIndices[inIndexName.ToLower()].ContainsStock(inStockName.ToLower());
             }
             else
             {
                 if (!this.existingIndices.ContainsKey(inIndexName.ToLower()))
                 {
                     throw new StockExchangeException("Pokušaj provjere posojanja dionice u nepostojećem indeksu");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj provjere postojanja nepostojeće dionice u indeksu");
                 }
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()))
             {
                 return this.existingIndices[inIndexName.ToLower()].GetValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Pokušaj izračuna vrijednosti nepostojećeg  indeksa");   
             }
         }

         public bool IndexExists(string inIndexName)
         {
             return this.existingIndices.ContainsKey(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return this.existingIndices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (this.existingIndices.ContainsKey(inIndexName.ToLower()))
             {
                 return this.existingIndices[inIndexName.ToLower()].GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Pokušaj provjere broja dionica u nepostojećem indeksu");
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!this.existingPortfolios.ContainsKey(inPortfolioID))
             {
                 existingPortfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
             else
             {
                 throw new StockExchangeException("Portfolio već postoji");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID) && this.existingStocks.ContainsKey(inStockName.ToLower())&& numberOfShares>=0)
             {
                 long sum = 0;
                 foreach (string key in this.existingPortfolios.Keys)
                 {
                     sum += this.existingPortfolios[key].GetNumOfSharesOfStock(inStockName.ToLower());
                 }
                 if (sum + numberOfShares <= this.existingStocks[inStockName.ToLower()].GetNumOfShares())
                 {
                     this.existingPortfolios[inPortfolioID].AddStock(this.existingStocks[inStockName.ToLower()], numberOfShares);
                 }
                 else
                 {
                     throw new StockExchangeException("Nemoguć broj dionica");
                 }
             }
             else
             {
                 if (!this.existingPortfolios.ContainsKey(inPortfolioID))
                 {
                     throw new StockExchangeException("Pokušaj dodavanja dionica u nepostojeći portfolio");
                 }
                 if (!this.existingStocks.ContainsKey(inPortfolioID))
                 {
                     throw new StockExchangeException("Pokušaj dodavanja nepostojeće dionice u portfolio");
                 }
                 if (numberOfShares < 0)
                 {
                     throw new StockExchangeException("Broj dionica koji se dodaje mora biti pozitivan");
                 }
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 this.existingPortfolios[inPortfolioID].RemoveStock(inStockName.ToLower(), numberOfShares);
             }
             else
             {
                 if (!this.existingPortfolios.ContainsKey(inPortfolioID))
                 {
                     throw new StockExchangeException("Pokušaj brisanja dionica iz nepostojećeg portfolija");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice iz portfolija");
                 }
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 this.existingPortfolios[inPortfolioID].RemoveStock(inStockName.ToLower());
             }
             else
             {
                 if (!this.existingPortfolios.ContainsKey(inPortfolioID))
                 {
                     throw new StockExchangeException("Pokušaj brisanja dionica iz nepostojećeg portfolija");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice iz portfolija");
                 }
             }
         }

         public int NumberOfPortfolios()
         {
             return this.existingPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID))
             {
                 return (int) this.existingPortfolios[inPortfolioID].GetNumOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata broja dionica iz nepostojećeg portfolija");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this.existingPortfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID) && this.existingStocks.ContainsKey(inStockName.ToLower()))
             {
                 return this.existingPortfolios[inPortfolioID].ContainsStock(inStockName.ToLower());
             }
             else
             {
                 if (!this.existingPortfolios.ContainsKey(inPortfolioID))
                 {
                     throw new StockExchangeException("Pokušaj provjere postojanja dionice u nepostojećem portfoliju");
                 }
                 else
                 {
                     throw new StockExchangeException("Pokušaj provjere postojanja nepostojeće dionice u portfoliju");
                 }
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID))
             {
                 return (int) this.existingPortfolios[inPortfolioID].GetNumOfSharesOfStock(inStockName.ToLower());
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata broja dionica iz nepostojećeg portfolija");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID))
             {
                 return this.existingPortfolios[inPortfolioID].GetValue(timeStamp);
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata vrijednosti nepostojećeg portfolija");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (this.existingPortfolios.ContainsKey(inPortfolioID))
             {
                 return this.existingPortfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year,Month);
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata promjene vrijednosti nepostojećeg portfolija");
             }
         }
     }

     public class Stock
     {
         private string stockName;
         private long numberOfShares;
         List<StockHistory> stockHistory;

         public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
         {
             if (initialPrice < 0)
             {
                 throw new StockExchangeException("Cijena dionice ne može biti negativna");
             }
             if (numberOfShares < 0)
             {
                 throw new StockExchangeException("Broj dionica ne može biti negativan");
             }
             this.stockName = stockName;
             this.numberOfShares = numberOfShares;
             this.stockHistory = new List<StockHistory>();
             stockHistory.Add(new StockHistory(initialPrice, timeStamp));
         }

         public void SetStockPrice(DateTime inIimeStamp, decimal inStockValue)
         {
             if (inStockValue < 0)
             {
                 throw new StockExchangeException("Cijena dionice ne može biti 0");
             }
             int index = 0;
             for (int i = 0; i < stockHistory.Count; i++)
             {
                 if (stockHistory[i].GetTimeStamp() < inIimeStamp)
                 {
                     index++;
                 }
                 else
                 {
                     if (stockHistory[i].GetTimeStamp() == inIimeStamp)
                     {
                         throw new StockExchangeException("Pokušaj definicije cijene za već postojeće vrijeme");
                     }
                     else
                     {
                         break;
                     }
                 }
             }
             stockHistory.Insert(index, new StockHistory(inStockValue,inIimeStamp));
         }

         public decimal GetStockPrice()
         {
             return stockHistory[stockHistory.Count - 1].GetPrice();
         }

         public decimal GetStockPrice(DateTime timeStamp)
         {
             int index = stockHistory.Count - 1;
             for (int i = 0; i < stockHistory.Count; i++)
             {
                 if (stockHistory[i].GetTimeStamp() > timeStamp)
                 {
                     index = i - 1;
                     break;
                 }
             }
             if (index >= 0)
             {
                 return this.stockHistory[index].GetPrice();
             }
             else
             {
                 throw new StockExchangeException("Pokušaj dohvata vrijednosti dionice za razdoblje kada još nije postojala");
             }
            
         }

         public decimal GetInitialPrice()
         {
             return stockHistory[0].GetPrice();
         }

         public string GetStockName()
         {
             return this.stockName;
         }

         public long GetNumOfShares()
         {
             return this.numberOfShares;
         }
     }

     public class StockHistory
     {
         decimal price;
         DateTime timeStamp;

         public StockHistory(decimal price, DateTime timeStamp)
         {
             this.price = price;
             this.timeStamp = timeStamp;
         }

         public decimal GetPrice()
         {
             return this.price;
         }

         public DateTime GetTimeStamp()
         {
             return this.timeStamp;
         }
     }

    public class Index
    {
        string indexName;
        IndexTypes indexType;
        Dictionary<string, Stock> assignedStocks;

        public Index(string indexName, IndexTypes indexType)
        {
            if (!(indexType == IndexTypes.AVERAGE || indexType == IndexTypes.WEIGHTED))
            {
                throw new StockExchangeException("Pokušaj stvaranja novog tipa indeksa");
            }
            this.indexName = indexName;
            this.indexType = indexType;
            this.assignedStocks = new Dictionary<string, Stock>();
        }

        public void AddStock(Stock stock)
        {
            if (!this.assignedStocks.ContainsKey(stock.GetStockName()))
            {
                assignedStocks.Add(stock.GetStockName(), stock);
            }
            else
            {
                throw new StockExchangeException("Dionica već postoji u indeksu");
            }
        }

        public void RemoveStock(string stockName)
        {
            if (assignedStocks.ContainsKey(stockName))
            {
                assignedStocks.Remove(stockName);
            }
            else
            {
                throw new StockExchangeException("Pokušaj brisanja dionice koja se ne nalazi u indeksu");
            }
        }

        public bool ContainsStock(string stockName)
        {
            return this.assignedStocks.ContainsKey(stockName);
        }

        public decimal GetValue(DateTime timeStamp)
        {
            
            if (indexType == IndexTypes.AVERAGE)
            {
                decimal sumPrices = 0;
                foreach (string key in this.assignedStocks.Keys)
                {
                    sumPrices += this.assignedStocks[key].GetStockPrice(timeStamp);
                }             
                return Math.Round(sumPrices / this.assignedStocks.Count,3);
            }
            else
            {
                decimal sumValues = 0;
                decimal sum = 0;
                foreach (string key in this.assignedStocks.Keys)
                {
                    sumValues += this.assignedStocks[key].GetStockPrice(timeStamp)*this.assignedStocks[key].GetNumOfShares();
                }
                foreach (string key in this.assignedStocks.Keys)
                {
                    sum += this.assignedStocks[key].GetStockPrice(timeStamp) * this.assignedStocks[key].GetNumOfShares() / sumValues * this.assignedStocks[key].GetStockPrice(timeStamp);
                }
                return Math.Round(sum,3);
            }
        }

        public int GetNumberOfStocks()
        {
            return this.assignedStocks.Count();
        }
    }

    public class Portfolio
    {
        string portfolioID;
        Dictionary<string, long> stockShares;
        Dictionary<string, Stock> assignedStocks;

        public Portfolio(string portfolioID)
        {
            this.portfolioID = portfolioID;
            this.stockShares = new Dictionary<string, long>();
            this.assignedStocks = new Dictionary<string, Stock>();
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (this.stockShares.ContainsKey(stock.GetStockName()))
            {
                this.stockShares[stock.GetStockName()] += numberOfShares;
            }
            else
            {
                this.stockShares.Add(stock.GetStockName(), (long) numberOfShares);
                this.assignedStocks.Add(stock.GetStockName(), stock);
            }
        }

        public void RemoveStock(string stockName)
        {
            if (this.stockShares.ContainsKey(stockName))
            {
                this.stockShares.Remove(stockName);
                this.assignedStocks.Remove(stockName);
            }
            else
            {
                throw new StockExchangeException("Pokušaj brisanja dionice koja se ne nalaz u portfoliju");
            }
        }

        public void RemoveStock(string stockName, int numberOfShares)
        {
            if (this.stockShares.ContainsKey(stockName))
            {
                if (this.stockShares[stockName] > numberOfShares)
                {
                    this.stockShares[stockName] -= numberOfShares;
                }
                else
                {
                    if (this.stockShares[stockName] == numberOfShares)
                    {
                        this.RemoveStock(stockName);
                    }
                    else
                    {
                        throw new StockExchangeException("Pokušaj brisanja većeg broja dionica nego što ih ima u portfoliju");
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Pokušaj brisanja nepostojeće dionice iz portfolija");
            }
        }

        public long GetNumOfStocks()
        {
            return this.stockShares.Count;
        }

        public long GetNumOfSharesOfStock(string stockName)
        {
            if (this.stockShares.ContainsKey(stockName))
            {
                return this.stockShares[stockName];
            }
            else
            {
                return 0;
            }
        }

        public bool ContainsStock(string stockName)
        {
            return this.stockShares.ContainsKey(stockName);
        }

        public decimal GetValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (string key in this.stockShares.Keys)
            {
                sum += assignedStocks[key].GetStockPrice(timeStamp)*this.stockShares[key];
            }
            return Math.Round(sum, 3); ;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            decimal beginning = this.GetValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
            decimal end = this.GetValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            return Math.Round((end - beginning) / beginning * 100,3);
        }
    }

}
