﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public StockExchange()
         {
             Stocks = new HashSet<Stock>();
             Portfolios = new HashSet<Portfolio>();
             Indexes = new HashSet<Index>();
         }

         private ICollection<Stock> Stocks { get; set; }
         private ICollection<Portfolio> Portfolios { get; set; }
         private ICollection<Index> Indexes { get; set; } 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             var stock = new Stock(inStockName)
                 {
                     SharesCount = inNumberOfShares,
                     SharesAvailable = inNumberOfShares
                 };
             stock.AddPrice(inInitialPrice, inTimeStamp);
             if (Stocks.Contains(stock))
                 throw new StockExchangeException("Trying to add existing stock");
             Stocks.Add(stock);
         }

         public void DelistStock(string inStockName)
         {
             var stock = GetStock(inStockName);

             foreach (var portfolioConnection in stock.PortfolioConnections.ToList())
             {
                 portfolioConnection.Portfolio.RemoveStock(stock);
             }
             foreach (var index in stock.Indexes.ToList())
             {
                 index.RemoveStock(stock);
             }
             Stocks.Remove(stock);
         }

         public bool StockExists(string inStockName)
         {
             return Stocks.Contains(new Stock(inStockName));
         }

         public int NumberOfStocks()
         {
             return Stocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             var stock = GetStock(inStockName);
             stock.AddPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             var stock = GetStock(inStockName);
             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             var stock = GetStock(inStockName);
             return stock.GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             var stock = GetStock(inStockName);
             return stock.GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index = null;
             switch (inIndexType)
             {
                 case IndexTypes.AVERAGE:
                     index = new AverageIndex(inIndexName);
                     break;
                 case IndexTypes.WEIGHTED:
                     index = new WeightedIndex(inIndexName);
                     break;
                 default:
                     throw new StockExchangeException("Index type not supported");
             }
             Indexes.Add(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             var index = GetIndex(inIndexName);
             var stock = GetStock(inStockName);
             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             var index = GetIndex(inIndexName);
             var stock = GetStock(inStockName);
             index.RemoveStock(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             var index = GetIndex(inIndexName);
             var stock = GetStock(inStockName);
             return index.ContainsStock(stock);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             var index = GetIndex(inIndexName);
             return index.GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return Indexes.Any(x => x.Name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase));
         }

         public int NumberOfIndices()
         {
             return Indexes.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             var index = GetIndex(inIndexName);
             return index.GetNumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             var portfolio = new Portfolio(inPortfolioID);
             if (Portfolios.Contains(portfolio))
                 throw new StockExchangeException("Portfolio already exists!");
             Portfolios.Add(portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);
             if (stock.SharesAvailable >= numberOfShares)
             {
                 portfolio.AddStockShares(stock, numberOfShares);
                 stock.SharesAvailable -= numberOfShares;
             }
             else
             {
                 throw new StockExchangeException("Not enough shares on the market");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);
             portfolio.RemoveStockShares(stock, numberOfShares);
             stock.SharesAvailable += numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);
             portfolio.RemoveStockShares(stock);
         }

         public int NumberOfPortfolios()
         {
             return Portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             return portfolio.GetNubmerOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             try
             {
                 GetPortfolio(inPortfolioID);
                 return true;
             }
             catch (Exception)
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);

             return portfolio.ContainsStock(stock);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             var stock = GetStock(inStockName);

             return portfolio.StockShares(stock);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             return portfolio.GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             var portfolio = GetPortfolio(inPortfolioID);
             return portfolio.GetValueChange(Year, Month);
         }

         private Stock GetStock(string inStockName)
         {
             var stock = new Stock(inStockName);
             stock = Stocks.FirstOrDefault(x => x.Equals(stock));
             if (stock == null)
                 throw new StockExchangeException("Trying to access non-existent Stock");
             return stock;
         }

         private Portfolio GetPortfolio(string inPortfolioId)
         {
             var portfolio = new Portfolio(inPortfolioId);
             portfolio = Portfolios.FirstOrDefault(x => x.Equals(portfolio));
             if (portfolio == null)
                 throw new StockExchangeException("Trying to access non-existent Portfolio");
             return portfolio;
         }

         private Index GetIndex(string inIndexName)
         {
             var index = Indexes.FirstOrDefault(x => x.Name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase));
             if (index == null)
                 throw new StockExchangeException("Trying to access non-existent Index");
             return index;
         }

     }

    public class Stock
    {
        public Stock(string name)
        {
            Prices = new List<StockPrice>();
            Indexes = new HashSet<Index>();
            PortfolioConnections = new HashSet<PortfolioStockConnection>();
            Name = name;
            SharesCount = 0;
        }

        public string Name { get; set; }

        public long SharesCount { get; set; }

        public long SharesAvailable { get; set; }

        public void AddPrice(decimal price, DateTime time)
        {
            Prices.Add(new StockPrice()
                {
                    Price = price,
                    Time = time
                });
        }

        public decimal GetPrice(DateTime inTimeStamp)
        {
            var earlierPrices = Prices.Where(x => x.Time < inTimeStamp).OrderBy(x => x.Time);
            if (!earlierPrices.Any())
                throw new StockExchangeException("Price not defined!");
            return earlierPrices.Last().Price;
        }

        public decimal GetInitialPrice()
        {
            var price = Prices.OrderBy(x => x.Time).FirstOrDefault();
            if (price == null)
                throw new StockExchangeException("Initial price not defined!");
            return price.Price;
        }

        public decimal GetLastPrice()
        {
            var price = Prices.OrderBy(x => x.Time).LastOrDefault();
            if (price == null)
                throw new StockExchangeException("Last price not defined!");
            return price.Price;
        }

        public ICollection<StockPrice> Prices { get; set; }

        public ICollection<Index> Indexes { get; set; }

        public ICollection<PortfolioStockConnection> PortfolioConnections { get; set; }

        protected bool Equals(Stock other)
        {
            return string.Equals(Name, other.Name, StringComparison.OrdinalIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Stock) obj);
        }

        public override int GetHashCode()
        {
            return (Name != null ? Name.ToLower().GetHashCode() : 0);
        }

    }

    public class StockPrice
    {
        private decimal _price;

        public decimal Price
        {
            get { return _price; }
            set
            {
                if (value < 0)
                    throw new StockExchangeException("Price less than 0");
                _price = Math.Round(value, 3);
            }
        }

        public DateTime Time { get; set; }
    }

    public abstract class Index
    {
        protected Index(string name)
        {
            Stocks = new HashSet<Stock>();
            Name = name;
        }

        public string Name { get; set; }

        protected ICollection<Stock> Stocks { get; set; }

        public abstract decimal GetIndexValue(DateTime inTimeStamp);

        public void AddStock(Stock stock)
        {
            if (ContainsStock(stock))
                throw new StockExchangeException("Stock allready in Index");
            Stocks.Add(stock);
            stock.Indexes.Add(this);
        }

        public void RemoveStock(Stock stock)
        {
            if (!ContainsStock(stock))
                throw new StockExchangeException("Stock not found in index!");
            Stocks.Remove(stock);
            stock.Indexes.Remove(this);
        }

        public bool ContainsStock(Stock stock)
        {
            return Stocks.Contains(stock);
        }

        public int GetNumberOfStocks()
        {
            return Stocks.Count();
        }

        protected bool Equals(Index other)
        {
            return string.Equals(Name, other.Name, StringComparison.OrdinalIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Index) obj);
        }

        public override int GetHashCode()
        {
            return (Name != null ? Name.ToLower().GetHashCode() : 0);
        }
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string name) : base(name)
        {
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (!Stocks.Any())
                throw new StockExchangeException("No Stocks in Index");
            return Stocks.Sum(x => x.GetPrice(inTimeStamp))/Stocks.Count();
        }
    }


    public class WeightedIndex : Index
    {
        public WeightedIndex(string name) : base(name)
        {
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (!Stocks.Any())
                throw new StockExchangeException("No Stocks in Index");
            var valueOfEverythingInIndex = Stocks.Sum(x => x.GetPrice(inTimeStamp) * x.SharesCount);
            return Math.Round(
                Stocks.Sum(x => 
                            x.GetPrice(inTimeStamp) * x.GetPrice(inTimeStamp) * x.SharesCount
                            / valueOfEverythingInIndex), 
                3);
        }
    }

    public class Portfolio
    {
        public Portfolio(string id)
        {
            Id = id;
            StockConnections = new List<PortfolioStockConnection>();        
        }

        public string Id { get; set; }

        public ICollection<PortfolioStockConnection> StockConnections { get; set; }

        public void AddStockShares(Stock inStock, int numberOfShares)
        {
            if (!StockConnections.Any(x => x.Stock.Equals(inStock)))
            {
                var connection = new PortfolioStockConnection(this, inStock);
                inStock.PortfolioConnections.Add(connection);
                StockConnections.Add(connection);
            }

            var stockConnection = StockConnections.First(x => x.Stock.Equals((inStock)));
            stockConnection.Count += numberOfShares;
        }

        public void RemoveStockShares(Stock inStock, int numberOfShares)
        {
            if (!StockConnections.Any(x => x.Stock.Equals(inStock)))
                throw new StockExchangeException("Stock not found");

            var stockConnection = StockConnections.First(x => x.Stock.Equals((inStock)));
            if (stockConnection.Count < numberOfShares)
                throw new StockExchangeException("Not enough stocks to remove");

            stockConnection.Count -= numberOfShares;
            if (stockConnection.Count == 0)
            {
                RemoveStock(inStock);
            }
        }

        public void RemoveStockShares(Stock inStock)
        {
            if (!StockConnections.Any(x => x.Stock.Equals(inStock)))
                throw new StockExchangeException("Stock not found");

            RemoveStock(inStock);

        }

        public void RemoveStock(Stock stock)
        {
            var stockConnection = StockConnections.First(x => x.Stock.Equals(stock));
            stockConnection.Portfolio = null;
            stockConnection.Stock.PortfolioConnections.Remove(stockConnection);
            stockConnection.Stock = null;
            StockConnections.Remove(stockConnection);
        }

        public bool ContainsStock(Stock stock)
        {
            return StockConnections.Any(x => x.Stock.Equals(stock));
        }

        public int GetNubmerOfStocks()
        {
            return StockConnections.Count();
        }

        public int StockShares(Stock stock)
        {
            var stockConnection = StockConnections.FirstOrDefault(x => x.Stock.Equals(stock));
            if (stockConnection == null)
                throw new StockExchangeException("Stock not found!");
            return stockConnection.Count;
        }

        public decimal GetValue(DateTime timeStamp)
        {
            return Math.Round(
                StockConnections.Sum(stockConnection => stockConnection.Stock.GetPrice(timeStamp)*stockConnection.Count),
                3
            );
        }

        public decimal GetValueChange(int year, int month)
        {
            var startTime = new DateTime(year, month, 1);
            var endTime = (new DateTime(year, month, 1)).AddMonths(1).AddMilliseconds(-1);
            return Math.Round(
                (GetValue(endTime) - GetValue(startTime)) / GetValue(startTime) * 100
                , 3);
        }

        protected bool Equals(Portfolio other)
        {
            return string.Equals(Id, other.Id, StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Portfolio) obj);
        }

        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }

        
    }

    public class PortfolioStockConnection
    {
        public PortfolioStockConnection(Portfolio portfolio, Stock inStock)
        {
            Portfolio = portfolio;
            Stock = inStock;
            Count = 0;
        }

        public Portfolio Portfolio { get; set; }

        public Stock Stock { get; set; }

        public int Count { get; set; }
    }
}
