﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
	{
		#region Privatne varijable
		List<Stock> dionice = new List<Stock>();
		List<Index> indeksi = new List<Index>();
		List<Portfolio> portfelji = new List<Portfolio>();
		#endregion

		#region Dionice
		public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
			Stock dionica = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
			
			//provjera da li vec postoji:
			foreach (Stock dionica1 in dionice)
			{
				if (dionica1.Ime == dionica.Ime) throw new StockExchangeException("Ta dionica već postoji.");
			}

			//provjera ispravnosti broja:
			if (dionica.Broj <= 0) throw new StockExchangeException("Broj mora biti pozitivan.");

			//provjera ispravnosti početne cijene:
			if (dionica.PocetnaCijena <= 0) throw new StockExchangeException("Cijena mora biti pozitivna.");

			//ako je sve OK dodajemo dionicu u listu
			dionice.Add(dionica);
        }

		public void DelistStock(string inStockName)
        {
			for (int i = 0; i < dionice.Count; i++)
			{
				if (dionice[i].Ime == inStockName)
				{
					dionice.Remove(dionice[i]);
					//kaskadno brisanje:
					foreach (Index indeks in indeksi)
						RemoveStockFromIndex(indeks.Naziv, inStockName);
					foreach (Portfolio portfelj in portfelji)
						RemoveStockFromPortfolio(portfelj.ID, inStockName);
					
					return;
				}
			}
			
			throw new StockExchangeException("Dionica ne postoji.");
        }

		public bool StockExists(string inStockName)
        {
			foreach (Stock dionica in dionice)
			{
				if (dionica.Ime == inStockName) return true;
			}
			return false;
        }

        public int NumberOfStocks()
        {
			return dionice.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
			foreach (Stock dionica in dionice)
			{
				if (dionica.Ime == inStockName)
				{
					StockPrice cijena = new StockPrice
					{
						Cijena = inStockValue,
						Vrijeme = inTimeStamp
					};
					if (cijena.Vrijeme < dionica.DatumVrijediOd)
						throw new StockExchangeException("Ne može se unijeti cijena za vrijeme ranije od vremena valjanosti.");
					dionica.DodajCijenu(cijena);
					return;
				}
			}
			throw new StockExchangeException("Dionica ne postoji.");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
			foreach (Stock dionica in dionice)
			{
				if (dionica.Ime == inStockName)
				{
					return dionica.DohvatiCijenu(inTimeStamp);
				}
			}
			throw new StockExchangeException("Dionica ne postoji.");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
			foreach (Stock dionica in dionice)
			{
				if (dionica.Ime == inStockName)
				{
					return dionica.PocetnaCijena;
				}
			}
			throw new StockExchangeException("Dionica ne postoji.");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
			foreach (Stock dionica in dionice)
			{
				if (dionica.Ime == inStockName)
				{
					return dionica.ZadnjaCijena;
				}
			}
			throw new StockExchangeException("Dionica ne postoji.");
        }
		#endregion

		#region Indeksi
		public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
			Index indeks = new Index
			{
				Naziv = inIndexName,
				Tip = inIndexType
			};

			foreach (Index indeks1 in indeksi)
			{
				if (indeks1.Naziv == indeks.Naziv) throw new StockExchangeException("Indeks već postoji.");
			}

			indeksi.Add(indeks);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName)
				{
					foreach (Stock dionica in dionice)
					{
						if (dionica.Ime == inStockName)
						{
							indeks.DodajDionicu(dionica);
							return;
						}
					}
					throw new StockExchangeException("Dionica ne postoji.");
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName)
				{
					foreach (Stock dionica in dionice)
					{
						if (dionica.Ime == inStockName)
						{
							indeks.UkloniDionicu(dionica);
							return;
						}
						throw new StockExchangeException("Dionica ne postoji.");
					}
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName)
				{
					foreach (Stock dionica in dionice)
					{
						if (dionica.Ime == inStockName.ToUpper())
						{
							return true;
						}
					}
					return false;
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName)
				{
					return indeks.DohvatiVrijednost(this.TrzisnaKapitalizacija);
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }

        public bool IndexExists(string inIndexName)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName) return true;
			}
			return false;
        }

        public int NumberOfIndices()
        {
			return indeksi.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
			foreach (Index indeks in indeksi)
			{
				if (indeks.Naziv == inIndexName)
				{
					return indeks.BrojDionica;
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }
		#endregion

		#region Portfelji
		public void CreatePortfolio(string inPortfolioID)
        {
			Portfolio portfelj = new Portfolio { ID = inPortfolioID };

			foreach (Portfolio portfelj1 in portfelji)
			{
				if (portfelj1.ID == portfelj.ID) throw new StockExchangeException("Portfelj već postoji.");
			}

			portfelji.Add(portfelj);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					foreach (Stock dionica in dionice)
					{
						if (dionica.Ime == inStockName)
						{
							int brZakupljenihDionica = 0;
							foreach (Portfolio portfelj1 in portfelji)
							{
								brZakupljenihDionica += portfelj1.DohvatiBrojDionicaUPortfelju(inStockName);
							}
							if (brZakupljenihDionica + numberOfShares > dionica.Broj)
								throw new StockExchangeException("Nema dovoljno dostupnih dionica na tržištu.");
							portfelj.DodajDionicu(dionica, numberOfShares);
							return;
						}
					}
					throw new StockExchangeException("Dionica ne postoji.");
				}
			}
			throw new StockExchangeException("Indeks ne postoji.");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					portfelj.UkloniDionicu(inStockName, numberOfShares);
					return;
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					portfelj.UkloniDionicu(inStockName);
					return;
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public int NumberOfPortfolios()
        {
			return portfelji.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
					return portfelj.BrojDionica;
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID) return true;
			}
			return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.DionicaJeUPortfelju(inStockName);
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.DohvatiBrojDionicaUPortfelju(inStockName); 
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.DohvatiVrijednost(timeStamp);
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
			foreach (Portfolio portfelj in portfelji)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.IzracunajMjesecnuPromjenu(Year, Month);
				}
			}
			throw new StockExchangeException("Portfelj ne postoji.");
		}
		#endregion

		#region Pomoćni Propertyji
		//fensi naziv za ukupnu vrijednosti svih dionica na burzi ;) :
		public decimal TrzisnaKapitalizacija
		{
			get
			{
				decimal vrijednost = 0;
				foreach (Stock dionica in dionice)
					vrijednost += dionica.ZadnjaCijena * dionica.Broj;
				return vrijednost;
			}
		}
		#endregion


	}

	#region Pomoćne klase
	public class Stock
	{
		public string Ime { get; set; }
		public long Broj { get; set; }
		public decimal PocetnaCijena { get; set; }
		public DateTime DatumVrijediOd { get; set; }
		private List<StockPrice> listaCijena = new List<StockPrice>();

		//u konstruktoru je potrebno dodati početnu cijenu u listu cijena:
		public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
		{
			this.Ime = inStockName;
			this.Broj = inNumberOfShares;
			this.PocetnaCijena = inInitialPrice;
			this.DatumVrijediOd = inTimeStamp;

			StockPrice pocetnaCijenaZaListu = new StockPrice
			{
				Cijena = this.PocetnaCijena,
				Vrijeme = this.DatumVrijediOd
			};
			this.listaCijena.Add(pocetnaCijenaZaListu);
		}

		public void DodajCijenu(StockPrice cijena)
		{
			foreach (StockPrice cijena1 in listaCijena)
			{
				if (cijena1.Vrijeme == cijena.Vrijeme)
					throw new StockExchangeException("Cijena za to vrijeme već je evidentirana.");
			}
			listaCijena.Add(cijena);
		}

		public Decimal ZadnjaCijena
		{
			get
			{
				DateTime maxTime = this.DatumVrijediOd;
				int maxIndex = 0;
				for (int i = 0; i < listaCijena.Count; i++)
				{
					if (listaCijena[i].Vrijeme > maxTime)
					{
						maxTime = listaCijena[i].Vrijeme;
						maxIndex = i;
					}
				}
				return listaCijena[maxIndex].Cijena;
			}
		}

		public Decimal DohvatiCijenu(DateTime inTime)
		{
			DateTime maxTime = this.DatumVrijediOd;
			int maxIndex = 0;
			for (int i = 0; i < listaCijena.Count; i++)
			{
				//dohvati cijenu u definiranom trenutku maxTime, pri čemu je maxTime > DatumVrijediOd i maxTime < zadanog trenutka inTime
				if ( (listaCijena[i].Vrijeme > maxTime) && (listaCijena[i].Vrijeme < inTime) )
				{
					maxTime = listaCijena[i].Vrijeme;
					maxIndex = i;
				}
			}
			return listaCijena[maxIndex].Cijena;
		}
	}

	public class StockPrice
	{
		public DateTime Vrijeme { get; set; }
		public decimal Cijena { get; set; }
	}

	public class Index
	{
		public string Naziv { get; set; }
		public IndexTypes Tip { get; set; }

		private List<Stock> dionice = new List<Stock>();

		public int BrojDionica
		{
			get
			{
				return dionice.Count;
			}
		}

		public decimal DohvatiVrijednost(decimal trzisnaKapitalizacija)
		{
			decimal vrijednost = 0;
			long brDionica = 0;
			decimal sum = 0;

			if (this.Tip == IndexTypes.AVERAGE)
			{
				foreach (Stock dionica in this.dionice)
				{
					vrijednost += dionica.ZadnjaCijena * dionica.Broj;
					brDionica += dionica.Broj;
				}
				vrijednost = Decimal.Round(vrijednost / brDionica, 3);
			}
			else
			{
				foreach (Stock dionica in this.dionice)
				{
					decimal faktor = dionica.ZadnjaCijena*dionica.Broj/trzisnaKapitalizacija;
					sum += dionica.ZadnjaCijena * faktor;
				}
				vrijednost = Decimal.Round(sum, 3);
			}

			return vrijednost;
		}

		public void DodajDionicu(Stock dionica)
		{
			foreach (Stock dionica1 in this.dionice)
			{
				if (dionica1.Ime == dionica.Ime)
					throw new StockExchangeException("Dionica već postoji u indeksu.");
			}
			this.dionice.Add(dionica);
		}

		public void UkloniDionicu(Stock dionica)
		{
			for (int i=0; i<this.dionice.Count; i++)
			{
				if (this.dionice[i].Ime == dionica.Ime)
				{
					this.dionice.Remove(this.dionice[i]);
					return;
				}
			}
			throw new StockExchangeException("Dionica ne postoji u indeksu.");
		}
	}

	public class Portfolio
	{
		public string ID { get; set; }
		private List<StockInProtfolio> listaUdjela = new List<StockInProtfolio>();

		public int BrojDionica
		{
			get
			{
				return listaUdjela.Count;
			}
		}

		public decimal DohvatiVrijednost(DateTime timeStamp)
		{
		    decimal sum = 0;
			foreach (StockInProtfolio udio in listaUdjela)
				sum += udio.Dionica.DohvatiCijenu(timeStamp) * udio.BrojDionica;
			return sum;
		}

		public bool DionicaJeUPortfelju(string inStockName)
		{
			foreach (StockInProtfolio udio in listaUdjela)
			{
				if (udio.Dionica.Ime == inStockName) return true;
			}
			return false;
		}

		public int DohvatiBrojDionicaUPortfelju(string inStockName)
		{
			foreach (StockInProtfolio udio in listaUdjela)
			{
				if (udio.Dionica.Ime == inStockName)
					return udio.BrojDionica;
			}
			return 0;
		}

		public void DodajDionicu(Stock dionica, int numShares)
		{
			//provjera da li dionica već postoji u portfelju:
			//ako postoji dodaje se u portfelj
			foreach (StockInProtfolio udio in listaUdjela)
			{
				if (udio.Dionica.Ime == dionica.Ime)
				{
					udio.BrojDionica += numShares;
					return;
				}
			}
			
			//inače se evidentira nova dionica
			StockInProtfolio udio1 = new StockInProtfolio
			{
				Dionica = dionica,
				BrojDionica = numShares
			};
			listaUdjela.Add(udio1);
		}

		public void UkloniDionicu(string inStockName, int numberOfShares)
		{
			foreach (StockInProtfolio udio in listaUdjela)
			{
				if (udio.Dionica.Ime == inStockName)
				{
					if (udio.BrojDionica - numberOfShares < 0)
						throw new StockExchangeException("Nema toliko udjela u portfelju.");
					udio.BrojDionica -= numberOfShares;
					return;
				}
			}
			throw new StockExchangeException("Te dionice nema u portfelju.");
		}

		public void UkloniDionicu(string inStockName)
		{
			for (int i = 0; i < listaUdjela.Count; i++)
			{
				if (listaUdjela[i].Dionica.Ime == inStockName)
				{
					listaUdjela.Remove(listaUdjela[i]);
					return;
				}
			}
			throw new StockExchangeException("Te dionice nema u portfelju.");
		}

		public decimal IzracunajMjesecnuPromjenu(int year, int month)
		{
			DateTime startTime = new DateTime(year, month, 1);
			int brDanaUMjesecu = System.DateTime.DaysInMonth(year, month);
			DateTime endTime = new DateTime(year, month, brDanaUMjesecu);
			endTime.AddHours(23);
			endTime.AddMinutes(59);
			endTime.AddSeconds(59);
			decimal startValue = 0;
			decimal endValue = 0;

			foreach (StockInProtfolio udio in listaUdjela)
			{
				startValue += udio.Dionica.DohvatiCijenu(startTime);
			}

			foreach (StockInProtfolio udio in listaUdjela)
			{
				endValue += udio.Dionica.DohvatiCijenu(endTime);
			}

			decimal value = (endValue - startValue) / startValue * 100;
			return Decimal.Round(value, 3);
		}
	}

	public class StockInProtfolio
	{
		public Stock Dionica { get; set; }
		public int BrojDionica { get; set; }
	}
	#endregion
}
