﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock
     {
         public string vrsta { get; set; }
         public long broj { get; set; }
         public decimal vrijednost { get; set; }
         public DateTime datumStvaranja { get; set; }
         private Dictionary<DateTime, decimal> pracenje;

         public Stock(string vrsta, long broj, decimal vrijednost, DateTime datumStvaranja)
         {
             this.vrsta = vrsta.ToLower();
             this.broj = broj;
             this.vrijednost = vrijednost;
             this.datumStvaranja = datumStvaranja;
             pracenje = new Dictionary<DateTime, decimal>();
             pracenje[datumStvaranja] = vrijednost;
         }

         public void update(DateTime datum, decimal vrijednost)
         {
             if (pracenje.Keys.Contains(datum)) throw new StockExchangeException("Vrijednost za taj datum je vec unesena!");
             pracenje[datum] = vrijednost;
             if (datum < datumStvaranja) datumStvaranja = datum;
             this.vrijednost = vrijednost;
         }

         public List<DateTime> getDates()
         {
             return pracenje.Keys.ToList();
         }

         public decimal getPrice(DateTime date)
         {
             List<DateTime> dates = getDates().Where(x => x <= date).ToList();
             if (dates.Count == 0) throw new StockExchangeException("Vrijednost nije bila definirana u tom trenutku!");
             return pracenje[dates.Max()];
         }

     }

     public class Index
     {
         public IndexTypes indexType { get; set; }
         public List<Stock> stockList;
         public float vrijednost {get; set;}
         public string id { get; set; }

         public Index(string id, IndexTypes indexType)
         {
             this.id = id.ToLower();
             this.indexType = indexType;
             this.stockList = new List<Stock>();
         }


         public void addStock(Stock s)
         {
             if (s == null) throw new StockExchangeException("dionica ne postoji!");
             if (stockList.Contains(s)) throw new StockExchangeException("dionica je vec u indeksu!");
             stockList.Add(s);
         }

         public void removeStock(string name)
         {
             Stock s = stockList.Find(x => x.vrsta == name.ToLower());
             if (s != null)
             {
                 stockList.Remove(s);
             }
             else
             {
                 throw new StockExchangeException("Dionica nije u indeksu!");
             }

         }

         public List<Stock> listAllStocks()
         {
             return stockList;
         }

         public Stock getStock(string name)
         {
             try
             {
                 return stockList.Find(x => x.vrsta == name.ToLower());
             }
             catch
             {
                 throw new StockExchangeException("Dionica nije u indexu");
             }
         }

         public decimal getValue(DateTime date)
         {

             decimal totalValue = 0;
             if (stockList.Count == 0) return 0;
             if (this.indexType == IndexTypes.AVERAGE)
             {
                 foreach (Stock s in stockList)
                 {
                     totalValue += s.getPrice(date);
                 }

                 totalValue /= stockList.Count;
                 return totalValue;
             }
             else
             {

                 decimal Sum = 0;

                 foreach (Stock s in stockList)
                 {
                     Sum += s.getPrice(date) * s.broj;

                 }

                 foreach (Stock s in stockList)
                 {
                     Decimal value = s.getPrice(date);
                     totalValue += value * value * s.broj / Sum;

                 }
                 return totalValue;
             }
         }

     }


    public class Portfolio
    {
        private Dictionary<Stock, int> portfolio;
        public string id { get; set; }

        public Portfolio(string id)
        {
            portfolio = new Dictionary<Stock, int>();
            this.id = id;
            return;
        }

        public decimal getPercentage(int year, int month)
        {
            DateTime dateStart, dateStop;
            try
            {
                dateStart = new DateTime(year, month, 1, 0, 0, 0, 0);
                dateStop = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
            }
            catch (Exception e)
            {
                throw new StockExchangeException("Neispravan datum!");
            }
            decimal sumStart = 0;
            decimal sumStop = 0;
            foreach (Stock s in portfolio.Keys.ToList())
            {
                if (s.datumStvaranja > dateStart) throw new StockExchangeException("Pocetna vrijednost nije definirana u danom trenutku!");
                sumStart += s.getPrice(dateStart) * portfolio[s];
                sumStop += s.getPrice(dateStop) * portfolio[s];
            }
            if (sumStart - sumStop == 0) return 0;
            return Decimal.Round(100 * (sumStop - sumStart) / sumStart, 3);

        }

        public void addStock(Stock s, int i)
        {
            if (portfolio.Keys.ToList().Find(x => x.vrsta == s.vrsta) == null)
            {
                this.portfolio[s] = i;
            }
            else
            {
                portfolio[s] += i;
            }
        }

        public void removeStock(string id)
        {
            Stock s = this.getStock(id);
            if (s != null)
            {
                portfolio.Remove(s);
            }
            else
            {
                throw new StockExchangeException("Dionica nije dio portfelja!");
            }
        }

        public void removeStock(string id, int n)
        {
            Stock s = this.getStock(id);
            if (s != null)
            {
                this.sellShare(s, n);
            }
            else
            {
                throw new StockExchangeException("Dionica nije dio portfelja!");
            }
        }

        public Stock getStock(string id)
        {
            return portfolio.Keys.ToList().Find(x => x.vrsta == id.ToLower());
        }

        public int getnStocks()
        {
            return portfolio.Keys.Count;
        }

        public int getNumber(string id)
        {
            Stock s = getStock(id);
            if (s != null)
            {
                return portfolio[s];
            }
            else
            {
                return 0;
            }
        }

        public decimal getSingleValue(string id, DateTime date)
        {
            Stock s = getStock(id);
            if (s != null)
            {
                return portfolio[s] * s.getPrice(date);
            }
            else
            {
                return 0;
            }
        }

        public decimal getTotalValue(DateTime date)
        {
            decimal sum = 0;
            foreach (Stock s in portfolio.Keys.ToList())
            {
                sum += getSingleValue(s.vrsta, date);
            }
            return sum;
        }


        public void sellShare(Stock s, int i)
        {
            if (this.portfolio[s] < i)
            {
                i = portfolio[s];
            }
            this.portfolio[s] -= i;
            if (this.portfolio[s] == 0)
            {
                this.portfolio.Remove(s);
            }
        }


        public int getnShares()
        {
            int sum = 0;
            foreach (Stock s in portfolio.Keys)
            {
                sum += portfolio[s];
            }
            return sum;
        }

    }

    public class StockData
    {
        private List<Stock> stocks;
        private List<Portfolio> portfolios;
        private List<Index> indexes;

        public StockData()
        {
            stocks = new List<Stock>();
            portfolios = new List<Portfolio>();
            indexes = new List<Index>();
        }


        public void addStock(Stock s)
        {
            stocks.Add(s);
        }

        public void removeStock(Stock s)
        {
            if (s == null) throw new StockExchangeException("Dionica ne postoji!");

            foreach (Portfolio p in portfolios)
            {
                if (p.getStock(s.vrsta) != null) p.removeStock(s.vrsta);
            }

            foreach (Index i in indexes)
            {
                if (i.getStock(s.vrsta) != null) i.removeStock(s.vrsta);
            }

            stocks.Remove(s);
        }

        public Stock getStock(string vrsta)
        {

            Stock s = stocks.Find(x => x.vrsta == vrsta.ToLower());
            return s;
        }

        public void updateStock(string name, decimal value, DateTime date)
        {

            if (value <= 0) throw new StockExchangeException("Nepravilna vrijednost!");

            Stock s = getStock(name.ToLower());
            if (s != null)
            {
                s.update(date, value);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public List<Stock> getAllStocks()
        {
            return stocks;
        }

        public int getnStocks()
        {
            return this.stocks.Count;
        }

        public void addPortfolio(string id)
        {
            if (portfolios.Find(x => x.id == id) == null)
            {
                Portfolio p = new Portfolio(id);
                portfolios.Add(p);
            }
            else
            {
                throw new StockExchangeException("Portfolio s tim id-om vec postoji!");
            }
        }

        public void removePortfolio(string id)
        {
            Portfolio p = portfolios.Find(x => x.id == id);
            if (p != null)
            {
                portfolios.Remove(p);
            }

        }

        public Portfolio getPortfolio(string id)
        {
            return portfolios.Find(x => x.id == id);
        }

        public List<Portfolio> getAllPortfolios()
        {
            return portfolios;
        }

        public int getnPortfolios()
        {
            return portfolios.Count;
        }

        public void addIndex(string id, IndexTypes tip)
        {
            if (!Enum.IsDefined(typeof(IndexTypes), tip))
            {
                throw new StockExchangeException("Nepravilan tip!");
            }

            if (indexes.Find(x => x.id == id.ToLower()) == null)
            {
                Index p = new Index(id, tip);
                indexes.Add(p);
            }
            else
            {
                throw new StockExchangeException("Index s tim id-om vec postoji!");
            }
        }

        public void removeIndex(string id)
        {
            Index p = indexes.Find(x => x.id == id.ToLower());
            if (p != null)
            {
                indexes.Remove(p);
            }

        }

        public Index getIndex(string id)
        {
            return indexes.Find(x => x.id == id.ToLower());
        }

        public int getnIndexes()
        {
            return indexes.Count;
        }



    }

    public class StockExchange : IStockExchange
    {
        private StockData stockData = new StockData();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName) && inNumberOfShares > 0 && inInitialPrice > 0)
             {
                 Stock s = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 stockData.addStock(s);
             }
             else
             {
                 throw new StockExchangeException("dionica vec postoji");
             }
         }

         public void DelistStock(string inStockName)
         {
             stockData.removeStock(stockData.getStock(inStockName));
         }

         public bool StockExists(string inStockName)
         {
             return (stockData.getStock(inStockName) != null);
         }

         public int NumberOfStocks()
         {
             return stockData.getnStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             stockData.updateStock(inStockName, inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return stockData.getStock(inStockName).getPrice(inTimeStamp); 
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock s = stockData.getStock(inStockName);
             return s.getPrice(s.datumStvaranja);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock s = stockData.getStock(inStockName);
             return s.getPrice(new DateTime(9999, 12, 31));
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             stockData.addIndex(inIndexName, inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock s = stockData.getStock(inStockName.ToLower());
             Index i = stockData.getIndex(inIndexName);
             if (i == null) throw new StockExchangeException("indeks ne postoji!");
             i.addStock(s);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index i = stockData.getIndex(inIndexName);
             if (i == null) throw new StockExchangeException("Indeks ne postoji!");
             i.removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return (stockData.getIndex(inIndexName).getStock(inStockName) != null);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index i = stockData.getIndex(inIndexName);
             return i.getValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return (stockData.getIndex(inIndexName) != null);
         }

         public int NumberOfIndices()
         {
             return stockData.getnIndexes();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return stockData.getIndex(inIndexName).listAllStocks().Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             stockData.addPortfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio p = stockData.getPortfolio(inPortfolioID);
             if (p == null) throw new StockExchangeException("Neispravan portfolio!");
             Stock s = stockData.getStock(inStockName);
             if (numberOfShares <= 0) throw new StockExchangeException("Neispravan broj dionica");
             if (s != null)
             {
                 int usedShares = 0;
                 foreach (Portfolio po in stockData.getAllPortfolios())
                 {
                     if (po.getStock(s.vrsta) != null)
                         usedShares += po.getNumber(s.vrsta);
                 }
                 if (numberOfShares > s.broj - usedShares) numberOfShares = (int) s.broj - usedShares;
                 p.addStock(s, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio p = stockData.getPortfolio(inPortfolioID);
             if (p != null)
             {
                 p.removeStock(inStockName, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Portfelj ne postoji!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = stockData.getPortfolio(inPortfolioID);
             if (p == null) throw new StockExchangeException("Portfelj ne postoji!");
             p.removeStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return stockData.getnPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return stockData.getPortfolio(inPortfolioID).getnStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return (stockData.getPortfolio(inPortfolioID) != null);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return (stockData.getPortfolio(inPortfolioID).getStock(inStockName) != null);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return stockData.getPortfolio(inPortfolioID).getNumber(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return stockData.getPortfolio(inPortfolioID).getTotalValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return stockData.getPortfolio(inPortfolioID).getPercentage(Year, Month);
         }
     }
}
