﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new GCalc();
        }
    }

    class GCalc : ICalculator
    {
        const short MaxDigitsLength = 10;
        const short MaxCharsLength = 12;
        const string ErrorMessage = "-E-";
        const string DisplayChars = "-0123456789,";
        const string BinaryOperators = "+-*/";

        private double? memory = null;
        private double? cache = null;
        private bool haserror = false;
        private bool rewrite = false;
        private char oper = ' ';
        private string display = null;

        public GCalc()
        {
            resetCalc();
        }

        public void Press(char inPressedDigit)
        {
            char d = inPressedDigit;

            //unos znamenke
            if (Char.IsDigit(d))
            {
                if (d == '0' && display == "0")
                    setDisplay("0");
                else
                    addToDisplay(d);
            }
            else //unos specijalnog znaka
            {
                double number = getNumberOnDisplay();
                bool hascache = cache.HasValue;

                if (BinaryOperators.Contains(d))
                {
                    if (hascache && !rewrite)
                    {
                        switch (oper)
                        {
                            case '+': setResult(cache.Value + number, true); break;
                            case '-': setResult(cache.Value - number, true); break;
                            case '*': setResult(cache.Value * number, true); break;
                            case '/':
                                if (number == 0)
                                    setError();
                                else
                                    setResult(cache.Value / number, true); break;
                        }

                        number = getNumberOnDisplay();
                    }
                }

                switch (d)
                {
                    case '+':
                    case '-':
                    case '*':
                    case '/':
                        memorizeOperator(d, number);
                        break;
                    case '=': //submit
                        if (oper != ' ')
                        {
                            switch (oper)
                            {
                                case '+': setMathOpResult(cache.Value + number); break;
                                case '-': setMathOpResult(cache.Value - number); break;
                                case '*': setMathOpResult(cache.Value * number); break;
                                case '/':
                                    if (number == 0)
                                        setError();
                                    else
                                        setMathOpResult(cache.Value / number); break;
                            }
                            oper = ' ';
                        }
                        else //samo evaluiraj broj
                            setDisplay(roundNumber(number));

                        break;
                    case ',': //decimalni zarez
                        addToDisplay(d);
                        break;
                    case 'M': //minus
                        if (number == 0)
                            setError();
                        else
                            setMathOpResult(-number);
                        break;
                    case 'S': //sinus
                        setMathOpResult(Math.Sin(number));
                        break;
                    case 'K': //kosinus
                        setMathOpResult(Math.Cos(number));
                        break;
                    case 'T': //tangens
                        setMathOpResult(Math.Tan(number));
                        break;
                    case 'Q': //kvadriranje
                        setMathOpResult(Math.Pow(number, 2));
                        break;
                    case 'R': //korijenovanje
                        setMathOpResult(Math.Sqrt(number));
                        break;
                    case 'I': //inverz
                        if (number == 0)
                            setError();
                        else
                            setMathOpResult(1 / number);
                        break;
                    case 'P': //spremanje u memoriju
                        memory = roundNumber(number);
                        break;
                    case 'G': //dohvat iz memorije
                        if (memory != null)
                            setDisplay(memory.Value);
                        break;
                    case 'C': //brisanje ekrana
                        setDisplay("0");
                        break;
                    case 'O': //resetiranje
                        resetCalc();
                        break;
                }
            }

            if (haserror)
                setError();
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        private void memorizeOperator(char d, double number)
        {
            oper = d;
            rewrite = true;
            cache = number;
        }

        private double roundNumber(double n)
        {
            string sn = n.ToString().Replace(".", ",");
            string nsn = sn;

            bool isnegative = n < 0;
            bool isdecimal = sn.Contains(",");

            if (isdecimal)
            {
                int i = sn.TrimStart('-').IndexOf(',');
                return Math.Round(n, MaxCharsLength - i - 2);
            }
            else
            {
                if (sn.TrimStart('-').Length > MaxDigitsLength)
                    return Double.NaN;
                else
                    return n;
            }
        }

        private void setMathOpResult(double number)
        {
            setResult(number, false);
        }

        private void setResult(double number, bool set_rewrite)
        {
            setDisplay(number);

            if (set_rewrite)
                rewrite = true;
        }

        private double getNumberOnDisplay()
        {
            if (display == ErrorMessage)
                return Double.NaN;
            else
                return Convert.ToDouble(display);
        }

        private void addToDisplay(char d)
        {
            if (display == "0")
                rewrite = true;

            if (display.Length < MaxCharsLength)
                setDisplay(display + d.ToString());

            if (rewrite)
            {
                setDisplay(d.ToString());
                rewrite = false;
            }
        }

        private void setDisplay(double d)
        {
            double n = roundNumber(d);

            if (n.Equals(Double.NaN))
                setError();
            else
                setDisplay(n.ToString());
        }

        private void setDisplay(string d)
        {
            if (d == ErrorMessage)
                display = ErrorMessage;
            else
            {
                bool ok = true;
                foreach (char c in d)
                {
                    if (!DisplayChars.Contains(c))
                    {
                        ok = false;
                        break;
                    }
                }

                if (ok)
                {
                    if (d.Length > MaxCharsLength)
                        display = d.Substring(0, MaxCharsLength);
                    else
                        display = d;

                    if (display.StartsWith(","))
                        display = "0" + display;
                    else if (display.StartsWith("-,"))
                        display = "-0," + display.Substring(2);
                }
                else
                    setError();
            }
        }

        private void setError()
        {
            setDisplay(ErrorMessage);
        }

        private void resetCalc()
        {
            memory = null;
            cache = null;
            haserror = false;
            oper = ' ';
            display = "0";
        }
    }
}
