﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private Display display;
        private bool firstChar;
        private Double memory;
        private Double cache;
        private char operation;

        public Kalkulator()
        {
            display = new Display();
            firstChar = true;
            memory = 0;
            cache = 0;
            operation = '\0';
        }

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit >= '0' && inPressedDigit <= '9' || inPressedDigit == ',')
            {
                if (firstChar)
                {
                    display.Clear();
                    firstChar = false;
                }
                display.AddChar(inPressedDigit);
            }
            else if (inPressedDigit == 'M')
            {
                display.ChangeSign();
            }
            else if (inPressedDigit == 'S')
            {
                try
                {
                    display.Put(Math.Sin(display.GetDouble()));
                }
                catch
                {
                    display.Error = true;
                }
                firstChar = true;
            }
            else if (inPressedDigit == 'K')
            {
                try
                {
                    display.Put(Math.Cos(display.GetDouble()));
                }
                catch
                {
                    display.Error = true;
                }
                firstChar = true;
            }
            else if (inPressedDigit == 'T')
            {
                try
                {
                    display.Put(Math.Tan(display.GetDouble()));
                }
                catch
                {
                    display.Error = true;
                }
                firstChar = true;
            }
            else if (inPressedDigit == 'Q')
            {
                display.Put(Math.Pow(display.GetDouble(), 2));
                firstChar = true;
            }
            else if (inPressedDigit == 'R')
            {
                try
                {
                    display.Put(Math.Sqrt(display.GetDouble()));
                }
                catch 
                {
                    display.Error = true;
                }
                firstChar = true;
            }
            else if (inPressedDigit == 'I')
            {
                try
                {
                    display.Put(Math.Pow(display.GetDouble(), -1));
                }
                catch
                {
                    display.Error = true;
                }
                firstChar = true;
            }
            else if (inPressedDigit == 'P')
            {
                memory = display.GetDouble();
            }
            else if (inPressedDigit == 'G')
            {
                display.Put(memory);
            }
            else if (inPressedDigit == 'C')
            {
                display.Clear();
            }
            else if (inPressedDigit == 'O')
            {
                display = new Display();
                firstChar = true;
                memory = 0;
                cache = 0;
                operation = '\0';
            }
            else if (inPressedDigit == '+')
            {
                display.ClearZeros();
                if (operation != '\0')
                {
                    doOperation();
                }
                cache = display.GetDouble();
                operation = '+';
                firstChar = true;
            }
            else if (inPressedDigit == '-')
            {
                display.ClearZeros();
                if (operation != '\0')
                {
                    doOperation();
                }
                cache = display.GetDouble();
                operation = '-';
                firstChar = true;
            }
            else if (inPressedDigit == '*')
            {
                display.ClearZeros();
                if (operation != '\0')
                {
                    doOperation();
                }
                cache = display.GetDouble();
                operation = '*';
                firstChar = true;
            }
            else if (inPressedDigit == '/')
            {
                display.ClearZeros();
                if (operation != '\0')
                {
                    doOperation();
                }
                cache = display.GetDouble();
                operation = '/';
                firstChar = true;
            }
            else if (inPressedDigit == '=')
            {
                if (operation != '\0')
                {
                    doOperation();
                    cache = 0;
                    operation = '\0';
                    firstChar = true;
                }
                else
                {
                    display.ClearZeros();
                }
            }
        }

        private void doOperation()
        {
            if (operation == '+')
            {
                cache = cache + display.GetDouble();
            }
            else if (operation == '-')
            {
                cache = cache - display.GetDouble();
            }
            else if (operation == '*')
            {
                cache = cache * display.GetDouble();
            }
            else if (operation == '/')
            {
                try
                {
                    cache = cache / display.GetDouble();
                }
                catch
                {
                    display.Error = true;
                }
            }
            display.Put(cache);
        }

        public string GetCurrentDisplayState()
        {
            return display.ToString();
        }

        private class Display
        {
            private char[] screen;
            private bool negative;
            private bool comma;
            private int screenSize;
            private bool error;

            public bool Error
            {
                get { return error; }
                set { error = value; }
            }

            public Display()
            { 
                screen = new char[11];
                negative = false;
                comma = false;
                screenSize = 0;
                error = false;
            }

            public bool IsDouble()
            {
                return comma;
            }

            private long GetLong()
            {
                if (comma || error)
                {
                    throw new InvalidOperationException("Screen contains comma!");
                }

                long number = 0;

                for (int i = 0; i < screenSize; i++)
                {
                    number = number * 10 + screen[i] - '0';
                }

                if (negative)
                {
                    number = -number;
                }
                return number;
            }

            public Double GetDouble()
            {
                Double beforeComma = 0;
                int commaPosition = findComma();

                if (error)
                {
                    throw new InvalidOperationException();
                }

                if (commaPosition == -1)
                {
                    comma = false;
                    return (Double) (GetLong());
                }

                for (int i = 0; i < commaPosition; i++)
                {
                    beforeComma = beforeComma * 10 + screen[i] - '0';
                }

                Double afterComma = 0;
                for (int i = screenSize-1; i > commaPosition; i--)
                {
                    afterComma = afterComma / 10 + screen[i] - '0';
                }

                double value = beforeComma + afterComma / 10;

                if (negative)
                {
                    return -value;
                }
                return value;
            }

            private int findComma()
            {
                for (int i = 0; i < screenSize; i++)
                {
                    if (screen[i] == ',')
                    {
                        return i;
                    }
                }
                return -1;
            }

            public bool AddChar(char c)
            {
                if (screenSize == 0 && c == '0')
                {
                    return false;
                }

                if ((c != ',') && ((c < '0') || (c > '9')))
                {
                    throw new ArgumentException("Illegal character!");
                }
                if (comma)
                {
                    if (screenSize == 11)
                    {
                        return false;
                    }
                    if (c == ',')
                    {
                        return false;
                    }
                }

                if (!comma)
                {
                    if (screenSize == 10)
                    {
                        return false;
                    }
                    if (c == ',')
                    {
                        comma = true;
                    }
                }
                screen[screenSize] = c;
                screenSize++;
                return true;
            }

            public override string ToString()
            {
                if (error)
                {
                    return "-E-";
                }

                if (screenSize == 0)
                {
                    return "0";
                }

                if (screenSize == 1 && screen[0] == '0')
                { 
                    return "0";
                }

                string display = "";
                if (negative)
                {
                    display += '-';
                }
                if (screen[0] == ',')
                {
                    display += "0";
                }
                for (int i = 0; i < screenSize; i++)
                {
                    display += screen[i];
                }
                return display;
            }

            private bool Put(long l)
            {
                if (l < 0)
                {
                    negative = true;
                    l = -l;
                }
                string LString = l.ToString().Trim();
                if (LString.Length > 10)
                {
                    error = true;
                    return false;
                }

                screenSize = 0;
                foreach (char c in LString)
                {
                    screen[screenSize] = c;
                    screenSize++;
                }
                return true;
            }

            private bool fitsScreen(Double d)
            {
                if (d < 0)
                {
                    d = -d;
                }
                string DString = d.ToString().Trim();
                if (DString.IndexOf(',') != -1)
                {
                    DString = DString.Substring(0, DString.IndexOf(','));
                }
                if (DString.Length > 10)
                {
                    return false;
                }
                return true;
            }

            public bool Put(Double d)
            {
                if (Double.IsInfinity(d))
                {
                    error = true;
                    return false;
                }

                if (!fitsScreen(d))
                {
                    error = true;
                    return false;
                }

                if (d < 0)
                {
                    negative = true;
                    d = -d;
                }
                string DString = Math.Round(d, 9).ToString().Trim();
                if (DString.IndexOf(',') > 11)
                {
                    error = true;
                    return false;
                }
                else
                {
                    if (DString.IndexOf(',') <= 10)
                    {
                        comma = true;
                    }
                    else
                    {
                        comma = false;
                    }
                }

                screenSize = 0;
                for (int i = 0; i <= 10 && i < DString.Length; i++)
                {
                    screen[screenSize] = DString[i];
                    screenSize++;
                }

                return true;
            }

            public void Clear()
            {
                negative = false;
                comma = false;
                screenSize = 0;
                error = false;
            }

            public void ClearZeros()
            {
                if (comma)
                {
                    int commaPositon = findComma();
                    while (screen[screenSize - 1] == '0' && screenSize != (commaPositon + 1))
                    {
                        screenSize--;
                    }
                    if (screen[screenSize - 1] == ',')
                    {
                        screenSize--;
                    }
                }
            }

            public void ChangeSign()
            { 
                this.negative = !negative;
            }
        }

    }
}
