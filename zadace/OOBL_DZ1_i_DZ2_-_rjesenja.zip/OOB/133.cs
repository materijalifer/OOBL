﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        List<Stock> _allStocks;
        List<Index> _allIndices;
        List<Portfolio> _allPortfolios;
        
        public StockExchange()
        {
            _allStocks = new List<Stock>();
            _allIndices = new List<Index>();
            _allPortfolios = new List<Portfolio>();
        }
        

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName) && inInitialPrice > 0)
            {
                _allStocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
            {
                throw new StockExchangeException("Stock with name: " + inStockName + " already exists.");
            }

            //throw new NotImplementedException();
        }

        public void DelistStock(string inStockName)
        {
            Stock delStock = FindStockByName(inStockName);

            foreach (Index i in _allIndices)
            {
                if (i.ContainsStock(delStock))
                {
                    i.RemoveStock(delStock);
                }
            }

            foreach (Portfolio p in _allPortfolios)
            {
                if (p.ContainsStock(inStockName))
                {
                    p.RemoveSharesOfStock(inStockName);
                }
            }

            _allStocks.Remove(delStock);

            //throw new NotImplementedException();
        }

        public bool StockExists(string inStockName)
        {
            foreach (Stock s in _allStocks)
            {
                if (s.Name.ToLower().Equals(inStockName.ToLower()))
                    return true;
            }
            return false;
            
            //throw new NotImplementedException();
        }

        public int NumberOfStocks()
        {
            return _allStocks.Count;

            //throw new NotImplementedException();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            FindStockByName(inStockName).SetPrize(inIimeStamp, inStockValue);

            //throw new NotImplementedException();
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return FindStockByName(inStockName).GetPrizeInTime(inTimeStamp);
            
            //throw new NotImplementedException();
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return FindStockByName(inStockName).InitialPrize;

            //throw new NotImplementedException();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return FindStockByName(inStockName).GetLastPrize();

            //throw new NotImplementedException();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Index type not supported.");
            }

            if (!IndexExists(inIndexName))
            {
                _allIndices.Add(new Index(inIndexName, inIndexType));
            }
            else
            {
                throw new StockExchangeException("Index with name: " + inIndexName + " already exists.");
            }
            
            //throw new NotImplementedException();
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName))
            {
                FindIndexByName(inIndexName).AddStock(FindStockByName(inStockName));
            }

            //throw new NotImplementedException();
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            FindIndexByName(inIndexName).RemoveStock(FindStockByName(inStockName));

            //throw new NotImplementedException();
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return FindIndexByName(inIndexName).ContainsStock(FindStockByName(inStockName));

            //throw new NotImplementedException();
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            //K.I.S.S principle :D
            if (FindIndexByName(inIndexName).Type == IndexTypes.AVERAGE)
            {
                return FindIndexByName(inIndexName).GetValueInTimeAverage(inTimeStamp);
            }
            else
            {
                return FindIndexByName(inIndexName).GetValueInTimeWeighted(inTimeStamp, totalValueOfStockExchange(inTimeStamp));
            }

            //throw new NotImplementedException();
        }

        public bool IndexExists(string inIndexName)
        {
            if (_allIndices.Find(i => i.Name.ToLower().Equals(inIndexName.ToLower())) != null)
            {
                return true;
            }
            else
            {
                return false;
            }
            //throw new NotImplementedException();
        }

        public int NumberOfIndices()
        {
            return _allIndices.Count;

            //throw new NotImplementedException();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return FindIndexByName(inIndexName).NumberOfStocks();

            //throw new NotImplementedException();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (_allPortfolios.Find(p => p.Id.Equals(inPortfolioID)) != null)
            {
                throw new StockExchangeException("Portfolio with id: " + inPortfolioID + " already exists.");
            }

            _allPortfolios.Add(new Portfolio(inPortfolioID));

            //throw new NotImplementedException();
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            int usedShares = 0;

            foreach (Portfolio p in _allPortfolios)
            {
                if (p.ContainsStock(inStockName))
                {
                    usedShares += NumberOfSharesOfStockInPortfolio(p.Id, inStockName);
                }
            }

            if (FindStockByName(inStockName).NumberOfShares >= (usedShares + numberOfShares))
            {
                FindPortfolioByName(inPortfolioID).AddSharesOfStock(FindStockByName(inStockName).getNShares(numberOfShares));
            }
            else
            {
                throw new StockExchangeException("Not enough free shares.");
            }
            
            //throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            FindPortfolioByName(inPortfolioID).RemoveSharesOfStock(inStockName, numberOfShares);

            //throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            FindPortfolioByName(inPortfolioID).RemoveSharesOfStock(inStockName);

            //throw new NotImplementedException();
        }

        public int NumberOfPortfolios()
        {
            return _allPortfolios.Count;

            //throw new NotImplementedException();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return FindPortfolioByName(inPortfolioID).NumOfStocks();

            //throw new NotImplementedException();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (_allPortfolios.Find(p => p.Id.Equals(inPortfolioID)) != null)
            {
                return true;
            }
            else
            {
                return false;
            }

            //throw new NotImplementedException();
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return FindPortfolioByName(inPortfolioID).ContainsStock(inStockName);
            
            //throw new NotImplementedException();
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return Convert.ToInt32(FindPortfolioByName(inPortfolioID).NumOfSharesOfStock(inStockName));
            
            //PITATI PROFESORA DA LI IDE INT ILI LONG
            //throw new NotImplementedException();
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return FindPortfolioByName(inPortfolioID).ValueInTime(timeStamp);
            //throw new NotImplementedException();
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal firstDayValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0));
            decimal lastDayValue =  GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
            
            return Math.Round((lastDayValue / firstDayValue - 1) * 100, 3);
            //throw new NotImplementedException();
        }

        //****************************NEW METHODS**********************//

        private Stock FindStockByName(string stockName)
        {
            if(StockExists(stockName))
            {
                return _allStocks.Find(s => s.Name.ToLower().Equals(stockName.ToLower()));
            }
            else
            {
                throw new StockExchangeException("Stock with name: " + stockName + " doesn't exist.");
            }
        }

        private Index FindIndexByName(string indexName)
        {
            if(IndexExists(indexName))
            {
                return _allIndices.Find(i => i.Name.ToLower().Equals(indexName.ToLower()));
            }
            else
            {
                throw new StockExchangeException("Index with name: " + indexName + " doesn't exist.");
            }
        }

        private Portfolio FindPortfolioByName(string portfolioId)
        {
            if(PortfolioExists(portfolioId))
            {
                return _allPortfolios.Find(p => p.Id.Equals(portfolioId));
            }
            else
            {
                throw new StockExchangeException("Portfolio with name: " + portfolioId + " doesn't exist.");
            }
        }

        public Decimal totalValueOfStockExchange(DateTime timeStamp)
        {
            Decimal value = 0;

            foreach (Stock s in _allStocks)
            {
                value += s.GetPrizeInTime(timeStamp) * s.NumberOfShares;
            }

            return value;
        }

        //*************************************************************//

    }

    //*******************NEW CLASSES****************************//

    public class Stock
    {
        private string _name;
        private long _numberOfShares;
        private Decimal _initialPrize;
        private DateTime _timeStamp;

        private List<PrizeCheckpoint> _stockPrizeTimeLine;

        private class PrizeCheckpoint:IComparable<PrizeCheckpoint>
        {
            public DateTime _timeStamp;
            public Decimal _prize;

            public PrizeCheckpoint(DateTime timeStamp, Decimal prize)
            {
                this._timeStamp = timeStamp;
                this._prize = prize;
            }

            public int CompareTo(PrizeCheckpoint pc)
            {
                return this._timeStamp.CompareTo(pc._timeStamp);
            }
        }

        private Stock(Stock orgStock)
        {
            this._name = orgStock._name;
            this._stockPrizeTimeLine = orgStock._stockPrizeTimeLine;
            this._initialPrize = orgStock._initialPrize;
            this._timeStamp = orgStock._timeStamp;

            //this._numberOfShares = numOfShares;
        }

        public Stock(string name, long numberOfShares, Decimal initialPrize, DateTime timeStamp)
        {
            this._stockPrizeTimeLine = new List<PrizeCheckpoint>();
            this._name = name;
            this._numberOfShares = numberOfShares;
            this._initialPrize = initialPrize;
            this._timeStamp = timeStamp;

            this._stockPrizeTimeLine.Add(new PrizeCheckpoint(timeStamp, initialPrize));
        }

        public string Name
        {
            get { return _name; }
        }

        public void SetPrize(DateTime timeStamp, Decimal value)
        {
            if (value > 0)
            {
                this._stockPrizeTimeLine.Add(new PrizeCheckpoint(timeStamp, value));
                this._stockPrizeTimeLine.Sort();
            }
            else
            {
                throw new StockExchangeException("Prize needs to be positive.");
            }
        }

        public Decimal GetPrizeInTime(DateTime timeStamp)
        {
            try
            {
                int i = _stockPrizeTimeLine.Count - 1;

                while (_stockPrizeTimeLine.ElementAt(i)._timeStamp > timeStamp)
                {
                    i--;
                }

                return _stockPrizeTimeLine.ElementAt(i)._prize;
            }
            catch (Exception e)
            {
                throw new StockExchangeException("No prize defined.");
            }
        }

        public Decimal InitialPrize
        {
            get { return _initialPrize; }
        }

        public Decimal GetLastPrize()
        {
            int lastIndex = _stockPrizeTimeLine.Count - 1;

            return _stockPrizeTimeLine.ElementAt(lastIndex)._prize;
        }

        public Stock getNShares(long n)
        {
            Stock stockPart = new Stock(this);
            stockPart._numberOfShares = n;

            return stockPart;
        }

        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }


    }

    public class Index
    {
        private string _name;
        private IndexTypes _type;

        private List<Stock> _stocks;

        public Index(string name, IndexTypes type)
        {
            this._name = name;
            this._type = type;
            this._stocks = new List<Stock>();
        }

        public string Name
        {
            get { return _name; }
        }

        public IndexTypes Type
        {
            get { return _type; }
        }

        public void AddStock(Stock newStock)
        {
            if (!this._stocks.Contains(newStock))
            {
                this._stocks.Add(newStock);
            }
            else
            {
                throw new StockExchangeException("Stock with name: " + newStock.Name + " already exists in this index.");
            }
        }

        public void RemoveStock(Stock stockToRemove)
        {
            if (this._stocks.Contains(stockToRemove))
            {
                this._stocks.Remove(stockToRemove);
            }
            else
            {
                throw new StockExchangeException("There is no stock with the name: " + stockToRemove.Name + " in this index.");
            }
        }

        public bool ContainsStock(Stock stock)
        {
            return this._stocks.Contains(stock);
        }

        public Decimal GetValueInTimeAverage(DateTime timeStamp)
        {
            try
            {
                Decimal value = 0;
                long totalNumOfShares = 0;

                if (_type == IndexTypes.AVERAGE)
                {
                    foreach (Stock s in _stocks)
                    {
                        value += s.GetPrizeInTime(timeStamp) * s.NumberOfShares;
                        totalNumOfShares += s.NumberOfShares;
                    }
                }

                return Math.Round(value / totalNumOfShares, 3);
            }
            catch (Exception e)
            {
                throw new StockExchangeException("No can do.");
            }
        }

        public Decimal GetValueInTimeWeighted(DateTime timeStamp, Decimal totalValue)
        {
            try
            {
                Decimal value = 0;

                foreach (Stock s in _stocks)
                {
                    Decimal stockValue = 0;
                    stockValue = s.GetPrizeInTime(timeStamp) * s.NumberOfShares;

                    value += s.GetPrizeInTime(timeStamp) * (stockValue / totalValue);
                }

                return Math.Round(value, 3);
            }
            catch
            {
                throw new StockExchangeException("No can do.");
            }
        }


        public int NumberOfStocks()
        {
            return this._stocks.Count;
        }

    }

    public class Portfolio
    {
        private string _id;
        private List<Stock> _stocks;

        public Portfolio(string id)
        {
            this._id = id;
            _stocks = new List<Stock>();
        }

        public string Id
        {
            get { return _id; }
        }

        public void AddSharesOfStock(Stock newStock)
        {
            if (ContainsStock(newStock.Name))
            {
                GetStockByName(newStock.Name).NumberOfShares += newStock.NumberOfShares;
            }
            else
            {
                this._stocks.Add(newStock);
            }
        }

        public long NumOfSharesOfStock(string stockName)
        {
            return GetStockByName(stockName).NumberOfShares;
        }

        private Stock GetStockByName(string stockName)
        {
            if(ContainsStock(stockName))
            {
                return _stocks.Find(s => s.Name.ToLower().Equals(stockName.ToLower()));
            }
            else
            {
                throw new StockExchangeException("No such stock in portfolio.");
            }
        }

        public bool ContainsStock(string stockName)
        {
            foreach (Stock s in _stocks)
            {
                if (s.Name.ToLower().Equals(stockName.ToLower()))
                    return true;
            }
            return false;
        }

        public int NumOfStocks()
        {
            return _stocks.Count;
        }

        public void RemoveSharesOfStock(string stockName, int numOfShares)
        {
            if (GetStockByName(stockName).NumberOfShares > numOfShares)
            {
                GetStockByName(stockName).NumberOfShares -= numOfShares;
            }
            else
            {
                _stocks.Remove(GetStockByName(stockName));
                //briše sve dionice iz portfolio ako se zada veći broj nego što ih ima
                //druga opcija je da baci exception ali mi se ova činila logičnija :)
            }
        }

        public void RemoveSharesOfStock(string stockName)
        {
            _stocks.Remove(GetStockByName(stockName));
        }

        public decimal ValueInTime(DateTime timeStamp)
        {
            decimal totalValue = 0;

            foreach (Stock s in _stocks)
            {
                totalValue += s.GetPrizeInTime(timeStamp)*s.NumberOfShares;
            }

            return totalValue;
        }

    }

    //**********************************************************//

}
