﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private IState currentState;

        public IState CurrentState {
            get { return currentState; }
            set { currentState = value; }
        }

        private double numInMemory = 0;

        /// <summary>
        /// Broj spremljen u memoriju
        /// </summary>
        public double NumInMemory {
            get { return numInMemory; }
            set { numInMemory = value; }
        }

        public Kalkulator() {
            currentState = new InitialState();
        }
        
        public void Press(char inPressedDigit)
        {
            currentState.Pressed(this, inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return currentState.GetCurrentDisplayState(this);
        }

    }

    /// <summary>
    /// Sučelje kojim se modelira oblikovni obrazac Stanje (State)
    /// </summary>
    public interface IState
    {
        void Pressed(Kalkulator calc, char inPressedDigit);

        string GetCurrentDisplayState(Kalkulator calc);
    }

    /// <summary>
    /// Početno stanje, kada se kalkulator pali i resetira
    /// </summary>
    public class InitialState : IState
    {
        public void Pressed(Kalkulator calc, char inPressedDigit) {
            if (inPressedDigit == '0') return;
            IState nextState = null;
            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',') {
                nextState = new EnteringNumState(null, null);
            }
            else {
                nextState = new OperationState("0");
            }
            calc.CurrentState = nextState;
                nextState.Pressed(calc, inPressedDigit);
        }

        public string GetCurrentDisplayState(Kalkulator calc) {
            return "0";
        }
    }

    /// <summary>
    /// Stanje za upis brojeva
    /// </summary>
    public class EnteringNumState : IState
    {
        private StringBuilder numBuilder = new StringBuilder(11);
        private bool isNegative = false;
        private int displayLen = 10;
        private OperationState callingState;

        public EnteringNumState(OperationState callingState, string alreadyEnteredNum) {
            if (alreadyEnteredNum != null) {
                numBuilder.Append(alreadyEnteredNum);
                if (numBuilder[0] == '-') {
                    numBuilder.Remove(0, 1);
                    isNegative = true;
                }
            }
            this.callingState = callingState;
        }

        public void Pressed(Kalkulator calc, char inPressedDigit) {
            if (Char.IsDigit(inPressedDigit)) {
                if (numBuilder.Length < displayLen) numBuilder.Append(inPressedDigit);
            }
            else if(inPressedDigit == 'M'){
                changeSign(); 
            }
            else if (inPressedDigit == ',') {
                if (isInsertedDecimalPointInNumber()) {
                    displayLen++;
                }
            }
            else {
                if (callingState == null) {
                    OperationState operState = new OperationState(this.GetCurrentDisplayState(calc));
                    calc.CurrentState = operState;
                    operState.Pressed(calc, inPressedDigit);
                }
                else {                   
                    calc.CurrentState = callingState;
                    callingState.SecondOperandEntered(calc, this.GetCurrentDisplayState(calc), inPressedDigit);
                    
                }
            }
        }

        private void changeSign() {
            if (isNegative == true) {
                isNegative = false;
            }
            else {
                isNegative = true;
            }
        }

        private bool isInsertedDecimalPointInNumber() {
            if (numBuilder.ToString().Contains(',')) return false;
            if (numBuilder.Length == 0) {
                numBuilder.Append('0');
            }
            numBuilder.Append(',');
            return true;
        }

        public string GetCurrentDisplayState(Kalkulator calc) {
            if (numBuilder.Length != 0) {
                string output = numBuilder.ToString();
                if (isNegative && !output.Contains('-')) output = output.Insert(0, "-");
                return output;
            }
            return "0";
        }
    }

    /// <summary>
    /// Stanje za izvršavanje operacija
    /// </summary>
    public class OperationState : IState
    {
        private double firstOperand;
        private string output;

        private BinaryOperations binaryOperation = BinaryOperations.NONE;
        private bool isBinOperEntered = false;

        private bool isUnarReqOnSecOper = false;
        private double unaryOperand;

        private bool isLastEnteredEquality = false;
        private double equalityOperand;

        public OperationState(string firstOperand) {
            this.firstOperand = Double.Parse(firstOperand);
            output = firstOperand;
        }
        
        public void Pressed(Kalkulator calc, char inPressedDigit) {
            if (isUnarReqOnSecOper) {
                this.SecondOperandEntered(calc, "0", inPressedDigit);
                return;
            }
            double tempResult = Double.Parse(output); ;
            switch (inPressedDigit) {
                case '+': binaryOperation = BinaryOperations.ADDING; isBinOperEntered = true;
                    break;
                case '-': binaryOperation = BinaryOperations.SUBTRACTION; isBinOperEntered = true;
                    break;
                case '*': binaryOperation = BinaryOperations.MULTIPLY; isBinOperEntered = true;
                    break;
                case '/': binaryOperation = BinaryOperations.DIVISION; isBinOperEntered = true;
                    break;
                case '=': equalsOperation(calc);
                    break;
                case 'S': tempResult = Math.Sin(firstOperand); setOutputAndOperand(calc, tempResult);
                    break;
                case 'K': tempResult = Math.Cos(firstOperand); setOutputAndOperand(calc, tempResult);
                    break;
                case 'T': tempResult = Math.Tan(firstOperand); setOutputAndOperand(calc, tempResult);
                    break;
                case 'Q': tempResult = Math.Pow(firstOperand, 2.0); setOutputAndOperand(calc, tempResult);
                    break;
                case 'R': tempResult = Math.Sqrt(firstOperand); setOutputAndOperand(calc, tempResult);
                    break;
                case 'I': if (firstOperand == 0.0) { error(calc); }
                    else { tempResult = Math.Pow(firstOperand, -1.0); setOutputAndOperand(calc, tempResult); }
                    break;
                case 'P': calc.NumInMemory = firstOperand; calc.CurrentState = new EnteringNumState(null, firstOperand.ToString());
                    break;
                case 'G': output = calc.NumInMemory.ToString();
                    break;
                case 'C': firstOperand = 0; output = "0";
                    break;
                case 'O': calc.NumInMemory = 0;
                    calc.CurrentState = new InitialState();
                    break;
                default: if (isNewNumberStarted(inPressedDigit)) 
                            { IState nextState = new EnteringNumState(this, null); nextState.Pressed(calc, inPressedDigit); calc.CurrentState = nextState; }
                        else { error(calc); }
                    break;
            }

            if (inPressedDigit != '=') isLastEnteredEquality = false;

        }

        public string GetCurrentDisplayState(Kalkulator calc) {
            if (isUnarReqOnSecOper) {
                return unaryOperand.ToString();
            }
            return output;
        }

        /// <summary>
        /// Postavljanje izlaza za čitanje i operanda ovisno o pozvanoj operaciji
        /// </summary>
        private void setOutputAndOperand(Kalkulator calc, double tempResult) {
            checkIfOverflow(calc);
            if (isBinOperEntered == false) {
                firstOperand = Double.Parse(fitResultToDisplay(tempResult.ToString()));
            }
            output = fitResultToDisplay(tempResult.ToString());
        }

        private bool isNewNumberStarted(char inPressedDigit) {
            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',') {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Provjera je li došlo do preljeva pri računanju
        /// </summary>
        private void checkIfOverflow(Kalkulator calc) {
            if (firstOperand > 1E9 || Double.Parse(output) > 1E9) {
                error(calc);
            }
        }

        /// <summary>
        /// stisnuto =
        /// </summary>
        private void equalsOperation(Kalkulator calc) { // kad je stisnuto =
            if (isLastEnteredEquality) {
                isBinOperEntered = true;
                equalsOperation(calc, equalityOperand);
            }
            else {
                if (!isBinOperEntered) {
                    output = firstOperand.ToString();
                }
                else {
                    isLastEnteredEquality = true;
                    equalityOperand = firstOperand;
                    equalsOperation(calc, firstOperand);
                }
            }
        }

        /// <summary>
        /// Računanje rezultata binarnih operacija
        /// </summary>
        private void equalsOperation(Kalkulator calc, Double secondOperand) { // izvođenje binarnih operacija
            switch (binaryOperation) {
                case BinaryOperations.ADDING: firstOperand += secondOperand;
                    break;
                case BinaryOperations.SUBTRACTION: firstOperand -= secondOperand;
                    break;
                case BinaryOperations.MULTIPLY: firstOperand *= secondOperand;
                    break;
                case BinaryOperations.DIVISION: firstOperand /= secondOperand;
                    break;
                default: error(calc);
                    break;
            }
            checkIfOverflow(calc);
            output = fitResultToDisplay(firstOperand.ToString());
            firstOperand = Double.Parse(output);
            isBinOperEntered = false;
        }

        /// <summary>
        /// Prilagođavanje brojeva prikazu kalkulatora
        /// </summary>
        private string fitResultToDisplay(string resultToFix) {
            int displaySize = 10;
            if (resultToFix.Contains(',')) displaySize++;
            if (resultToFix.Contains('-')) displaySize++;
            string fitResult = resultToFix;
            if (fitResult.Length > displaySize) {
                fitResult = Math.Round(Double.Parse(resultToFix), displaySize - resultToFix.LastIndexOf(',') -1).ToString();                
            }
            return fitResult;            
        }

        /// <summary>
        /// Dogodila se greška, promjena stanja u ErrorState
        /// </summary>
        private void error(Kalkulator calc) {
            calc.CurrentState = new ErrorState();
        }

        /// <summary>
        /// Unesen drugi operand binarne operacije
        /// </summary>
        public void SecondOperandEntered(Kalkulator calc, string secondOperandEntered, char inPressedDigit) {
            if (inPressedDigit == 'C') {
                return;
            }
            if (!isUnaryOperRequested(inPressedDigit)) {
                if (isUnarReqOnSecOper) {
                    isUnarReqOnSecOper = false;
                    this.SecondOperandEntered(calc, unaryOperand.ToString(), inPressedDigit);
                }
                else {
                    double secondOperand = Double.Parse(secondOperandEntered);
                    equalsOperation(calc, secondOperand);
                    this.Pressed(calc, inPressedDigit);
                }
            }
            else {
                if (isUnarReqOnSecOper) {
                    unaryOperand = unaryOperation(calc, unaryOperand, inPressedDigit);
                }
                else {
                    unaryOperand = unaryOperation(calc, Double.Parse(secondOperandEntered), inPressedDigit);
                    isUnarReqOnSecOper = true;
                }
                checkIfOverflow(calc);
                unaryOperand = Double.Parse(fitResultToDisplay(unaryOperand.ToString()));
            }
        }

        /// <summary>
        /// Računanje unarnih operacija
        /// </summary>
        private double unaryOperation(Kalkulator calc, double unaryOperand, char operation) {
            switch (operation) {
                case 'S': return Math.Sin(unaryOperand);
                case 'K': return Math.Cos(unaryOperand);
                case 'T': return Math.Tan(unaryOperand);
                case 'Q': return Math.Pow(unaryOperand, 2.0);
                case 'R': return Math.Sqrt(unaryOperand);
                case 'I': if (unaryOperand == 0.0) { error(calc); return 0; }
                    else { return Math.Pow(firstOperand, -1.0); }
                default: throw new NotSupportedException();
            }
        }

        /// <summary>
        /// Provjera je li pozvana unarna operacija
        /// </summary>
        private bool isUnaryOperRequested(char inPressedDigit) {
            switch (inPressedDigit) {
                case 'S': return true;
                case 'K': return true;
                case 'T': return true;
                case 'Q': return true;
                case 'R': return true;
                case 'I': return true;
                default: return false;
                    
            }
        }
    }

    /// <summary>
    /// Stanje koje se poziva u slučaju pogreške
    /// </summary>
    public class ErrorState : IState
    {

        public void  Pressed(Kalkulator calc, char inPressedDigit)
        {
            switch (inPressedDigit) {
                case 'C': calc.CurrentState = new InitialState();
                    break;
                case 'O': calc.NumInMemory = 0;
                    calc.CurrentState = new InitialState();
                    break;
            }
        }

        public string  GetCurrentDisplayState(Kalkulator calc)
        {
            return "-E-";
        }
    }

    enum BinaryOperations
    {
        NONE,
        ADDING = '+',
        SUBTRACTION = '-',
        MULTIPLY = '*',
        DIVISION = '/'

    }
}
