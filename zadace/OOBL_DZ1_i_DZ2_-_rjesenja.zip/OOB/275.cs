﻿//---
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        /// <summary>
        /// Handles input
        /// </summary>
        public void Press(char inPressedDigit)
        {
            // 
            if (Char.IsNumber(inPressedDigit))
            {
                fDigitEntered(inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case 'M':
                        if (current != error)
                            fSign();
                        break;
                    case decimalSeparator:
                        separatorPressed = true;
                        if (!lastOperation)
                        {
                            current = "0";
                        }
                        lastOperation = true;
                        dec = 0.1;
                        break;
                    case 'O':
                        fReset();
                        break;
                    case 'C':
                        fClear();
                        break;
                    case 'P':
                        if (current != error)
                            fStore();
                        break;
                    case 'G':
                        if (current != error)
                            fLoad();
                        break;
                    case 'S':
                        if (current != error)
                            fSin();
                        break;
                    case 'K':
                        if (current != error)
                            fCos();
                        break;
                    case 'T':
                        if (current != error)
                            fTan();
                        break;
                    case 'Q':
                        if (current != error)
                            fSquare();
                        break;
                    case 'R':
                        if (current != error)
                            fRoot();
                        break;
                    case '-':
                    case '+':
                    case '*':
                    case '/':
                    case '=':
                        if (current != error)
                            fBinaryOperations(inPressedDigit);
                        break;
                    case 'I':
                        if (current != error)
                            fInverse();
                        break;
                }
            }
        }

        /// <summary>
        /// Returns current display value
        /// </summary>
        public string GetCurrentDisplayState()
        {
            return current;
        }

        /// <summary>
        /// Handles numeric input
        /// </summary>
        private void fDigitEntered(char digit)
        {
            binaryOperator = false;

            // last input was a digit -> concatenate to current value
            if (lastOperation)
            {

                if (separatorPressed)
                {
                    // Real number - check if within allowed length
                    if (Math.Abs(double.Parse(current)).ToString().Length < maxDigits + 1)
                    {
                        // concatenating decimals for a positive current value
                        if (double.Parse(current) >= 0)
                        {
                            current = (double.Parse(current) + dec * double.Parse(digit.ToString())).ToString();
                        }
                        // concatenating decimals for a negative current value
                        else
                        {
                            current = (double.Parse(current) - dec * double.Parse(digit.ToString())).ToString();
                        }
                        dec /= 10;
                    }
                }

                // Integer - check if within allowed length
                else if (Math.Abs(double.Parse(current)).ToString().Length < maxDigits + 1)
                {
                    // Do not display trailing zeroes
                    if (!(current == "0"))
                    {
                        current = current + digit;
                    }
                }
            }
            else
            {
                current = digit.ToString();
                lastOperation = true;
            }
        }

        /// <summary>
        /// Toggles sign in current value
        /// </summary>
        private void fSign()
        {
            if (current != "0")
            {
                if (current[0] == '-')
                {
                    current = current.Remove(0, 1);
                }
                else
                {
                    current = "-" + current;
                }
            }
        }

        /// <summary>
        /// Resets the calculator to initial values
        /// </summary>
        private void fReset()
        {
            current = "0";
            stored = "0";
            previous = 0;
        }

        /// <summary>
        /// Clears the current input
        /// </summary>
        private void fClear()
        {
            current = "0";
            lastOperation = false;
        }

        /// <summary>
        /// Stores current input
        /// </summary>
        private void fStore()
        {
            stored = current;
            //inputEnded = true;
        }

        /// <summary>
        /// Loads stored value
        /// </summary>
        private void fLoad()
        {
            current = stored;
            //inputEnded = true;
        }

        /// <summary>
        /// Computes sine of current value
        /// </summary>
        private void fSin()
        {
            string sin = Math.Sin(Double.Parse(current)).ToString();
            current = stripDigits(sin);
        }

        /// <summary>
        /// Computes cosine of current value
        /// </summary>
        private void fCos()
        {
            string cos = Math.Cos(Double.Parse(current)).ToString();
            current = stripDigits(cos);
        }

        /// <summary>
        /// Computes tan of current value
        /// </summary>
        private void fTan()
        {
            string tan = Math.Tan(Double.Parse(current)).ToString();
            current = stripDigits(tan);
        }

        /// <summary>
        /// Computes inverse of current value
        /// </summary>
        private void fInverse()
        {
            if (Double.Parse(current) != 0)
            {
                Double tmp = 1 / Double.Parse(current);
                current = stripDigits(tmp.ToString());
            }
            else
            {
                current = error;
            }
        }

        /// <summary>
        /// Computes square of current value
        /// </summary>
        private void fSquare()
        {
            Double tmp = Math.Pow(Double.Parse(current), 2);
            current = stripDigits(tmp.ToString());
        }

        /// <summary>
        /// Computes square root of current value
        /// </summary>
        private void fRoot()
        {           
            if (Double.Parse(current) >= 0)
            {
                Double tmp = Math.Pow(Double.Parse(current), 0.5);
                current = stripDigits(tmp.ToString());
            }
            else
            {
                current = error;
            }
        }

        /// <summary>
        /// Handles and computes binary
        /// operations (+, -, * and /)
        /// </summary>
        private void fBinaryOperations(char currentOperator)
        {
            if (!(current == error))
            {
                separatorPressed = false;
                if (prevOperatorBinary)
                {
                    // check for division by zero
                    if ((prevOperator == '/') && (double.Parse(current) == 0))
                    {
                        current = error;
                    }
                    // if multiple binary operators entered,
                    // keep the last one
                    else if (binaryOperator && (currentOperator != '='))
                    {
                        prevOperator = currentOperator;
                    }
                    else
                    {
                        // compute the actual operation
                        switch (prevOperator)
                        {
                            case '+':
                                previous = previous + double.Parse(current);
                                prevOperator = currentOperator;
                                break;
                            case '-':
                                previous = previous - double.Parse(current);
                                prevOperator = currentOperator;
                                break;
                            case '*':
                                previous = previous * double.Parse(current);
                                prevOperator = currentOperator;
                                break;
                            case '/':
                                previous = previous / double.Parse(current);
                                prevOperator = currentOperator;
                                break;
                        }
                        current = previous.ToString();
                    }

                    // check for constraints when Integer
                    if (!current.Contains(decimalSeparator) && Math.Abs(previous).ToString().Length > maxDigits)
                    {
                        current = error;
                    }

                    // check for constrains when real
                    else if (current.Contains(decimalSeparator))
                    {
                        string[] dijeloviStringa = current.Split(decimalSeparator);
                        double prvi = double.Parse(dijeloviStringa[0]);
                        if (Math.Abs(prvi).ToString().Length > maxDigits)
                        {
                            current = error;
                        }
                        else if (Math.Abs(prvi).ToString().Length + dijeloviStringa[1].Length > maxDigits)
                        {
                            current = Math.Round(previous, (maxDigits - Math.Abs(prvi).ToString().Length)).ToString();
                        }

                    }
                }
                else
                {
                    previous = double.Parse(current);
                    prevOperator = currentOperator;
                    prevOperatorBinary = true;
                }
                binaryOperator = true;

            }

            lastOperation = false;

            //Console.WriteLine("current = " + current);
            if (current != error)
                current = stripDigits(current);

        }

        /// <summary>
        /// Strip digits to maxDigits
        /// or returns -E- if out of constraints
        /// </summary>
        private string stripDigits(string input)
        {
            bool decimalFound = false;
            int n = 0;
            int decimals = 0;

            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == decimalSeparator)
                {
                    decimalFound = true;
                }
                if (Char.IsNumber(input[i]))
                {
                    n++;
                    if (decimalFound)
                    {
                        decimals++;
                    }
                }

                if (n == maxDigits)
                {
                    if (decimalFound)
                    {
                        return double.Parse(Math.Round(Double.Parse(input), decimals).ToString()).ToString();
                    }
                    else
                    {
                        return error;
                    }
                }
            }
            return double.Parse(input).ToString();
        }

        // Definitions
        private const char decimalSeparator = ',';
        private const string error = "-E-";
        private int maxDigits = 10;

        // Variables
        private string current = "0";
        private string stored = "0";
        private double previous = 0;
        private char prevOperator;

        // States
        private bool lastOperation = false;      // was the last input an operation?
        private bool separatorPressed = false;   // was the decimal seperator pressed?
        private bool prevOperatorBinary = false; // was the laast operator a binary one?
        private bool binaryOperator = false;     // were there multiple binary operators entered? (we keep the last one)        

        private double dec;

    }

}