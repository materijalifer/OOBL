﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock : System.Object
    {
         private readonly string _inStockName;
         private long _inNumberOfShares;

         private List<TimeValue> values;

         public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             this._inStockName = inStockName;
             this._inNumberOfShares = inNumberOfShares;

             if (inInitialPrice <= new decimal(0.0))
             {
                 throw new StockExchangeException("Initial stock price may not be negative");
             }

             values = new List<TimeValue>();

             values.Add(new TimeValue(inInitialPrice, inTimeStamp));
       
         
         }

        public long getCount()
        {
            return _inNumberOfShares;
        }

        public Decimal getPrice(DateTime inTimeStamp)
        {
            TimeValue cmp = new TimeValue(new decimal(0.0),inTimeStamp);
            TimeValue last = values.ElementAt(0);
            foreach (TimeValue tv in values)
            {
                
                if (cmp.isAfter(tv.getTime())){
                    return last.getValue();
                }
                last = tv;
            }
            return Math.Round(last.getValue(),3);
        }



        public void addValue(DateTime inTimeStamp, Decimal inStockValue)
        {
            TimeValue tv = new TimeValue(inStockValue, inTimeStamp);

            for (int i = 0; i < values.Count; i++)
            {
                int cmp = values.ElementAt(i).CompareTo(tv);
                if (cmp == 0)
                {
                    throw new StockExchangeException("Timestamp allready exists.");
                }
            }
            values.Add(tv);
            values.Sort();
        }

        public Decimal getInitialPrice()
        {
            return Math.Round(values.ElementAt(0).getValue(),3);
        }

        public Decimal getLastPrice()
        {
            return Math.Round(values.ElementAt(values.Count - 1).getValue(),3);
        }

        public string getID()
        {
            return this._inStockName;
        }

        public bool iS(string ID)
        {
            return this._inStockName.Equals(ID, StringComparison.InvariantCultureIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Stock s = obj as Stock;
            if ((System.Object)s == null)
            {
                return false;
            }

            return s.getID().Equals(this.getID(), StringComparison.InvariantCultureIgnoreCase);
        }

        

        public override int GetHashCode()
        {
            return 1337;
        }

    }

    public class Index : System.Object
    {
        private readonly string inIndexName;
        private readonly IndexTypes indexType;
        private List<Stock> STOX;
        private IValueCalc calc;
        public Index(string inIndexName, IndexTypes indexType)
        {
            if (indexType != IndexTypes.AVERAGE && indexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Invalid indexType");
            }
            if (indexType == IndexTypes.AVERAGE)
            {
                calc = new AverageIndexType();
            }else if (indexType == IndexTypes.WEIGHTED)
            {
                calc = new WeightedIndexType();
            }

            this.indexType = indexType;
            this.inIndexName = inIndexName;

            STOX = new List<Stock>();
        }

        public int getCount()
        {
            return STOX.Count;
        }

        public void addStock(Stock stock){
            if (checkContain(stock.getID()))
            {
                throw new StockExchangeException("Index contains stock already");
            } 
            STOX.Add(stock);
        }

        private bool checkContain(string inStockName)
        {
            foreach (Stock s in STOX)
            {
                if (s.iS(inStockName))
                    return true;
            }
            return false;
        }

        public void removeStock(string inStockName)
        {
            if (checkContain(inStockName))
            {
                foreach (Stock s in STOX)
                {
                    if (s.iS(inStockName))
                    {
                        STOX.Remove(s);
                        return;
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Stock to be removed does not exist inside the index");
            }
        }

        public string getID()
        {
            return this.inIndexName;
        }

        public bool isStockContained(string inStockName)
        {
            return checkContain(inStockName);
        }

        public Decimal getValue(DateTime inTimeStamp)
        {
            return Math.Round(calc.getIndexValue(inTimeStamp, STOX),3);
        }

        public bool iS(string ID)
        {
            return this.inIndexName.Equals(ID, StringComparison.InvariantCultureIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Index s = obj as Index;
            if ((System.Object)s == null)
            {
                return false;
            }

            return s.getID().Equals(this.getID(), StringComparison.InvariantCultureIgnoreCase);
        }

        
        public override int GetHashCode()
        {
            return 1337;
        }
    }

    public class Portfolio : System.Object
    {
        private readonly string inPortfolioID;

        private Dictionary<string, int> stockAmounts;

        public Portfolio(string inPortfolioID)
        {
            this.inPortfolioID = inPortfolioID;

            stockAmounts = new Dictionary<string, int>();

        }

        public void addStocks(string inStockName, int numOfShares)
        {
            if (stockAmounts.ContainsKey(inStockName))
            {
                int numBefore = stockAmounts[inStockName];
                stockAmounts.Remove(inStockName);
                stockAmounts.Add(inStockName, numOfShares + numBefore);
            }
            else
            {
                stockAmounts.Add(inStockName, numOfShares);
            }
        }

        public void removeStocks(string inStockName, int numOfShares)
        {
            if (stockAmounts.ContainsKey(inStockName))
            {
                int numBefore = stockAmounts[inStockName];
                stockAmounts.Remove(inStockName);
                if (numOfShares < numBefore)
                {
                    stockAmounts.Add(inStockName, numBefore - numOfShares);
                }else if (numOfShares == numBefore)
                {
                    //nada
                }
                else
                {
                    throw new StockExchangeException("Too many stocks removed.");
                }
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in porftolio");
            }
        }

        public void removeStock(string inStockName)
        {
            if (stockAmounts.ContainsKey(inStockName)){
                stockAmounts.Remove(inStockName);
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in portfolio");
            }
        }

        public int numOfStocks()
        {
            return stockAmounts.Keys.Count;
        }

        public bool isStockContained(string inStockName)
        {
            return stockAmounts.ContainsKey(inStockName);
        }

        public int numOfShares(string inStockName)
        {
            if (stockAmounts.ContainsKey(inStockName))
            {
                return stockAmounts[inStockName];
            }
            else
            {
                throw new StockExchangeException("Stock does not exist in portfolio");
            }
        }

        public Dictionary<string, int> getPortfolioMap()
        {
            return this.stockAmounts;
        } 

        public string getID()
        {
            return this.inPortfolioID;
        }

        public bool iS(string ID)
        {
            return this.inPortfolioID == ID;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Portfolio s = obj as Portfolio;
            if ((System.Object)s == null)
            {
                return false;
            }

            return s.getID().Equals(this.getID());
        }

        
        public override int GetHashCode()
        {
            return 1337;
        }
    }

    public interface IValueCalc
    {
        Decimal getIndexValue(DateTime inTimeStamp, List<Stock> STOX);
    }

    public class AverageIndexType : IValueCalc
    {
        public Decimal getIndexValue(DateTime inTimeStamp, List<Stock> STOX)
        {
            long num = 0;
            Decimal value = new Decimal(0.0);

            foreach(Stock s in STOX)
            {
                value+= s.getPrice(inTimeStamp);
                num += 1;
            }
            if (num == 0)
            {
                return new decimal(0.0);
            }
            return Math.Round(value/num, 3);
        }
    }

    public class WeightedIndexType : IValueCalc
    {
        public Decimal getIndexValue(DateTime inTimeStamp, List<Stock> STOX)
        {
            Decimal totVal = new decimal(0.0);
            foreach (Stock s in STOX)
            {
                totVal += s.getPrice(inTimeStamp)*s.getCount();
            }
            Decimal val = new decimal(0.0);
            if (totVal == 0)
            {
                return new decimal(0.0);
            }
            foreach (Stock s in STOX)
            {
                val += s.getPrice(inTimeStamp)*s.getCount()*s.getPrice(inTimeStamp)/totVal;
            }
            return Math.Round(val,3);
        }
    }

    public class TimeValue : IComparable
    {
        private readonly Decimal value;
        private readonly DateTime time;

        public TimeValue(Decimal value, DateTime time)
        {
            this.value = value;
            this.time = time;
        }

        public Decimal getValue()
        {
            return this.value;
        }

        public DateTime getTime()
        {
            return this.time;
        }

        public Boolean isAfter(DateTime time)
        {
            TimeSpan diff = time.Subtract(this.time);
            if (diff.TotalMilliseconds > 0)
            {
                return true;
            }
            return false;
        }

        public int CompareTo(object obj)
        {
            if (obj == null) return 1;
            TimeValue other = obj as TimeValue;
            TimeSpan diff = other.time.Subtract(this.time);

            if (diff.TotalMilliseconds > 0)
            {
                return -1;
            }
            else if (diff.TotalMilliseconds == 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }

     public class StockExchange : IStockExchange
     {


         private List<Portfolio> portfolios;

         private List<Index> indices;

         private List<Stock> STOX;

         public StockExchange()
         {
             portfolios = new List<Portfolio>();
             indices = new List<Index>();
             STOX = new List<Stock>();
         }
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {

             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             if (STOX.Contains(stock))
             {
                 throw new StockExchangeException("Stock exchange already contains the stock which is trying to be added.");
             }
             else
             {
                 STOX.Add(stock);
             }

         }

         public void DelistStock(string inStockName)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.isStockContained(inStockName))
                 {
                     pf.removeStock(inStockName);
                 }
             }
             foreach (Index i in indices)
             {
                 if (i.isStockContained(inStockName))
                 {
                     i.removeStock(inStockName);
                 }
             }
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     STOX.Remove(s);
                     return;
                 }
             }
             throw new StockExchangeException("Stock does not exist in stock exchange.");
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return STOX.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     s.addValue(inIimeStamp, inStockValue);
                     return;
                 }
             }
             throw new StockExchangeException("Nonexistent stock ID");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     return s.getPrice(inTimeStamp);
                 }
             }
             throw new StockExchangeException("Nonexistent stock ID");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     return s.getInitialPrice();
                 }
             }
             throw new StockExchangeException("Nonexistent stock ID");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     return s.getLastPrice();
                 }
             }
             throw new StockExchangeException("Nonexistent stock ID");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index i = new Index(inIndexName, inIndexType);

             if (indices.Contains(i))
             {
                 throw new StockExchangeException("Index allready exists");
             }
             indices.Add(i);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = null;
             foreach(Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                     stock = s;
                     break;
                 }
             }
             if (stock == null)
             {
                 throw new StockExchangeException("Nonexistent stock ID");
             }

             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName))
                 {
                     i.addStock(stock);
                     return;
                 }
             }
             throw new StockExchangeException("Nonexistent index ID");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName)){
                     if (i.isStockContained(inStockName))
                     {
                         i.removeStock(inStockName);
                         return;
                     }
                     else
                     {
                         throw new StockExchangeException("Stock does not exist in given index");
                     }
                 }
             }
             throw new StockExchangeException("Nonexistent index ID");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName))
                 {
                     return (i.isStockContained(inStockName));
                 }
             }

             throw new StockExchangeException("Nonexistent index ID");
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName))
                 {
                     return i.getValue(inTimeStamp);
                 }
             }
             throw new StockExchangeException("Nonexistent Index ID");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName))
                 {
                     return true;
                 }
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index i in indices)
             {
                 if (i.iS(inIndexName))
                 {
                     return i.getCount();
                 }
             }
             throw new StockExchangeException("Nonexistent index ID");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio pf = new Portfolio(inPortfolioID);

             if (portfolios.Contains(pf))
             {
                 throw new StockExchangeException("Portfolio already exists");
             }
             portfolios.Add(pf);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             foreach (Stock s in STOX)
             {
                 if (s.iS(inStockName))
                 {
                 
                 int stockSum = numberOfShares;
                 foreach (Portfolio pf in portfolios)
                 {
                     if (IsStockPartOfPortfolio(pf.getID(), s.getID()))
                         stockSum += NumberOfSharesOfStockInPortfolio(pf.getID(), s.getID());
                 }
                 if (stockSum > s.getCount())
                 {
                     throw new StockExchangeException("Too many of the same stock added to a portfolio.");
                 }
                     break;
                 }
            }

             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     pf.addStocks(inStockName, numberOfShares);
                     return;
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     pf.removeStocks(inStockName, numberOfShares);
                     return;
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     pf.removeStock(inStockName);
                     return;
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     return pf.numOfStocks();
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     if (pf.isStockContained(inStockName))
                     {
                         return true;
                     }
                     else
                     {
                         return false;
                     }
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     if (pf.isStockContained(inStockName))
                     {
                         return pf.numOfShares(inStockName);
                     }
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     Dictionary<string, int> pfmap = pf.getPortfolioMap();
                     Decimal sum = new decimal(0.0);
                     foreach (string str in pfmap.Keys)
                     {
                         foreach (Stock s in STOX)
                         {
                             if (s.iS(str))
                             {
                                 sum += pfmap[str] * s.getPrice(timeStamp);
                                 break;
                             }
                         }
                     }
                     return Math.Round(sum,3);
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             foreach (Portfolio pf in portfolios)
             {
                 if (pf.iS(inPortfolioID))
                 {
                     Dictionary<string, int> pfmap = pf.getPortfolioMap();

                     Decimal percentage = new decimal(0.0);

                     Decimal begin = new decimal(0.0);
                     Decimal end = new decimal(0.0);

                     DateTime bDate = new DateTime(Year, Month, 1);
                     DateTime eDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month),23,59,59,999);
                     foreach (string str in pfmap.Keys)
                     {
                         foreach (Stock s in STOX)
                         {
                             if (s.iS(str))
                             {
                                 begin += pfmap[str]*s.getPrice(bDate);
                                 end += pfmap[str]*s.getPrice(eDate);
                                 break;
                             }
                         }
                     }
                     if (begin == 0)
                     {
                         return new decimal(0.0);
                     }
                     percentage = (end - begin)*100/begin;
                     return Math.Round(percentage,3);
                 }
             }
             throw new StockExchangeException("Nonexistent portfolio ID");
         }
     }
}
