﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private string kalkulatorDisplay; // stores current calculator display

        private string memory; // stores memory of a calculator (for MS, MR keys)

        private double firstOperand; // temporary storage for the first operand
        private double secondOperand; // temporary storage for the second operand

        private char selectedOperator; // stores last selected operator
        private char lastPressedKey; // keeps track of last pressed key

        private bool binaryEnabled; // flag for enabling calculating result from multiple binary operator presses
                                    // for example: 3 + 4 + 7 +   display: 14

        private const int MAXIMUM_DIGITS = 10; // stores maximum number of digits on display
        private const double MAXIMAL_NUMBER = 9999999999;
        private const double MINIMAL_NUMBER = -9999999999; 
        private const double SMALLEST_POSSIBLE = 0.0000000005; // smallest possible recognizable number

        /// Constructor of class Kalkulator, sets its display to "0"
        public Kalkulator()
        {
            ResetCalculator();
        }

        // sets display to "0"
        private void SetDisplayToZero()
        {
            kalkulatorDisplay = "0";
        }

        // sets display to "-E-" (error)
        private void SetDisplayToError()
        {
            kalkulatorDisplay = "-E-";
        }

        // total reset of calculator
        private void ResetCalculator()
        {
            SetDisplayToZero();
            firstOperand = 0;
            secondOperand = 0;
            selectedOperator = '+';
            lastPressedKey = 'R';
            binaryEnabled = false;
            memory = "";
        }

        // rounds result
        private double RoundResult(double result)
        {
            string resultString = result.ToString();

            if (Math.Abs(result) < SMALLEST_POSSIBLE)
                return 0;
            
            // rounding depending on given result
            if (resultString.Length > MAXIMUM_DIGITS)
            {
                if (result < 0)
                {
                    int indexOfDecimalPlace = resultString.IndexOf(",");
                    return Math.Round(result, MAXIMUM_DIGITS - indexOfDecimalPlace + 1, MidpointRounding.AwayFromZero);
                }
                else 
                {
                    int indexOfDecimalPlace = resultString.IndexOf(",");
                    return Math.Round(result, MAXIMUM_DIGITS - indexOfDecimalPlace, MidpointRounding.AwayFromZero);
                }
            }
            // no need for rounding result
            else
                return result;
        }

        // removes trailing zeroes after pressing operator
        //private void 

        // keeps track of current selected operator and stores current number
        private void SetOperator(char op)
        {
            // if two operators were pressed without hitting equals button, calculate 
            //if (selectedOperator != 'E')
             //   Calculate();

            if (binaryEnabled && KeyType(lastPressedKey) != "binary operator")
                Calculate();

            selectedOperator = op;

            // dunno
            if (kalkulatorDisplay == "2,0")
            {
                kalkulatorDisplay = "2";
                return;
            }
           
            firstOperand = double.Parse(kalkulatorDisplay);
            binaryEnabled = true;
        }

        // consumes char key and produces its type
        private string KeyType(char key)
        {
            switch (key)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    return "digit";
                // binary operators
                case '+':
                case '-':
                case '*':
                case '/':
                    return "binary operator";
                // unary operators
                case 'S':
                case 'K':
                case 'T':
                case 'Q':
                case 'R':
                case 'I':
                    return "unary operator";
                case '=':
                    return "equals";
                case 'C':
                    return "clear";
                case 'O':
                    return "reset";
            }

            // cannot determine type
            return "undefined";
        }

        // produces length of current display while ignoring comma (,) and minus (-)
        private int DisplayLength()
        {
            return kalkulatorDisplay.Replace(",", "").Replace("-", "").Length;
        }

        // adds decimal mark to display
        private void AddDecimalMark()
        {
            // after pressing any operator, display will be "0,"
            if (KeyType(lastPressedKey) == "unary operator" || KeyType(lastPressedKey) == "binary operator")
                kalkulatorDisplay = "0,";
            // if already contains "," nothing happens
            else if (!kalkulatorDisplay.Contains(","))
                kalkulatorDisplay += ",";
        }

        // Adds digit to display or displays new number if operator was pressed
        private void PressDigit(char digit)
        {

            // operator was pressed before this number, display new digit
            if (KeyType(lastPressedKey) == "binary operator" || KeyType(lastPressedKey) == "unary operator" || KeyType(lastPressedKey) == "equals")
                kalkulatorDisplay = digit.ToString();
            // exceeded maximum length of calculator display
            else if (DisplayLength() >= MAXIMUM_DIGITS)
                return;
            // concatenates digit to number if display isn't "0"
            else if (kalkulatorDisplay != "0")
                kalkulatorDisplay += digit.ToString();
            // if display is "0", new display becomes consumed digit
            else
                kalkulatorDisplay = digit.ToString();
        }

        // consumes result of an operation and displays it on the screen
        private void ResultToDisplay(double result)
        {
            // result is outside legit interval
            if (result > MAXIMAL_NUMBER || result < MINIMAL_NUMBER)
            {
                SetDisplayToError();
                return;
            }
            else
            {
                result = RoundResult(result);
                kalkulatorDisplay = result.ToString();
            }
        }

        // adds first and second operand, and sets display
        private void Add()
        {
            double result = firstOperand + secondOperand;
            ResultToDisplay(result);
        }

        // adds first and second operand, and sets display
        private void Sub()
        {
            double result = firstOperand - secondOperand;
            ResultToDisplay(result);
        }

        // calculates product of the first and second operand, and sets display
        private void Mul()
        {
            double result = firstOperand * secondOperand;
            ResultToDisplay(result);
        }

        // produces division of the first and second operand, and sets display
        private void Div()
        {
            if (secondOperand == 0)
                SetDisplayToError();
            else
            {
                double result = (double)firstOperand / secondOperand;
                ResultToDisplay(result);
            }
        }

        // calculates sin(x) and sets display
        private void Sin()
        {
            double result = Math.Sin(double.Parse(kalkulatorDisplay));
            ResultToDisplay(result);
        }

        // caculates cos(x) and sets display
        private void Cos()
        {
            double result = Math.Cos(double.Parse(kalkulatorDisplay));
            ResultToDisplay(result);
        }

        // calculates tan(x) and sets display
        private void Tan()
        {
            double num = double.Parse(kalkulatorDisplay);
            if (Math.Abs(Math.Cos(num)) < SMALLEST_POSSIBLE)
            {
                SetDisplayToError();
            }
            else
            {
                double result = Math.Tan(num);
                ResultToDisplay(result);
            }
        }

        // calculates square(x) and sets display
        private void Square()
        {
            double num = double.Parse(kalkulatorDisplay);
            double result = num * num;
            ResultToDisplay(result);
        }

        // calculates square root(x) and sets display
        private void SquareRoot()
        {
            double num = double.Parse(kalkulatorDisplay);

            // cannot calculate root of a negative number
            if (num < 0)
            {
                SetDisplayToError();
            }
            else
            {
                double result = Math.Sqrt(num);
                ResultToDisplay(result);
            }
        }

        // calculates inverse of x and sets display
        private void Inverse()
        {
            if (double.Parse(kalkulatorDisplay) == 0)
                SetDisplayToError();
            else
            {
                double result = 1.0 / (double.Parse(kalkulatorDisplay));
                ResultToDisplay(result);
            }
        }

        // sets display to negative value if value is positive and vice-versa
        private void ChangeSign()
        {
            double tmp = double.Parse(kalkulatorDisplay);
            tmp *= -1;
            kalkulatorDisplay = tmp.ToString();
        }

        // MS calculator function
        private void StoreInMemory()
        {
            memory = kalkulatorDisplay;
        }

        // MR calculator function
        private void RetrieveFromMemory()
        {
            kalkulatorDisplay = memory;
        }

        // Equals (=) was pressed, calculating result and printing it on the screen
        private void Calculate()
        {
            if (KeyType(lastPressedKey) == "equals" || KeyType(lastPressedKey) == "clear") 
                firstOperand = double.Parse(kalkulatorDisplay);
            else
                secondOperand = double.Parse(kalkulatorDisplay);

            // checks last pressed operand
            switch (selectedOperator)
            {
                case '+':
                    Add();
                    break;
                case '-':
                    Sub();
                    break;
                case '*':
                    Mul();
                    break;
                case '/':
                    Div();
                    break;
                default:
                    break;
            }

            binaryEnabled = false;
        }

        // processes user input (key presses)
        public void Press(char inPressedDigit)
        {
            
            switch (inPressedDigit)
            {
                // number was pressed
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    PressDigit(inPressedDigit);
                    break;
                case '+':
                    SetOperator('+');
                    break;
                case '-':
                    SetOperator('-');
                    break;
                case '*':
                    SetOperator('*');
                    break;
                case '/':
                    SetOperator('/');
                    break;
                case '=':
                    Calculate();
                    break;
                case 'Q':
                    Square();
                    break;
                case 'R':
                    SquareRoot();
                    break;
                case 'I':
                    Inverse();
                    break;
                case 'S':
                    Sin();
                    break;
                case 'K':
                    Cos();
                    break;
                case 'T':
                    Tan();
                    break;
                case ',':
                    AddDecimalMark();
                    break;
                case 'M':
                    ChangeSign();
                    break;
                case 'P':
                    StoreInMemory();
                    break;
                case 'G':
                    RetrieveFromMemory();
                    break;
                case 'C':
                    SetDisplayToZero();
                    break;
                case 'O':
                    ResetCalculator();
                    break;
                // not a valid key
                default:
                    break;
            }

            // storing last pressed key
            lastPressedKey = inPressedDigit;

        }

        // returns display state of calculator
        public string GetCurrentDisplayState()
        {
            return kalkulatorDisplay;
            //throw new NotImplementedException();
        }
    }

}
