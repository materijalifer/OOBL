﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Stock _stock = new Stock();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Share share = new Share(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             _stock.AddShareToStock(share);
         }

         public void DelistStock(string inStockName)
         {
             _stock.RemoveShareFromStock(inStockName.ToLower());
         }

         public bool StockExists(string inStockName)
         {
             return _stock.ShareExists(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return _stock.GetNumberOfShares();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
             { 
                 Share share = _stock.GetShare(inStockName.ToLower());
                 share.AddNewPrice(inIimeStamp,inStockValue);
                 _stock.AddNewPriceToPortofolios(inStockName.ToLower(), inIimeStamp, inStockValue);
                 }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName.ToLower());
                 return share.GetPrice(inTimeStamp);
                 
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName.ToLower());
                 return share.GetInitialPrice();
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName.ToLower());
                 return share.GetLastPrice();
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index = new Index(inIndexName, inIndexType);
             _stock.AddIndexToStock(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName.ToLower());
                 if (IndexExists(inIndexName))
                 {
                     Index index = _stock.GetIndex(inIndexName.ToLower());
                     index.AddShareToIndex(share);
                 }
                 else
                     throw new StockExchangeException("Index doesn't exist!");
               
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName))
             {
                 if (IndexExists(inIndexName))
                 {
                     Index index = _stock.GetIndex(inIndexName.ToLower());
                     index.RemoveShareFromIndex(inStockName.ToLower());
                 }
                 else
                     throw new StockExchangeException("Index doesn't exist!");

             }
             else
                 throw new StockExchangeException("Share doesn't exist!");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName))
             {
                 if (IndexExists(inIndexName))
                 {
                     Index index = _stock.GetIndex(inIndexName.ToLower());
                     return index.ShareExists(inStockName.ToLower());
                 }
                 else
                     throw new StockExchangeException("Index doesn't exist!");

             }
             else
                 return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 Index index = _stock.GetIndex(inIndexName.ToLower());
                 return index.CalculateValue(inTimeStamp);
             }
             else
                 throw new StockExchangeException("Index doesn't exist!");
         }

         public bool IndexExists(string inIndexName)
         {
             return _stock.IndexExists(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
            return _stock.GetNumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 Index index = _stock.GetIndex(inIndexName.ToLower());
                 return index.GetNumberOfShares();
             }
             else
                 throw new StockExchangeException("Index doesn't exist!");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portofolio portofolio = new Portofolio(inPortfolioID);
             _stock.AddPortofolioToStock(portofolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName);
                 if (PortfolioExists(inPortfolioID))
                 {
                     Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                     portofolio.AddShareToPortofolio(share, numberOfShares);
                 }
                 else
                     throw new StockExchangeException("Portofolio doesn't exist!");
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");         
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName);
                 if (PortfolioExists(inPortfolioID))
                 {
                     Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                     portofolio.RemoveShareFromPortofolio(inStockName.ToLower(), numberOfShares);
                 }
                 else
                     throw new StockExchangeException("Portofolio doesn't exist!");
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");  
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName);
                 if (PortfolioExists(inPortfolioID))
                 {
                     Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                     portofolio.RemoveEntireShareFromPortofolio(inStockName.ToLower());
                 }
                 else
                     throw new StockExchangeException("Portofolio doesn't exist!");
             }
             else
                 throw new StockExchangeException("Share doesn't exist!");    
         }

         public int NumberOfPortfolios()
         {
             return _stock.GetNumberOfPortofolios();

         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                 return portofolio.GetNumberOfShares();
             }
             else
                 throw new StockExchangeException("Portofolio doesn't exist!");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _stock.PortofolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (StockExists(inStockName))
             {
                 Share share = _stock.GetShare(inStockName);
                 if (PortfolioExists(inPortfolioID))
                 {
                     Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                     return portofolio.ShareExists(inStockName.ToLower());
                 }
                 else
                     throw new StockExchangeException("Portofolio doesn't exist!");
             }
             else
                 return false;   
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                     return portofolio.GetNumberOfSharesOfShare(inStockName.ToLower());
                 }
                 else
                     return 0;
             }
             else
                 throw new StockExchangeException("Portofolio doesn't exist!");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                 return portofolio.CalculateValue(timeStamp);
             }
             else
                 throw new StockExchangeException("Portofolio doesn't exist!");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 Portofolio portofolio = _stock.GetPortofolio(inPortfolioID);
                 return portofolio.PortfolioPercentChangeInValueForMonth(Year, Month);
             }
             else
                 throw new StockExchangeException("Portofolio doesn't exist!");
         }
                 
     }

     ///<summary>
     ///Stock = burza
     ///</summary>
      
     public class Stock
    {
        private Dictionary<string, Share> _shareDictionary = new Dictionary<string, Share>();
        private Dictionary<string, Index> _indicesDictionary = new Dictionary<string, Index>();
        private Dictionary<string, Portofolio> _portofoliosDictionary = new Dictionary<string, Portofolio>();

        public void AddShareToStock(Share share)
        {
            if (_shareDictionary.ContainsKey(share.name))
                throw new StockExchangeException("Stock already contains this share!");
            else
                _shareDictionary.Add(share.name, share);
        }

        public void RemoveShareFromStock(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName))
            {
                _shareDictionary.Remove(shareName);

                if (_indicesDictionary.Count > 0)
                {
                    foreach (var tempIndex in _indicesDictionary)
                    {
                        if(tempIndex.Value.shareDictionary.ContainsKey(shareName))
                            tempIndex.Value.RemoveShareFromIndex(shareName);
                    }
                }
                if (_portofoliosDictionary.Count > 0)
                {
                    foreach (var tempPortofolio in _portofoliosDictionary)
                    {
                        if(tempPortofolio.Value.shareDictionary.ContainsKey(shareName))
                            tempPortofolio.Value.RemoveEntireShareFromPortofolio(shareName);
                    }
                }
            }
            else
                throw new StockExchangeException("This share doesn't exist in stock!");
        }

        public bool ShareExists(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName))
                return true;
            else
                return false;
        }

        public int GetNumberOfShares()
        {
            return _shareDictionary.Count;
        }

        public Share GetShare(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName.ToLower()))
                return _shareDictionary[shareName.ToLower()];
            else
                return null;
        }

        public void AddIndexToStock(Index index)
        {
            if (_indicesDictionary.ContainsKey(index.name))
                throw new StockExchangeException("Stock already contains this index!");
            else
                _indicesDictionary.Add(index.name, index);
            
        }

        public Index GetIndex(string indexName)
        {
            if (_indicesDictionary.ContainsKey(indexName))
                return _indicesDictionary[indexName];
            else
                return null;
        }

        public int GetNumberOfIndices()
        {
            return _indicesDictionary.Count;
        }

        public bool IndexExists(string indexName)
        {
            if (_indicesDictionary.ContainsKey(indexName))
                return true;
            else
                return false;
        }

        public void AddPortofolioToStock(Portofolio portofolio)
        {
            if (_portofoliosDictionary.ContainsKey(portofolio.id))
                throw new StockExchangeException("Stock already contains portofolio with this id!");
            else
                _portofoliosDictionary.Add(portofolio.id, portofolio);
            
        }

        public bool PortofolioExists(string portofolioID)
        {
            if (_portofoliosDictionary.ContainsKey(portofolioID))
                return true;
            else
                return false;
        }

        public Portofolio GetPortofolio(string portofolioID)
        {
            if (_portofoliosDictionary.ContainsKey(portofolioID))
                return _portofoliosDictionary[portofolioID];
            else
                return null;
        }

        public int GetNumberOfPortofolios()
        {
            return _portofoliosDictionary.Count;
        }

        public void AddNewPriceToPortofolios(string shareName, DateTime timeStamp, decimal price)
        {
           
            foreach (var tempPortofolio in _portofoliosDictionary)
            {
                if (tempPortofolio.Value.shareDictionary.ContainsKey(shareName))
                    tempPortofolio.Value.shareDictionary[shareName].AddNewPrice(timeStamp, price);
            }

        }
         
    }


     ///<summary>
     ///Share = dionica
     ///</summary>

    public class Share
    {
        private string _name;
        private long _numberOfShares;
        private Decimal _initialPrice;
        private DateTime _inTimeStamp;
        private Decimal _newPrice;
        private SortedDictionary<DateTime, decimal> _priceDictionary = new SortedDictionary<DateTime,decimal>();

        public Share(string name, long numberOfShares, Decimal initialPrice, DateTime inTimeStamp)
        {
            if (initialPrice <= 0)
                throw new StockExchangeException("Initial share price is negative or zero!");
            if(numberOfShares <= 0)
                throw new StockExchangeException("Initial number of shares is negative or zero!");
            _name = name.ToLower();
            _numberOfShares = numberOfShares;
            _initialPrice = initialPrice;
            _inTimeStamp = inTimeStamp;
            _newPrice = initialPrice;
            _priceDictionary.Add(inTimeStamp, initialPrice);
        }

        public string name
        {
            set { this._name = value; }
            get { return this._name; }
        }

        public Decimal initialPrice
        {
            set { this._initialPrice = value; }
            get { return this._initialPrice; }
        }

        public DateTime inTimeStamp
        {
            set { this._inTimeStamp = value; }
            get { return this._inTimeStamp; }
        }

        public long numberOfShares
        {
            set { this._numberOfShares = value; }
            get { return this._numberOfShares; }
        }

        public SortedDictionary<DateTime, decimal> prices
        {
            set { this._priceDictionary = value; }
            get { return this._priceDictionary; }
        }

        public decimal GetInitialPrice()
        {
            return _priceDictionary.Values.First();
        }

        public void AddNewPrice(DateTime time, Decimal price)
        {
            if (_priceDictionary.ContainsKey(time))
                throw new StockExchangeException("Price for this date time already exists!");
            else
                _priceDictionary.Add(time, price);
        }

        public DateTime GetLastPriceTime()
        {
            return _priceDictionary.Keys.Last();
        }

        public Decimal GetLastPrice()
        {
            return _priceDictionary.Values.Last();
        }

        public Decimal GetPrice(DateTime time)
        {
            int compare;
            DateTime priceTime = new DateTime();
            compare = DateTime.Compare(time, _priceDictionary.Keys.First());
            if (compare < 0)
            {
                throw new StockExchangeException("Date time not valid!");
            }
            else
            {
                foreach (var tempTime in _priceDictionary)
                {
                    compare = DateTime.Compare(tempTime.Key, time);
                    if (compare <= 0)
                    {
                        priceTime = tempTime.Key;
                       
                    }
                    else
                        break;
                }
                return _priceDictionary[priceTime];
            }
        }

    }


    ///<summary>
    ///Index
    ///</summary>
    
    public class Index
    {
        private string _name;
        private IndexTypes _indexType;
        private Dictionary<string, Share> _shareDictionary = new Dictionary<string, Share>();

        public Index(string name, IndexTypes indexType)
        {
            _name = name.ToLower();
            _indexType = indexType;
        }

        public string name
        {
            set { this._name = value; }
            get { return this._name; }
        }

        public Dictionary<string, Share> shareDictionary
        {
            get { return this._shareDictionary; }
        }
        
        public void AddShareToIndex(Share share)
        {
            if (_shareDictionary.ContainsKey(share.name))
                throw new StockExchangeException("Index already contains this share!");
            else
                _shareDictionary.Add(share.name, share);
        }

        public void RemoveShareFromIndex(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName))
                _shareDictionary.Remove(shareName);
            else
                throw new StockExchangeException("This share doesn't exist in index!");
        }

        public bool ShareExists(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName))
                return true;
            else
                return false;
        }

        public int GetNumberOfShares()
        {
            return _shareDictionary.Count;
        }

        public decimal CalculateValue(DateTime time)
        {
            if (_indexType == IndexTypes.AVERAGE)
            {
                return AverageValue(time);
            }
            else if (_indexType == IndexTypes.WEIGHTED)
            {
                return WeightValue(time);
            }
            else
                throw new StockExchangeException("Invalid index type!");

        }

        public decimal AverageValue(DateTime time)
        {
            return Math.Round((ValueOfShares(time) / TotalNumberOfShares()), 3);
        }

        public decimal WeightValue(DateTime time)
        {
            decimal value = 0;
            foreach (var tempShare in _shareDictionary)
            {
                decimal factor = (tempShare.Value.GetPrice(time) * tempShare.Value.numberOfShares) / ValueOfShares(time);
                value += factor * tempShare.Value.GetPrice(time);
            }
            return Math.Round(value, 3);
        }

        public decimal ValueOfShares(DateTime time)
        {
            decimal value = 0;
            foreach (var tempShare in _shareDictionary)
                value += (tempShare.Value.GetPrice(time) * tempShare.Value.numberOfShares);
            return value;
        }

        public decimal TotalNumberOfShares()
        {
            decimal number = 0;
            foreach (var tempShare in _shareDictionary)
                number += tempShare.Value.numberOfShares;
            return number;
        }
    }


    ///<summary>
    ///Portofolio
    ///</summary>
    public class Portofolio
    {
        private string _portofolioID;
        private Dictionary<string, Share> _shareDictionary = new Dictionary<string, Share>();

        public Portofolio(string portofolioID)
        {
            _portofolioID = portofolioID;
        }

        public string id
        {
            set { this._portofolioID = value; }
            get { return this._portofolioID; }
        }

        public Dictionary<string, Share> shareDictionary
        {
            get { return this._shareDictionary; }
        }

        public void AddShareToPortofolio(Share share, long numberOfShares)
        {
            if (_shareDictionary.ContainsKey(share.name.ToLower()))
            {
                Share tempShare = _shareDictionary[share.name.ToLower()];
                long tempNumberOfShares;
                if (numberOfShares <= share.numberOfShares)
                {
                    tempShare.numberOfShares += numberOfShares;
                    share.numberOfShares -= numberOfShares;
                }
                else
                {
                    tempNumberOfShares = share.numberOfShares;
                    tempShare.numberOfShares += tempNumberOfShares;
                    share.numberOfShares -= tempNumberOfShares;
                }
            }
            else
            {
                if (numberOfShares <= share.numberOfShares)
                {
                    Share tempShare = new Share(share.name, numberOfShares, share.initialPrice, share.inTimeStamp);
                    foreach (var tempPrice in share.prices)
                    {
                        if (tempShare.prices.Keys.Contains(tempPrice.Key))
                            continue;
                        tempShare.AddNewPrice(tempPrice.Key, tempPrice.Value);
                    }
                    _shareDictionary.Add(share.name, tempShare);
                    share.numberOfShares -= numberOfShares;
                }
                else
                {
                    numberOfShares = share.numberOfShares;
                    Share tempShare = new Share(share.name, numberOfShares, share.initialPrice, share.inTimeStamp);
                    foreach (var tempPrice in share.prices)
                    {
                        if (tempShare.prices.Keys.Contains(tempPrice.Key))
                            continue;
                        tempShare.AddNewPrice(tempPrice.Key, tempPrice.Value);
                    }
                    _shareDictionary.Add(share.name, tempShare);
                    share.numberOfShares -= numberOfShares;
                }
            }
                
        }

        public bool ShareExists(string shareName)
        {
            if (_shareDictionary.ContainsKey(shareName))
                return true;
            else
                return false;
        }

        public int GetNumberOfShares()
        {
            return _shareDictionary.Count;
        }

        public int GetNumberOfSharesOfShare(string shareName)
        {
            Share share = _shareDictionary[shareName];
            return (int)share.numberOfShares;
        }

        public void RemoveEntireShareFromPortofolio(string shareName)
        {
            if (ShareExists(shareName))
            {
                _shareDictionary.Remove(shareName);
            }
            else
                throw new StockExchangeException("Share doesn't exist in portofolio!");
        }

        public void RemoveShareFromPortofolio(string shareName, int numberOfShares)
        {
            if (ShareExists(shareName))
            {
                Share tempShare = _shareDictionary[shareName];
                int newNumberOfShares = (int)tempShare.numberOfShares - numberOfShares;
                if (newNumberOfShares == 0)
                    RemoveEntireShareFromPortofolio(shareName);
                else if (newNumberOfShares > 0)
                    tempShare.numberOfShares = newNumberOfShares;
                else
                    throw new StockExchangeException("Number of shares is under zero!");
                
            }
            else
                throw new StockExchangeException("Share doesn't exist in portofolio!");
        }

        public decimal CalculateValue(DateTime time)
        {
            return Math.Round(ValueOfShares(time), 3);
        }

        private decimal ValueOfShares(DateTime time)
        {
            decimal value = 0;
            foreach (var tempShare in _shareDictionary)
                value += (tempShare.Value.GetPrice(time) * tempShare.Value.numberOfShares);
            return value;
        } 
 
        public decimal PortfolioPercentChangeInValueForMonth(int year, int month) 
        {
            decimal value = 0;
            decimal startMonthValue = 0;
            decimal endMonthValue = 1;
            if ((month > 12) || (month <= 0))
                throw new StockExchangeException("Invalid month!");
            else
            {
                DateTime firstDate = new DateTime(year, month, 1, 0, 0, 0);
                DateTime secondDate;
                if (month == 2)
                    secondDate = new DateTime(year, month, 28, 23, 59, 59);
                else if(monthHasThitryOneDays(month))
                    secondDate = new DateTime(year, month, 31, 23, 59, 59);
                else
                    secondDate = new DateTime(year, month, 30, 23, 59, 59);

                foreach (var tempShare in _shareDictionary)
                {
                    startMonthValue = tempShare.Value.GetPrice(firstDate);
                    endMonthValue = tempShare.Value.GetPrice(secondDate);
                }

                value = ((endMonthValue / startMonthValue) - 1) * 100;

                return value;
            }
        }

        private bool monthHasThitryOneDays(int month) 
        {
            if ((month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12))
                return true;
            else
                return false;
        }

    }
}
