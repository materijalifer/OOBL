﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Calculator : ICalculator
    {
        private string currentScreen = "0";
        private string previousScreen = "0";
        private string memory = "";
        private char previousOperator = ' ';
        private char lastPressed = ' ';

        private string savedRightOperand = "0";
        private char savedOperator = ' ';

        public string GetCurrentDisplayState()
        {
            return this.currentScreen;
        }

        public void Press( char inPressedDigit )
        {
            if ( this.isNumber( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    bool newNumber = this.screenEmpty() ||
                        this.isBinaryOperator( this.lastPressed ) ||
                        this.isUnaryOperator( this.lastPressed ) ||
                        this.isEqualSign( this.lastPressed ) ||
                        this.isGetMemory( this.lastPressed );
                    if ( newNumber )
                    {
                        this.currentScreen = inPressedDigit.ToString( CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                    }
                    else
                    {
                        if ( this.screenSizeOK() )
                        {
                            this.currentScreen += inPressedDigit;
                        }
                    }
                }
            }
            else if ( this.isBinaryOperator( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    if ( this.isBinaryOperator( this.lastPressed ) )
                    {
                        this.previousOperator = inPressedDigit;
                    }
                    else
                    {
                        this.savedRightOperand = this.currentScreen;
                        this.savedOperator = inPressedDigit;

                        decimal rigntOperand = decimal.Parse( this.currentScreen, CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                        decimal leftOperand = decimal.Parse( this.previousScreen, CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                        char operatorr = this.previousOperator;

                        try
                        {
                            decimal result;
                            if ( operatorr != ' ' )
                            {
                                result = this.calculate( operatorr, leftOperand, rigntOperand );
                            }
                            else
                            {
                                result = rigntOperand;
                            }
                            string resultDisplay = this.format( result );

                            this.previousScreen = resultDisplay;
                            this.currentScreen = resultDisplay;
                            this.previousOperator = inPressedDigit;
                        }
                        catch ( Exception )
                        {
                            this.previousScreen = "0";
                            this.currentScreen = "-E-";
                            this.previousOperator = ' ';
                            this.lastPressed = ' ';
                            this.savedRightOperand = "0";
                            this.savedOperator = ' ';
                        }
                    }
                }
            }
            else if ( this.isEqualSign( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    if ( this.isEqualSign( this.lastPressed ) )
                    {
                        this.previousScreen = this.currentScreen;
                        this.currentScreen = this.savedRightOperand;
                        this.previousOperator = this.savedOperator;
                    }
                    else
                    {
                        this.savedRightOperand = this.currentScreen;
                    }

                    decimal rigntOperand = decimal.Parse( this.currentScreen, CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                    decimal leftOperand = decimal.Parse( this.previousScreen, CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                    char operatorr = this.previousOperator;

                    try
                    {
                        decimal result;
                        if ( operatorr != ' ' )
                        {
                            result = this.calculate( operatorr, leftOperand, rigntOperand );

                        }
                        else
                        {
                            result = rigntOperand;
                        }
                        string resultDisplay = this.format( result );

                        this.previousScreen = "0";
                        this.previousOperator = ' ';
                        this.currentScreen = resultDisplay;
                    }
                    catch ( Exception )
                    {
                        this.previousScreen = "0";
                        this.currentScreen = "-E-";
                        this.previousOperator = ' ';
                        this.lastPressed = ' ';
                        this.savedRightOperand = "0";
                        this.savedOperator = ' ';
                    }
                }
            }
            else if ( this.isDecimalPoint( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    bool newNumber = this.isBinaryOperator( this.lastPressed ) ||
                        this.isEqualSign( this.lastPressed ) ||
                        this.isUnaryOperator( this.lastPressed ) ||
                        this.isGetMemory( this.lastPressed );
                    if ( newNumber )
                    {
                        this.currentScreen = "0,";
                    }
                    else
                    {
                        if ( this.screenSizeOK() && !this.hasDecimalPoint() )
                        {
                            this.currentScreen += inPressedDigit;
                        }
                    }
                }
            }
            else if ( this.isChangeSign( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    if ( !this.screenEmpty() )
                    {
                        this.changeSign();
                    }
                }
            }
            else if ( this.isUnaryOperator( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    decimal operand = decimal.Parse( this.currentScreen, CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
                    char operatorr = inPressedDigit;

                    try
                    {
                        decimal result = this.calculate( operatorr, operand );
                        string resultDisplay = this.format( result );

                        this.currentScreen = resultDisplay;
                    }
                    catch ( Exception )
                    {
                        this.previousScreen = "0";
                        this.currentScreen = "-E-";
                        this.previousOperator = ' ';
                        this.lastPressed = ' ';
                        this.savedRightOperand = "0";
                        this.savedOperator = ' ';
                    }
                }
            }
            else if ( this.isSetMemory( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    this.memory = this.currentScreen;
                }
            }
            else if ( this.isGetMemory( inPressedDigit ) )
            {
                if ( !this.screenError() )
                {
                    if ( !this.memoryEmpty() )
                    {
                        this.currentScreen = this.memory;
                    }
                }
            }
            else if ( this.isClearScreen( inPressedDigit ) )
            {
                this.currentScreen = "0";
            }
            else if ( this.isReset( inPressedDigit ) )
            {
                this.previousScreen = "0";
                this.currentScreen = "0";
                this.memory = "";
                this.previousOperator = ' ';
                this.lastPressed = ' ';
                this.savedRightOperand = "0";
                this.savedOperator = ' ';
            }
            else { } // Do nothing!

            this.lastPressed = inPressedDigit;
        }

        private decimal calculate( char operatorr, decimal leftOperand, decimal rigntOperand )
        {
            if ( this.isAddition( operatorr ) )
            {
                return leftOperand + rigntOperand;
            }
            else if ( this.isSubtraction( operatorr ) )
            {
                return leftOperand - rigntOperand;
            }
            else if ( this.isMultiplication( operatorr ) )
            {
                return leftOperand * rigntOperand;
            }
            else if ( this.isDivision( operatorr ) )
            {
                if ( rigntOperand == 0m )
                {
                    throw new ApplicationException( "Dijeljenje s nulom" );
                }
                return leftOperand / rigntOperand;
            }
            else
            {
                throw new ApplicationException( "Nepostojeća operacija" );
            }
        }

        private decimal calculate( char operatorr, decimal operand )
        {
            if ( this.isSine( operatorr ) )
            {
                return (decimal)Math.Sin( (double)operand );
            }
            else if ( this.isCosine( operatorr ) )
            {
                return (decimal)Math.Cos( (double)operand );
            }
            else if ( this.isTangent( operatorr ) )
            {
                double result = Math.Tan( (double)operand );
                if ( double.IsNaN( result ) )
                {
                    throw new ApplicationException( "Tangens od (k * Pi/2)" );
                }
                return (decimal)result;
            }
            else if ( this.isQuadrate( operatorr ) )
            {
                return operand * operand;
            }
            else if ( this.isRoot( operatorr ) )
            {
                if ( operand < 0m )
                {
                    throw new ApplicationException( "Korijen iz negativnog broja" );
                }
                return (decimal)Math.Sqrt( (double)operand );
            }
            else if ( this.isInverse( operatorr ) )
            {
                if ( operand == 0m )
                {
                    throw new ApplicationException( "Dijeljenje s nulom" );
                }
                return 1 / operand;
            }
            else
            {
                throw new ApplicationException( "Nedefinirana operacija" );
            }
        }

        private string format( decimal number )
        {
            int maxNumberOfDigits = 10;
            int leftSideNumberCount = ( (long)Math.Truncate( number ) ).ToString( CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat ).Count();

            int roundTo = ( maxNumberOfDigits - leftSideNumberCount >= 0 ) ? ( maxNumberOfDigits - leftSideNumberCount ) : 0;

            decimal result = Math.Round( number, roundTo );

            int leftSideResultCount = ( (long)Math.Truncate( result ) ).ToString( CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat ).Count();
            if ( leftSideResultCount > 10 )
            {
                throw new ApplicationException( "Broj se ne može prikazati na ekranu" );
            }

            if ( result - Math.Truncate( result ) == 0m )
            {
                return ( (long)Math.Truncate( result ) ).ToString( CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat );
            }
            else
            {
                return result.ToString( CultureInfo.GetCultureInfo( "hr-HR" ).NumberFormat ).TrimEnd( '0' );
            }
        }

        private void changeSign()
        {
            if ( this.currentScreen[0] == '-' )
            {
                this.currentScreen = this.currentScreen.Substring( 1 );
            }
            else
            {
                this.currentScreen = '-' + this.currentScreen;
            }
        }

        private bool screenEmpty()
        {
            return this.currentScreen == "0";
        }

        private bool screenSizeOK()
        {
            return this.currentScreen.Count( c => char.IsNumber( c ) ) < 10;
        }

        private bool memoryEmpty()
        {
            return this.memory == "";
        }

        private bool screenError()
        {
            return this.currentScreen == "-E-";
        }

        private bool hasDecimalPoint()
        {
            return this.currentScreen.Contains( ',' );
        }

        #region Checking operator
        private bool isDivision( char sign )
        {
            return sign == '/';
        }

        private bool isMultiplication( char sign )
        {
            return sign == '*';
        }

        private bool isSubtraction( char sign )
        {
            return sign == '-';
        }

        private bool isAddition( char sign )
        {
            return sign == '+';
        }

        private bool isInverse( char sign )
        {
            return sign == 'I';
        }

        private bool isRoot( char sign )
        {
            return sign == 'R';
        }

        private bool isQuadrate( char sign )
        {
            return sign == 'Q';
        }

        private bool isTangent( char sign )
        {
            return sign == 'T';
        }

        private bool isCosine( char sign )
        {
            return sign == 'K';
        }

        private bool isSine( char sign )
        {
            return sign == 'S';
        }
        #endregion

        #region Checking pressed key
        private bool isReset( char pressed )
        {
            return pressed == 'O';
        }

        private bool isClearScreen( char pressed )
        {
            return pressed == 'C';
        }

        private bool isGetMemory( char pressed )
        {
            return pressed == 'G';
        }

        private bool isSetMemory( char pressed )
        {
            return pressed == 'P';
        }

        private bool isUnaryOperator( char pressed )
        {
            return pressed == 'I' ||
                pressed == 'R' ||
                pressed == 'Q' ||
                pressed == 'T' ||
                pressed == 'K' ||
                pressed == 'S';
        }

        private bool isChangeSign( char pressed )
        {
            return pressed == 'M';
        }

        private bool isDecimalPoint( char pressed )
        {
            return pressed == ',';
        }

        private bool isEqualSign( char pressed )
        {
            return pressed == '=';
        }

        private bool isBinaryOperator( char pressed )
        {
            return pressed == '+' ||
                pressed == '-' ||
                pressed == '*' ||
                pressed == '/';
        }

        private bool isNumber( char pressed )
        {
            return char.IsNumber( pressed );
        }
        #endregion
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }
}
