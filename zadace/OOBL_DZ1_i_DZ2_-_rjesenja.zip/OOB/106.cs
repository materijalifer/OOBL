﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string _stockName;
        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockName = inStockName;
            NumberOfShares = inNumberOfShares;
            StockPrice.Add(inTimeStamp, inInitialPrice);
        }

        public Dictionary<DateTime, decimal> StockPrice = new Dictionary<DateTime, decimal>();
        public string StockName
        {
            get { return _stockName; }
            set { _stockName = value.ToLower(); }
        }
        public long NumberOfShares { get; set; }
    }

    public class Index
    {
        private string _indexName;
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            IndexName = inIndexName;
            IndexType = inIndexType;
        }

        public string IndexName
        {
            get { return _indexName; }
            set
            {
                _indexName = value.ToLower();
            }
        }
        public IndexTypes IndexType { get; set; }
        public List<Stock> Stocks = new List<Stock>();
    }

    public class Portfolio
    {
        public Portfolio(string inId)
        {
            Id = inId;
        }

        public string Id;
        public Dictionary<Stock, int> ConcreteStocks = new Dictionary<Stock, int>();
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stockList = new List<Stock>();
        private List<Index> _indexList = new List<Index>();
        private List<Portfolio> _portfolioList = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            if ((!StockExists(stock.StockName)) && (inInitialPrice > 0))
            {
                _stockList.Add(stock);
            }
            else throw new StockExchangeException("greska");
        }

        public void DelistStock(string inStockName)
        {
            if ((StockExists(inStockName)))
            {
                foreach (Stock stock in _stockList)
                {
                    if (stock.StockName.ToLower() == inStockName.ToLower())
                    {
                        _stockList.Remove(stock);
                        // indeks (i port.) mogu sadržavati samo dionice koje POSTOJE na burzi.
                        foreach (Index index in _indexList)
                        {
                            RemoveStockFromIndex(index.IndexName, stock.StockName);
                        }
                        foreach (Portfolio portfolio in _portfolioList)
                        {
                            RemoveStockFromPortfolio(portfolio.Id, stock.StockName);
                        }
                    }
                }
            }
            else throw new StockExchangeException("gr");
        }

        public bool StockExists(string inStockName)
        {
            return _stockList.Exists(stock => stock.StockName.ToLower() == inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return _stockList.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if ((StockExists(inStockName)) && (inStockValue > 0))
            {
                if (GetStockByName(inStockName).StockPrice.ContainsKey(inIimeStamp))
                {
                    GetStockByName(inStockName).StockPrice.Remove(inIimeStamp);
                    GetStockByName(inStockName).StockPrice.Add(inIimeStamp, inStockValue);
                }
                else
                {
                    GetStockByName(inStockName).StockPrice.Add(inIimeStamp, inStockValue);
                }  
            }
            else throw new StockExchangeException("greska");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                DateTime dateLastBefore = DateTime.MinValue;
                Dictionary<DateTime, decimal> stockPrice = GetStockByName(inStockName).StockPrice;
                foreach (KeyValuePair<DateTime, decimal> pair in stockPrice)
                {
                    if (pair.Key <= inTimeStamp)
                    {
                        if (pair.Key > dateLastBefore) dateLastBefore = pair.Key;
                    }
                }
                decimal currentPrice;
                if (stockPrice.TryGetValue(dateLastBefore, out currentPrice))
                {
                    return currentPrice;
                }
                else throw new StockExchangeException("greska");
            }
            else throw new StockExchangeException("greska");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists((inStockName)))
            {
                DateTime minDate = DateTime.MaxValue;
                Dictionary<DateTime, decimal> stockPrice = _stockList.Find(o => o.StockName == inStockName).StockPrice;
                foreach (KeyValuePair<DateTime, decimal> pair in stockPrice)
                {
                    if (pair.Key < minDate) minDate = pair.Key;
                }
                decimal currentPrice;
                if (stockPrice.TryGetValue(minDate, out currentPrice))
                {
                    return currentPrice;
                }
                else throw new StockExchangeException("greska");
            }
            else throw new StockExchangeException("gr");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists((inStockName)))
            {
                DateTime maxDate = DateTime.MinValue;
                Dictionary<DateTime, decimal> stockPrice = _stockList.Find(o => o.StockName == inStockName).StockPrice;
                foreach (KeyValuePair<DateTime, decimal> pair in stockPrice)
                {
                    if (pair.Key > maxDate) maxDate = pair.Key;
                }
                decimal currentPrice;
                if (stockPrice.TryGetValue(maxDate, out currentPrice))
                {
                    return currentPrice;
                }
                else throw new StockExchangeException("greska");
            }
            else throw new StockExchangeException("gr");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            // Stvaranje indeksa nekog drugog tipa ne smije biti dopušteno u sustavu te je u tom slučaju potrebno obavijestiti korisnika. 
            if (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
            {
                Index index = new Index(inIndexName, inIndexType);
                _indexList.Add(index);
            }
            else throw new StockExchangeException("greska");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            bool alreadyExistsInIndex = false;
            if (IndexExists(inIndexName) && StockExists((inStockName)))
            {
                Stock stock = GetStockByName(inStockName);
                // Ista dionica smije se samo jednom pridijeliti indeksu
                foreach (Index index in _indexList)
                {
                    if (IsStockPartOfIndex(inIndexName, inStockName))
                    {
                        alreadyExistsInIndex = true;
                    }
                }
                if (!alreadyExistsInIndex) GetIndexByName(inIndexName).Stocks.Add(stock);
                else throw new StockExchangeException("vec postoji");
            }
            else throw new StockExchangeException("gr");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists((inStockName)))
            {
                Stock stock = GetStockByName(inStockName);
                GetIndexByName(inIndexName).Stocks.Remove(stock);
            }
            else throw new StockExchangeException("gr");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName))
            {
                if (GetIndexByName(inIndexName).Stocks.Exists(s => s.StockName.ToLower() == inStockName.ToLower()))
                {
                    return true;
                }
                return false;
            }
            else throw new StockExchangeException("greska");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (IndexExists(inIndexName))
            {
                if (GetIndexByName(inIndexName).IndexType == IndexTypes.AVERAGE)
                {
                    // vrijednost indeksa se računa kao jednostavan prosjek cijene svih dionica u indeksu
                    List<Stock> stocks = GetIndexByName(inIndexName).Stocks;
                    decimal totalValue = 0;
                    decimal number = 0;
                    foreach (Stock stock in stocks)
                    {
                        totalValue += GetStockPrice(stock.StockName, inTimeStamp);
                        number++;
                    }
                    if (totalValue > 0 && number > 0)
                        return Math.Round( totalValue / number, 3);
                    else return 0;
                }
                else if (GetIndexByName(inIndexName).IndexType == IndexTypes.WEIGHTED)
                {
                    // vrijednost indeksa se računa kao težinski prosjek cijene svih dionica u indeksu, 
                    // gdje je težinski faktor za pojedinu dionicu definiran kao omjer ukupne vrijednosti te dionice 
                    // na burzi (cijena dionice * broj dionica) i ukupne vrijednosti svih dionica unutar indeksa
                    decimal tezinskiFaktor;
                    decimal tezinskiProsjek;
                    List<decimal> tezina = new List<decimal>();
                    decimal dioniceIndeksa = 0;

                    List<Stock> stocks = GetIndexByName(inIndexName).Stocks;
                    foreach (Stock stock in stocks)
                    {
                        dioniceIndeksa += GetStockPrice(stock.StockName, inTimeStamp)*stock.NumberOfShares;
                    }
                    foreach (Stock stock in stocks)
                    {
                        tezinskiFaktor = (GetStockPrice(stock.StockName, inTimeStamp) * stock.NumberOfShares / dioniceIndeksa);
                        tezina.Add(tezinskiFaktor * GetStockPrice(stock.StockName, inTimeStamp));
                    }
                    tezinskiProsjek = tezina.Sum();
                    if (dioniceIndeksa > 0)
                        return Math.Round(tezinskiProsjek, 3);
                    else return 0;
                }
                else throw new StockExchangeException("gr");
            }
            else throw new StockExchangeException("greska");
        }

        public bool IndexExists(string inIndexName)
        {
            return _indexList.Exists(index => index.IndexName.ToLower() == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return _indexList.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return GetIndexByName(inIndexName).Stocks.Count();
            }
            else throw new StockExchangeException("greska");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio portfolio = new Portfolio(inPortfolioID);
            _portfolioList.Add(portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Stock stock = GetStockByName(inStockName);

                long totalNumberOfShares = stock.NumberOfShares;
                int numberOfSharesInPortfolios = numberOfShares;
                foreach (Portfolio portfolio in _portfolioList)
                {
                    int value;
                    portfolio.ConcreteStocks.TryGetValue(stock, out value);
                    numberOfSharesInPortfolios += value;
                }
                bool enoughToAdd = numberOfSharesInPortfolios <= totalNumberOfShares;
                if (enoughToAdd)
                {
                    if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                    {
                        GetPortfolioById(inPortfolioID).ConcreteStocks[GetStockByName(inStockName)] =
                            GetPortfolioById(inPortfolioID).ConcreteStocks[GetStockByName(inStockName)] + numberOfShares;
                    }
                    else
                        GetPortfolioById(inPortfolioID).ConcreteStocks.Add(GetStockByName(inStockName), numberOfShares);
                }
                else throw new StockExchangeException("greska");
            }
            else
                throw new StockExchangeException("greska");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                int numberBefore;
                GetPortfolioById(inPortfolioID).ConcreteStocks.TryGetValue(GetStockByName(inStockName), out numberBefore);
                GetPortfolioById(inPortfolioID).ConcreteStocks.Remove(GetStockByName(inStockName));
                GetPortfolioById(inPortfolioID).ConcreteStocks.Add(GetStockByName(inStockName),
                                                                   numberBefore - numberOfShares);
                int numberAfter;
                GetPortfolioById(inPortfolioID).ConcreteStocks.TryGetValue(GetStockByName(inStockName), out numberAfter);
                if (numberAfter == 0) GetPortfolioById(inPortfolioID).ConcreteStocks.Remove(GetStockByName(inStockName));
            }
            else
                throw new StockExchangeException("greska");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                GetPortfolioById(inPortfolioID).ConcreteStocks.Remove(GetStockByName(inStockName));
            }
            else
                throw new StockExchangeException("greska");
        }

        public int NumberOfPortfolios()
        {
            return _portfolioList.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return GetPortfolioById(inPortfolioID).ConcreteStocks.Keys.Count();
            }
            else
                throw new StockExchangeException("greska");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioList.Exists(portfolio => portfolio.Id == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                return GetPortfolioById(inPortfolioID).ConcreteStocks.ContainsKey(GetStockByName(inStockName));
            }
            else
                throw new StockExchangeException("greska");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                int numberOfShares;
                GetPortfolioById(inPortfolioID).ConcreteStocks.TryGetValue(GetStockByName(inStockName),
                                                                           out numberOfShares);
                return numberOfShares;
            }
            else
                throw new StockExchangeException("greska");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal value = 0;
            if (PortfolioExists(inPortfolioID))
            {
                foreach (KeyValuePair<Stock, int> stockPrice in GetPortfolioById(inPortfolioID).ConcreteStocks)
                {
                    value += GetStockPrice(stockPrice.Key.StockName, timeStamp) * stockPrice.Value;
                }
                return Math.Round(value, 3);
            }
        else throw new StockExchangeException("greska");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal valueBegin = 0;
            decimal valueEnd = 0;
            if (PortfolioExists(inPortfolioID))
            {
           DateTime dateBegin = new DateTime(Year, Month, 1,0,0,0,0);
           DateTime dateEnd = new DateTime(Year, Month, DateTime.DaysInMonth(Year,Month),23,59,59,999);
            // overshoot the date by a month
           //dateEnd = dateEnd.AddMonths(1); 
           //dateEnd = dateEnd.AddDays(-(dateEnd.Day));

           valueBegin = GetPortfolioValue(inPortfolioID, dateBegin);
           valueEnd = GetPortfolioValue(inPortfolioID, dateEnd);
            return Math.Round((valueEnd - valueBegin)*100/valueBegin,3);
            }
            else throw new StockExchangeException("greska");
        }

        // funkcija koja enkapsulira funkcionalnost dohvata dionice
        public Stock GetStockByName(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return _stockList.Find(o => o.StockName.ToLower() == inStockName.ToLower());
            }
            else
                throw new StockExchangeException("greska");
        }
        public Index GetIndexByName(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return _indexList.Find(o => o.IndexName.ToLower() == inIndexName.ToLower());
            }
            else
                throw new StockExchangeException("greska");
        }
        public Portfolio GetPortfolioById(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return _portfolioList.Find(portfolio => portfolio.Id == inPortfolioID);
            }
            else
                throw new StockExchangeException("greska");
        }
    }
}
