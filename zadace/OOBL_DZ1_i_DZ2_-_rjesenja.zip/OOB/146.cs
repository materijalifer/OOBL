﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza {

	public static class Factory {
		public static IStockExchange CreateStockExchange() {
			return new StockExchange();
		}
	}

	/*==================== Stock ====================*/

	public class Stock {
		public string name { get; private set; }
		public long numberOfShares { get; private set; }
		private List<StockPrice> stockPrices = new List<StockPrice>();

		public Stock(string name, long numberOfShares, Decimal price, DateTime timeStamp) {
			if (numberOfShares <= 0L)
				throw new StockExchangeException("Illegal number of shares.");
			this.name = name;
			this.numberOfShares = numberOfShares;
			setPrice(timeStamp, price);
		}

		public void setPrice(DateTime timeStamp, Decimal price) {
			foreach (StockPrice stockPrice in stockPrices) {
				if (stockPrice.timeStamp.CompareTo(timeStamp) == 0)
					throw new StockExchangeException("Stock price already exists.");
			}
			stockPrices.Add(new StockPrice(timeStamp, price));
		}

		public Decimal getInitialPrice() {
			StockPrice initialPrice = stockPrices[0];
			foreach (StockPrice price in stockPrices) {
				if (price.timeStamp.CompareTo(initialPrice.timeStamp) < 0)  //ako je price ranije od initPrice
					initialPrice = price;
			}
			return initialPrice.price;
		}

		public Decimal getLastPrice() {
			StockPrice lastPrice = stockPrices[stockPrices.Count - 1];
			foreach (StockPrice price in stockPrices) {
				if (price.timeStamp.CompareTo(lastPrice.timeStamp) > 0)     //ako je price kasnije od initPrice
					lastPrice = price;
			}
			return lastPrice.price;
		}

		public Decimal getPrice(DateTime timeStamp) {
			StockPrice targetPrice = null;
			foreach (StockPrice price in stockPrices) {
				if (price.timeStamp.CompareTo(timeStamp) <= 0) {                                        //ako je price ranije ili isto kao timeStamp
					if (targetPrice == null || price.timeStamp.CompareTo(targetPrice.timeStamp) > 0)    //ako je price kasnije od targetPrice
						targetPrice = price;
				}
			}
			if (targetPrice == null) {
				throw new StockExchangeException("Stock price doesn't exists.");
			}
			return targetPrice.price;
		}

		// override object.Equals
		public override bool Equals(object obj) {
			if (obj == null || GetType() != obj.GetType()) {
				return false;
			}
			Stock other = (Stock)obj;
			return string.Compare(name, other.name, true) == 0;  //ignore case 
		}
		// override object.GetHashCode
		public override int GetHashCode() {
			return name.ToUpper().GetHashCode();
		}

		public class StockPrice {
			public DateTime timeStamp { get; private set; }
			public decimal price { get; private set; }

			public StockPrice(DateTime timeStamp, decimal price) {
				if (price <= 0m)
					throw new StockExchangeException("Illegal stock price.");
				this.timeStamp = timeStamp;
				this.price = price;
			}
		}
	}


	/*==================== Index ====================*/

	public class Index {
		public string name { get; private set; }
		public IndexTypes type { get; private set; }
		private IndexValueCalculator valueCalculator;
		private HashSet<Stock> stocks = new HashSet<Stock>();

		public Index(string name, IndexTypes type) {
			if (type == IndexTypes.AVERAGE) {
				valueCalculator = new AverageIndexValueCalculator();
			} else if (type == IndexTypes.WEIGHTED) {
				valueCalculator = new WeightedIndexValueCalculator();
			} else {
				throw new StockExchangeException("Illegal IndexType.");
			}
			this.name = name;
			this.type = type;
		}

		//prijenos argumenata je potreban jer Singelton obrazac za repozitorije ne funkcionira kod provodenja testova :)
		public void addStock(Stock stock, StockRepository stockRepository) {
			if (!stockRepository.contains(stock.name))
				throw new StockExchangeException("Stock doesn't exists.");
			if (containsStock(stock))
				throw new StockExchangeException("Stock is already in index.");
			stocks.Add(stock);
		}

		public void removeStock(Stock stock) {
			if (!containsStock(stock))
				throw new StockExchangeException("Stock isn't in index.");
			stocks.Remove(stock);
		}

		public bool containsStock(Stock stock) {
			return stocks.Contains(stock);
		}

		public int numberOfStocks() {
			return stocks.Count;
		}

		public Decimal getValue(DateTime timeStamp) {
			return Math.Round(valueCalculator.getValue(stocks.ToList(), timeStamp), 3);
		}

		// override object.Equals
		public override bool Equals(object obj) {
			if (obj == null || GetType() != obj.GetType()) {
				return false;
			}
			Index other = (Index)obj;
			return string.Compare(name, other.name, true) == 0;  //ignore case 
		}
		// override object.GetHashCode
		public override int GetHashCode() {
			return name.ToUpper().GetHashCode();
		}

		public interface IndexValueCalculator {
			Decimal getValue(List<Stock> stocks, DateTime timeStamp);
		}

		public class AverageIndexValueCalculator : IndexValueCalculator {
			public Decimal getValue(List<Stock> stocks, DateTime timeStamp) {
				decimal sum = 0m;
				int numOfStocks = 0;
				foreach (Stock stock in stocks) {
					decimal stockPrice = stock.getPrice(timeStamp);
					sum += stockPrice;
					numOfStocks++;
				}
				if (numOfStocks == 0)
					return 0;
				else
					return sum / numOfStocks;
			}
		}

		public class WeightedIndexValueCalculator : IndexValueCalculator {
			public Decimal getValue(List<Stock> stocks, DateTime timeStamp) {
				decimal totalPrice = 0m;
				foreach (Stock stock in stocks) {
					decimal stockPrice = stock.getPrice(timeStamp);
					totalPrice += stockPrice * stock.numberOfShares;
				}
				if (totalPrice == 0m)
					return 0m;
				decimal sum = 0m;
				foreach (Stock stock in stocks) {
					decimal stockPrice = stock.getPrice(timeStamp);
					decimal w = (stockPrice * stock.numberOfShares) / totalPrice;
					sum += stockPrice * w;
				}
				return sum;
			}
		}

	}


	/*==================== Portfolio ====================*/

	public class Portfolio {
		public string id { get; private set; }
		private Dictionary<Stock, StockShare> stockShares = new Dictionary<Stock, StockShare>();

		public Portfolio(string id) {
			this.id = id;
		}
		
		public void addStockShare(Stock stock, long numberOfShares, StockRepository stockRepository, PortfolioRepository portfolioRepository) {
			if (!stockRepository.contains(stock.name))
				throw new StockExchangeException("Stock doesn't exists.");
			if (numberOfShares <= 0L || numberOfShares > countAvailableStockShares(stock, portfolioRepository))
				throw new StockExchangeException("Illegal number of shares.");

			if (!stockShares.ContainsKey(stock)) {
				stockShares.Add(stock, new StockShare(stock));
			}
			StockShare stockShare = stockShares[stock];
			stockShare.setNumberOfShares(stockShare.numberOfShares + numberOfShares);
		}

		public long countAvailableStockShares(Stock stock, PortfolioRepository portfolioRepository) {
			long numOfUsedShares = 0;
			List<Portfolio> portfolios = portfolioRepository.listPortfoliosWithStockShare(stock);
			foreach (Portfolio portfolio in portfolios) {
				numOfUsedShares += portfolio.getNumberOfStockShares(stock);
			}
			return stock.numberOfShares - numOfUsedShares;
		}

		public void removeStockShare(Stock stock) {
			if (!containsStockShare(stock))
				throw new StockExchangeException("Stock isn't in portfolio.");
			stockShares.Remove(stock);
		}

		public void removeStockShare(Stock stock, long numberOfShares) {
			if (!containsStockShare(stock))
				throw new StockExchangeException("Stock isn't in portfolio.");
			StockShare stockShare = stockShares[stock];
			stockShare.setNumberOfShares(stockShare.numberOfShares - numberOfShares);
			if (stockShare.numberOfShares == 0L)
				stockShares.Remove(stock);
		}

		public int getNumberOfStocks() {
			return stockShares.Count();
		}

		public bool containsStockShare(Stock stock) {
			return stockShares.ContainsKey(stock);
		}

		public long getNumberOfStockShares(Stock stock) {
			if (!containsStockShare(stock))
				throw new StockExchangeException("Stock isn't in portfolio.");
			return stockShares[stock].numberOfShares;
		}

		public Decimal getValue(DateTime timeStamp) {
			return Math.Round(calculateValue(timeStamp), 3);
		}

		private Decimal calculateValue(DateTime timeStamp) {
			decimal sum = 0m;
			foreach (StockShare stockShare in stockShares.Values) {
				sum += stockShare.stock.getPrice(timeStamp) * stockShare.numberOfShares;
			}
			return sum;
		}

		public Decimal getPercentChangeInValueForMonth(int year, int month) {
			DateTime startTime = new DateTime(year, month, 1, 0, 0, 0);
			startTime.AddMilliseconds(0);
			DateTime endTime = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59);
			endTime.AddMilliseconds(999);

			Decimal startValue = calculateValue(startTime);
			Decimal endValue = calculateValue(endTime);

			Decimal change = (endValue - startValue) / startValue;
			return Math.Round(change, 3) * 100;
		}

		// override object.Equals
		public override bool Equals(object obj) {
			if (obj == null || GetType() != obj.GetType()) {
				return false;
			}
			Portfolio other = (Portfolio)obj;
			return id == other.id;              //case sensitive 
		}
		// override object.GetHashCode
		public override int GetHashCode() {
			return id.GetHashCode();
		}

		public class StockShare {
			public Stock stock { get; private set; }
			public long numberOfShares { get; private set; }

			public StockShare(Stock stock) {
				this.stock = stock;
				this.numberOfShares = 0L;
			}

			public void setNumberOfShares(long numberOfShares) {
				if (numberOfShares < 0L)
					throw new StockExchangeException("Illegal number of shares.");
				this.numberOfShares = numberOfShares;
			}
		}

	}

	/*==================== StockRepository ====================*/

	public class StockRepository {

		private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();		//kljuc je ime dionice u UPPERCASE-u

		public void add(Stock stock) {
			if (contains(stock.name))
				throw new StockExchangeException("Stock already exists.");
			string key = stock.name.ToUpper();
			stocks.Add(key, stock);
		}

		public void remove(string stockName, IndexRepository indexRepository, PortfolioRepository portfolioRepository) {
			string key = stockName.ToUpper();
			if (!stocks.ContainsKey(key))
				throw new StockExchangeException("Stock doesn't exists.");
			Stock stock = stocks[key];
			stocks.Remove(key);

			foreach (Index index in indexRepository.listIndexesWithStock(stock)) {						//maknut dionicu iz postojecih indeksa
				index.removeStock(stock);
			}
			foreach (Portfolio portfolio in portfolioRepository.listPortfoliosWithStockShare(stock)) {	//maknut dionicu iz postojecih portfolija
				portfolio.removeStockShare(stock);
			}
		}

		public bool contains(string stockName) {
			string key = stockName.ToUpper();
			return stocks.ContainsKey(key);
		}

		public int size() {
			return stocks.Count;
		}

		public Stock get(string stockName) {
			string key = stockName.ToUpper();
			if (!stocks.ContainsKey(key))
				throw new StockExchangeException("Stock doesn't exists.");
			return stocks[key];
		}

	}

	/*==================== IndexRepository ====================*/

	public class IndexRepository {
		//Both indexes and indices are acceptable plurals for index in English :)
		private Dictionary<string, Index> indexes = new Dictionary<string, Index>();		//kljuc je ime indexa u UPPERCASE-u
		
		public void add(Index index) {
			if (contains(index.name))
				throw new StockExchangeException("Index already exists.");
			string key = index.name.ToUpper();
			indexes.Add(key, index);
		}

		public void remove(string indexName) {
			string key = indexName.ToUpper();
			if (!indexes.ContainsKey(key))
				throw new StockExchangeException("Index doesn't exists.");
			indexes.Remove(key);
		}

		public bool contains(string indexName) {
			string key = indexName.ToUpper();
			return indexes.ContainsKey(key);
		}

		public int size() {
			return indexes.Count;
		}

		public Index get(string indexName) {
			string key = indexName.ToUpper();
			if (!indexes.ContainsKey(key))
				throw new StockExchangeException("Index doesn't exists.");
			return indexes[key];
		}

		public List<Index> listIndexesWithStock(Stock stock) {
			List<Index> list = new List<Index>();
			foreach (Index index in indexes.Values) {
				if (index.containsStock(stock))
					list.Add(index);
			}
			return list;
		}

	}

	/*==================== PortfolioRepository ====================*/

	public class PortfolioRepository {

		private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();		//kljuc je id portfolia, case sensitive

		public void add(Portfolio portfolio) {
			if (contains(portfolio.id))
				throw new StockExchangeException("Portfolio already exists.");
			string key = portfolio.id;
			portfolios.Add(key, portfolio);
		}

		public void remove(string portfolioId) {
			if (!portfolios.ContainsKey(portfolioId))
				throw new StockExchangeException("Portfolio doesn't exists.");
			portfolios.Remove(portfolioId);
		}

		public bool contains(string portfolioId) {
			string key = portfolioId;
			return portfolios.ContainsKey(key);
		}

		public int size() {
			return portfolios.Count;
		}

		public Portfolio get(string portfolioId) {
			string key = portfolioId;
			return portfolios[key];
		}

		public List<Portfolio> listPortfoliosWithStockShare(Stock stock) {
			List<Portfolio> list = new List<Portfolio>();
			foreach (Portfolio portfolio in portfolios.Values) {
				if (portfolio.containsStockShare(stock))
					list.Add(portfolio);
			}
			return list;
		}

	}

	/*==================== StockExchange ====================*/

	public class StockExchange : IStockExchange {

		private StockRepository stockRepository = new StockRepository();
		private IndexRepository indexRepository = new IndexRepository();
		private PortfolioRepository portfolioRepository = new PortfolioRepository();

		public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp) {
			Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
			stockRepository.add(stock);
		}

		public void DelistStock(string inStockName) {
			stockRepository.remove(inStockName, indexRepository, portfolioRepository);
		}

		public bool StockExists(string inStockName) {
			return stockRepository.contains(inStockName);
		}

		public int NumberOfStocks() {
			return stockRepository.size();
		}

		public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue) {
			Stock stock = stockRepository.get(inStockName);
			stock.setPrice(inIimeStamp, inStockValue);
		}

		public decimal GetStockPrice(string inStockName, DateTime inTimeStamp) {
			Stock stock = stockRepository.get(inStockName);
			return stock.getPrice(inTimeStamp);
		}

		public decimal GetInitialStockPrice(string inStockName) {
			Stock stock = stockRepository.get(inStockName);
			return stock.getInitialPrice();
		}

		public decimal GetLastStockPrice(string inStockName) {
			Stock stock = stockRepository.get(inStockName);
			return stock.getLastPrice();
		}

		public void CreateIndex(string inIndexName, IndexTypes inIndexType) {
			Index index = new Index(inIndexName, inIndexType);
			indexRepository.add(index);
		}

		public void AddStockToIndex(string inIndexName, string inStockName) {
			Index index = indexRepository.get(inIndexName);
			Stock stock = stockRepository.get(inStockName);
			index.addStock(stock, stockRepository);
		}

		public void RemoveStockFromIndex(string inIndexName, string inStockName) {
			Index index = indexRepository.get(inIndexName);
			Stock stock = stockRepository.get(inStockName);
			index.removeStock(stock);
		}

		public bool IsStockPartOfIndex(string inIndexName, string inStockName) {
			Index index = indexRepository.get(inIndexName);
			Stock stock = stockRepository.get(inStockName);
			return index.containsStock(stock);
		}

		public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp) {
			Index index = indexRepository.get(inIndexName);
			return index.getValue(inTimeStamp);
		}

		public bool IndexExists(string inIndexName) {
			return indexRepository.contains(inIndexName);
		}

		public int NumberOfIndices() {
			return indexRepository.size();
		}

		public int NumberOfStocksInIndex(string inIndexName) {
			Index index = indexRepository.get(inIndexName);
			return index.numberOfStocks();
		}

		public void CreatePortfolio(string inPortfolioID) {
			Portfolio portfolio = new Portfolio(inPortfolioID);
			portfolioRepository.add(portfolio);
		}

		public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			Stock stock = stockRepository.get(inStockName);
			portfolio.addStockShare(stock, numberOfShares, stockRepository, portfolioRepository);
		}

		public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			Stock stock = stockRepository.get(inStockName);
			portfolio.removeStockShare(stock, numberOfShares);
		}

		public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			Stock stock = stockRepository.get(inStockName);
			portfolio.removeStockShare(stock);
		}

		public int NumberOfPortfolios() {
			return portfolioRepository.size();
		}

		public int NumberOfStocksInPortfolio(string inPortfolioID) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			return portfolio.getNumberOfStocks();
		}

		public bool PortfolioExists(string inPortfolioID) {
			return portfolioRepository.contains(inPortfolioID);
		}

		public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			Stock stock = stockRepository.get(inStockName);
			return portfolio.containsStockShare(stock);
		}

		public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			Stock stock = stockRepository.get(inStockName);
			return (int)portfolio.getNumberOfStockShares(stock);
		}

		public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			return portfolio.getValue(timeStamp);
		}

		public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month) {
			Portfolio portfolio = portfolioRepository.get(inPortfolioID);
			return portfolio.getPercentChangeInValueForMonth(Year, Month);
		}
	}

}
