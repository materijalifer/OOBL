﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        const int MAX_DIGITS_IN_BUFFER = 10;        //Display can display max 10 digits
        int currDigInBuffer = 0;                    //Digits IN InputBuffer, MAX = 10
        string displayBuffer = "0";                 //Display buffer, Default = 0 
        string inputBuffer = String.Empty;          //Input buffer    
        string internalBuffer = String.Empty;       //Temp buffer for calculation
        double internalMemory = 0;                  //Calculator memory for M+, MR

        double mathResults = 0;                     
        char previousAction = '\0';                 
        char currentAction = '\0';              

        public void Press(char inPressedDigit)
        {
            if (Char.IsNumber(inPressedDigit) == true)
            {
                InsertDigitInInputBuffer(inPressedDigit);              
            }
            else            
            {
                InsertFunctionInInputBuffer(inPressedDigit);
            }
               
        }        
        public string GetCurrentDisplayState()
        {
            return displayBuffer.ToString();
        }

        private void InsertDigitInInputBuffer(char inPressedDigit)
        {
            switch (inputBuffer.Length)
            {
                case 0:
                    if (inPressedDigit != '0')
                    {
                        if (IsDigitBufferFull() == false)
                        {
                            inputBuffer = inputBuffer.Insert(inputBuffer.Length, inPressedDigit.ToString());
                            currDigInBuffer++;
                        }
                    }
                    break;
                default:
                    if (IsDigitBufferFull() == false)
                    {
                        inputBuffer = inputBuffer.Insert(inputBuffer.Length, inPressedDigit.ToString());
                        currDigInBuffer++;
                    }
                    break;
            }
            UpdateDisplay();
        }
        private void InsertFunctionInInputBuffer(char inPressedDigit)
        {
            previousAction = currentAction;   
            switch (inPressedDigit)
            {
                case '+':
                    currentAction = '+';
                    ValidateInputFromFunction();
                    if (inputBuffer != String.Empty)
                    {
                        inputBuffer = RemoveExtraNullsFromNumber(inputBuffer);
                        internalBuffer = inputBuffer;
                        UpdateDisplay();
                        inputBuffer = String.Empty;                       
                    }                    
                    ResetDigitBuffer();
                    break;

                case '-':
                    currentAction = '-';
                    ValidateInputFromFunction();
                    if (inputBuffer != String.Empty)
                    {
                        inputBuffer = RemoveExtraNullsFromNumber(inputBuffer);
                        internalBuffer = inputBuffer;
                        UpdateDisplay();
                        inputBuffer = String.Empty;          
                    }
                    ResetDigitBuffer();
                    break;

                case '*':
                    currentAction = '*';
                    ValidateInputFromFunction();
                    if (inputBuffer != String.Empty)
                    {
                        inputBuffer = RemoveExtraNullsFromNumber(inputBuffer);
                        internalBuffer = inputBuffer;
                        UpdateDisplay();
                        inputBuffer = String.Empty;          
                    }
                    ResetDigitBuffer();
                    break;

                case '/':
                    currentAction = '/';
                    ValidateInputFromFunction();
                    if (inputBuffer != String.Empty)
                    {
                        inputBuffer = RemoveExtraNullsFromNumber(inputBuffer);
                        internalBuffer = inputBuffer;
                        UpdateDisplay();
                        inputBuffer = String.Empty;          
                    }
                    ResetDigitBuffer();
                    break;              

                case ',':
                    if (inputBuffer.Length == 0)
                    {
                        // If , is first pressed char  
                        inputBuffer = inputBuffer.Insert(0, "0,");
                        currDigInBuffer++;
                    }
                    else if (inputBuffer.Contains(",") == false)
                    {
                        inputBuffer = inputBuffer.Insert(inputBuffer.Length, ",");
                    }
                    break;

                case 'M':
                    ResetDigitBuffer();
                    if (inputBuffer[0] != '-') inputBuffer = inputBuffer.Insert(0, "-");
                    else inputBuffer.Remove(0, 1);
                    UpdateDisplay();
                    break;

                case 'S':
                    ResetDigitBuffer();
                    mathResults = Math.Sin(double.Parse(inputBuffer));
                    inputBuffer = RoundMathResult(mathResults);
                    UpdateDisplay();
                    break;

                case 'K':
                    ResetDigitBuffer();
                    mathResults = Math.Cos(double.Parse(inputBuffer));
                    inputBuffer = RoundMathResult(mathResults);
                    UpdateDisplay();
                    break;

                case 'T':
                    ResetDigitBuffer();
                    mathResults = Math.Tan(double.Parse(inputBuffer));
                    inputBuffer = RoundMathResult(mathResults);
                    UpdateDisplay();
                    break;

                case 'Q':
                    ResetDigitBuffer();     
                    mathResults = Math.Pow(double.Parse(inputBuffer), 2);
                    inputBuffer = RoundMathResult(mathResults);
                    UpdateDisplay();
                    break;

                case 'R': ResetDigitBuffer();
                    mathResults = Math.Sqrt(double.Parse(inputBuffer));
                    inputBuffer = RoundMathResult(mathResults);
                    UpdateDisplay();
                    break;

                case 'I':
                    ResetDigitBuffer();
                    if (previousAction == '/' || previousAction == '*' || previousAction == '+' || previousAction == '-')
                    {
                        if (internalBuffer.Length != 0)
                        {
                            inputBuffer = ((double)1 / double.Parse(internalBuffer)).ToString();
                        }
                        else inputBuffer = "-E-";
                    }
                    else
                    {
                        if (inputBuffer.Length != 0)
                        {
                            inputBuffer = ((double)1 / double.Parse(inputBuffer)).ToString();
                        }
                        else inputBuffer = "-E-";
                    }
                   
                    UpdateDisplay();
                    inputBuffer = string.Empty;
                    break;

                case 'P':
                    internalMemory = double.Parse(inputBuffer);
                    UpdateDisplay();
                    break;

                case 'G':
                    ResetDigitBuffer();
                    inputBuffer = internalMemory.ToString();
                    displayBuffer = inputBuffer.ToString();
                    UpdateDisplay();
                    break;

                case 'C':
                    ResetDigitBuffer();
                    inputBuffer = String.Empty;
                    UpdateDisplay();
                    break;

                case 'O':
                    ResetDigitBuffer();
                    inputBuffer = String.Empty;
                    internalBuffer = String.Empty;
                    previousAction = '\0';
                    currentAction = '\0';

                    UpdateDisplay();
                    break;

                case '=':
                    ResetDigitBuffer();
                    if (inputBuffer.Length > 0 || internalBuffer.Length > 0)
                    {
                        ValidateInputFromEqual();
                    }
                    UpdateDisplay();
                    break;
            }           
        }
        
        private void UpdateDisplay()
        {
            if (inputBuffer.Length == 0) displayBuffer = "0";
            else
            {
                if (IsResultTooBig(inputBuffer) == false) displayBuffer = inputBuffer;
                else displayBuffer = "-E-";               
            }
        }

        private void ResetDigitBuffer()
        {
            currDigInBuffer = 0;
        }
        private bool IsDigitBufferFull()
        {
            if (currDigInBuffer < MAX_DIGITS_IN_BUFFER) return false;
            else return true;
        }

        private void ValidateInputFromEqual()
        {           
            switch (previousAction)
            {
                case '+':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) + double.Parse(inputBuffer)).ToString();
                    }
                    else internalBuffer = (double.Parse(internalBuffer) + double.Parse(internalBuffer)).ToString();
                    inputBuffer = internalBuffer;
                    break;

                case '-':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) - double.Parse(inputBuffer)).ToString();
                    }
                    else internalBuffer = (double.Parse(internalBuffer) - double.Parse(internalBuffer)).ToString();
                    inputBuffer = internalBuffer;
                    break;

                case '*':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) * double.Parse(inputBuffer)).ToString();
                    }
                    else internalBuffer = (double.Parse(internalBuffer) * double.Parse(internalBuffer)).ToString();
                    inputBuffer = internalBuffer;
                    break;

                case '/':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) / double.Parse(inputBuffer)).ToString();
                    }
                    else internalBuffer = (double.Parse(internalBuffer) / double.Parse(internalBuffer)).ToString();
                    inputBuffer = internalBuffer;
                    break;

                case '\0':
                    //Convert 2.000 in 2
                    inputBuffer = RemoveExtraNullsFromNumber(inputBuffer);
                    break;
            }
        }
        private void ValidateInputFromFunction()
        {
            switch (previousAction)
            {
                case '+':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) + double.Parse(inputBuffer)).ToString();
                        inputBuffer = internalBuffer;
                        UpdateDisplay();
                        inputBuffer = string.Empty;
                    }                    
                    break;

                case '-':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) - double.Parse(inputBuffer)).ToString();
                        inputBuffer = internalBuffer;
                        UpdateDisplay();
                        inputBuffer = string.Empty;
                    }
                    break;

                case '*':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) * double.Parse(inputBuffer)).ToString();
                        inputBuffer = internalBuffer;
                        UpdateDisplay();
                        inputBuffer = string.Empty;
                    }
                    break;

                case '/':
                    if (inputBuffer != string.Empty)
                    {
                        internalBuffer = (double.Parse(internalBuffer) / double.Parse(inputBuffer)).ToString();
                        inputBuffer = internalBuffer;
                        UpdateDisplay();
                        inputBuffer = string.Empty;
                    }
                    break;
            }           
        }
    
        private string RemoveExtraNullsFromNumber(string inNumber)
        {
            while (inNumber.LastIndexOf(",") < inNumber.Length && inNumber.LastIndexOf("0") == inNumber.Length - 1)
            {
                inNumber = inNumber.Remove(inNumber.Length - 1);
            }
            if (inNumber.LastIndexOf(",") == inNumber.Length - 1) inNumber = inNumber.Remove(inNumber.Length - 1);
            return inNumber;
        }        
        private bool IsResultTooBig(string result)
        {
            // Result can have MAX_DIGITS_IN_BUFFER digits and MAX_DIGITS_IN_BUFFER +2 chars        
            int digitsCount = 0;
            foreach (char c in result)
            {
                if (Char.IsDigit(c)) digitsCount++;
            }
            if (digitsCount < MAX_DIGITS_IN_BUFFER +1 && result.Length < MAX_DIGITS_IN_BUFFER +3) return false;
            else return true;
        }
        private string RoundMathResult(double mathResult)
        {
            if (mathResult.ToString().Length > 10) mathResult = Math.Round(mathResults, 9);
            return mathResult.ToString();
        }
    }
}
