﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         public StockExchange()
         {
             StockExchangeService.Reset();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stock = new Stock(inStockName);

             StockAtStockExchange stockAtStockExchange = new StockAtStockExchange(stock, inNumberOfShares);
             StockAtStockExchangeRepository.GetInstance().AddNewStockAtStockExchange(stockAtStockExchange);

             StockPrice stockPrice = new StockPrice(stockAtStockExchange, inInitialPrice, inTimeStamp);
             StockPriceRepository.GetInstance().AddNewStockPrice(stockPrice);
         }

         public void DelistStock(string inStockName)
         {
             StockAtStockExchange stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("Stock not found");
             }

             StockPriceRepository.GetInstance().RemoveStockPrices(stock);
             StockAtStockExchangeRepository.GetInstance().RemoveStock(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             return StockAtStockExchangeRepository.GetInstance().StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return StockAtStockExchangeRepository.GetInstance().Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             StockAtStockExchange stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(inStockName);
             StockPrice stockPrice = new StockPrice(stock, inStockValue, inIimeStamp);

             StockPriceRepository.GetInstance().AddNewStockPrice(stockPrice);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return StockPriceRepository.GetInstance().GetStockPrice(inStockName, inTimeStamp).Price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return StockPriceRepository.GetInstance().GetInitialStockPrice(inStockName).Price;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return StockPriceRepository.GetInstance().GetLastStockPrice(inStockName).Price;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index = IndexFactory.CreateIndex(inIndexName, inIndexType);
             IndexRepository.GetInstance().AddNewIndex(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName) != true)
             {
                 throw new StockExchangeException("Stock doesn't exitst");
             }
             Index index = IndexRepository.GetInstance().GetIndexByName(inIndexName);
             if (index == null)
             {
                 throw new StockExchangeException("Index not found");
             }

             StockAtStockExchange stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(inStockName);

             index.AddStockToIndex(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName) != true)
             {
                 throw new StockExchangeException("Stock doesn't exitst");
             }
             Index index = IndexRepository.GetInstance().GetIndexByName(inIndexName);
             if (index == null)
             {
                 throw new StockExchangeException("Index not found");
             }

             StockAtStockExchange stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(inStockName);

             index.RemoveStockFromIndex(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (StockExists(inStockName) != true)
             {
                 throw new StockExchangeException("Stock doesn't exitst");
             }
             Index index = IndexRepository.GetInstance().GetIndexByName(inIndexName);
             if (index == null)
             {
                 throw new StockExchangeException("Index not found");
             }

             return index.IsStockPartOfIndex(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = IndexRepository.GetInstance().GetIndexByName(inIndexName);
             return IndexValueCalculator.CalculateIndexValue(index, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return IndexRepository.GetInstance().IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return IndexRepository.GetInstance().Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = IndexRepository.GetInstance().GetIndexByName(inIndexName);

             return index.CountStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             PorfolioService.AddPortfolioToRepository(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             PorfolioService.AddStocksToPortfolio(inStockName, numberOfShares, inPortfolioID);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             PorfolioService.RemoveStocksFromPortfolio(inPortfolioID, inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             PorfolioService.RemoveStocksFromPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfPortfolios()
         {
             return PorfolioService.CountPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return PorfolioService.CountAllStocksInPortfolio(inPortfolioID);
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return PorfolioService.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return PorfolioService.StockIsPartOfPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return PorfolioService.CountStockInPortfolio(inStockName, inPortfolioID);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return PorfolioService.CalculatePortfolioValue(inPortfolioID, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return PorfolioService.CalculatePortfolioPercentChangedInMonth(inPortfolioID, Year, Month);
         }
     }

     #region Services
     public class StockExchangeService
     {
         public static void Reset()
         {
             IndexRepository.Reset();
             PortfolioRepository.Reset();
             StockAtStockExchangeRepository.Reset();
             StockPriceRepository.Reset();
         }
     }

     public class PorfolioService
     {
         public static void AddStocksToPortfolio(string stockName, int stockNumber, string portfolioID)
         {
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioID);

             if (CountStockInAllPortfolios(stockName) + stockNumber > StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).NumberOfShares)
             {
                 throw new StockExchangeException("cannot add");
             }
             else
             {
                 portfolio.AddStockToPortfolio(stock, stockNumber);
             }
         }

         public static int CountStockInAllPortfolios(string stockName)
         {
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;

             int stockNumber = 0;
             foreach (Portfolio p in PortfolioRepository.GetInstnace().GetAllPortfolios())
             {
                 if (p.StockExistsInPortfolio(stock))
                 {
                     stockNumber += p.NumberOfStocks(stock);
                 }
             }

             return stockNumber;
         }

         public static void AddPortfolioToRepository(string portfolioId)
         {
             Portfolio portfolio = new Portfolio(portfolioId);
             PortfolioRepository.GetInstnace().AddPortfolio(portfolio);
         }

         public static void RemovePortfolioFromRepository(string portfolioId)
         {
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);
             PortfolioRepository.GetInstnace().RemovePortfolio(portfolio);
         }

         public static int CountPortfolios()
         {
             return PortfolioRepository.GetInstnace().GetAllPortfolios().Count;
         }

         public static int CountStockInPortfolio(string stockName, string portfolioId)
         {
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;

             return portfolio.NumberOfStocks(stock);
         }

         public static int CountAllStocksInPortfolio(string portfolioId)
         {
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);

             return portfolio.CountStocks;
         }

         public static void RemoveStocksFromPortfolio(string portfolioId, string stockName)
         {
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);

             portfolio.RemoveStockFromPortfolio(stock);
         }

         public static void RemoveStocksFromPortfolio(string portfolioId, string stockName, int amount)
         {
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);

             portfolio.RemoveStockFromPortfolio(stock, amount);
         }

         public static bool PortfolioExists(string portfolioId)
         {
             return PortfolioRepository.GetInstnace().PortfolioExists(portfolioId);
         }

         public static bool StockIsPartOfPortfolio(string portfolioId, string stockName)
         {
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);
             Stock stock = StockAtStockExchangeRepository.GetInstance().GetStockByName(stockName).Stock;

             return portfolio.StockExistsInPortfolio(stock);
         }

         public static decimal CalculatePortfolioValue(string portfolioId, DateTime date)
         {
             Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);

             decimal sumValue = 0;

             foreach (Stock stock in portfolio.GetAllPortfolioStocks().Keys)
             {
                 StockAtStockExchange stockAtStockExchange = StockAtStockExchangeRepository.GetInstance().GetStockByName(stock.StockName);

                 sumValue += (StockPriceRepository.GetInstance().GetStockPrice(stockAtStockExchange, date).Price * portfolio.NumberOfStocks(stock));
             }

             return sumValue;
         }

         public static decimal CalculatePortfolioPercentChangedInMonth(string portfolioId, int year, int month)
         {
             if (month > 12)
             {
                 throw new StockExchangeException("monthy > 12 ?");
             }
             else
             {
                 Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioId);

                 DateTime firstDay = new DateTime(year, month, 1, 0, 0, 0, 0);
                 DateTime lastDay = firstDay.AddDays(DateTime.DaysInMonth(year, month));
                 lastDay.AddDays(23);
                 lastDay.AddMinutes(59);
                 lastDay.AddSeconds(59);
                 lastDay.AddMilliseconds(999);

                 decimal percentChanged;
                 decimal startValue = CalculatePortfolioValue(portfolioId, firstDay);
                 decimal endValalue = CalculatePortfolioValue(portfolioId, lastDay);
                 percentChanged = endValalue / startValue;

                 return percentChanged * 100;

             }
         }
     }

     public class IndexValueCalculator
     {
         public static decimal CalculateIndexValue(Index index, DateTime time)
         {
             if (index as AverageIndex != null)
                 return CalculateIndexValue(index as AverageIndex, time);
             if (index as WeightedIndex != null)
                 return CalculateIndexValue(index as WeightedIndex, time);

             return 0;
         }

         private static decimal CalculateIndexValue(AverageIndex index, DateTime time)
         {
             decimal sum = 0;
             long numberOfStocks = 0;
             foreach (StockAtStockExchange stock in index.GetAllStocks())
             {
                 sum += (StockPriceRepository.GetInstance().GetStockPrice(stock.Stock.StockName, time).Price * stock.NumberOfShares);
                 numberOfStocks += stock.NumberOfShares;
             }

             return sum / numberOfStocks;
         }

         private static decimal CalculateIndexValue(WeightedIndex index, DateTime time)
         {
             decimal totalSum = 0;
             foreach (StockAtStockExchange stock in index.GetAllStocks())
             {
                 totalSum += (StockPriceRepository.GetInstance().GetStockPrice(stock.Stock.StockName, time).Price * stock.NumberOfShares);
             }

             decimal sum = 0;
             foreach (StockAtStockExchange stock in index.GetAllStocks())
             {
                 sum += (((StockPriceRepository.GetInstance().GetStockPrice(stock, time).Price * stock.NumberOfShares) / totalSum) * StockPriceRepository.GetInstance().GetStockPrice(stock, time).Price);
             }

             return sum;
         }
     }
     #endregion Services

     #region Repositories
     public class StockPriceRepository
     {
         private static StockPriceRepository _instance;
         private List<StockPrice> _listStockPrice = new List<StockPrice>();

         public static void Reset()
         {
             _instance = null;
         }

         public static StockPriceRepository GetInstance()
         {
             if (_instance == null)
             {
                 _instance = new StockPriceRepository();
             }

             return _instance;
         }

         public void AddNewStockPrice(StockPrice stockPrice)
         {
             _listStockPrice.Add(stockPrice);
         }

         public StockPrice GetStockPrice(StockAtStockExchange stock, DateTime timeStamp)
         {
             try
             {
                 DateTime lastDate = (from l in _listStockPrice
                                      where l.TimeStamp < timeStamp && l.Stock == stock
                                      select l).Max(st => st.TimeStamp);


                 StockPrice stockPrice = (from l in _listStockPrice
                                          where l.TimeStamp == lastDate && l.Stock == stock
                                          select l).First();

                 return stockPrice;
             }
             catch (Exception ex)
             {
                 throw new StockExchangeException("Price doesn't exist.");
             }

         }

         public StockPrice GetStockPrice(string stockName, DateTime timeStamp)
         {
             DateTime lastDate = (from l in _listStockPrice
                                  where l.TimeStamp < timeStamp && l.Stock.Stock.StockName == stockName
                                  select l).Max(stPrice => stPrice.TimeStamp);

             StockPrice stockPrice = (from l in _listStockPrice
                                      where l.TimeStamp == lastDate && l.Stock.Stock.StockName == stockName
                                      select l).First();

             return stockPrice;
         }

         public void RemoveStockPrices(StockAtStockExchange stock)
         {
             _listStockPrice.RemoveAll(delegate(StockPrice stockPrice)
             {
                 if (stockPrice.Stock == stock)
                     return true;
                 else
                     return false;
             }
                                      );
         }

         public StockPrice GetInitialStockPrice(string stockName)
         {
             DateTime lastDate = (from l in _listStockPrice
                                  where l.Stock.Stock.StockName == stockName
                                  select l).Min(stPrice => stPrice.TimeStamp);

             StockPrice stockPrice = (from l in _listStockPrice
                                      where l.TimeStamp == lastDate && l.Stock.Stock.StockName == stockName
                                      select l).First();

             return stockPrice;
         }

         public StockPrice GetLastStockPrice(string stockName)
         {
             DateTime lastDate = (from l in _listStockPrice
                                  where l.Stock.Stock.StockName == stockName
                                  select l).Max(stPrice => stPrice.TimeStamp);

             StockPrice stockPrice = (from l in _listStockPrice
                                      where l.TimeStamp == lastDate && l.Stock.Stock.StockName == stockName
                                      select l).First();

             return stockPrice;
         }
     }

     public class StockAtStockExchangeRepository
     {
         private static StockAtStockExchangeRepository _instance;
         private List<StockAtStockExchange> _listStockAtStockExchange = new List<StockAtStockExchange>();

         public static void Reset()
         {
             _instance = null;
         }


         public static StockAtStockExchangeRepository GetInstance()
         {
             if (_instance == null)
             {
                 _instance = new StockAtStockExchangeRepository();
             }

             return _instance;
         }

         public void AddNewStockAtStockExchange(StockAtStockExchange stock)
         {
             if ((from l in _listStockAtStockExchange
                  where l.Stock.StockName == stock.Stock.StockName
                  select l).Count() > 0)
             {
                 throw new StockExchangeException("Stock exists");
             }

             _listStockAtStockExchange.Add(stock);
         }

         public StockAtStockExchange GetStockByName(string stockName)
         {
             StockAtStockExchange stock = (from l in _listStockAtStockExchange
                                           where l.Stock.StockName == stockName
                                           select l).First();

             return stock;
         }

         public void RemoveStock(string stockName)
         {
             _listStockAtStockExchange.RemoveAll(delegate(StockAtStockExchange stock)
             {
                 if (stock.Stock.StockName == stockName)
                     return true;
                 else
                     return false;
             }
                                                 );
         }

         public bool StockExists(string stockName)
         {
             if ((from l in _listStockAtStockExchange
                  where l.Stock.StockName == stockName
                  select l).Count() > 0)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int Count
         {
             get
             {
                 return _listStockAtStockExchange.Count;
             }
         }
     }

     public class PortfolioRepository
    {
        private static PortfolioRepository _instance;
        private List<Portfolio> _listPortfolio = new List<Portfolio>();

        public static void Reset()
        {
            _instance = null;
        }

        public static PortfolioRepository GetInstnace()
        {
            if (_instance == null)
                _instance = new PortfolioRepository();

            return _instance;
        }

        public void AddPortfolio(Portfolio portfolio)
        {
            if ((from l in _listPortfolio
                     where l.IdPortfolio == portfolio.IdPortfolio
                     select l).Count() > 0)
            {
                throw new StockExchangeException("exists");
            }

            _listPortfolio.Add(portfolio);
        }

        public bool PortfolioExists(string portfolioID)
        {
            Portfolio portfolio = PortfolioRepository.GetInstnace().GetPortfolioByID(portfolioID);

            if ((from l in _listPortfolio
                 where l.IdPortfolio == portfolio.IdPortfolio
                 select l).Count() > 0)
            {
                return true;
            }

            return false;
        }

        public void RemovePortfolio(Portfolio portfolio)
        {
            if (_listPortfolio.Contains(portfolio))
            {
                _listPortfolio.Remove(portfolio);
            }
            else
            {
                throw new StockExchangeException("doesn't exist");
            }
        }

        public Portfolio GetPortfolioByID(string portfolioId)
        {
            if ((from l in _listPortfolio
                 where l.IdPortfolio == portfolioId
                 select l).Count() > 0)
            {
                Portfolio portfolio = (from l in _listPortfolio
                                       where l.IdPortfolio == portfolioId
                                       select l).First();

                return portfolio;
            }
            else
            {
                throw new StockExchangeException("portfolio doesn't exist");
            }
        }

        public List<Portfolio> GetAllPortfolios()
        {
            return _listPortfolio;
        }
    }

     public class IndexRepository
     {
         private static IndexRepository _instance;
         private List<Index> _listIndex = new List<Index>();

         public static void Reset()
         {
             _instance = null;
         }

         public static IndexRepository GetInstance()
         {
             if (_instance == null)
             {
                 _instance = new IndexRepository();
             }

             return _instance;
         }

         public void AddNewIndex(Index index)
         {
             if ((from l in _listIndex
                  where l.IndexName == index.IndexName
                  select l).Count() > 0)
             {
                 throw new StockExchangeException("Repository contains index");
             }
             _listIndex.Add(index);
         }

         public void RemoveIndex(string indexName)
         {
             Index index = (from l in _listIndex
                            where l.IndexName == indexName
                            select l).First();
             if (index == null)
             {
                 throw new StockExchangeException("Index not found!");
             }

             _listIndex.Remove(index);
         }

         public int Count
         {
             get
             {
                 return _listIndex.Count;
             }
         }

         public bool IndexExists(string indexName)
         {
             if ((from l in _listIndex
                  where l.IndexName == indexName
                  select l).Count() > 0)
             {
                 return true;
             }

             return false;
         }

         public Index GetIndexByName(string indexName)
         {
             Index index = (from l in _listIndex
                            where l.IndexName == indexName
                            select l).First();

             return index;
         }
     }
     #endregion


     public class WeightedIndex : Index
     {
         public WeightedIndex(string indexName)
             : base(indexName)
         {

         }

         public override decimal GetIndexValue()
         {
             throw new NotImplementedException();
         }
     }

     public class StockPrice
     {
         private StockAtStockExchange _stock;
         private Decimal _price;
         private DateTime _timeStamp;

         public DateTime TimeStamp
         {
             get { return _timeStamp; }
             set { _timeStamp = value; }
         }

         public Decimal Price
         {
             get { return _price; }
             set
             {
                 if (value <= 0)
                 {
                     throw new StockExchangeException("Very cheap ;)");
                 }

                 _price = value;
             }
         }

         public StockAtStockExchange Stock
         {
             get { return _stock; }
             set { _stock = value; }
         }

         public StockPrice(StockAtStockExchange stock, Decimal price, DateTime timeStamp)
         {
             Stock = stock;
             Price = price;
             TimeStamp = timeStamp;
         }
     }

     public class StockAtStockExchange
     {
         private Stock _stock;
         private long _numberOfShares;

         public long NumberOfShares
         {
             get { return _numberOfShares; }
             set
             {
                 if (value < 1)
                 {
                     throw new StockExchangeException("<1 ?");
                 }
                 _numberOfShares = value;
             }
         }

         public Stock Stock
         {
             get { return _stock; }
             set { _stock = value; }
         }

         public StockAtStockExchange(Stock stock, long numberOfShares)
         {
             Stock = stock;
             NumberOfShares = numberOfShares;
         }
     }

     public class Stock
     {
         private string _stockName;

         public string StockName
         {
             get { return _stockName; }
             set { _stockName = value; }
         }

         public Stock(string stockName)
         {
             StockName = stockName;
         }
     }

     public class Portfolio
     {
         private string idPortfolio;
         private Dictionary<Stock, int> _listStock = new Dictionary<Stock, int>();

         public string IdPortfolio
         {
             get { return idPortfolio; }
             set { idPortfolio = value; }
         }

         public Portfolio(string portfolioId)
         {
             IdPortfolio = portfolioId;
         }

         internal void AddStockToPortfolio(Stock stock, int amount)
         {
             int currentAmount = NumberOfStocks(stock);

             if (currentAmount > 0)
             {
                 RemoveStockFromPortfolio(stock);
                 _listStock.Add(stock, currentAmount + amount);
             }
             else
             {
                 _listStock.Add(stock, amount);
             }
         }

         internal void RemoveStockFromPortfolio(Stock stock)
         {
             _listStock.Remove(stock);
         }

         internal void RemoveStockFromPortfolio(Stock stock, int amount)
         {
             int currentAmount = NumberOfStocks(stock);

             if (currentAmount < amount)
             {
                 throw new Exception("cannot remove more than exists.");
             }

             if (currentAmount == amount)
             {
                 RemoveStockFromPortfolio(stock);
             }
             if (currentAmount > amount)
             {
                 RemoveStockFromPortfolio(stock);
                 AddStockToPortfolio(stock, currentAmount - amount);
             }
         }

         public int NumberOfStocks(Stock stock)
         {
             int currentAmount = 0;

             _listStock.TryGetValue(stock, out currentAmount);

             return currentAmount;
         }

         public int CountStocks
         {
             get
             {
                 return _listStock.Count;
             }
         }

         public bool StockExistsInPortfolio(Stock stock)
         {
             if (_listStock.ContainsKey(stock))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public Dictionary<Stock, int> GetAllPortfolioStocks()
         {
             return _listStock;
         }
     }

     public abstract class Index
     {
         private string _indexName;
         protected List<StockAtStockExchange> _listStocks = new List<StockAtStockExchange>();

         internal string IndexName
         {
             get { return _indexName; }
             set { _indexName = value; }
         }

         public Index(string indexName)
         {
             IndexName = indexName;
         }

         public void AddStockToIndex(StockAtStockExchange stock)
         {
             if (_listStocks.Contains(stock))
             {
                 throw new StockExchangeException("Stock exists in index");
             }

             _listStocks.Add(stock);
         }

         public void RemoveStockFromIndex(StockAtStockExchange stock)
         {
             if (_listStocks.Contains(stock))
             {
                 _listStocks.Remove(stock);
             }
             else
             {
                 throw new StockExchangeException("Stock not found in Index");
             }
         }

         public bool IsStockPartOfIndex(string stockName)
         {
             if ((from l in _listStocks
                  where l.Stock.StockName == stockName
                  select l).Count() > 0)
             {
                 return true;
             }

             return false;
         }

         public abstract Decimal GetIndexValue();

         public int CountStocks()
         {
             return _listStocks.Count;
         }

         public List<StockAtStockExchange> GetAllStocks()
         {
             return _listStocks;
         }
     }

     public class AverageIndex : Index
     {
         public AverageIndex(string indexName)
             : base(indexName)
         {

         }

         public override decimal GetIndexValue()
         {
             return 0;
         }
     }

     #region Factories
     public class IndexFactory
     {
         public static Index CreateIndex(string indexName, IndexTypes indexType)
         {
             if (indexType == IndexTypes.AVERAGE)
             {
                 return new AverageIndex(indexName);
             }
             else
                 if (indexType == IndexTypes.WEIGHTED)
                 {
                     return new WeightedIndex(indexName);
                 }
                 else
                 {
                     throw new StockExchangeException("Index type error");
                 }
         }
     }
     #endregion
}
