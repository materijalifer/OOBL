﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Dionica> listaDionica = new List<Dionica>();
        private List<Indeks> listaIndeksa = new List<Indeks>();
        private List<Portfelj> listaPortfelja = new List<Portfelj>();

        private Dionica PronadjiDionicu(string inStockName)
        {
            Dionica trazenaDionica = listaDionica.Find(delegate(Dionica d) { return d.InStockName == inStockName.ToUpper(); });
            return trazenaDionica;
        }

        private Portfelj PronadjiPortfelj (string inPortfolioId)
        {
            Portfelj trazeniPortfelj = listaPortfelja.Find(delegate(Portfelj p){return p.InPortfolioId == inPortfolioId;});
            return trazeniPortfelj;
        }

        private Indeks PronadjiIndeks(string inIndexName)
        {
            Indeks trazeniIndeks = listaIndeksa.Find(delegate(Indeks i) {return i.InIndexName == inIndexName.ToUpper();});
            return trazeniIndeks;
        }

        private void IzbrisiDionicuIzIndeksa(string inStockName)
        {
            foreach (var indeks in listaIndeksa)
            {
                if (indeks.PronadjiDionicu(inStockName))
                    indeks.IzbrisiDionicu(inStockName);
            }
        }

        private void IzbrisiDionicuIzPortfelja(string inStockName)
        {
            foreach (var portfelj in listaPortfelja)
            {
                if (portfelj.PronadjiDionicu(inStockName) != null)
                    portfelj.UkloniDionicu(inStockName);
            }
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if ((inInitialPrice <= 0) || (inNumberOfShares <= 0))
                throw new StockExchangeException("Navedena cijena i/ili broj dionica je negativna vrijednost.");
            else
            {
                if (PronadjiDionicu(inStockName) == null)
                {
                    var novaDionica = new Dionica(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
                    listaDionica.Add(novaDionica);
                }
                else
                {
                    throw new StockExchangeException("Dionica pod tim imenom već postoji.");
                }   
            }            
        }        

        public void DelistStock(string inStockName)
        {
            listaDionica.Remove(PronadjiDionicu(inStockName));
            IzbrisiDionicuIzIndeksa(inStockName);
            IzbrisiDionicuIzPortfelja(inStockName);
        }

        public bool StockExists(string inStockName)
        {            
            if (PronadjiDionicu(inStockName) == null)
                return false;
            else
                return true;
        }

        public int NumberOfStocks()
        {
            return listaDionica.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
                throw new StockExchangeException("Cijena dionice krivo definirana.");
            var dionica = PronadjiDionicu(inStockName);
            if(dionica != null)
                dionica.DodajCijenuDionice(inTimeStamp, inStockValue);
            else
                throw new StockExchangeException("Dionica ne postoji.");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            decimal cijena = dionica.DohvatiCijenu(inTimeStamp);
            if (cijena>0)
                return cijena;
            throw new StockExchangeException("Ne postoji cijena u zadanom trenutku.");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            var dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            return dionica.InInitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            var dionica = PronadjiDionicu(inStockName);
            if(dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            return dionica.DohvatiZadnjuCijenu();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType.Equals(IndexTypes.AVERAGE) || inIndexType.Equals(IndexTypes.WEIGHTED))
            {
                if (PronadjiIndeks(inIndexName) == null)
                {
                    var noviIndeks = new Indeks(inIndexName.ToUpper(), inIndexType);
                    listaIndeksa.Add(noviIndeks);
                }
                else
                {
                    throw new StockExchangeException("Indeks pod tim imenom već postoji.");
                }
            }
            else
            {
                throw new StockExchangeException("Krivi tip indeksa.");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var indeks = PronadjiIndeks(inIndexName);
            if (indeks == null)
                throw new StockExchangeException("Indeks ne postoji.");
            var dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
                throw new StockExchangeException("Dionica nije definirana na burzi.");
            indeks.DodajDionicu(inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var indeks = PronadjiIndeks(inIndexName);
            if (indeks == null)
                throw new StockExchangeException("Indeks ne postoji.");
            indeks.UkloniDionicu(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var indeks = PronadjiIndeks(inIndexName);
            if (indeks==null)
                throw new StockExchangeException("Indeks ne postoji.");
            return indeks.PronadjiDionicu(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var indeks = PronadjiIndeks(inIndexName);
            if (indeks == null)
                throw new StockExchangeException("Indeks ne postoji.");
            return TriDecimale(indeks.IzracunajVrijednostIndeksa(inTimeStamp, listaDionica));
        }

        public bool IndexExists(string inIndexName)
        {
            if(PronadjiIndeks(inIndexName) == null)
                return false;
            else
                return true;
        }

        public int NumberOfIndices()
        {
            return listaIndeksa.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            var indeks = PronadjiIndeks(inIndexName);
            if (indeks == null)
                throw new StockExchangeException("Indeks ne postoji.");
            return indeks.BrojDionica();
        }

        public void CreatePortfolio(string inPortfolioId)
        {
            var portfelj = new Portfelj(inPortfolioId);
            var stariPortfelj = PronadjiPortfelj(inPortfolioId);
            if (stariPortfelj != null)
                throw new StockExchangeException("Portfelj zadanog imena već postoji.");
            listaPortfelja.Add(portfelj);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if(portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            var dionica = PronadjiDionicu(inStockName);
            if(dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            if ( dionica.DohvatiKolicinu() < (dionica.BrojIzdanihDionica + numberOfShares))
                throw new StockExchangeException("Nema dovoljno dionica na raspolaganju.");
            else
            {
                dionica.ProdajBrojDionica(numberOfShares);
                portfelj.DodajDionicu(inStockName, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            if (dionica.BrojIzdanihDionica < numberOfShares)
                throw new StockExchangeException("Pogreska.");
            else
            {
                dionica.VratiDionice(numberOfShares);
                portfelj.UkloniDionicu(inStockName, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            var dionica = PronadjiDionicu(inStockName);
            if (dionica == null)
                throw new StockExchangeException("Dionica ne postoji.");
            int brojOslobodjenihDionica = portfelj.UkloniDionicu(inStockName);
            dionica.VratiDionice(brojOslobodjenihDionica);
        }

        public int NumberOfPortfolios()
        {
            return listaPortfelja.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            return portfelj.BrojDionica();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj != null)
                return true;
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            if (portfelj.PronadjiDionicu(inStockName) != null)
                return true;
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            if (portfelj.PrebrojiDionice(inStockName) <=0)
                throw new StockExchangeException("Ne postoji dionica u portfeljeu.");
            else
            {
                return portfelj.PrebrojiDionice(inStockName);
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            return TriDecimale(portfelj.IzracunajVrijednost(listaDionica, timeStamp));           
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var portfelj = PronadjiPortfelj(inPortfolioID);
            if (portfelj == null)
                throw new StockExchangeException("Portfelj ne postoji.");
            return TriDecimale(portfelj.IzracunajMjesecnuPromjenu(listaDionica, Year, Month));
           
        }

        private decimal TriDecimale (decimal broj)
        {
            return Math.Round(broj, 3);
        }
    }

    public class Dionica
    {
        public string InStockName { get; set; }
        public long InNumberOfShares { get; set; }
        public decimal InInitialPrice { get; set; }
        public DateTime InTimeStamp { get; set; }
        public long BrojIzdanihDionica { get; set; }
        private List<CijenaDionice> ListaCijenaDionice = new List<CijenaDionice>();

        public Dionica(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            InStockName = inStockName;
            InNumberOfShares = inNumberOfShares;
            InInitialPrice = inInitialPrice;
            InTimeStamp = inTimeStamp;
            BrojIzdanihDionica = 0;
        }

        public void DodajCijenuDionice(DateTime inTimeStamp, decimal inStockValue)
        {
            var cijenaZaTimeStamp = ListaCijenaDionice.Find(delegate(CijenaDionice c) { return c.InTimeStamp == inTimeStamp; });
            if (cijenaZaTimeStamp == null)
            {
                var cijenaDionice = new CijenaDionice(inTimeStamp, inStockValue);
                ListaCijenaDionice.Add(cijenaDionice);
            }
            else
                throw new StockExchangeException("Cijena za zadano vrijeme već postoji.");
        }
      
        public decimal DohvatiCijenu(DateTime inTimeStamp)
        {            
            for (int i = ListaCijenaDionice.Count() -1; i>=0; i--)
            {
                if (ListaCijenaDionice[i].InTimeStamp <= inTimeStamp)
                    return ListaCijenaDionice[i].InStockValue;
            }
            return InInitialPrice;
        }

        public decimal DohvatiZadnjuCijenu()
        {
            DateTime zadnjaVremenksaOznaka = ListaCijenaDionice[0].InTimeStamp;
            foreach (var cijenaDionice in ListaCijenaDionice)
            {
                if (cijenaDionice.InTimeStamp > zadnjaVremenksaOznaka)
                    zadnjaVremenksaOznaka = cijenaDionice.InTimeStamp;
            }
            return
                ListaCijenaDionice.Find(delegate(CijenaDionice c) { return c.InTimeStamp == zadnjaVremenksaOznaka; }).
                    InStockValue;
        }

        public long DohvatiKolicinu()
        {
            return InNumberOfShares;
        }

        public void ProdajBrojDionica(int numberOfShares)
        {
            BrojIzdanihDionica = BrojIzdanihDionica + numberOfShares;
        }

        public void VratiDionice(int numberOfShares)
        {
            BrojIzdanihDionica = BrojIzdanihDionica - numberOfShares;
        }
    }

    public class CijenaDionice
    {
        public DateTime InTimeStamp { get; set; }
        public decimal InStockValue { get; set; }

        public CijenaDionice(DateTime inTimeStamp, decimal inStockValue)
        {
            InTimeStamp = inTimeStamp;
            InStockValue = inStockValue;
        }
    }

    public class Indeks
    {
        public string InIndexName { get; set; }
        public IndexTypes InIndexType { get; set; }
        private List<string> ListaDionicaIndeksa = new List<string>();

        public Indeks(string inIndexName, IndexTypes inIndexType)
        {
            InIndexName = inIndexName;
            InIndexType = inIndexType;
        }

        public void DodajDionicu(string inStockName)
        {
            string postojiDionicaPodImenom = ListaDionicaIndeksa.Find(delegate(string d) { return d == inStockName.ToUpper(); });
            if (postojiDionicaPodImenom == null)
            {
                ListaDionicaIndeksa.Add(inStockName.ToUpper());
            }
            else
                throw new StockExchangeException("Dionica pod zadanim imenom se već nalazi u indeksu.");
        }

        public void UkloniDionicu(string inStockName)
        {
            ListaDionicaIndeksa.Remove(inStockName.ToUpper());
        }

        public bool PronadjiDionicu(string inStockName)
        {
            if (ListaDionicaIndeksa.Find(delegate(string d) { return d == inStockName.ToUpper(); }) != null)
                return true;
            return false;
        }

        public void IzbrisiDionicu(string inStockName)
        {
            ListaDionicaIndeksa.Remove(inStockName.ToUpper());
        }

        public int BrojDionica()
        {
            return ListaDionicaIndeksa.Count();
        }

        public decimal IzracunajVrijednostIndeksa(DateTime inTimeStamp, List<Dionica> listaDionica)
        {
            if (InIndexType.Equals(IndexTypes.AVERAGE))
            {
                decimal ukupnaVrijednost = 0;
                foreach (var dionica in ListaDionicaIndeksa)
                {
                    ukupnaVrijednost = ukupnaVrijednost +
                                       listaDionica.Find(delegate(Dionica d) { return d.InStockName == dionica; }).
                                           DohvatiCijenu(inTimeStamp);
                }
                return ukupnaVrijednost / ListaDionicaIndeksa.Count();
            }
            else if (InIndexType.Equals(IndexTypes.WEIGHTED))
            {
                decimal vrijednostSvihDionica = 0;
                foreach (var nazivDionice in ListaDionicaIndeksa)
                {
                    var dionica = listaDionica.Find(delegate(Dionica d) { return d.InStockName == nazivDionice; });
                    vrijednostSvihDionica = vrijednostSvihDionica + dionica.DohvatiCijenu(inTimeStamp) * dionica.DohvatiKolicinu();
                }
                decimal vrijednostIndeksa = 0;
                foreach (var nazivDionice in ListaDionicaIndeksa)
                {
                    var dionica = listaDionica.Find(delegate(Dionica d) { return d.InStockName == nazivDionice; });
                    vrijednostIndeksa = vrijednostIndeksa +
                                        dionica.DohvatiCijenu(inTimeStamp) * dionica.DohvatiKolicinu() *
                                        dionica.DohvatiCijenu(inTimeStamp) / vrijednostSvihDionica;
                }
                return vrijednostIndeksa;
            }
            else return 0;
        }
    }

    public class Portfelj
    {
        public string InPortfolioId { get; set; }
        private List<DionicaPortfelja> listaDionicaPortfelja = new List<DionicaPortfelja>();

        public Portfelj(string inPortfolioId)
        {
            InPortfolioId = inPortfolioId;
        }

        public void DodajDionicu(string inStockName, int numberOfShares)
        {
            var dionicaPortfelja = PronadjiDionicu(inStockName);
            if (dionicaPortfelja != null)
            {
                dionicaPortfelja.DodajDionice(numberOfShares);
            }
            else
            {
                dionicaPortfelja = new DionicaPortfelja(inStockName, numberOfShares);
                listaDionicaPortfelja.Add(dionicaPortfelja);
            }
        }

        public DionicaPortfelja PronadjiDionicu(string inStockName)
        {
            DionicaPortfelja dionicaPortfelja = listaDionicaPortfelja.Find(delegate(DionicaPortfelja d) { return d.NazivDionice == inStockName; });
            return dionicaPortfelja;
        }

        public int PrebrojiDionice(string inStockName)
        {
            return PronadjiDionicu(inStockName).BrojDionica;
        }

        public int BrojDionica()
        {
            return listaDionicaPortfelja.Count();
        }

        public void UkloniDionicu(string inStockName, int numberOfShares)
        {
            var dionicaPortfelja = PronadjiDionicu(inStockName);
            dionicaPortfelja.UkloniDionice(numberOfShares);
            if (dionicaPortfelja.BrojDionica == 0)
                listaDionicaPortfelja.Remove(dionicaPortfelja);
        }

        public int UkloniDionicu(string inStockName)
        {
            var dionicaPortfelja = PronadjiDionicu(inStockName);
            int brojDionica = dionicaPortfelja.BrojDionica;
            listaDionicaPortfelja.Remove(dionicaPortfelja);
            return brojDionica;
        }

        public decimal IzracunajVrijednost(List<Dionica> listaDionica, DateTime timeStamp)
        {
            decimal vrijednost = 0;
            foreach (var dionicaPortfelja in listaDionicaPortfelja)
            {
                var dionica = listaDionica.Find(delegate(Dionica d) { return d.InStockName == dionicaPortfelja.NazivDionice; });
                vrijednost = vrijednost + dionica.DohvatiCijenu(timeStamp)*dionicaPortfelja.BrojDionica;
            }
            return vrijednost;
        }

        public decimal IzracunajMjesecnuPromjenu(List<Dionica> listaDionica, int year, int month)
        {
            decimal vrijednostNaPocetkuMjeseca = 0;
            decimal vrijednostNaKrajuMjeseca = 0;
            foreach (var dionicaPortfelja in listaDionicaPortfelja)
            {
                var dionica = listaDionica.Find(delegate(Dionica d) { return d.InStockName == dionicaPortfelja.NazivDionice; });
                DateTime datumPocetkaMjeseca = new DateTime(year, month, 1, 0, 0, 0);
                DateTime datumKrajaMjeseca = new DateTime(year, month, DateTime.DaysInMonth(year,month), 23, 59, 59, 999);
                vrijednostNaKrajuMjeseca = vrijednostNaKrajuMjeseca +
                                           dionica.DohvatiCijenu(datumKrajaMjeseca)*dionicaPortfelja.BrojDionica;
                vrijednostNaPocetkuMjeseca = vrijednostNaPocetkuMjeseca +
                                             dionica.DohvatiCijenu(datumPocetkaMjeseca)*dionicaPortfelja.BrojDionica;
            }
            return (vrijednostNaPocetkuMjeseca + vrijednostNaKrajuMjeseca)/vrijednostNaPocetkuMjeseca*100;
        }
    }

    public class DionicaPortfelja
    {        
        public string NazivDionice { get; set; }
        public int BrojDionica { get; set; }

        public DionicaPortfelja(string inStockName, int numberOfShares)
        {
            NazivDionice = inStockName;
            BrojDionica = numberOfShares;
        }

        public void DodajDionice(int numberOfShares)
        {
            BrojDionica = BrojDionica + numberOfShares;
        }

        public void UkloniDionice(int numberOfShares)
        {
            if(BrojDionica > numberOfShares)
                BrojDionica = BrojDionica - numberOfShares;
            else
            {
                throw new StockExchangeException("Nedovoljan broj dionica u portfeljeu.");
            }
        }

    }

}
