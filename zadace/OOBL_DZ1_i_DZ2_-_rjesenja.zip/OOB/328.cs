﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
    /// <summary>
    /// Opis rješenja, ideje za bolju implementaciju i tako to. 
    ///     Glavne apstrakcije koje opisuju entitete sustava su: Stock, StockIndex, Portofolio, StockPrice. 
    ///     Kako bi se postigla određena modularnost sustava uvedene su dodatne 3 klase: PortofolioHelper, StockHelper, StockIndexHelper.
    ///     One su određene managerske klase nad kolekcijom entiteta, tj. same po sebi predstavljaju kolekciju Index-a, Stock-a i StockPrice-ova, kao i 
    ///     skup funkcionalnosti  (logike) koje nastoje u određenoj mjeri očuvati integritet tih kolekcija. 
    ///     Možemo reći: pomoćne klase za dohvaćanje i spremanje entiteta u kolekcije. Odtud i "Helper" dio u nazivu. 
    ///     Glavni implementacijski razred StockExchange koristi usluge ta 3 razreda pri implementaciji logike burze.
    ///     
    ///     Razlog za takvo rješenje IMHO ću reći da mi se to nekako čini najoptimalnije s obzirom na opseg / doseg zadaće. 
    ///     U stvarnom svijetu, tj. da pravim sličan projekt iz nule, tj. nemam definirano sučelje tipa IStockExchange sa 10 000 metoda za implemenirati na jednom mjestu, 
    ///     stvari bi bile malo drugačije. Potojalo bi par sučelja, tj. klasa koje implementiraju to sučelje koje opisuju operacije nad Stock, StockPrice, Index i Portofolio objektima, 
    ///     te same u sebi implementiraju tražene slične funkcionalnosti. Dakle, umjesto jedne velike StockExchange klase (jednog velikog IStockExchange sučelja), 
    ///     imao bih više malih sučelja grupiranih po funkcionalnostima, te neku glavnu klasu koja delegira operacije prema podmodulima. Recimo. Ovisi, naravno. Stoga, 
    ///     ovdje nisam htio praviti neke velike podmodule, nego pametnije mi je djelovalo napraviti 3 klase sa najpotrebnijim operacijama koje se koriste u StockExchange klasi. Rezultat
    ///     je da svaka metoda u svojoj implementaciji mora vrlo malo toga činiti te vrlo lako se isprogramira logika svake od metoda. Helper obavljaju dohvat ili postavljanje 
    ///     stvari, a metode u StockExchange se brinu samo o sržu logike koju ta metoda treba implementirati. Broj linija u metodama StockExchange govori sam za sebe :P
    /// 
    /// Ideje za bolje rješenje: 
    ///     nemam ih. Sretan sam sa ovim rješenjem, za razliku od prve DZ. Da imam "milijun vremena" opet bih ovako napravio. :) 
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private StockHelper stockHelper = new StockHelper();
        private StockIndexHelper indexHelper = new StockIndexHelper();
        private PortofolioHelper portofolioHelper = new PortofolioHelper();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            stockHelper.AddStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            Stock stock = stockHelper.GetStock(inStockName); // throws exception if not exists
            // try remove stock
            if (!stockHelper.RemoveStock(stock))
            {
                throw new StockExchangeException("Stock cannot be deleted!");
            }
            // remove stock from indexes
            foreach (StockIndex stockIndex in indexHelper.IndexList)
            {
                stockIndex.Stocks.Remove(stock);
            }
            // remove stock from portofolios
            foreach (Portofolio p in portofolioHelper.Portofolios)
            {
                if (p.Stocks.ContainsKey(stock))
                {
                    p.Stocks.Remove(stock);
                }
            }
        }

        public bool StockExists(string inStockName)
        {
            return stockHelper.TryGetStock(inStockName) != null;
        }

        public int NumberOfStocks()
        {
            return stockHelper.Stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = stockHelper.GetStock(inStockName);
            stock.AddStockPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = stockHelper.GetStock(inStockName);

            // check initial
            if (stock.InitialPriceTimeStamp > inTimeStamp)
            {
                throw new StockExchangeException("Time error");
            }

            StockPrice finalPrice = null;
            foreach (StockPrice price in stock.Prices)
            {
                if (inTimeStamp > price.Time)
                {
                    finalPrice = price;
                }
            }

            if (finalPrice == null)
            {
                return stock.InitialPrice;
            }
            return finalPrice.Value;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = stockHelper.GetStock(inStockName);
            return stock.InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = stockHelper.GetStock(inStockName);
            if (stock.Prices.Count == 0)
            {
                return stock.InitialPrice;
            }
            return stock.Prices.Last().Value;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            indexHelper.AddIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            StockIndex index = indexHelper.GetIndex(inIndexName);
            Stock stock = stockHelper.GetStock(inStockName);
            if (index.Stocks.Contains(stock))
            {
                throw new StockExchangeException("Already in index");
            }
            index.Stocks.Add(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            StockIndex index = indexHelper.GetIndex(inIndexName);
            Stock stock = stockHelper.GetStock(inStockName);
            if (!index.Stocks.Contains(stock))
            {
                throw new StockExchangeException("Not in index");
            }
            index.Stocks.Remove(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            StockIndex index = indexHelper.GetIndex(inIndexName);
            Stock stock = stockHelper.GetStock(inStockName);
            return index.Stocks.Contains(stock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            StockIndex index = indexHelper.GetIndex(inIndexName);
            int stockCount = index.Stocks.Count;

            if (stockCount == 0)
            {
                return 0;
            }
            // weighted
            if (index.Type == IndexTypes.WEIGHTED)
            {
                decimal totalSum = 0;
                foreach (Stock stock in index.Stocks)
                {
                    StockPrice price = stock.GetStockPrice(inTimeStamp);
                    if (price != null)
                    {
                        totalSum += stock.NumberOfShares * price.Value;
                    }

                }
                decimal result = 0;
                foreach (Stock stock in index.Stocks)
                {
                    StockPrice price = stock.GetStockPrice(inTimeStamp);
                    if (price != null)
                    {
                        result += (stock.NumberOfShares * price.Value * price.Value / totalSum);
                    }

                }
                return decimal.Round(result, 3);
            }
            else 
            {
                // average
                decimal stockValueSum = 0;
                foreach (Stock stock in index.Stocks)
                {
                    stockValueSum += GetStockPrice(stock.Name, DateTime.Now);
                }
                return decimal.Round(stockValueSum / stockCount, 3);
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return indexHelper.TryGetIndex(inIndexName) != null;
        }

        public int NumberOfIndices()
        {
            return indexHelper.IndexList.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            StockIndex index = indexHelper.GetIndex(inIndexName);
            return index.Stocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            portofolioHelper.AddPortofolio(inPortfolioID);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            Stock stock = stockHelper.GetStock(inStockName);

            // calculate taken shares
            long numberTakes = 0;
            foreach (Portofolio p in portofolioHelper.Portofolios)
            {
                if (p.Stocks.ContainsKey(stock))
                {
                    numberTakes += p.Stocks[stock];
                }
            }

            long freeNumber = stock.NumberOfShares - numberTakes;
            if (numberOfShares > 0 && freeNumber >= numberOfShares)
            {
                if (portofolio.Stocks.ContainsKey(stock))
                {
                    portofolio.Stocks[stock] += numberOfShares;
                }
                else
                {
                    portofolio.Stocks[stock] = numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("number of shares error");
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            Stock stock = stockHelper.GetStock(inStockName);

            if (numberOfShares >= 0 && portofolio.Stocks.ContainsKey(stock))
            {
                long numberInPorotoflio = portofolio.Stocks[stock];

                if (numberInPorotoflio == numberOfShares)
                {
                    // complete remove
                    portofolio.Stocks.Remove(stock);
                }
                else if (numberInPorotoflio > numberOfShares)
                {
                    portofolio.Stocks[stock] -= numberOfShares;
                }
                else
                {
                    throw new StockExchangeException("stock  number error");
                }
            }
            else
            {
                throw new StockExchangeException("no stock in portofolio");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            Stock stock = stockHelper.GetStock(inStockName);

            if (portofolio.Stocks.ContainsKey(stock))
                portofolio.Stocks.Remove(stock);
        }

        public int NumberOfPortfolios()
        {
            return portofolioHelper.Portofolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return portofolioHelper.GetPortofolio(inPortfolioID).Stocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portofolioHelper.TryGetPortofolio(inPortfolioID) != null;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            Stock stock = stockHelper.GetStock(inStockName);
            return portofolio.Stocks.ContainsKey(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            Stock stock = stockHelper.GetStock(inStockName);

            if (portofolio.Stocks.ContainsKey(stock))
            {
                return (int)portofolio.Stocks[stock];
            }
            else
            {
                return 0;
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            IEnumerable<Stock> stocks = portofolio.Stocks.Keys.AsEnumerable();

            decimal result = 0;
            foreach (Stock stock in stocks)
            {
                StockPrice price = stock.GetStockPrice(timeStamp);
                if (price != null)
                {
                    result += price.Value * portofolio.Stocks[stock];
                }
            }
            return result;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            DateTime startTime;
            DateTime endTime;
            try
            {
                startTime = new DateTime(Year, Month, 1);
                endTime = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            } catch(Exception e)
            {
                throw new StockExchangeException("");
            }
            
            Portofolio portofolio = portofolioHelper.GetPortofolio(inPortfolioID);
            decimal startValue = 0;
            decimal endValue = 0;
            int pricesCalculated = 0;
            IEnumerable<Stock> stocks = portofolio.Stocks.Keys.AsEnumerable();
            foreach (Stock stock in stocks)
            {
                StockPrice startPrice = stock.GetStockPrice(startTime);
                StockPrice endPrice = stock.GetStockPrice(endTime);
                if (startPrice != null && endPrice != null)
                {
                    startValue += startPrice.Value;
                    endValue += endPrice.Value;
                    pricesCalculated++;
                }
            }

            if (pricesCalculated > 0)
            {
                return decimal.Round((startValue - endValue) / endValue * 100, 3);
            }
            return 0;
        }
    }

    /// <summary>
    /// Stock entity. 
    /// </summary>
    public class Stock
    {
        // stock properties
        public string Name { get; set; }
        public long NumberOfShares { get; set; }
        public Decimal InitialPrice { get; set; }
        public DateTime InitialPriceTimeStamp { get; set; }

        // stock prices (soryted by time ascending)
        public List<StockPrice> Prices { get; private set; }

        public Stock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            // check params integrity 
            if (string.IsNullOrEmpty(name) || numberOfShares <= 0 || initialPrice <= 0)
            {
                throw new StockExchangeException("Stock input error");
            }

            Name = name;
            NumberOfShares = numberOfShares;
            InitialPrice = initialPrice;
            InitialPriceTimeStamp = timeStamp;

            Prices = new List<StockPrice>();
        }

        public void AddStockPrice(DateTime time, Decimal value)
        {
            // check that time is higher than initial timestamp
            if (time < InitialPriceTimeStamp)
            {
                throw new StockExchangeException("Price input eror, must be higher than initial timestamp!");
            }

            // process && check time, time must be unique
            DateTime processedTime = DateTime.Parse(time.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            foreach (StockPrice stockPrice in Prices)
            {
                if (stockPrice.Time == processedTime)
                {
                    throw new StockExchangeException("Price for given time already exists");
                }
            }

            Prices.Add(new StockPrice(processedTime, decimal.Round(value, 3)));
            Prices.Sort();
        }

        /// <summary>
        /// Gets price for given datestamp, otherwise null. Initial price is wrapped in StockPrice object. 
        /// </summary>
        public StockPrice GetStockPrice(DateTime inTimeStamp)
        {
            // check initial
            if (InitialPriceTimeStamp > inTimeStamp)
            {
                return null;
            }

            StockPrice finalPrice = null;
            foreach (StockPrice price in Prices)
            {
                if (inTimeStamp > price.Time)
                {
                    finalPrice = price;
                }
            }

            if (finalPrice == null)
            {
                return new StockPrice(InitialPriceTimeStamp, InitialPrice);
            }
            return finalPrice;
        }
    }

    /// <summary>
    /// Stock price entity. 
    /// </summary>
    public class StockPrice : IComparable<StockPrice>
    {
        public DateTime Time { get; set; }
        public Decimal Value { get; set; }

        public StockPrice(DateTime time, decimal value)
        {
            // check params integrity 
            if (value <= 0)
            {
                throw new StockExchangeException("StockPrice input error");
            }
            Time = time;
            Value = value;
        }

        /// <summary>
        /// Compare based on Time property. 
        /// </summary>
        public int CompareTo(StockPrice other)
        {
            int ret = -1;
            if (Time < other.Time)
                ret = -1;
            else if (Time > other.Time)
                ret = 1;
            else if (Time == other.Time)
                ret = 0;
            return ret;
        }
    }

    /// <summary>
    ///   Collection of Stock with common operations.
    /// </summary>
    public class StockHelper
    {
        private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();

        public IEnumerable<Stock> Stocks
        {
            get { return stocks.Values.AsEnumerable(); }
        }

        public void AddStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string stockIndex = GetCollectionIndex(inStockName);
            // if index is ok, and no such entry already
            if (stockIndex != null && !stocks.ContainsKey(stockIndex))
            {
                Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                stocks.Add(stockIndex, newStock);
            }
            else
            {
                throw new StockExchangeException("Stock input error");
            }

        }

        public bool RemoveStock(Stock stock)
        {
            string index = GetCollectionIndex(stock.Name);
            if (index != null && stocks.ContainsKey(index))
            {
                stocks.Remove(index);
                return true;
            }
            return false;
        }

        public Stock TryGetStock(string stockName)
        {
            string stockIndex = GetCollectionIndex(stockName);
            Stock stock;
            if (stockIndex != null && stocks.TryGetValue(stockIndex, out stock))
            {
                return stock;
            }
            return null;
        }

        public Stock GetStock(string stockName)
        {
            Stock stock = TryGetStock(stockName);
            if (stock != null)
            {
                return stock;
            }
            throw new StockExchangeException("Stock input error");
        }

        public static string GetCollectionIndex(string stockName)
        {
            if (!string.IsNullOrEmpty(stockName))
            {
                return stockName.ToLower();
            }
            return null;
        }
    }

    /// <summary>
    /// Stock index entity. 
    /// </summary>
    public class StockIndex
    {
        public string Name { get; set; }
        public IndexTypes Type { get; set; }

        public List<Stock> Stocks { get; private set; }

        public StockIndex(string name, IndexTypes type)
        {
            // check supported types
            if (type != IndexTypes.WEIGHTED && type != IndexTypes.AVERAGE)
            {
                throw new StockExchangeException("Index type not allowed!");
            }
            Name = name;
            Type = type;

            Stocks = new List<Stock>();
        }
    }

    /// <summary>
    ///   StockIndex collection helper. 
    /// </summary>
    public class StockIndexHelper
    {
        private Dictionary<string, StockIndex> indexList = new Dictionary<string, StockIndex>();

        public IEnumerable<StockIndex> IndexList
        {
            get { return indexList.Values.AsEnumerable(); }
        }

        public void AddIndex(string inStockIndexName, IndexTypes type)
        {
            string index = GetCollectionIndex(inStockIndexName);
            // if index is ok, and no such entry already
            if (index != null && !indexList.ContainsKey(index))
            {
                StockIndex newStock = new StockIndex(inStockIndexName, type);
                indexList.Add(index, newStock);
            }
            else
            {
                throw new StockExchangeException("StockIndex input error");
            }
        }

        public StockIndex TryGetIndex(string inIndexName)
        {
            string indexName = GetCollectionIndex(inIndexName);
            StockIndex stock;
            if (indexName != null && indexList.TryGetValue(indexName, out stock))
            {
                return stock;
            }
            return null;
        }

        public StockIndex GetIndex(string inIndexName)
        {
            StockIndex index = TryGetIndex(inIndexName);
            if (index != null)
            {
                return index;
            }
            throw new StockExchangeException("No such index");
        }

        public static string GetCollectionIndex(string indexName)
        {
            if (!string.IsNullOrEmpty(indexName))
            {
                return indexName.ToLower();
            }
            return null;
        }
    }

    /// <summary>
    /// Portofolio entity.
    /// </summary>
    public class Portofolio
    {
        public string ID { get; set; }
        // stock 
        public Dictionary<Stock, long> Stocks { get; set; }

        public Portofolio(string inPortofolioID)
        {
            if (string.IsNullOrEmpty(inPortofolioID))
            {
                throw new StockExchangeException("Must be set Portofolio ID!");
            }
            ID = inPortofolioID;
            Stocks = new Dictionary<Stock, long>();
        }
    }

    /// <summary>
    /// Portofolio collection helper. 
    /// </summary>
    public class PortofolioHelper
    {
        /// <summary>
        /// ID --> Portofolio
        /// </summary>
        private Dictionary<string, Portofolio> portofolios = new Dictionary<string, Portofolio>();

        public IEnumerable<Portofolio> Portofolios
        {
            get { return portofolios.Values.AsEnumerable(); }
        }

        public void AddPortofolio(string inPortofolioID)
        {
            // ID must be unique && not empty
            if (!string.IsNullOrEmpty(inPortofolioID) && !portofolios.ContainsKey(inPortofolioID))
            {
                Portofolio p = new Portofolio(inPortofolioID);
                portofolios.Add(inPortofolioID, p);
            }
            else
            {
                throw new StockExchangeException("Portofolio input error");
            }
        }

        public Portofolio TryGetPortofolio(string inPortofolioID)
        {
            Portofolio portofolio;
            if (!string.IsNullOrEmpty(inPortofolioID) && portofolios.TryGetValue(inPortofolioID, out portofolio))
            {
                return portofolio;
            }
            return null;
        }

        public Portofolio GetPortofolio(string inPortofolioID)
        {
            Portofolio portofolio = TryGetPortofolio(inPortofolioID);
            if (portofolio != null)
            {
                return portofolio;
            }
            throw new StockExchangeException("Portofolio doesns't exist");
        }
    }
}