﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        //--------------- variables ---------------//

        private string          _stockName;
        private long            _numberOfShares;
        private decimal         _initialPrice;
        private DateTime        _startDate;
        private string          _indexName;
        private int             _inPortfolio;
        private List<string>    _portfolios;

        public PriceHistory     _stockPriceHistory;

        //--------------- methods ---------------//

        public Stock(string name, long number, decimal price, DateTime date)
        {
            this._stockName = name;
            this._numberOfShares = number;
            this._initialPrice = price;
            this._startDate = date;
            this._stockPriceHistory = new PriceHistory(date, price);
            this._indexName = "";
            this._inPortfolio = 0;
            this._portfolios = new List<string>();
        }

        public void AddPrice(DateTime timeStamp, decimal newPrice)
        {
            this._stockPriceHistory.Add(timeStamp, newPrice);
        }
        
        public decimal GetPrice(DateTime timeStamp)
        {
            return _stockPriceHistory.GetPrice(timeStamp);
        }
        
        public long NumberOfShares()
        {
            return this._numberOfShares;
        }
        
        public decimal GetInitialPrice()
        {
            return this._initialPrice;
        }
        
        public void SortDate()
        {
            this._stockPriceHistory.SortDate();
        }
        
        public bool IncludesDate(DateTime time)
        {
            return _stockPriceHistory._priceHistory.ContainsKey(time);
        }
        
        public void AddToIndex(string indexName)
        {
            this._indexName = indexName;
        }
        
        public void RemoveFromIndex()
        {
            this._indexName = "";
        }
        
        public bool NotInIndex()
        {
            return _indexName.Equals("");
        }
        
        public void AddedToPortfolio(string portfolioID, int numberOfStocks)
        {
            this._inPortfolio += numberOfStocks;
            if (!this._portfolios.Contains(portfolioID))
                this._portfolios.Add(portfolioID);
        }
        
        public bool AvalibleStocks(int numberOfStocks)
        {
            if (numberOfStocks <= (_numberOfShares - _inPortfolio))
                return true;
            else
                return false;
        }
        
        public bool IsMonthlyPricesDefined(int Year, int Month)
        {

            if (_stockPriceHistory.GetLatestDate(new DateTime(Year, Month, 1)) <= new DateTime(Year, Month, 1))
            {
                if (_stockPriceHistory.GetLatestDate(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) > new DateTime(Year, Month, 1))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        
        public bool IsInPortfolio()
        {
            if (this._portfolios.Count.Equals(0))
                return false;
            return true;
        }
        
        public string GetIndexName()
        {
            return _indexName;
        }
        
        public List<string> GetPortfolioList()
        {
            return this._portfolios;
        }

    }

    public class Index
    {
        //--------------- variables ---------------//

        string          _name;
        IndexTypes      _type;
        List<string>    _indexStockList;

        //--------------- methods ---------------//

        public Index(string name, IndexTypes t)
        {
            this._name = name;
            this._type = t;
            this._indexStockList = new List<string>();
        }
        
        public void AddStock(string stockName)
        {
            this._indexStockList.Add(stockName);
        }
        
        public bool ContainsStock(string stockName)
        {
            return this._indexStockList.Contains(stockName);
        }
        
        public void RemoveStock(string stockName)
        {
            this._indexStockList.Remove(stockName);
        }
        
        public int NumberOfStocks()
        {
            return this._indexStockList.Count();
        }
        
        public bool IsTypeOf(IndexTypes inType)
        {
            if (inType.Equals(this._type))
                return true;
            else
                return false;
        }
        
        public List<string> GetStockList()
        {
            return this._indexStockList;
        }
    }

    public class Portfolio
    {
        //--------------- variables ---------------//

        string  _id;

        public SortedList<string, int>  _stockList;

        //--------------- methods ---------------//

        public Portfolio(string ID)
        {
            this._id = ID;
            this._stockList = new SortedList<string, int>();
        }
        
        public void AddStock(string inStockName, int numberOfShares)
        {
            if (this.PartOf(inStockName))
                this._stockList[inStockName] += numberOfShares;
            else
                this._stockList.Add(inStockName, numberOfShares);
        }
        
        public void RemoveStock(string inStockName, int numberOfShares)
        {
            this._stockList[inStockName] -= numberOfShares;
        }
        
        public void RemoveStock(string inStockName)
        {
            this._stockList.Remove(inStockName);
        }
        
        public bool PartOf(string inStockName)
        {
            return this._stockList.ContainsKey(inStockName);
        }
        
        public int NumberOfStocks()
        {
            return this._stockList.Keys.Count();
        }
        
        public int NumberOfShares(string inStockName)
        {
            return this._stockList[inStockName];
            
        }

    }

    public class PriceHistory
    {
        //--------------- variables ---------------//

        public SortedList<DateTime, decimal> _priceHistory = new SortedList<DateTime, decimal>();

        //--------------- methods ---------------//

        public PriceHistory(DateTime time, decimal price)
        {
            _priceHistory.Add(time, price);
        }
        
        public void Add(DateTime time, decimal price)
        {
            _priceHistory.Add(time, price);
        }
        
        public decimal GetPrice(DateTime time)
        {
            return _priceHistory[time];
        }
        
        public void SortDate()
        {
            _priceHistory.OrderBy(x => x.Key);
        }
        
        public DateTime GetLatestDate(DateTime inTime)
        {
            DateTime outTime = _priceHistory.Keys.First();
            foreach(DateTime s in _priceHistory.Keys.ToList())
            {
                if ((s - inTime).TotalMilliseconds <= 0)
                    outTime = s;
                else
                    return outTime;
            }
            return outTime;
        }
    }


    public class StockExchange : IStockExchange
    {

        //--------------- variables ---------------//
        //-----------------------------------------//

        SortedList<string, Stock>       _stockList = new SortedList<string, Stock>();
        SortedList<string, Index>       _indexList = new SortedList<string, Index>();
        SortedList<string, Portfolio>   _portfolioList = new SortedList<string, Portfolio>();


        //--------------- methods ---------------//
        //---------------------------------------//

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Dionica s tim imenom vec postoji na burzi!");
            
            else if (inInitialPrice < 0)
                throw new StockExchangeException("Pogreska! Cijena ne moze biti negativna!");
            
            else
                _stockList.Add(inStockName.ToLower(), new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                if (!_stockList[inStockName.ToLower()].NotInIndex())
                    RemoveStockFromIndex(_stockList[inStockName.ToLower()].GetIndexName(), inStockName);
                if (_stockList[inStockName.ToLower()].IsInPortfolio())
                {
                    foreach (string portfolioId in _stockList[inStockName.ToLower()].GetPortfolioList())
                    {
                        RemoveStockFromPortfolio(portfolioId, inStockName.ToLower());
                    }
                }
                _stockList.Remove(inStockName.ToLower());

            }
            else
                throw new StockExchangeException("Pogreska! Dionica koja se zeli maknuti ne postoji na burzi!");
        }

        public bool StockExists(string inStockName)
        {
            return _stockList.ContainsKey(inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return _stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {

            if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Dionica s tim imenom ne postoji na burzi!");

            else if (inStockValue < 0)
                throw new StockExchangeException("Pogreska! Cijena ne moze biti negativna!");

            else
            {
                if (_stockList[inStockName.ToLower()].IncludesDate(inIimeStamp))
                    throw new StockExchangeException("Pogreska! Postoji definirana cijena za taj datum!");
                else
                {
                    _stockList[inStockName.ToLower()].AddPrice(inIimeStamp, inStockValue);
                    _stockList[inStockName.ToLower()].SortDate();
                }
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Dionica s tim imenom ne postoji na burzi!");

            else
            {
                if (_stockList[inStockName.ToLower()].IncludesDate(inTimeStamp))
                    return _stockList[inStockName.ToLower()]._stockPriceHistory.GetPrice(inTimeStamp);

                else
                {
                    DateTime date = _stockList[inStockName.ToLower()]._stockPriceHistory.GetLatestDate(inTimeStamp);
                    if ((date - inTimeStamp).TotalMilliseconds <= 0)
                        return _stockList[inStockName.ToLower()].GetPrice(date);
                    else
                        throw new StockExchangeException("Pogreska! Ne postoji raniji datum cijene!");
                }
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return _stockList[inStockName.ToLower()].GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Dionica s tim imenom ne postoji na burzi!");

            else
            {
                DateTime date = _stockList[inStockName.ToLower()]._stockPriceHistory._priceHistory.Keys.Last();
                return _stockList[inStockName.ToLower()].GetPrice(date);
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
                throw new StockExchangeException("Pogreska! Indeks s tim imenom vec postoji!");

            else if (!inIndexType.Equals(IndexTypes.AVERAGE) && !inIndexType.Equals(IndexTypes.WEIGHTED))
                throw new StockExchangeException("Pogreska! Neispravan tip indeksa!");

            else
                _indexList.Add(inIndexName.ToLower(), new Index(inIndexName.ToLower(), inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Pogreska! Ne postoji indeks!");

            else if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Ne postoji dionica!");

            else if (!_stockList[inStockName.ToLower()].NotInIndex())
                throw new StockExchangeException("Pogreska! Dionica je pridruzena drugom indeksu!");

            else
            {
                _indexList[inIndexName.ToLower()].AddStock(inStockName.ToLower());
                _stockList[inStockName.ToLower()].AddToIndex(inIndexName.ToLower());
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Ne postoji dionica na burzi!");

            else if (!IndexExists(inIndexName))
                throw new StockExchangeException("Pogreska! Ne postoji indeks na burzi!");

            else if (!_indexList[inIndexName.ToLower()].ContainsStock(inStockName.ToLower()))
                throw new StockExchangeException("Pogreska! Ne postoji dionica u indeksu!");

            else
            {
                _indexList[inIndexName.ToLower()].RemoveStock(inStockName.ToLower());
                _stockList[inStockName.ToLower()].RemoveFromIndex();
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return _indexList[inIndexName.ToLower()].ContainsStock(inStockName.ToLower());
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Pogreska! Ne postoji indeks!");

            if (NumberOfStocksInIndex(inIndexName).Equals(0))
                throw new StockExchangeException("Pogreska! Indeks je prazan!");

            if (_indexList[inIndexName.ToLower()].IsTypeOf(IndexTypes.AVERAGE))
            {
                decimal price = 0;
                foreach (string stockName in _indexList[inIndexName.ToLower()].GetStockList())
                {
                    price += GetStockPrice(stockName, inTimeStamp);
                }
                return Math.Round(price / NumberOfStocksInIndex(inIndexName), 3);
            }

            else if (_indexList[inIndexName.ToLower()].IsTypeOf(IndexTypes.WEIGHTED))
            {
                decimal price = 0;
                decimal totalValue = 0;
                foreach (string stockName in _indexList[inIndexName.ToLower()].GetStockList())
                {
                    price += (GetStockPrice(stockName, inTimeStamp) * GetStockPrice(stockName, inTimeStamp)) * _stockList[stockName.ToLower()].NumberOfShares();
                    totalValue += GetStockPrice(stockName, inTimeStamp) * _stockList[stockName.ToLower()].NumberOfShares();
                }
                return Math.Round(price / totalValue, 3);
            }

            throw new StockExchangeException("Pogreska!");
        }

        public bool IndexExists(string inIndexName)
        {
            return _indexList.ContainsKey(inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return _indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return _indexList[inIndexName.ToLower()].NumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Postoji portfelj s tim ID!");
            else 
                _portfolioList.Add(inPortfolioID, new Portfolio(inPortfolioID));

        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Ne postoji portfolio!");

            else if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Ne postoji dionica!");

            else if (!_stockList[inStockName.ToLower()].AvalibleStocks(numberOfShares))
                throw new StockExchangeException("Pogreska! Ne postoji dionica!");

            else if (numberOfShares <= 0)
                throw new StockExchangeException("Pogreska! Ne moze se dodati broj dionica manji ili jednak 0!");

            else
            {
                _portfolioList[inPortfolioID].AddStock(inStockName.ToLower(), numberOfShares);
                _stockList[inStockName.ToLower()].AddedToPortfolio(inPortfolioID, numberOfShares);
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Ne postoji portfolio!");

            else if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Ne postoji dionica!");

            else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                throw new StockExchangeException("Pogreska! Dionica nije u portfoliu!");

            else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
            {
                _portfolioList.Remove(inPortfolioID);
                throw new StockExchangeException("Pogreska! Portfolio je izbrisan jer nema dionica!");
            }

            else if (NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName) < numberOfShares)
                throw new StockExchangeException("Pogreska! Zeli se izbaciti vise udjela dionica nego sto ih ima u portfoliu!");

            else
            {
                _portfolioList[inPortfolioID].RemoveStock(inStockName.ToLower(), numberOfShares);
                if (NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName).Equals(0) && NumberOfStocksInPortfolio(inPortfolioID).Equals(1))
                    _portfolioList.Remove(inPortfolioID);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Ne postoji portfolio!");

            else if (!StockExists(inStockName))
                throw new StockExchangeException("Pogreska! Ne postoji dionica!");

            else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                throw new StockExchangeException("Pogreska! Dionica nije u portfoliu!");

            else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
            {
                _portfolioList.Remove(inPortfolioID);
                throw new StockExchangeException("Pogreska! Portfolio je izbrisan jer nema dionica!");
            }

            else
            {
                _portfolioList[inPortfolioID].RemoveStock(inStockName.ToLower());
                if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
                {
                    _portfolioList.Remove(inPortfolioID);
                }
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return _portfolioList[inPortfolioID].NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolioList.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioList[inPortfolioID].PartOf(inStockName.ToLower());
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return _portfolioList[inPortfolioID].NumberOfShares(inStockName.ToLower());
            
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Ne postoji portfolio!");

            else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
            {
                _portfolioList.Remove(inPortfolioID);
                throw new StockExchangeException("Pogreska! Portfolio je izbrisan jer nema dionica!");
            }

            decimal value = 0;
            foreach (string stockName in _portfolioList[inPortfolioID]._stockList.Keys)
            {
                value += GetStockPrice(stockName, timeStamp) * NumberOfSharesOfStockInPortfolio(inPortfolioID, stockName); ;
            }

            return value;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Pogreska! Ne postoji portfolio!");

            else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
            {
                _portfolioList.Remove(inPortfolioID);
                throw new StockExchangeException("Pogreska! Portfolio je izbrisan jer nema dionica!");
            }

            else if ((Year > DateTime.Today.Year) || ((Month > 12) || (Month < 1) ))
                throw new StockExchangeException("Pogreska! Pogresan datum, nepostojeca godina ili nepostojeci mjesec!");

            decimal oldPrice = 0;
            decimal newPrice = 0;

            foreach (string stockName in _portfolioList[inPortfolioID]._stockList.Keys)
            {
                if (!_stockList[stockName].IsMonthlyPricesDefined(Year, Month))
                    throw new StockExchangeException("Pogreska! Nisu definirane cijene za početak i kraj mjeseca!");

                else
                {
                    oldPrice += GetStockPrice(stockName, new DateTime(Year, Month, 1, 00, 00, 00, 00)) * NumberOfSharesOfStockInPortfolio(inPortfolioID, stockName);
                    newPrice += GetStockPrice(stockName, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) * NumberOfSharesOfStockInPortfolio(inPortfolioID, stockName);
                }

            }
            return Math.Round(100 * ( (newPrice - oldPrice) / oldPrice), 3);
        }

    }
}
