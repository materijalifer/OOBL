﻿using System;
using System.Collections.Generic;
using System.Linq;

// ReSharper disable CheckNamespace
namespace DrugaDomacaZadaca_Burza
// ReSharper restore CheckNamespace
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> _stockList;
         private Dictionary<string, Portfolio> _portofolioList;
         private List<Index> _indexList;

         private class Stock
         {
// ReSharper disable NotAccessedField.Local
             private string _name;
// ReSharper restore NotAccessedField.Local
             private long   _numOfShares;
             private List<PriceHistory> _prices;

             public Stock(string stockName, long numberOfShares, decimal inPrice,
                            DateTime timeStamp)
             {
                 _name = stockName;
                 _numOfShares = numberOfShares;
                 _prices = new List<PriceHistory>();
                 PriceHistory init = new PriceHistory(timeStamp, inPrice);
                 _prices.Add(init);
             }
/*
             public string GetStockName()
             {
                 return _name;
             }
*/
             public long GetStockNumOfShares()
             {
                 return _numOfShares;
             }
             public void SetPrice(DateTime timeStamp, decimal price)
             {
                 bool alreadyDefined = false;
                 if (price < 0)
                     throw new StockExchangeException("Neispravna cijena!");
                 foreach (PriceHistory priceHistory in _prices.Where(priceHistory => priceHistory.GetPriceDate() == timeStamp))
                 {
                     alreadyDefined = true;
                 }
                 if (alreadyDefined)
                     throw new StockExchangeException("Cijena za to vrijeme vec postoji!");
                 PriceHistory newPrice = new PriceHistory(timeStamp, price);
                 _prices.Add(newPrice);
                 _prices = _prices.OrderByDescending(o => o.GetPriceDate()).ToList();
             }

             public decimal GetPriceForDate(DateTime timeStamp)
             {
                 foreach (var priceHistory in _prices.Where(priceHistory => priceHistory.GetPriceDate() <= timeStamp))
                 {
                     return priceHistory.GetPrice();
                 }
                 throw new StockExchangeException("Cudna greska!");
             }
             public decimal GetOldestPrice()
             {
                 return _prices[_prices.Count - 1].GetPrice();
             }

             public decimal GetNewestPrice()
             {
                 return _prices[0].GetPrice();
             }

             private class PriceHistory
             {
                 private DateTime _priceSetOn;
                 private Decimal _price;

                 public PriceHistory(DateTime inTimeStamp, Decimal price)
                 {
                     if (price < 0)
                         throw new StockExchangeException("Negativna cijena!");
                     _priceSetOn = inTimeStamp;
                     _price = price;
                 }

                 public DateTime GetPriceDate()
                 {
                     return _priceSetOn;
                 }

                 public Decimal GetPrice()
                 {
                     return _price;
                 }
             }
         }

         private class Portfolio
         {
             Dictionary<string, int> _stocksInPortfolio = new Dictionary<string, int>();

             public Portfolio(string portfolioID)
             {
             }

             public void AddSharesToPortfolio(string stockName, int numOfShares)
             {
                 if (numOfShares <= 0) throw new StockExchangeException("Pogreska!");
                 //provjeriti broj dionica, ime i tak to
                 if (_stocksInPortfolio.ContainsKey(stockName))
                 {
                     _stocksInPortfolio[stockName] = _stocksInPortfolio[stockName] + numOfShares;
                 }
                 else
                 {
                     _stocksInPortfolio.Add(stockName, numOfShares);
                 }
             }

             public void RemoveShares(string stockName, int numOfShares)
             {
                 if (!_stocksInPortfolio.ContainsKey(stockName))
                     throw new StockExchangeException("Dionica ne postoji!");
                 int newNumber = _stocksInPortfolio[stockName] - numOfShares;
                 if (newNumber > 0)
                 {
                     _stocksInPortfolio[stockName] = newNumber;
                 }
                 else if (newNumber == 0)
                 {
                     RemoveStock(stockName);
                 }
                 else throw new StockExchangeException("Pogreska kod brisanja dionica!");
             }

             public void RemoveStock(string stockName)
             {
                 _stocksInPortfolio.Remove(stockName);
             }

             public bool StockExistInIndex(string stockName)
             {
                 return _stocksInPortfolio.ContainsKey(stockName);
             }

             public int NumOfStockInPortoflio()
             {
                 return _stocksInPortfolio.Count;
             }

             public int NumOfSharesOfStockInPortfolio(string stockName)
             {
                 return _stocksInPortfolio[stockName];
             }
         }

         private class Index
         {
             private string _indexName;
             private IndexTypes _indexType;
             private List<string> _stocks;
             //private int _numOfStocks;

             public Index(string indexName, IndexTypes indexType)
             {
                 //_numOfStocks = 0;
                 _stocks = new List<string>();
                 if (indexName != null) _indexName = indexName;
                 else throw new StockExchangeException("Neispravno ime indeksa");

                 if (indexType == IndexTypes.AVERAGE || indexType == IndexTypes.WEIGHTED)
                     _indexType = indexType;
                 else
                     throw new StockExchangeException("Neispravan indeks!");
             }

             public string GetIndexName()
             {
                 return _indexName;
             } 
             
             public void AddStockToIndeks(string stockName)
             {
                 if (stockName != null) _stocks.Add(stockName);
                 else throw new StockExchangeException("Neispravno ime dionice");
             }
             
             public bool RemoveStockFromIndeks(string stockName)
             {
                 return _stocks.Remove(stockName);
             }

             public bool StockExistsinIndex(string stockName)
             {
                 return _stocks.Contains(stockName);
             }

             public int CountStocks()
             {
                 return _stocks.Count();
             }

             public IndexTypes GetIndexType()
             {
                 return _indexType;
             }
         }

         public StockExchange()
         {
             _stockList = new Dictionary<string, Stock>();
             _portofolioList = new Dictionary<string, Portfolio>();
             _indexList = new List<Index>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (_stockList.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Postoji dionica s jednakim imenom");
             }
             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Krivi broj dionica");
             if (inInitialPrice <= 0)
                 throw new StockExchangeException("Neispravna cijena!");
             Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             _stockList.Add(inStockName, newStock);
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (_stockList != null && _stockList.ContainsKey(inStockName))
             {
                 _stockList.Remove(inStockName);
                 foreach (Index index in _indexList)
                 {
                     if (index.StockExistsinIndex(inStockName))
                         index.RemoveStockFromIndeks(inStockName);
                 }
                 foreach (KeyValuePair<string, Portfolio> keyValuePair in _portofolioList)
                 {
                     if(keyValuePair.Value.StockExistInIndex(inStockName))
                         keyValuePair.Value.RemoveStock(inStockName);
                 }
             }
             else throw new StockExchangeException("Dionica ne postoji!");
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             return _stockList.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToUpper();
             if (_stockList.ContainsKey(inStockName))
             {
                 _stockList[inStockName].SetPrice(inIimeStamp, inStockValue);
             }
             else throw new StockExchangeException("Ne postoji dionica!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (!_stockList.ContainsKey(inStockName))
                 throw new StockExchangeException("Dionica ne postoji!");
             return _stockList[inStockName].GetPriceForDate(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!_stockList.ContainsKey(inStockName))
                 throw new StockExchangeException("Dionica ne postoji!");
             return _stockList[inStockName].GetOldestPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!_stockList.ContainsKey(inStockName))
                 throw new StockExchangeException("Dionica ne postoji!");
             return _stockList[inStockName].GetNewestPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToUpper();
             Index newIndex = new Index(inIndexName, inIndexType);
             if (!_indexList.Contains(newIndex))
                 _indexList.Add(newIndex);
             else
             {
                 throw new StockExchangeException("Indeks vec postoji!");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             try
             {
                 Index indeks = _indexList.Find(item => item.GetIndexName() == inIndexName);
                 if (indeks == null) throw new ArgumentNullException("inIndexName");
                 if (_stockList.ContainsKey(inStockName) && !indeks.StockExistsinIndex(inStockName))
                     indeks.AddStockToIndeks(inStockName);
                 else
                     throw new StockExchangeException("Dionica ne postoji!");
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Greska kod dodavanja dionice u indeks");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             try
             {
                 Index indeks = _indexList.Find(item => item.GetIndexName() == inIndexName);
                 if (indeks == null) throw new ArgumentNullException("inIndexName");
                 if (!indeks.RemoveStockFromIndeks(inStockName))
                     throw new StockExchangeException("Greska kod brisanja!");
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Greska kod dodavanja dionice u indeks");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             Index temp = _indexList.Find(item => item.GetIndexName() == inIndexName);
             return temp.StockExistsinIndex(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();
             Index indeks = _indexList.Find(item => item.GetIndexName() == inIndexName);
             decimal value = 0;
             int j = 0;
             //string[] stocks = new string[_stockList.Count];
             long[] numShares = new long[indeks.CountStocks()];
             decimal[] prices = new decimal[indeks.CountStocks()];

             
             for (int i = 0; i < _stockList.Count; i++)
             {
                 if (indeks.StockExistsinIndex(_stockList.Keys.ElementAt(i)))
                 {
                     //stocks[j] = _stockList.Keys.ElementAt(i);
                     numShares[j] = _stockList[_stockList.Keys.ElementAt(i)].GetStockNumOfShares();
                     prices[j] = _stockList[_stockList.Keys.ElementAt(i)].GetPriceForDate(inTimeStamp);
                     j++;
                 }
             }
             if (indeks.GetIndexType() == IndexTypes.AVERAGE)
             {
                 value += prices.Sum();
                 if (prices.Count()!=0)
                     value /= prices.Count();
             }
             else if (indeks.GetIndexType() == IndexTypes.WEIGHTED)
             {
                 decimal maxValue = 0;
                 for (int c = 0; c < prices.Count(); c++)
                 {
                     maxValue += prices[c] * numShares[c];
                 }
                 for (int c = 0; c < prices.Count(); c++)
                 {
                     value += numShares[c]*prices[c]*(prices[c]/maxValue);
                 }
             }
             return Math.Round(value, 3);
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             Index temp = _indexList.Find(item => item.GetIndexName() == inIndexName);
             return temp != null;
         }

         public int NumberOfIndices()
         {
             return _indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             Index indeks = _indexList.Find(item => item.GetIndexName() == inIndexName);
             if (indeks != null)
             {
                 return indeks.CountStocks();
             }
             throw new StockExchangeException("Nepostojeci indeks!");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio newPortfolio = new Portfolio(inPortfolioID);
             try
             {
                 if (!_portofolioList.ContainsKey(inPortfolioID))
                     _portofolioList.Add(inPortfolioID, newPortfolio);
                 else
                     throw new StockExchangeException("Portfolio vec postoji!");
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Pogreska kod stvaranja portfolia!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             try
             {
                Portfolio portfolio;
                 if (_portofolioList == null || !_portofolioList.TryGetValue(inPortfolioID, out portfolio)) 
                     throw new StockExchangeException("Pogreska!");
                 if (portfolio == null)
                     throw new Exception();
                 if (_stockList.ContainsKey(inStockName) &&
                     numberOfShares <= _stockList[inStockName].GetStockNumOfShares())
                 {
                     if (CountShares(inStockName) + numberOfShares <= _stockList[inStockName].GetStockNumOfShares())
                         portfolio.AddSharesToPortfolio(inStockName, numberOfShares);                    
                 }
                 else throw new Exception();
             }
             catch (Exception)
             {
                 throw new StockExchangeException("Greska kod dodavanja dionica u portfolio!");
             }
         }

         private int CountShares(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             return _portofolioList.Where(keyValuePair => keyValuePair.Value.StockExistInIndex(inStockName)).Sum(keyValuePair => keyValuePair.Value.NumOfSharesOfStockInPortfolio(inStockName));
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             _portofolioList[inPortfolioID].RemoveShares(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             _portofolioList[inPortfolioID].RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _portofolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio tempPortfolio;
             if (_portofolioList.TryGetValue(inPortfolioID, out tempPortfolio))
             {
                 return tempPortfolio.NumOfStockInPortoflio();
             }
             throw new StockExchangeException("Greska!!!");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portofolioList.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             Portfolio tempPortfolio;
             return _portofolioList.TryGetValue(inPortfolioID, out tempPortfolio) && tempPortfolio.StockExistInIndex(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             return _portofolioList[inPortfolioID].NumOfSharesOfStockInPortfolio(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal value = 0;
             for (int i = 0; i < _stockList.Count; i++)
             {
                 if (_portofolioList[inPortfolioID].StockExistInIndex(_stockList.Keys.ElementAt(i)))
                 {
                     int numOfShares =
                         _portofolioList[inPortfolioID].NumOfSharesOfStockInPortfolio(_stockList.Keys.ElementAt(i));
                     decimal price = _stockList[_stockList.Keys.ElementAt(i)].GetPriceForDate(timeStamp);
                     value += numOfShares*price;
                 }
             }
             return value;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime begin = new DateTime(Year, Month, 1, 00, 00, 00, 00, 000);
             DateTime end = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

             decimal startValue = GetPortfolioValue(inPortfolioID, begin);
             decimal endValue = GetPortfolioValue(inPortfolioID, end);

             if (startValue==0 || endValue==0) 
                 throw new StockExchangeException("Cijena nije definirana");

             decimal percentage = ((endValue - startValue)/startValue) * 100;
             return Math.Round(percentage, 3);
         }
     }
}