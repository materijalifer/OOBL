﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    public class Calculator : ICalculator
    {
        private int state; // početno - 0, stanje akumuliranja brojeva i računanja - 1
        private decimal? acc; //akumulator, trenutni broj koji se unosi ili zadnji koji se unijeo
        private string display;
        private char? lastBinary;
        private bool binaryIsComputing;
        private bool decimalInput;
        private bool firstDigit;
        private bool error;
        private decimal decimalPart;
        private decimal digit;
        public decimal help;
        private decimal? ls; //lijeva strana binarne operacije
        private decimal? rs;
        private decimal? buffer;
        private decimal? memory;
        private int foretoken;
        private char[] unaryOperators = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        private char[] binaryOperators = { '+', '-', '*', '/' };

        public Calculator()
        {
            Reset();
        }

        public void Reset()
        {
            state = 0;
            acc = 0;
            buffer = null;
            memory = null;
            lastBinary = null;
            binaryIsComputing = false;
            firstDigit = false;
            display = "0";
            decimalInput = false;
            decimalPart = 0.1m;
            foretoken = 1;
            ls = null;
            rs = null;
            buffer = null;
            error = false;
        }

        public bool DigitOverflow(string d)
        {
            if (d.Count(Char.IsDigit) > 10)
            {
                return true;
            }
            return false;
        }

        public decimal? Round(decimal? n)
        {
            string ns = n.ToString();
            int nwd; //number of whole digits
            if (DigitOverflow(ns))
            {
                nwd = ns.Split(',')[0].Count(Char.IsDigit);
                n = Decimal.Round((decimal)n, 10 - nwd);
            }
            ns = n.ToString(); //micanje suvišnih nula sa kraja
            if (ns.Contains(',') && ns.EndsWith("0"))
            {
                int commaIndex = ns.IndexOf(',');
                for (int i = ns.Length - 1; i >= commaIndex; i--)
                {
                    if (ns[i] == '0' || ns[i] == ',')
                    {
                        ns = ns.Substring(0, i);
                    }
                    else
                    {
                        break;
                    }
                }
                n = Convert.ToDecimal(ns);
            }
            return n;
        }

        public void UnaryOperation(char op)
        {
            switch (op)
            {
                case 'M':
                    acc = -acc;
                    foretoken = -1;
                    break;
                case 'S':
                    acc = (decimal)Math.Sin((double)acc);
                    break;
                case 'K':
                    acc = (decimal)Math.Cos((double)acc);
                    break;
                case 'T':
                    acc = (decimal)Math.Tan((double)acc);
                    break;
                case 'Q':
                    acc = (decimal)Math.Pow((double)acc, 2);
                    break;
                case 'R':
                    if (acc < 0m) //broj ispod korijena negativan --> error
                    {
                        display = "-E-";
                        error = true;
                        state = 0;
                        break;
                    }
                    acc = (decimal)Math.Sqrt((double)acc);
                    break;
                case 'I':
                    if (acc == 0m) //dijeljenje s nulom --> error
                    {
                        display = "-E-";
                        error = true;
                        state = 0;
                        break;
                    }
                    acc = (decimal)Math.Pow((double)acc, -1);
                    break;
            }
            if (!acc.ToString().Contains(",") && DigitOverflow(acc.ToString())) //prevelik broj --> error
            {
                display = "-E-";
                error = true;
                return;
            }
            acc = Round(acc);
        }

        public void BinaryOperation()
        {
            switch (lastBinary)
            {
                case '+':
                    buffer = ls + rs;
                    break;
                case '-':
                    buffer = ls - rs;
                    break;
                case '*':
                    buffer = ls * rs;
                    break;
                case '/':
                    if (rs == 0m) //dijeljenje s nulom --> error
                    {
                        display = "-E-";
                        error = true;
                        break;
                    }
                    buffer = ls / rs;
                    break;
            }
            if (!buffer.ToString().Contains(",") && DigitOverflow(buffer.ToString())) //prevelik broj --> error
            {
                display = "-E-";
                error = true;
                return;
            }
            buffer = Round(buffer);
        }

        public void Press(char inPressedDigit)
        {
            if (state == 0)
            {
                if (Char.IsDigit(inPressedDigit))
                {
                    if (inPressedDigit != '0') //pritisnuta znamenka != 0; ako je pritisnuta 0, ostaje se u početnom stanju
                    {
                        acc = (decimal)Char.GetNumericValue(inPressedDigit);
                        state = 1;
                        display = inPressedDigit.ToString();
                    }
                }
                else if (inPressedDigit == ',') //unosi se decimalni broj
                {
                    decimalInput = true;
                    decimalPart = 0.1m;
                    state = 1;
                    display += inPressedDigit.ToString();
                }
                else if (inPressedDigit == '-') //negativan broj
                {
                    foretoken = -1;
                    state = 1;
                    display = inPressedDigit.ToString();
                }
                else if (unaryOperators.Contains(inPressedDigit)) //unarna operacija sa argumentom 0
                {
                    UnaryOperation(inPressedDigit);
                    if (!error)
                        state = 1;
                }
                return;
            }
            if (state == 1)
            {
                if (DigitOverflow(display + inPressedDigit.ToString())) //maksimalno 10 znamenki na ekranu
                    return;
                if (Char.IsDigit(inPressedDigit))
                {
                    if (binaryIsComputing && firstDigit) //spremamo prethodni broj
                    {
                        buffer = acc;
                        acc = 0m;
                        firstDigit = false;
                        decimalInput = false; //za slučaj 2,+3 da ne računa 2,3
                        foretoken = 1;
                        display = "";
                    }
                    digit = (decimal)Char.GetNumericValue(inPressedDigit);
                    if (decimalInput) //unosi se decimalni broj
                    {
                        acc += foretoken * digit * decimalPart;
                        decimalPart *= 0.1m;
                        display += inPressedDigit.ToString();
                    }
                    else //unosi se cijeli broj
                    {
                        acc = acc * 10 + foretoken * digit;
                        display += inPressedDigit.ToString();
                    }
                    if (binaryIsComputing)
                        rs = acc;
                }
                else if (inPressedDigit == ',') //unosi se decimalni broj
                {
                    if (decimalInput) //ignoriramo višestruke zareze
                        return;
                    decimalInput = true;
                    decimalPart = 0.1m;
                    display += inPressedDigit.ToString();
                }
                else if (unaryOperators.Contains(inPressedDigit))
                {
                    UnaryOperation(inPressedDigit);
                    if (!error)
                        display = acc.ToString();
                    if (binaryIsComputing)
                        rs = acc;
                }
                else if (binaryOperators.Contains(inPressedDigit))
                {
                    if (binaryIsComputing && rs != null) //računa se prethodna binarna operacija; imamo lijevu i desnu stranu
                    {
                        BinaryOperation();
                        if (!error)
                            display = buffer.ToString();
                    }
                    binaryIsComputing = true;
                    ls = buffer == null ? acc : buffer;
                    rs = null;
                    lastBinary = inPressedDigit;
                    firstDigit = true; //slijedi unos prve znamenke drugog operanda
                }
                else if (inPressedDigit == '=')
                {
                    if (binaryIsComputing)
                    {
                        if (rs != null)
                        {
                            BinaryOperation();
                            binaryIsComputing = false;
                        }
                        else // skraćeni zapis operacija s istim operatorom, npr. 2+=
                        {
                            rs = acc;
                            BinaryOperation();
                            binaryIsComputing = false;
                        }
                        if (!error)
                        {
                            if (buffer == (int)buffer) //ako je iznos cjelobrojan, ne ispisivati decimalni dio
                                display = Convert.ToInt32(buffer).ToString();
                            else
                                display = buffer.ToString();
                        }
                    }
                    else
                    {
                        if (acc == (int)acc)
                            display = Convert.ToInt32(acc).ToString();
                        else
                            display = acc.ToString();
                    }
                }
                else if (inPressedDigit == 'C')
                {
                    display = "0";
                    acc = 0m;
                }
                else if (inPressedDigit == 'O')
                {
                    Reset();
                }
                else if (inPressedDigit == 'P')
                {
                    memory = acc;
                }
                else if (inPressedDigit == 'G')
                {
                    acc = memory;
                    display = acc.ToString();
                }
                return;
            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }
    }

}