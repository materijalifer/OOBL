﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        #region Fields

        #region Const

        private char[] binary = { '+', '-', '*', '/' };

        private char[] unary = { 'S', 's', 'K', 'k', 'T', 't', 'Q', 'q', 'R', 'r', 'I', 'i' };

        private char[] memory = { 'G', 'g', 'P', 'p' };

        #endregion

        private bool checkOperand;

        private double mem;

        private double operand1;

        private double operand2;

        private char lastBinaryIn;

        private char lastIn;


        private Operations Operations = new Operations();

        private Display Display = new Display();

        #endregion

        #region Constructors

        public Kalkulator()
        {
            this.checkOperand = false;
            this.mem = 0;
            this.operand1 = 0;
            this.operand2 = 0;
            this.lastBinaryIn = ' ';
            this.lastIn = ' ';
        }

        #endregion

        #region public Methods

        public void Press(char inPressedDigit)
        {
            ParseInput(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return Display.Get();
        }

        #endregion

        #region private Methods

        private void addNumber(char n, bool comma = false)
        {
            string state = Display.Get();

            state += n;

            if (checkOverflow(state))
            {
                operand1 = Convert.ToDouble(state);
            }
        }

        private int countDigits(double operand)
        {
            return countDigits(operand.ToString());
        }

        private int countDigits(string operand)
        {
            return operand.Replace(",", "").Replace("-", "").Count();
        }

        private bool checkOverflow(double operand)
        {
            return checkOverflow(operand.ToString());
        }

        private bool checkOverflow(string operand)
        {
            return countDigits(operand) <= 10;
        }

        private double floor(double operand)
        {
            return floor(operand.ToString());
        }

        private double floor(string operand)
        {
            if (operand.Contains(",") && checkOverflow(operand.Split(',')[0]))
            {
                int i = 10 - countDigits(operand.Split(',')[0]);
                return Operations.Round(Convert.ToDouble(operand), i);
            }
            else
            {
                return double.NaN;
            }

        }

        private void reset()
        {
            mem = 0;
            operand1 = 0;
            operand2 = 0;
            Display.Clear();
            lastBinaryIn = ' ';
            lastIn = ' ';

        }

        private void clear()
        {
            operand1 = 0;
            Display.Clear();
        }

        private void checkBinary()
        {
            if (lastBinaryIn == '+')
            {
                operand1 = Operations.Add(operand2, operand1);
            }
            else if (lastBinaryIn == '-')
            {
                operand1 = Operations.Subtract(operand2, operand1);
            }
            else if (lastBinaryIn == '*')
            {
                operand1 = Operations.Multiply(operand2, operand1);
            }
            else if (lastBinaryIn == '/')
            {
                operand1 = Operations.Divide(operand2, operand1);
            }
        }

        private void ParseInput(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                #region Digits
                case ('0'):
                case ('1'):
                case ('2'):
                case ('3'):
                case ('4'):
                case ('5'):
                case ('6'):
                case ('7'):
                case ('8'):
                case ('9'):
                    if (binary.Contains(lastBinaryIn) && !checkOperand)
                    {
                        operand1 = 0;
                        Display.Clear();
                        addNumber(inPressedDigit);
                        checkOperand = true;
                    }
                    else
                    {
                        addNumber(inPressedDigit);
                    }

                    break;
                #endregion

                #region Binary

                case ('+'):
                case ('-'):
                case ('*'):
                case ('/'):
                    if (binary.Contains(lastBinaryIn) && checkOperand == true)
                    {
                        checkBinary();
                        operand2 = 0;
                        checkOperand = false;
                    }
                    lastBinaryIn = inPressedDigit;
                    operand2 = operand1;
                    break;
                #endregion

                #region Equal

                case ('='):
                    if (binary.Contains(lastBinaryIn))
                    {
                        checkBinary();
                        operand2 = 0;
                        lastBinaryIn = ' ';
                        Display.Update(operand1.ToString());
                    }


                    break;

                #endregion

                #region Comma

                case (','):
                    if (!Display.Get().Contains(",") && !unary.Contains(lastIn) && !binary.Contains(lastIn))
                    {
                        string state = Display.Get();
                        state += ",";
                        Display.Update(state);
                    }
                    else if (!Display.Get().Contains(",") && (unary.Contains(lastIn) || binary.Contains(lastIn)))
                    {
                        operand1 = 0;
                        Display.Update(operand1);
                        string state = Display.Get();
                        state += ",";
                        Display.Update(state);
                    }

                    if (binary.Contains(lastIn)) checkOperand = true;

                    break;

                #endregion

                #region Unary

                case ('M'):
                case ('m'):
                    operand1 = Operations.SignChange(operand1);
                    break;

                case ('S'):
                case ('s'):
                    operand1 = Operations.Sine(operand1);
                    break;

                case ('K'):
                case ('k'):
                    operand1 = Operations.Cosine(operand1);
                    break;

                case ('T'):
                case ('t'):
                    operand1 = Operations.Tangent(operand1);
                    break;

                case ('Q'):
                case ('q'):
                    operand1 = Operations.Square(operand1);
                    break;

                case ('R'):
                case ('r'):
                    operand1 = Operations.SquareRoot(operand1);
                    break;

                case ('I'):
                case ('i'):
                    operand1 = Operations.Inverse(operand1);
                    break;
                #endregion

                #region Memory

                case ('P'):
                case ('p'):
                    mem = operand1;
                    break;

                case ('G'):
                case ('g'):
                    operand1 = mem;
                    break;

                #endregion

                #region Reset

                case ('O'):
                case ('o'):
                    reset();
                    break;
                case ('C'):
                case ('c'):
                    clear();
                    break;

                #endregion

                default:
                    break;
            }

            lastIn = inPressedDigit;

            if (inPressedDigit != ',') Display.Update(operand1);

            if (!checkOverflow(operand1))
            {
                operand1 = floor(operand1);
                if (double.IsNaN(operand1))
                {
                    Display.Error = true;
                }
                else
                {
                    Display.Update(operand1);
                }
            }

            if (double.IsInfinity(operand1))
            {
                Display.Error = true;
            }
        }

        #endregion
    }

    public class Display
    {

        #region Fields

        #region Const

        private const string error = "-E-";

        #endregion

        private string _value;

        private bool isError;

        #endregion

        #region Constructors

        public Display(string value = "0")
        {
            this._value = value;
            this.isError = false;
        }

        #endregion

        #region Properties

        public bool Error
        {
            get { return this.isError; }
            set { isError = value; }
        }

        #endregion

        #region public Methods

        public string Get()
        {
            if (isError) return error;
            else return _value;
        }

        public void Update(string value)
        {
            this._value = value;
        }

        public void Update(double value)
        {
            Update(value.ToString());
        }

        public void Clear()
        {
            this._value = "0";
            this.isError = false;
        }

        #endregion

    }

    public class Operations
    {
        #region Operations

        public double Round(double a, int n)
        {
            return Math.Round(a, n);
        }

        public double Add(double a, double b)
        {
            return a + b;
        }

        public double Subtract(double a, double b)
        {
            return a - b;
        }

        public double Multiply(double a, double b)
        {
            return a * b;
        }

        public double Divide(double a, double b)
        {
            return a / b;
        }

        public double SignChange(double a)
        {
            return -a;
        }

        public double Sine(double a)
        {
            return Math.Sin(a);
        }

        public double Cosine(double a)
        {
            return Math.Cos(a);
        }

        public double Tangent(double a)
        {
            return Math.Tan(a);
        }

        public double Square(double a)
        {
            return Math.Pow(a, 2);
        }

        public double SquareRoot(double a)
        {
            return Math.Sqrt(a);
        }

        public double Inverse(double a)
        {
            return Math.Pow(a, -1);
        }

        #endregion
    }


}
