using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    #region StockExchange
    public class StockExchange : IStockExchange
    {
        private readonly List<Stock> _listOfStocks;

        private readonly List<StockExchangeIndex> _listOfIndices;

        private readonly List<StockExchangePortfolio> _listOfPortfolios;

        public StockExchange()
        {
            _listOfStocks = new List<Stock>();
            _listOfIndices = new List<StockExchangeIndex>();
            _listOfPortfolios = new List<StockExchangePortfolio>();
        }

        private Stock GetStockByName(string inStockName)
        {
            if (_listOfStocks.Exists(st => st.InStockName.ToUpper().Equals(inStockName.ToUpper())))
            {
                var findStock = _listOfStocks.Single(st => st.InStockName.ToUpper().Equals(inStockName.ToUpper()));
                return findStock;
            }
            throw new StockExchangeException("Stock with this name doesn't exists!");
        }

        private StockExchangeIndex GetStockExchangeIndexByName(string indexName)
        {
            if (_listOfIndices.Exists(ind => ind.IndexName.ToUpper().Equals(indexName.ToUpper())))
            {
                var findStockExchangeIndex = _listOfIndices.Single(ind => ind.IndexName.ToUpper().Equals(indexName.ToUpper()));
                return findStockExchangeIndex;
            }
            throw new StockExchangeException("Stock with this name doesn't exists!");
        }

        private StockExchangePortfolio GetStockExchangePortfolioById(string idPortfolio)
        {
            if (_listOfPortfolios.Exists(port => port.Id.Equals(idPortfolio)))
            {
                var findStockExchangePortfolio = _listOfPortfolios.Single(port => port.Id.Equals(idPortfolio));
                return findStockExchangePortfolio;
            }
            throw new StockExchangeException("Portfolio with this name doesn't exists!");
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            var newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

            if (!_listOfStocks.Contains(newStock))
            {
                _listOfStocks.Add(newStock);
            }
            else
            {
                throw new StockExchangeException("Stock with this name exists!");
            }
        }

        public void DelistStock(string inStockName)
        {
            var delistStock = GetStockByName(inStockName);
            if (_listOfStocks.Contains(delistStock))
            {
                _listOfStocks.Remove(delistStock);
            }
            foreach (var stockExchangeIndex in _listOfIndices)
            {
                if(stockExchangeIndex.ListOfIndexStocks.Contains(delistStock))
                {
                    stockExchangeIndex.RemoveStock(delistStock);
                }
            }

            foreach (var stockExchangePortfolio in _listOfPortfolios)
            {
                if (stockExchangePortfolio.StockExists(delistStock))
                {
                    stockExchangePortfolio.RemoveStockFromPortfolio(delistStock);
                }
            }
        }

        public bool StockExists(string inStockName)
        {
            return _listOfStocks.Exists(st => st.InStockName.ToUpper().Equals(inStockName.ToUpper()));
        }

        public int NumberOfStocks()
        {
            return _listOfStocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var findStock = GetStockByName(inStockName);
            findStock.AddStockPrice(inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var findStock = GetStockByName(inStockName);
            return findStock.GetStockPrice(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            var findStock = GetStockByName(inStockName);
            return findStock.InInitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            var findStock = GetStockByName(inStockName);
            return findStock.GetLastStockPrice();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            var newStockExchangeIndex = StockExchangeIndexFactory.CreateStockExchangeIndex(inIndexName, inIndexType);

            if (!_listOfIndices.Contains(newStockExchangeIndex))
            {
                _listOfIndices.Add(newStockExchangeIndex);
            }
            else
            {
                throw new StockExchangeException("Index with this name exists!");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var findIndex = GetStockExchangeIndexByName(inIndexName);
            var findStock = GetStockByName(inStockName);
            findIndex.AddStock(findStock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var findIndex = GetStockExchangeIndexByName(inIndexName);
            var findStock = GetStockByName(inStockName);
            findIndex.RemoveStock(findStock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var findStock = GetStockByName(inStockName);
            var findIndex = GetStockExchangeIndexByName(inIndexName);
            return findIndex.StockExist(findStock);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var findIndex = GetStockExchangeIndexByName(inIndexName);
            return findIndex.CalculateIndex(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return _listOfIndices.Exists(ind => ind.IndexName.ToUpper().Equals(inIndexName.ToUpper()));
        }

        public int NumberOfIndices()
        {
            return _listOfIndices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            var findIndex = GetStockExchangeIndexByName(inIndexName);
            return findIndex.ListOfIndexStocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            var newPortfolio = new StockExchangePortfolio(inPortfolioID);

            if (!_listOfPortfolios.Contains(newPortfolio))
            {
                _listOfPortfolios.Add(newPortfolio);
            }
            else
            {
                throw new StockExchangeException("Portfolio with this name exists!");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            var findStock = GetStockByName(inStockName);

            int numberOfSharesInAllPortfolios = _listOfPortfolios.Sum(port => port.GetNumberOfSharesOfStock(findStock));

            if (numberOfSharesInAllPortfolios + numberOfShares <= findStock.InNumberOfShares)
            {
                findStockExchangePortfolio.AddStockToPortfolio(findStock, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            var findStock = GetStockByName(inStockName);

            findStockExchangePortfolio.RemoveStockSharesFromPortfolio(findStock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            var findStock = GetStockByName(inStockName);

            findStockExchangePortfolio.RemoveStockFromPortfolio(findStock);
        }

        public int NumberOfPortfolios()
        {
            return _listOfPortfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            return findStockExchangePortfolio.GetNumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _listOfPortfolios.Exists(port => port.Id.Equals(inPortfolioID));
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            var findStock = GetStockByName(inStockName);

            return findStockExchangePortfolio.StockExists(findStock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            var findStock = GetStockByName(inStockName);
            return findStockExchangePortfolio.GetNumberOfSharesOfStock(findStock);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            return findStockExchangePortfolio.GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var findStockExchangePortfolio = GetStockExchangePortfolioById(inPortfolioID);
            return findStockExchangePortfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
        }
    }
    #endregion

    #region Stock
    public class Stock
    {
        public long InNumberOfShares { get; private set; }

        public string InStockName { get; private set; }

        public decimal InInitialPrice { get; set; }

        public DateTime InTimeStamp { get; private set; }

        private readonly List<StockPrice> _listOfPrices;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            InStockName = inStockName;
            if (inNumberOfShares < 0 || inInitialPrice < 0)
            {
                throw new StockExchangeException("Invalid data!");
            }
            InNumberOfShares = inNumberOfShares;
            InInitialPrice = inInitialPrice;
            InTimeStamp = inTimeStamp;

            _listOfPrices = new List<StockPrice> { new StockPrice(inTimeStamp, inInitialPrice) };
        }

        public List<StockPrice> GetStockPrices
        {
            get { return _listOfPrices; }
        }

        public void AddStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            var newStockPrice = new StockPrice(inTimeStamp, inStockValue);

            if (!_listOfPrices.Contains(newStockPrice))
            {
                _listOfPrices.Add(newStockPrice);
            }
            else
            {
                throw new StockExchangeException("Price with this timestamp exists!");
            }
        }

        public decimal GetLastStockPrice()
        {
            // sortirano silazno - prva je trenutna/zadnja cijena dionice
            IEnumerable<StockPrice> result = _listOfPrices.OrderByDescending(s => s.InTimeStamp).ToList();
            return result.First().InStockValue;
        }

        public decimal GetTotalLastStockPrice()
        {
            return InNumberOfShares * GetLastStockPrice();
        }

        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            var priceResult = 0m;
            IEnumerable<StockPrice> result = _listOfPrices.OrderBy(s => s.InTimeStamp).ToList();

            // ako je zatra�ena cijena prije nego je uop�e dionica kreirana - gre�ka, nema takve cijene
            if (inTimeStamp.CompareTo(InTimeStamp) == -1)
                throw new StockExchangeException("No price set for this timestamp!");

            foreach (var stockPrice in result)
            {
                // da li je cijena definirane prije (-1) ili ba� u tra�enom trenutku (0) - zapamti vrijednost i nastavi dalje
                // ako je cijena definirana kasnije od vremena za koji je zatra�ena - vrati prethodno postavljenu vrijednost
                if (stockPrice.InTimeStamp.CompareTo(inTimeStamp) == -1 ||
                    stockPrice.InTimeStamp.CompareTo(inTimeStamp) == 0)
                {
                    priceResult = stockPrice.InStockValue;
                }
                else
                {
                    return priceResult;
                }
            }
            return priceResult;
        }

        public decimal GetTotalStockPrice(DateTime inTimeStamp)
        {
            return InNumberOfShares * GetStockPrice(inTimeStamp);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Stock)) return false;
            var other = (Stock)obj;
            return other.InStockName.ToUpper().Equals(InStockName.ToUpper());
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    #endregion

    #region StockPrice
    public class StockPrice
    {
        public decimal InStockValue { get; private set; }

        public DateTime InTimeStamp { get; private set; }

        public StockPrice(DateTime inTimeStamp, Decimal inStockValue)
        {
            InTimeStamp = inTimeStamp;
            if (inStockValue < 0)
            {
                throw new StockExchangeException("Invalid data!");
            }
            InStockValue = inStockValue;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is StockPrice)) return false;
            var other = (StockPrice)obj;
            return InTimeStamp.Date.Equals(other.InTimeStamp.Date) &&
                   InTimeStamp.Hour.Equals(other.InTimeStamp.Hour) &&
                   InTimeStamp.Minute.Equals(other.InTimeStamp.Minute) &&
                   InTimeStamp.Second.Equals(other.InTimeStamp.Second) &&
                   InTimeStamp.Millisecond.Equals(other.InTimeStamp.Millisecond);

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    #endregion

    #region StockExchangeIndexFactory
    public class StockExchangeIndexFactory
    {
        public static StockExchangeIndex CreateStockExchangeIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType == IndexTypes.AVERAGE)
            {
                return new StockExchangeIndexAverage(inIndexName);
            }
            if (inIndexType == IndexTypes.WEIGHTED)
            {
                return new StockExchangeIndexWeighted(inIndexName);
            }
            throw new StockExchangeException("Invalid type of index!");
        }
    }
    #endregion

    #region StockExchangeIndex
    public abstract class StockExchangeIndex
    {
        public const int NumberOfIndexRoundDigits = 3;

        public string IndexName { get; private set; }

        private readonly List<Stock> _listOfIndexStocks;

        protected StockExchangeIndex(string nameOfIndex)
        {
            IndexName = nameOfIndex;
            _listOfIndexStocks = new List<Stock>();
        }

        public List<Stock> ListOfIndexStocks
        {
            get { return _listOfIndexStocks; }
        }

        public void AddStock(Stock stock)
        {
            if (!StockExist(stock))
            {
                _listOfIndexStocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Stock exists in index!");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (StockExist(stock))
            {
                _listOfIndexStocks.Remove(stock);
            }
        }

        public bool StockExist(Stock stock)
        {
            return _listOfIndexStocks.Contains(stock);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is StockExchangeIndex)) return false;
            var other = (StockExchangeIndex)obj;
            return IndexName.ToUpper().Equals(other.IndexName.ToUpper());
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public abstract decimal CalculateIndex(DateTime inTimeStamp);
    }
    #endregion

    #region StockExchangeIndexAverage
    public class StockExchangeIndexAverage : StockExchangeIndex
    {
        public StockExchangeIndexAverage(string nameOfIndex)
            : base(nameOfIndex)
        { }

        public override decimal CalculateIndex(DateTime inTimeStamp)
        {
            decimal result = 0m;
            int numberOfStocks = ListOfIndexStocks.Count;
            decimal sumPrice = ListOfIndexStocks.Sum(indexStock => indexStock.GetStockPrice(inTimeStamp));

            if (numberOfStocks > 0)
                result = sumPrice / numberOfStocks;

            return Math.Round(result, NumberOfIndexRoundDigits);
        }
    }
    #endregion

    #region StockExchangeIndexWeighted
    public class StockExchangeIndexWeighted : StockExchangeIndex
    {
        public StockExchangeIndexWeighted(string nameOfIndex)
            : base(nameOfIndex)
        { }

        public override decimal CalculateIndex(DateTime inTimeStamp)
        {
            decimal result = 0m;

            decimal allStocksTotalPrice = ListOfIndexStocks.Sum(indexStock => indexStock.GetTotalStockPrice(inTimeStamp));

            decimal overallFactorIndex =
                ListOfIndexStocks.Sum(indexStock => indexStock.GetTotalStockPrice(inTimeStamp) / allStocksTotalPrice);

            decimal sumIndexFactorPrice = ListOfIndexStocks.Sum(indexStock => indexStock.GetStockPrice(inTimeStamp) * indexStock.GetTotalStockPrice(inTimeStamp) / allStocksTotalPrice);


            if (overallFactorIndex > 0)
                result = sumIndexFactorPrice / overallFactorIndex;

            return Math.Round(result, NumberOfIndexRoundDigits);
        }
    }
    #endregion

    #region StockExchangePortfolio
    public class StockExchangePortfolio
    {
        private const int NumberOfPortfolioRoundDigits = 3;

        public string Id { get; private set; }

        private readonly Dictionary<Stock, int> _portfolioStocks;

        public StockExchangePortfolio(string id)
        {
            Id = id;
            _portfolioStocks = new Dictionary<Stock, int>();
        }

        public void AddStockToPortfolio(Stock stock, int numOfShares)
        {
            if (StockExists(stock))
            {
                _portfolioStocks[stock] += numOfShares;
            }
            else
            {
                _portfolioStocks.Add(stock, numOfShares);
            }
        }

        public int GetNumberOfStocks()
        {
            return _portfolioStocks.Keys.Count;
        }

        public bool StockExists(Stock stock)
        {
            return _portfolioStocks.ContainsKey(stock);
        }

        public int GetNumberOfSharesOfStock(Stock stock)
        {
            return StockExists(stock) ? _portfolioStocks[stock] : 0;
        }

        public void RemoveStockFromPortfolio(Stock stock)
        {
            if (StockExists(stock))
            {
                _portfolioStocks.Remove(stock);
            }
        }

        public void RemoveStockSharesFromPortfolio(Stock stock, int numOfShares)
        {
            if ((GetNumberOfSharesOfStock(stock) - numOfShares) > 0)
            {
                _portfolioStocks[stock] = GetNumberOfSharesOfStock(stock) - numOfShares;
            }
            else
            {
                RemoveStockFromPortfolio(stock);
            }

        }

        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            var result = _portfolioStocks.Keys.Sum(portfolioStock => portfolioStock.GetStockPrice(inTimeStamp) * _portfolioStocks[portfolioStock]);

            return Math.Round(result, NumberOfPortfolioRoundDigits);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
        {
            decimal valueAtBeginOfMonth = GetPortfolioValue(new DateTime(year, month, 1, 0, 0, 0, 0));
            decimal valueAtEndOfMonth = GetPortfolioValue(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
            return (valueAtEndOfMonth / valueAtBeginOfMonth - 1) * 100;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is StockExchangePortfolio)) return false;
            var other = (StockExchangePortfolio)obj;
            return Id.Equals(other.Id);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    #endregion
}
