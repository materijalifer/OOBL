﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock
    {
        private string _symbol;
        private long _numOfShares;
        private SortedDictionary<string, decimal> _priceHistory;

        public Stock(string symbol, long numOfShares, Decimal initialPrice, DateTime timeStamp)
        {
            Symbol = symbol;
            NumberOfShares = numOfShares;
            _priceHistory = new SortedDictionary<string, decimal>();
            
            if (initialPrice > 0m)
            {
                _priceHistory.Add(ConvertDateTimeToString(timeStamp), initialPrice);
            }
            else
            {
                throw new StockExchangeException("Cijena dionice mora biti > 0");
            }
        }
    
         
        #region StockProperties
        
        public DateTime CurrentTimeStamp
        {
            get { return ConvertStringToDateTime(_priceHistory.Keys.Last()); }
        }

        public string Symbol
        {
            get { return _symbol; } 
            set { _symbol = value.ToUpper(); }
        }

        public long NumberOfShares 
        { 
            get { return _numOfShares; } 
            set
            {
                if (value > 0)
                {
                    _numOfShares = value;
                }
                else
                {
                    throw new StockExchangeException("Broj dionica mora biti > 0");
                }
            }
        }
        public decimal LastStockPrice
        {
            get { return _priceHistory.Values.Last(); } 
        }
        public decimal FirstStackPrice
        {
            get { return _priceHistory.Values.First(); }
        }

       
        #endregion StockProperties

        public void SetStockPrice(DateTime timeStamp, decimal newPrice)
        {
            string timeString = ConvertDateTimeToString(timeStamp);

            if (!(_priceHistory.ContainsKey(timeString)))
            {
                _priceHistory.Add(timeString, newPrice);
            }
            else
            {
                throw new StockExchangeException("Postoji već definirana cijena za to vrijeme");
            }
        }
       
        public Decimal GetStockPrice(DateTime timeStamp)
        {
            string queriedKey = null;
            var reversedDictionary = _priceHistory.Keys.Reverse();
            
            foreach (var key in reversedDictionary)
            {
                DateTime dt = ConvertStringToDateTime(key);
                if (dt.CompareTo(timeStamp) <= 0)
                {
                    queriedKey = key;
                    break;
                }
            }
            
            if (queriedKey == null)
            {
                throw new StockExchangeException("Nedefinirana cijena za traženi vremenski period");
            }

            return _priceHistory[queriedKey];
        }

        private string ConvertDateTimeToString(DateTime timeStamp)
        {
            const string timeFormat = "yyyy-MM-dd HH:mm:ss:fff";

            return timeStamp.ToString(timeFormat);
        }
        private DateTime ConvertStringToDateTime(string timeString)
        {
            string timeFormat = "yyyy-MM-dd HH:mm:ss:fff";
            DateTime dt;

            bool success = DateTime.TryParseExact(timeString,
                                                  timeFormat,
                                                  CultureInfo.InvariantCulture,
                                                  DateTimeStyles.None,
                                                  out dt);
            if (success)
            {
                return dt;
            }
            else
            {
                throw new StockExchangeException("Neispravni format vremena");
            }
        }
     }
     
     public class Index
     {
         private string _name;
         private IndexTypes _type;
         private Dictionary<string, Stock> _stocks;

         public Index(string name, IndexTypes type)
         {
             Name = name;
             IndexType = type;
             _stocks = new Dictionary<string, Stock>();
         }

         public string Name
         {
             get { return _name; }
             set { _name = value.ToUpper(); }
         }
        
         public IndexTypes IndexType
         {
             get { return _type; } 
             set
             {

                 if (Enum.IsDefined(typeof (IndexTypes), value))
                 {
                     _type = value;
                 }
                 else
                 {
                     throw new StockExchangeException("Unesena vrijednost tipa nije definirana");
                 }
             }
         }
 
         public void AddStock(Stock stock)
         {
             if (!(_stocks.ContainsKey(stock.Symbol)))
             {
                 _stocks.Add(stock.Symbol, stock);
             }
             else
             {
                 throw new StockExchangeException("Dionica je vec dodijeljena indexu");
             }
         }

         public void RemoveStock(string stockSymbol)
         {
             if (_stocks.ContainsKey(stockSymbol))
             {
                 _stocks.Remove(stockSymbol);
             }
         }

         public bool ContainsStock(string stockName)
         {
             if (_stocks.ContainsKey(stockName))
             {
                 return true;
             }
             
             return false;
         }

         public int GetNumberOfStocks()
         {
             return _stocks.Count;
         }

         public decimal GetIndexValue(DateTime timeStamp)
         {
             decimal indValue = 0m;

             switch (IndexType)
             {
                 case IndexTypes.AVERAGE:
                     indValue = calculateAverageValue(timeStamp);
                     break;
                 case IndexTypes.WEIGHTED:
                     indValue = calculateWeightedValue(timeStamp);
                     break;
             }

             return indValue;
         }
         
         private decimal calculateWeightedValue(DateTime timeStamp)
         {
             decimal totalIndexValue = 0m;
             foreach (Stock stock in _stocks.Values)
             {
                 decimal stockPrice = stock.GetStockPrice(timeStamp);
                 totalIndexValue += Decimal.Multiply(stockPrice, stock.NumberOfShares);
             }

             decimal weighedValue = 0m;
             foreach (Stock stock in _stocks.Values)
             {
                 decimal stockPrice = stock.GetStockPrice(timeStamp);
                 decimal weighFactor = Decimal.Divide(Decimal.Multiply(stockPrice, stock.NumberOfShares),
                                                      totalIndexValue);
                 weighedValue += Decimal.Multiply(weighFactor, stockPrice);
             }

             return Decimal.Round(weighedValue, 3, MidpointRounding.AwayFromZero);
         }

         private decimal calculateAverageValue(DateTime timeStamp)
         {
             decimal indValue = 0m;
             foreach (Stock stock in _stocks.Values)
             {
                 decimal stockPrice = stock.GetStockPrice(timeStamp);
                 indValue += Decimal.Multiply(stockPrice, stock.NumberOfShares);
             }

             return Decimal.Round(Decimal.Divide(indValue, _stocks.Count), 3, MidpointRounding.AwayFromZero);
         }

     }

    public class Portfolio
    {
        private string _ID;
        private Dictionary<string, long> _stockListing;

        public Portfolio(string portfolioID)
        {
            _ID = portfolioID;
            _stockListing = new Dictionary<string, long>();
        }

        public string ID
        {
            get { return _ID; }
        }
        public int NumberOfStocks
        {
            get { return _stockListing.Count; }
        }

        public Dictionary<string, long> StockListing
        {
            get { return _stockListing; }
        }

        public void AddStockShares(string stockSymbol, long numOfShares)
        {
            if (_stockListing.ContainsKey(stockSymbol))
            {
                _stockListing[stockSymbol] += numOfShares;
            }
            else
            {
                _stockListing.Add(stockSymbol, numOfShares);
            }
            
        }
    
        public void RemoveStockShares(string stockSymbol, long numOfShares)
        {
            if (_stockListing.ContainsKey(stockSymbol))
            {
                _stockListing[stockSymbol] -= numOfShares;
                if (_stockListing[stockSymbol] <= 0)
                {
                    // brisem dionicu iz portfolia
                    _stockListing.Remove(stockSymbol);
                }

            }
            else
            {
                throw new StockExchangeException("Pokušaj brisanja dionice koja ne postoji u portfoliu");
            }
        }

        public long GetNumberOfSharesOfStock(string stockSymbol)
        {
            return _stockListing[stockSymbol];
        }

        public bool ContainsStock(string stockSymbol)
        {
            return _stockListing.ContainsKey(stockSymbol);
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> _stocks;
         private Dictionary<string, Index> _indices;
         private Dictionary<string, Portfolio> _portfolios; 
 
         public StockExchange()
         {
             _stocks = new Dictionary<string, Stock>();
             _indices = new Dictionary<string, Index>();
             _portfolios = new Dictionary<string, Portfolio>();
         }

         #region Stocks

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (_stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Već postoji ova dionica");
             }
             Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             _stocks.Add(newStock.Symbol, newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (_stocks.ContainsKey(inStockName))
             {
                 // izbrisi dionice u indexima i portfoliima
                 foreach (Index index in _indices.Values)
                 {
                     if (index.ContainsStock(inStockName))
                     {
                         index.RemoveStock(inStockName);
                     }
                 }

                 foreach (Portfolio portfolio in _portfolios.Values)
                 {
                     if (portfolio.ContainsStock(inStockName))
                     {
                         RemoveStockFromPortfolio(portfolio.ID, inStockName);
                     }
                 }

                 // na kraju makni dionicu sa burze
                 _stocks.Remove(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica koju zelite obrisati");
             }
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stocks.Keys.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock queriedStock = _stocks[inStockName];
             queriedStock.SetStockPrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock queriedStock = _stocks[inStockName];

             return queriedStock.GetStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock queriedStock = _stocks[inStockName];
             
             return queriedStock.FirstStackPrice;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock queriedStock = _stocks[inStockName];
             
             return queriedStock.LastStockPrice;
         }

         #endregion Stocks

         #region Indices

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index newIndex = new Index(inIndexName, inIndexType);
             _indices.Add(inIndexName, newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (_indices.ContainsKey(inIndexName) && _stocks.ContainsKey(inStockName))
                 // postoji i trazeni index i trazena dionica
             {
                 Index queriedIndex = _indices[inIndexName];
                 Stock queriedStock = _stocks[inStockName];
                 queriedIndex.AddStock(queriedStock);
             }
             else
             {
                 throw new StockExchangeException("Ne postoji traženi index ili tražena dionica");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index queriedIndex = _indices[inIndexName];
             Stock queriedStock = _stocks[inStockName];

             if ((queriedIndex != null) && (queriedStock != null))
             {
                 queriedIndex.RemoveStock(inStockName);
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _indices[inIndexName].ContainsStock(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return _indices[inIndexName].GetIndexValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _indices[inIndexName].GetNumberOfStocks();
         }

         #endregion Indices

         #region Portfolios

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio newPortfolio = new Portfolio(inPortfolioID);
             _portfolios.Add(inPortfolioID, newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!(_portfolios.ContainsKey(inPortfolioID)) || !(_stocks.ContainsKey(inStockName)))
             {
                 throw new StockExchangeException("Dionica ne moze biti dodana u portfolio");
             }

             if ((GetTotalNumberOfSharesOfStockInPortfolios(inStockName) + numberOfShares) <= _stocks[inStockName].NumberOfShares)
             {
                 _portfolios[inPortfolioID].AddStockShares(inStockName, numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!(_portfolios.ContainsKey(inPortfolioID)) || !(_portfolios[inPortfolioID].ContainsStock(inStockName)))
             {
                 throw new StockExchangeException("Ne postoji tražen portfolio ili ne postoji tražena dionica u portfoliu");
             }

             _portfolios[inPortfolioID].RemoveStockShares(inStockName, numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!(_portfolios.ContainsKey(inPortfolioID)) || !(_portfolios[inPortfolioID].ContainsStock(inStockName)))
             {
                 throw new StockExchangeException("Ne postoji tražen portfolio ili ne postoji tražena dionica u portfoliu");
             }

             _portfolios[inPortfolioID].StockListing.Remove(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Navedeni portfolio ne postoji");
             }
             
             return _portfolios[inPortfolioID].NumberOfStocks;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji traženi portfolio");
             }
             
             return _portfolios[inPortfolioID].ContainsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji traženi portfolio");
             }
             else
             {
                 if (_portfolios[inPortfolioID].ContainsStock(inStockName))
                 {
                     return (int) _portfolios[inPortfolioID].GetNumberOfSharesOfStock(inStockName);
                 }
                 else
                 {
                     throw new StockExchangeException("Ne postoji tražena dionica");
                 }
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Decimal portfolioValue = 0m;
             if (_portfolios.ContainsKey(inPortfolioID))
             {
                 foreach (var stockListing in _portfolios[inPortfolioID].StockListing)
                 {
                     Stock currStock = _stocks[stockListing.Key];
                     Decimal currStockPrice = currStock.GetStockPrice(timeStamp);

                     portfolioValue += Decimal.Multiply(currStockPrice, stockListing.Value);
                 }

                 return Decimal.Round(portfolioValue, 3, MidpointRounding.AwayFromZero);
             }
             else
             {
                 throw  new StockExchangeException("Ne postoji traženi portfolio");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime firstDayOfMonthTimeStamp = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             DateTime lastDayOfMonthTimeStamp = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

             Decimal relativeValueChangedInMonth = GetPortfolioValue(inPortfolioID, lastDayOfMonthTimeStamp) -
                                                   GetPortfolioValue(inPortfolioID, firstDayOfMonthTimeStamp);
             Decimal valueChangePercentage = Decimal.Divide(relativeValueChangedInMonth,
                                                            GetPortfolioValue(inPortfolioID, firstDayOfMonthTimeStamp));
             valueChangePercentage = Decimal.Multiply(100m, valueChangePercentage);

             return Decimal.Round(valueChangePercentage, 3, MidpointRounding.AwayFromZero);
         }

         private long GetTotalNumberOfSharesOfStockInPortfolios(string stockSymbol)
         {
             long totalSharesOfStock = 0l;
             foreach (Portfolio portfolio in _portfolios.Values)
             {
                 if (portfolio.ContainsStock(stockSymbol))
                 {
                     totalSharesOfStock += portfolio.GetNumberOfSharesOfStock(stockSymbol);
                 }

             }

             return totalSharesOfStock;
         }
         
         #endregion Portfolios
     }
}
