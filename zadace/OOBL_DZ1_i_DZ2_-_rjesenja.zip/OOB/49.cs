﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class MyCalculator : ICalculator
	{
		public enum KeyTypes
		{
			BINARY,
			UNARY,
			EQUAL,
			DIGIT,
			MEMORY_STORE,
			MEMORY_RECALL,
			MINUS,
			CLEAR,
			ON,
			DECIMAL_POINT,
			NONE
		}

		public const long MAX_VALUE = 9999999999;
		public const char BINARY_NONE = '\0';

		private double operand;
		private double memory;
		private Display display;
		private char lastBinaryOp;
		private KeyTypes lastKey;

		public MyCalculator()
		{
			display = new Display();
			Initialize();
		}

		private void Initialize()
		{
			operand = 0;
			memory = 0;
			lastBinaryOp = BINARY_NONE;
			lastKey = KeyTypes.NONE;
			display.Initialize();
		}

		public void Press(char inPressedDigit)
		{
			KeyTypes currentKey = GetKeyType(inPressedDigit);
			double displayValue = display.GetDisplayValue();

			if (currentKey == KeyTypes.ON)
				Initialize();
			else if (currentKey == KeyTypes.CLEAR)
				display.Initialize();
			else try
			{
				switch (currentKey)
				{
					case KeyTypes.DIGIT:
						bool startNewNumber = ((lastKey != KeyTypes.DIGIT) && (lastKey != KeyTypes.DECIMAL_POINT) && (lastKey != KeyTypes.MEMORY_STORE) && (lastKey != KeyTypes.MINUS));
						if (startNewNumber)
							display.Initialize();
						if (display.IsInitial())
							display.SetDisplayToChar(inPressedDigit);
						else
							display.AddDigit(inPressedDigit);
						break;

					case KeyTypes.BINARY:
						if ((lastBinaryOp != BINARY_NONE) && (lastKey != KeyTypes.BINARY))
							operand = PerformBinaryOp(operand, displayValue, lastBinaryOp);
						else if (lastKey != KeyTypes.BINARY)
							operand = displayValue;
						lastBinaryOp = inPressedDigit;
						break;
						
					case KeyTypes.UNARY:
						display.SetDisplayToDouble(PerformUnaryOp(displayValue, inPressedDigit));
						break;

					case KeyTypes.EQUAL:
						if (lastBinaryOp != BINARY_NONE)
						{
							double result = PerformBinaryOp(operand, displayValue, lastBinaryOp);
							if (lastKey != KeyTypes.EQUAL)
								operand = displayValue;
							display.SetDisplayToDouble(result);
						}
						else
							display.SetDisplayToDouble(displayValue);
						break;

					case KeyTypes.DECIMAL_POINT:
						display.AddDecimalPoint();
						break;

					case KeyTypes.MINUS:
						display.SetNegativeSign();
						break;

					case KeyTypes.MEMORY_STORE:
						memory = displayValue;
						break;

					case KeyTypes.MEMORY_RECALL:
						display.SetDisplayToDouble(memory);
						break;

					default:
						throw new ArgumentException("Illegal operation!");
				}
			}
			catch (CalcValueException e)
			{
				display.SetError();
			}

			lastKey = currentKey;
		}

		public string GetCurrentDisplayState()
		{
			return display.ToString();
		}

		private KeyTypes GetKeyType(char key)
		{
			switch (key)
			{
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					return KeyTypes.DIGIT;
				case '+':
				case '-':
				case '*':
				case '/':
					return KeyTypes.BINARY;
				case '=':
					return KeyTypes.EQUAL;
				case 'S':
				case 'K':
				case 'T':
				case 'I':
				case 'Q':
				case 'R':
					return KeyTypes.UNARY;
				case 'M':
					return KeyTypes.MINUS;
				case ',':
					return KeyTypes.DECIMAL_POINT;
				case 'P':
					return KeyTypes.MEMORY_STORE;
				case 'G':
					return KeyTypes.MEMORY_RECALL;
				case 'C':
					return KeyTypes.CLEAR;
				case 'O':
					return KeyTypes.ON;
				default:
					return KeyTypes.NONE;
			}
		}

		private double PerformUnaryOp(double operand, char unaryOp)
		{
			double result = 0;

			switch (unaryOp)
			{
				case 'S':
					result = CalcMathOperations.Sin(operand);
					break;

				case 'K':
					result = CalcMathOperations.Cos(operand);
					break;

				case 'T':
					result = CalcMathOperations.Tan(operand);
					break;

				case 'Q':
					result = CalcMathOperations.Sqr(operand);
					break;

				case 'R':
					result = CalcMathOperations.Sqrt(operand);
					break;

				case 'I':
					result = CalcMathOperations.Inverse(operand);
					break;

				default:
					throw new ArgumentException("Illegal unary operation!");
			}

			if (Math.Abs(result) > MAX_VALUE)
				throw new CalcValueException("Operation result exceeds limitations!");
			else
				return result;
		}

		private double PerformBinaryOp(double firstOperand, double secondOperand, char binaryOp)
		{
			double result = 0;

			switch (binaryOp)
			{
				case '+':
					result = CalcMathOperations.Add(firstOperand, secondOperand);
					break;

				case '-':
					result = CalcMathOperations.Sub(firstOperand, secondOperand);
					break;

				case '*':
					result = CalcMathOperations.Mul(firstOperand, secondOperand);
					break;

				case '/':
					result = CalcMathOperations.Div(firstOperand, secondOperand);
					break;

				default:
					throw new ArgumentException("Illegal binary operation!");
			}

			if (Math.Abs(result) > MAX_VALUE)
				throw new CalcValueException("Operation result exceeds limitations!");
			else
				return result;
		}
	}

	public class CalcMathOperations
	{
		public static double Add(double first, double second)
		{
			return first + second;
		}

		public static double Sub(double first, double second)
		{
			return first - second;
		}

		public static double Mul(double first, double second)
		{
			return first * second;
		}

		public static double Div(double first, double second)
		{
			if (second == 0)
				throw new CalcValueException("Division by zero!");
			else
				return first / second;
		}

		public static double Sqr(double operand)
		{
			return operand * operand;
		}

		public static double Sqrt(double operand)
		{
			return Math.Sqrt(operand);
		}

		public static double Sin(double operand)
		{
			return Math.Sin(operand);
		}

		public static double Cos(double operand)
		{
			return Math.Cos(operand);
		}

		public static double Tan(double operand)
		{
			return Math.Tan(operand);
		}

		public static double Inverse(double operand)
		{
			if (operand == 0)
				throw new CalcValueException("Division by zero!");
			else
				return 1 / operand;
		}
	}

	public class Display
	{
		public const string DISPLAY_INITIAL = "0";
		public const string DISPLAY_ERROR = "-E-";
		public const char DISPLAY_DECIMAL_POINT = ',';
		public const char DISPLAY_MINUS = '-';
		public const int DISPLAY_DIGIT_COUNT = 10;

		private StringBuilder display;
		private bool stateOK;

		public Display()
		{
			Initialize();
		}

		public void Initialize()
		{
			display = new StringBuilder(DISPLAY_INITIAL);
			stateOK = true;
		}

		public bool IsInitial()
		{
			return display.ToString().Equals(DISPLAY_INITIAL);
		}

		public double GetDisplayValue()
		{
			return Double.Parse(display.ToString());
		}

		public void SetDisplayToDouble(double value)
		{
			if (stateOK)
			{
				int leftDigits = Math.Max(1, (int)Math.Log10(value));
				display = new StringBuilder(Math.Round(value, DISPLAY_DIGIT_COUNT - leftDigits).ToString());
			}
		}

		public void SetDisplayToChar(char c)
		{
			if (stateOK)
			{
				display = new StringBuilder(c.ToString());
			}
		}

		public void SetDisplayToString(string s)
		{
			if (stateOK)
			{
				display = new StringBuilder(s);
			}
		}

		public void AddDigit(char digit)
		{
			if (stateOK)
			{
				double additionalSpaces = 0;
				if (display.ToString().Contains(DISPLAY_DECIMAL_POINT))
					additionalSpaces++;
				if (display.ToString().Contains(DISPLAY_MINUS))
					additionalSpaces++;

				if (display.ToString().Length < DISPLAY_DIGIT_COUNT + additionalSpaces)
					display.Append(digit);
			}
		}

		public void AddDecimalPoint()
		{
			if (stateOK)
			{
				if (!display.ToString().Contains(DISPLAY_DECIMAL_POINT))
					display.Append(DISPLAY_DECIMAL_POINT);
			}
		}

		public void SetNegativeSign()
		{
			if (stateOK)
			{
				if (display[0] == DISPLAY_MINUS)
					display.Remove(0, 1);
				else
					display = new StringBuilder('-' + display.ToString());
			}
		}

		public void SetError()
		{
			display = new StringBuilder(DISPLAY_ERROR);
		}

		public override string ToString()
		{
			return display.ToString();
		}
	}

	public class CalcValueException : Exception
	{
		public CalcValueException() : base() { }
		public CalcValueException(string message) : base(message) { }
		public CalcValueException(string message, System.Exception inner) : base(message, inner) { }
		protected CalcValueException(System.Runtime.Serialization.SerializationInfo info,
        System.Runtime.Serialization.StreamingContext context) { }

	}

	public class Factory
	{
		public static ICalculator CreateCalculator()
		{
			//vratiti kalkulator
			return new MyCalculator();
		}
	}
}
