﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    /// <summary>
    /// TODO: IDEJE ZA BOLJU IMPLEMENTACIJU 
    ///     (napravio bih to, ali vrijeme, vrijeme... - samo zelim ostaviti doznanja da sam svjestan da se ovo moze mnogo lijepse napravit'! :) ) 
    ///         evo ideja: 
    ///     - smisliti bolji algoritam rada kalkulatora koji smanjuje broj varijabli stanja kalkulatora, drasticno 
    ///         smanjuje zavisnosti u kodu 
    ///     - switch/case se moze zamjeniti sa odredjednim OO patternima, ali s obzirom na malu domenu problema nije potrebno, 
    ///         stovise i da je rijec o kompleksnijem kalkulatoru predstavljalo bi mozda overengineering, treba razmisliti
    ///     - grupirati varijable stanja i operacija kalkulatora u vece cjeline, dakle postojalo bi više klasa (UnaryOperation, BinaryOperation, ....)
    ///         koje imaju pristupu sucelju kalkulatora i pozivaju odredjene metode za postavljanje rezultata na ekran i slicno, a 
    ///         klasa Kalkulator samo definira kojim redom se trebaju hendlati pojedine operacije na "lageru" i potrebne 
    ///         --> vise koda, kompleksniji odnosi, ali citljiviji i razumljiviji kod, tj. lakse shvatljiviji ako se smisli dobar
    ///         algoritam koji prati takvu vrstu podjele posla i organizaciju
    ///         i to bi mozda bio poveci overengineering, ali definitivno lijepse rjesenje, jer momentalni kod je jako krhat i prekrut, tj. 
    ///         previse ovisi o varijablama stanja cije se promjene moraju dogadjati na (pre)vise mjesta, te tesko ih je pratiti (promjene) 
    /// </summary>
    public class Kalkulator : ICalculator
    {
        // consts & config vars
        private const string InitialDisplay = "0";
        private const int ScreenSize = 10; 
        private const string ErrorDisplay = "-E-";
        private readonly NumberFormatInfo nf = new NumberFormatInfo() {NumberDecimalSeparator = ",", NumberDecimalDigits = 10 };

        // state vars
        private string display = InitialDisplay;
        // if current display is second operator in binary operation
        private bool hasStartedWithSecondOperand = false;
        // if unary operation was performed on display (input after that is new number)
        private bool preformedUnary = false;
        // binary operation first inserted operator
        private string firstOperand = null;
        // current/last selected binary operator
        private string binaryOperator = null;
        // memory container
        private string savedDisplay = null; 


        #region ICalculator
        
        public void Press(char inPressedDigit)
        {
            try
            {
                switch (inPressedDigit)
                {
                    case '9':
                    case '8':
                    case '7':
                    case '6':
                    case '5':
                    case '4':
                    case '3':
                    case '2':
                    case '1':
                    case '0':
                        ProcessDigit(inPressedDigit);
                        break;
                    case ',':
                        AppendComma();
                        break;
                    case '+':
                    case '-':
                    case '/':
                    case '*':
                        ProcessBinaryOperator(inPressedDigit);
                        break;
                    case '=':
                        Compute(true);
                        
                        break;
                    case 'M':
                        ChangeDisplaySign();
                        break;
                    case 'S':
                    case 'K':
                    case 'T':
                    case 'Q':
                    case 'R':
                    case 'I':
                        ProcessUnaryOperator(inPressedDigit);
                        break;
                    case 'P':
                        savedDisplay = ProcessInput(display, true);
                        break;
                    case 'G':
                        display = savedDisplay;
                        break;
                    case 'C':
                        Clear();
                        break;
                    case 'O':
                        OnOff();
                        break;
                }
            }
            catch (Exception exception)
            {
                firstOperand = null;
                hasStartedWithSecondOperand = false;
                display = ErrorDisplay;
            }
        }

        public string GetCurrentDisplayState()
        {
            // show only ScreenSize input values. 
            return ProcessInput(display, false);
        }

        #endregion

        private void ProcessBinaryOperator(char inPressedDigit)
        {
            if (preformedUnary)
            {
                preformedUnary = false;
            }
            if (hasStartedWithSecondOperand)
            {
                Compute(false);
            }
            display = ProcessInput(display, true); 
            firstOperand = display;
            binaryOperator = inPressedDigit.ToString();
        }

        private void ProcessUnaryOperator(char operation)
        {
            double displayValue = GetDisplayValue();

            switch (operation)
            {
                case 'S':
                    SaveToDisplayAfterOperation(Math.Sin(displayValue));
                    break;
                case 'K':
                    SaveToDisplayAfterOperation(Math.Cos(displayValue));
                    break;
                case 'T':
                    SaveToDisplayAfterOperation(Math.Tan(displayValue));
                    break;
                case 'Q':
                    SaveToDisplayAfterOperation(Math.Pow(displayValue, 2));
                    break;
                case 'R':
                    SaveToDisplayAfterOperation(Math.Sqrt(displayValue));
                    break;
                case 'I':
                    if (displayValue.ToString(nf) == "0")
                    {
                        throw new Exception();
                    }
                    SaveToDisplayAfterOperation(1.0D/displayValue);
                    break;
            }
            preformedUnary = true;
        }

        private void ProcessDigit(char digit)
        {
            // start over if unary operation was performed
            if (preformedUnary)
            {
                display = InitialDisplay;
                preformedUnary = false;
            }

            if (binaryOperator != null && hasStartedWithSecondOperand == false)
            {
                hasStartedWithSecondOperand = true;
                display = InitialDisplay;
            }

            // check for multiple zeroes
            if (display == "0" && digit == '0')
            {
                return;
            }

            // remove trailing zero
            if (display == "0" && digit != '0')
            {
                display = digit.ToString(CultureInfo.InvariantCulture);
                return;
            }

            display += digit;
        }

        private void AppendComma()
        {
            // start over if unary operation was performed
            if (preformedUnary)
            {
                display = InitialDisplay;
                preformedUnary = false;
            }
            // only if hasn't got alredy one
            if (!display.Contains(","))
            {
                display += ",";
            }
        }

        private void Clear()
        {
            display = InitialDisplay;
            preformedUnary = false;
        }

        private void OnOff()
        {
            // put callculator in ON state, reset all state vars
            display = InitialDisplay;
            hasStartedWithSecondOperand = false;
            firstOperand = null;
            binaryOperator = null;
            savedDisplay = null;
            preformedUnary = false;
        }

        /// <summary>
        /// Just append or remove current display "-"
        /// </summary>
        private void ChangeDisplaySign()
        {
            if (display.StartsWith("-"))
                display = display.Substring(1, display.Length - 1);
            else if (display != "0")
                display = "-" + display;
        }

        private void Compute(bool preserveOperationState)
        {
            // save old values
            string savedFirst = firstOperand;
            if (binaryOperator != null)
            {
                double first;
                double second;
                // normal binary operation with input of 2 operands
                if (hasStartedWithSecondOperand)
                {
                    first = Double.Parse(firstOperand, nf);
                    second = GetDisplayValue();
                }
                else
                {
                    // reverse operands for multiple/shorted binary operation with "="
                    first = GetDisplayValue();
                    second = Double.Parse(firstOperand, nf);
                }

                // preform binary operation
                double result = 0;
                switch (binaryOperator[0])
                {
                    case '+':
                        result = first + second;
                        break;
                    case '-':
                        result = first - second;
                        break;
                    case '/':
                        if (second.ToString(nf) == "0")
                        {
                            throw new Exception();
                        }
                        result = first/second;
                        break;
                    case '*':
                        result = first*second;

                        break;
                }
                SaveToDisplayAfterOperation(result);
            } 
            else
            {
                // simple "="
                display = ProcessInput(display, true); 
            }
            // perserver old operand for shorted binary operations with "="
            if (preserveOperationState)
            {
                firstOperand = savedFirst;
                hasStartedWithSecondOperand = false;
            }
            else
            {
                firstOperand = null;
                hasStartedWithSecondOperand = false;
                binaryOperator = null;
            }
            if (preformedUnary)
            {
                preformedUnary = false;
            }
        }

        /// <summary>
        /// Takes only what is possible to display and/or preforms display opimization. 
        /// </summary>
        /// <param name="value">input value</param>
        /// <param name="optimizeDisplayValue">should return had ",", or ",00" values</param>
        /// <returns></returns>
        private string ProcessInput(string value, bool optimizeDisplayValue)
        {
            // if current value is error, no need for additional processsing
            if (value == ErrorDisplay)
            {
                return ErrorDisplay;
            }

            // take only what is possibly visible on screen
            int take = ScreenSize;
            if (value.Contains("-"))
            {
                take++;
            }
            if (value.Contains(","))
            {
                take++;
            }
            if (value.Length > take)
            {
                value = value.Substring(0, take);
            }

            // remove ",", or "1,00" to "1"
            if(optimizeDisplayValue) {
                value = Double.Parse(value, nf).ToString(nf);
            }

            return value;
        }

        /// <summary>
        /// Saves operation result to display and preforms necessary checks. 
        /// </summary>
        /// <param name="operationResult"></param>
        private void SaveToDisplayAfterOperation(Double operationResult)
        {
            string valueAsString = operationResult.ToString(nf);

            // number of symbols
            int digits = NumberOfIntegerDigits(valueAsString);
            int decimals = NumberOfDecimalDigits(valueAsString);

            // check if result exceeds screen
            if (digits > ScreenSize)
            {
                throw new Exception();
            }

            // round up 

            Double roundedValue; 
            if (digits + decimals > 10)
            {
                int round = 10 - digits;
                roundedValue = Math.Round(operationResult, round);
            }
            else
            {
                roundedValue = operationResult; 
            }

            // save value to display 
            display = roundedValue.ToString(nf);
        }

        /// <summary>
        /// Get current display value as Double type. 
        /// </summary>
        private Double GetDisplayValue()
        {
            return Double.Parse(ProcessInput(display, true), nf);
        }

        #region Utility 
        
        public static int NumberOfIntegerDigits(string decimalNumber)
        {
            if (decimalNumber.StartsWith("-"))
            {
                decimalNumber = decimalNumber.Substring(1, decimalNumber.Length - 1);
            }

            if (decimalNumber.Contains(","))
            {
                int pointIndex = decimalNumber.IndexOf(",");
                return pointIndex;
            }
            return decimalNumber.Length;
        }

        public static int NumberOfDecimalDigits(string decimalNumber)
        {
            if (decimalNumber.StartsWith("-"))
            {
                decimalNumber = decimalNumber.Substring(1, decimalNumber.Length - 1);
            }

            if (decimalNumber.Contains(","))
            {
                int pointIndex = decimalNumber.IndexOf(",");
                return decimalNumber.Length - pointIndex;
            }
            return 0;
        } 

        #endregion
    }
}