﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        char[] unarOperations = {'I', 'S', 'T', 'K', 'Q', 'R'};
        char[] binaryOperations = { '+', '-', '*', '/' };

        char currentOperation = '\0';
        char currentUnarOperation;

        string temp;

        string currentDisplayString = "0";
        double currentDisplayNumber = 0;

        string resultString = "0";
        double resultNumber = 0;

        double memory;
        
        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == ',')
            {
                Coma();
                return;
            }
            
            if (inPressedDigit == 'C')
            {
                ClearScreen();
                return;
            }

            if (inPressedDigit == 'O')
            {
                Off();
                return;
            }

            if (digits.Contains(inPressedDigit))
            {
                resultString += inPressedDigit;
                currentDisplayNumber = Convert.ToDouble(resultString);
                currentDisplayString = Convert.ToString(currentDisplayNumber);
                return;
            }

            if (binaryOperations.Contains(inPressedDigit))
            {
                if ((resultNumber != 0) && (resultString.Length > 0))
                {
                    resultNumber = BinaryOperation(resultNumber, currentDisplayNumber, currentOperation);
                    if (Round(resultNumber) == "-E-")
                    {
                        currentDisplayString = "-E-";
                        return;
                    }
                    temp = Round(resultNumber);
                    resultNumber = Convert.ToDouble(temp);
                    currentDisplayNumber = resultNumber;
                    currentDisplayString = Convert.ToString(currentDisplayNumber);
                    currentOperation = inPressedDigit;
                    resultString = "";
                    return;
                }

                else
                {
                    currentOperation = inPressedDigit;
                    if (Round(currentDisplayNumber) == "-E-")
                    {
                        currentDisplayString = "-E-";
                        return;
                    }
                    temp = Round(currentDisplayNumber);
                    resultNumber = Convert.ToDouble(temp);
                    resultString = "";
                    return;
                }
            }

            if ((inPressedDigit == '=') && (binaryOperations.Contains(currentOperation)))
            {
                if ((currentDisplayNumber == 0) && (currentOperation == '/'))
                {
                    currentDisplayString = "-E-";
                    return;
                }
                resultNumber = BinaryOperation(resultNumber, currentDisplayNumber, currentOperation);
                currentDisplayNumber = resultNumber;
                if (Round(currentDisplayNumber) == "-E-")
                {
                    currentDisplayString = "-E-";
                    return;
                }
                temp = Round(currentDisplayNumber);
                currentDisplayNumber = Convert.ToDouble(temp);
                currentDisplayString = Convert.ToString(currentDisplayNumber);
                resultNumber = 0;
                resultString = "";
                currentOperation = '\0';
                return;
            }

            if (inPressedDigit == 'M')
            {
                Minus();
                return;
            }

            if (unarOperations.Contains(inPressedDigit))
            {
                currentUnarOperation = inPressedDigit;
                if ((inPressedDigit == 'I') && (currentDisplayNumber == 0))
                {
                    currentDisplayString = "-E-";
                    return;
                }
                currentDisplayNumber = UnaryOperation(currentDisplayNumber, currentUnarOperation);
                if (Round(currentDisplayNumber) == "-E-")
                {
                    currentDisplayString = "-E-";
                    return;
                }
                currentDisplayNumber = Convert.ToDouble(Round(currentDisplayNumber));
                currentDisplayString = currentDisplayNumber.ToString();
                return;
            }

            if (inPressedDigit == '=')
            {
                currentOperation = '\0';
                resultString = "";
                resultNumber = 0;
                return;
            }

            if (inPressedDigit == 'P')
            {
                MemoryPut();
                return;
            }

            if (inPressedDigit == 'G')
            {
                MemoryGet();
                return;
            }
            //throw new NotImplementedException();
        }

        private void Coma()
        {
            if (resultString.Contains(','))
            {
                return;
            }
            resultString += ',';
            return;
        }

        private void ClearScreen()
        {
            currentDisplayNumber = 0;
            currentDisplayString = "0";
            resultString = "";
            return;
        }

        private void MemoryPut()
        {
            memory = currentDisplayNumber;
            return;
        }

        private void MemoryGet()
        {
            currentDisplayNumber = memory;
            currentDisplayString = Convert.ToString(memory);
            resultString = "";
            return;
        }

        private void Off()
        {
            resultString = "";
            resultNumber = 0;
            currentDisplayNumber = 0;
            currentDisplayString = "0";
            memory = 0;
            currentOperation = '\0';
            return;
        }


        private double UnaryOperation(double number, char operation)
        {
            switch (operation)
            {
                case 'S':
                    number = Math.Sin(number);
                    break;
                case 'K':
                    number = Math.Cos(number);
                    break;
                case 'T':
                    number = Math.Tan(number);
                    break;
                case 'Q':
                    number = Math.Pow(number, 2);
                    break;
                case 'R':
                    number = Math.Sqrt(number);
                    break;
                case 'I':
                    number = 1 / number;
                    break;
            }
            return number;
        }

        private double BinaryOperation(double result, double currentNumber, char operation)
        {
            switch (operation)
            {
                case '+':
                    result += currentNumber;
                    break;
                case '-':
                    result -= currentNumber;
                    break;
                case '*':
                    result *= currentNumber;
                    break;
                case '/':
                    result /= currentNumber;
                    break;
            }
            return result;
        }

        private string Round(double resultN)
        {
            string resultS;
            int length = 0;
            int comaI, roundI;
            resultS = resultN.ToString();
            length = resultS.Length;

            if ((resultN < 0) && (resultS.Contains(',')) && (length > 12))
            {
                comaI = resultS.IndexOf(',');
                roundI = 11 - comaI;
                resultN = Math.Round(resultN, roundI);
                resultS = Convert.ToString(resultN);
                return resultS;
            }


            else if ((resultN > 0) && (length > 11) && (resultS.Contains(',')))
            {
                string subS = resultS.Substring(0, 11);
                comaI = resultS.IndexOf(',');
                roundI = 10 - comaI;
                resultN = Math.Round(resultN, roundI);
                resultS = Convert.ToString(resultN);
                return resultS;
            }


            else if (((length > 10) && (resultN > 0) && (!resultS.Contains(','))) ||
                ((resultN < 0) && (!resultS.Contains(',')) && (length > 12)) ||
                ((resultN > 0) && (!resultS.Contains(',')) && (length > 11)))
            {
                return "-E-";
            }
            else
                return resultS;

        }

        private void Minus()
        {
            currentDisplayNumber *= -1;
            currentDisplayNumber = Convert.ToDouble(Round(currentDisplayNumber));
            resultString = currentDisplayNumber.ToString();
            currentDisplayString = resultString;
            return;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayString;
        }
    }


}
