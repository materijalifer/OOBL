﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
	{


		#region Stock functions
		public void ListStock(string stockName, long inNum, decimal startingPrice, DateTime startingTime)
        {
			Stock stock = new Stock(stockName, inNum, startingPrice, startingTime);
			
			foreach (Stock st in allStocks)
                if (st.Name == stock.Name) 
                    throw new StockExchangeException("A stock with the same name already exists");

            allStocks.Add(stock);
        }

		public void DelistStock(string stockName)
        {
            foreach (Stock st in allStocks)
            {
                if (st.Name == stockName)
                {
                    foreach (Index ind in allIndexes)
                        RemoveStockFromIndex(ind.Name, stockName);
                    foreach (Portfolio port in allPortfolios)
                        RemoveStockFromPortfolio(port.ID, stockName);
                    allStocks.Remove(st);
                    return;
                }
            }
			throw new StockExchangeException("There is no stock with the given name");
        }

		public bool StockExists(string stockName)
        {
			foreach (Stock st in allStocks)
			{
                if (st.Name == stockName) 
                    return true;
			}
			return false;
        }

        public int NumberOfStocks()
        {
			return allStocks.Count;
        }

        public void SetStockPrice(string stockName, DateTime startingTime, decimal inPrice)
        {
			foreach (Stock st in allStocks)
			{
                if (st.Name == stockName)
				{
					StockPrice price = new StockPrice
					{
						Price = inPrice,
                        Time = startingTime
					};
					if (price.Time < st.StartingDateTime)
						throw new StockExchangeException("A price cannot have a starting time earlier than its designated stock.");
					st.AddPrice(price);
					return;
				}
			}
			throw new StockExchangeException("The stock does not exist");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
			foreach (Stock dionica in allStocks)
			{
				if (dionica.Name == inStockName)
				{
					return dionica.GetPrice(inTimeStamp);
				}
			}
			throw new StockExchangeException("The stock does not exist");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
			foreach (Stock dionica in allStocks)
			{
				if (dionica.Name == inStockName)
				{
					return dionica.StartingPrice;
				}
			}
			throw new StockExchangeException("The stock does not exist");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
			foreach (Stock dionica in allStocks)
			{
                if (dionica.Name == inStockName)
                {
                    return dionica.LastKnownPrice;
                }
			}
			throw new StockExchangeException("The stock does not exist");
        }
		#endregion

		#region Indeks functions
		public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
			Index indeks = new Index
			{
				Name = inIndexName,
				Type = inIndexType
			};

			foreach (Index indeks1 in allIndexes)
			{
				if (indeks1.Name == indeks.Name) throw new StockExchangeException("Index already exists.");
			}

			allIndexes.Add(indeks);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName)
				{
					foreach (Stock dionica in allStocks)
					{
						if (dionica.Name == inStockName)
						{
							indeks.AddStock(dionica);
							return;
						}
					}
					throw new StockExchangeException("Stock already exists.");
				}
			}
			throw new StockExchangeException("Index does not exist.");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName)
				{
					foreach (Stock dionica in allStocks)
					{
						if (dionica.Name == inStockName)
						{
							indeks.RemoveStock(dionica);
							return;
						}
						throw new StockExchangeException("Stock does not exist.");
					}
				}
			}
			throw new StockExchangeException("Index does not exist.");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName)
				{
					foreach (Stock dionica in indeks.allStocks)
					{
						if (dionica.Name == inStockName)
						{
						    return true;
						}
					}
					return false;
				}
			}
            throw new StockExchangeException("Index does not exist.");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName)
				{
					return indeks.GetValue(this.UkupnaVrijednostDionicaNaTržištu);
				}
			}
            throw new StockExchangeException("Index does not exist.");
        }

        public bool IndexExists(string inIndexName)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName) return true;
			}
			return false;
        }

        public int NumberOfIndices()
        {
			return allIndexes.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
			foreach (Index indeks in allIndexes)
			{
				if (indeks.Name == inIndexName)
				{
					return indeks.BrojDionica;
				}
			}
            throw new StockExchangeException("Index does not exist.");
        }
		#endregion

		#region Portfolio functions
		public void CreatePortfolio(string inPortfolioID)
        {
			Portfolio portfelj = new Portfolio { ID = inPortfolioID };

			foreach (Portfolio portfelj1 in allPortfolios)
			{
				if (portfelj1.ID == portfelj.ID) throw new StockExchangeException("Portfolio already exists");
			}

			allPortfolios.Add(portfelj);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					foreach (Stock dionica in allStocks)
					{
						if (dionica.Name == inStockName)
						{
							int brZakupljenihDionica = 0;
							foreach (Portfolio portfelj1 in allPortfolios)
							{
								brZakupljenihDionica += portfelj1.GetCountOfStockInPortfolio(inStockName);
							}
							if (brZakupljenihDionica + numberOfShares > dionica.NumberOfShares)
								throw new StockExchangeException("There isn't enough stock on the market.");
							portfelj.AddStock(dionica, numberOfShares);
							return;
						}
					}
					throw new StockExchangeException("Stock does not exist.");
				}
			}
            throw new StockExchangeException("Index does not exist.");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					portfelj.RemoveStock(inStockName, numberOfShares);
					return;
				}
			}
            throw new StockExchangeException("Portfolio does not exist..");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					portfelj.RemoveStock(inStockName);
					return;
				}
			}
            throw new StockExchangeException("Portfolio does not exist.");
        }

        public int NumberOfPortfolios()
        {
			return allPortfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
					return portfelj.BrojDionica;
			}
            throw new StockExchangeException("Portfolio does not exist.");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID) return true;
			}
			return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.IsStockInPortfolio(inStockName);
				}
			}
            throw new StockExchangeException("Portfolio does not exist.");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.GetCountOfStockInPortfolio(inStockName); 
				}
			}
            throw new StockExchangeException("Portfolio does not exist.");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.GetValue(timeStamp);
				}
			}
            throw new StockExchangeException("Portfolio does not exist.");
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
			foreach (Portfolio portfelj in allPortfolios)
			{
				if (portfelj.ID == inPortfolioID)
				{
					return portfelj.CalculateMonthlyChange(Year, Month);
				}
			}
            throw new StockExchangeException("Portfolio does not exist.");
		}
		#endregion

        #region Liste objekata
        List<Stock> allStocks = new List<Stock>();
        List<Index> allIndexes = new List<Index>();
        List<Portfolio> allPortfolios = new List<Portfolio>();
        #endregion

		#region Additional properties
		public decimal UkupnaVrijednostDionicaNaTržištu
		{
			get
			{
				decimal vrijednost = 0;
				foreach (Stock dionica in allStocks)
					vrijednost += dionica.LastKnownPrice * dionica.NumberOfShares;
				return vrijednost;
			}
		}
		#endregion


	}

	#region Model classes
	public class Stock
	{
		public string Name { get; set; }
		public long NumberOfShares { get; set; }
        public DateTime StartingDateTime { get; set; }
        public decimal StartingPrice { get; set; }
		
		private List<StockPrice> listOfStockPrices = new List<StockPrice>();

		public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
		{
		    this.Name = inStockName.ToUpper();

            if(inNumberOfShares <= 0)
                throw new StockExchangeException("Number of shares must be 1 or above");
            this.NumberOfShares = inNumberOfShares;

            if (inInitialPrice <= 0) throw new StockExchangeException("Price cannot be below 0");
            this.StartingPrice = inInitialPrice;

            this.StartingDateTime = inTimeStamp;

			StockPrice pocetnaCijenaZaListu = new StockPrice
			{
                Price = this.StartingPrice,
                Time = this.StartingDateTime
			};


			this.listOfStockPrices.Add(pocetnaCijenaZaListu);
		}

	    #region Public methods

	    public void AddPrice(StockPrice inPrice)
	    {
	        foreach (StockPrice stprice in listOfStockPrices)
	            if (stprice.Time == inPrice.Time)
	                throw new StockExchangeException("Price for that time is already defined.");
	        listOfStockPrices.Add(inPrice);
	    }

	    public Decimal LastKnownPrice
	    {
	        get { return GetLastPrice(); }
	    }

	    public Decimal GetPrice(DateTime inTime)
	    {
	        DateTime maxTime = this.StartingDateTime;
	        //ako se traži cijena prije nego što je promjenjena
	        if (inTime < maxTime)
	            return 0;
	        int maxIndex = 0;
	        for (int i = 0; i < listOfStockPrices.Count; i++)
	        {
	            if ((listOfStockPrices[i].Time >= maxTime) && (listOfStockPrices[i].Time <= inTime))
	            {
	                maxTime = listOfStockPrices[i].Time;
	                maxIndex = i;
	            }
	        }
	        return listOfStockPrices[maxIndex].Price;
	    }

	    #endregion

        private decimal GetLastPrice()
        {
            DateTime maxTime = this.StartingDateTime;
            int maxIndex = 0;
            for (int i = 0; i < listOfStockPrices.Count; i++)
            {
                if (listOfStockPrices[i].Time > maxTime)
                {
                    maxTime = listOfStockPrices[i].Time;
                    maxIndex = i;
                }
            }
            return listOfStockPrices[maxIndex].Price;
        }
	}

	public class StockPrice
	{
		public DateTime Time { get; set; }
		public decimal Price { get; set; }
	}

	public class Index
	{
		public string Name { get; set; }
		public IndexTypes Type { get; set; }

		public List<Stock> allStocks = new List<Stock>();

		public int BrojDionica
		{
			get
			{
				return allStocks.Count;
			}
		}

		public decimal GetValue(decimal ukupnaVrijednostDionicaNaTržištu)
		{
			decimal vrijednost = 0;
			long brDionica = 0;
			decimal sum = 0;

			if (this.Type == IndexTypes.AVERAGE)
			{
				foreach (Stock dionica in this.allStocks)
				{
					vrijednost += dionica.LastKnownPrice * dionica.NumberOfShares;
				}
				vrijednost = Decimal.Round(vrijednost / allStocks.Count, 3);
			}
			else
			{
                foreach (Stock dionica in this.allStocks)
                {
                    vrijednost += dionica.LastKnownPrice * dionica.NumberOfShares;
                }
				foreach (Stock dionica in this.allStocks)
				{
					decimal faktor = dionica.LastKnownPrice*dionica.NumberOfShares/vrijednost;
					sum += dionica.LastKnownPrice * faktor;
				}
				vrijednost = Decimal.Round(sum, 3);
			}

			return vrijednost;
		}

		public void AddStock(Stock dionica)
		{
			foreach (Stock dionica1 in this.allStocks)
			{
				if (dionica1.Name == dionica.Name )
					throw new StockExchangeException("This stock already exist in the index");
			}
			this.allStocks.Add(dionica);
		}

		public void RemoveStock(Stock dionica)
		{
			for (int i=0; i<this.allStocks.Count; i++)
			{
				if (this.allStocks[i].Name == dionica.Name)
				{
					this.allStocks.Remove(this.allStocks[i]);
					return;
				}
			}
			throw new StockExchangeException("This stock does not exist in the index");
		}
	}

	public class Portfolio
	{
		public string ID { get; set; }
		private List<StockInPortfolio> listaUdjela = new List<StockInPortfolio>();

		public int BrojDionica
		{
			get
			{
				return listaUdjela.Count;
			}
		}

		public decimal GetValue(DateTime timeStamp)
		{
		    decimal sum = 0;
			foreach (StockInPortfolio udio in listaUdjela)
				sum += udio.PortfStock.GetPrice(timeStamp) * udio.NumOfStocks;
			return sum;
		}

		public bool IsStockInPortfolio(string inStockName)
		{
			foreach (StockInPortfolio udio in listaUdjela)
			{
				if (udio.PortfStock.Name == inStockName) return true;
			}
			return false;
		}

		public int GetCountOfStockInPortfolio(string inStockName)
		{
			foreach (StockInPortfolio udio in listaUdjela)
			{
				if (udio.PortfStock.Name == inStockName)
					return udio.NumOfStocks;
			}
			return 0;
		}

		public void AddStock(Stock dionica, int numShares)
		{
			foreach (StockInPortfolio udio in listaUdjela)
			{
				if (udio.PortfStock.Name == dionica.Name)
				{
					udio.NumOfStocks += numShares;
					return;
				}
			}
			
			StockInPortfolio udio1 = new StockInPortfolio
			{
				PortfStock = dionica,
				NumOfStocks = numShares
			};
			listaUdjela.Add(udio1);
		}

		public void RemoveStock(string inStockName, int numberOfShares)
		{
			foreach (StockInPortfolio udio in listaUdjela)
			{
				if (udio.PortfStock.Name == inStockName)
				{
					if (udio.NumOfStocks - numberOfShares < 0)
						throw new StockExchangeException("There isn't so much stocks in given portfolio");
					udio.NumOfStocks -= numberOfShares;
					return;
				}
			}
			throw new StockExchangeException("That stock isn't present in the portfolio");
		}

		public void RemoveStock(string inStockName)
		{
			for (int i = 0; i < listaUdjela.Count; i++)
			{
				if (listaUdjela[i].PortfStock.Name == inStockName)
				{
					listaUdjela.Remove(listaUdjela[i]);
					return;
				}
			}
            throw new StockExchangeException("That stock isn't present in the portfolio");
		}

		public decimal CalculateMonthlyChange(int year, int month)
		{
			DateTime startTime = new DateTime(year, month, 1);
			int brDanaUMjesecu = System.DateTime.DaysInMonth(year, month);
			DateTime endTime = new DateTime(year, month, brDanaUMjesecu);
			endTime.AddHours(23);
			endTime.AddMinutes(59);
			endTime.AddSeconds(59);
			decimal startValue = 0;
			decimal endValue = 0;

			foreach (StockInPortfolio udio in listaUdjela)
			{
				startValue += udio.PortfStock.GetPrice(startTime);
			}

			foreach (StockInPortfolio udio in listaUdjela)
			{
				endValue += udio.PortfStock.GetPrice(endTime);
			}

			decimal value = (endValue - startValue) / startValue * 100;
			return Decimal.Round(value, 3);
		}
	}

	public class StockInPortfolio
	{
		public Stock PortfStock { get; set; }
		public int NumOfStocks { get; set; }
	}
	#endregion
}
