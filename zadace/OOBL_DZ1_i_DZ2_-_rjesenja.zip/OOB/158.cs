﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Dodao sam dosta komentara koji su na prvu mozda suvisni, no
// buduci kako ima velik broj metoda sa slicnim imenima koje pripadaju
// razlicitim klasama, vjerujem da ce Vam ovo olaksati snalazenje
// po ovom (dugom) kodu :)

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    // Klasa Stock:
    public class Stock
    {
        private string _stockName;
        private long _totalNumberOfShares;
        private long _numberOfShares;
        private decimal _initialStockPrice;
        SortedDictionary<DateTime,decimal> _prices = new SortedDictionary<DateTime,decimal>();

        // Klasa Stock...
        public Stock (string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0 || inInitialPrice <= 0)
                throw new StockExchangeException("Stock input incorrect!");
            else
            {
                _stockName = inStockName;
                _totalNumberOfShares = inNumberOfShares;
                _numberOfShares = inNumberOfShares;
                _initialStockPrice = inInitialPrice;
                _prices.Add(inTimeStamp, inInitialPrice);
            }
        }

        // Klasa Stock...
        public long GetTotalNumberOfShares
        {
            get { return _totalNumberOfShares; }
        }

        // Klasa Stock...
        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value;  }
        }

        // Klasa Stock...
        public string GetName
        {
            get { return _stockName; }
        }

        // Klasa Stock...
        public decimal GetInitialStockPrice
        {
            get { return _initialStockPrice; }
        }

        // Klasa Stock...
        public decimal GetLastStockPrice
        {
            get { return _prices.Values.Last(); }
        }

        // Klasa Stock...
        public decimal GetPrice(DateTime inTimeStamp)
        {
            decimal TMPprice = -1;
            foreach (DateTime timeStamp in _prices.Keys)
                if (inTimeStamp >= timeStamp)
                    TMPprice = _prices[timeStamp];
            if (TMPprice != -1) return TMPprice;
            throw new StockExchangeException("The timeStamp is before any defined one");
        }

        // Klasa Stock...
        public void newPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (_prices.ContainsKey(inTimeStamp))
                throw new StockExchangeException("A value for that TimeStamp is already set");
            else
                _prices.Add(inTimeStamp, inStockValue);
        }
    }

    // Klasa Index...
    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        List<Stock> _myIndexStocks = new List<Stock>();

        // Klasa Index...
        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if ((inIndexType != IndexTypes.AVERAGE) & (inIndexType != IndexTypes.WEIGHTED))
                throw new StockExchangeException("No such index type!");
            else
            {
                _indexName = inIndexName;
                _indexType = inIndexType;
            }
        }

        // Klasa Index...
        public int NumberOfStocks
        {
            get { return _myIndexStocks.Count; }
        }

        // Klasa Index...
        public Stock GetStock(Stock stock)
        {
            if (_myIndexStocks.Contains(stock))
                return stock;
            else
                throw new StockExchangeException("Stock not found in index!");
        }

        // Klasa Index...
        public string GetName
        {
            get { return _indexName; }
        }

        // Klasa Index...
        public void AddStock(Stock stock)
        {
            if (_myIndexStocks.Contains(stock))
                throw new StockExchangeException("Stock is already part of index!");
            else
                _myIndexStocks.Add(stock);
        }

        // Klasa Index...
        public void RemoveStock(Stock stock)
        {
            _myIndexStocks.Remove(stock);
        }

        // Klasa Index...
        public bool IsStockPartOfIndex(Stock stock)
        {
            return (_myIndexStocks.Contains(stock));
        }

        // Klasa Index...
        public decimal EvaluateIndexValue(DateTime inTimeStamp)
        {
            decimal indexValue = 0;

            if (_indexType == IndexTypes.AVERAGE)
            { 
                int numOfStocks = _myIndexStocks.Count;
                
                foreach (Stock stock in _myIndexStocks)
                    indexValue += stock.GetPrice(inTimeStamp);

                return decimal.Round(indexValue / numOfStocks, 3);
            }
            else if (_indexType == IndexTypes.WEIGHTED)
            {
                decimal sumOfValues = 0;

                foreach (Stock stock in _myIndexStocks)
                {
                    sumOfValues += stock.GetTotalNumberOfShares * stock.GetPrice(inTimeStamp);
                    indexValue += stock.GetTotalNumberOfShares * stock.GetPrice(inTimeStamp) * stock.GetPrice(inTimeStamp);
                }

                return decimal.Round(indexValue / sumOfValues, 3);
            }
            else
                throw new StockExchangeException("Error in evaluating index value!");
        }
    }

    // Klasa Portfolio...
    public class Portfolio
    {
        private string _ID;
        Dictionary<Stock,int> _myPortfolioStocks = new Dictionary<Stock,int>();

        // Klasa Portfolio...
        public Portfolio(string ID)
        {
            _ID = ID;
        }

        // Klasa Portfolio...
        public string GetID
        {
            get { return _ID; }
        }

        // Klasa Portfolio...
        public int NumberOfStocks
        {
            get { return _myPortfolioStocks.Count; }
        }

        // Klasa Portfolio...
        public bool IsStockPartOfPortfolio(Stock stock)
        {
            return _myPortfolioStocks.ContainsKey(stock);
        }

        // Klasa Portfolio...
        public void AddStock(Stock inStock,int numOfShares)
        {
            if (_myPortfolioStocks.ContainsKey(inStock))
                _myPortfolioStocks[inStock] += numOfShares;
            else
                _myPortfolioStocks.Add(inStock, numOfShares);
        }

        // Klasa Portfolio...
        public void RemoveStock(Stock inStock, int numberOfShares)
        {
            if (_myPortfolioStocks.ContainsKey(inStock))
            {
                if (_myPortfolioStocks[inStock] > numberOfShares)
                    _myPortfolioStocks[inStock] -= numberOfShares;
                else if (_myPortfolioStocks[inStock] == numberOfShares)
                    _myPortfolioStocks.Remove(inStock);
                else
                    throw new StockExchangeException("Invalid number of stocks!");
            }
            else
                throw new StockExchangeException("No such stock in portfolio!");
        }

        // Klasa Portfolio...
        public long RemoveStock(Stock inStock)
        {
            if (_myPortfolioStocks.ContainsKey(inStock))
            {
                long numberOfShares = _myPortfolioStocks[inStock];
                _myPortfolioStocks.Remove(inStock);
                return numberOfShares;
            }
            throw new StockExchangeException("No such stock in portfolio!");
        }

        // Klasa Portfolio...
        public int NumberOfSharesOfStock(string inStockName)
        {
            foreach (KeyValuePair<Stock, int> pair in _myPortfolioStocks)
                if (pair.Key.GetName == inStockName)
                    return pair.Value;
            return 0;
        }

        // Klasa Portfolio...
        public decimal GetValue(DateTime timeStamp)
        {
            decimal portfolioValue = 0;
            foreach (KeyValuePair<Stock, int> pair in _myPortfolioStocks)
            {
                portfolioValue += pair.Key.GetPrice(timeStamp) * pair.Value;
            }
            return portfolioValue;
        }

        // Klasa Portfolio...
        public decimal GetValue(int Year, int Month)
        {
            decimal beginningOfMonthValueOfPortfolio = 0;
            decimal endOfMonthValueOfPortfolio = 0;
            DateTime beginningOfMonth = new DateTime(Year,Month,1,00,00,00);
            DateTime endOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            foreach (KeyValuePair<Stock, int> pair in _myPortfolioStocks)
            {
                beginningOfMonthValueOfPortfolio += pair.Key.GetPrice(beginningOfMonth) * pair.Value;
                endOfMonthValueOfPortfolio += pair.Key.GetPrice(endOfMonth) * pair.Value;
            }
            return decimal.Round(((100 * endOfMonthValueOfPortfolio - beginningOfMonthValueOfPortfolio) / beginningOfMonthValueOfPortfolio), 3);
        }
    }

    // Klasa StockExchange...
    public class StockExchange : IStockExchange
    {
        // Klasa StockExchange: 'simulira' repozitorij sa listama
        List<Stock> _stocks = new List<Stock>();
        List<Index> _indexes = new List<Index>();
        List<Portfolio> _portfolios = new List<Portfolio>();

        // Klasa StockExchange: dohvacanje dionica iz 'repozitorija'
        public Stock GetStock(string inStockName)
        {
            inStockName = inStockName.ToLower();
            foreach (Stock stock in _stocks)
                if (stock.GetName == inStockName)
                    return stock;
            throw new StockExchangeException("No stock with such a name!");
        }

        // Klasa StockExchange: dohvacanje indeksa iz 'repozitorija'
        public Index GetIndex(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();
            foreach (Index index in _indexes)
                if (index.GetName == inIndexName)
                    return index;
            throw new StockExchangeException("No index with such a name!");
        }

        // Klasa StockExchange: dohvacanje portfelja iz 'repozitorija'
        public Portfolio GetPortfolio(string inPortfolioID)
        {
            foreach (Portfolio portfolio in _portfolios)
                if (portfolio.GetID == inPortfolioID)
                    return portfolio;
            throw new StockExchangeException("No portfolio with such an ID!");
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToLower();
            
            foreach (Stock stock in _stocks)
                if (stock.GetName == inStockName) 
                    throw new StockExchangeException("Stock input incorrect!");

            _stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void DelistStock(string inStockName)
        {
            Stock stock = GetStock(inStockName);
            foreach (Index index in _indexes)
            {
                if (index.IsStockPartOfIndex(stock))
                    index.RemoveStock(stock);
            }
            foreach (Portfolio portfolio in _portfolios)
            {
                if (portfolio.IsStockPartOfPortfolio(stock))
                    portfolio.RemoveStock(stock);
            }
            _stocks.Remove(stock);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public bool StockExists(string inStockName)
        {
            inStockName = inStockName.ToLower();

            foreach (Stock stock in _stocks)
            {
                if (stock.GetName == inStockName) return true;
            }
            return false;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            Stock stock = GetStock(inStockName);
            stock.newPrice(inTimeStamp,inStockValue);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = GetStock(inStockName);
            return stock.GetPrice(inTimeStamp);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = GetStock(inStockName);
            return stock.GetInitialStockPrice;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = GetStock(inStockName);
            return stock.GetLastStockPrice;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            inIndexName = inIndexName.ToLower();

            foreach (Index index in _indexes)
                if (index.GetName == inIndexName)
                    throw new StockExchangeException("Index already exists!");

            _indexes.Add(new Index(inIndexName,inIndexType));
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock stock = GetStock(inStockName);
            Index index = GetIndex(inIndexName);
            index.AddStock(stock);     
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stock = GetStock(inStockName);
            Index index = GetIndex(inIndexName);
            index.RemoveStock(stock);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stock = GetStock(inStockName);
            Index index = GetIndex(inIndexName);
            return index.IsStockPartOfIndex(stock);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = GetIndex(inIndexName);
            return index.EvaluateIndexValue(inTimeStamp);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public bool IndexExists(string inIndexName)
        {
            inIndexName = inIndexName.ToLower();
            foreach (Index index in _indexes)
                if (index.GetName == inIndexName)
                    return true;
            return false;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfIndices()
        {
            return _indexes.Count;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = GetIndex(inIndexName);
            return index.NumberOfStocks;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void CreatePortfolio(string inPortfolioID)
        {
            foreach (Portfolio portfolio in _portfolios)
                if (portfolio.GetID == inPortfolioID)
                    throw new StockExchangeException("Portfolio with that ID already exists!");
            _portfolios.Add(new Portfolio(inPortfolioID));
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Invalid number of shares");

            Portfolio portfolio = GetPortfolio(inPortfolioID);
            Stock stock = GetStock(inStockName);
            if (stock.NumberOfShares >= numberOfShares)
            {
                stock.NumberOfShares -= numberOfShares;
                portfolio.AddStock(stock, numberOfShares);
            }
            else
                throw new StockExchangeException("Not enought shares of stock");

        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Invalid number of shares");

            Portfolio portfolio = GetPortfolio(inPortfolioID);
            Stock stock = GetStock(inStockName);
            portfolio.RemoveStock(stock, numberOfShares);
            stock.NumberOfShares += numberOfShares;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            Stock stock = GetStock(inStockName);
            long numberOfShares = portfolio.RemoveStock(stock);
            stock.NumberOfShares += numberOfShares;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            return portfolio.NumberOfStocks;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (Portfolio portfolio in _portfolios)
                if (portfolio.GetID == inPortfolioID)
                    return true;
            return false;
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            Stock stock = GetStock(inStockName);
            return portfolio.IsStockPartOfPortfolio(stock);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            Stock stock = GetStock(inStockName);
            return portfolio.NumberOfSharesOfStock(stock.GetName);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            return portfolio.GetValue(timeStamp);
        }

        // Klasa StockExchange: metoda zadana IStockExchange-om
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if ((Year > 0) && (Month >= 12 || Month <= 1))
                throw new StockExchangeException("Incorrect year or date!");
            Portfolio portfolio = GetPortfolio(inPortfolioID);
            return portfolio.GetValue(Year,Month);
        }
    }
}
