﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char operacijaUTijeku = 'N'; // N kao ni jedna, može biti +, -, *, /
        private string cjelobrojniDio = "0";
        private string decimalniDio = "";
        private bool automatskiPrikazBroja = false;
        private bool zarezAktivan = false;
        private bool prviBrojUnesen = false;
        private bool predznakAktivan = false;
        private decimal memorija = 0;
        private decimal prviBroj = 0;
        private decimal automatskiBroj = 0;

        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
        }

        private void reset()
        {
            this.cjelobrojniDio = "0";
            this.decimalniDio = "";
            this.zarezAktivan = false;
            this.prviBrojUnesen = false;
            this.predznakAktivan = false;
            this.memorija = 0;
            this.prviBroj = 0;
            this.operacijaUTijeku = 'N';
            this.automatskiPrikazBroja = false;
        }
        private void brisanjeEkrana()
        {
            this.cjelobrojniDio = "0";
            this.decimalniDio = "";
            this.zarezAktivan = false;
            this.predznakAktivan = false;
        }
        private bool stringSadrziSamoNule(string s)
        {
            foreach (char c in s)
                if (c != '0')
                    return false;
            return true;
        }
        private void srediBrojNaEkranu()
        {
            //ako decimalni dio sadrži samo nule
            if (stringSadrziSamoNule(this.decimalniDio))
            {
                this.decimalniDio = "";
                this.zarezAktivan = false;
            }
            this.decimalniDio = this.decimalniDio.TrimEnd('0');
            //ako cjelobrojni dio ima više od dopuštenog broja znamenaka
            if (this.cjelobrojniDio.Length > 10)
                throw new Exception();
            else // potrebno je zaokružiti decimalni dio
            {
                if (decimalniDio != "")
                {
                    string[] zaokruzi = Math.Round(decimal.Parse("0," + this.decimalniDio), 10 - this.cjelobrojniDio.Length).ToString().Split(',');
                    zarezAktivan = true;
                    this.decimalniDio = zaokruzi[1];
                }
            }
        }
        public string srediAutomatskiPrikazBroja(string s)
        {
            string temp = "";
            string[] polje = s.Split(',');
            if (polje[0][0] == '-')
            {
                polje[0] = polje[0].Substring(1);
                temp += "-";
            }
                
            if (polje[0].Length > 10)
            {
                throw new Exception();
            }
            else
            {
                temp += polje[0];
                
                if (polje.Length==2 && polje[1] != "")
                {
                    polje[1] = polje[1].TrimEnd('0');
                    string[] zaokruzi = Math.Round(decimal.Parse("0," + polje[1]), 10 - polje[0].Length).ToString().Split(',');
                    if (zaokruzi.Length == 2 && zaokruzi[1].TrimEnd('0') != "")
                        temp += "," + zaokruzi[1].TrimEnd('0');
                }
            }

            return temp;
        }
        private void dodajDecimalniBrojNaEkran(decimal broj)
        {
            string[] brojString = broj.ToString().Split(',');
            if (brojString[0][0] == '-')
            {
                this.cjelobrojniDio = brojString[0].Substring(1);
                this.predznakAktivan = true;
            }
            else
            {
                this.cjelobrojniDio = brojString[0];
                this.predznakAktivan = false;
            }
            this.zarezAktivan = false;
            if (brojString.Length == 2) // ako je u memoriji i decimalni dio
            {
                this.zarezAktivan = true;
                this.decimalniDio = brojString[1];
            }
        }
        private decimal pretvoriUDecimalniBroj(bool predznak, string lijevoOdZareza, string desnoOdZareza)
        {
            string temp = "";
            if (predznak)
                temp += "-";
            return (decimal.Parse(temp + lijevoOdZareza + "," + desnoOdZareza));
        }
        private decimal obaviBinarnuOperaciju(decimal prvi, decimal drugi, char operacija)
        {
            if (operacija == '+')
                return prvi + drugi;
            else if (operacija == '-')
                return prvi - drugi;
            else if (operacija == '*')
                return prvi * drugi;
            else
                return prvi / drugi;
        }
        private decimal obaviUnarnuOperaciju(decimal prvi, char operacija)
        {
            if (operacija == 'S')
                return (decimal)Math.Sin((double)prvi);
            else if (operacija == 'K')
                return (decimal)Math.Cos((double)prvi);
            else if (operacija == 'T')
                return (decimal)Math.Tan((double)prvi);
            else if (operacija == 'Q')
                return (decimal)Math.Pow((double)prvi, 2);
            else if (operacija == 'R')
                return (decimal)Math.Sqrt((double)prvi);
            else 
                return (decimal)(1 / prvi);
            
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                if (inPressedDigit >= '0' && inPressedDigit <= '9') // pritisnuta je znamenka
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                    if (this.automatskiPrikazBroja) // ako je automatski prikaz broja treba pobrisat ekran
                    {
                        this.automatskiBroj = 0;
                        this.automatskiPrikazBroja = false;
                        brisanjeEkrana();
                    }
                    
                    if (this.prviBrojUnesen)
                    {
                        brisanjeEkrana();
                        this.prviBrojUnesen = false;
                    }

                    if (!this.zarezAktivan) //unos cjelobrojnog dijela
                    {
                        if (this.cjelobrojniDio.Length < 10)
                        {
                            if (this.cjelobrojniDio == "0")
                                this.cjelobrojniDio = inPressedDigit.ToString();
                            else
                                this.cjelobrojniDio += inPressedDigit;
                        }
                    }
                    else // unos decimalnog dijela
                    {
                        if ((this.decimalniDio.Length + this.cjelobrojniDio.Length) < 10)
                            this.decimalniDio += inPressedDigit;
                    }
                }
                else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/') //binarne operacije
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                    srediBrojNaEkranu();
                    //nije nikakva operacija u tijeku
                    if (operacijaUTijeku == 'N')
                    {
                        //ako je automatski prikaz aktivan on postaje prvi
                        if (this.automatskiPrikazBroja)
                        {
                            this.prviBroj = this.automatskiBroj;
                            dodajDecimalniBrojNaEkran(this.prviBroj);
                            this.automatskiPrikazBroja = false;
                            this.automatskiBroj = 0;
                        }
                        else
                            this.prviBroj = pretvoriUDecimalniBroj(this.predznakAktivan, this.cjelobrojniDio, this.decimalniDio);
                        this.operacijaUTijeku = inPressedDigit;
                        this.prviBrojUnesen = true;
                    }
                    //neka operacija je u tijeku
                    else
                    {
                        //nije unos istog operatora
                        //potrebno je obaviti operaciju
                        if (!prviBrojUnesen) //malo cudna provjera al' radi :)
                        {
                            //drugi broj na ekranu je automatski
                            if (this.automatskiPrikazBroja)
                            {
                                dodajDecimalniBrojNaEkran(obaviBinarnuOperaciju(this.prviBroj, this.automatskiBroj, this.operacijaUTijeku));
                                this.automatskiPrikazBroja = false;
                                this.automatskiBroj = 0;
                            }
                            else // neki novi broj je unesen za drugi operand
                            {
                                dodajDecimalniBrojNaEkran(obaviBinarnuOperaciju(this.prviBroj, pretvoriUDecimalniBroj(this.predznakAktivan, this.cjelobrojniDio, this.decimalniDio), this.operacijaUTijeku));
                            }

                            srediBrojNaEkranu();
                            this.prviBroj = pretvoriUDecimalniBroj(this.predznakAktivan, this.cjelobrojniDio, this.decimalniDio);
                            this.operacijaUTijeku = inPressedDigit;
                            this.prviBrojUnesen = true;
                        }
                        //inače unos novog binarnog operatora preko već postojećeg
                        else
                        {
                            this.operacijaUTijeku = inPressedDigit;
                        }
                    }
                }
                else if (inPressedDigit == '=')
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                    //neka binarna operacija je u tijeku
                    if (this.operacijaUTijeku != 'N')
                    {
                        if (this.prviBrojUnesen) // unesen je samo prvi broj
                        {
                            dodajDecimalniBrojNaEkran(obaviBinarnuOperaciju(this.prviBroj, this.prviBroj, this.operacijaUTijeku));
                        }
                        else //unesen je i drugi
                        {
                            //drugi broj na ekranu je automatski
                            if (this.automatskiPrikazBroja)
                            {
                                dodajDecimalniBrojNaEkran(obaviBinarnuOperaciju(this.prviBroj, this.automatskiBroj, this.operacijaUTijeku));
                                this.automatskiPrikazBroja = false;
                                this.automatskiBroj = 0;
                            }
                            else // neki novi broj je unesen za drugi operand
                            {
                                dodajDecimalniBrojNaEkran(obaviBinarnuOperaciju(this.prviBroj, pretvoriUDecimalniBroj(this.predznakAktivan, this.cjelobrojniDio, this.decimalniDio), this.operacijaUTijeku));
                            }
                        }
                        operacijaUTijeku = 'N';
                        prviBroj = 0;
                        prviBrojUnesen = false;
                    }

                    srediBrojNaEkranu();
                }
                else if (inPressedDigit == ',' || inPressedDigit == 'M') // , ili promjena predznaka
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                    if (inPressedDigit == ',')
                    {
                        if (this.automatskiPrikazBroja)
                        {
                            brisanjeEkrana();
                            this.automatskiPrikazBroja = false;
                            this.automatskiBroj = 0;
                        }
                        this.zarezAktivan = true;
                    }
                    else
                    {
                        if (predznakAktivan)
                            predznakAktivan = false;
                        else
                            predznakAktivan = true;
                    }
                }
                else if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T' || // unarne operacije
                          inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                        if (automatskiPrikazBroja) // ako već imamo automatski prikaz broja njega treba unarno
                        {
                            this.automatskiBroj = decimal.Parse(srediAutomatskiPrikazBroja(obaviUnarnuOperaciju(this.automatskiBroj, inPressedDigit).ToString()));
                        }
                        else // inače ono što je na ekranu ide u automatski prikaz broja
                        {
                            this.automatskiBroj = decimal.Parse(srediAutomatskiPrikazBroja(obaviUnarnuOperaciju(pretvoriUDecimalniBroj(this.predznakAktivan, this.cjelobrojniDio, this.decimalniDio), inPressedDigit).ToString()));
                            this.automatskiPrikazBroja = true;
                        }
                        if (this.operacijaUTijeku != 'N')
                            this.prviBrojUnesen = false;
                  
                }
                else if (inPressedDigit == 'P' || inPressedDigit == 'G') // memorija
                {
                    if (cjelobrojniDio == "-E-")
                        throw new Exception();

                    if (inPressedDigit == 'P') // spremanje u memoriju
                    {
                        this.memorija = decimal.Parse(GetCurrentDisplayState());
                    }
                    else // dohvaćanje iz memorije
                    {
                        dodajDecimalniBrojNaEkran(this.memorija);
                    }
                }
                if (inPressedDigit == 'C' || inPressedDigit == 'O') // brisanje ekrana, reset kalkulatora
                {
                    if (inPressedDigit == 'C')
                    {
                        brisanjeEkrana();
                    }
                    else
                    {
                        reset();
                    }
                }
     
            }
            catch (Exception ex)
            {
                this.cjelobrojniDio = "-E-";
                this.zarezAktivan = false;
                this.predznakAktivan = false;
                this.decimalniDio = "";
            }
        }

        public string GetCurrentDisplayState()
        {
            if (this.automatskiPrikazBroja)
                return this.automatskiBroj.ToString();
            
            string display ="";
            if (predznakAktivan)
                display = "-";
            //ako cjelobrojni dio postoji
            display += this.cjelobrojniDio;
            
            //ako decimalni dio postoji
            if (this.zarezAktivan)
                display += ",";
            if (this.decimalniDio.Length != 0)
                display += this.decimalniDio;

            return display;

        }
    }


}
