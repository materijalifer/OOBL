﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        int digitsCounter = 0;
        string display = "0";
        string tmp = "0";
        string op;
        string memory = "";
        bool opPressed = false;
        bool shortCalc = true;
        bool newNumber = true;

        List<string> binaryOperators = new List<string>(){"+","-", "*","-"};
        List<string> unaryOperators = new List<string>() { "S", "K", "T", "Q", "R", "I" };

        #region FormatNumber
        private string FormatNumber(string number)
        {
            string[] digits = Regex.Split(number, string.Empty);
            int totalDigits = 0;
            int beforeDecimal = 0;
            string afterDecimal = "0,";
            string formatedNumber = "";
            bool pointFound = false;
            bool minus = false;
            int result;

            for (int i = 0; i < digits.Count(); i++)
            {
                if (digits[i] == "-")
                {
                    minus = true;
                }
                else if (digits[i] == ",")
                {
                    formatedNumber += digits[i];
                    pointFound = true;
                }
                else if (Int32.TryParse(digits[i], out result))
                {
                    if (totalDigits > 10)
                    {
                        if (!pointFound)
                        {
                            beforeDecimal++;
                        }
                        else
                            afterDecimal += digits[i];
                        if (beforeDecimal > 10)
                            break;
                    }
                    else
                    {
                        totalDigits++;
                        if (!pointFound)
                        {
                            beforeDecimal++;
                            formatedNumber += digits[i];
                        }
                        else
                        {
                            afterDecimal += digits[i];
                        }
                    }
                }
            }

            if (beforeDecimal > 10)
            {
                formatedNumber = "-E-";
            }
            else
            {
                double pom = 0;
                if (pointFound)
                {
                    pom = Math.Round(Double.Parse(afterDecimal), (10 - beforeDecimal));
                }
                double value = Double.Parse(formatedNumber);
                if (minus)
                {
                    formatedNumber = ((value + pom) * -1).ToString();
                }
                else
                {
                    formatedNumber = (value + pom).ToString();
                }
            }
            return formatedNumber;
        }
        #endregion

        #region BinaryOperation
        private string BinaryOperation(string num1, string num2, string op)
        {
            string result = "";

            try
            {
                double operand1 = Double.Parse(num1);
                double operand2 = Double.Parse(num2);

                switch (op)
                {
                    case "+":
                        result = FormatNumber((operand1 + operand2).ToString());
                        break;
                    case "-":
                        result = FormatNumber((operand1 - operand2).ToString());
                        break;
                    case "*":
                        result = FormatNumber((operand1 * operand2).ToString());
                        break;
                    case "/":
                        result = FormatNumber((operand1 / operand2).ToString());
                        break;
                    default:
                        break;
                }
            }
            catch
            {
                result = "-E-";
            }

            return result;
        }
        #endregion

        #region UnaryOperation
        private string UnaryOperation(string num1, string op)
        {
            string result = "";
            try
            {
                double operand1 = Double.Parse(num1);
                switch (op)
                {
                    case "S":
                        result = FormatNumber(Math.Sin(operand1).ToString());
                        break;
                    case "K":
                        result = FormatNumber(Math.Cos(operand1).ToString());
                        break;
                    case "T":
                        result = FormatNumber(Math.Tan(operand1).ToString());
                        break;
                    case "Q":
                        result = FormatNumber(Math.Pow(operand1, 2).ToString());
                        break;
                    case "R":
                        result = FormatNumber(Math.Pow(operand1, 1 / 2).ToString());
                        break;
                    case "I":
                        result = FormatNumber((1 / operand1).ToString());
                        break;
                    default:
                        break;
                }
            }
            catch
            {
                result = "-E-";
            }
            return result;
        }
        #endregion

        public void Press(char inPressedDigit)
        {
            int number;
            bool isNumber;
            string input = inPressedDigit.ToString();
            isNumber = Int32.TryParse(input, out number);

            if (isNumber && digitsCounter < 10 && display != "-E-")
            {
                shortCalc = false;
                if (newNumber)
                {
                    if (display != "0,")
                    {
                        display = "0";
                    }
                    newNumber = false;
                }
                try
                {
                    display = FormatNumber(Double.Parse(display + input).ToString());
                }
                catch
                {
                    display = "-E-";
                }
                digitsCounter++;
            }

            else if (input == "," && display != "-E-")
            {
                display += ",";
            }
            else if (input == "M" && display != "-E-")
            {
                try
                {
                    display = FormatNumber((Double.Parse(display) * (-1)).ToString());
                }
                catch
                {
                    display = "-E-";
                }
            }

            else if (binaryOperators.Contains(input) && display != "-E-")
            {
                if (!opPressed)
                {
                    opPressed = true;
                    shortCalc = true;
                    op = input;
                    tmp = display;
                    digitsCounter = 0;
                    newNumber = true;
                }
                else
                {
                    if (newNumber)
                    {
                        op = input;
                    }
                    else
                    {
                        display = BinaryOperation(tmp, display, op);
                        op = input;
                        tmp = display;
                        digitsCounter = 0;
                        newNumber = true;
                    }
                }
            }

            else if (unaryOperators.Contains(input) && display != "-E-")
            {
                string result = UnaryOperation(display, input);
                display = result;
            }

            else if (input == "=" && display != "-E-")
            {
                if (opPressed)
                {
                    if (shortCalc)
                    {
                        display = BinaryOperation(display, display, op);
                        tmp = display;
                        opPressed = false;
                    }
                    else
                    {
                        display = BinaryOperation(tmp, display, op);
                        tmp = display;
                        opPressed = false;
                    }
                }
            }

            else if (input == "P" && display != "-E-")
            {
                memory = display;
            }
            else if (input == "G")
            {
                display = memory;
            }
            else if (input == "C")
            {
                display = "0";
            }
            else if (input == "O")
            {
                digitsCounter = 0;
                display = "0";
                tmp = "0";
                memory = "";
                opPressed = false;
                shortCalc = true;
                newNumber = true;
            }
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }
    }
}
