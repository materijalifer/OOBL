﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Math;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        // stanje kalkulatora
        private string memoryNumber;
        private string displayState;
        private char operation = ' ';
        private char unaryOperation = ' ';
        private string savedNumber = "";
        bool lockCurrentNumber = false;

        public void Press(char inPressedDigit)
        {
            // pretpostavka je da nakon greske mozemo dalje nastaviti rad s kalkulatorom
            if (displayState == "-E-")
            {
                displayState = "";
            }

            if (displayState == "0" && isNumber(inPressedDigit))
            {
                // brišemo nulu i pišemo samo znak
                displayState = inPressedDigit.ToString();
            }

            else if (isScreenOperation(inPressedDigit))
            {
                manipulateScreen(inPressedDigit);
            }

            else if (isBinaryOperation(inPressedDigit))
            {
                if ((operation != ' ') && (savedNumber != "") && (lockCurrentNumber == false))
                {
                    if (displayState != "")
                    {
                        compute(operation, savedNumber, displayState);
                    }
                    else
                    {
                        compute(operation, savedNumber);
                    }
                }
                operation = inPressedDigit;
                savedNumber = displayState;
                lockCurrentNumber = true;
            }

            else if (isUnaryOperation(inPressedDigit))
            {
                // zbrajanje i slicno
                unaryOperation = inPressedDigit;
                computeUnary(unaryOperation, displayState);
                unaryOperation = ' ';
            }

            else if (isEquality(inPressedDigit))
            {
                // kliknuli smo jednako i trazimo izracun
                if (operation != ' ')
                {
                    if (displayState != "")
                    {
                        compute(operation, savedNumber, displayState);
                    }
                    else
                    {
                        compute(operation, savedNumber);
                    }
                }
                displayState = roundNumber(displayState);
                displayState = trimZeroes(displayState);
                operation = ' ';
            }
            else if (isMinus(inPressedDigit))
            {
                changePolarity();
            }
            else
            {
                // pisanje obicnih brojki
                if (lockCurrentNumber)
                {
                    displayState = inPressedDigit.ToString();
                    lockCurrentNumber = false;
                }
                else
                {
                    String tempResult = displayState + inPressedDigit.ToString();
                    if (longNumber(tempResult))
                    {
                        tempResult = cutNumber(tempResult);
                    }
                    displayState = tempResult;
                }
                if (displayState.Count(c => c == ',') > 1) displayState = displayState.Remove(displayState.Count() - 1, 1);
            }
            // skrati broj koji je dulji od 10 znakova
            displayState = roundNumber(displayState);
        }

        public string GetCurrentDisplayState()
        {
            return this.displayState;
        }

        public Kalkulator()
        {
            displayState = "0";
        }

        public bool isScreenOperation(char inDigit)
        {
            if (inDigit == 'P' || inDigit == 'G' || inDigit == 'C' || inDigit == 'O')
            {
                return true;
            }
            return false;
        }

        public bool isNumber(char inDigit)
        {
            if (inDigit == '0' || inDigit == '1' || inDigit == '2' || inDigit == '3' || inDigit == '4' || inDigit == '5' || inDigit == '6' || inDigit == '7' || inDigit == '8' || inDigit == '9')
            {
                return true;
            }
            return false;
        }
        public bool isComma(char inDigit)
        {
            if (inDigit == ',')
            {
                return true;
            }
            return false;
        }

        public bool isBinaryOperation(char inDigit)
        {
            if (inDigit == '+' || inDigit == '-' || inDigit == '*' || inDigit == '/')
            {
                return true;
            }
            return false;
        }

        public bool isUnaryOperation(char inDigit)
        {
            if (inDigit == 'S' || inDigit == 'K' || inDigit == 'T' || inDigit == 'Q' || inDigit == 'R' || inDigit == 'I')
            {
                return true;
            }
            return false;
        }

        public bool isEquality(char inDigit)
        {
            if (inDigit == '=')
            {
                return true;
            }
            return false;

        }

        public bool isMinus(char inDigit)
        {
            if (inDigit == 'M')
            {
                return true;
            }
            return false;
        }

        private void changePolarity()
        {
            // ako postoji broj na ekranu promijeni mu polaritet
            if (displayState != "")
            {
                if (double.Parse(displayState) >= 0) { displayState = "-" + displayState; }
                else
                {
                    displayState = displayState.Remove(0);
                }
            }
            else displayState = "-";
        }

        private void manipulateScreen(char operation)
        {
            if (operation == 'P')
            {
                memoryNumber = displayState;
            }
            else if (operation == 'G')
            {
                displayState = memoryNumber;

            }
            else if (operation == 'C')
            {
                //mice zadnji znak          
                displayState = displayState.Remove(displayState.Length - 1, 1);
                if (displayState == "") displayState = "0";
            }
            else if (operation == 'O')
            {
                displayState = "0";
                memoryNumber = "";
                savedNumber = "0";
                operation = ' ';
                unaryOperation = ' ';
            }
        }
        // funkcija za skraceni zapis operacija s istim operatorom
        private void compute(char operation, string onlyNumber)
        {
            double result = 0;
            double number = double.Parse(onlyNumber);

            if (operation == '+')
            {
                result = number + number;

            }
            else if (operation == '-')
            {
                result = number - number;

            }
            else if (operation == '*')
            {
                result = number * number;

            }
            else if (operation == '/')
            {
                result = number / number;

            }
            if (result.ToString().Count() > 10) errorOnDisplay();
            else displayState = result.ToString();
            operation = ' ';
        }
        // funkcija koja prima broj i operaciju koja se koristi za izracun
        private void compute(char operation, string leftNumber, string rightNumber)
        {
            double result = 0;
            double firstNumber = double.Parse(leftNumber);
            double secondNumber = double.Parse(rightNumber);

            if (operation == '+')
            {
                result = firstNumber + secondNumber;

            }
            else if (operation == '-')
            {
                result = firstNumber - secondNumber;

            }
            else if (operation == '*')
            {
                result = firstNumber * secondNumber;

            }
            else if (operation == '/')
            {
                result = firstNumber / secondNumber;

            }
            string tempResult = result.ToString();
            tempResult = roundNumber(tempResult);
            if (longNumber(tempResult)) errorOnDisplay();
            else displayState = tempResult;
        }
        // funkcija za rad s unarnim operacijama
        private void computeUnary(char operation, string onlyNumber)
        {
            double result = 0;
            double number = double.Parse(onlyNumber);

            if (operation == 'S')
            {
                result = Math.Sin(number);
            }
            else if (operation == 'K')
            {
                result = Math.Cos(number);

            }
            else if (operation == 'T')
            {
                result = Math.Tan(number);

            }
            else if (operation == 'Q')
            {
                result = Math.Pow(number, 2);
            }
            else if (operation == 'R')
            {
                result = Math.Pow(number, 0.5);

            }
            else if (operation == 'I')
            {
                if (number != 0)
                {
                    result = 1 / number;
                }
                else errorOnDisplay();
            }

            if (displayState != "-E-")
            {
                string tempResult = result.ToString();
                tempResult = roundNumber(tempResult);
                if (longNumber(tempResult)) errorOnDisplay();
                else displayState = tempResult;
            }
        }

        private void errorOnDisplay()
        {
            displayState = "-E-";
        }

        private string roundNumber(string number)
        {
            int availibleDigits = 10;
            if (number.Contains(',')) availibleDigits++;
            if (number.Contains('-')) availibleDigits++;

            if (number.Count() > availibleDigits)
            {
                double decimalNumber = double.Parse(number);

                string[] s = number.Split(',');
                string leftString = s[0];

                if (number.Contains(',')) number = Math.Round(decimalNumber, availibleDigits - leftString.Count() - 1).ToString();

            }
            return number;
        }

        private string cutNumber(string number)
        {
            int availibleDigits = 10;
            if (number.Contains(',')) availibleDigits++;
            if (number.Contains('-')) availibleDigits++;

            if (number.Count() > availibleDigits)
            {
                number = number.Substring(0, availibleDigits);
            }
            return number;
        }

        private bool longNumber(string number)
        {
            int availibleDigits = 10;
            if (number.Contains(',')) availibleDigits++;
            if (number.Contains('-')) availibleDigits++;

            if (number.Count() > availibleDigits)
            {
                return true;
            }
            return false;
        }

        private string trimZeroes(string number)
        {
            number.TrimEnd('0');
            if (number.Last() == '0') number = Math.Round(Double.Parse(number)).ToString();
            return number;
        }
    }
}