﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private const char PLUS = '+';
        private const char MINUS = '-';
        private const char PUTA = '*';
        private const char PODJELJENO = '/';
        private char[] BINARNI_OPERATORI = { PLUS, MINUS, PUTA, PODJELJENO };

        private const char SINUS = 'S';
        private const char KOSINUS = 'K';
        private const char TANGENS = 'T';
        private const char KVADRAT = 'Q';
        private const char KORJEN = 'R';
        private const char INVERZ = 'I';
        private char[] UNARNI_OPERATORI = { SINUS, KOSINUS, TANGENS, KVADRAT, KORJEN, INVERZ };

        private const char JEDNAKO = '=';
        private const char ZAREZ = ',';
        private const char SPREMANJE_U_MEMORIJU = 'P';
        private const char DOHVACANJE_IZ_MEMORIJE = 'G';
        private const char PROMJENA_PREDZAKA = 'M';

        private const char POCETNO_STANJE = 'p';
        private const char BINARNA_OPERACIJA = 'b';
        private const char UNARNA_OPERACIJA = 'u';

        private const double NAJVECI_MOGUCI_BROJ = 9999999999;

        private StringBuilder sb = new StringBuilder("0");
        private char trenutnoStanje = POCETNO_STANJE;
        private bool jeNegiran = false;
        private bool prvaZnameknaNakonOperacije = false; 

        private string prviOperand;
        private string medjurezultat;
        private string trenutnoStanjeEkrana = "0";

        public void Press(char inPressedDigit)
        {

            string ekran = sb.ToString();

            switch (trenutnoStanje)
            {
                case POCETNO_STANJE:

                    if (Char.IsDigit(inPressedDigit))
                    {
                        if (ekran.Length < 10 + (ekran.Contains(ZAREZ) ? 1 : 0))
                        {

                            if (ekran.Equals("0"))
                            {
                                sb.Clear();
                                sb.Append(inPressedDigit);
                                trenutnoStanjeEkrana = sb.ToString();
                            }
                            else
                            {
                                sb.Append(inPressedDigit);
                                trenutnoStanjeEkrana = sb.ToString();
                            }
                        }
                    }

                    else
                    {
                        if (BINARNI_OPERATORI.Contains(inPressedDigit))
                        {
                            prviOperand = sb.ToString();
                            trenutnoStanje = BINARNA_OPERACIJA;
                            prvaZnameknaNakonOperacije = true;
                        }
                        else
                        {
                            if (UNARNI_OPERATORI.Contains(inPressedDigit))
                            {
                                trenutnoStanjeEkrana = ObaviUnarnuOperaciju(sb.ToString(), inPressedDigit);
                                sb.Clear();
                                trenutnoStanje = UNARNA_OPERACIJA;
                            }
                        }
                    }


                    break;

                case BINARNA_OPERACIJA:


                    break;

                case UNARNA_OPERACIJA:


                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return trenutnoStanjeEkrana;
        }

        private string ObaviBinarnuOperaciju(string prviOperand, string drugiOperand, char operacija)
        {

            double prvi = Convert.ToDouble(prviOperand);
            double drugi = Convert.ToDouble(drugiOperand);
            double rezultat = 0;

            switch (operacija)
            {
                case PLUS:
                    rezultat = prvi + drugi;
                    break;
                case MINUS:
                    rezultat = prvi - drugi;
                    break;
                case PUTA:
                    rezultat = prvi * drugi;
                    break;
                case PODJELJENO:
                    rezultat = prvi / drugi;
                    break;
            }

            return (Convert.ToString(Zaokruzi(rezultat)));
      
        }

        private string ObaviUnarnuOperaciju(string operand, char operacija)
        {

            double broj = Convert.ToDouble(operand);
            double rezultat = 0;

            switch (operacija)
            {

                case SINUS :
                    rezultat = Math.Sin(broj);
                    break;
                case KOSINUS:
                    rezultat = Math.Cos(broj);
                    break;
                case TANGENS:
                    rezultat = Math.Tan(broj);
                    break;
                case KVADRAT:
                    rezultat = broj * broj;
                    break;
                case KORJEN:
                    rezultat = Math.Sqrt(broj);
                    break;
                case INVERZ:
                    rezultat = 1/broj;
                    break;
            }

            return (Convert.ToString(Zaokruzi(rezultat)));

        }

        private string Zaokruzi(double rezultat)
        {

            if (rezultat > NAJVECI_MOGUCI_BROJ)
            {
                throw new System.InvalidOperationException();
            }

            int indeksZareza = Convert.ToString(rezultat).IndexOf(ZAREZ);

            return (Math.Round(rezultat, 10 - indeksZareza + rezultat < 0 ? 1 : 0).ToString());

        }

    }


}
