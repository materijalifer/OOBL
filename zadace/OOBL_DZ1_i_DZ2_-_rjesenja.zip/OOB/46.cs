﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new SpektakularniKalkulator();
        }
    }

    public class SpektakularniKalkulator:ICalculator
    {
        private Boolean reset = true;
        private string currentDisplay = "0";
        private double currentNumber = 0;
        private Boolean negative = false;
        private Boolean decimalPoint = false;
        private double power = 10;
        private char operatorPressed = 'N';
        private Boolean operatorLast = false;        
        private double firstOperand = 0;
        private double Memory = 0;

        public void Press(char inPressedDigit) 
        {
            //Unos brojeva
            if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                if (operatorLast)
                {
                    currentDisplay = "0";
                    currentNumber = 0;                    
                }
                if ((currentDisplay.Length <= 9 && (!negative) && (!decimalPoint)) ||
                    (currentDisplay.Length <= 10 && ((negative && (!decimalPoint)) || ((!negative) && decimalPoint))) ||
                    (currentDisplay.Length <= 11 && negative && decimalPoint))
                {
                    if ((currentNumber == 0 && (!inPressedDigit.Equals('0')) && (!decimalPoint)) || 
                        (currentNumber != 0 && (!decimalPoint)))
                    {
                        if (negative)
                        {
                            currentNumber = currentNumber * 10 - ((double)inPressedDigit - 48);                            
                        }
                        else
                            currentNumber = currentNumber * 10 + ((double)inPressedDigit - 48);
                        currentDisplay = NumberToString(currentNumber);
                    }

                    if ((currentNumber == 0 && decimalPoint && (!inPressedDigit.Equals('0'))) ||
                        (currentNumber != 0 && decimalPoint && (!inPressedDigit.Equals('0'))))
                    {
                        if (negative)
                            currentNumber = currentNumber - (((double)inPressedDigit - 48) / power);
                        else
                            currentNumber = currentNumber + (((double)inPressedDigit - 48) / power);
                        power *= 10;
                        currentDisplay = NumberToString(currentNumber);
                    }
                    
                    if (decimalPoint && inPressedDigit.Equals('0'))
                    {
                        if (power == 10)
                        {
                            currentDisplay = currentDisplay + ",0";
                            power *= 10;
                        }
                        else
                        {
                            currentDisplay = currentDisplay + "0";
                            power *= 10;
                        }
                    }
                }
                operatorLast = false;                                
            }

            //Unos decimalnog zareza
            if (inPressedDigit.Equals(','))
            {
                decimalPoint = true;
                operatorLast = false;
            }
            
            //Unos predznaka
            if (inPressedDigit.Equals('M'))
            {
                currentNumber *= -1;
                if (negative) negative = false;
                else negative = true;

                if (currentDisplay.Equals("0") && negative) currentDisplay = "-0";
                else currentDisplay = NumberToString(currentNumber);
                reset = false;
            }
            
            //Unos operatora zbrajanja
            if (inPressedDigit.Equals('+'))
            {
                if (!operatorLast && (!operatorPressed.Equals('N')))
                {
                    currentNumber = doOperation(firstOperand, currentNumber, operatorPressed);
                    currentDisplay = NumberToString(currentNumber);
                }
                operatorPressed = '+';              
                if (!operatorLast)
                    firstOperand = currentNumber;
                operatorLast = true;
                currentNumber = 0;
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos operatora oduzimanja
            if (inPressedDigit.Equals('-'))
            {
                if (!operatorLast && (!operatorPressed.Equals('N')))
                {
                    currentNumber = doOperation(firstOperand, currentNumber, operatorPressed);
                    currentDisplay = NumberToString(currentNumber);
                }
                operatorPressed = '-';               
                if (!operatorLast)
                    firstOperand = currentNumber;
                operatorLast = true;
                currentNumber = 0;
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos operatora mnozenja
            if (inPressedDigit.Equals('*'))
            {
                if (!operatorLast && (!operatorPressed.Equals('N')))
                {
                    currentNumber = doOperation(firstOperand, currentNumber, operatorPressed);
                    currentDisplay = NumberToString(currentNumber);
                }
                operatorPressed = '*';                
                if (!operatorLast) 
                    firstOperand = currentNumber;
                operatorLast = true;
                currentNumber = 0;
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos operatora dijeljenja
            if (inPressedDigit.Equals('/'))
            {
                if (!operatorLast && (!operatorPressed.Equals('N')))
                {
                    currentNumber = doOperation(firstOperand, currentNumber, operatorPressed);
                    currentDisplay = NumberToString(currentNumber);
                }
                operatorPressed = '/';                
                if (!operatorLast) 
                    firstOperand = currentNumber;
                operatorLast = true;
                currentNumber = 0;
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka jednako
            if (inPressedDigit.Equals('='))
            {
                if (!(operatorPressed.Equals('N')))
                {
                    if (operatorLast)
                        currentNumber = doOperation(firstOperand, firstOperand, operatorPressed);
                    else
                        currentNumber = doOperation(firstOperand, currentNumber, operatorPressed);
                    operatorPressed = 'N';                    
                }
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za reset
            if (inPressedDigit.Equals('O'))
            {
                reset = true;
                currentDisplay = "0";
                currentNumber = 0;
                negative = false;
                decimalPoint = false;
                power = 10;
                operatorPressed = 'N';
                operatorLast = false;        
                firstOperand = 0;
                Memory = 0;
            }

            //Unos znaka za spremanje u memoriju
            if (inPressedDigit.Equals('P'))
            {
                Memory = currentNumber;                
            }

            //Unos znaka za dohvat iz memorije
            if (inPressedDigit.Equals('G'))
            {
                currentNumber = Memory;
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za brisanje ekrana
            if (inPressedDigit.Equals('C'))
            {
                currentDisplay = "0";
                currentNumber = 0;                                
            }

            //Unos znaka za sinus
            if (inPressedDigit.Equals('S'))
            {
                if (operatorLast) currentNumber = firstOperand;
                currentNumber = Math.Sin(currentNumber);
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za kosinus
            if (inPressedDigit.Equals('K'))
            {
                if (operatorLast) currentNumber = firstOperand;
                currentNumber = Math.Cos(currentNumber);
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za tangens
            if (inPressedDigit.Equals('T'))
            {
                if (operatorLast) currentNumber = firstOperand;
                currentNumber = Math.Tan(currentNumber);
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za kvadriranje
            if (inPressedDigit.Equals('Q'))
            {
                if (operatorLast) currentNumber = firstOperand;
                currentNumber = currentNumber * currentNumber;
                currentDisplay = NumberToString(currentNumber);
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za korjenovanje
            if (inPressedDigit.Equals('R'))
            {
                if (operatorLast) currentNumber = firstOperand;
                if (currentNumber < 0) currentDisplay = "-E-";
                else
                {
                    currentNumber = Math.Sqrt(currentNumber);
                    currentDisplay = NumberToString(currentNumber);
                }
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }

            //Unos znaka za inverz
            if (inPressedDigit.Equals('I'))
            {
                if (operatorLast) currentNumber = firstOperand;
                if (currentNumber == 0) currentDisplay = "-E-";
                else
                {
                    currentNumber = 1 / (currentNumber);
                    currentDisplay = NumberToString(currentNumber);
                }
                decimalPoint = false;
                negative = false;
                power = 10;
                reset = false;
            }
        }

        //Metoda za obavljanje binarnih operacija
        private double doOperation(double firstOperand, double secondOperand, char operatorPressed)
        {
            switch (operatorPressed)
            {
                case '+': return firstOperand + secondOperand;
                case '-': return firstOperand - secondOperand;
                case '*': return firstOperand * secondOperand;
                case '/':
                    {
                        if (secondOperand == 0) return -10000000000;
                        return firstOperand / secondOperand;
                    }
                default: return -10000000000;
            }
        }

        public string GetCurrentDisplayState()
        {
            
            if (this.reset)
            {
                return "0";
            }
            else return currentDisplay;
        }
        
        //Pretvaranje broja u tekst za prikaz
        private string NumberToString(double currentNumber)
        {
            int decimalComma = 0;
            string currentDisplay = null;
            
            if (negative && currentNumber > 0) negative = false;
            if ((!negative) && currentNumber < 0) negative = true;

            if (currentNumber > 9999999999 || currentNumber < -9999999999) currentDisplay = "-E-";
            else
            {
                currentDisplay = currentNumber.ToString();
                                
                if (currentDisplay.Contains(','))
                {                    
                    decimalComma = currentDisplay.IndexOf(',');
                    if (negative)
                    {
                        if (decimalComma == 11) currentDisplay.Remove(decimalComma);
                        if (decimalComma < 11)
                        {
                            currentNumber = Math.Round(currentNumber, 11 - decimalComma);
                            currentDisplay = currentNumber.ToString();
                        }
                    }
                    else
                    {
                        if (decimalComma == 10) currentDisplay.Remove(decimalComma);
                        if (decimalComma < 10)
                        {
                            currentNumber = Math.Round(currentNumber, 10 - decimalComma);
                            currentDisplay = currentNumber.ToString();
                        }
                    }
                }

                
            }
            this.reset = false;
            return currentDisplay;
        }
    }


}
