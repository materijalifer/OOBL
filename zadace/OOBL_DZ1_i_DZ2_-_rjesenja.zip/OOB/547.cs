﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new SimpleStockExchange();
        }
    }

    /// <summary>
    /// Implementacija burze
    /// </summary>
    public class SimpleStockExchange : IStockExchange
    {

        public SimpleStockExchange()
        {
            _stocks = new List<Stock>();
            _indicesRep = new Repository<Index>();
            _portfolioRep = new Repository<Portfolio>();
            StockPriceArchive archive = StockPriceArchive.GetInstance();
            archive.Clear();
        }

        List<Stock> _stocks;
        Repository<Index> _indicesRep;
        Repository<Portfolio> _portfolioRep;

        #region IStockExchange Members

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0 || inInitialPrice <= 0)
                throw new StockExchangeException("Number of shares and price cannot be negative!");

            Stock sl = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

            if (_stocks.Contains(sl))
                throw new StockExchangeException("Stock already exists!");
            else
                _stocks.Add(sl);
        }

        public void DelistStock(string inStockName)
        {
            Stock s = getStock(inStockName);
            _stocks.Remove(s);

            foreach(Index index in _indicesRep)
            {
                index.RemoveStock(inStockName);
            }

            foreach (Portfolio portfolio in _portfolioRep)
            {
                portfolio.RemoveStock(inStockName);
            }
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.Where(x => x.CheckStockNameEquality(inStockName)).Count() != 0;
        }

        public int NumberOfStocks()
        {
            return _stocks.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock s = getStock(inStockName);

            if (inIimeStamp <= s.InTimestamp)
            {
                s.InitialPrice = inStockValue;
                s.InTimestamp = inIimeStamp;
            }

            StockPriceArchive archive = StockPriceArchive.GetInstance();
            archive.SaveStockChange(inStockName, inIimeStamp, inStockValue);

            s.CurrentPrice = archive.GetLastPrice(inStockName);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock s = getStock(inStockName);
            if (inTimeStamp < s.InTimestamp)
                throw new StockExchangeException("Price is not defined for this moment!");

            StockPriceArchive archive = StockPriceArchive.GetInstance();

            decimal price = archive.GetStockPriceAtTime(inStockName, inTimeStamp);
            return price;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock s = _stocks.Where(x => x.CheckStockNameEquality(inStockName)).First();
            return s.InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock s = _stocks.Where(x => x.CheckStockNameEquality(inStockName)).First();
            return s.CurrentPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index = new Index();
            index.Name = inIndexName;
            index.IndexType = inIndexType;

            if (!_indicesRep.ContainsObject(inIndexName))
                _indicesRep.Add(index);
            else
                throw new StockExchangeException("Index already exists!");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Stock s = getStock(inStockName);
            Index index = getIndex(inIndexName);

            index.AddStock(s);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);
            index.RemoveStock(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);
            return index.ContainsStock(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = getIndex(inIndexName);
            return index.GetValue();
        }

        public bool IndexExists(string inIndexName)
        {
            return _indicesRep.ContainsObject(inIndexName);
        }

        public int NumberOfIndices()
        {
            return _indicesRep.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return getIndex(inIndexName).GetStockCount();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio p = new Portfolio(inPortfolioID);
            _portfolioRep.Add(p);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Invalid number of stocks!");

            Portfolio p = _portfolioRep.Get(inPortfolioID);

            int alreadyInProtfolios = 0;

            foreach (Portfolio portfolio in _portfolioRep)
            {
                alreadyInProtfolios += portfolio.GetNumberOfShares(inStockName);
            }

            int sharesToBeAdded = numberOfShares;
            Stock s = getStock(inStockName);

            if (numberOfShares + alreadyInProtfolios > s.NumberOfShares)
            {
                sharesToBeAdded = ((int)s.NumberOfShares) - alreadyInProtfolios;
            }

            p.AddStock(getStock(inStockName), sharesToBeAdded);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio p = _portfolioRep.Get(inPortfolioID);
            p.RemoveStock(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio p = _portfolioRep.Get(inPortfolioID);
            p.RemoveStock(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return _portfolioRep.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio p = _portfolioRep.Get(inPortfolioID);
            return p.GetNumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return 
                _portfolioRep.ContainsObject(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio p = _portfolioRep.Get(inPortfolioID);
            return p.ContainsStock(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return
                _portfolioRep.Get(inPortfolioID).GetNumberOfShares(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return 
                _portfolioRep.Get(inPortfolioID).GetPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (Year < 0 || Year > DateTime.MaxValue.Year || Month < 0 || Month > 12)
                throw new StockExchangeException("Wrong month or year!");

            Portfolio p = _portfolioRep.Get(inPortfolioID);
            decimal beginning = p.GetPortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
            decimal end = p.GetPortfolioValue(new DateTime(Year, Month,
                DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

            return decimal.Round(((end - beginning) / beginning) * 100, 3);
        }

        #endregion

        private Index getIndex(string indexName)
        {
            return _indicesRep.Get(indexName);
        }

        private Stock getStock(string stockName)
        {
            try
            {
                return
                    _stocks.Where(x => x.CheckStockNameEquality(stockName)).First();
            }
            catch (Exception)
            {
                throw new StockExchangeException("Error while retrieving stock!");
            }
        }
    }

    /// <summary>
    /// Klasa predstavlja dionicu na burzi.
    /// </summary>
    public class Stock
    {
        public string StockName { get; set; }
        public decimal InitialPrice { get; set; }
        public decimal CurrentPrice { get; set; }
        public long NumberOfShares { get; set; }
        public DateTime InTimestamp { get; set; }

        public Stock(string StockName)
        {
            this.StockName = StockName;
        }

        public Stock(string StockName, long NumberOfShares, decimal InitialPrice, DateTime TimeStamp)
        {
            this.StockName = StockName;
            this.NumberOfShares = NumberOfShares;
            this.InitialPrice = InitialPrice;
            this.CurrentPrice = InitialPrice;
            this.InTimestamp = TimeStamp;

            StockPriceArchive archive = StockPriceArchive.GetInstance();
            archive.SaveStockChange(StockName, TimeStamp, InitialPrice);
        }

        public bool CheckStockNameEquality(string name)
        {
            return StockName.ToLower().Equals(name.ToLower());
        }

        public override string ToString()
        {
            return StockName;
        }

        public override bool Equals(object obj)
        {
            Stock s = (Stock)obj;
            return StockName.ToLower().Equals(s.StockName.ToLower());
        }

        public override int GetHashCode()
        {
            return StockName.GetHashCode();
        }
    }

    /// <summary>
    /// Singleton klasa koja arhivira sve promjene svih dionica
    /// </summary>
    public class StockPriceArchive
    {
        private static StockPriceArchive instance;

        private Dictionary<string, List<StockChange>> _archive;

        private StockPriceArchive() 
        {
            _archive = new Dictionary<string, List<StockChange>>();
        }

        public void SaveStockChange(string stockName, DateTime timeStamp, decimal stockValue)
        {
            StockChange sc = new StockChange(timeStamp, stockValue);

            List<StockChange> stockChanges = null;

            try
            {
                stockChanges = _archive[stockName.ToLower()];

                if (stockChanges.Contains(sc))
                    throw new StockExchangeException("This timechange allready exists");

                stockChanges.Add(sc);
            }
            catch (KeyNotFoundException)
            {
                stockChanges = new List<StockChange>();
                stockChanges.Add(sc);
                _archive[stockName.ToLower()] = stockChanges;
            }

        }

        public decimal GetStockPriceAtTime(string stock, DateTime timeStamp)
        {
            List<StockChange> stockHistory = null;
            try
            {
                stockHistory = _archive[stock.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Error while retrieving stock history!");
            }

            if (stockHistory == null || stockHistory.Count == 0)
                throw new StockExchangeException("No history for this stock!");
            else
            {
                StockChange sc = null;
                try
                {
                    stockHistory.Sort();
                    sc = stockHistory.Where(x => x.ChangeTime <= timeStamp).Last();
                }
                catch (Exception)
                {
                    throw new StockExchangeException("Price not defined!");
                }

                if (sc == null)
                    throw new StockExchangeException("Price not defined for this moment!");
                else return sc.NewPrice;
            }
        }

        public decimal GetLastPrice(string stockId)
        {
            List<StockChange> changes = null;

            try
            {
                changes = _archive[stockId.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                return decimal.Zero;
            }

            changes.Sort();
            return changes.Last().NewPrice;
        }

        public void Clear()
        {
            _archive.Clear();
        }

        public static StockPriceArchive GetInstance()
        {
            if (instance == null)
                instance = new StockPriceArchive();

            return instance;
        }
    }

    /// <summary>
    /// Klasa koja enkapsulira vrijeme i novu cijenu dionice. Ova klasa predstavlja promjenu dionice
    /// i koristi se samo u <see cref="StockPriceArchive"/>
    /// </summary>
    class StockChange : IComparable
    {
        public DateTime ChangeTime { get; set; }
        public decimal NewPrice { get; set; }

        public StockChange(DateTime changeTime, decimal price)
        {
            this.ChangeTime = changeTime;
            this.NewPrice = price;
        }

        #region IComparable Members

        public int CompareTo(object obj)
        {
            StockChange sc = (StockChange)obj;
            if (this.ChangeTime < sc.ChangeTime)
                return -1;
            else if (this.ChangeTime == sc.ChangeTime)
                return 0;
            else
                return 1;
        }

        #endregion

        public override bool Equals(object obj)
        {
            StockChange sc = (StockChange)obj;
            return sc.ChangeTime.Equals(this.ChangeTime);
        }
    }

    /// <summary>
    /// Klasa predstavlja indeks na burzi.
    /// </summary>
    public class Index : IKeyComparer
    {
        private List<Stock> _stocks;
        public IndexTypes IndexType;
        public string Name { get; set; }

        public Index()
        {
            _stocks = new List<Stock>();
        }

        public void AddStock(Stock s)
        {
            if (!_stocks.Contains(s))
                _stocks.Add(s);
            else
                throw new StockExchangeException("This stock already exists in index!");
        }

        public void RemoveStock(string stockName)
        {
            if (!ContainsStock(stockName))
                throw new StockExchangeException("This stock doesnt exist!");
            _stocks.RemoveAll(x => x.CheckStockNameEquality(stockName));
        }

        public int GetStockCount()
        {
            return _stocks.Count;
        }

        public bool ContainsStock(string stockName)
        {
            return _stocks.Where(x => x.CheckStockNameEquality(stockName)).Count() != 0;
        }

        public decimal GetValue()
        {
            decimal v = decimal.Zero;

            if (_stocks.Count == 0)
                return decimal.Round(decimal.Zero,3);

            if (IndexType == IndexTypes.AVERAGE)
            {
                foreach (Stock stock in _stocks)
                    v += stock.CurrentPrice;

                v /= _stocks.Count;
            }
            else if (IndexType == IndexTypes.WEIGHTED)
            {
                decimal total = decimal.Zero;
                foreach (Stock stock in _stocks)
                    total += stock.CurrentPrice * stock.NumberOfShares;

                foreach (Stock stock in _stocks)
                {
                    decimal f = stock.CurrentPrice * stock.NumberOfShares;
                    f /= total;
                    v += f * stock.CurrentPrice;
                }
            }

            return decimal.Round(v, 3);
        }

        public override bool Equals(object obj)
        {
            Index ind = (Index)obj;
            return this.Name.ToLower().Equals(ind.Name.ToLower());
        }

        #region IKeyComparer Members

        public bool CompareKeys(object key)
        {
            return this.Name.ToLower().Equals(key.ToString().ToLower());
        }

        #endregion
    }

    /// <summary>
    /// Klasa predstavlja portfelj na burzi.
    /// </summary>
    public class Portfolio : IKeyComparer
    {
        private List<Stock> _stocks;
        private Dictionary<string, int> _stockCount;
        public string Name { get; set; }

        public Portfolio()
        {
            _stocks = new List<Stock>();
            _stockCount = new Dictionary<string, int>();
        }

        public Portfolio(string id)
        {
            _stocks = new List<Stock>();
            _stockCount = new Dictionary<string, int>();
            this.Name = id;
        }

        public override bool Equals(object obj)
        {
            Portfolio p = (Portfolio)obj;
            return this.Name.Equals(p.Name);
        }

        public void AddStock(Stock s, int numberOfStocks)
        {
            if (!_stocks.Contains(s))
            {
                _stocks.Add(s);
                _stockCount[s.StockName.ToLower()] = numberOfStocks;
            }
            else
            {
                _stockCount[s.StockName.ToLower()] += numberOfStocks;
            }
        }

        public void RemoveStock(string stockId, int numberOfShares)
        {
            if (!ContainsStock(stockId))
                throw new StockExchangeException("This stock doesn't exist!");

            int n = _stockCount[stockId.ToLower()];
            if (numberOfShares < n)
                _stockCount[stockId.ToLower()] -= numberOfShares;
            else
            {
                _stockCount.Remove(stockId.ToLower());
                _stocks.RemoveAll(x => x.CheckStockNameEquality(stockId));
            }
        }

        public void RemoveStock(string stockId)
        {
            if (!ContainsStock(stockId))
                throw new StockExchangeException("This stock doesn't exist!");
            _stockCount.Remove(stockId.ToLower());
            _stocks.RemoveAll(x => x.CheckStockNameEquality(stockId));
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal v = decimal.Zero;
            StockPriceArchive archive = StockPriceArchive.GetInstance();
            foreach (Stock s in _stocks)
            {
                v += archive.GetStockPriceAtTime(s.StockName, timeStamp) * _stockCount[s.StockName.ToLower()];
            }

            return v;
        }

        public int GetNumberOfStocks()
        {
            return _stocks.Count();
        }

        public int GetNumberOfShares()
        {
            int shares = 0;
            foreach (string s in _stockCount.Keys)
            {
                shares += _stockCount[s.ToLower()];
            }

            return shares;
        }

        public int GetNumberOfShares(string stockId)
        {
            try
            {
                return
                    _stockCount[stockId.ToLower()];
            }
            catch (KeyNotFoundException)
            {
                return 0;
            }
        }

        public bool ContainsStock(string stockId)
        {
            return
                _stocks.Where(x => x.CheckStockNameEquality(stockId)).Count() != 0;
        }

        #region IKeyComparer Members

        public bool CompareKeys(object key)
        {
            return Name.Equals(key);
        }

        #endregion
    }

    /// <summary>
    /// Parametrizirani repozitorij koji pohranjuje kolekcije indeksa i portfelja.
    /// </summary>
    /// <typeparam name="T">
    /// Tip objekata u repozitoriju mora implementriati sucelje IKeyComparer pomoću
    /// kojeg se objekti usporedjuju po kljucu
    /// </typeparam>
    public class Repository<T> : IEnumerable<T> where T:IKeyComparer
    {
        private List<T> _objects;

        public Repository()
        {
            _objects = new List<T>();
        }

        public bool ContainsObject(object key)
        {
            return _objects.Where(x => x.CompareKeys(key)).Count() != 0;
        }

        public int Count()
        {
            return _objects.Count;
        }

        public T Get(object key)
        {
            IEnumerable<T> collection =  _objects.Where(x => x.CompareKeys(key));

            if (collection == null || collection.Count() == 0)
                throw new StockExchangeException("Object doesn't exist!");
            else return
                collection.First();
        }

        public T GetAtIndex(int index)
        {
            return _objects[index];
        }

        public void Add(T x)
        {
            if (!_objects.Contains(x))
                _objects.Add(x);
            else
                throw new StockExchangeException("This object already exists!");
        }

        public void Remove(object key)
        {
            _objects.RemoveAll(x => x.CompareKeys(key));
        }



        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < _objects.Count; i++)
            {
                yield return _objects[i];
            }
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion
    }

    /// <summary>
    /// Sucelje za usporedjivanje po kljucu(koristi se za usporedbu portfelja i indeksa)
    /// </summary>
    public interface IKeyComparer
    {
        bool CompareKeys(object key);
    }
}
