﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<StockObj> _stockList = new List<StockObj>();
        private List<IIndex> _indexList = new List<IIndex>();
        private int _foundStockIndex = -1;
        private int _foundIndexIndex = -1;

        private List<IIndex> indexList
        {
            get { return this._indexList; }
            set { this._indexList = value; }
        }
        private int foundIndexIndex
        {
            get { return this._foundIndexIndex; }
            set { this._foundIndexIndex = value; }
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if ( StockExists(inStockName) )
                throw new StockExchangeException("In class StockExchange, ListStock(): <" + inStockName + "> dionica se već nalazi na burzi!");

            StockObj stock = new StockObj(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            this._stockList.Add(stock);
        }

        public void DelistStock(string inStockName)
        {
            for (int i = 0; i < this.indexList.Count; ++i) //ako postoje brišu se dionice iz svih indexa
            {
                if(this.indexList[i].isStockInIndex(inStockName) == true) {
                    int StockListIndex = this.indexList[i].foundStockListIndex;
                    this.indexList[i].stockList.RemoveAt(StockListIndex);
                }
            }
            if (StockExists(inStockName))
                this._stockList.RemoveAt(this._foundStockIndex);
            else
                throw new StockExchangeException("In class StockExchange, DelistStock(): <" + inStockName + "> dionica se ne nalazi na burzi!");
        }

        public bool StockExists(string inStockName)
        {
            for (int i = 0; i < this._stockList.Count; ++i)
            {
                if (_stockList[i].compareNames(inStockName))
                {
                    this._foundStockIndex = i;
                    return true;
                }
            }

            this._foundStockIndex = -1;
            return false;   
        }

        public int NumberOfStocks()
        {
            return this._stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, Decimal inStockValue)
        {
            if (StockExists(inStockName))
                _stockList[this._foundStockIndex].changeStockPrice(inTimeStamp, inStockValue);
            else
                throw new StockExchangeException("SetStockPrice() error:<" + inStockName + "> dionica se ne nalazi na burzi!");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            int customTimePrice = 2;

            if(StockExists(inStockName))
                return _stockList[this._foundStockIndex].getStockPrice(customTimePrice, inTimeStamp);
            else
                throw new StockExchangeException("In class StockExchange, GetStockPrice() error:<" + inStockName + "> dionica se ne nalazi na burzi!");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            int initialTimePrice = 0;

            if (StockExists(inStockName))
                return _stockList[this._foundStockIndex].getStockPrice(initialTimePrice);
            else
                throw new StockExchangeException("In class StockExchange, GetInitialStockPrice() error:<" + inStockName + "> dionica se ne nalazi na burzi!");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            int lastTimePrice = 1;

            if (StockExists(inStockName))
                return _stockList[this._foundStockIndex].getStockPrice(lastTimePrice);
            else
                throw new StockExchangeException("In class StockExchange, GetLastStockPrice() error:<" + inStockName + "> dionica se ne nalazi na burzi!");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
                throw new StockExchangeException("In class StockExchange, CreateIndex() error: <" + inIndexName + "> index se već nalazi na burzi!");
            
            IIndex index = IIndexFactory.Create(inIndexName, inIndexType);
            this.indexList.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName)==true && StockExists(inStockName)==true) //postoje li na burzi taj index i dionica
            {

                if (this.indexList[this.foundIndexIndex].isStockInIndex(inStockName) == true) //postoji li već ta dionica u indexu
                    throw new StockExchangeException("In class StockExchange, AddStockToIndex() error: <" + inStockName + "> dionica se već nalazi u indexu!");
                else
                {
                    StockObj stock = this._stockList[_foundStockIndex];
                    this.indexList[this.foundIndexIndex].stockList.Add(stock);
                }
            }
            else
            {
                if (this.foundIndexIndex == -1)
                    throw new StockExchangeException("In class StockExchange, AddStockToIndex() error: <" + inIndexName + "> index se ne nalazi na burzi!");
                else
                    throw new StockExchangeException("In class StockExchange, AddStockToIndex() error: <" + inStockName + "> dionica se ne nalazi na burzi!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) == true && StockExists(inStockName) == true)
            {
                if (this.indexList[this.foundIndexIndex].isStockInIndex(inStockName) == true)
                {
                    int StockListIndex = this.indexList[this.foundIndexIndex].foundStockListIndex;
                    this.indexList[this.foundIndexIndex].stockList.RemoveAt(StockListIndex);
                }
                else
                    throw new StockExchangeException("In class StockExchange, RemoveStockFromIndex() error: <" + inStockName + "> dionica se  ne nalazi u indexu!");
            }
            else
            {
                if (this.foundIndexIndex == -1)
                    throw new StockExchangeException("In class StockExchange, RemoveStockFromIndex() error: <" + inIndexName + "> index se ne nalazi na burzi!");
                else
                    throw new StockExchangeException("In class StockExchange, RemoveStockFromIndex() error: <" + inStockName + "> dionica se ne nalazi na burzi!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) == true && StockExists(inStockName) == true)
                return this.indexList[this.foundIndexIndex].isStockInIndex(inStockName);
            else
            {
                if (this.foundIndexIndex == -1)
                    throw new StockExchangeException("In class StockExchange, IsStockPartOfIndex() error: <" + inIndexName + "> index se ne nalazi na burzi!");
                else
                    throw new StockExchangeException("In class StockExchange, IsStockPartOfIndex() error: <" + inStockName + "> dionica se ne nalazi na burzi!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Decimal value = 0m;
            int customTime = 2;
            if (IndexExists(inIndexName)==true)
            {
                int stockNumbers = this.indexList[foundIndexIndex].stockList.Count;
                for(int i=0; i<stockNumbers; ++i) 
                {
                    Decimal stockPrice = this.indexList[foundIndexIndex].stockList[i].getStockPrice(customTime, inTimeStamp);
                    long stockShares = this.indexList[foundIndexIndex].stockList[i].shNumber;
                    value += stockPrice * (Decimal)stockShares;
                }

                return (value / (Decimal)stockNumbers);
            }
            else
                    throw new StockExchangeException("In class StockExchange, GetIndexValue() error: <" + inIndexName + "> index se ne nalazi na burzi!");
        }

        public bool IndexExists(string inIndexName)
        {
            for (int i = 0; i < this.indexList.Count; ++i)
            {
                if (indexList[i].compareNames(inIndexName))
                {
                    this.foundIndexIndex = i;
                    return true;
                }
            }

            this.foundIndexIndex = -1;
            return false;   
        }

        public int NumberOfIndices()
        {
            return this.indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
                return this.indexList[foundIndexIndex].stockList.Count;
            else
                throw new StockExchangeException("In class StockExchange, AddStockToIndex() error: <" + inIndexName + "> index se ne nalazi na burzi!");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            throw new NotImplementedException();
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public int NumberOfPortfolios()
        {
            throw new NotImplementedException();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            throw new NotImplementedException();
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            throw new NotImplementedException();
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }

    }

    interface IIndex
    {
        bool compareNames(string inIndexName);
        bool isStockInIndex(string inStockName);
        Decimal getIndexValue(string inIndexName, DateTime inTimeStamp, StockExchange stockExchange);
        int foundStockListIndex { get; set; }
        string indexName { get; set; }
        List<StockObj> stockList {get; set;}
    }
    abstract class IndexObj : IIndex
    {
        private string _indexName;
        private List<StockObj> _stockList = new List<StockObj>();
        private int _foundStockListIndex;

        public IndexObj(string inIndexName) { indexName = inIndexName; }

        public bool isStockInIndex(string inStockName)
        {
            for (int i=0; i < this.stockList.Count; ++i) {
                if (this.stockList[i].stName == inStockName) 
                {
                    this.foundStockListIndex = i;
                    return true;
                }
            }
            this.foundStockListIndex = -1;
            return false;
        }
        public bool compareNames(string inIndexName)
        {
            if (this.indexName.ToUpper() == inIndexName.ToUpper() )
                return true;
            else
                return false;
        }

        public int foundStockListIndex
        {
            get { return _foundStockListIndex; }
            set { _foundStockListIndex = value; }
        }
        public List<StockObj> stockList
        {
            get { return _stockList; }
            set { _stockList = value; }
        }
        public string indexName 
        {
            get { return _indexName; }
            set { _indexName = value; }
        }

        public abstract Decimal getIndexValue(string inIndexName, DateTime inTimeStamp, StockExchange stockExchange);
    }
    class IIndexFactory
    {
        public static IIndex Create(string inIndexName, IndexTypes inIndexType)
        {
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    return new AverageIndexObj(inIndexName);
                case IndexTypes.WEIGHTED:
                    return new WeightedIndexObj(inIndexName);
                default:
                    throw new StockExchangeException("In class IIndexFactory,Create() error: <ne dozvoljen tip indexa!>");
            }
        }
    }

    class AverageIndexObj : IndexObj
    {
        public AverageIndexObj(string inIndexName) : base(inIndexName) { }

        public override Decimal getIndexValue(string inIndexName, DateTime inTimeStamp, StockExchange stockExchange) { return 0m; }
    }
    class WeightedIndexObj : IndexObj
    {
        public WeightedIndexObj(string inIndexName) : base(inIndexName) { }

        public override Decimal getIndexValue(string inIndexName, DateTime inTimeStamp, StockExchange stockExchange) { return 0m; }
    }

    public class StockPriceTimeObj
    {
        private Decimal _stockPrice;
        private DateTime _stockTimeStamp;

        public StockPriceTimeObj(Decimal stockPrice, DateTime stockTimeStamp)
        {
            this.stPrice = stockPrice;
            this.stTimeStamp = stockTimeStamp;
        }

        public Decimal stPrice
        {
            get { return _stockPrice; }
            set { _stockPrice = value; }
        }
        public DateTime stTimeStamp
        {
            get { return _stockTimeStamp; }
            set { _stockTimeStamp = value; }
        }
    }

    public class StockObj
    {
        private string _stockName;
        private long _sharesNumber;
        private Decimal _stockPrice;
        private DateTime _stockTimeStamp;
        private List<StockPriceTimeObj> _stPriceTimeList = new List<StockPriceTimeObj>();
        private StockPriceTimeObj _stPriceTime;

        public StockObj(string stockName, long sharesNumber, Decimal stockPrice, DateTime stockTimeStamp)
        {
            this.stName = stockName;
            this.shNumber = sharesNumber;
            this.stPrice = stockPrice;
            this.stTime = stockTimeStamp;

            this._stPriceTime = new StockPriceTimeObj(stockPrice, stockTimeStamp);
            this.stPriceList.Add(this._stPriceTime);
        }

        public Decimal getStockPrice(int position, DateTime inStockTimeStamp) 
        {
            if (position == 2)
            {
                for (int i = 0; i < stPriceList.Count; ++i)
                {
                    if (stPriceList[i].stTimeStamp.CompareTo(inStockTimeStamp) > 0)  //za prvo i-to vrijeme veće od ulaznog vremena(inStockTimeStamp) u listi cijena
                    {
                        if (i >= 1)
                            return stPriceList[i - 1].stPrice; //vrati prethodnu(i-1) cijenu iz liste
                        else
                            throw new StockExchangeException("In class StockObj, getStockPrice() error: <Pokušaj dohvaćanja prije inicijalne cijene!>");

                    }
                    else if (stPriceList[i].stTimeStamp.Equals(inStockTimeStamp)) //ako je ulazno vrijeme jednako i-tom vremenu u listi cijena
                        return stPriceList[i].stPrice; //vrati i-tu cijenu iz liste
                    else if (i == stPriceList.Count - 1) //ako je ulazno vrijeme veće od najvećeg vremena u listi cijena
                        return stPriceList[i].stPrice; //vrati zadnju cijenu iz liste
                }
            }

           throw new StockExchangeException("In class StockObj, getStockPrice() error:<Invalid index!>");
        }

        public Decimal getStockPrice(int position)
        {
            if (position == 0)
            {
                int zeroIndex = 0;
                return this.stPriceList[zeroIndex].stPrice;
            }
            else if (position == 1)
            {
                int lastIndex;
                lastIndex = stPriceList.Count - 1;
                return this.stPriceList[lastIndex].stPrice;
            }

            throw new StockExchangeException("In class StockObj, getStockPrice() error:<Invalid index!>");
        }
        public bool changeStockPrice( DateTime stockTimeStamp, Decimal stockPrice )
        {
            this.stPrice = stockPrice;
            this.stTime = stockTimeStamp;

            this._stPriceTime = new StockPriceTimeObj(stockPrice, stockTimeStamp);
            this.stPriceList.Add(this._stPriceTime);
            this.stPriceList = this.stPriceList.OrderBy(x => x.stTimeStamp).ToList(); //sortiranje liste parova cijena-vrijeme

            return true;
        }
        public bool compareNames(string inStockName)
        {
            if (this.stName.ToUpper() == inStockName.ToUpper())
                return true;
            else
                return false;
        }
        public string stName
        {
            get { return _stockName; }
            set { _stockName = value; }
        }
        public long shNumber
        {
            get { return _sharesNumber; }
            set
            {
                if (value <= 0)
                    throw new StockExchangeException("In class StockObj, StockObj.shNumber error: Shares number <= 0");
                else
                    _sharesNumber = value;
            }   
        }
        public Decimal stPrice
        {
            get { return _stockPrice; }
            set
            {
                if (value <= 0m)
                    throw new StockExchangeException("In class StockObj, StockObj.stPrice error: Stock price <= 0");
                else
                    _stockPrice = value;
            }
        }
        public DateTime stTime
        {
            get { return _stockTimeStamp; }
            set {
                foreach (StockPriceTimeObj obj in this._stPriceTimeList)
                {
                    if (obj.stTimeStamp == value)
                        throw new StockExchangeException("In class StockObj, StockObj.stTime error: <Već postoji cijena sa tim datumom!>");
                }
                _stockTimeStamp = value; 
            }
        }
        public List<StockPriceTimeObj> stPriceList
        {
            get { return _stPriceTimeList; }
            set { _stPriceTimeList = value; }
        }

    }

}
