using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
	public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
	
	public class StockExchange : IStockExchange
    {
        public Dictionary<string, Stock> Stocks { get; private set; }

        public Dictionary<string, Index> Indices { get; private set; }

        public Dictionary<string, Portfolio> Portfolios { get; private set; }

        public StockExchange()
        {
            this.Stocks = new Dictionary<string, Stock>();
            this.Indices = new Dictionary<string, Index>();
            this.Portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            var key = inStockName.ToUpperInvariant();

            // ovo se moze smatrati kao business pravilo (broj i cijena ne smiju biti <= 0) i moglo bi se izdvojiti
            // u posebnu metodu za validaciju, al je dovoljno jasno (i samo ovdje se provjerava) pa nije posebno izdvajano
            bool stockError = this.Stocks.ContainsKey(key)
                || inNumberOfShares <= 0
                || inInitialPrice <= 0;

            if (stockError)
            {
                throw new StockExchangeException("Stock creation error!");
            }

            var stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            this.Stocks[key] = stock;
        }

        public void DelistStock(string inStockName)
        {
            try
            {
                var key = inStockName.ToUpperInvariant();

                // ako brisemo dionicu s burze moramo ju izbrisati i iz indeksa koji ju ima (ako postoji takav)
                // ovo bi se moglo rijesiti i implementacijom observer patterna ili upotrebom delgata/evenata, ali smatram da bi u ovom slucaju bilo nepotrebno kompliciranje
                var stock = this.Stocks[key];
                foreach (var i in this.Indices.Values.Where(i => i.Contains(stock)))
                {
                    i.RemoveStockFromIndex(stock);
                }

                foreach (var i in this.Portfolios.Values.Where(i => i.Contains(stock)))
                {
                    i.RemoveStockFromPortfolio(stock);
                }

                this.Stocks.Remove(key);

            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock with this name does not exists!");
            }
        }

        public bool StockExists(string inStockName)
        {
            return this.Stocks.ContainsKey(inStockName.ToUpperInvariant());
        }

        public int NumberOfStocks()
        {
            return this.Stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            try
            {
                var key = inStockName.ToUpperInvariant();
                var stock = this.Stocks[key];
                stock.SetStockPrice(inIimeStamp, inStockValue);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock with this name does not exists!");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                var key = inStockName.ToUpperInvariant();
                return this.Stocks[key].GetStockPrice(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock with this name does not exists!");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            try
            {
                var key = inStockName.ToUpperInvariant();
                return this.Stocks[key].InitialPrice;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock with this name does not exists!");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            try
            {
                var key = inStockName.ToUpperInvariant();
                return this.Stocks[key].LastStockPrice;
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Stock with this name does not exists!");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Unsupported index type");
            }

            var key = inIndexName.ToUpperInvariant();
            bool error = this.Indices.ContainsKey(key);

            if (error)
            {
                throw new StockExchangeException("Index creation error!");
            }

            var index = new Index(inIndexName, inIndexType);
            this.Indices[key] = index;
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                var indexKey = inIndexName.ToUpperInvariant();
                var stockKey = inStockName.ToUpperInvariant();
                var index = this.Indices[indexKey];
                var stock = this.Stocks[stockKey];

                index.AddStockToIndex(stock);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Index or stock with this name does not exists!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try
            {
                var indexKey = inIndexName.ToUpperInvariant();
                var stockKey = inStockName.ToUpperInvariant();
                var index = this.Indices[indexKey];
                var stock = this.Stocks[stockKey];

                index.RemoveStockFromIndex(stock);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Index or stock with this name does not exists!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                var indexKey = inIndexName.ToUpperInvariant();
                var stockKey = inStockName.ToUpperInvariant();
                var index = this.Indices[indexKey];
                var stock = this.Stocks[stockKey];

                return index.Contains(stock);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Index or stock with this name does not exists!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                var key = inIndexName.ToUpperInvariant();
                return this.Indices[key].GetIndexValue(inTimeStamp);
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Index with this name does not exists!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            var indexKey = inIndexName.ToUpperInvariant();
            return this.Indices.ContainsKey(indexKey);
        }

        public int NumberOfIndices()
        {
            return this.Indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            try
            {
                var indexKey = inIndexName.ToUpperInvariant();
                var index = this.Indices[indexKey];

                return index.NumberOfStocks();
            }
            catch (KeyNotFoundException)
            {
                throw new StockExchangeException("Index with this name does not exists!");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                this.Portfolios[inPortfolioID] = new Portfolio(inPortfolioID);
            }
            else
            {
                throw new StockExchangeException("Portfolio with this ID already exists.");
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            if (!this.StockExists(inStockName.ToUpperInvariant()))
            {
                throw new StockExchangeException("Non existing stock.");
            }

            var stock = this.Stocks[inStockName.ToUpperInvariant()];
            var usedShares = this.Portfolios.Values.Where(p => p.Stocks.Keys.Contains(stock)).Sum(p => p.Stocks[stock]);

            if (stock.NumberOfShares - usedShares < 0)
            {
                throw new StockExchangeException("Not enough stocks.");
            }

            var portfolio = this.Portfolios[inPortfolioID];
            if (portfolio.Stocks.ContainsKey(stock))
            {
                portfolio.Stocks[stock] += numberOfShares;
            }
            else
            {
                portfolio.Stocks[stock] = numberOfShares;
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            if (!this.StockExists(inStockName.ToUpperInvariant()))
            {
                throw new StockExchangeException("Non existing stock.");
            }

            var stock = this.Stocks[inStockName.ToUpperInvariant()];
            var portfolio = this.Portfolios[inPortfolioID];

            try
            {
                if (portfolio.Stocks[stock] < numberOfShares)
                {
                    throw new StockExchangeException("Not enough stocks.");
                }
                if (portfolio.Stocks[stock] == numberOfShares)
                {
                    portfolio.Stocks.Remove(stock);
                }
                else
                {
                    portfolio.Stocks[stock] -= numberOfShares;
                }
            }
            catch (KeyNotFoundException e)
            {
                throw new StockExchangeException("Portolio does not contain that stock");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            if (!this.StockExists(inStockName.ToUpperInvariant()))
            {
                throw new StockExchangeException("Non existing stock.");
            }

            var stock = this.Stocks[inStockName.ToUpperInvariant()];
            var portfolio = this.Portfolios[inPortfolioID];

            try
            {
                portfolio.Stocks.Remove(stock);
            }
            catch (KeyNotFoundException e)
            {
                throw new StockExchangeException("Portolio does not contain that stock");
            }
        }

        public int NumberOfPortfolios()
        {
            return Portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            return this.Portfolios[inPortfolioID].Stocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return this.Portfolios.ContainsKey(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            if (!this.StockExists(inStockName.ToUpperInvariant()))
            {
                throw new StockExchangeException("Non existing stock.");
            }

            var stock = this.Stocks[inStockName.ToUpperInvariant()];
            var portfolio = this.Portfolios[inPortfolioID];

            return portfolio.Stocks.ContainsKey(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var number = 0;
            if (this.IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                var stock = this.Stocks[inStockName.ToUpperInvariant()];
                var portfolio = this.Portfolios[inPortfolioID];
                number = portfolio.Stocks[stock];
            }

            return number;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!this.PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Non existing portfolio.");
            }

            var portfolio = this.Portfolios[inPortfolioID];
            var sum = portfolio.Stocks.Keys.Sum(stock => stock.GetStockPrice(timeStamp) * portfolio.Stocks[stock]);

            return Math.Round(sum, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var daysInMonth = DateTime.DaysInMonth(Year, Month);
            var firstDay = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
            var lastDay = this.GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, daysInMonth, 23, 59, 59, 999));
            return firstDay == 0 ? 0m : Math.Round((lastDay - firstDay) * 100 / firstDay, 3);
        }
    }
	
	public class Stock
    {
        /// <summary>
        /// Holds name of the stock
        /// </summary>
        public string StockName { get; private set; }

        /// <summary>
        /// Holds number of shares (stocks)
        /// </summary>
        public long NumberOfShares { get; private set; }

        /// <summary>
        /// Returns initial price
        /// </summary>
        public decimal InitialPrice
        {
            get
            {
                var oldest = this.stockPriceHistory.Keys.Min();
                return this.stockPriceHistory[oldest];
            }
        }

        /// <summary>
        /// Returns last price
        /// </summary>
        public decimal LastStockPrice
        {
            get
            {
                var newest = this.stockPriceHistory.Keys.Max();
                return this.stockPriceHistory[newest];
            }
        }

        /// <summary>
        /// Holds stock price history
        /// </summary>
        private Dictionary<DateTime, decimal> stockPriceHistory;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="stockName">Name of the stock.</param>
        /// <param name="numberOfShares">Numer of shares.</param>
        /// <param name="initialPrice">Initial price.</param>
        /// <param name="timeStamp">Time stamp.</param>
        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            this.NumberOfShares = numberOfShares;
            this.StockName = stockName;

            this.stockPriceHistory = new Dictionary<DateTime, decimal>();
            this.stockPriceHistory[timeStamp] = initialPrice;
        }

        /// <summary>
        /// Sets stock price on a given moment
        /// </summary>
        /// <param name="inTimeStamp">Time stamp.</param>
        /// <param name="inStockValue">New stock price.</param>
        public void SetStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            // stock value cant be <= 0 
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Stock value can not be less than or equal to zero");
            }

            this.stockPriceHistory[inTimeStamp] = inStockValue;
        }

        /// <summary>
        /// Gets stock price for a given time moment.
        /// </summary>
        /// <param name="inTimeStamp">Time stmap.</param>
        /// <returns></returns>
        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            var min = this.stockPriceHistory.Keys.Min();
            if (inTimeStamp < min)
            {
                throw new StockExchangeException("Not existing stock for this time");
            }

            if (this.stockPriceHistory.ContainsKey(inTimeStamp))
            {
                return this.stockPriceHistory[inTimeStamp];
            }

            var closest = DateTime.MaxValue;
            foreach (var c in this.stockPriceHistory.Keys)
            {
                if ((c < inTimeStamp) && (inTimeStamp - c < TimeSpan.MaxValue))
                {
                    closest = c;
                }
            }

            return this.stockPriceHistory[closest];
        }

        /// <summary>
        /// Overriden Equals method - needed for storing stocks in Set
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            var other = (Stock)obj;
            return other.StockName == this.StockName;
        }
    }
	
    public class Index
    {
        /// <summary>
        /// Holds name of the index name
        /// </summary>
        public string IndexName { get; private set; }

        /// <summary>
        /// Holds index value calculation algorithm
        /// </summary>
        private IIndexAlgorithm calcAlgorithm;

        /// <summary>
        /// Holds list of stocks
        /// </summary>
        public HashSet<Stock> Stocks { get; private set; } 

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="indexName">Index name.</param>
        /// <param name="type">Index type.</param>
        public Index(string indexName, IndexTypes type)
        {
            this.IndexName = indexName;
            this.calcAlgorithm = AlgorithmFactory.GetAlgorithm(type);
            this.Stocks = new HashSet<Stock>();
        }

        /// <summary>
        /// Adds given stock to this index.
        /// </summary>
        /// <param name="stock">Stock to be added.</param>
        public void AddStockToIndex(Stock stock)
        {
            var status = this.Stocks.Add(stock);
            if (status == false)
            {
                throw new StockExchangeException("Stock already present in index!");
            }
        }

        /// <summary>
        /// Removes stock from index.
        /// </summary>
        /// <param name="stock">Stock to be removed.</param>
        public void RemoveStockFromIndex(Stock stock)
        {
            var status = this.Stocks.Remove(stock);
            if (status == false)
            {
                throw new StockExchangeException("Error while removing stock from index!");
            }
        }

        /// <summary>
        /// Checks if index already contains given stock.
        /// </summary>
        /// <param name="stock">Stock to be checked.</param>
        /// <returns>True if stock is present in index.</returns>
        public bool Contains(Stock stock)
        {
            return this.Stocks.Contains(stock);
        }

        /// <summary>
        /// Gets index value.
        /// </summary>
        /// <returns>Index value.</returns>
        public decimal GetIndexValue(DateTime timeStamp)
        {
            // ovo je moglo biti rijeseno i na drugaciji nacin - npr. da postoji AbstractIndex i dvije izvedene klase (AverageIndex i WeightedIndex)
            // koje bi implementirale svala svoju GetIndexValue, a AlgorithmFactory bi mogao umjesto implementacije algoritma vracati konkretnu instancu 
            // indexa. na taj nacin bi switch/case i dalje bio samo na jednom mjestu. kao sto se vidi, odlucio sam se za Strategy + Factory jer mi se tako 
            // cinilo prikladnije - Index je Index zauvijek i ne ovisi o dodatnim novim (potencijalno) tipovima Indexa. a i vise mi se svida strategy od nasljedivanja :)
            return this.calcAlgorithm.CalculateIndexValue(this, timeStamp);
        }

        /// <summary>
        /// Gets number of stocks in index.
        /// </summary>
        /// <returns></returns>
        public int NumberOfStocks()
        {
            return this.Stocks.Count;
        }
    }	

    public class Portfolio
    {
        /// <summary>
        /// Holds portofolio id
        /// </summary>
        public string ID { get; private set; }

        /// <summary>
        /// portfolio
        /// </summary>
        public Dictionary<Stock, int> Stocks { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="id">Portfolio id.</param>
        public Portfolio(string id)
        {
            this.ID = id;
            this.Stocks = new Dictionary<Stock, int>();
        }

        /// <summary>
        /// Removes stock from portfolio
        /// </summary>
        /// <param name="stock">Stock to be removed.</param>
        public void RemoveStockFromPortfolio(Stock stock)
        {
            var status = this.Stocks.Remove(stock);
            if (status == false)
            {
                throw new StockExchangeException("Error while removing stock from portfolio!");
            }
        }

        /// <summary>
        /// Checks if stock is in portfolio.
        /// </summary>
        /// <param name="stock">Stock to be cheked.</param>
        /// <returns>True if exists, false otherwise.</returns>
        public bool Contains(Stock stock)
        {
            return this.Stocks.ContainsKey(stock);
        }

        /// <summary>
        /// Checks for equality of other portfolio and this.
        /// </summary>
        /// <param name="obj">Other portfolio.</param>
        /// <returns>True if they are equal, false otherwise.</returns>
        public override bool Equals(object obj)
        {
            var other = (Portfolio)obj;
            return other.ID == this.ID;
        }
    }

    public interface IIndexAlgorithm
    {
        decimal CalculateIndexValue(Index index, DateTime timeStamp);
    }
	
    public class AverageIndex : IIndexAlgorithm
    {
        public decimal CalculateIndexValue(Index index, DateTime timeStamp)
        {
            var stocks = index.Stocks;

            long count = 0;
            var value = 0m;

            foreach(var s in stocks)
            {
                count += 1;
                value += s.GetStockPrice(timeStamp);
            }

            return count == 0 ? 0m : Math.Round((value / count), 3);
        }
    }	
	
    public class WeightedIndex : IIndexAlgorithm
    {
        public decimal CalculateIndexValue(Index index, DateTime timeStamp)
        {
            var stocks = index.Stocks;
            var sum = stocks.Sum(i => i.GetStockPrice(timeStamp) * i.NumberOfShares);
            var w = stocks.Sum(s => (s.GetStockPrice(timeStamp) * s.NumberOfShares * s.GetStockPrice(timeStamp) / sum));
            
            return Math.Round(w, 3);
        }
    }	

    public static class AlgorithmFactory
    {
        /// <summary>
        /// Returns index value calculation algorithm based on a given index type. 
        /// </summary>
        /// <param name="type">Index type</param>
        /// <returns>An algorithm for calculating idnex value.</returns>
        public static IIndexAlgorithm GetAlgorithm(IndexTypes type)
        {
            IIndexAlgorithm algorithm = null;

            switch (type)
            {
                case IndexTypes.AVERAGE:
                    algorithm = new AverageIndex();
                    break;
                case IndexTypes.WEIGHTED:
                    algorithm = new WeightedIndex();
                    break;
                default:
                    throw new StockExchangeException("Unsupported index type!");
            }

            return algorithm;
        }
    }	
}