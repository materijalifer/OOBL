﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private Display display;
        private List<IEntry> data;
        private NumberSaved savedNumber;
        private bool operationOver;
        private double numberForSecondOperand;

        public Kalkulator() {
            data = new List<IEntry>();
            IEntry zero = new Number('0');
            data.Add(zero);
            display = new Display();
            savedNumber = new NumberSaved();
            operationOver = false;
        }

        public void Press(char inPressedDigit)
        {
            IEntry entry;
            if (Char.IsDigit(inPressedDigit))
            {
                entry = new Number(inPressedDigit);
            }
            else 
            {
                entry = new Operator(inPressedDigit);
            }

            if (display.display().Equals("-E-"))
            {
                if (!checkIfInterrupt(entry))
                {
                    return;
                }
            }

            if (entry.isNumber())
            {
                if (operationOver)
                {
                    data.Clear();
                    IEntry numberWithZero = new Number();
                    numberWithZero.changeValue("0");
                    data.Add(numberWithZero);
                    operationOver = false;
                }
                insertNewDigitOrBinaryOperation(entry);
                return;
            }

            if (entry.ToString().Equals("P"))
            {
                string toSave = display.display();
                savedNumber.numberToSave = toSave;
                return;
            }

            if (entry.ToString().Equals("G"))
            {
                if (!savedNumber.numberToSave.Equals(""))
                {
                    display.refreshDisplay(savedNumber.numberToSave);
                }
                return;
            }

            bool comma = false;
            comma = checkIfComma(entry);

            bool interrupt = false;
            if (!comma) 
            {
                interrupt = checkIfInterrupt(entry);
            }

            bool unaryOperator = false;
            if (!interrupt && !comma)
            {
                unaryOperator = checkIfUnaryOperator(entry);
            }

            bool binaryOperator = false;
            if (!interrupt && !unaryOperator && !comma)
            {
                binaryOperator = checkIfBinaryOperator(entry);
            }

            bool equalSign = false;
            if (!interrupt && !unaryOperator && !binaryOperator && !comma)
            {
                equalSign = checkIfEqualSign(entry); 
            }
        }

        private bool checkIfComma(IEntry entry)
        {
            if (entry.ToString().Equals(","))
            {
                if (data[data.Count - 1].isNumber())
                {
                    if (!data[data.Count - 1].ToString().Contains(","))
                    {
                        Number number = (Number)data[data.Count - 1];
                        number.concateNumber(entry.ToString());
                        Console.Out.WriteLine("Tu sam: " + number.ToString());
                        display.refreshDisplay(number.ToString());
                    }
                    return true;
                }
                else 
                {
                    IEntry numberWithZero = new Number();
                    numberWithZero.changeValue("0,");
                    data.Add(numberWithZero);
                    display.refreshDisplay(numberWithZero.ToString());
                    return true;
                }
            }
            else
               return false;
        }

        private bool checkIfEqualSign(IEntry entry)
        {
            if (entry.ToString().Equals("="))
            {
                evaluateList();
                return true;
            }
            else 
            {
                return false;
            }
        }

        private void evaluateList()
        {
            double result = Convert.ToDouble(data[0].ToString());

            string operatorLast = data[data.Count - 1].ToString();
            if (operatorLast.Equals("+") || operatorLast.Equals("-") || operatorLast.Equals("/") || operatorLast.Equals("*"))
            {
                data.Add(data[data.Count - 2]);
            }

            for (int i = 1; i < data.Count; i+=2)
            {
                if (data[i].ToString().Equals("+"))
                {
                    result += Convert.ToDouble(data[i + 1].ToString());
                //    result = Convert.ToDouble(normalizeAfterOperation(result.ToString()));               
                }
                else if (data[i].ToString().Equals("-"))
                {
                    result -= Convert.ToDouble(data[i + 1].ToString());
         //           result = Convert.ToDouble(normalizeAfterOperation(result.ToString()));
                } 
                else if (data[i].ToString().Equals("*"))
                {
                    result *= Convert.ToDouble(data[i + 1].ToString());
      //              result = Convert.ToDouble(normalizeAfterOperation(result.ToString()));
                }
                else if (data[i].ToString().Equals("/"))
                {
                    if (Convert.ToDouble(data[i + 1].ToString()) != 0)
                    {
                        result /= Convert.ToDouble(data[i + 1].ToString());
          //              result = Convert.ToDouble(normalizeAfterOperation(result.ToString()));
                    }
                    else 
                    {
                        display.refreshDisplay("-E-");
                        return;
                    }
                }
                string tempRez = normalizeAfterOperation(result.ToString());
                if (!tempRez.Equals("-E-"))
                {
                    result = Convert.ToDouble(normalizeAfterOperation(result.ToString()));
                }
                else
                    break;
                
            }

            display.refreshDisplay(normalizeAfterOperation(result.ToString()));
            data.Clear();
            IEntry number = new Number();
            number.changeValue(result.ToString());
            data.Add(number);
            operationOver = true;
        }

        private bool checkIfBinaryOperator(IEntry entry)
        {
            if (entry.ToString().Equals("+") || entry.ToString().Equals("-") || entry.ToString().Equals("*") || entry.ToString().Equals("/"))
            {
                insertNewDigitOrBinaryOperation(entry);
                return true;
            }
            else 
                return false;
        }


        private bool checkIfUnaryOperator(IEntry entry)
        {
            if (entry.ToString().Equals("M"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(minusInserted(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else 
                {
                    IEntry sameNumber = new Number(data[data.Count-2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(minusInserted(data[data.Count - 2].ToString())));
         //           data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }
            }

            else if (entry.ToString().Equals("S"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(calculateSinus(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else 
                {
                    IEntry sameNumber = new Number(data[data.Count-2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(calculateSinus(data[data.Count - 2].ToString())));
        //            data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }

            }

            else if (entry.ToString().Equals("K"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(calculateCosinus(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else
                {
                    IEntry sameNumber = new Number(data[data.Count - 2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(calculateCosinus(data[data.Count - 2].ToString())));
           //         data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }
            }

            else if (entry.ToString().Equals("T"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(calculateTangens(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else
                {
                    IEntry sameNumber = new Number(data[data.Count - 2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(calculateTangens(data[data.Count - 2].ToString())));
           //         data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }
            }

            else if (entry.ToString().Equals("Q"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(calculateSquare(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else
                {
                    IEntry sameNumber = new Number(data[data.Count - 2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(calculateSquare(data[data.Count - 2].ToString())));
           //         data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }
            }

            else if (entry.ToString().Equals("R"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count - 1].changeValue(normalizeAfterOperation(calculateRoot(data[data.Count - 1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else
                {
                    IEntry sameNumber = new Number(data[data.Count - 2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(calculateRoot(data[data.Count - 2].ToString())));
        //            data.Add(sameNumber);
                    display.refreshDisplay(sameNumber.ToString());
                    return true;
                }
            }

            else if (entry.ToString().Equals("I"))
            {
                if (data[data.Count - 1].isNumber())
                {
                    data[data.Count-1].changeValue(normalizeAfterOperation(invert(data[data.Count-1].ToString())));
                    display.refreshDisplay(data[data.Count - 1].ToString());
                    return true;
                }
                else
                {
                    IEntry sameNumber = new Number(data[data.Count - 2].ToString());
                    sameNumber.changeValue(normalizeAfterOperation(invert(data[data.Count - 2].ToString())));
                    display.refreshDisplay(sameNumber.ToString());
        //            data.Add(sameNumber);
                    return true;
                }
            }

            else
                return false;
        }

        private string calculateRoot(string p)
        {

            if (Convert.ToDouble(p) >= 0)
            {
                return Math.Sqrt(Convert.ToDouble(p)).ToString();
            }
            else
                return "-E-";
        }

        private string calculateSquare(string p)
        {
            return Math.Pow(Convert.ToDouble(p), 2).ToString();
        }

        private string calculateTangens(string p)
        {
            return Math.Tan(Convert.ToDouble(p)).ToString();
        }

        private string calculateCosinus(string p)
        {
            return Math.Cos(Convert.ToDouble(p)).ToString();
        }

        private string calculateSinus(string p)
        {
            return Math.Sin(Convert.ToDouble(p)).ToString();
        }


        private bool checkIfInterrupt(IEntry entry)
        {
            if (entry.ToString().Equals("O"))
            {
                data.Clear();
                IEntry zero = new Number('0');
                data.Add(zero);
                savedNumber.clear();
                display.refreshDisplay(zero.ToString());
                return true;
            }

            else if (entry.ToString().Equals("C"))
            {
                if (display.display().Equals("-E-"))
                {
                    data.Clear();
                    IEntry zero = new Number('0');
                    data.Add(zero);
                    savedNumber.clear();
                    display.refreshDisplay(zero.ToString());
                    return true;
                }


                int size = data.Count();

                if (data[size - 1].isNumber())
                {
                    data[size - 1].changeValue("0");
                    return true;
                }
                else
                {
                    IEntry zero = new Number('0');
                    data.Add(zero);
                    return true;
                }
            }
            else
                return false;
        }


        private string minusInserted(string value)
        {
            double number = Convert.ToDouble(value);
            if (number != 0)
            {
                number = -number;
                return number.ToString();
            }
            else
            {
                return "0";
            }
        }


        private string invert(string value)
        {
            double number = Convert.ToDouble(value);
            if (number != 0)
            {
                number = 1 / number;
                return number.ToString();
            }
            else
            {
                return "-E-";
            }
        }


        private void insertNewDigitOrBinaryOperation(IEntry entry)
        {
            if (data[data.Count - 1].isNumber() && entry.isNumber())
            {
                if (checkSize(data[data.Count - 1].ToString()))
                {
                    Number number = (Number)data[data.Count - 1];
                    if (!number.ToString().Equals("0"))
                    {
                        number.concateNumber(entry.ToString());
                        display.refreshDisplay(number.ToString());
                    }
                    else
                    {
                        number.changeValue(entry.ToString());
                        display.refreshDisplay(number.ToString());
                    }
                }
            }
            else if (!data[data.Count - 1].isNumber() && !entry.isNumber())
            {
                data[data.Count - 1] = entry;
            }
            else
            {
                if (entry.isNumber()) 
                {
                    display.refreshDisplay(entry.ToString());
                    data.Add(entry);
                }
                else
                    data.Add(entry);
            }
        }

        public void printData()
        {
            foreach (IEntry entry in data)
            {
                Console.Out.WriteLine(entry.ToString());
            }
        }

        public string GetCurrentDisplayState()
        {
            return display.display();
        }


        public string normalizeAfterOperation(string value)
        {
            if (value.Equals("-E-"))
                return value;

            if (value.Length > 10)
            {
                if (value.Contains(","))
                {
                    string[] splited = value.Split(',');
                    if (splited[0].Length <= 10)
                    {
                        int numberOffDecimal;
                        if (splited[0].Contains("-"))
                        {
                            numberOffDecimal = 10 - splited[0].Length + 1;
                        }
                        else
                        {
                            numberOffDecimal = 10 - splited[0].Length;
                        }

                        if (numberOffDecimal > 0)
                        {
                            string toRound = splited[0] + "," + splited[1];
                            double dValue = Convert.ToDouble(value);
                            dValue = Math.Round(dValue, numberOffDecimal, MidpointRounding.AwayFromZero);
                            return dValue.ToString();
                        }
                        else
                        {
                            string toRound = splited[0] + "," + splited[1];
                            double dValue = Convert.ToDouble(value);
                            dValue = Math.Round(dValue, 0, MidpointRounding.AwayFromZero);
                            return dValue.ToString();
                        }
                    }
                    else if (splited[0].Length == 11 && splited[0].Contains("-"))
                    {
                        string toRound = splited[0] + "," + splited[1];
                        double dValue = Convert.ToDouble(value);
                        dValue = Math.Round(dValue, 0, MidpointRounding.AwayFromZero);
                        return dValue.ToString();
                    }
                    else
                        return "-E-";
                }
                else
                {
                    return "-E-";
                }
            }
            else
            {
                return value;
            }
        }


        private bool checkSize(string number)
        {
            int size = number.Length;
            if (number.Contains(","))
            {
                size--;
            }
            if (number.Contains("-"))
            {
                size--;
            }

            if (size < 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }


    public class Display 
    {
        public string toDisplay;

        public Display()
        {
            toDisplay = "0";
        }

        public void refreshDisplay(string display)
        {
            this.toDisplay = display;
        }

        public string display()
        {
            return removeZeros(toDisplay);
        }

        private string removeZeros(string value)
        {
            if (!value.Equals("-E-"))
            {
                if (!value.ElementAt(value.Length - 1).Equals(','))
                {
                    double dValue = Convert.ToDouble(value);
                    return (dValue / 1.000000000000).ToString();
                }
                else
                    return value;
            }
            else
            {
                return value;
            }
        }
    }


    public interface IEntry
    {
        bool isNumber();
        void changeValue(string value);
    }


    public class Number:IEntry
    {
        private string number { get; set; }

        public Number(char number)
        {
            this.number = Char.ToString(number);
        }

        public Number()
        { }

        public Number(string number)
        {
            this.number = number;
        }

        public bool isNumber()
        {
            return true;
        }

        public void changeValue(string value)
        {
            this.number = value;
        }

        public override string ToString()
        {
            return number;
        }

        public void concateNumber(string numberToConcate)
        {
            number += numberToConcate;
        }
    }


    public class Operator : IEntry
    {
        public string operation { get; set; }

        public Operator(char operation)
        {
            this.operation = Char.ToString(operation);
        }

        public bool isNumber()
        {
            return false;
        }

        public void changeValue(string value)
        {
            this.operation = value;
        }

        public override string ToString()
        {
            return operation;
        }
    }


    public class NumberSaved
    {
        public string numberToSave { get; set; }

        public void clear()
        {
            numberToSave = "";
        }
    }
}
