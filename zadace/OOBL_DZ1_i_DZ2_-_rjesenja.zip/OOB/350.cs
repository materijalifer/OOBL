﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        public StockExchange()
        {
            SEData = new StockExchangeData();
        }

        private class StockExchangeData
        {
            private Dictionary<string, Stock> stocks;
            private Dictionary<string, Index> indices;
            private Dictionary<string, Portfolio> portfolios;

            public Dictionary<string, Stock> Stocks
            {
                get
                {
                    return stocks;
                }
                set
                {
                    stocks = value;
                }
            }
            public Dictionary<string, Index> Indices
            {
                get
                {
                    return indices;
                }
                set
                {
                    indices = value;
                }
            }
            public Dictionary<string, Portfolio> Portfolios
            {
                get
                {
                    return portfolios;
                }
                set
                {
                    portfolios = value;
                }
            }

            public StockExchangeData()
            {
                stocks = new Dictionary<string, Stock>();
                indices = new Dictionary<string, Index>();
                portfolios = new Dictionary<string, Portfolio>();
            }

            public class StockPriceHistory
            {
                //povijest svih unosa
                private Dictionary<DateTime, decimal> priceHistory;

                //prvi kronoloski unos, koji cemo pamtiti i provjeravati nove unose s njim 
                //- ako je datum manji od pocetnog, znaci da je datum unesen kriv!
                private KeyValuePair<DateTime, decimal> initialEntry;
                //zadnji kronoloski unos
                private KeyValuePair<DateTime, decimal> lastEntry;

                public StockPriceHistory()
                {
                    this.priceHistory = new Dictionary<DateTime, decimal>();
                    this.initialEntry = new KeyValuePair<DateTime, decimal>();
                    this.lastEntry = new KeyValuePair<DateTime, decimal>();
                }

                public StockPriceHistory(DateTime timeStamp, decimal initialPrice)
                {
                    this.priceHistory = new Dictionary<DateTime, decimal>();

                    this.priceHistory.Add(timeStamp, initialPrice);

                    initialEntry = new KeyValuePair<DateTime, decimal>(timeStamp, initialPrice);
                    lastEntry = initialEntry;
                }

                public decimal ReturnEntryByDate(DateTime timeStamp)
                {
                    if (IsEntryDateRangePresent(timeStamp))
                    {
                        //sortiramo dictionary po datumu
                        var items = from pair in priceHistory
                                    orderby pair.Key ascending
                                    select pair;

                        //iteriramo svaki par datuma i provjeravamo da li je datum u nekom od tih raspona
                        for (int i = 1; i < items.Count(); i++)
                        {
                            //sortirane vrijednosti prije i poslije uzimamo i gledamo raspon
                            KeyValuePair<DateTime, decimal> pairBefore = items.ElementAt(i - 1);
                            KeyValuePair<DateTime, decimal> pairAfter = items.ElementAt(i);

                            if (pairBefore.Key.CompareTo(timeStamp) < 0 &&
                                pairAfter.Key.CompareTo(timeStamp) > 0)
                                return priceHistory[priceHistory.Keys.ElementAt(i - 1)];

                        }

                        //ako je vrijeme iza zadnjeg entry-a
                        return ReturnLastEntry().Value;
                    }

                    throw new StockExchangeException("Entry not found.");
                }

                //provjeravamo da li datum uopce moze postojati u zapisima, znaci mora biti poslije inicijalnog datuma
                public bool IsEntryDateRangePresent(DateTime timeStamp)
                {
                    if (initialEntry.Key.CompareTo(timeStamp) < 0)
                        return true;
                    else
                        return false;
                }

                public void AddNewEntry(decimal price, DateTime timeStamp)
                {
                    //provjera da ne postoji isto vrijeme za sve unose vremena
                    if (priceHistory.ContainsKey(timeStamp))
                        throw new StockExchangeException("Datetime already present in stock history!");

                    priceHistory.Add(timeStamp, price);

                    //provjera da li je prvi ili zadnji unos veci ili manji respektivno. ako da, zamijeni sa novom vrijednoscu.
                    if (initialEntry.Key.CompareTo(timeStamp) > 0)
                        initialEntry = new KeyValuePair<DateTime, decimal>(timeStamp, price);
                    if (lastEntry.Key.CompareTo(timeStamp) < 0)
                        lastEntry = new KeyValuePair<DateTime, decimal>(timeStamp, price);
                }

                public KeyValuePair<DateTime, decimal> ReturnFirstEntry()
                {
                    return initialEntry;
                }

                public KeyValuePair<DateTime, decimal> ReturnLastEntry()
                {
                    return lastEntry;
                }

                public Dictionary<DateTime, decimal> ReturnAllEntries()
                {
                    return priceHistory;
                }
            }

            public class Stock
            {
                private string stockName;
                private long numberOfShares;
                //broj dionica koje su u portfeljima
                private long numberOfOwnedShares;

                public string StockName
                {
                    get
                    {
                        return stockName;
                    }
                }
                public long NumberOfShares
                {
                    get
                    {
                        return numberOfShares;
                    }
                    set
                    {
                        numberOfShares = value;
                    }
                }
                public long NumberOfOwnedShares
                {
                    get
                    {
                        return numberOfOwnedShares;
                    }
                    set
                    {
                        numberOfOwnedShares = value;
                    }
                }

                //povijest svih unosa
                public StockPriceHistory priceHistory;

                public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
                {
                    this.stockName = stockName.ToUpper();
                    this.numberOfShares = numberOfShares;
                    this.priceHistory = new StockPriceHistory(timeStamp, initialPrice);

                    this.numberOfOwnedShares = 0;
                }
            }

            public class Index
            {
                private string indexName;
                private IndexTypes indexType;
                private List<string> stockList;

                public string IndexName
                {
                    get
                    {
                        return indexName;
                    }
                    set
                    {
                        indexName = value;
                    }
                }
                public IndexTypes IndexType
                {
                    get
                    {
                        return indexType;
                    }
                    set
                    {
                        indexType = value;
                    }
                }
                public List<string> StockList
                {
                    get
                    {
                        return stockList;
                    }
                }

                public Index(string inIndexName, IndexTypes inIndexType)
                {
                    this.indexName = inIndexName.ToUpper();
                    this.indexType = inIndexType;
                    this.stockList = new List<string>();
                }
            }

            public class Portfolio
            {
                private string portfolioName;
                //necemo sadrzavati cijele podatke o dionicama, vec samo njihovo ime i broj udjela u portfelju
                private Dictionary<string, long> stockList;

                public String PortfolioName
                {
                    get
                    {
                        return portfolioName;
                    }
                    set
                    {
                        portfolioName = value;
                    }
                }
                public Dictionary<string, long> StockList
                {
                    get
                    {
                        return stockList;
                    }
                    set
                    {
                        stockList = value;
                    }
                }

                public Portfolio(string inPortfolioID)
                {
                    this.portfolioName = inPortfolioID;
                    this.stockList = new Dictionary<string, long>();
                }
            }
        }

        StockExchangeData SEData;

        #region STOCK_ponasanje

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            //ne smije se unijeti datum koji je poslije sada. nismo vidoviti milan.
            if (inNumberOfShares <= 0 || inInitialPrice <= 0 || DateTime.Now.CompareTo(inTimeStamp) < 0)
                throw new StockExchangeException("Invalid input!");
            else if (StockExists(inStockName))
                throw new StockExchangeException("Stock already exists.");
            else
            {
                //ako dionica ne postoji i sve vrijednosti su pravilno unesene, stvori novu dionicu i uvrsti istu na burzu.
                StockExchangeData.Stock newStock = new StockExchangeData.Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                SEData.Stocks.Add(inStockName.ToUpper(), newStock);
            }
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                SEData.Stocks.Remove(inStockName.ToUpper());

                //sad brisemo za svaki index i portfolio posebno
                foreach (StockExchangeData.Index index in SEData.Indices.Values)
                    if (index.StockList.Contains(inStockName.ToUpper()))
                        index.StockList.Remove(inStockName.ToUpper());

                foreach (StockExchangeData.Portfolio portfolio in SEData.Portfolios.Values)
                    if (portfolio.StockList.ContainsKey(inStockName.ToUpper()))
                        portfolio.StockList.Remove(inStockName.ToUpper());
            }
            else
                throw new StockExchangeException("Error: Stock name does not exist!");
        }

        public bool StockExists(string inStockName)
        {
            if (SEData.Stocks.ContainsKey(inStockName.ToUpper()))
                return true;
            else
                return false;
        }

        public int NumberOfStocks()
        {
            return SEData.Stocks.Keys.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName))
            {
                //vrijednost ne smije biti 0 ili negativna
                if (inStockValue <= 0)
                    throw new StockExchangeException("Invalid input of price!");

                StockExchangeData.Stock stock = SEData.Stocks[inStockName.ToUpper()];

                stock.priceHistory.AddNewEntry(inStockValue, inIimeStamp);
            }
            else
                throw new StockExchangeException("Error: Stock name does not exist!");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                StockExchangeData.Stock stock = SEData.Stocks[inStockName.ToUpper()];

                //ako postoji neki unos u rasponu vremenskih unosa na nacin na koji je napisano u definiciji klase Stocks; onda vracamo unos iz odgovarajućeg raspona.
                if (stock.priceHistory.IsEntryDateRangePresent(inTimeStamp))
                {
                    decimal foundPrice = stock.priceHistory.ReturnEntryByDate(inTimeStamp);
                    return foundPrice;
                }
                else
                {
                    throw new StockExchangeException("Entry not found.");
                }
            }
            else
                throw new StockExchangeException("Error: Stock name does not exist!");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                StockExchangeData.Stock stock = SEData.Stocks[inStockName.ToUpper()];

                return stock.priceHistory.ReturnFirstEntry().Value;
            }
            else
                throw new StockExchangeException("Error: Stock name does not exist!");

            throw new StockExchangeException("Entry not found.");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                StockExchangeData.Stock stock = SEData.Stocks[inStockName.ToUpper()];

                return stock.priceHistory.ReturnLastEntry().Value;
            }
            else
                throw new StockExchangeException("Error: Stock name does not exist!");

            throw new StockExchangeException("Entry not found.");
        }
        #endregion

        #region INDEX_ponasanje

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!inIndexType.Equals(IndexTypes.AVERAGE) && !inIndexType.Equals(IndexTypes.WEIGHTED))
                throw new StockExchangeException("Invalid index number!");

            if (!IndexExists(inIndexName))
            {
                StockExchangeData.Index newIndex = new StockExchangeData.Index(inIndexName.ToUpper(), inIndexType);
                SEData.Indices.Add(inIndexName.ToUpper(), newIndex);
            }
            else
                throw new StockExchangeException("Error: Index already exists!");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName) && !IsStockPartOfIndex(inIndexName, inStockName))
            {
                StockExchangeData.Index index = SEData.Indices[inIndexName.ToUpper()];
                index.StockList.Add(inStockName.ToUpper());
            }
            else
            {
                throw new StockExchangeException("Error: Index or stock not found; or stock already added!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName) && IsStockPartOfIndex(inIndexName, inStockName))
            {
                StockExchangeData.Index index = SEData.Indices[inIndexName.ToUpper()];
                index.StockList.Remove(inStockName.ToUpper());
            }
            else
            {
                throw new StockExchangeException("Error: Index or stock not found!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName) && IndexExists(inIndexName))
            {
                StockExchangeData.Index index = SEData.Indices[inIndexName.ToUpper()];
                if (index.StockList.Contains(inStockName.ToUpper()))
                    return true;
                else
                    return false;
            }
            else
            {
                throw new StockExchangeException("Error: Index or stock not found!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal averageValue = 0;

            if (IndexExists(inIndexName))
            {
                //ako nema dionica u indeksu, vracamo nulu
                if (NumberOfStocksInIndex(inIndexName) == 0)
                    return 0;

                StockExchangeData.Index index = SEData.Indices[inIndexName.ToUpper()];

                //ovisno o tome koji je tip indeksa, racunamo.
                if (index.IndexType.Equals(IndexTypes.AVERAGE))
                {
                    foreach (string stockName in index.StockList)
                    {
                        StockExchangeData.Stock stock = SEData.Stocks[stockName];
                        sum = sum + stock.priceHistory.ReturnEntryByDate(inTimeStamp);
                    }

                    averageValue = sum / index.StockList.Count();
                }
                else
                {
                    foreach (string stockName in index.StockList)
                    {
                        StockExchangeData.Stock stock = SEData.Stocks[stockName];
                        sum = sum + stock.priceHistory.ReturnEntryByDate(inTimeStamp) * stock.NumberOfShares;
                    }

                    foreach (string stockName in index.StockList)
                    {
                        StockExchangeData.Stock stock = SEData.Stocks[stockName];
                        averageValue = averageValue + (stock.priceHistory.ReturnEntryByDate(inTimeStamp) / sum) * (stock.priceHistory.ReturnEntryByDate(inTimeStamp) * stock.NumberOfShares);
                    }

                    //zaokruzujemo na 3 decimale
                    averageValue = decimal.Round(averageValue, 3);
                }

                return averageValue;
            }
            else
                throw new StockExchangeException("Error: Index not found!");
        }

        public bool IndexExists(string inIndexName)
        {
            if (SEData.Indices.ContainsKey(inIndexName.ToUpper()))
                return true;
            else
                return false;
        }

        public int NumberOfIndices()
        {
            return SEData.Indices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                StockExchangeData.Index index = SEData.Indices[inIndexName.ToUpper()];
                return index.StockList.Count();
            }
            else
                throw new StockExchangeException("Error: Index not found!");
        }
        #endregion

        #region PORTFOLIO_ponasanje

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                SEData.Portfolios.Add(inPortfolioID, new StockExchangeData.Portfolio(inPortfolioID));
            else
                throw new StockExchangeException("Error: Portfolio already exists!");
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            //uz normalne provjere, broj udjela ne smije biti negativan ili nula; te njegov zbroj sa vec preuzetim udjelima ne smije prelaziti ukupan broj raspolozivih udjela.
            if (PortfolioExists(inPortfolioID)
                && StockExists(inStockName)
                && (SEData.Stocks[inStockName.ToUpper()].NumberOfShares - SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares) >= numberOfShares
                && numberOfShares > 0)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    //ako broj udjela koje cemo "preuzeti" ne premasuje broj raspolozivih udjela, pridodajemo ih portfelju.
                    if (SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares + numberOfShares <= SEData.Stocks[inStockName.ToUpper()].NumberOfShares)
                    {
                        SEData.Portfolios[inPortfolioID].StockList[inStockName.ToUpper()] += numberOfShares;
                        SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares += numberOfShares;
                    }
                    else
                        throw new StockExchangeException("Error: Too many shares assigned!");
                }
                else
                {
                    SEData.Portfolios[inPortfolioID].StockList.Add(inStockName.ToUpper(), numberOfShares);
                    SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares += numberOfShares;
                }
            }
            else
                throw new StockExchangeException("Error: Invalid input!");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                //ako cemo uzeti vise udjela od broja koliko ih ima u portfelju, onda cemo izbrisati dionicu iz portfelja.
                if (numberOfShares >= SEData.Portfolios[inPortfolioID].StockList[inStockName.ToUpper()])
                {
                    RemoveStockFromPortfolio(inPortfolioID, inStockName);
                }
                else
                {
                    //oduzmemo one dionice koje su sadrzane u portfelju iz brojaca zakupljenih dionica, ali ovisno o broju dionica koje oduzimamo
                    SEData.Portfolios[inPortfolioID].StockList[inStockName.ToUpper()] -= numberOfShares;
                    SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares -= numberOfShares;
                }
            }
            else
                throw new StockExchangeException("Error: Invalid input or stock is not a part of portfolio!");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                //oduzmemo one dionice koje su sadrzane u portfelju iz brojaca zakupljenih dionica
                SEData.Stocks[inStockName.ToUpper()].NumberOfOwnedShares -= SEData.Portfolios[inPortfolioID].StockList[inStockName.ToUpper()];
                SEData.Portfolios[inPortfolioID].StockList.Remove(inStockName.ToUpper());
            }
            else
                throw new StockExchangeException("Error: Invalid input!");
        }

        public int NumberOfPortfolios()
        {
            return SEData.Portfolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                return SEData.Portfolios[inPortfolioID].StockList.Count();
            else
                throw new StockExchangeException("Error: Portfolio name not found!");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (SEData.Portfolios.ContainsKey(inPortfolioID))
                return true;
            else
                return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                if (SEData.Portfolios[inPortfolioID].StockList.ContainsKey(inStockName.ToUpper()))
                    return true;
                else
                    return false;
            }
            else
                throw new StockExchangeException("Error: Invalid input!");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                return (int)SEData.Portfolios[inPortfolioID].StockList[inStockName.ToUpper()];
            else
                return 0;//throw new StockExchangeException("Stock not part of portfolio!");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                decimal valueSum = 0;

                foreach (string stockName in SEData.Portfolios[inPortfolioID].StockList.Keys)
                {
                    valueSum = valueSum + SEData.Stocks[stockName.ToUpper()].priceHistory.ReturnEntryByDate(timeStamp) * SEData.Portfolios[inPortfolioID].StockList[stockName.ToUpper()];
                }

                return valueSum;
            }
            else
            {
                throw new StockExchangeException("Error: Portfolio not found!");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (PortfolioExists(inPortfolioID))
            {
                //ako nema dionica, vrijednost portfelja je 0              
                if (NumberOfStocksInPortfolio(inPortfolioID) == 0)
                {
                    return 0;
                }

                decimal ratio;

                //definiramo pocetak i kraj mjeseca
                DateTime beginningOfMonth = new DateTime(Year, Month, 1, 0, 00, 00, 00);
                DateTime endOfMonth = new DateTime(Year, Month, 1, 23, 59, 59, 999).AddMonths(1).AddDays(-1);

                //moraju biti definirane vrijednosti SVIH dionica na pocetku i kraju mjeseca
                foreach (string stockName in SEData.Portfolios[inPortfolioID].StockList.Keys)
                {
                    if (SEData.Stocks[stockName.ToUpper()].priceHistory.ReturnEntryByDate(beginningOfMonth) == 0
                        || SEData.Stocks[stockName.ToUpper()].priceHistory.ReturnEntryByDate(endOfMonth) == 0)
                        throw new StockExchangeException("Error: Not all SEData.Stocks have defined values for that month!");
                }

                //inace, racunamo dalje
                decimal valueBeginningOfMonth = GetPortfolioValue(inPortfolioID, beginningOfMonth);
                decimal valueEndOfMonth = GetPortfolioValue(inPortfolioID, endOfMonth);

                //jednostavna operacija u kojoj cemo dohvatiti iz povijesti svake dionice unos za pocetak i kraj mjeseca i napraviti omjer
                ratio = (valueEndOfMonth - valueBeginningOfMonth) / valueBeginningOfMonth * 100;
                ratio = decimal.Round(ratio, 3);

                return ratio;
            }
            else
                throw new StockExchangeException("Error: Portfolio not found!");
        }
        #endregion
    }

}
