using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        int digitCounter;
        int comaCounter;
        bool minus;
        bool emptyScreen;
        bool bOperationReady;
        char currentBinaryOperator;
        bool isError;
        string currentDisplayState = "0";
        string nextDisplayState = "0";
        string savedDisplayState;
        string resultString;
        double result;
        double uNumber;
        double prevBinaryNumber;
        double currBinaryNumber;
        string allButtons = "9876543210,MSKTQRI+-*/=PGCO";

        public void Press(char inPressedDigit)
        {
            if(!allButtons.Contains(inPressedDigit))
            {
                DisplayString("-E-");
            }

            if("9876543210".Contains(inPressedDigit))
            {
                PressedDigit(inPressedDigit);
            }
            else if(inPressedDigit == 'M')
            {
                Minus();
            }
            else if("SKTQRI".Contains(inPressedDigit))
            {
                UnaryOperation(inPressedDigit);
            }
            else if("+-*/".Contains(inPressedDigit))
            {
                BinaryOperation();
                currentBinaryOperator = inPressedDigit;
            }   
            else if(inPressedDigit == '=')
            {
                bOperationReady = true;
                BinaryOperation();
                Equal();
                currentBinaryOperator = '0';
            }
            else if(inPressedDigit == 'P')
            {
                savedDisplayState = GetCurrentDisplayState();
            }
            else if(inPressedDigit == 'G')
            {
                DisplayString(savedDisplayState);
            }
            else if(inPressedDigit == 'C')
            {
                minus = false;
                Clear();
            }
            else if(inPressedDigit == 'O')
            {
                savedDisplayState = "";
                currentBinaryOperator = '0';
                minus = false;
                Clear();                
            }
            else if(inPressedDigit == ',')
            {
                comaCounter++;
                PressedDigit(inPressedDigit);
            }
            
        }

        public void PressedDigit(char pressedDigit)
        {
            if (digitCounter == 0)
            {
                if ((comaCounter == 0) && (pressedDigit != '0'))
                {
                    nextDisplayState = new string(pressedDigit, 1);
                }
                else if (comaCounter == 1)
                {
                    nextDisplayState = currentDisplayState + pressedDigit;
                }

                if (nextDisplayState != "0")
                {
                    digitCounter = 1;
                }
                else
                {
                    emptyScreen = true;
                }

            }
            else if ((digitCounter > 0) && (digitCounter < 10))
            {
                if (pressedDigit == ',')
                {
                    if (comaCounter == 1)
                    {
                        nextDisplayState = currentDisplayState + pressedDigit;
                    }
                }
                else
                {
                    nextDisplayState = currentDisplayState + pressedDigit;
                    digitCounter++;
                }
            }

            DisplayString(nextDisplayState);
        }

        public void DisplayString(string displayString)
        {
            currentDisplayState = displayString;
            emptyScreen = false;
            bOperationReady = true;

            if ((currentDisplayState == "0") || (currentDisplayState == "-E-"))
            {
                emptyScreen = true;
                if (currentDisplayState == "-E-")
                {
                    bOperationReady = false;
                }
            }
        }

        public void Minus()
        {
            if (emptyScreen == false)
            {
                string previousString = GetCurrentDisplayState();
                string currentString = "0";

                if (minus == false)
                {
                    currentString = "-" + previousString;
                    minus = true;
                }
                else if (minus == true)
                {
                    currentString = previousString.Remove(0, 1);
                    minus = false;
                }

                DisplayString(currentString);
            }
        }

        public double CurrentStringToNumber()
        {
            string currentString = GetCurrentDisplayState();
            double currentNumber = Convert.ToDouble(currentString);
            digitCounter = 0;
            comaCounter = 0;
            minus = false;
            return currentNumber;
        }

        public void UnaryOperation(char uOperator)
        {
            uNumber = CurrentStringToNumber();
            if(uOperator == 'K')
            {
                result = Math.Cos(uNumber);
            }
            else if (uOperator == 'S')
            {
                result = Math.Sin(uNumber);
            }
            else if(uOperator == 'T')
            {
                result = Math.Tan(uNumber);
            }
            else if(uOperator == 'Q')
            {
                result = uNumber * uNumber;
            }
            else if(uOperator == 'R')
            {
                if (uNumber >= 0)
                {
                    result = Math.Sqrt(uNumber);
                }
                else
                {
                    isError = true;
                }
            }
            else if(uOperator == 'I')
            {
                if (uNumber != 0)
                {
                    result = 1 / uNumber;
                }
                else
                {
                    isError = true;
                }
            }
            
            CheckResult();
            uNumber = result;
            Equal();
        }

        public void BinaryOperation()
        {
            if (bOperationReady == true)
            {
                prevBinaryNumber = currBinaryNumber;
                currBinaryNumber = CurrentStringToNumber();
                switch (currentBinaryOperator)
                {
                    case '+':
                        {
                            result = prevBinaryNumber + currBinaryNumber;
                            break;
                        }
                    case '-':
                        {
                            result = prevBinaryNumber - currBinaryNumber;
                            break;
                        }
                    case '*':
                        {
                            result = prevBinaryNumber * currBinaryNumber;
                            break;
                        }
                    case '/':
                        {
                            result = prevBinaryNumber / currBinaryNumber;
                            break;
                        }
                    default:
                        {
                            result = currBinaryNumber;
                            break;
                        }
                }
                CheckResult();
                currBinaryNumber = result;
                bOperationReady = false;
            }
        }

        public void CheckResult()
        {
            int pomComaIndicator = 0;
            string pomResultString = Convert.ToString(result);
            if (pomResultString.Contains(","))
            {
                pomComaIndicator = 1;
            }
            string[] pomStringArray = pomResultString.Split(',');
            pomResultString = pomStringArray[0];
            if (pomResultString.Contains("-"))
            {
                pomResultString = pomResultString.Remove(0, 1);
            }
            if (pomComaIndicator == 0)
            {
                int pom1StringLength = pomResultString.Length;
                if (pom1StringLength > 10)
                {
                    isError = true;
                }
            }
            else
            {
                int pom2StringLength = pomResultString.Length;
                if ((pom2StringLength < 11) && (pom2StringLength > 0))
                {
                    int decimalDigitNumber = 10 - pom2StringLength;
                    result = Math.Round(result, decimalDigitNumber);
                }
                else
                {
                    isError = true;
                }
            }
        }

        public void Equal()
        {
            if (isError == false)
            {
                resultString = Convert.ToString(result);
                DisplayString(resultString);
            }
            else
            {
                DisplayString("-E-");
                isError = false;
            }
        }

        public void Clear()
        {
            currentDisplayState = "0";
            digitCounter = 0;
            comaCounter = 0;
        }

        public string GetCurrentDisplayState()
        {
            return CleanDisplay();
        }

        private string CleanDisplay()
        {
            while (currentDisplayState.Length > 1 && (currentDisplayState.Substring(currentDisplayState.Length - 1, 1) == "0" || currentDisplayState.Substring(currentDisplayState.Length - 1, 1) == ","))
            {
                currentDisplayState = currentDisplayState.Substring(0, currentDisplayState.Length - 1);
            }
            return currentDisplayState;
        }
    }
}