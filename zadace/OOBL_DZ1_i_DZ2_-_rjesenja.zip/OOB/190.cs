﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string prikaz = "0";
        private string spremljeniBroj = "";

        private int dohvatiDuljinuPrikazaUZnamenkama()
        {
            int duljina = prikaz.Length;

            if (prikaz.Contains(','))
                duljina--;
            if (prikaz.StartsWith("-"))
                duljina--;

            return duljina;
        }

        private void promijeniPredznak()
        {
            // zdesna nalijevo idemo sve dok ne dođemo do početka, + mijenjamo u - i obrnuto
            int duljina = prikaz.Length-1;
            bool izmjena = false;
            while (duljina != -1)
            {
                if (prikaz[duljina] == '-')
                {
                    prikaz = prikaz.Substring(0, duljina) + '+' + prikaz.Substring(duljina + 1, prikaz.Length - 1 - duljina);
                    izmjena = true;
                    break;
                }
                else if (prikaz[duljina] == '+')
                {
                    prikaz = prikaz.Substring(0, duljina - 1) + '-' + prikaz.Substring(duljina + 1, prikaz.Length - 1 - duljina);
                    izmjena = true;
                    break;
                }
                duljina--;
            }
            if (prikaz.StartsWith("+"))
                prikaz = prikaz.Substring(1, prikaz.Length-1);
            if (izmjena == false)
                prikaz = "-" + prikaz;

            //if (!sadrziLiPrikazBinarnuOperaciju())
            //{
            //    // dodaj minus ako je pozitivan, makni ga ako je negativan
            //    if (!prikaz.StartsWith("-"))
            //        prikaz = "-" + prikaz;
            //    else
            //        prikaz = prikaz.Substring(1, prikaz.Length - 1);
            //}

        }

        private string zaokruziBroj(String brojStr)
        {
            if (brojStr.EndsWith(",0"))
                return brojStr.Substring(0, brojStr.Length - 2);
            else if (brojStr.EndsWith(",00"))
                return brojStr.Substring(0, brojStr.Length - 3);
            else if (brojStr.EndsWith(",000"))
                return brojStr.Substring(0, brojStr.Length - 4);
            else if (brojStr.EndsWith(",0000"))
                return brojStr.Substring(0, brojStr.Length - 5);
            else if (brojStr.EndsWith(",00000"))
                return brojStr.Substring(0, brojStr.Length - 6);
            else if (brojStr.EndsWith(",000000"))
                return brojStr.Substring(0, brojStr.Length - 7);
            else if (brojStr.EndsWith(",0000000"))
                return brojStr.Substring(0, brojStr.Length - 8);
            else if (brojStr.EndsWith(",00000000"))
                return brojStr.Substring(0, brojStr.Length - 9);
            else
                return brojStr;
        }

        private void izracunajSinus()
        {
            int brojac = prikaz.Length - 1;
            while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
            {
                brojac--;
            }
            string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac);
            double broj = double.Parse(operand);
            prikaz = Math.Sin(broj).ToString();
            skratiPrikazAkoTreba();
        }

        private void izracunajKosinus()
        {
            int brojac = prikaz.Length - 1;
            while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
            {
                brojac--;
            }
            string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac);
            double broj = double.Parse(operand);
            prikaz = Math.Cos(broj).ToString();
            skratiPrikazAkoTreba();
        }

        private void izracunajTangens()
        {
            int brojac = prikaz.Length - 1;
            while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
            {
                brojac--;
            }
            string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac);
            double broj = double.Parse(operand);
            prikaz = Math.Tan(broj).ToString();
            skratiPrikazAkoTreba();
        }

        // ako je prikaz zadnjeg unešenog broja dulji od 10 znakova, skrati ga
        private void skratiPrikazAkoTreba()
        {
            // ako je na ekranu samo jedan broj onda samo njega skraćujemo
            if (!sadrziLiPrikazBinarnuOperaciju())
            {
                bool sadrziZarez = prikaz.Contains(',');
                bool jeliNegativan = prikaz.StartsWith("-");
                if (dohvatiDuljinuPrikazaUZnamenkama() > 10)
                {
                    if (sadrziZarez && jeliNegativan)
                        prikaz = prikaz.Substring(0, 12);
                    else if (!sadrziZarez && jeliNegativan)
                        prikaz = prikaz.Substring(0, 11);
                    else if (sadrziZarez && !jeliNegativan)
                        prikaz = prikaz.Substring(0, 11);
                    else
                        prikaz = prikaz.Substring(0, 10);
                }
            }
            // inače dohvaćamo zadnji unešeni broj
            else
            {
                int rez = prikaz.LastIndexOfAny(new char[] { '+', '-', '*', '/' });
                string zadnjiUneseniBroj = prikaz.Substring(rez+1, prikaz.Length - rez-1);
                string prikazBezZadnjegUnesenogBroja = prikaz.Substring(0, rez+1);
                bool sadrziZarez = zadnjiUneseniBroj.Contains(',');

                if (sadrziZarez && zadnjiUneseniBroj.Length > 11)
                    prikaz = prikazBezZadnjegUnesenogBroja + zadnjiUneseniBroj.Substring(0, 11);
            }
        }

        private bool jeliUnarniOperator(char znak)
        {
            char[] unarniOperatori = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
            bool rez = false;
            foreach (char c in unarniOperatori)
            {
                if (c == znak)
                    rez = true;
            }
            return rez;
        }

        private bool jeliBinarniOperator(char znak)
        {
            char[] unarniOperatori = { '+', '-', '*', '/', };
            bool rez = false;
            foreach (char c in unarniOperatori)
            {
                if (c == znak)
                    rez = true;
            }
            return rez;
        }

        private bool sadrziLiPrikazBinarnuOperaciju()
        {
            bool rez = false;
            foreach (char c in prikaz)
            {
                if (jeliBinarniOperator(c))
                    rez = true;
            }
            return rez;
        }

        private void resetirajKalkulator()
        {
            prikaz = "0";
        }

        private void reduplicirajAkoJePotrebno()
        {
            if (prikaz.EndsWith("+") || prikaz.EndsWith("-") || prikaz.EndsWith("*") || prikaz.EndsWith("/"))
            {
                int brojac = prikaz.Length - 2;
                while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
                {
                    brojac--;
                }
                string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac-1);
                prikaz += operand;
            }
        }

        // pritisnut je znak "=", evaluiramo binarne operacije
        private void obaviOperaciju()
        {
            // ako se s lijeve strane nalazi samo broj tada je on rezultat evaluacije
            // idemo slijeva nadesno
            string[] operandi;
            if (!prikaz.StartsWith("-"))
                operandi = prikaz.Split(new char[] { '+', '-', '*', '/' });
            else
                operandi = prikaz.Substring(1, prikaz.Length-1).Split(new char[] { '+', '-', '*', '/' });
            if (operandi.Length == 1)
            {
                prikaz = zaokruziBroj(prikaz);
                return;
            }
            double rez = 0.0f;
            int opIndeks = 1;
            for (int i = 0; i < operandi.Length-1; i++)
            {
                int poz = prikaz.IndexOfAny(new char[] { '+', '-', '*', '/' }, opIndeks);
                opIndeks = poz + 1;
                double lijeviOperand = Double.Parse(prikaz.Substring(0, poz));
                int kraj = prikaz.IndexOfAny(new char[] { '+', '-', '*', '/' }, poz+1);
                if (kraj == -1)
                    kraj = prikaz.Length;
                double desniOperand = Double.Parse(prikaz.Substring(poz + 1, kraj - poz - 1));
                char operacija = prikaz[poz];
                if (operacija == '-')
                {
                    rez += lijeviOperand - desniOperand;
                    //prikaz = rez.ToString() + 
                }
                else if (operacija == '+')
                {
                    rez += lijeviOperand + desniOperand;
                }
                else if (operacija == '*')
                {
                    rez += lijeviOperand * desniOperand;
                }
                else if (operacija == '/')
                {
                    rez += lijeviOperand / desniOperand;
                }
            }
            prikaz = rez.ToString();
            //skratiPrikazAkoTreba();
            if (dohvatiDuljinuPrikazaUZnamenkama() > 10)
                prikaz = "-E-";
            prikaz = zaokruziBroj(prikaz);
        }

        // sprema trenutni prikaz u memoriju
        private void spremiPrikazUMemoriju()
        {
            spremljeniBroj = prikaz;
        }

        // dohvati spremljeni prikaz iz memorije
        private void dohvatiPrikazIzMemorije()
        {
            prikaz = spremljeniBroj;
        }

        // kvadrira zadnji broj
        private void kvadriraj()
        {
            int brojac = prikaz.Length - 1;
            while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
            {
                brojac--;
            }
            string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac);
            double broj = double.Parse(operand);
            prikaz = (broj * broj).ToString();
            skratiPrikazAkoTreba();
        }

        // inverz
        private void inverz()
        {
            int brojac = prikaz.Length - 1;
            while ((brojac > -1) && (Char.IsDigit(prikaz[brojac]) || prikaz[brojac] == ','))
            {
                brojac--;
            }
            string operand = prikaz.Substring(brojac + 1, prikaz.Length - 1 - brojac);
            double broj = double.Parse(operand);
            if (operand == "0")
            {
                prikaz = "-E-";
                return;
            }
            prikaz = (1/broj).ToString();
            skratiPrikazAkoTreba();
        }

        public void Press(char inPressedDigit)
        {
            // 0 pa znak jednakosti evaluiramo na 0
            if (prikaz == "0" && inPressedDigit == '=')
                prikaz = "0";
            // ako je unešen decimalni zarez tada početnu nulu ne brišemo
            else if (prikaz == "0" && inPressedDigit == ',')
                prikaz = "0,";
            else if (prikaz == "0" && Char.IsDigit(inPressedDigit))
                prikaz = inPressedDigit.ToString(); 
            else {
                // za unarne operatore operacija se obavlja nad trenutno prikazanim brojem na ekranu
                if (jeliUnarniOperator(inPressedDigit))
                {
                    switch (inPressedDigit)
                    {
                        case 'M':
                            promijeniPredznak();
                            break;
                        case 'S':
                            izracunajSinus();
                            break;
                        case 'K':
                            izracunajKosinus();
                            break;
                        case 'T':
                            izracunajTangens();
                            break;
                        case 'Q':
                            kvadriraj();
                            break;
                        case 'I':
                            inverz();
                            break;
                    }
                }
                else if (jeliBinarniOperator(inPressedDigit))
                {
                    // ne radimo skraćivanje jer inače faila jedan od testova
                    prikaz += inPressedDigit;
                }
                // je li utipkana znamenka
                else if (Char.IsDigit(inPressedDigit))
                {
                    prikaz += inPressedDigit;
                    skratiPrikazAkoTreba();
                }
                // zarez samo prikazujemo bez potencijanog skraćivanja
                else if (inPressedDigit == ',')
                {
                    prikaz += ',';
                }
                // resetiranje stanja kalkulatora
                else if (inPressedDigit == 'O')
                {
                    resetirajKalkulator();
                }
                // spremi broj
                else if (inPressedDigit == 'P')
                {
                    spremiPrikazUMemoriju();
                }
                else if (inPressedDigit == 'G')
                {
                    dohvatiPrikazIzMemorije();
                }
                // evaluiraj operaciju
                else if (inPressedDigit == '=')
                {
                    reduplicirajAkoJePotrebno();
                    obaviOperaciju();
                }                
            }
            //else if (inPressedDigit != '0') {
            //    prikaz += inPressedDigit;
            //}
            string s = Math.Round(-12345.67891234, 5).ToString();
        }

        public string GetCurrentDisplayState()
        {
            if (prikaz != "-E-") {
                if (prikaz.EndsWith("+") || prikaz.EndsWith("-") || prikaz.EndsWith("*") || prikaz.EndsWith("/")) {
                    string tempPrikaz = prikaz.Substring(0, prikaz.Length - 1);
                    return zaokruziBroj(tempPrikaz);
            }
            }
            return prikaz;
        }
    }


}
