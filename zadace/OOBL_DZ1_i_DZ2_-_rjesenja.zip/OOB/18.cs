﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using M=System.Math;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new SimpleCalculator();
        }
    }

    public class SimpleCalculator:ICalculator
    {
        private string operat = "0", memory, displayState = "0";
        private Boolean unarFlag = false, commaFlag = false, oper2Flag=false,operFlag = false;
        private Double number1,number2, number, result;
     

        private int getRoundNumber(double result)
        {
            if (Convert.ToInt64(result).ToString().Length <= 11)
            {
                int rounded = 999999999;
                long roundNumber = Convert.ToInt64(result);
                if (roundNumber < 0)
                {
                    if (roundNumber.ToString().Length <= 11) rounded = 11 - roundNumber.ToString().Length;
                }
                else
                {
                    if (roundNumber.ToString().Length <= 10) rounded = 10 - roundNumber.ToString().Length;
                }
                return rounded;
            }
            else
                return 0;
        }
        private int getLength(string number) 
        {
            int length;
            length = displayState.Length;
            if (displayState.StartsWith("-")) { length = length - 1; }
            if (displayState.IndexOf(",") != -1) { length = length - 1; }
            return length; 
        }


        public void Press(char inPressedDigit)
        {
            if ((displayState == "0" && inPressedDigit.ToString() == "0" && Char.IsDigit(inPressedDigit) && !commaFlag) || ((displayState == "0"  || displayState == "-E-") && Char.IsDigit(inPressedDigit) && !commaFlag) || (oper2Flag && operat != "0" && Char.IsDigit(inPressedDigit) && !commaFlag) || (unarFlag && operat != "0") && Char.IsDigit(inPressedDigit))
                
            {
                displayState = inPressedDigit.ToString();
                if (operat != "0")
                {
                    operFlag = true;
                    oper2Flag = false;
                }
            }
            else
            {
                if (unarFlag) { unarFlag = false; }
                
                switch (inPressedDigit)
                {
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        if (commaFlag) { displayState += ","; commaFlag = false; }
                        if (operat != "0") operFlag = true;
                        if (getLength(displayState) < 10)
                        {
                            displayState += inPressedDigit.ToString();
                        }
                        break;
                    case ',':
                        if (displayState.IndexOf(",") == -1)
                        commaFlag = true;
                        break;
                    case 'P':
                        memory = displayState;
                        break;
                    case 'G':
                        if (memory != null)
                            displayState = memory;
                        break;
                    case '+':
                        commaFlag = false;
                        if (operFlag) { Press('='); operFlag = false; }
                        operat = "+";
                        number1 = Convert.ToDouble(displayState);
                        oper2Flag = true;
                        break;
                    case '-':
                        commaFlag = false;
                        if (operFlag) { Press('='); operFlag = false; }
                        operat = "-";
                        number1 = Convert.ToDouble(displayState);
                        oper2Flag = true;
                        break;
                    case '*':
                        commaFlag = false;
                        if (operFlag) { Press('='); operFlag = false; }
                        operat = "*";
                        number1 = Convert.ToDouble(displayState);
                        oper2Flag = true;
                        break;
                    case '/':
                        commaFlag = false;
                        if (operFlag) { Press('='); operFlag = false; }
                        operat = "/";
                        number1 = Convert.ToDouble(displayState);
                        oper2Flag = true;
                        break;
                    case '=':
                        displayState = Convert.ToDouble(displayState).ToString();
                        switch(operat)
                        {
                            case "+":
                                number2 = Convert.ToDouble(displayState);
                                result = number1 + number2;
                                if (Convert.ToInt64(result).ToString().Length >= 11) displayState = "-E-";
                                else
                                {
                                    result = M.Round(result, getRoundNumber(result));
                                    displayState = result.ToString("0.#########");
                                }
                                number1 = 0;
                                number2 = 0;
                                operat = "0";
                                break;
                            case "-":
                                number2 = Convert.ToDouble(displayState);
                                result = number1 - number2;
                                result = M.Round(result, getRoundNumber(result));
                                displayState = result.ToString("0.#########");
                                number1 = 0;
                                number2 = 0;
                                operat = "0";
                                break;
                            case "/":
                                number2 = Convert.ToDouble(displayState);
                                if (number2 == 0) displayState = "-E-";
                                else
                                {
                                    result = number1 / number2;
                                    if (Convert.ToInt64(result).ToString().Length >= 11) displayState = "-E-";
                                    else
                                    {
                                        result = M.Round(result, getRoundNumber(result));
                                        displayState = result.ToString("0.#########");
                                    }
                                    number1 = 0;
                                    number2 = 0;
                                    operat = "0";
                                }
                                break;
                            case "*":
                                number2 = Convert.ToDouble(displayState);
                                result = number1 * number2;
                                if (Convert.ToInt64(result).ToString().Length >= 11) displayState = "-E-";
                                else
                                {
                                    result = M.Round(result, getRoundNumber(result));
                                    displayState = result.ToString("0.#########");
                                }
                                number1 = 0;
                                number2 = 0;
                                operat = "0";
                                memory = "0";
                                break;
                        }
                        break;
                    case 'I':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        if (number == 0) displayState = "-E-";
                        else
                        {

                            result = 1 / number;
                            result = M.Round(result, getRoundNumber(result));
                            displayState = result.ToString("0.#########");
                            unarFlag = true;
                        }
                        break;
                    case 'Q':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        result = number * number;
                        result = M.Round(result, getRoundNumber(result));
                        displayState = result.ToString("0.#########");
                        unarFlag = true;
                        break;
                    case 'R':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        if (number < 0) displayState = "-E-";
                        else 
                        {
                            result = M.Sqrt(number);
                            result = M.Round(result, getRoundNumber(result));
                            displayState = result.ToString("0.#########");
                            unarFlag = true;
                        } 
                        break;
                    case 'S':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        result=M.Sin(number);
                        result = M.Round(result, 9);
                        displayState = result.ToString("0.#########");
                        unarFlag = true;
                        break;
                    case 'K':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        result = M.Cos(number);
                        result = M.Round(result, getRoundNumber(result));
                        displayState = result.ToString("0.#########");
                        unarFlag = true;
                        break;
                    case 'T':
                        commaFlag = false;
                        number = Convert.ToDouble(displayState);
                        result = M.Tan(number);
                        result = M.Round(result, getRoundNumber(result));
                        displayState = result.ToString("0.#########");
                        unarFlag = true;
                        break;
                    case 'M':
                        displayState = (0-Convert.ToDouble(displayState)).ToString();
                        break;
                    case 'C':
                        displayState = "0";
                        break;
                    case 'O':
                        displayState = "0";
                        operFlag = false;
                        unarFlag = false;
                        commaFlag = false;
                        operat="0";
                        oper2Flag = false;
                        memory = null;
                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            displayState.Replace('.', ','); 
            return displayState;
        }
    }
}
