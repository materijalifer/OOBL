﻿using System;
using System.Diagnostics;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public enum Operation
    {
        Plus,
        Minus,
        Multiply,
        Divide
    }

    public class Kalkulator : ICalculator
    {
        public const int MaxDigits = 10;
        private readonly CultureInfo conversionCulture = CultureInfo.GetCultureInfo("hr-HR");

        private bool clearOnPress;
        private bool lastInputIsOperation;

        private double memory;
        private string operation = string.Empty;

        private double _registerA;
        private double registerA
        {
            get { return _registerA; }
            set
            {
                _registerA = Round(value);
                display = _registerA.ToString(conversionCulture);
            }
        }

        private double _registerB;
        private double registerB
        {
            get { return _registerB; }
            set { _registerB = Round(value); }
        }

        private string display = "0";
        private double displayValue
        {
            get { return double.Parse(display); }
            set { display = Round(value).ToString(conversionCulture); }
        }

        private bool error;
        private const string errorString = "-E-";

        public void Press(char inPressedDigit)
        {
            Debug.WriteLine("Input: " + inPressedDigit);

            // reset
            if (inPressedDigit == 'O')
                Reset();

            // no reaction if in error
            if (error)
                return;

            // digit or comma
            if (char.IsDigit(inPressedDigit) || inPressedDigit == ',')
                InputNumber(inPressedDigit);

            // plus
            if (inPressedDigit == '+')
                Plus();

            // minus
            if (inPressedDigit == '-')
                Minus();

            // multiply
            if (inPressedDigit == '*')
                Multiply();

            // divide
            if (inPressedDigit == '/')
                Divide();

            // equals
            if (inPressedDigit == '=')
                Equals();

            // inverse sign
            if (inPressedDigit == 'M')
                InverseSign();

            // square
            if (inPressedDigit == 'Q')
                Square();

            // square root
            if (inPressedDigit == 'R')
                Root();

            // inverse
            if (inPressedDigit == 'I')
                Inverse();

            // sine
            if (inPressedDigit == 'S')
                Sin();

            // cosine
            if (inPressedDigit == 'K')
                Cos();

            // tangens
            if (inPressedDigit == 'T')
                Tan();

            // clearthe display
            if (inPressedDigit == 'C')
                Clear();

            // put in memory
            if (inPressedDigit == 'P')
                PutInMemory();

            // get from memory
            if (inPressedDigit == 'G')
                GetFromMemory();

        }

        /// <summary>
        /// Returns whatever is on the display.
        /// </summary>
        /// <returns>The current display state.</returns>
        public string GetCurrentDisplayState()
        {
            string displayState = error ? errorString : display;
            Debug.WriteLine("Display: " + displayState);

            return displayState;
        }

        /// <summary>
        /// Rounds the number to a predefined number of digits.
        /// </summary>
        /// <param name="value">Value to be rounded.</param>
        /// <returns>Rounded value.</returns>
        private double Round(double value)
        {
            // number of left-digits
            int leftDigits = (int) Math.Ceiling(Math.Log10(Math.Abs(value)));
            leftDigits = Math.Max(leftDigits, 0);

            // normalize number
            double normalized = value*Math.Pow(10, -leftDigits);

            // round
            double roundedNormalized = Math.Round(normalized, MaxDigits - 1 + Math.Sign(leftDigits));

            // de-normalize it
            double rounded = roundedNormalized*Math.Pow(10, leftDigits);

            return rounded;
        }

        /// <summary>
        /// Return true if the number is too big to fit on the screen.
        /// </summary>
        /// <param name="value">The number queried.</param>
        /// <returns>True if the number is too big and false if it isn't.</returns>
        private bool IsTooBig(double value)
        {
            string strippedValue = value.ToString(conversionCulture).Replace("-", "");
            int decimalIndex = value.ToString(conversionCulture).Replace("-", "").IndexOf(",", StringComparison.Ordinal);
            if (decimalIndex == -1)
                return strippedValue.Length > MaxDigits;
            
            return decimalIndex > MaxDigits;
        }

        /// <summary>
        /// Handles digit and comma input.
        /// </summary>
        /// <param name="pressed">Can be a digit or a comma.</param>
        private void InputNumber(char pressed)
        {
            // handle input of new numbers
            if (clearOnPress)
            {
                display = "0";
                registerA = 0;
                clearOnPress = false;
            }

            // strip the display to numbers only
            bool hasSign = display.IndexOf("-", StringComparison.Ordinal) >= 0;
            int commaPosition = display.IndexOf(",", StringComparison.Ordinal);

            string strippedDisplay = display.Replace("-", "").Replace(",", "");

            // add if comma pressed and no comma present
            if (pressed == ',' && commaPosition == -1)
            {
                strippedDisplay += pressed;
            }

            // add if digit and digits not maxed
            if (char.IsDigit(pressed) && strippedDisplay.Length < MaxDigits)
                strippedDisplay += pressed;

            // add sign
            if (hasSign && strippedDisplay != "0" && strippedDisplay != string.Empty)
                strippedDisplay = "-" + strippedDisplay;

            // add comma
            if (commaPosition >= 0)
                strippedDisplay = strippedDisplay.Insert(commaPosition, ",");

            // trim zeroes
            strippedDisplay = strippedDisplay.Trim('0');

            // if stripped goes null, replace with zero
            if (strippedDisplay == string.Empty)
                strippedDisplay = "0";

            // if stripped starts with a comma insert zero
            if (strippedDisplay.StartsWith(","))
                strippedDisplay = "0" + strippedDisplay;

            display = strippedDisplay;
            if (pressed != ',')
            {
                registerA = double.Parse(display);
            }

            lastInputIsOperation = false;
        }

        /// <summary>
        /// Adds the buffer with the current number on the display.
        /// </summary>
        private void Plus()
        {
            if (!lastInputIsOperation)
            {
                registerB = registerA;
                Equals();
            }

            operation = "+";
            clearOnPress = true;
            lastInputIsOperation = true;
        }

        /// <summary>
        /// Substracts the current number on the display from buffer.
        /// </summary>
        private void Minus()
        {
            if (!lastInputIsOperation)
            {
                registerB = registerA;
                Equals();
            }

            operation = "-";
            clearOnPress = true;
            lastInputIsOperation = true;
        }

        /// <summary>
        /// Multiplies the number on the display and the buffer.
        /// </summary>
        private void Multiply()
        {
            if (!lastInputIsOperation)
            {
                registerB = registerA;
                Equals();
            }

            operation = "*";
            clearOnPress = true;
            lastInputIsOperation = true;
        }

        /// <summary>
        /// Divides the buffer with the number on the display.
        /// </summary>
        private void Divide()
        {
            if (!lastInputIsOperation)
            {
                registerB = registerA;
                Equals();
            }

            operation = "/";
            clearOnPress = true;
            lastInputIsOperation = true;
        }

        /// <summary>
        /// Performs the current operation.
        /// </summary>
        private void Equals()
        {
            if (operation == string.Empty)
                return;

            double result = 0;
            if (operation == "+")
            {
                result = displayValue + registerB;
            }

            if (operation == "-")
            {
                result = registerB - displayValue;
            }

            if (operation == "*")
            {
                result = displayValue * registerB;
            }

            if (operation == "/")
            {
                result = registerB / displayValue;
            }

            if (IsTooBig(result))
            {
                Error();
                return;
            }

            clearOnPress = true;
            lastInputIsOperation = false;
            registerA = result;
        }

        /// <summary>
        /// Inverses the sign on the number on the display
        /// </summary>
        private void InverseSign()
        {
            displayValue *= -1;
            registerA = displayValue;
        }

        /// <summary>
        /// Inverts the number on the display (1/x)
        /// </summary>
        private void Inverse()
        {
            if (Math.Abs(registerA - 0.0) < double.Epsilon)
            {
                Error();
                return;
            }

            displayValue = 1 / displayValue;
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Squares the number on the display
        /// </summary>
        private void Square()
        {
            double result = displayValue * displayValue;
            if (IsTooBig(result))
            {
                Error();
                return;
            }

            displayValue = result;
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Displays the square root of the number on the display.
        /// </summary>
        private void Root()
        {
            // no complex numbers
            if (displayValue < 0)
            {
                Error();
                return;
            }

            displayValue = Math.Sqrt(displayValue);
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Displays the sine of the number on the display.
        /// </summary>
        private void Sin()
        {
            displayValue = Math.Sin(displayValue);
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Displays the cosine of the number on the display.
        /// </summary>
        private void Cos()
        {
            displayValue = Math.Cos(displayValue);
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Displays the tangent of the number on the display
        /// </summary>
        private void Tan()
        {
            displayValue = Math.Tan(displayValue);
            registerA = displayValue;
            clearOnPress = true;
        }

        /// <summary>
        /// Puts the calculator in error mode.
        /// </summary>
        private void Error()
        {
            error = true;
        }

        /// <summary>
        /// Clears the current display.
        /// </summary>
        private void Clear()
        {
            registerA = 0;
        }

        /// <summary>
        /// Resets the calculator
        /// </summary>
        private void Reset()
        {
            memory = 0;
            registerA = 0;
            registerB = 0;
            display = "0";
            error = false;
            clearOnPress = false;
        }

        /// <summary>
        /// Put the number on the display into memory.
        /// </summary>
        private void PutInMemory()
        {
            memory = registerA;
        }

        /// <summary>
        /// Prints the number in memory to the display
        /// </summary>
        private void GetFromMemory()
        {
            registerA = memory;
        }
    }


}
