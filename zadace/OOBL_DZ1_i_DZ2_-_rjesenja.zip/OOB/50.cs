﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using System.Diagnostics;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        /* Private enum tipovi*/
        private enum unaryOp
        {
            sin = 0,
            cos,
            tan,
            power,
            sqrt,
            inverz,
            prefix,
            empty
        };
        private enum binOp
        {
            plus = 0,
            minus,
            multiply,
            divide,
            empty
        };
        private enum digit
        {
            number = 0,
            binOperator,
            unOperator,
            decimalPoint,
            equal,
            memPut,
            memGet,
            clear,
            reset,
            error
        };
        
        /* Private Varijable */
        private double firstOperand;
        private double secondOperand;
        private bool firstOperandSet;
        private bool secondOperandSet;
        private int maxSize;
        private string display;
        private double result;
        private double memory;
        private string tempInput;
		private digit lastInput;
        private unaryOp uOperacija;
        private binOp bOperacija;
        private binOp bOperacijaTemp;

        /* Private konstante*/
        private const string numbers = "0123456789";
        private const string unaryOperators = "SKTQRIM";
        private const string binaryOperators = "+-*/";

        /* Private Metode */
        
        /*Metoda prima uneseni znak i vraca da li je korisnik unio broj, operaciju ...*/
		private digit CheckDigit (char inPressedDigit)
		{	
			int testPressedKey = numbers.IndexOf(inPressedDigit);
			if (testPressedKey != -1)
			{
				return digit.number;
			}
			
			testPressedKey = unaryOperators.IndexOf(inPressedDigit);
			if (testPressedKey != -1)
			{
				uOperacija = (unaryOp)testPressedKey;
				return digit.unOperator;
			}
			
			testPressedKey = binaryOperators.IndexOf(inPressedDigit);
			if (testPressedKey != -1)
			{
				bOperacijaTemp = (binOp)testPressedKey;
				return digit.binOperator;
			}
			
			if (inPressedDigit == 'C') return digit.clear;
			if (inPressedDigit == 'O') return digit.reset;
			if (inPressedDigit == 'P') return digit.memPut;
			if (inPressedDigit == 'G') return digit.memGet;
			if (inPressedDigit == ',') return digit.decimalPoint;
			if (inPressedDigit == '=') return digit.equal;
			return digit.error;
		}
        
        /*Metoda za ciscenje zadnje unesenog broja*/
        private void Clear()
        {
            tempInput = "0";
        }
        
        /*Metoda za provjeru da li broj ima decimalni zarez i za dodavanje zareza*/
        private void DecPoint()
        {
            int checkIfHasPoint;
            checkIfHasPoint = tempInput.IndexOf(',');
            if (checkIfHasPoint == -1)
            {
                addDigit(',');
                SetMaxSize();
            }
        }
        
        /*Metoda za dodavanje znamenke broju*/
        private void addDigit(char digit)
        {
            tempInput += digit;
        }
        
        /*Metoda koja se poziva kada je unesea znamenka*/
        /*-ovisno o prethodno unesenom znaku odlucuje sta treba dalje napraviti*/
        private void Number(char num)
        {
            addDigit(num);
            if (lastInput == digit.equal) firstOperandSet = false;
            if (tempInput.Length == (maxSize + 1))
            {
                tempInput = tempInput.Remove(maxSize, 1);
            }
            secondOperandSet = false;
            MultipleNull();
        }
        
        /*Metoda se poziva nakon sto je stisnut znak '=' i racuna rezultat*/
        private void Equal()
        {
            if (lastInput == digit.binOperator) tempInput = firstOperand.ToString();
            BCalculate();
        }      

        /*Metoda za ispis broja na ekran*/
        private void SetDisplay()
        {
            display = tempInput;
           // Debug.WriteLine("Display: " + display);
        }       
        
        /*Metoda za spremanje broja u memoriju*/
        private void PutMemory()
        {
            memory = double.Parse(tempInput);
        }      
        
        /*Metoda za citanje broja iz memorije*/
        private void GetMemory()
        {
            tempInput = memory.ToString();
        }
        
        /*Metoda postavljanje maksimalno dopustene velicine stringa*/
        /*-koristi se kako bi na ekranu uvijek bilo maksimalno ispisano 10 znamenki*/
        private void SetMaxSize()
        {
            int decPoint;
            decPoint = tempInput.IndexOf(',');
            if (result < 0 && decPoint != -1) maxSize = 12;
            else if (result < 0) maxSize = 11;
            else if (decPoint != -1) maxSize = 11;
            else maxSize = 10;
        }
        
        /*Metoda koja sprjecava unos vise 0 na pocetku broja*/
        private void MultipleNull()
        {
            if (tempInput.Length == 2)
            {
                if (tempInput[0] == '0') tempInput = tempInput[1].ToString();
            }
        }
        
        /*Metoda za zaokruzivanje rezultata*/
        private double Round(double number)
        {
            if (Math.Abs(number) > 9999999999)
            {
                tempInput = "-E-";
                return 0;
            }
            else
            {
                int i = 0;
                double tmpResult = number;
                do
                {
                    tmpResult /= 10;
                    i++;
                }
                while (Math.Abs(tmpResult) > 1);
                tmpResult = Math.Round(number, (10 - i));
                tempInput = tmpResult.ToString();
                return tmpResult;
            }
        }
       
        /*Metoda koja se poziva kada je unesena neka unarna operacija*/
        private void UnOperator()
        {
            if (lastInput == digit.binOperator) tempInput = firstOperand.ToString();
            UCalculate();
            SetDisplay();
            if (lastInput == digit.binOperator)
            {
                secondOperand = double.Parse(tempInput);
                secondOperandSet = true;
                Clear();
            }
        }	   
        /*Metoda koja racuna rezultat unarnih operacije*/
        private void UCalculate()
        {
            double tempResult = double.Parse(tempInput);
            switch (uOperacija)
            {
                case unaryOp.sin:
                    result = Math.Sin(tempResult);
                    break;

                case unaryOp.cos:
                    result = Math.Cos(tempResult);
                    break;

                case unaryOp.tan:
                    result = Math.Tan(tempResult);
                    break;

                case unaryOp.power:
                    result = Math.Pow(tempResult, 2);
                    break;

                case unaryOp.sqrt:
                    result = Math.Sqrt(tempResult);
                    break;

                case unaryOp.inverz:
                    result = tempResult;
                    result = 1 / result;
                    break;

                case unaryOp.prefix:
                    result = tempResult * (-1);
                    break;
            }

            /* Zaokruzivanje */
            result = Round(result);
            SetMaxSize();
        }
        
        /*Metoda koja se poziva kada je unesena neka binarna operacija (+,-,*,/)*/
        private void BinOperator(char inPressedDigit)
        {
            if (bOperacija == binOp.empty)
            {
                bOperacija = bOperacijaTemp;
                BCalculate();
                SetDisplay();
                Clear();
            }
            else
            {
                if (lastInput == digit.binOperator)
                {
                    bOperacija = bOperacijaTemp;
                }
                else
                {
                    BCalculate();
                    SetDisplay();
                    bOperacija = bOperacijaTemp;
                    Clear();
                }
            }
        }                
        /*Metoda koja racuna rezultat binarnih operacija*/
        private void BCalculate()
        {
           // if (firstOperand == 0)
            if(firstOperandSet == false)
            {
                firstOperandSet = true;
                firstOperand = double.Parse(tempInput);
                if (bOperacija == binOp.empty) firstOperand = Round(firstOperand);         
            }
            else
            {
                /*if(secondOperand == 0)*/
                if (secondOperandSet == false)
                {
                    secondOperandSet = true;
                    secondOperand = double.Parse(tempInput);
                }
                switch (bOperacija)
                {
                    case binOp.plus:
                        firstOperand += secondOperand;
                        break;
                    case binOp.minus:
                        firstOperand -= secondOperand;
                        break;
                    case binOp.multiply:
                        firstOperand = firstOperand * secondOperand;
                        break;
                    case binOp.divide:
                        firstOperand /= secondOperand;
                        break;
                }

                /* Zaokruzivanje */
                firstOperand = Round(firstOperand);
            }
            SetMaxSize();
        }
       
        /*Metoda za resetiranje digitrona*/
        private void reset()
        {
            firstOperand = 0;
            secondOperand = 0;
            firstOperandSet = false;
            secondOperandSet = false;
            maxSize = 10;
            display = "0";
            result = 0;
            memory = 0;
            tempInput = "0";
            lastInput = digit.number;
            uOperacija = unaryOp.empty;
            bOperacija = binOp.empty;
            bOperacijaTemp = binOp.empty;
        }
        
        /* Public Metode */

        /*Konstruktor - pravilno inicijalizira sve varijable*/
        public Kalkulator()
        {
            firstOperand = 0;
            secondOperand = 0;
            firstOperandSet = false;
            secondOperandSet = false;
            maxSize = 10;
            display = "0";
            result = 0;
            memory = 0;
            tempInput = "0";
		    lastInput = digit.number;
		    uOperacija = unaryOp.empty;
            bOperacija = binOp.empty;
		    bOperacijaTemp = binOp.empty;
        }	
        
        /*Metoda pomocu koje se unose vrijednosti*/
        public void Press(char inPressedDigit)
        {
           // Debug.WriteLine("pressedkey: " + inPressedDigit);
            digit input = CheckDigit(inPressedDigit);
			switch(input)
			{
				case digit.number:
					Number(inPressedDigit);
					SetDisplay();
					break;
					
				case digit.unOperator:
					UnOperator();
					break;
					
				case digit.binOperator:
					BinOperator(inPressedDigit);
					break;
					
				case digit.clear:
					Clear();
					SetDisplay();
					break;
					
				case digit.reset:
					reset();
					SetDisplay();
					break;
					
				case digit.decimalPoint:
					DecPoint();
					SetDisplay();
					break;
					
				case digit.equal:
					Equal();
					SetDisplay();
                    Clear();
					break;
					
				case digit.memPut:
					PutMemory();
					break;
					
				case digit.memGet:
					GetMemory();
					SetDisplay();
					break;
					
				case digit.error:
					break;
			}
			lastInput = input;
        }
       
        /*Metoda za prikaz trenutnog stanja ekrana*/
        public string GetCurrentDisplayState()
        {
            return display;
        }
    }
}