﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

        public static class Factory
        {
            public static IStockExchange CreateStockExchange()
            {
                return new StockExchange();
            }
        }

        public class StockPrice : IComparable
        {
            public DateTime date;
            public decimal price;
            public StockPrice(DateTime date, decimal price)
            {
                this.date = date;
                this.price = price;
            }

            public int CompareTo(object obj)
            {
                StockPrice sp = (StockPrice)obj;
                return DateTime.Compare(this.date, sp.date);
            }
        }

        public class Stock : IEquatable<Stock>
        {

            public List<StockPrice> stockPriceList;
            private string stockName;
            public string StockName
            {
                get { return stockName; }
            }

            private long numberOfShares;
            public long NumberOfShares
            {
                get { return numberOfShares; }
            }

            private decimal initialPrice;
            public decimal InitialPrice
            {
                get { return initialPrice; }
            }

            public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
            {
                stockPriceList = new List<StockPrice>();
                stockPriceList.Add(new StockPrice(timeStamp, initialPrice));

                this.stockName = stockName;
                this.numberOfShares = numberOfShares;
                this.initialPrice = initialPrice;
            }

            public decimal GetPrice(DateTime timeStamp)
            {
                StockPrice sp = this.stockPriceList.FindLast(x => x.date.CompareTo(timeStamp) <= 0);
                return sp.price;
            }

            #region IEquatable<Stock> Members

            public bool Equals(Stock other)
            {
                if (other == null) return false;
                return (this.stockName.ToLower().Equals(other.stockName.ToLower()));
            }

            public override int GetHashCode()
            {
                return this.stockName.ToLower().GetHashCode();
            }

            public override bool Equals(object obj)
            {
                Stock stock = obj as Stock;
                if (stock != null)
                {
                    return Equals(stock);
                }
                else
                {
                    return false;
                }
            }
            #endregion
        }

        public abstract class Index
        {
            public List<Stock> stocksList = new List<Stock>();

            protected string indexName;
            public string IndexName
            {
                get { return indexName; }
            }

            protected IndexTypes indexType;
            public IndexTypes IndexType
            {
                get { return indexType; }
            }

            public abstract decimal GetValue(DateTime inTimeStamp);
        }


        public class AvarageIndex : Index
        {
            public AvarageIndex(string indexName, IndexTypes indextype)
            {
                this.indexName = indexName;
                this.indexType = indextype;
                stocksList = new List<Stock>();
            }
            public override decimal GetValue(DateTime inTimeStamp)
            {
                decimal sum = 0.0m;
                long numberOfShares = 0;

                foreach (Stock stock in stocksList)
                {
                    StockPrice sp = stock.stockPriceList.FindLast(x => x.date.CompareTo(inTimeStamp) <= 0);
                    sum = sum + (sp.price * stock.NumberOfShares);
                    numberOfShares += stock.NumberOfShares;
                }

                decimal result = sum / numberOfShares;

                return Math.Round(result, 3);
            }
        }

        public class WeightedIndex : Index
        {
            public WeightedIndex(string indexName, IndexTypes indextype)
            {
                this.indexName = indexName;
                this.indexType = indextype;
                stocksList = new List<Stock>();
            }

            public override decimal GetValue(DateTime inTimeStamp)
            {
                decimal sum = 0.0m;
                decimal weightedSum = 0.0m;
                long numberOfShares = 0;

                foreach (Stock stock in stocksList)
                {
                    StockPrice sp = stock.stockPriceList.FindLast(x => x.date.CompareTo(inTimeStamp) <= 0);
                    sum = sum + (sp.price * stock.NumberOfShares);
                }

                foreach (Stock stock in stocksList)
                {
                    StockPrice sp = stock.stockPriceList.FindLast(x => x.date.CompareTo(inTimeStamp) <= 0);
                    weightedSum += ((sp.price * stock.NumberOfShares) / sum) * sp.price;
                }

                return Math.Round(weightedSum, 3);
            }
        }

        public class Portfolio
        {
            private string portfolioID;
            public string PortfolioID
            {
                get { return portfolioID; }
            }
            //public Dictionary<string, long> stocks = new Dictionary<string, long>();
            public Dictionary<Stock, long> stocks = new Dictionary<Stock, long>();

            public Portfolio(string portfolioID)
            {
                this.portfolioID = portfolioID;
            }
            
            /// <summary>
            /// Vraca vrijednost portfelja za zadani datum
            /// </summary>
            /// <param name="inTimeStamp"></param>
            /// <returns></returns>
            public Decimal GetValue(DateTime inTimeStamp)
            {
                decimal totalValue = 0.0m;
                Stock stock = null;
                StockPrice sp;

                foreach (var s in stocks)
                {
                    stock = s.Key;
                    //trazi trenutnu cijenu dionice
                    sp = stock.stockPriceList.FindLast(x => x.date.CompareTo(inTimeStamp) <= 0);

                    totalValue = totalValue + sp.price * s.Value;
                }
                return totalValue;
            }

            //vraca broj odredjenih dionica u portfelju
            public long GetNumberOfShares(Stock stock)
            {
                long numberOfShares = stocks[stock];
                return numberOfShares;
            }

            public void AddStock(Stock stock,long inNumberOfShares)
            {
                stocks.Add(stock,inNumberOfShares);
            }

            public void RemoveStock(Stock stock)
            {
                stocks.Remove(stock);
            }

            public void RemoveStock(Stock stock,long inNumberOfShares )
            {
                stocks[stock] -= inNumberOfShares;
            }
        }

        public class StockExchange : IStockExchange
        {
            List<Stock> stocksList = new List<Stock>();
            List<Index> indexList = new List<Index>();
            List<Portfolio> portfolioList = new List<Portfolio>();
            //
            #region Stock
            public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
            {
                //provjerava da li vec postoji dionica
                if (StockExists(inStockName))
                {
                    throw new StockExchangeException("Dionica vec postoji!");
                }
                else
                {
                    if (inInitialPrice <= 0 || inNumberOfShares <= 0)
                    {
                        throw new StockExchangeException("Broj dionica i cijana ne mogu biti negativni");
                    }
                    Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                    stocksList.Add(stock);
                }
            }

            //treba dodati i brisanje iz indexa
            public void DelistStock(string inStockName)
            {
                stocksList.RemoveAll(s => s.StockName.ToLower() == inStockName.ToLower());

                //brisanje iz indexa
                foreach (Index index in indexList)
                {
                    if (IsStockPartOfIndex(index.IndexName, inStockName))
                    {
                        RemoveStockFromIndex(index.IndexName,inStockName);
                    }
                }
                //brisanje iz portfolia
                foreach (Portfolio portfolio in portfolioList)
                {
                    if (IsStockPartOfPortfolio(portfolio.PortfolioID, inStockName))
                    {
                        RemoveStockFromPortfolio(portfolio.PortfolioID,inStockName);
                    }
                }
            }

            public bool StockExists(string inStockName)
            {
                return stocksList.Exists(s => s.StockName.ToLower() == inStockName.ToLower());
            }

            public int NumberOfStocks()
            {
                return stocksList.Count();
            }

            public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
            {
                if (inStockValue <= 0)
                {
                    throw new StockExchangeException("cijena ne smije biti negativna");
                }

                if (StockExists(inStockName))
                {
                    Stock stock = GetStock(inStockName);

                    //provjera jel vec postoji cijena za taj datum                
                    bool dateExist = stock.stockPriceList.Exists(x => x.date.CompareTo(inIimeStamp) == 0);
                    if (dateExist == true)
                    {
                        throw new StockExchangeException("Postoji cijena za navedeno vrijeme!");
                    }
                    else
                    {
                        stock.stockPriceList.Add(new StockPrice(inIimeStamp, inStockValue));
                        stock.stockPriceList.Sort();//sortira uzlazno
                    }
                }
                else
                {
                    throw new StockExchangeException("Ne postoji tražena dionica!");
                }

            }

            public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
            {
                if (StockExists(inStockName))
                {
                    Stock stock = GetStock(inStockName);
                    StockPrice sp = stock.stockPriceList.FindLast(x => x.date.CompareTo(inTimeStamp) <= 0);
                    
                    if (sp == null)
                    {
                        throw new StockExchangeException("ne postoji cijena za trazeni datum");
                    }
                    else
                    {
                        return sp.price;
                    }
                }
                else
                {
                    throw new StockExchangeException("ne postoji dionica");
                }
            }

            public decimal GetInitialStockPrice(string inStockName)
            {
                if (StockExists(inStockName))
                {
                    Stock stock = GetStock(inStockName);
                    return stock.InitialPrice;
                }
                else
                {
                    throw new StockExchangeException("Ne postoji dionica!");
                }
            }

            public decimal GetLastStockPrice(string inStockName)
            {
                //vraca trenutnu cijenu dionice
                return GetStockPrice(inStockName, DateTime.Now);
            }
            #endregion

            #region Index
            public void CreateIndex(string inIndexName, IndexTypes inIndexType)
            {
                if (IndexExists(inIndexName))
                {
                    throw new StockExchangeException("Index vec postoji!");
                }
                else
                {
                    Index index = null;
                    if (inIndexType == IndexTypes.AVERAGE)
                    {
                        index = new AvarageIndex(inIndexName, inIndexType);
                    }
                    else if (inIndexType == IndexTypes.WEIGHTED)
                    {
                        index = new WeightedIndex(inIndexName, inIndexType);
                    }
                    else
                    {
                        throw new StockExchangeException("Ne postoji takav tip indexa!");
                    }
                    indexList.Add(index);
                }
            }

            public void AddStockToIndex(string inIndexName, string inStockName)
            {
                if (IndexExists(inIndexName))
                {
                    if (StockExists(inStockName))
                    {
                        Index index = indexList.Find(x => x.IndexName.ToLower() == inIndexName.ToLower());
                        Stock stock = stocksList.Find(x => x.StockName.ToLower() == inStockName.ToLower());
                        index.stocksList.Add(stock);
                    }
                    else
                    {
                        throw new StockExchangeException("Ne postoji dionica!");
                    }
                }
                else
                {
                    throw new StockExchangeException("Ne postoji index!");
                }
            }

            public void RemoveStockFromIndex(string inIndexName, string inStockName)
            {
                if (IndexExists(inIndexName))
                {
                    if (StockExists(inStockName))
                    {
                        Index index = indexList.Find(x => x.IndexName.ToLower() == inIndexName.ToLower());
                        Stock stock = index.stocksList.Find(x => x.StockName.ToLower() == inStockName.ToLower());
                        index.stocksList.Remove(stock);
                    }
                    else
                    {
                        throw new StockExchangeException("Ne postoji dionica!");
                    }
                }
                else
                {
                    throw new StockExchangeException("Ne postoji index!");
                }
            }

            public bool IsStockPartOfIndex(string inIndexName, string inStockName)
            {
                if (IndexExists(inIndexName))
                {
                    if (StockExists(inStockName))
                    {
                        Index index = indexList.Find(x => x.IndexName.ToLower() == inIndexName.ToLower());
                        return index.stocksList.Exists(x => x.StockName.ToLower() == inStockName.ToLower());
                    }
                    else
                    {
                        throw new StockExchangeException("Ne postoji dionica!");
                    }
                }
                else
                {
                    throw new StockExchangeException("Ne postoji index!");
                }
            }

            public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
            {
                if (IndexExists(inIndexName))
                {
                    Index index = indexList.Find(x => x.IndexName.ToLower() == inIndexName.ToLower());
                    return index.GetValue(inTimeStamp);
                }
                else
                {
                    throw new StockExchangeException("ne postoji zadani index");
                }
            }

            public bool IndexExists(string inIndexName)
            {
                return indexList.Exists(x => x.IndexName.ToLower() == inIndexName.ToLower());
            }

            public int NumberOfIndices()
            {
                return indexList.Count();
            }

            public int NumberOfStocksInIndex(string inIndexName)
            {
                if (IndexExists(inIndexName))
                {
                    Index index = indexList.Find(x => x.IndexName.ToLower() == inIndexName.ToLower());
                    return index.stocksList.Count();
                }
                else
                {
                    throw new StockExchangeException("ne postoji zadani index");
                }
            }
            #endregion

            public void CreatePortfolio(string inPortfolioID)
            {
                if (PortfolioExists(inPortfolioID))
                {
                    throw new StockExchangeException("Portfolio vec postoji!");
                }
                else
                {
                    portfolioList.Add(new Portfolio(inPortfolioID));
                }
            }

            //treba dovrsit
            public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
            {
                if (StockExists(inStockName) == false)
                {
                    throw new StockExchangeException("Ne postoji dionica");
                }

                if (PortfolioExists(inPortfolioID) == false)
                {
                    throw new StockExchangeException("Ne postoji portfolio");
                }

                //provjera za broj shareova dionice
                //ako vec postoji dionica u portfoliu treba samo povecat broj
                //Stock stock = stocksList.Find(s => s.StockName.ToLower() == inStockName.ToLower());

                Stock stock = GetStock(inStockName);
                long totalStockNumber=0;
                long maxStockNumber = stock.NumberOfShares;

                foreach (Portfolio portfolio in portfolioList)
                {
                    if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                    {
                        totalStockNumber += portfolio.GetNumberOfShares(stock);
                        //zbrajamo ukupan broj dionice u portfeljima?
                    }
                }

                if (totalStockNumber + numberOfShares > maxStockNumber)
                {
                    throw  new StockExchangeException("Ne postoji toliko dionica");
                }

                Portfolio p = GetPortfolio(inPortfolioID);
                
                //2 slucaja za dodavanje
                //dionica vec postoji u portfelja
                //treba dodati dionicu u portfelju
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    p.stocks[stock] += numberOfShares;
                }
                else
                {
                    p.AddStock(stock,numberOfShares);
                }

                //ako je broj dionica 0 treba ju izbaciti
                if (p.GetNumberOfShares(stock) == 0)
                {
                    p.RemoveStock(stock);
                }

            }

            public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
            {
                if (StockExists(inStockName) == false)
                {
                    throw new StockExchangeException("Ne postoji dionica");
                }

                if (PortfolioExists(inPortfolioID) == false)
                {
                    throw new StockExchangeException("Ne postoji portfolio");
                }

                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                   
                    Stock stock = GetStock(inStockName);
                    long totalStockNumber = 0;
                    long maxStockNumber = stock.NumberOfShares;

                    foreach (Portfolio portfolio in portfolioList)
                    {
                        if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                        {
                            totalStockNumber += portfolio.GetNumberOfShares(stock);
                        }
                    }

                    if (totalStockNumber - numberOfShares < 0)
                    {
                        throw new StockExchangeException("Ne postoji toliko dionica");
                    }

                    Portfolio p = GetPortfolio(inPortfolioID);
                    p.RemoveStock(stock,numberOfShares);

                    //ako je broj dionica 0 treba ju izbaciti
                    if (p.GetNumberOfShares(stock) == 0)
                    {
                        p.RemoveStock(stock);
                    }
                }
                else
                {
                    throw new StockExchangeException("dionica ne postoji u portfelju");
                }
            }

            public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
            {
                if (StockExists(inStockName) == false)
                {
                    throw new StockExchangeException("Ne postoji dionica");
                }

                if (PortfolioExists(inPortfolioID) == false)
                {
                    throw new StockExchangeException("Ne postoji portfolio");
                }

                if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    Portfolio portfolio = GetPortfolio(inPortfolioID);
                    Stock stock = GetStock(inStockName);
                    portfolio.RemoveStock(stock);
                }

            }

            public int NumberOfPortfolios()
            {
                return portfolioList.Count();
            }

            public int NumberOfStocksInPortfolio(string inPortfolioID)
            {
                if (PortfolioExists(inPortfolioID))
                {
                    Portfolio portfolio = GetPortfolio(inPortfolioID);
                    return portfolio.stocks.Count();
                }
                else
                {
                    throw new StockExchangeException("ne postoji portfolio");
                }
            }

            public bool PortfolioExists(string inPortfolioID)
            {
                return portfolioList.Exists(x => x.PortfolioID == inPortfolioID);
            }

            public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
            {
                if (PortfolioExists(inPortfolioID) == false)
                {
                    throw new StockExchangeException("ne postoji portfolio!");
                }
                if (StockExists(inStockName) == false)
                {
                    throw new StockExchangeException("ne postoji dionica!");
                }
                
                Portfolio portfolio = GetPortfolio(inPortfolioID);
                Stock stock = GetStock(inStockName);

                if (portfolio.stocks.ContainsKey(stock))
                {
                    return true;
                }
                return false;
            }

            public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
            {
                if (StockExists(inStockName) == false)
                {
                    throw new StockExchangeException("ne postoji dionica");
                }

                if (PortfolioExists(inPortfolioID))
                {
                    //Portfolio portfolio = portfolioList.Find(x => x.PortfolioID == inPortfolioID);
                    Portfolio portfolio = GetPortfolio(inPortfolioID);
                    //Stock stock = stocksList.Find(x => x.StockName.ToLower() == inStockName.ToLower());
                    Stock stock = GetStock(inStockName);

                    if (portfolio.stocks.Keys.Contains(stock))
                    {
                        return Convert.ToInt32(portfolio.stocks[stock]);
                    }
                    else
                    {
                        return 0;
                    }

                }
                else
                {
                    throw new StockExchangeException("ne postoji portfolio");
                }
            }

            public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
            {
                if (PortfolioExists(inPortfolioID))
                {
                    Portfolio portfolio = GetPortfolio(inPortfolioID);
                    return portfolio.GetValue(timeStamp);
                }
                else
                {
                    throw new StockExchangeException("ne postoji portfolio!");
                }
            }

            public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
            {
                if (PortfolioExists(inPortfolioID))
                {
                    //vrijednosti portfelja za prvi i zadnji dan u mjesecu
                    decimal firstDayValue;
                    decimal lastDayValue;
                    int lastDayOfMonth = new DateTime(Year, Month, 1).AddMonths(1).AddDays(-1).Day;

                    DateTime startDate=new DateTime(Year,Month,1,0,0,0);
                    DateTime endDate = new DateTime(Year, Month,lastDayOfMonth , 23, 59, 59,999);

                    Portfolio portfolio = GetPortfolio(inPortfolioID);
                    firstDayValue = portfolio.GetValue(startDate);
                    lastDayValue = portfolio.GetValue(endDate);

                    decimal result = ((lastDayValue - firstDayValue)/(firstDayValue))*100;

                    return Math.Round(result, 3);
                }
                else
                {
                    throw new StockExchangeException("ne postoji portfolio");
                }
            }
            //
            private Stock GetStock(string inStockName)
            {
                Stock stock = null;
                if (StockExists(inStockName))
                {
                   stock = stocksList.Find(x => x.StockName.ToLower() == inStockName.ToLower());
                }
                return stock;
            }

            private Portfolio GetPortfolio(string inPortfolioID)
            {
                return portfolioList.Find(x => x.PortfolioID == inPortfolioID);
            }
        }


}
