﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string stockName;
        private long numberOfShares;
        private decimal initialPrice;
        private DateTime timeStamp;
        private Dictionary<DateTime, Decimal> stockValue;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName == null)
                throw new StockExchangeException("Null");
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Null");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Null");
            if (inTimeStamp == null)
                throw new StockExchangeException("Null");

            this.stockName = inStockName;
            this.numberOfShares = inNumberOfShares;
            this.stockValue = new Dictionary<DateTime,decimal>();
            this.stockValue.Add(inTimeStamp, inInitialPrice);
            this.initialPrice = inInitialPrice;
            this.timeStamp = inTimeStamp;
        }

        public void setStockName(string inStockName)
        {
            if (inStockName == null)
                throw new StockExchangeException("Null");

            this.stockName = inStockName;
        }

        public void setNumberOfShares(long inNumberOfShares)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Null");

            this.numberOfShares = inNumberOfShares;
        }

        public void addStockValue(decimal inStockValue, DateTime inTimeStamp)
        {
            if (inStockValue <= 0)
                throw new StockExchangeException("Null");
            if (inTimeStamp == null)
                throw new StockExchangeException("Null");

            this.stockValue.Add(inTimeStamp, inStockValue);
            this.timeStamp = inTimeStamp;
        }

        public string getStockName()
        {
            return this.stockName;
        }

        public long getNumberOfShares()
        {
            return this.numberOfShares;
        }

        // Return last by default
        public decimal getStockValue()
        {
            return this.stockValue[this.timeStamp];
        }

        public decimal getStockValue(DateTime inTimeStamp)
        {
            if (inTimeStamp == null)
                throw new StockExchangeException("Null");

            List<DateTime> keys = this.stockValue.Keys.ToList();
            keys.Sort();
            DateTime last = DateTime.Now;

            if (inTimeStamp < keys[0])
                throw new StockExchangeException("Improssibru");

            foreach(DateTime ts in keys) {
                if(ts < inTimeStamp)
                    last = ts;
            }

            if (this.stockValue.ContainsKey(last))
                 return this.stockValue[last];
            else
                return this.getStockValue();

        }

        public decimal getInitialPrice()
        {
            return this.initialPrice;
        }

        public DateTime getTimeStamp()
        {
            return this.timeStamp;
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Stock)) return false;

            Stock s = (Stock) obj;
            return this.stockName.ToUpper().Equals(s.getStockName().ToUpper());
        }

        public override int GetHashCode()
        {
            return this.stockName.ToUpper().GetHashCode();
        }
    }

    public class Index
    {
        string indexName;
        IndexTypes indexType;
        List<Stock> stockList;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
                throw new StockExchangeException("Null");
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Not a valid indexType");

            this.indexName = inIndexName;
            this.indexType = inIndexType;
            this.stockList = new List<Stock>();
        }

        public string getIndexName()
        {
            return this.indexName;
        }

        public IndexTypes getIndexType()
        {
            return this.indexType;
        }

        public void setIndexName(string inIndexName)
        {
            if (inIndexName == null)
                throw new StockExchangeException("Null");

            this.indexName = inIndexName;
        }

        public bool containsStock(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            return this.stockList.Contains(inStock);
        }

        public void addStockToIndex(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            if (!this.containsStock(inStock))
            {
                this.stockList.Add(inStock);
            }
            else
            {
                throw new StockExchangeException("Same stock in index");
            }
        }

        public void removeStockFromIndex(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            if (this.containsStock(inStock))
            {
                this.stockList.Remove(inStock);
            }
            else
            {
                throw new StockExchangeException("Same stock in index");
            }
        }

        public void setIndexType(IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE || inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Not a valid indexType");

            this.indexType = inIndexType;
        }

        public int getNumberOfStocks()
        {
            return this.stockList.Count;
        }

        public decimal getValueOfIndex(DateTime inTimeStamp)
        {
            if (this.indexType == IndexTypes.AVERAGE)
                return this.indexValueAverage(inTimeStamp);
            else if (this.indexType == IndexTypes.WEIGHTED)
                return this.indexValueWeighted(inTimeStamp);
            else
                throw new StockExchangeException("No such index type");
        }

        private decimal indexValueWeighted(DateTime inTimeStamp)
        {
            decimal allStocksValue = 0;
            decimal stockFactor = 0;
            decimal sumFactors = 0;
            decimal value = 0;

            foreach (Stock s in this.stockList)
                allStocksValue += s.getStockValue(inTimeStamp);

            foreach (Stock s in this.stockList)
            {
                stockFactor = (s.getStockValue(inTimeStamp) * s.getNumberOfShares()) / allStocksValue;
                sumFactors += stockFactor;
                value += s.getStockValue(inTimeStamp) * stockFactor;
            }

            return decimal.Round(value / sumFactors, 3, MidpointRounding.AwayFromZero);
        }

        private decimal indexValueAverage(DateTime inTimeStamp)
        {
            decimal value = 0;

            foreach (Stock s in this.stockList)
                value += s.getStockValue(inTimeStamp);

            return decimal.Round(value / this.stockList.Count(), 3, MidpointRounding.AwayFromZero);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Index)) return false;

            Index i = (Index)obj;
            return this.indexName.ToUpper().Equals(i.getIndexName().ToUpper());
        }

        public override int GetHashCode()
        {
            return this.indexName.ToUpper().GetHashCode();
        }

    }

    public class Portfolio
    {
        private string portfolioID;
        private List<Stock> stockList;

        public Portfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
                throw new StockExchangeException("Null");

            this.portfolioID = inPortfolioID;
            this.stockList = new List<Stock>();
        }

        public void setPortfolioID(string inPortfolioID)
        {
            if (inPortfolioID == null)
                throw new StockExchangeException("Null");

            this.portfolioID = inPortfolioID;
        }

        public string getPortfolioID()
        {
            return this.portfolioID;
        }

        public int getNumberOfStocks()
        {
            return this.stockList.Count;
        }

        public int getNumberOfSharesOfStock(Stock inStock)
        {
            if (!this.containsStock(inStock))
                throw new StockExchangeException("No such stock in portfolio");

            int ind = this.stockList.IndexOf(inStock);
            return (int)this.stockList.ElementAt(ind).getNumberOfShares();
        }

        public bool containsStock(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            return this.stockList.Contains(inStock);
        }

        public void addStockToPortfolio(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            if (!this.containsStock(inStock))
            {
                this.stockList.Add(inStock);
            }
            else
            {
                int index = this.stockList.IndexOf(inStock);
                Stock stored = this.stockList.ElementAt(index);
                stored.setNumberOfShares(inStock.getNumberOfShares() + stored.getNumberOfShares());
            }
        }

        public void removeStockFromPortfolio(Stock inStock)
        {
            if (inStock == null)
                throw new StockExchangeException("Null");

            if (this.containsStock(inStock))
            {
                this.stockList.Remove(inStock);
            }
            else
            {
                throw new StockExchangeException("Stock doesn't exist");
            }
        }

        public decimal getPortfolioValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (Stock s in this.stockList)
                sum = s.getNumberOfShares() * s.getStockValue();

            return decimal.Round(sum, 3, MidpointRounding.AwayFromZero);
        }

        public decimal getPortfolioPercentageChangeInMonth(DateTime inStartTimeStamp, DateTime inStopTimeStamp)
        {
            decimal sumStart = 0, sumEnd = 0, diff = 0, percentage = 0;

            foreach (Stock s in this.stockList)
                sumStart = s.getNumberOfShares() * s.getStockValue(inStartTimeStamp);

            foreach (Stock s in this.stockList)
                sumEnd = s.getNumberOfShares() * s.getStockValue(inStopTimeStamp);

            diff = sumEnd - sumStart;

            percentage = (diff * 100) / sumStart;

            return decimal.Round(percentage, 3, MidpointRounding.AwayFromZero);
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Portfolio)) return false;

            Portfolio i = (Portfolio)obj;
            return this.portfolioID.Equals(i.getPortfolioID());
        }

        public override int GetHashCode()
        {
            return this.portfolioID.GetHashCode();
        }

    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stockList = new List<Stock>();
        private List<Index> indexList = new List<Index>();
        private List<Portfolio> portfolioList = new List<Portfolio>();
        private Dictionary<Stock, int> stockShares = new Dictionary<Stock, int>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (this.StockExists(inStockName))
                throw new StockExchangeException("Exists");

            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            this.stockList.Add(newStock);
            this.stockShares.Add(newStock, (int)inNumberOfShares);
        }

        public void DelistStock(string inStockName)
        {
            if (!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            this.stockList.Remove(new Stock(inStockName, 1, 1, DateTime.Now));
            this.stockShares.Remove(new Stock(inStockName, 1, 1, DateTime.Now));
        }

        public bool StockExists(string inStockName)
        {
            if (this.stockList.Count == 0)
                return false;

            return this.stockList.Contains(new Stock(inStockName, 1, 1, DateTime.Now));
        }

        public int NumberOfStocks()
        {
            return this.stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (this.StockExists(inStockName))
            {
                int index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
                Stock stock = this.stockList.ElementAt(index);
                stock.addStockValue(inStockValue, inIimeStamp);
            }
            else
            {
                throw new StockExchangeException("No such element");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (this.StockExists(inStockName))
            {
                int index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
                Stock stock = this.stockList.ElementAt(index);
                return stock.getStockValue(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("No such element");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                int index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
                Stock stock = this.stockList.ElementAt(index);
                return stock.getInitialPrice();
            }
            else
            {
                throw new StockExchangeException("No such element");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (this.StockExists(inStockName))
            {
                int index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
                Stock stock = this.stockList.ElementAt(index);
                return stock.getStockValue();
            }
            else
            {
                throw new StockExchangeException("No such element");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (this.IndexExists(inIndexName))
                throw new StockExchangeException("Exists");

            this.indexList.Add(new Index(inIndexName, inIndexType));

        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if(!this.IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist");
            if(!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            int index = this.indexList.IndexOf(new Index(inIndexName, IndexTypes.AVERAGE));
            Index i = this.indexList.ElementAt(index);

            index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(index);

            i.addStockToIndex(s);

        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!this.IsStockPartOfIndex(inIndexName, inStockName))
                throw new StockExchangeException("Stock not in index");

            int index = this.indexList.IndexOf(new Index(inIndexName, IndexTypes.AVERAGE));
            Index i = this.indexList.ElementAt(index);

            index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(index);

            i.removeStockFromIndex(s);

        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!this.IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist");
            if (!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            int index = this.indexList.IndexOf(new Index(inIndexName, IndexTypes.AVERAGE));
            Index i = this.indexList.ElementAt(index);

            index = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(index);

            return i.containsStock(s);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!this.IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist");

            int index = this.indexList.IndexOf(new Index(inIndexName, IndexTypes.AVERAGE));
            Index i = this.indexList.ElementAt(index);

            return i.getValueOfIndex(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            if (this.indexList.Count == 0)
                return false;

            return this.indexList.Contains(new Index(inIndexName, IndexTypes.AVERAGE));
        }

        public int NumberOfIndices()
        {
            return this.indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!this.IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist");

            int index = this.indexList.IndexOf(new Index(inIndexName, IndexTypes.AVERAGE));
            Index i = this.indexList.ElementAt(index);

            return i.getNumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Exists");

            this.portfolioList.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if(!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");
            if (!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");
            if (numberOfShares <= 0)
                throw new StockExchangeException("More than 0");

            int ind = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(ind);

            int numShares = this.stockShares[s];

            if (numShares < numberOfShares)
                throw new StockExchangeException("Not enough shares");

            numShares -= numberOfShares;
            this.stockShares.Remove(s);
            this.stockShares.Add(s, numShares);

            Stock newStock = new Stock(s.getStockName(), (long)numberOfShares, s.getStockValue(), s.getTimeStamp());

            ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            Portfolio p = this.portfolioList.ElementAt(ind);

            p.addStockToPortfolio(newStock);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");
            if (!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");
            if (numberOfShares <= 0)
                throw new StockExchangeException("More than 0");

            int ind = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(ind);

            ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            Portfolio p = this.portfolioList.ElementAt(ind);

            int numShr = p.getNumberOfSharesOfStock(s);
            int currNumShr = this.stockShares[s];
            this.stockShares.Remove(s);
            this.stockShares.Add(s, currNumShr + numberOfShares);

            p.removeStockFromPortfolio(s);

            if(numberOfShares > numShr)
                throw new StockExchangeException("More");
            else if(numberOfShares < numShr) {
                Stock newStock = new Stock(s.getStockName(), (long)(numShr - numberOfShares), s.getStockValue(), s.getTimeStamp());
                p.addStockToPortfolio(newStock);
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");
            if (!this.StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            int ind = this.stockList.IndexOf(new Stock(inStockName, 1, 1, DateTime.Now));
            Stock s = this.stockList.ElementAt(ind);

            ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            Portfolio p = this.portfolioList.ElementAt(ind);

            int numShr = p.getNumberOfSharesOfStock(s);
            int currNumShr = this.stockShares[s];
            this.stockShares.Remove(s);
            this.stockShares.Add(s, numShr + currNumShr);

            p.removeStockFromPortfolio(s);

        }

        public int NumberOfPortfolios()
        {
            return this.portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if(!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");

            int ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            return this.portfolioList.ElementAt(ind).getNumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (this.portfolioList.Count == 0)
                return false;

            return this.portfolioList.Contains(new Portfolio(inPortfolioID));
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if(!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");

            int ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            return this.portfolioList.ElementAt(ind).containsStock(new Stock(inStockName, 1, 1, DateTime.Now));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");

            int ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            return this.portfolioList.ElementAt(ind).getNumberOfSharesOfStock(new Stock(inStockName, 1, 1, DateTime.Now));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");

            int ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));
            return this.portfolioList.ElementAt(ind).getPortfolioValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!this.PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist");
            if (Year <= 0)
                throw new StockExchangeException("Year");
            if(Month <= 0 || Month > 12)
                throw new StockExchangeException("Month");

            int ind = this.portfolioList.IndexOf(new Portfolio(inPortfolioID));

            DateTime timeStampStart = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime timeStampStop = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            return this.portfolioList.ElementAt(ind).getPortfolioPercentageChangeInMonth(timeStampStart, timeStampStop);
        }
    }
}
