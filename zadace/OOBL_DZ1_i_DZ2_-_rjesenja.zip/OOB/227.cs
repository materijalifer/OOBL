﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        bool isMemoryEmpty;
        private double memory;

        bool isLastOperator;
        private char lastOperator;

        private string displayState;
        private double currentResult;

        bool isFirstNumber;

        private char specialChar = ',';

        public Kalkulator()
        {
            this.isMemoryEmpty = true;
            this.isLastOperator = false;
            this.lastOperator = '!';
            this.displayState = "0";
            this.currentResult = 0;

            isFirstNumber = true;

            //Thread.CurrentThread.CurrentCulture = new CultureInfo("hr-HR");
            CultureInfo c = Thread.CurrentThread.CurrentCulture;
            if (c.Name != "hr-HR")
            {
                this.specialChar = '.';
            }
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                switch (inPressedDigit)
                {
                    case 'G':
                        getFromMemory();
                        break;
                    case 'P':
                        putInMemory();
                        break;
                    case 'C':
                        clearScreen();
                        break;
                    case 'O':
                        reset();
                        break;
                    case 'I':
                        unarOper('I');
                        break;
                    case 'R':
                        unarOper('R');
                        break;
                    case 'Q':
                        unarOper('Q');
                        break;
                    case 'T':
                        unarOper('T');
                        break;
                    case 'K':
                        unarOper('K');
                        break;
                    case 'S':
                        unarOper('S');
                        break;
                    case 'M':
                        changeSign();
                        break;
                    case ',':
                        insertComa();
                        break;
                    case '+':
                        binaryOperator('+');
                        break;
                    case '-':
                        binaryOperator('-');
                        break;
                    case '*':
                        binaryOperator('*');
                        break;
                    case '/':
                        binaryOperator('/');
                        break;
                    case '=':
                        calculate();
                        break;
                    case '1':
                        insertNumber('1');
                        break;
                    case '2':
                        insertNumber('2');
                        break;
                    case '3':
                        insertNumber('3');
                        break;
                    case '4':
                        insertNumber('4');
                        break;
                    case '5':
                        insertNumber('5');
                        break;
                    case '6':
                        insertNumber('6');
                        break;
                    case '7':
                        insertNumber('7');
                        break;
                    case '8':
                        insertNumber('8');
                        break;
                    case '9':
                        insertNumber('9');
                        break;
                    case '0':
                        insertNumber('0');
                        break;

                }
            }
            catch (Exception)
            {
                this.displayState = "-E-";
            }
        }

        private void binaryOperator(char p)
        {
            if (isLastOperator)
            {
                this.lastOperator = p;
            }
            else if (this.lastOperator == '!')
            {
                this.lastOperator = p;
                this.isLastOperator = true;
            }
            else
            {
                isLastOperator = true;
                currentResult = doOperation(currentResult, Double.Parse(this.displayState), this.lastOperator);

                this.lastOperator = p;

                this.displayState = currentResult.ToString();
                makePretty();
            }
            this.isFirstNumber = true;
            this.currentResult = Double.Parse(this.displayState);
            this.displayState = currentResult.ToString();
        }

        private double doOperation(double currentResult, double p, char p_2)
        {
            double result = 0;
            switch (p_2)
            {
                case '+':
                    result = currentResult + p;
                    break;
                case '-':
                    result = currentResult - p;
                    break;
                case '*':
                    result = currentResult * p;
                    break;
                case '/':
                    result = currentResult / p;
                    break;
            }
            return result;
        }

        private void unarOper(char p)
        {
            switch (p)
            {
                case 'I':
                    inverse();
                    break;
                case 'R':
                    squareRoot();
                    break;
                case 'Q':
                    squaring();
                    break;
                case 'T':
                    tangent();
                    break;
                case 'K':
                    cosine();
                    break;
                case 'S':
                    sine();
                    break;
            }
        }

        #region unar operation

        private void sine()
        {
            this.displayState = Math.Sin(Double.Parse(this.displayState)).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void cosine()
        {
            this.displayState = Math.Cos(Double.Parse(this.displayState)).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void tangent()
        {
            this.displayState = Math.Tan(Double.Parse(this.displayState)).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void squaring()
        {
            this.displayState = Math.Pow(Double.Parse(this.displayState), 2).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void squareRoot()
        {
            this.displayState = Math.Sqrt(Double.Parse(this.displayState)).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void inverse()
        {
            this.displayState = ((double)1 / Double.Parse(this.displayState)).ToString();
            makePretty();
            this.isFirstNumber = true;
        }

        private void makePretty()
        {
            if (this.displayState == "Infinity" || this.displayState == "NaN")
            {
                throw new Exception();
            }
            
            string newScreen = "";
            if (this.displayState[0] == '-')
            {
                newScreen = "-";
                this.displayState = this.displayState.Substring(1, this.displayState.Length - 1);
            }
            
            if (this.displayState.Length <= 10)
            {
                newScreen = newScreen + this.displayState;
            }
            else if (this.displayState.Substring(0, 10).Contains(specialChar))
            {
                //newScreen = newScreen + this.displayState.Substring(0, 11);

                Double current = Double.Parse(this.displayState);
                int index = this.displayState.IndexOf(specialChar);
                current = Math.Round(current, (10-index));

                newScreen = newScreen + current.ToString();
            }
            else if (this.displayState[10] == specialChar)
            {
                newScreen = newScreen + this.displayState.Substring(0, 10);
            }
            else
            {
                throw new Exception();
            }
            double help = Double.Parse(newScreen);
            this.displayState = help.ToString();
            
            

        }

        #endregion

        private void changeSign()
        {
            if (this.displayState.Equals("0"))
            {
                return;
            }
            else if (this.displayState[0] == '-')
            {
                this.displayState = this.displayState.Substring(1, this.displayState.Length - 1);
            }
            else
            {
                this.displayState = "-" + this.displayState;
            }
        }

        private void insertComa()
        {
            if (this.displayState.Contains(specialChar))
            {
                return;
            }
            else
            {
                this.displayState = this.displayState + specialChar;
            }
        }

        private void insertNumber(char p)
        {
            if (this.isFirstNumber == true)
            {
                this.isFirstNumber = false;
                if (this.displayState == "0" + specialChar)
                {
                    this.displayState = this.displayState + p;
                }
                else
                {
                    this.displayState = "" + p;
                }
            }
            else if ((this.displayState[0] == '-' && this.displayState.Length <= 11 && this.displayState.Contains(specialChar))
                || (this.displayState[0] == '-' && this.displayState.Length <= 10 && !this.displayState.Contains(specialChar))
                || (this.displayState[0] != '-' && displayState.Length <= 11 && this.displayState.Contains(specialChar))
                || (this.displayState[0] != '-' && displayState.Length <= 9 && !this.displayState.Contains(specialChar)))
            {
                this.displayState = this.displayState + p;
            }
            else
            {
                return;
            }
            this.isLastOperator = false;
            makePretty();
        }

        private void calculate()
        {
            if (this.isLastOperator)
            {
                this.isLastOperator = false;

                this.currentResult = doOperation(this.currentResult, this.currentResult, this.lastOperator);
                this.displayState = this.currentResult.ToString();
                makePretty();
                this.currentResult = Double.Parse(this.displayState);
                this.displayState = this.currentResult.ToString();

                this.lastOperator = '!';
            }
            else if (this.lastOperator == '!')
            {
                makePretty();
            }
            else
            {
                this.isLastOperator = false;

                this.currentResult = doOperation(this.currentResult, Double.Parse(this.displayState), this.lastOperator);
                this.displayState = this.currentResult.ToString();
                makePretty();
                this.currentResult = Double.Parse(this.displayState);
                this.displayState = this.currentResult.ToString();

                this.lastOperator = '!';
            }
            this.isFirstNumber = true;
        }

        private void reset()
        {
            this.isMemoryEmpty = true;
            this.isLastOperator = false;
            this.displayState = "0";
            this.currentResult = 0;
        }

        private void clearScreen()
        {
            this.displayState = "0";
        }

        private void putInMemory()
        {
            this.isMemoryEmpty = false;
            this.memory = Double.Parse(this.displayState);
        }

        private void getFromMemory()
        {
            if (this.isMemoryEmpty == true)
            {
                throw new Exception();
            }
            else
            {
                this.displayState = memory.ToString();
            }

        }

        public string GetCurrentDisplayState()
        {

            return this.displayState.Replace('.', ',');
        }

        public void Ispis(char pressed)
        {
            Console.WriteLine("I pressed: " + pressed);
            Console.WriteLine("is memory empty: " + this.isMemoryEmpty);
            Console.WriteLine("is last operator " + this.isLastOperator);
            Console.WriteLine("display state: " + this.displayState);
            Console.WriteLine("memory: " + this.memory);
            Console.WriteLine("last operator: " + this.lastOperator);
            Console.WriteLine("trenutno stanje ekrana je: " + this.GetCurrentDisplayState());
            Console.WriteLine("------------------------------------");
        }
    }


}
