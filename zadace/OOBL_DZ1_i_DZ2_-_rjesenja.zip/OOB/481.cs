﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {
        private iStates currentState;
        private string displayState = "";
        private string memory;

        private char[] binOper = { '+', '-', '/', '*' };
        private char[] unOper = { 'S', 'K', 'I', 'Q', 'R', 'T', 'M', 'O', 'P', 'G', 'C' };
        private char[] number = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };

        public Kalkulator()
        {
            displayState = "0";
            currentState = new initialState();
        }


        public void setState(iStates stanje)
        {
            currentState = stanje;
        }
        public char[] getBinOper()
        {
            return binOper;
        }
        public char[] getUnOper()
        {
            return unOper;
        }
        public char[] getNumber()
        {
            return number;
        }
        public void Press(char inPressedDigit)
        {
            currentState.handleInput(this, inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        public void setDisplay(string number)
        {
            displayState = number;
        }

        public void setMemory(string toSave)
        {
            memory = toSave;
        }

        public string getMemory()
        {
            return memory;
        }

        public string solveUnOper(char oper, string number)
        {
            double a = Convert.ToDouble(number);
            double result;
            switch (oper)
            {
                case 'Q':
                    result = a * a;
                    break;
                case 'M':
                    result = a * -1;
                    break;
                case 'S':
                    result = Math.Round(Math.Sin(a), 9);
                    break;
                case 'K':
                    result = Math.Round(Math.Cos(a), 9);
                    break;
                case 'T':
                    result = Math.Round(Math.Tan(a), 9);
                    break;
                case 'R':
                    result = Math.Sqrt(a);
                    break;
                case 'I':
                    if (a == 0)
                    {
                        return "-E-";
                    }
                    else
                    {
                        result = 1 / a;
                        break;
                    }
                case 'P':
                    setMemory(a.ToString());
                    result = a;
                    break;
                case 'G':
                    result = Convert.ToDouble(getMemory());
                    break;
                case 'C':
                    return "";

                default:
                    return a.ToString();


            }
            string res = validResult(result.ToString());
            return res;
        }

        public string solveBinOper(char oper, string number1, string number2)
        {
            double a = Convert.ToDouble(number1);
            double b = Convert.ToDouble(number2);
            double result;
            switch (oper)
            {
                case '+':
                    result = a + b;
                    break;
                case '-':
                    result = a - b;
                    break;
                case '*':
                    result = a * b;
                    break;
                case '/':
                    if (b == 0)
                    {
                        return "-E-";
                    }
                    else
                    {
                        result = a / b;
                        break;
                    }
                default:
                    return a.ToString();
            }
            string res = validResult(result.ToString());
            return res;
        }

        public string validResult(string number)
        {

            int specOpers = 0;
            if (number.Contains(","))
            {
                specOpers++;
            }
            if (number.Contains("-"))
            {
                specOpers++;
            }

            if (number.Length < 10 + specOpers)
            {
                return number.ToString();
            }
            else if (number.Length > 10 && !number.Contains(","))
                return "-E-";
            else
            {
                int i = number.IndexOf(',');
                if (i > 10 + specOpers)
                    return "-E-";
                else
                {
                    number = number.Substring(0, 10 + specOpers);
                    return number;
                }

            }
        }
    }

    public interface iStates
    {
        void handleInput(Kalkulator calc, char input);
    }

    class initialState : iStates
    {

        public void handleInput(Kalkulator calc, char input)
        {
            if (calc.getBinOper().Contains(input))
            {
                calc.setState(new operationInProgressState("0", input));
            }
            else if (calc.getUnOper().Contains(input))
            {
                if (input == 'O')
                {
                    calc.setDisplay("0");
                    calc.setState(new initialState());
                }
                else
                {
                    string result = calc.solveUnOper(input, "0");
                    if (result != "-E-")
                    {
                        calc.setDisplay(result);
                        calc.setState(new digitState(result));
                    }
                    else
                    {
                        calc.setDisplay("-E-");
                        calc.setState(new errorState());
                    }
                }
            }
            else if (calc.getNumber().Contains(input) || input == ',')
            {
                if (input == '0')
                {
                    calc.setDisplay(input.ToString());
                    calc.setState(new initialState());
                }
                else if (input == ',')
                {
                    calc.setState(new digitState("0" + input.ToString()));
                }

                else
                {
                    calc.setDisplay(input.ToString());
                    calc.setState(new digitState(input.ToString()));
                }
            }

            else if (input == '=')
            {
                calc.setDisplay("0");

            }
        }
    }


    class digitState : iStates
    {
        private string number;
        public digitState(string number)
        {
            this.number = number;
        }

        public void handleInput(Kalkulator calc, char input)
        {
            if (calc.getBinOper().Contains(input))
            {
                if (Convert.ToDouble(number) % 1 == 0)
                {
                    number = Math.Floor(Convert.ToDouble(number)).ToString();
                    calc.setDisplay(number);
                }
                calc.setState(new operationInProgressState(number, input));
            }
            else if (calc.getUnOper().Contains(input))
            {
                if (input == 'O')
                {
                    calc.setDisplay("0");
                    calc.setState(new initialState());
                }
                else
                {
                    string result = calc.solveUnOper(input, number);
                    if (result != "-E-")
                    {
                        calc.setDisplay(result);
                        calc.setState(new digitState(result));
                    }
                    else
                    {
                        calc.setDisplay("-E-");
                        calc.setState(new errorState());
                    }
                }
            }
            else if (calc.getNumber().Contains(input) || input == ',')
            {

                string result = calc.validResult(number + input);
                if (result != "-E-")
                {
                    //string result = num + input;
                    calc.setDisplay(result);
                    calc.setState(new digitState(result));
                }
                else
                {
                    calc.setDisplay("-E-");
                    calc.setState(new errorState());
                }

            }
            else if (input == '=')
            {
                if (Convert.ToDouble(number) % 1 == 0)
                {
                    number = Math.Floor(Convert.ToDouble(number)).ToString();
                    calc.setDisplay(number);
                }
                else
                    calc.setDisplay(number);
            }
        }
    }


    class operationInProgressState : iStates
    {
        string operand1;
        char binOperator;
        public operationInProgressState(string oper1, char binOper)
        {
            operand1 = oper1;
            binOperator = binOper;
        }

        public void handleInput(Kalkulator calc, char input)
        {
            if (calc.getBinOper().Contains(input))
            {
                calc.setState(new operationInProgressState(operand1, input));
            }
            else if (calc.getUnOper().Contains(input))
            {
                if (input == 'O')
                {
                    calc.setDisplay("0");
                    calc.setState(new initialState());
                }
                else
                {
                    string result = calc.solveUnOper(input, operand1);
                    if (result != "-E-")
                    {
                        calc.setDisplay(result);
                        calc.setState(new operationInProgressState(operand1, binOperator));
                    }
                    else
                    {
                        calc.setDisplay("-E-");
                        calc.setState(new errorState());
                    }
                }
            }
            else if (calc.getNumber().Contains(input))
            {
                calc.setDisplay(input.ToString());
                calc.setState(new operationCompletedState(operand1, input.ToString(), binOperator));
            }
            else if (input == '=')
            {

                string result = calc.solveBinOper(binOperator, operand1, operand1);
                if (result != "-E-")
                {
                    calc.setDisplay(result);
                    calc.setState(new digitState(result));
                }
                else
                {
                    calc.setDisplay("-E-");
                    calc.setState(new errorState());
                }

            }
        }
    }

    class operationCompletedState : iStates
    {
        private string operand1;
        private string operand2;
        private char binOperator;
        public operationCompletedState(string num1, string num2, char oper)
        {
            operand1 = num1;
            operand2 = num2;
            binOperator = oper;
        }

        public void handleInput(Kalkulator calc, char input)
        {
            if (calc.getBinOper().Contains(input))
            {
                string result = calc.solveBinOper(binOperator, operand1, operand2);
                if (result != "-E-")
                {
                    calc.setDisplay(result);
                    calc.setState(new operationInProgressState(result, input));
                }
                else
                {
                    calc.setDisplay("-E-");
                    calc.setState(new errorState());
                }
            }
            else if (calc.getUnOper().Contains(input))
            {
                if (input == 'O')
                {
                    calc.setDisplay("0");
                    calc.setState(new initialState());
                }
                else
                {
                    string result = calc.solveUnOper(input, operand2);
                    if (result != "-E-")
                    {
                        calc.setDisplay(result);
                        calc.setState(new operationCompletedState(operand1, result, binOperator));
                    }
                    else
                    {
                        calc.setDisplay("-E-");
                        calc.setState(new errorState());
                    }

                }
            }
            else if (calc.getNumber().Contains(input) || input == ',')
            {
                string result = calc.validResult(operand2 + input);
                if (result != "-E-")
                {
                    calc.setDisplay(result);
                    calc.setState(new operationCompletedState(operand1, result, binOperator));
                }
                else
                {
                    calc.setDisplay("-E-");
                    calc.setState(new errorState());
                }


            }
            else if (input == '=')
            {

                string result = calc.solveBinOper(binOperator, operand1, operand2);
                if (result != "-E-")
                {
                    calc.setDisplay(result);
                    calc.setState(new digitState(result));
                }
                else
                {
                    calc.setDisplay("-E-");
                    calc.setState(new errorState());
                }

            }
        }
    }

    class errorState : iStates
    {
        public errorState()
        {

        }
        public void handleInput(Kalkulator calc, char input)
        {
            if (input == 'O')
            {
                calc.setDisplay("0");
                calc.setState(new initialState());
            }
        }
    }

}
