﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator {
	public class Factory {
		public static ICalculator CreateCalculator() {
			// vratiti kalkulator
			return new Kalkulator();
		}
	}

	public class Kalkulator : ICalculator {
		public string zaslon = "0";

		private char[] spremnik = new char[12];

		private double piPola = Math.PI * 0.5;
		private int brZnam = 0;
		private double oper1, rezultat = 0;
		private string memorija = "", funkcija = "", zadnjiOdabran = "";
		private bool greska = false, operand = false, jednakoOdabran = false;


		private void ucitajSpremnik() {
			isprazniSpremnik();
			int j = 11;
			bool predznak = false;
			for (int i = this.zaslon.Length - 1; i >= 0; i--) {		
				if (this.zaslon[i] >= '0' && this.zaslon[i] <= '9' || this.zaslon[i] == ',') {
					spremnik[j] = this.zaslon[i];
				}
				else if (this.zaslon[i] == '-') {
					predznak = true;
				}
				j--;
			}

			if (predznak) 
				spremnik[0] = '-';
		}

		private void isprazniSpremnik() {
			if (!greska) {
				this.brZnam = 0;
				for (int i = 0; i < 12; i++) {
					this.spremnik[i] = '\0';
				}
			}
		}

		private void _popuniZaslon() {
			string s = new string(this.spremnik);
			string tmp = s.Replace("\0", "");
			if (tmp.Contains(",")) {
				decimal test = decimal.Parse(tmp);
				test = test / 1.000000000000000000000000000000000m;
				tmp = test.ToString();
			}
			this.zaslon = tmp;
		}

		private void _dodaj(char[] ulaz) {
			int j = 2;
			if (zaslon.Contains(",")) 
				j = 1;
			for (int i = j; i < 11; i++) {
				ulaz[i] = ulaz[i + 1];
			}	
		}


		private void _jednako() {
			jednakoOdabran = true;

			switch (funkcija) {
				case "+":
					rezultat = oper1 + double.Parse(this.zaslon);
					zaokruzi(rezultat.ToString()); 
					break;
				case "-":
					rezultat = oper1 - double.Parse(this.zaslon);
					zaokruzi(rezultat.ToString());
					break;
				case "*": 
					rezultat = oper1 * double.Parse(this.zaslon);
					zaokruzi(rezultat.ToString());
					break;
				case "/":
					rezultat = oper1 / double.Parse(this.zaslon); 
					zaokruzi(rezultat.ToString()); 
					break;
				default:
					break;
			}
		}

		private void _plus() {
			if (!operand) {
				oper1 = double.Parse(this.zaslon);
				operand = true;
				isprazniSpremnik();
			}
			else if (!"+-*/".Contains(zadnjiOdabran) && jednakoOdabran == false) {
				_jednako();
				oper1 = rezultat;
				this.zaslon = rezultat.ToString();
				isprazniSpremnik();
			}
			zadnjiOdabran = "+";
			this.funkcija = "+";
			if (jednakoOdabran == true) {
				jednakoOdabran = false;
				isprazniSpremnik();
				oper1 = rezultat;
			}
		}

		private void _minus() {
			if (!operand) {
				oper1 = double.Parse(this.zaslon);
				operand = true;
				isprazniSpremnik();
			}
			else if (!"+-*/".Contains(zadnjiOdabran) && jednakoOdabran == false) {
				_jednako();
				oper1 = rezultat;
				this.zaslon = rezultat.ToString();
				isprazniSpremnik();
			}
			zadnjiOdabran = "-";
			this.funkcija = "-";
			if (jednakoOdabran == true) {
				jednakoOdabran = false;
				isprazniSpremnik();
				oper1 = rezultat;
			}
		}

		private void _puta() {
			if (!operand) {
				oper1 = double.Parse(this.zaslon);
				operand = true;
				isprazniSpremnik();
			}
			else if (!"+-*/".Contains(zadnjiOdabran) && jednakoOdabran == false) {
				_jednako();
				oper1 = rezultat;
				this.zaslon = rezultat.ToString();
				isprazniSpremnik();
			}
			zadnjiOdabran = "*";
			this.funkcija = "*";
			if (jednakoOdabran == true) {
				jednakoOdabran = false;
				isprazniSpremnik();
				oper1 = rezultat;
			}
		}

		private void _podijeljeno() {
			if (!operand) {
				oper1 = double.Parse(this.zaslon);
				operand = true;
				isprazniSpremnik();
			}
			else if (!"+-*/".Contains(zadnjiOdabran) && jednakoOdabran == false) {
				_jednako();
				oper1 = rezultat;
				this.zaslon = rezultat.ToString();
				isprazniSpremnik();
			}
			zadnjiOdabran = "/";
			this.funkcija = "/";
			if (jednakoOdabran == true) {
				jednakoOdabran = false;
				oper1 = rezultat;
				isprazniSpremnik();
			}
		}


		private void _znamenka(char broj) {
			if (brZnam < 10) {
				zadnjiOdabran = broj.ToString();
				_dodaj(this.spremnik);
				this.spremnik[11] = broj;
				brZnam++;
				_popuniZaslon();
			}
		}

		private void _nula() {
			if (brZnam < 10) {
				if (!(brZnam == 0 && this.zaslon == "0")) {
					zadnjiOdabran = "0";
					_dodaj(this.spremnik);
					this.spremnik[11] = '0';
					brZnam++;
					_popuniZaslon();
				}
			}
		}

		private void _zarez() {
			if (this.zaslon.Length == 1 && this.zaslon.Contains("0")) {
				this.spremnik[11] = '0';
				brZnam++;
			}
			else if (brZnam == 10 || this.zaslon.Contains(","))
				return;

			_dodaj(this.spremnik);
			this.spremnik[11] = ',';
			_popuniZaslon();
		}


		private void _promijeniPredznak() {
			if (this.zaslon != "0" && !jednakoOdabran && !"SKTQRI".Contains(this.zadnjiOdabran)) {
				if (this.spremnik[0].Equals('\0'))
					this.spremnik[0] = '-';
				else
					this.spremnik[0] = '\0';
				_popuniZaslon();
			}
			else if (jednakoOdabran) {
				ucitajSpremnik();
				if (this.spremnik[0].Equals('\0'))
					this.spremnik[0] = '-';
				else
					this.spremnik[0] = '\0';
				_popuniZaslon();
				string tmp = new string(this.spremnik);
				tmp = tmp.Replace("\0", "");
				this.rezultat = double.Parse(tmp);
			}
			else {
				this.zaslon = "-" + this.zaslon;
			}
		}

		private void _inverz() {
			this.zadnjiOdabran = "I";
			if (double.Parse(this.zaslon) == 0.0) {
				this.zaslon = "-E-";
				greska = true;
				return;
			}
			double inverz = 1 / double.Parse(this.zaslon);
			zaokruzi(inverz.ToString());
		}

		private void _kvadrat() {
			this.zadnjiOdabran = "Q";
			zaokruzi(Math.Pow((double.Parse(this.zaslon)), 2.0).ToString());
		}

		private void _korjen() {
			this.zadnjiOdabran = "R";
			if ((double.Parse(this.zaslon)) < 0.0) {
				this.zaslon = "-E-";
				greska = true;
				return;
			}
			zaokruzi(Math.Sqrt(double.Parse(this.zaslon)).ToString());
		}

		private void _sinus() {
			this.zadnjiOdabran = "S";
			zaokruzi(Math.Sin(double.Parse(this.zaslon)).ToString());
		}

		private void _kosinus() {
			this.zadnjiOdabran = "K";
			zaokruzi(Math.Cos(double.Parse(this.zaslon)).ToString());
		}

		private void _tangens() {
			this.zadnjiOdabran = "T";
			double infTest = double.Parse(this.zaslon) / piPola;
			if (infTest == Math.Truncate(infTest)) {
				this.zaslon = "-E-";
				greska = true;
				return;
			}
			zaokruzi(Math.Tan(double.Parse(this.zaslon)).ToString());
		}


		private void _resetiraj() {
			this.zaslon = "0";
			this.oper1 = 0;
			this.rezultat = 0;
			this.greska = false;
			this.memorija = "";
			this.funkcija = "";
			isprazniSpremnik();
		}

		private void _brisanjeZaslona() {
			this.zaslon = "0";
			if (this.greska) {
				this.greska = false;
				this.operand = false;
				this.rezultat = 0;
			}
			isprazniSpremnik();
		}

		private void _uzmiIzMemorije() {
			this.zaslon = this.memorija;
		}

		private void _staviUMemoriju() {
			this.memorija = this.zaslon;
		}


		private void zaokruzi(string rez) {
			double test = double.Parse(rez);
			if (test < -9999999999.0 || test > 9999999999.0) {
				this.zaslon = "-E-";
				this.greska = true;
			}
			else {
				if (rez.Contains(",")) {
					int broj = 10;
					int zarez = rez.IndexOf(',');

					if (rez.Contains("-"))
						broj = 11;

					broj = broj - zarez;
					this.zaslon = Math.Round(double.Parse(rez), broj).ToString();
				}
				else
					this.zaslon = rez.ToString();
			}
		}


		public void Press(char inPressedDigit) {
			if (!greska || inPressedDigit.Equals('C') || inPressedDigit.Equals('O')) {
				switch (inPressedDigit) {
					case '+': _plus(); break;
					case '-': _minus(); break;
					case '*': _puta(); break;
					case '/': _podijeljeno(); break;
					case '=': _jednako(); break;
					case ',': _zarez(); break;
					case '0': _nula(); break;
					case '1': _znamenka(inPressedDigit); break;
					case '2': _znamenka(inPressedDigit); break;
					case '3': _znamenka(inPressedDigit); break;
					case '4': _znamenka(inPressedDigit); break;
					case '5': _znamenka(inPressedDigit); break;
					case '6': _znamenka(inPressedDigit); break;
					case '7': _znamenka(inPressedDigit); break;
					case '8': _znamenka(inPressedDigit); break;
					case '9': _znamenka(inPressedDigit); break;
					case 'M': _promijeniPredznak(); break;
					case 'Q': _kvadrat(); break;
					case 'R': _korjen(); break;
					case 'I': _inverz(); break;
					case 'S': _sinus(); break;
					case 'K': _kosinus(); break;
					case 'T': _tangens(); break;
					case 'P': _staviUMemoriju(); break;
					case 'G': _uzmiIzMemorije(); break;
					case 'C': _brisanjeZaslona(); break;
					case 'O': _resetiraj(); break;
				}
			}
		}

		public string GetCurrentDisplayState() {
			return this.zaslon;
		}



		public static void Main() {
			ICalculator calc = Factory.CreateCalculator();
			calc.Press('3');
			calc.Press('*');
			calc.Press('7');
			calc.Press('+');
			calc.Press('2');
			calc.Press('=');
			Console.WriteLine(calc.GetCurrentDisplayState());
			Console.ReadLine();
		}

	}
}
