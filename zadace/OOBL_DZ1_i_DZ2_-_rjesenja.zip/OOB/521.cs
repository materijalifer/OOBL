﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> _stocks = new Dictionary<string, Stock>();

         private Dictionary<string, Index> _indexes = new Dictionary<string, Index>();

         private Dictionary<string, Portfolio> _portfolios = new Dictionary<string, Portfolio>();

        
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName) && Decimal.Compare(inInitialPrice, new decimal(0.0)) > 0 
                                                && inNumberOfShares > 0)  
             {
                 _stocks.Add(inStockName.ToLower(), new Stock(inStockName.ToLower(), inInitialPrice,
                                                        inTimeStamp, inNumberOfShares) );
                 return;
             }

             throw new StockExchangeException("pogreska prilikom dodavanja stock-a");
         }


         public void DelistStock(string inStockName)
         {
               if(!StockExists(inStockName))
                   throw new StockExchangeException("pokusavas obrisati stock koji ne postoji");
                
               foreach(Index index in _indexes.Values) // makni stock iz svih indexa prije
               {
                   if(index.IsStockPartOfIndex(_stocks[inStockName.ToLower()]))
                        index.RemoveStockFromIndex(_stocks[inStockName.ToLower()]);
               }

               foreach(Portfolio portfolio in _portfolios.Values) // makni iz svih portfelja
               {
                   if(portfolio.IsStockPartOfPortfolio(inStockName.ToLower()))
                        portfolio.RemoveStockFromPortfolio(_stocks[inStockName.ToLower()] );
               }

               _stocks.Remove(inStockName.ToLower()); 
         }



         public bool StockExists(string inStockName)
         {
             if (_stocks.ContainsKey(inStockName.ToLower()))
                 return true;
             return false;
         }


         public int NumberOfStocks()
         {
             return _stocks.Count;
         }



         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("stock ne postoji");

             Stock stock = _stocks[inStockName.ToLower()];
             stock.SetStockPrice(inIimeStamp , inStockValue);
         }



         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("stock ne postoji");

             return _stocks[inStockName.ToLower()].GetStockPrice(inTimeStamp);
         }



         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("stock ne postoji");

             return _stocks[inStockName.ToLower()].GetInitialStockPrice();
         }



         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("stock ne postoji");

             return _stocks[inStockName.ToLower()].GetLastStockPrice();
         }



         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName) || (inIndexType != IndexTypes.WEIGHTED && inIndexType != IndexTypes.AVERAGE))
                 throw new StockExchangeException("index vec postoji ili se pokusava kreirati index tipa razlicitog od tipa definiranog u sustavu");

             _indexes.Add(inIndexName.ToLower(), new Index(inIndexType));
         
         }


         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if ( IndexExists(inIndexName) && StockExists(inStockName) && !IsStockPartOfIndex(inIndexName,inStockName))
                 _indexes[inIndexName.ToLower()].AddStockToIndex(_stocks[inStockName.ToLower()]);
             else
                 throw new StockExchangeException("pogreska prilikom dodavanja stocka indexu");
         }


         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if ( IndexExists(inIndexName) && StockExists(inStockName) && !IsStockPartOfIndex(inIndexName, inStockName))
                 _indexes[inIndexName.ToLower()].RemoveStockFromIndex(_stocks[inStockName.ToLower()]);
             else
                 throw new StockExchangeException("pogreska prilikom brisanja stocka iz indexa");
         }


         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
                 return _indexes[inIndexName.ToLower()].IsStockPartOfIndex(_stocks[inStockName.ToLower()]);
             else
                 return false;
         }


         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("index ne postoji");

             return _indexes[inIndexName.ToLower()].GetIndexValue(inTimeStamp); 
         }


         public bool IndexExists(string inIndexName)
         {
             if (_indexes.ContainsKey(inIndexName.ToLower()))
                 return true;
             return false;
         }

         public int NumberOfIndices()
         {
             return _indexes.Count;
         }


         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("index nije definiran");

             return _indexes[inIndexName.ToLower()].GetNumberOfStocks();
         }


         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 _portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             else
                 throw new StockExchangeException("portfelj nije dodan jer vec postoji");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()) && numberOfShares > 0)
                 _portfolios[inPortfolioID].AddStockToPortfolio(_stocks[inStockName.ToLower()], numberOfShares);
             else
                 throw new StockExchangeException("pogreska prilikom dodavanja stocka portfelju");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName) && numberOfShares > 0)
             {
                 _portfolios[inPortfolioID].RemoveStockFromPortfolio(_stocks[inStockName.ToLower()], numberOfShares);
             }
             else
                 throw new StockExchangeException("pogreska prilikom micanja stocka iz portfelja");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 _portfolios[inPortfolioID].RemoveStockFromPortfolio(_stocks[inStockName.ToLower()]);
             }
             else
                 throw new StockExchangeException("pogreska prilikom micanja stocka iz portfelja");
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 return _portfolios[inPortfolioID].NumberOfStocksInPortfolio();

             throw new StockExchangeException("portfelj ne postoji");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (_portfolios.ContainsKey(inPortfolioID))
                 return true;

             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName.ToLower()))
             {
                 return _portfolios[inPortfolioID].IsStockPartOfPortfolio(inStockName.ToLower());
             }
             else
                 return false;
             //throw new StockExchangeException("portfelj ili stock nije definiran");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 return _portfolios[inPortfolioID].NumberOfSharesOfStockInPortfolio(_stocks[inStockName.ToLower()]);

             throw new StockExchangeException("stock ne pripada portfelju");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
                 return _portfolios[inPortfolioID].GetPortfolioValue(timeStamp);
             
             throw new StockExchangeException("portfelj ne postoji");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID))
                 return _portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month);
             else
                 throw new StockExchangeException("portfelj ne postoji");
         }
     }


     public class Index
     {
         List<Stock> _attachedStocks = new List<Stock>();

         Dictionary<IndexTypes, IndexDelegate> indexMethods = new Dictionary<IndexTypes, IndexDelegate>();

         IndexTypes type;

         delegate decimal IndexDelegate(DateTime inDateTime);

         decimal IndexAverage(DateTime inDateTime)
         {
             decimal average = 0.0m;

             foreach (Stock stock in _attachedStocks)
             {
                 average += stock.GetStockPrice(inDateTime);
             }

             try
             {
                 return decimal.Round(average / _attachedStocks.Count, 3);
             }
             catch
             {
                 return decimal.Round(average, 3);
             }
         }


         decimal IndexWeighted(DateTime inDateTime)
         {
             decimal totalValue = 0.0m;

             foreach (Stock stock in _attachedStocks)
             {
                 totalValue += stock.GetStockPrice(inDateTime) * stock.NumberOfShares;
             }

             decimal result = 0.0m;

             foreach (Stock stock in _attachedStocks)
             {
                 result += ((stock.GetStockPrice(inDateTime) * stock.NumberOfShares) / totalValue) * stock.GetStockPrice(inDateTime);
             }

             return result;
         }

         public Index(IndexTypes type)
         {
             this.type = type;

             indexMethods.Add(IndexTypes.AVERAGE, new IndexDelegate(IndexAverage));
             indexMethods.Add(IndexTypes.WEIGHTED, new IndexDelegate(IndexWeighted));
         }

         public IndexTypes Type
         {
             get { return type; }
         }


         public void AddStockToIndex(Stock stock)
         {
             _attachedStocks.Add(stock);
         }

         public void RemoveStockFromIndex(Stock stock)
         {
             if (IsStockPartOfIndex(stock))
                 _attachedStocks.Remove(stock);
         }


         public bool IsStockPartOfIndex(Stock stock)
         {
             if (_attachedStocks.Contains(stock))
                 return true;

             return false;
         }

         public decimal GetIndexValue(DateTime inTimeStamp)
         {
             return indexMethods[type](inTimeStamp);
         }


         public int GetNumberOfStocks()
         {
             return _attachedStocks.Count;
         }
     }

     public class Portfolio
     {
         Dictionary<string, long> assignedStocks = new Dictionary<string, long>();

         Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();

         private string _id;

         public Portfolio(string id)
         {
             this._id = id;
         }


         public void AddStockToPortfolio(Stock stock, long numberOfShares)
         {
             stock.AssignShares(numberOfShares);

             if (assignedStocks.ContainsKey(stock.Id))
                 assignedStocks[stock.Id] += numberOfShares;
             else
                 assignedStocks[stock.Id] = numberOfShares;

             if (!stocks.ContainsKey(stock.Id))
                 stocks[stock.Id] = stock;
         }

         public void RemoveStockFromPortfolio(Stock stock, long numberOfShares)
         {
             if (assignedStocks.ContainsKey(stock.Id))
             {
                 if (numberOfShares > assignedStocks[stock.Id])
                     throw new StockExchangeException("pokusavas maknuti vise dionica nego sto portfelj posjeduje");

                 stock.FreeShares(numberOfShares);

                 assignedStocks[stock.Id] -= numberOfShares;

                 if (assignedStocks[stock.Id] == 0)
                 {
                     assignedStocks.Remove(stock.Id);
                     stocks.Remove(stock.Id);
                 }
             }
             else
                 throw new StockExchangeException("stock nije pridruzen portefelju");
         }

         public void RemoveStockFromPortfolio(Stock stock)
         {
             if (IsStockPartOfPortfolio(stock.Id))
             {
                 stock.FreeShares(assignedStocks[stock.Id]);
                 assignedStocks.Remove(stock.Id);
                 stocks.Remove(stock.Id);
             }
             else
                 throw new StockExchangeException("pokusvas maknuti stock koji nije pridruzen portfelju");
         }


         public bool IsStockPartOfPortfolio(string inStockName)
         {
             return stocks.ContainsKey(inStockName);
         }

         public int NumberOfStocksInPortfolio()
         {
             return stocks.Count;
         }

         public int NumberOfSharesOfStockInPortfolio(Stock stock)
         {
             if (IsStockPartOfPortfolio(stock.Id))
                 return (int)assignedStocks[stock.Id];

             throw new StockExchangeException("stock ne pripada portfelju");
         }

         public decimal GetPortfolioValue(DateTime inDateTime)
         {
             decimal result = 0.0m;

             foreach (string stockId in assignedStocks.Keys)
             {
                 result += assignedStocks[stockId] * stocks[stockId].GetStockPrice(inDateTime);
             }

             return Decimal.Round(result, 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
         {
             decimal oldValue = GetPortfolioValue(new DateTime(Year, Month, 1, 00, 00, 00, 000));
             decimal newValue = GetPortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

             return Decimal.Round(((newValue - oldValue) / oldValue) * 100.0m, 3);
         }
     }

     public class Stock
     {
         private SortedDictionary<DateTime, Decimal> _stockValues = new SortedDictionary<DateTime, Decimal>();

         private long _numberOfShares;

         private long _assignedShares = 0;

         private string _id;


         public Stock(string id, Decimal inInitialPrice, DateTime inTimeStamp, long numberOfShares)
         {
             this._id = id.ToLower();
             this._stockValues.Add(inTimeStamp, inInitialPrice);
             this._numberOfShares = numberOfShares;
         }

         public string Id
         {
             get { return _id; }
             set { _id = value; }
         }


         public void AssignShares(long numberOfSharesToAssign)
         {
             if (_assignedShares + numberOfSharesToAssign > _numberOfShares)
                 throw new StockExchangeException("broj dionica koji se zeli dodijeliti portfelju je veci od postojeceg broja dionica");

             _assignedShares += numberOfSharesToAssign;
         }

         public void FreeShares(long numberOfShares)
         {
             if (numberOfShares > _assignedShares)
                 throw new StockExchangeException("pokusava se osloboditi vise shareova nego sto je zauzeto");

             _assignedShares -= numberOfShares;
         }

         public long NumberOfShares
         {
             get { return _numberOfShares; }
             set { _numberOfShares = value; }
         }


         public Decimal GetInitialStockPrice()
         {
             return _stockValues.Values.First();
         }

         public Decimal GetLastStockPrice()
         {
             return _stockValues.Values.Last();
         }

         public Decimal GetStockPrice(DateTime inTimeStamp)
         {
             var keys = _stockValues.Keys.Reverse().ToList();

             foreach (var key in keys)
             {
                 if (DateTime.Compare(key, inTimeStamp) <= 0)
                     return _stockValues[key];
             }

             throw new StockExchangeException("nije definirana cijena za navedeni datum");
         }

         public void SetStockPrice(DateTime inTimeStamp, decimal inStockValue)
         {
             if (_stockValues.ContainsKey(inTimeStamp))
                 throw new StockExchangeException("cijena za navedeni datum vec definirana");

             _stockValues.Add(inTimeStamp, inStockValue);
         }

         public override bool Equals(object obj)
         {
             Stock stock = obj as Stock;
             if (stock == null)
                 return false;

             else
                 return _id.Equals(stock._id);
         }

         public override int GetHashCode()
         {
             return _id.GetHashCode();
         }
     }
}
