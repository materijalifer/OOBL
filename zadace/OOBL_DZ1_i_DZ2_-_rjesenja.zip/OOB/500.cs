﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        #region Variables

        private string _displayState;

        private string _error = "-E-";

        private double _memory;

        private double _lastOperand;

        private char _lastOperator;

        private bool _startAnew = false;

        private bool _binaryOperatorWasPressedLast = false;
        private char _savedOperator = '+';
        private double _savedOperand = 0;

        #endregion

        public void Press(char inPressedDigit)
        {
            /*
             * ako je broj, nadodam ga u display state
             * ako je bilo koji od binarnih operatora pozvat ću funkciju koja to obrađuje
             * ako je bilo koji od unarnih operatora pozvat ću funkciju koja ih obrađuje
             * ako je clear izbrisat ću displayState
             * ako je put/get, dohvatit ću/spremit u memoriju
             * ako je on/off resetirat ću sve na nulu
             */
            switch (inPressedDigit) 
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    {
                        if (!_binaryOperatorWasPressedLast)
                        {
                            HandleAddDigit(inPressedDigit);
                        }
                        else
                        {
                            HandleBinaryOperator(_savedOperator);
                            _binaryOperatorWasPressedLast = false;

                            HandleAddDigit(inPressedDigit);
                        }
                        break;
                    }
                case '+':
                case '-':
                case '*':
                case '/':
                    {
                        //HandleBinaryOperator(inPressedDigit);
                        _binaryOperatorWasPressedLast = true;
                        _savedOperator = inPressedDigit;
                        _savedOperand = Convert.ToDouble(_displayState);
                        break;
                    }
                case '=':
                    {
                        HandleEquals();
                        _binaryOperatorWasPressedLast = false;
                        break;
                    }
                    
                case ',':
                    {
                        HandleComma();
                        _binaryOperatorWasPressedLast = false;
                        break;
                    }
                case 'M':
                    {
                        HandleMinus();
                        break;
                    }
                case 'S':
                case 'K':
                case 'T':
                case 'Q':
                case 'R':
                case 'I':
                    {
                        HandleUnaryOperator(inPressedDigit);
                        _binaryOperatorWasPressedLast = false;
                        _startAnew = true;
                        break;
                    }
                case 'P':
                case 'G':
                    {
                        HandleMemory(inPressedDigit);
                        break;
                    }
                case 'C':
                    {
                        _displayState = "0";
                        _savedOperand = _lastOperand;
                        _binaryOperatorWasPressedLast = false;
                        break;
                    }
                case 'O':
                    {
                        _displayState = "0";
                        _lastOperand = 0;
                        _savedOperand = 0;
                        _lastOperator = '+';
                        _memory = new double();
                        _binaryOperatorWasPressedLast = false;
                        break;
                    }
                default:
                    {
                        _displayState = _error;
                        break;
                    }


            }
        }

        public string GetCurrentDisplayState()
        {
            return _displayState;
        }

        public Kalkulator()
        {
            _displayState = "0";
            _lastOperand = 0;
            _lastOperator = '+';
        }

        #region Handlers

        private void HandleAddDigit(char Digit) 
        {
            if (Convert.ToDouble(_displayState) == 0 && !_displayState.Contains(',') || _startAnew)
            {
                _displayState = Digit.ToString();
                _startAnew = false;
            }
            else
            {
                _displayState += Digit;
            }
            if (DisplayStateOverflow()) 
            {
                if (_displayState.TrimStart('-').Split(',')[0].Length > 10)
                {
                    _displayState = _error;
                }
                else
                {
                    _displayState = _displayState.Substring(0, _displayState.Length-1);
                }
            }
        }

        private void HandleBinaryOperator(char Operator) 
        {
            switch (_lastOperator) 
            {
                case '+':
                    {
                        _lastOperand = _lastOperand + Convert.ToDouble(_displayState);
                        _lastOperator = Operator;
                        break;
                    }
                case '-':
                    {
                        _lastOperand = _lastOperand - Convert.ToDouble(_displayState);
                        _lastOperator = Operator;
                        break;
                    }
                case '*':
                    {
                        _lastOperand = _lastOperand * Convert.ToDouble(_displayState);
                        _lastOperator = Operator;
                        break;
                    }
                case '/':
                    {
                        _lastOperand = _lastOperand / Convert.ToDouble(_displayState);
                        _lastOperator = Operator;
                        break;
                    }
            }
            //_displayState = "0";
            _startAnew = true;
        }

        private void HandleUnaryOperator(char Operator)
        {
            switch (Operator) 
            {
                case 'S':
                    {
                        double temp = Math.Sin(Convert.ToDouble(_displayState));
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
                case 'K':
                    {
                        double temp = Math.Cos(Convert.ToDouble(_displayState));
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
                case 'T':
                    {
                        double temp = Math.Tan(Convert.ToDouble(_displayState));
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
                case 'Q':
                    {
                        double temp = Math.Pow(Convert.ToDouble(_displayState), 2);
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
                case 'R':
                    {
                        double temp = Math.Sqrt(Convert.ToDouble(_displayState));
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
                case 'I':
                    {
                        double temp = Math.Pow(Convert.ToDouble(_displayState), -1);
                        _displayState = TrimDoubleToString(temp);
                        break;
                    }
            
            }
        }

        private void HandleEquals() 
        {
            if (!_binaryOperatorWasPressedLast)
                switch (_lastOperator)
                {
                    case '+':
                        {
                            _lastOperand = _savedOperand + Convert.ToDouble(_displayState);
                            break;
                        }
                    case '-':
                        {
                            _lastOperand = _savedOperand - Convert.ToDouble(_displayState);
                            break;
                        }
                    case '*':
                        {
                            _lastOperand = _savedOperand * Convert.ToDouble(_displayState);
                            break;
                        }
                    case '/':
                        {
                            _lastOperand = _savedOperand / Convert.ToDouble(_displayState);
                            break;
                        }
                }
            else 
            {
                switch (_savedOperator)
                {
                    case '+':
                        {
                            _lastOperand = Convert.ToDouble(_displayState) + Convert.ToDouble(_displayState);
                            break;
                        }
                    
                    case '*':
                        {
                            _lastOperand = Convert.ToDouble(_displayState) * Convert.ToDouble(_displayState);
                            break;
                        }
                    
                }
                _savedOperand = _lastOperand;
                _binaryOperatorWasPressedLast = false;
            }
            _lastOperator = '+';
            _savedOperand = _lastOperand;
            _displayState = TrimDoubleToString(_lastOperand);
            _lastOperand = 0;
        }

        private void HandleComma() 
        {
            if (!_displayState.Contains(',')) 
            {
                _displayState += ',';
            }
        }

        private void HandleMinus()
        {
            if (!_displayState.Contains('-'))
            {
                _displayState = '-' + _displayState;
            }
            else 
            {
                _displayState = _displayState.TrimStart('-');
            }
        }

        private void HandleMemory(char Operation) 
        {
            if (Operation == 'P')
            {
                _memory = Convert.ToDouble(_displayState);
            }
            else
            {
                _displayState = _memory.ToString();
            }
        }

        #endregion

        private bool DisplayStateOverflow() 
        {
            int numberOfDigits = 0;
            if (_displayState.Length > 12)
                return true;
            for (int i = 0; i < _displayState.Length; i++) 
            {
                if (_displayState[i] != '-' && _displayState[i] != ',') 
                {
                    numberOfDigits += 1;
                }
            }
            if (numberOfDigits > 10)
                return true;
            return false;
        }

        private string TrimDoubleToString(double number) 
        {
            if (number > 10000000000 || number < -10000000000) 
            {
                return _error;
            }
            string result = String.Empty;
            int decimals = 10 - number.ToString().Split(',')[0].TrimStart('-').Length;
            if (decimals > 0)
            {
                result = Convert.ToString(Math.Round(number, decimals));
            }
            else
                return _error;
            return result;
        }

        public void Main()
        {
            char PressedKey = new char();
            while (true)
            {
                PressedKey = (char)Console.Read();
                Press(PressedKey);
            }
        }
    }


}
