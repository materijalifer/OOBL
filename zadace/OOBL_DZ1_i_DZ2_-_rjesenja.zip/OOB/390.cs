﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        private string _stockName;
        private long _availableShares;
        private Decimal _initialPrice;
        private Decimal _lastPrice;
        private DateTime _initialPriceTime;
        private long _numberOfShares;

        private Dictionary<DateTime, Decimal> _prices;

        public Stock(string inStockName, long inNumberOfShares,
                Decimal inInitialPrice, DateTime inTimeStamp)
        {
            _stockName = inStockName.ToUpper();
            _availableShares = _numberOfShares = inNumberOfShares;
            _initialPrice = _lastPrice = inInitialPrice;
            _initialPriceTime = inTimeStamp;

            _prices = new Dictionary<DateTime, Decimal>();
            _prices.Add(_initialPriceTime, _initialPrice);
            //Console.WriteLine("Stvoren stock nazvan "+ StockName
            //    + " sa price = " + InitialPrice + " u " + InitialPriceTime);
        }

        public long GetNumberOfShares()
        {
            return _numberOfShares;
        }

        public Decimal GetPrice(DateTime time)
        {
            Decimal price = -1;
            DateTime priceTimeStamp = new DateTime(3000, 1, 1, 0,0, 0, 0);

            foreach (var item in _prices.OrderByDescending(key => key.Key))
            {
                price = item.Value;
                priceTimeStamp = item.Key;
                //Console.WriteLine("Stock = " + StockName + " Timestamp = " + item.Key + " price = " + item.Value);
                if (item.Key < time) break;
            }
            // priceTimeStamp i Price ce uvijek ispravno biti inicijalizirani posto _prices ima barem
            // jedan element (cijenu i vrijeme izdavanja dionica).
            if (priceTimeStamp > time)
            {
                throw new StockExchangeException("Dionice nisu postojale u to vrijeme");
            }            
            return price;
        }

        public Decimal GetInitialPrice()
        {
            return _initialPrice;
        }
        
        public Decimal GetLastPrice()
        {
            return _lastPrice;
        }

        public void SetPrice(decimal inStockValue, DateTime inTimeStamp)
        {
            // Javi gresku ako cijena nije pozitivna
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("SetPrice sa nepozitivnom cijenom");
            }

            // Javi gresku ako je za taj trenutak vec unijeta cijena
            if (_prices.ContainsKey(inTimeStamp))
            {
                throw new StockExchangeException("SetPrice redefinira cijenu za vec zabiljezeni trenutak");
            }

            _prices.Add(inTimeStamp, inStockValue);
            _lastPrice = inStockValue;

            if (inTimeStamp < _initialPriceTime)
            {
                _initialPrice = inStockValue;
                _initialPriceTime = inTimeStamp;
            }
        }

        // Vlasnik portfejla kupuje dionicu(e)
        public void getShare(int inNumberOfShares)
        {
            if (inNumberOfShares > _availableShares)
            {
                throw new StockExchangeException("Nema dovoljno dionica za kupiti");
            }
            _availableShares -= inNumberOfShares;
        }
        // Vlasnik portfejla vraca dionicu(e)
        public void returnShare(int inNumberOfShares)
        {
            _availableShares += inNumberOfShares;
        }

    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<string> _stocksInIndex;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            _indexName = inIndexName;
            _indexType = inIndexType;
            _stocksInIndex = new List<string>();
        }

        public IndexTypes GetIndexType()
        {
            return _indexType;
        }

        public void AddStock(string inStockName)
        {
            // Javi gresku ako je dionica vec dodana u indeks            
            if (_stocksInIndex.Contains(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Dionica vec dodana u indeks");
            }
            _stocksInIndex.Add(inStockName.ToUpper());
        }

        public bool Contains(string inStockName)
        {
            return _stocksInIndex.Contains(inStockName.ToUpper());
        }

        public int GetNumberOfStocks()
        {
            return _stocksInIndex.Count;
        }

        public List<string> GetStocksInIndex()
        {
            return _stocksInIndex;
        }

        public void RemoveStock(string inStockName)
        {
            // Javi gresku ako dionica nije u indeksu
            if (!_stocksInIndex.Contains(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Brisanje dionce iz indeksa koja nije u indeksu");
            }
            _stocksInIndex.Remove(inStockName.ToUpper());
        }
    }

    public class Portfolio
    {
        private string _portfolioId;
        private Dictionary<string, int> _stocksInPortfolio;

        public Portfolio(string Id)
        {
            _portfolioId = Id;
            _stocksInPortfolio = new Dictionary<string, int>();
        }

        public void AddStock(string inStockName, int inNumberOfShares)
        {
            if (_stocksInPortfolio.ContainsKey(inStockName.ToUpper()))
            {
                // vec imamo nekoliko takvih dionica
                _stocksInPortfolio[inStockName.ToUpper()] += inNumberOfShares;

            }
            else
            {
                // Kupujemo te dionice prvi put
                _stocksInPortfolio.Add(inStockName.ToUpper(), inNumberOfShares);
            }
        }

        public bool Contains(string inStockName)
        {
            return _stocksInPortfolio.ContainsKey(inStockName.ToUpper());
        }

        public int GetNumberOfShares(string inStockName)
        {
            // Ako nemamo dionicu u portfejlu, ocito imamo nula udjela
            if (!_stocksInPortfolio.ContainsKey(inStockName.ToUpper()))
            {
                return 0;
            }
            return _stocksInPortfolio[inStockName.ToUpper()];
        }

        public int GetNumberOfStocks()
        {
            return _stocksInPortfolio.Count;
        }

        public void RemoveStock(string inStockName, int n)
        {
            if (!_stocksInPortfolio.ContainsKey(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Brisanje dionice koja nije u portfejlu");
            }

            if (n > _stocksInPortfolio[inStockName.ToUpper()])
            {
                throw new StockExchangeException("Pokusaj brisanja vise dionica nego sto imamo u porftejlu");
            }

            // Smanjimo broj udjela
            _stocksInPortfolio[inStockName.ToUpper()] -= n;

            // Ako ih nemamo vise, brisemo tu dionicu iz portfejla
            if (_stocksInPortfolio[inStockName.ToUpper()] <= 0)
            {
                _stocksInPortfolio.Remove(inStockName.ToUpper());
            }
        }

        // Brise sve dionice
        public void RemoveStock(string inStockName)
        {
            _stocksInPortfolio.Remove(inStockName.ToUpper());
        }

        public Dictionary<string, int> GetStocksInPortfolio()
        {
            return _stocksInPortfolio;
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> _stocks;
        private Dictionary<string, Index> _indices;
        private Dictionary<string, Portfolio> _portfolios;

        public StockExchange()
        {
            _stocks = new Dictionary<string, Stock> {};
            _indices = new Dictionary<string, Index> ();
            _portfolios = new Dictionary<string, Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            // Provjerimo da dionica vec postoji na burzi
            if (_stocks.ContainsKey(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Dionica vec postoji na burzi");
            }
            
            // Provjerimo da je cijena dionice pozitivna
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena izdane dionice mora biti pozitivna");
            }

            // Provjerimo da je broj dionica pozitivan
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Broj izdanih dionica mora biti pozitivan");
            }

            // Dodajemo novu dionicu u burzu
            //Console.WriteLine("Stvaram stock zvan " + inStockName);
            var newStock = new Stock(inStockName.ToUpper(), inNumberOfShares,
                inInitialPrice, inTimeStamp);

            _stocks.Add(inStockName.ToUpper(), newStock); 
         }

         public void DelistStock(string inStockName)
         {
             // Ako dionica ne postoji, javi gresku
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Delist nepostojece dionice");
             }
             // Birisi dionicu iz svih indeksa
             foreach (var index in _indices)
             {
                 _indices[index.Key].RemoveStock(inStockName.ToUpper());
             }
             // Brisi dionicu iz svih portfejla
             foreach (var portfolio in _portfolios)
             {
                 _portfolios[portfolio.Key].RemoveStock(inStockName.ToUpper());
             }
             // Brisi dionicu iz burze
             _stocks.Remove(inStockName.ToUpper());
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             // Javi gresku ako dionica ne postji
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("SetStockPrice nad nepostojecom dionicom");
             }
             // Javi gresku ako cijena nije pozitivna
             if (inStockValue <= 0)
             {
                 throw new StockExchangeException("SetStockPrice sa nepozitivnom cijenom");
             }
             _stocks[inStockName.ToUpper()].SetPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             // Javi gresko ako dionica ne postoji
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("GetStockPrice nad nepostojecom dionicom");
             }

             return Math.Round(_stocks[inStockName.ToUpper()].GetPrice(inTimeStamp),3);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             // Javi gresko ako dionica ne postoji
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("GetStockPrice nad nepostojecom dionicom");
             }
             return Math.Round(_stocks[inStockName.ToUpper()].GetInitialPrice(),3);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             // Javi gresko ako dionica ne postoji
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("GetStockPrice nad nepostojecom dionicom");
             }
             return Math.Round(_stocks[inStockName.ToUpper()].GetLastPrice(),3);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             // Javi gresku ako indeks vec postoji
             if (_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Indeks vec postoji");
             }
             // Javi gresku za nevazeci IndexType
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Kreiranje indeksa s nevaljalim IndexType");
             }
             var newIndex = new Index(inIndexName.ToUpper(), inIndexType);
             _indices.Add(inIndexName.ToUpper(), newIndex);

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             // Javi gresku ukoliko dodamo u dionicu u nepostojeci indeks
             if (!_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("AddStockToIndex s nepostojecim indeksom");
             }

             // Javi gresku ukoliko dodamo nepostojecu dionicu
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("AddStockToIndex s nepostojecom dionicom");
             }
             _indices[inIndexName.ToUpper()].AddStock(inStockName.ToUpper());
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             // Javi gresku ako indeks ne postoji
             if (!_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromIndex s nepostojecim indeksom");
             }

             // Javi gresku ako dionica ne postoji
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromIndex s nepostojecom dionicom");
             }

             _indices[inIndexName.ToUpper()].RemoveStock(inStockName.ToUpper());

         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             // Javi gresku ako indeks ne postoji
             if (!_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("IsStockPartOfIndex s nepostojecim indeksom");
             }
             return _indices[inIndexName.ToUpper()].Contains(inStockName.ToUpper());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             // Javi gresku ako indeks ne postoji
             if (!_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("GetIndexValue za nepostojeci indeks");
             }

             // Racunamo ukupnu vrijednost tih dionica na burzi
             Decimal indexPrice = 0;
             if (_indices[inIndexName.ToUpper()].GetIndexType() == IndexTypes.WEIGHTED)
             {
                 // Za WEIGHTED index
                 Decimal totalValue = 0;
                 foreach (string stock in _indices[inIndexName.ToUpper()].GetStocksInIndex())
                 {
                     //Console.WriteLine("--- racunam za "+ stock + " ----");
                     totalValue += _stocks[stock].GetPrice(inTimeStamp)*_stocks[stock].GetNumberOfShares();
                 }

                 indexPrice = 0;
                 foreach (string stock in _indices[inIndexName.ToUpper()].GetStocksInIndex())
                 {
                     indexPrice += ((_stocks[stock].GetPrice(inTimeStamp)*_stocks[stock].GetNumberOfShares())/totalValue)
                                   *_stocks[stock].GetPrice(inTimeStamp);
                 }
             }
             else
             {
                 // Za AVERAGE index
                 Decimal totalValue = 0;
                 long totalNumber = 0;
                 foreach (string stock in _indices[inIndexName.ToUpper()].GetStocksInIndex())
                 {
                     //Console.WriteLine("--- racunam za "+ stock + " ----");
                     totalValue += _stocks[stock].GetPrice(inTimeStamp);
                     totalNumber += _stocks[stock].GetNumberOfShares();
                 }
                 indexPrice = totalValue/totalNumber;
             }

             return Math.Round(indexPrice, 3);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.ContainsKey(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             // Javi gresku ako indeks ne postoji
             if (!_indices.ContainsKey(inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("NumberOfStocksInIndex s nepostojecim indeksom");
             }
             return _indices[inIndexName.ToUpper()].GetNumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             // Javi gresku ako portfejl vec postoji
             if (_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("portfejl vec postoji");
             }
             var newPortfolio = new Portfolio(inPortfolioID);
             _portfolios.Add(inPortfolioID, newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             
             // Javi gresku ukoliko dodamo dionicu u nepostojeci portfejl
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("AddStockToPortfolio na nepostojeci Portfejl");
             }

             // Javi gresku ako ne postoji takva dionica
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Pokusaj kupovanja nepostojece dionice");
             }

             // Javi gresku ako je broj dionica negativan ili 0
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("AddStockToPortfolio sa nepozitivnim brojem dionica");
             }

             // Smanji broj slobodnih dionica ili javi gresku ako nema dovoljno dionica
             _stocks[inStockName.ToUpper()].getShare(numberOfShares);

             // Dodaj dionice u portfejl
             _portfolios[inPortfolioID].AddStock(inStockName.ToUpper(), numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             // Javi gresku ako ne postoji takav portfejl
             if (!_portfolios.ContainsKey(inPortfolioID.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromPortfolio s nevazecim ID-om porfejla");
             }
             // Javi gresku ako ne postoji takav stock
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromPortfolio s nevazecom dionicom");
             }
             // Javi gresku ako je broj shareova nepozivivan
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("RemoveStockFromPortfolio s nepozitivnim brojem uloga");
             }
             _portfolios[inPortfolioID.ToUpper()].RemoveStock(inStockName.ToUpper(), numberOfShares);
             _stocks[inStockName.ToUpper()].returnShare(numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             // Javi gresku ako ne postoji takav portfejl
             if (!_portfolios.ContainsKey(inPortfolioID.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromPortfolio s nevazecim ID-om porfejla");
             }

             // Javi gresku ako ne postoji takav stock
             if (!_stocks.ContainsKey(inStockName.ToUpper()))
             {
                 throw new StockExchangeException("RemoveStockFromPortfolio s nevazecom dionicom");
             }

             _portfolios[inPortfolioID.ToUpper()].RemoveStock(inStockName.ToUpper());
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!_portfolios.ContainsKey(inPortfolioID))
            {
                throw new StockExchangeException("NumberOfStockInPortfolio za nepostojeci portfejl");
            }
            return _portfolios[inPortfolioID].GetNumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.ContainsKey(inPortfolioID);
        }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("IsStockPartOfPortfolio za nepostojeci portfejl");
             }
             return _portfolios[inPortfolioID].Contains(inStockName.ToUpper());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("NumberOfSharesOfStockInPortfolio za nepostojeci portfejl");
             }
             return _portfolios[inPortfolioID].GetNumberOfShares(inStockName.ToUpper());
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("GetPortfolioValue sa nepostojecim id-om");
             }

             Decimal totalValue = 0;
             foreach (var stock in _portfolios[inPortfolioID].GetStocksInPortfolio())
             {
                 totalValue += _stocks[stock.Key].GetPrice(timeStamp);
             }
             return Math.Round(totalValue,3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             // Provjeri valjanost datuma
             if (Month <= 0 || Month > 12 || Year <= 0)
             {
                 throw new StockExchangeException("GetPortfolioPercentChangeInValueForMonth - Nevaljali datum");
             }

             // Provjeri id portfejla
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("GetPortfolioPercetnChangeInValueForMotn - nevaljali id");
             }
             
             // Izracunaj postotak
             DateTime beginPeriod = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             //DateTime endPeriod = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 999);
             DateTime endPeriod = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

             Decimal initialValue = GetPortfolioValue(inPortfolioID, beginPeriod);
             Decimal endValue = GetPortfolioValue(inPortfolioID, endPeriod);

             Decimal percentage = ((endValue - initialValue) / initialValue ) *100;

             return Math.Round(percentage,3);
         }
     }
}
