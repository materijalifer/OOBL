﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace DrugaDomacaZadaca_Burza
{

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchangeAdapter();
        }
    }

    class StockExchangeAdapter : IStockExchange
    {
        private const int Precision = 3;

        public StockExchangeAdapter()
        {
            StockExchange.Clear();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            StockExchange.ListStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            StockExchange.DelistStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return StockExchange.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return StockExchange.NumberOfStocks;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            StockExchange.SetStockPrice(inStockName, inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return decimal.Round(StockExchange.StockValue(inStockName, inTimeStamp), Precision);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return decimal.Round(StockExchange.GetInitialStockPrice(inStockName), Precision);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return decimal.Round(StockExchange.GetLastStockPrice(inStockName), Precision);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            StockExchange.CreateIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            StockExchange.AddStockToIndex(inIndexName, inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            StockExchange.RemoveStockFromIndex(inIndexName, inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return StockExchange.IsStockPartOfIndex(inIndexName, inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return decimal.Round(StockExchange.IndexValue(inIndexName, inTimeStamp), Precision);
        }

        public bool IndexExists(string inIndexName)
        {
            return StockExchange.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return StockExchange.NumberOfIndices;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return StockExchange.NumberOfStocksInIndex(inIndexName);
        }

        public void CreatePortfolio(string inPortfolioId)
        {
            StockExchange.CreatePortfolio(inPortfolioId);
        }

        public void AddStockToPortfolio(string inPortfolioId, string inStockName, int numberOfShares)
        {
            StockExchange.AddStockToPortfolio(inPortfolioId, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioId, string inStockName, int numberOfShares)
        {
            StockExchange.RemoveStockFromPortfolio(inPortfolioId, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioId, string inStockName)
        {
            StockExchange.RemoveStockFromPortfolio(inPortfolioId, inStockName);
        }

        public int NumberOfPortfolios()
        {
            return StockExchange.NumberOfPortfolios;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioId)
        {
            return StockExchange.NumberOfStocksInPortfolio(inPortfolioId);
        }

        public bool PortfolioExists(string inPortfolioId)
        {
            return StockExchange.PortfolioExists(inPortfolioId);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioId, string inStockName)
        {
            return StockExchange.IsStockPartOfPortfolio(inPortfolioId, inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioId, string inStockName)
        {
            return (int)StockExchange.NumberOfSharesOfStockInPortfolio(inPortfolioId, inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioId, DateTime timeStamp)
        {
            return decimal.Round(StockExchange.GetPortfolioValue(inPortfolioId, timeStamp), Precision);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioId, int year, int month)
        {
            return decimal.Round(StockExchange.GetPortfolioPercentChangeInValueForMonth(inPortfolioId, year, month),
                                 Precision);
        }
    }

    static class StockExchange
    {
        private static readonly Dictionary<StockId, Stock> Stocks = new Dictionary<StockId, Stock>();

        /// <summary>
        /// Checks wether the stock with the specified ID exist on the stock exchange.
        /// </summary>
        /// <param name="id">Stock ID.</param>
        /// <returns>True if the stock exists on the stock exchange.</returns>
        internal static bool StockExists(StockId id)
        {
            return Stocks.ContainsKey(id);
        }

        /// <summary>
        /// Gets price of the stock at the specified time.
        /// </summary>
        /// <param name="id">Stock ID.</param>
        /// <param name="time">Time for which price is evaluated.</param>
        /// <returns>Stock price at the time.</returns>
        internal static Decimal StockValue(StockId id, DateTime time)
        {
            return Stocks[id].GetPrice(time);
        }

        /// <summary>
        /// Gets number of shares contained in the specified stock.
        /// </summary>
        /// <param name="id">Stock ID.</param>
        /// <returns>Number of stock shares.</returns>
        internal static long StockShares(StockId id)
        {
            return Stocks[id].NumberOfShares;
        }

        /// <summary>
        /// Adds a new stock on the stock exchange.
        /// </summary>
        /// <param name="inStockName">Stock name.</param>
        /// <param name="inNumberOfShares">Stock shares.</param>
        /// <param name="inInitialPrice">Stock price.</param>
        /// <param name="inTimeStamp">Stock creation time stamp.</param>
        internal static void ListStock(
            string inStockName,
            long inNumberOfShares,
            Decimal inInitialPrice,
            DateTime inTimeStamp)
        {
            if (Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Stock " + inStockName + " already exists!");

            Stocks.Add(inStockName, new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        /// <summary>
        /// Removes the specified stock frome the stock exchange.
        /// </summary>
        /// <param name="id">Stock ID.</param>
        internal static void DelistStock(StockId id)
        {
            if (!Stocks.ContainsKey(id))
                throw new StockExchangeException("Stock " + id + " doesn't exist on the stock exchange!");

            var indices =
                from ind in Indices
                where ind.Value.ContainsStock(id)
                select ind;

            foreach (var index in indices)
                index.Value.RemoveStock(id);

            var portfolios =
                from por in Portfolios
                where por.Value.IsStockPartOfPortfolio(id)
                select por;

            foreach (var portfolio in portfolios)
                portfolio.Value.RemoveStock(id);
        }

        internal static int NumberOfStocks
        {
            get { return Stocks.Count; }
        }

        internal static Decimal GetInitialStockPrice(StockId id)
        {
            if (!Stocks.ContainsKey(id))
                throw new StockExchangeException("Stock " + "doesn't exist on the stock exchage!");

            return Stocks[id].InitialPrice;
        }

        internal static Decimal GetLastStockPrice(StockId id)
        {
            if (!Stocks.ContainsKey(id))
                throw new StockExchangeException("Stock " + "doesn't exist on the stock exchage!");

            return Stocks[id].Price;
        }

        internal static void SetStockPrice(StockId id, Decimal price, DateTime time)
        {
            if (!Stocks.ContainsKey(id))
                throw new StockExchangeException("Stock " + id + " doesn't exist!");

            Stocks[id].AddPrice(price, time);
        }

        /*/////////////////////////////////////////////////////////////////////////////////////////////////////*/

        private static readonly Dictionary<IndexId, Index> Indices = new Dictionary<IndexId, Index>();

        private static void CheckArgs(IndexId indexName, StockId stockName)
        {
            if (!Indices.ContainsKey(indexName))
                throw new StockExchangeException("Index " + indexName + " doesn't exist!");

            if (!Stocks.ContainsKey(stockName))
                throw new StockExchangeException("Stock " + stockName + " doesn't exist!");
        }

        internal static void AddStockToIndex(IndexId indexName, StockId stockName)
        {
            CheckArgs(indexName, stockName);

            Indices[indexName].AddStock(stockName);
        }

        internal static void RemoveStockFromIndex(IndexId indexName, StockId stockName)
        {
            CheckArgs(indexName, stockName);

            Indices[indexName].RemoveStock(stockName);
        }

        internal static bool IsStockPartOfIndex(IndexId indexName, StockId stockName)
        {
            CheckArgs(indexName, stockName);

            return Indices[indexName].ContainsStock(stockName);
        }

        internal static void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (Indices.ContainsKey(inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " already exists!");

            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    Indices.Add(inIndexName, new AverageIndex(inIndexName));
                    break;
                case IndexTypes.WEIGHTED:
                    Indices.Add(inIndexName, new WeightIndex(inIndexName));
                    break;
                default:
                    throw new StockExchangeException("Unknown index type");
            }
        }

        internal static Decimal IndexValue(IndexId index, DateTime time)
        {
            if (!Indices.ContainsKey(index))
                throw new StockExchangeException("Index " + index + " doesn't exist!");

            return Indices[index].Value(time);
        }

        internal static bool IndexExists(IndexId id)
        {
            return Indices.ContainsKey(id);
        }

        internal static int NumberOfStocksInIndex(IndexId indexName)
        {
            if (!Indices.ContainsKey(indexName))
                throw new StockExchangeException("Index " + indexName + " doesn't exist!");

            return Indices[indexName].NumberOfStocks;
        }

        internal static int NumberOfIndices
        {
            get { return Indices.Count; }
        }

        /*/////////////////////////////////////////////////////////////////////////////////////////////////////*/

        private static readonly Dictionary<PortfolioId, Portfolio> Portfolios = new Dictionary<PortfolioId, Portfolio>();

        private static void CheckArgs(PortfolioId portfolioName, StockId stockName)
        {
            if (!Portfolios.ContainsKey(portfolioName))
                throw new StockExchangeException("Portfolio " + portfolioName + " doesn't exist!");

            if (!Stocks.ContainsKey(stockName))
                throw new Exception("Stock " + stockName + " doesn't exist!");
        }

        internal static void CreatePortfolio(PortfolioId name)
        {
            if (Portfolios.ContainsKey(name))
                throw new StockExchangeException("Portfolio" + name + "alreday exists!");
            Portfolios.Add(name, new Portfolio(name));
        }

        internal static void AddStockToPortfolio(PortfolioId inPortfolioId, StockId inStockName, long numberOfShares)
        {
            CheckArgs(inPortfolioId, inStockName);

            long shareSum = Portfolios
                .Where(portfolio => portfolio.Value.IsStockPartOfPortfolio(inStockName))
                .Sum(portfolio => portfolio.Value.NumberOfSharesOfStockInPortfolio(inStockName));

            if (shareSum + numberOfShares > Stocks[inStockName].NumberOfShares)
                throw new StockExchangeException("Stock " + inStockName + " doesn't have that many shares!");

            Portfolios[inPortfolioId].AddStock(inStockName, numberOfShares);
        }

        internal static void RemoveStockFromPortfolio(PortfolioId inPortfolioId, StockId inStockName, long numberOfShares)
        {
            CheckArgs(inPortfolioId, inStockName);

            Portfolios[inPortfolioId].RemoveStock(inStockName, numberOfShares);
        }

        internal static void RemoveStockFromPortfolio(PortfolioId inPortfolioId, StockId inStockName)
        {
            CheckArgs(inPortfolioId, inStockName);

            Portfolios[inPortfolioId].RemoveStock(inStockName);
        }

        internal static int NumberOfStocksInPortfolio(PortfolioId inPortfolioId)
        {
            if (!Portfolios.ContainsKey(inPortfolioId))
                throw new StockExchangeException("Portfolio " + inPortfolioId + " doesn't exist!");

            return Portfolios[inPortfolioId].NumberOfStocksInPortfolio;
        }

        internal static long NumberOfSharesOfStockInPortfolio(PortfolioId inPortfolioId, StockId inStockName)
        {
            CheckArgs(inPortfolioId, inStockName);

            return Portfolios[inPortfolioId].NumberOfSharesOfStockInPortfolio(inStockName);
        }

        internal static bool IsStockPartOfPortfolio(PortfolioId inPortfolioId, StockId inStockName)
        {
            CheckArgs(inPortfolioId, inStockName);

            return Portfolios[inPortfolioId].IsStockPartOfPortfolio(inStockName);
        }

        internal static Decimal GetPortfolioValue(PortfolioId inPortfolioId, DateTime timeStamp)
        {
            if (!Portfolios.ContainsKey(inPortfolioId))
                throw new StockExchangeException("Portfolio " + inPortfolioId + " doesn't exist!");

            return Portfolios[inPortfolioId].GetValue(timeStamp);
        }

        internal static Decimal GetPortfolioPercentChangeInValueForMonth(PortfolioId inPortfolioId, int year, int month)
        {
            if (!Portfolios.ContainsKey(inPortfolioId))
                throw new StockExchangeException("Portfolio " + inPortfolioId + " doesn't exist!");

            return Portfolios[inPortfolioId].GetPortfolioPercentChangeInValueForMonth(year, month);
        }

        internal static bool PortfolioExists(PortfolioId inPortfolioId)
        {
            return Portfolios.ContainsKey(inPortfolioId);
        }

        internal static int NumberOfPortfolios
        {
            get { return Portfolios.Count; }
        }

        /*/////////////////////////////////////////////////////////////////////////////////////////////////////*/

        public static void Clear()
        {
            Stocks.Clear();
            Indices.Clear();
            Portfolios.Clear();
        }
    }

    class StockId
    {
        public string Id { get; private set; }

        public StockId(string id)
        {
            CheckID(id);
            Id = ApplyNamingRules(id);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            StockId id = obj as StockId;

            if ((object)id == null)
                return false;

            return id.Id == this.Id;
        }

        public static bool operator ==(StockId lhs, StockId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return true;
                else
                    return false;

            return lhs.Equals(rhs);
        }

        public static bool operator !=(StockId lhs, StockId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return false;
                else
                    return true;

            return !lhs.Equals(rhs);
        }

        public static implicit operator string(StockId rhs)
        {
            if ((object)rhs == null)
                return null;

            return rhs.Id;
        }

        public static implicit operator StockId(string rhs)
        {
            CheckID(rhs);
            return new StockId(rhs);
        }

        /// <summary>
        /// Checks wether any of the references are null.
        /// </summary>
        /// <param name="args">Referneces to be checked for null references.</param>
        /// <returns>True if any reference is null.</returns>
        private static bool CheckForNullReferences(params StockId[] args)
        {
            return args.Any(arg => (object)arg == null);
        }

        /// <summary>
        /// Applies naming convention for Stock ID's on the specified string.
        /// </summary>
        /// <param name="id">String to be transformed by naming convention.</param>
        /// <returns>Transformed string.</returns>
        private static string ApplyNamingRules(string id)
        {
            CheckID(id);
            return id.ToLower();
        }

        /// <summary>
        /// Check wether the id satisfies conditions for being an ID.
        /// </summary>
        /// <param name="id">String to be checked.</param>
        private static void CheckID(string id)
        {
            if (string.IsNullOrEmpty(id))
                throw new StockExchangeException("Invalid stock name!");

            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(id.Trim()))
                throw new StockExchangeException("Invalid stock name!");

            if (id.Any(c => !char.IsLetter(c)))
                throw new StockExchangeException("Invalid stock name!");
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public override string ToString()
        {
            return Id;
        }
    }

    class Stock
    {
        /// <summary>
        /// Gets stock name.
        /// </summary>
        public StockId Name { get; private set; }

        /// <summary>
        /// Gets stock creation time.
        /// </summary>
        public DateTime CreationTime { get; private set; }

        /// <summary>
        /// Gets current stock price.
        /// </summary>
        public Decimal Price { get; private set; }

        /// <summary>
        /// Gets initial stock price.
        /// </summary>
        public Decimal InitialPrice
        {
            get { return _changeTimes.First().Value; }
        }

        /// <summary>
        /// Gets the stock's number of shares.
        /// </summary>
        public long NumberOfShares { get; private set; }

        private readonly SortedList<DateTime, Decimal> _changeTimes = new SortedList<DateTime, Decimal>();

        /// <summary>
        /// Creates a new instance of class DrugaDomacaZadaca_Burza.Stock.
        /// </summary>
        /// <param name="name">Stock name.</param>
        /// <param name="numberOfShares">Number of shares in the stock.</param>
        /// <param name="initialPrice">Initial stock price.</param>
        /// <param name="timeStamp">Creation time stamp.</param>
        public Stock(string name, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
        {
            CheckArguments(initialPrice);
            Name = name;
            Price = initialPrice;
            NumberOfShares = numberOfShares;
            CreationTime = timeStamp;
            _changeTimes.Add(timeStamp, initialPrice);
        }

        /// <summary>
        /// Checks whether the change time stamp complies with the specified rules.
        /// </summary>
        /// <param name="timeStamp">Change time stamp.</param>
        /// <exception cref="StockExchangeException">Throws StockExchangeException if the change is already written in stock history.</exception>
        private void CheckArguments(DateTime timeStamp)
        {
            const string errorMessage = "Inconsistent time stamps!";

            if (_changeTimes.ContainsKey(timeStamp))
                throw new StockExchangeException(errorMessage);
        }

        /// <summary>
        /// Checks whether the price complies with the specified rules.
        /// </summary>
        /// <param name="price">Price to be checked.</param>
        private void CheckArguments(Decimal price)
        {
            const Decimal minPrice = 0;

            if (price <= minPrice)
                throw new StockExchangeException("Price must be greater than 0!");
        }

        /// <summary>
        /// Checks wether the parameters comply with the business rules.
        /// </summary>
        /// <param name="price">Price.</param>
        /// <param name="timeStamp">Time stamp.</param>
        private void CheckArguments(Decimal price, DateTime timeStamp)
        {
            CheckArguments(timeStamp);
            CheckArguments(price);
        }

        /// <summary>
        /// Adds a price to stock history.
        /// </summary>
        /// <param name="price">Price to be added.</param>
        /// <param name="timeStamp">Change time stamp.</param>
        public void AddPrice(Decimal price, DateTime timeStamp)
        {
            CheckArguments(price, timeStamp);

            _changeTimes.Add(timeStamp, price);

            if (timeStamp > _changeTimes.Keys.Last())
                Price = price;

            if (timeStamp < CreationTime)
                CreationTime = timeStamp;
        }

        /// <summary>
        /// Gets stock price at the specified moment.
        /// </summary>
        /// <param name="timeStamp">Moment in which stock price is evaluated.</param>
        /// <returns>Stock price at the specified moment.</returns>
        public Decimal GetPrice(DateTime timeStamp)
        {
            if (timeStamp < CreationTime)
                return 0;

            if (_changeTimes.ContainsKey(timeStamp))
                return _changeTimes[timeStamp];

            DateTime closest = DateTime.MinValue;
            foreach (DateTime time in _changeTimes.Keys)
            {
                if (timeStamp < time)
                    break;
                closest = time;
            }
            return _changeTimes[closest];
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }

    class IndexId
    {
        /// <summary>
        /// Gets index ID.
        /// </summary>
        public string Id { get; private set; }

        public IndexId(string id)
        {
            CheckID(id);
            Id = ApplyNamingRules(id);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            IndexId id = obj as IndexId;

            if ((object)id == null)
                return false;

            return id.Id == this.Id;
        }

        public static bool operator ==(IndexId lhs, IndexId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return true;
                else
                    return false;

            return lhs.Equals(rhs);
        }

        public static bool operator !=(IndexId lhs, IndexId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return false;
                else
                    return true;

            return !lhs.Equals(rhs);
        }

        public static implicit operator string(IndexId rhs)
        {
            if ((object)rhs == null)
                return null;

            return rhs.Id;
        }

        public static implicit operator IndexId(string rhs)
        {
            CheckID(rhs);
            return new IndexId(rhs);
        }

        /// <summary>
        /// Checks wether any of the references are null.
        /// </summary>
        /// <param name="args">Referneces to be checked for null references.</param>
        /// <returns>True if any reference is null.</returns>
        private static bool CheckForNullReferences(params IndexId[] args)
        {
            return args.Any(arg => (object)arg == null);
        }

        /// <summary>
        /// Applies naming convention for Index ID's on the specified string.
        /// </summary>
        /// <param name="id">String to be transformed by naming convention.</param>
        /// <returns>Transformed string.</returns>
        private static string ApplyNamingRules(string id)
        {
            CheckID(id);
            return id.ToLower();
        }

        /// <summary>
        /// Check wether the id satisfies conditions for being an ID.
        /// </summary>
        /// <param name="id">String to be checked.</param>
        private static void CheckID(string id)
        {
            if (string.IsNullOrEmpty(id))
                throw new StockExchangeException("Invalid index name!");

            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(id.Trim()))
                throw new StockExchangeException("Invalid index name!");
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public override string ToString()
        {
            return Id;
        }
    }

    abstract class Index
    {
        /// <summary>
        /// Gets index name.
        /// </summary>
        public virtual IndexId Name { get; private set; }

        /// <summary>
        /// List containing stock id's of stock added to the index.
        /// </summary>
        protected readonly List<StockId> Stocks = new List<StockId>();

        /// <summary>
        /// Gets numboer of stocks in index.
        /// </summary>
        public virtual int NumberOfStocks
        {
            get { return Stocks.Count; }
        }

        /// <summary>
        /// Initializes Name with name.
        /// </summary>
        /// <param name="name">String to be used for initialization.</param>
        protected Index(string name)
        {
            Name = name;
        }

        /// <summary>
        /// Adds stock to index.
        /// </summary>
        /// <param name="stock">Stock to be added to index.</param>
        /// <exception cref="StockExchangeException">Throws StockExchangeException if stock is null or if it is alreadry contained in index.</exception>
        public virtual void AddStock(StockId stock)
        {
            if (stock == null)
                throw new StockExchangeException("Stock reference cannot be null!");

            if (Stocks.Contains(stock))
                throw new StockExchangeException("Index already contains stock " + stock + "!");

            if (!StockExchange.StockExists(stock))
                throw new StockExchangeException("Stock " + stock + " doesn't exist on stock exchange!");

            Stocks.Add(stock);
        }

        /// <summary>
        /// Removes the specified stock from index.
        /// </summary>
        /// <param name="stock">Stock to be removed.</param>
        public virtual void RemoveStock(StockId stock)
        {
            if (!Stocks.Contains(stock))
                throw new StockExchangeException("Stock " + stock + " is not a part of the index!");

            Stocks.Remove(stock);
        }

        /// <summary>
        /// Checks wether the index contans the specified stock.
        /// </summary>
        /// <param name="stock">Stock that is searched for.</param>
        /// <returns>True if index contains stock.</returns>
        public virtual bool ContainsStock(StockId stock)
        {
            return Stocks.Contains(stock);
        }

        /// <summary>
        /// Gets index value at the specified moment.
        /// </summary>
        /// <param name="timeStamp">Moment in which the index is evaluated.</param>
        /// <returns>Index value at the specified moment.</returns>
        public abstract Decimal Value(DateTime timeStamp);

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }

    class WeightIndex : Index
    {
        public WeightIndex(string name) :
            base(name)
        {
        }

        /// <summary>
        /// Gets the value of weight index at the specified time.
        /// </summary>
        /// <param name="timeStamp">Time in which index is evaluated.</param>
        /// <returns>Index value at the time.</returns>
        public override decimal Value(DateTime timeStamp)
        {
            Decimal stockSum = Stocks.Sum(id => StockExchange.StockValue(id, timeStamp) * StockExchange.StockShares(id));

            return Stocks.Sum(id => StockExchange.StockShares(id) * StockExchange.StockValue(id, timeStamp) * StockExchange.StockValue(id, timeStamp) / stockSum);
        }
    }

    class AverageIndex : Index
    {
        public AverageIndex(string name) :
            base(name)
        {
        }

        /// <summary>
        /// Gets average of the stocks containde in the index at the specified time.
        /// </summary>
        /// <param name="timeStamp">Time in which index is evaluated.</param>
        /// <returns>Stock average.</returns>
        public override decimal Value(DateTime timeStamp)
        {
            Decimal sum = Stocks.Sum(id => StockExchange.StockValue(id, timeStamp));

            return sum / Stocks.Count;
        }
    }

    class PortfolioId
    {
        public string Id { get; private set; }

        public PortfolioId(string id)
        {
            CheckID(id);
            Id = ApplyNamingRules(id);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            PortfolioId id = obj as PortfolioId;

            if ((object)id == null)
                return false;

            return id.Id == this.Id;
        }

        public static bool operator ==(PortfolioId lhs, PortfolioId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return true;
                else
                    return false;

            return lhs.Equals(rhs);
        }

        public static bool operator !=(PortfolioId lhs, PortfolioId rhs)
        {
            if (CheckForNullReferences(lhs, rhs))
                if (((object)lhs == null) && ((object)rhs == null))
                    return false;
                else
                    return true;

            return !lhs.Equals(rhs);
        }

        public static implicit operator string(PortfolioId rhs)
        {
            if ((object)rhs == null)
                return null;

            return rhs.Id;
        }

        public static implicit operator PortfolioId(string rhs)
        {
            CheckID(rhs);
            return new PortfolioId(rhs);
        }

        /// <summary>
        /// Checks wether any of the references are null.
        /// </summary>
        /// <param name="args">Referneces to be checked for null references.</param>
        /// <returns>True if any reference is null.</returns>
        private static bool CheckForNullReferences(params PortfolioId[] args)
        {
            return args.Any(arg => (object)arg == null);
        }

        /// <summary>
        /// Applies naming convention for Porfolio ID's on the specified string.
        /// </summary>
        /// <param name="id">String to be transformed by naming convention.</param>
        /// <returns>Transformed string.</returns>
        private static string ApplyNamingRules(string id)
        {
            CheckID(id);
            return id;
        }

        /// <summary>
        /// Check wether the id satisfies conditions for being an ID.
        /// </summary>
        /// <param name="id">String to be checked.</param>
        private static void CheckID(string id)
        {
            if (string.IsNullOrEmpty(id))
                throw new StockExchangeException("Invalid stock name!");

            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(id.Trim()))
                throw new StockExchangeException("Invalid stock name!");
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public override string ToString()
        {
            return Id;
        }
    }

    class Portfolio
    {
        /// <summary>
        /// Gets portfolio name.
        /// </summary>
        public PortfolioId Name { get; private set; }

        public int NumberOfStocksInPortfolio
        {
            get { return _stocks.Count; }
        }

        private readonly Dictionary<StockId, long> _stocks = new Dictionary<StockId, long>();

        public Portfolio(string id)
        {
            Name = id;
        }

        public void AddStock(StockId stockId, long shares)
        {
            if (_stocks.ContainsKey(stockId))
                _stocks[stockId] += shares;
            else
                _stocks.Add(stockId, shares);
        }

        public void RemoveStock(StockId id)
        {
            if (!_stocks.ContainsKey(id))
                throw new StockExchangeException("Stock" + id + " is not a part of portfolio " + Name + "!");

            _stocks.Remove(id);
        }

        public void RemoveStock(StockId id, long numberOfShares)
        {
            if (!_stocks.ContainsKey(id))
                throw new StockExchangeException("Stock" + id + " is not a part of portfolio " + Name + "!");

            if (_stocks[id] < numberOfShares)
                throw new StockExchangeException("Stock " + id + "doesn't have " + numberOfShares +
                                                 "shares in portfolio " + Name);

            _stocks[id] -= numberOfShares;

            if (_stocks[id] == 0)
                _stocks.Remove(id);
        }

        public Decimal GetValue(DateTime timeStamp)
        {
            return _stocks.Sum(stock => StockExchange.StockValue(stock.Key, timeStamp) * stock.Value);
        }

        public long NumberOfSharesOfStockInPortfolio(StockId id)
        {
            if (!_stocks.ContainsKey(id))
                throw new StockExchangeException("Portfolio " + Name + "doesn't contain stock " + id + "!");

            return _stocks[id];
        }

        public bool IsStockPartOfPortfolio(StockId id)
        {
            return _stocks.ContainsKey(id);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
        {
            DateTime monthStart = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime monthEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

            return 100 * ((GetValue(monthEnd) - GetValue(monthStart)) / (GetValue(monthStart)));
        }
    }
}

