﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PrvaDomacaZadaca_Kalkulator;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string trenutniStatus = "0";
        private char zadnjiUnesen;
        private bool visestrukaOperacija;


        // memorija kalkulatora - definirati
        private double memorija;

        public double Unarna(double input, char op)
        {
            switch(op)
            {
                case 'M':
                    return -input;
                case 'S':
                    return Math.Sin(input);
                case 'K':
                    return Math.Cos(input);
                case 'T':
                    return Math.Tan(input);
                case 'Q':
                    return Math.Pow(input, 2);
                case 'R':
                    return Math.Sqrt(input);
                case 'I':
                    return (1 / input);
                default:
                    return double.MaxValue;
            }
        }

        public string MemorijaDisplay(double input, char op)
        {
            switch (op)
            {
                case 'P':
                    memorija = input;
                    return trenutniStatus;
                case 'G':
                    return memorija.ToString();
                case 'C':
                    return "0";
                case 'O':
                    memorija = 0;
                    return "0";
                default:
                    return "0";
            }
        }

        public double Binarna(double in1, double in2, char op)
        {
            switch (op)
            {
                case '+':
                    return in1 + in2;
                case '-':
                    return in1 - in2;
                case '*':
                    return in1 * in2;
                case '/':
                    if(in2 != 0)
                        return in1 / in2;
                    return double.MaxValue;
                default:
                    return double.MaxValue;
            }            
        }

        public bool JednakoProvjera(char iCh)
        {
            if (iCh == '=')
                return true;
            return false;
        }

        public void PostaviZadnjiZnak(char zadnji)
        {
            zadnjiUnesen = zadnji;
        }

        public string Jednako()
        {
            if (BinarnaOperacijaProvjera(zadnjiUnesen))
            {
                return Binarna(double.Parse(trenutniStatus.Remove(trenutniStatus.Length - 1, 1)), double.Parse(trenutniStatus.Remove(trenutniStatus.Length - 1, 1)), trenutniStatus[trenutniStatus.Length-1]).ToString();
            }
            else
            {
                return trenutniStatus;
            }            
        }

        public bool RegularanZnak(char iCh)
        {
            if (iCh == '1' || iCh == '2' || iCh == '3' || iCh == '4' || iCh == '5' || iCh == '6' || iCh == '7' || iCh == '8' || iCh == '9' || iCh == '0' || iCh == '+' || iCh == '-' || iCh == '*' || iCh == '/' || iCh == '=' || iCh == ',' || iCh == 'M' || iCh == 'S' || iCh == 'K' || iCh == 'T' || iCh == 'Q' || iCh == 'R' || iCh == 'I' || iCh == 'P' || iCh == 'G' || iCh == 'C' || iCh == 'O')
                return true;
            return false;
        }

        public bool RegularanBroj(char iCh)
        {
            if (iCh == '1' || iCh == '2' || iCh == '3' || iCh == '4' || iCh == '5' || iCh == '6' || iCh == '7' || iCh == '8' || iCh == '9' || iCh == '0')
                return true;
            return false;
        }

        public bool UnarnaOperacijaProvjera(char iCh)
        {
            if (iCh == ',' || iCh == 'M' || iCh == 'S' || iCh == 'K' || iCh == 'T' || iCh == 'Q' || iCh == 'R' || iCh == 'I') 
                return true;
            return false;
        }

        private bool MemorijaDisplayProvjera(char iCh)
        {
            if (iCh == 'P' || iCh == 'G' || iCh == 'C' || iCh == 'O')
                return true;
            return false;
        }

        public bool BinarnaOperacijaProvjera(char iCh)
        {
            if (iCh == '+' || iCh == '-' || iCh == '*' || iCh == '/')
                return true;
            return false;
        }


        public void KreiranjeStringa(char iCh)
        {
            double brojKonverz;
            // nula
            if (trenutniStatus.Equals("0"))
            {
                if (iCh == '0')
                {
                    trenutniStatus = "0";
                    PostaviZadnjiZnak('0');
                }
                else if (RegularanBroj(iCh))
                {
                    trenutniStatus = iCh.ToString();
                    PostaviZadnjiZnak(iCh);
                }
                else if (UnarnaOperacijaProvjera(iCh))
                {
                    trenutniStatus = Unarna((double)0, iCh).ToString();
                    PostaviZadnjiZnak(iCh);
                }
                else if (BinarnaOperacijaProvjera(iCh))
                {
                    trenutniStatus = "0";
                    PostaviZadnjiZnak(iCh);
                }
                else if (MemorijaDisplayProvjera(iCh))
                {
                    trenutniStatus = (MemorijaDisplay(0, iCh));
                    PostaviZadnjiZnak('0');
                }
                else if (JednakoProvjera(iCh))
                {
                    trenutniStatus = "0";
                    PostaviZadnjiZnak('0');
                }
            }

            // broj 
            else if (double.TryParse(trenutniStatus, out brojKonverz)) 
            {
                if (RegularanBroj(iCh) || BinarnaOperacijaProvjera(iCh))
                {
                    // ako je druga po redu binarna izračun dodati!!!
                    trenutniStatus += iCh.ToString();
                    PostaviZadnjiZnak(iCh);
                }
                else if (UnarnaOperacijaProvjera(iCh))
                {
                    trenutniStatus = Unarna(brojKonverz, iCh).ToString();
                    PostaviZadnjiZnak(iCh);
                }
                else if (MemorijaDisplayProvjera(iCh))
                {
                    trenutniStatus = MemorijaDisplay(brojKonverz, iCh);
                    PostaviZadnjiZnak(iCh);
                }
                else if (JednakoProvjera(iCh))
                {
                    trenutniStatus = Jednako();
                }
            }

            //broj pa zarez
            /*else if ()
            {
            }
            */

            // broj pa binarna operacija
            else if (BinarnaOperacijaProvjera(zadnjiUnesen))
            {
                if (JednakoProvjera(iCh))
                {
                    trenutniStatus = Jednako();
                }
                else if (RegularanBroj(iCh))
                {
                    trenutniStatus += iCh.ToString();
                    PostaviZadnjiZnak(iCh);
                }
                else if (BinarnaOperacijaProvjera(iCh))
                {
                    // remove last, add last

                    trenutniStatus.Remove(trenutniStatus.Length -1, 1);
                    
                    trenutniStatus += iCh.ToString();
                }
            }

        }
              
        public void Press(char inPressedDigit)
        {
            if (RegularanZnak(inPressedDigit))
            {
                KreiranjeStringa(inPressedDigit);
                //trenutniStatus += inPressedDigit.ToString();
            }
        }

        public string GetCurrentDisplayState()
        {
            return trenutniStatus;
        }
    }


}
