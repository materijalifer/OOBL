﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char[] numberChar = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        private char[] unaryOperatorChar = new char[] { 'S', 'K', 'T', 'Q', 'R', 'I', 'M' };
        private char[] binaryOperatorChar = new char[] { '+', '-', '*', '/' };
        private char[] controlOperatorChar = new char[] { 'O', 'C', ',', 'P', 'G' };

        Operator numberOperator = new NumberOperator();
        Operator unaryOperator = new UnaryOperator();
        Operator binaryOperator = new BinaryOperator();
        Operator controlOperator = new ControlOperator();
        CalculatorState state = new CalculatorState();

        
        public void Press(char inPressedDigit)
        {
            // unesen kontrolni znak
            if (controlOperatorChar.Contains(inPressedDigit))
            {
                state = controlOperator.Calculate(inPressedDigit, state);
            }

            // unesen broj
            else if (numberChar.Contains(inPressedDigit))
            {
                state = numberOperator.Calculate(inPressedDigit, state);
            }

            // unesen binarni operator
            else if (binaryOperatorChar.Contains(inPressedDigit))
            {
                state = binaryOperator.Calculate(inPressedDigit, state);
            }

            else if ( inPressedDigit == '=' && binaryOperatorChar.Contains(state.CurrentBinaryOperator))
            {
                state = binaryOperator.Calculate(inPressedDigit, state);
            }

            // unesen unarni operator
            else if (unaryOperatorChar.Contains(inPressedDigit))
            {
                state = unaryOperator.Calculate(inPressedDigit, state);
            }
            else if (inPressedDigit == '=')
            {
                state.CurrentBinaryOperator = '\0';
                state.ResultString = string.Empty;
                state.ResultValue = 0;
            }
        }

        public string GetCurrentDisplayState()
        {
            return state.CurrentDisplayString;
        }
    }

    public class CalculatorState
    {
        public string CurrentDisplayString { get; set; }
        public double CurrentDisplayValue { get; set; }
        public double CalculatorMemory { get; set; }

        public string ResultString { get; set; }
        public double ResultValue { get; set; }

        public char CurrentBinaryOperator { get; set; }
        public char CurrentUnaryOperator { get; set; }

        public CalculatorState() 
        {
            this.CalculatorMemory = 0;
            this.CurrentDisplayString = "0";
            this.CurrentDisplayValue = 0;
            this.ResultString = string.Empty;
            this.ResultValue = 0;
            this.CurrentBinaryOperator = this.CurrentUnaryOperator = '\0';
        }
    }

    public abstract class Operator
    {
        public abstract CalculatorState Calculate(char pressedDigit, CalculatorState state);

        public string DisplayRound(double value)
        {
            string valueString = value.ToString();
            int length = valueString.Length;
            int commaIndex, roundDigitCount;

            if (value < 0)
            {
                if (valueString.Contains(',') && length > 12)
                {
                    commaIndex = valueString.IndexOf(',');
                    roundDigitCount = 11 - commaIndex;
                    if (roundDigitCount >= 0)
                    {
                        value = Math.Round(value, roundDigitCount);
                        return value.ToString();
                    }
                    else
                    {
                        return "-E-";
                    }
                }
                else if (!valueString.Contains(',') && length > 11)
                {
                    return "-E-";
                }
                else
                {
                    return valueString;
                }
            }
            else if (value > 0)
            {
                if (valueString.Contains(',') && length > 11)
                {
                    commaIndex = valueString.IndexOf(',');
                    roundDigitCount = 10 - commaIndex;
                    if (roundDigitCount >= 0)
                    {
                        value = Math.Round(value, roundDigitCount);
                        return value.ToString();
                    }
                    else
                    {
                        return "-E-";
                    }
                }
                else if (!valueString.Contains(',') && length > 10)
                {
                    return "-E-";
                }
                else
                {
                    return valueString;
                }
            }
            else
            {
                return valueString;
            }
        }
    }

    public class NumberOperator : Operator
    {
        public override CalculatorState Calculate(char pressedDigit, CalculatorState state)
        {
            state.ResultString += pressedDigit;
            state.CurrentDisplayValue = Convert.ToDouble(state.ResultString);
            state.CurrentDisplayString = Convert.ToString(state.CurrentDisplayValue);
            return state;
        }
    }

    public class ControlOperator : Operator
    {
        public override CalculatorState Calculate(char pressedDigit, CalculatorState state)
        {
            if (pressedDigit == ',')
            {
                if (state.ResultString.Contains(','))
                {
                    return state;
                }
                else
                {
                    state.ResultString += ',';
                    return state;
                }
            }
            else if (pressedDigit == 'C')
            {
                state.CurrentDisplayValue = 0;
                state.CurrentDisplayString = "0";
                state.ResultString = string.Empty;
                return state;
            }
            else if (pressedDigit == 'O')
            {
                return new CalculatorState();
            }
            else if (pressedDigit == 'P')
            {
                state.CalculatorMemory = state.CurrentDisplayValue;
                return state;
            }
            else if (pressedDigit == 'G')
            {
                state.CurrentDisplayValue = state.CalculatorMemory;
                state.CurrentDisplayString = Convert.ToString(state.CurrentDisplayValue);
                state.ResultString = string.Empty;
                return state;
            }
            else
            {
                throw new ArgumentException();
            }
        }
    }

    public class UnaryOperator : Operator
    {
        public override CalculatorState Calculate(char pressedDigit, CalculatorState state)
        {
            state.CurrentUnaryOperator = pressedDigit;
            if (pressedDigit == 'I' && state.CurrentDisplayValue == 0)
            {
                state.CurrentDisplayString = "-E-";
                return state;
            }

            state.CurrentDisplayValue = unaryOperation(state.CurrentDisplayValue, state.CurrentUnaryOperator);

            if (DisplayRound(state.CurrentDisplayValue) == "-E-")
            {
                state.CurrentDisplayString = "-E-";
                return state;
            }
            state.CurrentDisplayValue = Convert.ToDouble(DisplayRound(state.CurrentDisplayValue));
            state.CurrentDisplayString = Convert.ToString(state.CurrentDisplayValue);

            if (pressedDigit == 'M')
            {
                state.ResultString = state.CurrentDisplayString;
            }

            return state;
        }

        private double unaryOperation(double currentValue, char operatorChar)
        {
            switch (operatorChar)
            {
                case 'S':
                    currentValue = Math.Sin(currentValue);
                    break;
                case 'K':
                    currentValue = Math.Cos(currentValue);
                    break;
                case 'T':
                    currentValue = Math.Tan(currentValue);
                    break;
                case 'Q':
                    currentValue = Math.Pow(currentValue, 2);
                    break;
                case 'R':
                    currentValue = Math.Sqrt(currentValue);
                    break;
                case 'I':
                    currentValue = 1 / currentValue;
                    break;
                case 'M':
                    currentValue = currentValue * (-1);
                    break;
                default:
                    throw new ArgumentException();
            }
            return currentValue;
        }
    }

    public class BinaryOperator : Operator
    {
        public override CalculatorState Calculate(char pressedDigit, CalculatorState state)
        {
            if (pressedDigit != '=')
            {
                if (state.ResultValue != 0 && state.ResultString.Length > 0)
                {
                    state.ResultValue = binaryOperation(state.ResultValue, state.CurrentDisplayValue, state.CurrentBinaryOperator);
                    if (DisplayRound(state.ResultValue) == "-E-")
                    {
                        state.CurrentDisplayString = "-E-";
                        return state;
                    }
                    state.ResultValue = Convert.ToDouble(DisplayRound(state.ResultValue));
                    state.CurrentDisplayValue = state.ResultValue;
                    state.CurrentDisplayString = Convert.ToString(state.CurrentDisplayValue);
                    state.CurrentBinaryOperator = pressedDigit;
                    state.ResultString = string.Empty;
                    return state;
                }
                else
                {
                    state.CurrentBinaryOperator = pressedDigit;
                    if (DisplayRound(state.CurrentDisplayValue) == "-E-")
                    {
                        state.CurrentDisplayString = "-E-";
                        return state;
                    }
                    state.ResultValue = Convert.ToDouble(DisplayRound(state.CurrentDisplayValue));
                    state.ResultString = string.Empty;
                    return state;
                }
            }
            else
            {
                if (state.CurrentDisplayValue == 0 && state.CurrentBinaryOperator == '/')
                {
                    state.CurrentDisplayString = "-E-";
                    return state;
                }

                state.ResultValue = binaryOperation(state.ResultValue, state.CurrentDisplayValue, state.CurrentBinaryOperator);
                state.CurrentDisplayValue = state.ResultValue;

                if (DisplayRound(state.CurrentDisplayValue) == "-E-")
                {
                    state.CurrentDisplayString = "-E-";
                    return state;
                }

                state.CurrentDisplayValue = Convert.ToDouble(DisplayRound(state.CurrentDisplayValue));
                state.CurrentDisplayString = Convert.ToString(state.CurrentDisplayValue);
                state.ResultValue = 0;
                state.ResultString = string.Empty;
                state.CurrentBinaryOperator = '\0';
                return state;
            }
        }

        private double binaryOperation(double stateResultValue, double currentValue, char operatorChar)
        {
            switch (operatorChar)
            {
                case '+':
                    stateResultValue += currentValue;
                    break;
                case '-':
                    stateResultValue -= currentValue;
                    break;
                case '*':
                    stateResultValue *= currentValue;
                    break;
                case '/':
                    stateResultValue /= currentValue;
                    break;
                default:
                    throw new ArgumentException();
            }
            return stateResultValue;
        }
    }
}
