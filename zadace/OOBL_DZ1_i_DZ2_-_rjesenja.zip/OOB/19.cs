﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class OvoJeImeMogKalkulatora:ICalculator
    {
        string display = "0";//Ekran kalkulatora
        double desni = 0;       //desni operator kod racunanja
        double memory = 0;
        double lijevi = 0;     //lijevi operator kod racunanja
        double temp = 0;    //pomocni operator kod racunanja(unarne oper)
        char binOperator = '\0'; //+,-,*,/

        int control1 = 0;      //(ne)pokretanje operacije pritiskim na bin. operator-> 2+3+ 
        int control2 = 2;      //kontrolira citanje 2. operatora s displaya->unos '='
        int p = 0;            //pom varijabla kod izracuna

        bool decZarez = false;//aktiviran zarez
        bool enableDecZarez = true; //da se ne bi 2 put mogao utipkati zarez
        bool operacija = false;//pritisnuta tipka za bin. binOperator
        bool unarniOperGotov = false;
        bool binarniGotov = false;

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    toDisplay(inPressedDigit);
                    break;
                case '=':
                    p = 0;
                    izracunaj();
                    binarniGotov = true;
                    break;
                case '+':
                case '-':
                case '*':
                case '/':
                    binarnaOP(inPressedDigit);
                    break;
                case 'M':
                    suprotanPredznak();
                    break;
                case ',':
                    decZar();
                    break;
                case 'P':
                    memory = double.Parse(display);
                    break;
                case 'G':
                    display = memory.ToString();
                    break;
                case 'Q':
                    kvadrat();
                    break;
                case 'R':
                    korjen();
                    break;
                case 'S':
                    sinus();
                    break;
                case 'K':
                    kosinus();
                    break;
                case 'T':
                    tangens();
                    break;
                case 'I':
                    inverz();
                    break;
                case 'C':
                    display = "0";
                    break;
                case 'O':
                    display = "0";
                    memory = desni = lijevi = p = control1 = 0;
                    control2 = 2;
                    enableDecZarez = true;
                    binOperator = '\0';
                    decZarez = operacija = binarniGotov = unarniOperGotov = false;
                    break;
                default:
                    break;
            }
        }

        private void izracunaj()
        {
            if (control2 == 2)
                desni = double.Parse(display);
            switch (binOperator)
            {
                case '+':
                    lijevi += desni;
                    break;
                case '-':
                    lijevi = lijevi - desni;
                    break;
                case '*':
                    lijevi *= desni;
                    break;
                case '/':
                    lijevi = lijevi / desni;
                    break;
                default:
                    lijevi = desni;
                    break;
            }

            if (!unarniOperGotov || control2 == 2)
            {
                display = lijevi.ToString();
                checkResult(lijevi);
            }
            operacija = false;
            control1 = 1;
            control2 = 1;
        }

        private void binarnaOP(char binOP)
        {
            control2 = 2;
            if (p == 0)//prvi ulaz
            {
                control1 = 1;
                p = 1;
                decZarez = false;
                enableDecZarez = true;
                lijevi = desni = double.Parse(display);
            }
            if (control1 == 2)
            {
                //if (operacijaCeka)//slucaj 1+2+
                izracunaj();

                lijevi = desni = double.Parse(display);
                decZarez = false;
                enableDecZarez = true;
            }
            binOperator = binOP;
            operacija = true; //pritisnut bin.binOperator
        }

        private void sinus()
        {
            temp = Math.Sin(double.Parse(display));
            obavljenUnarni();
            checkResult(temp);
        }

        private void kosinus()
        {
            temp = Math.Cos(double.Parse(display));
            obavljenUnarni();
            checkResult(temp);
        }

        private void tangens()
        {
            temp = Math.Tan(double.Parse(display));
            obavljenUnarni();
            checkResult(temp);
        }

        private void inverz()
        {
            temp = 1 / (double.Parse(display));
            obavljenUnarni();
            checkResult(temp);
        }

        private void korjen()
        {
            temp = Math.Sqrt(double.Parse(display));
            obavljenUnarni();
            checkResult(temp);
        }

        private void kvadrat()
        {
            temp = Math.Pow(double.Parse(display), 2);
            obavljenUnarni();
            checkResult(temp);
        }

        private void obavljenUnarni()
        {
            control1 = 2;
            control2 = 2;
            unarniOperGotov = true;
        }

        private void suprotanPredznak()
        {
            desni = double.Parse(display);
            desni = -desni;
            display = desni.ToString();
        }

        private void decZar()
        {
            if (enableDecZarez)
            {
                decZarez = true;
                enableDecZarez = false;
            }
            if (operacija)
                display = "0";
        }

        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        private void toDisplay(char digit) //saljemo znamenku na display
        {
            control2 = 2;
            if (operacija && !decZarez)//pritisnuta tipka binarnog operatora
            {
                display = "";
                operacija = false;
                enableDecZarez = true;
                control1 = 2;
            }
            if (unarniOperGotov)//izracunat unarni operator
            {
                display = "";
                unarniOperGotov = false;
                enableDecZarez = true;
            }
            if (binarniGotov)//izracunat binarni operator
            {
                display = "";
                binarniGotov = false;
                enableDecZarez = true;
                control1 = 1;
            }
            if (decZarez)//ako je prethodno pritisnut zarez i njega dodajemo
            {
                display += "," + digit;
                decZarez = false;
            }
            else//inace samo provjerimo da li je vodec na displayu "0"
            {
                if (display.CompareTo("0") == 0)
                    display = digit.ToString();
                else
                    display += digit;
            }
            checkDisplayAdd();//da li smo izasli iz opsega displaya            
        }

        private void checkDisplayAdd() //provjeravamo da li je prekoracena duljina displaya
        {
            int pom = 0;
            foreach (char c in display)
            {
                if (Char.IsDigit(c))
                    pom++;
            }

            if (pom > 10) //ako je vise od 10 znamenki odbacimo zadanju dodanu(11.dodanu)
            {
                display = display.Remove(display.Length - 1);
                if (display[display.Length - 1].Equals(','))//pazimo da ne ostane zarez visiti
                    display = display.Remove(display.Length - 1);
            }
        }

        private void checkResult(double rezultat)//provjeravamo da li rezultat stane na display
        {
            if (double.IsInfinity(rezultat))//dijeljenje s nulom
                display = "-E-";
            else
                display = rezultat.ToString();

            int brojZnamenki = 0;

            foreach (char c in display)//pobrojimo znamenke
            {
                if (Char.IsDigit(c))
                    brojZnamenki++;
            }

            if (brojZnamenki > 10) //ako je vise od 10 znamenki
            {
                if (display.Contains(',')) //zaokuzujemo ako je su decimale problem
                {
                    if (display[0].Equals('-')) //odredimo gdje je zarez tj koliko imamo decimala
                        brojZnamenki = display.IndexOf(',') - 1;
                    else
                        brojZnamenki = display.IndexOf(',');

                    if (brojZnamenki < 11)//jesu li SAMO decimale problem, ako da odbacimo ih
                        display = Math.Round(rezultat, 10 - brojZnamenki).ToString();
                    else
                        display = "-E-";
                }
                else //rezultat je 11+znamenki :(
                    display = "-E-";
            }
        }
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
     {
         // vratiti kalkulator
         return new OvoJeImeMogKalkulatora();
     } 
    }
}

