﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock
     {
         public string stockName { get; set; }
         public long numberOfShares { get; set; }
         public long availableShares { get; set; }
         public List<Price> prices = new List<Price>();

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             stockName = inStockName.ToLower();
             numberOfShares = inNumberOfShares;
             availableShares = inNumberOfShares;
             prices.Add(new Price(inInitialPrice, inTimeStamp));
         }
     }

     public class Price
     { 
         public decimal price { get; set; }
         public DateTime timeStamp { get; set; } 

         public Price(decimal inPrice, DateTime inTimeStamp)
         {
             price = inPrice;
             timeStamp = inTimeStamp;
         }
     }

     public class Index
     {
         public string indexName { get; set; }
         public IndexTypes indexType { get; set; }
         public List<Stock> stocks = new List<Stock>();

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             indexName = inIndexName.ToLower();
             indexType = inIndexType;
         }
     }

     public class Portfolio
     {
         public string portfolioID { get; set; }
         public Dictionary<Stock, int> stockShares = new Dictionary<Stock,int>();

         public Portfolio(string inPortfolioID)
         {
             portfolioID = inPortfolioID;
         }
     }

     public class StockExchangeModel
     {
         static StockExchangeModel instance;
         private StockExchangeModel() { }

         public List<Stock> stocks = new List<Stock>();
         public List<Index> indices = new List<Index>();
         public List<Portfolio> portfolios = new List<Portfolio>();

         static public void refresh()
         {
             instance = new StockExchangeModel();
         }
         static public StockExchangeModel get()
         {
             if (instance == null)
                 instance = new StockExchangeModel();
             return instance;
         }
     }

     public class StockExchange : IStockExchange
     {
         public StockExchange()
         {
             StockExchangeModel.refresh();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberOfShares <= 0 || inInitialPrice <= 0 || StockExists(inStockName))
                 throw new StockExchangeException("greska");

             StockExchangeModel.get().stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             Stock stock;
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             StockExchangeModel.get().stocks.Remove(stock);
             foreach (Index i in StockExchangeModel.get().indices)
                 i.stocks.Remove(stock);
             foreach (Portfolio p in StockExchangeModel.get().portfolios)
                 p.stockShares.Remove(stock);
         }

         public bool StockExists(string inStockName)
         {
             return StockExchangeModel.get().stocks.Exists(s => s.stockName == inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return StockExchangeModel.get().stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock;
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null || inStockValue <= 0)
                 throw new StockExchangeException("greska");
             if (stock.prices.Find(p => p.timeStamp == inIimeStamp) != null)
                 throw new StockExchangeException("greska");

             stock.prices.Add(new Price(inStockValue, inIimeStamp));
             stock.prices = stock.prices.OrderBy(p => p.timeStamp).ToList();
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock;
             Price price;
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if ((price = stock.prices.FindLast(p => p.timeStamp <= inTimeStamp)) == null)
                 throw new StockExchangeException("greska");

             return decimal.Round(price.price, 3);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock;
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             return decimal.Round(stock.prices.First().price, 3);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock;
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             return decimal.Round(stock.prices.Last().price, 3);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName) || (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED))
                 throw new StockExchangeException("greska");

             StockExchangeModel.get().indices.Add(new Index(inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index;
             Stock stock;
             if ((index = StockExchangeModel.get().indices.Find(i => i.indexName == inIndexName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if (index.stocks.Contains(stock))
                 throw new StockExchangeException("greska");

             index.stocks.Add(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index;
             Stock stock;
             if ((index = StockExchangeModel.get().indices.Find(i => i.indexName == inIndexName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if ((stock = index.stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             index.stocks.Remove(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index;
             if ((index = StockExchangeModel.get().indices.Find(i => i.indexName == inIndexName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             return index.stocks.Exists(s => s.stockName == inStockName.ToLower());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index;
             Decimal sum = 0;
             if ((index = StockExchangeModel.get().indices.Find(i => i.indexName == inIndexName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             if (index.indexType == IndexTypes.AVERAGE)
             {
                 foreach (Stock s in index.stocks)
                     sum += GetStockPrice(s.stockName, inTimeStamp);
                 return decimal.Round(sum / index.stocks.Count, 3);
             }
             else
             {
                 Decimal total = 0;
                 foreach (Stock s in index.stocks)
                     total += GetStockPrice(s.stockName, inTimeStamp) * s.numberOfShares;
                 foreach (Stock s in index.stocks)
                 {
                     Decimal price = GetStockPrice(s.stockName, inTimeStamp);
                     sum += price * (price * s.numberOfShares / total);
                 }
                 return decimal.Round(sum, 3);
             }
         }

         public bool IndexExists(string inIndexName)
         {
             return StockExchangeModel.get().indices.Exists(i => i.indexName == inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return StockExchangeModel.get().indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index;
             if ((index = StockExchangeModel.get().indices.Find(i => i.indexName == inIndexName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             return index.stocks.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("greska");

             StockExchangeModel.get().portfolios.Add(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio;
             Stock stock;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if (numberOfShares <= 0)
                 throw new StockExchangeException("greska");

             if (numberOfShares > stock.availableShares)
             {
                 numberOfShares = (int)stock.availableShares;
             }
             stock.availableShares -= numberOfShares;
             if (portfolio.stockShares.Keys.Contains(stock))
                 portfolio.stockShares[stock] += numberOfShares;
             else
                 portfolio.stockShares[stock] = numberOfShares;
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio;
             Stock stock;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if (!portfolio.stockShares.Keys.Contains(stock))
                 throw new StockExchangeException("greska");
             if (numberOfShares <= 0)
                 throw new StockExchangeException("greska");

             if (portfolio.stockShares[stock] <= numberOfShares)
             {
                 stock.availableShares += portfolio.stockShares[stock];
                 portfolio.stockShares.Remove(stock);
             }
             else
             {
                 stock.availableShares += numberOfShares;
                 portfolio.stockShares[stock] -= numberOfShares;
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio;
             Stock stock;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");
             if (!portfolio.stockShares.Keys.Contains(stock))
                 throw new StockExchangeException("greska");

             portfolio.stockShares.Remove(stock);
         }

         public int NumberOfPortfolios()
         {
             return StockExchangeModel.get().portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");

             return portfolio.stockShares.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return StockExchangeModel.get().portfolios.Exists(p => p.portfolioID == inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio;
             Stock stock;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 return false;

             return portfolio.stockShares.Keys.Contains(stock);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio;
             Stock stock;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if ((stock = StockExchangeModel.get().stocks.Find(s => s.stockName == inStockName.ToLower())) == null)
                 throw new StockExchangeException("greska");

             if (!portfolio.stockShares.Keys.Contains(stock))
                 return 0;

             return portfolio.stockShares[stock];
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");

             decimal sum = 0;
             foreach (Stock s in portfolio.stockShares.Keys)
             {
                 sum += GetStockPrice(s.stockName, timeStamp) * portfolio.stockShares[s];
             }
             return decimal.Round(sum, 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio;
             if ((portfolio = StockExchangeModel.get().portfolios.Find(p => p.portfolioID == inPortfolioID)) == null)
                 throw new StockExchangeException("greska");
             if (Month > 12 || Month < 1)
                 throw new StockExchangeException("greska");

             decimal start = GetPortfolioValue(portfolio.portfolioID, new DateTime(Year, Month, 1, 0, 0, 0));
             decimal end = GetPortfolioValue(portfolio.portfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

             return decimal.Round((end / start - 1) * 100, 3);
         }
     }
}
