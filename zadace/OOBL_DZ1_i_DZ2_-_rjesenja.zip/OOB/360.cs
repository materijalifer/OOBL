﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
 
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         StockRepository _stock=new StockRepository();
         IndexRepository _index=new IndexRepository();
         PortfolioRepository _portfolio = new PortfolioRepository();
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _stock.Add(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp);
         }

         public void DelistStock(string inStockName)
         {
             bool stockExists = _stock.Exists(inStockName);
             if (stockExists != true)
             {
                 throw new StockExchangeException("Nepostoji dionica s tim imenom");
             }
             else
             {
                 Stock stock = _stock.GetStock(inStockName);
                 _stock.Delete(inStockName);
                 //brisanje dionice iz portfolia i iz indeksa
                 _portfolio.RemoveStockFromAllPortfolios(stock);
                 _index.RemoveStockFromAllIndexs(stock);
             }
         }

         public bool StockExists(string inStockName)
         {
             return _stock.Exists(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stock.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             _stock.SetStockPrice(inStockName,inIimeStamp,inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return _stock.GetStockPrice(inStockName, inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return _stock.GetInitialStockPrice(inStockName);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return _stock.GetLastStockPrice(inStockName);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             _index.Add(inIndexName,inIndexType);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stockForIndex = _stock.GetStock(inStockName);
             if (stockForIndex == null)
             {
                 throw new StockExchangeException("Nemože se dodati nepostojeća dionica");
             }
             else
             {
                 this._index.AddStockToIndex(inIndexName,stockForIndex);
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Stock stockForIndex = _stock.GetStock(inStockName);
             if (stockForIndex == null)
             {
                 throw new StockExchangeException("Nemože se dodati nepostojeća dionica");
             }
             else
             {
                 this._index.RemoveStockFromIndex(inIndexName, stockForIndex);
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Stock stockForIndex = _stock.GetStock(inStockName);
             if (stockForIndex == null)
             {
                 throw new StockExchangeException("Nemože se dodati nepostojeća dionica");
             }
             else
             {
                 return _index.IsStockPartOfIndex(inIndexName, stockForIndex);
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return _index.GetIndexValue(inIndexName, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _index.Exist(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _index.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _index.NumberOfStocksInIndex(inIndexName);
         }

         public void CreatePortfolio(string inPortfolioId)
         {
             this._portfolio.Create(inPortfolioId);
         }

         public void AddStockToPortfolio(string inPortfolioId, string inStockName, int numberOfShares)
         {
             Stock stock = this._stock.GetStock(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("nepostoji dionica");
             }
             else
             {
                this._portfolio.AddStockToPortfolio(inPortfolioId, stock, numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioId, string inStockName, int numberOfShares)
         {
             Stock stock = this._stock.GetStock(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("nepostoji dionica");
             }
             else
             {
                 this._portfolio.RemoveStockFromPortfolio(inPortfolioId, stock, numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioId, string inStockName)
         {
             Stock stock = this._stock.GetStock(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("nepostoji dionica");
             }
             else
             {
                 this._portfolio.RemoveStockFromPortfolio(inPortfolioId, stock);
             }
        }

         public int NumberOfPortfolios()
         {
            return this._portfolio.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioId)
         {
            return this._portfolio.NumberOfStocksInPortfolio(inPortfolioId);
         }

         public bool PortfolioExists(string inPortfolioId)
         {
            return this._portfolio.Exists(inPortfolioId);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioId, string inStockName)
         {
              Stock stock = this._stock.GetStock(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("nepostoji dionica");
             }
             else
             {
                return this._portfolio.IsStockPartOfPortfolio(inPortfolioId,stock);
             }
             
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioId, string inStockName)
         {
             Stock stock = this._stock.GetStock(inStockName);
             if (stock == null)
             {
                 throw new StockExchangeException("nepostoji dionica");
             }
             else
             {
                 return this._portfolio.NumberOfSharesOfStocksInPortfolio(inPortfolioId, stock);
             }
         }

         public decimal GetPortfolioValue(string inPortfolioId, DateTime timeStamp)
         {
             return this._portfolio.GetPortfolioValue(inPortfolioId, timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioId, int year, int month)
         {
             return this._portfolio.GetPortfolioPercentChangeInValueForMonth(inPortfolioId, year, month);
         }
     }
     class Index
     {
         private string _indexName;
         private IndexTypes _indexTypes;
         private List<Stock> _indexStocks;


         #region constructor
         public Index(string indexName, IndexTypes indexTypes)
         {
             this._indexName = indexName;
             this._indexTypes = indexTypes;
             this._indexStocks = new List<Stock>();
         }
         #endregion

         #region public
         public void addStock(Stock newStock)
         {
             this._indexStocks.Add(newStock);
         }
         #endregion

         #region properties
         public string IndexName
         {
             get { return this._indexName; }
         }
         public IndexTypes IndexType
         {
             get { return this._indexTypes; }
         }

         public List<Stock> Stocks
         {
             get { return _indexStocks; }
         }
         #endregion
     }
     class IndexRepository
     {
         private List<Index> _index = new List<Index>();

         #region public
         public int Count()
         {
             return _index.Count;
         }

         public void Add(string indexName, IndexTypes indexType)
         {
             bool indexExist = Exist(indexName);
             if (indexExist == true)
             {
                 throw new StockExchangeException("Index istog imena već postoji na burzi");
             }
             else
             {
                 Index newIndex = new Index(indexName, indexType);
                 _index.Add(newIndex);
             }

         }

         public bool Exist(string indexName)
         {
             string indexNameLowerCase = indexName.ToLower();
             foreach (Index index in _index)
             {
                 if (indexNameLowerCase == index.IndexName.ToLower())
                 {
                     return true;
                 }
             }
             return false;
         }

         public void AddStockToIndex(string indexName, Stock newStock)
         {
             bool indexExist = Exist(indexName);
             if (indexExist != true)
             {
                 throw new StockExchangeException("Index nepostoji na burzi");
             }
             else
             {
                 Index index = FindIndex(indexName);
                 bool indexHasStock = false;
                 foreach (Stock stock in index.Stocks)
                 {
                     if (stock.StockName.ToLower() == newStock.StockName.ToLower())
                     {
                         indexHasStock = true;
                         break;
                     }
                 }

                 if (indexHasStock == true)
                 {
                     throw new StockExchangeException("Index već ima dionicu");
                 }
                 else
                 {
                     index.addStock(newStock);
                 }
             }

         }

         public void RemoveStockFromIndex(string indexName, Stock newStock)
         {
             bool indexExist = Exist(indexName);
             if (indexExist != true)
             {
                 throw new StockExchangeException("Index nepostoji na burzi");
             }
             else
             {
                 Index index = FindIndex(indexName);
                 bool indexHadStock = false;
                 foreach (Stock stock in index.Stocks)
                 {
                     if (stock.StockName.ToLower() == newStock.StockName.ToLower())
                     {
                         indexHadStock = true;
                         index.Stocks.Remove(stock);
                         break;
                     }
                 }

                 if (indexHadStock == false)
                 {
                     throw new StockExchangeException("Index nemože obrisati dionicu koju nema");
                 }

             }


         }

         public bool IsStockPartOfIndex(string indexName, Stock newStock)
         {
             bool indexExist = Exist(indexName);
             if (indexExist != true)
             {
                 throw new StockExchangeException("Index nepostoji na burzi");
             }
             else
             {
                 Index index = FindIndex(indexName);
                 foreach (Stock stock in index.Stocks)
                 {
                     if (stock.StockName.ToLower() == newStock.StockName.ToLower())
                     {
                         return true;
                     }
                 }
                 return false;
             }
         }

         public int NumberOfStocksInIndex(string indexName)
         {
             bool indexExist = Exist(indexName);
             if (indexExist != true)
             {
                 throw new StockExchangeException("Index nepostoji na burzi");
             }
             else
             {
                 Index index = FindIndex(indexName);
                 return index.Stocks.Count;
             }
         }

         public Decimal GetIndexValue(string indexName, DateTime timeStamp)
         {
             bool indexExist = Exist(indexName);
             Decimal indexValue = 0;
             if (indexExist != true)
             {
                 throw new StockExchangeException("Index nepostoji na burzi");
             }
             else
             {
                 Index index = FindIndex(indexName);
                 switch (index.IndexType)
                 {
                     case IndexTypes.AVERAGE:
                         indexValue = CalculateAverageIndexValue(index, timeStamp);
                         break;
                     case IndexTypes.WEIGHTED:
                         indexValue = CalculateWeightedIndexValue(index, timeStamp);
                         break;
                 }
             }
             return Math.Round(indexValue, 3);
         }

         public void RemoveStockFromAllIndexs(Stock inStock)
         {
             for (int i = 0; i < _index.Count; i++)
             {
                 bool postoji = false;
                 foreach (Stock stock in _index[i].Stocks)
                 {
                     if (stock == inStock)
                     {
                         postoji = true;
                         break;
                     }
                 }
                 if (postoji)
                 {
                     _index[i].Stocks.Remove(inStock);
                 }
             }
         }

         #endregion
         #region private
         private Decimal CalculateAverageIndexValue(Index index, DateTime timeStamp)
         {

             Decimal sumAllStockValue = 0;
             Decimal stockNumber = 0;
             foreach (Stock stock in index.Stocks)
             {
                 sumAllStockValue = sumAllStockValue + stock.GetStockPrice(timeStamp);
                 stockNumber++;
             }
             Decimal averageIndex = 0;
             if (stockNumber == 0)
             {
                 return 0;
             }
             else
             {
                 averageIndex = sumAllStockValue / stockNumber;
             }
             return averageIndex;
         }


         private Decimal CalculateWeightedIndexValue(Index index, DateTime timeStamp)
         {
             Decimal weightIndex = 0;
             Decimal sumAllStockValue = SumAllStockValueInIndex(index, timeStamp);
             foreach (Stock stock in index.Stocks)
             {
                 Decimal sockValue = stock.GetStockPrice(timeStamp);
                 weightIndex = weightIndex + ((stock.SharesNumber * sockValue / sumAllStockValue) * sockValue);
             }
             return weightIndex;
         }

         private Decimal SumAllStockValueInIndex(Index index, DateTime timeStamp)
         {
             Decimal sumAllStockValue = 0;
             foreach (Stock stock in index.Stocks)
             {
                 sumAllStockValue = sumAllStockValue + (stock.SharesNumber * stock.GetStockPrice(timeStamp));
             }
             return sumAllStockValue;
         }

         private Index FindIndex(string indexName)
         {
             string indexNameLowerCase = indexName.ToLower();
             foreach (Index index in _index)
             {
                 if (indexNameLowerCase == index.IndexName.ToLower())
                 {
                     return index;
                 }
             }
             return null;
         }
         #endregion
     }
     class NumberOfSharesOfStocks
     {
         private Stock _stock;
         private int _numberOfOwnedShares;

         #region constructor
         public NumberOfSharesOfStocks(Stock stock, int numberOfOwnedShares)
         {
             this._stock = stock;
             this._numberOfOwnedShares = numberOfOwnedShares;

         }
         #endregion
         #region public
         public void AddNumberOfShares(int numberOfShares)
         {
             if (_stock.SharesNumber < _numberOfOwnedShares + numberOfShares)
             {
                 throw new StockExchangeException("u portfoliu je više udjela u dionici nego što postoji");
             }
             else
             {
                 this._numberOfOwnedShares += numberOfShares;
             }
         }
         public void RemoveNumberOfShares(int numberOfShares)
         {
             if (0 > _numberOfOwnedShares - numberOfShares)
             {
                 throw new StockExchangeException("u portfoliu je negativan broj udjela u dionici");
             }
             else
             {
                 this._numberOfOwnedShares -= numberOfShares;
             }
         }
         #endregion
         #region properties
         public Stock Stock
         {
             get { return this._stock; }
         }
         public int NumberOfOwnedShars
         {
             get { return this._numberOfOwnedShares; }
         }

         #endregion
     }
     class Portfolio
     {
         private string _portfolioName;
         private List<NumberOfSharesOfStocks> _ownedStocks;

         #region constructor
         public Portfolio(string portfolioName)
         {
             this._portfolioName = portfolioName;
             this._ownedStocks = new List<NumberOfSharesOfStocks>();

         }
         #endregion

         #region public
         public void AddShares(Stock stock, int numberOfShares)
         {
             foreach (NumberOfSharesOfStocks numberOfSharesOfStockse in _ownedStocks)
             {
                 if (numberOfSharesOfStockse.Stock == stock)
                 {
                     numberOfSharesOfStockse.AddNumberOfShares(numberOfShares);

                     return;
                 }
             }
             NumberOfSharesOfStocks newShares = new NumberOfSharesOfStocks(stock, numberOfShares);
             this._ownedStocks.Add(newShares);
         }

         public void RemoveShares(Stock stock)
         {
             foreach (NumberOfSharesOfStocks numberOfSharesOfStockse in _ownedStocks)
             {
                 if (numberOfSharesOfStockse.Stock == stock)
                 {
                     this._ownedStocks.Remove(numberOfSharesOfStockse);
                     return;
                 }
             }
             //ako dionica nije izbrisana
             throw new StockExchangeException("Nemoguće izbrisati dionicu koja nije u portfoliu");

         }
         public void RemoveShares(Stock stock, int numberOfShares)
         {
             foreach (NumberOfSharesOfStocks numberOfSharesOfStockse in _ownedStocks)
             {
                 if (numberOfSharesOfStockse.Stock == stock)
                 {
                     numberOfSharesOfStockse.RemoveNumberOfShares(numberOfShares);
                     if (numberOfSharesOfStockse.NumberOfOwnedShars == 0)
                     {
                         this._ownedStocks.Remove(numberOfSharesOfStockse);
                     }
                     return;
                 }
             }
             //ako dionica ne postoji u portfoliu
             throw new StockExchangeException("Nemoguće izbrisati dionicu koja nije u portfoliu");
         }
         public int OwnedStocksCount()
         {
             return this._ownedStocks.Count;
         }
         public int OwnedSharesOfStock(Stock stock)
         {
             foreach (NumberOfSharesOfStocks numberOfSharesOfStockse in _ownedStocks)
             {
                 if (numberOfSharesOfStockse.Stock == stock)
                 {
                     return numberOfSharesOfStockse.NumberOfOwnedShars;
                 }
             }
             return 0;
         }
         public bool HaveStock(Stock stock)
         {
             foreach (NumberOfSharesOfStocks numberOfSharesOfStockse in _ownedStocks)
             {
                 if (numberOfSharesOfStockse.Stock == stock)
                 {
                     return true;
                 }
             }
             return false;
         }
         public Decimal GetPortfolioValue(DateTime timeStamp)
         {
             Decimal portfolioValue = 0;
             foreach (NumberOfSharesOfStocks numberOfShares in _ownedStocks)
             {
                 portfolioValue = portfolioValue +
                 (numberOfShares.Stock.GetStockPrice(timeStamp) * numberOfShares.NumberOfOwnedShars);
             }
             return portfolioValue;
         }

         #endregion

         #region properties
         public string PortfolioName
         {
             get { return this._portfolioName; }
         }

         #endregion
     }
     class PortfolioRepository
     {
         private List<Portfolio> _portfolios = new List<Portfolio>();

         #region public
         public void Create(string portfolioName)
         {
             bool portfolioExists = Exists(portfolioName);
             if (portfolioExists == true)
             {
                 throw new StockExchangeException("portfolio već postoji");
             }
             else
             {
                 Portfolio newPortfolio = new Portfolio(portfolioName);
                 this._portfolios.Add(newPortfolio);
             }
         }

         public bool Exists(string portfolioName)
         {
             foreach (Portfolio portfolio in _portfolios)
             {
                 if (portfolio.PortfolioName == portfolioName)
                 {
                     return true;
                 }
             }
             return false;
         }

         public int Count()
         {
             return this._portfolios.Count;
         }

         public void AddStockToPortfolio(string portfolioName, Stock stock, int numberOfShares)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 portfolio.AddShares(stock, numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string portfolioName, Stock stock)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 portfolio.RemoveShares(stock);
             }
         }

         public void RemoveStockFromPortfolio(string portfolioName, Stock stock, int numberOfShares)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 portfolio.RemoveShares(stock, numberOfShares);
             }
         }

         public int NumberOfStocksInPortfolio(string portfolioName)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 return portfolio.OwnedStocksCount();
             }
         }

         public int NumberOfSharesOfStocksInPortfolio(string portfolioName, Stock stock)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 return portfolio.OwnedSharesOfStock(stock);
             }
         }

         public bool IsStockPartOfPortfolio(string portfolioName, Stock stock)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 return portfolio.HaveStock(stock);
             }
         }

         public Decimal GetPortfolioValue(string portfolioName, DateTime timeStamp)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 Decimal portfolioValue = portfolio.GetPortfolioValue(timeStamp);
                 return Math.Round(portfolioValue, 3);
             }
         }

         public Decimal GetPortfolioPercentChangeInValueForMonth(string portfolioName, int year, int month)
         {
             Portfolio portfolio = FindPortfolio(portfolioName);
             if (portfolio == null)
             {
                 throw new StockExchangeException("nepostoji portfolio");
             }
             else
             {
                 DateTime firstMilisecondOfMonth = new DateTime(year, month, 1, 0, 0, 0, 0);
                 DateTime lastMilisecondOfMonth;
                 if (month < 12)
                 {
                     lastMilisecondOfMonth = new DateTime(year, month + 1, 1, 0, 0, 0, 0).AddMilliseconds(-1);
                 }
                 else
                 {
                     lastMilisecondOfMonth = new DateTime(year + 1, 1, 1, 0, 0, 0, 0).AddMilliseconds(-1);
                 }
                 if (portfolio.OwnedStocksCount() == 0)
                 {
                     return 0;
                 }
                 Decimal portfolioValueAtBeginingOfMonth = portfolio.GetPortfolioValue(firstMilisecondOfMonth);
                 Decimal portfolioValueAtEndOfMonth = portfolio.GetPortfolioValue(lastMilisecondOfMonth);
                 Decimal portfolioPercentChangeInValue = (portfolioValueAtEndOfMonth - portfolioValueAtBeginingOfMonth) / portfolioValueAtBeginingOfMonth * 100;


                 return Math.Round(portfolioPercentChangeInValue, 3);
             }
         }

         public void RemoveStockFromAllPortfolios(Stock inStock)
         {
             for (int i = 0; i < _portfolios.Count; i++)
             {
                 bool postoji = _portfolios[i].HaveStock(inStock);
                 if (postoji)
                 {
                     _portfolios[i].RemoveShares(inStock);
                 }
             }
         }

         #endregion
         #region private
         private Portfolio FindPortfolio(string portfolioName)
         {
             foreach (Portfolio portfolio in _portfolios)
             {
                 if (portfolio.PortfolioName == portfolioName)
                 {
                     return portfolio;
                 }
             }
             return null;
         }
         #endregion
     }
     class Stock
     {
         private string _stockName;
         private long _sharesNumber;
         private StockPriceInTime _initialStockPrice;
         private List<StockPriceInTime> _stockPrice;

         #region constructor
         public Stock(string stockName, long sharesNumber, StockPriceInTime initialStockPrice)
         {
             this._stockName = stockName;
             this._sharesNumber = sharesNumber;
             this._initialStockPrice = initialStockPrice;
             this._stockPrice = new List<StockPriceInTime>();
         }
         #endregion

         #region public
         public void AddStockPrice(StockPriceInTime stockPrice)
         {
             this._stockPrice.Add(stockPrice);
         }

         public Decimal GetInitialStockPrice()
         {
             return _initialStockPrice.StockPrice;
         }

         public Decimal GetLastStockPrice()
         {
             if (this._stockPrice.Count == 0)
             {
                 return this._initialStockPrice.StockPrice;
             }
             else
             {
                 StockPriceInTime lastPrice = this._stockPrice[0];
                 foreach (StockPriceInTime stockPrice in this._stockPrice)
                 {
                     if (lastPrice.TimeStamp > stockPrice.TimeStamp)
                     {
                         lastPrice = stockPrice;
                     }
                 }
                 return lastPrice.StockPrice;
             }
         }

         public bool TimeStampExist(DateTime timeStamp)
         {
             foreach (StockPriceInTime stockTimeStamp in this._stockPrice)
             {
                 if (stockTimeStamp.TimeStamp == timeStamp)
                 {
                     return true;
                 }
             }
             return false;
         }

         public Decimal GetStockPrice(DateTime timeStamp)
         {
             if (this._stockPrice.Count == 0)
             {
                 if (this._initialStockPrice.TimeStamp > timeStamp)
                 {
                     throw new StockExchangeException("Vrijednost dionice je nepoznata");
                 }
                 else
                 {
                     return this._initialStockPrice.StockPrice;
                 }

             }
             else
             {
                 List<StockPriceInTime> stockPriceBeforeTimeStamp = new List<StockPriceInTime>();
                 foreach (StockPriceInTime stockPrice in this._stockPrice)
                 {//naći sve definirane cijene prije zadanog trenutka
                     if (stockPrice.TimeStamp <= timeStamp)
                     {
                         stockPriceBeforeTimeStamp.Add(stockPrice);
                     }
                 }
                 if (stockPriceBeforeTimeStamp.Count == 0)
                 {//ako nije nijedna cijena definirana između početka i traženog trenutka vrati početnu cijenu
                     return this._initialStockPrice.StockPrice;
                 }
                 else
                 {//inače vrati cjenu najbližu traženom vremenu
                     StockPriceInTime stockPriceAtTime = stockPriceBeforeTimeStamp[0];
                     foreach (StockPriceInTime stockPriceInTime in stockPriceBeforeTimeStamp)
                     {
                         if (stockPriceInTime.TimeStamp > stockPriceAtTime.TimeStamp)
                         {
                             stockPriceAtTime = stockPriceInTime;
                         }
                     }
                     return stockPriceAtTime.StockPrice;
                 }
             }
         }
         #endregion

         #region properties
         public string StockName
         {
             get { return this._stockName; }
         }
         public long SharesNumber
         {
             get { return this._sharesNumber; }
         }
         public StockPriceInTime InitialStockPrice
         {
             get { return this._initialStockPrice; }
         }

         #endregion

     }
     static class StockFactory
     {
         public static Stock CreateStock(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
         {
             Validate(numberOfShares, initialPrice);
             StockPriceInTime stockPrice = new StockPriceInTime(timeStamp, initialPrice);
             Stock newStock = new Stock(stockName, numberOfShares, stockPrice);
             return newStock;
         }

         private static void Validate(long numberOfShares, Decimal initialPrice)
         {
             if (numberOfShares <= 0 || initialPrice <= 0)
             {
                 throw new StockExchangeException("Krivi ulaznu podaci");
             }
         }
     }
     class StockPriceInTime
     {//vrijednosti dionice u danom trenutku
         private DateTime _timeStamp;
         private Decimal _stockPrice;

         #region constructor
         public StockPriceInTime(DateTime TimeStamp, Decimal StockPrice)
         {
             this._timeStamp = TimeStamp;
             this._stockPrice = StockPrice;
         }
         #endregion

         #region properties
         public DateTime TimeStamp
         {
             get { return this._timeStamp; }
         }
         public Decimal StockPrice
         {
             get { return this._stockPrice; }
         }
         #endregion

     }
     class StockRepository
     {
         private List<Stock> _stock = new List<Stock>();


         #region public
         public int Count()
         {
             return _stock.Count;
         }

         public bool Exists(string stockName)
         {
             string stockNameLowerCase = stockName.ToLower();
             foreach (Stock stock in _stock)
             {
                 if (stock.StockName.ToLower() == stockNameLowerCase)
                 {
                     return true;
                 }
             }
             return false;
         }

         public void Add(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
         {
             bool stockExists = Exists(stockName);
             if (stockExists == true)
             {
                 throw new StockExchangeException("Već postoji dionica s istim imenom");
             }
             else
             {
                 Stock newStock = StockFactory.CreateStock(stockName, numberOfShares, initialPrice, timeStamp);
                 this._stock.Add(newStock);
             }

         }

         public void Delete(string stockName)
         {
             Stock stock = FindStock(stockName);
             _stock.Remove(stock);

         }

         public void SetStockPrice(string stockName, DateTime timeStamp, Decimal newStockPrice)
         {
             if (newStockPrice <= 0)
             {
                 throw new StockExchangeException("Kriva vrijednost dionice");
             }
             bool stockExists = Exists(stockName);
             if (stockExists != true)
             {
                 throw new StockExchangeException("Nepostoji dionica s tim imenom");
             }
             else
             {
                 Stock stock = FindStock(stockName);
                 StockPriceInTime stockPrice = new StockPriceInTime(timeStamp, newStockPrice);
                 if (stock.InitialStockPrice.TimeStamp >= stockPrice.TimeStamp)
                 {
                     throw new StockExchangeException("Vrijeme nove cijene je prije vremena početne cijene");
                 }
                 bool stockTimeStampExists = stock.TimeStampExist(timeStamp);

                 if (stockTimeStampExists == false)
                 {
                     stock.AddStockPrice(stockPrice);
                 }
                 else
                 {
                     throw new StockExchangeException("Za zadano vrijeme je definirana cijena");
                 }
             }
         }

         public Decimal GetInitialStockPrice(string stockName)
         {
             bool stockExists = Exists(stockName);
             if (stockExists != true)
             {
                 throw new StockExchangeException("Nepostoji dionica s tim imenom");
             }
             else
             {
                 Stock stock = FindStock(stockName);
                 return stock.GetInitialStockPrice();
             }
         }

         public Decimal GetLastStockPrice(string stockName)
         {
             bool stockExists = Exists(stockName);
             if (stockExists != true)
             {
                 throw new StockExchangeException("Nepostoji dionica s tim imenom");
             }
             else
             {
                 Stock stock = FindStock(stockName);
                 return stock.GetLastStockPrice();
             }
         }

         public Decimal GetStockPrice(string stockName, DateTime timeStamp)
         {
             bool stockExists = Exists(stockName);
             if (stockExists == false)
             {
                 throw new StockExchangeException("Nepostoji dionica s tim imenom");
             }
             else
             {
                 Stock stock = FindStock(stockName);
                 return stock.GetStockPrice(timeStamp);
             }
         }

         public Stock GetStock(string stockName)
         {
             string stockNameLowerCase = stockName.ToLower();
             foreach (Stock stock in _stock)
             {
                 if (stock.StockName.ToLower() == stockNameLowerCase)
                 {
                     return stock;
                 }
             }
             return null;
         }

         #endregion
         #region private
         private Stock FindStock(string stockName)
         {

             string stockNameLowerCase = stockName.ToLower();
             foreach (Stock stock in _stock)
             {
                 if (stock.StockName.ToLower() == stockNameLowerCase)
                 {
                     return stock;
                 }
             }
             return null;
         }
         #endregion

     }
}
