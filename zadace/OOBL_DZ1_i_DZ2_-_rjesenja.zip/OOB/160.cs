﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public class Price
    {
        private decimal value;

        public decimal Value
        {
            get { return value; }
            set { this.value = value; }
        }
        private DateTime timeStamp;

        public DateTime TimeStamp
        {
            get { return timeStamp; }
            set { timeStamp = value; }
        }

        public Price(decimal inPrice, DateTime inTimeStamp)
        {
            value = inPrice;
            timeStamp = inTimeStamp;
        }
    }

    public class Stock
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private long numberOfShares;
        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }

        private List<Price> stockPrices = new List<Price>();
        public List<Price> StockPrices
        {
            get { return stockPrices; }
            set { stockPrices = value; }
        }

        public Stock(string inName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            name = inName.ToLower();
            numberOfShares = inNumberOfShares;
            Price newPrice = new Price(inInitialPrice, inTimeStamp);
            stockPrices.Add(newPrice);
        }

        public void SetNewStockPrice(decimal inStockPrice, DateTime inTimeStamp)
        {
            if (IsPriceDefinedForTimestamp(inTimeStamp))
            {
                throw new StockExchangeException("Price is already defined for specified timeStamp!");
            }
            else
            {
                Price newPrice = new Price(inStockPrice, inTimeStamp);
                stockPrices.Add(newPrice);
            }
        }

        public decimal GetPriceByTimeStamp(DateTime inTimeStamp)
        {
            if (stockPrices.Count == 0)
            {
                throw new StockExchangeException("No prices defined for selected stock!");
            }
            DateTime lastPriceDefinition = DateTime.MinValue;
            Price lastDefinedPrice = null;
            foreach (var price in stockPrices)
            {
                if (price.TimeStamp < inTimeStamp && price.TimeStamp > lastPriceDefinition)
                {
                    lastPriceDefinition = price.TimeStamp;
                    lastDefinedPrice = price;
                }
            }
            if (lastDefinedPrice != null)
            {
                return lastDefinedPrice.Value;
            }
            else
            {
                throw new StockExchangeException("Stock price isn't defined for selected timeStamp!");
            }
        }

        public decimal GetInitialPrice()
        {
            if (stockPrices.Count == 0)
            {
                throw new StockExchangeException("No prices defined for selected stock!");
            }
            Price firstDefinedPrice = stockPrices.FirstOrDefault();
            foreach (var price in stockPrices)
            {
                if (price.TimeStamp < firstDefinedPrice.TimeStamp)
                {
                    firstDefinedPrice = price;
                }
            }
            return firstDefinedPrice.Value;
        }

        public decimal GetLastPrice()
        {
            if (stockPrices.Count == 0)
            {
                throw new StockExchangeException("No prices defined for selected stock!");
            }
            Price lastDefinedPrice = stockPrices.FirstOrDefault();
            foreach (var price in stockPrices)
            {
                if (price.TimeStamp > lastDefinedPrice.TimeStamp)
                {
                    lastDefinedPrice = price;
                }
            }
            return lastDefinedPrice.Value;
        }

        public bool IsPriceDefinedForTimestamp(DateTime inTimeStamp)
        {
            foreach (var price in stockPrices)
            {
                if (price.TimeStamp == inTimeStamp)
                {
                    return true;
                }
            }
            return false;
        }

    }

    public class Index
    {
        private IndexTypes type;
        public IndexTypes Type
        {
            get { return type; }
            set { type = value; }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private List<Stock> stocksInIndex = new List<Stock>();
        public List<Stock> StocksInIndex
        {
            get { return stocksInIndex; }
            set { stocksInIndex = value; }
        }

        public Index(string inName, IndexTypes inIndexType)
        {
            name = inName.ToLower();
            type = inIndexType;
        }

        public void AddNewStockToIndex(Stock inStock)
        {
            stocksInIndex.Add(inStock);
        }

        public void RemoveStockFromIndex(Stock inStock)
        {
            stocksInIndex.Remove(inStock);
        }

        public bool IsStockPartOfIndex(string inStockName)
        {
            string inStockNameDowncase = inStockName.ToLower();
            foreach (var stock in stocksInIndex)
            {
                if (stock.Name == inStockNameDowncase)
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfStocksInIndex()
        {
            return stocksInIndex.Count;
        }

        public decimal Value(DateTime inTimeStamp, decimal totalValueOfListedStocks)
        {
            decimal value = 0;
            if (type == IndexTypes.AVERAGE)
            {
                foreach (var stock in stocksInIndex)
                {
                    value += stock.GetPriceByTimeStamp(inTimeStamp);
                }
                value = Math.Round(value / stocksInIndex.Count, 3);
            }
            else if (type == IndexTypes.WEIGHTED)
            {
                foreach (var stock in stocksInIndex)
                {
                    value += (stock.GetPriceByTimeStamp(inTimeStamp) * stock.NumberOfShares / totalValueOfListedStocks) * stock.GetPriceByTimeStamp(inTimeStamp);
                }
                value = Math.Round(value, 3);
            }
            else
            {
                throw new StockExchangeException("Index type isn't valid!");
            }
            return value;
        }
    }

    public class Portfolio
    {
        string portfolioID;
        public string PortfolioID
        {
            get { return portfolioID; }
            set { portfolioID = value; }
        }

        private Dictionary<string, int> stockShares = new Dictionary<string, int>();
        public Dictionary<string, int> StockShares
        {
            get { return stockShares; }
            set { stockShares = value; }
        }

        public Portfolio(string inPortfolioID)
        {
            portfolioID = inPortfolioID;
        }

        public int NumberOfStocksInPortfolio()
        {
            return stockShares.Count;
        }

        public bool IsStockPartOfPortfolio(string inStockName)
        {
            string inStockNameDowncase = inStockName.ToLower();
            foreach (var stock in stockShares)
            {
                if (stock.Key == inStockNameDowncase)
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            string inStockNameDowncase = inStockName.ToLower();
            return stockShares[inStockNameDowncase];
        }

        public void AddStockToPortfolio(string inStockName, int numberOfShares)
        {
            string inStockNameDowncase = inStockName.ToLower();
            if (IsStockPartOfPortfolio(inStockNameDowncase))
            {
                stockShares[inStockNameDowncase] += numberOfShares;
            }
            else
            {
                stockShares.Add(inStockNameDowncase, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inStockName, int numberOfShares)
        {
            string inStockNameDowncase = inStockName.ToLower();
            if (stockShares[inStockNameDowncase] < numberOfShares)
            {
                throw new StockExchangeException("There aren't enough stock shares in portfolio to be removed!");
            }
            stockShares[inStockNameDowncase] -= numberOfShares;
            if (stockShares[inStockNameDowncase] == 0)
            {
                RemoveStockFromPortfolio(inStockNameDowncase);
            }
        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            string inStockNameDowncase = inStockName.ToLower();
            stockShares.Remove(inStockNameDowncase);
        }

        public decimal PortfolioValue(DateTime inTimeStamp, List<Stock> listedStocks)
        {
            decimal value = 0;
            foreach (var stock in listedStocks)
            {
                if (stockShares.ContainsKey(stock.Name))
                {
                    value += stock.GetPriceByTimeStamp(inTimeStamp) * stockShares[stock.Name];
                }
            }
            return value;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month, List<Stock> listedStocks)
        {
            decimal percentageOfValueChange = 0;
            decimal valueAtBegginingOfMonth = Math.Round(PortfolioValue(new DateTime(Year, Month, 1, 00, 00, 00), listedStocks), 3);
            decimal valueAtEndOfMonth = Math.Round(PortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999), listedStocks), 3);
            percentageOfValueChange = Math.Round(100 * (valueAtEndOfMonth - valueAtBegginingOfMonth) / valueAtBegginingOfMonth, 3);
            return percentageOfValueChange;
        }
    }

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stockList = new List<Stock>();
        private List<Index> indexList = new List<Index>();
        private List<Portfolio> portfolioList = new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Stock name must be defined!");
            }
            else if ( StockExists(inStockName) )
            {
                throw new StockExchangeException("Stock with the same name already exists!");
            }
            else if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be positive!");
            }
            else if (inInitialPrice <= 0)
            {
                throw new StockExchangeException("Inital price must be positive!");
            }
            else if (inTimeStamp == null)
            {
                throw new StockExchangeException("TimeStamp must be defined!");
            }
            else
            {
                Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                stockList.Add(newStock);
            }
        }

        public void DelistStock(string inStockName)
        {
            validateStockName(inStockName);
            Stock inStock = getStockByName(inStockName);
            foreach (var index in indexList)
            {
                if (index.IsStockPartOfIndex(inStockName))
                {
                    Stock stockToRemove = getStockByName(inStockName);
                    index.RemoveStockFromIndex(stockToRemove);
                }
            }
            foreach (var portfolio in portfolioList)
            {
                if (portfolio.IsStockPartOfPortfolio(inStock.Name))
                {
                    portfolio.RemoveStockFromPortfolio(inStock.Name);
                }
            }
            stockList.Remove(inStock);
        }

        public bool StockExists(string inStockName)
        {
            foreach (var stock in stockList)
            {
                if (stock.Name == inStockName.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            validateStockName(inStockName);
            if (inStockValue <= 0)
            {
                throw new StockExchangeException("Price must be positive!");
            }
            else if (inIimeStamp == null)
            {
                throw new StockExchangeException("TimeStamp must be defined!");
            }
            Stock inStock = getStockByName(inStockName);
            inStock.SetNewStockPrice(inStockValue, inIimeStamp);
        }

        private Stock getStockByName(string inStockName)
        {
            string inStockNameDowncase = inStockName.ToLower();
            Stock stock = (from s in stockList
                           where s.Name == inStockNameDowncase
                           select s).FirstOrDefault();
            return stock;
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            validateStockName(inStockName);
            if (inTimeStamp == null)
            {
                throw new StockExchangeException("TimeStamp must be defined!");
            }
            Stock inStock = getStockByName(inStockName);
            return inStock.GetPriceByTimeStamp(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            validateStockName(inStockName);
            Stock inStock = getStockByName(inStockName);
            return inStock.GetInitialPrice();
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            validateStockName(inStockName);
            Stock inStock = getStockByName(inStockName.ToLower());
            return inStock.GetLastPrice();
        }

        public decimal TotalValueOfListedStocks(DateTime inTimeStamp)
        {
            decimal value = 0;
            foreach (var stock in stockList)
            {
                value += stock.GetPriceByTimeStamp(inTimeStamp) * stock.NumberOfShares;
            }
            return value;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexName == null)
            {
                throw new StockExchangeException("Index name must be defined!");
            }
            if (!(inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED))
            {
                throw new StockExchangeException("Index type isn't allowed!");
            }
            else
            {
                Index newIndex = new Index(inIndexName, inIndexType);
                indexList.Add(newIndex);
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            validateStockName(inStockName);
            validateIndexName(inIndexName);
            if (IsStockPartOfIndex(inIndexName, inStockName))
            {
                throw new StockExchangeException("Stock already in index!");
            }
            else
            {
                Stock inStock = getStockByName(inStockName);
                Index inIndex = getIndexByName(inIndexName);
                inIndex.AddNewStockToIndex(inStock);
            }
        }

        private Index getIndexByName(string inIndexName)
        {
            string inIndexNameDowncase = inIndexName.ToLower();
            Index index = (from i in indexList
                           where i.Name == inIndexNameDowncase
                           select i).FirstOrDefault();
            return index;
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            validateStockName(inStockName);
            validateIndexName(inIndexName);
            if (!IsStockPartOfIndex(inIndexName, inStockName))
            {
                throw new StockExchangeException("Stock not in index!");
            }
            else
            {
                Stock inStock = getStockByName(inStockName);
                Index inIndex = getIndexByName(inIndexName);
                inIndex.RemoveStockFromIndex(inStock);
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            validateStockName(inStockName);
            validateIndexName(inIndexName);
            Index inIndex = getIndexByName(inIndexName);
            return inIndex.IsStockPartOfIndex(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            validateIndexName(inIndexName);
            if (inTimeStamp == null)
            {
                throw new StockExchangeException("TimeStamp must be defined!");
            }
            Index inIndex = getIndexByName(inIndexName);
            return inIndex.Value(inTimeStamp, TotalValueOfListedStocks(inTimeStamp));
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (var index in indexList)
            {
                if (index.Name == inIndexName.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            validateIndexName(inIndexName);
            Index inIndex = getIndexByName(inIndexName);
            return inIndex.NumberOfStocksInIndex();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Portfolio ID must be defined!");
            }
            else if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio with the same ID already exists!");
            }
            Portfolio newPortfolio = new Portfolio(inPortfolioID);
            portfolioList.Add(newPortfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            validateStockName(inStockName);
            Stock inStock = getStockByName(inStockName);
            validateNumberOfShares(inStock,numberOfShares);
            inPortfolio.AddStockToPortfolio(inStockName, numberOfShares);
        }

        private Portfolio getPortfolioByID(string inPortfolioID)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio portfolio = (from p in portfolioList
                           where p.PortfolioID == inPortfolioID
                           select p).FirstOrDefault();
            return portfolio;

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            validateStockName(inStockName);
            if (!inPortfolio.IsStockPartOfPortfolio(inStockName))
            {
                throw new StockExchangeException("Stock isn't part of portfolio!");
            }
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Number of shares must be positive!");
            }
            inPortfolio.RemoveStockFromPortfolio(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            validateStockName(inStockName);
            if (!inPortfolio.IsStockPartOfPortfolio(inStockName))
            {
                throw new StockExchangeException("Stock isn't part of portfolio!");
            }
            inPortfolio.RemoveStockFromPortfolio(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            return inPortfolio.NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (var portfolio in portfolioList)
            {
                if (portfolio.PortfolioID == inPortfolioID)
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            validateStockName(inStockName);
            return inPortfolio.IsStockPartOfPortfolio(inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            validatePortfolioID(inPortfolioID);
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            validateStockName(inStockName);
            if (!inPortfolio.IsStockPartOfPortfolio(inStockName))
            {
                throw new StockExchangeException("Stock isn't part of portfolio!");
            }
            return inPortfolio.NumberOfSharesOfStockInPortfolio(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            validatePortfolioID(inPortfolioID);
            if (timeStamp == null)
            {
                throw new StockExchangeException("TimeStamp must be defined!");
            }
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            return inPortfolio.PortfolioValue(timeStamp, stockList);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            validatePortfolioID(inPortfolioID);
            if (Year < 0)
            {
                throw new StockExchangeException("Year is not in correct format!");
            }
            if (Month < 1 || Month > 12)
            {
                throw new StockExchangeException("Month is not in correct format!");
            }
            Portfolio inPortfolio = getPortfolioByID(inPortfolioID);
            return inPortfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month, stockList);
        }

        private void validateStockName(string inStockName)
        {
            if (inStockName == null)
            {
                throw new StockExchangeException("Stock name must be defined!");
            }
            else if (!StockExists(inStockName.ToLower()))
            {
                throw new StockExchangeException("Stock doesn't exists!");
            }
        }

        private void validateIndexName(string inIndexName)
        { 
            if (inIndexName == null)
            {
                throw new StockExchangeException("Index name must be defined!");
            }
            else if (!IndexExists(inIndexName.ToLower()))
            {
                throw new StockExchangeException("Index doesn't exists!");
            }

        }

        private void validatePortfolioID(string inPortfolioID)
        {
            if (inPortfolioID == null)
            {
                throw new StockExchangeException("Portfolio ID must be defined!");
            }
            else if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio doesn't exists!");
            }

        }

        private void validateNumberOfShares(Stock inStock, int numberOfShares)
        {
            if (numberOfShares <=0)
            {
                throw new StockExchangeException("Number of shares must be positive!");
            }
            long numberOfSharesInPortfolios = 0;
            foreach (var portfolio in portfolioList)
            {
                if (portfolio.IsStockPartOfPortfolio(inStock.Name))
                {
                    numberOfSharesInPortfolios += portfolio.NumberOfSharesOfStockInPortfolio(inStock.Name);
                }
            }
            if ( (inStock.NumberOfShares - numberOfSharesInPortfolios) < numberOfShares)
            {
                throw new StockExchangeException("There aren't enough free stock shares to be added!");
            }
        }
    }
}
