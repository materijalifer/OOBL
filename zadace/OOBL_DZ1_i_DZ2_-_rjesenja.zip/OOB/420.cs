﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char[] display = new char[12] { '+', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' };
        private Boolean minus = false;
        private int digits = 10;
        private Boolean comma = false;
        private int pos = 1; //nulta pozicija rezervirana za predznak
        private double operand = 0;
        private char? command = null;
        private Boolean equal = false;
        private string memory;
        //private Boolean on = true;
        //private Boolean dcml = false;
        //private int markPos;

        public void Press(char inPressedDigit)
        {

            if (Char.IsNumber(inPressedDigit) && digits > 0)
            {
              
                  addNumber(inPressedDigit);
                  digits--;
            }

            else if (inPressedDigit == ',')
            {
                addComma();
            }

            else if (inPressedDigit == '=')
            {
                equals();

            }

            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                binaryOperator(inPressedDigit);
            }

            else if (Char.IsUpper(inPressedDigit))
            {
                unaryOperator(inPressedDigit);
            }
            else
            {
                return; 
            }

            //throw new NotImplementedException();
        }//end Press

        public string GetCurrentDisplayState()
        {
            if (display[1] == '0' && display[2] == '0')
            {
                return "0";
            }
            else
            {
                if (display[0]=='-')
                {
                    string currentDisplayState = new string(display, 0, pos);
                    return currentDisplayState;
                }
                else
                {
                    string currentDisplayState = new string(display, 1, pos-1);
                    return currentDisplayState;
                }
                }

            throw new NotImplementedException();
        }//end GetCurrentDisplayState

        public void addNumber(char n)
        {
            if (!(pos==1 && n=='0'))
            {
                display[pos] = n;
                pos++;
            }

        }

        public void addComma()
        {
            if (pos==1 && display[1]=='0')
            {
                display[pos+1] = ',';
                pos=pos+2;
            }
            else
            {
                display[pos] = ',';
                pos++;
            }

        }

        public void binaryOperator(char c)
        {
            string s = new string(display, 0, pos); //pos-1???
            operand = Convert.ToDouble(s);
            command = c;
            pos = 1;
            minus = false;
            display[0] = '+';

        }

        public void equals()
        {
            string s = new string(display, 0, pos);
            double operand2 = Convert.ToDouble(s);
            switch (command)
            {
                case '+':
                    {
                        toDisplay(operand + operand2);
                        break;
                    }
                case '-':
                    {
                        toDisplay(operand - operand2);
                        break;
                    }
                case '*':
                    {
                        toDisplay(operand * operand2);
                        break;
                    }
                case '/':
                    {
                        toDisplay(operand / operand2);
                        break;
                    }
                case '\0':
                    {
                        break; 
                    }
            }

                    command = null;
        }

        public void unaryOperator(char c)
        {

            switch (c)
            {
                case 'M': setSign();
                    break;

                case 'S': getSinus();
                    break;

                case 'K': getKosinus();
                    break;

                case 'T': getTangens();
                    break;

                case 'Q': getQuadrat();
                    break;

                case 'R': getRoot();
                    break;

                case 'I': getInvers();
                    break;

                case 'P': setMemory();
                    break;

                case 'G': getMemory();
                    break;

                case 'C': clear();
                    break;

                case 'O': onOff();
                    break;
                default: break; //baciti grešku

            } //end case
        }//end unaryOperator


        public void clear()
        {
            display[0] = '+';
            for (int i = 1; i < 12; i++)
            {
                display[i]='0';
            }
        }

        public void onOff()
        {
            clear();
            operand = 0;
            command = '\0';
            memory = "\0";
        }

        public void getMemory()
        {
            char[] m = memory.ToCharArray();
            int j=1;
            pos = m.Length+1;
            for(int i=0; i<m.Length; i++)
            {
                display[j]=m[i];
                j++;
            }

        }

        public void setMemory()
        {
            memory = new string(display,1,pos-1);
        }

        public void getInvers()
        {
            string s = new string(display, 1, pos - 1);
            toDisplay(Math.Pow(Convert.ToDouble(s), -1));
        }

        public void getRoot()
        {
            string s = new string(display, 1, pos - 1);
            toDisplay(Math.Sqrt(Convert.ToDouble(s)));
        }

        public void getQuadrat()
        {
            string s = new string(display, 1, pos - 1);
            toDisplay(Math.Pow(Convert.ToDouble(s),2));

        }

        public void setSign()
        {
            if (display[0]=='+')
            {
                display[0] = '-';
            }
            else
            {
                display[0] = '+';
            }
        }

        public void getSinus()
        {
            string s = new string(display, 1, pos-1);
            toDisplay(Math.Sin(Convert.ToDouble(s)));
        }

        public void getKosinus()
        {
            string s = new string(display, 1, pos - 1);
            toDisplay(Math.Cos(Convert.ToDouble(s)));
        }

        public void getTangens()
        {
            string s = new string(display, 1, pos - 1);
            toDisplay(Math.Tan(Convert.ToDouble(s)));
        }

        public void toDisplay (double d) {
            String str = d.ToString();
            pos = 12;
            if (d > 0)
            {
                char[] chararray = str.ToCharArray();
                display[0] = '+';
                int j = 1;
                for (int i = 0; i < chararray.Length; i++)
                {
                    display[j] = chararray[i];
                    j++;
                } 
            }
            else
            {
                char[] chararray = str.ToCharArray(0, 12);
                display = chararray;
            }
        }
    
    }//end class Kalkulator


}//end namespace