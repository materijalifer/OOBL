﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private static string unaryOperators = "MSKTQRI";
        private static string binaryOperators = "+-/*=";
        private static string options = "PGOC";


        private string currentDisplayState;
        private double lastValue;
        private string bufferedString;
        private double bufferedValue;
        private bool bufferEmpty;
        private double memory;
        private char operation;

        private bool unaryAfterBinary = false;

        private int numberOfDigits;


        public Kalkulator()
        {
            lastValue = 0.0;
            bufferedValue = 0.0;
            bufferedString = "";
            bufferEmpty = true;
            currentDisplayState = "0";
            memory = 0.0;
            numberOfDigits = 0;
            operation = ' ';
        }



        public void Press(char inPressedDigit)
        {
            if (unaryAfterBinary)
            {
                flushBuffer();
                unaryAfterBinary = false;
            }

            // Ucitavanje brojeva
            if (Char.IsDigit(inPressedDigit))
            {
                // zanemari višestruke nule
                if (bufferedString == "0" && inPressedDigit == '0')
                    return;

                else if (numberOfDigits < 10)
                {
                    bufferedString += inPressedDigit;
                    numberOfDigits++;
                }

                bufferedValue = double.Parse(bufferedString);
                bufferEmpty = false;
            }

            // ne dopustaj visestruke zareze
            else if (inPressedDigit == ',' && !bufferedString.Contains('.') && numberOfDigits < 10)
                bufferedString += ".";

            // pritisnuta je funkcijska tipka
            else if (options.Contains(inPressedDigit))
            {
                handleOptions(inPressedDigit);
            }

            // unesen je unarni operator
            else if (unaryOperators.Contains(inPressedDigit))
            {
                handleUnaryOperation(inPressedDigit);
            }

            // unesen je binarni operator
            else if (binaryOperators.Contains(inPressedDigit))
            {
                handleBinaryOperation(inPressedDigit);
            }
        }

        /// <summary>
        /// Metoda zaduzena za obradu odabranih opcija
        /// </summary>
        /// <param name="inPressedDigit">odabrana opcija</param>
        private void handleOptions(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'P':
                    memory = bufferedValue;
                    break;
                case 'G':
                    lastValue = memory;
                    bufferedString = memory.ToString();
                    break;
                case 'O':
                    clearDisplay();
                    memory = 0.0;
                    lastValue = 0.0;
                    break;
                case 'C':
                    clearDisplay();
                    break;
            }
        }


        /// <summary>
        /// Metoda obradjuje unarne operatore
        /// </summary>
        /// <param name="inPressedDigit">unarni operator</param>
        private void handleUnaryOperation(char inPressedDigit)
        {

            if (bufferEmpty)
            {
                Console.WriteLine("Tu sam");
                bufferedValue = lastValue;
                bufferEmpty = false;
                unaryAfterBinary = true;
            }

            switch (inPressedDigit)
            {
                case 'M':
                    bufferedValue *= -1;
                    break;
                case 'S':
                    bufferedValue = Math.Sin(bufferedValue);
                    break;
                case 'K':
                    bufferedValue = Math.Cos(bufferedValue);
                    break;
                case 'T':
                    bufferedValue = Math.Tan(bufferedValue);
                    break;
                case 'Q':
                    bufferedValue = Math.Pow(bufferedValue, 2.0);
                    break;
                case 'R':
                    bufferedValue = Math.Sqrt(bufferedValue);
                    break;
                case 'I':
                    if (bufferedValue != 0 && !bufferEmpty)
                    {
                        bufferedValue = 1 / bufferedValue;
                    }
                    else
                        currentDisplayState = "-E-";
                    break;
            }
            bufferedString = bufferedValue.ToString();
        }


        /// <summary>
        /// Metoda obradjuje binarne operacije
        /// </summary>
        /// <param name="inPressedDigit">binarni operator</param>
        private void handleBinaryOperation(char inPressedDigit)
        {

            if (inPressedDigit == '=')
            {
                if (bufferEmpty)
                {
                    bufferedValue = lastValue;
                    bufferEmpty = false;
                }
                handleBinaryOperation(' ');
            }
            else
            {
                if(!bufferEmpty)
                    switch (operation)
                    {
                        case '+':
                            lastValue += bufferedValue;
                            break;
                        case '-':
                            lastValue -= bufferedValue;
                            break;
                        case '*':
                            lastValue *= bufferedValue;
                            break;
                        case '/':
                            if (bufferedValue == 0.0)
                                currentDisplayState = "-E-";
                            else
                                lastValue /= bufferedValue;
                            break;
                        case ' ':
                            lastValue = bufferedValue;
                            break;
                    }
            }

            operation = inPressedDigit;

            flushBuffer();

        }

        /// <summary>
        /// Metoda cisti ekran, postavlja ga na 0
        /// </summary>
        private void clearDisplay()
        {
            flushBuffer();
            currentDisplayState = "0";
            bufferEmpty = false;
        }

        /// <summary>
        /// Metoda prazni medjuspremnik
        /// </summary>
        private void flushBuffer()
        {
            bufferedValue = 0.0;
            bufferedString = "0";
            bufferEmpty = true;

            numberOfDigits = 0;
        }

        public string GetCurrentDisplayState()
        {

            if (currentDisplayState != "-E-")
            {

                if (bufferEmpty)
                    currentDisplayState = lastValue.ToString();
                else
                    currentDisplayState = bufferedString;

                formatOutput();

                currentDisplayState = currentDisplayState.Replace('.', ',');
            }
            return currentDisplayState;
        }


        /// <summary>
        /// Metoda se brine o izgledu trnenutnog stanja ekrana.
        /// Ne dopusta vise od 10 znamenki na ekranu i ispisuje gresku 
        /// ukoliko je cjelobrojni dio rezultata dulji od 10 znamenki.
        /// </summary>
        private void formatOutput()
        {
            double temp = double.Parse(currentDisplayState);

            long whole_part = Math.Abs((long)temp);
            int whole_part_length = whole_part.ToString().Length;
            int decimal_part_length = (temp.ToString().Length - 1) - whole_part_length;

            if (whole_part_length <= 10)
            {
                int precision = 10 - whole_part_length;
                if (precision > 0)
                    temp = Math.Round(temp, precision);
                currentDisplayState = temp.ToString().Replace('.', ',');
            }
            else
            {
                currentDisplayState = "-E-";
            }
        }



    }





}
