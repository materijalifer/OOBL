﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    public class Calculator : ICalculator
    {

        Memory memory = new Memory();
        Display display = new Display();

        Function.FunctionDelegate function = null;
        Function.ArithmeticDelegate arithmetic = null;

        public Calculator()
        {
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                this.CheckDisplay();
                if (CharManager.IsDigit(inPressedDigit))
                {
                    
                    //dodaj znamenku na ekran
                    display.AddDigit(inPressedDigit);
                }
                //ako je ulazni znak ,
                else if (CharManager.IsComma(inPressedDigit))
                {
                    
                    //ako na ekranu nema decimalnog znaka, ako ima ne stavljaj ništa
                    if (!display.IsDecimal)
                    {
                        //dodaj decimalni znak 
                        display.AddDecimalToken(inPressedDigit);
                    }
                }
                //ako je ulazni znak aritemitcki operator
                else if (CharManager.IsArithmeticOperator(inPressedDigit))
                {
                    if (!display.IsEmpty)
                    {
                        //ako je ulazni znak aritmetički operator uzmi broj sa ekrana i spremi ga na slobodnu memorijsku lokaciju
                        memory.FreeMemoryLocation = new Number(display.Value);
                    }
                    
                    //ako postoji prijašnji aritmetički operator sa obje memorijske lokacije zauzete -> izračunaj ga
                    if (arithmetic != null && memory.IsFull)
                    {
                        this.Calculate();
                        memory.FreeMemoryLocation = new Number(display.Value);
                        display.Value = memory.LastMemoryLocation.ToString();
                        display.Reset = true;
                    }

                    //postavi delegat na odabranu funckiju
                    arithmetic = Function.ArithmeticFactory(inPressedDigit);
                    //postavi display spreman za brisanje
                    display.Reset = true;
                }

                else if (CharManager.IsFunctionOperator(inPressedDigit))
                {
                    //ako je ulazni znak funkcijski operator uzmi broj sa ekrana i spremi ga na slobodnu memorijsku lokaciju
                    memory.FreeMemoryLocation = new Number(display.Value);
                    //Izgradi novi funkcijski operator
                    function = Function.FunctionFactory(inPressedDigit);
                    display.Reset = true;
                }

                else if (CharManager.IsEqualOperator(inPressedDigit))
                {    
                    //izracunaj niz
                    if (!display.IsEmpty)
                    {
                        memory.FreeMemoryLocation = new Number(display.Value);
                    }
                    else
                    {
                        //ako nije postavljeno nista na display iskopiraj broj iz zauzetog registra u slobodni
                        memory.FreeMemoryLocation = memory.LastMemoryLocation;
                    }

                }

                else if (CharManager.IsDisplayOperator(inPressedDigit))
                {
                    display.Clear();
                }

                else if (CharManager.IsMemoryOperator(inPressedDigit))
                {
                    if (inPressedDigit == 'P')
                    {
                        Number number = new Number(display.Value);
                        memory.Put(number);
                    }
                    else if (inPressedDigit == 'G')
                    {
                        memory.FreeMemoryLocation = memory.Get();
                        display.Value = memory.LastMemoryLocation.ToString();
                        display.Reset = true;
                    }
                        
                }
                // izračunaj ako možeš
                this.Calculate();
                

            }
            catch (NumberSizeException e) 
            {
                display.Value = e.Message;
            }

        }

        public string GetCurrentDisplayState()
        {
            return display.Value;
        }

        private void Calculate()
        {
            
            if (function != null)
            {
                Number number = memory.EmptyRegister();
                number = function(number);
                display.Value = number.ToString();
                function = null;
            }
            else if (arithmetic != null)
            {
                //aritmeticki operator zahtjeva 2 operanda -> memorija mora biti puna
                if (memory.IsFull)                {
                    Number number1 = memory.EmptyRegister();
                    Number number2 = memory.EmptyRegister();
                    Number displayNumber = arithmetic(number2, number1);
                    display.Value = displayNumber.ToString();
                    
                    // postavljanje delegata na null
                    arithmetic = null;   
                }
            }
        }

        private void CheckDisplay()
        {
            if (display.Reset)
            {
                display.Clear();
            }
        }


        class Memory
        {
            private Number register1 = null;
            private Number register2 = null;

            private Number lastUsedMemoryLocation = null;


            private Number savedNumber = null;

            public Memory()
            {
                savedNumber = new Number(0.0);
            }



            public void Put(Number number)
            {
                savedNumber = number;
            }

            public Number Get()
            {
                return savedNumber;
            }

            public Number FreeMemoryLocation
            {
                set
                {
                    if (register1 == null)
                    {
                        register1 = value;
                        lastUsedMemoryLocation = register1;
                    }
                    else if (register2 == null)
                    {
                        register2 = value;
                        lastUsedMemoryLocation = register2;
                    }
                }
            }

            public Number LastMemoryLocation
            {
                get
                {
                    return lastUsedMemoryLocation;
                }

                set
                {
                    if (register1 == lastUsedMemoryLocation)
                    {
                        register2 = value;
                        lastUsedMemoryLocation = register2;
                    }
                    else if (register2 == lastUsedMemoryLocation)
                    {
                        register1 = value;
                        lastUsedMemoryLocation = register1;
                    }
                }

            }



            public Number EmptyRegister()
            {
                Number number = null;
                if (lastUsedMemoryLocation == register1)
                {
                    lastUsedMemoryLocation = register2;
                    number = register1;
                    register1 = null;
                }
                else if (lastUsedMemoryLocation == register2)
                {
                    lastUsedMemoryLocation = register1;
                    number = register2;
                    register2 = null;
                }
                return number;
            }

            public bool IsFull
            {
                get
                {
                    if (this.register1 == null || this.register2 == null)
                        return false;
                    else
                        return true;
                }
            }
        }

        class Display
        {
            StringBuilder display = null;


            public int digitCounter;

            private bool isDecimal;
            private bool isNegative;
            private bool isEmpty;
            private bool clear;
            static char NEGATIVE_TOKEN = '-';

            public Display()
            {
                display = new StringBuilder(12);
                ResetAll();
            }

            public void AddDigit(char c)
            {
                if ((digitCounter == 0 && c == '0') || (digitCounter == 10))
                {
                    isEmpty = false;
                    return;
                }

                digitCounter++;
                display.Insert(display.Length, c);
            }

            public void AddDecimalToken(char c)
            {
                isDecimal = true;
                display.Insert(display.Length, c);
            }

            public void AddPrefix()
            {
                if (digitCounter != 0)
                {
                    if (!isNegative)
                    {
                        display.Insert(0, NEGATIVE_TOKEN);
                    }
                    else
                    {
                        display.Remove(0, 1);
                    }
                }
            }

            public void Clear()
            {
                display.Remove(0, display.Length);
                ResetAll();
            }

            private void ResetAll()
            {
                digitCounter = 0;
                isNegative = false;
                isDecimal = false;
                clear = false;
                isEmpty = true;
            }

            public bool IsDecimal
            {
                get { return isDecimal; }
            }

            public bool IsEmpty
            {
                get
                {
                    if (digitCounter == 0 && isEmpty)
                        return true;
                    else
                        return false;
                }
            }

            public override String ToString()
            {
                Number number = new Number(display.ToString());
                return number.ToString();
            }

            public bool Reset
            {
                get { return clear; }
                set { clear = value; }
            }

            public String Value
            {
                get
                {
                    //provjere za posebne slucajeve displaya -> kada je prazan i kada se dogodila pogreška
                    if (digitCounter == 0)
                        return "0";
                    else if (display.ToString().Equals("-E-"))
                        return display.ToString();

                    Number number = new Number(display.ToString());
                    return number.ToString();
                }
                set
                {
                    ResetAll();
                    if (value.Contains(','))
                    {
                        isDecimal = true;
                    }

                    display.Remove(0, display.Length);
                    display.Append(value);
                    digitCounter = display.Length;
                }
            }


        }

        public class Number
        {
            Decimal number;

            public Number(String number)
            {
                try
                {
                    if (number.Contains(','))
                    {
                        while (number.EndsWith("0"))
                        {
                            number = number.Remove(number.Length - 1, 1);
                        }
                    }
                    this.number = Decimal.Parse(number);
                }
                catch (FormatException e)
                {

                }
            }

            public Number(double number)
            {
                this.number = new Decimal(number);
            }

            public Number(Decimal number)
            {
                this.number = number;
            }

            public Decimal Value
            {
                get { return number; }
                set { number = value; }
            }

            public override string ToString()
            {
                return (number.ToString());
            }

            public bool IsNegative
            {
                get
                {
                    if (number < 0)
                        return true;
                    else
                        return false;
                }
            }

        }

        class Function
        {
            //funkcije 

            public static Number Minus(Number number)
            {
                number.Value = -number.Value;
                return number;
            }

            public static Number Sin(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                number = Round(Math.Sin(value), 10);
                return number;
            }

            public static Number Cos(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                return Round(Math.Cos(value), 10);
            }

            public static Number Tan(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                return Round(Math.Tan(value), 10);
            }

            public static Number Sqr(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                return Round(Math.Pow(value, 2), 10);
            }

            public static Number Sqrt(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                return Round(Math.Sqrt(value), 10);
            }

            public static Number Inverse(Number number)
            {
                double value = Decimal.ToDouble(number.Value);
                return Round(1 / value, 10);
            }

            //delegat za funkcije
            public delegate Number FunctionDelegate(Number number);

            // factory uzorak za funkcije
            public static FunctionDelegate FunctionFactory(char c)
            {
                switch (c)
                {
                    case 'M':
                        return Minus;
                    case 'S':
                        return Sin;
                    case 'K':
                        return Cos;
                    case 'T':
                        return Tan;
                    case 'Q':
                        return Sqr;
                    case 'R':
                        return Sqrt;
                    case 'I':
                        return Inverse;
                    default:
                        return null;
                }
            }

            //aritmetika

            public static Number Add(Number numberA, Number numberB)
            {
                double numA = Decimal.ToDouble(numberA.Value);
                double numB = Decimal.ToDouble(numberB.Value);
                return Round(numA + numB, 10);
            }

            public static Number Subtrac(Number numberA, Number numberB)
            {
                double numA = Decimal.ToDouble(numberA.Value);
                double numB = Decimal.ToDouble(numberB.Value);
                return Round((numA - numB), 10);
            }

            public static Number Divide(Number numberA, Number numberB)
            {
                double numA = Decimal.ToDouble(numberA.Value);
                double numB = Decimal.ToDouble(numberB.Value);
                return Round(numA / numB, 10);
            }

            public static Number Multiply(Number numberA, Number numberB)
            {
                double numA = Decimal.ToDouble(numberA.Value);
                double numB = Decimal.ToDouble(numberB.Value);
                return Round((numA * numB), 10);
            }

            public static Number Round(double number, int numberOfDigits)
            {
                int token = 1;
                if (number < 0) token = -1;

                number = Math.Abs(number);
                //number of digits before decimal token
                int numBDT = 0;
                //number of digits after decimal token
                int numADT = numberOfDigits;

                for (int i = 1; i <= numberOfDigits; i++)
                {
                    if (number < Math.Pow(10, i))
                    {
                        numBDT = i;
                        Number newNumber = new Number(token * Decimal.Round(new Decimal(number), numADT - numBDT));
                        return newNumber;
                    }
                }
                throw new NumberSizeException();
            }

            //delegat za aritmetičke funkcije
            public delegate Number ArithmeticDelegate(Number number1, Number number2);

            //factory obrazac za aritmetiku
            public static ArithmeticDelegate ArithmeticFactory(char c)
            {
                switch (c)
                {
                    case '*':
                        return Multiply;
                    case '/':
                        return Divide;
                    case '+':
                        return Add;
                    case '-':
                        return Subtrac;
                    default:
                        return null;
                }
            }
        }

        class CharManager
        {

            public static bool IsComma(char c)
            {
                if (c == ',')
                    return true;
                else
                    return false;
            }

            public static bool IsDigit(char c)
            {
                return Char.IsDigit(c);
            }

            public static bool IsArithmeticOperator(char c)
            {
                switch (c)
                {
                    case '*':
                    case '/':
                    case '+':
                    case '-':
                        return true;
                    default:
                        return false;
                }
            }

            public static bool IsFunctionOperator(char c)
            {
                switch (c)
                {
                    case 'M':
                    case 'S':
                    case 'K':
                    case 'T':
                    case 'Q':
                    case 'R':
                    case 'I':
                    case 'O':
                        return true;
                    default:
                        return false;
                }
            }

            public static bool IsMemoryOperator(char c)
            {
                switch (c)
                {
                    case 'P':
                    case 'G':
                        return true;
                    default:
                        return false;
                }
            }

            public static bool IsDisplayOperator(char c)
            {
                switch (c)
                {
                    case 'C':
                        return true;
                    default:
                        return false;
                }
            }

            public static bool IsSaveOperator(char c)
            {
                switch (c)
                {
                    case 'P':
                    case 'G':
                    case 'C':
                    case 'O':
                        return true;
                    default:
                        return false;
                }
            }

            public static bool IsOffOnOperator(char c)
            {
                if (c == 'O') { return true; }
                else { return false; }
            }

            public static bool IsEqualOperator(char c)
            {
                if (c.Equals('='))
                    return true;
                else
                    return false;
            }
        }

        class NumberSizeException : System.ApplicationException
        {
            public override string Message
            {
                get
                {
                    return "-E-";
                }
            }
        }
    }
}