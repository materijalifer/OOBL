﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        public Kalkulator()
        {
            CalcState.Reset();
        }

        public void Press(char inPressedDigit)
        {
            if (MiscValues.Instance.Operations.ContainsKey(inPressedDigit))
            {
                MiscValues.Instance.Operations[inPressedDigit].Execute();
            }
            else if (Char.IsDigit(inPressedDigit))
            {
                Display.addDigit(inPressedDigit);
                CalcState.LastOpWasBinary = false;
            }
            else
            {
                return;
            }
            CalcState.LastChar = inPressedDigit;
        }


        public string GetCurrentDisplayState()
        {
            return Display.OnScreen;
        }
    }

    static class CalcState
    {
        private static Number previousValue;
        private static Operation previousOperation;
        private static bool lastOpWasBinary;
        private static char lastChar;


        public static void Reset()
        {
            previousValue = null;
            previousOperation = null;
            lastOpWasBinary = false;
            lastChar = Char.MinValue;
            Display.Clear();
            Memory.Reset();
        }

        public static Number PreviousValue
        {
            get { return previousValue; }
            set { previousValue = value; }
        }

        public static Operation PreviousOperation
        {
            get { return previousOperation; }
            set { previousOperation = value; }
        }

        public static bool LastOpWasBinary
        {
            get { return lastOpWasBinary; }
            set { lastOpWasBinary = value; }
        }

        public static char LastChar
        {
            get { return lastChar; }
            set { lastChar = value; }
        }
    }

    public static class Display
    {
        private static string onScreen;
        private static int digitsCount;
        private static bool gotNegative;
        private static bool gotDecimal;

        private static bool error;

        static Display()
        {
            Clear();
        }

        public static void Clear()
        {
            onScreen = "";
            digitsCount = 0;
            gotNegative = false;
            gotDecimal = false;
            error = false;
        }

        public static bool CleanOnInput
        {
            get { return error; }
            set { error = value; }
        }

        public static void addDigit(char digit)
        {
            if (error)
            {
                Clear();
                error = false;
            }

            if (onScreen.Equals("" + MiscValues.Instance.InitScreenVal) && digitsCount == 1 &&
                digit.Equals(MiscValues.Instance.InitScreenVal))
            {
                return;
            }

            else if (digitsCount < MiscValues.Instance.MaxDigits)
            {
                digitsCount += 1;
                onScreen += digit;
            }
        }

        public static void changeSign()
        {
            if (digitsCount == 0)
            {
                return;
            }

            if (gotNegative)
            {
                gotNegative = false;
            }
            else
            {
                gotNegative = true;
            }
        }

        public static void addDecimal()
        {
            if (error)
            {
                Clear();
                error = false;
            }

            if (gotDecimal || digitsCount >= MiscValues.Instance.MaxDigits)
            {
                return;
            }

            if (digitsCount == 0)
            {
                onScreen = "" + MiscValues.Instance.InitScreenVal;
                digitsCount += 1;
            }
            onScreen += MiscValues.Instance.DecimalSign;
            gotDecimal = true;
        }

        public static string OnScreen
        {
            get
            {
                string result = "";

                if (!onScreen.Equals(""))
                {
                    if (gotNegative)
                    {
                        result = "" + MiscValues.Instance.NegativeSign;
                    }
                    result += onScreen;
                }
                else
                {
                    result = "" + MiscValues.Instance.InitScreenVal;
                }
                return result;
            }
            set
            {
                gotNegative = false;
                gotDecimal = false;

                if (value.Equals(MiscValues.Instance.ErrorSign))
                {
                    Clear();
                    onScreen = value;
                    error = true;
                }
                else
                {
                    digitsCount = value.Length;

                    if (value.Contains(MiscValues.Instance.DecimalSign))
                    {
                        gotDecimal = true;
                        digitsCount -= 1;
                    }

                    if (value.Contains(MiscValues.Instance.NegativeSign))
                    {
                        gotNegative = true;
                        digitsCount -= 1;
                    }

                    onScreen = value;

                    if (onScreen.Contains(MiscValues.Instance.NegativeSign))
                    {
                        onScreen = onScreen.Remove(onScreen.IndexOf(MiscValues.Instance.NegativeSign), 1);
                    }
                }
            }
        }
    }
    
    public static class Memory
    {
        private static double data;

        static Memory()
        {
            data = 0;
        }

        public static double Data
        {
            get { return data; }

            set { data = value; }
        }

        public static void Reset()
        {
            data = 0;
        }
    }

    public class MiscValues
    {
        private const string cultureName = "hr-HR";

        private static MiscValues instance;
        private string format;
        private int maxDigits;
        private string errorSign;
        private double errorVal;
        private char decimalSign;
        private char negativeSign;
        private char initScreenVal;
        private Dictionary<char, Operation> operations;
        private CultureInfo culture;

        private MiscValues()
        {
            this.format = "{0:0.#########}";
            this.maxDigits = 10;
            this.errorSign = "-E-";
            this.errorVal = Double.NaN;
            this.decimalSign = ',';
            this.negativeSign = '-';
            this.initScreenVal = '0';
            this.operations = new Dictionary<char, Operation>();
            this.initOperations();
            this.culture = new CultureInfo(cultureName);
        }

        public static MiscValues Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new MiscValues();
                }
                return instance;
            }
        }

        private void initOperations()
        {
            this.operations.Add('+', new OperationAdd());
            this.operations.Add('-', new OperationSub());
            this.operations.Add('*', new OperationMul());
            this.operations.Add('/', new OperationDiv());
            this.operations.Add('M', new OperationSign());
            this.operations.Add('S', new OperationSin());
            this.operations.Add('K', new OperationCos());
            this.operations.Add('T', new OperationTan());
            this.operations.Add('Q', new OperationPow());
            this.operations.Add('R', new OperationRoot());
            this.operations.Add('I', new OperationInv());
            this.operations.Add('P', new OperationSave());
            this.operations.Add('G', new OperationLoad());
            this.operations.Add('C', new OperationClear());
            this.operations.Add(',', new OperationDecimal());
            this.operations.Add('=', new OperationEquals());
            this.operations.Add('O', new OperationOn());
        }

        public Dictionary<char, Operation> Operations
        {
            get { return this.operations; }
        }

        public string Format
        {
            get { return this.format; }
        }

        public int MaxDigits
        {
            get { return this.maxDigits; }
        }

        public string ErrorSign
        {
            get { return this.errorSign; }
        }

        public double ErrorVal
        {
            get { return this.errorVal; }
        }

        public char DecimalSign
        {
            get { return this.decimalSign; }
        }

        public char NegativeSign
        {
            get { return this.negativeSign; }
        }

        public char InitScreenVal
        {
            get { return this.initScreenVal; }
        }

        public CultureInfo Culture
        {
            get { return this.culture; }
        }
    }

    public class Number
    {
        private double doubleRep;
        private string stringRep;

        public Number(double input)
        {
            if (Double.IsInfinity(input) || Double.IsNaN(input))
            {
                this.doubleRep = MiscValues.Instance.ErrorVal;
                this.stringRep = MiscValues.Instance.ErrorSign;
            }
            else
            {
                this.parse(input.ToString());
            }
        }

        public double Double
        {
            get { return this.doubleRep; }
        }

        public String String
        {
            get { return this.stringRep; }
        }

        public Number(string input)
        {
            this.parse(input);
        }

        private void parse(string input)
        {
            if (input.Equals(MiscValues.Instance.ErrorSign))
            {
                this.doubleRep = MiscValues.Instance.ErrorVal;
                this.stringRep = MiscValues.Instance.ErrorSign;
            }
            else
            {

                double number = (Double.Parse(input, MiscValues.Instance.Culture));
                int integers = (Math.Truncate(number)).ToString().Length;

                if (Math.Truncate(number).ToString().Contains(MiscValues.Instance.NegativeSign))
                {
                    integers -= 1;
                }

                if (integers > MiscValues.Instance.MaxDigits)
                {
                    this.doubleRep = MiscValues.Instance.ErrorVal;
                    this.stringRep = MiscValues.Instance.ErrorSign;
                }
                else
                {
                    this.doubleRep = Math.Round(number, MiscValues.Instance.MaxDigits - integers);
                    this.stringRep = String.Format(MiscValues.Instance.Culture, MiscValues.Instance.Format, this.doubleRep);
                }
            }
        }
    }

    public abstract class Operation
    {
        public abstract void Execute();

        public abstract void RunOperation();
    }

    public abstract class BinaryOperation : Operation
    {

        public override void Execute()
        {
            Display.CleanOnInput = true;

            if (CalcState.PreviousOperation != null)
            {
                if (CalcState.LastOpWasBinary == false)
                {
                    CalcState.PreviousOperation.RunOperation();
                }
            }
            CalcState.PreviousValue = new Number(Display.OnScreen);
            CalcState.PreviousOperation = this;
            CalcState.LastOpWasBinary = true;

        }
    }

    public abstract class UnaryOperation : Operation
    {

        public override void Execute()
        {
            Display.CleanOnInput = true;

            this.RunOperation();
            CalcState.LastOpWasBinary = false;
        }
    }

    public class OperationAdd : BinaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = new Number(Display.OnScreen);

            double result = previousValue.Double + currentVal.Double;

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationClear : UnaryOperation
    {
        public override void RunOperation()
        {
            Display.Clear();
        }
    }

    class OperationCos : UnaryOperation
    {
        public override void RunOperation()
        {
            Number currentVal = new Number(Display.OnScreen);
            double result = Math.Cos(currentVal.Double);
            Display.OnScreen = new Number(result).String;
        }
    }

    class OperationDecimal : UnaryOperation
    {
        public override void Execute()
        {
            if (CalcState.LastOpWasBinary)
            {
                Display.CleanOnInput = true;
            }
            else
            {
                Display.CleanOnInput = false;
            }

            this.RunOperation();
            CalcState.LastOpWasBinary = false;
        }

        public override void RunOperation()
        {
            Display.addDecimal();
        }
    }

    class OperationDiv : BinaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = currentVal = new Number(Display.OnScreen); ;

            double result = previousValue.Double / currentVal.Double;

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationEquals : UnaryOperation
    {
        public override void RunOperation()
        {
            if (CalcState.PreviousOperation != null)
            {
                CalcState.PreviousOperation.RunOperation();
            }

            CalcState.PreviousOperation = null;
            CalcState.PreviousValue = new Number(Display.OnScreen);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationInv : UnaryOperation
    {
        public override void RunOperation()
        {
            Number currentVal = new Number(Display.OnScreen);
            double result = 1.0 / currentVal.Double;
            Display.OnScreen = new Number(result).String;
        }
    }

    class OperationLoad : UnaryOperation
    {
        public override void Execute()
        {
            Display.CleanOnInput = false;

            this.RunOperation();
            CalcState.LastOpWasBinary = false;
        }

        public override void RunOperation()
        {
            Display.OnScreen = new Number(Memory.Data).String;
        }
    }

    class OperationMul : BinaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = new Number(Display.OnScreen);

            double result = previousValue.Double * currentVal.Double;

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationOn : UnaryOperation
    {
        public override void RunOperation()
        {
            CalcState.Reset();
        }
    }

    class OperationPow : UnaryOperation
    {
        public override void RunOperation()
        {
            Number currentVal = new Number(Display.OnScreen);
            double result = currentVal.Double * currentVal.Double;
            Display.OnScreen = new Number(result).String;
        }
    }

    class OperationRoot : UnaryOperation
    {
        public override void RunOperation()
        {
            Number currentVal = new Number(Display.OnScreen);
            double result = Math.Sqrt(currentVal.Double);
            Display.OnScreen = new Number(result).String;
        }
    }

    class OperationSave : UnaryOperation
    {
        public override void Execute()
        {
            Display.CleanOnInput = false;

            this.RunOperation();
            CalcState.LastOpWasBinary = false;
        }

        public override void RunOperation()
        {
            Memory.Data = new Number(Display.OnScreen).Double;
        }
    }

    class OperationSign : UnaryOperation
    {
        public override void Execute()
        {
            if (CalcState.LastOpWasBinary)
            {
                Display.CleanOnInput = true;
            }
            else
            {
                Display.CleanOnInput = false;
            }

            this.RunOperation();

            CalcState.LastOpWasBinary = false;
        }

        public override void RunOperation()
        {
            Display.changeSign();
        }
    }

    class OperationSin : UnaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = new Number(Display.OnScreen);

            double result = Math.Sin(currentVal.Double);

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationSub : BinaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = new Number(Display.OnScreen);

            double result = previousValue.Double - currentVal.Double;

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }

    class OperationTan : UnaryOperation
    {
        public override void RunOperation()
        {
            Number previousValue = CalcState.PreviousValue;
            Number currentVal = new Number(Display.OnScreen);

            double result = Math.Tan(currentVal.Double);

            CalcState.PreviousValue = new Number(result);
            Display.OnScreen = CalcState.PreviousValue.String;
        }
    }
}


