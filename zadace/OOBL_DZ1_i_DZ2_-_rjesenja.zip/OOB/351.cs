﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private readonly Dictionary<string, Stock> _stockList;
         private readonly Dictionary<string, Index> _indexList;
         private readonly Dictionary<string, Portfolio> _portfolioList;

         public StockExchange()
         {
             _stockList = new Dictionary<string, Stock>();
             _indexList = new Dictionary<string, Index>();
             _portfolioList = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica s odabranim imenom već postoji.");
             }
             if (inNumberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica ne može biti jednak nuli.");
             }
             if (inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Cijena dionice mora biti veća od 0.");
             }
             var newStock = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
             _stockList.Add(inStockName.ToLower(), newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji.");
             }
             foreach (Index index in _indexList.Values)
             {
                 if (index.IsStockParfOfIndex(inStockName.ToLower()))
                 {
                     index.RemoveStock(inStockName.ToLower());
                 }
             }
             foreach (Portfolio portfolio in _portfolioList.Values)
             {
                 if (portfolio.ContainsStock(inStockName.ToLower()))
                 {
                     portfolio.RemoveStock(_stockList[inStockName.ToLower()]);
                 }
             }
             _stockList.Remove(inStockName.ToLower());
         }

         public bool StockExists(string inStockName)
         {
             return _stockList.ContainsKey(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return _stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji.");
             }
             _stockList[inStockName.ToLower()].SetPrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji.");
             }
             return Decimal.Round(_stockList[inStockName.ToLower()].GetStockPrice(inTimeStamp), 3, MidpointRounding.AwayFromZero);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji.");
             }
             return Decimal.Round(_stockList[inStockName.ToLower()].GetInitialPrice(), 3, MidpointRounding.AwayFromZero);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji.");
             }
             return Decimal.Round(_stockList[inStockName.ToLower()].GetLastPrice(), 3, MidpointRounding.AwayFromZero);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks s odabranim imenom već postoji na burzi.");
             }
             if (inIndexType == IndexTypes.AVERAGE)
             {
                 Index newIndex = new AverageIndex();
                 _indexList.Add(inIndexName.ToLower(), newIndex);
             }
             else
             {
                 if (inIndexType == IndexTypes.WEIGHTED)
                 {
                     Index newIndex = new WeightedIndex();
                     _indexList.Add(inIndexName.ToLower(), newIndex);
                 }
                 else
                 {
                     throw new StockExchangeException("Nepostojeći tip indeksa.");
                 }
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks ne postoji na burzi.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             _indexList[inIndexName.ToLower()].AddStock(_stockList[inStockName.ToLower()]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks ne postoji na burzi.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             _indexList[inIndexName.ToLower()].RemoveStock(inStockName.ToLower());
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks ne postoji na burzi.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             return _indexList[inIndexName.ToLower()].IsStockParfOfIndex(inStockName.ToLower());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks ne postoji na burzi.");
             }

             return Decimal.Round(_indexList[inIndexName.ToLower()].GetValue(inTimeStamp), 3, MidpointRounding.AwayFromZero);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indexList.ContainsKey(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return _indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!_indexList.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Indeks ne postoji na burzi.");
             }

             return _indexList[inIndexName.ToLower()].GetNumOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portfelj sa zadanim imenom već postoji.");
             }
             
             _portfolioList.Add(inPortfolioID, new Portfolio());
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             _portfolioList[inPortfolioID].AddStock(_stockList[inStockName.ToLower()], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             _portfolioList[inPortfolioID].RemoveStock(_stockList[inStockName.ToLower()], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             _portfolioList[inPortfolioID].RemoveStock(_stockList[inStockName.ToLower()]);
         }

         public int NumberOfPortfolios()
         {
             return _portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }
             return _portfolioList[inPortfolioID].GetNumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolioList.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             return _portfolioList[inPortfolioID].ContainsStock(inStockName.ToLower());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             if (!_stockList.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji na burzi.");
             }

             return _portfolioList[inPortfolioID].GetNumberOfSharesForStock(inStockName.ToLower());
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }
             decimal value = 0;
             foreach (KeyValuePair<string, int> entry in _portfolioList[inPortfolioID].GetShareList())
             {
                 value += _stockList[entry.Key].GetStockPrice(timeStamp)*entry.Value;
             }
             return Decimal.Round(value, 3, MidpointRounding.AwayFromZero);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!_portfolioList.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Ne postoji portfelj sa zadanim imenom.");
             }

             
             var beginningOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             decimal valueAtTheBeginningOfMonth = GetPortfolioValue(inPortfolioID, beginningOfMonth);
             if (valueAtTheBeginningOfMonth == 0)
             {
                 return 0;
             }
             
             var endOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             decimal valueAtTheEndOfMonth = GetPortfolioValue(inPortfolioID, endOfMonth);

             decimal change = ((valueAtTheEndOfMonth - valueAtTheBeginningOfMonth) / valueAtTheBeginningOfMonth)* 100;

             

             return Decimal.Round(change, 3, MidpointRounding.AwayFromZero);
         }
     }

    public class Stock
    {
        private readonly String _name;
        private readonly long _numOfShares;
        private long _numOfUnsortedShares;

        private readonly List<StockPrice> _priceList;

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            _name = inStockName;
            _numOfShares = inNumberOfShares;
            _numOfUnsortedShares = inNumberOfShares;
            _priceList = new List<StockPrice> {new StockPrice(inInitialPrice, inTimeStamp)};
        }

        public void SetPrice(DateTime inIimeStamp, Decimal inStockValue)
        {
            if (_priceList.Any(st => st.GetTimeStamp().Equals(inIimeStamp)))
            {
                throw new StockExchangeException("Za određeni trenutak nije moguće unijeti više zapisa cijena");
            }
            _priceList.Add(new StockPrice(inStockValue, inIimeStamp));
            _priceList.Sort();
        }

        public Decimal GetInitialPrice()
        {
            return _priceList.ElementAt(0).GetValue();
        }

        public Decimal GetLastPrice()
        {
            return _priceList.ElementAt(_priceList.Count() - 1).GetValue();
        }

        public Decimal GetStockPrice(DateTime timeStamp)
        {
            if (_priceList.ElementAt(0).GetTimeStamp().CompareTo(timeStamp) == 1)
            {
                throw new StockExchangeException("Ne postoji cijena dionice za zadano vrijeme.");
            }
            for (int i = 0; i < _priceList.Count; i++)
            {
                if (_priceList.ElementAt(i).GetTimeStamp().CompareTo(timeStamp) == 1)
                {
                    return _priceList.ElementAt(i - 1).GetValue();
                }
            }
            return _priceList.ElementAt(_priceList.Count - 1).GetValue();
        }

        public string GetName()
        {
            return _name;
        }

        public long GetNumOfShares()
        {
            return _numOfShares;
        }

        public void SortShares(long numOfSharesToSort)
        {
            if (_numOfUnsortedShares - numOfSharesToSort < 0)
            {
                throw new StockExchangeException("Ne postoji toliko dionica.");
            }
            _numOfUnsortedShares -= numOfSharesToSort;
        }

        public void UnsortShares(long numOfSharesToUnsort)
        {
            if (_numOfUnsortedShares + numOfSharesToUnsort > _numOfShares)
            {
                throw new StockExchangeException("Nije moguće obrisati toliko dionica.");
            }
            _numOfUnsortedShares += numOfSharesToUnsort;
        }
}

    public abstract class Index
    {
        internal Dictionary<string, Stock> StockList;

        protected Index()
        {
            StockList = new Dictionary<string, Stock>();
        }

        public void AddStock(Stock stock)
        {
            if (StockList.ContainsKey(stock.GetName()))
            {
                throw new StockExchangeException("Indeks već sadrži odabranu dionicu.");
            }
            StockList.Add(stock.GetName(), stock);
        }

        public void RemoveStock(string stockName)
        {
            if (!StockList.ContainsKey(stockName.ToLower()))
            {
                throw new StockExchangeException("Dionica ne postoji.");
            }
            StockList.Remove(stockName);
        }

        public bool IsStockParfOfIndex(string stockName)
        {
            return StockList.ContainsKey(stockName);
        }

        public int GetNumOfStocks()
        {
            return StockList.Count;
        }

        public abstract decimal GetValue(DateTime timeStamp);
    }

    public class AverageIndex : Index
    {
        public override decimal GetValue(DateTime timeStamp)
        {
            if (StockList.Count == 0)
            {
                return 0;
            }
            return Decimal.Round(StockList.Sum(entry => entry.Value.GetStockPrice(timeStamp)) / StockList.Count,
                                3, MidpointRounding.AwayFromZero);
        }

    }

    public class WeightedIndex : Index
    {
        public override decimal GetValue(DateTime timeStamp)
        {
            if (StockList.Count == 0)
            {
                return 0;
            }
            decimal totalValue = StockList.Sum(entry => entry.Value.GetStockPrice(timeStamp)*entry.Value.GetNumOfShares());

            return Decimal.Round(StockList.Sum(entry => entry.Value.GetStockPrice(timeStamp)*entry.Value.GetNumOfShares()
                *(entry.Value.GetStockPrice(timeStamp)/totalValue)), 3, MidpointRounding.AwayFromZero);
        }
    }

    public class Portfolio
    {
        private readonly Dictionary<string, int> _shareList;

        public Portfolio()
        {
            _shareList = new Dictionary<string, int>();
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            stock.SortShares(numberOfShares);
            if (_shareList.ContainsKey(stock.GetName()))
            {
                _shareList[stock.GetName()] += numberOfShares;
            }
            else
            {
                _shareList.Add(stock.GetName(), numberOfShares);
            }
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            stock.UnsortShares(numberOfShares);
            if (_shareList.ContainsKey(stock.GetName()) && _shareList[stock.GetName()] >= numberOfShares)
            {
                _shareList[stock.GetName()] -= numberOfShares;
                if (_shareList[stock.GetName()] == 0)
                {
                    _shareList.Remove(stock.GetName());
                }
            }
            else
            {
                throw new StockExchangeException("Nije moguće ukloniti udio dionica iz portfolija.");
            }
        }

        public void RemoveStock(Stock stock)
        {
            stock.UnsortShares(_shareList[stock.GetName()]);
            if (_shareList.ContainsKey(stock.GetName()))
            {
                _shareList.Remove(stock.GetName());
            }
            else
            {
                throw new StockExchangeException("Portfolio ne sadrži zadanu dionicu.");
            }
        }

        public int GetNumberOfStocks()
        {
            return _shareList.Count;
        }

        public bool ContainsStock(string stockName)
        {
            return _shareList.ContainsKey(stockName);
        }

        public int GetNumberOfSharesForStock(string stockName)
        {
            if (!_shareList.ContainsKey(stockName))
            {
                throw new StockExchangeException("Portfelj ne sadrži zadanu dionicu.");
            }
            return _shareList[stockName];
        }

        public Dictionary<string, int> GetShareList()
        {
            return _shareList;
        }
}

    public class StockPrice : IComparable<StockPrice>
    {
        private readonly Decimal _value;
        private DateTime _timeStamp;

        public StockPrice(Decimal value, DateTime timeStamp)
        {
            if (value <= 0)
            {
                throw new StockExchangeException("Vrijednost dionice ne može biti manja od 0.");
            }
            _value = value;
            _timeStamp = timeStamp;
        }

        public Decimal GetValue()
        {
            return _value;
        }

        public DateTime GetTimeStamp()
        {
            return _timeStamp;
        }

        public int CompareTo(StockPrice other)
        {
            return _timeStamp.CompareTo(other.GetTimeStamp());
        }
    }
}
