﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    // Posto sam krenuo rjesavati ovo preko funkcija koje da ne bi imale hrpu parametara sto si salju medjusobno sam
    // koristio nekoliko zastavica koje se vjerojatno ne bi pojavile da sam isao rjesavati sa obicnim swith-case.
    // Na prvu mi se ovo cinilio kao elegantnije rjesenje, sada znam da vjerojatno nije ali sam mislio i da je vise
    // OO nastrojen te sam stoga to tako rjesavao. 
    public class Kalkulator:ICalculator
    {
        String display;
        String lastBinarOperand;
        String currentNumber;
        String calculatedNumber;
        String numberInMemory;   // služi za rad sa operacijama P i G
        String binarOperands;
        String currentOperand;
        String equalsBrainFk;   // pomocna varijabla pomocu koje se izvrsavaju operacije na svako uzastopno  pritiskanje
                                // operacije =, zove se tako jer sam vec popizdio bio tu malo ^^
        bool binaryOperandPresent;        
        bool error;       
        bool equalOperandPresent;
        bool unarOperandPresent;
        bool equalAfterEqual;  // zastavica koja se postavlja na prvi = i stoji dignuta za svaki iduci = radi ponavljanja
                               //operacije =
        bool clearedDisplay;    //ukoliko se odmah nakon pozivanja funkcije C pozove display da se prikaze 0 
        

        private void setValues()
        {
            display = "";
            lastBinarOperand = "";
            currentNumber = "";
            currentOperand = "";
            binaryOperandPresent = false;
            calculatedNumber = "";
            error = false;
            binarOperands = "+-*/";
            equalOperandPresent = false;
            numberInMemory = "";
            unarOperandPresent = false;
            equalAfterEqual = false;
            equalsBrainFk = "";
            clearedDisplay = false;
        }
      
        public Kalkulator() {
            setValues();
        }
 
        public void Press(char inPressedDigit)
        {
            clearedDisplay = false;
            if (Char.IsDigit(inPressedDigit))
            {
                processDigit(inPressedDigit);
                equalAfterEqual = false;
            }
            else
            {
                processNonDigit(inPressedDigit);
            }
        }
        
        public string GetCurrentDisplayState()
        {

            if (currentNumber.Equals("") && !clearedDisplay)
                display = calculatedNumber;
            else
                display = currentNumber;
            
            if (error)
            {
                return "-E-";
            }
            if (display.Equals(""))
            {
                return "0";
            }

            display = formatNumber(display);
            return display;
        }

        private void processNonDigit(char inPressedDigit)
        {
            if (inPressedDigit == ',')
            {
                processDecimal(inPressedDigit);
            }
            else
            {
                processOperand(inPressedDigit);
            }
        }

        private void processDecimal(char inPressedDigit)
        {
            if (currentNumber.Equals(""))
            {
                currentNumber = "0,";
            }
            else
            {
                currentNumber += ",";
            }
            equalAfterEqual = false;
        }

        private void processOperand(char inPressedDigit)
        {
           currentOperand = inPressedDigit.ToString();
           if (binarOperands.Contains(currentOperand))
           {
               calculateBinarOperation();
               unarOperandPresent = false;
               equalAfterEqual = false;
           }
           else if (currentOperand.Equals("="))
           {
               calculateEqualOperation();
               equalAfterEqual = true;
           }
           else
           {
               calculateUnarOperation();
               if(!currentOperand.Equals("M"))
                unarOperandPresent = true;
               equalAfterEqual = false;
           } 
        }

        private void calculateBinarOperation()
        {
            if (binaryOperandPresent && !currentNumber.Equals(""))
            {
                processBinaryOperation(lastBinarOperand);
                currentNumber = "";
                lastBinarOperand = currentOperand;
            }
            else
            {
                binaryOperandPresent = true;
                lastBinarOperand = currentOperand;
                currentOperand = "";
                if(!currentNumber.Equals(""))
                calculatedNumber = currentNumber;
                currentNumber = "";
            }
            
        }
        private void calculateEqualOperation()
        {
            if (binaryOperandPresent)
            {
                if (equalAfterEqual)
                    currentNumber = equalsBrainFk;
                else
                {
                    equalsBrainFk = currentNumber;

                }
                if (currentNumber.Equals(""))
                    equalsBrainFk = calculatedNumber;
                
                processBinaryOperation(lastBinarOperand);
                currentNumber = "";
            }
            else
            {
                equalOperandPresent = true;
            }
        }

        private void calculateUnarOperation()
        {
            processUnarOperand(currentOperand);
        }

        private void processDigit(char inPressedDigit)
        {
            if (unarOperandPresent)
                currentNumber = inPressedDigit.ToString();
            else
                currentNumber += inPressedDigit.ToString();
        }

        private void processUnarOperand(string operand)
        {
            string tempNumber = "";
            double number = 0;
            if (currentNumber.Equals(""))
                tempNumber = calculatedNumber;
            else
                tempNumber = currentNumber;

            number = double.Parse(tempNumber);

            if (operand.Equals("M"))
            {
                tempNumber = (number * -1).ToString();
            }
            else if (operand.Equals("S"))
            {
                tempNumber = Math.Round(Math.Sin(number), 9).ToString();
            }
            else if (operand.Equals("K"))
            {
                tempNumber = Math.Cos(number).ToString();
            }
            else if (operand.Equals("T"))
            {
                tempNumber = Math.Tan(number).ToString();
            }
            else if (operand.Equals("Q"))
            {
                tempNumber = Math.Pow(number, 2).ToString();
            }
            else if (operand.Equals("R"))
            {
                if (number < 0)
                    error = true;
                else
                    tempNumber = Math.Sqrt(number).ToString();
            }
            else if (operand.Equals("I"))
            {
                if ((number - 0) < 10E-6)
                    error = true;
                tempNumber = (1 / number).ToString();
            }
            else if (operand.Equals("C"))
            {
                currentNumber = "";
                clearedDisplay = true;
                return;
            }
            else if (operand.Equals("P"))
            {
                numberInMemory += currentNumber;
                currentNumber = "";
                return;
            }
            else if (operand.Equals("G"))
            {
                tempNumber = numberInMemory;
                numberInMemory = "";
            }
            else if (operand.Equals("O"))
            {
                setValues();
                return;
            }

            tempNumber = formatNumber(tempNumber);
            currentNumber = tempNumber;
        }

        private void processBinaryOperation(string operand)
        {
            calculatedNumber = formatNumber(calculatedNumber);
            double firstNumber = 0;
            double secondNumber = 0;
            if (!currentNumber.Equals(""))
            {
                currentNumber = formatNumber(currentNumber);
                secondNumber = double.Parse(currentNumber);
            }
            else
            {
                secondNumber = double.Parse(calculatedNumber);
            }
            firstNumber = double.Parse(calculatedNumber);

            if (operand.Equals("+"))
            {
                calculatedNumber = (firstNumber + secondNumber).ToString();
            }
            else if (operand.Equals("-"))
            {
                calculatedNumber = (firstNumber - secondNumber).ToString();
            }
            else if (operand.Equals("/"))
            {
                if((secondNumber - 0) < 10E-6)
                    error = true;
                else
                calculatedNumber = (firstNumber / secondNumber).ToString();
            }
            else if (operand.Equals("*"))
            {
                calculatedNumber = (firstNumber * secondNumber).ToString();
            }

            calculatedNumber = formatNumber(calculatedNumber);
        }

        private string formatNumber(string calculatedNumber)
        {
            String goodNumber = calculatedNumber;
            double number = double.Parse(calculatedNumber);
            bool rounding = false;

            if (number >= 10E10 || number <= -10E10)
            {
                error = true;
                return "0";
            }
            else
            {
                int allowedSize = 10;
                if (Math.Abs((Math.Ceiling(number) - number)) < 10E-6)
                {
                    calculatedNumber = Math.Ceiling(number).ToString();
                }

                if (calculatedNumber.Contains(",")) allowedSize++;
                    rounding = true;
                if (calculatedNumber.Contains("-")) allowedSize++;
                if (calculatedNumber.Length > allowedSize)
                {
                    if (rounding)
                    {
                        int roundTo = allowedSize - calculatedNumber.IndexOf(",") - 1;
                        calculatedNumber = Math.Round(number, roundTo).ToString();
                    }
                    return calculatedNumber.Substring(0, allowedSize);
                }
                else if (binaryOperandPresent || equalOperandPresent || calculatedNumber.Equals("0"))
                    return calculatedNumber;
                else
                    return goodNumber;
            }
        }
    }
}
