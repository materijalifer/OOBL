﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }



    #region display
    internal class Display
    {

        #region fileds
        bool negative;
        public bool error { get; set; }
        public bool newInput { get; set; }
        bool pointActivated;
        string digitsBeforePoint;
        string digitsAfterPoint;
        #endregion

        public Display()
        {
            negative = false;
            error = false;
            newInput = false;
            pointActivated = false;
            digitsBeforePoint = "0";
            digitsAfterPoint = "";
        }

        public void reset()
        {
            negative = false;
            error = false;
            newInput = false;
            pointActivated = false;
            digitsBeforePoint = "0";
            digitsAfterPoint = "";
        }

        public double getNumber()
        {

            double res = 0.0;
            res += Double.Parse(digitsBeforePoint, CultureInfo.InvariantCulture);

            res += Double.Parse("0." + digitsAfterPoint, CultureInfo.InvariantCulture);
            if (negative)
            {
                res *= -1;
            }

            return res;
        }

        public bool isZero()
        {
            double d = getNumber();
            if (d == 0.0)
            {
                return true;
            }
            return false;
        }

        public bool putNumber(double number)
        {
            reset();


            bool isNegative = (0 > number);
            if (isNegative)
            {
                number *= -1;
            }



            digitsBeforePoint = ((int)number).ToString();


            int beforePointSpace = digitsBeforePoint.Length;
            if (beforePointSpace > 10)
            {
                error = true;
                return false;
            }

            int afterPointSpace = 10 - beforePointSpace;



            double roundedNumber = Math.Round(number, afterPointSpace);

            digitsBeforePoint = ((int)roundedNumber).ToString();

            roundedNumber += 0.0000000005;

            double tempD = roundedNumber * Math.Pow(10, afterPointSpace) - ((int)roundedNumber) * Math.Pow(10, afterPointSpace);
            digitsAfterPoint = ((long)(tempD)).ToString();

            while (digitsAfterPoint.Length < afterPointSpace)
            {
                digitsAfterPoint = "0" + digitsAfterPoint;
            }

            while (digitsAfterPoint.Length > 0 && digitsAfterPoint[digitsAfterPoint.Length - 1] == '0')
            {
                digitsAfterPoint = digitsAfterPoint.Substring(0, digitsAfterPoint.Length - 1);
            }

            if (digitsAfterPoint == "")
            {
                pointActivated = false;
            }
            else
            {
                pointActivated = true;
            }

            if (isNegative && !isZero())
            {
                negative = true;
            }
            else
            {
                negative = false;
            }

            return true;
        }

        public string getNumberDisplay()
        {

            string res;

            if (!error)
            {
                res = digitsBeforePoint;
                if (pointActivated)
                {
                    res += "," + digitsAfterPoint;
                }
                if (negative)
                {
                    res = "-" + res;
                }
            }
            else
            {
                res = "-E-";
            }


            return res;
        }

        public void handleInput(char input)
        {
            if (newInput)
            {
                reset();
            }
            if (Char.IsDigit(input))
            {
                int length = digitsAfterPoint.Length + digitsBeforePoint.Length;
                if (length < 10)
                {
                    if (pointActivated)
                    {
                        digitsAfterPoint += input;
                    }
                    else
                    {
                        if (digitsBeforePoint != "0")
                            digitsBeforePoint += input;
                        else
                            digitsBeforePoint = "" + input;

                    }
                }

            }
            else if (input == ',')
            {
                pointActivated = true;
            }
            else
            {
                throw new ArgumentException();
            }
        }



    }
    #endregion

    #region Operations
    internal class Operations
    {
        public static double add(double d1, double d2)
        {
            return d1 + d2;
        }

        public static double sub(double d1, double d2)
        {
            return d1 - d2;
        }

        public static double mul(double d1, double d2)
        {
            return d1 * d2;
        }

        public static double div(double d1, double d2)
        {
            return d1 / d2;
        }
    }
    #endregion

    public class Kalkulator : ICalculator
    {


        private Stack<double> firstOperand;
        private Stack<double> memory;


        private static Display display;
        private Dictionary<char, handleInput> inputHandlers;
        private Stack<operation> operations;

        private delegate void handleInput();
        private delegate double operation(double firstOperand, double secondOperand);

        private char lastInput;

        private void inputPlus()
        {
            double d = display.getNumber();


            if ((lastInput == '+' || lastInput == '-' || lastInput == '*' || lastInput == '/') && operations.Count > 0)
            {
                operations.Pop();
                operations.Push(new operation(Operations.add));
            }
            else if (operations.Count > 0)
            {
                operation o = operations.Pop();
                double d1 = firstOperand.Pop();
                operation oDiv = new operation(Operations.div);
                double res = 0;
                if (o == oDiv && d == 0.0)
                {
                    display.error = true;
                }
                else
                {
                    res = o(d1, d);
                }
                display.putNumber(res);
                operations.Push(new operation(Operations.add));
                firstOperand.Push(res);

            }
            else
            {
                firstOperand.Push(d);
                operations.Push(new operation(Operations.add));
            }

            display.newInput = true;

        }

        private void inputMinus()
        {
            double d = display.getNumber();


            if ((lastInput == '+' || lastInput == '-' || lastInput == '*' || lastInput == '/') && operations.Count > 0)
            {
                operations.Pop();
                operations.Push(new operation(Operations.sub));
            }
            else if (operations.Count > 0)
            {
                operation o = operations.Pop();
                double d1 = firstOperand.Pop();
                operation oDiv = new operation(Operations.div);
                double res = 0;
                if (o == oDiv && d == 0.0)
                {
                    display.error = true;
                }
                else
                {
                    res = o(d1, d);
                }
                display.putNumber(res);
                operations.Push(new operation(Operations.sub));
                firstOperand.Push(res);

            }
            else
            {
                firstOperand.Push(d);
                operations.Push(new operation(Operations.sub));
            }

            display.newInput = true;
        }

        private void inputMultiple()
        {
            double d = display.getNumber();


            if ((lastInput == '+' || lastInput == '-' || lastInput == '*' || lastInput == '/') && operations.Count > 0)
            {
                operations.Pop();
                operations.Push(new operation(Operations.mul));
            }
            else if (operations.Count > 0)
            {
                operation o = operations.Pop();
                double d1 = firstOperand.Pop();

                operation oDiv = new operation(Operations.div);
                double res = 0;
                if (o == oDiv && d == 0.0)
                {
                    display.error = true;
                }
                else
                {
                    res = o(d1, d);
                }

                display.putNumber(res);
                operations.Push(new operation(Operations.mul));
                firstOperand.Push(res);
            }
            else
            {
                firstOperand.Push(d);
                operations.Push(new operation(Operations.mul));
            }
            display.newInput = true;
        }

        private void inputDivide()
        {
            double d = display.getNumber();


            if ((lastInput == '+' || lastInput == '-' || lastInput == '*' || lastInput == '/') && operations.Count > 0)
            {
                operations.Pop();
                operations.Push(new operation(Operations.div));
            }
            else if (operations.Count > 0)
            {
                operation o = operations.Pop();
                double d1 = firstOperand.Pop();

                operation oDiv = new operation(Operations.div);
                double res = 0;
                if (o == oDiv && d == 0.0)
                {
                    display.error = true;
                }
                else
                {
                    res = o(d1, d);
                }

                display.putNumber(res);
                operations.Push(new operation(Operations.div));
                firstOperand.Push(res);
            }
            else
            {
                firstOperand.Push(d);
                operations.Push(new operation(Operations.div));
            }

            display.newInput = true;
        }

        private void inputEqual()
        {

            if (operations.Count == 0)
            {
                display.putNumber(display.getNumber());
                return;
            }
            double d1 = 0;
            if (firstOperand.Count != 0)
            {
                d1 = firstOperand.Pop();
            }
            else
            {
                d1 = display.getNumber();
            }
            operation o = operations.Pop();
            double d2 = display.getNumber();


            operation oDiv = new operation(Operations.div);

            if (o == oDiv && d2 == 0.0)
            {
                display.error = true;
            }
            else
            {
                display.putNumber(o(d1, d2));
            }

            display.newInput = true;

        }

        private void inputM()
        {
            display.putNumber(display.getNumber() * (-1));
        }

        private void inputS()
        {
            display.putNumber(Math.Sin(display.getNumber()));
            display.newInput = true;
        }

        private void inputK()
        {

            display.putNumber(Math.Cos(display.getNumber()));
            display.newInput = true;
        }

        private void inputT()
        {
            display.putNumber(Math.Tan(display.getNumber()));
            display.newInput = true;
        }

        private void inputQ()
        {
            display.putNumber(display.getNumber() * display.getNumber());
            display.newInput = true;
        }

        private void inputR()
        {
            display.putNumber(Math.Sqrt(display.getNumber()));
            display.newInput = true;
        }

        private void inputI()
        {
            double d = display.getNumber();
            if (d == 0.0)
            {
                display.error = true;
            }
            else
            {
                display.putNumber(1.0 / d);
            }
            display.newInput = true;
        }

        private void inputP()
        {
            memory.Pop();
            memory.Push(display.getNumber());
        }

        private void inputG()
        {
            double d = memory.Peek();
            display.putNumber(d);
            display.newInput = true;
        }

        private void inputC()
        {
            display.reset();
        }


        public Kalkulator()
        {
            firstOperand = new Stack<double>();
            memory = new Stack<double>();
            memory.Push(0);
            display = new Display();
            inputHandlers = new Dictionary<char, handleInput>();
            operations = new Stack<operation>();
            lastInput = 'O';

            inputHandlers.Add('+', new handleInput(inputPlus));
            inputHandlers.Add('-', new handleInput(inputMinus));
            inputHandlers.Add('*', new handleInput(inputMultiple));
            inputHandlers.Add('/', new handleInput(inputDivide));
            inputHandlers.Add('=', new handleInput(inputEqual));
            inputHandlers.Add('M', new handleInput(inputM));
            inputHandlers.Add('S', new handleInput(inputS));
            inputHandlers.Add('K', new handleInput(inputK));
            inputHandlers.Add('T', new handleInput(inputT));
            inputHandlers.Add('Q', new handleInput(inputQ));
            inputHandlers.Add('R', new handleInput(inputR));
            inputHandlers.Add('I', new handleInput(inputI));
            inputHandlers.Add('P', new handleInput(inputP));
            inputHandlers.Add('G', new handleInput(inputG));
            inputHandlers.Add('C', new handleInput(inputC));

        }

        public void reset()
        {
            firstOperand = new Stack<double>();
            memory = new Stack<double>();
            memory.Push(0);
            display.reset();
            operations = new Stack<operation>();
            lastInput = 'O';
        }




        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',')
            {
                if (!display.error)
                {
                    display.handleInput(inPressedDigit);
                }
            }
            else if (inPressedDigit == 'O')
            {
                reset();
            }
            else
            {
                if (!display.error)
                {
                    double d = display.getNumber();
                    display.putNumber(d);

                    inputHandlers[inPressedDigit]();


                }
            }

            lastInput = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            return display.getNumberDisplay();
        }
    }


}
