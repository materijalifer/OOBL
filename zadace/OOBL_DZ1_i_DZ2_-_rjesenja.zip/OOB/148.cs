﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks;
        private List<Index> _indices;
        private List<Portfolio> _portfolios;

        public StockExchange()
        {
            _stocks = new List<Stock>();
            _indices = new List<Index>();
            _portfolios = new List<Portfolio>();
        }

        //dodaje dionicu s početnom cijenom na burzu
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            var stockName = inStockName.ToLower();

            if (_stocks.Any(stock1 => stock1.Name == stockName))
            {
                throw new StockExchangeException("Dionica istog imena vec postoji");
            }

            var stock = new Stock(stockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            _stocks.Add(stock);
        }

        //briše dionicu s burze
        public void DelistStock(string inStockName)
        {
            var stockName = inStockName.ToLower();
            //brisemo dionicu iz indexa i portfolija
            foreach (Index index in _indices.Where(index => index.HasStock(stockName)))
            {
                RemoveStockFromIndex(index.Name, stockName);
            }
            foreach (Portfolio portfolio in _portfolios.Where(p => p.HasStock(stockName)))
            {
                RemoveStockFromPortfolio(portfolio.ID, stockName);
            }

            try
            {
                _stocks.RemoveAll(s => s.Name == stockName);
            }
            catch
            {
                throw new StockExchangeException("Dionica koju zelite maknuti sa burze ne postoji");
            }
        }

        //provjerava postoji li tražena dionica na burzi
        public bool StockExists(string inStockName)
        {
            return _stocks.Any(stock => stock.Name == inStockName.ToLower());
        }

        //vraća broj dionica na burzi
        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        //postavlja novu cijenu dionice
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            var stock = GetStock(inStockName);
            stock.ChangePrice(inStockValue, inIimeStamp);
        }

        //dohvaća cijenu koju je dionica imala u nekom trenutku
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            var stock = GetStock(inStockName);
            return stock.GetPrice(inTimeStamp);
        }

        //dohvaća početnu cijenu dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            var stock = GetStock(inStockName);
            return stock.GetInitialPrice();
        }

        //dohvaća zadnju cijenu dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            var stock = GetStock(inStockName);
            return stock.GetLastPrice();
        }



        //stvara novi indeks na burzi
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            var indexName = inIndexName.ToLower();
            if (_indices.Any(i => i.Name == indexName))
            {
                throw new StockExchangeException("Index istog imena vec postoji");
            }

            Index index;
            if (inIndexType == IndexTypes.AVERAGE)
                index = new AvarageIndex(indexName);
            else if (inIndexType == IndexTypes.WEIGHTED)
                index = new WeightedIndex(indexName);
            else
                throw new StockExchangeException("Indeks krivoga tipa.");

            _indices.Add(index);
        }

        //dodaje dionicu u indeks
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            var index = GetIndex(inIndexName);
            var stock = GetStock(inStockName);
            index.AddStock(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            var index = GetIndex(inIndexName);
            var stock = GetStock(inStockName);
            index.RemoveStock(stock);
        }

        //provjerava je li dionica u indeksu
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            var index = GetIndex(inIndexName);
            return index.HasStock(inStockName.ToLower());
        }

        //dohvaća vrijednost indeksa
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            var index = GetIndex(inIndexName);
            return index.GetValue(inTimeStamp);
        }

        //provjerava postoji li traženi indeks na burzi
        public bool IndexExists(string inIndexName)
        {
            return _indices.Any(index => index.Name == inIndexName.ToLower());
        }

        //dohvaća broj indeksa na burzi
        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        //dohvaća broj dionica u traženom indeksu
        public int NumberOfStocksInIndex(string inIndexName)
        {
            var index = GetIndex(inIndexName);
            return index.NumOfStocks();
        }



        //stvara novi portfolio na burzi
        public void CreatePortfolio(string inPortfolioID)
        {
            if (_portfolios.Any(p => p.ID == inPortfolioID))
                throw new StockExchangeException("Portfilo sa istim IDem vec postoji");

            _portfolios.Add(new Portfolio(inPortfolioID));
        }

        //dodaje određeni broj dionica u portfolio
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            var stock = GetStock(inStockName);

            //provjera ima li dionica koje zelimo staviti u portfelj na burzi
            var numOfSharesNotInPortvolios = stock.NumOfShares;
            foreach (Portfolio p in _portfolios.Where(p => p.HasStock(inStockName)))
            {
                numOfSharesNotInPortvolios -= p.NumberOfSharesOfStock(inStockName);
            }
            if(numOfSharesNotInPortvolios < numberOfShares)
                throw new StockExchangeException("U portfelj zelite dodati vise dionica nego sto ih je na burzi");

            portfolio.AddStock(new StockPackage(stock, numberOfShares));

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            portfolio.RemoveStock(inStockName.ToLower(), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            portfolio.RemoveStock(inStockName.ToLower());
        }

        //dohvaća broj portfolija na burzi
        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        //dohvaća broj dionica u traženom portfoliju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.Any(p => p.ID == inPortfolioID);
        }

        //provjerava nalazi li se dionica u portfoliju
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.HasStock(inStockName.ToLower());
        }

        //dohvaća broj dionice u traženom portfoliju
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.NumberOfSharesOfStock(inStockName.ToLower());
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            var portfolio = GetPortfolio(inPortfolioID);
            return portfolio.GetPercentChangeInValueForMonth(Year, Month);
        }


        private Stock GetStock(string stockName)
        {
            try
            {
                return _stocks.Where(s => s.Name == stockName.ToLower()).First();
            }
            catch
            {
                throw new StockExchangeException("Dionica sa navedenim imenom ne postoji na burzi.");
            }
        }

        private Index GetIndex(string indexName)
        {
            try
            {
                return _indices.Where(i => i.Name == indexName.ToLower()).First();
            }
            catch
            {
                throw new StockExchangeException("Indeks sa navedenim imenom ne postoji.");
            }
        }

        private Portfolio GetPortfolio(string portfolioID)
        {
            try
            {
                return _portfolios.Where(p => p.ID == portfolioID).First();
            }
            catch (Exception)
            {
                throw new StockExchangeException("Portfolio sa navedenim ID-em ne postoji.");
            }
        }
    }


    //*************************************************************************
    //                               STOCK
    //*************************************************************************
    public class Stock
    {
        public String Name { get; set; }
        public long NumOfShares { get; set; }
        private List<StockValue> _values;

        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Broj dionica ne smije biti nula ili negativan");
            if (initialPrice <= 0)
                throw new StockExchangeException("Cijena dionice ne smije biti nula ili negativna");

            Name = stockName;
            NumOfShares = numberOfShares;
            _values = new List<StockValue> {new StockValue(initialPrice, timeStamp)};
        }

        public void ChangePrice(decimal price, DateTime timeStamp)
        {
            //staroj cijeni stavlja datum do kada vrijedi
            var lastValue = _values.Where(v => v.EndTimeStamp == DateTime.MaxValue).First();
            lastValue.EndTimeStamp = timeStamp;

            _values.Add(new StockValue(price, timeStamp));
        }

        public decimal GetPrice(DateTime timeStamp)
        {
            try
            {
                return
                    Decimal.Round(
                        _values.Where(v => v.StartTimeStamp <= timeStamp && timeStamp < v.EndTimeStamp).First().Price, 3);
            }
            catch
            {
                throw new StockExchangeException("Cijena dionice nije definirana za dani trenutak.");
            }
        }

        public decimal GetInitialPrice()
        {
            //trazi najstariji trenutak u kojem je definirana cijena
            var firstTimeStamp = DateTime.MaxValue;
            foreach (var stockValue in _values)
            {
                if (stockValue.StartTimeStamp < firstTimeStamp) 
                    firstTimeStamp = stockValue.StartTimeStamp;
            }

            return Decimal.Round(_values.Where(v => v.StartTimeStamp == firstTimeStamp).First().Price, 3);
        }

        public decimal GetLastPrice()
        {
            //trenutno aktualna cijena ima vrijeme do kada je aktivna postavljeno na DateTie.MaxValue
            return Decimal.Round(_values.Where(v => v.EndTimeStamp == DateTime.MaxValue).First().Price, 3);
        }

        //funkcija koja vraca virjednost dionice, koristi se u racunanju vrijednosti indexa
        public decimal GetTotalValue(DateTime timeStamp)
        {
            return GetPrice(timeStamp)*NumOfShares;
        }
    }

    public class StockValue
    {
        public DateTime StartTimeStamp { get; set; }
        public DateTime EndTimeStamp { get; set; }
        public Decimal Price { get; set; }

        public StockValue(decimal initialPrice, DateTime timeStamp)
        {
            Price = initialPrice;
            StartTimeStamp = timeStamp;
            //vrijeme do kada vrijedi cijena se postavlja na DateTime.MaxValue
            //zato sto DateTime nema null vrijednost
            //da je postavljena na minValue zakompliciralo bi se trazenje cijene za odredjeni trenutak
            EndTimeStamp = DateTime.MaxValue;
        }
    }

    //*************************************************************************
    //                               INDEX
    //*************************************************************************
    public abstract class Index
    {
        protected List<Stock> StocksInIndex;
        public string Name { get; set; }

        public abstract Decimal GetValue(DateTime timeStamp);

        protected Index(string name)
        {
            Name = name;
            StocksInIndex = new List<Stock>();
        }

        public void AddStock(Stock stock)
        {
            if(!HasStock(stock.Name))
                StocksInIndex.Add(stock);
        }

        public int NumOfStocks()
        {
            return StocksInIndex.Count;
        }

        public void RemoveStock(Stock stock)
        {
            StocksInIndex.Remove(stock);
        }

        internal bool HasStock(string inStockName)
        {
            return StocksInIndex.Any(s => s.Name == inStockName);
        }
    }

    public class AvarageIndex : Index
    {
        public AvarageIndex(string name) : base(name) {}

        public override decimal GetValue(DateTime timeStamp)
        {
            var sum = StocksInIndex.Sum(index => index.GetPrice(timeStamp));
            return Decimal.Round(sum / NumOfStocks(), 3);
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string name) : base(name) {}

        public override decimal GetValue(DateTime timeStamp)
        {
            //value dionice je cijena*(cijena*broj)/sum(cijena*broj)svihDionica
            var totalValue = StocksInIndex.Sum(stock => stock.GetPrice(timeStamp)*stock.NumOfShares);
            var value = StocksInIndex.Sum(s => s.GetPrice(timeStamp)*s.GetTotalValue(timeStamp)/totalValue);
            return Decimal.Round(value, 3);
        }
    }


    //*************************************************************************
    //                              PORTFOLIO
    //*************************************************************************
    public class Portfolio
    {
        public string ID { get; private set; }
        private List<StockPackage> _stocksInPortfolio;

        public Portfolio(string id)
        {
            ID = id;
            _stocksInPortfolio = new List<StockPackage>();
        }

        public bool HasStock(string stockName)
        {
            return _stocksInPortfolio.Any(p => p.StockName == stockName);
        }

        public void AddStock(StockPackage stockPackage)
        {
            if (_stocksInPortfolio.Any(s => s.StockName == stockPackage.StockName))
            {
                var package = GetStock(stockPackage.StockName);
                package.NumOfShares += stockPackage.NumOfShares;
                return;
            }

            _stocksInPortfolio.Add(stockPackage);

        }

        public int NumberOfSharesOfStock(string stockName)
        {
            var package = GetStock(stockName);
            return package.NumOfShares;
        }

        public int NumberOfStocks()
        {
            return _stocksInPortfolio.Count;
        }

        public void RemoveStock(string stockName, int numberOfShares)
        {
            var package = GetStock(stockName);
            if (package.NumOfShares - numberOfShares < 0)
                throw new StockExchangeException("Zelite uzeti vise dionica nego sto ih ima.");
            
            package.NumOfShares -= numberOfShares;
            if (package.NumOfShares == 0)
                RemoveStock(stockName);
        }

        public void RemoveStock(string stockName)
        {
            try
            {
                _stocksInPortfolio.RemoveAll(s => s.StockName == stockName);
            }
            catch
            {
                throw new StockExchangeException("");
            }
        }

        private StockPackage GetStock(string stockName)
        {
            try
            {
                return _stocksInPortfolio.Where(s => s.StockName == stockName).First();
            }
            catch
            {
                throw new StockExchangeException("Dionice koju trazite nema u portfoliju");
            }
        }

        public decimal GetValue(DateTime timeStamp)
        {
            decimal value = 0;
            foreach (StockPackage stock in _stocksInPortfolio)
            {
                value += stock.GetPrice(timeStamp);
            }

            return decimal.Round(value, 3);
        }

        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            decimal startValue = GetValue(new DateTime(year, month, 1, 00, 00, 00, 00));
            int numberOfDays = DateTime.DaysInMonth(year, month);
            decimal endValue = GetValue(new DateTime(year, month, numberOfDays, 23, 59, 59, 999));

            return Decimal.Round(((endValue - startValue)/startValue)*100, 3);
        }
    }

    public class StockPackage
    {
        public Stock Stock { get; set; }
        public int NumOfShares { get; set; }

        public StockPackage(Stock stock, int numOfShares)
        {
            Stock = stock;
            NumOfShares = numOfShares;
        }

        public string StockName
        {
            get { return Stock.Name; }
        }

        public decimal GetPrice(DateTime timeStamp)
        {
            return Stock.GetPrice(timeStamp);
        }
    }
}
