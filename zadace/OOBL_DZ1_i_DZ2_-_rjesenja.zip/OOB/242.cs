﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
            
        }
    }

    public class Kalkulator : ICalculator
    {
        #region const
        const string ispisError = "-E-";
        const string pocetniIspis = "0";
        #endregion

        #region enum
        enum UlazniZnakovi
        {
            plus = BinarneOperacije.zbrajanje,
            minus = BinarneOperacije.oduzimanje,
            puta = BinarneOperacije.mnozenje,
            djeljeno = BinarneOperacije.djeljenje,
            rezultat_unarni = '=',
            zarez = ',',
            predznak = 'M',
            sinus = 'S',
            cosinus = 'K',
            tanges = 'T',
            kvadrat = 'Q',
            korjen = 'R',
            inverz = 'I',
            spremanjeMemorije = 'P',
            dohvatMemorije = 'G',
            brisanje = 'C',
            reset = 'O'

        };
        enum ZadnjaOperacija
        {
            binarniOperator,
            broj,
            rezultat,
            unarniOperator
        };
        enum BinarneOperacije
        {
            zbrajanje = '+',
            oduzimanje = '-',
            mnozenje = '*',
            djeljenje = '/',
            bezOperacije = '?'
        }
        #endregion

        #region fields
        private string display = pocetniIspis;
        private string memory = pocetniIspis;
        private bool error = false;

        private string firstNumber = pocetniIspis;
        private char operation = (char)BinarneOperacije.bezOperacije;
        private ZadnjaOperacija znak = ZadnjaOperacija.broj;
        private string drugiOperatorRezultata = pocetniIspis;


        #endregion

        #region public
        public string GetCurrentDisplayState()
        {
            return display;
        }
        public void Press(char inPressedDigit)
        {
            if (error)
            {
                switch (inPressedDigit)
                {
                    case (char)UlazniZnakovi.brisanje:
                        Clear();
                        break;
                    case (char)UlazniZnakovi.reset:
                        Reset();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (inPressedDigit)
                {
                    case (char)UlazniZnakovi.predznak:
                        PromjenaPredznaka();
                        break;
                    case (char)UlazniZnakovi.sinus:
                        Sinus();
                        break;
                    case (char)UlazniZnakovi.cosinus:
                        Cosinus();
                        break;
                    case (char)UlazniZnakovi.tanges:
                        Tanges();
                        break;
                    case (char)UlazniZnakovi.kvadrat:
                        Kvadrat();
                        break;
                    case (char)UlazniZnakovi.korjen:
                        Korjen();
                        break;
                    case (char)UlazniZnakovi.inverz:
                        Inverz();
                        break;
                    case (char)UlazniZnakovi.spremanjeMemorije:
                        SpremanjeMemorije();
                        break;
                    case (char)UlazniZnakovi.dohvatMemorije:
                        DohvacanjeMemorije();
                        break;
                    case (char)UlazniZnakovi.brisanje:
                        Clear();
                        break;
                    case (char)UlazniZnakovi.reset:
                        Reset();
                        break;
                    case (char)UlazniZnakovi.plus:
                        Plus();
                        break;
                    case (char)UlazniZnakovi.minus:
                        Minus();
                        break;
                    case (char)UlazniZnakovi.puta:
                        Puta();
                        break;
                    case (char)UlazniZnakovi.djeljeno:
                        Djeljeno();
                        break;
                    case (char)UlazniZnakovi.rezultat_unarni:
                        Izracun();
                        break;
                    case (char)UlazniZnakovi.zarez:
                        DecimalniZarez();
                        break;
                    default:
                        DodavanjeBroja(inPressedDigit);
                        break;
                }

            }
        }
        #endregion

        #region private

        #region pomocneFunkcije

        private void OgranicavanjeBrojaZnamenaka(double znamenke)
        {
            int duzinaBroja = Math.Round(Math.Abs(znamenke), 0).ToString().Length;
            if (duzinaBroja > 10)
            {
                display = ispisError;
            }
            display = ((decimal)Math.Round(znamenke, 10 - duzinaBroja)).ToString();
        }

        private int DigitCounter()
        {
            int counter = 0;
            foreach (char i in display)
            {
                if (i >= '0' && i <= '9')
                {
                    counter++;
                }
            }
            return counter;
        }

        private void Izracun(char novaOperacija)
        {
            switch (operation)
            {
                case (char)BinarneOperacije.bezOperacije:
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                    break;
                case (char)BinarneOperacije.zbrajanje:
                    Zbroji();
                    break;
                case (char)BinarneOperacije.oduzimanje:
                    Oduzmi();
                    break;
                case (char)BinarneOperacije.mnozenje:
                    Pomnozi();
                    break;
                case (char)BinarneOperacije.djeljenje:
                    Podjeli();
                    break;

            }
            operation = novaOperacija;
            znak = ZadnjaOperacija.binarniOperator;
            firstNumber = display;
        }
        #endregion

        #region tipke
        private void DodavanjeBroja(char noviBroj)
        {
            if (znak == ZadnjaOperacija.broj)
            {
                if (DigitCounter() < 10)
                {
                    display = display + noviBroj;
                    if (!(noviBroj == '0' && display.Contains(',')))
                    {
                        OgranicavanjeBrojaZnamenaka(double.Parse(display));
                    }
                }
            }
            else
            {
                display = "" + noviBroj;
            }

            znak = ZadnjaOperacija.broj;

        }

        private void Podjeli()
        {
            try
            {
                if (display != pocetniIspis)
                {
                    double broj = double.Parse(firstNumber) / double.Parse(display);
                    OgranicavanjeBrojaZnamenaka(broj);
                }
                else
                {
                    display = ispisError;
                    error = true;
                }
            }
            catch
            {
                display = ispisError;
                error = true;
            }
        }

        private void Pomnozi()
        {
            try
            {
                double broj = double.Parse(firstNumber) * double.Parse(display);
                OgranicavanjeBrojaZnamenaka(broj);
            }
            catch
            {
                display = ispisError;
                error = true;
            }
        }

        private void Oduzmi()
        {
            try
            {
                double broj = double.Parse(firstNumber) - double.Parse(display);
                OgranicavanjeBrojaZnamenaka(broj);
            }
            catch
            {
                display = ispisError;
                error = true;
            }
        }

        private void Zbroji()
        {
            try
            {
                double broj = double.Parse(firstNumber) + double.Parse(display);
                OgranicavanjeBrojaZnamenaka(broj);
            }
            catch
            {
                display = ispisError;
                error = true;
            }
        }

        private void Izracun()
        {
            if (znak != ZadnjaOperacija.rezultat)
            {
                drugiOperatorRezultata = display;
            }
            else
            {
                firstNumber = display;
                display = drugiOperatorRezultata;
            }
            switch (operation)
            {
                case (char)BinarneOperacije.bezOperacije:
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                    break;
                case (char)BinarneOperacije.zbrajanje:
                    Zbroji();
                    break;
                case (char)BinarneOperacije.oduzimanje:
                    Oduzmi();
                    break;
                case (char)BinarneOperacije.mnozenje:
                    Pomnozi();
                    break;
                case (char)BinarneOperacije.djeljenje:
                    Podjeli();
                    break;
            }
            znak = ZadnjaOperacija.rezultat;
            firstNumber = pocetniIspis;
        }

        private void Djeljeno()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)BinarneOperacije.bezOperacije)
                {
                    Izracun((char)BinarneOperacije.djeljenje);
                }
                else
                {
                    operation = (char)BinarneOperacije.djeljenje;
                    firstNumber = display;
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)BinarneOperacije.djeljenje;
                firstNumber = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)BinarneOperacije.djeljenje;
            }
            znak = ZadnjaOperacija.binarniOperator;

        }

        private void Puta()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)BinarneOperacije.bezOperacije)
                {
                    Izracun((char)BinarneOperacije.mnozenje);
                }
                else
                {
                    operation = (char)BinarneOperacije.mnozenje;
                    firstNumber = display;
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)BinarneOperacije.mnozenje;
                firstNumber = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)BinarneOperacije.mnozenje;
            }
            znak = ZadnjaOperacija.binarniOperator;

        }

        private void Minus()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)BinarneOperacije.bezOperacije)
                {
                    Izracun((char)BinarneOperacije.oduzimanje);
                }
                else
                {
                    operation = (char)BinarneOperacije.oduzimanje;
                    firstNumber = display;
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)BinarneOperacije.oduzimanje;
                firstNumber = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)BinarneOperacije.oduzimanje;
            }
            znak = ZadnjaOperacija.binarniOperator;

        }

        private void Plus()
        {
            if (znak == ZadnjaOperacija.broj || znak == ZadnjaOperacija.unarniOperator)
            {
                if (operation != (char)BinarneOperacije.bezOperacije)
                {
                    Izracun((char)BinarneOperacije.zbrajanje);
                }
                else
                {
                    operation = (char)BinarneOperacije.zbrajanje;
                    firstNumber = display;
                    OgranicavanjeBrojaZnamenaka(double.Parse(display));
                }
            }
            else if (znak == ZadnjaOperacija.rezultat)
            {
                operation = (char)BinarneOperacije.zbrajanje;
                firstNumber = display;

            }
            else if (znak == ZadnjaOperacija.binarniOperator)
            {
                operation = (char)BinarneOperacije.zbrajanje;
            }

            znak = ZadnjaOperacija.binarniOperator;

        }

        private void Reset()
        {
            display = pocetniIspis;
            memory = pocetniIspis;
            error = false;

            firstNumber = pocetniIspis;
            operation = (char)BinarneOperacije.bezOperacije;
            znak = ZadnjaOperacija.broj;
            drugiOperatorRezultata = pocetniIspis;

        }

        private void Clear()
        {
            if (error)
            {
                operation = (char)BinarneOperacije.bezOperacije;
            }
            display = pocetniIspis;
            error = false;
            znak = ZadnjaOperacija.broj;
            
        }

        private void DohvacanjeMemorije()
        {
            display = memory;
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void SpremanjeMemorije()
        {
            memory = display;
        }

        private void Inverz()
        {
            if (display == pocetniIspis)
            {
                display = ispisError;
                error = true;
            }
            else
            {
                double broj = double.Parse(display);
                broj = 1 / broj;
                OgranicavanjeBrojaZnamenaka((double)broj);
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void Korjen()
        {
            double broj = double.Parse(display);
            try
            {
                broj = Math.Sqrt(broj);
                OgranicavanjeBrojaZnamenaka(broj);
            }
            catch
            {
                display = ispisError;
                error = true;
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void Kvadrat()
        {
            double broj = double.Parse(display);
            try
            {
                broj = Math.Pow(broj, 2);
                OgranicavanjeBrojaZnamenaka(broj);
            }
            catch
            {
                display = ispisError;
                error = true;
            }
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void Tanges()
        {
            double broj = double.Parse(display);
            broj = Math.Tan(broj);
            OgranicavanjeBrojaZnamenaka(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void Cosinus()
        {
            double broj = double.Parse(display);
            broj = Math.Cos(broj);
            OgranicavanjeBrojaZnamenaka(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void Sinus()
        {
            double broj = double.Parse(display);
            broj = Math.Sin(broj);
            OgranicavanjeBrojaZnamenaka(broj);
            znak = ZadnjaOperacija.unarniOperator;
        }

        private void DecimalniZarez()
        {
            if (znak == ZadnjaOperacija.broj)
            {
                if (!display.Contains(','))
                {
                    display = display + ',';
                }
            }
            else
            {
                Clear();
                display = display + ',';
            }
            znak = ZadnjaOperacija.broj;
        }

        private void PromjenaPredznaka()
        {
            
            if (display.Contains('-'))
            {
                display = display.Replace("-", "");
            }
            else
            {
                display = '-' + display;
            }
        }
        #endregion

        #endregion

    }
}
