﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
    public interface Operator
    {
        double operate(double number1, double number2 = 0);
        bool IsBinary();
    }
    public class Kalkulator : ICalculator
    {

        List<char> outDisplay = new List<char> { '0' };
        List<char> inDisplay = new List<char> { '0' };
        List<char> binarny = new List<char> { '+', '-', '*', '/' };
        double memory = 0;
        bool binaryOperator = false;
        char before;
        Operator currentBinaryOperator;
        bool firstDigit = false;
        double ans = 0;
        double oldAns = 0;
        int numberDecimal = -3;
        bool negative = false;

        public void Press(char inPressedDigit)
        {
            // ako se pritišću samo nule
            if (firstDigit == false && inPressedDigit != '0')
            {
                firstDigit = true;
                inDisplay.Remove('0');
            }
            //ako je pritisnuta tipka koja nije 0
            if (firstDigit == true)
            {
                //ako je opertor
                if (inPressedDigit < 48 || inPressedDigit > 57)
                {
                    //ako je M i negavit= false, broj je negativan
                    //ao je M i negativ= true; broj je pozitivan
                    // ne piši M u indisplay
                    // prikaži ans do sada
                    if (inPressedDigit == 'M')
                    {
                        if (negative == false)
                        {
                            negative = true;
                            if (before >= 48 && before <= 67)
                                ans = TenDigits(GetNumber(0, numberDecimal));
                            ans *= -1;
                            SetDisplay(ans);
                        }
                        else
                        {
                            negative = false;
                            if (before >= 48 && before <= 67)
                                ans = TenDigits(GetNumber(0, numberDecimal));
                            ans *= -1;
                            SetDisplay(ans);
                        }

                    }
                    // ako je , pamti index od zadnjeg broja prije ,
                    // upisi , u inDispay
                    else if (inPressedDigit == ',' && !inDisplay.Contains(','))
                    {
                        inDisplay.Add(inPressedDigit);
                        numberDecimal = inDisplay.Count - 2;
                        ans = TenDigits(GetNumber(0, numberDecimal));
                        SetDisplay(ans);
                        outDisplay.Add(',');
                    }
                    //ako se vec desio , ne radi nista (return)
                    else if (inPressedDigit == ',' && inDisplay.Contains(','))
                    {
                        return;
                    }
                    //on(off gumb
                    else if (inPressedDigit == 'O')
                    {
                        OnOff();
                    }
                    //clear gumb
                    else if (inPressedDigit == 'C')
                    {
                        Clear();
                    }
                    //put gumb
                    else if (inPressedDigit == 'P')
                    {
                        Put(ans);
                    }
                    //get gumb
                    else if (inPressedDigit == 'G')
                    {
                        ans = Get();
                        SetDisplay(ans);
                    }
                    //ako nije = (jednako nam izračunava sve)
                    else if (inPressedDigit != '=')
                    {
                        // ucitaj broj prije operatora
                        if (inDisplay.Count != 0)
                        {
                            ans = TenDigits(GetNumber(0, numberDecimal));
                            if (negative == true)
                                ans *= -1;
                        }
                        // učitaj opertator i ispiši broj na zaslon
                        Operator op = FactoryOperator.CreateOperator(inPressedDigit);
                        SetDisplay(ans);
                        //ako nije binarno radi operaciju operatora
                        // postavi novi ans, izbrisi inDispay i postavi na zaslonu ans
                        if (op.IsBinary() == false)
                        {
                            ans = TenDigits(op.operate(ans));
                            inDisplay.Clear();
                            negative = false;
                            numberDecimal = -3;
                            SetDisplay(ans);
                        }
                        //ako je operator binarni
                        else
                        {
                            //ako je prvi put doso binarni operator ({broj}{operator})
                            // spremi trenutno ans kao oldans (prvi operand)
                            // cuvaj trenutni binarni opertor
                            // binaryOperator = true; označava je stisnut binarni operator
                            if (binaryOperator == false)
                            {
                                binaryOperator = true;
                                currentBinaryOperator = op;
                                oldAns = ans;
                                inDisplay.Clear();
                                negative = false;
                                numberDecimal = -3;
                            }
                            //ponavljanje binarnih operatora
                            // spremi zadnji
                            else if (binarny.Contains(before))
                            {
                                op = FactoryOperator.CreateOperator(inPressedDigit);
                                currentBinaryOperator = op;
                            }
                            //zadnji binarni i stisnut je novi binarni operator ({broj1}{operator1}{broj2}{operator2})
                            //radi operaciju (oldAns {operator} ans)
                            // izbriši inDispay, ispisi ans
                            // sačuvaj novi binarni operator kao trenutni
                            // oldAns je trenutni ans {oldAns}{operator2}
                            else
                            {
                                ans = TenDigits(currentBinaryOperator.operate(oldAns, ans));
                                inDisplay.Clear();
                                numberDecimal = -3;
                                negative = false;
                                SetDisplay(ans);
                                op = FactoryOperator.CreateOperator(inPressedDigit);
                                currentBinaryOperator = op;
                                oldAns = ans;
                            }
                        }
                    }
                    //ako je stisut =

                    else
                    {
                        //ako je znak prije binarni operator odlsAns= ans 
                        //{broj}{operator}{=} je oldAns {operator} ans tj {broj} {operator} {broj}
                        if (binarny.Contains(before))
                            oldAns = ans;
                        //ako postoji operatir koji je potrebno izvršiti
                        if (currentBinaryOperator != null)
                            ans = TenDigits(currentBinaryOperator.operate(oldAns, ans));
                        //inače ispiši ans prijašnje stanje
                        inDisplay.Clear();
                        numberDecimal = -3;
                        negative = false;
                        SetDisplay(ans);
                        binaryOperator = false;
                        currentBinaryOperator = null;
                        negative = false;
                    }
                }
                //ako je stisnut broj
                //spremi ga u inDispay
                //učitaj cijeli inDispay kao ans 
                //ispiši stisnuti broj
                else
                {
                    if (!inDisplay.Contains(',') && inDisplay.Count == 10)
                        return;
                    inDisplay.Add(inPressedDigit);
                    ans = TenDigits(GetNumber(0, numberDecimal));
                    if (negative == true)
                        ans = ans * -1;
                    SetDisplay(ans);
                }
                //čuvaj prijašnje stisnuti gumb
                //potrebo za provjere ponavljanja
                before = inPressedDigit;
            }

        }

        //vrati trenutnu vrijednost displaya
        public string GetCurrentDisplayState()
        {
            // trenutno stanje se nalazi u varijabli outDisplay
            // vrati outDisplay kao string
            string stringDispay = "";
            foreach (char digit in outDisplay)
                stringDispay = stringDispay + digit.ToString();
            return stringDispay;
        }

        //postavi number kao dispay
        public void SetDisplay(double number)
        {
            // ako je doslo do pogreske u računanju (djeljenje s nulom, preveliki broj i td..)
            //ispisi -E-
            if (Double.IsInfinity(number) || Double.IsNaN(number) || number > 9999999999)
            {
                outDisplay.Clear();
                outDisplay.Add('-');
                outDisplay.Add('E');
                outDisplay.Add('-');
            }
            //inače izbriši prijašnje stanje i postavi number kao trenutno stanje
            else
            {
                outDisplay.Clear();
                Char[] displayChar;
                displayChar = number.ToString().ToCharArray();
                foreach (char digit in displayChar)
                    outDisplay.Add(digit);

                if (outDisplay.Contains('E'))
                    outDisplay = ExpToNumber(outDisplay);
            }
        }

        //eksponencionalni zapis u broj
        private List<char> ExpToNumber(List<char> number)
        {
            List<char> numberExp = new List<char>();
            List<char> returnNumber = new List<char> { '0', ',' };
            int exp = 0, decimalDigits = 0;
            if (number[0] == '-')
            {
                returnNumber.Insert(0, '-');
                number.RemoveAt(0);
            }
            for (int i = 0; i < number.IndexOf('E'); i++)
            {
                numberExp.Add(number[i]);
                if (number[i] == ',')
                    decimalDigits = number.IndexOf('E') - i - 1;
            }

            exp = Convert.ToInt32(number[number.IndexOf('E') + 3]) - 48 + decimalDigits;
            numberExp.Remove(',');
            for (int i = 0; i < exp - numberExp.Count; i++)
            {
                returnNumber.Add('0');
            }

            returnNumber.AddRange(numberExp);
            return returnNumber;
        }
        //učitaj broj iz inDispaya tj iz zaslona
        private double GetNumber(int startIndex, int numberDecimal)
        {
            List<char> displayCopy = new List<char>();
            for (int i = startIndex; i < inDisplay.Count; i++)
            {
                if (inDisplay[i] != 'M')
                    displayCopy.Add(inDisplay[i]);
            }
            double number = 0;
            // ako je decimalni broj
            if (numberDecimal > -2)
            {
                double multiply = Math.Pow(10, numberDecimal);
                // cijelobrojni dio
                for (int i = numberDecimal + 1; i > 0; i--)
                {
                    number += (displayCopy[numberDecimal + 1 - i] - 48) * multiply;
                    multiply /= 10;
                }
                //decimalni dio
                for (int i = numberDecimal + 2; i < displayCopy.Count; i++)
                {
                    number += (displayCopy[i] - 48) * multiply;
                    multiply /= 10;
                }
            }
            //ako nije decimalni broj
            else
            {
                double multiply = Math.Pow(10, displayCopy.Count - 1);
                for (int i = 0; i < displayCopy.Count; i++)
                {
                    number += (displayCopy[i] - 48) * multiply;
                    multiply /= 10;
                }
            }
            return number;

        }


        //zaokruživanje na 10 znakova
        private double TenDigits(double number)
        {
            // ako je doslo do pogreške vrati pogrešku (djeljenje s 0, preveliki broj i td.)
            if (Double.IsInfinity(number) || Double.IsNaN(number) || number > 9999999999)
                return number;
            //ako je apsolutno broj veći od 1
            else if (Math.Abs(number) > 1)
            {
                // izračunaj broj znakova cijelogbrojnog dijela broja
                // koristeći log10
                int numberOfNonDecimals = Convert.ToInt32(Math.Floor(Math.Log10(Math.Abs(number)))) + 1;
                // zaokruži na (10- (broj znakova cijelogbrojnog dijela broja)) decimala
                return Math.Round(number, 10 - numberOfNonDecimals);
            }
            //ako je manji od 1 zaokruži na 9 decimala
            else
                return Math.Round(number, 9);
        }

        // operacija dodavanja u memoriju
        private void Put(double number)
        {
            memory = number;
        }

        // uzimanje iz memorije
        private double Get()
        {
            SetDisplay(memory);
            //ans = memory; ?
            return memory;
        }

        //brisanje zadnjeg unosa tj inDispay
        private void Clear()
        {
            SetDisplay(0);
            inDisplay.Clear();
            negative = false;
            numberDecimal = -3;
        }

        // on/off gumb
        private void OnOff()
        {
            memory = 0;
            inDisplay.Clear();
            negative = false;
            numberDecimal = -3;
            inDisplay.Add('0');
            currentBinaryOperator = null;
            ans = 0;
            outDisplay.Clear();
            outDisplay.Add('0');
        }


    }
    class FactoryOperator
    {
        public static Operator CreateOperator(char znak)
        {
            switch (znak)
            {
                case '+':
                    return new Plus();
                case '-':
                    return new Minus();
                case '*':
                    return new Multiply();
                case '/':
                    return new Divide();
                case 'S':
                    return new Sin();
                case 'K':
                    return new Cos();
                case 'T':
                    return new Tan();
                case 'Q':
                    return new Quadrat();
                case 'R':
                    return new Root();
                case 'I':
                    return new Invers();
                default:
                    return null;
            }
        }
    }

    class Plus : Operator
    {
        public double operate(double number1, double number2)
        {
            return number1 + number2;
        }
        public bool IsBinary()
        {
            return true;
        }

    }
    class Minus : Operator
    {
        public double operate(double number1, double number2)
        {
            return number1 - number2;
        }
        public bool IsBinary()
        {
            return true;
        }
    }
    class Multiply : Operator
    {
        public double operate(double number1, double number2)
        {
            return number1 * number2;
        }
        public bool IsBinary()
        {
            return true;
        }
    }
    class Divide : Operator
    {
        public double operate(double number1, double number2)
        {
            return number1 / number2;
        }
        public bool IsBinary()
        {
            return true;
        }
    }
    class Sin : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return Math.Sin(number);
        }
        public bool IsBinary()
        {
            return false;
        }
    }
    class Cos : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return Math.Cos(number);
        }
        public bool IsBinary()
        {
            return false;
        }
    }
    class Tan : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return Math.Tan(number);
        }
        public bool IsBinary()
        {
            return false;
        }
    }
    class Quadrat : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return number * number;
        }
        public bool IsBinary()
        {
            return false;
        }
    }
    class Root : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return Math.Sqrt(number);
        }
        public bool IsBinary()
        {
            return false;
        }
    }
    class Invers : Operator
    {
        public double operate(double number, double number2 = 0)
        {
            return 1 / number;
        }
        public bool IsBinary()
        {
            return false;
        }
    }




    




}
