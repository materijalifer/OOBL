﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> allStocks = new Dictionary<string, Stock>();
        private Dictionary<string, AbstractIndex> allIndices = new Dictionary<string, AbstractIndex>();
        private Dictionary<string, Portfolio> allPortfolios = new Dictionary<string, Portfolio>();
        private Dictionary<string, long> stocksLeft = new Dictionary<string, long>();

        /// <summary>
        /// dodaje dionicu s početnom cijenom na burzu
        /// </summary>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string _inStockName = inStockName.ToLower();
            if (allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " already exists!");
            if (allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " already exists!");
            if (inInitialPrice<=0)
                throw new StockExchangeException("Price can not be negative or null");
            if (inNumberOfShares <=0)
                throw new StockExchangeException("Number of shares has to be postive");
            allStocks.Add(_inStockName,
                new Stock(_inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            stocksLeft.Add(_inStockName, inNumberOfShares);
        }

        /// <summary>
        /// briše dionicu s burze
        /// </summary>
        public void DelistStock(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            

            foreach (string key in allIndices.Keys)
            {
                RemoveStockFromIndex(key, _inStockName);
            }

            foreach (string key in allPortfolios.Keys)
            {
                RemoveStockFromPortfolio(key, _inStockName);
            }

            allStocks.Remove(_inStockName);
            stocksLeft.Remove(_inStockName);
        }

        /// <summary>
        /// provjerava postoji li tražena dionica na burzi
        /// </summary>
        public bool StockExists(string inStockName)
        {
            return allStocks.ContainsKey(inStockName.ToLower());
        }

        /// <summary>
        /// vraća broj dionica na burzi
        /// </summary>
        public int NumberOfStocks()
        {
            return allStocks.Count();
        }

        /// <summary>
        /// postavlja cijenu dionice za određeno vrijeme
        /// </summary>
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            allStocks[_inStockName].SetPrice(inStockValue, inIimeStamp);
        }

        /// <summary>
        /// dohvaća cijenu dionice za neko vrijeme
        /// </summary>
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            return allStocks[_inStockName].GetPrice(inTimeStamp);
        }

        /// <summary>
        /// dohvaća početnu cijenu dionice
        /// </summary>
        public decimal GetInitialStockPrice(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist and cant read initial price!");
            return allStocks[_inStockName].InitialPrice;
        }

        /// <summary>
        /// dohvaća zadnju cijenu dionice
        /// </summary>
        public decimal GetLastStockPrice(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist and cant read last price!");
            return allStocks[_inStockName].Price;
        }

        /// <summary>
        /// stvara novi indeks na burzi
        /// </summary>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            string _inIndexName = inIndexName.ToLower();
            if (allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " already exists!");
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Index " + inIndexName + " is not supported!");

            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    allIndices.Add(_inIndexName, new AverageIndex(_inIndexName, allStocks));
                    break;
                case IndexTypes.WEIGHTED:
                    allIndices.Add(_inIndexName, new WeightedIndex(_inIndexName, allStocks));
                    break;
            }
        }

        /// <summary>
        /// dodaje dionicu u indeks
        /// </summary>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            string _inIndexName = inIndexName.ToLower();
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");

            if (!allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " does not exist!");

            allIndices[_inIndexName].AddStock(_inStockName);
        }

        /// <summary>
        /// briše dionicu iz indeksa
        /// </summary>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            string _inIndexName = inIndexName.ToLower();
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");

            if (!allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " does not exist!");
            
            allIndices[_inIndexName].RemoveStock(_inStockName);
        }

        /// <summary>
        /// provjerava je li dionica u indeksu
        /// </summary>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            string _inIndexName = inIndexName.ToLower();
            string _inStockName = inStockName.ToLower();
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");

            if (!allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " does not exist!");

            return allIndices[_inIndexName].IsPartOf(_inStockName);
        }

        /// <summary>
        /// dohvaća vrijednost indeksa
        /// </summary>
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            string _inIndexName = inIndexName.ToLower();

            if (!allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " does not exist!");

            return allIndices[_inIndexName].GetValue(inTimeStamp);
        }

        /// <summary>
        /// provjerava postoji li traženi indeks na burzi
        /// </summary>
        public bool IndexExists(string inIndexName)
        {
            string _inIndexName = inIndexName.ToLower();

            return allIndices.ContainsKey(_inIndexName);
        }

        /// <summary>
        /// dohvaća broj indeksa na burzi
        /// </summary>
        public int NumberOfIndices()
        {
            return allIndices.Count();
        }

        /// <summary>
        /// dohvaća broj dionica u traženom indeksu
        /// </summary>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            string _inIndexName = inIndexName.ToLower();
            if (!allIndices.ContainsKey(_inIndexName))
                throw new StockExchangeException("Index " + inIndexName + " does not exist!");
            return allIndices[_inIndexName].NumberOfStocks();
        }

        /// <summary>
        /// stvara novi portfolio na burzi
        /// </summary>
        public void CreatePortfolio(string inPortfolioID)
        {

            if (allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio" + inPortfolioID + "alreday exists!");
            allPortfolios.Add(inPortfolioID, new Portfolio(inPortfolioID, allStocks));
        }

        /// <summary>
        /// dodaje određeni broj dionica u portfolio 
        /// </summary>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string _inStockName = inStockName.ToLower();
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            if (stocksLeft[_inStockName] < numberOfShares)
            {
                //throw new StockExchangeException("Stock " + inStockName + " does not have that many shares!");
                allPortfolios[inPortfolioID].AddStocks(_inStockName, stocksLeft[_inStockName]);
                stocksLeft[_inStockName] = 0;
                return;
            }
            allPortfolios[inPortfolioID].AddStocks(_inStockName, numberOfShares);
            stocksLeft[_inStockName] = stocksLeft[_inStockName] - numberOfShares;
        }

        /// <summary>
        /// briše određeni broj dionica iz portfolija 
        /// </summary>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string _inStockName = inStockName.ToLower();
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            long numToFree = 0;
            allPortfolios[inPortfolioID].RemoveStocks(_inStockName, numberOfShares, out numToFree);
            stocksLeft[_inStockName] = stocksLeft[_inStockName] + numToFree;
        }

        /// <summary>
        /// briše dionicu iz portofolija
        /// </summary>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            //if (!allStocks.ContainsKey(_inStockName))
                //throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            long numToFree = 0;
            allPortfolios[inPortfolioID].RemoveStocks(_inStockName, out numToFree);
            stocksLeft[_inStockName] = stocksLeft[_inStockName] + numToFree;
        }

        /// <summary>
        /// dohvaća broj portfolija na burzi
        /// </summary>
        public int NumberOfPortfolios()
        {
            return allPortfolios.Count();
        }

        /// <summary>
        /// dohvaća broj dionica u traženom portfoliju
        /// </summary>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            return allPortfolios[inPortfolioID].NumberOfStocks;
        }

        /// <summary>
        /// provjerava postoji li traženi portfolio na burzi
        /// </summary>
        public bool PortfolioExists(string inPortfolioID)
        {
            return allPortfolios.ContainsKey(inPortfolioID);
        }

        /// <summary>
        /// provjerava nalazi li se dionica u portfoliju
        /// </summary>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            if (!allStocks.ContainsKey(_inStockName))
                //throw new StockExchangeException("Stock " + inStockName + " does not exist!");
                return false;
            return allPortfolios[inPortfolioID].IsStockPartOf(_inStockName);
        }

        /// <summary>
        /// dohvaća broj dionice u traženom portfoliju
        /// </summary>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            if (!allStocks.ContainsKey(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exist!");
            return (int) allPortfolios[inPortfolioID].NumberOfShares(_inStockName);
        }

        /// <summary>
        /// //dohvaća vrijednost portfolija u određenom trenutku
        /// </summary>
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            return allPortfolios[inPortfolioID].GetValue(timeStamp);
        }

        /// <summary>
        /// dohvaća mjeseću promjenu vrijednosti portfolija
        /// </summary>
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!allPortfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
            if (Month < 1 || Month >12)
                throw new StockExchangeException("Month is not valid!");
            return allPortfolios[inPortfolioID].GetChange(Year, Month);
        }
    }

    class Stock
    {
        public string stockName;
        public long numberOfShares { get; private set; }

        public Decimal Price { get; private set; }

        public Decimal InitialPrice
        {
            get { return historyTimesPrices.First().Value; }
        }
        private DateTime timeStamp;

        public SortedList<DateTime, Decimal> historyTimesPrices = new SortedList<DateTime, Decimal>();

        public Stock(string inStockName,long inNumberOfShares,Decimal inInitialPrice,DateTime inTimeStamp)
            {
                stockName = inStockName;
                numberOfShares = inNumberOfShares;
                Price = inInitialPrice;
                timeStamp = inTimeStamp;
                historyTimesPrices.Add(timeStamp, inInitialPrice);
            }

        public void SetPrice(Decimal inPrice, DateTime inTimeStamp)
        {
            if (historyTimesPrices.ContainsKey(inTimeStamp))
                throw new StockExchangeException("Price with timestamp "+inTimeStamp.ToString()+" already exists");
            
            const Decimal minPrice = 0;

            if (inPrice <= minPrice)
                throw new StockExchangeException("Price must be greater than 0!");
            
            if (inTimeStamp.CompareTo(historyTimesPrices.Keys.Last()) > 0)
            {
                Price = inPrice;
            }

            historyTimesPrices.Add(inTimeStamp,inPrice);
        }

        public Decimal GetPrice(DateTime inTimeStamp)
        {

            if (historyTimesPrices.First().Key.CompareTo(inTimeStamp) > 0)
                throw new StockExchangeException("Time stamp is invalid, stock didnt exsist then");

            if (historyTimesPrices.ContainsKey(inTimeStamp))
                return historyTimesPrices[inTimeStamp];

            DateTime closeTo = this.historyTimesPrices.First().Key;
            foreach (DateTime time in historyTimesPrices.Keys)
            {
                if (inTimeStamp < time)
                    break;
                closeTo = time;
            }
            return historyTimesPrices[closeTo];
        }
    }

    abstract class AbstractIndex
    {
        protected List<string> StocksInIndex = new List<string>();
        protected Dictionary<string, Stock> Stocks;
        public string Name { get; private set; }

        /// <summary>
        /// Konstruktor za apstraktni razred indexa
        /// </summary>
        protected AbstractIndex(string name, Dictionary<string, Stock> allStocks)
        {
            this.Name = name.ToLower();
            this.Stocks = allStocks;
        }

        /// <summary>
        /// Dodaje dionicu u indeks
        /// </summary>
        public void AddStock(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (StocksInIndex.Contains(_inStockName))
                throw new StockExchangeException("Index already contains stock " + inStockName + "!");

            StocksInIndex.Add(_inStockName);
        }

        /// <summary>
        /// Briše dionicu iz indeksa
        /// </summary>
        public void RemoveStock(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            if (!StocksInIndex.Contains(_inStockName))
                throw new StockExchangeException("Stock " + inStockName + " does not exsist in this index!");
            StocksInIndex.Remove(_inStockName);
        }

        /// <summary>
        /// Provjerava pripada li dionica indeksu
        /// </summary>
        public bool IsPartOf(string inStockName)
        {
            string _inStockName = inStockName.ToLower();
            return StocksInIndex.Contains(_inStockName);
        }

        /// <summary>
        /// Prebrojava broj dionica u indeksu
        /// </summary>
        public int NumberOfStocks()
        {
            return StocksInIndex.Count();
        }

        /// <summary>
        /// Abstraktna klasu za izračun vrijednosi, implementirana u izvedenim klasama
        /// </summary>
        public abstract Decimal GetValue(DateTime inTimeStamp);
    }

    class WeightedIndex : AbstractIndex
    {

        public WeightedIndex(string name, Dictionary<string, Stock> stocks) : base(name, stocks)
        { }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (string stockName in StocksInIndex)
            {
                sum += Stocks[stockName].GetPrice(inTimeStamp) * Stocks[stockName].numberOfShares;
            }

            decimal result = 0;
            foreach (string stockName in StocksInIndex)
            {
                result += Stocks[stockName].numberOfShares * Stocks[stockName].GetPrice(inTimeStamp) * Stocks[stockName].GetPrice(inTimeStamp) / sum;
            }

            return decimal.Round(result, 3);
        }
    }

    class AverageIndex : AbstractIndex
    {
        public AverageIndex(string name, Dictionary<string, Stock> stocks)
            : base(name, stocks)
        { }

        public override decimal GetValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (string stockName in StocksInIndex)
            {
                sum = sum + Stocks[stockName].GetPrice(inTimeStamp);
            }

            return decimal.Round(sum / (decimal)StocksInIndex.Count(), 3);
        }
    }

    class Portfolio
    {
        private string portfolioID;
        private Dictionary<string, Stock> allStocks;
        private Dictionary<string, long> stocks = new Dictionary<string, long>();
        public int NumberOfStocks
        {
            get { return stocks.Count; }
        }

        /// <summary>
        /// Konstruktor za apstraktni razred portofolija
        /// </summary>
        public Portfolio(string portfolioID, Dictionary<string, Stock> allStocks)
        {
            this.portfolioID = portfolioID;
            this.allStocks = allStocks;
        }

        /// <summary>
        /// Dodaje dionice u portofolio
        /// </summary>
        public void AddStocks(string stockName, long shares)
        {
            if (shares<0)
                throw new StockExchangeException("Number of shares can not be negative!");
            if (stocks.ContainsKey(stockName))
                stocks[stockName] += shares;
            else
                stocks.Add(stockName, shares);
        }

        /// <summary>
        /// Briše određen broj udjela dionica iz portofolija
        /// </summary>
        public void RemoveStocks(string stockName, long shares, out long numOfDeleted)
        {
            if (!stocks.ContainsKey(stockName))
                throw new StockExchangeException("Stock" + stockName + " is not a part of portfolio " + portfolioID + "!");
           
            if (stocks[stockName] < shares)
                throw new StockExchangeException("Stock " + stockName + "does not have " + shares +
                                                 "shares in portfolio " + portfolioID);

            stocks[stockName] -= shares;

            if (stocks[stockName] == 0)
                stocks.Remove(stockName);

            numOfDeleted = shares;
        }

        /// <summary>
        /// Briše dionicu iz portofolija i vraća broj koliko ima slobodnih udjela
        /// </summary>
        public void RemoveStocks(string stockName, out long numOfDeleted)
        {
            if (!stocks.ContainsKey(stockName))
                throw new StockExchangeException("Stock" + stockName + " is not a part of portfolio " + portfolioID + "!");
            numOfDeleted = stocks[stockName];
            stocks.Remove(stockName);
        }

        /// <summary>
        /// Provjerava postoji li dionica u portofoliju
        /// </summary>
        public bool IsStockPartOf(string stockName)
        {
            return stocks.ContainsKey(stockName);
        }

        /// <summary>
        /// Prebrojava koliko udjela ima koja dionica u portofoliju
        /// </summary>
        public long NumberOfShares(string stockName)
        {

            if (!stocks.ContainsKey(stockName))
                //throw new StockExchangeException("Portfolio " + portofolioID + "doesn't contain stock " + stockName + "!");
                return 0;
            else
                return stocks[stockName];
        }

        /// <summary>
        /// Vraća vrijednost portofolija u odrešenom trenutku
        /// </summary>
        public decimal GetValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (var stock in stocks)
            {
                sum = sum + stock.Value * allStocks[stock.Key].GetPrice(timeStamp);
            }
            return sum;
        }

        /// <summary>
        /// Računa porast/pad u vrijednosti portofolija kroz neki vremenski period
        /// </summary>
        public decimal GetChange(int year, int month)
        {
            DateTime monthStart = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime monthEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

            return decimal.Round(100 * ((GetValue(monthEnd) - GetValue(monthStart)) / (GetValue(monthStart))), 3);
        }
    }
}