﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> stockList;
         private Dictionary<string, Index> indexList;
         private Dictionary<string, Portfolio> portfolioList;

         public StockExchange()
         {
             stockList = new Dictionary<string, Stock>();
             indexList = new Dictionary<string, Index>();
             portfolioList = new Dictionary<string, Portfolio>();
         }

         /// <summary>
         /// Dodaje dionicu sa početnom cijenom i količinom na burzu
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <param name="inNumberOfShares">Broj dionica</param>
         /// <param name="inInitialPrice">Početna cijena dionice</param>
         /// <param name="inTimeStamp">Datum od kad ta cijena vrijedi</param>
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             // sprijčavanje dodavanje dionice koja već postoji
             string stockName = inStockName.ToUpper();
             if (stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica već postoji!");
             if (inInitialPrice <= 0)
                 throw new StockExchangeException("CIjena mora biti veća od 0!");
             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica mora biti veći od 0!");
             Stock stock = new Stock(stockName,inInitialPrice,inTimeStamp, inNumberOfShares);
             stockList.Add(stock.Name, stock);
         }

         /// <summary>
         /// Briše dionicu sa burze
         /// </summary>
         /// <param name="inStockName">Ime dionice koja se briše</param>
         public void DelistStock(string inStockName)
         {
             //Provjera postoji li dionica uopće na burzi
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Ne možete izbrisati dionicu koja ne psotoji!");
             stockList.Remove(stockName);
             Stock s = stockList[stockName];
             DeleteStockFromIndexes(s);
             DeleteStockFromPortfolio(s);
         }

         /// <summary>
         /// Briše dionicu iz svih idnexa
         /// </summary>
         /// <param name="s">Dionica koja se briše</param>
         private void DeleteStockFromIndexes(Stock s)
         {
             foreach (KeyValuePair<string, Index> element in indexList)
             {
                 if (element.Value.ContainsStock(s))
                     element.Value.RemoveStockFromIndex(s);
             }
         }

         /// <summary>
         /// Briše dionicu iz svih portfelja
         /// </summary>
         /// <param name="s">Dionica koja se briše</param>
         private void DeleteStockFromPortfolio(Stock s)
         {
             foreach (KeyValuePair<string, Portfolio> element in portfolioList)
                 if (element.Value.StockExist(s))
                     element.Value.DeleteStock(s);
         }

         /// <summary>
         /// Provjera psotoji li dionica na burzi
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <returns>True ako dionica postoji na burzi, u protivnom false</returns>
         public bool StockExists(string inStockName)
         {
             if (stockList.ContainsKey(inStockName.ToUpper()))
                 return true;
             else
                 return false;
         }

         /// <summary>
         /// Izračunava broj dionica na burzi
         /// </summary>
         /// <returns>Broj dionica na burzi</returns>
         public int NumberOfStocks()
         {
             return stockList.Count;
         }

         /// <summary>
         /// Postavlja cijenu dionice za određeno vrijeme
         /// </summary>
         /// <param name="inStockName">Ime dionice za koju se psotavlja cijena</param>
         /// <param name="inIimeStamp">Vrijeme za koje se postavlja cijena</param>
         /// <param name="inStockValue">Nova cijena dionice</param>
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             if (inStockValue <= 0)
                 throw new StockExchangeException("Cijena mora biti veća od 0!");
             Stock s = stockList[stockName];
             s.SetStockPrice(inIimeStamp, inStockValue);             
         }

         /// <summary>
         /// Dohvaća cijenu dionice za neko vrijeme
         /// </summary>
         /// <param name="inStockName">Ime dionice</param>
         /// <param name="inTimeStamp">Vrijeme za koje se želi saznati cijena</param>
         /// <returns>Cijena dionice</returns>
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             return s.GetStockValueByDate(inTimeStamp);
         }

         /// <summary>
         /// Vraća izvornu cijenu dionice
         /// </summary>
         /// <param name="inStockName">Ime dionice za koju se želi znati izvoran cijean</param>
         /// <returns>Izvoran cijena dionice</returns>
         public decimal GetInitialStockPrice(string inStockName)
         {
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             return s.InitialPrice;
         }

         /// <summary>
         /// Vraća zadnju evidentiranu cijenu dionice
         /// </summary>
         /// <param name="inStockName">Ime dionice za koju se traži cijena</param>
         /// <returns>Cijena dionice</returns>
         public decimal GetLastStockPrice(string inStockName)
         {
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             return s.LastRecordedPrice;
         }

         /// <summary>
         /// Stvara novi indeks na burzi
         /// </summary>
         /// <param name="inIndexName">Ime indeksa</param>
         /// <param name="inIndexType">Tip indeksa</param>
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             // sprijčavanje dodavanje indeksa koji već postoji
             string indexName = inIndexName.ToUpper();
             if (indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index već postoji!");
             Index index = new Index(inIndexName, inIndexType);
             indexList.Add(indexName, index);
         }

         /// <summary>
         /// Dodaje dionicu u index
         /// </summary>
         /// <param name="inIndexName">Index u koji se dodaje</param>
         /// <param name="inStockName">Dionica koja se dodaje</param>
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index ne postoji!");
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Index i = indexList[indexName];
             Stock s = stockList[stockName];
             i.AddStockToIndex(s);
         }

         /// <summary>
         /// Briše dionicu sa indexa
         /// </summary>
         /// <param name="inIndexName">Ime indeksa sa kojeg se briše</param>
         /// <param name="inStockName">Ime dionice koja se briše sa indexa</param>
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index ne postoji!");
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Index i = indexList[indexName];
             Stock s = stockList[stockName];
             i.RemoveStockFromIndex(s);
         }

         /// <summary>
         /// Provjerava je li određena dionica u određenom indeksu
         /// </summary>
         /// <param name="inIndexName">Ime indeksa</param>
         /// <param name="inStockName">Ime dionice</param>
         /// <returns></returns>
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index ne postoji!");
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Index i = indexList[indexName];
             Stock s = stockList[stockName];
             return i.ContainsStock(s);
         }

         /// <summary>
         /// Izračunava vrijednost indeksa
         /// </summary>
         /// <param name="inIndexName">Ime indeksa</param>
         /// <param name="inTimeStamp">Vrijeme za koje se računa vrijednost</param>
         /// <returns>Vrijednost indeksa</returns>
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index ne postoji!");
             Index index = indexList[indexName];
             return index.CalculateValue(inTimeStamp);
         }
        
         /// <summary>
         /// Provjerava postoji li traženi index na burzi
         /// </summary>
         /// <param name="inIndexName">Ime indeksa</param>
         /// <returns>Tru/false postoji li index na burzi ili ne</returns>
         public bool IndexExists(string inIndexName)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 return false;
             else
                 return true;
         }

         /// <summary>
         /// Izračunava broja indeksa na burzi
         /// </summary>
         /// <returns>Broj indeksa na burzi</returns>
         public int NumberOfIndices()
         {
             return indexList.Count;
         }

         /// <summary>
         /// Izračunava broj dionica u odabranom indeksu
         /// </summary>
         /// <param name="inIndexName">Ime indexa</param>
         /// <returns></returns>
         public int NumberOfStocksInIndex(string inIndexName)
         {
             string indexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(indexName))
                 throw new StockExchangeException("Index ne postoji!");
             Index i = indexList[indexName];
             return i.NumberOfStocks;
         }

         /// <summary>
         /// Stvara novi portfelj na burzi
         /// </summary>
         /// <param name="inPortfolioID"></param>
         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfelj već postoji!");
             Portfolio p = new Portfolio(inPortfolioID);
             portfolioList.Add(inPortfolioID, p);
         }

         /// <summary>
         /// Dodaje određeni broj dionica na portfelj
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <param name="inStockName">Ime dionice koje se dodaje</param>
         /// <param name="numberOfShares">Broj dionica koji se dodaje</param>
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Nepostojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             p.AddStock(s, numberOfShares);
         }

         /// <summary>
         /// Briše određeni broj dionica iz portfelja
         /// </summary>
         /// <param name="inPortfolioID">ID porfelja iz kojeg se briše</param>
         /// <param name="inStockName">Dionica koja se briše</param>
         /// <param name="numberOfShares">Broj dionica koji se briše</param>
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             p.DeleteStock(s,numberOfShares);
         }

         /// <summary>
         /// Briše kompletno dionicu iz portfelja
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja iz kojeg se briše</param>
         /// <param name="inStockName">Ime dionice koja se briše</param>
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             p.DeleteStock(s);
         }

         /// <summary>
         /// Vraća broj portfelja na burzi
         /// </summary>
         /// <returns>Broj portfelja na burzi</returns>
         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }

         /// <summary>
         /// Vraća broj dionica u odabranom portfelju
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <returns>Broj dionica</returns>
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             int num = p.StocksCount;             
             return num;
         }

         /// <summary>
         /// Provjerava postoji li portfelj sa zadanim imenom
         /// </summary>
         /// <param name="inPortfolioID">Ime portfelja</param>
         /// <returns></returns>
         public bool PortfolioExists(string inPortfolioID)
         {
             if (portfolioList.ContainsKey(inPortfolioID))
                 return true;
             else
                 return false;
         }
         
         /// <summary>
         /// Provjerava je li odabrana dionica dio odabranog portfelja
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <param name="inStockName">ID dionice</param>
         /// <returns>true/false ovisno postoji li dionica ili ne</returns>
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             return p.StockExist(s);
         }

         /// <summary>
         /// Dohvaća broj dionice u portfelju
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <param name="inStockName">ID dionice</param>
         /// <returns>Broj dionica u porfelju</returns>
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             string stockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(stockName))
                 throw new StockExchangeException("Tražena dionica ne postoji!");
             Stock s = stockList[stockName];
             return p.NumberOfShares(s);
         }

         /// <summary>
         /// Izračunava vrijednost portfelja
         /// </summary>
         /// <param name="inPortfolioID">ID portfljea</param>
         /// <param name="timeStamp">Vrijeme za koje se izračunava</param>
         /// <returns>Vrijednost portfelja</returns>
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             return p.GetValue(timeStamp);
         }

         /// <summary>
         /// Izračunava mjesećnu promjenu vrijednosti portfelja
         /// </summary>
         /// <param name="inPortfolioID">ID portfelja</param>
         /// <param name="Year">Godina</param>
         /// <param name="Month">Mjesec</param>
         /// <returns>Promjena vrijednost</returns>
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!portfolioList.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Ne postojeći portfelj!");
             Portfolio p = portfolioList[inPortfolioID];
             DateTime date = new DateTime(Year, Month, 1);
             return p.MonthlyValueChange(date);
         }
     }

    public class Stock
    {
        private SortedDictionary<DateTime, Price> priceHistory;
        public string Name { get; set; }
        public long Count { get; set; }
        public decimal InitialPrice 
        { 
            get 
            {
                Price p = priceHistory.First().Value;
                return p.Value; 
            } 
        }
        public decimal LastRecordedPrice
        {
            get
            {
                Price p = priceHistory.Last().Value;
                return p.Value;
            }
        }

        public Stock(string name, decimal value, DateTime startTime, long count)
        {
            Name = name;
            Price stockPrice = new Price(value,startTime);
            priceHistory = new SortedDictionary<DateTime, Price>();
            priceHistory.Add(startTime, stockPrice);
            Count = count;
        }

        /// <summary>
        /// Postavlja novu cijenu dionice
        /// </summary>
        /// <param name="timeMarker">Od kada nova cijena vrijedi</param>
        /// <param name="value">Koja je nova cijena dionice</param>
        public void SetStockPrice(DateTime timeMarker, decimal value)
        {
            Price stockPrice = new Price(value, timeMarker);
            if (priceHistory.ContainsKey(timeMarker))
                throw new StockExchangeException("Ne može se cijena dva puta mjenjati u istom trenutku!");
            priceHistory.Add(timeMarker, stockPrice);
        }

        /// <summary>
        /// Izračunava cijenu dionice u točno određenom vremenskom trenutku
        /// </summary>
        /// <param name="date">Vrijeme za koje se želi znati cijena</param>
        /// <returns>Cijena dionice</returns>
        public decimal GetStockValueByDate(DateTime date)
        {
            Price current = null;
            Price last = null;
            foreach (KeyValuePair<DateTime, Price> p in priceHistory)
            {
                current = p.Value;
                if (current.StartMarker > date && last == null)
                    throw new StockExchangeException("Ne postoji cijena dionice za odabrano vrijeme!");
                if (current.StartMarker > date && last.StartMarker <= date)
                    return last.Value;
                last = current;
            }
            if (current.StartMarker < date)
                return current.Value;
            throw new StockExchangeException("Greška kod dohvata cijene dionice!");
        }
    }

    public class Price
    {
        public DateTime StartMarker { get; set; }
        public Decimal Value { get; set; }

        public Price(decimal value, DateTime start)
        {
            Value = value;
            StartMarker = start;
        }
    }

    public class Index
    {
        private List<Stock> stockList;
        public string Name { get; set; }
        public IndexTypes IndexType { get; set; }
        public int NumberOfStocks
        {
            get
            {
                return stockList.Count();
            }
        }

        public Index (string name, IndexTypes it)
        {
            Name = name;
            if (it != IndexTypes.AVERAGE && it != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Nepostojeći tip indeksa!");
            IndexType = it;
            stockList = new List<Stock>();
        }

        /// <summary>
        /// Dodaje dionicu na index
        /// </summary>
        /// <param name="s">Dionica koja se dodaje</param>
        public void AddStockToIndex(Stock s)
        {
            if (!stockList.Contains(s))
                stockList.Add(s);
            else
                throw new StockExchangeException("Odabrana dionica već se nalazi u indexu!");
        }

        /// <summary>
        /// Briše dionicu sa indexa
        /// </summary>
        /// <param name="s">Dionica koja se briše</param>
        public void RemoveStockFromIndex(Stock s)
        {
            if (stockList.Contains(s))
                stockList.Remove(s);
            else
                throw new StockExchangeException("Odabrana dionica nije u odabranom indeksu!");
        }

        /// <summary>
        /// Provjerava sadrži li index određenu dionicu
        /// </summary>
        /// <param name="s">Donica</param>
        /// <returns></returns>
        public bool ContainsStock(Stock s)
        {
            if (stockList.Contains(s))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Izračunava vrijednosti indexa
        /// </summary>
        /// <param name="date">Datum za koji se izračunava</param>
        /// <returns></returns>
        public decimal CalculateValue(DateTime date)
        {
            decimal result = 0;
            if (IndexType == IndexTypes.AVERAGE)
            {
                decimal sum = StockValueSum(date);
                result = sum / NumberOfStocks;
            }
            else if (IndexType == IndexTypes.WEIGHTED)
            {
                result = StockWeightedSum(date);
            }
            else
                throw new StockExchangeException("Ne postojeći tip indeksa!");
            result = decimal.Round(result, 3);
            return result;
        }

        /// <summary>
        /// Izračun ukune vrijednost svih dionica u indexu
        /// </summary>
        /// <param name="date">Datum za koji se računaju vrijednosti</param>
        /// <returns></returns>
        private decimal StockValueSum(DateTime date)
        {
            decimal sum = 0;
            foreach (Stock s in stockList)
            {
                sum += s.GetStockValueByDate(date);
            }
            return sum;
        }

        /// <summary>
        /// Zbraja težinski prosjeka (vrijednost dionice * broj dionica)
        /// </summary>
        /// <param name="date">Datum za vrijednost dionica</param>
        /// <returns>Ukupna suma</returns>
        private decimal StockWeightedSum(DateTime date)
        {
            decimal sum = 0;
            List<decimal> stockValues = new List<decimal>();
            foreach (Stock s in stockList)
            {
                decimal d = s.GetStockValueByDate(date);
                sum += d * s.Count;
                stockValues.Add(s.Count*d*d);
            }
            decimal result = 0;
            foreach (decimal d in stockValues)
                result= result + d/sum;  
            return result;
        }

        /// <summary>
        /// Izračunava ukupan broj dionca u indexu
        /// </summary>
        /// <returns>Broj dionica</returns>
        private long TotalSharesCount()
        {
            long sum = 0;
            foreach (Stock s in stockList)
                sum += s.Count;
            return sum;
        }
    }

    public class Portfolio
    {
        private Dictionary<Stock, int> stockList;
        public string ID { get; set; }
        public int StocksCount
        {
            get
            {
                return stockList.Count;
            }
        }

        public Portfolio(string id)
        {
            ID = id;
            stockList = new Dictionary<Stock, int>();
        }

        /// <summary>
        /// Briše neki broj odabrane dionice iz portfelja
        /// </summary>
        /// <param name="s">Dionica koja se briše</param>
        /// <param name="num">Broj dionca koji se briše</param>
        public void DeleteStock(Stock s, int num)
        {
            if (!stockList.ContainsKey(s))
                throw new StockExchangeException("Tražena dionica nije dio portfelja!");
            int n = stockList[s];
            if (n < num)
                throw new StockExchangeException("Ne može se izrisati toliko dionca!");
            stockList[s] = n - num;
            if (n - num == 0)
                stockList.Remove(s);
        }

        /// <summary>
        /// Briše cijelu dionicu iz portfelja
        /// </summary>
        /// <param name="s">Dionica koja se briše</param>
        public void DeleteStock(Stock s)
        {
            if (!stockList.ContainsKey(s))
                throw new StockExchangeException("Tražena dionica nije dio portfelja!");
            stockList.Remove(s);
        }

        /// <summary>
        /// Dodaje novu dionicu u portfelj
        /// </summary>
        /// <param name="stock">Dionica koja se dodaje</param>
        /// <param name="num">Broj dionica koji se dodaje</param>
        public void AddStock(Stock stock, int num)
        {
            if (stock.Count < num)
                throw new StockExchangeException("Ne moeže se dodati više dionica nego što ih postoji!");
            if (stockList.ContainsKey(stock))
            {
                int shareNumber = stockList[stock];
                if (shareNumber + num <= stock.Count)
                {
                    stockList[stock] = shareNumber + num;
                    return;
                }
                else
                    throw new StockExchangeException("Ne moeže se dodati više dionica nego što ih postoji!");
            }
            stockList.Add(stock, num);
        }

        /// <summary>
        /// Provjerava postoji li dionica u portfelju
        /// </summary>
        /// <param name="s">Dionica</param>
        /// <returns>Postoji li dionica</returns>
        public bool StockExist(Stock s)
        {
            if (stockList.ContainsKey(s))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Izračunava broj određenog tipa dionica u portfelju
        /// </summary>
        /// <param name="s">Dionica</param>
        /// <returns>Broj dionica</returns>
        public int NumberOfShares(Stock s)
        {
            if (!stockList.ContainsKey(s))
                throw new StockExchangeException("Dionice nema u portfelju!");
            return stockList[s];
        }

        /// <summary>
        /// Izračunava vrijednost profelja u odabranom trnutku
        /// </summary>
        /// <param name="dt">Trenutak za koji se računa vrijednost</param>
        /// <returns></returns>
        public decimal GetValue(DateTime dt)
        {
            decimal sum = 0;
            foreach (KeyValuePair<Stock, int> stock in stockList)
            {
                sum += stock.Value;
            }
            return sum;
        }

        /// <summary>
        /// Izračunava postotak promjene vrijednosti za dani mjesec
        /// </summary>
        /// <param name="start">Datum</param>
        /// <returns>Promjena vrijednosti</returns>
        public decimal MonthlyValueChange(DateTime startDate)
        {
            decimal result = 0;
            decimal startValue = 0;
            decimal endValue = 0;
            DateTime endDate = startDate;
            endDate = endDate.AddMonths(1);
            endDate = endDate.Subtract(new TimeSpan(0, 0, 0, 0, 1));
            if (stockList.Count < 1)
                throw new StockExchangeException("Greška, nema dionica u portfelju!");
            foreach (KeyValuePair<Stock, int> stock in stockList)
            {
                startValue += stock.Key.GetStockValueByDate(startDate);
                endValue += stock.Key.GetStockValueByDate(endDate);
            }
            result = startValue / endValue;
            result = result * 100;
            result = decimal.Round(result, 3);
            return result;
        }
    }
}
