﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
  
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Index
    {
        private string _indexName;
        private IndexTypes _indexType;
        private List<Stock> _stockList = new List<Stock>();

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            // TODO: Complete member initialization
            _indexName = inIndexName;
            _indexType = inIndexType;
        }

        #region getters and setters

        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }
        public IndexTypes IndexType
        {
            get { return _indexType; }
            set { _indexType = value; }
        }
        public List<Stock> StockList
        {
            get { return _stockList; }
            set { _stockList = value; }
        }

        #endregion
    }

    public class Stock
    {
        #region private variables

        private string _stockName;
        private Decimal _initialPrice;
        private Decimal _lastPrice;
        private SortedDictionary<DateTime, Decimal> _valueInHistory = new SortedDictionary<DateTime, decimal>();

        #endregion

        public Stock(string inStockName, decimal inInitialPrice, DateTime inTimeStamp)
        {
            // TODO: Complete member initialization
            _stockName = inStockName;
            _initialPrice = inInitialPrice;
            _lastPrice = inInitialPrice;
            _valueInHistory.Add(inTimeStamp, inInitialPrice);
        }

        #region getters and setters

        public Decimal LastPrice
        {
            get { return _lastPrice; }
            set { _lastPrice = value; }
        }

        public string StockName
        {
            get { return _stockName; }
            set { _stockName = value; }
        }

        public Decimal InitialPrice
        {
            get { return _initialPrice; }
            set { _initialPrice = value; }
        }

        public SortedDictionary<DateTime, Decimal> ValueInHistory
        {
            get { return _valueInHistory; }
            set { _valueInHistory = value; }
        }

        #endregion

    }

    public class Portfolio
    {
        private string _portfolioID;
        private SortedDictionary<string, long> _stockstInPorfolio = new SortedDictionary<string, long>();



        public Portfolio(string inPortfolioID)
        {
            // TODO: Complete member initialization
            _portfolioID = inPortfolioID;
        }

        #region getters and setters

        public string PortfolioID
        {
            get { return _portfolioID; }
            set { _portfolioID = value; }
        }

        public SortedDictionary<string, long> StockstInPorfolio
        {
            get { return _stockstInPorfolio; }
            set { _stockstInPorfolio = value; }
        }

        #endregion
    }

    public class StockExchange : IStockExchange
    {
        private SortedDictionary<string, long> _stockDict = new SortedDictionary<string, long>();
        private List<Stock> _stockList = new List<Stock>();
        private List<Portfolio> _portfolioList = new List<Portfolio>();
        private List<Index> _indexList = new List<Index>();

        //dodaje dionicu s početnom cijenom na burzu
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string name = inStockName.ToLower();
            //gleda postoji li vec dionica na burzi s tim imenom
            if (_stockDict.ContainsKey(name) != true)
            {
                //provjerava ulazne parametre
                if (inInitialPrice > 0 && inNumberOfShares > 0)
                {
                    //dodaje u dictionary dionicu i njen numberOfShares
                    _stockDict.Add(name, inNumberOfShares);

                    //dodaje dionicu u listu dionica na burzi
                    Stock stock = new Stock(name, inInitialPrice, inTimeStamp);
                    _stockList.Add(stock);
                }
                else
                    throw new StockExchangeException("Pocetna cijena ili broj dionica su <= 0");
            }
            else throw new StockExchangeException("Vec postoji dionica s tim imenom!");
        }
        //briše dionicu s burze
        public void DelistStock(string inStockName)
        {
            string name = inStockName.ToLower();

            //provjerava postoji li u rijecniku dionica s tim imenom
            if (_stockDict.ContainsKey(name) == true)
            {
                //brisi iz portfolia
                foreach (Portfolio portfolio in _portfolioList)
                {
                    if (portfolio.StockstInPorfolio.ContainsKey(name))
                        RemoveStockFromPortfolio(portfolio.PortfolioID, name);
                }

                //brisi iz indeksa
                foreach (Index index in _indexList)
                {
                    if (index.StockList.Any(s => s.StockName == name))
                        RemoveStockFromIndex(index.IndexName, name);
                }

                //brise s burze
                foreach (Stock stock in _stockList)
                {
                    if (stock.StockName == name)
                    {
                        _stockList.Remove(stock);
                        _stockDict.Remove(name);
                        break;
                    }
                }
                
            }
            else throw new StockExchangeException("Ne postoji dionica s tim imenom pa ju ne mozemo ni obrisati!");
           
        }
        //provjerava postoji li tražena dionica na burzi
        public bool StockExists(string inStockName)
        {
            string name = inStockName.ToLower();
            //provjerava postoji li dionica na burzi
            if (_stockDict.ContainsKey(name) == true)
                return true;
            else
                return false;
        }
        //vraća broj dionica na burzi
        public int NumberOfStocks()
        {
            return _stockList.Count;
        }
        //postavlja cijenu dionice za određeno vrijeme
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            string name = inStockName.ToLower();
            //ispituje parametar inStockValue
            if (inStockValue <= 0)
                throw new StockExchangeException("Cijena dionice ne moze biti <= 0");
            else
            {
                //provjerava postoji li vec dionica u rjecniku
                if (_stockDict.ContainsKey(name))
                {
                    foreach (Stock stock in _stockList)
                    {
                        if (stock.StockName == name)
                        {
                            //dodaje novu vrijednost u listu promjene vrijednosti dionice
                            stock.LastPrice = inStockValue;
                            stock.ValueInHistory.Add(inTimeStamp, inStockValue);
                        }
                    }
                }
                else throw new StockExchangeException("Ne postoji dionica s nazivom " + inStockName);
            }  
        }
        //dohvaća cijenu dionice za neko vrijeme
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Decimal val = 0;
            string name = inStockName.ToLower();
            //ako rjecnik dionica sadrzi trazenu dionicu
            if (_stockDict.ContainsKey(name))
            {
                //pronadji ju i dohvati vrijednost za trenutak zadan kao parametar
                Stock stock = _stockList.Find(s => s.StockName == name);
                //ako ne postoji zapis za trenutak zadan kao parametar uzmi prvi manji
                foreach (DateTime dt in stock.ValueInHistory.Keys)
                {
                    if (dt <= inTimeStamp)
                        val = stock.ValueInHistory[dt];
                    else
                        break;
                }
            }
            else throw new StockExchangeException("Ne postoji dionica s imenom " + inStockName + " pa ju ne mozemo dohvatiti!");
           
            return val;

        }
        //dohvaća početnu cijenu dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            string name = inStockName.ToLower();
            if (_stockDict.ContainsKey(name))
            {
                Decimal price = _stockList.Find(stock => stock.StockName == name).InitialPrice;
                return price;
            }
            else throw new StockExchangeException("Ne postoji dionica s nazivom: " + inStockName);         
        }
        //dohvaća zadnju cijenu dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            string name = inStockName.ToLower();
            if (_stockDict.ContainsKey(name))
            {
                Decimal price = _stockList.Find(stock => stock.StockName == name).LastPrice;
                return price;
            }
            else
            {
                throw new StockExchangeException("Ne postoji dionica s nazivom: " + inStockName);
            }
        }
        //stvara novi indeks na burzi
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            string name = inIndexName.ToLower();     
            //provjerava je li parametar inIndexType valjan
            if (Enum.IsDefined(typeof(IndexTypes), inIndexType) == true)
            {
                //provjerava postoji li vec indeks s tim imenom
                if (_indexList.Find(i => i.IndexName == name) == null)
                {
                    //stvara indeks i dodaje ga u listu indeksa na burzi
                    Index index = new Index(name, inIndexType);
                    _indexList.Add(index);
                }
                else
                {
                    throw new StockExchangeException("Vec postoji indeks s tim imenom");
                }
            }
            else
        	{
                throw new StockExchangeException("Ne postoji takav tip indeksa");
        	}
            
        }
        //dodaje dionicu u indeks
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            string indexName = inIndexName.ToLower();
            string stockName = inStockName.ToLower();

            //provjerava postoji li vec indeks s tim imenom
            if (_indexList.Any(ind => ind.IndexName == indexName))
            {
                //provjerava postoji li dionica s tim imenom
                if (_stockDict.ContainsKey(stockName))
                {
                    Index index = _indexList.Find(i => i.IndexName == indexName);
                    if (index.StockList.Find(s => s.StockName == stockName) == null)
                    {
                        //dodaje dionicu u indeks
                        Stock stock = _stockList.Find(st => st.StockName == stockName);
                        index.StockList.Add(stock);
                    }
                    else
	                {
                       throw new StockExchangeException("Vec postoji dionica " + inStockName + " u indeksu " + inIndexName + " pa ju ne mozemo ponovno dodati!");     
	                }
                }
                else 
                {
                    throw new StockExchangeException("Ne postoji dionica naziva " + inStockName + " pa ju ne mozemo dodati u indeks!");
                }
            }
            else throw new StockExchangeException("Ne postoji indeks naziva: " + inIndexName);
        }
        //briše dionicu iz indeksa
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            //provjerava postoji li indeks s tim imenom na burzi
            if (_indexList.Any(ind => ind.IndexName == inIndexName.ToLower()))
            {
                //dohvati indeks i dionicu
                Index index = (Index)_indexList.Find(ind => ind.IndexName == inIndexName.ToLower());
                Stock stock = index.StockList.Find(s => s.StockName == inStockName.ToLower());
                if (stock != null)
                {
                    //obrisi dionicu iz indeksa
                    index.StockList.Remove(stock);
                }
                else
                {
                    throw new StockExchangeException("Ne postoji dionica naziva " + inStockName + " pa ju ne mozemo obrisati iz indeksa!");
                }
            }
            else throw new StockExchangeException("Ne postoji indeks naziva: " + inIndexName);
        }
        //provjerava je li dionica u indeksu
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (_indexList.Any(ind => ind.IndexName == inIndexName.ToLower()))
            {
                Index index = _indexList.Find(i => i.IndexName == inIndexName.ToLower());
                if (index.StockList.Find(s => s.StockName == inStockName.ToLower()) != null)
                    return true;
                else
                    return false;           
            }
            else 
                throw new StockExchangeException("Ne postoji indeks naziva: " + inIndexName);
        }
        //dohvaća vrijednost indeksa
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal result = 0;
            //provjerava postoji li indeks s tim imenom na burzi
            if (_indexList.Any(ind => ind.IndexName == inIndexName.ToLower()))
            {
                //dohvati indeks
                Index index = _indexList.Find(i => i.IndexName == inIndexName.ToLower());
                
                switch (index.IndexType)
                {
                    case IndexTypes.AVERAGE:
                        {
                            //gleda broj dionica u indeksu. potrebno da ne mozemo dijeliti s 0
                            int number = index.StockList.Count();
                            if (number == 0)
                            {
                                result = 0;
                                break;
                            }
                            else 
                            {
                                decimal sum = 0;
                                DateTime date = inTimeStamp;
                                //za svaku dionicu u indeksu dohvaca vrijednost za zadano vrijeme ili prvo manje definirano vrijeme
                                foreach (Stock stock in index.StockList)
                                {
                                    foreach (DateTime dt in stock.ValueInHistory.Keys)
                                    {
                                        if (dt <= inTimeStamp)
                                            date = dt;
                                        else
                                            break;
                                    }
                                    sum += stock.ValueInHistory[date];
                                }
                                //rezultat
                                result = sum / number;
                                break;
                            } 
                        }
                    case IndexTypes.WEIGHTED:
                        {
                            decimal total = 0;
                            DateTime date = inTimeStamp;
                            //za svaku dionicu u indeksu gleda je li definiarana za inTimeStamp i ako nije uzima prvo manje 
                            //definirano vrijeme te zbraja ukupnu vrijednost
                            foreach (Stock stock in index.StockList)
                            {
                                if (stock.ValueInHistory.ContainsKey(inTimeStamp))
                                    total += stock.ValueInHistory[date] * _stockDict[stock.StockName];
                                else
                                {
                                    foreach (DateTime dt in stock.ValueInHistory.Keys)
                                    {
                                        if (dt <= inTimeStamp)
                                            date = dt;
                                        else
                                            break;
                                    }
                                    total += stock.ValueInHistory[date] * _stockDict[stock.StockName];
                                }        
                            }
                            decimal d;
                            foreach (Stock stock in index.StockList)
                            {
                                foreach (DateTime dt in stock.ValueInHistory.Keys)
                                {
                                    if (dt <= inTimeStamp)
                                        date = dt;
                                    else
                                        break;
                                }
                                //racuna ukupni rezultat
                                d = stock.ValueInHistory[date] / total;
                                result += stock.ValueInHistory[date] * _stockDict[stock.StockName] * d;
                            }
                            break;
                        }
                    default: return 0;
                }
            }
            else 
                throw new StockExchangeException("Ne postoji indeks tog naziva na burzi.");
            
            //zaokruzuje na 3 decimale
            result = Decimal.Round(result, 3);
            return result;
        }
        //provjerava postoji li traženi indeks na burzi
        public bool IndexExists(string inIndexName)
        {
            string name = inIndexName.ToLower();
            if (_indexList.Any(i => i.IndexName == name))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //dohvaća broj indeksa na burzi
        public int NumberOfIndices()
        {
            return _indexList.Count();
        }
        //dohvaća broj dionica u traženom indeksu
        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (_indexList.Any(i => i.IndexName == inIndexName.ToLower()))
            {
                foreach (Index index in _indexList)
                {
                    if (index.IndexName == inIndexName.ToLower())
                    {
                        return index.StockList.Count();
                    }
                }
            }
            else
                throw new StockExchangeException("Ne postoji indeks tog naziva");
            return 0;
        }
        //stvara novi portfolio na burzu
        public void CreatePortfolio(string inPortfolioID)
        {
            //gleda postoji li vec portfolio s tim imenom
            if (_portfolioList.Find(p => p.PortfolioID == inPortfolioID) == null)
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                _portfolioList.Add(portfolio);
            }
            else
            {
                throw new StockExchangeException("Vec postoji portfolio s tim imenom");
            }
        }
        //dodaje određeni broj dionica u portfolio
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            string stockName = inStockName.ToLower();
            if (portfolio != null)
            {
                if (_stockDict.ContainsKey(stockName))
                {
                    //ispituje koliko dionica zelimo dodati i ako zelimo vise nego sto je raspolozivo, dodaj koliko je raspolozivo
                    if (_stockDict[stockName] < numberOfShares)
                    {
                        numberOfShares = (int)_stockDict[stockName];
                    }
                    
                    //umanjuje broj raspolozivih dionica na burzi
                    _stockDict[stockName] -= numberOfShares;
                    //gleda postoji li vec takva dionica u portfoliu
                    if (portfolio.StockstInPorfolio.ContainsKey(stockName))
                    {
                        //ako da, nadodaj ih jos
                        long value = portfolio.StockstInPorfolio[stockName] + numberOfShares;
                        portfolio.StockstInPorfolio[stockName] = value;
                    }
                    else
                    {
                        //ako ne, dodaj dionice u portfolio
                        portfolio.StockstInPorfolio.Add(stockName, numberOfShares);
                    }
                    
                }
                else
                {
                    throw new StockExchangeException("Ne postoji dionica " + inStockName + " pa ju ne mozemo dodati u porfolio!");
                }
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID + " pa ne mozemo dodati dionce u njega!");
        }
        //briše određeni broj dionica iz portfolija
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            string stockName = inStockName.ToLower();
            if (portfolio != null)
            {
                if (portfolio.StockstInPorfolio.ContainsKey(stockName))
                {
                    long currentNum = portfolio.StockstInPorfolio[stockName];
                    if (currentNum > numberOfShares)
                    {
                        //ako je trenutni broj dionica na portfoliu veci nego sto zelimo maknuti, ok, makni numberOfShares dionica
                        currentNum -= numberOfShares;
                        portfolio.StockstInPorfolio[stockName] = currentNum;
                    }
                    else
                        //totalno izbrisi te dionice iz portfolia
                        RemoveStockFromPortfolio(portfolio.PortfolioID, stockName);

                    //povecaj broj raspolozivih dionica na burzi
                    _stockDict[stockName] += numberOfShares;
                }
                else
                    throw new StockExchangeException("Ne postoji dionica " + inStockName + " u portfoliu pa ju ne mozemo obrisati!");
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID + " pa ne mozemo obrisati dionce iz njega!");
        }      
        //briše dionicu iz portfolia
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            string stockName = inStockName.ToLower();
            if (portfolio != null)
            {
                if (portfolio.StockstInPorfolio.ContainsKey(stockName))
                {
                    int numOfShares = (int)portfolio.StockstInPorfolio[stockName]; 
                    portfolio.StockstInPorfolio.Remove(stockName);

                    _stockDict[stockName] += numOfShares;
                }
                else
                    throw new StockExchangeException("Ne postoji dionica " + inStockName + " u portfoliu pa ju ne mozemo obrisati iz njega!");
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID + " pa ne mozemo brisati dionce iz njega!");
        }
        //dohvaća broj portfolija na burzi
        public int NumberOfPortfolios()
        {
            return _portfolioList.Count();
        }
        //dohvaća broj dionica u traženom portfoliju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            int total = 0;

            if (portfolio != null)
            {
                total = portfolio.StockstInPorfolio.Count();
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID + " pa ne mozemo dohvatiti broj dionica iz njega!");
            
            return total;
        }
        //provjerava postoji li traženi portfolio na burzi
        public bool PortfolioExists(string inPortfolioID)
        {
            if (_portfolioList.Find(p => p.PortfolioID == inPortfolioID) != null)
                return true;
            else
                return false;
        }
        //provjerava nalazi li se dionica u portfoliju
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            string stockName = inStockName.ToLower();
            bool decision = false;
            if (portfolio != null)
            {
                if (portfolio.StockstInPorfolio.ContainsKey(stockName))
                    decision = true;
                else
                    decision = false;
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID);

            return decision;
        }
        //dohvaća broj dionice u traženom portfoliju
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            string stockName = inStockName.ToLower();
            int numOfShares = 0;
            if (portfolio != null)
            {
                if (portfolio.StockstInPorfolio.ContainsKey(stockName))
                {
                    numOfShares = (int)portfolio.StockstInPorfolio[stockName];
                }
                else
                    throw new StockExchangeException("portfolio " + inPortfolioID + " ne sadrzi dionicu " + inStockName);
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID);

            return numOfShares;
        }
        //dohvaća vrijednost portfolija u određenom trenutku
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
            decimal result = 0;
            DateTime date = timeStamp;
            if (portfolio != null)
            {
                foreach (string stockName in portfolio.StockstInPorfolio.Keys)
                {
                    Stock stock = _stockList.Find(s => s.StockName == stockName);
                    foreach (DateTime dt in stock.ValueInHistory.Keys)
                    {
                        if (dt <= timeStamp)
                            date = dt;
                        else
                            break;
                    }
                    result += stock.ValueInHistory[date] * portfolio.StockstInPorfolio[stockName];
                }
            }
            else
                throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID);
            return result;
        }
        //dohvaća mjesećnu promjenu vrijednosti portfolija
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal result = 0;
            if((Year <= 0) && (Month < 1 || Month > 12))
                throw new StockExchangeException("Ne valjaju godina i mjesec");
            else
            {
                //odredjivanje broja dana u mjesecu
                int days;
                switch(Month)
                {
                    case 1 :
                    case 3 :
                    case 5 :
                    case 7 :
                    case 8 :
                    case 10 :
                    case 12 : 
                        days = 31;
                        break;
                    case 4 :
                    case 6 :
                    case 9 :
                    case 11 :
                        days = 30;
                        break;
                    default :
                        days = 28;
                        break;
                }


                DateTime startDate = new DateTime(Year, Month, 1, 0, 0, 0, 000);
                DateTime endDate = new DateTime(Year, Month, days, 23, 59, 59, 999);
                Portfolio portfolio = _portfolioList.Find(p => p.PortfolioID == inPortfolioID);
                decimal monthChange = 0, firstDay, lastDay;

                if (portfolio != null)
                {
                    foreach (string key in portfolio.StockstInPorfolio.Keys)
                    {
                        Stock stock = _stockList.Find(s => s.StockName == key);

                        firstDay = GetStockPrice(stock.StockName, startDate);
                        lastDay = GetStockPrice(stock.StockName, endDate);
                        
                        monthChange = (lastDay - firstDay) / firstDay * 100;
                         
                        result += monthChange;
                        
                    }
                    if (portfolio.StockstInPorfolio.Count == 0)
                        result = 0;
                    else
                        result = result / portfolio.StockstInPorfolio.Count();
                }
                else
                    throw new StockExchangeException("Ne postoji portfolio " + inPortfolioID);
           }
            result = Decimal.Round(result, 3);
            return result;
        }
    }
}
