﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {

         private Dictionary<string, Stock> _stocks; 
         private Dictionary<Stock, long> _stockCounts;
         private Dictionary<Stock, StockPriceHistory> _stockHistory;

         private Dictionary<string, Index> _indices;
         private Dictionary<string, Portfolio> _portfolios; 

         public StockExchange()
         {
             _stocks = new Dictionary<string, Stock>();
             _stockCounts = new Dictionary<Stock, long>();
             _stockHistory = new Dictionary<Stock, StockPriceHistory>();
             _portfolios = new Dictionary<string, Portfolio>();
             _indices = new Dictionary<string, Index>();
         }

         private Index GetIndex(string indexName)
         {
             if(!_indices.ContainsKey(indexName.ToLower()))
             {
                 throw new StockExchangeException("No such Index!");
             } 
             
             return _indices[indexName.ToLower()];
             

         }
         private Portfolio GetPortfolio(string portfolioName)
         {
             if (!_portfolios.ContainsKey(portfolioName))
             {
                 throw new StockExchangeException("No such portfolio");
             }

             return _portfolios[portfolioName];
         }
         private Stock GetStock(string stockName)
         {
             if (!_stocks.ContainsKey(stockName.ToLower()))
             {
                 throw new StockExchangeException("No such Stock!");
             }

             return _stocks[stockName.ToLower()];
         }

        
         private long GetFreeShares(Stock stock)
         {
             long count = 0;
             foreach (KeyValuePair<string, Portfolio> p in _portfolios)
             {
                 if(p.Value.ContainsStock(stock))
                    count += p.Value.GetNoOfShares(stock);
             }

             return _stockCounts[stock] - count;
         }
         public long GetSharesCount(Stock stock)
         {
             if (!_stockCounts.ContainsKey(stock))
                 return 0;
             else
                 return _stockCounts[stock];
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Stock allready exists!");
             }

             inStockName = inStockName.ToLower();
             var newStock = new Stock(inStockName,inInitialPrice);

             _stocks.Add(inStockName, newStock);
             _stockCounts.Add(newStock, inNumberOfShares);
             
             var priceHistory = new StockPriceHistory(newStock);

             _stockHistory.Add(newStock,priceHistory);


         }

         public void DelistStock(string inStockName)
         {


             var stock = GetStock(inStockName);
             
             _stockHistory.Remove(stock);
             _stocks.Remove(inStockName);

         }

         public bool StockExists(string inStockName)
         {
             return _stocks.ContainsKey(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             
             
             _stockHistory[GetStock(inStockName)].AddPrice(inIimeStamp,inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {

             var stock = GetStock(inStockName);
             return _stockHistory[stock].GetPriceAtDate(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             
             return GetStock(inStockName).InitialPrice;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             
             return _stockHistory[GetStock(inStockName)].GetPriceAtDate(DateTime.Now);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
             {
                 throw new StockExchangeException("Index for given name allready exists!");
             }

             Index newIndex = null;
             switch (inIndexType)
             {
                     case IndexTypes.AVERAGE:
                        newIndex = new AverageIndex(inIndexName.ToLower(),this);
                        break; 
                     case IndexTypes.WEIGHTED:
                        newIndex = new WeightedIndex(inIndexName.ToLower(),this);
                        break;
             }

             _indices.Add(inIndexName.ToLower(),newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             
             
             GetIndex(inIndexName).AddStock(GetStock(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             _stockHistory.Remove(GetStock(inStockName));
             _stocks.Remove(inStockName);
             
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             
             return GetIndex(inIndexName).containsStock(inStockName.ToLower());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return GetIndex(inIndexName).CalculateValue();
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.ContainsKey(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             
             return GetIndex(inIndexName).numberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                throw new StockExchangeException("Portfolio allready exists!");   
             }

             var portfolio = new Portfolio(inPortfolioID,this);
             _portfolios.Add(inPortfolioID,portfolio);


         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if(GetFreeShares(GetStock(inStockName)) >= numberOfShares)
                GetPortfolio(inPortfolioID).AddStock(GetStock(inStockName),numberOfShares);
             else
             {
                 throw new StockExchangeException("Not enough remaining shares!");
             }

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
            GetPortfolio(inPortfolioID).RemoveStock(GetStock(inStockName),numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
            GetPortfolio(inPortfolioID).RemoveStock(GetStock(inStockName));
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return GetPortfolio(inPortfolioID).GetStockCount();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolio(inPortfolioID).ContainsStock(GetStock(inStockName));
             
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return (int)GetPortfolio(inPortfolioID).GetNoOfShares(GetStock(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return GetPortfolio(inPortfolioID).getValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {

             return GetPortfolio(inPortfolioID).getPercentChange(Year, Month);
         }
     }


    public class Stock
    {
        private string _name;
        private decimal _initialPrice;

        public String Name
        {
            get { return _name; }
        }
        public decimal InitialPrice
        {
            get { return _initialPrice;  }
        }


        public Stock( string stockName, decimal initialPrice )
        {

            if (initialPrice <= 0)
            {
                throw new StockExchangeException("Illegal stock price!");
            }
            _name = stockName.ToLower();
            _initialPrice = initialPrice;
        }

        public override bool Equals( object obj ) {
            return ((Stock)obj)._name.Equals(_name);
        }
    }

    public class StockPriceHistory
    {
        private Stock _stock;
        private SortedDictionary<DateTime, decimal> _priceHistory;

        

        public StockPriceHistory(Stock stock)
        {
            _stock = stock;
            _priceHistory = new SortedDictionary<DateTime, decimal>();
            _priceHistory.Add(DateTime.Now,stock.InitialPrice);
        }

        public void AddPrice( DateTime time, decimal price )
        {
            if (price <= 0)
            {
                throw new StockExchangeException("Illegal price!");
            }

            if (time == null)
            {
                throw new StockExchangeException("Illegal time!");
            }

            if (_priceHistory.ContainsKey(time))
            {
                throw new StockExchangeException("Price for given time allready exists!");
            }
            _priceHistory.Add(time,price);
        }

        public decimal GetPriceAtDate( DateTime date )
        {
            decimal last = 0;

            foreach( KeyValuePair<DateTime, decimal> currentDatePrice in _priceHistory )
            {
                if (currentDatePrice.Key < date)
                {
                    last = currentDatePrice.Value;
                }
                else
                {
                    break;
                }
            }

            if (last==0)
            {
                throw new StockExchangeException(string.Format("No stock price info for stock: {0} before: {1}", this._stock.Name, _priceHistory.First().Key));
            }

            return last;
        }

        

    }

    public abstract class Index {
        protected IStockExchange _stockExchange;
        protected List<Stock> _indexStocks;
        protected string _name;

        public Index( string inIndexName, IStockExchange exchange )
         {
             _name = inIndexName.ToLower();
             _stockExchange = exchange;
             _indexStocks = new List<Stock>();
         }

        public int numberOfStocks()
        {
            return _indexStocks.Count;
        }
        public void AddStock(Stock stock)
        {
            if (_indexStocks.Contains(stock))
            {
                throw new StockExchangeException("index allready contains stock!");
            }

            _indexStocks.Add(stock);
        }

        public bool containsStock(string inStockName)
        {
            return _indexStocks.Contains(new Stock(inStockName, 2));
        }

        public abstract decimal CalculateValue();



     }

    public class AverageIndex : Index
    {

        public AverageIndex( string inIndexName, IStockExchange exchange )
            : base(inIndexName,exchange)
        {
            
        }

        public override decimal CalculateValue()
        {
            decimal sum = 0;
            foreach (var stock in _indexStocks)
            {
                sum += _stockExchange.GetLastStockPrice(stock.Name);
            }
            return sum / this.numberOfStocks();
        }
    }

    public class WeightedIndex : Index {

        public WeightedIndex( String inIndexName,IStockExchange exchange )
            : base(inIndexName,exchange) {

        }

        public override decimal CalculateValue()
        {
            decimal sum = 0;
            decimal sumStocks = 0;
            decimal sumShares = 0;
            StockExchange ex = (StockExchange) _stockExchange;
            

            foreach (var stock in _indexStocks)
            {
                sumStocks += ex.GetLastStockPrice(stock.Name)*ex.GetSharesCount(stock);
                sumShares += ex.GetSharesCount(stock);
            }
           
            foreach (var stock in _indexStocks)
            {

                Console.WriteLine("name: " + stock.Name + " price: " + ex.GetLastStockPrice(stock.Name)+" shares: "+ex.GetSharesCount(stock));

                decimal fact = ex.GetSharesCount(stock)*ex.GetLastStockPrice(stock.Name);
                fact /= sumStocks;
                
                decimal price =  _stockExchange.GetLastStockPrice(stock.Name);
                sum += price*fact;
                Console.WriteLine(price+"  "+fact+"  "+ex.GetSharesCount(stock));
            }

            return sum;
        }
    }



     public class Portfolio
     {
         private Dictionary<String, Stock> _stocks;
         private Dictionary<String, long> _stockCount;
         private string _id;
         private IStockExchange _exchange;

         public Portfolio(string inPortfolioId,IStockExchange exchange) 
         {
             _stocks = new Dictionary<string, Stock>();
            _stockCount = new Dictionary<string, long>();
             _exchange = exchange;
            _id = inPortfolioId;
         }

         public void AddStock(Stock stock,long count)
         {
             if (_stocks.ContainsKey(stock.Name))
             {
                 _stockCount[stock.Name] += count;
             }
             else
             {
                 _stocks.Add(stock.Name, stock);
                 _stockCount.Add(stock.Name, count);
             }


             
         }

         public void RemoveStock(Stock stock, long count)
         {
             _stockCount[stock.Name] -= count;
             if (_stockCount[stock.Name] <= 0)
             {
                 _stockCount.Remove(stock.Name);
                 _stocks.Remove(stock.Name);
             }
         }

         public void RemoveStock(Stock stock)
         {
             _stocks.Remove(stock.Name);
             _stockCount.Remove(stock.Name);
         }

         public long GetNoOfShares(Stock stock)
         {
             if (!_stocks.ContainsKey(stock.Name))
                 return 0;
             else return _stockCount[stock.Name];
         }

         public bool ContainsStock(Stock stock)
         {
             return _stocks.ContainsKey(stock.Name);
         }

         public int GetStockCount()
         {
             return _stocks.Count;
         }

         public long GetSharesCount(Stock stock)
         {
             if (!_stocks.ContainsKey(stock.Name))
                 return 0;
             else
             {
                 return _stockCount[stock.Name];
             }
         }
     
         public decimal getValue(DateTime time)
        {
            decimal sum = 0;
            foreach (var stock in _stocks.Keys)
            {
                sum += _stockCount[stock]*_exchange.GetStockPrice(stock,DateTime.Today);
            }

            return sum;
        }

         public decimal getPercentChange( int Year, int Month )
         {
            DateTime start = new DateTime(Year,Month,1);
             DateTime end = new DateTime(Year, Month + 1, 1).Subtract(new TimeSpan(0, 0, 0, 0, 0));
             decimal monthStart = getValue(start);
             decimal monthEnd = getValue(end);

             return (monthEnd - monthStart)/monthEnd;
         }
        
     
     }




   
}
