﻿using System;
using System.Collections.Generic;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<String, Stock> _stocks;
         private Dictionary<String, long> _freeStocks;
         private Dictionary<String, Index> _indices;
         private Dictionary<String, Portfolio> _portfolios; 

         public StockExchange()
         {
             _stocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
             _freeStocks = new Dictionary<string, long>(StringComparer.InvariantCultureIgnoreCase);
             _indices = new Dictionary<string, Index>(StringComparer.InvariantCultureIgnoreCase);
             _portfolios = new Dictionary<string, Portfolio>();
         }


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if(_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Dionica sa nazivom " + inStockName + " već postoji!");
             _stocks.Add(inStockName,new Stock(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp));
             _freeStocks.Add(inStockName, inNumberOfShares);
         }

         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 _stocks.Remove(inStockName);
                 _freeStocks.Remove(inStockName);
                 RemoveStockFromPortfoliosAndIndices(inStockName);
             }
             else
                 throw new StockExchangeException("Dionica sa nazivom " + inStockName + " ne postoji!");
         }

         private void RemoveStockFromPortfoliosAndIndices(String stockName)
         {
             foreach (Index index in _indices.Values)
             {
                 if(index.Contains(stockName))
                     index.RemoveStock(stockName);
             }
             foreach (Portfolio portfolio in _portfolios.Values)
             {
                 if(portfolio.ContainsStock(stockName))
                     portfolio.RemoveStock(stockName);
             }
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if(inStockValue < 0)
                 throw new StockExchangeException("Vrijednost dionice mora biti veća od 0");
             if(!_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Tražena dionica ne postoji");
             _stocks[inStockName].SetPrice(inIimeStamp,inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if(!_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Tražena dionica ne postoji");
             return _stocks[inStockName].GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if(!_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Tražena dionica ne postoji");
             return _stocks[inStockName].GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if(!_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Tražena dionica ne postoji");
             return _stocks[inStockName].GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if(_indices.ContainsKey(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " već postoji!");
             _indices.Add(inIndexName,new Index(inIndexName,inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if(!_indices.ContainsKey(inIndexName) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Nepostojeći index ili dionica!");
             _indices[inIndexName].AddStock(_stocks[inStockName]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!_indices.ContainsKey(inIndexName) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Nepostojeći index ili dionica!");
             _indices[inIndexName].RemoveStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!_indices.ContainsKey(inIndexName))
                 throw new StockExchangeException("Nepostojeći index ili dionica!");
             return _indices[inIndexName].Contains(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if(!_indices.ContainsKey(inIndexName))
                 throw new StockExchangeException("Nepostojeći index!");
             return _indices[inIndexName].GetValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if(!_indices.ContainsKey(inIndexName))
                 throw new StockExchangeException("Nepostojeći indeks!");
             return _indices[inIndexName].NumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if(_portfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfelj već postoji!");
             _portfolios.Add(inPortfolioID,new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if(numberOfShares <=0)
                 throw new StockExchangeException("Broj dionica mora biti veći od 0!");
             if(!_portfolios.ContainsKey(inPortfolioID) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Nepostojeći portfelj ili dionica!");
             if(_freeStocks[inStockName] < numberOfShares)
                 throw new StockExchangeException("Nedovoljan broj dionica!");
            

             _freeStocks[inStockName] -= numberOfShares;
             _portfolios[inPortfolioID].AddStock(_stocks[inStockName],numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if(!_portfolios.ContainsKey(inPortfolioID) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne mogu uklanjati nepostojeće dionice ili portfelje!");

             // smještanje dionica u portfelj
             _portfolios[inPortfolioID].RemoveStock(inStockName, numberOfShares);
             _freeStocks[inStockName] += numberOfShares;
             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Ne mogu uklanjati nepostojeće dionice ili portfelje!");
             // oslobađanje dionica iz portfelja
             _freeStocks[inStockName] += NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
             _portfolios[inPortfolioID].RemoveStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if(!_portfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Nepostojeći portfelj!");
             return _portfolios[inPortfolioID].NumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if(!_portfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Nepostojeći portfelj ili dionica!");
             return _portfolios[inPortfolioID].ContainsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!_portfolios.ContainsKey(inPortfolioID) || !_stocks.ContainsKey(inStockName))
                 throw new StockExchangeException("Nepostojeći portfelj ili dionica!");
             return _portfolios[inPortfolioID].NumberOfSharesOfStock(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if(!_portfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Nepostojeći portfelj!");
             return _portfolios[inPortfolioID].GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {

             DateTime startDate;
             DateTime endDate; 

             if(!_portfolios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Nepostojeći portfelj!");
             try
             {
                 startDate = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                 endDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException("Krivi datum!");
             }

             decimal start = _portfolios[inPortfolioID].GetValue(startDate);
             decimal end = _portfolios[inPortfolioID].GetValue(endDate);

             if (start == 0)
                 return Math.Round(end,3);

             return Math.Round((end - start)/start*100,3);
         }
     }
    
     class Stock
     {

         private string _name;
         private long _quantity;
         private KeyValuePair<DateTime, Decimal> _initialPrice;
         private KeyValuePair<DateTime, Decimal> _lastPrice;
         private Dictionary<DateTime, Decimal> _prices;


         public Stock(string name, long quantity, Decimal price, DateTime time)
         {

             _name = name;
             _quantity = quantity;
             if (price > 0 && quantity > 0)
             {
                 _prices = new Dictionary<DateTime, Decimal>()
                    {
                        {time, price}
                    };
                 _initialPrice = new KeyValuePair<DateTime, decimal>(time,price);
                 _lastPrice = new KeyValuePair<DateTime, decimal>(time, price);
             }
             else
             {
                 throw new StockExchangeException("Cijena ili količina su manji od 0!");
             }
         }

         public string Name
         {
             get { return _name; }
             set { _name = value; }
         }

         public long Quantity
         {
             get { return _quantity; }
             set { _quantity = value; }
         }


         public Decimal GetInitialPrice()
         {
             return _initialPrice.Value;
         }

         public Decimal GetLastPrice()
         {
             return _lastPrice.Value;
         }

         public void SetPrice(DateTime time, Decimal price)
         {
             if (_prices.ContainsKey(time))
                 throw new StockExchangeException("Cijena je već definirana za dani trenutak!");
             _prices.Add(time, price);

             if (_lastPrice.Key < time)
                 _lastPrice = new KeyValuePair<DateTime, decimal>(time, price);

             if(_initialPrice.Key > time)
                 _initialPrice = new KeyValuePair<DateTime, decimal>(time, price);

         }

         public Decimal GetPrice(DateTime time)
         {
             List<DateTime> times = new List<DateTime>(_prices.Keys);
             Decimal tempPrice = 0;
             bool notDefined = true;

             foreach (DateTime dateTime in times)
             {
                 if (dateTime <= time)
                 {
                     tempPrice = _prices[dateTime];
                     notDefined = false;
                 }
             }

             if (notDefined || tempPrice == 0m)
                 throw new StockExchangeException("Cijena dionice nije definirana za trenutak " + time);

             return tempPrice;
         }
     }


     class Index
     {
         private IndexTypes _type;
         private String _name;
         private Dictionary<String, Stock> _stocks;

         public Index(String name, IndexTypes type)
         {
             if (!type.Equals(IndexTypes.AVERAGE) && !type.Equals(IndexTypes.WEIGHTED))
                 throw new StockExchangeException("Nepostojeći tip indexa!");

             _name = name;
             _type = type;
             _stocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
         }

         public void AddStock(Stock stock)
         {
             if (_stocks.ContainsKey(stock.Name))
                 throw new StockExchangeException("Dionica sa nazivom " + stock.Name + " već postoji!");
             _stocks.Add(stock.Name, stock);
         }

         public void RemoveStock(string stockName)
         {
             if (!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica " + stockName + " ne postoji u indeksu " + _name + "!");
             _stocks.Remove(stockName);
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public bool Contains(string stockName)
         {
             return _stocks.ContainsKey(stockName);
         }

         public Decimal GetValue(DateTime time)
         {
             Decimal result = 0.0m;
             Decimal quantity = 0.0m;

             if (_stocks.Count == 0)
                 return 0m;

             if (_type == IndexTypes.AVERAGE)
             {

                 foreach (Stock stock in _stocks.Values)
                 {
                     result += stock.GetPrice(time);//* stock.Quantity;
                     quantity += stock.Quantity;
                 }

                 result /= _stocks.Count;
             }
             else if (_type == IndexTypes.WEIGHTED)
             {
                 Decimal sum = 0.0m;
                 foreach (Stock stock in _stocks.Values)
                 {
                     sum += stock.GetPrice(time) * stock.Quantity;
                 }
                 foreach (Stock stock in _stocks.Values)
                 {
                     result += stock.Quantity * stock.GetPrice(time) * stock.GetPrice(time) / sum;
                 }

             }

             return Math.Round(result, 3);

         }

     }

     class Portfolio
     {

         private String _ID;
         private Dictionary<String, int> _stockQuantities;
         private Dictionary<String, Stock> _stocks;



         public Portfolio(String ID)
         {
             _ID = ID;
             _stockQuantities = new Dictionary<string, int>(StringComparer.InvariantCultureIgnoreCase);
             _stocks = new Dictionary<string, Stock>(StringComparer.InvariantCultureIgnoreCase);
         }

         public bool ContainsStock(String stockName)
         {
             return _stocks.ContainsKey(stockName);
         }

         public int NumberOfStocks()
         {
             return _stockQuantities.Count;
         }

         public int NumberOfSharesOfStock(String stockName)
         {
             if (!_stockQuantities.ContainsKey(stockName))
                 throw new StockExchangeException("Portfelj ne sadrži dionicu!");
             return _stockQuantities[stockName];
         }

         public Decimal GetValue(DateTime time)
         {
             Decimal sum = 0.0m;
             foreach (String key in _stocks.Keys)
             {
                 sum += _stocks[key].GetPrice(time) * _stockQuantities[key];
             }
             return sum;
         }

         public void AddStock(Stock stock, int numberOfStocks)
         {


             if (numberOfStocks <= 0)
                 throw new StockExchangeException("Broj dionica mora biti veći od 0!");

             if (_stocks.ContainsKey(stock.Name))
                 _stockQuantities[stock.Name] += numberOfStocks;
             else
             {
                 _stocks.Add(stock.Name, stock);
                 _stockQuantities.Add(stock.Name, numberOfStocks);
             }
         }

         public void RemoveStock(String stockName)
         {
             if (!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Portfelj ne sadrži traženu dionicu!");
             _stocks.Remove(stockName);
             _stockQuantities.Remove(stockName);
         }

         public void RemoveStock(String stockName, int numberOfStocks)
         {
             if (!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Portfelj ne sadrži traženu dionicu!");
             if (_stockQuantities[stockName] < numberOfStocks)
                 throw new StockExchangeException("Portfelj sadrži manji broj dionica od zadanog!");

             _stockQuantities[stockName] -= numberOfStocks;

             if (_stockQuantities[stockName] == 0)
                 RemoveStock(stockName);
         }
     }

}