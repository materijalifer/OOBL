﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string displayedNumber;
        private double lastCalculatedNumber;
        private string lastUsedOperator;
        private char lastPressedKey;
        private double memorisedNumber;
        private int canAddDigitsFlag;

        public Kalkulator()
        {
            this.displayedNumber = "0";
            this.lastCalculatedNumber = 0;
            this.memorisedNumber = 0;
            canAddDigitsFlag = 1;
        }

        public string GetCurrentDisplayState()
        {
            return this.displayedNumber;
        }

        public void Press(char inPressedDigit)
        {
            double preNumber;

            if (displayedNumber == "-E-") return;

            switch (inPressedDigit)
            {
                case ',': // Decimalni zarez 
                    if (displayedNumber.Contains(',') == false && canAddDigitsFlag == 1)
                    {
                        displayedNumber = displayedNumber + ",";
                    }
                    break;
                case 'M': // Promjena predznaka
                    displayedNumber = PromijeniPredznak(displayedNumber);
                    break;
                case 'S': // Racunanje sinusa
                    preNumber = Math.Round(Math.Sin(Double.Parse(displayedNumber)), 9);
                    displayedNumber = preNumber.ToString();
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'K': // Racunanje kosinusa
                    preNumber = Math.Cos(Double.Parse(displayedNumber));
                    displayedNumber = preNumber.ToString();
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'T': // Racunanje tangensa
                    preNumber = Math.Tan(Double.Parse(displayedNumber));
                    displayedNumber = preNumber.ToString();
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'Q': // Kvadriranje
                    preNumber = Math.Pow(Double.Parse(displayedNumber), 2);
                    displayedNumber = preNumber.ToString();
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'R': // Korjenovanje
                    try
                    {
                        displayedNumber = Korjenuj(Double.Parse(displayedNumber)).ToString();
                    }
                    catch (ArgumentException)
                    {
                        displayedNumber = "-E-";
                        return;
                    }
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'I': // Inverz
                    try
                    {
                        displayedNumber = Inverz(Double.Parse(displayedNumber)).ToString();
                    }
                    catch (ArgumentException)
                    {
                        displayedNumber = "-E-";
                        return;
                    }
                    displayedNumber = Prepare(displayedNumber);
                    canAddDigitsFlag = 0;
                    break;
                case 'P': // Spremanje u memoriju
                    displayedNumber = Prepare(displayedNumber);
                    this.memorisedNumber = Double.Parse(this.displayedNumber);
                    break;
                case 'G': // Dohvacanje iz memorije
                    this.displayedNumber = this.memorisedNumber.ToString();
                    canAddDigitsFlag = 1;
                    break;
                case 'C': // Brisanje ekrana
                    this.displayedNumber = "0";
                    break;
                case 'O': // Resetiranje kalkulatora
                    this.displayedNumber = "0";
                    this.lastCalculatedNumber = 0;
                    this.memorisedNumber = 0;
                    this.lastUsedOperator = null;
                    this.canAddDigitsFlag = 1;
                    break;
            }
            if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                canAddDigitsFlag = 0;

                if (lastPressedKey == '+' || lastPressedKey == '-' || lastPressedKey == '*' || lastPressedKey == '/')
                {
                    lastUsedOperator = inPressedDigit.ToString();
                    lastPressedKey = inPressedDigit;
                    return;
                }

                if (lastUsedOperator == null)
                {
                    lastCalculatedNumber = Double.Parse(displayedNumber);
                    displayedNumber = Prepare(displayedNumber);
                    lastUsedOperator = inPressedDigit.ToString();
                }
                else
                {
                    double result = 0;
                    if (lastUsedOperator == "+")
                    {
                        double num1 = this.lastCalculatedNumber;
                        double num2 = Double.Parse(displayedNumber);
                        result = num1 + num2;
                    }
                    else if (lastUsedOperator == "-")
                    {
                        double num1 = this.lastCalculatedNumber;
                        double num2 = Double.Parse(displayedNumber);
                        result = num1 - num2;
                    }
                    else if (lastUsedOperator == "*")
                    {
                        double num1 = this.lastCalculatedNumber;
                        double num2 = Double.Parse(displayedNumber);
                        result = num1 * num2;
                    }
                    else if (lastUsedOperator == "/")
                    {
                        double num1 = this.lastCalculatedNumber;
                        double num2 = Double.Parse(displayedNumber);
                        result = num1 / num2;
                    }

                    lastUsedOperator = inPressedDigit.ToString();

                    displayedNumber = result.ToString();
                    displayedNumber = Prepare(displayedNumber);
                    lastCalculatedNumber = result;
                }
            }

            if (inPressedDigit == '=')
            {
                double result = 0;
                
                if (lastUsedOperator == "+")
                {
                    double num1 = this.lastCalculatedNumber;
                    double num2 = Double.Parse(displayedNumber);
                    result = num1 + num2;
                }
                else if (lastUsedOperator == "-")
                {
                    double num1 = this.lastCalculatedNumber;
                    double num2 = Double.Parse(displayedNumber);
                    result = num1 - num2;
                }
                else if (lastUsedOperator == "*")
                {
                    double num1 = this.lastCalculatedNumber;
                    double num2 = Double.Parse(displayedNumber);
                    result = num1 * num2;
                }
                else if (lastUsedOperator == "/")
                {
                    double num1 = this.lastCalculatedNumber;
                    double num2 = Double.Parse(displayedNumber);
                    result = num1 / num2;
                }
                else if (lastUsedOperator == null)
                {
                    lastPressedKey = inPressedDigit;
                    displayedNumber = Prepare(displayedNumber);
                    return;
                }
                lastCalculatedNumber = result;
                lastUsedOperator = null;

                displayedNumber = result.ToString();
                displayedNumber = Prepare(displayedNumber);
                
            }

            if (Char.IsDigit(inPressedDigit))
            {
                if (this.displayedNumber == "0")
                {
                    this.displayedNumber = Char.ToString(inPressedDigit);
                    lastPressedKey = inPressedDigit;
                    return;
                }

                if (canAddDigitsFlag == 0)
                {
                    displayedNumber = inPressedDigit.ToString();
                    canAddDigitsFlag = 1;
                }

                if (canAddDigitsFlag == 1)
                {
                    if (displayedNumber.Contains(','))
                    {
                        if (displayedNumber.Length == 11)
                        {
                            return;
                        }
                        else if (displayedNumber.Length == 12 && displayedNumber.StartsWith("-"))
                        {
                            return;
                        }
                        else
                        {
                            displayedNumber = displayedNumber + Char.ToString(inPressedDigit);
                        }
                    }
                    else
                    {
                        if (displayedNumber.StartsWith("-") && displayedNumber.Length == 11) return;
                        else if (displayedNumber.Length == 10) return;
                        else displayedNumber = displayedNumber + Char.ToString(inPressedDigit);
                    }
                }
            }
            
            lastPressedKey = inPressedDigit;
        }

        // Provjera da li je broj spreman za ispis
        private string Prepare(string number)
        {
            if (number.Contains('E'))
            {
                return "-E-";
            }

            if (number.Contains(',') == false)
            {
                if (number.Length >= 11)
                {
                    return "-E-";
                }
                else if (number.StartsWith("-") && number.Length >= 12)
                {
                    return "-E-";
                }
            }
            else
            {
                int indeks;

                if (number.StartsWith("-"))
                {
                    indeks = number.IndexOf(',') - 1;
                }
                else
                {
                    indeks = number.IndexOf(',');
                }

                if (indeks >= 10)
                {
                    return "-E-";
                }

                double digits = Double.Parse(number);
                digits = Math.Round(digits, 10 - indeks);
                number = digits.ToString();

                while (number.EndsWith("0"))
                {
                    number = number.Remove(number.Length - 1);
                }

                if (number.EndsWith(","))
                {
                    number.Remove(number.Length - 1);
                }
            }
            return number;
        }

        private string PromijeniPredznak(string number)
        {
            if (number.StartsWith("-"))
            {
                return number.Substring(1);
            }
            else return "-" + number;
        }

        private double Korjenuj(double number)
        {
            if (number >= 0)
            {
                return Math.Sqrt(number);
            }
            else throw new System.ArgumentException("Parametar mora biti pozitivan broj");
        }

        private double Inverz(double number)
        {
            if (number != 0)
            {
                return 1 / number;
            }
            else throw new System.ArgumentException("Broj ne smije biti 0");
        }
    }
}