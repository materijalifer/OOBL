﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        List<Stock> stockList = new List<Stock>();
        List<Index> indexList = new List<Index>();
        List<Portfolio> portfolioList = new List<Portfolio>();


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("inNumberOfShares must be a number greater than 0!");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("inInitialPrice must be a number greater than 0!");
            if (StockExists(inStockName))
                throw new StockExchangeException("Stock with this name already exists!");

            Stock tempStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stockList.Add(tempStock);
        }


        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock with this name doesn't exist!");

            foreach (Stock currentStock in stockList)
                if (currentStock.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                    stockList.Remove(currentStock);

            foreach (Index currentIndex in indexList)
                if (IsStockPartOfIndex(currentIndex.indexName, inStockName))
                    RemoveStockFromIndex(currentIndex.indexName, inStockName);

            foreach (Portfolio currentPortfolio in portfolioList)
                if (IsStockPartOfPortfolio(currentPortfolio.portfolioID, inStockName))
                    RemoveStockFromPortfolio(currentPortfolio.portfolioID, inStockName);

        }


        public bool StockExists(string inStockName)
        {
            bool stockExists = false;
            foreach (Stock currentStock in stockList)
            {
                if (currentStock.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                    stockExists = true;
            }
            return stockExists;
        }


        public Stock FindStock(string inStockName)
        {
            Stock tmpStock = null;
            foreach (Stock currentStock in stockList)
            {
                if (currentStock.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                    tmpStock = currentStock;
            }
            return tmpStock;
        }


        public int NumberOfStocks()
        {
            return stockList.Count;
        }


        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock with this name doesn't exist!");

            Stock currentStock = FindStock(inStockName);
            currentStock.SetStockPrice(inIimeStamp, inStockValue);
        }


        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock with this name doesn't exist!");

            Stock currentStock = FindStock(inStockName);
            decimal price = currentStock.GetStockPrice(inTimeStamp);
            return price;
        }


        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock with this name doesn't exist!");

            Stock currentStock = FindStock(inStockName);
            decimal price = currentStock.GetInitialStockPrice();
            return price;
        }


        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock with this name doesn't exist!");

            Stock currentStock = FindStock(inStockName);
            decimal price = currentStock.GetLastStockPrice();

            return price;
        }


        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Invalid index type!");
            if (IndexExists(inIndexName))
                throw new StockExchangeException("Index with this name already exists!");

            Index tmpIndex = new Index(inIndexName, inIndexType);
            indexList.Add(tmpIndex);
        }


        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Stock currentStock = FindStock(inStockName);
            if (currentStock.stockIsInIndex == true)
                throw new StockExchangeException("This stock is already in some other index");

            Index currentIndex = FindIndex(inIndexName);
            currentIndex.AddStockToIndex(currentStock);
        }


        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Index currentIndex = FindIndex(inIndexName);
            currentIndex.RemoveStockFromIndex(inStockName);
        }


        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Index currentIndex = FindIndex(inIndexName);
            bool stockIsPartOfIndex = currentIndex.IsStockPartOfIndex(inStockName);
            return stockIsPartOfIndex;
        }


        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist!");

            Index currentIndex = FindIndex(inIndexName);
            decimal indexValue = currentIndex.GetIndexValue(inTimeStamp);

            return indexValue;
        }


        public bool IndexExists(string inIndexName)
        {
            bool indexExists = false;
            foreach (Index currentIndex in indexList)
                if (currentIndex.indexName.Equals(inIndexName, StringComparison.OrdinalIgnoreCase))
                    indexExists = true;
            return indexExists;
        }


        public Index FindIndex(string inIndexName)
        {
            Index tmpIndex = null;
            foreach (Index currentIndex in indexList)
                if (currentIndex.indexName.Equals(inIndexName, StringComparison.OrdinalIgnoreCase))
                    tmpIndex = currentIndex;
            return tmpIndex;
        }


        public int NumberOfIndices()
        {
            return indexList.Count;
        }


        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index doesn't exist!");

            Index currentIndex = FindIndex(inIndexName);
            int numberOfStocks = currentIndex.NumberOfStocksInIndex();
            return numberOfStocks;
        }


        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio tmpPortfolio = new Portfolio(inPortfolioID);
            portfolioList.Add(tmpPortfolio);
        }


        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio with this ID doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            Stock currentStock = FindStock(inStockName);
            currentPortfolio.AddStockToPortfolio(currentStock, numberOfShares);
        }


        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            Stock currentStock = FindStock(inStockName);
            currentPortfolio.RemoveStockFromPortfolio(currentStock, numberOfShares);
        }


        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            Stock currentStock = FindStock(inStockName);
            currentPortfolio.RemoveStockFromPortfolio(currentStock);
        }


        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }


        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio with this ID doesn't exist");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            int nrOfStocks = currentPortfolio.NumberOfStocksInPortfolio();
            return nrOfStocks;
        }


        public bool PortfolioExists(string inPortfolioID)
        {
            bool portfolioExistx = false;
            foreach (Portfolio currentPort in portfolioList)
                if (currentPort.portfolioID.Equals(inPortfolioID))
                    portfolioExistx = true;
            return portfolioExistx;
        }


        public Portfolio FindPortfolio(string inPortfolioID)
        {
            Portfolio tmpPortfolio = null;
            foreach (Portfolio currentPort in portfolioList)
                if (currentPort.portfolioID.Equals(inPortfolioID))
                    tmpPortfolio = currentPort;
            return tmpPortfolio;
        }


        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist!");

            Portfolio currentPort = FindPortfolio(inPortfolioID);
            bool stockIsPartOfPortfolio = currentPort.IsStockPartOfPortfolio(inStockName);

            return stockIsPartOfPortfolio;
        }


        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio with this ID doesn't exist");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Stock doesn't exist");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            int nrOfShares = currentPortfolio.NumberOfSharesOfStockInPortfolio(inStockName);
            return nrOfShares;

        }


        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist!");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            decimal value = currentPortfolio.GetPortfolioValue(timeStamp);
            return value;
        }


        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio doesn't exist!");

            Portfolio currentPortfolio = FindPortfolio(inPortfolioID);
            decimal changeInValue = currentPortfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
            return changeInValue;
        }
    }



    public class Stock
    {
        public string stockName { get; set; }
        public long numberOfShares { get; set; }
        public long availableNrOfShares { get; set; }
        public SortedList<DateTime, decimal> pricesInTime { get; set; }
        public bool stockIsInIndex { get; set; }


        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.stockName = inStockName;
            this.numberOfShares = inNumberOfShares;
            this.availableNrOfShares = inNumberOfShares;
            this.pricesInTime = new SortedList<DateTime, decimal>();
            this.pricesInTime.Add(inTimeStamp, inInitialPrice);
            this.stockIsInIndex = false;
        }


        public void SetStockPrice(DateTime inIimeStamp, decimal inStockValue)
        {
            foreach (KeyValuePair<DateTime, decimal> priceInTime in this.pricesInTime)
                if (priceInTime.Value == inStockValue)
                    throw new StockExchangeException("price for this timestamp already exists!");

            this.pricesInTime.Add(inIimeStamp, inStockValue);
        }


        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            if (this.pricesInTime.ElementAt(0).Key > inTimeStamp)
                throw new StockExchangeException("Price for this stock was not yet defined for the current timestamp!");
            decimal price = 0;
            foreach (KeyValuePair<DateTime, decimal> priceInTime in this.pricesInTime)
            {
                if (priceInTime.Key < inTimeStamp)
                    price = priceInTime.Value;
            }
            return price;
        }


        public decimal GetInitialStockPrice()
        {
            return this.pricesInTime.ElementAt(0).Value;
        }


        public decimal GetLastStockPrice()
        {
            int lastIndex = this.pricesInTime.Count;
            return this.pricesInTime.ElementAt(lastIndex).Value;
        }
    }



    public class Index
    {
        public string indexName { get; set; }
        public IndexTypes indexType { get; set; }
        public List<Stock> indexStocks { get; set; }


        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.indexName = inIndexName;
            this.indexType = inIndexType;
            this.indexStocks = new List<Stock>();
        }


        public void AddStockToIndex(Stock inStock)
        {
            this.indexStocks.Add(inStock);
            inStock.stockIsInIndex = true;
        }


        public void RemoveStockFromIndex(string inStockName)
        {
            if (!IsStockPartOfIndex(inStockName))
                throw new StockExchangeException("Index doesn't contain this stock!");
            foreach (Stock currentStock in this.indexStocks)
                if (currentStock.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                {
                    this.indexStocks.Remove(currentStock);
                    currentStock.stockIsInIndex = false;
                }
        }


        public bool IsStockPartOfIndex(string inStockName)
        {
            bool stockIsPartOfIndex = false;

            foreach (Stock currentStock in this.indexStocks)
                if (currentStock.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                    stockIsPartOfIndex = true;

            return stockIsPartOfIndex;
        }


        public decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal indexValue = 0;

            if (this.indexType == IndexTypes.AVERAGE)
                indexValue = this.IndexValueAverage(inTimeStamp);

            else if (this.indexType == IndexTypes.WEIGHTED)
                indexValue = this.IndexValueWeighted(inTimeStamp);

            return indexValue;
        }


        public decimal IndexValueAverage(DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal nrOfStocks = 0;
            foreach (Stock currentStock in this.indexStocks)
            {
                if (currentStock.pricesInTime.ElementAt(0).Key > inTimeStamp)
                    throw new StockExchangeException("Not all stocks in index have defined value for the chosen timestamp!");
                decimal price = 0;
                foreach (KeyValuePair<DateTime, decimal> priceInTime in currentStock.pricesInTime)
                {
                    int i = 0;
                    while (priceInTime.Key <= inTimeStamp)
                    {
                        price = priceInTime.Value;
                        i++;
                        if (i >= currentStock.pricesInTime.Count)
                            break;
                    }
                }
                sum += price * currentStock.numberOfShares;
                nrOfStocks += currentStock.numberOfShares;
            }
            return Math.Round(sum / nrOfStocks, 3);
        }


        public decimal IndexValueWeighted(DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal[] prices = new decimal[this.indexStocks.Count];
            decimal[] weights = new decimal[this.indexStocks.Count];
            decimal finalValue = 0;

            //1: izračunava se cijena svake dionice u željenom trenutku
            for (int i = 0; i < this.indexStocks.Count; i++)
            {
                if (this.indexStocks.ElementAt(i).pricesInTime.ElementAt(0).Key > inTimeStamp)
                    throw new StockExchangeException("Not all stocks in index have defined value for the chosen timestamp!");
                foreach (KeyValuePair<DateTime, decimal> priceInTime in this.indexStocks.ElementAt(i).pricesInTime)
                {
                    int j = 0;
                    while (priceInTime.Key <= inTimeStamp)
                    {
                        prices[i] = priceInTime.Value;
                        j++;
                        if (j >= this.indexStocks.ElementAt(i).pricesInTime.Count)
                            break;
                    }
                }
                sum += prices[i] * this.indexStocks.ElementAt(i).numberOfShares;
            }

            //2: izračunava se težina svake pojedine dionice
            for (int i = 0; i < indexStocks.Count; i++)
            {
                weights[i] = prices[i] * indexStocks.ElementAt(i).numberOfShares / sum;
            }

            //3: konačna vrijednost je suma pomnoženih težina i cijena svake pojedine dionice
            for (int i = 0; i < indexStocks.Count; i++)
            {
                finalValue += prices[i] * weights[i];
            }

            return Math.Round(finalValue, 3);
        }


        public int NumberOfStocksInIndex()
        {
            return this.indexStocks.Count;
        }
    }



    public class Portfolio
    {
        public string portfolioID { get; set; }
        public Dictionary<Stock, long> portfolioStocks { get; set; }


        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
            this.portfolioStocks = new Dictionary<Stock, long>();
        }


        public bool IsStockPartOfPortfolio(string inStockName)
        {
            bool stockIsPartOfPortfolio = false;
            foreach (KeyValuePair<Stock, long> currentStock in this.portfolioStocks)
                if (currentStock.Key.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                    stockIsPartOfPortfolio = true;
            return stockIsPartOfPortfolio;
        }


        public void AddStockToPortfolio(Stock inStock, int numberOfShares)
        {
            long newNrOfAvailableShares = inStock.availableNrOfShares - numberOfShares;
            if (newNrOfAvailableShares < 0)
                throw new StockExchangeException("NumberOfShares is too big!");
            else
                inStock.availableNrOfShares = newNrOfAvailableShares;
            if (IsStockPartOfPortfolio(inStock.stockName))
            {
                foreach (KeyValuePair<Stock, long> currentStock in portfolioStocks)
                    if (currentStock.Key.stockName.Equals(inStock.stockName, StringComparison.OrdinalIgnoreCase))
                    {
                        long newNrOfShares = currentStock.Value + numberOfShares;
                        portfolioStocks.Remove(currentStock.Key);
                        portfolioStocks.Add(inStock, newNrOfShares);

                        break;
                    }
            }
            else
                portfolioStocks.Add(inStock, numberOfShares);
        }


        public void RemoveStockFromPortfolio(Stock inStock, int numberOfShares)
        {
            if (!IsStockPartOfPortfolio(inStock.stockName))
                throw new StockExchangeException("Portfolio doesn't have any shares of this stock!");
            else
            {
                inStock.availableNrOfShares += numberOfShares;
                foreach (KeyValuePair<Stock, long> currentStock in portfolioStocks)
                    if (currentStock.Key.stockName.Equals(inStock.stockName, StringComparison.OrdinalIgnoreCase))
                    {
                        long newNrOfShares = currentStock.Value - numberOfShares;
                        portfolioStocks.Remove(currentStock.Key);
                        if (newNrOfShares > 0)
                            portfolioStocks.Add(currentStock.Key, newNrOfShares);
                        break;
                    }
            }
        }


        public void RemoveStockFromPortfolio(Stock inStock)
        {
            if (!IsStockPartOfPortfolio(inStock.stockName))
                throw new StockExchangeException("this stock is not in this portfolio!");
            else
                foreach (KeyValuePair<Stock, long> currentStock in portfolioStocks)
                    if (currentStock.Key.stockName.Equals(inStock.stockName, StringComparison.OrdinalIgnoreCase))
                    {
                        inStock.availableNrOfShares += currentStock.Value;
                        portfolioStocks.Remove(currentStock.Key);
                    }
        }


        public int NumberOfStocksInPortfolio()
        {
            return this.portfolioStocks.Count;
        }


        public int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            int nrOfShares = 0;
            if (!IsStockPartOfPortfolio(inStockName))
                throw new StockExchangeException("Stock doesn't exist in this portfolio!");
            else
            {
                foreach (KeyValuePair<Stock, long> currentStock in portfolioStocks)
                    if (currentStock.Key.stockName.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                        nrOfShares = (int)currentStock.Value;
            }
            return nrOfShares;
        }


        public decimal GetPortfolioValue(DateTime inTimeStamp)
        {
            decimal sum = 0;

            foreach (KeyValuePair<Stock, long> currentStock in this.portfolioStocks)
            {
                if (currentStock.Key.pricesInTime.ElementAt(0).Key > inTimeStamp)
                    throw new StockExchangeException("Not all stocks in portfolio have defined value for the chosen timestamp!");
                decimal price = 0;
                foreach (KeyValuePair<DateTime, decimal> priceInTime in currentStock.Key.pricesInTime)
                {
                    int i = 0;
                    while (priceInTime.Key <= inTimeStamp)
                    {
                        price = priceInTime.Value;
                        i++;
                        if (i >= currentStock.Key.pricesInTime.Count)
                            break;
                    }
                }
                sum += price * currentStock.Value;
            }
            return Math.Round(sum, 3);
        }


        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            int lastDayOfTheMonth = DateTime.DaysInMonth(Year, Month);
            DateTime startDate = new DateTime(Year, Month, 01, 00, 00, 00, 00);
            DateTime endDate = new DateTime(Year, Month, lastDayOfTheMonth, 23, 59, 59, 999);

            decimal startValueFinal = this.GetPortfolioValue(startDate);
            decimal endValueFinal = this.GetPortfolioValue(endDate);

            decimal changeInValue = ((startValueFinal - endValueFinal) / startValueFinal) * 100;
            return Math.Round(Math.Abs(changeInValue), 3);
        }
    }
}
