﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string StockName { get; private set; }
        public long NumberOfShares { get; set; }
        public decimal InitialPrice { get; set; }
        public DateTime InitialTime { get; set; }
        public decimal CurrentPrice { get; set; }
        public DateTime TimeStamp { get; set; }
        public long PreostaloDionica { get; set; }

        public Dictionary<DateTime, decimal> prices = new Dictionary<DateTime, decimal>();

        public Stock(string StockName, long NumberOfShares, decimal InitialPrice, DateTime Timestamp)
        {
            this.StockName = StockName.ToUpper();
            this.NumberOfShares = NumberOfShares;
            this.InitialPrice = InitialPrice;
            this.InitialTime = Timestamp;
            this.CurrentPrice = InitialPrice;
            this.TimeStamp = Timestamp;
            this.PreostaloDionica = NumberOfShares;
            prices.Add(Timestamp, InitialPrice);
        }
    }

    public class Index
    {
        public string IndexName { get; private set; }
        public IndexTypes IndexType { get; private set; }

        public Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();

        public Index(string name, IndexTypes type)
        {
            if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Korištenje nedozvoljene vrste indeksa!");
            }
            else
            {
                this.IndexName = name.ToUpper();
                this.IndexType = type;
            }
        }

    }

    public class Portfolio
    {
        public string ID { get; private set; }

        public Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        public Dictionary<string, PortfolioShareHelp> shares = new Dictionary<string, PortfolioShareHelp>();

        public Portfolio(string ID)
        {
            this.ID = ID;
        }
    }

    public struct PortfolioShareHelp
    {
        public long maxShare;
        public long currentShare;
    }


    public class StockExchange : IStockExchange
    {
        Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        Dictionary<string, Index> indices = new Dictionary<string, Index>();
        Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Naziv dionice postoji!!");
            }
            else if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica ne smije biti 0 ili manji");
            }
            else if (inInitialPrice <= 0m)
            {
                throw new StockExchangeException("Cijena ne smije biti 0 ili negativna");
            }
            else
            {
                stocks.Add(inStockName.ToUpper(), new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }

        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                stocks.Remove(inStockName.ToUpper());
            }
            else
            {
                throw new StockExchangeException("Ne mogu obrisati dionicu koja ne postoji!");
            }
            foreach (Index index in indices.Values)
            {
                foreach (string stock in index.stocks.Keys)
                {
                    if (stock.Equals(inStockName.ToUpper()))
                    {
                        index.stocks.Remove(stock);
                        break;
                    }
                }
            }
            foreach (Portfolio portfolio in portfolios.Values)
            {
                foreach (string SS in portfolio.stocks.Keys)
                {
                    if (SS.Equals(inStockName.ToUpper()))
                    {
                        portfolio.stocks.Remove(SS);
                        portfolio.shares.Remove(SS);
                        break;
                    }
                }
            }

        }

        public bool StockExists(string inStockName)
        {
            foreach (string item in stocks.Keys)
            {
                if (item.Equals(inStockName.ToUpper()))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0m)
            {
                throw new StockExchangeException("Nova cijena ne smije biti nula ili negativna!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Ne mogu promijeniti vrijednost nepostojećoj dionici!!");
            }
            else
            {
                Stock a = stocks[inStockName.ToUpper()];
                foreach (DateTime item in a.prices.Keys)
                {
                    if (item.CompareTo(inIimeStamp) == 0)
                    {
                        throw new StockExchangeException("Za navedeni trenutak cijena postoji!");
                    }
                }
                a.prices.Add(inIimeStamp, inStockValue);
                if (inIimeStamp.CompareTo(a.TimeStamp) > 0)
                {
                    a.TimeStamp = inIimeStamp;
                    a.CurrentPrice = inStockValue;
                }
                else if (inIimeStamp.CompareTo(a.InitialTime) < 0)
                {
                    a.InitialTime = inIimeStamp;
                    a.InitialPrice = inStockValue;
                }
                //stocks[inStockName.ToUpper()] = a; //nije potrebno jer je u objektu "a" referenca
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                long timeToCompare = inTimeStamp.Ticks;
                long min = long.MaxValue;
                DateTime minDT = DateTime.MinValue;

                Stock a = stocks[inStockName.ToUpper()];
                foreach (DateTime item in a.prices.Keys)
                {
                    long time = item.Ticks;
                    long rez = timeToCompare - time;
                    if (rez >= 0 && rez < min)
                    {
                        min = rez;
                        minDT = item;
                    }
                }
                if (minDT.CompareTo(DateTime.MinValue) > 0)
                {
                    return a.prices[minDT];
                }
                else
                {
                    throw new StockExchangeException("Za navedeni datum cijena ne postoji!");
                }
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return stocks[inStockName.ToUpper()].InitialPrice;
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName))
            {
                return stocks[inStockName.ToUpper()].CurrentPrice;
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji!");
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index već postoji!");
            }
            else
            {
                Index a = new Index(inIndexName, inIndexType);
                indices.Add(inIndexName.ToUpper(), a);
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index a = indices[inIndexName.ToUpper()];
                if (a.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    throw new StockExchangeException("Dionica već pripada indeksu, nije moguće dodati duplu vrijednost!");
                }
                else
                {
                    a.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                }
            }
            else
            {
                throw new StockExchangeException("Dodavanje nije moguće zbog nepostojanja dionice ili indeksa!");
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index a = indices[inIndexName.ToUpper()];
                if (a.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    a.stocks.Remove(inStockName.ToUpper());
                }
                else
                {
                    throw new StockExchangeException("Nije moguće ukloniti dionucu koja ne postoji iz indeksa!");
                }
            }
            else
            {
                throw new StockExchangeException("Uklanjanje nije moguće zbog nepostojanja dionice ili indeksa!");
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) && StockExists(inStockName))
            {
                Index a = indices[inIndexName.ToUpper()];
                if (a.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new StockExchangeException("Provjera nije moguća zbog nepostojanja indeksa!");
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (IndexExists(inIndexName))
            {
                Index a = indices[inIndexName.ToUpper()];
                decimal sumA = 0m;
                int count = 0;
                decimal sumW = 0m;
                foreach (string stockName in a.stocks.Keys)
                {
                    decimal temp = GetStockPrice(stockName, inTimeStamp);
                    sumA += temp;
                    count++;
                    sumW += a.stocks[stockName].NumberOfShares * temp;

                }
                if (count == 0)
                {
                    return 0;
                }

                else if (a.IndexType == IndexTypes.AVERAGE)
                {
                    return Math.Round(sumA / count, 3);
                }
                else if (a.IndexType == IndexTypes.WEIGHTED)
                {
                    decimal weightedSum = 0m;
                    foreach (string stockName in a.stocks.Keys)
                    {
                        decimal temp = GetStockPrice(stockName, inTimeStamp);
                        weightedSum += temp * ((temp * a.stocks[stockName].NumberOfShares) / (sumW));
                    }
                    return Math.Round(weightedSum, 3);
                }
                else
                {
                    throw new StockExchangeException("Neodgovarajući tip indeksa!");
                }
            }
            else
            {
                throw new StockExchangeException("Računanje indeksa nije moguće zbog nepostojanja indeksa!");
            }
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (string item in indices.Keys)
            {
                if (item.Equals(inIndexName.ToUpper()))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName))
            {
                return indices[inIndexName.ToUpper()].stocks.Count;
            }
            else
            {
                throw new StockExchangeException("Index ne postoji!");
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfolio već postoji!");
            }
            else
            {
                Portfolio a = new Portfolio(inPortfolioID);
                portfolios.Add(inPortfolioID, a);
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName) && numberOfShares > 0)
            {
                Portfolio p = portfolios[inPortfolioID];
                
                long preostalo = stocks[inStockName.ToUpper()].PreostaloDionica;

                if (p.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    PortfolioShareHelp PSH = p.shares[inStockName.ToUpper()];
                    if (PSH.currentShare + numberOfShares <= PSH.maxShare)
                    {
                        if (preostalo >= numberOfShares)
                        {
                            PSH.currentShare += numberOfShares;
                            p.shares[inStockName.ToUpper()] = PSH;
                            stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - numberOfShares;

                        }
                        else if(preostalo < numberOfShares)
                        {
                            PSH.currentShare += preostalo;
                            p.shares[inStockName.ToUpper()] = PSH;
                            stocks[inStockName.ToUpper()].PreostaloDionica = 0;
                        }
                    }
                    else if (PSH.currentShare + numberOfShares > PSH.maxShare)
                    {
                        if (preostalo >= numberOfShares)
                        {
                            stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - (PSH.maxShare - PSH.currentShare);
                            PSH.currentShare = PSH.maxShare;
                            p.shares[inStockName.ToUpper()] = PSH;                           
                        }
                        else if (preostalo < numberOfShares) 
                        {
                            if (PSH.currentShare + preostalo <= PSH.maxShare) 
                            {
                                stocks[inStockName.ToUpper()].PreostaloDionica = 0;
                                PSH.currentShare += preostalo;
                                p.shares[inStockName.ToUpper()] = PSH;
                            }
                            else if (PSH.currentShare + preostalo > PSH.maxShare) 
                            {
                                stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - (PSH.maxShare - PSH.currentShare);
                                PSH.currentShare = PSH.maxShare;
                                p.shares[inStockName.ToUpper()] = PSH;
                            }
                        }
                    }
                }
                else
                {
                    long max = stocks[inStockName.ToUpper()].NumberOfShares;
                    if (numberOfShares <= max)
                    {
                        if (preostalo >= numberOfShares)
                        {
                            PortfolioShareHelp PSH = new PortfolioShareHelp();
                            PSH.maxShare = max;
                            PSH.currentShare = numberOfShares;
                            p.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                            p.shares.Add(inStockName.ToUpper(), PSH);
                            stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - numberOfShares;
                        }
                        else if (preostalo < numberOfShares) 
                        {
                            PortfolioShareHelp PSH = new PortfolioShareHelp();
                            PSH.maxShare = max;
                            PSH.currentShare = preostalo;
                            p.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                            p.shares.Add(inStockName.ToUpper(), PSH);
                            stocks[inStockName.ToUpper()].PreostaloDionica = 0;
                        }
                    }
                    else if(numberOfShares > max)
                    {
                        if (preostalo >= numberOfShares) 
                        {
                            PortfolioShareHelp PSH = new PortfolioShareHelp();
                            PSH.maxShare = max;
                            PSH.currentShare = max;
                            p.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                            p.shares.Add(inStockName.ToUpper(), PSH);
                            stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - max;
                        }
                        else if (preostalo < numberOfShares) 
                        {
                            if (preostalo <= max) 
                            {
                                PortfolioShareHelp PSH = new PortfolioShareHelp();
                                PSH.maxShare = max;
                                PSH.currentShare = preostalo;
                                p.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                                p.shares.Add(inStockName.ToUpper(), PSH);
                                stocks[inStockName.ToUpper()].PreostaloDionica = 0;
                            }
                            else if (preostalo > max) 
                            {
                                PortfolioShareHelp PSH = new PortfolioShareHelp();
                                PSH.maxShare = max;
                                PSH.currentShare = max;
                                p.stocks.Add(inStockName.ToUpper(), stocks[inStockName.ToUpper()]);
                                p.shares.Add(inStockName.ToUpper(), PSH);
                                stocks[inStockName.ToUpper()].PreostaloDionica = preostalo - max;
                            }
                        }
                    }
                }
            }
            else
            {
                throw new StockExchangeException("Dodavanje dionice nije moguće. Portfolio ili dionica ne postoji! Ili broj dionica <= 0!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolios[inPortfolioID];
                if (p.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    PortfolioShareHelp PSH = p.shares[inStockName.ToUpper()];
                    if (PSH.currentShare - numberOfShares > 0)
                    {
                        PSH.currentShare -= numberOfShares;
                        p.shares[inStockName.ToUpper()] = PSH;
                    }
                    else if (PSH.currentShare - numberOfShares <= 0)
                    {
                        p.shares.Remove(inStockName.ToUpper());
                        p.stocks.Remove(inStockName.ToUpper());
                    }

                }
                else
                {
                    throw new StockExchangeException("Brisanje dionice iz portfolija nije moguće!");
                }
            }
            else
            {
                throw new StockExchangeException("Brisanje dionice iz portfolija nije moguće!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolios[inPortfolioID];
                if (p.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    p.stocks.Remove(inStockName.ToUpper());
                    p.shares.Remove(inStockName.ToUpper());
                }
                else
                {
                    throw new StockExchangeException("Brisanje dionice iz portfolija nije moguće!");
                }
            }
            else
            {
                throw new StockExchangeException("Brisanje dionice iz portfolija nije moguće!");
            }
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                return portfolios[inPortfolioID].stocks.Count;
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (string item in portfolios.Keys)
            {
                if (item.Equals(inPortfolioID))
                {
                    return true;
                }
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
            {
                Portfolio p = portfolios[inPortfolioID];
                if (p.stocks.ContainsKey(inStockName.ToUpper()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) && IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                return (int)portfolios[inPortfolioID].shares[inStockName.ToUpper()].currentShare;
            }
            else if (PortfolioExists(inPortfolioID)) 
            {
                return 0;
            }
            else
            {
                throw new StockExchangeException("Portfolio ne postoji!");
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
            {
                Portfolio p = portfolios[inPortfolioID];
                decimal sum = 0m;
                foreach (Stock item in p.stocks.Values)
                {
                    sum += GetStockPrice(item.StockName, timeStamp) * p.shares[item.StockName].currentShare;
                }
                return Math.Round(sum, 3); ;
            }
            else
            {
                throw new StockExchangeException("Porfolio ne postoji!");
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            try
            {
                DateTime.DaysInMonth(Year, Month);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Datum nije dobar!");
            }
            if (PortfolioExists(inPortfolioID))
            {
                decimal first = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 0, 0, 0, 0));
                int dan = DateTime.DaysInMonth(Year, Month);
                decimal last = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, dan, 23, 59, 59, 999));
                if (first == 0)
                {
                    return 0m;
                }
                else
                {
                    return Math.Round((last - first) / first * 100, 3);
                }

            }
            else
            {
                throw new StockExchangeException("Porfolio ne postoji, računjanje nije moguće!");
            }
        }
    }
}
