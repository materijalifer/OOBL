﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public abstract class StockExchangeElement
    {
    }

    public interface IRepository
    {
        void add(StockExchangeElement element);
        void remove(string elementName);
        bool elementExists(string elementName);
    }

    public class Stock : StockExchangeElement
    {
        public string stockName { get; set; }
        public long numberOfStocks { get; set; }
        public List<KeyValuePair<DateTime, decimal>> stockPrices = new List<KeyValuePair<DateTime, decimal>>();

        public Stock() { }

        public Stock(string stockName, long numberOfStocks, decimal stockPrice, DateTime timestamp)
        {
            this.stockName = stockName;
            this.numberOfStocks = numberOfStocks;
            stockPrices.Add(new KeyValuePair<DateTime, decimal>(timestamp, stockPrice));
        }

        public decimal getCurrentStockPrice()
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            dates.Sort();
            dates.RemoveAll(date => date > DateTime.Now);
            return stockPrices.Single(pair => pair.Key == dates.Last()).Value;
        }

        public decimal getStockPriceAtGivenTime(DateTime timestamp)
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            dates.Sort();
            dates.RemoveAll(date => date > timestamp);
            return stockPrices.Single(pair => pair.Key == dates.Last()).Value;
        }

        public decimal getFirstPrice()
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            dates.Sort();
            return stockPrices.Single(pair => pair.Key == dates.First()).Value;
        }

        public decimal getLastPrice()
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            dates.Sort();
            return stockPrices.Single(pair => pair.Key == dates.Last()).Value;
        }

        public bool priceExistsAtExactTime(DateTime timestamp)
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            if (dates.Exists(item => item.Equals(timestamp)))
                return true;
            else
                return false;
        }

        public bool priceExistsForGivenTimestamp(DateTime timestamp)
        {
            List<DateTime> dates = new List<DateTime>();
            stockPrices.ForEach(pair => dates.Add(pair.Key));
            dates.Sort();
            dates.RemoveAll(date => date > timestamp);
            if (dates.Count() > 0)
                return true;
            else
                return false;
        }
    }

    public abstract class IndexFactory
    {
        public abstract Index createIndex();
    }

    public class WeightedIndexFactory : IndexFactory
    {
        public override Index createIndex()
        {
            return new WeightedIndex();
        }
    }

    public class AverageIndexFactory : IndexFactory
    {
        public override Index createIndex()
        {
            return new AverageIndex();
        }
    }

    public abstract class Index : StockExchangeElement
    {
        public string indexName { get; set; }
        public IndexTypes type { get; set; }
        public List<Stock> stocks = new List<Stock>();
        public abstract decimal calculateIndexValue(DateTime timestamp);
    }

    public class WeightedIndex : Index
    {
        public override decimal calculateIndexValue(DateTime timestamp)
        {
            decimal totalSum = 0;
            decimal indexValue = 0;

            foreach (Stock stock in stocks)
            {
                totalSum += stock.getStockPriceAtGivenTime(timestamp) * stock.numberOfStocks;
            }
            foreach (Stock stock in stocks)
            {
                indexValue += calculateStockValue(stock, totalSum);
            }

            return indexValue;
        }

        decimal calculateStockValue(Stock stock, decimal totalSum)
        {
            return (stock.getCurrentStockPrice() / totalSum) * stock.getCurrentStockPrice() * stock.numberOfStocks;
        }
    }

    public class AverageIndex : Index
    {
        public override decimal calculateIndexValue(DateTime timestamp)
        {
            decimal totalSum = 0;
            if (stocks.Count() == 0)
            {
                return 0;
            }
            foreach (Stock stock in stocks)
            {
                totalSum += stock.getStockPriceAtGivenTime(timestamp);
            }
            return totalSum / stocks.Count();
        }
    }

    public class IndexRepository : IRepository
    {
        public List<StockExchangeElement> indices = new List<StockExchangeElement>();
        public void add(StockExchangeElement index)
        {
            indices.Add(index);
        }

        public void addStockToIndex(string indexName, Stock stock)
        {
            indices.Cast<Index>().SingleOrDefault(item => item.indexName == indexName).stocks.Add(stock);
        }

        public void removeStockFromIndex(string indexName, Stock stock)
        {
            indices.Cast<Index>().SingleOrDefault(item => item.indexName == indexName).stocks.Remove(stock);
        }

        public bool isStockInIndex(string indexName, string stockName)
        {
            return indices.Cast<Index>().SingleOrDefault(item => item.indexName == indexName).stocks.Exists(item => item.stockName.Equals(stockName, StringComparison.OrdinalIgnoreCase));
        }

        public decimal getIndexValue(string indexName, DateTime timestamp)
        {
            return indices.Cast<Index>().SingleOrDefault(item => item.indexName == indexName).calculateIndexValue(timestamp);
        }

        public void remove(string name)
        {
            throw new NotImplementedException();
        }

        public bool elementExists(string name)
        {
            return indices.Cast<Index>().ToList().Exists(item => item.indexName.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public int getNumberOfIndices()
        {
            return indices.Count();
        }

        public int getNumberOfStocksInIndex(string name)
        {
            return indices.Cast<Index>().SingleOrDefault(item => item.indexName == name).stocks.Count();
        }

        public void removeStockFromAllIndices(Stock stock)
        {
            foreach (Index index in indices)
            {
                if (index.stocks.Exists(item => item.stockName.Equals(stock.stockName, StringComparison.OrdinalIgnoreCase)))
                {
                    index.stocks.Remove(stock);
                }
                else
                {
                    continue;
                }
            }
        }

        public bool indexTypeExists(IndexTypes type)
        {
            if (type != IndexTypes.AVERAGE && type != IndexTypes.WEIGHTED)
                return false;
            else
                return true;
        }
    }

    public class Portfolio : StockExchangeElement
    {
        public string portfolioID { get; set; }
        public List<KeyValuePair<Stock, int>> stocks { get; set; }

        public decimal calculatePortfolioValue(DateTime timestamp)
        {
            decimal portfolioValue = 0;
            foreach (KeyValuePair<Stock, int> stock in stocks)
            {
                portfolioValue += stock.Key.getStockPriceAtGivenTime(timestamp) * stock.Value;
            }

            return portfolioValue;
        }

        public Portfolio() { }

        public Portfolio(string id)
        {
            this.portfolioID = id;
            stocks = new List<KeyValuePair<Stock, int>>();
        }
    }

    public class PortfolioRepository : IRepository
    {
        List<StockExchangeElement> portfolios = new List<StockExchangeElement>();

        public void add(StockExchangeElement element)
        {
            portfolios.Add(element);
        }

        public void addStockToPortfolio(string portfolioID, Stock stock, int stockNumber)
        {
            if (portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Exists(item => item.Key == stock))
            {
                KeyValuePair<Stock, int> oldValue = portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.SingleOrDefault(item => item.Key == stock);
                KeyValuePair<Stock, int> newValue = new KeyValuePair<Stock, int>(oldValue.Key, oldValue.Value + stockNumber);
                portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Remove(oldValue);
                portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Add(newValue);
            }
            else
            {
                portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Add(new KeyValuePair<Stock, int>(stock, stockNumber));
            }
        }

        public void removeStockFromPortfolio(string portfolioID, Stock stock, int stockNumber)
        {
            KeyValuePair<Stock, int> oldValue = portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.SingleOrDefault(item => item.Key == stock);
            KeyValuePair<Stock, int> newValue = new KeyValuePair<Stock, int>(oldValue.Key, oldValue.Value - stockNumber);
            portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Remove(oldValue);
            if (newValue.Value == 0)
            {
                return;
            }
            else
            {
                portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Add(newValue);
            }
        }

        public void removeStockFromPortfolio(string portfolioID, Stock stock)
        {
            portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.RemoveAll(item => item.Key == stock);
        }

        public int getNumberOfPortfolios()
        {
            return portfolios.Count();
        }

        public int getNumberOfStocksInPortfolio(string portfolioID)
        {
            return portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Count();
        }

        public bool isStockInPortfolio(string portfolioID, Stock stock)
        {
            return portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.Exists(item => item.Key == stock);
        }

        public int getNumberOfStockSharesInPortfolio(string portfolioID, Stock stock)
        {
            return portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).stocks.SingleOrDefault(item => item.Key == stock).Value;
        }

        public decimal getPortfolioValue(string portfolioID, DateTime timestamp)
        {
            return portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID).calculatePortfolioValue(timestamp);
        }

        public decimal getMonthlyPercentChange(string portfolioID, int year, int month)
        {
            Portfolio portfolio = portfolios.Cast<Portfolio>().SingleOrDefault(item => item.portfolioID == portfolioID);
            if (portfolio.stocks.Count() == 0)
            {
                return 0;
            }
            else
            {
                decimal startValue = portfolio.calculatePortfolioValue(new DateTime(year, month, 1, 00, 00, 00, 000));
                decimal endValue = portfolio.calculatePortfolioValue(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
                return ((endValue - startValue) / startValue) * 100;
            }
        }

        public void remove(string elementName)
        {
            throw new NotImplementedException();
        }

        public bool elementExists(string elementName)
        {
            return portfolios.Cast<Portfolio>().ToList().Exists(item => item.portfolioID == elementName);
        }

        public void removeStockFromAllPortfolios(Stock stock)
        {
            foreach (Portfolio portfolio in portfolios)
            {
                if (portfolio.stocks.Exists(item => item.Key == stock))
                {
                    portfolio.stocks.RemoveAll(item => item.Key == stock);
                }
                else
                {
                    continue;
                }
            }
        }

        public bool isEnoughSharesAvailable(Stock stock, int numberOfShares)
        {
            int sharesTaken = 0;
            foreach (Portfolio portfolio in portfolios)
            {
                if (portfolio.stocks.Exists(item => item.Key == stock))
                {
                    sharesTaken += portfolio.stocks.Single(item => item.Key == stock).Value;
                }
                else
                {
                    continue;
                }
            }
            if (stock.numberOfStocks - sharesTaken >= numberOfShares)
                return true;
            else
                return false;
        }

        public bool isEnoughSharesInPortfolio(string portfolioID, Stock stock, int numberOfShares)
        {
            Portfolio portfolio = portfolios.Cast<Portfolio>().Single(item => item.portfolioID == portfolioID);
            if (portfolio.stocks.Single(item => item.Key == stock).Value < numberOfShares)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public enum ExceptionTypes
    {
        INVALID_PRICE,
        INVALID_NUMBER_OF_SHARES,
        STOCK_EXISTS,
        INDEX_EXISTS,
        PORTFOLIO_EXISTS,
        TIMESTAMP_EXISTS,
        STOCK_DOESNT_EXIST,
        INDEX_DOESNT_EXIST,
        PORTFOLIO_DOESNT_EXIST,
        INDEX_TYPE_DOESNT_EXIST,
        NO_STOCK_IN_INDEX,
        NO_STOCK_IN_PORTFOLIO,
        PRICE_NOT_DECLARED,
        STOCK_ALREADY_IN_INDEX,
        NOT_ENOUGH_SHARES_AVAILABLE
    }

    public class StockRepository : IRepository
    {
        List<StockExchangeElement> stocks = new List<StockExchangeElement>();

        public void add(StockExchangeElement stock)
        {
            stocks.Add(stock);
        }

        public void remove(string name)
        {
            Stock stock = stocks.Cast<Stock>().ToList().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase));
            stocks.Remove(stock);
        }

        public bool elementExists(string name)
        {
            return stocks.Cast<Stock>().SingleOrDefault(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase)) == null ? false : true;
        }

        public int getNumberOfStocks()
        {
            return stocks.Count();
        }

        public void setPrice(string name, DateTime timestamp, decimal value)
        {
            stocks.Cast<Stock>().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase)).stockPrices.Add(new KeyValuePair<DateTime, decimal>(timestamp, value));
        }

        public decimal getPrice(string name, DateTime timestamp)
        {
            Stock stock = stocks.Cast<Stock>().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase));
            return stock.getStockPriceAtGivenTime(timestamp);
        }

        public Stock getStock(string name)
        {
            return stocks.Cast<Stock>().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public bool timestampExists(string name, DateTime timestamp)
        {
            return stocks.Cast<Stock>().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase)).priceExistsAtExactTime(timestamp);
        }

        public bool priceExists(string name, DateTime timestamp)
        {
            return stocks.Cast<Stock>().Single(item => item.stockName.Equals(name, StringComparison.OrdinalIgnoreCase)).priceExistsForGivenTimestamp(timestamp);
        }
    }

    public class UnitOfWork
    {
        private IndexRepository _indexRepository;
        private StockRepository _stockRepository;
        private PortfolioRepository _portfolioRepository;

        public IndexRepository IndexRepository
        {
            get
            {
                if (this._indexRepository == null)
                {
                    _indexRepository = new IndexRepository();
                }
                return _indexRepository;
            }
        }

        public StockRepository StockRepository
        {
            get
            {
                if (this._stockRepository == null)
                {
                    _stockRepository = new StockRepository();
                }
                return _stockRepository;
            }
        }

        public PortfolioRepository PortfolioRepository
        {
            get
            {
                if (this._portfolioRepository == null)
                {
                    _portfolioRepository = new PortfolioRepository();
                }
                return _portfolioRepository;
            }
        }
    }

    public class StockExchange : IStockExchange
    {
        UnitOfWork unit = new UnitOfWork();

        public static readonly Dictionary<ExceptionTypes, string> ExceptionMessages = new Dictionary<ExceptionTypes, string>()
        {
            {ExceptionTypes.INVALID_PRICE, "Price can't be negative or zero!"},
            {ExceptionTypes.INVALID_NUMBER_OF_SHARES, "Number of shares can't be negative or zero!"},
            {ExceptionTypes.STOCK_EXISTS, "Stock with that name already exists in the system!"},
            {ExceptionTypes.INDEX_EXISTS, "Index with that name already exists in the system!"},
            {ExceptionTypes.PORTFOLIO_EXISTS, "Portfolio with that name already exists in the system!"},
            {ExceptionTypes.TIMESTAMP_EXISTS, "There is already a price declared for this timestamp!"},
            {ExceptionTypes.STOCK_DOESNT_EXIST, "Stock with that name doesn't exist in the system!"},
            {ExceptionTypes.INDEX_DOESNT_EXIST, "Index with that name doesn't exist in the system!"},
            {ExceptionTypes.PORTFOLIO_DOESNT_EXIST, "Portfolio with that name doesn't exist in the system!"},
            {ExceptionTypes.INDEX_TYPE_DOESNT_EXIST, "You entered an index type that isn't declared in the system!"},
            {ExceptionTypes.NO_STOCK_IN_INDEX, "Stock with that name doesn't exist in index!"},
            {ExceptionTypes.NO_STOCK_IN_PORTFOLIO, "Stock with that name doesn't exist in portfolio!"},
            {ExceptionTypes.PRICE_NOT_DECLARED, "Price is not declared for that timestamp!"},
            {ExceptionTypes.STOCK_ALREADY_IN_INDEX, "Stock is already in this index!"},
            {ExceptionTypes.NOT_ENOUGH_SHARES_AVAILABLE, "Not enough shares available to add!"}
        };

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (unit.StockRepository.elementExists(inStockName))
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_EXISTS]);
            }
            if (inNumberOfShares <= 0)
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INVALID_NUMBER_OF_SHARES]);
            }
            if (inInitialPrice <= 0)
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INVALID_PRICE]);
            }
            else
            {
                Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                unit.StockRepository.add(stock);
            }
        }

        public void DelistStock(string inStockName)
        {
            if (!unit.StockRepository.elementExists(inStockName))
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
            }
            else
            {
                Stock stock = unit.StockRepository.getStock(inStockName);
                unit.StockRepository.remove(inStockName);
                unit.IndexRepository.removeStockFromAllIndices(stock);
                unit.PortfolioRepository.removeStockFromAllPortfolios(stock);
            }
        }

        public bool StockExists(string inStockName)
        {
            return unit.StockRepository.elementExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return unit.StockRepository.getNumberOfStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (unit.StockRepository.elementExists(inStockName))
            {
                if (unit.StockRepository.timestampExists(inStockName, inIimeStamp))
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.TIMESTAMP_EXISTS]);
                }
                if (inStockValue <= 0)
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INVALID_PRICE]);
                }
                else
                {
                    unit.StockRepository.setPrice(inStockName, inIimeStamp, inStockValue);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (unit.StockRepository.elementExists(inStockName))
            {
                if (unit.StockRepository.priceExists(inStockName, inTimeStamp))
                {
                    return unit.StockRepository.getPrice(inStockName, inTimeStamp);
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PRICE_NOT_DECLARED]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
            }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (unit.StockRepository.elementExists(inStockName))
            {
                Stock stock = unit.StockRepository.getStock(inStockName);
                return stock.getFirstPrice();
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
            }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (unit.StockRepository.elementExists(inStockName))
            {
                Stock stock = unit.StockRepository.getStock(inStockName);
                return stock.getLastPrice();
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
            }
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            IndexFactory factory = null;
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_EXISTS]);
            }
            else
            {
                if (unit.IndexRepository.indexTypeExists(inIndexType))
                {
                    if (inIndexType == IndexTypes.AVERAGE)
                    {
                        factory = new AverageIndexFactory();
                    }
                    if (inIndexType == IndexTypes.WEIGHTED)
                    {
                        factory = new WeightedIndexFactory();
                    }

                    Index index = factory.createIndex();
                    index.indexName = inIndexName;
                    index.type = inIndexType;
                    unit.IndexRepository.add(index);
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_TYPE_DOESNT_EXIST]);
                }
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (unit.IndexRepository.isStockInIndex(inIndexName, inStockName))
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_ALREADY_IN_INDEX]);
                    }
                    else
                    {
                        Stock stock = unit.StockRepository.getStock(inStockName);
                        unit.IndexRepository.addStockToIndex(inIndexName, stock);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_DOESNT_EXIST]);
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (unit.IndexRepository.isStockInIndex(inIndexName, inStockName))
                    {
                        Stock stock = unit.StockRepository.getStock(inStockName);
                        unit.IndexRepository.removeStockFromIndex(inIndexName, stock);
                    }
                    else
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NO_STOCK_IN_INDEX]);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_DOESNT_EXIST]);
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    return unit.IndexRepository.isStockInIndex(inIndexName, inStockName);
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_DOESNT_EXIST]);
            }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                return Math.Round(unit.IndexRepository.getIndexValue(inIndexName, inTimeStamp), 3);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_DOESNT_EXIST]);
            }
        }

        public bool IndexExists(string inIndexName)
        {
            return unit.IndexRepository.elementExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return unit.IndexRepository.getNumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (unit.IndexRepository.elementExists(inIndexName))
            {
                return unit.IndexRepository.getNumberOfStocksInIndex(inIndexName);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INDEX_DOESNT_EXIST]);
            }
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                unit.PortfolioRepository.add(portfolio);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_EXISTS]);
            }
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (numberOfShares > 0)
                    {
                        if (unit.PortfolioRepository.isEnoughSharesAvailable(unit.StockRepository.getStock(inStockName), numberOfShares))
                        {
                            Stock stock = unit.StockRepository.getStock(inStockName);
                            unit.PortfolioRepository.addStockToPortfolio(inPortfolioID, stock, numberOfShares);
                        }
                        else
                        {
                            throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NOT_ENOUGH_SHARES_AVAILABLE]);
                        }
                    }
                    else
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INVALID_NUMBER_OF_SHARES]);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (numberOfShares > 0)
                    {
                        if (unit.PortfolioRepository.isStockInPortfolio(inPortfolioID, unit.StockRepository.getStock(inStockName)))
                        {
                            if (unit.PortfolioRepository.isEnoughSharesInPortfolio(inPortfolioID, unit.StockRepository.getStock(inStockName), numberOfShares))
                            {
                                Stock stock = unit.StockRepository.getStock(inStockName);
                                unit.PortfolioRepository.removeStockFromPortfolio(inPortfolioID, stock, numberOfShares);
                            }
                            else
                            {
                                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NOT_ENOUGH_SHARES_AVAILABLE]);
                            }
                        }
                        else
                        {
                            throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NO_STOCK_IN_PORTFOLIO]);
                        }
                    }
                    else
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.INVALID_NUMBER_OF_SHARES]);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (unit.PortfolioRepository.isStockInPortfolio(inPortfolioID, unit.StockRepository.getStock(inStockName)))
                    {
                        Stock stock = unit.StockRepository.getStock(inStockName);
                        unit.PortfolioRepository.removeStockFromPortfolio(inPortfolioID, stock);
                    }
                    else
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NO_STOCK_IN_PORTFOLIO]);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public int NumberOfPortfolios()
        {
            return unit.PortfolioRepository.getNumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                return unit.PortfolioRepository.getNumberOfStocksInPortfolio(inPortfolioID);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return unit.PortfolioRepository.elementExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    Stock stock = unit.StockRepository.getStock(inStockName);
                    return unit.PortfolioRepository.isStockInPortfolio(inPortfolioID, stock);
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                if (unit.StockRepository.elementExists(inStockName))
                {
                    if (unit.PortfolioRepository.isStockInPortfolio(inPortfolioID, unit.StockRepository.getStock(inStockName)))
                    {
                        Stock stock = unit.StockRepository.getStock(inStockName);
                        return unit.PortfolioRepository.getNumberOfStockSharesInPortfolio(inPortfolioID, stock);
                    }
                    else
                    {
                        throw new StockExchangeException(ExceptionMessages[ExceptionTypes.NO_STOCK_IN_PORTFOLIO]);
                    }
                }
                else
                {
                    throw new StockExchangeException(ExceptionMessages[ExceptionTypes.STOCK_DOESNT_EXIST]);
                }
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                return Math.Round(unit.PortfolioRepository.getPortfolioValue(inPortfolioID, timeStamp), 3);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (unit.PortfolioRepository.elementExists(inPortfolioID))
            {
                return Math.Round(unit.PortfolioRepository.getMonthlyPercentChange(inPortfolioID, Year, Month), 3);
            }
            else
            {
                throw new StockExchangeException(ExceptionMessages[ExceptionTypes.PORTFOLIO_DOESNT_EXIST]);
            }
        }
    }
}
