﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public class Share {
        public String name; //Case insensitive

        public long number;

        public SortedList<DateTime, Decimal> priceHistory;

        public Share(String shareName, long numberOfShares, decimal sharePrice, DateTime time) {
            if (sharePrice <= 0) throw new StockExchangeException("Invalid price.");

            if (numberOfShares <= 0) throw new StockExchangeException("Invalid number of shares.");

            if (shareName.Equals("")) throw new StockExchangeException("Invalid stock name.");

            this.name = shareName;
            this.number = numberOfShares;

            this.priceHistory = new SortedList<DateTime, Decimal>();
            this.priceHistory.Add(time, sharePrice);
        }
    }

    public class Index {
        public String name; //Case insensitive

        public IndexTypes type;

        public List<Share> shares;

        public Index(String indexName, IndexTypes indexType) {
            if (indexName.Equals("")) throw new StockExchangeException("Invalid index name.");

            if (indexType != IndexTypes.AVERAGE && indexType != IndexTypes.WEIGHTED) throw new StockExchangeException("Invalid index type.");

            this.name = indexName;
            this.type = indexType;
            this.shares = new List<Share>();
        }
    }

    public class PortfolioEntry { 
        public Share share;

        public SortedList<DateTime, long> amountHistory;

        public PortfolioEntry(Share portfolioShare, long shareAmount) {
            if ( !(portfolioShare is Share) ) throw new StockExchangeException("Invalid share.");

            if (shareAmount <= 0) throw new StockExchangeException("Invalid share amount.");

            this.share = portfolioShare;
            this.amountHistory = new SortedList<DateTime, long>();
            amountHistory.Add(DateTime.Now, shareAmount);
        }
    }

    public class Portfolio {
        public String ID; //Case sensitive

        public SortedList<DateTime, PortfolioEntry> entries;

        public Portfolio(String name) {
            if (name.Equals("")) throw new StockExchangeException("Invalid protfolio name.");

            this.ID = name;
            this.entries = new SortedList<DateTime, PortfolioEntry>();
        }
    }

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        public List<Index> indexes;
        
        public List<Share> shares;
        
        public List<Portfolio> portfolios;

         public StockExchange() {
             this.indexes = new List<Index>();
             this.shares = new List<Share>();
             this.portfolios = new List<Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             foreach(Share s in this.shares){
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Share with such name already exists.");
             }

             Share newShare = new Share(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

             this.shares.Add(newShare);
         }

         public void DelistStock(string inStockName)
         {
             Share shareToDelete = null;

             foreach(Share s in this.shares){
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToDelete = s;
             }

             //Ukloni iz svakog indeksa i portfolija
             foreach(Index i in this.indexes){
                 this.RemoveStockFromIndex(i.name, shareToDelete.name);
             }

             foreach(Portfolio p in this.portfolios){
                this.RemoveStockFromPortfolio(p.ID, shareToDelete.name);
             }

             //Brisi iz popisa dionica
             this.shares.Remove(shareToDelete);
         }

         public bool StockExists(string inStockName)
         {
             foreach (Share s in this.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return true;
             }

             return false;
         }

         public int NumberOfStocks()
         {
             return this.shares.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             Share shareToSet = null;

             foreach (Share s in this.shares) {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToSet = s;
             }

             if (shareToSet == null) throw new StockExchangeException("No such share.");

             shareToSet.priceHistory.Add(inTimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Share shareToGet = null;

             foreach (Share s in this.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToGet = s;
             }

             if (shareToGet == null) throw new StockExchangeException("No such share.");

             //Naci cijenu za dionicu shareToGet i zadano vrijeme
             if(shareToGet.priceHistory.First().Key > inTimeStamp) throw new StockExchangeException("Price is not available for selected time.");

             decimal price = 0.0m;

             foreach (KeyValuePair<DateTime, Decimal> pair in shareToGet.priceHistory)
             {
                 if (pair.Key <= inTimeStamp) price = pair.Value;
                 else break;
             }

             return price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Share shareToGet = null;

             foreach (Share s in this.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToGet = s;
             }

             if (shareToGet == null) throw new StockExchangeException("No such share.");

             return shareToGet.priceHistory.First().Value;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Share shareToGet = null;

             foreach (Share s in this.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToGet = s;
             }

             if (shareToGet == null) throw new StockExchangeException("No such share.");

             return shareToGet.priceHistory.Last().Value;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             foreach(Index i in this.indexes){
                if(i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Index with such name already exists.");
             }

             this.indexes.Add(new Index(inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             //Get reference to share
             Share shareToAdd = null;
             foreach (Share s in this.shares) {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToAdd = s;
             }
             if (shareToAdd == null) throw new StockExchangeException("No such share.");

             //Get reference to index
             Index indexToAddTo = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) indexToAddTo = i;
             }
             if (indexToAddTo == null) throw new StockExchangeException("No such index.");

             //Check if share exists in index' list
             if (indexToAddTo.shares.Contains(shareToAdd)) throw new StockExchangeException("Share already exists in index' list.");

             indexToAddTo.shares.Add(shareToAdd);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             //Get reference to index
             Index indexToRemoveFrom = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) indexToRemoveFrom = i;
             }
             if (indexToRemoveFrom == null) throw new StockExchangeException("No such index.");

             foreach (Share s in indexToRemoveFrom.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) indexToRemoveFrom.shares.Remove(s);
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             //Get reference to index
             Index indexToCheck = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) indexToCheck = i;
             }
             if (indexToCheck == null) throw new StockExchangeException("No such index.");

             foreach (Share s in indexToCheck.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return true;
             }

             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             //Get reference to index
             Index indexToCheck = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) indexToCheck = i;
             }
             if (indexToCheck == null) throw new StockExchangeException("No such index.");

             //Napravi popis dionica u indeksu u danom trenutku
             List<Share> sharesAtTheTime = new List<Share>();

             foreach (Share s in indexToCheck.shares)
             {
                 if (s.priceHistory.First().Key <= inTimeStamp) sharesAtTheTime.Add(s);
             }

             //Racunanje vrijednosti indeksa
             if (indexToCheck.type == IndexTypes.AVERAGE){

                 decimal pricesSum = 0.0m;
                 int numberOfShares = sharesAtTheTime.Count;

                 foreach (Share s in sharesAtTheTime)
                 {
                     pricesSum += this.GetStockPrice(s.name, inTimeStamp);                  
                 }

                 return pricesSum / numberOfShares;

             } else {

                 //Calculate total value of all shares within an index at given time
                 decimal totalValueOfAllShares = 0.0m;
                 foreach (Share s in sharesAtTheTime) {
                     totalValueOfAllShares += s.number * this.GetStockPrice(s.name, inTimeStamp);
                 }

                 //Calculate sum of all weights
                 decimal weightedIndex = 0.0m;
                 foreach (Share s in sharesAtTheTime)
                 {
                     weightedIndex += this.GetStockPrice(s.name, inTimeStamp) * s.number * this.GetStockPrice(s.name, inTimeStamp)/totalValueOfAllShares;
                 }

                 return weightedIndex;
             }             
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) return true;
             }

             return false;
         }

         public int NumberOfIndices()
         {
             return indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             //Get reference to index
             Index indexToCheck = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)) indexToCheck = i;
             }
             if (indexToCheck == null) throw new StockExchangeException("No such index.");

             return indexToCheck.shares.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) throw new StockExchangeException("Portfolio with such name already exists.");
             }

             Portfolio newPortfolio = new Portfolio(inPortfolioID);

             this.portfolios.Add(newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //Get reference to portfolio
             Portfolio portfolioToAddTo = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToAddTo = p;
             }
             if (portfolioToAddTo == null) throw new StockExchangeException("No such portfolio.");

             //Get reference to share
             Share shareToAdd = null;
             foreach (Share s in this.shares)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) shareToAdd = s;
             }
             if (shareToAdd == null) throw new StockExchangeException("No such share.");

             if (numberOfShares <= 0 || shareToAdd.number < numberOfShares) throw new StockExchangeException("Wrong number of shares.");

             PortfolioEntry e = new PortfolioEntry(shareToAdd, numberOfShares);

             portfolioToAddTo.entries.Add(DateTime.Now, e);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //Get reference to portfolio
             Portfolio portfolioToRemoveFrom = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToRemoveFrom = p;
             }
             if (portfolioToRemoveFrom == null) throw new StockExchangeException("No such portfolio.");

             //Get reference to portfolio entry
             PortfolioEntry entryToRemoveFrom = null;
             foreach (KeyValuePair<DateTime, PortfolioEntry> pair in portfolioToRemoveFrom.entries)
             {
                 if (pair.Value.share.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) entryToRemoveFrom = pair.Value;
             }
             if (entryToRemoveFrom == null) throw new StockExchangeException("No such share.");

             //Get current amount
             int newAmount = (int) entryToRemoveFrom.amountHistory.Last().Value - numberOfShares;

             if (newAmount > 0) {
                 entryToRemoveFrom.amountHistory.Add(DateTime.Now, newAmount);
             }
             else if (newAmount == 0)
             {
                 this.RemoveStockFromPortfolio(inPortfolioID, inStockName);
             }
             else {
                 throw new StockExchangeException("Amount of shares is too low.");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             //Get reference to portfolio
             Portfolio portfolioToRemoveFrom = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToRemoveFrom = p;
             }
             if (portfolioToRemoveFrom == null) throw new StockExchangeException("No such portfolio.");

             //Get key for a share
             DateTime d = DateTime.MinValue;
             foreach (KeyValuePair<DateTime, PortfolioEntry> pair in portfolioToRemoveFrom.entries)
             {
                 if (pair.Value.share.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) d = pair.Key;
             }
             if (d.Equals(DateTime.MinValue)) throw new StockExchangeException("No such share.");

             portfolioToRemoveFrom.entries.Remove(d);
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             //Get reference to portfolio
             Portfolio portfolioToCheck = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToCheck = p;
             }
             if (portfolioToCheck == null) throw new StockExchangeException("No such portfolio.");

             return portfolioToCheck.entries.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             //Get reference to portfolio
             Portfolio portfolioToCheck = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToCheck = p;
             }
             if (portfolioToCheck == null) throw new StockExchangeException("No such portfolio.");

             //Get reference to portfolio entry
             foreach (KeyValuePair<DateTime, PortfolioEntry> pair in portfolioToCheck.entries)
             {
                 if (pair.Value.share.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return true;
             }

             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             //Get reference to portfolio
             Portfolio portfolioToCheck = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToCheck = p;
             }
             if (portfolioToCheck == null) throw new StockExchangeException("No such portfolio.");

             //Get reference to portfolio entry
             foreach (KeyValuePair<DateTime, PortfolioEntry> pair in portfolioToCheck.entries)
             {
                 if (pair.Value.share.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return (int) pair.Value.amountHistory.Last().Value;
             }
             return 0;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             //Get reference to portfolio
             Portfolio portfolioToCheck = null;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolioID)) portfolioToCheck = p;
             }
             if (portfolioToCheck == null) throw new StockExchangeException("No such portfolio.");

             //Iterate through it entries
             decimal value = 0.0m;
             foreach(KeyValuePair<DateTime, PortfolioEntry> pair in portfolioToCheck.entries){
                int am = -1;

                foreach(KeyValuePair<DateTime, long> a in pair.Value.amountHistory){
                    if(a.Key <= timeStamp) am = (int) a.Value;
                    else break;
                }

                value += this.GetStockPrice(pair.Value.share.name, timeStamp) * am;
             }
             
             return value;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             decimal percentage;

             DateTime t1 = new DateTime(Year, Month, 1);
             DateTime t2 = new DateTime(Year, Month+1, 1);

             percentage = (this.GetPortfolioValue(inPortfolioID, t2) / this.GetPortfolioValue(inPortfolioID, t1)) - 1;

             return percentage;
         }
     }
}