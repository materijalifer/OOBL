﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private int canAddDigitsToRight;
        private string onScreenNumber;
        private double lastCalculatedNumber;
        private string lastOperator;
        private double numberInMemory;
        private char lastPressedButton;


        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            this.onScreenNumber = "0";
            this.lastCalculatedNumber = 0;
            this.numberInMemory = 0;
            canAddDigitsToRight = 1;
        }

        public void Press(char inPressedDigit)
        {
            if (onScreenNumber == "-E-") return; //if an error is already calculated, just skip the pressed button.

            switch (inPressedDigit)
            {
                case ',': //skip if there already is an ',', else place it there
                    if (canAddDigitsToRight == 1 && onScreenNumber.Contains(',') == false) onScreenNumber = onScreenNumber + ",";
                    break;
                case 'O': //reset
                    Reset();
                    break;
                case 'C': //clear
                    Clear();
                    break;
                case 'P': //place in memory
                    onScreenNumber = MakeValid(onScreenNumber);
                    PlaceInMemory(Double.Parse(this.onScreenNumber));
                    break;
                case 'G': //get from memory
                    this.onScreenNumber = GetFromMemory().ToString();
                    canAddDigitsToRight = 1;
                    break;
                case 'M': // change the foretoken
                    onScreenNumber = Minus(onScreenNumber);
                    break;
                case 'S': //calculate the sinus
                    onScreenNumber = Sinus(Double.Parse(onScreenNumber)).ToString();
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
                case 'K': //calculate the cosinus
                    onScreenNumber = Cosinus(Double.Parse(onScreenNumber)).ToString();
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
                case 'T': //calculate the tangens
                    onScreenNumber = Tangens(Double.Parse(onScreenNumber)).ToString();
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
                case 'Q': //calculate the square
                    onScreenNumber = Square(Double.Parse(onScreenNumber)).ToString();
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
                case 'R': //calculate the root if possible
                    try
                    {
                        onScreenNumber = Root(Double.Parse(onScreenNumber)).ToString();
                    }
                    catch (ArgumentException e)
                    {
                        onScreenNumber = "-E-";
                        return;
                    }
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
                case 'I': //calculate the inverse if possible
                    try
                    {
                        onScreenNumber = Inverse(Double.Parse(onScreenNumber)).ToString();
                    }
                    catch (ArgumentException e)
                    {
                        onScreenNumber = "-E-";
                        return;
                    }
                    onScreenNumber = MakeValid(onScreenNumber);
                    canAddDigitsToRight = 0;
                    break;
            }
            if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            { //if u got + - * /
                canAddDigitsToRight = 0;

                if (lastPressedButton == '+' || lastPressedButton == '-' || lastPressedButton == '*' || lastPressedButton == '/')
                { //check if the operator is to be overwritten
                    lastOperator = inPressedDigit.ToString();
                    lastPressedButton = inPressedDigit;
                    return;
                }

                if (lastOperator == null)
                { //if this is the first time the operator is being typed
                    lastCalculatedNumber = Double.Parse(onScreenNumber);
                    onScreenNumber = MakeValid(onScreenNumber);
                    lastOperator = inPressedDigit.ToString();
                }
                else
                { //else calculate
                    double result = 0;
                    if (lastOperator == "+")
                    {
                        double first = this.lastCalculatedNumber;
                        double second = Double.Parse(onScreenNumber);
                        result = first + second;
                    }
                    if (lastOperator == "-")
                    {
                        double first = this.lastCalculatedNumber;
                        double second = Double.Parse(onScreenNumber);
                        result = first - second;
                    }
                    if (lastOperator == "*")
                    {
                        double first = this.lastCalculatedNumber;
                        double second = Double.Parse(onScreenNumber);
                        result = first * second;
                    }
                    if (lastOperator == "/")
                    {
                        double first = this.lastCalculatedNumber;
                        double second = Double.Parse(onScreenNumber);
                        result = first / second;

                    }
                    onScreenNumber = result.ToString();
                    onScreenNumber = MakeValid(onScreenNumber);
                    lastCalculatedNumber = result;
                    lastOperator = inPressedDigit.ToString();
                }
            }
            if (Char.IsDigit(inPressedDigit))
            { //if there is zero on the screen
                if (this.onScreenNumber == "0")
                { //if possible, add it to the right
                    this.onScreenNumber = Char.ToString(inPressedDigit);
                    lastPressedButton = inPressedDigit;
                    return;
                }
                if (canAddDigitsToRight == 1)
                { //else add if possible
                    if (onScreenNumber.Contains(','))
                    {
                        if (onScreenNumber.StartsWith("-") && onScreenNumber.Length == 12) return;
                        else if (onScreenNumber.Length == 11) return;
                        else onScreenNumber = onScreenNumber + Char.ToString(inPressedDigit);
                    }
                    else
                    {
                        if (onScreenNumber.StartsWith("-") && onScreenNumber.Length == 11) return;
                        else if (onScreenNumber.Length == 10) return;
                        else onScreenNumber = onScreenNumber + Char.ToString(inPressedDigit);
                    }
                }
                if (canAddDigitsToRight == 0)
                { //if can't add a digit to the right overwrite
                    onScreenNumber = inPressedDigit.ToString();
                    canAddDigitsToRight = 1;
                }
            }
            if (inPressedDigit == '=')
            { //calculate the result
                double result = 0;
                if (lastOperator == null)
                {
                    lastPressedButton = inPressedDigit;
                    onScreenNumber = MakeValid(onScreenNumber);
                    return;
                }
                if (lastOperator == "+")
                {
                    double first = this.lastCalculatedNumber;
                    double second = Double.Parse(onScreenNumber);
                    result = first + second;
                }
                if (lastOperator == "-")
                {
                    double first = this.lastCalculatedNumber;
                    double second = Double.Parse(onScreenNumber);
                    result = first - second;
                }
                if (lastOperator == "*")
                {
                    double first = this.lastCalculatedNumber;
                    double second = Double.Parse(onScreenNumber);
                    result = first * second;
                }
                if (lastOperator == "/")
                {
                    double first = this.lastCalculatedNumber;
                    double second = Double.Parse(onScreenNumber);
                    result = first / second;

                }
                onScreenNumber = result.ToString();
                onScreenNumber = MakeValid(onScreenNumber);
                lastCalculatedNumber = result;
                lastOperator = null;
            }
            lastPressedButton = inPressedDigit; //remember the last pressed button
        }

        public string GetCurrentDisplayState()
        {
            return this.onScreenNumber;
        }

        private string Minus(string number)
        {
            if (number.StartsWith("-")) return number.Substring(1);
            else return "-" + number;
        }

        private double Sinus(double number)
        {
            return Math.Round(Math.Sin(number), 9);
        }

        private double Cosinus(double number)
        {
            return Math.Cos(number);
        }

        private double Tangens(double number)
        {
            return Math.Tan(number);
        }

        private double Square(double number)
        {
            return Math.Pow(number, 2);
        }

        /// <summary>
        /// Method that calculates the root of the number.
        /// If the specified number is negative, throw ArgumentException.
        /// </summary>
        /// <param name="number"></param> Number whose root is to be calculated.
        /// <returns></returns> The root of the number.
        private double Root(double number)
        {
            if (number >= 0) return Math.Sqrt(number);
            else throw new System.ArgumentException("Parameter has to be a positive number");
        }

        /// <summary>
        /// Method that calculates the inverse of the number.
        /// If the specified number is zero, throw ArgumentException.
        /// </summary>
        /// <param name="number"></param> Number whose inverse is to be calculated.
        /// <returns></returns> The inverse of the number.
        private double Inverse(double number)
        {
            if (number != 0) return 1 / number;
            else throw new System.ArgumentException("Parameter can't be zero");
        }

        private void PlaceInMemory(double number)
        {
            this.numberInMemory = number;
        }

        private double GetFromMemory()
        {
            return this.numberInMemory;
        }

        /// <summary>
        /// Method that clears the screen, puts zero on it.
        /// </summary>
        private void Clear()
        {
            this.onScreenNumber = "0";
        }

        /// <summary>
        /// Method that resets the whole calculator.
        /// </summary>
        private void Reset()
        {
            this.onScreenNumber = "0";
            this.lastCalculatedNumber = 0;
            this.numberInMemory = 0;
            this.lastOperator = null;
            this.canAddDigitsToRight = 1;
        }

        /// <summary>
        /// Method that makes a number ready for printing if possible.
        /// If not, return '-E-' as Error.
        /// </summary>
        /// <param name="number"></param> Number that has to be checked if it is correct to display.
        /// <returns></returns> Rounded and validated number.
        private string MakeValid(string number)
        {
            if (number.Contains('E')) return "-E-";

            if (number.Contains(',') == false)
            {
                if (number.StartsWith("-") && number.Length >= 12) return "-E-";
                else if (number.Length >= 11) return "-E-";
            }
            else
            {
                int index;
                if (number.StartsWith("-")) index = number.IndexOf(',') - 1;
                else index = number.IndexOf(',');

                if (index >= 10) return "-E-";
                double numberAsDigits = Double.Parse(number);
                numberAsDigits = Math.Round(numberAsDigits, 10 - index);
                number = numberAsDigits.ToString();
                while (number.EndsWith("0"))
                {
                    number = number.Remove(number.Length - 1);
                }
                if (number.EndsWith(",")) number.Remove(number.Length - 1);
            }
            return number;
        }
    }
}