﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
   

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string rezultat = "0";
        private string operand = "0";
        private string ekran = "0";
        private int brojZnamenkiOperanda = 0;
        private int stanje = 0;
        private string memorija = "";
        private string binarniOperator = "";
        private bool unesenBinarni = false;

        public void Press(char inPressedDigit)
        {
            if (stanje == 0)  //stanje kada nema binarnog operatora i nije unesena niti jedna znamenka operanda
            {
                if (Char.IsDigit(inPressedDigit))     //unosenje znamenki i ispisivanje operanda
                {
                    if (inPressedDigit != '0')          //rjesava pritisak vise nula na pocetku operanda
                    {
                        operand = "" + inPressedDigit;
                        ekran = operand;
                        stanje = 1;
                        brojZnamenkiOperanda++;
                        rezultat = "0";                 //ako se prije provodila unarna neka
                    }
                }
                else
                    switch (inPressedDigit)
                    {
                        case '+':
                            binarniOperator = "+";  //za kasniju operaciju
                            rezultat = ekran;       //sto je na ekranu postaje prvi operand od dva
                            ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                            operand = "";           // drugi operand = ""
                            stanje = 2;             //stanje kada je unesen binarni operator
                            break;                  //brojznam je vec nula po def stanja
                        case '-':
                            binarniOperator = "-";
                            rezultat = ekran;
                            ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                            operand = "";
                            stanje = 2;             
                            break;
                        case '*':
                            binarniOperator = "*";
                            rezultat = ekran;
                            ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                            operand = "";
                            stanje = 2;             
                            break;
                        case '/':
                            binarniOperator = "/";
                            rezultat = ekran;
                            ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                            operand = "";
                            stanje = 2;             
                            break;
                        case ',':
                            operand = operand + inPressedDigit; 
                            ekran = operand;
                            stanje = 1;        //stanje kada unosimo operand a nema bin operatora unesenog
                            brojZnamenkiOperanda++;
                            rezultat = "0";
                            break;
                        case 'M':
                            ekran = Convert.ToString(Convert.ToDouble(ekran) * (-1));
                            rezultat = ekran;
                            break;
                        case 'K':
                            rezultat = Convert.ToString(Math.Cos(Convert.ToDouble(ekran)));
                            rezultat = zaokruziZnamenke(rezultat);
                            ekran = rezultat;  
                            break;
                        case 'I':
                            ekran = "-E-";
                            //neznam za rez i oper
                            stanje = 7; //stanje za error
                            break;
                        case 'P':
                            memorija = operand;
                            break;
                        case 'G':               
                            if (memorija != "")             //provjeriti kako to radi pravi calc
                            {
                                operand = memorija;
                                ekran = operand;
                                stanje = 1;
                                rezultat = "0";
                            }
                            break;
                        case 'C':
                            ekran = "0";
                            rezultat = "0";
                            break;
                        case 'O':
                            memorija = "";
                            rezultat = "0";
                            operand = "0";
                            ekran = "0";
                            break; 
                        default:
                            break;
                    }
            }  //kraj stanja 0




            else if (stanje == 1)  //unosenje operanda  a nema binarnog operatora
            {
                if (Char.IsDigit(inPressedDigit))     //unosenje znamenki i ispisivanje operanda
                {
                    if (brojZnamenkiOperanda < 10)          //rjesava problem broja znamenki
                    {
                        operand = operand + inPressedDigit;
                        ekran = operand;
                        brojZnamenkiOperanda++;
                    }
                }
                else
                    switch (inPressedDigit)
                    {
                        case '+':
                            binarniOperator = "+";
                            rezultat = Convert.ToString(Convert.ToDouble(operand) * 1);
                            ekran = rezultat;
                            brojZnamenkiOperanda = 0;
                            operand = "";
                            stanje = 2;            //unesen binarni operator
                            break;
                        case '-':
                            binarniOperator = "-";
                            rezultat = Convert.ToString(Convert.ToDouble(operand) * 1);
                            ekran = rezultat;
                            operand = "";
                            brojZnamenkiOperanda = 0;
                            stanje = 2;
                            break;
                        case '*':
                            binarniOperator = "*";
                            rezultat = Convert.ToString(Convert.ToDouble(operand) * 1);
                            ekran = rezultat;
                            operand = "";
                            brojZnamenkiOperanda = 0;
                            stanje = 2;
                            break;
                        case '/':
                            binarniOperator = "/";
                            rezultat = Convert.ToString(Convert.ToDouble(operand) * 1);
                            ekran = rezultat;
                            operand = "";
                            brojZnamenkiOperanda = 0;
                            stanje = 2;
                            break;
                        case 'S':
                            rezultat = Convert.ToString(Math.Sin(Convert.ToDouble(operand)));
                            rezultat = zaokruziZnamenke(rezultat);
                            ekran = rezultat;
                            operand = "0";                            
                            stanje = 0;
                            brojZnamenkiOperanda = 0;
                            break;
                        case 'K':
                            rezultat = Convert.ToString(Math.Cos(Convert.ToDouble(operand)));
                            rezultat = zaokruziZnamenke(rezultat);
                            ekran = rezultat;
                            operand = "0";                            
                            stanje = 0;
                            brojZnamenkiOperanda = 0;
                            break;
                        case 'T':
                            rezultat = Convert.ToString(Math.Tan(Convert.ToDouble(operand)));
                            if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                            {
                                ekran = "-E-";
                                //neznam za rez i oper
                                stanje = 7; //stanje za error
                            }
                            else
                            {
                                rezultat = zaokruziZnamenke(rezultat);
                                ekran = rezultat;
                                operand = "0";
                                stanje = 0;
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case 'Q':
                            if (Convert.ToDouble(operand) < 0)
                            {
                                ekran = "-E-";
                                stanje = 7;
                                break;
                            }
                            rezultat = Convert.ToString(Math.Pow(Convert.ToDouble(operand), 2));
                            if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                            {
                                ekran = "-E-";
                                //neznam za rez i oper
                                stanje = 7; //stanje za error
                            }
                            else
                            {
                                rezultat = zaokruziZnamenke(rezultat);
                                ekran = rezultat;
                                operand = "0";
                                stanje = 0;
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case 'R':
                            rezultat = Convert.ToString(Math.Sqrt(Convert.ToDouble(operand)));
                            rezultat = zaokruziZnamenke(rezultat);
                            ekran = rezultat;
                            operand = "0";                            
                            stanje = 0;
                            brojZnamenkiOperanda = 0;
                            break;
                        case ',':
                            operand = operand + inPressedDigit;
                            ekran = operand;
                            //vise zareza zaredom
                            break;
                        case 'M':
                            if (operand != "")
                                operand = Convert.ToString(Convert.ToDouble(operand) * (-1));
                            ekran = operand;
                            break;
                        case 'P':
                            memorija = operand;
                            break;
                        case 'G':
                            if (memorija != "")
                            {
                                operand = memorija;
                                ekran = operand;
                            }
                            break;
                        case 'C':
                            operand = "0";
                            brojZnamenkiOperanda = 0;
                            stanje = 0;
                            ekran = operand;
                            break;
                        case 'O':
                            memorija = "";
                            rezultat = "0";
                            operand = "0";
                            ekran = "0";
                            stanje = 0;
                            break;
                        case 'I':
                            if (Convert.ToDouble(operand) == 0)
                            {
                                ekran = "-E-";
                                stanje = 7;
                                //isto nezz za ostale registre
                            }
                            else
                            {
                                rezultat = Convert.ToString(1 / Convert.ToDouble(operand));
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                else
                                {
                                    rezultat = zaokruziZnamenke(rezultat);
                                    ekran = rezultat;
                                    operand = "0";
                                    stanje = 0;
                                    brojZnamenkiOperanda = 0;
                                }
                            }
                            break;
                        case '=':
                            rezultat = Convert.ToString(Convert.ToDouble(operand) * 1); //mozda ne pali to skidanje dec zareza
                            ekran = rezultat;
                            rezultat = "0";
                            brojZnamenkiOperanda = 0;
                            operand = "";
                            stanje = 0;                     //nakon =
                            break;
                        default:
                            Console.WriteLine("Default case");
                            break;
                    }
            }



            else if (stanje == 2)  //unesen binarni operator/ operand je prazan/ rezultat je pun
            {
                if (Char.IsDigit(inPressedDigit))     //unosenje znamenki i ispisivanje operanda
                {
                    if (brojZnamenkiOperanda < 10)          //rjesava problem broja znamenki
                    {
                        operand = operand + inPressedDigit;
                        ekran = operand;
                        brojZnamenkiOperanda++;
                    }
                }
                else
                    switch (inPressedDigit)
                    {
                        case '+':
                            if (brojZnamenkiOperanda == 0) binarniOperator = "+";
                            else
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, operand);
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                binarniOperator = "+";
                                operand = "";
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case '-':
                            if (brojZnamenkiOperanda == 0) binarniOperator = "-";
                            else
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, operand);
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                binarniOperator = "-";
                                operand = "";
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case '*':
                            if (brojZnamenkiOperanda == 0) binarniOperator = "*";
                            else
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, operand);
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                binarniOperator = "*";
                                operand = "";
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case '/':
                            if (brojZnamenkiOperanda == 0) binarniOperator = "/";
                            else
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, operand);
                                //provjeri za djeljenje s nulom
                                rezultat = zaokruziZnamenke(rezultat);
                                binarniOperator = "/";
                                operand = "";
                                brojZnamenkiOperanda = 0;
                            }
                            break;
                        case '=':
                            if (brojZnamenkiOperanda == 0)
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, rezultat);
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                else
                                {
                                    ekran = rezultat;
                                    ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                                    rezultat = "0";
                                    brojZnamenkiOperanda = 0;
                                    operand = "";
                                    stanje = 0;
                                }
                            }
                            else
                            {
                                rezultat = izvediOperaciju(rezultat, binarniOperator, operand);
                                if (Math.Abs(Convert.ToDouble(rezultat)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                else
                                {
                                    ekran = rezultat;
                                    ekran = Convert.ToString(Convert.ToDouble(ekran) * 1);
                                    rezultat = "0";
                                    brojZnamenkiOperanda = 0;
                                    operand = "";
                                    stanje = 0;
                                }

                            }
                            break;

                        case 'S':
                            if (operand == "")
                                ekran = zaokruziZnamenke(Convert.ToString(Math.Sin(Convert.ToDouble(rezultat))));
                            else
                            {
                                operand = Convert.ToString(Math.Sin(Convert.ToDouble(operand)));
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;
                        case 'K':
                            if (operand == "")
                                ekran = zaokruziZnamenke(Convert.ToString(Math.Cos(Convert.ToDouble(rezultat))));
                            else
                            {
                                operand = Convert.ToString(Math.Cos(Convert.ToDouble(operand)));
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;
                        case 'T':
                            if (operand == "")
                                ekran = zaokruziZnamenke(Convert.ToString(Math.Tan(Convert.ToDouble(rezultat))));
                            else
                            {
                                operand = Convert.ToString(Math.Tan(Convert.ToDouble(operand)));
                                if (Math.Abs(Convert.ToDouble(operand)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;
                        case 'Q':
                            if (operand == "")
                                ekran = zaokruziZnamenke(Convert.ToString(Math.Pow(Convert.ToDouble(rezultat), 2)));
                            else
                            {
                                operand = Convert.ToString(Math.Pow(Convert.ToDouble(operand),2));
                                if (Math.Abs(Convert.ToDouble(operand)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;
                        case 'I':
                            if (operand == "")
                                ekran = zaokruziZnamenke(Convert.ToString(1 / Convert.ToDouble(rezultat)));
                            else
                            {
                                operand = Convert.ToString(1 / Convert.ToDouble(operand));
                                if (Math.Abs(Convert.ToDouble(operand)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;
                        case 'R':
                            if (operand == "")
                            {
                                if (Convert.ToDouble(rezultat) < 0)
                                {
                                    ekran = "-E-";
                                    stanje = 7;
                                    break;
                                }
                                ekran = zaokruziZnamenke(Convert.ToString(Math.Sqrt(Convert.ToDouble(rezultat))));
                            }
                            else
                            {
                                if (Convert.ToDouble(operand) < 0)
                                {
                                    ekran = "-E-";
                                    stanje = 7;
                                    break;
                                }
                                operand = Convert.ToString(Math.Sqrt(Convert.ToDouble(operand)));
                                if (Math.Abs(Convert.ToDouble(operand)) > 9999999999)
                                {
                                    ekran = "-E-";
                                    //neznam za rez i oper
                                    stanje = 7; //stanje za error
                                }
                                operand = zaokruziZnamenke(operand);
                                ekran = operand;                    //unarne dal se racunaju u binarnima ili osnovni podatak
                            }
                            break;                        
                        case ',':
                            if (operand == "")
                                operand = "0,";
                            else
                                operand = operand + inPressedDigit;
                            ekran = operand;
                            //vise zareza zaredom
                            break;
                        case 'M':
                            operand = Convert.ToString(Convert.ToDouble(operand) * (-1)); //kome se mijenja ako je abs šritisnut npr +
                            ekran = operand;
                            break;
                        case 'P':
                            memorija = operand;
                            break;
                        case 'G':
                            if (memorija != "")
                            {
                                operand = memorija;
                                ekran = operand;
                            }
                            break;
                        case 'C':
                            operand = "0";
                            brojZnamenkiOperanda = 0;
                            ekran = operand;
                            break;
                        case 'O':
                            memorija = "";
                            rezultat = "0";
                            operand = "0";
                            ekran = "0";
                            stanje = 0;
                            break;
                        default:
                            Console.WriteLine("Default case");
                            break;
                    }

                if (stanje == 7)
                    if (inPressedDigit == 'O')
                    {
                        memorija = "";
                        rezultat = "0";
                        operand = "0";
                        ekran = "0";
                        stanje = 0;
                       
                    }

            }




           // operand = reducirajZnamenke(operand);

            
            
            
            
            
            
        }

        public string GetCurrentDisplayState()
        {
            return ekran;
        }


        private string izvediOperaciju(string rezultat, string binarniOperator, string operand)
        {
            switch (binarniOperator)
            {
                case "+":
                    rezultat = Convert.ToString(Convert.ToDouble(rezultat) + Convert.ToDouble(operand));
                    break;
                case "-":
                    rezultat = Convert.ToString(Convert.ToDouble(rezultat) - Convert.ToDouble(operand));
                    break;
                case "*":
                    rezultat = Convert.ToString(Convert.ToDouble(rezultat) * Convert.ToDouble(operand));
                    break;
                case "/":
                    rezultat = Convert.ToString(Convert.ToDouble(rezultat) / Convert.ToDouble(operand));
                    break;
                default:
                    break;
            }


            return rezultat;
        }


        private string reducirajZnamenke(string broj)
        {
            int i = 0;
            int brznam = 0;
            for (i = 0; i < broj.Length; i++)
            {
                if (Char.IsDigit(broj[i]))
                    brznam++;
                if (brznam == 10)
                    return broj.Substring(0,i + 1);             
            }
            return broj.Substring(0, i);
        }


        private string zaokruziZnamenke(string broj)
        {
            int i = 0;
            int brznam = 0;
            int brojUkupno = 0;
            for (i = 0; i < broj.Length; i++)
            {
                brojUkupno++;
                if (Char.IsDigit(broj[i]))
                    brznam++;
                if (brznam == 10)
                {
                    if (broj.Length > brojUkupno)
                    {
                        if (Convert.ToInt32(broj[brojUkupno]) > 4)
                            broj = broj.Substring(0, brojUkupno - 1) + Convert.ToChar(Convert.ToInt32(broj[brojUkupno - 1]) + 1);
                    }
                    return broj.Substring(0, i + 1);
                }
            }
            return broj.Substring(0, i);
        }





    }


}
