﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private StockRepository stockRepository = new StockRepository();
        private IndexRepository indexRepository = new IndexRepository();
        private PortfolioRepository portfolioRepository = new PortfolioRepository();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            stockRepository.ListStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)//kad se brise dionica brise se i iz indexa i portfelja
        {
            stockRepository.DelistStock(inStockName);
            indexRepository.RemoveStockFromIndex(inStockName);
            portfolioRepository.RemoveStockFromPortfolio(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return stockRepository.StockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return stockRepository.GetNumStocks();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            stockRepository.SetStockPrice(inStockName, inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return stockRepository.GetStockPrice(inStockName, inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return stockRepository.GetInitialStockPrice(inStockName);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return stockRepository.GetLastStockPrice(inStockName);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            indexRepository.CreateIndex(inIndexName, inIndexType, stockRepository);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            indexRepository.AddStockToIndex(inIndexName, inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            indexRepository.RemoveStockFromIndex(inIndexName, inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return indexRepository.IsStockPartOfIndex(inIndexName, inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return indexRepository.GetIndexValue(inIndexName, inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return indexRepository.IndexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return indexRepository.NumberOfIndices();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return indexRepository.NumberOfStocksInIndex(inIndexName);
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            portfolioRepository.CreatePortfolio(inPortfolioID,stockRepository);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            portfolioRepository.AddStockToPortfolio(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            portfolioRepository.RemoveStockFromPortfolio(inPortfolioID, inStockName);
        }

        public int NumberOfPortfolios()
        {
            return portfolioRepository.NumberOfPortfolios();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return portfolioRepository.NumberOfStocksInPortfolio(inPortfolioID);
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolioRepository.PortfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return portfolioRepository.IsStockPartOfPortfolio(inPortfolioID, inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return portfolioRepository.NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return portfolioRepository.GetPortfolioValue(inPortfolioID, timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return portfolioRepository.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month);
        }
    }

    public class Stock
    {

        private string inStockName;
        private long inNumberOfShares;
        private long stockNumberInPortfolios;
        public string StockName { get { return inStockName; } }
        public long NumberOfShares { get { return inNumberOfShares; } }
        public long StockNumberInPortfolios { get { return stockNumberInPortfolios; } set { stockNumberInPortfolios = value; } }
        List<StockPrice> stockPrices = new List<StockPrice>();
        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            // TODO: Complete member initialization
            this.inStockName = inStockName.ToUpper();
            this.inNumberOfShares = inNumberOfShares;
            stockPrices.Add(new StockPrice(inInitialPrice, inTimeStamp));
            stockNumberInPortfolios = 0;
        }

        private StockPrice getStockPriceValidForDate(DateTime dateTime)
        {
            StockPrice stockPriceLatest = null;
            foreach (StockPrice stockPrice in stockPrices)
            {
                if (stockPrice.TimeStamp <= dateTime)
                    stockPriceLatest = stockPrice;
                else
                    break;
            }
            return stockPriceLatest;
        }
        internal void SetStockPrice(DateTime inTimeStamp, decimal inStockValue)
        {
            if (StockPriceDateExists(inTimeStamp) == false)
            {
                stockPrices.Add(new StockPrice(inStockValue, inTimeStamp));
                stockPrices.Sort((a, b) => a.TimeStamp.CompareTo(b.TimeStamp));
            }
            else
                throw new StockExchangeException("DelistStock - Nije nadena dionica");
        }

        private bool StockPriceDateExists(DateTime inTimeStamp)
        {
            foreach (StockPrice curStockPrice in stockPrices)
            {
                if (curStockPrice.TimeStamp == inTimeStamp)
                    return true;
            }
            return false;
        }

        internal decimal GetStockPrice(DateTime inTimeStamp)
        {
            StockPrice stockPrice = getStockPriceValidForDate(inTimeStamp);
            if (stockPrice != null)
                return stockPrice.Price;
            else
                throw new StockExchangeException("GetStockPrice - nije nadena valjana cijena");
        }

        internal decimal GetInitialStockPrice()
        {
            return stockPrices[0].Price;
        }

        internal decimal GetLastStockPrice()
        {
            return stockPrices[stockPrices.Count - 1].Price;
        }
    }

    public class StockRepository
    {
        private List<Stock> listStock = new List<Stock>();


        internal void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName) == false && inInitialPrice > 0 && inNumberOfShares > 0)
                listStock.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            else
                throw new StockExchangeException("ListStock Dionica vec postoji ili je cijena negativna");
        }
        public Stock getStockByName (string StockName)
        {
            foreach (Stock stock in listStock)
            {
                if (stock.StockName == StockName.ToUpper())
                    return stock;
            }
            return null;
        }

        internal void DelistStock(string inStockName) 
        {
            Stock stock = getStockByName(inStockName);
            if (stock != null)
                listStock.Remove(stock);
            else
                throw new StockExchangeException("DelistStock - Nije nadena dionica");

        }

        internal bool StockExists(string inStockName)
        {
            if (getStockByName(inStockName) != null)
                return true;
            else
                return false;
        }

        internal int GetNumStocks()
        {
            return listStock.Count;
        }

        internal void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = getStockByName(inStockName);
            if (stock != null && inStockValue > 0)
                stock.SetStockPrice(inIimeStamp, inStockValue);
            else
                throw new StockExchangeException("SetStockPrice - Nije nadena dionica ili je cijena negativna");
        }

        internal decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = getStockByName(inStockName);
            if (stock != null)
                return stock.GetStockPrice(inTimeStamp);
            else
                throw new StockExchangeException("GetStockPrice - Nije nadena dionica");
        }

        internal decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = getStockByName(inStockName);
            if (stock != null)
                return stock.GetInitialStockPrice();
            else
                throw new StockExchangeException("GetInitialStockPrice - Nije nadena dionica");

        }

        internal decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = getStockByName(inStockName);
            if (stock != null)
                return stock.GetLastStockPrice();
            else
                throw new StockExchangeException("GetLastStockPrice - Nije nadena dionica");
        }
    }

    public class StockPrice
    {
        private decimal inPrice;
        private DateTime inTimeStamp;
        public DateTime TimeStamp { get { return inTimeStamp; }  }
        public decimal Price { get { return inPrice; } }
        public StockPrice(decimal inPrice, DateTime inTimeStamp)
        {
            // TODO: Complete member initialization
            this.inPrice = inPrice;
            this.inTimeStamp = inTimeStamp;
        }
    }

    public class Index
    {
        private string inIndexName;
        private IndexTypes inIndexType;
        List<Stock> listStocks = new List<Stock>();
        private StockRepository stockRepository;
        public string IndexName { get { return inIndexName; } }

        public Index(string inIndexName, IndexTypes inIndexType, StockRepository stockRepository)
        {
            // TODO: Complete member initialization
            this.inIndexName = inIndexName.ToUpper();
            this.inIndexType = inIndexType;
            this.stockRepository = stockRepository;
        }

        internal void AddStockToIndex(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
                listStocks.Add(stock);
            else
                throw new StockExchangeException("AddStockToIndex - nije nadena dionica s odgovarajucim imenom");

        }

        internal void RemoveStockFromIndex(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
                listStocks.Remove(stock);
            else
                throw new StockExchangeException("RemoveStockFromIndex - nije nadena dionica s odgovarajucim imenom");
        }

        internal bool IsStockPartOfIndex(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
                if (listStocks.Contains(stock))
                    return true;
                else
                    return false;
            else
                throw new StockExchangeException("IsStockPartOfIndex - nije nadena dionica s odgovarajucim imenom");
        }

        internal decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (inIndexType == IndexTypes.AVERAGE)
                return calculateAverageIndexValue(inTimeStamp);
            else if (inIndexType == IndexTypes.WEIGHTED)
                return calculateWeightedIndexValue(inTimeStamp);
            else
                throw new StockExchangeException("GetIndexValue - tip indeksa neispravan");
        }

        private decimal calculateWeightedIndexValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal ukupnaVrijednostDionica = 0;

            foreach (Stock stock in listStocks)
            {
                decimal price = stock.GetStockPrice(inTimeStamp);
                ukupnaVrijednostDionica += (price * stock.NumberOfShares);
            }
            foreach (Stock stock in listStocks)
            {
                decimal price = stock.GetStockPrice(inTimeStamp);
                decimal faktor = (stock.NumberOfShares * price) / ukupnaVrijednostDionica;
                sum += (price * faktor);
            }
            return sum;
        }

        private decimal calculateAverageIndexValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach (Stock stock in listStocks)
            {
                decimal price = stock.GetStockPrice(inTimeStamp);
                sum += price;
            }
            decimal avgIndexValue = sum / listStocks.Count;
            return avgIndexValue;
        }

        internal int NumberOfStocksInIndex()
        {
            return listStocks.Count;
        }
    }

    public class IndexRepository
    {
        List<Index> listIndex = new List<Index>();

        internal void CreateIndex(string inIndexName, IndexTypes inIndexType, StockRepository stockRepository)
        {
            Index index = getIndexByName(inIndexName);
            if (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
                if(index==null)
                    listIndex.Add(new Index(inIndexName, inIndexType, stockRepository));
                else
                    throw new StockExchangeException("CreateIndex - index vec postoji");

            else
                throw new StockExchangeException("CreateIndex - nevaljali tip indeksa");
        }

        internal void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                index.AddStockToIndex(inStockName);
            else
                throw new StockExchangeException("AddStockToIndex - Index ne postoji");
        }

        private Index getIndexByName(string inIndexName)
        {
            foreach (Index index in listIndex)
            {
                if (index.IndexName == inIndexName.ToUpper())
                    return index;
            }
            return null;
        }


        internal void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                index.RemoveStockFromIndex(inStockName);
            else
                throw new StockExchangeException("RemoveStockFromIndex - Index ne postoji");

        }
        internal void RemoveStockFromIndex(string inStockName)
        {
            foreach (Index index in listIndex)
            {
                index.RemoveStockFromIndex(inStockName);
            }
        }

        internal bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                return index.IsStockPartOfIndex(inStockName);
            else
            throw new StockExchangeException("IsStockPartOfIndex - Index ne postoji");

        }


        internal decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                return index.GetIndexValue(inTimeStamp);
            else
                throw new StockExchangeException("GetIndexValue - Index ne postoji");
        }

        internal bool IndexExists(string inIndexName)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                return true;
            else
                return false;
        }

        internal int NumberOfIndices()
        {
            return listIndex.Count;
        }

        internal int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = getIndexByName(inIndexName);
            if (index != null)
                return index.NumberOfStocksInIndex();
            else
                throw new StockExchangeException("NumberOfStocksInIndex - Index ne postoji");
        }
    }

    public class Portfolio
    {
        private string inPortfolioID;
        private StockRepository stockRepository;
        public string PortfolioID { get { return inPortfolioID; } }
        Dictionary<Stock, long> numberOfStockShares = new Dictionary<Stock, long>();

        public Portfolio(string inPortfolioID, StockRepository stockRepository)
        {
            // TODO: Complete member initialization
            this.inPortfolioID = inPortfolioID;
            this.stockRepository = stockRepository;
        }

        internal void AddStockToPortfolio(string inStockName, int numberOfShares)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
            {
                stock.StockNumberInPortfolios += numberOfShares;
                if (stock.StockNumberInPortfolios > stock.NumberOfShares)
                    throw new StockExchangeException("AddStockToPortfolio - dodano je vise dionica nego sto postoji");
                else
                {
                    if (numberOfStockShares.ContainsKey(stock))
                    {
                        numberOfStockShares[stock] += numberOfShares;
                    }
                    else
                        numberOfStockShares.Add(stock, numberOfShares);
                }
            }
            else
                throw new StockExchangeException("AddStockToPortfolio - ne postoji dionica");
        }

        internal void RemoveStockFromPortfolio(string inStockName, int numberOfShares)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
            {
                stock.StockNumberInPortfolios -= numberOfShares;
                if (stock.StockNumberInPortfolios < 0)
                    throw new StockExchangeException("RemoveStockFromPortfolio - oduzeto previse dionica");
                numberOfStockShares[stock] -= numberOfShares;
                if (numberOfStockShares[stock] == 0)
                    numberOfStockShares.Remove(stock);
                else if (numberOfStockShares[stock] < 0)
                    throw new StockExchangeException("RemoveStockFromPortfolio - oduzeto previse dionica");
            }
            else
                throw new StockExchangeException("RemoveStockFromPortfolio - dionica ne postoji");
        }

        internal void RemoveStockFromPortfolio(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
            {
                stock.StockNumberInPortfolios -= numberOfStockShares[stock];
                numberOfStockShares.Remove(stock);
            }
            else
                throw new StockExchangeException("RemoveStockFromPortfolio - dionica ne postoji");
        }


        internal int NumberOfStocksInPortfolio()
        {
            return numberOfStockShares.Count;
        }

        internal bool IsStockPartOfPortfolio(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (numberOfStockShares.ContainsKey(stock))
                return true;
            else
                return false;
        }

        internal int NumberOfSharesOfStockInPortfolio(string inStockName)
        {
            Stock stock = stockRepository.getStockByName(inStockName);
            if (stock != null)
                if (numberOfStockShares.ContainsKey(stock))
                    return (int)numberOfStockShares[stock];
                else
                    throw new StockExchangeException("NumberOfSharesOfStockInPortfolio - dionica ne postoji u portfoliu");
            else
                throw new StockExchangeException("NumberOfSharesOfStockInPortfolio - dionica ne postoji u repozitoriju");

        }

        internal decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (Stock stock in numberOfStockShares.Keys)
            {
                sum += (stock.GetStockPrice(timeStamp) * numberOfStockShares[stock]);
            }
            return decimal.Round(sum, 3);//zaokruziti na 3 decimale
        }

        internal decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            decimal percentChange = 100m * ((GetPortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999)) / GetPortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0, 0))) - 1);
            return decimal.Round(percentChange, 3);
            //zaokruziti na 3 decimale
        }
    }

    public class PortfolioRepository
    {
        List<Portfolio> listPortfolio = new List<Portfolio>();

        internal void CreatePortfolio(string inPortfolioID, StockRepository stockRepository)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio == null)
                listPortfolio.Add(new Portfolio(inPortfolioID, stockRepository));
            else
                throw new StockExchangeException("CreatePortfolio - portfolio vec postoji");
        }

        private Portfolio getPortfolioById(string inPortfolioID)
        {
            foreach (Portfolio portfolio in listPortfolio)
            {
                if (portfolio.PortfolioID == inPortfolioID)
                    return portfolio;
            }
            return null;
        }

        internal void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                portfolio.AddStockToPortfolio(inStockName, numberOfShares);
            else
                throw new StockExchangeException("AddStockToPortfolio - portfolio ne postoji");
        }

        internal void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                portfolio.RemoveStockFromPortfolio(inStockName, numberOfShares);
            else
                throw new StockExchangeException("RemoveStockFromPortfolio - portfolio ne postoji");
        }

        internal void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                portfolio.RemoveStockFromPortfolio(inStockName);
            else
                throw new StockExchangeException("RemoveStockFromPortfolio - portfolio ne postoji");
        }

        internal int NumberOfPortfolios()
        {
            return listPortfolio.Count;
        }

        internal void RemoveStockFromPortfolio(string inStockName)
        {
            foreach (Portfolio portfolio in listPortfolio)
            {
                portfolio.RemoveStockFromPortfolio(inStockName);
            }
        }

        internal int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return portfolio.NumberOfStocksInPortfolio();
            else
                throw new StockExchangeException("NumberOfStocksInPortfolio - portfolio ne postoji");

        }

        internal bool PortfolioExists(string inPortfolioID)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return true;
            else
                return false;
        }

        internal bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return portfolio.IsStockPartOfPortfolio(inStockName);
            else
                throw new StockExchangeException("IsStockPartOfPortfolio - portfolio ne postoji");
        }

        internal int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return portfolio.NumberOfSharesOfStockInPortfolio(inStockName);
            else
                throw new StockExchangeException("NumberOfSharesOfStockInPortfolio - portfolio ne postoji");
        }

        internal decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return portfolio.GetPortfolioValue(timeStamp);
            else
                throw new StockExchangeException("NumberOfSharesOfStockInPortfolio - portfolio ne postoji");
        }


        internal decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = getPortfolioById(inPortfolioID);
            if (portfolio != null)
                return portfolio.GetPortfolioPercentChangeInValueForMonth(Year,Month);
            else
                throw new StockExchangeException("GetPortfolioPercentChangeInValueForMonth - portfolio ne postoji");
        }
    }
}
