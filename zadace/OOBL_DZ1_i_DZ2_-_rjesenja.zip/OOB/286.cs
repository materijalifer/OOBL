﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,Stock> stocks= new Dictionary<string,Stock>();
         private Dictionary<string, Index> indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
                 throw new StockExchangeException("Dionica vec postoji");
             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica mora biti pozitivan");
             if (inInitialPrice <= 0)
                 throw new StockExchangeException("cijena mora biti pozitivan broj");
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(inStockName.ToUpper(), stock);

         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             foreach (Index index in indices.Values)
             {
                 index.stockRemoved(inStockName.ToUpper());
             }
             foreach (Portfolio portfolio in portfolios.Values)
             {
                 portfolio.stockRemoved(inStockName.ToUpper());
             }

             stocks.Remove(inStockName.ToUpper());
             

         }

         public bool StockExists(string inStockName)
         {
             return stocks.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             stocks[inStockName.ToUpper()].newValue(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return stocks[inStockName.ToUpper()].getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return stocks[inStockName.ToUpper()].getInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return GetStockPrice(inStockName.ToUpper(), DateTime.MaxValue);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks postoji");
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                 throw new StockExchangeException("nepostojeci tip indexa");
             Index index =new Index(inIndexName.ToUpper(),inIndexType);
             indices.Add(inIndexName.ToUpper(),index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             indices[inIndexName.ToUpper()].addStock(inStockName);

         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             indices[inIndexName.ToUpper()].removeStock(inStockName.ToUpper());
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             return indices[inIndexName.ToUpper()].containsStock(inStockName.ToUpper());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
                          
             decimal result = 0;
             long numOfStokes=0;
             decimal overalValue = 0;
             if (indices[inIndexName.ToUpper()].getType() == IndexTypes.AVERAGE)
             {
                 foreach (string stockName in indices[inIndexName.ToUpper()].getStockList(inTimeStamp))
                 {
                     result += GetStockPrice(stockName, inTimeStamp);
                     numOfStokes++;
                 }
                 if (numOfStokes == 0)
                     return 0;
                 return Math.Round(result/numOfStokes,3);
             }
             if (indices[inIndexName.ToUpper()].getType() == IndexTypes.WEIGHTED)
             {
                 foreach (string stockName in indices[inIndexName.ToUpper()].getStockList(inTimeStamp))
                 {
                     result += GetStockPrice(stockName, inTimeStamp)*
                         GetStockPrice(stockName, inTimeStamp)*stocks[stockName].getNoOfShares();
                     overalValue += GetStockPrice(stockName, inTimeStamp) * stocks[stockName].getNoOfShares();
                 }
                 if (overalValue == 0)
                     return 0;
                 return Math.Round(result/overalValue,3);
             }
             throw new StockExchangeException("kriva definicija indexa");
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.ContainsKey(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks ne postoji");
             return indices[inIndexName.ToUpper()].getNumOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj postoji");
             Portfolio portfolio = new Portfolio(inPortfolioID);
             portfolios.Add(inPortfolioID,  portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             stocks[inStockName.ToUpper()].buyShare(numberOfShares);            
             portfolios[inPortfolioID].addStock(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             stocks[inStockName.ToUpper()].sellShare(numberOfShares);
             portfolios[inPortfolioID].removeStock(inStockName, numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             if (!IsStockPartOfPortfolio(inPortfolioID,inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             int numOfShares;
             numOfShares=portfolios[inPortfolioID].removeStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             return portfolios[inPortfolioID].getNoOfStockes();

         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return portfolios[inPortfolioID].containsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica ne postoji");
             return portfolios[inPortfolioID].getNoOfShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             return portfolios[inPortfolioID].value(timeStamp, stocks);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfelj ne postoji");
             return portfolios[inPortfolioID].monthlyChange(Year, Month, stocks);
         }
         
     }
    public class StockValue
    {
        private decimal value;
        private DateTime timeStamp;
        public DateTime getTimeStamp()
        {
            return this.timeStamp;
        }
        public decimal getValue()
        {
            return this.value;
        }
        public StockValue(decimal inValue, DateTime inTimeStamp)
        {
            this.value = inValue;
            this.timeStamp = inTimeStamp;
        }
    }
    public class Stock
     {
         private string stockName;
         private long numberOfShares;
         private long availableShares;
         private DateTime initial;
         private List<StockValue> stockValueList; 
         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             this.stockName=inStockName;
             stockValueList = new List<StockValue>();
             StockValue price = new StockValue(inInitialPrice, inTimeStamp);
             this.stockValueList.Add(price);
             this.numberOfShares = inNumberOfShares;
             this.availableShares = inNumberOfShares;
             this.initial = inTimeStamp;
         }
         public DateTime GetInitialDateTime()
         {
             return this.initial;
         }
         public long getNoOfShares()
         {
             return this.numberOfShares;
         }
        public void newValue(decimal inValue,DateTime inTimeStamp)
        {
            if (inTimeStamp < initial)
                throw new StockExchangeException("nema jos dionice");
            foreach (StockValue sv in stockValueList)
            {
                if (sv.getTimeStamp() == inTimeStamp)
                    throw new StockExchangeException("vec je zadana vrijednost za taj trenutak");
            }

            StockValue value = new StockValue(inValue,inTimeStamp);
            stockValueList.Add(value);
        }
        public decimal getInitialPrice()
        {
            return getPrice(initial);
        }
        public decimal getPrice(DateTime inTimeStamp)
        {
            int maxIndex=0;
            for (int i = 1; i < stockValueList.Count; i++)
            {
                if (stockValueList[i].getTimeStamp() <= inTimeStamp &&
                    stockValueList[i].getTimeStamp() > stockValueList[maxIndex].getTimeStamp())
                    maxIndex = i;
            }
            return stockValueList[maxIndex].getValue();
        }
        public void buyShare(int noOfShares)
        {
            if (noOfShares > availableShares)
                throw new StockExchangeException("nema toliko dionica na burzi");
            availableShares = availableShares - noOfShares;
        }
        public void sellShare(int noOfShares)
        {
            availableShares += noOfShares;
        }
     }
    public class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private List<string> indexStockList;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.indexName = inIndexName;
            this.indexType = inIndexType;
            indexStockList=new List<string>();
        }
        public void addStock(string inStock)
        {
            if (indexStockList.Contains(inStock.ToUpper()))
                throw new StockExchangeException("Dionica postoji u indeksu");
            indexStockList.Add(inStock.ToUpper());
        }
        public void removeStock(string inStock)
        {
            if (!indexStockList.Contains(inStock.ToUpper()))
                throw new StockExchangeException("Dionica ne postoji u indeksu");
            indexStockList.Remove(inStock.ToUpper());
        }

        public int getNumOfStocks()
        {
            return indexStockList.Count;
        }
        public bool containsStock(string inStock)
        {
            return indexStockList.Contains(inStock);
        }
        public List<string> getStockList(DateTime inTimeStamp)
        {
            return this.indexStockList;
        }
        public IndexTypes getType()
        {
            return this.indexType;
        }
        public void stockRemoved(string inStockName)
        {
            if (this.containsStock(inStockName))
                this.removeStock(inStockName);  
        }
    }
    public class Share
    {
        public Share(string inStockName, int inNoOfShares)
        {
            this.stockName = inStockName;
            this.noOfShares = inNoOfShares;
        }
        public string stockName;
        public int noOfShares;
    }
    public class Portfolio
    {
        string portfolioID;
        List<Share> portfolioShareList;
        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
            portfolioShareList = new List<Share>();
        }
        public void addStock(string stock, int num)
        {
            
            foreach (Share shar in portfolioShareList)
                if (shar.stockName==stock)
                {
                    shar.noOfShares+=num;
                    return;
                }
            Share virtualShare = new Share(stock,num);
            portfolioShareList.Add(virtualShare);
            

        }
        public void removeStock(string stock, int num)
        {
            foreach (Share shar in portfolioShareList)
                if (shar.stockName == stock)
                {
                    shar.noOfShares = shar.noOfShares - num;
                    if (shar.noOfShares < 0)
                        throw new StockExchangeException("nema toliko udjela u portfelju");
                    if (shar.noOfShares == 0)
                        portfolioShareList.Remove(shar);
                    return;
                }
                
        }
        public int removeStock(string stock)
        {
            foreach (Share shar in portfolioShareList)
                if (shar.stockName == stock)
                {
                    int noShares=shar.noOfShares;
                    portfolioShareList.Remove(shar);
                    return noShares;
                }
            return 0;
        }
        public bool containsStock(string inStockName)
        {
            foreach (Share shar in portfolioShareList)
                if (shar.stockName == inStockName)
                    return true;
            return false;
        }
        public void stockRemoved(string inStockName)
        {
            if (this.containsStock(inStockName))
                this.removeStock(inStockName);
        }
        public int getNoOfStockes()
        {
            return portfolioShareList.Count();
        }
        public int getNoOfShares(string inStockName)
        {
            foreach (Share shar in portfolioShareList)
                if (shar.stockName == inStockName)
                {
                    return shar.noOfShares;
                }
            return 0;
        }
        public decimal value(DateTime ts, Dictionary<string, Stock> stocks)
        {
            decimal result = 0;
            foreach (Share shar in portfolioShareList)
                result += stocks[shar.stockName].getPrice(ts) * shar.noOfShares;
            return Math.Round(result,3);
        }
        public decimal monthlyChange(int year, int month, Dictionary<string, Stock> stocks)
        {
            decimal result = 0;
            DateTime dt1 = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime dt2=new DateTime(year,month,DateTime.DaysInMonth(year,month),23,59,59,999);
            result = value (dt1,stocks);
            if(result==0)
                throw new StockExchangeException("nije definiranio");
            result= ((value (dt2,stocks)/result)-1)*100;
            return Math.Round(result,3);

        }
    }


}
