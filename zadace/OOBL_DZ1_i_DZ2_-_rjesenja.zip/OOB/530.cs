﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    } 
     public class Dionica
     {
         #region ---Osnove varijable---
         public string imeDionice;
         public long brojDionica;
         public decimal pocetnaCijena;
         public DateTime pocetniTrenutak;
         #endregion
         #region ---Dodatne varijable---
         public PovijestCijeneDionice povijestCijeneDionice;
         string imeIndexa;
         int brojportfelja;
         List<string> portfelji;
         #endregion
         #region ---konstruktor---
         public Dionica(string ime, long broj, decimal cijena, DateTime datum)
         {
             this.imeDionice = ime;
             this.brojDionica = broj;
             this.pocetnaCijena = cijena;
             this.pocetniTrenutak = datum;
             this.povijestCijeneDionice = new PovijestCijeneDionice (datum, cijena);
             this.imeIndexa = "";
             this.brojportfelja = 0;
             this.portfelji = new List<string>();
         }
         #endregion
         #region ----Metode za upravljanje s povijesti---     
         public void DodajNovuCijenu(DateTime trenutnoVrijeme, decimal novaCijena) 
         {
             this.povijestCijeneDionice.DodajCijenu(trenutnoVrijeme,novaCijena);
         }
         #endregion
         #region ----Metode za upravljanje s indexima----
         public bool ImaIndeks()
         {
             bool flag = (!imeIndexa.Equals(""));
             return flag;
         }
         public void DodajIndeks(string ime)
         {
             this.imeIndexa = ime;
         }
         public void MakniIndeks()
         {
             this.imeIndexa = "";
         }
         public string DohvatiIndeks()
         {
             return imeIndexa;
         }
         #endregion
         #region ----Metode za upravljanje portfeljima---
         public bool UPortfelju()
         {
             bool prazna = (!this.portfelji.Any());
             if (prazna)
                 return prazna;
             else
                 return !prazna;
         }
         public bool NeDostupnaDionica(int brojDionicaNaBurzi) 
         {
             if (brojDionicaNaBurzi <= (brojDionica - brojportfelja))
                 return false;
             else
                 return true;
         }
         public void DodajUPortfelj(string portfeljID, int brojDionicaNaBurzi) 
         {
             this.brojDionica += brojDionicaNaBurzi;
             if (!this.portfelji.Contains(portfeljID))
                 this.portfelji.Add(portfeljID);
         }
         public List<string> DohvatiListuPortfelja()
         {
             return this.portfelji;
         }
         #endregion

     }
     public class PovijestCijeneDionice
     {
         #region ---varijabla---
         public SortedDictionary<DateTime, decimal> povijestCijene = new SortedDictionary<DateTime, decimal>();
         #endregion
         #region ---konstruktor---
         public PovijestCijeneDionice(DateTime vrijeme, decimal cijena) 
         {
             povijestCijene.Add(vrijeme, cijena);
         }
         #endregion
         //metode
         #region ---cijena---
         public void DodajCijenu(DateTime vrijeme, decimal cijena)
         {
             povijestCijene.Add(vrijeme, cijena);
         }
         #endregion
         #region---datum---
         public DateTime DohvatiZadnjiDatum( DateTime pocetni) 
         {
             DateTime konacno = povijestCijene.Keys.First();
             foreach(DateTime datum in povijestCijene.Keys.ToList())
             {
                 if ((pocetni - datum).TotalMilliseconds > 0)
                     konacno = datum;
                 else
                     return konacno;
             }
             return konacno;
         }
         #endregion
     }
     public class Portfelj
     {
         #region ---varijable---
         string ID;
         public SortedDictionary<string, int> listaDionica;
         #endregion
         #region ---konstrukor---
         public Portfelj(string id)
         {
             this.ID = id;
             this.listaDionica = new SortedDictionary<string, int>();
         }
         #endregion
         #region ---Metode za upravljanje dionicama---
         public void DodajDionicu(string imeDionice, int brojDionice)
         {
             if (this.listaDionica.ContainsKey(imeDionice))
                 this.listaDionica[imeDionice] += brojDionice;
             else
                 this.listaDionica.Add(imeDionice, brojDionice);
         }
         public void MakniDionicu(string imeDionice, int brojDionice)
         {
             this.listaDionica[imeDionice] -= brojDionice;
         }
         #endregion
     }
     public class Indeks
     {
         #region ---varijable---
         string imeIndeksa;
         public IndexTypes tipIndeksa;
         public List<string> listaIndeksiranihDionica;
         #endregion
         #region ---konstruktor---
         public Indeks(string ime, IndexTypes tip)
         {
             this.imeIndeksa = ime;
             this.tipIndeksa = tip;
             this.listaIndeksiranihDionica = new List<string>();
         }
         #endregion
     }
     public class StockExchange : IStockExchange
     {
         #region ---varijable---
         SortedDictionary<string, Dionica> listaDionica = new SortedDictionary<string, Dionica>();
         SortedDictionary<string, Indeks> listaIndeksa = new SortedDictionary<string, Indeks>();
         SortedDictionary<string, Portfelj> listaPortfelja = new SortedDictionary<string, Portfelj>();
         #endregion
         #region ---glavne metode---
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice < 0)
                 throw new StockExchangeException("Cijena ne smije biti negativna!");
             else if (StockExists(inStockName))
                 throw new StockExchangeException("Dionica s istim imenom postoji na burzi!");
             else
                 listaDionica.Add(inStockName.ToUpper(), new Dionica (inStockName.ToUpper(),inNumberOfShares,inInitialPrice,inTimeStamp));
         }
         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica koja se zeli maknuti nije na burzi!");
             else
             {
                 if (listaDionica[inStockName.ToUpper()].UPortfelju())
                 {
                     foreach (string id in listaDionica[inStockName.ToUpper()].DohvatiListuPortfelja())
                     {
                         RemoveStockFromPortfolio(id, inStockName.ToUpper());
                     }
                 }
                 if (listaDionica[inStockName.ToUpper()].ImaIndeks())
                     RemoveStockFromIndex(listaDionica[inStockName.ToUpper()].DohvatiIndeks(), inStockName);
                 listaDionica.Remove(inStockName.ToUpper());
             }
         }
         public bool StockExists(string inStockName)
         {
             return listaDionica.ContainsKey(inStockName.ToUpper());
         }
         public int NumberOfStocks()
         {
             return listaDionica.Count;
         }
         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (inStockValue< 0)
                 throw new StockExchangeException("Cijena ne smije biti negativna!");
             else if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
             else
             {
                 if (!listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene.ContainsKey(inIimeStamp))
                 {
                    listaDionica[inStockName.ToUpper()].DodajNovuCijenu(inIimeStamp, inStockValue);
                    listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene.OrderBy(i => i.Key);
                 }
                 else
                     throw new StockExchangeException("Postoji cijena za taj datum!");
             }
         }
         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
             {
                 if (!listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene.ContainsKey(inTimeStamp))
                 {
                     return listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene[listaDionica[inStockName.ToUpper()].povijestCijeneDionice.DohvatiZadnjiDatum(inTimeStamp)];
                 }
                 else
                     return listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene[inTimeStamp];
             }
             else
                 throw new StockExchangeException("Dionica s tim imenom ne postoji!");
         }
         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica s takvim imenom ne postoji!");
             else
                 return listaDionica[inStockName.ToUpper()].pocetnaCijena;
         }
         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Dionica s takvim imenom ne postoji!");
             else
                 return listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene[listaDionica[inStockName.ToUpper()].povijestCijeneDionice.povijestCijene.Keys.Last()];
         }
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!inIndexType.Equals(IndexTypes.AVERAGE) && !inIndexType.Equals(IndexTypes.WEIGHTED))
                 throw new StockExchangeException("Neisprvan tip indeksa!");
             else if (IndexExists(inIndexName))
                 throw new StockExchangeException("Indeks s tim imenom vec postoji!");
             else
                 listaIndeksa.Add(inIndexName.ToUpper(), new Indeks(inIndexName.ToUpper(), inIndexType));

         }
         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Ne postoji dionica!");
             else if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Ne postoji indeks!");

             else if (listaDionica[inStockName.ToUpper()].ImaIndeks())
                 throw new StockExchangeException("Dionica ima drugi indeks!");

             else
             {
                 listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica.Add(inStockName.ToUpper());
                 listaDionica[inStockName.ToUpper()].DodajIndeks(inIndexName.ToUpper());
             }
         }
         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Ne postoji dionica!");
             else if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Ne postoji indeks!");

             else if (!listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica.Contains(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica nije u indeksu!");

             else
             {
                 listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica.Remove(inStockName.ToUpper());
                 listaDionica[inStockName.ToUpper()].MakniIndeks();
             }
         }
         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica.Contains(inStockName.ToUpper());
         }
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (NumberOfStocksInIndex(inIndexName).Equals(0))
                 throw new StockExchangeException("Indeks je prazan!");
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Ne postoji indeks!");
             if (listaIndeksa[inIndexName.ToUpper()].tipIndeksa.Equals(IndexTypes.WEIGHTED))
             {
                 decimal cijena = 0;
                 decimal totalnaVrijednost = 0;
                 foreach (string imeDionice in listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica)
                 {
                     cijena += (GetStockPrice(imeDionice, inTimeStamp) * GetStockPrice(imeDionice, inTimeStamp)) * listaDionica[imeDionice.ToUpper()].brojDionica;
                     totalnaVrijednost += GetStockPrice(imeDionice, inTimeStamp) * listaDionica[imeDionice.ToUpper()].brojDionica;
                 }
                 return Math.Round(cijena / totalnaVrijednost, 3);
             }
             else if (listaIndeksa[inIndexName.ToUpper()].tipIndeksa.Equals(IndexTypes.AVERAGE))
             {
                 decimal cijena = 0;
                 foreach (string imeDionice in listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica)
                 {
                     cijena += GetStockPrice(imeDionice, inTimeStamp);
                 }
                 return Math.Round(cijena / NumberOfStocksInIndex(inIndexName), 3);
             }
             throw new StockExchangeException("Error!!!!");
         }
         public bool IndexExists(string inIndexName)
         {
             return listaIndeksa.ContainsKey(inIndexName.ToUpper());
         }
         public int NumberOfIndices()
         {
             return listaIndeksa.Count;
         }
         public int NumberOfStocksInIndex(string inIndexName)
         {
             return listaIndeksa[inIndexName.ToUpper()].listaIndeksiranihDionica.Count();
         }
         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 listaPortfelja.Add(inPortfolioID, new Portfelj(inPortfolioID));
             else
                 throw new StockExchangeException("Postoji već takav portfelj!");
         }
         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Ne postoji dionica!");
             else if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ne postoji portfelj!");
             else if (numberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica ne smije biti negativan ili 0!");
             else if (listaDionica[inStockName.ToUpper()].NeDostupnaDionica(numberOfShares))
                 throw new StockExchangeException("Dionica je nedostupna tj. ne postoji!");
             else
             {
                 listaPortfelja[inPortfolioID.ToUpper()].DodajDionicu(inStockName.ToUpper(), numberOfShares);
                 listaDionica[inStockName.ToUpper()].DodajUPortfelj(inPortfolioID, numberOfShares);
             }
         }
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Ne postoji dionica!");
             else if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ne postoji portfelj!");
             else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
                 throw new StockExchangeException("Portfelj je izbrisan jer nema dionicu!");
             else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Dionica nije u protfelju!");
             else if (NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName) < numberOfShares)
                 throw new StockExchangeException("Izbacivanje više dionica u odnosu na portfelj,zabranjeno!");
             else
             {
                 if (NumberOfStocksInPortfolio(inPortfolioID).Equals(1) && NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName).Equals(0))
                     listaPortfelja.Remove(inPortfolioID);
                 listaPortfelja[inPortfolioID.ToUpper()].MakniDionicu(inStockName.ToUpper(), numberOfShares);
             }
         }
         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Ne postoji dionica!");
             else if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ne postoji portfelj!");
             else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
                 throw new StockExchangeException("Portfelj je izbrisan jer nema dionicu!");
             else if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Dionica nije u protfelju!");
             else
             {
                 if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
                     listaPortfelja.Remove(inPortfolioID);
                 listaPortfelja[inPortfolioID.ToUpper()].listaDionica.Remove(inStockName.ToUpper());
             }
         }
         public int NumberOfPortfolios()
         {
             return listaPortfelja.Count;
         }
         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return listaPortfelja[inPortfolioID].listaDionica.Keys.Count();
         }
         public bool PortfolioExists(string inPortfolioID)
         {
             return listaPortfelja.ContainsKey(inPortfolioID);
         }
         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return listaPortfelja[inPortfolioID].listaDionica.ContainsKey(inStockName);
         }
         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return listaPortfelja[inPortfolioID].listaDionica[inStockName.ToUpper()];
         }
         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ne postoji portfelj!");
             else if (NumberOfStocksInPortfolio(inPortfolioID).Equals(0))
             {
                 listaPortfelja.Remove(inPortfolioID);
                 throw new StockExchangeException("Portfelj je izbrisan jer nema dionicu!");
             }
             decimal vrijednost = 0;
             foreach (string imeDionice in listaPortfelja[inPortfolioID].listaDionica.Keys)
             {
                 vrijednost += GetStockPrice(imeDionice, timeStamp) * NumberOfSharesOfStockInPortfolio(inPortfolioID,imeDionice);
             }
             return vrijednost;
            
         }
         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
         #endregion
     }
}