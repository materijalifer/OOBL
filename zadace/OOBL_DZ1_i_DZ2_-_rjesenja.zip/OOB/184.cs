﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator_MC();
        }
    }
    public class Kalkulator_MC:ICalculator
    {
        int digitCounter;
        int comaCounter;

        bool negativeNumber;
        bool screenIsEmpty;
        bool binaryOperationEnabled;

        char currentBinaryOperator;
        char nullCharacter;
        char comaCharacter;

        string error;
        string nullString;
        string currentDisplayState;
        string newDisplayState;

        string resultString;
        double resultNumber;
        bool resultError;

        double currentUnaryNumber;
        double previousBinaryNumber;
        double currentBinaryNumber;

        string previousSaveString;

        public Kalkulator_MC()
        {
            digitCounter = 0;
            comaCounter = 0;

            resultError = false;
            negativeNumber = false;
            screenIsEmpty = false;
            binaryOperationEnabled = true;

            error = "-E-";
            nullString = "0";
            currentDisplayState = nullString;
            newDisplayState = nullString;

            previousSaveString = "0";

            comaCharacter = ',';
            nullCharacter = '0';
            currentBinaryOperator = nullCharacter;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayState;
        }

        public void Press(char pressedKey)
        {
            switch (pressedKey)
            {
                case '0':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '1':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '2':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '3':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '4':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '5':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '6':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '7':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '8':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '9':
                    {
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case '+':
                    {
                        BinaryOperation();
                        currentBinaryOperator = pressedKey;
                        break;
                    }
                case '-':
                    {
                        BinaryOperation();
                        currentBinaryOperator = pressedKey;
                        break;
                    }
                case '*':
                    {
                        BinaryOperation();
                        currentBinaryOperator = pressedKey;
                        break;
                    }
                case '/':
                    {
                        BinaryOperation();
                        currentBinaryOperator = pressedKey;
                        break;
                    }
                case '=':
                    {
                        binaryOperationEnabled = true;
                        BinaryOperation();
                        Equal();
                        currentBinaryOperator = nullCharacter;
                        break;
                    }
                case ',':
                    {
                        comaCounter++;
                        DisplaySymbol(pressedKey);
                        break;
                    }
                case 'M':
                    {
                        Minus();
                        break;
                    }
                case 'S':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'K':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'T':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'Q':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'R':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'I':
                    {
                        UnaryOperation(pressedKey);
                        break;
                    }
                case 'P':
                    {
                        Save();
                        break;
                    }
                case 'G':
                    {
                        Load();
                        break;
                    }
                case 'C':
                    {
                        ClearScreen();
                        break;
                    }
                case 'O':
                    {
                        Reset();
                        break;
                    }
                default:
                    {
                        DisplayString(error);
                        break;
                    }
            }
        }

        public void DisplaySymbol(char pressedKey)
        {
            if (digitCounter == 0)
            {
                if ((comaCounter == 0) && (pressedKey != nullCharacter))
                {
                    newDisplayState = new string(pressedKey, 1);
                }
                else if ((comaCounter == 1) && (pressedKey != nullCharacter))
                {
                    newDisplayState = currentDisplayState + pressedKey;
                }
                if (newDisplayState != nullString)
                {
                    digitCounter = 1;
                }
                else
                {
                    screenIsEmpty = true;
                }
            }
            else if ((digitCounter > 0) && (digitCounter <= 9))
            {
                if (pressedKey == comaCharacter)
                {
                    if (comaCounter == 1)
                    {
                        newDisplayState = currentDisplayState + pressedKey;
                    }
                }
                else
                {
                    newDisplayState = currentDisplayState + pressedKey;
                    digitCounter++;
                }
            }
            else if (digitCounter == 10) newDisplayState = currentDisplayState;
            DisplayString(newDisplayState);
        }

        public void DisplayString(string displayString) 
        {
            screenIsEmpty = false;
            binaryOperationEnabled = true;

            currentDisplayState = displayString;

            if ((currentDisplayState == "0") || (currentDisplayState == "-E-"))
            {
                screenIsEmpty = true;
                if (currentDisplayState == "-E-")
                {
                    binaryOperationEnabled = false;
                }
            }
        }

        public void Minus()
        {
            if (screenIsEmpty == false)
            {
                string previousString = GetCurrentDisplayState();
                string currentString = nullString;

                if (negativeNumber == false)
                {
                    currentString = "-" + previousString;
                    negativeNumber = true;
                }
                else if (negativeNumber == true)
                {
                    currentString = previousString.Remove(0, 1);
                    negativeNumber = false;
                }

                DisplayString(currentString);
            }
        }

        public double CurrentStringToNumber()
        {
            string currentString = GetCurrentDisplayState();
            double currentNumber = Convert.ToDouble(currentString);
            ResetValues();
            return currentNumber;
        }

        public void BinaryOperation()
        {
            if (binaryOperationEnabled == true)
            {
                previousBinaryNumber = currentBinaryNumber;
                currentBinaryNumber = CurrentStringToNumber();
                switch (currentBinaryOperator)
                {
                    case '+':
                        {
                            resultNumber = previousBinaryNumber + currentBinaryNumber;
                            break;
                        }
                    case '-':
                        {
                            resultNumber = previousBinaryNumber - currentBinaryNumber;
                            break;
                        }
                    case '*':
                        {
                            resultNumber = previousBinaryNumber * currentBinaryNumber;
                            break;
                        }
                    case '/':
                        {
                            resultNumber = previousBinaryNumber / currentBinaryNumber;
                            break;
                        }
                    default:
                        {
                            resultNumber = currentBinaryNumber;
                            break;
                        }
                }
                CheckResult();
                currentBinaryNumber = resultNumber;
                string temp = Convert.ToString(resultNumber);
                if (currentBinaryNumber % 1 == 0) currentBinaryNumber = Convert.ToInt32(temp);
                binaryOperationEnabled = false;
            }
        }

        public void UnaryOperation(char currentUnaryOperator)
        {
            currentUnaryNumber = CurrentStringToNumber();
            switch (currentUnaryOperator)
            {
                case 'S':
                    {
                        resultNumber = Math.Sin(currentUnaryNumber);
                        break;
                    }
                case 'K':
                    {
                        resultNumber = Math.Cos(currentUnaryNumber);
                        break;
                    }
                case 'T':
                    {
                        resultNumber = Math.Tan(currentUnaryNumber);
                        break;
                    }
                case 'Q':
                    {
                        resultNumber = currentUnaryNumber * currentUnaryNumber;
                        break;
                    }
                case 'R':
                    {
                        if (currentUnaryNumber >= 0)
                        {
                            resultNumber = Math.Sqrt(currentUnaryNumber);
                        }
                        else
                        {
                            resultError = true;
                        }
                        break;
                    }
                case 'I':
                    {
                        if (currentUnaryNumber != 0)
                        {
                            resultNumber = 1 / currentUnaryNumber;
                        }
                        else
                        {
                            resultError = true;
                        }
                        break;
                    }
                default:
                    {
                        resultNumber = currentUnaryNumber;
                        break;
                    }
            }
            CheckResult();
            currentUnaryNumber = resultNumber;
            Equal();
        }
        
        public void CheckResult()
        {
            int tempComaIndicator = 0;
            string tempResultString = Convert.ToString(resultNumber);
            if (tempResultString.Contains(","))
            {
                tempComaIndicator = 1;
            }
            string[] tempStringArray = tempResultString.Split(',');
            tempResultString = tempStringArray[0];
            if (tempResultString.Contains("-"))
            {
                tempResultString = tempResultString.Remove(0, 1);
            }
            if (tempComaIndicator == 0)
            {
                int tempFirstStringLength = tempResultString.Length;
                if (tempFirstStringLength > 10)
                {
                    resultError = true;
                }
            }
            else
            {
                int tempSecondStringLength = tempResultString.Length;
                if ((tempSecondStringLength < 11) && (tempSecondStringLength > 0))
                {
                    int decimalDigitNumber = 10 - tempSecondStringLength;
                    resultNumber = Math.Round(resultNumber, decimalDigitNumber);
                }
                else
                {
                    resultError = true;
                }
            }
        }

        public void Equal()
        {
            if (resultError == false)
            {
                resultString = Convert.ToString(resultNumber);
                DisplayString(resultString);
            }
            else
            {
                DisplayString(error);
                resultError = false;
            }
        }

        string savedDisplayState;

        public void Save()
        {
            savedDisplayState = GetCurrentDisplayState();
        }

        public void Load()
        {
            DisplayString(savedDisplayState);
        }

        public void ClearScreen()
        {
            currentDisplayState = "0";
            ResetValues();
        }

        public void Reset()
        {
            ClearScreen();
            savedDisplayState = "";
            currentBinaryOperator = nullCharacter;
        }

        public void ResetValues()
        {
            digitCounter = 0;
            comaCounter = 0;
            negativeNumber = false;
        }

    }
}
