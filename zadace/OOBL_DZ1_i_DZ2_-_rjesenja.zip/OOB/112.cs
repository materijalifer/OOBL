﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock{
        string stockName;
        long inNumberOfShares;

        public string Name
        {
            get { return stockName; }
        }

        public long NumberOfShares
        {
            get { return inNumberOfShares; }
        }

        SortedDictionary<DateTime, Decimal> prices = new SortedDictionary<DateTime, Decimal>();

        public Stock(string inSTockName, long numberOfShares, Decimal initialPrice, DateTime timestmap)
        {
            this.stockName = inSTockName;
            if(numberOfShares <=0)
              throw new StockExchangeException("Broj dionica premali");
            this.inNumberOfShares = numberOfShares;
            if (initialPrice <= 0)
                throw new StockExchangeException("Cijena dionice mora biti veca od nula");
            prices.Add(timestmap, initialPrice);
        }

        public void setPrice(Decimal price, DateTime timestmap){
            if (price <= 0)
                throw new StockExchangeException("Cijena dionice mora biti veca od nula");
            prices.Add(timestmap, price);
        }
        public Decimal getPrice(DateTime timestmp)
        {
            DateTime old = prices.Keys.ElementAt(0);

            if (DateTime.Compare(timestmp,old)< 0) //return 0; nije definirano vrati nulu ili
            throw new StockExchangeException("Cijena dionice nije definirana"); //baci exception
            foreach (DateTime d in prices.Keys)
            {
                if (timestmp.Equals(d)) return prices[d];


                if (DateTime.Compare(d,timestmp) > 0) return prices[old];
                
                old = d;
            }
            return prices[old];
        }
         public Decimal getLastPrice()
        {
            DateTime old = prices.Keys.ElementAt(prices.Keys.Count - 1);
            return prices[old];
        }
         public Decimal getInitialPrice()
        {
            DateTime old = prices.Keys.ElementAt(0);
            return prices[old];
        }
    }


    public class Index
    {
        string name;
        IndexTypes type;

        List<String> stocks = new List<string>();

        public string Name
        {
            get { return name; }
        }

        public Index(string n, IndexTypes t)
        {
            this.name = n;
            if (t != IndexTypes.AVERAGE && t != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Krivi tip indeksa");
            this.type = t;
        }

        public void addStock(string name)
        {
            if(stocks.Contains(name))
                throw new StockExchangeException("Postoji vec ta dionica u indeksu");
            stocks.Add(name);
        }

        public void removeStock(string name)
        {
            if (!stocks.Contains(name))
                throw new StockExchangeException("Ne postoji vec ta dionica u indeksu");
            stocks.Remove(name);
        }

        public bool isStockInIndex(string name)
        {
            return stocks.Contains(name);
        }
        public int numberOfStocks()
        {
            return stocks.Count();
        }
        public Decimal calculateIndexValue(DateTime stamp, Dictionary<string,Stock> stocks)
        {
            if (type == IndexTypes.AVERAGE)
            {
                Decimal sum = 0;
                int i = 0;
                foreach (string s in stocks.Keys)
                {
                    sum += stocks[s].getPrice(stamp);
                    i++;
                }

                return Decimal.Round(sum,3);

            }
            else if (type == IndexTypes.WEIGHTED)
            {
                Decimal ukupna = 0;
                
                foreach (string s in stocks.Keys)
                {
                    ukupna += stocks[s].getPrice(stamp)*stocks[s].NumberOfShares;
                    
                }
                Decimal sum = 0;
                foreach (string s in stocks.Keys)
                {
                    sum += stocks[s].getPrice(stamp) * stocks[s].NumberOfShares / ukupna * stocks[s].getPrice(stamp);
                    
                }

                return Decimal.Round(sum,3);;


            }
            return 0;
        }
    }

    public class Portfolio
    {
        string id;

        Dictionary<string, long> stocks = new Dictionary<string, long>();

        public string PortfolioID{
            get { return id; }
        }

        public Portfolio(string PortfolioID)
        {
            id = PortfolioID;
        }

        public bool isStockInPortfolio(string name)
        {
            return stocks.ContainsKey(name);
        }
        public int numberOfStocks()
        {
            return stocks.Count();
        }

        public void addStock(string stockname,int numberOfShares){
            if(numberOfShares < 0) 
               throw new StockExchangeException("Broj dionica mora biti veci od nule");
            if (stocks.ContainsKey(stockname))
            {
                
                stocks[stockname] = stocks[stockname] + numberOfShares; ;
                
            }
            else
                stocks.Add(stockname, numberOfShares);

        }

        public void removeStock(string stockname, int numberOfShares)
        {
            if (numberOfShares < 0)
                throw new StockExchangeException("Broj dionica mora biti veci od nule");
            if (!stocks.ContainsKey(stockname))
                throw new StockExchangeException("Ne postoji ta dionica u portfelju");
            if (stocks[stockname] - numberOfShares < 0)
                throw new StockExchangeException("Nemozes maknuti vise dionica neg imas");
            if (stocks[stockname] - numberOfShares == 0)
            {
                stocks.Remove(stockname);
                return;
            }
            
            stocks[stockname]=stocks[stockname] - numberOfShares;
            
        }
        public void removeStock(string stockname)
        {
            if (!stocks.ContainsKey(stockname))
                throw new StockExchangeException("Ne postoji ta dionica u portfelju");
         
                stocks.Remove(stockname);
                
         
            
        }

        public long numberOfSharesOfStock(string name)
        {
            if (!stocks.ContainsKey(name)) return 0;
            return stocks[name];
        }

        public Decimal getPortfolioValue(DateTime timestamp, Dictionary<string,Stock> s){
            Decimal sum = 0;
            foreach (string st in stocks.Keys)
                sum += s[st].getPrice(timestamp) * stocks[st];
            return Decimal.Round(sum, 3);
        }

        public Decimal getPortfolioValue(int year,int month, Dictionary<string, Stock> s)
        {
            DateTime start = new DateTime(year, month, 1, 0, 0, 0);
            DateTime end = new DateTime(year, month+1, 1, 23, 59, 59,99);
            end = end.AddDays(-1);

            Decimal sumStart = 0;
            Decimal sumEnd = 0;
            foreach (string st in stocks.Keys)
            {
                sumStart += s[st].getPrice(start) * stocks[st];
                sumEnd += s[st].getPrice(end) * stocks[st];
            }
            
            
            return Decimal.Round((sumEnd-sumStart)/sumStart*100, 3);


            
        }
    }


    public class Repository
    {
        Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();

        Dictionary<string, Index> index = new Dictionary<string, Index>();

        Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

        public void createNewStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            inStockName = inStockName.ToUpper();

            if (stocks.ContainsKey(inStockName))
            {
                throw new StockExchangeException("Dionica vec postoji");
            }

            Stock s = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stocks.Add(s.Name, s);
        }
        public void removeStock(string name){
            if(stocks.ContainsKey(name.ToUpper()))
                stocks.Remove(name.ToUpper());
            else
                 
                throw new StockExchangeException("Nemozes obrisati nepostojecu dionicu");
            foreach (Index i in index.Values)
            {
                if(i.isStockInIndex(name.ToUpper()))
                    i.removeStock(name.ToUpper());
            }
            foreach (Portfolio i in portfolios.Values)
            {
                if (i.isStockInPortfolio(name.ToUpper()))
                    i.removeStock(name.ToUpper());
            }
        }
        public bool stockExists(string name)
        {
            return stocks.ContainsKey(name.ToUpper());
        }

        public bool indexExists(string name)
        {
            return index.ContainsKey(name.ToUpper());
        }

        public bool portfolioExists(string name)
        {
            return portfolios.ContainsKey(name);
        }


        public int stockCount()
        {
            return stocks.Count();
        }

        public int indexCount()
        {
            return index.Count();
        }

        public int portfolioCount()
        {
            return portfolios.Count();
        }

        public void stockSetPrice(string name, DateTime date,decimal price)

        {
            if (!stockExists(name)) throw new StockExchangeException("Ne postoji ta dionica");
            Stock s = stocks[name.ToUpper()];
            s.setPrice(price, date);  
        }
        public decimal stockGetPrice(string name, DateTime date)
        {
            if (!stockExists(name.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            Stock s = stocks[name.ToUpper()];
            return s.getPrice(date); 
        }
        public decimal stockGetInitialPrice(string name)
        {
            if (!stockExists(name.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            Stock s = stocks[name.ToUpper()];
            return s.getInitialPrice();
        }
        public decimal stockGetLastPrice(string name)
        {
            if (!stockExists(name.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            Stock s = stocks[name.ToUpper()];
            return s.getLastPrice();
        }



        public void createNewIndex(string indexname, IndexTypes type)
        {
            indexname = indexname.ToUpper();

            if (index.ContainsKey(indexname))
            {
                throw new StockExchangeException("Index vec postoji");
            }
            Index i = new Index(indexname, type);
            
            index.Add(i.Name, i);
        }

        public void indexAddStock(string indexname, string stockname)
        {
            if (!stockExists(stockname.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            if (!indexExists(indexname.ToUpper())) throw new StockExchangeException("Ne postoji taj index");
            index[indexname].addStock(stockname);
        }

        public void indexRemoveStock(string indexname, string stockname)
        {
            if (!stockExists(stockname.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            if (!indexExists(indexname.ToUpper())) throw new StockExchangeException("Ne postoji taj index");
            index[indexname.ToUpper()].removeStock(stockname.ToUpper());
        }

        public bool indexIsStockPartofIndex(string indexname, string stockname)
        {
            if (!stockExists(stockname.ToUpper())) throw new StockExchangeException("Ne postoji ta dionica");
            if (!indexExists(indexname.ToUpper())) throw new StockExchangeException("Ne postoji taj index");
            return index[indexname.ToUpper()].isStockInIndex(stockname);
        }

        public decimal indexGetValue(string indexname,DateTime timestamp)
        {
            if (!indexExists(indexname.ToUpper())) throw new StockExchangeException("Ne postoji taj index");
            return index[indexname.ToUpper()].calculateIndexValue(timestamp, stocks);
        }

        public int indexNumberOfStocks(string indexname)
        {
            if (!indexExists(indexname.ToUpper())) throw new StockExchangeException("Ne postoji taj index");
            return index[indexname.ToUpper()].numberOfStocks();
        }

        public void createNewPortfolio(string portfolioID)
        {
            

            if (portfolios.ContainsKey(portfolioID))
            {
                throw new StockExchangeException("Portfolio vec postoji");
            }

            Portfolio p = new Portfolio(portfolioID);
            portfolios.Add(p.PortfolioID, p);
        }

        public long portfolioFreeSharesOnTheMarket(string shareName){
            string name = shareName.ToUpper();
            if (!stockExists(name)) throw new StockExchangeException("Ne postoji ta dionica");
            long sum = 0;
            foreach (Portfolio p in portfolios.Values)
                sum += p.numberOfSharesOfStock(name);
            return stocks[name].NumberOfShares-sum;
        }

        public void portfolioAddStock(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string name = inStockName.ToUpper();
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            if (!stockExists(name)) throw new StockExchangeException("Ne postoji ta dionica");

            if(portfolioFreeSharesOnTheMarket(name) < numberOfShares)
                throw new StockExchangeException("Nedovoljan broj dionica na burzi");

            portfolios[inPortfolioID].addStock(name, numberOfShares);
        }

        public void portfolioRemoveStock(string inPortfolioID, string inStockName, int numberOfShares){
            string stockname = inStockName.ToUpper();
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            if (!stockExists(stockname)) throw new StockExchangeException("Ne postoji ta dionica");
            portfolios[inPortfolioID].removeStock(stockname, numberOfShares);
        }
        public void portfolioRemoveStock(string inPortfolioID, string inStockName)
        {
            string stockname = inStockName.ToUpper();
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            if (!stockExists(stockname)) throw new StockExchangeException("Ne postoji ta dionica");
            portfolios[inPortfolioID].removeStock(stockname);
        }

        public int portfolioNumberOfstocks(string inPortfolioID)
        {
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");

            return portfolios[inPortfolioID].numberOfStocks();

        }

        public bool portfolioIsStockPartOf(string inPortfolioID, string stockName)
        {
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            return portfolios[inPortfolioID].isStockInPortfolio(stockName.ToUpper());
        }

        public int portfolioNumberOfSharesOfStockIn(string inPortfolioID, string stockName)
        {
            string stockname = stockName.ToUpper();
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            if (!stockExists(stockname)) throw new StockExchangeException("Ne postoji ta dionica");
            return (int)portfolios[inPortfolioID].numberOfSharesOfStock(stockname);
        }
        public Decimal portfolioGetValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            return portfolios[inPortfolioID].getPortfolioValue(timeStamp,stocks);
        }
        public Decimal portfolioGetPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!portfolios.ContainsKey(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji");
            return portfolios[inPortfolioID].getPortfolioValue(Year,Month,stocks);
        }
        
    }


    public class StockExchange : IStockExchange
    {

        Repository stocks = new Repository();
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            stocks.createNewStock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
        }

        public void DelistStock(string inStockName)
        {
            stocks.removeStock(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return stocks.stockExists(inStockName);
        }

        public int NumberOfStocks()
        {
            return stocks.stockCount();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            stocks.stockSetPrice(inStockName, inIimeStamp, inStockValue);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return stocks.stockGetPrice(inStockName, inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return stocks.stockGetInitialPrice(inStockName);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return stocks.stockGetLastPrice(inStockName);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            stocks.createNewIndex(inIndexName, inIndexType);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            stocks.indexAddStock(inIndexName, inStockName);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            stocks.indexRemoveStock(inIndexName, inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return stocks.indexIsStockPartofIndex(inIndexName, inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return stocks.indexGetValue(inIndexName, inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return stocks.indexExists(inIndexName);
        }

        public int NumberOfIndices()
        {
            return stocks.indexCount();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return stocks.indexNumberOfStocks(inIndexName);
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            stocks.createNewPortfolio(inPortfolioID);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            stocks.portfolioAddStock(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            stocks.portfolioRemoveStock(inPortfolioID, inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            stocks.portfolioRemoveStock(inPortfolioID, inStockName);
        }

        public int NumberOfPortfolios()
        {
            return stocks.portfolioCount();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return stocks.portfolioNumberOfstocks(inPortfolioID);
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return stocks.portfolioExists(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return stocks.portfolioIsStockPartOf(inPortfolioID, inStockName);
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return stocks.portfolioNumberOfSharesOfStockIn(inPortfolioID, inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return stocks.portfolioGetValue(inPortfolioID, timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return stocks.portfolioGetPercentChangeInValueForMonth(inPortfolioID, Year, Month);
        }
    }
}
