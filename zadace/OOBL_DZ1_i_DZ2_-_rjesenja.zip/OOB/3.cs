﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private bool greska;
        private bool negativanPrikaz;
        private bool decimalanPrikaz;
        private bool traziSeDrugiOperand;
        private string prikaz;
        private char zadnjiOperator;
        private double operand1;
        private double operand2;
        private double rezultat;
        private char zadnjiZnak;
        #region memorija
        private string memorija;
        private bool decimalanMemorija;
        private bool negativanMemorija;
        #endregion

        public Kalkulator()
        {
            resetirajKalkulator();
        }

        private double spremiOperand()
        {
            string temp;
            if (negativanPrikaz)
            {
                temp = "-" + prikaz;
            }
            else
            {
                temp = prikaz;
            }
            return double.Parse(temp);
        }
        private double zaokruziRezultat(double broj)
        {
            string zapisBroja = broj.ToString();
            int indeksDecimale = zapisBroja.IndexOf(',');
            if (broj >= 0)
            {
                return Math.Round(Convert.ToDouble(zapisBroja.ToString()), 10 - indeksDecimale, MidpointRounding.AwayFromZero);
            }
            else
            {
                return Math.Round(Convert.ToDouble(zapisBroja.ToString()), 10 - indeksDecimale + 1, MidpointRounding.AwayFromZero);
            }
        }
        private bool provjeriRezultat(double broj)
        {
            string zapisBroja = broj.ToString();
            if (zapisBroja.IndexOf(',') == -1) // ako je cijeli broj
            {
                if (zapisBroja[0] == '-' && zapisBroja.Length > 11 || zapisBroja[0] != '-' && zapisBroja.Length > 10)
                {
                    greska = true;
                    return false;
                }
                else
                {
                    rezultat = broj;
                    return true;
                }
            }
            else // ako je decimalni broj
            {
                if (zapisBroja[0] == '-' && zapisBroja.IndexOf(',') > 12 || zapisBroja[0] != '-' && zapisBroja.IndexOf(',') > 11)
                {
                    greska = true;
                    return false;
                }
                else
                {
                    if (zapisBroja[0] == '-' && zapisBroja.Length > 12 || zapisBroja[0] != '-' && zapisBroja.Length > 11)
                    {
                        rezultat = zaokruziRezultat(broj);
                        return true;
                    }
                    else
                    {
                        rezultat = broj;
                        return true;
                    }
                }
            }
        }
        private void prikaziRezultat()
        {
            if (rezultat >= 0)
            {
                prikaz = rezultat.ToString();
                negativanPrikaz = false;
            }
            else
            {
                prikaz = (-1 * rezultat).ToString();
                negativanPrikaz = true;
            }
            if (prikaz.IndexOf(',') == -1)
            {
                decimalanPrikaz = true;
            }
        }

        private bool provjeriKorijen(double operand)
        {
            if (operand >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool provjeriDjeljivost(double djelitelj)
        {
            if (djelitelj == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private bool provjeriTangens(double operand)
        {
            if (operand == Math.Round(Math.PI / 2, 9, MidpointRounding.AwayFromZero))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        #region Binarne funkcije
        private double odaberiFunkciju(char bOperator)
        {
            switch (bOperator)
            {
                case '+':
                    return Zbrajanje();
                case '-':
                    return Oduzimanje();
                case '*':
                    return Mnozenje();
                case '/':
                    return Dijeljenje();
                default:
                    return 0;
            }
        }
        private double Zbrajanje()
        {
            return operand1 + operand2;
        }
        private double Oduzimanje()
        {
            return operand1 - operand2;
        }
        private double Mnozenje()
        {
            return operand1 * operand2;
        }
        private double Dijeljenje()
        {
            return operand1 / operand2;
        }
        #endregion

        #region Obrada ulaznih znakova
        private void obradiZnamenku(char znamenka)
        {
            if (prikaz.Length == 11 && decimalanPrikaz || prikaz.Length == 10 && !decimalanPrikaz)
            {
                if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                {
                    prikaz = znamenka.ToString();
                    decimalanPrikaz = false;
                    zadnjiZnak = znamenka;
                    negativanPrikaz = false;
                }
                else
                { }
            }
            else
            {
                if (prikaz == "0")
                {
                    prikaz = znamenka.ToString();
                    zadnjiZnak = znamenka;
                }
                else
                {
                    if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                    {
                        prikaz = znamenka.ToString();
                        decimalanPrikaz = false;
                        zadnjiZnak = znamenka;
                        negativanPrikaz = false;
                    }
                    else
                    {
                        prikaz += znamenka;
                        zadnjiZnak = znamenka;
                    }
                }
            }
        }
        private void obradiZarez()
        {
            if (zadnjiZnak >= '0' && zadnjiZnak <= '9')
            {
                if (!decimalanPrikaz)
                {
                    prikaz += ',';
                    zadnjiZnak = ',';
                    decimalanPrikaz = true;
                }
            }
            else if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
            {
                if (!decimalanPrikaz)
                {
                    prikaz = "0,";
                    zadnjiZnak = ',';
                    decimalanPrikaz = true;
                }
            }
        }
        private void obradiUnarni(char uOperator)
        {
            switch (uOperator)
            {
                case 'M':
                    negativanPrikaz = !negativanPrikaz;
                    break;
                case 'S':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        if (provjeriRezultat(sinus(operand1)))
                        {
                            operand1 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    else
                    {
                        operand2 = spremiOperand();
                        if (provjeriRezultat(sinus(operand2)))
                        {
                            operand2 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    break;
                case 'K':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        if (provjeriRezultat(kosinus(operand1)))
                        {
                            operand1 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    else
                    {
                        operand2 = spremiOperand();
                        if (provjeriRezultat(kosinus(operand2)))
                        {
                            operand2 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    break;
                case 'T':
                    if (provjeriTangens(spremiOperand()))
                    {
                        if (!traziSeDrugiOperand)
                        {
                            operand1 = spremiOperand();
                            if (provjeriRezultat(tangens(operand1)))
                            {
                                operand1 = rezultat;
                                prikaziRezultat();
                            }
                        }
                        else
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(tangens(operand2)))
                            {
                                operand2 = rezultat;
                                prikaziRezultat();
                            }
                        }
                    }
                    else
                    {
                        greska = true;
                    }
                    break;
                case 'Q':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        if (provjeriRezultat(kvadriraj(operand1)))
                        {
                            operand1 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    else
                    {
                        operand2 = spremiOperand();
                        if (provjeriRezultat(kvadriraj(operand2)))
                        {
                            operand2 = rezultat;
                            prikaziRezultat();
                        }
                    }
                    break;
                case 'R':
                    if (provjeriKorijen(spremiOperand()))
                    {
                        if (!traziSeDrugiOperand)
                        {
                            operand1 = spremiOperand();
                            if (provjeriRezultat(korjenuj(operand1)))
                            {
                                operand1 = rezultat;
                                prikaziRezultat();
                            }
                        }
                        else
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(korjenuj(operand2)))
                            {
                                operand2 = rezultat;
                                prikaziRezultat();
                            }
                        }
                    }
                    else
                    {
                        greska = true;
                    }
                    break;
                case 'I':
                    if (provjeriDjeljivost(spremiOperand()))
                    {
                        if (!traziSeDrugiOperand)
                        {
                            operand1 = spremiOperand();
                            if (provjeriRezultat(invertiraj(operand1)))
                            {
                                operand1 = rezultat;
                                prikaziRezultat();
                            }
                        }
                        else
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(invertiraj(operand2)))
                            {
                                operand2 = rezultat;
                                prikaziRezultat();
                            }
                        }
                    }
                    else
                    {
                        greska = true;
                    }
                    break;
                case 'P':
                    spremiPrikaz();
                    break;
                case 'G':
                    dohvatiPrikaz();
                    break;
                case 'C':
                    obrisiPrikaz();
                    break;
                case 'O':
                    resetirajKalkulator();
                    break;
                default:
                    break;
            }
        }
        private void obradiBinarni(char bOperator)
        {
            switch (bOperator)
            {
                case '+':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        zadnjiZnak = '+';
                        zadnjiOperator = '+';
                        negativanPrikaz = false;
                        
                        traziSeDrugiOperand = true;
                    }
                    else
                    {
                        if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                        {
                            zadnjiZnak = '+';
                            zadnjiOperator = '+';
                        }
                        else if (zadnjiZnak >= '0' && zadnjiZnak <= '9')
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(odaberiFunkciju(zadnjiOperator)))
                            {
                                operand1 = rezultat;
                                zadnjiOperator = '+';
                                zadnjiZnak = '+';
                                negativanPrikaz = false;
                            }
                        }
                    }
                    break;
                case '-':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        zadnjiZnak = '-';
                        zadnjiOperator = '-';
                        negativanPrikaz = false;
                        traziSeDrugiOperand = true;
                    }
                    else
                    {
                        if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                        {
                            zadnjiZnak = '-';
                            zadnjiOperator = '-';
                        }
                        else if (zadnjiZnak >= '0' && zadnjiZnak <= '9')
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(odaberiFunkciju(zadnjiOperator)))
                            {
                                operand1 = rezultat;
                                zadnjiOperator = '-';
                                zadnjiZnak = '-';
                                negativanPrikaz = false;
                            }
                        }
                    }
                    break;
                case '*':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        zadnjiZnak = '*';
                        zadnjiOperator = '*';
                        negativanPrikaz = false;
                        traziSeDrugiOperand = true;
                    }
                    else
                    {
                        if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                        {
                            zadnjiZnak = '*';
                            zadnjiOperator = '*';
                        }
                        else if (zadnjiZnak >= '0' && zadnjiZnak <= '9')
                        {
                            operand2 = spremiOperand();
                            if (provjeriRezultat(odaberiFunkciju(zadnjiOperator)))
                            {
                                operand1 = rezultat;
                                zadnjiOperator = '*';
                                zadnjiZnak = '*';
                                negativanPrikaz = false;
                            }
                        }
                    }
                    break;
                case '/':
                    if (!traziSeDrugiOperand)
                    {
                        operand1 = spremiOperand();
                        zadnjiZnak = '/';
                        zadnjiOperator = '/';
                        negativanPrikaz = false;
                        traziSeDrugiOperand = true;
                    }
                    else
                    {
                        if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                        {
                            zadnjiZnak = '/';
                            zadnjiOperator = '/';
                        }
                        else if (zadnjiZnak >= '0' && zadnjiZnak <= '9')
                        {
                            if (provjeriDjeljivost(spremiOperand()))
                            {
                                operand2 = spremiOperand();
                                if (provjeriRezultat(odaberiFunkciju(zadnjiOperator)))
                                {
                                    operand1 = rezultat;
                                    zadnjiOperator = '/';
                                    zadnjiZnak = '/';
                                    negativanPrikaz = false;
                                }
                            }
                            else
                            {
                                greska = true;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        private void obradiJednako()
        {
            if (!traziSeDrugiOperand)
            {
                if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                {
                    operand2 = operand1;
                    if (provjeriRezultat(odaberiFunkciju(zadnjiZnak)))
                    {
                        operand1 = rezultat;
                        prikaziRezultat();
                    }
                    else
                    {
                        greska = true;
                    }
                }
                else
                {
                    operand1 = spremiOperand();
                    rezultat = operand1;
                    prikaziRezultat();
                }
            }
            else
            {
                operand2 = spremiOperand();
                traziSeDrugiOperand = false;
                if (provjeriRezultat(odaberiFunkciju(zadnjiOperator)))
                {
                    prikaziRezultat();
                }
                else
                {
                    greska = true;
                }
            }
        }
        #endregion

        #region Trigonometrija
        private double sinus(double operand)
        {
            return Math.Sin(operand);
        }
        private double kosinus(double operand)
        {
            return Math.Cos(operand);
        }
        private double tangens(double operand)
        {
            return Math.Tan(operand);
        }
        private double kvadriraj(double operand)
        {
            return Math.Pow(operand,2);
        }
        private double korjenuj(double operand)
        {
            return Math.Sqrt(operand);
        }
        private double invertiraj(double operand)
        {
            return 1 / operand;
        }
        #endregion

        #region rad s memorijom, prikazom
        private void resetirajKalkulator()
        {
            prikaz = "0";
            zadnjiZnak = '0';
            greska = false;
            negativanPrikaz = false;
            decimalanPrikaz = false;
            traziSeDrugiOperand = false;

            memorija = "0";
            negativanMemorija = false;
            decimalanMemorija = false;
        }
        private void obrisiPrikaz()
        {
            prikaz = "0";
            negativanPrikaz = false;
            decimalanPrikaz = false; 
        }
        private void spremiPrikaz()
        {
            memorija = prikaz;
            decimalanMemorija = decimalanPrikaz;
            negativanMemorija = negativanPrikaz;
        }
        private void dohvatiPrikaz()
        {
            prikaz = memorija;
            negativanPrikaz = negativanMemorija;
            decimalanPrikaz = decimalanMemorija;
        }
        #endregion

        #region Za testiranje
        public void Press(char inPressedDigit)
        {
            if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                obradiZnamenku(inPressedDigit);
            }
            else if (inPressedDigit == ',')
            {
                obradiZarez();
            }
            else if (inPressedDigit >= 'A' && inPressedDigit <= 'Z')
            {
                obradiUnarni(inPressedDigit);
            }
            else if (inPressedDigit == '=')
            {
                obradiJednako();
            }
            else
            {
                obradiBinarni(inPressedDigit);
            }
        }
        public string GetCurrentDisplayState()
        {
            if (greska)
            {
                greska = false;
                return "-E-";
            }
            else
            {
                if (zadnjiZnak == '+' || zadnjiZnak == '-' || zadnjiZnak == '*' || zadnjiZnak == '/')
                {
                    return  prikaz.ToString();
                }
                else
                {
                    return spremiOperand().ToString();
                }
            }
        }
        #endregion
    }


}
