﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {

         private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
         private Dictionary<string, Index> indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>(); 


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {

             if (inNumberOfShares <= 0 || inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Cijena/BrojDionica su manji ili jednaki 0!");
             }

             string _name = inStockName.ToLower();
             if (stocks.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 stocks.Add(inStockName.ToLower(), new Stock(inStockName.ToLower(), inNumberOfShares, inTimeStamp, inInitialPrice));
             }
             
         }

         public void DelistStock(string inStockName)
         {
             string _name = inStockName.ToLower();
             if (StockExists(_name))
             {
                 stocks.Remove(_name);
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }

             foreach (string index in indices.Keys)
             {
                 if (indices[index].containsStock(inStockName.ToLower()))
                 {
                     indices[index].removeStock(inStockName.ToLower());
                 }

                 
             }

             foreach (string portfolio in portfolios.Keys)
             {
                 if (portfolios[portfolio].containsStock(inStockName.ToLower()))
                 {
                     portfolios[portfolio].removeStock(inStockName.ToLower());
                 }
                 
             }
         }

         public bool StockExists(string inStockName)
         {
             string _name = inStockName.ToLower();

             if (stocks.ContainsKey(_name))
             {
                 return true;
             }
             else
             {
                 return false;
             }
             
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 stocks[inStockName.ToLower()].setPrice(inIimeStamp, inStockValue);
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 return stocks[inStockName.ToLower()].getStockPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 return stocks[inStockName.ToLower()].getInitialPrice();
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName.ToLower()))
             {
                 return stocks[inStockName.ToLower()].getLastPrice();
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName.ToLower()))
             {
                 throw  new StockExchangeException("Index vec postoji!");
             }
             else if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Nepoznat tip!");
             }
             else
             {
                 indices.Add(inIndexName.ToLower(), new Index(inIndexName.ToLower(), inIndexType));
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index pod imenom ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw  new StockExchangeException("Dionica pod imenom ne postoji!");
             }
             else
             {
                 indices[inIndexName.ToLower()].addStock(inStockName.ToLower(), stocks[inStockName.ToLower()]);
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index pod imenom ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica pod imenom ne postoji!");
             }
             else
             {
                 indices[inIndexName.ToLower()].removeStock(inStockName.ToLower());
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index pod imenom ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica pod imenom ne postoji!");
             }
             else
             {
                 return indices[inIndexName.ToLower()].containsStock(inStockName.ToLower());
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index pod imenom ne postoji");
             }

             if (indices[inIndexName.ToLower()].numberOfStocks() == 0)
             {
                 return 0;
             }

             return Math.Round(indices[inIndexName.ToLower()].getValue(inTimeStamp), 3);
         }

         public bool IndexExists(string inIndexName)
         {
             if (indices.ContainsKey(inIndexName.ToLower()))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index pod imenom ne postoji!");
             }
             else
             {
                 return indices[inIndexName.ToLower()].numberOfStocks();
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio vec postoji!");
             }
             else
             {
                 portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
             
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica ne može biti manji od 1!");
             }
             else if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio ne postoji!");
             }
             if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 long currentNumber = NumberOfSharesAtStockExchange(inStockName.ToLower());
                 long totalNumber = stocks[inStockName.ToLower()].returnNumberOfShares();

                 if ((currentNumber + numberOfShares) > totalNumber)
                 {
                     throw new StockExchangeException("Nedozvoljen broj dionica!");
                 }

                 portfolios[inPortfolioID].addStock(inStockName.ToLower(), numberOfShares);
                 
                 
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 portfolios[inPortfolioID].removeStock(inStockName.ToLower(), numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 portfolios[inPortfolioID].removeStock(inStockName.ToLower());
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji!");
             }
             else
             {
                 return portfolios[inPortfolioID].numberOfStocks();
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (portfolios.ContainsKey(inPortfolioID))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 return portfolios[inPortfolioID].containsStock(inStockName.ToLower());
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio ne postoji!");
             }
             else if (!StockExists(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 return portfolios[inPortfolioID].numberOfShares(inStockName.ToLower());
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji!");
             }
             else
             {
                 Dictionary<string, int> portfolioStocks = new Dictionary<string, int>(portfolios[inPortfolioID].returnStocks());
                 List<string> ownedStocks = new List<string>(portfolioStocks.Keys);
                 Decimal value = 0;

                 foreach (string ownedStock in ownedStocks)
                 {
                     value += portfolioStocks[ownedStock]*stocks[ownedStock].getStockPrice(timeStamp);
                 }

                 return value;
             }
             
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 throw new StockExchangeException("Portfolio ne postoji");
             }
             else
             {
                 decimal startValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 000));
                 decimal endValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));

                 if (startValue == 0)
                 {
                     throw new StockExchangeException("Cijena nije definirana!");
                     
                 }

                 return Math.Round((endValue - startValue)/startValue*100, 3);
             }
         }

         public long NumberOfSharesAtStockExchange(string inStockId)
         {
             if (StockExists(inStockId.ToLower()))
             {
                 long sum = 0;

                 foreach (string portfolio in portfolios.Keys)
                 {
                     if (portfolios[portfolio].containsStock(inStockId.ToLower()))
                     {
                         sum += NumberOfSharesOfStockInPortfolio(portfolio, inStockId.ToLower());
                     }
                 }

                 return sum;
             }
             else
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
         }
        
     }


     public class Stock
     {
         private string _name = "";
         private long _number = 0;
         private Dictionary<DateTime, Decimal> _values = new Dictionary<DateTime, Decimal>();

         public Stock(string name, long number, DateTime startDate, decimal stockValue)
         {
             _name = name;
             _number = number;
             _values.Add(startDate, stockValue);
         }

         public void setPrice(DateTime time, Decimal value)
         {
             _values.Add(time, value);
         }

         public Decimal getStockPrice(DateTime time)
         {
             if (_values.ContainsKey(time))
             {
                 return _values[time];
             }
             else
             {
                 List<DateTime> timestamps = new List<DateTime>(_values.Keys);
                 List<DateTime> before = new List<DateTime>();

                 foreach (DateTime ts in timestamps)
                 {
                     if (ts < time)
                     {
                         before.Add(ts);
                     }
                 }

                 if (before.Count == 0)
                 {
                     throw new StockExchangeException("Vrijednost dionice nije definirana!");
                 }

                 before.Sort();

                 return _values[before[before.Count - 1]];
             }
         }

         public Decimal getInitialPrice()
         {
             List<DateTime> keys = new List<DateTime>(_values.Keys);
             keys.Sort();

             return _values[keys[0]];
         }

         public Decimal getLastPrice()
         {
             List<DateTime> keys = new List<DateTime>(_values.Keys);
             keys.Sort();

             return _values[keys[_values.Count-1]];
         }

         public long returnNumberOfShares()
         {
             return _number;
         }
     }

     public class Index
     {
         private string _name = "";
         private IndexTypes type;
         private Dictionary<string, Stock> _stocks = new Dictionary<string, Stock>();

         public Index(string indexName, IndexTypes indexType)
         {
             _name = indexName;
             type = indexType;
         }

         public void addStock(string stockName, Stock inStock)
         {
             if (_stocks.ContainsKey(stockName.ToLower()))
             {
                 throw new StockExchangeException("Index vec sadrzi dionicu!");
             }
             else
             {
                 _stocks.Add(stockName, inStock);
             }
             
         }

         public void removeStock(string stockName)
         {
             if (_stocks.ContainsKey(stockName.ToLower()) )
             {
                 _stocks.Remove(stockName.ToLower());
                 
             }
             else
             {
                 throw new StockExchangeException("Index ne sadrzi dionicu!");
             }
         }

         public int numberOfStocks()
         {
             return _stocks.Count;
         }

         private Dictionary<string, Decimal> calculateFactors(DateTime timestamp)
         {
             Dictionary<string, Decimal> factors = new Dictionary<string, Decimal>();

             List<string> shares = new List<string>(_stocks.Keys);

             Decimal OverallNumber = 0;

             foreach (string share in shares)
             {
                 OverallNumber += _stocks[share].getStockPrice(timestamp)*_stocks[share].returnNumberOfShares();
                 factors.Add(share, _stocks[share].getStockPrice(timestamp));
             }

             foreach (string share in shares)
             {
                 factors[share] = factors[share]/OverallNumber;
             }

             return factors;
         }

         public Decimal getValue(DateTime timestamp)
         {
             Decimal _value = 0;
             long numberOfShares = numberOfStocks();

             if (type == IndexTypes.AVERAGE)
             {
                 List<string> shares = new List<string>(_stocks.Keys);

                 foreach (string share in shares)
                 {
                     _value += _stocks[share].getStockPrice(timestamp);
                     
                 }

                 return (Decimal) _value/numberOfShares;
             }
             else
             {
                 Dictionary<string, Decimal> factors = new Dictionary<string, decimal>();
                 factors = calculateFactors(timestamp);

                 List<string> shares = new List<string>(_stocks.Keys);

                 foreach (string share in shares)
                 {
                     _value += _stocks[share].getStockPrice(timestamp)*_stocks[share].returnNumberOfShares()*factors[share];
                 }

                 return _value;
             }
         }

         public bool containsStock(string inStockName)
         {
             if (_stocks.ContainsKey(inStockName.ToLower()))
             {
                 return true;
             }
                 
             else
             {
                 return false;
             }
         }
     }

     public class Portfolio
     {
         private string ID = "";
         private Dictionary<string, int> _stocks = new Dictionary<string, int>(); 

         public Portfolio(string portofolioId)
         {
             ID = portofolioId;
         }

         public void addStock(string inStockName, int inNumberOfShares)
         {
             if (_stocks.ContainsKey(inStockName))
             {
                 _stocks[inStockName] = _stocks[inStockName] + inNumberOfShares;
             }
             else
             {
                 _stocks.Add(inStockName, inNumberOfShares);
             }
             
         }

         public void removeStock(string inStockName, int inNumberOfShares)
         {
             if (!_stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Portfolio ne sadrzi zadanu dionicu!");
             }
             else if (_stocks[inStockName] < inNumberOfShares)
             {
                 throw  new StockExchangeException("Portfolio sadrzi manji broj dionica od broja koji se zeli obrisati!");
             }
             else
             {
                 _stocks[inStockName] = _stocks[inStockName] - inNumberOfShares;

                 if (_stocks[inStockName] == 0)
                 {
                     _stocks.Remove(inStockName);
                 }
             }
         }

         public void removeStock(string inStockName)
         {
             if (!_stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Portfolio ne sadrzi zadanu dionicu!");
             }
             else
             {
                 _stocks.Remove(inStockName);
             }
         }

         public int numberOfStocks()
         {
             return _stocks.Count;
         }

         public bool containsStock(string inStockName)
         {
             if (_stocks.ContainsKey(inStockName))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

         public int numberOfShares(string inStockName)
         {
             if (containsStock(inStockName))
             {
                 return _stocks[inStockName];
             }
             else
             {
                 throw new StockExchangeException("Portfolio ne sadrzi zadanu dionicu!");
                 //return 0;
             }
         }

         public Dictionary<string, int> returnStocks()
         {
             return _stocks;
         }



     }

}
