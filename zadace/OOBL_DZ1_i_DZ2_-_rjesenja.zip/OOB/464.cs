﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }
    public class Kalkulator : ICalculator
    {
        private string stanje;

        private int number;
        private string previous=null;
        public void Press(char inPressedDigit)
        {
            stanje += inPressedDigit.ToString(); 
        }

        private void Result()
        {
            try
            {
                result();
            }
            catch (Exception exc)
            {
                stanje = "Error!";
            }
        }

        private void result()
        {
            String op;
            int iOp = 0;
            if (stanje.Contains("+"))
            {
                iOp = stanje.IndexOf("+");
            }
            else if (stanje.Contains("-"))
            {
                iOp = stanje.IndexOf("-");
            }
            else if (stanje.Contains("*"))
            {
                iOp = stanje.IndexOf("*");
            }
            else if (stanje.Contains("/"))
            {
                iOp = stanje.IndexOf("/");
            }
            else if (stanje.Contains("M"))
            {
                iOp = stanje.IndexOf("M");
            }
            else if (stanje.Contains(","))
            {
                iOp = stanje.IndexOf(",");
            }
            else
            {
                //error 
            }

            if (iOp == 0)
            {
                op = stanje.ToString();
                stanje += op.ToString();
            }
            else
            {
                op = stanje.Substring(iOp, 1);
                double op1 = Convert.ToDouble(stanje.Substring(0, iOp));
                if (stanje.Length > iOp)
                {
                    double op2 = Convert.ToDouble(stanje.Substring(iOp + 1, stanje.Length - iOp - 1));

                    if (op == "+")
                    {
                        stanje += (op1 + op2);
                    }
                    else if (op == "-")
                    {
                        stanje += (op1 - op2);
                    }
                    else if (op == "*")
                    {
                        stanje += (op1 * op2);
                    }
                    else if (op == "/")
                    {
                        stanje += (op1 / op2);
                    }
                    else if (op == ",")
                    {
                        stanje += op1.ToString() + "," + op2.ToString();
                    }
                    else
                    {
                        stanje += op1.ToString();
                    }
                }
                else
                {
                    if (op == "M")
                    {
                        op1 = op1 * (-1);
                    }
                    stanje += op1.ToString();
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return this.stanje;
        }
    }
}
