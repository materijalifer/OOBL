﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        char[] numbers = new char[] {'0','1','2','3','4','5','6','7','8','9'};
        char[] operations = new char[] {'S', 'K', 'T', 'Q', 'R', 'I' };
        char[] binOperations = new char[] {'+','-','*','/'};

        char operation;
        char selfOperation;

        char coma = ',';
        char clear = 'C';
        char reset = 'O';
        

        string tmp;
        string currentDisplayS = "0";
        string resultString = "";

        double resultNum = 0;
        double currentDisplayN = 0;
        double memory = 0;

        public void Press(char inPressedDigit)
        {
            if (numbers.Contains(inPressedDigit))
            {
                resultString += inPressedDigit;
                currentDisplayN = Convert.ToDouble(resultString);
                currentDisplayS = Convert.ToString(currentDisplayN);
                return;
            }

            if (binOperations.Contains(inPressedDigit))
            {
                if ((resultNum != 0) && (resultString.Length > 0))
                {
                    resultNum = CalculateBin(resultNum, currentDisplayN, operation);
                    if (Round(resultNum) == "-E-")
                    {
                        currentDisplayS = "-E-";
                        return;
                    }
                    tmp = Round(resultNum);
                    resultNum = Convert.ToDouble(tmp);
                    currentDisplayN = resultNum;
                    currentDisplayS = Convert.ToString(currentDisplayN);
                    operation = inPressedDigit;
                    resultString = "";
                    return;
                }

                else
                {
                    operation = inPressedDigit;
                    if (Round(currentDisplayN) == "-E-")
                    {
                        currentDisplayS = "-E-";
                        return;
                    }
                    tmp = Round(currentDisplayN);
                    resultNum = Convert.ToDouble(tmp);
                    resultString = "";
                    return;
                }
            }

            if (operations.Contains(inPressedDigit))
            {
                selfOperation = inPressedDigit;
                if ((inPressedDigit == 'I') && (currentDisplayN == 0))
                {
                    currentDisplayS = "-E-";
                    return;
                }
                currentDisplayN = Calculate(currentDisplayN, selfOperation);
                if (Round(currentDisplayN) == "-E-")
                {
                    currentDisplayS = "-E-";
                    return;
                }
                currentDisplayN = Convert.ToDouble(Round(currentDisplayN));
                currentDisplayS = Convert.ToString(currentDisplayN);
                return;
            }

            if ((inPressedDigit == '=') && (binOperations.Contains(operation)))
            {
                if ((currentDisplayN == 0) && (operation == '/'))
                {
                    currentDisplayS = "-E-";
                    return;
                }
                resultNum = CalculateBin(resultNum, currentDisplayN, operation);
                currentDisplayN = resultNum;
                if (Round(currentDisplayN) == "-E-")
                {
                    currentDisplayS = "-E-";
                    return;
                }
                currentDisplayN = Convert.ToDouble(Round(currentDisplayN));
                currentDisplayS = Convert.ToString(currentDisplayN);
                resultNum = 0;
                resultString = "";
                operation = '\0';
                return;
            }

            if (inPressedDigit == coma)
            {
                if (resultString.Contains(',')) return;
                resultString += coma;
                return;
            }

            if (inPressedDigit == clear)
            {
                currentDisplayN = 0;
                currentDisplayS = "0";
                resultString = "";
                return;
            }

            if (inPressedDigit == reset)
            {
                resultNum = 0;
                resultString = "0";
                currentDisplayN = 0;
                currentDisplayS = "0";
                operation = '\0';
                memory = 0;
                return;
            }

            if (inPressedDigit == 'M')
            {
                currentDisplayN *= -1;
                currentDisplayN = Convert.ToDouble(Round(currentDisplayN));
                resultString = Convert.ToString(currentDisplayN);
                currentDisplayS = resultString;
            }

            if (inPressedDigit == '=')
            {
                operation = '\0';
                resultString = "";
                resultNum = 0;
                return;
            }

            if (inPressedDigit == 'P')
            {
                memory = currentDisplayN;
                return;
            }

            if (inPressedDigit == 'G')
            {
                currentDisplayN = memory;
                currentDisplayS = Convert.ToString(currentDisplayN);
                resultString = "";
                return;
            }
        }

        public double CalculateBin(double result, double currentNum, char operation)
        {
            switch (operation)
            {
                case '+':
                    result += currentNum;
                    break;
                case '-':
                    result -= currentNum;
                    break;
                case '*':
                    result *= currentNum;
                    break;
                case '/':
                    result /= currentNum;
                    break;
                default:
                    Console.WriteLine("Greška kod binarnog operatora");
                    break;
            }
            return result;
        }

        public string Round(double result)
        {
            string resultStr = result.ToString();
            int len = resultStr.Length;
            int comaInd, roundInd;

            if ((result < 0) && (resultStr.Contains(",")) && (len > 12))
            {
                comaInd = resultStr.IndexOf(',');
                roundInd = 11 - comaInd;
                result = Math.Round(result, roundInd);
                resultStr = Convert.ToString(result);
                return resultStr;
            }
            else if ((result < 0) && (!resultStr.Contains(",")) && (len > 11))
            {
                string tmpS = resultStr.Substring(0, 11);
                comaInd = resultStr.IndexOf(',');
                roundInd = 10 - comaInd;
                result = Math.Round(result, roundInd);
                resultStr = Convert.ToString(result);
                return resultStr;
            }
            else if ((result > 0) && (resultStr.Contains(',')) && (len > 11))
            {
                string tmpS = resultStr.Substring(0, 11);
                comaInd = resultStr.IndexOf(',');
                roundInd = 10 - comaInd;
                result = Math.Round(result, roundInd);
                resultStr = Convert.ToString(result);
                return resultStr;
            }

            else if (((len > 10) && (result > 0) && (!resultStr.Contains(","))) ||
                ((result < 0) && (!resultStr.Contains(",")) && (len > 12)) ||
                ((result > 0) && (!resultStr.Contains(",")) && (len > 11)))
                return "-E-";

            else return resultStr;
        }

        public double Calculate(double result, char operation)
        {
            switch (operation)
            {
                case 'S':
                    result = Math.Sin(result);
                    break;
                case 'K':
                    result = Math.Cos(result);
                    break;
                case 'T':
                    result = Math.Tan(result);
                    break;
                case 'Q':
                    result = Math.Pow(result, 2);
                    break;
                case 'R':
                    result = Math.Sqrt(result);
                    break;
                case 'I':
                    result = 1 / result;
                    break;
                default:
                    Console.WriteLine("Greška kod operatora");
                    break;
            }
            return result;
        }

        public string GetCurrentDisplayState()
        {
            return currentDisplayS;
        }
    }


}
