using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        private string displayState;
        private string currentValue;
        private string previousValue;
        private bool minusSign;
        private string memoryValue;
        private string binaryOperator;
        private bool memorySign;

        public Kalkulator()
        {
          string initialState = "0";
          this.displayState = initialState;
          this.minusSign = false;
          this.binaryOperator = "";
        }

        public void Press(char inPressedDigit)
        {
         // this.displayState = inPressedDigit;
          switch (inPressedDigit)
          {
            case '0':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '1':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '2':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '3':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '4':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '5':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '6':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '7':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '8':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case '9':
              AddDigit(inPressedDigit);
              RefreshDisplay();
              break;
            case ',':
              AddComma(inPressedDigit);
              RefreshDisplay();
              break;
            case 'M':
              ChangeSign();
              RefreshDisplay();
              break;
            case 'O':
              OnOff();
              RefreshDisplay();
              break;
            case 'C':
              Clear();
              RefreshDisplay();
              break;
            case 'P':
              MemoryPut(this.currentValue);
              break;
            case 'G':
              MemoryGet();
              RefreshDisplay();
              break;
            case '+':
              AddBinaryOperator(inPressedDigit);
              RefreshDisplay();
              break;
            case '-':
              AddBinaryOperator(inPressedDigit);
              RefreshDisplay();
              break;
            case '*':
              AddBinaryOperator(inPressedDigit);
              RefreshDisplay();
              break;
            case '/':
              AddBinaryOperator(inPressedDigit);
              RefreshDisplay();
              break;
            case 'Q':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case 'R':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case 'I':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case 'S':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case 'K':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case 'T':
              CalculateUnaryOperation(currentValue, inPressedDigit);
              RefreshDisplay();
              break;
            case '=':
              CalculateBinaryOperation();
              RefreshDisplay();
              break;
          }

        }

        public string GetCurrentDisplayState()
        {
          return this.displayState;
        }

        private void RefreshDisplay()
        {
          if (!this.currentValue.Equals(""))
          {
            this.displayState = this.currentValue;
          }
          else
          {
            this.displayState = this.previousValue;
          }

          this.displayState = PrepareForDisplay(this.displayState);
        }

        // prije ispisa na ekran uklanja decimalni zarez i nulu, tj zaokru�uje na integer vrijednost ako je mogu�e
        private string PrepareForDisplay(string displayState)
        {
          double decimalPrecision = 0.00000000000001;
          try
          {
            double decimalValue = Double.Parse(displayState);
            if (Math.Abs(decimalValue - Math.Round(decimalValue, 0)) < decimalPrecision)
            {
              displayState = Math.Round(decimalValue, 0).ToString();
            }
          }
          catch { }
          return displayState;
        }

        private void AddDigit(char inPressedDigit)
        {
          try
          {
            if (this.currentValue[0].Equals('0') && inPressedDigit.Equals('0'))
            {
              return;
            }
            if (this.currentValue[0].Equals('0') && !this.currentValue[1].Equals(','))
            {
              this.currentValue = this.currentValue.Substring(1);
            }
            int allowedDigits = 10;
            if (this.currentValue.Length == allowedDigits &&
                System.Text.RegularExpressions.Regex.IsMatch(currentValue, ","))
            {
              this.currentValue = this.currentValue + inPressedDigit;
            }
            if (this.currentValue.Length >= allowedDigits) { return; }
          }
          catch (Exception e) { }
          this.currentValue = this.currentValue + inPressedDigit;
        }

        private void AddComma(char inPressedDigit)
        {
          try
          {
            if (System.Text.RegularExpressions.Regex.IsMatch(currentValue, ","))
            {
              return;
            }
            this.currentValue = this.currentValue + inPressedDigit;
          }
          catch { this.currentValue = "0,"; }
          
        }

        private void ChangeSign()
        {
          try
          {
            if (this.currentValue.Equals("0")) { return; }
            if (this.currentValue[0].Equals('-'))
            {
              this.currentValue = this.currentValue.Substring(1);
            }
            else
            {
              this.currentValue = "-" + this.currentValue;
            }
          }
          catch { }
        }

        private void OnOff()
        {
          this.currentValue = "0";
          this.previousValue = "0";
          this.minusSign = false;
          this.displayState = "0";
        }

        private void Clear()
        {
          this.currentValue = "0";
        }

        private void MemoryPut(string currentValue)
        {
          this.memoryValue = currentValue;
          this.memorySign = this.minusSign;
        }

        private void MemoryGet()
        {
          try
          {
            this.currentValue = this.memoryValue;
            this.minusSign = this.memorySign;
          }
          catch { }
        }

        private void AddBinaryOperator(char binaryOperator)
        {
          if (!this.binaryOperator.Equals("") && !this.currentValue.Equals(""))
          {
            CalculateBinaryOperation();
          }
          if (!this.currentValue.Equals(""))
          {
            this.previousValue = this.currentValue;
          }
          this.binaryOperator = binaryOperator.ToString();
          this.currentValue = "";
          
        }

        private double StringToDecimal(string stringValue)
        {
          double value = double.Parse(stringValue);
          return value;
        }

        private void CalculateBinaryOperation()
        {
          if (this.binaryOperator.Equals("")) { return; }

          double operandFirst;
          double operandSecond;
          double result;

          operandFirst = double.Parse(this.previousValue);
          try
          {
            operandSecond = double.Parse(this.currentValue);
          }
          catch
          {
            operandSecond = double.Parse(this.previousValue);
          }
          
          switch (this.binaryOperator)
          {
            case "+": result = operandFirst + operandSecond; break;
            case "-": result = operandFirst - operandSecond; break;
            case "*": result = operandFirst * operandSecond; break;
            case "/": result = operandFirst / operandSecond; break;
            default: result = operandSecond; break;
          }
          SetCurrentValue(result);
        }

        private void CalculateUnaryOperation(string currentValue, char unaryOperator)
        {
          double operand;
          try
          {
             operand = double.Parse(currentValue);
          }
          catch { operand = double.Parse(this.previousValue); }
            
            double result;

            switch (unaryOperator.ToString())
            {
              case "Q": result = Math.Pow(operand, 2); break;
              case "R": result = Math.Sqrt(operand); break;
              case "I": result = 1 / operand; break;
              case "S": result = Math.Sin(operand); break;
              case "K": result = Math.Cos(operand); break;
              case "T": result = Math.Tan(operand); break;
              default: result = 0; break;
            }
            SetCurrentValue(result);
        }

        // ukoliko je vrijednost broja nedozvoljena postavlja vrijednost operacije na "-E-"
        // u protivnom pohranjuje vrijednost operacije
        private void SetCurrentValue(double number)
        {
          string stringValue;

          int decimalPlaces = 9;
          stringValue = Math.Round(number, decimalPlaces).ToString();

          if ((stringValue.Replace(",", "").Replace("-", "").Length > 10) ||
                stringValue.Equals("Infinity") ||
                stringValue.Equals("-Infinity")
            )
          {
            stringValue = "-E-";
          }
          this.currentValue = stringValue;
        }

    }
}