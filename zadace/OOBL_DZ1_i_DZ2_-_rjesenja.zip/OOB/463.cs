﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string _displayState;
        private string _previousOperand;
        private Func<string> _operation;
        private bool _error;
        private bool _binaryOperandPressed;
        private Memory _storage;

        public Kalkulator()
        {
            _displayState = "0";
            _storage = new Memory();
            _error = false;
            _binaryOperandPressed = false;
            _operation = null;
        }

        public void Press(char inPressedDigit)
        {
            // on/off

            if (inPressedDigit == 'O')
            {
                _displayState = "0";
                _storage = new Memory();
                _error = false;
                _binaryOperandPressed = false;
                _operation = null;
            }

            if (_error == true)
                return;

            // clear 

            if (inPressedDigit == 'C')
            {
                _displayState = "0";
            }            

            if (inPressedDigit == 'P')
            {
                _storage.SetValue(_displayState);
            }

            if (inPressedDigit == 'G')
            {
                _displayState = _storage.GetValue();
            }

            if (inPressedDigit == 'M')
            {
                if (_displayState[0] != '-')
                    _displayState = "-" + _displayState;
                else
                    _displayState = _displayState.Substring(1);

                _displayState = "" + roundNumber(_displayState);
            }

            if (inPressedDigit == 'S')
            {
                double result = Math.Sin(toDouble(_displayState));
                _displayState = "" + roundNumber(result);
            }

            if (inPressedDigit == 'K')
            {
                double result = Math.Cos(toDouble(_displayState));
                _displayState = "" + roundNumber(result);
            }

            if (inPressedDigit == 'T')
            {
                double result = Math.Tan(toDouble(_displayState));
                _displayState = "" + roundNumber(result);
            }

            if (inPressedDigit == 'Q')
            {
                double result = Math.Pow(toDouble(_displayState), 2);
                _displayState = "" + roundNumber(result);
            }

            if (inPressedDigit == 'R')
            {
                double result = Math.Sqrt(toDouble(_displayState));
                _displayState = "" + roundNumber(result);
            }

            if (inPressedDigit == 'I')
            {
                double x = toDouble(_displayState);

                if (x == 0.0)
                {
                    _error = true;
                    _displayState = "-E-";
                }
                else
                {
                    double result = 1 / x;
                    _displayState = "" + roundNumber(result);
                }
            }

            if (inPressedDigit == '+')
            {
                if (_operation != null && !_binaryOperandPressed)
                {
                    string currentValue = _displayState;

                    _displayState = _operation();
                    _previousOperand = currentValue;
                }

                _operation = delegate
                {
                    double op1 = roundNumber(_displayState);

                    string previousOperand = _previousOperand;

                    if (previousOperand == null)
                        previousOperand = _displayState;

                    double op2 = roundNumber(previousOperand);
                    return (op1 + op2) + "";
                };

                _previousOperand = _displayState;
                _binaryOperandPressed = true;
            }

            if (inPressedDigit == '-')
            {
                if (_operation != null && !_binaryOperandPressed)
                {
                    string currentValue = _displayState;

                    _displayState = _operation();
                    _previousOperand = currentValue;
                }

                _operation = delegate
                {
                    double op1 = roundNumber(_displayState);
                    string previousOperand = _previousOperand;

                    if (previousOperand == null)
                        previousOperand = _displayState;

                    double op2 = roundNumber(previousOperand);

                    return (op2 - op1) + "";
                };

                _previousOperand = _displayState;
                _binaryOperandPressed = true;
            }

            if (inPressedDigit == '*')
            {
                if (_operation != null && !_binaryOperandPressed)
                {
                    string currentValue = _displayState;

                    _displayState = _operation();
                    _previousOperand = currentValue;
                }

                _operation = delegate
                {
                    double op1 = roundNumber(_displayState);
                    string previousOperand = _previousOperand;

                    if (previousOperand == null)
                        previousOperand = _displayState;

                    double op2 = roundNumber(previousOperand);
                    return (op1 * op2) + "";
                };

                _previousOperand = _displayState;
                _binaryOperandPressed = true;
            }

            if (inPressedDigit == '/')
            {
                if (_operation != null && !_binaryOperandPressed)
                {
                    string currentValue = _displayState;

                    _displayState = _operation();
                    _previousOperand = currentValue;
                }

                _operation = delegate
                {
                    double op1 = roundNumber(_displayState);
                    string previousOperand = _previousOperand;

                    if (previousOperand == null)
                        previousOperand = _displayState;

                    double op2 = roundNumber(previousOperand);

                    if (Convert.ToDouble(_displayState) == 0.0)
                    {
                        _error = true;
                        return "-E-";
                    }

                    return (op1 / op2) + "";
                };

                _previousOperand = _displayState;
                _binaryOperandPressed = true;
            }

            if (inPressedDigit == '=')
            {
                string currentValue = _displayState;

                if (_operation != null)
                {
                    _displayState = _operation();
                    _previousOperand = currentValue;
                }                

                // check for errors

                if (_error == true)
                    return;

                // check for overflow errors

                double floating = toDouble(_displayState);
                long integer;

                try
                {
                   integer = Convert.ToInt64(floating);
                }
                catch (OverflowException)
                {
                    _error = true;
                    _displayState = "-E-";
                    return;
                }

                if (getDigitNumber(integer) > 10)
                {
                    _error = true;
                    _displayState = "-E-";
                }
                else
                {
                    // check for superflous decimals                

                    if (integer == floating)
                        _displayState = "" + integer;
                }
            }

            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',')
            {
                if (_binaryOperandPressed)
                    _displayState = "0";

                if (_displayState == "0")
                {
                    if (inPressedDigit != ',')
                        _displayState = inPressedDigit + String.Empty;
                    else
                        _displayState = "0,";
                }
                else
                    _displayState += inPressedDigit;

                _binaryOperandPressed = false;
            }
            else
            {
                if (_displayState == "-E-")
                    return;

                double floating = toDouble(_displayState);
                long integer;

                try
                {
                    integer = Convert.ToInt64(floating);
                }
                catch (OverflowException)
                {
                    _error = true;
                    _displayState = "-E-";
                    return;
                }

                if (getDigitNumber(integer) > 10)
                {
                    _error = true;
                    _displayState = "-E-";
                }
                else
                {
                    // check for superflous decimals                

                    if (integer == floating)
                        _displayState = "" + integer;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return this._displayState;
        }

        private int getDigitNumber(string state)
        {
            try
            {
                return getDigitNumber(Int64.Parse(state.Replace(',', '.')));
            }
            catch (FormatException)
            {
                return getDigitNumber(Double.Parse(state.Replace(',', '.')));
            }
        }

        private int getDigitNumber(long val)
        {
            long number = val;

            if (number == 0)
                return 1;

            int digits = 1;

            // negative sign in front

            if (number < 0)
                number *= -1;

            while (number > 0)
            {
                ++digits;
                number /= 10;
            }

            return digits;
        }

        private int getDigitNumber(double val)
        {
            long number;

            try
            {
                number = Convert.ToInt64(val);
            }
            catch (OverflowException)
            {
                return 0;
            }

            return getDigitNumber(number);
        }

        private long toInteger(string state)
        {
            return Int64.Parse(state);
        }

        private double toDouble(string state)
        {
            return Double.Parse(state);
        }

        private double roundNumber(string state)
        {
            return roundNumber(toDouble(state));
        }

        private double roundNumber(double val)
        {
            int digits = getDigitNumber(val);            

            return Math.Round(val, 11 - digits);
        }
    }

    public class Memory
    {
        private string _value;

        public Memory()
        {
            _value = "0";
        }

        public void ClearValue()
        {
            _value = "0";
        }

        public string GetValue()
        {
            return _value;
        }

        public void SetValue(string value)
        {
            _value = value;
        }
    }
}
