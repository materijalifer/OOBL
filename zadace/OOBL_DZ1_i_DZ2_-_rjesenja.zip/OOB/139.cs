﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
     {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
     }

     public class Stock
     {
         private string _stockName;
         private long _numberOfShares;
         private Dictionary<DateTime, decimal> _prices = new Dictionary<DateTime, decimal>();

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
                 this._stockName = inStockName;
                 this._numberOfShares = inNumberOfShares;
                 this._prices[inTimeStamp] = inInitialPrice;
         }

         public void SetStockPrice(DateTime inIimeStamp, decimal inStockValue)
         {
             this._prices[inIimeStamp] = inStockValue;
         }

         public decimal GetStockPrice(DateTime inTimeStamp)
         {
             DateTime validTimeStamp = DateTime.MinValue;
             foreach (DateTime timeStamp in _prices.Keys)
             {
                 if (timeStamp <= inTimeStamp && timeStamp > validTimeStamp)
                 {
                     validTimeStamp = timeStamp;
                 }
             }

             if (validTimeStamp.Equals(DateTime.MinValue))
             {
                 throw new StockExchangeException("Nema odgovarajuceg timestampa!");
             }
             return this._prices[validTimeStamp];
         }

         public decimal GetLastPrice()
         {
             DateTime maxTimeStamp = DateTime.MinValue;
             foreach( DateTime timeStamp in _prices.Keys)
             {
                 if (timeStamp > maxTimeStamp)
                 {
                     maxTimeStamp = timeStamp;
                 }
             }
             return _prices[maxTimeStamp];
         }

         public decimal GetInitialPrice()
         {
             DateTime minTimeStamp = DateTime.MaxValue;
             foreach (DateTime timeStamp in _prices.Keys)
             {
                 if (timeStamp < minTimeStamp)
                 {
                     minTimeStamp = timeStamp;
                 }
             }
             return _prices[minTimeStamp];
         }

         public long GetNumberOfShares()
         {
             return _numberOfShares;
         }
     }

     public class Index
     {
         private string _indexName;
         private IndexTypes _indexType;
         private List<string> _stocks;

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             this._indexName = inIndexName;
             this._indexType = inIndexType;
             this._stocks = new List<string>();
         }

         public void AddStock(string inStockName)
         {
             if (this._stocks.Contains(inStockName))
             {
                 throw new StockExchangeException("Dionica već postoji!");
             }
             else
             {
                 this._stocks.Add(inStockName);
             }
         }

         public void RemoveStock(string inStockName)
         {
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 this._stocks.Remove(inStockName);
             }
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.Contains(inStockName);
         }

         public int StockCount()
         {
             return _stocks.Count;
         }

         public decimal GetValue(DateTime inTimeStamp, Dictionary<string, Stock> inStockExchange)
         {
             decimal totalStockPrices = 0;
             decimal indexValue = 0;
             switch (this._indexType)
             {
                 case IndexTypes.AVERAGE:
                     foreach (string stock in _stocks)
                     {
                         totalStockPrices += inStockExchange[stock].GetStockPrice(inTimeStamp);
                     }
                     indexValue = Math.Round(totalStockPrices / _stocks.Count, 3);
                     break;
                 case IndexTypes.WEIGHTED:
                     decimal numberOfSharesInIndex = 0;
                     foreach (string stock in _stocks)
                     {
                         totalStockPrices += inStockExchange[stock].GetStockPrice(inTimeStamp) * inStockExchange[stock].GetNumberOfShares() * inStockExchange[stock].GetStockPrice(inTimeStamp);
                         numberOfSharesInIndex += inStockExchange[stock].GetNumberOfShares() * inStockExchange[stock].GetStockPrice(inTimeStamp);
                     }
                     indexValue = Math.Round(totalStockPrices / numberOfSharesInIndex, 3);
                     break;
                 default:
                     break;
             }
             return indexValue;
         }

     }

     public class Portfolio
     {
         private string _PortfolioID;
         private Dictionary<string, long> _stockShares;

         public Portfolio(string inPortfolioID)
         {
             _PortfolioID = inPortfolioID;
             _stockShares = new Dictionary<string, long>();
         }

         public void AddStockShares(string inStockName, long inStockShares)
         {
             if (_stockShares.ContainsKey(inStockName))
             {
                 _stockShares[inStockName] += inStockShares;
             }
             else
             {
                 _stockShares[inStockName] = inStockShares;
             }
         }

         public void RemoveStock(string inStockName)
         {
             _stockShares.Remove(inStockName);
         }

         public void RemoveStockShares(string inStockName, long inStockShares)
         {
             if (inStockShares >= _stockShares[inStockName])
             {
                 RemoveStock(inStockName);
             }
             else
             {
                 _stockShares[inStockName] -= inStockShares;
             }
         }

         public bool StockExists(string inStockName)
         {
             return _stockShares.ContainsKey(inStockName);
         }

         public long GetNumberOfSharesOfStock(string inStockName)
         {
             if (_stockShares.ContainsKey(inStockName))
             {
                 return _stockShares[inStockName];
             }
             else
             {
                 return 0;
             }
         }

         public int GetNumberOfStocks()
         {
             return _stockShares.Count;
         }

         public decimal GetValue(DateTime inTimeStamp, Dictionary<string, Stock> inStockExchange)
         {
             decimal totalValue = 0;
             foreach (string stock in _stockShares.Keys)
             {
                 totalValue += inStockExchange[stock].GetStockPrice(inTimeStamp) * _stockShares[stock];
             }
             return totalValue;
         }
     }

     public class StockExchange : IStockExchange
     {
         Dictionary<string, Stock> _stockExchange;
         Dictionary<string, Index> _stockIndices;
         Dictionary<string, Portfolio> _portfolios;


         public StockExchange()
         {
             _stockExchange = new Dictionary<string, Stock>();
             _stockIndices = new Dictionary<string, Index>();
             _portfolios = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToLower();
             if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica vec postoji!");
             }
             else if (inNumberOfShares <= 0 || inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Broj dionica i/ili njihova cijena su manji ili jednaki 0!");
             }
             else
             {
                 _stockExchange[inStockName] = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             }
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 _stockExchange.Remove(inStockName);
                 foreach (string index in _stockIndices.Keys)
                 {
                     RemoveStockFromIndex(index, inStockName);
                 }
                 foreach (string portfolio in _portfolios.Keys)
                 {
                     RemoveStockFromPortfolio(portfolio, inStockName);
                 }
             }
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToLower();
             return _stockExchange.ContainsKey(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stockExchange.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToLower();
             if (inStockValue <= 0)
             {
                 throw new StockExchangeException("Cijena dionica je manja/jednaka 0!");
             }
             else if (!_stockExchange.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 _stockExchange[inStockName].SetStockPrice(inIimeStamp, inStockValue);
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToLower();
             return _stockExchange[inStockName].GetStockPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 return _stockExchange[inStockName].GetInitialPrice();
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (!StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica ne postoji!");
             }
             else
             {
                 return _stockExchange[inStockName].GetLastPrice();
             }
         }
/// <summary>
/// </summary>
/// <param name="inIndexName"></param>
/// <param name="inIndexType"></param>
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             string indexName = inIndexName.ToLower();
             if (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
             {
                 _stockIndices[indexName] = new Index(indexName, inIndexType);
             }
             else
             {
                 throw new StockExchangeException("Tip indexa nije valjan ili index vec postoji!");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 _stockIndices[inIndexName].AddStock(inStockName);   
             }
             else
             {
                 throw new StockExchangeException("Index ili dionica ne postoji!");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 _stockIndices[inIndexName].RemoveStock(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Index ili dionica ne postoji!");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToLower();
             inStockName = inStockName.ToLower();
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 return _stockIndices[inIndexName].StockExists(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Index ili dionica ne postoji!");
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToLower();
             if (IndexExists(inIndexName))
             {
                 return _stockIndices[inIndexName].GetValue(inTimeStamp, _stockExchange);
             }
             else
             {
                 throw new StockExchangeException("Index ne postoji!");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToLower();
             return _stockIndices.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _stockIndices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToLower();
             if (_stockIndices.ContainsKey(inIndexName))
             {
                 return _stockIndices[inIndexName].StockCount();
             }
             else
             {
                 throw new StockExchangeException("Index ne postoji!");
             }
         }

         /// <summary>
         /// </summary>
         /// <param name="inIndexName"></param>
         /// <param name="inIndexType"></param>
         /// 
         public void CreatePortfolio(string inPortfolioID)
         {
             if (!_portfolios.ContainsKey(inPortfolioID))
             {
                 _portfolios[inPortfolioID] = new Portfolio(inPortfolioID);
             }
             else
             {
                 throw new StockExchangeException("Portfelj vec postoji!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToLower();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 long numberOfSharesInPortfolios = 0;
                 foreach (string portfolioID in _portfolios.Keys)
                 {
                     numberOfSharesInPortfolios += _portfolios[inPortfolioID].GetNumberOfSharesOfStock(inStockName);
                 }
                 if ((long)numberOfShares + numberOfSharesInPortfolios <= _stockExchange[inStockName].GetNumberOfShares())
                 {
                     _portfolios[inPortfolioID].AddStockShares(inStockName, (long)numberOfShares);
                 }
                 else
                 {
                     throw new StockExchangeException("Broj dionica prevelik!");
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfelj ili dionica ne postoji!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToLower();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName) && IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 _portfolios[inPortfolioID].RemoveStockShares(inStockName, numberOfShares);
             }
             else
             {
                 throw new StockExchangeException("Portfelj ili dionica ne postoji!");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName) && IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 _portfolios[inPortfolioID].RemoveStock(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Portfelj ili dionica ne postoji!");
             }
         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return _portfolios[inPortfolioID].GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("Portfelj ne postoji!");
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (PortfolioExists(inPortfolioID))
             {
                 return _portfolios[inPortfolioID].StockExists(inStockName);
             }
             else
             {
                 throw new StockExchangeException("Portfelj ne postoji!");
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToLower();
             if (PortfolioExists(inPortfolioID))
             {
                 if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 {
                    return (int) _portfolios[inPortfolioID].GetNumberOfSharesOfStock(inStockName);
                 }
                 else
                 {
                     throw new StockExchangeException("Portfelj ne sadrzi tu dionicu!");
                 }
             }
             else
             {
                 throw new StockExchangeException("Portfelj ne postoji!");
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return Math.Round(_portfolios[inPortfolioID].GetValue(timeStamp, _stockExchange), 3);
             }
             else
             {
                 throw new StockExchangeException("Portfelj ne postoji!");
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime firstDay = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             DateTime lastDay = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             return Math.Round(100 * (GetPortfolioValue(inPortfolioID, lastDay) - GetPortfolioValue(inPortfolioID, firstDay)) / GetPortfolioValue(inPortfolioID, firstDay), 3);
         }
     }
}
