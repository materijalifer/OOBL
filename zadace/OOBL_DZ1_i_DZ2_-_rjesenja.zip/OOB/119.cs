﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        Dictionary<string, Stock> stocks; //skup svih dionica na burzi
        Dictionary<string, Index> indices; //skup svih indeksa na burzi
        Dictionary<string, Portfolio> portfolios; //skup svih portfolija na burzi

        public StockExchange()
        {
            stocks = new Dictionary<string, Stock>();
            indices = new Dictionary<string, Index>();
            portfolios = new Dictionary<string, Portfolio>();
        }

        #region Helper methods

        /// <summary>
        /// Pomocna metoda za ujednacavanje imena dionica i indeksa
        /// </summary>
        /// <param name="name">pocetno ime koje unose korisnici</param>
        /// <returns>ime velikim slovima</returns>
        private string getName(string name)
        {
            return name.ToUpper();
        }

        /// <summary>
        /// Pomocna metoda za dohvacanje dionice iz burze.
        /// Ukoliko ne postoji baca se iznimka.
        /// </summary>
        /// <param name="name">ime dionice</param>
        /// <returns>trazena dionica</returns>
        private Stock getStock(string name)
        {
            string stockName = getName(name);
            if (!StockExists(stockName))
                throw new StockExchangeException("Stock does not exist");

            return stocks[stockName];
        }

        /// <summary>
        /// Pomocna metoda za dohvacanje indeksa iz burze.
        /// Ukoliko ne postoji baca se iznimka.
        /// </summary>
        /// <param name="name">ime indeksa</param>
        /// <returns>trazeni indeks</returns>
        private Index getIndex(string name)
        {
            string indexName = getName(name);
            if (!IndexExists(indexName))
                throw new StockExchangeException("Index does not exist");

            return indices[indexName];
        }

        /// <summary>
        /// Pomocna metoda za dohvacanje portfolija iz burze.
        /// Ukoliko ne postoji baca se iznimka.
        /// </summary>
        /// <param name="name">ime portfolija</param>
        /// <returns>trazeni portfolio</returns>
        private Portfolio getPortfolio(string name)
        {
            string portName = getName(name);
            if (!PortfolioExists(portName))
                throw new StockExchangeException("Portfolio does not exist");

            return portfolios[portName];
        }

        /// <summary>
        /// Pimićna metoda za zaokruživanje brojeva
        /// </summary>
        private decimal round(decimal num)
        {
            return Math.Round(num, 3);
        }

        #endregion

        #region Stock methods

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Number of shares can't be negative");

            if (inInitialPrice <= 0)
                throw new StockExchangeException("Initial price can't be negative");

            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            if (StockExists(inStockName))
                throw new StockExchangeException("Stock is already listed");

            stocks.Add(getName(inStockName), newStock);

        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName)) {
                stocks.Remove(getName(inStockName));

                Stock stock = getStock(inStockName);

                foreach (String name in indices.Keys)
                    if (indices[name].ContainsStock(stock)) indices[name].RemoveStock(stock);

                foreach (String name in portfolios.Keys)
                    if (portfolios[name].ContainsStock(stock)) indices[name].RemoveStock(stock);

            }
            else throw new StockExchangeException("Stock is not listed");
        }

        public bool StockExists(string inStockName)
        {
            return stocks.ContainsKey(getName(inStockName));
        }

        public int NumberOfStocks()
        {
            return stocks.Keys.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0)
                throw new StockExchangeException("Price can't be negative");

            getStock(inStockName).SetPrice(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return round(getStock(inStockName).GetPrice(inTimeStamp));
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return round(getStock(inStockName).GetInitialPrice());
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return round(getStock(inStockName).GetLastPrice());
        }

        #endregion

        #region Index methods

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (!IndexExists(inIndexName))
            {

                switch (inIndexType)
                {
                    case IndexTypes.AVERAGE:
                        indices.Add(getName(inIndexName), new AvarageIndex(getName(inIndexName)));
                        break;
                    case IndexTypes.WEIGHTED:
                        indices.Add(getName(inIndexName), new WeightedIndex(getName(inIndexName)));
                        break;
                    default:
                        throw new StockExchangeException("Forbidden index type");
                }
            }
            else
            {
                throw new StockExchangeException("Index already exists");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            getIndex(inIndexName).AddStock(getStock(inStockName));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = getIndex(inIndexName);

            if (StockExists(inStockName))
                index.RemoveStock(getStock(inStockName));
            else throw new StockExchangeException("Stock is not listed");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (StockExists(inStockName))
                return getIndex(inIndexName).ContainsStock(getStock(inStockName));
            else throw new StockExchangeException("Stock is not listed");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return round(getIndex(inIndexName).getValue(inTimeStamp));
        }

        public bool IndexExists(string inIndexName)
        {
            return indices.ContainsKey(getName(inIndexName));
        }

        public int NumberOfIndices()
        {
            return indices.Keys.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return getIndex(inIndexName).NumberOfStocks();
        }

        #endregion

        #region Portfolio methods

        public void CreatePortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
            else 
                throw new StockExchangeException("Portfolio already exists");
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = getStock(inStockName);
            int totalShares = 0;
            foreach (String name in portfolios.Keys)
            {
                Portfolio port = portfolios[name];
                if (port.ContainsStock(stock))
                {
                    totalShares += port.NumberOfShares(stock);
                }
            }

            if (totalShares + numberOfShares > stock.Quantitiy)
                throw new StockExchangeException("Selected number of shares is not available");

            getPortfolio(inPortfolioID).AddStock(stock, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            getPortfolio(inPortfolioID).RemoveStock(getStock(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inStockName)) return;
            getPortfolio(inPortfolioID).RemoveStock(getStock(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Keys.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return getPortfolio(inPortfolioID).NumberOfStocks();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolios.Keys.Contains(inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return getPortfolio(inPortfolioID).ContainsStock(getStock(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return getPortfolio(inPortfolioID).NumberOfShares(getStock(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return round(getPortfolio(inPortfolioID).GetValue(timeStamp));
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            return round(getPortfolio(inPortfolioID).GetPercentChangeInValueForMonth(Year, Month));
        }
        #endregion
    }

    /// <summary>
    /// Razred koji predstavlja dionicu na burzi
    /// </summary>
    public class Stock
    {
        private string name; //ime dionice
        private long quantitiy; //ukupan broj dostupan na burzi
        private Dictionary<DateTime, decimal> prices; //popis cijena sa vremenskim trenucima
        private DateTime initialTimeStamp; //početni trenutak od kada je stvorena dionica

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public long Quantitiy
        {
            get { return quantitiy; }
        }

        public Stock(string name, long quant, decimal price, DateTime timeStamp)
        {
            this.name = name;
            this.quantitiy = quant;
            this.initialTimeStamp = timeStamp;
            prices = new Dictionary<DateTime, decimal>();
            prices.Add(timeStamp, price);
        }

        /// <summary>
        /// Usporedba dionica prema imenu
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (!(obj is Stock)) return false;
            Stock stock = (Stock)obj;

            return stock.Name.ToUpper() == this.name.ToUpper();

        }

        /// <summary>
        /// Postavlja cijenu dionice za zadani trenutak
        /// </summary>
        public void SetPrice(decimal price, DateTime timestamp)
        {
            if (timestamp < initialTimeStamp)
                throw new StockExchangeException("Stock was not yet listed in selected moment");

            prices.Add(timestamp, price);
        }

        /// <summary>
        /// Vraca cijenu dionice u zadanom trenutku
        /// </summary>
        public decimal GetPrice(DateTime timeStamp)
        {
            List<DateTime> stamps = getSortedStamps();
            for (int i = stamps.Count - 1; i >= 0; i--)
            {
                if (stamps[i] <= timeStamp)
                {
                    return prices[stamps[i]];
                    
                }
            }
            throw new StockExchangeException("Price was not set for that moment");
        }
        
        /// <summary>
        /// Pomoćna funkcija koja vraća sortirana vremena
        /// </summary>
        private List<DateTime> getSortedStamps()
        {
            List<DateTime> stamps = prices.Keys.ToList();
            stamps.Sort();
            return stamps;
        }

        /// <summary>
        /// Daje početnu vrijednost dionice
        /// </summary>
        public decimal GetInitialPrice()
        {
            return prices[initialTimeStamp];
        }

        /// <summary>
        /// Daje posljednju vrijednost dionice
        /// </summary>
        public decimal GetLastPrice()
        {
            DateTime stamp = initialTimeStamp;
            foreach (DateTime st in prices.Keys)
                if (st > stamp) stamp = st;
            return prices[stamp];
        }
    }

    /// <summary>
    /// Razred koji predstavlja indeks na burzi
    /// </summary>
    public abstract class Index
    {
        protected string name;
        protected List<Stock> stocks;

        public Index(string name)
        {
            this.name = name;
            stocks = new List<Stock>();
        }

        /// <summary>
        /// Provjerava da li je zadana dionica u indeksu
        /// </summary>
        public bool ContainsStock(Stock stock)
        {
            return stocks.Contains(stock);
        }

        /// <summary>
        /// Dodaje dionicu u indeks
        /// </summary>
        public void AddStock(Stock stock)
        {
            if (ContainsStock(stock))
                throw new StockExchangeException("Stock is already in index");

            stocks.Add(stock);
        }

        /// <summary>
        /// Uklanja dionicu iz indeksa
        /// </summary>
        public void RemoveStock(Stock stock)
        {
            if (ContainsStock(stock))
                stocks.Remove(stock);
            else
                throw new StockExchangeException("Stock is not in index");
        }

        /// <summary>
        /// Vraća broj dionica u indeksu
        /// </summary>
        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        /// <summary>
        /// Template metoda za racunanje vrijednosti indeksa
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public abstract decimal getValue(DateTime timeStamp);
        
    }

    /// <summary>
    /// vrijednost indeksa se računa kao jednostavan prosjek cijene svih dionica u indeksu
    /// </summary>
    public class AvarageIndex : Index
    {
        public AvarageIndex(string name) : base(name) { }

        public override decimal getValue(DateTime timeStamp)
        {
            decimal value = 0;
            foreach (Stock stock in stocks)
            {
                value += stock.GetPrice(timeStamp);
            }
            return value / NumberOfStocks();
        }
    }

    /// <summary>
    /// vrijednost indeksa se računa kao težinski prosjek cijene svih dionica u indeksu
    /// </summary>
    public class WeightedIndex : Index
    {
        public WeightedIndex(string name) : base(name) { }

        public override decimal getValue(DateTime timeStamp)
        {
            decimal value = 0;
            decimal priceSum = 0;
            foreach (Stock stock in stocks)
            {
                decimal price = stock.GetPrice(timeStamp);
                priceSum += (price * stock.Quantitiy);
                value += price * (price * stock.Quantitiy);
            }
            return (value / priceSum);
        }
    }

    /// <summary>
    /// Razred koji predstavlja portfolio na burzi
    /// </summary>
    public class Portfolio
    {
        string id;
        Dictionary<Stock, int> shares;

        public Portfolio(string id)
        {
            this.id = id;
            this.shares = new Dictionary<Stock, int>();
        }

        /// <summary>
        /// Dodaje zadani broj neke dionice u portfolio
        /// </summary>
        public void AddStock(Stock stock, int share)
        {
            if (share == 0) return;
            if (share < 0)
                throw new StockExchangeException("Share number can't be negative");

            if (!ContainsStock(stock))
            {
                shares.Add(stock, share);
            }
            else
            {
                shares[stock] += share;
            }
            
        }

        /// <summary>
        /// Provjerava da li zadana dionica postoji u portfoliju
        /// </summary>
        public bool ContainsStock(Stock stock)
        {
            return shares.ContainsKey(stock);
        }

        /// <summary>
        /// Uklanja određeni broj dionica iz portfolija
        /// </summary>
        public void RemoveStock(Stock stock, int share)
        {
            if (share == 0) return;
            if (share < 0)
                throw new StockExchangeException("Share number can't be negative");

            if (!ContainsStock(stock))
                throw new StockExchangeException("Stock is not in portfolio");

            if (shares[stock] < share)
                throw new StockExchangeException("Can't remove more shares, then there are in portfolio");

            shares[stock] -= share;
            if (shares[stock] == 0)
                shares.Remove(stock);

        }

        /// <summary>
        /// Briše dionicu iz portfolija
        /// </summary>
        public void RemoveStock(Stock stock)
        {
            if (ContainsStock(stock))
                shares.Remove(stock);
            else throw new StockExchangeException("Stock is not in portfolio");
        }

        /// <summary>
        /// Vraća ukupan broj dionica u portfoliju
        /// </summary>
        public int NumberOfStocks()
        {
            return shares.Keys.Count;
        }

        /// <summary>
        /// Vraća količinu od zadane dionice u portfoliju
        /// </summary>
        public int NumberOfShares(Stock stock)
        {
            if (!ContainsStock(stock)) return 0;
            return shares[stock];
        }

        /// <summary>
        /// Vraća vrijednost portfelja za zadani trenutak
        /// </summary>
        public decimal GetValue(DateTime timeStamp)
        {
            decimal value = 0;
            foreach (Stock stock in shares.Keys)
            {
                value += stock.GetPrice(timeStamp) * shares[stock];
            }
            return Math.Round(value,3);
        }

        /// <summary>
        /// Računa postotak mjesečne promjene vrijednosti portfelja
        /// </summary>
        public decimal GetPercentChangeInValueForMonth(int year, int month)
        {
            DateTime startDay = new DateTime(year, month, 1, 0, 0, 0, 0);
            DateTime endDay = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

            decimal startValue = GetValue(startDay);
            decimal endValue = GetValue(endDay);
            if (startValue == 0) throw new StockExchangeException("Value can't be calculated");

            return (endValue - startValue) / startValue * 100;
        }

    }


}
