﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new BasicCalculatorWith10Digits();
        }
    }

    /// <summary>
    /// Interface for a calculator screen.
    /// </summary>
    public interface ICalculatorScreen
    {
        void SetDisplay(string screenString);
        string GetDisplay();
        void ResetDisplay();
    }

    /// <summary>
    /// Calculator screen.
    /// </summary>
    public class CalculatorScreen : ICalculatorScreen
    {
        // screen state
        private string screenString;

        public CalculatorScreen()
        {
            screenString = "";
        }

        /// <summary>
        /// Clears the screen and and sets screen to display new string.
        /// </summary>
        /// <param name="screenString">String to be displayed on screen.</param>
        public void SetDisplay(string screenString)
        {
            this.screenString = screenString;
        }

        /// <summary>
        /// Retrieves current state of display.
        /// </summary>
        /// <returns>Currently displayed string.</returns>
        public string GetDisplay()
        {
            return screenString;
        }

        /// <summary>
        /// Clears the screen.
        /// </summary>
        public void ResetDisplay()
        {
            SetDisplay("");
        }
    }

    /// <summary>
    /// Control class for basic calculator that can display 10 digits at most.
    /// Basic calculator can only execute simple arithmetic operations.
    /// </summary>
    public class BasicCalculatorWith10Digits : ICalculator
    {
        // current operand that calculator works with
        private double currentOperand;

        // operand stored in memory
        private double storedOperand;

        // last binary operation that has been created
        private BinaryOperation lastBinaryOperation;

        // flag for operand state
        // operand can be created from input or from last executed operation
        private bool isOperandResultFromOperation;

        // constants
        private static readonly long upperNumberBoundary = 10000000000;
        private static readonly string errorMessage = "-E-";

        // screen for displaying current operand.
        ICalculatorScreen calculatorScreen;

        /// <summary>
        /// Constructor for BasicCalculator.
        /// Creates a new calculator screen and displays the current operand.
        /// </summary>
        public BasicCalculatorWith10Digits()
        {
            // Zvone said we can count on this but we don't believe him
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            calculatorScreen = new CalculatorScreen();
            ClearCurrentOperand();
            storedOperand = 0;
            isOperandResultFromOperation = false;
        }

        /// <summary>
        /// Key press main handler.
        /// </summary>
        /// <param name="inPressedDigit">Character representing button that was clicked.</param>
        public void Press(char inPressedDigit)
        {
            try
            {
                if (IsCalculatorInErrorState())
                {
                    if (!(inPressedDigit.Equals('C') || inPressedDigit.Equals('O')))
                    {
                        throw new ArithmeticException();
                    }
                }
                else if (Char.GetNumericValue(inPressedDigit) != -1.0)
                {
                    ProcessNumberPress(inPressedDigit);
                }
                else
                {
                    ProcessOperationPress(inPressedDigit);
                }
            }
            catch (ArithmeticException e)
            {
                DisplayErrorMessageOnScreen();
            }
        }

        /// <summary>
        /// Sets screen to display passed string.
        /// </summary>
        /// <param name="screenString">String to be displayed on screen.</param>
        private void SetCalculatorDisplay(string screenString)
        {
            calculatorScreen.SetDisplay(screenString);
        }

        /// <summary>
        /// Update screen with current operand.
        /// </summary>
        private void UpdateCalculatorScreen()
        {
            SetCalculatorDisplay("" + currentOperand);
        }

        /// <summary>
        /// Retrieve state of the screen.
        /// </summary>
        /// <returns>String state of the screen.</returns>
        public string GetCurrentDisplayState()
        {
            return calculatorScreen.GetDisplay();
        }

        /// <summary>
        /// Displays an error message on screen.
        /// </summary>
        public void DisplayErrorMessageOnScreen()
        {
            calculatorScreen.SetDisplay(errorMessage);
        }

        /// <summary>
        /// Checks if error message is currently displayed on screen.
        /// </summary>
        /// <returns>Error state of the screen.</returns>
        public bool IsCalculatorInErrorState()
        {
            if (calculatorScreen.GetDisplay().Equals(errorMessage))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Round and set current operand to new operand.
        /// </summary>
        /// <param name="operand">Operand to replace currently set one.</param>
        private void SetCurrentOperand(double operand)
        {
            this.currentOperand = ProcessDoubleToFitOnScreen(operand);
        }

        /// <summary>
        /// Round and truncate double number to fit on screen.
        /// </summary>
        /// <param name="number">Double to be processed.</param>
        /// <returns>Processed double.</returns>
        private double ProcessDoubleToFitOnScreen(double number)
        {
            // In case number is equal to 0, it surely fits on the screen (we don't want to pass 0 to log function)
            if (number == 0)
            {
                return 0;
            }

            double testedNumber = Math.Abs(number);
            double result;

            // number of digits is equal to floor( log10 (x) ) + 1
            double testedNumberLog10 = Math.Log10(testedNumber);
            int numberOfUsedCharacters = Convert.ToInt32(Math.Floor(Math.Abs(testedNumberLog10))) + 1;

            // if integer part of double has more than 10 digits, truncate it
            if (numberOfUsedCharacters >= 10)
            {
                double truncatedOperand = number % upperNumberBoundary;
                result = Math.Round(number, 0, MidpointRounding.AwayFromZero);
            }
            // always round the number
            else
            {
                int numberOfAvailableCharacters = 10 - numberOfUsedCharacters;
                result = Math.Round(number, numberOfAvailableCharacters, MidpointRounding.AwayFromZero);
            }

            return result;
        }

        /// <summary>
        /// Process number key press.
        /// </summary>
        /// <param name="inPressedDigit">Inserted double.</param>
        private void ProcessNumberPress(char inPressedDigit)
        {
            if (isOperandResultFromOperation)
            {
                SetCurrentOperand(0);
                SetCalculatorDisplay("" + 0);
                isOperandResultFromOperation = false;
            }

            string appendedOperand = "";

            if (!GetCurrentDisplayState().Equals("0"))
            {
                appendedOperand += GetCurrentDisplayState();
            }

            appendedOperand += inPressedDigit;
            SetCalculatorDisplay(appendedOperand);

            double newOperand = Convert.ToDouble(appendedOperand);
            SetCurrentOperand(newOperand);
        }

        private void ProcessOperationPress(char operationCharacter)
        {
            switch (operationCharacter)
            {
                case '=':
                    ProcessEqualOperation();
                    break;

                case ',':
                    ProcessCommaOperation();
                    break;

                case 'M':
                    ProcessChangeSignOperation();
                    break;

                case 'S':
                    ProcessSinOperation();
                    break;

                case 'K':
                    ProcessCosOperation();
                    break;

                case 'T':
                    ProcessTanOperation();
                    break;

                case 'Q':
                    ProcessQuadratOperation();
                    break;

                case 'R':
                    ProcessSqrtOperation();
                    break;

                case 'I':
                    ProcessInversOperation();
                    break;

                case 'P':
                    ProcessPutOperation();
                    break;

                case 'G':
                    ProcessGetOperation();
                    break;

                case 'C':
                    ProcessClearOperation();
                    break;

                case 'O':
                    ProcessOnOffOperation();
                    break;

                default:
                    ProcessBinaryOperation(operationCharacter);
                    break;
            }
        }

        private void ProcessEqualOperation()
        {
            BinaryOperation nextOperation = lastBinaryOperation;
            ExecuteLastBinaryOperation();
            if (nextOperation != null)
            {
                nextOperation.firstOperand = currentOperand;
            }
            lastBinaryOperation = nextOperation;
        }

        private void ProcessCommaOperation()
        {
            string currentScreenString = calculatorScreen.GetDisplay();
            if (!currentScreenString.Contains(','))
            {
                string newScreenString = currentScreenString + ',';
                calculatorScreen.SetDisplay(newScreenString);
            }
        }

        private void ProcessChangeSignOperation()
        {
            UnaryOperation changeSign = new ChangeSignOperation(currentOperand);
            SetCurrentOperand(changeSign.Execute());
            SetCalculatorDisplay("" + currentOperand);
        }

        private void ProcessSinOperation()
        {
            UnaryOperation sinOperation = new SinOperation(currentOperand);
            SetCurrentOperand(sinOperation.Execute());
            UpdateCalculatorScreen();
        }

        private void ProcessCosOperation()
        {
            UnaryOperation cosOperation = new CosOperation(currentOperand);
            SetCurrentOperand(cosOperation.Execute());
            UpdateCalculatorScreen();
        }

        private void ProcessTanOperation()
        {
            UnaryOperation tanOperation = new TanOperation(currentOperand);
            SetCurrentOperand(tanOperation.Execute());
            UpdateCalculatorScreen();
        }

        private void ProcessQuadratOperation()
        {
            UnaryOperation quadratOperation = new QuadratOperation(currentOperand);
            SetCurrentOperand(quadratOperation.Execute());
            UpdateCalculatorScreen();
        }

        private void ProcessSqrtOperation()
        {
            UnaryOperation sqrtOperation = new SqrtOperation(currentOperand);
            SetCurrentOperand(sqrtOperation.Execute());
            UpdateCalculatorScreen();
        }

        private void ProcessInversOperation()
        {
            UnaryOperation inversOperation = new InversOperation(currentOperand);
            SetCurrentOperand(inversOperation.Execute());
            UpdateCalculatorScreen();
            isOperandResultFromOperation = true;
        }

        private void ProcessPutOperation()
        {
            storedOperand = currentOperand;
        }

        private void ProcessGetOperation()
        {
            SetCurrentOperand(storedOperand);
            UpdateCalculatorScreen();
        }

        private void ProcessClearOperation()
        {
            ClearCurrentOperand();
        }

        private void ProcessOnOffOperation()
        {
            ClearCurrentOperand();
            lastBinaryOperation = null;
        }
        
        private void ProcessBinaryOperation(char operationCharacter)
        {
            if (!isOperandResultFromOperation)
            {
                ExecuteLastBinaryOperation();
            }

            switch (operationCharacter)
            {
                case '+':
                    lastBinaryOperation = new AdditionOperation(currentOperand);
                    break;

                case '-':
                    lastBinaryOperation = new SubtractionOperation(currentOperand);
                    break;

                case '*':
                    lastBinaryOperation = new MultiplicationOperation(currentOperand);
                    break;

                case '/':
                    lastBinaryOperation = new DivisionOperation(currentOperand);
                    break;

                default:
                    throw new ArithmeticException();
            }
        }

        /// <summary>
        /// Sets 2nd operand of last binary operation and then executes it.
        /// </summary>
        private void ExecuteLastBinaryOperation()
        {
            if (lastBinaryOperation != null)
            {
                if (lastBinaryOperation.secondOperand == null)
                {
                    lastBinaryOperation.secondOperand = currentOperand;
                }
                double result = lastBinaryOperation.Execute();

                SetCurrentOperand(result);

                if (currentOperand / upperNumberBoundary >= 1)
                {
                    throw new OverflowException();
                }
            }
            UpdateCalculatorScreen();
            lastBinaryOperation = null;
            isOperandResultFromOperation = true;
        }

        /// <summary>
        /// Clears current operand and updates screen.
        /// </summary>
        private void ClearCurrentOperand()
        {
            SetCurrentOperand(0);
            UpdateCalculatorScreen();
        }
    }

    public abstract class UnaryOperation
    {
        public double operand { get; set; }

        public UnaryOperation(double operand)
        {
            this.operand = operand;
        }

        public abstract double Execute();
    }

    public abstract class BinaryOperation
    {
        public double? firstOperand { get; set; }
        public double? secondOperand { get; set; }

        public BinaryOperation(double firstOperand)
        {
            this.firstOperand = firstOperand;
        }

        public abstract double Execute();
    }

    public class AdditionOperation : BinaryOperation
    {
        public AdditionOperation(double firstOperand)
            : base(firstOperand)
        {
        }

        public override double Execute()
        {
            return firstOperand.Value + secondOperand.Value;
        }
    }

    public class SubtractionOperation : BinaryOperation
    {
        public SubtractionOperation(double firstOperand)
            : base(firstOperand)
        {
        }

        public override double Execute()
        {
            return firstOperand.Value - secondOperand.Value;
        }
    }

    public class MultiplicationOperation : BinaryOperation
    {
        public MultiplicationOperation(double firstOperand)
            : base(firstOperand)
        {
        }

        public override double Execute()
        {
            return firstOperand.Value * secondOperand.Value;
        }
    }

    public class DivisionOperation : BinaryOperation
    {
        public DivisionOperation(double firstOperand)
            : base(firstOperand)
        {
        }

        public override double Execute()
        {
            return firstOperand.Value / secondOperand.Value;
        }
    }

    public class ChangeSignOperation : UnaryOperation
    {
        public ChangeSignOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return -1 * operand;
        }
    }

    public class SinOperation : UnaryOperation
    {
        public SinOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return Math.Sin(operand);
        }
    }

    public class CosOperation : UnaryOperation
    {
        public CosOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return Math.Cos(operand);
        }
    }

    public class TanOperation : UnaryOperation
    {
        public TanOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return Math.Tan(operand);
        }
    }

    public class QuadratOperation : UnaryOperation
    {
        public QuadratOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return Math.Pow(operand, 2);
        }
    }

    public class SqrtOperation : UnaryOperation
    {
        public SqrtOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return Math.Sqrt(operand);
        }
    }

    public class InversOperation : UnaryOperation
    {
        public InversOperation(double operand)
            : base(operand)
        {
        }

        public override double Execute()
        {
            return 1 / operand;
        }
    }
}
