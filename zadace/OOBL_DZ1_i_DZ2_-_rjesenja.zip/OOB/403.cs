﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    //private ICalculator calculator;  

    public class Kalkulator:ICalculator
    {
        string display = "0";
        string buff = "";
        string mem = "";
        bool memAkt = false;
        char lastBinaryOperator='x';
        string secondOperand = "";
        bool lastOperator = false;
        public void Press(char inPressedDigit)
        {
            //throw new NotImplementedException();

            switch (inPressedDigit)
            {
                #region unos znamenki
                case '0': 
                    if (display.Equals("0")){}
                    else
                    {
                        //display += "0";
                        unesiZnamenka('0');
                    }
                    break;
                
                case '1':
                    unesiZnamenka('1');
                    break;
                case '2':
                    unesiZnamenka('2');
                    break;
                case '3':
                    unesiZnamenka('3');
                    break;
                case '4':
                    unesiZnamenka('4');
                    break;
                case '5':
                    unesiZnamenka('5');
                    break;
                case '6':
                    unesiZnamenka('6');
                    break;
                case '7':
                    unesiZnamenka('7');
                    break;
                case '8':
                    unesiZnamenka('8');
                    break;
                case '9':
                    unesiZnamenka('9');
                    break;
                #endregion

                case 'C' :
                    display = "0";
                    break;
                case 'O':
                    display = "0";
                    buff = "";
                    mem = "";
                    lastBinaryOperator = 'x';
                    secondOperand = "";
                    lastOperator = false;
                    break;
                case 'M':
                    if (display.Equals("0")) {  }
                    else
                    {
                        if (display[0].Equals('-'))
                        {
                            display.Substring(1);
                            
                        }
                        else
                        {
                            display = "-" + display;
                            
                        }
                    }
                    break;
                case '-' :
                    doOperation();
                    lastBinaryOperator = '-';
                    buff = display;
                    lastOperator = true;
                    break;
                case '+':
                    doOperation();
                    lastBinaryOperator = '+';
                    buff = display;
                    lastOperator = true;
                    break;
                case '*':
                    doOperation();
                    lastBinaryOperator = '*';
                    buff = display;
                    lastOperator = true;
                    break;
                case '/':
                    doOperation();
                    lastBinaryOperator = '/';
                    buff = display;
                    lastOperator = true;
                    break;
                case ',':
                    if(!display.Contains(','))
                    display += ',';
                    break;
                case 'P':
                    if (!display.Equals("0"))
                    {
                        mem = display;
                        memAkt = true;
                    }
                    break;
                case 'G':
                    if (!display.Equals("0"))
                    {
                        display = mem;
                    }
                    break;
                case 'Q':
                    display = (Convert.ToDouble(display) * Convert.ToDouble(display)).ToString();
                    break;
                case 'S':
                    display = round(Math.Sin(Convert.ToDouble(display)).ToString());
                    break;
                case 'K':
                    double a = Convert.ToDouble(display);
                    double d = Math.Cos(a);
                    display = round(d.ToString());
                    break;
                case 'T':
                    display = round(Math.Tan(Convert.ToDouble(display)).ToString());
                    break;
                case 'R':
                    if (display.StartsWith("-")) { display = "-E-"; }
                    else
                    {
                        display = round(Math.Sqrt(Convert.ToDouble(display)).ToString());
                    }
                    break;
                case 'I':
                    if (display.Equals("0")) display = "-E-";
                    else
                    {
                        display = round(Math.Pow(Convert.ToDouble(display), -1).ToString());
                    }
                    break;
                case '=':
                    operation();
                    break;

                
                default:
                    display = "-E-";
                    break;
            }
        }

        private void doOperation()
        {
            if (!buff.Equals("") && !lastOperator)
                operation();
            lastOperator = false;
            lastBinaryOperator = 'x';
        }

        private void unesiZnamenka(char znamenka)
        {
            if (lastOperator == true)
            {
                display = znamenka.ToString();
                lastOperator = false;
            }
            else if (display.Equals("0")) { display = znamenka.ToString(); }
            else
            {
                if (displayLenghtCheck())
                {
                    if (!memAkt)
                        display += znamenka;
                    else
                    {
                        display = znamenka.ToString();
                        memAkt = false;
                    }

                }
            }
        }

        private void operation()
        {
            
            double a = 0;
            double b = 0;

            if (!buff.Equals(""))
            {
                a = Convert.ToDouble(buff);
            }
            if (display.Equals("0") || display.Equals("0,") || display.Equals(""))
            {
                b = 0.0;
            }
            else b = Convert.ToDouble(display);

            switch (lastBinaryOperator)
            {
                case '-':
                    display = (a - b).ToString();
                    break;
                case '+':
                    display = (a + b).ToString();
                    break;
                case '*':
                    display = (a * b).ToString();
                    break;
                case '/':
                    if (b == 0)
                    {
                        display = "-E-";
                    }
                    else
                    {
                        display = (a / b).ToString();
                    }
                    break;
                    
            }

            if (!displayLenghtCheck())
            {
                display = "-E-";
            }
        }

        private string round(string disp)
        {
            
            string r = "";
            if (disp.Contains(','))
            {
                string[] part = disp.Split(',');
                int wholeN;
                
                if (disp.StartsWith("-"))
                {
                    wholeN = part[0].Length - 1;
                    if (wholeN > 10) return "-E-";
                }
                else
                {
                    wholeN = part[0].Length;
                    if (wholeN > 10) return "-E-";
                }

                r = Math.Round(Convert.ToDouble(disp), 10 - wholeN).ToString();
            }

            return r;
        }

        private void naturalNumber()
        {
            
            if (display.Contains(','))
            {
                string[] part = display.Split(',');
                if (Convert.ToDouble(part[1]) == 0.0)
                {
                    display = part[0];
                }
            }
        }

        private bool displayLenghtCheck()
        {
            if (display.StartsWith("-") && display.Contains(",") && display.Length > 12)
            {
                return false;
            }
            else if (display.StartsWith("-") && !display.Contains(",") && display.Length > 11)
            {
                return false;
            }
            else if (!display.StartsWith("-") && !display.Contains(",") && display.Length > 10)
            {
                return false;
            }
            else if (!display.StartsWith("-") && display.Contains(",") && display.Length > 10)
            {
                return false;
            }
            else return true;
        }

        public string GetCurrentDisplayState()
        {
            naturalNumber();
            //throw new NotImplementedException();
            return display;
        }
    }


}
