﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private int brojBrojeva=0;
        private string stanjeDisplay;
        private double stanjeBroj;
        private string brojIzMemorije;
       // private double prethodniBroj;
        private double prviOperand;
        private double drugiOperand;
        private char prethodniZnak;
        private bool operacijeZastavica=false;
        private char trenutnaOperacija;
        private List<char> binarnaOperacija = new List<char> {'+','-','*','/' };
        private List<char> unarnaOperacija = new List<char> {'S','K','T','Q','R','I' };
        private List<char> brojevi = new List<char>{ '0', '1','2','3','4','5','6','7','8','9'};
        private bool decimalniBroj=false;
        

        public void Press(char inPressedDigit)
        {
            
            double pomocniBroj;
            if(brojevi.Contains(inPressedDigit))
            {
                if(binarnaOperacija.Contains(prethodniZnak))
                {
                    trenutnaOperacija=prethodniZnak;
                }
                dodajNaDisplay(inPressedDigit);
            }
            else
            {
                
                switch (inPressedDigit)
                {

                    case ',':
                        if (!decimalniBroj)
                        {
                            decimalniBroj = true;
                            dodajNaDisplay(inPressedDigit);

                        }
                        break;
                    case '+':
                        format();
                        obradiBinarnuOperaciju(inPressedDigit);
                        break;
                    case '-':
                        format();
                        obradiBinarnuOperaciju(inPressedDigit);
                        break;
                    case '*':
                        format();
                        obradiBinarnuOperaciju(inPressedDigit);
                        break;
                    case '/':
                        format();
                        obradiBinarnuOperaciju(inPressedDigit);
                        break;
                    case '=':
                        obaviJednakost();
                        break;
                    case 'M':
                        stanjeDisplay = stanjeDisplay.Insert(0, "-");
                        format();
                        break;
                    case 'S':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Sin(pomocniBroj);
                        obnovi();
                        break;
                    case 'K':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Cos(pomocniBroj);
                        obnovi();
                        break;
                    case 'T':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Tan(pomocniBroj);
                        obnovi();
                        break;
                    case 'Q':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Pow(pomocniBroj, 2);
                        obnovi();
                        break;
                    case 'R':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Sqrt(pomocniBroj);
                        obnovi();
                        break;
                    case 'I':
                        Double.TryParse(GetCurrentDisplayState(), out pomocniBroj);
                        stanjeBroj = Math.Pow(pomocniBroj, -1);
                        obnovi();
                        break;
                    case 'P':
                        brojIzMemorije = stanjeDisplay;
                        break;
                    case 'G':
                        stanjeDisplay = brojIzMemorije;
                        break;
                    case 'C':
                        stanjeDisplay = "0";
                        stanjeBroj = 0;
                        break;
                    case 'O':
                        ugasi();
                        break;

                }
                
              

               
            }

            if(unarnaOperacija.Contains(inPressedDigit) && binarnaOperacija.Contains(prethodniZnak))
            {
                trenutnaOperacija=prethodniZnak;
            }
            prethodniZnak = inPressedDigit;

        }

        public string GetCurrentDisplayState()
        {
            format();
            return stanjeDisplay;
        }

        private void obaviOperaciju()
        {
            operacijeZastavica = false;
            switch (trenutnaOperacija)
            {
                case '+':
                    stanjeBroj = prviOperand + drugiOperand;
                    break;

                case '-':
                    stanjeBroj = prviOperand - drugiOperand;
                    break;

                case '*':
                    stanjeBroj = prviOperand * drugiOperand;
                    break;

                case '/':
                    stanjeBroj = prviOperand / drugiOperand;
                    break;
            }
            obnovi();
        }
        private void obradiBinarnuOperaciju(char pritisnutiDigit)
        {
            
         /*   if(binarnaOperacija.Contains(pritisnutiDigit))
            {
                trenutnaOperacija=pritisnutiDigit;
            }*/
            if (binarnaOperacija.Contains(prethodniZnak))//provjerava prethodni znak, te da li je binrani operator
            {
                if (pritisnutiDigit == '=')
                {
                    trenutnaOperacija = prethodniZnak;
                    Double.TryParse(GetCurrentDisplayState(), out drugiOperand);
                    obaviOperaciju();
                    return;
                }
                return;
            }
            else if (Char.IsNumber(prethodniZnak)||unarnaOperacija.Contains(prethodniZnak)||prethodniZnak==',')
            {
                if (operacijeZastavica)
                {
                    Double.TryParse(GetCurrentDisplayState(), out drugiOperand);
                    obaviOperaciju();
                    return;
                }
                Double.TryParse(GetCurrentDisplayState(), out prviOperand);
                operacijeZastavica = true;
                return;
            }
        }
        private void obaviJednakost()
        {
            if (prethodniZnak == '=')
            {
                Double.TryParse(GetCurrentDisplayState(),out prviOperand);
                obaviOperaciju();
                return;
            }
            obradiBinarnuOperaciju('=');
        }
        private void dodajNaDisplay(char inPressedDigit)
        {
            if (brojBrojeva == 11)
            {
                return;
            }
        
            if(binarnaOperacija.Contains(prethodniZnak) || prethodniZnak =='=' ||unarnaOperacija.Contains(prethodniZnak))
            {
                stanjeDisplay=inPressedDigit.ToString();
                decimalniBroj = false;
                brojBrojeva = 0;
            }
            else
            {
                brojBrojeva++;
                stanjeDisplay += inPressedDigit;
            }
            
        }
        private void format()
        {
            if (stanjeDisplay == "-E-")
            {
                return;
            }
          
            Double.TryParse(stanjeDisplay, out stanjeBroj);
            stanjeDisplay = Math.Round(stanjeBroj, 9).ToString();
            if (stanjeDisplay == "Infinity")
            {
                stanjeDisplay = "-E-";
            }
            
            //stanjeDisplay=stanjeBroj.ToString("##########.#########");
        }
        private void obnovi()
        {
            if (stanjeBroj > 999999999 || stanjeBroj < -9999999999)
            {
                stanjeDisplay = "-E-";
            }
            else
            {
                stanjeDisplay = Math.Round(stanjeBroj, 9).ToString();
            }
            
            //stanjeDisplay = stanjeBroj.ToString("##########.#########");
        }
        private void ugasi()
        {
            stanjeDisplay = "0";
            stanjeBroj = 0;
            brojIzMemorije = null;
           // private double prethodniBroj;
            //prviOperand =
          //  drugiOperand = null;
           // prethodniZnak = null;
            operacijeZastavica=false;
           // trenutnaOperacija = null;
            decimalniBroj=false;
        }
        
    }


}
