﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Calculator:ICalculator
    {
        private string displayState;
        private string memory;
        private string currentExpression;
        bool newDisplay;
        private LinkedList<char> currentState = new LinkedList<char>();
        public Calculator()
        {
            reset();
        }
        public void Press(char inPressedDigit)
        {
            if (char.IsDigit(inPressedDigit)||inPressedDigit==',')
            {
                if (displayState == "-E-")
                {
                    reset();
                }
                if (newDisplay)
                {
                    displayState = null;
                    newDisplay = false;
                }
                displayState += inPressedDigit;
                currentState.AddLast(inPressedDigit);
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '/' || inPressedDigit == '*')
            {
                newDisplay = true;
                currentState.AddLast(inPressedDigit);
                evaluateBinary();
            }
            else if (inPressedDigit == '=')
            {
                currentState.AddLast(inPressedDigit);
                equal();
            }
            else if (inPressedDigit == 'M' || inPressedDigit == 'S' || inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'K' || inPressedDigit == 'T' || inPressedDigit == 'I')
            {
                currentState.AddLast(inPressedDigit);
                evaluateUnary();
            }
            else if (inPressedDigit == 'P')
            {
                memory = displayState;
            }
            else if (inPressedDigit == 'G')
            {
                displayState = memory;
                while (true)
                {
                    if (currentState.Count != 0 && (char.IsDigit(currentState.Last()) || currentState.Last() == ',' || currentState.Last() == '.'))
                    {
                        currentState.RemoveLast();
                    }
                    else
                    {
                        break;
                    }
                }
                foreach (char c in memory)
                {
                    currentState.AddLast(c);
                }
            }
            else if (inPressedDigit == 'C')
            {
                clear();
            }
            else if (inPressedDigit == 'O')
            {
                reset();
            }
            else
            {
            }
        }

        private void equal()
        {
            string operand = null;
            char c;
            if (char.IsDigit(currentState.ElementAt(currentState.Count - 2)))
            {
                evaluateBinary();
                currentState.RemoveLast();
            }
            else
            {
                currentState.RemoveLast();
                while (char.IsDigit(c = currentState.First())||(c=currentState.First())==','||(c=currentState.First())=='.')
                {
                    operand += c;
                    currentState.RemoveFirst();
                }
                for (int i = operand.Length-1; i >= 0; i--)
                {
                    currentState.AddFirst(operand[i]);
                }
                for (int i = 0; i < operand.Length; i++)
                {
                    currentState.AddLast(operand[i]);
                }

                currentState.AddLast('=');
                evaluateBinary();
                currentState.RemoveLast();
            }
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        private void reset()
        {
            displayState = null;
            memory = null;
            currentExpression = null;
            currentState.Clear();
            currentState.AddLast('0');
        }

        private void clear()
        {
            char c;
            char op;
            c = currentState.Last();
            if (!char.IsDigit(c))
            {
                op = c;
                currentState.RemoveLast();
                while (char.IsDigit(c = currentState.Last()))
                {
                    currentState.RemoveLast();
                }
                currentState.AddLast(op);
            }
            else
            {
                while (char.IsDigit(c = currentState.Last()))
                {
                    currentState.RemoveLast();
                }
            }

            displayState = "0";
        }

        private void evaluateBinary()
        {
            float result=0;
            string first = null;
            string second = null;
            bool secondExists = false;
            char tempOperator;
            char endOperator=' ';
            char op;
            if (true)
            {
                char c;
                int i = 0;
                int j = 0;
                if (!char.IsDigit(currentState.ElementAt(currentState.Count - 2)))
                {
                    if (currentState.ElementAt(currentState.Count - 1) != '=')
                    {
                        tempOperator = currentState.Last();
                        currentState.RemoveLast();
                        currentState.RemoveLast();
                        currentState.AddLast(tempOperator);
                    }
                }
                while (char.IsDigit((c = currentState.First())) || ((c = currentState.First()) == ',') || ((c = currentState.First()) == '.'))
                {
                    if (c == ',')
                    {
                        c = '.';
                    }
                    first += c;
                    currentState.RemoveFirst();
                }
                op = c;
                currentState.RemoveFirst();
                while(true)
                {
                    if (currentState.Count == 0)
                    {
                        break;
                    }
                    c = currentState.First();
                    if (char.IsDigit(c)||c==','||c=='.')
                    {
                        if (c == ',')
                        {
                            c = '.';
                        }
                        secondExists = true;
                        second += c;
                        currentState.RemoveFirst();
                    }
                    else
                    {
                        endOperator = c;
                        currentState.RemoveFirst();
                    }
                }
                if (secondExists)
                {
                    switch (op)
                    {
                        case '+':
                            result = float.Parse(first) + float.Parse(second);
                            break;
                        case '-':
                            result = float.Parse(first) - float.Parse(second);
                            break;
                        case '*':
                            result = float.Parse(first) * float.Parse(second);
                            break;
                        case '/':
                            if (float.Parse(second) != 0)
                            {
                                result = float.Parse(first) / float.Parse(second);
                            }
                            else
                            {
                                displayState = "-E-";
                                return;
                            }
                            break;
                    }
                    if (result > 9999999999)
                    {
                        displayState = "-E-";
                        return;
                    }
                    currentExpression = result.ToString();
                    displayState = currentExpression;
                    currentState.AddFirst(endOperator);
                    for (int l = currentExpression.Length - 1; l >= 0; l--)
                    {
                        currentState.AddFirst(currentExpression[l]);
                    }
                }
                else
                {
                    currentState.AddFirst(op);
                    first = float.Parse(first).ToString();
                    displayState = first;
                    for (int l = first.Length - 1; l >= 0; l--)
                    {
                        currentState.AddFirst(first[l]);
                    }
                }
            }
        }

        private void evaluateUnary()
        {
            float result = 0;
            string first = null;
            string second = null;
            string operand = null;
            bool secondExists = false;
            bool otherOperation = false;
            string reverseOperand = null;
            char otherOp=' ';
            char op;
            float toEvaluate;
            char c;
            int i = 0;
            int j = 0;
            op = currentState.Last();
            currentState.RemoveLast();
            if (!char.IsDigit(c = currentState.Last()))
            {
                otherOp = c;
                currentState.RemoveLast();
                otherOperation = true;
                while ((char.IsDigit(c = currentState.Last())))
                {
                    operand += c;
                    currentState.RemoveFirst();
                }
                for (int n = operand.Length - 1; n >= 0; n--)
                {
                    reverseOperand += operand[n];
                }
                operand = reverseOperand;
            }
            else
            {
                while ((char.IsDigit(c = currentState.Last()))||((c=currentState.Last())==',')||((c=currentState.Last())=='.'))
                {
                    operand += c;
                    currentState.RemoveLast();
                }
                for (int n = operand.Length - 1; n >= 0; n--)
                {
                    reverseOperand += operand[n];
                }
                operand = reverseOperand;
            }

            switch (op)
            {
                case 'M':
                    result = -float.Parse(operand);
                    break;
                case 'S':
                    result = (float)Math.Sin(float.Parse(operand));
                    break;
                case 'K':
                    result = (float)Math.Cos(float.Parse(operand));
                    break;
                case 'T':
                    result = (float)Math.Tan(float.Parse(operand));
                    break;
                case 'R':
                    result = (float)Math.Sqrt(float.Parse(operand));
                    break;
                case 'Q':
                    result = (float)Math.Pow(float.Parse(operand), 2);
                    break;
                case 'I':
                    result = (float)1 / float.Parse(operand);
                    break;
            }
            if (result > 9999999999)
            {
                displayState = "-E-";
                return;
            }
            currentExpression = result.ToString();
            displayState = currentExpression;
            if (otherOperation)
            {

                currentState.AddLast(otherOp);
                for (int l = 0; l < currentExpression.Length; l++)
                {
                    currentState.AddLast(currentExpression[l]);
                }
            }
            else
            {
                for (int l = 0; l < currentExpression.Length; l++)
                {
                    currentState.AddLast(currentExpression[l]);
                }
            }
        }
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }
}
