﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator {

    #region Factory
    public class Factory {

        public static ICalculator CreateCalculator() {
            return new Kalkulator();
        }

    }
    #endregion Factory

    #region ICalculator implementation
    public class Kalkulator : ICalculator {

        #region Fields
        private const int MAX_NUM_OF_DIGITS = 10;
        private const char DECIMAL_SYMBOL = ',';
        private const string ERROR = "-E-";

        private delegate void DualOperation();

        private bool receiveNextOperand;
        private bool errorFlag;
        private bool canExecuteDualOperation;
        private InternalNumber storedResult;
        private InternalNumber memory;
        private DisplayNumber displayNumber;
        private DualOperation PreviousDualOperation;
        #endregion

        #region Constructors
        public Kalkulator() {
            InitializeCalculator();
        }
        #endregion

        #region Public methods
        public void Press(char inPressedDigit) {
            if (  errorFlag  &&  (inPressedDigit != 'C')
                                &&  (inPressedDigit != 'O')  ) {
                return;
            }

            switch (inPressedDigit) {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    if (CanReceiveNextOperand()) {
                        displayNumber = new DisplayNumber(
                                            0, MAX_NUM_OF_DIGITS, DECIMAL_SYMBOL
                        );

                        AllowDualOperationExecution();
                        AllowReceiveNextOperand(false);
                    }

                    displayNumber.Append(inPressedDigit);
                    break;
                case DECIMAL_SYMBOL:
                    if (CanReceiveNextOperand()) {
                        displayNumber = new DisplayNumber(
                                            0, MAX_NUM_OF_DIGITS, DECIMAL_SYMBOL
                        );

                        AllowDualOperationExecution();
                        AllowReceiveNextOperand(false);
                    }

                    displayNumber.MakeDecimal();
                    break;
                case 'M':
                    displayNumber.AlternateSign();
                    break;
                case 'C':
                    ClearScreen();
                    break;
                case 'O':
                    InitializeCalculator();
                    break;
                case 'G':
                    displayNumber = new DisplayNumber(
                                        memory.Value, MAX_NUM_OF_DIGITS, DECIMAL_SYMBOL
                    );
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'P':
                    memory = new InternalNumber(
                                    displayNumber.Value, MAX_NUM_OF_DIGITS
                    );
                    break;
                case 'I':
                    double inverse = 1 / displayNumber.Value;
                    DisplayResult(inverse);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'R':
                    double root = Math.Sqrt(displayNumber.Value);
                    DisplayResult(root);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'Q':
                    double square = displayNumber.Value * displayNumber.Value;
                    DisplayResult(square);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'T':
                    double tangens = Math.Tan(displayNumber.Value);
                    DisplayResult(tangens);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'K':
                    double cosine = Math.Cos(displayNumber.Value);
                    DisplayResult(cosine);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case 'S':
                    double sine = Math.Sin(displayNumber.Value);
                    DisplayResult(sine);
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();
                    break;
                case '+':
                    TryExecutePreviousDualOperation();
                    
                    PreviousDualOperation = DoAddition;
                    AllowReceiveNextOperand();
                    break;
                case '-':
                    TryExecutePreviousDualOperation();

                    PreviousDualOperation = DoSubtraction;
                    AllowReceiveNextOperand();
                    break;
                case '*':
                    TryExecutePreviousDualOperation();

                    PreviousDualOperation = DoMultiplication;
                    AllowReceiveNextOperand();
                    break;
                case '/':
                    TryExecutePreviousDualOperation();

                    PreviousDualOperation = DoDivision;
                    AllowReceiveNextOperand();
                    break;
                case '=':
                    PreviousDualOperation();
                    DisplayResult(storedResult.Value);
                    
                    AllowDualOperationExecution();
                    AllowReceiveNextOperand();                    
                    PreviousDualOperation = StoreDisplayNumber;
                    break;
                default:
                    break;
            }
        }


        
        public string GetCurrentDisplayState() {
            if (errorFlag) {
                return ERROR;
            }

            return displayNumber.ToString();
        }
        #endregion

        #region Private methods
        private void InitializeCalculator() {
            storedResult = new InternalNumber(0, MAX_NUM_OF_DIGITS);
            memory = new InternalNumber(0, MAX_NUM_OF_DIGITS);
            ClearScreen();
            AllowDualOperationExecution();
            PreviousDualOperation = StoreDisplayNumber;
        }



        private void ClearScreen() {
            displayNumber = new DisplayNumber(
                                0, MAX_NUM_OF_DIGITS, DECIMAL_SYMBOL
            );
            errorFlag = false;
            AllowReceiveNextOperand();
        }



        private bool CanReceiveNextOperand() {
            return receiveNextOperand;
        }



        private bool CanExecuteDualOperation() {
            return canExecuteDualOperation;
        }



        private void AllowReceiveNextOperand(bool flag) {
            receiveNextOperand = flag;
        }



        private void AllowReceiveNextOperand() {
            AllowReceiveNextOperand(true);
        }



        private void AllowDualOperationExecution(bool flag) {
            canExecuteDualOperation = flag;
        }



        private void AllowDualOperationExecution() {
            AllowDualOperationExecution(true);
        }
        


        private void TryExecutePreviousDualOperation() {
            if (CanExecuteDualOperation()) {
                PreviousDualOperation();
                AllowDualOperationExecution(false);
            }
        }



        private void DoAddition() {
            double result = storedResult.Value + displayNumber.Value;
            StoreResult(result);
            DisplayResult(result);
        }



        private void DoSubtraction() {
            double result = storedResult.Value - displayNumber.Value;
            StoreResult(result);
            DisplayResult(result);
        }



        private void DoMultiplication() {
            double result = storedResult.Value * displayNumber.Value;
            StoreResult(result);
            DisplayResult(result);
        }



        private void DoDivision() {
            double result = storedResult.Value / displayNumber.Value;
            StoreResult(result);
            DisplayResult(result);
        }



        private void StoreDisplayNumber() {
            StoreResult(displayNumber.Value);
        }



        private void StoreResult(double result) {
            try {
                InternalNumber newStoredResult = new InternalNumber(
                                                    result, MAX_NUM_OF_DIGITS
                );
                storedResult = newStoredResult;
            } catch (ArgumentException) {
                errorFlag = true;
            }
        }



        private void DisplayResult(double x) {
            try {
                DisplayNumber newDisplNum = new DisplayNumber(
                                                x, MAX_NUM_OF_DIGITS, DECIMAL_SYMBOL
                );

                displayNumber = newDisplNum;
            } catch (ArgumentException) {
                errorFlag = true;
            }
        }
        #endregion

    }
    #endregion

    #region DisplayNumber
    public class DisplayNumber {

        #region Fields
        private string signlessValue;
        private int maxNumOfDigits;
        private char decimalSymbol;
        private bool isPositive;
        private bool isDecimal;
        #endregion
        
        #region Properties
        public double Value { get { return GetDouble(); } }
        #endregion

        #region Constructors
        public DisplayNumber(double number, int maxNumOfDigits, char decimalSymbol) {
            double roundedInput = InternalNumber.Round(number, maxNumOfDigits);
            string genericDoubleVal = Math.Abs(roundedInput).ToString( CultureInfo.InvariantCulture );

            this.signlessValue = genericDoubleVal.Replace('.', decimalSymbol);
            this.maxNumOfDigits = maxNumOfDigits;
            this.decimalSymbol = decimalSymbol;
            this.isDecimal = IsDecimal(number);
            this.isPositive = IsPositive(number);
        }
        #endregion

        #region Public methods
        public bool Append(char number) {
            if (!IsIntegerASCIIChar(number)) {
                throw new ArgumentException("Input char is not a single digit number: " + number);
            }

            bool needToSkipInputZero = (number == 0) && (signlessValue == "0");
            bool displayIsFull = (GetNumberOfDigits(signlessValue) == maxNumOfDigits);
            
            if (needToSkipInputZero || displayIsFull) {
                return false;
            }

            if (signlessValue == "0") {
                signlessValue = "";
            }

            signlessValue += number;

            return true;
        }



        public bool MakeDecimal() {
            if (!isDecimal) {
                signlessValue += decimalSymbol;
                isDecimal = true;

                return true;
            } else {
                return false;
            }
        }



        public void AlternateSign() {
            isPositive = isPositive ? false : true;
        }


        
        public override string ToString() {
            if (isPositive) {
                return signlessValue;
            } else {
                return "-" + signlessValue;
            }
        }
        #endregion

        #region Private methods
        private double GetDouble() {
            string stringVal = ToString();
            string cultureIndependantVal = stringVal.Replace(decimalSymbol, '.');

            return double.Parse(cultureIndependantVal, CultureInfo.InvariantCulture);
        }



        private int GetNumberOfDigits(string val) {
            int numOfDigits = 0;

            foreach (char c in val) {
                if (IsIntegerASCIIChar(c)) {
                    numOfDigits++;
                }
            }

            return numOfDigits;
        }



        private bool IsIntegerASCIIChar(char number) {
            return (number >= '0' && number <= '9');
        }



        private bool IsPositive(double number) {
            return number >= 0;
        }



        private bool IsDecimal(double value) {
            string ceilStringVal = Math.Ceiling(value).ToString();
            string stringVal = value.ToString();

            return (ceilStringVal != stringVal);
        }
        #endregion
    }
    #endregion

    #region InternalNumber
    public class InternalNumber {

        #region Fields
        private double value;
        #endregion

        #region Properties
        public double Value { get { return value; } }
        #endregion

        #region Constructors
        public InternalNumber(double number, int maxNumOfDigits) {
            if (GetNumberOfDigits(number) > maxNumOfDigits) {
                throw new ArgumentException("Input number contains too many digits");
            } else if (Double.IsInfinity(number)) {
                throw new ArgumentException("Input number is infinity");
            } else if (Double.IsNaN(number)) {
                throw new ArgumentException("Input number is NaN");
            }

            value = Round(number, maxNumOfDigits);           
        }
        #endregion

        #region Public methods
        public static double Round(double number, int maxNumOfDigits) {
            if ( Double.IsInfinity(number) ) {
                throw new ArgumentException("Input number is infinity");
            } else if (Double.IsNaN(number)) {
                throw new ArgumentException("Input number is NaN");
            }

            int integerPartSize = GetIntegerPartSize(number);
            int numOfDecimalSpaces = maxNumOfDigits - integerPartSize;

            return Math.Round(number, numOfDecimalSpaces); 
        }
        #endregion

        #region Private methods
        private int GetNumberOfDigits(double val) {
            string sVal = val.ToString();
            int numOfDigits = 0;

            foreach (char c in sVal) {
                if (c >= '0' && c <= '9') {
                    numOfDigits++;
                }
            }

            return numOfDigits;
        }



        private static int GetIntegerPartSize(double number) {
            return Math.Abs( Math.Floor(number) )
                                            .ToString()
                                            .Length;
        }
        #endregion
    }
    #endregion 

}