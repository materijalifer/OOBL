﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        public double Result;
        private double _currentOnDisplay;
        public string _currentCharactersOnDisplay;
        private char _lastKeyPressed;
        public double NumberStoredInMemory;
        private char?  _currentActiveOperator=null;
        private bool _isUnaryPressedAfterOperator=false;

        private const int MAXLENGTH = 10;
     
        public Kalkulator()
        {
            _currentOnDisplay = 0;
            _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            Result = 0;
        }
        
        public bool isBinaryOperator(char inputKey)
        {
            if (inputKey == '+' || inputKey == '-' ||
                inputKey == '*' || inputKey == '/') 
            {
                //Result = _currentOnDisplay;
                return true;
            }
            else { return false; }
        }
        public bool isUnaryOperator(char inputKey)
        {
            if( inputKey=='M'|| inputKey=='S'|| inputKey=='K'||
                inputKey=='T'|| inputKey=='Q'|| inputKey=='R'||
                inputKey=='I')
            {
                if (isBinaryOperator(_lastKeyPressed))
                {
                    _isUnaryPressedAfterOperator = true;
                }
                return true;
            }
            else
            {
                return false;
            }
        }  
        public bool isMemoryOperator(char inputKey)
        {
            if (inputKey == 'P' || inputKey == 'G')
            {
                return true;
            }
            return false;
        }
        public bool isSystemKey(char inputKey)
        {
            if( inputKey=='C' || inputKey=='O')
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Metoda koja sprema i čita iz pričuvne memorije
        /// </summary>
        /// <param name="memoryKey"></param>
        public void doMemoryOperation(char memoryKey)
        {
            if (memoryKey == 'P')
            {
                NumberStoredInMemory = _currentOnDisplay;
            }
            else
            {
                Convert.ToDouble(_currentOnDisplay);
                _currentOnDisplay = NumberStoredInMemory;
                _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            }
        }
        /// <summary>
        /// Metda koja obavlja operacije reset i clean
        /// </summary>
        /// <param name="systemKey"></param>
        public void doSystemOperation(char systemKey)
        {
            if (systemKey == 'C')
            {
                _currentOnDisplay = 0;
                    _currentCharactersOnDisplay=_currentOnDisplay.ToString();
            }
            else
            {
                NumberStoredInMemory=0;
                Result=0;
                _currentOnDisplay=0;
                _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            }
        }
        /// <summary>
        /// Metoda koja se izvršava kada korisnik stisne unarni operator
        /// </summary>
        /// <param name="operation"></param>
        public void doUnaryOperation(char operation)
        {
            switch (operation)
            {
                case 'M':
                    _currentOnDisplay *= -1;
                    break;
                case 'S':
                    _currentOnDisplay = Math.Sin(_currentOnDisplay);
                    break;
                case 'K':
                    _currentOnDisplay = Math.Cos(_currentOnDisplay);
                    break;
                case 'T':
                    _currentOnDisplay = Math.Tan(_currentOnDisplay);
                    break;
                case 'Q':
                    _currentOnDisplay = Math.Pow(_currentOnDisplay, 2);
                    break;
                case 'R':
                    _currentOnDisplay = Math.Pow(_currentOnDisplay, 0.5);
                    break;
                case 'I':
                    _currentOnDisplay = Math.Pow(_currentOnDisplay, -1);
                    break;
            }
            _currentOnDisplay = Math.Round(_currentOnDisplay, 9);
            _currentCharactersOnDisplay = _currentOnDisplay.ToString();    
        }
        /// <summary>
        /// Metoda se izvrši kada korisnik unese znak '='
        /// </summary>
        public void doEquation()
        {
            _currentOnDisplay = Convert.ToDouble(_currentCharactersOnDisplay);
            if (_currentActiveOperator == _lastKeyPressed )
            {
                #region kratke naredbe
                switch (_lastKeyPressed)
                {
                    case '+':
                        _currentOnDisplay = Result * 2;
                        break;
                    case '*':
                        _currentOnDisplay=Result*Result;
                        break;
                    case '/':
                        _currentOnDisplay=1;
                        break;
                    case '-':
                        _currentOnDisplay=0;
                        break;
                }
                #endregion
            }
            else if ( _currentActiveOperator == '+')
            {
                _currentOnDisplay += Result;
            }
            else if ( _currentActiveOperator == '*')
            {
                _currentOnDisplay *= Result;
            }
            else if ( _currentActiveOperator == '-')
            {
                _currentOnDisplay = Result - _currentOnDisplay;
            }
            else if ( _currentActiveOperator == '/')
            {
                    _currentOnDisplay = Result / _currentOnDisplay;
            }
            _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            Result = _currentOnDisplay;
        }
        /// <summary>
        /// Metoda se izvrši kada korisnik unese znamenku
        /// </summary>
        public void doDigitOperation(char digit)
        {
            if (isBinaryOperator(_lastKeyPressed))
            {
                _currentOnDisplay = 0;
                _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            }
            else if (_isUnaryPressedAfterOperator) 
            {
                _currentOnDisplay = 0;
                _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            }
            _isUnaryPressedAfterOperator = false;
            
            _currentCharactersOnDisplay += digit;
            _currentOnDisplay = Convert.ToDouble(_currentCharactersOnDisplay);

            //checkLength();
            
            
            
        }
        /// <summary>
        /// Metoda poziva metodu doOperation, te postavlja trenutni operand
        /// </summary>
        /// <param name="binaryOperator"></param>
        public void doBinaryOperation(char binaryOperator)
        {           
            doOperation(binaryOperator);
            _currentActiveOperator = binaryOperator;
        }
        /// <summary>
        /// Metoda koja se izvršava svaki put kada se stisne na binarni operator
        /// </summary>
        /// <param name="currentOperator"></param>
        public void doOperation(char currentOperator)
        {
            if(!isBinaryOperator(_lastKeyPressed))
            {
                if (_currentActiveOperator.HasValue)
                {
                    switch (_currentActiveOperator)
                    {
                        case '+':
                            Result += _currentOnDisplay;
                            break;
                        case '-':
                            Result=Result - _currentOnDisplay;
                            break;
                                
                        case '*':
                            Result *= _currentOnDisplay;
                            break;

                        case '/':
                            Result = Result/_currentOnDisplay;
                            break;
                    }   
                }
                else 
                {
                    Result = Convert.ToDouble(_currentCharactersOnDisplay);
                }
            }
            else 
            {
                _currentActiveOperator = currentOperator;
            }
        }
        /// <summary>
        /// Metoda koja se izvršava ukoliko je korisnik stisnuo znak ','
        /// </summary>
        /// <param name="inPressedDigit"></param>
        private void doSemiColon(char inPressedDigit)
        {
            _currentCharactersOnDisplay += inPressedDigit;
            _currentOnDisplay = Convert.ToDouble(_currentCharactersOnDisplay);
        }
        /// <summary>
        /// Metoda provjera duljina zadanaog broja,te ga zaokruzuje
        /// </summary>
        public void checkLength()
        {
            int count = 0;
            for (int i = 0; i < _currentCharactersOnDisplay.Length; i++)
            {
                if (_currentCharactersOnDisplay[i] == ',') break;
                if (char.IsDigit(_currentCharactersOnDisplay[i])) count++;
            }
            if (count <= MAXLENGTH)
            {
                int length = _currentCharactersOnDisplay.Length;
                _currentOnDisplay = Math.Round(_currentOnDisplay, MAXLENGTH - count);
                _currentCharactersOnDisplay = _currentOnDisplay.ToString();
            }
        }
        
        public void Press(char inPressedDigit)
        {

            if (char.IsDigit(inPressedDigit))
            {
                doDigitOperation(inPressedDigit);
            }
            else if (inPressedDigit == ',')
            {
                doSemiColon(inPressedDigit);
            }
            else if (isBinaryOperator(inPressedDigit))
            {
                doBinaryOperation(inPressedDigit);
            }
            else if (isUnaryOperator(inPressedDigit))
            {
                doUnaryOperation(inPressedDigit);
            }
            else if (isSystemKey(inPressedDigit))
            {
                doSystemOperation(inPressedDigit);
            }
            else if (isMemoryOperator(inPressedDigit))
            {
                doMemoryOperation(inPressedDigit);
            }
            else if (inPressedDigit == '=')
            {
                doEquation();
            }

            if (!char.IsDigit(inPressedDigit) && inPressedDigit != ',')
            {
                checkLength();
            }

            _lastKeyPressed = inPressedDigit;
        }
        public string GetCurrentDisplayState()
        {
            
            if ((_currentOnDisplay >= 0 && _currentOnDisplay.ToString().Contains(',') && _currentOnDisplay.ToString().Length > 11) ||
                (_currentOnDisplay < 0 && _currentOnDisplay.ToString().Contains(',') && _currentOnDisplay.ToString().Length > 12)
                || (_currentOnDisplay >= 0 && !_currentOnDisplay.ToString().Contains(',') && _currentOnDisplay.ToString().Length > 10)
                || double.IsInfinity(_currentOnDisplay)
                )
            { return "-E-"; }
            else return _currentOnDisplay.ToString();
        }
}
    }



