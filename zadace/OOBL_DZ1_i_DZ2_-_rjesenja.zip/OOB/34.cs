﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    

    public class Kalkulator:ICalculator
    {

        //moguca stanja kalkulatora
        enum State { Input, PostBinary, PostUnary };
        
        private string screen; //trenutno stanje display-a
        private string register; //registar za pamcenje medurezultata
        private string memory; //unutarnja memorija kalkulatora (P i G operacije)
        
        private BinaryOperator lastOperator; //zadnji operator kod nizanja operacija
        private State state; //trenutno stanje kalkulatora

        private NumberFormatInfo numFormatInfo;

        private const string ERR_MSG = "-E-"; //poruka o gresci
        private const int MAX_DIGITS = 10; //maksimalan broj znamenki na ekranu

        bool equalsPressed; //sluzi za nizanje operacija pomocu tipke

        public Kalkulator()
        {
            CultureInfo cultureInfo = CultureInfo.InstalledUICulture;
            numFormatInfo = (NumberFormatInfo) cultureInfo.NumberFormat.Clone();
            numFormatInfo.NumberDecimalSeparator = ","; 
            Reset();
        }

        /// <summary>
        /// Postavlja kalkulator u pocetno stanje
        /// </summary>
        private void Reset()
        {
            state = State.Input;
            screen = register = memory = "0";
            lastOperator = null;
            equalsPressed = false;
        }


        public string GetCurrentDisplayState()
        {
            return screen;
        }

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit <= '9' && inPressedDigit >= '0')
            {
                //pritisnuta brojka
                int maxSymbols = MAX_DIGITS; //maksimalan broj simbola na ekranu
                if (screen.Contains('-')) maxSymbols++;
                if (screen.Contains(',')) maxSymbols++;

                if (state == State.PostBinary || state == State.PostUnary || screen == "0")
                {
                    state = State.Input;
                    screen = inPressedDigit.ToString();
                }
                else if (screen.Length < maxSymbols) screen += inPressedDigit;
            }

            else if (inPressedDigit == ',') 
            {
                //dodavanje decimalnog zareza
                if (state == State.PostBinary || state == State.PostUnary)
                {
                    screen = "0,";
                    state = State.Input;
                }
                else if (!screen.Contains(inPressedDigit) && screen.Length < MAX_DIGITS + 2)
                    screen += inPressedDigit;
            }

            else if (inPressedDigit == 'M') 
            {
                //promjena predznaka
                if (!screen.Contains('-'))
                {
                    if (screen != "0" && screen != ERR_MSG) screen = '-' + screen;
                }
                else
                    screen = screen.Replace("-", "");
            }

            else if (inPressedDigit == '=') 
            {

                if (state == State.PostBinary && lastOperator != null)
                {
                    //slucaj ponavljanja operacija sa =
                    screen = GetBinaryOpResult(lastOperator, screen, register);                  
                }
                else if (lastOperator != null)
                {
                    string tmp = register;
                    register = screen;
                    if (equalsPressed) 
                        screen = GetBinaryOpResult(lastOperator, screen, tmp);
                    else
                        screen = GetBinaryOpResult(lastOperator, tmp, screen);
                    
                }
                else
                {
                    //ako nema operacije, potrebno je izaci iz Input stanja
                    //da se ekran ponisti nakon sljedece znamenke
                    state = State.PostUnary;
                }
                screen = FormatScreen(screen);
                equalsPressed = true;
            } else {

                switch (inPressedDigit)
                {
                    //binarni operatori
                    case '+': BinaryPressed(new Sumation()); break;
                    case '-': BinaryPressed(new Subtraction()); break;
                    case '*': BinaryPressed(new Multiplication()); break;
                    case '/': BinaryPressed(new Division()); break;

                    //unarni operatori
                    case 'S': UnaryPressed(new Sine()); break;
                    case 'K': UnaryPressed(new Cosine()); break;
                    case 'T': UnaryPressed(new Tangens()); break;
                    case 'Q': UnaryPressed(new Power()); break;
                    case 'R': UnaryPressed(new SquareRoot()); break;
                    case 'I': UnaryPressed(new Inverse()); break;

                    //ostale operacije
                    case 'C': screen = "0"; break;
                    case 'O': Reset(); break;
                    case 'P': if (screen != ERR_MSG) memory = FormatScreen(screen); break;
                    case 'G': screen = memory; state = State.PostUnary; break;

                }

            }

        }

        /// <summary>
        /// Formatiranje brojevnog zapisa za prikaz na ekranu u skladu sa postavljenim zahtjevima.
        /// </summary>
        /// <param name="scr">brojevni zapis koji se zeli formatirati</param>
        /// <returns></returns>
        private string FormatScreen(string scr)
        {
            if (scr.Contains(","))
            {
                while (scr.EndsWith("0"))
                    scr = scr.Remove(scr.Length - 1);
            }
            if (scr.EndsWith(","))
                scr = scr.Remove(scr.Length - 1);

            if (scr == "" || scr == "-0") scr = "0";

            return scr;
            
        }

        /// <summary>
        /// Izvrsavanje odredene binarne operacije.
        /// </summary>
        /// <param name="binOperator">Binarni operator</param>
        private void BinaryPressed(BinaryOperator binOperator)
        {
            if (state == State.PostBinary)
            {
                lastOperator = binOperator;
                return;
            }

            
            if (lastOperator != null && !equalsPressed)
            {
                register = GetBinaryOpResult(lastOperator, register, screen);
                screen = register;
            }
            else
                register = screen;

            equalsPressed = false;
            state = State.PostBinary;
            lastOperator = binOperator;
        }

        /// <summary>
        /// Izvrsavanje unarne operacije nad trenutnim brojem na ekranu.
        /// </summary>
        /// <param name="unaOperator">Unarni operator</param>
        private void UnaryPressed(UnaryOperator unaOperator)
        {
            
            try
            {
                double num = StringToDouble(screen);
                screen = FormatResult(unaOperator.GetResult(num));
            }
            catch (Exception e)
            {
                screen = ERR_MSG;
            }
            state = State.PostUnary;
        }

        /// <summary>
        /// Racunanje binarne operacije nad zadanim operandima.
        /// Pazi na greske do kojih moze doci kod izvrsavanja.
        /// Formatira rezultat za prikaz na ekranu.
        /// </summary>
        /// <param name="binOp">binarni operator</param>
        /// <param name="num1">prvi operand</param>
        /// <param name="num2">drugi operand</param>
        /// <returns>znakovni zapis rezultata, formatiran za prikaz na ekranu</returns>
        private string GetBinaryOpResult(BinaryOperator binOp, String num1, String num2)
        {
            
            string result = "";
            try
            {
                double dNum1 = StringToDouble(num1);
                double dNum2 = StringToDouble(num2);

                result = FormatResult(binOp.GetResult(dNum1, dNum2));
                state = State.PostBinary;
            }
            catch (Exception e)
            {
                result = ERR_MSG;
            }
            
            return result;
        }

        private double StringToDouble (string num)
        {
            return double.Parse(num, numFormatInfo);
        }

        /// <summary>
        /// Formatiranje brojevnog rezultata za prikaz na ekranu.
        /// Pazi na broj decimala i ograničenje broja znamenki.
        /// </summary>
        /// <param name="res">broj koji se zeli fomatirati</param>
        /// <returns>znakovni zapis formatiranog broja</returns>
        private string FormatResult(double res)
        {
            try
            {
                if (Double.IsNaN(res) || Double.IsInfinity(res)) return ERR_MSG;

                int size = Math.Floor(Math.Abs(res)).ToString().Length;
                if (size > MAX_DIGITS) return ERR_MSG;
                res = Math.Round(res, MAX_DIGITS - size);

                //poseban slucaj ako nakon zaokruzivanja imamo previse znamenki
                if (Math.Floor(Math.Abs(res)).ToString().Length > MAX_DIGITS)
                    return "-E-";

                string ret = res.ToString("F" + (MAX_DIGITS - size).ToString(), numFormatInfo);
                return FormatScreen(ret);
            }
            catch (Exception e)
            {
                return ERR_MSG;
            }
        }
    }

    public abstract class BinaryOperator
    {
        /// <summary>
        /// Vraca rezultat binarne oparcije nad zadanim operandima.
        /// </summary>
        /// <param name="num1">prvi operator</param>
        /// <param name="num2">drugi operator</param>
        /// <returns>rezultat operacije</returns>
        public abstract double GetResult(double num1, double num2);
    }

    public abstract class UnaryOperator
    {
        /// <summary>
        /// Vraca rezultat unarne oparcije nad zadanim operandom.
        /// </summary>
        /// <param name="num">operand</param>
        /// <returns>rezultat operacije</returns>
        public abstract double GetResult(double num);
    }

    public class Sumation : BinaryOperator
    {
        public override double GetResult(double num1, double num2)
        {
            return num1 + num2;
        }
    }

    public class Subtraction : BinaryOperator
    {
        public override double GetResult(double num1, double num2)
        {
            return num1 - num2;
        }
    }

    public class Multiplication : BinaryOperator
    {
        public override double GetResult(double num1, double num2)
        {
            return num1 * num2;
        }
    }
    
    public class Division : BinaryOperator
    {
        public override double GetResult(double num1, double num2)
        {
            if (num2 == 0) throw new DivideByZeroException();
            return num1 / num2;
        }
    }

    public class Cosine : UnaryOperator
    {
        public override double GetResult(double num)
        {
            return Math.Cos(num);
        }    }

    public class Sine : UnaryOperator
    {
        public override double GetResult(double num)
        {
            return Math.Sin(num);
        }
    }

    public class Power : UnaryOperator
    {
        public override double GetResult(double num)
        {
            return Math.Pow(num, 2);
        }
    }

    public class SquareRoot : UnaryOperator
    {
        public override double GetResult(double num)
        {
            return Math.Sqrt(num);
        }
    }

    public class Inverse : UnaryOperator
    {
        public override double GetResult(double num)
        {
            if (num == 0) throw new DivideByZeroException();
            return 1 / num;
        }
    }

    public class Tangens : UnaryOperator
    {
        public override double GetResult(double num)
        {
            return Math.Tan(num);
        }
    }
}
