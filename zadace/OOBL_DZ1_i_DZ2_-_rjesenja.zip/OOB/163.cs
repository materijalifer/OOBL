﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string ulaz = "0";
        private string izlaz = "";
        private string memorija = "";
        bool prvaZnamenka = true;
        string prviOperand;
        string drugiOperand;
        bool imamPrviOperand = true;
        bool imamDrugiOperand = false;
        bool imamOperator = false;
        char Operator;
        int pocetniIndeks = 0;
        bool first = true;
        string baza;
        bool samoPrikazi = false;



        public void Press(char inPressedDigit)
        {
         

            if (ulaz == inPressedDigit.ToString() && prvaZnamenka == false && inPressedDigit == '0')
                return;

            if (inPressedDigit == ',')
            {
                ulaz = ulaz + inPressedDigit.ToString();

                prvaZnamenka = false;
                return;
            }

            if (prvaZnamenka)
            {
                ulaz = "" + inPressedDigit.ToString();

                prvaZnamenka = false;
                return;
            }



            ulaz = ulaz + inPressedDigit.ToString();


        }

        public string GetCurrentDisplayState()
        {
            char[] poljeZnakova = ulaz.ToCharArray();
            for (int i = pocetniIndeks; i < poljeZnakova.Length; i++)
            {

                //if (izlaz == "-E-")
                //    continue;

                if(i>0){
                    if (poljeZnakova[i] == ',' && poljeZnakova[i - 1] == ',')
                    {
                       // prviOperand = drugiOperand = izlaz = "-E-";
                        pocetniIndeks++;
                        continue;


                    }
                   

               }

                if (i == 0 && poljeZnakova[i] == '-')
                {
                    prviOperand = "-";
                    pocetniIndeks++;
                    continue;
                }



                if (poljeZnakova[i].ToString() == "O")
                {
                    prviOperand = "0";
                    drugiOperand = "";
                    izlaz = "";
                    memorija = "";
                    continue;
                }


                if ((char.IsNumber(poljeZnakova[i]) || poljeZnakova[i] == ',') && imamOperator == false)//promjena
                {
                    
                        prviOperand = prviOperand + poljeZnakova[i];

                }


                if (poljeZnakova[i] == '-' || poljeZnakova[i] == '*' || poljeZnakova[i] == '+' || poljeZnakova[i] == '/')
                {

                    Operator = poljeZnakova[i];
                    imamOperator = true;
                    // POZOR
                    baza = "";
                    first = true;

                }

              


                if ((char.IsNumber(poljeZnakova[i]) || poljeZnakova[i] == ',') && imamPrviOperand == true && imamOperator == true)
                {
                    drugiOperand = drugiOperand + poljeZnakova[i];

                    if((i+1) < poljeZnakova.Length)
                        if ((!char.IsNumber(poljeZnakova[i + 1]) && poljeZnakova[i + 1] != ',') && poljeZnakova[i + 1] != 'M' && poljeZnakova[i + 1] != 'Q' && poljeZnakova[i + 1] != 'C' && poljeZnakova[i + 1] != 'K' && poljeZnakova[i + 1] != 'S' && poljeZnakova[i + 1] != 'T' && poljeZnakova[i + 1] != 'R' && poljeZnakova[i + 1] != 'I' && poljeZnakova[i + 1] != 'P' && poljeZnakova[i + 1] != 'G' && poljeZnakova[i + 1] != 'O')
                        imamDrugiOperand = true;

                    //if((i+2)<= poljeZnakova.Length)
                    //    if(poljeZnakova[i+2] == '=')
                    //        imamDrugiOperand = true;

                    //POZORRR
                }

                //MIJENJAM
                if ((poljeZnakova[i] == 'I' || poljeZnakova[i] == 'K' || poljeZnakova[i] == 'S' || poljeZnakova[i] == 'R') && imamOperator)//POZOR
                {
                    if (String.IsNullOrEmpty(drugiOperand) == false)
                    {
                        izlaz = drugiOperand = izvediUnarnu(poljeZnakova[i].ToString(), drugiOperand);
                        imamDrugiOperand = true;
                    }

                    else
                    {

                        izlaz = izvediUnarnu(poljeZnakova[i].ToString(), prviOperand);//promjena

                    }

                    samoPrikazi = true;
                    pocetniIndeks++;
                    continue;

                }



                if (poljeZnakova[i] == 'M' || poljeZnakova[i] == 'S' || poljeZnakova[i] == 'I' || poljeZnakova[i] == 'Q' || poljeZnakova[i] == 'K' || poljeZnakova[i] == 'R' || poljeZnakova[i] == 'T')
                {
                    if (imamOperator)
                    {
                        if (drugiOperand == "")
                            izlaz = prviOperand = izvediUnarnu(poljeZnakova[i].ToString(), prviOperand);

                        else

                            izlaz = drugiOperand = izvediUnarnu(poljeZnakova[i].ToString(), drugiOperand);

                        if ((i + 1) == poljeZnakova.Length || poljeZnakova[i + 1] == '-' || poljeZnakova[i + 1] == '*' || poljeZnakova[i + 1] == '+' || poljeZnakova[i + 1] == '/')
                            imamDrugiOperand = true;


                    }

                    else
                    {
                        if (string.IsNullOrEmpty(prviOperand))
                            prviOperand = "0";

                        izlaz = prviOperand = izvediUnarnu(poljeZnakova[i].ToString(), prviOperand);

                    }

                    //if ((i+1) <= poljeZnakova.Length)
                    //    if(poljeZnakova[i+1] == '=')
                    //    return izlaz;

                  

                }

                if (poljeZnakova[i] == 'C')
                {
                    if (!string.IsNullOrEmpty(drugiOperand))
                        drugiOperand = Clear();

                    else
                        prviOperand = Clear();
                }





                if (poljeZnakova[i] == 'P')
                {
                    if (imamOperator)
                        Spremi(drugiOperand);

                    else
                        Spremi(prviOperand);

                }

                if (poljeZnakova[i] == 'G')
                {
                    if (imamOperator)
                        drugiOperand = Dohvati();

                    else
                        prviOperand = Dohvati();

                }



                //if((i+1) == poljeZnakova.Length || imamOperator && imamDrugiOperand && imamPrviOperand || poljeZnakova[i+1] == '=')
                if (imamOperator && imamDrugiOperand && imamPrviOperand)
                {
                    prviOperand = izlaz = izvediBinarnu(Operator.ToString(), prviOperand, drugiOperand);
                    drugiOperand = "";
                    imamPrviOperand = true;
                    imamOperator = false;
                    imamDrugiOperand = false;
                    baza = "";
                    first = true;
                }

                if (poljeZnakova[i] == '=' && imamOperator)
                {


                    if (first == true)
                    {
                        baza = prviOperand;
                        first = false;
                    }

                    izlaz = prviOperand = izvediBinarnu(Operator.ToString(), prviOperand, baza);//promjena



                }

                if (prviOperand == "-E-" || drugiOperand == "-E-" || izlaz == "-E-")
                {
                    pocetniIndeks++;
                    continue;


                }

                pocetniIndeks++;
            }

            if (samoPrikazi == true)
                //return Math.Round(double.Parse(izlaz), 9).ToString();   // Promjena
                return ProvjeriDuljinu(izlaz);

            if (poljeZnakova[poljeZnakova.Length - 1] == '=')
            {
                if (prviOperand == "-E-")
                    return prviOperand;

                if (drugiOperand == "-E-")
                    return drugiOperand;


                if (imamDrugiOperand)
                    //return Round(drugiOperand);
                    return ProvjeriDuljinu( drugiOperand);

                else
                    //return Round(prviOperand);
                    return ProvjeriDuljinu( prviOperand);


                //if (imamDrugiOperand)
                //    return ProvjeriDuljinu(drugiOperand);
                //else return ProvjeriDuljinu(prviOperand);

            }






            if (imamDrugiOperand == false)
            {


                return ProvjeriDuljinu(prviOperand);
              //  return Round(prviOperand);

            }


             //return izlaz;
            return ProvjeriDuljinu(izlaz);
        }

        public string izvediBinarnu(string Operator, string prvi, string drugi)
        {
            switch (Operator)
            {
                case "-":
                    return Oduzmi(prvi, drugi);

                case "*":
                    return Pomnozi(prvi, drugi);

                case "+":
                    return Zbroji(prvi, drugi);

                case "/":
                    return Podijeli(prvi, drugi);

                default:
                    return "-E-";

            }




        }

        public string izvediUnarnu(string Operator, string operand)
        {
            switch (Operator)
            {
                case "M":
                    return Minus(operand);
                    break;

                case "S":
                    return Sinus(operand);
                    break;

                case "I":
                    return Inverz(operand);
                    break;

                case "Q":
                    return Kvadriraj(operand);
                    break;

                case "K":
                    return Kosinus(operand);
                    break;

                case "R":
                    return Korjenuj(operand);
                    break;

                case "T":
                    return Tangens(operand);
                    break;


                default:
                    return "-E-";

            }
        }



        public string Oduzmi(string prvi, string drugi)
        {
            double prviBroj = double.Parse(prvi);
            double drugiBroj = double.Parse(drugi);
            double rezultat = prviBroj - drugiBroj;
            return ProvjeriDuljinu(rezultat.ToString());


        }

        public string Clear()
        {
            return "0";

        }

        public string Zbroji(string prvi, string drugi)
        {
            double prviBroj = double.Parse(prvi);
            double drugiBroj = double.Parse(drugi);
            double rezultat = prviBroj + drugiBroj;
            //return rezultat.ToString();
            return ProvjeriDuljinu(rezultat.ToString());

        }



        public string Pomnozi(string prvi, string drugi)
        {
            double prviBroj = double.Parse(prvi);
            double drugiBroj = double.Parse(drugi);
            double rezultat = prviBroj * drugiBroj;

        
            return ProvjeriDuljinu(rezultat.ToString());

        }

        public string Podijeli(string prvi, string drugi)
        {


            double prviBroj = double.Parse(prvi);
            double drugiBroj = double.Parse(drugi);

            if (drugiBroj == 0)
                return "-E-";

            double rezultat = prviBroj / drugiBroj;

         

            return ProvjeriDuljinu(rezultat.ToString());

        }

        public string Inverz(string ulaz)
        {
            double broj = double.Parse(ulaz);
            if (broj == 0)
                return "-E-";

            else
                broj = 1 / broj;
            return ProvjeriDuljinu( broj.ToString());

        }

        public string Kvadriraj(string ulaz)
        {
            double broj = double.Parse(ulaz);
            broj = Math.Pow(broj, 2);
            return ProvjeriDuljinu(broj.ToString());

        }

        public string Korjenuj(string ulaz)
        {
            double broj = double.Parse(ulaz);
            if (broj < 0)
                return "-E-";

            broj = Math.Sqrt(broj);
            return ProvjeriDuljinu(broj.ToString());

        }

        public string Kosinus(string ulaz)
        {
            double broj = double.Parse(ulaz);
            broj = Math.Cos(broj);
            return ProvjeriDuljinu(broj.ToString());

        }

        public string Sinus(string ulaz)
        {
            double broj = double.Parse(ulaz);
            broj = Math.Sin(broj);
            broj = Math.Round(broj, 9);
         
            return ProvjeriDuljinu(broj.ToString());

        }

        public string Tangens(string ulaz)
        {
            double broj = double.Parse(ulaz);
            broj = Math.Tan(broj);
            return ProvjeriDuljinu(broj.ToString());

        }

        public string Dohvati()
        {
            return memorija;

        }

        public void Spremi(string ulaz)
        {
            memorija = ulaz;
        }

        public string Reset()
        {

            return "0";
        }

        public string Minus(string ulaz)
        {
            if (ulaz == null)
                return "0";

            double broj = double.Parse(ulaz);
            broj = broj * (-1);
            return ProvjeriDuljinu(broj.ToString());

        }

        public string ProvjeriDuljinu(string ulaz)
        {
            if (DuljinaValjana(ulaz) == false)
                return "-E-";

            int imaMinus = 0;
            int decimalnih = ulaz.IndexOf(',') - 1;
            int k = 0;
            int i = 0;
            int indeks = 0;
            char[] polje = ulaz.ToCharArray();
           
            for (; i < ulaz.Length; i++)
            {
                if(polje[i] == '-')
                    imaMinus=1;

                if (polje[i] == '-' || polje[i] == ',')
                    k++;

                if(i>0)
                if (polje[i] == '0' && polje[i-1] == ',' )
                    indeks = i;
            }

            if (indeks > 0)
            {
                if(imaMinus == 1 && ulaz.Length == 4)
                ulaz = Round(ulaz);

                if(imaMinus == 0 && ulaz.Length == 3)
                    ulaz = Round(ulaz);
            }

            if (ulaz.Length <= (10 + k))
                return ulaz;

            else
                //return Round(ulaz);
                return Math.Round(Double.Parse(ulaz), 12 - k - decimalnih).ToString();

        }



        public bool DuljinaValjana(string ulaz)
        {
            int i = 0;
            char[] polje = ulaz.ToCharArray();
            for (; i < ulaz.Length; i++)
            {
                if (polje[i] == ',')
                    break;

            }

            if (i > 10)
                return false;
            else
                return true;

        }

        public string Round(string ulaz)
        {
            int i = 0;

            char[] polje = ulaz.ToCharArray();

            for (; i < ulaz.Length; i++)
            {
                if (polje[i] == ',')
                {

                    break;
                }
            }

            if (ulaz[0] == '-')
                i--;

            double broj = Math.Round(Double.Parse(ulaz), i);
            //double broj = Math.Round(Double.Parse(ulaz), i);
            return broj.ToString();
        }

    }


}
