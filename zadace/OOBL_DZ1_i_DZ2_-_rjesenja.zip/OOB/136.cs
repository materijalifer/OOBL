﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DrugaDomacaZadaca_Burza;

namespace DrugaDomacaZadaca_Burza
{

    #region Sucelja

    /// <summary>
    /// Sučelje predsavlja odgovornost za micanje dionice sa promatrača.
    /// </summary>
    public interface IStockObserver
    {
        /// <summary>
        /// Metoda briše predanu dionicu
        /// </summary>
        /// <param name="stock"></param>
        void RemoveStock(Stock stock);
    }

    /// <summary>
    /// Sučelje predstavlja odgovornost subjekta koji sadrži dionice.
    /// </summary>
    public interface IStockSubject
    {
        void RegisterObserver(IStockObserver stockObsever);

        void UnregistarObserver(IStockObserver stockObserver);

        void NotifyObservers(Stock stock);
    }

    #endregion

    #region Model

    /// <summary>
    /// Klasa modelira objekt dionice na burzi
    /// </summary>
    public class Stock : IEquatable<Stock>
    {

        //osnovni indetifikator dionice
        string name;

        //broj dionica
        long numberOfShares;

        //definirane cijene za dionice
        Dictionary<DateTime, decimal> prices;

        /// <summary>
        /// Konstruktor razreda.
        /// </summary>
        /// <param name="stockName"></param>
        /// <param name="numberOfShares"></param>
        /// <param name="initialPrice"></param>
        /// <param name="validFrom"></param>
        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime validFrom)
        {
            this.Name = stockName;
            this.NumberOfShares = numberOfShares;
            this.prices = new Dictionary<DateTime, decimal>();
            AddPrice(initialPrice, validFrom);
        }

        /// <summary>
        /// Definira naziv dionice. 
        /// Naziv dionice je indetifikator dionice i nije case sensitive.
        /// </summary>
        public string Name
        {

            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
            }

        }

        /// <summary>
        /// Definira broj dionica.
        /// </summary>
        public long NumberOfShares
        {

            get
            {
                return this.numberOfShares;
            }

            set
            {
                if (value > 0)
                {
                    this.numberOfShares = value;
                }
                else
                {
                    throw new StockExchangeException("Broj dionica mora biti veca od 0!");
                }
            }
        }

        /// <summary>
        /// Dodaje cijenu u popis definiranih cijena dionice.
        /// </summary>
        /// <param name="price"></param>
        /// <param name="validTo"></param>
        public void AddPrice(decimal price, DateTime validTo)
        {
            if (price > 0m && !this.prices.ContainsKey(validTo))
            {
                this.prices.Add(validTo, price);
            }
            else
            {
                throw new StockExchangeException("Cijena koju ste pokusali dodati dionici: " + this.Name + " nije moguce dodati jer je ili cijena manja od 0 ili je vec definirana cijena za dano vrijeme!");
            }
        }

        /// <summary>
        /// Metoda vraca zadnju definiranu cijenu prije danoga datuma.
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public decimal GetPrice(DateTime time)
        {
            decimal price = 0m;
            DateTime currentPriceDate = DateTime.MinValue;

            foreach (DateTime key in this.prices.Keys)
            {
                int result = DateTime.Compare(key, time);
                if (result < 0 && (DateTime.Compare(key, currentPriceDate) > 0))
                {
                    //datum definirane cijene je prije trazenog datuma i veci je od svih prethodnih definiranih
                    price = this.prices[key];
                    currentPriceDate = key;
                }
                else if (result == 0)
                {
                    //datum definirane cijene je trazeni datum
                    return this.prices[key];
                }
                else
                {
                    //datum definirane cijene je nakon trazenog datuma pa se ignorira
                }
            }

            if (price == 0m)
            {
                //nije pronadjena niti jedna cijena definiran prije danog datuma
                throw new StockExchangeException("Cijena za trazeni datum nije definirana!");
            }
            else
            {
                return price;
            }
        }

        /// <summary>
        /// Provjerava da li su dvije dionice jednake.
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool Equals(Stock stock)
        {
            if (this.Name.ToLower().Equals(stock.Name.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Metoda provjerava da li je dani indetifikator dionice indetifikator trenutne dionice.
        /// </summary>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public bool Equals(string stockId)
        {
            if (this.Name.ToLower().Equals(stockId.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// Metoda vraca prvu cijenu definiranu.
        /// </summary>
        /// <returns></returns>
        internal decimal GetFirstDefinedPrice()
        {
            decimal stockPrice = 0m;
            DateTime priceStartDate = DateTime.MaxValue;

            foreach (DateTime currStockPriceDate in this.prices.Keys)
            {
                int result = DateTime.Compare(currStockPriceDate, priceStartDate);
                if (result < 0)
                {
                    stockPrice = this.prices[currStockPriceDate];
                    priceStartDate = currStockPriceDate;
                }
            }

            return stockPrice;
        }

        /// <summary>
        /// Metoda vraca zadnju definiranu cijenu
        /// </summary>
        /// <returns></returns>
        internal decimal GetLastDefinedPrice()
        {
            decimal stockPrice = 0m;
            DateTime priceStartDate = DateTime.MinValue;

            foreach (DateTime currStockPriceDate in this.prices.Keys)
            {
                int result = DateTime.Compare(currStockPriceDate, priceStartDate);
                if (result > 0)
                {
                    stockPrice = this.prices[currStockPriceDate];
                    priceStartDate = currStockPriceDate;
                }
            }

            return stockPrice;
        }
    }

    /// <summary>
    /// Klasa modelira portfolio burze.
    /// </summary>
    public class Portfolio : IStockObserver, IEquatable<Portfolio>
    {

        //indetifikator portfolia
        string portfolioId;

        //dionice koje su u portfoliu
        Dictionary<Stock, int> stocksInProtfolio;

        /// <summary>
        /// Kostruktor razreda.
        /// </summary>
        /// <param name="portfolioId"></param>
        public Portfolio(string portfolioId)
        {
            this.portfolioId = portfolioId;
            this.stocksInProtfolio = new Dictionary<Stock, int>();
        }

        //jedinstveni indetifikator portfolija
        public string Id
        {
            get { return this.portfolioId; }
        }

        /// <summary>
        /// Metoda dodaje odredjen broj predenih dionica u portfolio.
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numSharesToAdd"></param>
        public void AddSharesToPortfolio(Stock stock, int numSharesToAdd)
        {
            if (this.stocksInProtfolio.ContainsKey(stock))
            {
                this.stocksInProtfolio[stock] += numSharesToAdd;
            }
            else
            {
                this.stocksInProtfolio.Add(stock, numSharesToAdd);
            }
        }

        /// <summary>
        /// Metoda mice predani iznons predani dionica iz portfolija.
        /// U slucaju da je predani iznos veci od broja dionica u portfoliju ili predane dionice
        /// ne postoje, metoda baca StockExchangeException
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="numToRemove"></param>
        public void RemoveShares(Stock stock, int numToRemove)
        {
            Stock sharesToRemove = null;

            foreach (Stock share in this.stocksInProtfolio.Keys)
            {
                if (share.Equals(stock))
                {
                    sharesToRemove = share;
                    break;
                }
            }

            if (sharesToRemove != null)
            {
                if (this.stocksInProtfolio[sharesToRemove] >= numToRemove)
                {

                    if (this.stocksInProtfolio[sharesToRemove] == numToRemove)
                    {
                        //brise sve dionice neke dionice u portfoliju
                        this.stocksInProtfolio.Remove(sharesToRemove);
                    }
                    else
                    {
                        //brise predani broj dionica iz portfolija
                        sharesToRemove.NumberOfShares -= numToRemove;
                        this.stocksInProtfolio[sharesToRemove] -= numToRemove;
                    }
                }
                else
                {
                    throw new StockExchangeException("Nije moguce makrnuti vise dionica iz portfolija nego sto ih ima u portfoliju!");
                }
            }
            else
            {
                throw new StockExchangeException("Nije moguce maknuti dionice iz portfolija jer one nisu dio portfolija!");
            }
        }

        /// <summary>
        /// Brise dionicu iz portfolija ako postoji u portfoliju inace baca gresku.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveAllShares(Stock stock)
        {
            if (this.stocksInProtfolio.ContainsKey(stock))
            {
                this.RemoveStock(stock);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji u portfoliju pa je nije moguce izbrisati!");
            }
        }

        /// <summary>
        /// Metoda brise dionicu iz portfolija
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            if (this.stocksInProtfolio.Keys.Contains(stock))
            {
                this.stocksInProtfolio.Remove(stock);
            }
            else
            {
                //ignorira brisanje
            }
        }

        /// <summary>
        /// Metoda vraca vrijednost portfolija
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public decimal GetValueOfPortfolio(DateTime timeStamp)
        {
            decimal valueOfPortfolio = 0m;
            foreach (Stock stock in this.stocksInProtfolio.Keys)
            {
                valueOfPortfolio += stock.GetPrice(timeStamp) * this.stocksInProtfolio[stock];
            }
            return valueOfPortfolio;
        }

        /// <summary>
        /// Metoda vraća ukupan broj dionica u portfoliju
        /// </summary>
        /// <returns></returns>
        internal int GetNuberOfAllShares()
        {
            int numberOfShares = 0;
            foreach (Stock stock in this.stocksInProtfolio.Keys)
            {
                numberOfShares += this.stocksInProtfolio[stock];
            }
            return numberOfShares;
        }

        /// <summary>
        /// Metoda vraća vrijednst s obzirom na to da li portfolio sadrži danu dionicu
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool ContainsStock(Stock stock)
        {
            return this.stocksInProtfolio.Keys.Contains(stock);
        }

        /// <summary>
        /// Metoda vraća broj dionica u portfoliju.
        /// </summary>
        /// <returns></returns>
        public int GetNumOfAllStocks()
        {
            return this.stocksInProtfolio.Keys.Count;
        }

        /// <summary>
        /// Metoda vraca broj dionica u portfoliju predane dionice
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public int GetNuberOfSharesOfStock(Stock stock)
        {
            if (this.stocksInProtfolio.ContainsKey(stock))
            {
                return this.stocksInProtfolio[stock];
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Metoda uspoređuje dva portfolija po indetifikatorima i vraća true ako su isti
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(Portfolio other)
        {
            if (this.portfolioId.Equals(other.Id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Metoda uspoređuje dva portfolija po indetifikatorima i vraća true ako su isti
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(string otherPortfolioId)
        {
            if (this.portfolioId.Equals(otherPortfolioId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Metoda vraca promjenu portfelja u preadnom mjesecu.
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        internal decimal GetPercetChangeInValueForMonth(DateTime timeStamp)
        {
            //vrijednost prvog u mjesecu
            DateTime firstInMonth = new DateTime(timeStamp.Year, timeStamp.Month, 1, 0, 0, 0);
            decimal firstValueOfTheMonth = this.GetValueOfPortfolio(firstInMonth);
            //vrjednost zadnjeg u mjesecu
            int numberOfDaysInMonth = DateTime.DaysInMonth(timeStamp.Year, timeStamp.Month);
            DateTime lastOfTheMonth = new DateTime(timeStamp.Year, timeStamp.Month, numberOfDaysInMonth, 23, 59, 59);
            //sami izracun vrijednosti
            decimal lastValueOfTheMonth = this.GetValueOfPortfolio(lastOfTheMonth);
            decimal valueCange = (lastValueOfTheMonth - firstValueOfTheMonth) / firstValueOfTheMonth;
            decimal cangePercentige = valueCange * 100;

            return cangePercentige;
        }
    }

    /// <summary>
    /// Klasa modelira indeks burze
    /// </summary>
    public class Index : IStockObserver, IEquatable<Index>
    {
        //indetifikator indeksa
        string name;

        //tip indeksa
        DrugaDomacaZadaca_Burza.IndexTypes type;

        //dionice u indeksu
        List<Stock> listOfStocks;

        /// <summary>
        /// Kostruktor razreda
        /// </summary>
        /// <param name="name"></param>
        /// <param name="type"></param>
        public Index(string inIndexName, DrugaDomacaZadaca_Burza.IndexTypes inIndexType)
        {
            this.Name = inIndexName;
            this.Type = inIndexType;
            this.listOfStocks = new List<Stock>();
        }

        /// <summary>
        /// Naziv indeksa.
        /// </summary>
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /// <summary>
        /// Tip indeksa.
        /// </summary>
        public DrugaDomacaZadaca_Burza.IndexTypes Type
        {
            get { return this.type; }
            set { this.type = value; }
        }

        /// <summary>
        /// Dionice koje se nalaze u indeksu.
        /// </summary>
        public List<Stock> Stocks
        {
            get { return this.listOfStocks; }
        }

        /// <summary>
        /// Metoda vraca broj dionica koje su u indeksu.
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfStocks()
        {
            return this.listOfStocks.Count;
        }

        /// <summary>
        /// Metoda racuna vrijednost dionica u indeksu za dano vrijeme.
        /// Vrijednost indeksa je ukupna vrijednost svih dionica (vrijednost dionice * broj dionica) koje se nalaze u indeksu.
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public decimal GetValueOfStocks(DateTime timeStamp)
        {
            decimal indexValue = 0m;
            foreach (Stock stock in this.listOfStocks)
            {
                indexValue += stock.GetPrice(timeStamp) * stock.NumberOfShares;
            }
            return indexValue;
        }

        /// <summary>
        /// Metoda dodaje dionicu u indeks.
        /// </summary>
        /// <param name="stock"></param>
        public void AddStock(Stock stock)
        {
            if (!this.listOfStocks.Contains(stock))
            {
                this.listOfStocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Nemoze se dva puta ista dionica pridodati indeksu!");
            }
        }

        /// <summary>
        /// Metoda vraća vrijednost o tome da li je predana dionica u index-u
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        public bool ContainsStock(Stock stock)
        {
            return this.listOfStocks.Contains(stock);
        }

        /// <summary>
        /// Metoda briše predanu dionicu iz indeksa.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            this.listOfStocks.Remove(stock);
        }

        /// <summary>
        /// Metoda provjerava da li su dva indeksa jednaka.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public bool Equals(Index index)
        {
            if (this.Name.ToLower().Equals(index.Name.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Metoda provjerava da li predani idIndeksa indentificira trenutni indeks.
        /// </summary>
        /// <param name="indexId"></param>
        /// <returns></returns>
        public bool Equals(string indexId)
        {
            if (this.Name.ToLower().Equals(indexId.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    /// <summary>
    /// Klasa predstavlja dodatne funkcionalnosti enum tipa
    /// </summary>
    public static class IndexTypesExtensions
    {

        public static decimal CalculateIndexValue(this IndexTypes type, Index index, DateTime timeStamp)
        {
            if (type == IndexTypes.AVERAGE)
            {
                return CalculateAverageIndexValue(index, timeStamp);
            }
            else if (type == IndexTypes.WEIGHTED)
            {
                return CalculateWeightedIndexValue(index, timeStamp);
            }
            else
            {
                //nije podrzan taj index
                throw new StockExchangeException("Tip indeksa nije podrzan!");
            }
        }

        /// <summary>
        /// Metoda racuna weighted vrijednost danog indeksa.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private static decimal CalculateWeightedIndexValue(Index index, DateTime timeStamp)
        {
            decimal aggregatValOfIndexStocks = 0m;
            foreach (Stock indexStock in index.Stocks)
            {
                decimal stockExStockValue = indexStock.GetPrice(timeStamp) * indexStock.NumberOfShares;
                decimal factor = stockExStockValue / index.GetValueOfStocks(timeStamp);
                aggregatValOfIndexStocks += factor * indexStock.GetPrice(timeStamp);
            }

            decimal weightIndexValue = aggregatValOfIndexStocks;
            return weightIndexValue;
        }

        /// <summary>
        /// Metoda racuna average vrijednost danog indeksa.
        /// </summary>
        /// <param name="index"></param>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        private static decimal CalculateAverageIndexValue(Index index, DateTime timeStamp)
        {
            decimal allIndexPrices = 0m;
            foreach (Stock stock in index.Stocks)
            {
                allIndexPrices += stock.GetPrice(timeStamp);
            }
            decimal indexValue = allIndexPrices / index.Stocks.Count;
            return indexValue;
        }
    }

    #endregion

    #region Implementacija

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Osnovna klasa implementacije
    /// </summary>
    public class StockExchange : IStockExchange
     {
         public static int NUMBEROFDECIMALSPACES = 3;

         //lista svih dionica na burzi
         private StockExchangeStocks stocks;

         //lista indeksa na burzi
         private List<Index> indexs;

         //portfoliji na burzi
         private StockExchangePortfolios portfolios;

         /// <summary>
         /// Konstruktor razreda
         /// </summary>
         public StockExchange() {
             this.stocks = new StockExchangeStocks();
             this.indexs = new List<Index>();
             this.portfolios = new StockExchangePortfolios();

             //inicializacija promatraca
             this.stocks.RegisterObserver(this.portfolios);
         }

         //dionice na burzi
         public StockExchangeStocks Stocks
         {
             get { return this.stocks; }
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             this.stocks.AddStock(stock);
         }

         public void DelistStock(string inStockName)
         {
             Stock stockToRemove = this.stocks.GetStock(inStockName);
             this.stocks.RemoveStock(stockToRemove);
         }

         public bool StockExists(string inStockName)
         {
            return this.stocks.StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return this.stocks.GetNuberOfAllStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = this.stocks.GetStock(inStockName);
             stock.AddPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = this.stocks.GetStock(inStockName);
             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = this.stocks.GetStock(inStockName);
             return stock.GetFirstDefinedPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = this.stocks.GetStock(inStockName);
             return stock.GetLastDefinedPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index = new Index(inIndexName, inIndexType);
             this.stocks.RegisterObserver(index);
             this.indexs.Add(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stockToAdd = this.stocks.GetStock(inStockName);
             index.AddStock(stockToAdd);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stockToRemove = this.stocks.GetStock(inStockName);
             index.RemoveStock(stockToRemove);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             //provjerava da li je dionica dio burze
             if (this.stocks.StockExists(inStockName))
             {
                 Stock stock = this.stocks.GetStock(inStockName);
                 return index.ContainsStock(stock);
             }
             else {
                 //ako dionica nije dio burze nije sigurno ni dio indexa
                 return false;
             }
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = GetIndex(inIndexName);
             decimal indexValue = index.Type.CalculateIndexValue(index, inTimeStamp);
             return Math.Round(indexValue, NUMBEROFDECIMALSPACES);
         }

         public bool IndexExists(string inIndexName)
         {
             Index indexToCheck = new Index(inIndexName, IndexTypes.AVERAGE);
             return this.indexs.Contains(indexToCheck);
         }

         public int NumberOfIndices()
         {
             return this.indexs.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = GetIndex(inIndexName);
             return index.Stocks.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio portfolio = new Portfolio(inPortfolioID);
             this.portfolios.Add(portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             Stock stock = this.stocks.GetStock(inStockName);
            this.portfolios.AddSharesToPortfolio(portfolio, stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             Stock stock = this.stocks.GetStock(inStockName);
             this.portfolios.RemoveShares(portfolio, stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             Stock stock = this.stocks.GetStock(inStockName);
             this.portfolios.RemoveShares(portfolio, stock);
         }

         public int NumberOfPortfolios()
         {
             return this.portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             return portfolio.GetNumOfAllStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return this.portfolios.Contains(new Portfolio(inPortfolioID));
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             //provjerava da li je dionica dio burze
             if (this.stocks.StockExists(inStockName))
             {
                 Stock stockToCheck = this.stocks.GetStock(inStockName);
                 return portfolio.ContainsStock(stockToCheck);
             }
             else {
                 //ako dionica nije dio burze sigurno nije ni dio portfolija
                 return false;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             Stock stockToCheck = this.stocks.GetStock(inStockName);
             return portfolio.GetNuberOfSharesOfStock(stockToCheck);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             decimal portfolioValue = portfolio.GetValueOfPortfolio(timeStamp);
             return Math.Round(portfolioValue, NUMBEROFDECIMALSPACES);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = this.portfolios.GetPortfolio(inPortfolioID);
             decimal portfolioValueCange = portfolio.GetPercetChangeInValueForMonth(new DateTime(Year, Month, 1));
             return Math.Round(portfolioValueCange, NUMBEROFDECIMALSPACES);
         }

         /// <summary>
         /// Metoda vraća indeks prema indetfikatoru.
         /// </summary>
         /// <param name="indexId"></param>
         /// <returns></returns>
         private Index GetIndex(string indexId) {
             foreach (Index index in this.indexs) {
                 if (index.Equals(indexId)) {
                     return index;
                 }
             }
             
             throw new StockExchangeException("Trazeni indeks ne postoji na burzi!");
         }
     }

    /// <summary>
    /// Klasa modelira aggregat portfolija koji se nalaze na burzi.
    /// </summary>
    public class StockExchangePortfolios : IStockObserver
    {
        //lista portfolija na burzi
        List<Portfolio> portfolios;

        //popis koliko koje dionice ima u svim portfolijima
        Dictionary<Stock, int> sharesInAllPortfolios;

        public StockExchangePortfolios()
        {
            this.portfolios = new List<Portfolio>();
            this.sharesInAllPortfolios = new Dictionary<Stock, int>();
        }

        /// <summary>
        /// Metoda vraća portfolijo prema indetifikatoru.
        /// </summary>
        /// <param name="portfolioId"></param>
        /// <returns></returns>
        public Portfolio GetPortfolio(string portfolioId)
        {
            foreach (Portfolio portfolio in this.portfolios)
            {
                if (portfolio.Equals(portfolioId))
                {
                    return portfolio;
                }
            }

            throw new StockExchangeException("Trazeni portfolio ne postoji na burzi!");
        }

        /// <summary>
        /// Metoda dodaje portflio na burzu.
        /// </summary>
        /// <param name="portfolio"></param>
        internal void Add(Portfolio portfolio)
        {
            if (!this.portfolios.Contains(portfolio))
            {
                this.portfolios.Add(portfolio);
            }
            else
            {
                throw new StockExchangeException("Portfolio sa predanim indetifikatorom vec postoji na burzi!");
            }
        }

        /// <summary>
        /// Metoda dodaje određen broj dionica portfoliju na burzi.
        /// </summary>
        /// <param name="portfolio"></param>
        /// <param name="stock"></param>
        /// <param name="numberOfSharesToAdd"></param>
        internal void AddSharesToPortfolio(Portfolio portfolio, Stock stock, int numberOfSharesToAdd)
        {
            // da li postoji taj portfolio na burzi
            if (this.portfolios.Contains(portfolio))
            {
                //da li su vec dodavane te dionice u neki portfolio
                if (this.sharesInAllPortfolios.ContainsKey(stock))
                {

                    if ((numberOfSharesToAdd + this.sharesInAllPortfolios[stock]) <= stock.NumberOfShares)
                    {
                        //moguce je dodati jos dionica neke dionice
                        portfolio.AddSharesToPortfolio(stock, numberOfSharesToAdd);
                        this.sharesInAllPortfolios[stock] += numberOfSharesToAdd;

                    }

                }
                else if (numberOfSharesToAdd <= stock.NumberOfShares)
                {
                    //dodaju se nove dionice u neki portfolio na burzi
                    portfolio.AddSharesToPortfolio(stock, numberOfSharesToAdd);
                    this.sharesInAllPortfolios.Add(stock, numberOfSharesToAdd);

                }
                else
                {
                    throw new StockExchangeException("Nije mogce dodati vise dionica u portfolio od broja dionica koje postoje na burzi!");
                }
            }
            else
            {
                throw new StockExchangeException("Trazeni portfolio ne postoji na burzi! Pa mu nije moguce dodati dionice.");
            }
        }

        /// <summary>
        /// Metoda brise predani broj dionica sa portfolija.
        /// </summary>
        /// <param name="portfolio"></param>
        /// <param name="stock"></param>
        /// <param name="numberOfShares"></param>
        internal void RemoveShares(Portfolio portfolio, Stock stock, int numberOfShares)
        {
            //da li predane dionice i portfolijo postoji na burzi
            if (this.portfolios.Contains(portfolio) && this.sharesInAllPortfolios.ContainsKey(stock))
            {

                portfolio.RemoveShares(stock, numberOfShares);
                this.sharesInAllPortfolios[stock] -= numberOfShares;

            }
            else
            {
                throw new StockExchangeException("Trazeni portfolio ne postoji na burzi! Pa mu nije moguce maknuti dionice.");
            }
        }

        /// <summary>
        /// Metoda brise dionicu iz zadanog portfolija.
        /// </summary>
        /// <param name="portfolio"></param>
        /// <param name="stock"></param>
        internal void RemoveShares(Portfolio portfolio, Stock stock)
        {
            if (this.portfolios.Contains(portfolio) && this.sharesInAllPortfolios.ContainsKey(stock))
            {
                this.sharesInAllPortfolios[stock] -= portfolio.GetNuberOfSharesOfStock(stock);
                portfolio.RemoveAllShares(stock);
            }
            else
            {
                throw new StockExchangeException("Nije moguce izbrisati dionice iz portfolija jer ih on ne sadrzi!");
            }
        }

        /// <summary>
        /// Metoda vraca broj portfolija na burzi.
        /// </summary>
        /// <returns></returns>
        public int Count
        {
            get { return this.portfolios.Count; }
        }

        /// <summary>
        /// Metoda vraca da li postoji trazeni portfolio
        /// </summary>
        /// <param name="portfolio"></param>
        /// <returns></returns>
        internal bool Contains(Portfolio portfolio)
        {
            return this.portfolios.Contains(portfolio);
        }

        /// <summary>
        /// Brise dionice iz svih portfolija
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            foreach (Portfolio portfolio in this.portfolios)
            {
                portfolio.RemoveStock(stock);
            }
        }
    }

    /// <summary>
    /// Klasa predstavlja aggregat dionica koje se nalaze na burzi.
    /// </summary>
    public class StockExchangeStocks : IStockSubject
    {
        //interna lista dioncia na burzi
        List<Stock> stocks;

        //lista promatraca na subjekt
        List<IStockObserver> observers;

        /// <summary>
        /// Konstruktor razreda.
        /// </summary>
        /// <param name="stocks"></param>
        public StockExchangeStocks(List<Stock> stocks)
        {
            this.stocks = stocks;

        }

        /// <summary>
        /// Konstruktor razreda
        /// </summary>
        public StockExchangeStocks()
        {
            this.stocks = new List<Stock>();
            this.observers = new List<IStockObserver>();
        }

        /// <summary>
        /// Metoda dodaje dionicu na burzu.
        /// </summary>
        /// <param name="stock"></param>
        public void AddStock(Stock stock)
        {
            if (!this.stocks.Contains(stock))
            {
                this.stocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Nije moguce dodati dionicu istog naziva. Dionica:" + stock.Name + " nije dodana!");
            }
        }

        /// <summary>
        /// Metoda vraća doinicu u slucaju da postoji na burzi inace baci gresku.
        /// </summary>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public Stock GetStock(string stockId)
        {
            Stock stockToReturn = null;
            foreach (Stock stock in this.stocks)
            {
                if (stock.Equals(stockId))
                {
                    stockToReturn = stock;
                }
            }

            if (stockToReturn != null)
            {
                return stockToReturn;
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji na burzi!");
            }
        }

        /// <summary>
        /// Metoda miče dionicu sa burze.
        /// </summary>
        /// <param name="stock"></param>
        public void RemoveStock(Stock stock)
        {
            Stock stockToRemove = null;
            foreach (Stock stockOnExcange in this.stocks)
            {
                if (stockOnExcange.Equals(stock))
                {
                    stockToRemove = stockOnExcange;
                }
            }

            if (stockToRemove != null)
            {
                NotifyObservers(stockToRemove);
                this.stocks.Remove(stockToRemove);
            }
            else
            {
                throw new StockExchangeException("Nije moguće maknuti dionicu koja nije na burzi. Dionica " + stock.Name + " nije maknuta sa burze!");
            }
        }

        /// <summary>
        /// Metoda dodaje promatraca u listu promatraca.
        /// U slucaju da promatrac već postoji ignorira se dodaja.
        /// </summary>
        /// <param name="stockObsever"></param>
        public void RegisterObserver(IStockObserver stockObsever)
        {
            if (!this.observers.Contains(stockObsever))
            {
                this.observers.Add(stockObsever);
            }
            else
            {
                //promatrač već postoji pa se ignorira
            }
        }

        /// <summary>
        /// Metoda brise promatraca iz liste promatraca.
        /// U slučaju da nije u listi ignorira se.
        /// </summary>
        /// <param name="stockObserver"></param>
        public void UnregistarObserver(IStockObserver stockObserver)
        {
            if (this.observers.Contains(stockObserver))
            {
                this.observers.Remove(stockObserver);
            }
            else
            {
                //ne postoji promatrač pa se ignorira
            }
        }

        /// <summary>
        /// Metoda obavještava promatrače da se izbrisala dionica sa burze
        /// </summary>
        /// <param name="stock"></param>
        public void NotifyObservers(Stock stock)
        {
            foreach (IStockObserver observer in this.observers)
            {
                observer.RemoveStock(stock);
            }
        }

        /// <summary>
        /// Metoda provjerava da li dionica postoji na burzi.
        /// </summary>
        /// <param name="stock"></param>
        /// <returns></returns>
        internal bool StockExists(string stock)
        {
            Stock stockExistis = null;
            foreach (Stock stockOnExcange in this.stocks)
            {
                if (stockOnExcange.Equals(stock))
                {
                    stockExistis = stockOnExcange;
                }
            }

            if (stockExistis != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int GetNuberOfAllStocks() {
            return this.stocks.Count;
        }

    }

    #endregion
}
