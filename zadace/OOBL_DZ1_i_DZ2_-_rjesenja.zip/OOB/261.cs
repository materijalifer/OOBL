﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        private class Record
        {
            protected string _digits;  //prikaz brojeva u stringu
            protected int _comma;      //pozicija gdje se nalazi zarez, ako je -1 ne prikazuje se
            protected bool _sign;      //predzank, true za -, false za +
            protected bool _error;     //oznaka da li se prikazuje -E-
            protected const int maxDigit = 10;

            /// <summary>
            /// Uzmi brojevni zapis
            /// </summary>
            public string getDigits
            {
                get
                {
                    return _digits;
                }
            }

            /// <summary>
            /// Uzmi poziciju zareza
            /// </summary>
            public int getComma
            {
                get
                {
                    return _comma;
                }
            }

            /// <summary>
            /// Uzmi predznak
            /// </summary>
            public bool getSign
            {
                get
                {
                    return _sign;
                }
            }

            /// <summary>
            /// Uzmi error
            /// </summary>
            public bool getError
            {
                get
                {
                    return _error;
                }
            }



            /// <summary>
            /// Zaokruzi broj i javi ako je prevelik
            /// </summary>
            /// <param name="number">Broj koji se zaokruzuje</param>
            /// <returns>Ako je broj valjan vrati true, inace false </returns>
            private bool Round(ref double number)
            {
                string numberString = String.Format("{0:0.##########}", number);

                if (numberString[0] == '-')
                    numberString = numberString.Substring(1);

                int commaPos = numberString.IndexOf(',');

                //ako je decimalna tocka dalje od desetog znaka greska
                if (commaPos > maxDigit)
                    return false;

                //ako je int dio broja prevelik greska
                if (commaPos == -1 && numberString.Length > maxDigit)
                    return false;

                number = Math.Round(number, maxDigit - commaPos);

                return true;
            }

            /// <summary>
            /// Konstruktor Record razreda
            /// </summary>
            public Record()
            {
                _digits = "0";
                _comma = -1;
                _sign = false;
                _error = false;
            }

            /// <summary>
            /// Record copy konstruktor
            /// </summary>
            /// <param name="A"></param>
            public Record(Record A)
            {
                _digits = A._digits;
                _comma = A._comma;
                _sign = A._sign;
                _error = A._error;
            }


            /// <summary>
            /// Spremi broj tipa dobule u Record
            /// </summary>
            /// <param name="number">Broj tipa double</param>
            public void SaveDouble(double number)
            {
                //zaokruzi i provjeri valjanost broja

                if (Round(ref number) == false)
                {
                    _error = true;
                    return;
                }

                string stringNumber = String.Format("{0:0.##########}", number);

                //provjeri predzank i spremi ga
                if (stringNumber[0] == '-')
                {
                    _sign = true;
                    stringNumber = stringNumber.Substring(1);
                }
                else
                    _sign = false;


                //spremi poziciju zareza
                int locComma = stringNumber.IndexOf(',');

                if (locComma != -1)
                    stringNumber = stringNumber.Remove(locComma, 1);

                _comma = locComma;

                //spremi znamenke i ako je greska oznaci to u Recordu
                _digits = stringNumber;
            }

            /// <summary>
            /// Pretvaranje Record u string
            /// </summary>
            /// <returns>Vraca string prikaz broja</returns>
            public override string ToString()
            {
                //ako je error odmah vrati -E-

                if (_error == true)
                    return "-E-";

                string ret = "";

                //obradi predznak
                if (_sign == true)
                    ret = "-";

                //obradi zarez
                if (_comma != -1)
                    ret += _digits.Substring(0, _comma) + "," + _digits.Substring(_comma);
                else
                    ret += _digits;

                return ret;
            }

            /// <summary>
            /// Dohvati Record kao double broj
            /// </summary>
            /// <returns>Double tip broj koji je spremljen kao Record</returns>
            public double ToDouble()
            {
                if (_error == true) return 0; //zanemari ako je error
                return Convert.ToDouble(this.ToString());
            }

        }

        private class SmartRecord : Record
        {
            private bool _lock; //ako je true vise nije dopusteno tipkanje

            /// <summary>
            /// Vrati ako je zapis zakljucan (nemozre se mijenjati)
            /// </summary>
            public bool Locked
            {
                set
                {
                    _lock = value;
                }
                get
                {
                    return _lock;
                }
            }

            public bool Error
            {
                set
                {
                    _error = value;
                }
            }

            /// <summary>
            /// Konstruktor razreda SmartRecord
            /// </summary>
            public SmartRecord()
            {
                _digits = "0";
                _comma = -1;
                _sign = false;
                _error = false;
                _lock = false;
            }

            /// <summary>
            /// Zapisi u SmartRecord Record ali obavezno se navodi da li je zapis zakljucan
            /// </summary>
            /// <param name="A">Objekt razreda Record</param>
            /// <param name="locked">Oznaka da li je zakljucan ili ne</param> 
            public SmartRecord(Record A, bool locked)
            {
                this._digits = A.getDigits;
                this._comma = A.getComma;
                this._sign = A.getSign;
                this._error = A.getError;
                this._lock = locked;
            }

            /// <summary>
            /// SmartRecord copy konstruktor
            /// </summary>
            /// <param name="A"></param>
            public SmartRecord(SmartRecord A)
            {
                _digits = A._digits;
                _comma = A._comma;
                _sign = A._sign;
                _error = A._error;
                _lock = A._lock;
            }

            /// <summary>
            /// Promijeni predzank
            /// </summary>
            public void SetSign()
            {
                if (_lock == false)
                {
                    double number = this.ToDouble();
                    this.SaveDouble(-1 * number);
                }
            }

            /// <summary>
            /// Postavi zarez
            /// </summary>
            public void SetComma()
            {
                if (_comma == -1)
                    _comma = _digits.Length;
            }

            /// <summary>
            /// Zapisi jedan znak u zapis
            /// </summary>
            /// <param name="oneDigit"></param>
            public void PutDigit(char oneDigit)
            {
                if (_digits.Length >= 10) return; //ako je popunjeno ne puni
                if (_error == true) return; //ako je error zanemari sve

                //zanemari 0 ako se stisce na pocetku
                if (_digits == "0" && oneDigit == '0' && _comma == -1)
                    return;

                if (_digits == "0" && _comma == -1)
                    _digits = oneDigit.ToString();
                else
                    _digits += oneDigit;
            }
        }

        private delegate double MathFunction(double X);

        //prikaz na ekranu
        private SmartRecord _currentOnDisplay;

        //prvi operand za binarni operatpr
        private Record _binaryOperand;

        //memorija kalkulatora (P i G operacije)
        private Record _memory;

        // pamti koji je zandji operator, oznaka N oznacuje da ga nema
        private char _currentOperator;

        //ako je true, to znaci da ce se sigurno izvrstiti trenutni operator
        private bool _strongOperator;




        /// <summary>
        /// Simulacija operatora =
        /// </summary>
        private void EqualsOperator()
        {
            if (_currentOperator != 'N')
            {
                double opr1 = _binaryOperand.ToDouble();
                double opr2 = _currentOnDisplay.ToDouble();
                double sol = 0;
                if (_currentOperator == '+')
                    sol = opr1 + opr2;
                else if (_currentOperator == '-')
                    sol = opr1 - opr2;
                else if (_currentOperator == '*')
                    sol = opr1 * opr2;
                else if (_currentOperator == '/' && opr2 != 0)
                    sol = opr1 / opr2;
                else
                {
                    _currentOnDisplay.Error = true;
                    return;
                }

                _currentOnDisplay.SaveDouble(sol);
            }
            else
            {
                _currentOnDisplay.SaveDouble(_currentOnDisplay.ToDouble());
            }

            _currentOperator = 'N';

            _currentOnDisplay.Locked = true;
        }

        /// <summary>
        /// Simulacija binarnih operatora
        /// </summary>
        /// <param name="op">Znak za binarni operator</param>
        private void ProcessBinaryOperator(char op)
        {
            if (_strongOperator == true)
                EqualsOperator();
            _currentOnDisplay.SaveDouble(_currentOnDisplay.ToDouble()); //zaokruzi ako je potrebno
            _currentOperator = op; //oznaci da je operator aktivan
            _binaryOperand = new Record(_currentOnDisplay); //zapamti operand
            _currentOnDisplay.Locked = true; //zakljucaj ekran
            _strongOperator = false;
        }

        /// <summary>
        /// Simulacija unarnih operatora
        /// </summary>
        /// <param name="op">Znak za unarni operator</param>
        private void ProcessUnaryOperator(char op)
        {
            if (op == 'S')
                UnaryOperator(Math.Sin);
            else if (op == 'K')
                UnaryOperator(Math.Cos);
            else if (op == 'T')
                UnaryOperator(Math.Tan);
            else if (op == 'Q')
                UnaryOperator(Quadrat);
            else if (op == 'R')
                UnaryOperator(Sqrt);
            else if (op == 'I')
                UnaryOperator(Inverse);
        }


        /// <summary>
        /// Simuliraj kvadrat
        /// </summary>
        /// <param name="x">Double broj x</param>
        /// <returns>x*x</returns>
        private double Quadrat(double x)
        {
            return x * x;
        }

        /// <summary>
        /// Inverz broja 1/x, ako je x=0 automatski prijavi gresku
        /// </summary>
        /// <param name="x">Double broj x</param>
        /// <returns>1/x</returns>
        private double Inverse(double x)
        {
            if (x == 0)
            {
                _currentOnDisplay.Error = true;
                return 0;
            }

            return 1 / x;
        }

        /// <summary>
        /// Korjen broja, ako je x manji od 0 prijavi gresku
        /// </summary>
        /// <param name="x">Double broj x</param>
        /// <returns>Sqrt(x)</returns>
        private double Sqrt(double x)
        {
            if (x < 0)
            {
                _currentOnDisplay.Error = true;
                return 0;
            }
            return Math.Sqrt(x);
        }


        /// <summary>
        /// Simulacija unarnog operatora
        /// </summary>
        /// <param name="F">Funkcija/Metoda koja se izvrsava</param>
        private void UnaryOperator(MathFunction F)
        {
            double number = F(_currentOnDisplay.ToDouble());
            _currentOnDisplay.SaveDouble(number);
            _currentOnDisplay.Locked = true; //zakljucaj zapis
        }

        /// <summary>
        /// Reset kalulatora
        /// </summary>
        private void Reset()
        {
            _currentOnDisplay = new SmartRecord();
            _binaryOperand = new Record();
            _memory = new Record();
            _currentOperator = 'N';
            _strongOperator = false;
        }


        /// <summary>
        /// Konstruktor kalkulatora
        /// </summary>
        public Kalkulator()
        {
            //System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            Reset();
        }

        /// <summary>
        /// Simuliraj pritisak na tipku
        /// </summary>
        /// <param name="inPressedDigit"></param>
        public void SimulatePressDigit(char inPressedDigit)
        {
            if (_currentOnDisplay.Locked == true)
            {
                _currentOnDisplay = new SmartRecord();
                _strongOperator = true;
            }
            _currentOnDisplay.PutDigit(inPressedDigit);
        }

        /// <summary>
        /// Calculator input
        /// </summary>
        /// <param name="inPressedDigit">Pressed key</param>
        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'O')
                Reset();
            else if (_currentOnDisplay.getError == true)
                return;
            else if (Char.IsDigit(inPressedDigit))
                SimulatePressDigit(inPressedDigit);
            else if (inPressedDigit == ',')
                _currentOnDisplay.SetComma();
            else if (inPressedDigit == 'M')
                _currentOnDisplay.SetSign();
            else if (inPressedDigit == 'C')
                _currentOnDisplay = new SmartRecord();
            else if (inPressedDigit == 'P')
                _memory = new Record(_currentOnDisplay);
            else if (inPressedDigit == 'G')
            {
                _currentOnDisplay = new SmartRecord(_memory, true);
                _currentOnDisplay.SaveDouble(_currentOnDisplay.ToDouble());
            }
            else if ("SKTQRI".IndexOf(inPressedDigit) != -1) //ako je unarni
                ProcessUnaryOperator(inPressedDigit);
            else if ("+-/*".IndexOf(inPressedDigit) != -1) //ako je binarni operator
                ProcessBinaryOperator(inPressedDigit);
            else if (inPressedDigit == '=')
                EqualsOperator();
        }

        /// <summary>
        /// Get display status
        /// </summary>
        /// <returns>Display status as string</returns>
        public string GetCurrentDisplayState()
        {
            return _currentOnDisplay.ToString();
        }
    }


}
