﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> stocks;
        private List<Index> indices;
        private List<Portfolio> portfolios;

        public StockExchange()
        {
            stocks = new List<Stock>();
            indices = new List<Index>();
            portfolios = new List<Portfolio>();
        }

        private Stock getStock(string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock is not listed on exchange!");
            return stocks.First(s => s.StockName.ToLowerInvariant() == inStockName.ToLowerInvariant());
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName)) throw new StockExchangeException("Stock is already listed!");
            stocks.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName)) throw new StockExchangeException("Stock is already not listed on exchange!");
            stocks.Remove(this.getStock(inStockName));
        }

        public bool StockExists(string inStockName)
        {
            return stocks.Exists(s => s.StockName.ToLowerInvariant() == inStockName.ToLowerInvariant());
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            this.getStock(inStockName).AddPriceAtMoment(inStockValue, inIimeStamp);
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            return this.getStock(inStockName).GetPriceAtMoment(inTimeStamp);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            return this.getStock(inStockName).InitialPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            return this.getStock(inStockName).LastPrice;
        }

        private Index getIndex(string inIndexName)
        {
            if (!(this.IndexExists(inIndexName))) throw new StockExchangeException("Index does not exist!");
            return indices.First(i => i.Name.ToLowerInvariant() == inIndexName.ToLowerInvariant());
        }
        
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (this.IndexExists(inIndexName)) throw new StockExchangeException("Index already exists!");
            indices.Add(new Index(inIndexName, inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            this.getIndex(inIndexName).AddStock(this.getStock(inStockName));
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            this.getIndex(inIndexName).RemoveStock(this.getStock(inStockName));
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            return this.getIndex(inIndexName).ContainsStock(this.getStock(inStockName));
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            return this.getIndex(inIndexName).ValueAtMoment(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            return indices.Exists(i => i.Name.ToLowerInvariant() == inIndexName.ToLowerInvariant());
        }

        public int NumberOfIndices()
        {
            return this.indices.Count();
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            return this.getIndex(inIndexName).GetNumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("Portfolio already exists!");
            portfolios.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            this.getPortfolio(inPortfolioID).AddShares(this.getStock(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            this.getPortfolio(inPortfolioID).RemoveShares(this.getStock(inStockName), numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            this.getPortfolio(inPortfolioID).RemoveShares(this.getStock(inStockName));
        }

        public int NumberOfPortfolios()
        {
            return this.portfolios.Count();
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            return this.getPortfolio(inPortfolioID).NumberOfStocks();
        }

        private Portfolio getPortfolio(string inPortfolioID)
        {
            if (!this.PortfolioExists(inPortfolioID)) throw new StockExchangeException("Specified portfolio does not exist!");
            return portfolios.First(p => p.Id == inPortfolioID);
        }
        
        public bool PortfolioExists(string inPortfolioID)
        {
            return this.portfolios.Exists(p => p.Id == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            return this.getPortfolio(inPortfolioID).ContainsStock(this.getStock(inStockName));
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            return (int)this.getPortfolio(inPortfolioID).NumberOfShares(this.getStock(inStockName));
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            return this.getPortfolio(inPortfolioID).GetValue(timeStamp);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            throw new NotImplementedException();
        }
    }

    internal class Stock
    {
        private string stockName;
        public string StockName { get { return stockName; } }

        private long maxNumberOfShares;
        private long availableNumberOfShares;

        private Decimal initialPrice;
        public Decimal InitialPrice
        {
            get
            {
                return initialPrice;
            }
        }

        public Decimal LastPrice { get { return prices.GetLastPrice(); } }

        public Dictionary<Portfolio, long> shares;

        private StockPrice prices;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if ((inNumberOfShares <= 0) || (inInitialPrice <= 0)) throw new StockExchangeException("Stock must have a valid (positive) number of shares and price!");
            this.stockName = inStockName;
            this.maxNumberOfShares = inNumberOfShares;
            this.availableNumberOfShares = inNumberOfShares;
            this.initialPrice = inInitialPrice;
            this.prices = new StockPrice();
            this.shares = new Dictionary<Portfolio, long>();
            this.prices.AddPriceAtMoment(inInitialPrice, inTimeStamp);
        }

        public void AddPriceAtMoment(decimal price, DateTime moment)
        {
            if (price <= 0) throw new StockExchangeException("Price of a stock must always be positive!");
            prices.AddPriceAtMoment(price, moment);
        }

        public decimal GetPriceAtMoment(DateTime moment)
        {
            return prices.GetPriceAtMoment(moment);
        }

        public decimal GetValueAtMoment(DateTime moment)
        {
            return this.GetPriceAtMoment(moment) * maxNumberOfShares;
        }

        public bool HasSharesInPorfolio(Portfolio portfolio)
        {
            return shares.ContainsKey(portfolio);
        }

        public void AddSharesToPortfolio(Portfolio portfolio, long nrOfShares)
        {
            if (nrOfShares <= 0) throw new StockExchangeException("Number of shares to add must be a natural number!");          
            if (availableNumberOfShares < nrOfShares) throw new StockExchangeException("There are not enough shares available to add to portfolio!");
            if (this.HasSharesInPorfolio(portfolio))
            {
                shares[portfolio] += nrOfShares;
            }
            else
            {
                shares.Add(portfolio, nrOfShares);
            }
            availableNumberOfShares -= nrOfShares;
        }
        public void RemoveSharesFromPortfolio(Portfolio portfolio, long nrOfShares)
        {
            if (nrOfShares <= 0) throw new StockExchangeException("Number of shares to add must be a natural number!");
            if (!this.HasSharesInPorfolio(portfolio)) throw new StockExchangeException("The portfolio does not contain any shares of that stock!");
            if (nrOfShares > shares[portfolio]) throw new StockExchangeException("The portfolio does not contain that many shares!");
            shares[portfolio] -= nrOfShares;
            availableNumberOfShares += nrOfShares;
            if (shares[portfolio] == 0) shares.Remove(portfolio);
        }

        public void RemoveSharesFromPortfolio(Portfolio portfolio)
        {
            if (!this.HasSharesInPorfolio(portfolio)) throw new StockExchangeException("The portfolio does not contain any shares of that stock!");
            availableNumberOfShares += shares[portfolio];
            shares.Remove(portfolio);
        }

        public long GetNrOfSharesInPortfolio(Portfolio portfolio)
        {
            if (!this.HasSharesInPorfolio(portfolio)) throw new StockExchangeException("The portfolio does not contain any shares of that stock!");
            return shares[portfolio];
        }

        public decimal GetValueForPortfolio(Portfolio portfolio, DateTime moment)
        {
            if (!this.HasSharesInPorfolio(portfolio)) throw new StockExchangeException("The portfolio does not contain any shares of that stock!");
            return shares[portfolio] * this.GetPriceAtMoment(moment);
        }
    }

    internal class Portfolio
    {
        private string id;
        private List<Stock> stockInPortfolio;

        public string Id
        {
            get { return id; }
        }

        public Portfolio(string id)
        {
            this.id = id;
            this.stockInPortfolio = new List<Stock>();
        }

        public void AddShares(Stock stock, long amount)
        {
            stock.AddSharesToPortfolio(this, amount);
            if (!this.ContainsStock(stock)) stockInPortfolio.Add(stock);
        }

        public void RemoveShares(Stock stock, long amount)
        {
            stock.RemoveSharesFromPortfolio(this, amount);
            if (!stock.HasSharesInPorfolio(this)) stockInPortfolio.Remove(stock);
        }

        public void RemoveShares(Stock stock)
        {
            stock.RemoveSharesFromPortfolio(this);
            stockInPortfolio.Remove(stock);
        }

        public int NumberOfStocks()
        {
            return stockInPortfolio.Count();
        }

        public long NumberOfShares(Stock stock)
        {
            return stock.GetNrOfSharesInPortfolio(this);
        }

        public bool ContainsStock(Stock stock)
        {
            return this.stockInPortfolio.Contains(stock);
        }

        private decimal getValue(DateTime moment)
        {
            return (from s in stockInPortfolio
                    select s.GetValueForPortfolio(this, moment)).Sum();
        }

        public decimal GetValue(DateTime moment)
        {
            return Decimal.Round(this.getValue(moment));
        }

        public decimal GetPercentageChangeForMonth(int year, int month)
        {
            DateTime begin = new DateTime(year, month, 1, 0, 0, 0, 000);
            DateTime end = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);
            return Decimal.Round(((this.getValue(end) / this.getValue(begin)) - 1)*100, 3);
        }
    }

    internal class Index
    {
        private string name;

        public string Name
        {
            get { return name; }
        }

        private IndexTypes type;

        public IndexTypes Type
        {
            get { return type; }
        }

        private List<Stock> stocks;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.stocks = new List<Stock>();
            this.name = inIndexName;

            if (!(Enum.IsDefined(typeof(IndexTypes), inIndexType))) throw new Exception("Indicated index type does not exist!");
            this.type = inIndexType;
        }

        public void AddStock(Stock stock)
        {
            if (stocks.Contains(stock)) throw new StockExchangeException("Stock is already in index!");
            stocks.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            if (!(stocks.Contains(stock))) throw new StockExchangeException("Stock is not in index!");
            stocks.Remove(stock);
        }

        public bool ContainsStock(Stock stock)
        {
            return stocks.Contains(stock);
        }

        public decimal ValueAtMoment(DateTime moment)
        {
            switch (this.type)
            {
                case IndexTypes.AVERAGE:
                    var prices = from s in this.stocks
                                 select s.GetPriceAtMoment(moment);
                    return Decimal.Round((prices.Sum() / prices.Count()), 3);
                case IndexTypes.WEIGHTED:
                    var values = from s in this.stocks
                                 select s.GetValueAtMoment(moment);
                    var weightedPrices = from s in this.stocks
                                         select (s.GetValueAtMoment(moment) / values.Sum()) * s.GetPriceAtMoment(moment);
                    return Decimal.Round(weightedPrices.Sum());
                default:
                    throw new StockExchangeException("Value algorithm for desired index type not implemented!");
            }
        }

        public int GetNumberOfStocks()
        {
            return stocks.Count();
        }
    }

    internal class StockPrice
    {
        private List<KeyValuePair<DateTime, Decimal>> pricesAtMoment;

        public StockPrice()
        {
            pricesAtMoment = new List<KeyValuePair<DateTime, decimal>>();
        }

        public void AddPriceAtMoment(decimal price, DateTime moment)
        {
            if (price <= 0) throw new StockExchangeException("Price of a stock must always be positive!");
            if (!(pricesAtMoment.Exists(pr => pr.Key == moment))) pricesAtMoment.Add(new KeyValuePair<DateTime, decimal>(moment, price));
            else throw new StockExchangeException("Price already definied for the stock at that moment!");
            pricesAtMoment = pricesAtMoment.OrderBy(p => p.Key).ToList();
        }

        public decimal GetPriceAtMoment(DateTime moment)
        {
            if ((pricesAtMoment.Count == 0) || (moment < pricesAtMoment.First().Key)) throw new StockExchangeException("Price not defined for specified moment!");
            decimal price = 0;
            var oldmp = pricesAtMoment.First();
            foreach (var mp in pricesAtMoment)
            {
                if (moment <= mp.Key) price = oldmp.Value;
                oldmp = mp;
            }
            if (price == 0) price = pricesAtMoment.Last().Value;
            return price;
        }

        public decimal GetLastPrice()
        {
            if (pricesAtMoment.Count == 0) throw new StockExchangeException("No price defined!");
            return pricesAtMoment.Last().Value;
        }
    }
}
