﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{


    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string stanje;
        private string memorija;

        public Kalkulator()
        {
            this.stanje = "0";
            this.memorija="";
        }

        public void Press(char inPressedDigit)
        {
            if (stanje.Length < 12)
            {
                if (inPressedDigit == ',')
                {
                   stanje = stanje + inPressedDigit;
                }
                else if (inPressedDigit == 'P')
                {
                    memorija = stanje;
                }
                else if (inPressedDigit == 'G')
                {
                    stanje = memorija;
                }
                else if (inPressedDigit == 'C')
                {
                    stanje = "0";
                }
                else if (inPressedDigit == 'O')
                {
                    stanje = "0";
                    memorija = "";
                }
                else if (inPressedDigit == 'S')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'K')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'T')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'I')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'Q')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'R')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == 'M')
                {
                    stanje = RacunajTrig(inPressedDigit);
                }
                else if (inPressedDigit == '0')
                {
                    if (stanje != "0")
                        stanje = stanje + inPressedDigit;

                    stanje=SkratiString(stanje);
                   
                }
                else if (inPressedDigit == '=')
                {
                    stanje = IzracunajIzraz(stanje);
                }

                else
                {   // dodavaj
                    if (stanje == "0")
                        stanje = inPressedDigit.ToString();
                    else
                    {
                        stanje = stanje + inPressedDigit.ToString();
                    }
                }

            }
        }

        private string IzracunajIzraz(string stanje)
        {
            double num;
            string r="";

            if (double.TryParse(stanje, out num))
            {
               if ((num - 0.000) == num)
                    r = Convert.ToInt32(num).ToString();
                else
                    r = num.ToString();

            }
            else if (stanje[stanje.Length - 1] == '+')
            {
                double numm;
                if (double.TryParse(stanje.Remove(stanje.Length - 1, 1), out numm))
                {
                    if ((numm - 0.000) == numm)
                        r = Convert.ToInt32(numm + numm).ToString();
                    else
                        r = (numm + numm).ToString();
                }
            }
            else if (stanje[stanje.Length - 1] == '*')
            {
                double numm;
                if (double.TryParse(stanje.Remove(stanje.Length - 1, 1), out numm))
                {
                    if ((numm - 0.000) == numm)
                        r = Convert.ToInt32(numm * numm).ToString();
                    else
                        r = (numm * numm).ToString();
                }
            }

           return SkratiString(r);

        }

        private string SkratiString(string r)
        {
            if (r.Length > 11)
                r = r.Remove(12, r.Length - 12);

            return r;
        }

        private string RacunajTrig(char inPressDigit)
        {
            double num;
            string candidate = stanje;
            string rez = "";
            if (double.TryParse(candidate, out num))
            {
                if(inPressDigit=='S')
                    rez = Math.Sin(num).ToString();
                else if (inPressDigit=='K')
                    rez = Math.Cos(num).ToString();
                else if (inPressDigit == 'T')
                    rez = Math.Tan(num).ToString();
                else if (inPressDigit == 'I')
                {
                    if (num != 0)
                        rez = (1 / num).ToString();
                    else
                        rez = "-E-";
                }
                else if (inPressDigit == 'R')
                {
                    if (num < 0)
                        rez = (1 / num).ToString();
                    else
                        rez = "-E-";
                }
                else if (inPressDigit == 'Q')
                        rez = (num* num).ToString();
                else if (inPressDigit == 'M')
                        rez = (num*(-1)).ToString();

                rez = SkratiString(rez);
            }
            else
            {
                rez = rez + inPressDigit;
            }
            return rez;
        }

     
        public string GetCurrentDisplayState()
        {
            return stanje;
        }

 
    }

  
}
