﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new MojKalkulator();
        }
    }

    public class MojKalkulator : ICalculator
    {


        public interface Command
        {
             void ExecuteCommand();
        }

        class MinusCommand : Command
        {
            MojKalkulator mainClass;

            public MinusCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {

                string currentDisplayStateTemp = mainClass.GetCurrentDisplayState();
                mainClass.ResetCurrentDisplayState();
                if (currentDisplayStateTemp.Contains('-'))
                {
                    mainClass.ChangeCurrentDisplayState(currentDisplayStateTemp.Replace("-", ""));
                }
                else if (!currentDisplayStateTemp.Equals("0"))
                {
                    mainClass.ChangeCurrentDisplayState("-" + currentDisplayStateTemp);
                }
            }
        }

        class ResetCommand : Command
        {
            MojKalkulator mainClass;

            public ResetCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {

                mainClass.ResetAll();
            }
        }

        class AddCommand : Command
        {
            MojKalkulator mainClass;

            public AddCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.SetRegisterValue(1, Double.Parse(mainClass.GetCurrentDisplayState()));
                mainClass.SetRegisterValue(0, mainClass.GetRegisterValue(0) + mainClass.GetRegisterValue(1));
                mainClass.ResetCurrentDisplayState();
                mainClass.ProperlyRoundRegisterValue(0);
                mainClass.ChangeCurrentDisplayState(mainClass.GetRegisterValue(0).ToString());
            }
        }

        class SubtractCommand : Command
        {
            MojKalkulator mainClass;

            public SubtractCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.SetRegisterValue(1, Double.Parse(mainClass.GetCurrentDisplayState()));
                mainClass.SetRegisterValue(0, mainClass.GetRegisterValue(0) - mainClass.GetRegisterValue(1));
                mainClass.ResetCurrentDisplayState();
                mainClass.ProperlyRoundRegisterValue(0);
                mainClass.ChangeCurrentDisplayState(mainClass.GetRegisterValue(0).ToString());
            }
        }

        class DivideCommand : Command
        {
            MojKalkulator mainClass;

            public DivideCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.SetRegisterValue(1, Double.Parse(mainClass.GetCurrentDisplayState()));
                mainClass.SetRegisterValue(0, mainClass.GetRegisterValue(0) / mainClass.GetRegisterValue(1));
                 mainClass.ResetCurrentDisplayState();
                mainClass.ProperlyRoundRegisterValue(0);
                mainClass.ChangeCurrentDisplayState(mainClass.GetRegisterValue(0).ToString());
            }
        }

        class MultiplyCommand : Command
        {
            MojKalkulator mainClass;

            public MultiplyCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.SetRegisterValue(1, Double.Parse(mainClass.GetCurrentDisplayState()));
                mainClass.SetRegisterValue(0, mainClass.GetRegisterValue(0) * mainClass.GetRegisterValue(1));
                 mainClass.ResetCurrentDisplayState();
                mainClass.ProperlyRoundRegisterValue(0);
                mainClass.ChangeCurrentDisplayState(mainClass.GetRegisterValue(0).ToString());
            }
        }

        class SinusCommand : Command
        {
            MojKalkulator mainClass;

            public SinusCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                result = mainClass.ProperlyRoundValue(Math.Sin(result));
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class CosinusCommand : Command
        {
            MojKalkulator mainClass;

            public CosinusCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                result = mainClass.ProperlyRoundValue(Math.Cos(result));
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class TangensCommand : Command
        {
            MojKalkulator mainClass;

            public TangensCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                result = mainClass.ProperlyRoundValue(Math.Tan(result));
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class RootCommand : Command
        {
            MojKalkulator mainClass;

            public RootCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                result = mainClass.ProperlyRoundValue(Math.Sqrt(result));
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class QuadratCommand : Command
        {
            MojKalkulator mainClass;

            public QuadratCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                result = mainClass.ProperlyRoundValue(Math.Pow(result, 2));
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class InversCommand : Command
        {
            MojKalkulator mainClass;

            public InversCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                double result = Double.Parse(mainClass.GetCurrentDisplayState());
                if (result != 0)
                {
                    result = mainClass.ProperlyRoundValue(1 / result);
                }
                else
                {
                    mainClass.isError = true;
                }
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(result.ToString());
            }
        }

        class PutCommand : Command
        {
            MojKalkulator mainClass;

            public PutCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.memory = mainClass.GetCurrentDisplayState();
            }
        }

        class GetCommand : Command
        {
            MojKalkulator mainClass;

            public GetCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.ResetCurrentDisplayState();
                mainClass.ChangeCurrentDisplayState(mainClass.memory);
            }
        }

        class ClearCommand : Command
        {
            MojKalkulator mainClass;

            public ClearCommand(MojKalkulator mainClass)
            {
                this.mainClass = mainClass;
            }

            public void ExecuteCommand()
            {
                mainClass.ResetCurrentDisplayState();
            }
        }

        private string currentDisplayState;
        private int numberOfDigits = 0;
        private bool isError;
        private double[] registers;
        private Dictionary<string, Command> mapOfCommands = new Dictionary<string, Command>();
        private State currentState;
        private string memory;

        private const int maxNumberOfDigits = 10;
        private const char PLUS = '+';
        private const char MINUS = '-';
        private const char MULTIPLICATION_SIGN = '*';
        private const char DIVISION_SIGN = '/';
        private const char EQUALITY_SIGN = '=';

        enum State { NOTHING, ADD, SUBTRACT, DIVIDE, MULTIPLY, EQUALS };


        public MojKalkulator()
        {
            currentDisplayState = "0";
            currentState = State.NOTHING;
            isError = false;
            registers = new double[2] { 0, 0 };
            memory = "";

            InitializeMapOfCommands();
        }

        private void InitializeMapOfCommands()
        {
            mapOfCommands.Add(State.ADD.ToString(), new AddCommand(this));
            mapOfCommands.Add(State.SUBTRACT.ToString(), new SubtractCommand(this));
            mapOfCommands.Add(State.DIVIDE.ToString(), new DivideCommand(this));
            mapOfCommands.Add(State.MULTIPLY.ToString(), new MultiplyCommand(this));
            mapOfCommands.Add("M", new MinusCommand(this));
            mapOfCommands.Add("O", new ResetCommand(this));
            mapOfCommands.Add("S", new SinusCommand(this));
            mapOfCommands.Add("K", new CosinusCommand(this));
            mapOfCommands.Add("T", new TangensCommand(this));
            mapOfCommands.Add("R", new RootCommand(this));
            mapOfCommands.Add("Q", new QuadratCommand(this));
            mapOfCommands.Add("I", new InversCommand(this));
            mapOfCommands.Add("P", new PutCommand(this));
            mapOfCommands.Add("G", new GetCommand(this));
            mapOfCommands.Add("C", new ClearCommand(this));
        }

        State savedState = State.NOTHING;

        public void Press(char inPressedDigit)
        {

            if (numberOfDigits < maxNumberOfDigits)
            {

                if (Char.IsDigit(inPressedDigit))
                {
                    if (savedState != currentState )
                    {
                        savedState = currentState;
                        ResetCurrentDisplayState();
                    }

                    numberOfDigits++;
                    ChangeCurrentDisplayState(inPressedDigit.ToString());
                }
                else if (inPressedDigit.Equals(','))
                {
                    if (savedState != currentState)
                    {
                        savedState = currentState;
                        ResetCurrentDisplayState();
                    }

                    if (GetCurrentDisplayState().Equals("0"))
                    {
                        ChangeCurrentDisplayState("0,");
                    }
                    else
                    {
                        ChangeCurrentDisplayState(inPressedDigit.ToString());
                    }
                }

            }

            if (!Char.IsDigit(inPressedDigit) && !inPressedDigit.Equals(','))
            {

                ProcessPressedSymbol(inPressedDigit);
            }
        }



        char symbolPressedBefore = 'x';

        private void ProcessPressedSymbol(char inPressedSymbol)
        {
           
            if (!CheckIsBinaryOperator(inPressedSymbol) && inPressedSymbol != EQUALITY_SIGN)
            {
                Command command = GetCommandByKey(inPressedSymbol.ToString());
                command.ExecuteCommand();
            }
            else if (currentState == State.NOTHING )
            {
                ChangeCurrentState(inPressedSymbol);

                SetRegisterValue(0, ProperlyRoundValue(Double.Parse(currentDisplayState)));
                ResetCurrentDisplayState();
                ChangeCurrentDisplayState(GetRegisterValue(0).ToString());

            }
            else if (currentState == State.EQUALS)
            {
                ChangeCurrentState(inPressedSymbol);
                savedState = State.NOTHING;
            }
            else
            {
                if (numberOfDigits > 0 || inPressedSymbol == EQUALITY_SIGN || !CheckIsBinaryOperator(symbolPressedBefore))
                {

                    Command command = GetCommandByKey(currentState.ToString());
                    if (command != null)
                    {
                        command.ExecuteCommand();
                    }
                }
                ChangeCurrentState(inPressedSymbol);
                if (currentState == State.EQUALS)
                {
                    ProperlyRoundRegisterValue(0);
                    ResetCurrentDisplayState();
                    ChangeCurrentDisplayState(GetRegisterValue(0).ToString());

                }

            }
            symbolPressedBefore = inPressedSymbol;
        }

        private bool CheckIsBinaryOperator(char symbol)
        {
            if (symbol == PLUS || symbol == MINUS || symbol == DIVISION_SIGN || symbol == MULTIPLICATION_SIGN)
            {
                return true;
            }

            return false;
        }

        private void ProperlyRoundRegisterValue(int index)
        {
            double registerValue = GetRegisterValue(index);
            SetRegisterValue(index, ProperlyRoundValue(registerValue));

        }

        private double ProperlyRoundValue(double value)
        {

            if (value > 9999999999 || value < -9999999999)
            {
                isError = true;
            }
            else
            {
                string valueString = value.ToString();
                if (valueString.Contains(','))
                {
                    int indexOfComma = valueString.IndexOf(',');
                    if (valueString.Contains(MINUS)) indexOfComma -= 1;
                    value = Math.Round(value, maxNumberOfDigits - indexOfComma);
                }
            }
            return value;
        }

        private void ChangeCurrentState(char inPressedSymbol)
        {

            switch (inPressedSymbol)
            {
                case PLUS:
                    currentState = State.ADD;
                    break;
                case MINUS:
                    currentState = State.SUBTRACT;
                    break;
                case MULTIPLICATION_SIGN:
                    currentState = State.MULTIPLY;
                    break;
                case DIVISION_SIGN:
                    currentState = State.DIVIDE;
                    break;
                case EQUALITY_SIGN:
                    currentState = State.EQUALS;
                    break;
                default: break;
            }
        }

        public Command GetCommandByKey(string code)
        {
            Command command;
            if (mapOfCommands.TryGetValue(code, out command))
                return command;
            else
                return null;
        }

        public string GetCurrentDisplayState()
        {
            if (isError == true)
            {
                ResetAll();
                ChangeCurrentDisplayState("-E-");
            }
            return currentDisplayState;
        }

        private void ChangeCurrentDisplayState(string addedDisplayString)
        {
            if (!currentDisplayState.Equals("0"))
            {
                currentDisplayState += addedDisplayString;
            }
            else
            {
                currentDisplayState = addedDisplayString;
            }
        }

        private void ResetCurrentDisplayState()
        {
            currentDisplayState = "0";
            numberOfDigits = 0;
        }

        private void ResetAll()
        {
            currentState = State.NOTHING;
            savedState = State.NOTHING;
            isError = false;
            registers[0] = 0;
            registers[1] = 0;
            memory = "";
            ResetCurrentDisplayState();
        }


        private double GetRegisterValue(int index)
        {
            if (index > 1 || index < 0)
            {
                throw new IndexOutOfRangeException();
            }
            return registers[index];
        }


        private void SetRegisterValue(int index, double value)
        {
            if (index > 1 || index < 0)
            {
                throw new IndexOutOfRangeException();
            }
            registers[index] = value;
        }
    }
}
