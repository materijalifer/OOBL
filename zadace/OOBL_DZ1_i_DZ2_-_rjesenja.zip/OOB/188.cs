﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string Display_string = "0";
        private string Memory;
        private double Current_Result = 0;
        private char[] UnaryOperators = new char[] { 'Q', 'R', 'I', 'S', 'K', 'T', 'P', 'G', 'M' };
        private string my_operator = "";
        private bool OperatorPressed = false;
        private bool NeedClean = false;
        private string last_input = "";


        public Kalkulator()
        {
        }

        public void Press(char inPressedDigit)
        {

            if (Display_string == "-E-")
            {
                //Ak ose dogodila greška u izračunu, resetiraj stanje u kalkulatoru

                Reset();
            }
            
            if (inPressedDigit == 'C')
            {
                //Clean desktop
                Clear();
            }
            else if (inPressedDigit == 'O')
            {
                //Reset
                Reset();
            }
            else if ((inPressedDigit >= '0' && inPressedDigit <= '9') || inPressedDigit == ',')
            {
                //Typing a number

                if (NeedClean)
                {
                    //Ako je prethodno utipkan binarni operator, sad se unosi noi broj pa treba očistiti ekran
                    
                    Display_string = "0";
                    NeedClean = false;
                }
                
                if (Display_string == "0" && inPressedDigit == '0')
                {
                    //Tipkanje više 0
                    
                    Display_string = "0";
                }
                else
                {
                    
                    if (Display_string == "0")
                    {
                        //početak unosa novog broja

                        Display_string = "";
                        Display_string += inPressedDigit;
                    }
                    else
                    {
                        //Tipkanje broja

                        Display_string += inPressedDigit;
                    }
                }
                
            }
            else if (CheckUnar(inPressedDigit))
            {
                UnaryOperator(inPressedDigit);
            }
            else
            {
                BinaryOperator(inPressedDigit);
            }

            //pamćenje zadnjeg unesenog znaka -> za provjeru duplih operatora
            last_input = "" + inPressedDigit;

            CheckDisplay();
        }

        public string GetCurrentDisplayState()
        {
            return Display_string;
        }

        private bool CheckUnar(char my_operator)
        {

            //Metoda koja provjerava je li uneseni znak unarni operator

            bool nasao = false;
            int i;

            for (i = 0; i < UnaryOperators.Length; i++)
            {
                if (my_operator == UnaryOperators[i])
                {
                    nasao = true;
                    break;
                }
            }


            return nasao;
        }

        private bool CheckBinary(char my_operator)
        {
            //Metoda koja provjerava je li uneseni znak binarni operator

            if (my_operator == '+' || my_operator == '-' || my_operator == '*' || my_operator == '/')
            {
                return true;
            }

            return false;
        }

        private void UnaryOperator(char button)
        {
            //izvođenje operacija unarnog operatora

            switch (button)
            {
                case 'Q': Display_string = Square();
                    break;
                case 'R': Display_string = Root();
                    break;
                case 'S': Display_string = Sinus();
                    break;
                case 'K': Display_string = Cosine();
                    break;
                case 'T': Display_string = Tangens();
                    break;
                case 'I': Display_string = Invers();
                    break;
                case 'P': Put();
                    break;
                case 'M': ChangeSign();
                    break;
                case 'G': Get();
                    break;
            }
        }

        private string Square()
        {
            double result = double.Parse(Display_string) * double.Parse(Display_string);

            return result.ToString();
        }

        private string Root()
        {
            if (Display_string[0] == '-')
            {
                Display_string = "-E-";
                return "-E-";
            }

            double result = Math.Round(Math.Sqrt(double.Parse(Display_string)),9);

            return result.ToString();
        }

        private string Sinus()
        {
            double result = Math.Round(Math.Sin(double.Parse(Display_string)),9);

            return result.ToString();
        }

        private string Cosine()
        {
            double result = Math.Round(Math.Cos(double.Parse(Display_string)),9);

            return result.ToString();
        }

        private string Tangens()
        {
            double result = Math.Round(Math.Tan(double.Parse(Display_string)),9);

            return result.ToString();
        }

        private string Invers()
        {
            if (double.Parse(Display_string) == 0)
            {
                return "-E-";
            }
            else
            {
                double result = Math.Round(1 / double.Parse(Display_string),9);

                return result.ToString();
            }

        }

        private void Put()
        {
            Memory = Display_string;
        }

        private void Get()
        {
            Display_string = Memory;
        }

        private void Add(string element)
        {
            Current_Result += double.Parse(element);
        }

        private void Substract(string element)
        {
            Current_Result -= double.Parse(element);
        }

        private void Multiply(string element)
        {
            Current_Result *= double.Parse(element);
        }

        private void Division(string element)
        {
            if (double.Parse(element) == 0)
            {
                Display_string = "-E-";
                return;
            }
            else
            {
                Current_Result /= double.Parse(element);
            }
        }

        private void BinaryOperator(char button)
        {
            NeedClean = true; //Nakon ovog će se unositi novi broj

            if (CheckBinary(last_input[0]))
            {
                //Ako je unesen dvostruki binarni operator ili '='

                if (button == '=')
                {
                    switch (last_input[0])
                    {
                        case '+': Add(Display_string);
                            break;
                        case '-': Substract(Display_string);
                            break;
                        case '*': Multiply(Display_string);
                            break;
                        case '/': Division(Display_string);
                            break;
                    }

                    Display_string = Current_Result.ToString();
                }
                else
                {
                    my_operator = "" + button;
                }
            }
            else if (my_operator == "")
            {
                //kalkulator je tek uključen, tek je unesen prvi broj
                //ne obavlja se nikakva operacije, samo se pamti slijedeća operacija

                Current_Result += double.Parse(Display_string);
                OperatorPressed = true;
                my_operator = "" + button;

            }
            else
            {
                //Obavljanje binarnih operacija

                switch (my_operator)
                {
                    case "+": Add(Display_string);
                        break;
                    case "-": Substract(Display_string);
                        break;
                    case "*": Multiply(Display_string);
                        break;
                    case "/": Division(Display_string);
                        break;
                }

                Display_string = Current_Result.ToString(); //Spremanje rezultat an adisplay
                my_operator = "" + button; //pamćenje novog operatora
            }
        }

        private void ChangeSign()
        {
            if (Display_string[0] != '-')
            {
                Display_string = "-" + Display_string;
            }
            else
            {
                Display_string = Display_string.Remove(0, 1);
            }
        }

        private void Reset()
        {
            Display_string = "0";
            Current_Result = 0;
            Memory = "0";
        }

        private void Clear()
        {
            Display_string = "0";
        }

        private void CheckDisplay()
        {
            //Metoda koja sređuje ispravnost prikaza

            if (Display_string[0] == ',')
            {
                //Decimalni broj bez početne 0

                Display_string = "0" + Display_string;
            }

            //rezanje više 0 u jednu dodati

            if (Display_string.Contains(','))
            {
                //Cijeli broj zapisan u decimalnom obliku

                string[] temp = Display_string.Split(',');
                
                if (temp[1] == "0")
                {
                    Display_string = temp[0];
                }
            }

            //dužina veća od 10 znamenaka
            if (Display_string.Length > 10)
            {
                if (Display_string.Contains(','))
                {
                    string NoDigits = Math.Round(Math.Abs(double.Parse(Display_string))).ToString();
                    int number = NoDigits.Length;

                    Display_string = Math.Round(double.Parse(Display_string), 10-number).ToString();
                }

                if (!Display_string.Contains(',') && !Display_string.Contains('-'))
                {
                    Display_string = "-E-";
                }
            }
        }

    }


}



