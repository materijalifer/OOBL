﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        #region Private fields
        /// <summary>
        /// Maksimalni broj znakova na displayu
        /// </summary>
        private const int DMAX = 10;

        /// <summary>
        /// Provjera da li je prijašnja tipka bila binarni operator
        /// Potrebno za osiguravanje da se prilikom stiskanja različitih bin. op. samo operator mijenja
        /// </summary>
        private bool previousKeyWasBinOp;
        
        /// <summary>
        /// Hack kako bi obrada displaya bila točno po specifikaciji zadatka kod bin. operacija
        /// - inače bi uvedena default operacija identiteta izvršila zaokruživanje
        /// </summary>
        private bool isNeededOldDataIdentityRoundingHack;

        /// <summary>
        /// Sadržaj ekrana kalkulatora
        /// </summary>
        private char[] display;

        /// <summary>
        /// Pozicija decimalnog zareza - -1 znači da radimo sa cijelim br., 0 znači da je stisnuta tipka ali još nisu uneseni br., 1 znači jedno mjesto na desno itd.
        /// </summary>
        private int decCommaPosition;

        /// <summary>
        /// Da li je trenutni sadržaj ekrana pozitivan
        /// </summary>
        private bool isPositive;

        /// <summary>
        /// Da li je u error načinu rada
        /// </summary>
        private bool isErrored;

        /// <summary>
        /// Broj koji je unesen prije unošenja binarnog operatora
        /// </summary>
        private double oldNumber;

        /// <summary>
        /// Trenutna binarna operacija u tijeku
        /// </summary>
        private char currBinOp;

        /// <summary>
        /// Memorija - može prihvatiti samo jedan broj
        /// </summary>
        private double memory;

        /// <summary>
        /// Da li trenutno korisnik unosi brojeve
        /// </summary>
        private bool userEntryInProgress;
        #endregion

        #region Delegate and dictionary definitions 
        /// <summary>
        /// Delegat za metode binarnih operatora
        /// </summary>
        /// <param name="a">Prvi (lijevi) broj u binarnoj operaciji u infix notaciji</param>
        /// <param name="b">Drugi (desni) broj u binarnoj operaciji u infix notaciji</param>
        /// <returns></returns>
        private delegate double binaryOperation(double a, double b);

        /// <summary>
        /// Delegat za metode unarnih operatora
        /// <param name="a">Broj nad kojim se provodi op.</param>
        /// </summary>
        private delegate double UnaryOperation(double a);

        /// <summary>
        /// Riječnik sa pripadnim operacijama za binarne operatore. 
        /// Ključ - char operatora, Vrijednost - metoda koja izvršava operaciju
        /// </summary>
        private Dictionary<char, binaryOperation> executeBinOp;

        /// <summary>
        /// Riječnik sa pripadnim operacijama za unarne operatore. 
        /// Ključ - char operatora, Vrijednost - metoda koja izvršava operaciju
        /// </summary>
        private Dictionary<char, UnaryOperation> executeUnOp;


        /// <summary>
        /// Delegat za metode koje obrađuju što se treba dogoditi prilikom pritiska pojedine tipke
        /// </summary>
        /// <param name="key">Pritisnuta tipka</param>
        private delegate void specificKeyPressedHandler(char key);

        /// <summary>
        /// Riječnik sa pripadnim metodama za obradu pojedine tipke
        /// Ključ - char tipke, Vrijednost - metoda koja obrađuje tu tipku
        /// </summary>
        private Dictionary<char, specificKeyPressedHandler> keyDirectory;
        #endregion

        #region Key-handler methods
        
        /// <summary>
        /// Handler za 0 - moraju se raditi dodatne provjere
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void key0(char key)
        {
            if (userEntryInProgress)
            {
                if (getCurrentDisplayedRealNum() != 0)
                {
                    displayAddKey('0');
                }
            }
            else
            {
                clearCalc();
                userEntryInProgress = true;
            }
            previousKeyWasBinOp = false;

        }

        /// <summary>
        /// Handler za znamenke osim 0
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta</param>
        private void keyNum(char key)
        {
            if (userEntryInProgress)
            {
                if (getCurrentDisplayedRealNum() != 0)
                {
                    displayAddKey(key);
                }
                else
                {
                    if (decCommaPosition < 0) displayReplace(key.ToString());
                    else displayAddKey(key);
                }
            }
            else
            {
                clearCalc();
                userEntryInProgress = true;
                displayReplace(key.ToString());
            }
            previousKeyWasBinOp = false;
        }

        /// <summary>
        /// Handler za decimalni zarez
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyComma(char key)
        {
            if (userEntryInProgress)
            {
                if (decCommaPosition < 0)
                {
                    decCommaPosition = 0;
                }
            }
            else
            {
                clearCalc();
                userEntryInProgress = true;
                decCommaPosition = 0;
            }
            previousKeyWasBinOp = false;
        }

        /// <summary>
        /// Handler za +/-
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyM(char key)
        {
            if (getCurrentDisplayedRealNum() != 0) isPositive = !isPositive;
            else isPositive = true;
            //ne utječe na trenutno stanje da li je prijašnja tipka bila bin. op.
        }

        /// <summary>
        /// Handler za unarne operacije
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta</param>
        private void keyUnary(char key)
        {
            try
            {
                //direktno se izvršava ona operacija za koju je tipka stisnuta
                double result = executeUnOp[key](getCurrentDisplayedRealNum());
                showRealOnDisplay(result);
                userEntryInProgress = false;
                previousKeyWasBinOp = false;
            }
            catch
            {
                //ukoliko dođe do greške prilikom izračuna (npr. 1/0) prelazi se u stanje greške
                isErrored = true;
            }
        }

        /// <summary>
        /// Handler za binarne operacije
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta</param>
        private void keyBinary(char key)
        {
            // Ako je prijašnja tipka bila bin. op. samo zamijeni operator
            if (previousKeyWasBinOp) currBinOp = key;
            else
            {
                try
                {
                    //direktno se izvršava poslijednja binarna operacija; ukoliko niti jedna nije ukucana 
                    //provodi se operacija identiteta tj. vraća se broj na ekranu
                    double result = executeBinOp[currBinOp](oldNumber, getCurrentDisplayedRealNum());
                    oldNumber = result;
                    currBinOp = key;
                    userEntryInProgress = false;
                    
                    //kako bi se vjerno implementirala specifikacija, ukoliko je stisnuti operator sa brojem tipa 5,0000 na ekranu,
                    //broj na ekranu se neće promijeniti - identitet bi inače taj broj prebrisao sa zaokruženim
                    if (isNeededOldDataIdentityRoundingHack)
                    {
                        isNeededOldDataIdentityRoundingHack = false;
                    }
                    else
                    {
                        showRealOnDisplay(result);
                    }
                    previousKeyWasBinOp = true;
                }
                catch
                {
                    //ukoliko dođe do greške prilikom izračuna (npr. X/0) prelazi se u stanje greške
                    isErrored = true;
                }
            }
        }

        /// <summary>
        /// Handler za jednakost
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyEquals(char key)
        {
            try
            {
                //direktno se izvršava poslijednja binarna operacija; ukoliko niti jedna nije ukucana 
                //provodi se operacija identiteta tj. vraća se broj na ekranu
                double result = executeBinOp[currBinOp](oldNumber, getCurrentDisplayedRealNum());
                userEntryInProgress = false;

                //housekeeping za slučaj da je identitet zadnja binarna operacija
                if (isNeededOldDataIdentityRoundingHack)
                {
                    isNeededOldDataIdentityRoundingHack = false;
                }
                showRealOnDisplay(result);
                previousKeyWasBinOp = false;
            }
            catch
            {
                //ukoliko dođe do greške prilikom izračuna (npr. X/0) prelazi se u stanje greške
                isErrored = true;
            }
        }

        /// <summary>
        /// Čiščenje trenutnog stanja ekrana
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyClear(char key)
        {
            clearCalc();
            previousKeyWasBinOp = false;
        }

        /// <summary>
        /// Gašenje i paljenje kalkulatora - provodi puni reset
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyOnOff(char key)
        {
            resetCalc();
            isErrored = false;
            previousKeyWasBinOp = false;
        }

        /// <summary>
        /// Handler za tipku spremanja u memoriju
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyStoreMem(char key)
        {
            memory = getCurrentDisplayedRealNum();
            previousKeyWasBinOp = false;
        }

        /// <summary>
        /// Handler za tipku dohvata iz memorije
        /// </summary>
        /// <param name="key">Tipka koja je stisnuta - ignorira se</param>
        private void keyGetMem(char key)
        {
            showRealOnDisplay(memory);
            userEntryInProgress = false;
            previousKeyWasBinOp = false;
        }
        #endregion
        
        #region Display handling
        /// <summary>
        /// Pretvara realni broj u stanje ekrana kalkulatora
        /// </summary>
        /// <param name="result">Realni broj za prikazati na kalkulatoru</param>
        private void showRealOnDisplay(double result)
        {
            decCommaPosition = -1;

            if (result < 0)
            {
                isPositive = false;
                result = result * -1;
            }

            long intpart = (long)Math.Floor(result);

            if (((double)intpart) == result)
            {
                displayReplace(intpart.ToString());
            }
            else
            {
                if (intpart.ToString().Count() <= DMAX)
                {
                    string displayPrep = intpart.ToString();
                    string fractionalPart = Math.Round((result - intpart), DMAX - displayPrep.Count(), MidpointRounding.AwayFromZero).ToString();
                    fractionalPart = fractionalPart.Substring(2).TrimEnd('0');
                    decCommaPosition = fractionalPart.Count();
                    displayPrep += fractionalPart;
                    displayReplace(displayPrep);
                }
                else
                {
                    //Ukoliko je broj predugačak, odlazi se u stanje greške
                    isErrored = true;
                }
            }
        }

        /// <summary>
        /// Dodaj broj na ekran
        /// Ukoliko je ekran pun neće se ništa dogoditi
        /// </summary>
        /// <param name="key">Broj za dodati</param>
        private void displayAddKey(char key)
        {
            if ((!isErrored) && (display[DMAX - 1] == '-'))
            {
                for (int i = DMAX - 1; i > 0; i--)
                {
                    display[i] = display[i - 1];
                }
                display[0] = key;

                if (decCommaPosition >= 0)
                {
                    decCommaPosition++;
                }
            }
        }

        /// <summary>
        /// Zamijeni trenutno stanje ekrana sa novime
        /// </summary>
        /// <param name="data">Podaci za prikazati</param>
        private void displayReplace(string data)
        {
            if (data.Count() <= DMAX)
            {
                for (int i = 0; i < data.Count(); i++)
                {
                    display[i] = data[data.Count() - (i + 1)];
                }
                if (data.Count() < DMAX)
                {
                    for (int i = data.Count(); i < DMAX; i++)
                    {
                        display[i] = '-';
                    }
                }
            }
            else
            {
                //Ukoliko je string predugačak, odlazi se u stanje greške
                isErrored = true;
            }
        }

        /// <summary>
        /// Očisti trenutno stanje ekrana kalkulatora
        /// </summary>
        private void clearCalc()
        {
            displayReplace("0");
            decCommaPosition = -1;
            isPositive = true;
            userEntryInProgress = false;
        }
        #endregion

        #region Init and reset
        /// <summary>
        /// Kalkulator koji je vrlo moćan
        /// </summary>
        public Kalkulator()
        {
            display = new char[DMAX];
            isErrored = false;
            resetCalc();
            initKeyDirectories();
        }

        /// <summary>
        /// Inicijalizacija riječnika za obradu tipki odnosno operacija
        /// </summary>
        private void initKeyDirectories()
        {
            keyDirectory = new Dictionary<char, specificKeyPressedHandler>();
            keyDirectory.Add('0', key0);
            for (int i = 1; i < 10; i++) keyDirectory.Add(char.Parse(i.ToString()), keyNum);
            keyDirectory.Add(',', keyComma);
            keyDirectory.Add('M', keyM);
            keyDirectory.Add(' ', keyBinary);
            keyDirectory.Add('+', keyBinary);
            keyDirectory.Add('-', keyBinary);
            keyDirectory.Add('*', keyBinary);
            keyDirectory.Add('/', keyBinary);
            keyDirectory.Add('S', keyUnary);
            keyDirectory.Add('K', keyUnary);
            keyDirectory.Add('T', keyUnary);
            keyDirectory.Add('Q', keyUnary);
            keyDirectory.Add('R', keyUnary);
            keyDirectory.Add('I', keyUnary);
            keyDirectory.Add('=', keyEquals);
            keyDirectory.Add('C', keyClear);
            keyDirectory.Add('O', keyOnOff);
            keyDirectory.Add('P', keyStoreMem);
            keyDirectory.Add('G', keyGetMem);

            executeBinOp = new Dictionary<char, binaryOperation>();
            executeBinOp.Add('+', delegate(double a, double b) { return a + b; });
            executeBinOp.Add('-', delegate(double a, double b) { return a - b; });
            executeBinOp.Add('*', delegate(double a, double b) { return a * b; });
            executeBinOp.Add('/', delegate(double a, double b) { return a / b; });
            executeBinOp.Add(' ', delegate(double a, double b) { isNeededOldDataIdentityRoundingHack = true; return b; });

            executeUnOp = new Dictionary<char, UnaryOperation>();
            executeUnOp.Add('S', delegate(double a) { return Math.Sin(a); });
            executeUnOp.Add('K', delegate(double a) { return Math.Cos(a); });
            executeUnOp.Add('T', delegate(double a) { return Math.Tan(a); });
            executeUnOp.Add('Q', delegate(double a) { return a * a; });
            executeUnOp.Add('R', delegate(double a) { return Math.Sqrt(a); });
            executeUnOp.Add('I', delegate(double a) { return 1 / a; });
        }
        
        /// <summary>
        /// Resetiranje kalkulatora - sve se gubi!
        /// </summary>
        private void resetCalc()
        {
            clearCalc();
            oldNumber = 0;
            currBinOp = ' ';
            memory = 0;
            previousKeyWasBinOp = false;
            isNeededOldDataIdentityRoundingHack = false;
        }
        #endregion

        #region Interface implementation
        
        /// <summary>
        /// Obrada tipke koja je stisnuta
        /// </summary>
        /// <param name="inPressedDigit">Tipka</param>
        public void Press(char inPressedDigit)
        {
            //Ako je došlo do greške u prijašnjim operacijama ne dopusti nove obrade prije reseta
            if (!isErrored)
            {
                //Ako je stigla kao tipka nešto čega nema na kalk. pređi u stanje greške
                try
                {
                    //Putem riječnika odnosno delegata u riječniku direktno se pristupa metodi za obradu pojedine tipke
                    keyDirectory[inPressedDigit](inPressedDigit);
                }
                catch
                {
                    isErrored = true;
                }
            }
            else
            {
                // Jedino nas O - resetiranje kalkulatora - može spasiti od greške
                if (inPressedDigit == 'O')
                {
                    keyDirectory[inPressedDigit](inPressedDigit);
                }
            }
        }

        /// <summary>
        /// Dohvati trenutno stanje ekrana u tekstualnom obliku
        /// </summary>
        /// <returns>Stanje ekrana u string formatu</returns>
        public string GetCurrentDisplayState()
        {
            if (isErrored) return "-E-";

            string output = "";
            if (!isPositive) output += "-";
            for (int i = DMAX - 1; i >= 0; i--)
            {
                if (display[i] != '-') output += display[i].ToString();
                if ((decCommaPosition == i) && (i != 0)) output += ",";
            }
            return output;
        }
        #endregion

        #region Utility methods
        /// <summary>
        /// Dohvati trenutno stanje ekrana u brojčanom obliku
        /// </summary>
        /// <returns>Stanje ekrana u double formatu</returns>
        private double getCurrentDisplayedRealNum()
        {
            return double.Parse(GetCurrentDisplayState(), new CultureInfo("hr-HR").NumberFormat);
        }
        #endregion
    }


}
