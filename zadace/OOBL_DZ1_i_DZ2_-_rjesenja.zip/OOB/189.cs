﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string rightOperand = String.Empty;

        const string errorSign = "-E-";

        const int maxNumLenght = 10;

        string display = "0";

        const string decimalSeperator = ",";

        string memory = "0";

        BinaryOperator binaryOperator = null;

        bool resetDisplay = false;

        bool firstOperandInputed = false;

        bool secondOperandInputed = false;

        bool errorState = false;

        bool userInputedNumber = false;

        public void Press(char inPressedDigit)
        {
            if (CalculatorCharacterChecker.IsOnOff(inPressedDigit)) {
                onOffCommand();
                return;
            }
            else if (CalculatorCharacterChecker.IsClearDisplay(inPressedDigit))
            {
                clearDisplay();
            }

            if (errorState)
                return;

            if (CalculatorCharacterChecker.IsDigit(inPressedDigit)) {
                addNumber(inPressedDigit);
            }
            else if (CalculatorCharacterChecker.IsDecimalSeparator(inPressedDigit)) {
                addDecimalSeparator();
            }
            else if (CalculatorCharacterChecker.IsMinusNumberSign(inPressedDigit)) {
                addMinusSign();
            }
            else if (CalculatorCharacterChecker.IsSave(inPressedDigit)) {
                saveToMemory();
            }
            else if (CalculatorCharacterChecker.IsLoad(inPressedDigit)) {
                loadFromMemory();
            }
            else if (CalculatorCharacterChecker.IsBinaryOperator(inPressedDigit)) {
                binaryOperatorInput(inPressedDigit);
            }
            else if (CalculatorCharacterChecker.IsEquals(inPressedDigit)) {
                equalsSign();
            }
            else if (CalculatorCharacterChecker.IsUnaryOperator(inPressedDigit)) {
                unaryOperator(inPressedDigit);
            }

        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        void onOffCommand() {
            display = "0";
            memory = "0";
            firstOperandInputed = false;
            secondOperandInputed = false;
            resetDisplay = false;
            binaryOperator = null;
            errorState = false;
        }

        void formatDisplay() {
            
            int startIndex = display.IndexOf(",");

            if (startIndex == -1)
                return;

            for (int i = startIndex+1; i < display.Length; i++) {
                if (display[i] != '0')
                    return;
            }

            display = display.Remove(startIndex);
            
        }

        void equalsSign() {
            resetDisplay = true;

            if (binaryOperator == null)
            {
                validateDisplay();
                formatDisplay();
            }
            else
            {
                try
                {
                    if (userInputedNumber && !firstOperandInputed)
                    {
                        binaryOperator.LeftOperand = display;

                        userInputedNumber = false;
                    }
                    else if (secondOperandInputed)
                        binaryOperator.RightOperand = rightOperand;
                    display = binaryOperator.Execute();
                    validateDisplay();
                    formatDisplay();
                    binaryOperator.LeftOperand = display;
                    firstOperandInputed = false;
                    secondOperandInputed = false;
                }
                catch
                {
                    display = errorSign;
                    errorState = true;
                }
            }
        }

        void validateDisplay() {
            if (display.Contains(","))
            {
                if (display.IndexOf(",") < 11)
                {
                    int round = 0;
                    if(display.StartsWith("-"))
                        round = 11 - display.IndexOf(",");
                    else
                        round = 10 - display.IndexOf(",");
                    double num = Convert.ToDouble(display);
                    num = Math.Round(num, round);
                    display = num.ToString("F10");
                    while (display[display.Length - 1] == '0')
                        display = display.Remove(display.Length-1);
                }
                else
                {
                    throw new Exception();
                }
            }
            else { 
                if(display.GetNumberCount()>10)
                    throw new Exception();
            }

        }

        void unaryOperator(char c) {

            resetDisplay = true;
            UnaryOperator unaryOperator = UnaryOperatorFactory.GetUnaryOperator(c);
            unaryOperator.Operand = display;


            try
            {
                display = unaryOperator.Execute();
                validateDisplay();
                formatDisplay();
                if (firstOperandInputed)
                    rightOperand = display;
            }
            catch {
                display = errorSign;
                errorState = true;
            }
        }

        void binaryOperatorInput(char c){

            userInputedNumber = false;

            if (secondOperandInputed)
                equalsSign();
            
            firstOperandInputed = true;
            secondOperandInputed = false;

            binaryOperator = BinaryOperatorFactory.getBinaryOperator(c);
            binaryOperator.LeftOperand = display;
            binaryOperator.RightOperand = display;
            resetDisplay = true;
            formatDisplay();
        }

        void saveToMemory() {
            memory = display.RemoveEnding(decimalSeperator);
        }

        void loadFromMemory() {
            resetDisplay = true;
            display = memory;
        }

        void clearDisplay() {
            display = "0";
            errorState = false;
            rightOperand = display;
            if (!firstOperandInputed && binaryOperator != null)
                binaryOperator.LeftOperand = display;
           
        }

        void addMinusSign() {
            userInputedNumber = true;
            
            if (firstOperandInputed)
                secondOperandInputed = true;

            if (display.StartsWith("-"))
            {
                display = display.Remove(0, 1);
                return;
            }
            for (int i = 0; i < display.Length; i++ )
                if (display[i] != '0' && display[i] != ',')
                {
                    display = "-" + display;
                    rightOperand = display;
                    return;
                }
        }

        void addNumber(char c) {

            userInputedNumber = true;

            if (firstOperandInputed)
                secondOperandInputed = true;

            string character = c.ToString();

            if (display == "0"||resetDisplay)
            {
                display = character;
                resetDisplay = false;
            }
            else if (display.GetNumberCount() == maxNumLenght) {
                return;
            }
            else
                display += character;
            rightOperand = display;
        }

        void addDecimalSeparator() {

            if (display.Contains(decimalSeperator))
                return;
            if (resetDisplay)
            {
                resetDisplay = false;
                display = "0";
            }
            display += decimalSeperator;
        }
    }

    public static class StringHelpers {
        public static int GetNumberCount(this string s) { 
            int counter = 0;
            foreach (char c in s) {
                if (CalculatorCharacterChecker.IsDigit(c))
                    counter++;
            }
            return counter;
        }

        public static string RemoveEnding(this string s, string endString) { 
            String returnString = s;
            if (s.EndsWith(endString))
                returnString = returnString.Remove(s.Length-endString.Length);
            return returnString;
        }
    }

    public static class CalculatorCharacterChecker {

        public static bool IsDigit(char c) {
            return char.IsDigit(c);
        }

        public static bool IsDecimalSeparator(char c) {
            return c == ',';
        }

        public static bool IsMinusNumberSign(char c) {
            return c == 'M';
        }

        public static bool IsClearDisplay(char c) { 
            return c=='C';
        }

        public static bool IsSave(char c) {
            return c=='P';
        }

        public static bool IsLoad(char c) { 
            return c=='G';
        }

        public static bool IsBinaryOperator(char c) {
            if (c == '+' || c == '-' || c == '*' || c == '/')
                return true;
            return false;
        }

        public static bool IsUnaryOperator(char c) {
            if (c == 'S' || c == 'K' || c == 'T' || c == 'Q' || c == 'R' || c == 'I')
                return true;
            return false;
        }

        public static bool IsPlusOperator(char c) {
            return c == '+';
        }

        public static bool IsMinusOperator(char c) { 
            return c == '-';
        }

        public static bool IsMultiplicationOperator(char c) { 
            return c == '*';
        }

        public static bool IsDivisionOperator(char c) { 
            return c =='/';
        }

        public static bool IsEquals(char c) { 
            return c == '=';
        }

        public static bool IsSinusOperator(char c) { 
            return c =='S';
        }

        public static bool IsCosinusOperator(char c) {
            return c == 'K';
        }

        public static bool IsTangensOperator(char c) { 
            return c =='T';
        }

        public static bool IsSquareOperator(char c) { 
            return c=='Q';
        }

        public static bool IsSquareRootOperator(char c) {
            return c == 'R';
        }

        public static bool IsInverseOperator(char c) {
            return c == 'I';
        }

        public static bool IsOnOff(char c) {
            return c == 'O';
        }
    }


    public abstract class BinaryOperator {

        protected string leftOperand;

        public string LeftOperand
        {
            get { return leftOperand; }
            set { leftOperand = value; }
        }

        protected string rightOperand;

        public string RightOperand
        {
            get { return rightOperand; }
            set { rightOperand = value; }
        }
        
        abstract public string Execute();
        
    }

    public class AddOperator : BinaryOperator {
        public override String Execute() {
            double leftOperand = Convert.ToDouble(this.leftOperand);
            double rightOperand = Convert.ToDouble(this.rightOperand);
            double result = leftOperand + rightOperand;
            return result.ToString("F10");
        }
    }

    public class SubstractionOperator : BinaryOperator {
        public override string Execute()
        {
            double leftOperand = Convert.ToDouble(this.leftOperand);
            double rightOperand = Convert.ToDouble(this.rightOperand);
            double result = leftOperand - rightOperand;
            return result.ToString("F10");
        }
    }

    public class MultiplicationOperator : BinaryOperator {
        public override string Execute()
        {
            double leftOperand = Convert.ToDouble(this.leftOperand);
            double rightOperand = Convert.ToDouble(this.rightOperand);
            double result = leftOperand * rightOperand;

            return result.ToString("F10");
        }
    }

    public class DivisionOperator : BinaryOperator {
        public override string Execute()
        {
            double leftOperand = Convert.ToDouble(this.leftOperand);
            double rightOperand = Convert.ToDouble(this.rightOperand);
            double result = leftOperand / rightOperand;
            if (double.IsInfinity(result) || double.IsNaN(result))
                throw new Exception();
            return result.ToString("F10");
        }
    }

    public static class BinaryOperatorFactory {
        public static BinaryOperator getBinaryOperator(char c) {
            if (CalculatorCharacterChecker.IsPlusOperator(c))
                return new AddOperator();
            else if (CalculatorCharacterChecker.IsMinusOperator(c))
                return new SubstractionOperator();
            else if (CalculatorCharacterChecker.IsMultiplicationOperator(c))
                return new MultiplicationOperator();
            else if (CalculatorCharacterChecker.IsDivisionOperator(c))
                return new DivisionOperator();
            else
                return null;
        }
    }

    public abstract class UnaryOperator {
        protected string operand;

        public string Operand
        {
            get { return operand; }
            set { operand = value; }
        }


        abstract public string Execute();
    }

    public class SinusOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = Math.Sin(op);
            return result.ToString("F10");
        }
    }

    public class CosinusOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = Math.Cos(op);
            return result.ToString("F10");
        }
    }

    public class TangensOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = Math.Tan(op);
            return result.ToString("F10");
        }
    }

    public class SquareOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = Math.Pow(op, 2);
            return result.ToString("F10");
        }
    }

    public class SquareRootOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = Math.Sqrt(op);
            if (double.IsInfinity(result) || double.IsNaN(result))
                throw new Exception();
            var t = result.ToString("F10");
            return result.ToString("F10");
        }
    }

    public class InversionOperator : UnaryOperator {
        public override string Execute()
        {
            double op = Convert.ToDouble(operand);
            double result = 1/op;
            if (double.IsInfinity(result) || double.IsNaN(result))
                throw new Exception();
            return result.ToString("F10");
        }
    }

    public static class UnaryOperatorFactory {
        public static UnaryOperator GetUnaryOperator(char c) {
            if (CalculatorCharacterChecker.IsSinusOperator(c))
                return new SinusOperator();
            else if (CalculatorCharacterChecker.IsCosinusOperator(c))
                return new CosinusOperator();
            else if (CalculatorCharacterChecker.IsTangensOperator(c))
                return new TangensOperator();
            else if (CalculatorCharacterChecker.IsSquareOperator(c))
                return new SquareOperator();
            else if (CalculatorCharacterChecker.IsSquareRootOperator(c))
                return new SquareRootOperator();
            else if (CalculatorCharacterChecker.IsInverseOperator(c))
                return new InversionOperator();
            else
                return null;
        }
    }

}
