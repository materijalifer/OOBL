﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        private delegate void binaryOperator(bool hasTwoOperands);
        private delegate void unaryOperator();
        private delegate void otherOperator();

        private string Memory = "0";

        private string DisplayContent = "0";
        private string previousDisplayContent = "0";
        private decimal firstValue = decimal.MinValue;
        private char prevOperator = '\0';
        private char newOperator = '\0';
        private Dictionary<char, binaryOperator> binaryOperators;
        private Dictionary<char, unaryOperator> unaryOperators;
        private Dictionary<char, otherOperator> othersOperators;
        private bool isEnteredNumber = false;
        private bool simpleUnaryOperation = false;



        public Kalkulator()
        {
            DisplayContent = "0";
            previousDisplayContent = "0";
            prevOperator = '0';
            newOperator = '0';
            Memory = "0";
            isEnteredNumber = false;
            firstValue = decimal.MinValue;
            simpleUnaryOperation = false;
            binaryOperators = new Dictionary<char, binaryOperator>();
            unaryOperators = new Dictionary<char, unaryOperator>();
            othersOperators = new Dictionary<char, otherOperator>();

            binaryOperators.Add('+', plusOperator);
            binaryOperators.Add('-', minusOperator);
            binaryOperators.Add('*', mulOperator);
            binaryOperators.Add('/', divOperator);
            othersOperators.Add('=', equalOperator);
            othersOperators.Add(',', comaOperator);
            unaryOperators.Add('M', signedOperator);
            unaryOperators.Add('S', sinusOperator);
            unaryOperators.Add('K', cosinusOperator);
            unaryOperators.Add('T', tangensOperator);
            unaryOperators.Add('Q', quadOperator);
            unaryOperators.Add('R', rootOperator);
            unaryOperators.Add('I', inverOperator);
            othersOperators.Add('P', putOperator);
            othersOperators.Add('G', getOperator);
            othersOperators.Add('C', clearOperator);
            othersOperators.Add('O', powerOperator);




        }

        public void Press(char inPressedDigit)
        {
            Console.Out.WriteLine("Upisani znak je " + inPressedDigit + "   TRenutni operator ili operand je" + newOperator + "  Prošli operand je " + prevOperator + "  First Value je" + firstValue + " i stanje ekrana je " + DisplayContent);

            //Upisujemo znamenke dok broj ne prelazi zadane okvire
            if (Char.IsDigit(inPressedDigit))
            {
                if (!isEnteredNumber)
                {
                    DisplayContent = "0";
                }

               
                if (DisplayContent.Length < 10 && !DisplayContent.Contains(","))
                {
                    isEnteredNumber = true;
                    string tempStr = DisplayContent + inPressedDigit.ToString();
                    DisplayContent = decimal.Parse(tempStr).ToString();
                }
                else if (DisplayContent.Length < 11 && DisplayContent.Contains(","))
                {
                    isEnteredNumber = true;
                    string tempStr = DisplayContent + inPressedDigit.ToString();
                    DisplayContent = decimal.Parse(tempStr).ToString();
                }
            }



            else
            {
                if (DisplayContent.Contains(',') && inPressedDigit == ',')
                {
                    return;
                }
                prevOperator = newOperator;
                newOperator = inPressedDigit;

                if (binaryOperators.ContainsKey(newOperator) && binaryOperators.ContainsKey(prevOperator) && !isEnteredNumber)
                {
                    Console.Out.WriteLine("Preskacemo operande");
                    return;
                }

                //uneseni operator je unarni
                if (unaryOperators.ContainsKey(newOperator))
                {
                    if (newOperator != 'M' && isEnteredNumber)
                        simpleUnaryOperation = true;
                    unaryOperator temp = unaryOperators[newOperator];
                    temp();
                    newOperator = prevOperator;

                }
                //uneseni operator je binarni
                else if (binaryOperators.ContainsKey(newOperator))
                {

                    if (firstValue != decimal.MinValue)
                    {

                        binaryOperator temp = binaryOperators[prevOperator];
                        temp(true);
                    }
                    else if (firstValue == decimal.MinValue)
                    {
                        binaryOperator temp = binaryOperators[newOperator];
                        temp(false);
                    }
                    else { throw new NotSupportedException(); }

                    isEnteredNumber = false;
                    simpleUnaryOperation = false;



                }
                //uneseni operator je 'ostali'
                else
                {

                    otherOperator temp = othersOperators[newOperator];
                    temp();
                    newOperator = prevOperator;
                    simpleUnaryOperation = false;


                }

                if (!DisplayContent.Equals("-E-"))
                {
                    if (decimal.Parse(DisplayContent) > 9999999999 || decimal.Parse(DisplayContent) < -9999999999)
                    {
                        DisplayContent = "-E-";
                        previousDisplayContent = "0";
                        prevOperator = '0';
                        newOperator = '0';
                        isEnteredNumber = false;
                        firstValue = decimal.MinValue;
                    }
                }



            }
        }

        public string GetCurrentDisplayState()
        {
            return DisplayContent;
        }

        private void plusOperator(bool hasTwoOperands)
        {
            DisplayContent = (double.Parse(DisplayContent).ToString());

            if (hasTwoOperands)
            {
                decimal res = decimal.Parse(DisplayContent) + firstValue;
                res = Round(res);

                double temp = (double)res;
                DisplayContent = temp.ToString();
                firstValue = (decimal)temp;

            }
            else
            {
                firstValue = decimal.Parse(DisplayContent);
            }


        }

        private decimal Round(decimal res)
        {



            if (res >= 0)
            {
                if (res.ToString().Length > 11)
                {

                    if (res.ToString().StartsWith("-") && res.ToString().Contains(","))
                    {
                        int indexofcom = res.ToString().IndexOf(",");
                        int nuberofdig = 11 - indexofcom;
                        if (nuberofdig > -1)
                        {
                            res = Math.Round(decimal.Parse(res.ToString()), nuberofdig);
                        }
                    }
                    else if (res.ToString().Contains(","))
                    {
                        int indexofcom = res.ToString().IndexOf(",");
                        int nuberofdig = 10 - indexofcom;
                        if (nuberofdig > -1)
                        {
                            res = Math.Round(decimal.Parse(res.ToString()), nuberofdig);
                        }
                    }
                }

            }
            else
            {
                if (res.ToString().Length > 12)
                {

                    if (res.ToString().StartsWith("-") && res.ToString().Contains(","))
                    {
                        int indexofcom = res.ToString().IndexOf(",");
                        int nuberofdig = 11 - indexofcom;
                        if (nuberofdig > -1)
                        {
                            res = Math.Round(decimal.Parse(res.ToString()), nuberofdig);
                        }
                    }
                    else if (res.ToString().Contains(","))
                    {
                        int indexofcom = res.ToString().IndexOf(",");
                        int nuberofdig = 10 - indexofcom;
                        if (nuberofdig > -1)
                        {
                            res = Math.Round(decimal.Parse(res.ToString()), nuberofdig);
                    }}
                }
            }
            return (decimal)(double)res;
        }
        private void minusOperator(bool hasTwoOperands)
        {
            DisplayContent = (double.Parse(DisplayContent).ToString());

            if (hasTwoOperands)
            {
                decimal res = firstValue - decimal.Parse(DisplayContent);
                res = Round(res);

                double temp = (double)res;
                DisplayContent = temp.ToString();
                firstValue = (decimal)temp;

            }
            else
            {
                firstValue = decimal.Parse(DisplayContent);
            }
        }
        private void mulOperator(bool hasTwoOperands)
        {
            DisplayContent = (double.Parse(DisplayContent).ToString());

            if (hasTwoOperands)
            {
                decimal res = firstValue * decimal.Parse(DisplayContent);
                res = Round(res);

                double temp = (double)res;
                DisplayContent = temp.ToString();
                if (temp == (double)decimal.MaxValue)
                {
                    firstValue = decimal.MaxValue;
                }
                else
                    firstValue = (decimal)temp;

            }
            else
            {
                firstValue = decimal.Parse(DisplayContent);
            }
        }
        private void divOperator(bool hasTwoOperands)
        {
            DisplayContent = (double.Parse(DisplayContent).ToString());

            if (hasTwoOperands)
            {
                if (decimal.Parse(DisplayContent) == 0)
                {
                    resetError();
                }
                else
                {
                    decimal res = firstValue / decimal.Parse(DisplayContent);

                    res = Round(res);

                    double temp = (double)res;
                    DisplayContent = temp.ToString();
                    firstValue = (decimal)temp;
                }
            }
            else
            {
                firstValue = decimal.Parse(DisplayContent);
            }
        }
        private void equalOperator()
        {
            //slucaj +=
            if (binaryOperators.ContainsKey(prevOperator) && !isEnteredNumber && firstValue == decimal.Parse(DisplayContent))
            {
                DisplayContent = firstValue.ToString();
                binaryOperators[prevOperator](true);

            }
            //slucaj 2+Q+
            else if (binaryOperators.ContainsKey(prevOperator) && !isEnteredNumber && firstValue != decimal.Parse(DisplayContent))
            {

                binaryOperators[prevOperator](true);
            }
            else if (binaryOperators.ContainsKey(prevOperator) && isEnteredNumber)
            {
                binaryOperators[prevOperator](true);
            }
            else
            {
                decimal temp = Round(decimal.Parse(DisplayContent));
                DisplayContent = temp.ToString();
                firstValue = temp;
            }

            prevOperator = '0';
            newOperator = '0';
            isEnteredNumber = false;



        }
        private void comaOperator()
        {
           
            if (simpleUnaryOperation)
            {
                Console.Out.WriteLine("aaaaaa");
                DisplayContent = "0,";
                isEnteredNumber = true;
                simpleUnaryOperation = false;

            }
            else
            {
                DisplayContent += ",";
                isEnteredNumber = true;

            }



        }
        private void signedOperator()
        {

            if (DisplayContent.StartsWith("-"))
            {
                DisplayContent = DisplayContent.Substring(1);
            }
            else
            {
                DisplayContent = "-" + DisplayContent;
            }

            decimal temp = Round(decimal.Parse(DisplayContent));
            DisplayContent = temp.ToString();
            isEnteredNumber = true;

        }
        private void sinusOperator()
        {

            if (isEnteredNumber)
            {
                decimal temp = Round((decimal)Math.Sin(double.Parse(DisplayContent)));
                DisplayContent = temp.ToString();
                isEnteredNumber = true;
            }
            else
            {
                decimal temp = Round((decimal)Math.Sin(double.Parse(DisplayContent)));
                DisplayContent = temp.ToString();
                isEnteredNumber = false;
            }

        }
        private void cosinusOperator()
        {

            if (isEnteredNumber)
            {
                decimal temp = Round((decimal)Math.Cos(double.Parse(DisplayContent)));
                DisplayContent = temp.ToString();
                isEnteredNumber = true;
            }
            else
            {
                decimal temp = Round((decimal)Math.Cos(double.Parse(DisplayContent)));
                DisplayContent = temp.ToString();
                isEnteredNumber = false;
            }

        }
        private void tangensOperator()
        {


            if (isEnteredNumber)
            {
                try
                {
                    decimal temp = Round((decimal)Math.Tan(double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = true;
                }
                catch (Exception e)
                {
                    DisplayContent = "-E-";
                    isEnteredNumber = true;
                }
            }
            else
            {
                try
                {
                    decimal temp = Round((decimal)Math.Tan(double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = false;
                }
                catch (Exception e)
                {
                    DisplayContent = "-E-";
                    isEnteredNumber = false;
                }
            }

        }
        private void quadOperator()
        {
            //prikaži rezultat na ekranu
            if (isEnteredNumber)
            {
                decimal temp = Round(decimal.Parse(DisplayContent) * decimal.Parse(DisplayContent));
                DisplayContent = temp.ToString();


                isEnteredNumber = true;


            }
            else
            {
                decimal temp = Round(decimal.Parse(DisplayContent) * decimal.Parse(DisplayContent));
                DisplayContent = temp.ToString();
                isEnteredNumber = false;
            }


        }
        private void rootOperator()
        {

            //prikaži rezultat na ekranu
            if (isEnteredNumber)
            {
                try
                {
                    decimal temp = Round((decimal)Math.Sqrt(double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = true;
                }
                catch (Exception e)
                {
                    DisplayContent = "-E-";
                    isEnteredNumber = true;
                }
            }
            else
            {
                try
                {
                    decimal temp = Round((decimal)Math.Sqrt(double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = false;
                }
                catch (Exception e)
                {
                    DisplayContent = "-E-";
                    isEnteredNumber = false;
                }
            }

        }
        private void inverOperator()
        {
            if (DisplayContent.Equals("0"))
            {
                DisplayContent = "-E-";
                isEnteredNumber = false;
            }
            else
            {
                if (isEnteredNumber)
                {
                    decimal temp = Round((decimal)(1 / double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = true;
                }
                else
                {
                    decimal temp = Round((decimal)(1 / double.Parse(DisplayContent)));
                    DisplayContent = temp.ToString();
                    isEnteredNumber = false;
                }
            }

        }
        private void putOperator()
        {
            Memory = DisplayContent;
            isEnteredNumber = true;
        }
        private void getOperator()
        {
            DisplayContent = Memory;
            isEnteredNumber = false;

        }
        private void clearOperator()
        {
            DisplayContent = "0";
            isEnteredNumber = false;
        }
        private void powerOperator()
        {
            DisplayContent = "0";
            previousDisplayContent = "0";
            prevOperator = '0';
            newOperator = '0';
            Memory = "0";
            isEnteredNumber = false;
            firstValue = decimal.MinValue;
            simpleUnaryOperation = false;
        }
        private void resetError()
        {
            DisplayContent = "-E-";
            previousDisplayContent = "0";
            isEnteredNumber = false;
        }
    }



}
