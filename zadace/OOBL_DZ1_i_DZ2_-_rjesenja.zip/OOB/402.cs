﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string displayState;
        private string memory;
        private double internalState;
        private char op;
        private bool resetDisplay;
        private int stanje;
        private bool prva;

        public Kalkulator()
        {
            displayState = "0";
            memory = "0";
            internalState = 0;
            op = '0';
            resetDisplay = false;
            stanje = 0;
            prva = true;
        }

        public void Press(char inPressedDigit)
        {
            
            if (char.IsDigit(inPressedDigit))
            {
                UtipkajZnamenku(inPressedDigit);
                return;
            }
            
            switch (inPressedDigit)
            {
                case ',':
                    prva = false;
                    if (displayState.IndexOf(',') != -1)
                        return;
                    else
                        displayState += ",";
                    return;
                case 'C':
                     displayState = "0";
                     prva = true;
                    return;
                case 'O':
                    displayState = "0";
                    internalState = 0;
                    memory = "0";
                    return;
                case '+':
                    BinarnaOperacija('+');
                    Zaokruzi();
                    return;
                case '*':
                    BinarnaOperacija('*');
                    return;
                case '-':
                    BinarnaOperacija('-');
                    return;
                case '/':
                    BinarnaOperacija('/');
                    return;
                case '=':
                    displayState = IzvrsiOperaciju();
                    Zaokruzi();
                    return;
                case 'M':
                    displayState = PromijeniPredznak();
                    Zaokruzi();
                    return;
                case 'P': 
                    memory = displayState;
                    return;
                case 'G':
                    displayState = memory;
                    return;
                case 'S':
                    displayState = Sinus();
                    Zaokruzi();
                    return;
                case 'K':
                    displayState = Kosinus();
                    Zaokruzi();
                    return;
                case 'T':
                    displayState = Tangens();
                    Zaokruzi();
                    return;
                case 'I':
                    displayState = Inverz();
                    Zaokruzi();
                    return;
                case 'Q':
                    displayState = Kvadrat();
                    Zaokruzi();
                    return;
                case 'R':
                    displayState = Korijen();
                    Zaokruzi();
                    return;
                default:
                    return;
            }
            
        }
        
        private string PromijeniPredznak()
        {
            if (displayState.StartsWith("-"))
                displayState = displayState.Remove(0,1);
            else
                displayState = displayState.Insert(0, "-");
            return displayState;
        }
        
        private void UtipkajZnamenku(char znamenka)
        {
            if (resetDisplay)
            {
                displayState = "";
                resetDisplay = false;
            }

            if (stanje == 1)
                stanje = 2;

            if (prva)
            {
                if (znamenka == '0')
                    return;
                prva = false;
                displayState = znamenka.ToString();
            }
            else
                displayState += znamenka;
        }

        private string IzvrsiOperaciju()
        {
            double rezultat = 0;
            double drugiOperand = 0;
            if (displayState == "")
                drugiOperand = internalState;
            else
                drugiOperand = Convert.ToDouble(displayState);
            switch (op)
            {
                case '+':
                    rezultat = internalState + drugiOperand;
                    break;
                case '-':
                    rezultat = internalState - drugiOperand;
                    break;
                case '/':
                    if (drugiOperand == 0)
                    {
                        resetDisplay = true;
                        return "-E-";
                    }
                    rezultat = internalState / drugiOperand;
                    break;
                case '*':
                    rezultat = internalState * drugiOperand;
                    break;
                default:
                    rezultat = drugiOperand;
                    break;
            }

            op = '0';
            
            internalState = rezultat;
            return rezultat.ToString();
            
        }

        private void BinarnaOperacija(char operacija)
        {
            if(stanje == 0)
                stanje = 1;
            if (stanje == 2)
            {
                stanje = 1;
                displayState = IzvrsiOperaciju();
            }
            if(displayState != "")
                internalState = Convert.ToDouble(displayState);
           
            op = operacija;
            resetDisplay = true;

        }

        private string Kvadrat()
        {
            double tmp = 0;
            if (displayState.Length == 0)
                tmp = internalState;
            else
                tmp = Convert.ToDouble(displayState);
            tmp = tmp*tmp;
            return tmp.ToString();
        }

        private string Korijen()
        {
            double tmp = 0;
            if (displayState.Length == 0)
                tmp = internalState;
            else
                tmp = Convert.ToDouble(displayState);
            if (tmp < 0)
            {
                prva = true;
                resetDisplay = true;

                return "-E-";
            }
            else
            {
                tmp = Math.Sqrt(tmp);
                return tmp.ToString();
            }
            
        }

        private string Inverz()
        {
            double tmp = 0;
            if(displayState.Length == 0)
               tmp = internalState;  
            else
               tmp = Convert.ToDouble(displayState);
            if (tmp == 0)
            {
                resetDisplay = true;
                return "-E-";
            }
            tmp = 1/tmp;
            return tmp.ToString();
        }

        private string Tangens()
        {
            double tmp = Convert.ToDouble(displayState);
            tmp = Math.Tan(tmp);
            return tmp.ToString(); 
        }

        private string Kosinus()
        {
            double tmp = Convert.ToDouble(displayState);
            tmp = Math.Cos(tmp);
            return tmp.ToString(); 
        }

        private string Sinus()
        {
            double tmp = Convert.ToDouble(displayState);
            tmp = Math.Sin(tmp);
            return tmp.ToString(); 
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }

        private void Zaokruzi()
        {
            if (displayState == "-E-")
                return;

            while (displayState.Length > 1 && displayState.StartsWith("0"))
            {
                if (!displayState.StartsWith("0,"))
                    displayState = displayState.Remove(0, 1);
                else
                    break;
            }

            while (displayState.Length > 2 && displayState.StartsWith("-0"))
            {
                if (!displayState.StartsWith("-0,"))
                    displayState = displayState.Remove(1, 1);
                else
                    break;
            }

            if (displayState.EndsWith(","))
                displayState = displayState.Remove(displayState.Length - 1);

            if (displayState.Length > 10)
            {
                int numberOfDecimals;
                int point = displayState.IndexOf(',');
                if (point == -1 || point > 11)
                {
                    displayState = "-E-";
                    resetDisplay = true;
                    return;
                }

                if (displayState.StartsWith("-"))
                    numberOfDecimals = 11 - point;
                else
                    numberOfDecimals = 10 - point;
                double tmp = Convert.ToDouble(displayState);
                tmp = Math.Round(tmp, numberOfDecimals);
                displayState = tmp.ToString();
                if (NumberOfDigits(displayState) > 10)
                {
                    displayState = "-E-";
                    return;
                }
            }
            else
            {
                double tmp = Convert.ToDouble(displayState);
                displayState = tmp.ToString();
            }

            

        }

        private int NumberOfDigits(string test)
        {
            int numberOfDigits = 0;
            foreach (char i in test)
                if (Char.IsDigit(i))
                    numberOfDigits += 1;
            return numberOfDigits;
        }



    }


}
