﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string currentDisplayState = "0";
        int countDisplaySize = 1;       ///spremam veličinu unosa radi ograničenja na veličinu displaya
        int countDecimal = 0;          ////brojim znakove poslije decimalne točke (radi lakšeg zaokruživanja) 
        int comaPressed = 0;

        char operation = '0';
        string firstOper;

        
        int resetCurrDS = 0;

        string currentMemory = "0";
        int countCurrentMemory = 1;
        int countDecimalMemory = 0;
        int comaMemory = 0;

        string saveFirst = null;
        int flag = 0;
                

        Method callMethod = new Method();
                  

        public void Press(char inPressedDigit)
        {
            if (currentDisplayState == "-E-")
            {
                return;
            }
            if (resetCurrDS == 1)
            {
                //resetCurrDS = 0;
                //firstOper = currentDisplayState;
                currentDisplayState = "0";
                countDisplaySize = 1;
                countDecimal = 0;
                comaPressed = 0;
            }

            if (operation != '0' && (firstOper == null || resetCurrDS == 1) && char.IsNumber(inPressedDigit))
            {
                
                if (flag == 1)
                {
                    flag = 0;
                    firstOper = saveFirst;
                    saveFirst = null;
                }
                else if (resetCurrDS == 0)
                {
                    firstOper = currentDisplayState;
                }
                else
                {
                    resetCurrDS = 0;
                }
                currentDisplayState = "0";
                countDisplaySize = 1;
                countDecimal = 0;
                comaPressed = 0;
            }
            if (char.IsNumber(inPressedDigit) && countDisplaySize < 10)      /////ukoliko je broj, osvježavam string za ispis
            {
                
                //Console.WriteLine(inPressedDigit);
                if (currentDisplayState.Length == 1 && currentDisplayState == "0")  ///ako je string za ispis u početnom stanju, spremam unos preko njega
                {
                    
                    if (inPressedDigit != '0')
                    {
                       
                        currentDisplayState = inPressedDigit.ToString();
                        //countDisplaySize++;
                    }                    
                    return;
                }
                else
                {
                    currentDisplayState = currentDisplayState + inPressedDigit;     ///ako se već nalaze neke znamenke, dodajem novu znamenku njima
                    countDisplaySize++;
                    if (comaPressed == 1)
                    {
                        countDecimal++;
                    }
                    return;
                }               
            }
            if (inPressedDigit == 'M')
            {
                if (currentDisplayState == "0")
                {
                    return;
                }
                currentDisplayState = callMethod.Round(currentDisplayState, countDecimal, countDisplaySize);
                currentDisplayState = '-' + currentDisplayState;
                return;
                
               
            }
            if (inPressedDigit == ',' && comaPressed == 0)
            {   
                currentDisplayState = currentDisplayState + ',';
                
                comaPressed = 1;
                return;
            }


            if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                if (operation != '0')
                {
                    if (firstOper != null)
                    {
                        currentDisplayState = callMethod.DoOperation(firstOper, currentDisplayState, 1, operation);
                        //operation = '0';
                        firstOper = null;

                    }
                    operation = inPressedDigit;
                    return;
                }
                else
                {
                    operation = inPressedDigit;
                    currentDisplayState = callMethod.Round(currentDisplayState, countDecimal, countDisplaySize);
                    if (flag == 1)
                    {
                        flag = 0;
                        saveFirst = null;
                    }
                    return;
                }
            }

            if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T' || inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
            {
                if (firstOper == null)
                {
                    saveFirst = currentDisplayState;
                    flag = 1;
                }
                currentDisplayState = callMethod.OneOperOperation(currentDisplayState, inPressedDigit);
                return;
            }            
            
        

            if (inPressedDigit == '=')
            {
                if (operation == '0')
                {
                    currentDisplayState = callMethod.Round(currentDisplayState, countDecimal, countDisplaySize);
                    return;
                }
                else if (firstOper == null)
                {
                    currentDisplayState = callMethod.DoOperation(firstOper, currentDisplayState, 0, operation);
                    
                    return;
                }
                else
                {
                    currentDisplayState = callMethod.DoOperation(firstOper, currentDisplayState, 1, operation);
                    return;
                }
            }

            if (inPressedDigit == 'C')
            {
                //resetCurrDS = 1;
                //resetCurrDS = 1;
                //resetCurrDS = 0;
                //firstOper = currentDisplayState;
                currentDisplayState = "0";
                countDisplaySize = 1;
                countDecimal = 0;
                comaPressed = 0;

                return;
                
            }

            if(inPressedDigit == 'P')
            {
                currentMemory = currentDisplayState;
                countCurrentMemory = countDisplaySize;
                countDecimalMemory = countDecimal;
                comaMemory = comaPressed;
                return;
            }

            if (inPressedDigit == 'G')
            {
                currentDisplayState = currentMemory;
                countDisplaySize = countCurrentMemory;
                countDecimal = countDecimalMemory;
                comaPressed = comaMemory;                
                return;
            }

            if (inPressedDigit == 'O')
            {
                resetCurrDS = 1;
                operation = '0';
                firstOper = null;
                saveFirst = null;
                flag = 0;
                currentMemory = "0";
                countCurrentMemory = 1;
                countDecimalMemory = 0;
                comaMemory = 0;
                return;
            }

            //throw new NotImplementedException();
        }

        public string GetCurrentDisplayState()
        {
            /*
            if (operation != '0' && currentDisplayState == "0")
            {
                Console.WriteLine(firstOper);
                return firstOper;
            }*/
            //Console.WriteLine(currentDisplayState);
            //Console.WriteLine("BROJ" + countDisplaySize);
            return currentDisplayState;
            //throw new NotImplementedException();
        }
    }

    public class Method
    {
        public string Round(string input, int dec, int disp)
        {
            double cast = Convert.ToDouble(input);
            cast = Math.Round(cast,10 - (disp - dec));
            input = cast.ToString();
            return input;
        }
        
        public string DoOperation(string first, string second, int number, char oper)
        {
            double firstNum;
            double secondNum = Convert.ToDouble(second);
            if (number == 1)
            {
                firstNum = Convert.ToDouble(first);
            }
            else
            {
                firstNum = Convert.ToDouble(second);
            }
            double result;
            if (oper == '+')
            {
                result = firstNum + secondNum;
            }
            else if (oper == '-')
            {
                result = firstNum - secondNum;
            }
            else if (oper == '*')
            {
                result = firstNum * secondNum;
            }
            else if (oper == '/')
            {
                result = firstNum / secondNum;
            }
            else
            {
                return "-E-";
            }
            return GenerateOutput(result);
        }

        public string OneOperOperation(string input, char oper)
        {
            double result = Convert.ToDouble(input);
            if (oper == 'S')
            {
                result = Math.Sin(result);
            }
            else if (oper == 'K')
            {
                result = Math.Cos(result);
            }
            else if (oper == 'T')
            {
                result = Math.Tan(result);
            }
            else if (oper == 'Q')
            {
                result = Math.Pow(result, 2);
            }
            else if (oper == 'R')
            {
                result = Math.Sqrt(result);
            }
            else if (oper == 'I')
            {
                if (result != 0)
                {
                    result = 1 / result;
                }
                else
                    return "-E-";
            }
            return GenerateOutput(result);
        }

        public string GenerateOutput(double input)
        {
            string output = input.ToString();
            int coma = 0;
            int min = 0;
            int size = output.Length;
            if (output.Contains('-'))
            {
                size--;
                min = 1;
            }
            if (output.Contains(','))
            {
                size--;
                coma = 1;
            }
            if (size > 10)
            {
                if (coma == 0)
                {
                    output = "-E-";
                    return output;
                }
                else
                {
                    int comaIndex = output.IndexOf(',');
                    if (min == 1)
                    {
                        comaIndex--;
                    }
                    int countDec = size - comaIndex;
                    output = Round(output, countDec, size);
                    return output;
                }
            }
            else
            {
                return output;
            }
        }
    }
}
