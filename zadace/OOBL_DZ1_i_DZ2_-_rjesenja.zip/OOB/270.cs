﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    //znam da ova zadaća nije najobjektnije izrađena, trebalo bi dodati još par klasa, neke metode razbiti na više manjih zbog preglednosti i ponovne iskoristivosti
    //upotrijebiti par oblikovnih obrazaca, ali s vremenskim resursima koje sam imao na raspolaganju, ovo je najbolje što se dalo napraviti
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private Screen screen;
        private double currentNumber;
        private double stogNumber; //broj sa kojim se računa ilitiga broj prije operatora
        private double savedNumber;
        private char function; //operator(funkcija) koji se koristi

        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            screen = new Screen();
            function = '0'; //0 - nije još bilo operacije
        }

        public void Press(char inPressedDigit)
        {
            if (char.IsNumber(inPressedDigit) == true)
            {
                screen.AddDigit(inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case ',':
                        screen.Decimal();
                        break;
                    case '=':
                        Calculate();
                        screen.InputScreen(stogNumber);
                        break;
                    case '-':
                        if (function != '0')                    //ako postoji operacija koja je predhodno bila zadana onda se obavlja ona i broj na stogu je rezlutat te operacija
                            Calculate();
                        else                                    //u protivno je broj onaj koji piše na ekranu
                            stogNumber = screen.GetNumber();
                        screen.ResetScreen();
                        function = '-';
                        break;
                    case '+':
                        if (function != '0')                    //ako postoji operacija koja je predhodno bila zadana onda se obavlja ona i broj na stogu je rezlutat te operacija
                            Calculate();
                        else                                    //u protivno je broj onaj koji piše na ekranu
                            stogNumber = screen.GetNumber();
                        screen.ResetScreen();
                        function = '+';
                        break;
                    case '*':
                        if (function != '0')                    //ako postoji operacija koja je predhodno bila zadana onda se obavlja ona i broj na stogu je rezlutat te operacija
                            Calculate();
                        else                                    //u protivno je broj onaj koji piše na ekranu
                            stogNumber = screen.GetNumber();
                        screen.ResetScreen();
                        function = '*';
                        break;
                    case '/':
                        if (function != '0')                    //ako postoji operacija koja je predhodno bila zadana onda se obavlja ona i broj na stogu je rezlutat te operacija
                            Calculate();
                        else                                    //u protivno je broj onaj koji piše na ekranu
                            stogNumber = screen.GetNumber();
                        screen.ResetScreen();
                        function = '/';
                        break;
                    case 'M':   //predznak
                        screen.ChangeMinus();
                        //currentNumber *= -1;
                        break;
                    case 'S':   //sinus broja
                        currentNumber = screen.GetNumber();
                        currentNumber = Math.Sin(currentNumber);
                        screen.InputScreen(currentNumber);
                        break;
                    case 'K':   //kosinus broja
                        currentNumber = screen.GetNumber();
                        currentNumber = Math.Cos(currentNumber);
                        screen.InputScreen(currentNumber);
                        break;
                    case 'T':  //tanges broja
                        currentNumber = screen.GetNumber();
                        currentNumber = Math.Tan(currentNumber);
                        screen.InputScreen(currentNumber);
                        break;
                    case 'Q':   //kvadrat broja
                        currentNumber = screen.GetNumber();
                        currentNumber = Math.Pow(currentNumber, 2);
                        screen.InputScreen(currentNumber);
                        break;
                    case 'R':   //korjen broja
                        currentNumber = screen.GetNumber();
                        currentNumber = Math.Sqrt(currentNumber);
                        screen.InputScreen(currentNumber);
                        break;
                    case 'I':   //inverz broja
                        currentNumber = screen.GetNumber();
                        if (currentNumber == 0)
                            screen.Error();
                        else
                        {
                            currentNumber = Math.Pow(currentNumber, -1);
                            screen.InputScreen(currentNumber);
                        }
                        break;
                    case 'P':   //spremanje broja
                        savedNumber = screen.GetNumber();
                        break;
                    case 'G':   //dohvat broja iz memorije
                        screen.InputScreen(savedNumber);
                        break;
                    case 'C':   //brisanje ekrana
                        screen.ResetScreen();
                        break;
                    case 'O':   //reset digitrona
                        ResetCalculator();
                        break;
                    default:

                        break;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            if (function != '0')                   //zaobilaženje pravog ispisa u slučaju kada je zapis tipa 5+
                return stogNumber.ToString();
            return screen.ToString();
        }

        /// <summary>
        /// Funkcija koja bi trebala obraditi moguće iznemke kod ispisa
        /// </summary>
        /// <returns>String za ispis</returns>
        private string PrintExceptions()
        {
            if (function != '0')
                return stogNumber.ToString();
            return null;
        }

        /// <summary>
        /// Izračunava operaciju
        /// </summary>
        private void Calculate()
        {
            switch (function)                                           //note: ne radi za slučaj više operatera jedan za drugim -> početna ideja programa je bila dobra, ali više nije, trebalo bi raditi redizajn
            {
                case '-':
                    stogNumber = stogNumber - screen.GetNumber();
                    break;
                case '+':
                    double d = screen.GetNumber();
                    if (d != 0)                                         //slučaj kada sa desne strane nemamo ništa slučaj 5+=
                        stogNumber = stogNumber + screen.GetNumber();
                    else                                                //neće davati dobar rezultat za recimo 5+0= , ali ne vidim izlaz bez da mjenjam pola programa, što znači da program baš i nevalja
                        stogNumber *= 2;
                    break;
                case '*':
                    double p = screen.GetNumber();
                    if (p != 0)
                        stogNumber = stogNumber * screen.GetNumber();
                    else
                        stogNumber = Math.Pow(stogNumber, 2);
                    break;
                case '/':
                    double i = screen.GetNumber();
                    if (i != 0)
                        stogNumber = stogNumber / i;
                    else
                        screen.Error();
                    break;
                default:
                    stogNumber = screen.GetNumber();
                    break;
            }
            function = '0';
        }

        /// <summary>
        /// Resetira memoriju i ekran kalkulatora
        /// </summary>
        private void ResetCalculator()
        {
            currentNumber = 0;
            savedNumber = 0;
            function = '0';
            screen.ResetScreen();
        }
    }

    public class Screen
    {
        private string screen; //ono kaj je na ekranu
        private int state;  //koje vrste zadnja pritisnuta tipka broj ili operacija 0-početno stanje digitrona (reset), 1-broj, 2-error
        //moglo se je ovo rijeit sa oblikovnim obrascem (mislim da je stanje), ali nisam ima vremena i čini mi se da bi mogli prekomplicirati kode time 
        private string minus; //ima li minus
        private int numDigits; //koliko ima znamenaka

        public Screen()
        {
            state = 0;
            minus = "";
            screen = "0";
            numDigits = 0;
        }

        /// <summary>
        /// Dodaje znamenku na ekran
        /// </summary>
        /// <param name="digit">Znamenka koja se dodaje</param>
        public void AddDigit(char digit)
        {
            if (state == 2)     //u slučaju greške ne radi ništa dok se ne poništi
                return;
            if (state == 0)         //ako je stanje 0 na ekranu je samo početna nula
                if (digit == '0')   //ako je dopisana nova nula -> ništa se ne dira
                    return;
                else                //inče se te nula obirše i nastavlja se dalje sa upisivanjem znamenaka
                    screen = "";
            screen += digit;
            state = 1;
            numDigits++;
            if (numDigits > 10)
            {
                RoundNumber();
                //numDigits=10;
            }
        }

        /// <summary>
        /// Unos decimalnog zareza
        /// </summary>
        public void Decimal()
        {
            if (state == 2)     //u slučaju greške ne radi ništa dok se ne poništi
                return;
            if (state == 0)     //ako je prazan ekran (odnosno 0) mora dodati najprije 0 ispred zareza
            {
                screen = "0";
                numDigits++;
            }
            screen += ',';
            state = 1;
        }

        /// <summary>
        /// Zaokružuje broj na ekranu na prihvatljiv broj decimala
        /// </summary>
        private void RoundNumber()
        {
            string[] parts = screen.Split(',');
            int maxDecLen = 10 - (parts[0].Length);
            if (maxDecLen < 0)
            {
                Error();
                return;
            }
            try
            {
                double num = Convert.ToDouble(minus + screen);
                num = Math.Round(num, maxDecLen);
                screen = Math.Abs(num).ToString();
                numDigits = 10;
            }
            catch
            {
                //
            }
        }

        /// <summary>
        /// Mjenaj predznak na ekranu
        /// </summary>
        public void ChangeMinus()
        {
            if (state != 0)
                if (minus.Length == 0)
                    minus = "-";
                else
                    minus = "";
        }

        /// <summary>
        /// Vraća broj zapisan na ekranu kao double
        /// </summary>
        /// <returns>Double vrijednost broja na ekranu</returns>
        public double GetNumber()
        {
            return Convert.ToDouble(minus + screen);
        }

        /// <summary>
        /// Briše ekran
        /// </summary>
        public void ResetScreen()
        {
            minus = "";
            screen = "0";
            state = 0;
            numDigits = 0;
        }

        /// <summary>
        /// U slučaju greške u radu digitrona
        /// </summary>
        public void Error()
        {
            screen = "-E-";
            state = 2;
        }

        /// <summary>
        /// Direktno zapisivanje nekog broja na ekran
        /// </summary>
        /// <param name="number">Broj koji se želi prikazati na ekranu</param>
        public void InputScreen(double number)
        {
            screen = Math.Abs(number).ToString();
            if (number < 0)
                minus = "-";
            if (screen.Length > 9)
                RoundNumber();
        }

        public override string ToString()
        {
            return minus + screen;
        }
    }

}
