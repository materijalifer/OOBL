﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string display;
        private bool dalje;
        private double ukupno;
        private string memorija;
        private string operatorr;

        public Kalkulator()
        {
            this.display = "0";
            this.dalje = false;
            this.ukupno = 0;
            this.memorija = "";
            this.operatorr = "";
        }

        private void OdsijeciVisak()
        {
            int duljina = 0;
            int duljina1 = 0;
            bool prosao = false;
         
            foreach (char znak in this.display)
            {
                if (znak.Equals(','))
                {
                    prosao = true;
                }
                if (char.IsDigit(znak))
                {
                    duljina += 1;
                    if (prosao)
                    {
                        duljina1 += 1;
                    }
                    if (duljina > 9)
                    {
                        break;
                    }
                }
            }

            this.display = Convert.ToString(Math.Round(Convert.ToDouble(this.display), duljina1));
            if (duljina>10)
            {
                int pomocni = 0;
                if (this.display.Contains(','))
                {
                    pomocni +=1 ;
                }
                if (this.display.Contains('-'))
                {
                    pomocni += 1;
                }
                this.display.Substring(0,10+pomocni);
            }
        }

        private bool ProvjeriGranicu()
        {
            if (Math.Abs(Convert.ToDouble(this.display)) > 9999999999)
            {
                this.display = "-E-";
                return true;
            }
            else
            {
                return false;
            }
        }

        
        private void Clear()
        {
            this.display = "0";
        }

        private void OnOff()
        {
            this.display = "0";
            this.memorija = "";
            this.ukupno = 0;
        }

        private void Inverse()
        {
            if (Convert.ToDouble(this.display).Equals(0))
            {
                this.display = "-E-";
            }
            else
            {
                this.display = Convert.ToString(1 / Convert.ToDouble(this.display));
            }
        }

        private void Kvadriraj()
        {
            this.display = Convert.ToString(Convert.ToDouble(this.display) * Convert.ToDouble(this.display));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
        }

        private void PromjenaPredznaka()
        {
            if (Convert.ToDouble(this.display).Equals(0))
            {
                return;
            }
            else if (this.display[0].Equals('-'))
            {
                this.display.Remove(0);
            }
            else
            {
                this.display = '-' + this.display;
            }
        }

        private void Memoriziraj()
        {
            this.memorija = this.display;
        }

        private void IzvadiIzMemorije()
        {
            this.display = this.memorija;
        }

        private void Kosinus()
        {
            this.display = Convert.ToString(Math.Cos(Convert.ToDouble(this.display)));
            OdsijeciVisak();
        }

        private void Sinus()
        {
            this.display = Convert.ToString(Math.Sin(Convert.ToDouble(this.display)));
            OdsijeciVisak();
        }

        private void Tangens()
        {
            this.display = Convert.ToString(Math.Tan(Convert.ToDouble(this.display)));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
        }

        private void Korjenuj()
        {
            if (Convert.ToDouble(this.display) < 0)
            {
                this.display = "-E-";
            }
            else
            {
                this.display = Convert.ToString(Math.Sqrt(Convert.ToDouble(this.display)));
            }
        }

        private void Racunaj(char operatorr)
        {
            switch (this.operatorr)
            {
                case "+":
                    Zbroji();
                    break;
                case "-":
                    Oduzmi();
                    break;
                case "/":
                    Podijeli();
                    break;
                case "*":
                    Pomnozi();
                    break;
                default:

                    break;
            }
            this.operatorr = "";
        }

        private void Zbroji()
        {
            this.display = Convert.ToString(this.ukupno + Convert.ToDouble(this.display));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
            this.ukupno = Convert.ToDouble(this.display);
        }

        private void Oduzmi()
        {
            this.display = Convert.ToString(this.ukupno - Convert.ToDouble(this.display));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
            this.ukupno = Convert.ToDouble(this.display);
        }

        private void Podijeli()
        {
            this.display = Convert.ToString(this.ukupno / Convert.ToDouble(this.display));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
            this.ukupno = Convert.ToDouble(this.display);
        }

        private void Pomnozi()
        {
            this.display = Convert.ToString(this.ukupno * Convert.ToDouble(this.display));
            if (ProvjeriGranicu())
            {
                return;
            }
            else
            {
                OdsijeciVisak();
            }
            this.ukupno = Convert.ToDouble(this.display);
        }

        private void Operand(char operand)
        {
            if (this.dalje)
            {
                this.dalje = false;
                this.display = "0";
            }

            if (operand.Equals(','))
            {
                if (this.display.Contains(','))
                {
                    return;
                }
                else
                {
                    this.display += ',';
                }
            }

            else
            {
                if (this.display.Equals("0"))
                {
                    this.display = "";
                }
                this.display += operand;
                OdsijeciVisak();
            }
        }


        private void Operator(char operatorr)
        {
            if (operatorr.Equals('='))
            {
                Racunaj(operatorr);
            }

            else
            {
                if (this.operatorr.Equals(""))
                {
                    dalje = true;
                    this.ukupno = Convert.ToDouble(this.display);
                    OdsijeciVisak();
                }
                else if (!dalje)
                {
                    dalje = true;
                    Racunaj(operatorr);
                }
                this.operatorr = Convert.ToString(operatorr);
            }
            return;
        }

        private void Funkcija(char funkcija)
        {
            switch (funkcija)
            {
                case 'O':
                    OnOff();
                    break;
                case 'C':
                    Clear();
                    break;
                case 'I':
                    Inverse();
                    break;
                case 'Q':
                    Kvadriraj();
                    break;
                case 'R':
                    Korjenuj();
                    break;
                case 'M':
                    PromjenaPredznaka();
                    break;
                case 'P':
                    Memoriziraj();
                    break;
                case 'G':
                    IzvadiIzMemorije();
                    break;
                case 'S':
                    Sinus();
                    break;
                case 'K':
                    Kosinus();
                    break;
                case 'T':
                    Tangens();
                    break;
                default:
                    break;
            }
        }

        public void Press(char inPressedDigit)
        {
            if (this.display.Equals("-E-"))
            {
                switch (inPressedDigit)
                {
                case 'O':
                    OnOff();
                    break;
                case 'C':
                    Clear();
                    break;
                default:
                    break;
                }
            }

            if ((char.IsDigit(inPressedDigit)) || inPressedDigit.Equals(','))
            {
                Operand(inPressedDigit);
            }
            else if (char.IsLetter(inPressedDigit))
            {
                Funkcija(inPressedDigit);
            }
            else
            {
                Operator(inPressedDigit);
            }

        }

        public string GetCurrentDisplayState()
        {
            return this.display;
        }
    }


}
