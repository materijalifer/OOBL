﻿using System;
using System.Collections.Generic;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        double lastNumber, currentNumber, memory;
        bool operationPending, numHasDecPoint, hasChangedPredznak, hasBeenSaved;
        string numberPending;
        char lastOperator;
        List<char> listaOperations = new List<char>() { '-', '+', '*', '/' };
        List<char> specialOperations = new List<char>() { 'I', 'S', 'T', 'K', 'R', 'Q' };

        public Kalkulator()
        {
            ResetValues();
        }

        private void ResetValues()
        {
            hasBeenSaved = false;
            lastNumber = 0;
            currentNumber = 0;
            memory = 0;
            numberPending = "0";
            operationPending = false;
            numHasDecPoint = false;
            hasChangedPredznak = false;
        }

        public void Press(char newInput)
        {
            if (IsPartOfNum(newInput)) ParseNumber(newInput);
            else
            {
                ParseNumber();
                DoOperation(newInput);
            }
        }

        private string ShortNumber(double number)
        {
            string first = number.ToString().Split(',')[0];
            string second = number.ToString().Split(',')[1];
            while (first.Length + second.Length > 11) second = second.Substring(0, second.Length - 1);
            return first + "," + second;
        }

        public string GetCurrentDisplayState()
        {
            if (currentNumber.ToString().Length > 11)
            {
                if (currentNumber.ToString().Split(',').Length > 1)
                {
                    currentNumber = Convert.ToDouble(ShortNumber(currentNumber));
                    return currentNumber.ToString();
                }
                return "-E-";
            }
            else if (currentNumber == Convert.ToDouble("Infinity")) return "-E-";
            else if (operationPending == true && currentNumber == 0) return lastNumber.ToString();
            else if (operationPending == true && lastNumber != 0) return currentNumber.ToString();
            else return currentNumber.ToString();
        }

        private void ParseNumber(char partOfNumber)
        {
            if ((numHasDecPoint == true) && (partOfNumber == '.')) return;
            if ((numberPending.Length == 0) && (IsDecPoint(partOfNumber))) numberPending = "0";
            if (IsDecPoint(partOfNumber))
            {
                numHasDecPoint = true;
                numberPending = numberPending + ",";
            }
            else if (numberPending == "0")
            {
                numberPending = partOfNumber.ToString();
                currentNumber = Convert.ToDouble(numberPending);
            }
            else if (numberPending.Length > 0 && operationPending == true)
            {
                numberPending = numberPending + partOfNumber.ToString();
                if (currentNumber < 0) currentNumber = -Convert.ToDouble(numberPending);
                else currentNumber = Convert.ToDouble(numberPending);
            }
            else
            {
                numberPending = numberPending + partOfNumber;
                if (currentNumber < 0) currentNumber = -Convert.ToDouble(numberPending);
                else currentNumber = Convert.ToDouble(numberPending);
            }
        }

        private bool IsPartOfNum(char testedChar)
        {
            if ((testedChar >= '0') && (testedChar <= '9'))
                return true;
            return
                IsDecPoint(testedChar);
        }

        private bool IsDecPoint(char testedChar)
        {
            if ((testedChar == ',') || (testedChar == 188))
                return true;
            else
                return false;
        }

        private void ParseNumber()
        {
            if (numberPending.Length > 0 && hasChangedPredznak == true)
            {
                if (currentNumber < 0)
                    currentNumber = -System.Convert.ToDouble(numberPending);
                else
                    currentNumber = System.Convert.ToDouble(numberPending);
            }
            if (numberPending.Length > 0 && hasChangedPredznak == false)
            {
                if (currentNumber < 0)
                    currentNumber = -System.Convert.ToDouble(numberPending);
                else
                    currentNumber = System.Convert.ToDouble(numberPending);
                numberPending = "0";
                numHasDecPoint = false;
            }
        }

        private void DoOperation(char operation)
        {
            if (operation == '=' && operationPending == true && currentNumber == 0)
            {
                if (lastOperator == '+') currentNumber = lastNumber + lastNumber;
                if (lastOperator == '-') currentNumber = 0;
                if (lastOperator == '*') currentNumber = lastNumber * lastNumber;
                if (lastOperator == '/') currentNumber = 1;
                operationPending = false;
            }

            if (operation == '=' && operationPending == true && currentNumber != 0)
            {
                if (lastOperator == '+') currentNumber = currentNumber + lastNumber;
                if (lastOperator == '-') currentNumber = lastNumber - currentNumber;
                if (lastOperator == '*') currentNumber = currentNumber * lastNumber;
                if (lastOperator == '/') currentNumber = lastNumber / currentNumber;
                operationPending = false;
            }

            if (specialOperations.Contains(operation) && operationPending == true && currentNumber == 0)
            {
                if (operation == 'R')
                {
                    currentNumber = Math.Sqrt(lastNumber);
                    return;
                }
                if (operation == 'Q')
                {
                    currentNumber *= lastNumber;
                    return;
                }
                if (operation == 'I')
                {
                    currentNumber = 1 / lastNumber;
                    return;
                }
                if (operation == 'S')
                {
                    currentNumber = Math.Sin(lastNumber);
                    return;
                }
                if (operation == 'K')
                {
                    currentNumber = Math.Cos(lastNumber);
                    return;
                }
                if (operation == 'T')
                {
                    currentNumber = Math.Tan(lastNumber);
                    return;
                }
            }

            if (operation == 'M')
            {
                currentNumber = -Math.Abs(currentNumber);
                numberPending = currentNumber.ToString();
                hasChangedPredznak = true;
                return;
            }
            if (operation == 'O')
            {
                ResetValues();
                return;
            }
            if (operation == 'C')
            {
                currentNumber = 0;
                return;
            }
            if (operation == 'P')
            {
                if (hasBeenSaved == true) memory = Convert.ToDouble((memory.ToString() + currentNumber.ToString()));
                else memory = Convert.ToDouble(currentNumber.ToString());
                hasBeenSaved = true;
                return;
            }
            if (operation == 'G')
            {
                hasBeenSaved = false;
                currentNumber = memory;
                return;
            }
            if (operation == 'R')
            {
                currentNumber = Math.Sqrt(currentNumber);
                numberPending = currentNumber.ToString();
                return;
            }
            if (operation == 'Q')
            {
                currentNumber *= currentNumber;
                numberPending = currentNumber.ToString();
                return;
            }
            if (operation == 'I')
            {
                currentNumber = 1 / currentNumber;
                numberPending = currentNumber.ToString();
                return;
            }
            if (operation == 'S')
            {
                currentNumber = Math.Sin(currentNumber);
                numberPending = currentNumber.ToString();
                return;
            }
            if (operation == 'K')
            {
                currentNumber = Math.Cos(currentNumber);
                numberPending = currentNumber.ToString();
                return;
            }
            if (operation == 'T')
            {
                currentNumber = Math.Tan(currentNumber);
                numberPending = currentNumber.ToString();
                return;
            }

            if (operationPending == true)
            {
                operationPending = false;
                if (lastOperator == '+') currentNumber = currentNumber + lastNumber;
                if (lastOperator == '-') currentNumber = lastNumber - currentNumber;
                if (lastOperator == '*') currentNumber = currentNumber * lastNumber;
                if (lastOperator == '/') currentNumber = lastNumber / currentNumber;
                lastNumber = 0;
            }

            if (operation == '+') lastOperator = '+';
            if (operation == '-') lastOperator = '-';
            if (operation == '*') lastOperator = '*';
            if (operation == '/') lastOperator = '/';
            if (listaOperations.Contains(operation))
            {
                lastNumber = currentNumber;
                currentNumber = 0;
                numberPending = "0";
                hasChangedPredznak = false;
                operationPending = true;
            }
        }
    }
}
