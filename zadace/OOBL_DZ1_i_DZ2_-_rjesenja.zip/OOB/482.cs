﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Display
    {
        string displayNum;
        int commaPlace;
        char unOperator;
        const int MAXdigits = 10;

        public Display() //konstruktor displaya, razredi za operacije nad ekranom
        {
            resetDisplay();
        }

        public string MakeDisplay()
        {
            string currentDisplay = "";
            currentDisplay = displayNum;//makni nule s početka ekrana                          
            if (commaPlace > 0) //ubaci zarez na svoje mjesto
            {
                currentDisplay=currentDisplay.Insert(commaPlace,","); 
            }
            if (unOperator == '-' && !(currentDisplay.Equals("0"))) //dodaj predznak ako je potrebno
            {
                currentDisplay=currentDisplay.Insert(0,"-");
            }
            return currentDisplay;
        }
        public void addNumber(char number)
        {
            if (displayNum.Equals("0")&& commaPlace==0)
            {
                displayNum = number.ToString();
            }else if (displayNum.Length<MAXdigits)
            {
            displayNum += number;
            }
        }
        public void ChangeUnOperator()
        {
            if (unOperator == '+')
            {
                unOperator = '-';
            }
            else
            {
                unOperator = '+';
            }
        }
        public void addComa()
        {
            if (commaPlace == 0)
            {
                commaPlace = displayNum.Length;
            }
        }
        public void error()
        {
            resetDisplay();
            displayNum = "-E-";
        }
        public void resetDisplay()
        {
            displayNum="0";
            commaPlace=0;
            unOperator='+';
        }
        public void doubleToDisplay(double number)
        {
            string strNumber;
            resetDisplay();
            if (!(number==double.NaN||number==double.NegativeInfinity||number==double.PositiveInfinity))
            {
                strNumber = Convert.ToString(number);
                if (strNumber.IndexOf("-") > -1)
                {
                    strNumber = strNumber.Replace("-", "");
                    unOperator = '-';
                }
                commaPlace = strNumber.IndexOf(",");
                if (commaPlace >= (MAXdigits)||number>Math.Pow(10,MAXdigits))
                {
                    error(); 
                }
                else
                {
                    if (commaPlace > 0)
                    {
                        number = Math.Round(number, MAXdigits- commaPlace);
                    }
                    strNumber = Convert.ToString(number);
                    if (strNumber.IndexOf("-") > -1)
                    {
                        strNumber = strNumber.Replace("-", "");
                        unOperator = '-';
                    }
                    strNumber = strNumber.Replace(",", "");
                    displayNum = strNumber;
                }
            }
            else
            {
                error();
            }
            
        }
        public double displayToDouble()
        {
            string dispStr;
            dispStr=MakeDisplay();
            return Convert.ToDouble(dispStr);
            
        }
    }

    public class MemorizeNumber
    {
        double numberMemorized;
        public MemorizeNumber(double number)
        {
            numberMemorized = number;
        }
        public void set(double newNumber)
        {
            numberMemorized = newNumber;
        }
        public double get()
        {
            return numberMemorized;
        }
    }
    delegate double binOp(double a, double b);
    public class Operacije
    {
        binOp zadnjaBin;
        char LastOperation = 'n';
        Display display;
        MemorizeNumber firstNumber;
        MemorizeNumber memory = new MemorizeNumber(0);
        public Operacije(Display display)
        {
            this.display = display;
        }
        void binaryOperations()
        {
            double broj;
            broj = display.displayToDouble();//uzmi broj s ekrana
            if (zadnjaBin == null)//ima li operacije koje čekaju izvršenje
            {
                firstNumber = new MemorizeNumber(broj);
            }
            else if (!(LastOperation == 'b')) //da li je zadnja bila binaran operacija pritisnuta
            {
                firstNumber.set(zadnjaBin(firstNumber.get(), broj));
            }
            display.doubleToDisplay(firstNumber.get());
        }
        void NumberCase(char inPressedDigit)
        {
            if (!(LastOperation == 'n'))//da li je zadnja operacija bila unos broja
            {
                display.resetDisplay();
                LastOperation = 'n';
            }
            display.addNumber(inPressedDigit);
        }
        void Sum()
        {
            binaryOperations();
            zadnjaBin = (double a, double b) => a + b;
            LastOperation = 'b';//zadnja operacija je bila binarna
        }
        void Sub()
        {
            binaryOperations();
            zadnjaBin = (double a, double b) => a - b;
            LastOperation = 'b';
        }
        void Multiply()
        {
                binaryOperations();
                zadnjaBin = (double a, double b) => a * b;
                LastOperation = 'b';
        }
        void Div()
        {
            binaryOperations();
            zadnjaBin = (double a, double b) => a / b;
            LastOperation = 'b';
        }
        void Quad()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(Math.Pow(broj, 2));
            LastOperation = 'u';
        }
        void Inv()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(1 / broj);
            LastOperation = 'u';
        }
        void Root()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(Math.Sqrt(broj));
            LastOperation = 'u';
        }
        void Sin()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(Math.Sin(broj));
            LastOperation = 'u';
        }
        void Cos()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(Math.Cos(broj));
            LastOperation = 'u';
        }
        void Tan()
        {
            double broj;
            broj = display.displayToDouble();
            display.doubleToDisplay(Math.Tan(broj));
            LastOperation = 'u';
        }
        void Eq()
        {
            double broj;
            broj = display.displayToDouble();
            if (zadnjaBin == null)
            {
                firstNumber = new MemorizeNumber(broj);
            }
            else
            {
                firstNumber.set(zadnjaBin(firstNumber.get(), broj));
            }
            LastOperation = 'u';
            display.doubleToDisplay(firstNumber.get());
        }
        void GetMem()
        {
            double broj;
            broj = memory.get();
            if (zadnjaBin == null)
            {
                firstNumber = new MemorizeNumber(broj);
                display.doubleToDisplay(broj);
            }
            else
            {
                firstNumber.set(zadnjaBin(firstNumber.get(), broj));
                display.doubleToDisplay(firstNumber.get());
            }
            zadnjaBin = null;
            LastOperation = 'y';
        }
        void OffOn()
        {
            LastOperation = 'n';
            zadnjaBin = null;
            display.resetDisplay();
            firstNumber = null;
        }
        public void pressOperation(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    NumberCase(inPressedDigit);
                    break;
                case 'M':
                    display.ChangeUnOperator();
                    break;
                case ',':
                    display.addComa();
                    break;
                case '+':
                    Sum();
                    break;
                case '-':
                    Sub();
                    break;
                case '*':
                    Multiply();
                    break;
                case '/':
                    Div();
                    break;
                case 'Q':
                    Quad();
                    break;
                case 'R':
                    Root();
                    break;
                case 'I':
                    Inv();
                    break;
                case 'S':
                    Sin();
                    break;
                case 'K':
                    Cos();
                    break;
                case 'T':
                    Tan();
                    break;
                case '=':
                    Eq();
                    break;
                case 'P':
                    memory = new MemorizeNumber(display.displayToDouble());
                    break;
                case 'G':
                    GetMem();
                    break;
                case 'O':
                    OffOn();
                    break;
                case 'C':
                    display.resetDisplay();
                    break;
                default:
                    throw new NotImplementedException();
            }
        }

    }
    public class Kalkulator:ICalculator
    {
        Display display; 
        Operacije oper; 
       
        public Kalkulator()
        {
            display = new Display();
            oper = new Operacije(display);
        }
        public void Press(char inPressedDigit)
        {
            oper.pressOperation(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return display.MakeDisplay();
        }
    }


}
