﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {

            return new StockExchange();
        }
    }

    public class Stock
    {
        public String name;
        public long amount;
        SortedDictionary<DateTime, decimal> history;

        public Stock(String inName, long inAmount, DateTime inTime, decimal inPrice)
        {
            if (inName.Equals("", StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Name not allowed.");
            if (inAmount<=0) throw new StockExchangeException("Amount must be larger than 0.");
            if (inPrice<=0) throw new StockExchangeException("Price must be larger than 0.");

            this.name = inName;
            this.amount = inAmount;
            this.history = new SortedDictionary<DateTime, decimal>();
            this.history.Add(inTime, inPrice);
        }

        public void setPrice(decimal inPrice, DateTime inTime)
        {
            if (inPrice <= 0 || this.history.Keys.Contains(inTime)) throw new StockExchangeException("Price not allowed.");

            this.history.Add(inTime, inPrice);
        }

        public decimal getPrice(DateTime inTime)
        {
            decimal price = -1;

            foreach (KeyValuePair<DateTime, decimal> entry in this.history)
            {
                if (entry.Key.CompareTo(inTime) > 0) break;
                price = entry.Value;
            }

            if (price == -1) throw new StockExchangeException("Undefined price.");
            else return price;
        }

        public decimal getFirstPrice()
        {
            return this.history.First().Value;
        }

        public decimal getLastPrice()
        {
            return this.history.Last().Value;
        }
    }

     public class StockRepository
     {
         private List<Stock> stocks = new List<Stock>();

         public int totalNumberOfStocks()
         {
             return this.stocks.Count;
         }

         public void add(Stock inStock)
         {
            foreach(Stock s in this.stocks)
            {
                if(s.name.Equals(inStock.name, StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Stock already exists.");
            }

            this.stocks.Add(inStock);
         }

         public void remove(String inName)
         {
             Stock toRemove = null;
             foreach (Stock s in this.stocks)
             {
                 if (s.name.Equals(inName, StringComparison.OrdinalIgnoreCase)) toRemove = s;
             }

             if (toRemove != null) this.stocks.Remove(toRemove);
             else throw new StockExchangeException("No such stock.");
         }

         public Stock get(String inName)
         {
             Stock retval = null;

             foreach (Stock s in this.stocks)
             {
                 if (s.name.Equals(inName, StringComparison.OrdinalIgnoreCase)) retval = s;
             }

             if(retval!=null)return retval;
             else throw new StockExchangeException("No such stock.");
         }
     }

     public class Index
     {
         private IndexTypes type;

         public String name;

         List<Stock> stocks;

         public Index(String inName, IndexTypes inType)
         {
             if (inName.Equals("", StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Name not allowed.");
             if (inType != IndexTypes.AVERAGE && inType != IndexTypes.WEIGHTED) throw new StockExchangeException("Type not allowed.");

             this.name = inName;
             this.type = inType;
             this.stocks = new List<Stock>();
         }

         public Boolean containsStock(String inName)
         {
             bool retval = false;

             foreach (Stock s in this.stocks)
             {
                 if (s.name.Equals(inName, StringComparison.OrdinalIgnoreCase))
                 {
                     retval = true;
                     break;
                 }
             }

             return retval;
         }

         public void addStock(Stock inStock)
         {
             if (this.containsStock(inStock.name)) throw new StockExchangeException("Index already contains this stock.");

             this.stocks.Add(inStock);
         }

         public void removeStock(String inName)
         {
             if (!this.containsStock(inName)) throw new StockExchangeException("Stock not in index.");

             foreach(Stock s in this.stocks)
             {
                 if (s.name.Equals(inName, StringComparison.OrdinalIgnoreCase))
                 {
                     this.stocks.Remove(s);
                     break;
                 }
             }
         }

         public decimal getValue(DateTime inTime)
         {
             decimal retval;

             if (this.type == IndexTypes.AVERAGE)
             {
                 decimal totalPrice = 0m;
                 long numberOfStocks = 0;

                 foreach (Stock s in this.stocks)
                 {
                     totalPrice += s.amount * s.getPrice(inTime);
                     numberOfStocks += s.amount;
                 }

                 retval= totalPrice / numberOfStocks;
             }
             else if (this.type == IndexTypes.WEIGHTED)
             {
                 decimal sum = 0m;
                 decimal factor = 0m;

                 foreach (Stock s in this.stocks)
                 {
                     factor += s.amount * s.getPrice(inTime);
                 }
                 factor=1m/factor;

                 foreach (Stock s in this.stocks)
                 { 
                    decimal p = s.getPrice(inTime);
                    sum += factor * s.amount * p * p;
                 }

                 retval= sum;
             }
             else throw new StockExchangeException("Error calculating value.");

             retval *= 1000;
             retval = (int)retval;
             retval /= 1000m;

             return retval;
         }

         public int getStocksAmount()
         {
             return this.stocks.Count;
         }
     }

     public class IndexRepository
     {
         private List<Index> indexes = new List<Index>();

         public int numberOfIndexes()
         {
             return this.indexes.Count;
         }

         public void add(Index inIndex)
         {
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inIndex.name, StringComparison.OrdinalIgnoreCase)) throw new StockExchangeException("Index already exists.");
             }

             this.indexes.Add(inIndex);
         }

         public void remove(String inName)
         { 
             Index indx = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inName, StringComparison.OrdinalIgnoreCase))
                 {
                     indx = i;
                     break;
                 }
             }

             if (indx == null) throw new StockExchangeException("No such index.");

             this.indexes.Remove(indx);
         }

         public Index get(String inName)
         {
             Index indx = null;
             foreach (Index i in this.indexes)
             {
                 if (i.name.Equals(inName, StringComparison.OrdinalIgnoreCase))
                 {
                     indx = i;
                     break;
                 }
             }

             if (indx == null) throw new StockExchangeException("No such index.");

             return indx;
         }

         public void removeStockFromAll(string inStockName)
         {
            foreach(Index i in this.indexes)
            {
                if(i.containsStock(inStockName))i.removeStock(inStockName);
            }
         }
     }

     public class Portfolio
     {
         public string ID;
         private Dictionary<Stock, long> entries;

         public Portfolio(string inID)
         {
             if (inID.Trim().Equals("")) throw new StockExchangeException("ID not allowed.");

             this.ID = inID;
             this.entries = new Dictionary<Stock, long>();
         }

         public bool containsStock(string inStockName)
         {
             foreach (Stock s in this.entries.Keys)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return true;
             }

             return false;
         }

         public void addStock(StockRepository repStock, PortfolioRepository repPortfolio, string inStockName, long inAmount)
         {
             if (inAmount <= 0) throw new StockExchangeException("Amount not permitted.");

             Stock s = repStock.get(inStockName);

             if (inAmount + repPortfolio.getTotalAmountOfStock(inStockName) > s.amount) inAmount = s.amount - repPortfolio.getTotalAmountOfStock(inStockName);

             if(this.containsStock(inStockName))
             {
                this.entries[s] += inAmount;
             }
             else
             {
                this.entries.Add(s, inAmount);
             }
         }

         public void removeStock(string inStockName)
         {
             foreach (Stock s in this.entries.Keys)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                 {
                     this.entries.Remove(s);
                     return;
                 }
             }

             throw new StockExchangeException("Doesn't contain stock.");
         }

         public void removeStockAmount(string inStockName, long inAmount)
         {
             if (!this.containsStock(inStockName) || inAmount<0) throw new StockExchangeException("Removing not possible.");

             foreach (Stock s in this.entries.Keys)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase))
                 {
                     this.entries[s] -= inAmount;

                     if (this.entries[s] <= 0) this.entries.Remove(s);

                     break;
                 }
             }
         }

         public long getAmountOfStock(string inStockName)
         {
             foreach (Stock s in this.entries.Keys)
             {
                 if (s.name.Equals(inStockName, StringComparison.OrdinalIgnoreCase)) return this.entries[s];
             }

             return 0;
         }

         public int numberOfStocks()
         {
             return this.entries.Count;
         }

         public decimal value(DateTime inTime) 
         {
             decimal val = 0m;

             foreach (Stock s in this.entries.Keys)
             {
                 val += this.entries[s] * s.getPrice(inTime);
             }

             return val;
         }
     }

     public class PortfolioRepository
     {
         private List<Portfolio> portfolios = new List<Portfolio>();

         public void removeStockFromAll(string inStockName)
         {
             foreach (Portfolio p in this.portfolios) 
             {
                 if (p.containsStock(inStockName)) 
                 {
                     p.removeStock(inStockName);
                 }
             }
         }

         public bool contains(string inID)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inID)) return true;
             }
             return false;
         }

         public void add(Portfolio inPortfolio)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inPortfolio.ID)) throw new StockExchangeException("Portfolio already exists.");
             }

             this.portfolios.Add(inPortfolio);
         }

         public void remove(string inID)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inID)) 
                 {
                     this.portfolios.Remove(p);
                     return;
                 }
             }

             throw new StockExchangeException("Portfolio doesn't exist.");
         }

         public Portfolio get(string inID)
         {
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.ID.Equals(inID)) return p;
             }
             throw new StockExchangeException("Portfolio doesn't exist.");
         }

         public int getNumberOfPortfolios()
         {
             return this.portfolios.Count;
         }

         public long getTotalAmountOfStock(string inStockName)
         {
             long amount = 0;
             foreach (Portfolio p in this.portfolios)
             {
                 if (p.containsStock(inStockName)) amount = p.getAmountOfStock(inStockName);
             }

             return amount;
         }
     }

     public class StockExchange : IStockExchange
     {
         StockRepository stockRep;
         IndexRepository indexRep;
         PortfolioRepository portfolioRep;

         public StockExchange() 
         {
             stockRep = new StockRepository();
             indexRep = new IndexRepository();
             portfolioRep = new PortfolioRepository();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock s = new Stock(inStockName, inNumberOfShares, inTimeStamp, inInitialPrice);

             stockRep.add(s);
         }

         public void DelistStock(string inStockName)
         {
             indexRep.removeStockFromAll(inStockName);
             portfolioRep.removeStockFromAll(inStockName);
             stockRep.remove(inStockName);
         }

         public bool StockExists(string inStockName)
         {

             try
             {
                 stockRep.get(inStockName);
             }
             catch(StockExchangeException e)
             {
                 return false;
             }

             return true;
         }

         public int NumberOfStocks()
         {
             return  stockRep.totalNumberOfStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock s = stockRep.get(inStockName);
             s.setPrice(inStockValue, inIimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock s = stockRep.get(inStockName);
             return s.getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock s = stockRep.get(inStockName);
             return s.getFirstPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock s = stockRep.get(inStockName);
             return s.getLastPrice();
         }

         public void CreateIndex( string inIndexName, IndexTypes inIndexType)
         {
             Index i = new Index(inIndexName, inIndexType);

             indexRep.add(i);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock s = stockRep.get(inStockName);
             Index i = indexRep.get(inIndexName);

             i.addStock(s);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index i = indexRep.get(inIndexName);

             i.removeStock(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index i = indexRep.get(inIndexName);

             return i.containsStock(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index i = indexRep.get(inIndexName);

             return i.getValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             try
             {
                 indexRep.get(inIndexName);
             }
             catch (StockExchangeException e)
             {
                 return false;
             }

             return true;
         }

         public int NumberOfIndices()
         {
             return indexRep.numberOfIndexes();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index i = indexRep.get(inIndexName);

             return i.getStocksAmount();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio p = new Portfolio(inPortfolioID);
             portfolioRep.add(p);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             p.addStock(stockRep, portfolioRep, inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             p.removeStockAmount(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             p.removeStock(inStockName);
         }

         public int NumberOfPortfolios()
         {
             return portfolioRep.getNumberOfPortfolios();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
            Portfolio p = portfolioRep.get(inPortfolioID);

             return p.numberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolioRep.contains(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             return p.containsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             return (int)p.getAmountOfStock(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             return p.value(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio p = portfolioRep.get(inPortfolioID);

             DateTime start;
             DateTime stop;

             try
             {
                 start = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                 stop = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             }
             catch (Exception e)
             {
                 throw new StockExchangeException("Wrong input for date.");
             }
             

             decimal val1 = p.value(start);
             decimal val2 = p.value(stop);

             decimal retval = 100 * (val2 / val1 - 1);

             retval *= 1000;
             retval = (int)retval;
             retval /= 1000m;

             return retval;
         }
     }
}
