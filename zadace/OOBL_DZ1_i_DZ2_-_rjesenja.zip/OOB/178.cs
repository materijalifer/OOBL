﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string display;
        private string tmp;
        private string memory;
        private char lastOperation;
        private char lastInPressedDigit;

        private static int maxDigit = 10;
        private static double maxAbs = 9999999999.5;
        private static string unaryOp = "SKTQRI";
        private static string binaryOp = "+-*/";
        private static string memoryOp = "PG";

        public Kalkulator()
        {
            Reset();
        }

        //Omogućava unos znaka
        public void Press(char inPressedDigit)
        {         
            //Resetiranje omogućeno u bilo kojem trenutku
            if (inPressedDigit == 'O')
            {
                Reset();
            }

            //Ako se dogodila greška, daljnji unos više nije moguć
            else if (this.display == "-E-")
            {
                return;
            }

            else if (inPressedDigit == 'C')
            {
                ClearDisplay();
            }

            else if (inPressedDigit >= '0' && inPressedDigit <= '9' || inPressedDigit == ',')
            {
                AddDigit(inPressedDigit);
            }

            else if (binaryOp.Contains(inPressedDigit))
            {
                //Unos binarne operacije uzrokuje izvršavanje prethodne binarne operacije
                //Prethodna se binarna operacija izvršava samo ako sljedeća binarna operacija nije unesena neposredno nakon nje
                if (!binaryOp.Contains(lastInPressedDigit))
                {
                    ExecuteBinaryOperation();
                    this.tmp = this.display;
                }
                //Pamti se zadnji uneseni binarni operator
                this.lastOperation = inPressedDigit; 
            }

            else if (inPressedDigit == '=')
            {
                ExecuteBinaryOperation();
            }

            else if (unaryOp.Contains(inPressedDigit))
            {
                ExecuteUnaryOperation(inPressedDigit);
            }
            else if (inPressedDigit == 'M')
            {
                Minus();
            }

            else if (memoryOp.Contains(inPressedDigit))
            {
                ExecuteMemoryOperation(inPressedDigit);
            }

            else
            {
                this.display = "-E-";
            }

            this.lastInPressedDigit = inPressedDigit;
        }

        //Vraća trenutni display
        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        //Promjena predznaka
        private void Minus()
        {
            if (this.display[0] == '-')
            {
                this.display = this.display.Substring(1);
            }
            else
            {
                this.display = "-" + this.display;
            }
        }

        //Dodaje znamenku ili zarez na ekran
        private void AddDigit(char inPressedDigit)
        {            
            //Nakon oznake operacije (osim promjene predznaka) započinje unos novog broja...
            if (binaryOp.Contains(this.lastInPressedDigit) || unaryOp.Contains(this.lastInPressedDigit) || this.lastInPressedDigit == 'G' || this.lastInPressedDigit == '=')
            {
                ClearDisplay();
            }

            string absDisplayVal = Math.Abs(Convert.ToDouble(this.display.Replace(',', '.'))).ToString();

            //...inače se znamenka nadovezuje na stari broj
            if (this.display.Contains(','))
            {
                if (inPressedDigit != ',' && absDisplayVal.Length < maxDigit + 1)
                {
                    this.display += inPressedDigit.ToString();
                }
            }

            else if (absDisplayVal.Length < maxDigit)
            {
                if (this.display == "0" && inPressedDigit != ',')
                {
                    this.display = inPressedDigit.ToString();
                }
                else
                {
                    this.display += inPressedDigit.ToString();
                }
            }
        }

        //Izvršava unarne operacije
        //radi nad displayem
        private void ExecuteUnaryOperation(char inPressedDigit)
        {
            double numDisplayVal = Convert.ToDouble(this.display.Replace(',','.'));
            double newDisplayVal = numDisplayVal;
            switch (inPressedDigit)
            {
                case 'S':
                    newDisplayVal = Math.Sin(numDisplayVal);
                    break;
                case 'K':
                    newDisplayVal = Math.Cos(numDisplayVal);
                    break;
                case 'T':
                    newDisplayVal = Math.Tan(numDisplayVal);
                    break;
                case 'Q':
                    newDisplayVal = Math.Pow(numDisplayVal, 2);
                    break;
                case 'R':
                    if (numDisplayVal >= 0)
                    {
                        newDisplayVal = Math.Pow(numDisplayVal, 0.5);
                    }
                    else
                    {
                        DisplayError();
                        return;
                    }
                    break;
                case 'I':
                    if (numDisplayVal != 0)
                    {
                        newDisplayVal = 1 / numDisplayVal;
                    }
                    else
                    {
                        DisplayError();
                        return;
                    }
                    break;
            }
            ChangeDisplay(newDisplayVal);
        }

        //Izvršava binarne operacije
        private void ExecuteBinaryOperation()
        {
            double numDisplayVal = Convert.ToDouble(this.display.Replace(',', '.'));
            double numTmpVal= Convert.ToDouble(this.tmp.Replace(',','.'));
            double newDisplayVal = numDisplayVal;
            switch (lastOperation)
            {
                case '+':
                    newDisplayVal = numTmpVal + numDisplayVal;
                    break;
                case '-':
                    newDisplayVal = numTmpVal - numDisplayVal;
                    break;
                case '*':
                    newDisplayVal = numTmpVal * numDisplayVal;
                    break;
                case '/':
                    if (numDisplayVal != 0)
                    {
                        newDisplayVal = numTmpVal / numDisplayVal;
                    }
                    else
                    {
                        DisplayError();
                        return;
                    }
                    break;
            }
            ChangeDisplay(newDisplayVal);
        }

        //Rad s memorijom
        private void ExecuteMemoryOperation(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'P':
                    this.memory = this.display;
                    break;
                case 'G':
                    ChangeDisplay(Convert.ToDouble(this.memory));
                    break;
            }
        }

        //Vrši zaokruživanje, brine za pravilan prikaz brojeva
        private void ChangeDisplay (double stringValue)
        {
            string stringAbsValue = Math.Abs(stringValue).ToString();
            int dotIndex = stringAbsValue.IndexOf('.');
            if (Math.Abs(stringValue) > maxAbs)
            {
                DisplayError();
                return;
            }
            else
            {
                double newValue = stringValue;
                if (dotIndex > 0)
                {
                    newValue = Math.Round(stringValue, maxDigit - dotIndex);
                }
                this.display = newValue.ToString();
            }
            this.display = this.display.Replace('.', ',');
        }

        //Vraća display na 0
        private void ClearDisplay()
        {
            this.display = "0";
        }

        //Resetira kalkulator
        private void Reset()
        {
            this.memory = "0";
            this.display = "0";
            this.tmp = "0";
            this.lastInPressedDigit = '0';
            this.lastOperation = '\0';
        }

        //Prikazuje pogrešku
        private void DisplayError()
        {
            this.display = "-E-";
        }
    }

}
