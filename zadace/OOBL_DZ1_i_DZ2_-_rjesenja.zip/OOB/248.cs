﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        enum VrstaZnaka
        {
            znamenka,
            binarnaOperacija,
            unarnaOperacija,
            jednako,
            dZarez,
            onOff,
            clear,
            memory
           
        }
       
        private static Dictionary<char, VrstaZnaka> vrsta = popuni();
      
        private static Dictionary<char, VrstaZnaka> popuni()
        {
            var d = new Dictionary<char, VrstaZnaka>();

            d['0'] = d['1'] = d['2'] = d['3'] = d['4'] = d['5'] = d['6'] = d['7'] = d['8'] = d['9'] = VrstaZnaka.znamenka;
            d['+'] = d['-'] = d['*'] = d['/'] = VrstaZnaka.binarnaOperacija;
            d['M'] = d['S'] = d['K'] = d['T'] = d['Q'] = d['R'] = d['I'] = VrstaZnaka.unarnaOperacija;
            d['='] = VrstaZnaka.jednako;
            d[','] = VrstaZnaka.dZarez;
            d['O'] = VrstaZnaka.onOff;
            d['C'] = VrstaZnaka.clear;
            d['P'] = d['G'] = VrstaZnaka.memory;

            return d;
        }
       
        private string ekran = "0"; //ekran kalkulatora
        private Nullable<double> a = null; // prvi operand
        private Nullable<double> b = null; // drugi operand
        private const int MAX_ZNAMENKI = 10; // max broj znamenki na ekranu
        private bool pritisnutaOperacija = false; // varijabla stanja kalkulatora
        private bool zatrazeniRezultat = false;  // varijabla stanja kalkulatora
        private char zadnjaOperacija;
        private Nullable<double> operandJednako = null;
        private const string FILE_NAME = "myICalculator.txt";


        public string GetCurrentDisplayState()
        {
            return ekran;
        }
        public void Press(char inPressedDigit)
        {
            VrstaZnaka Vz = vrsta[inPressedDigit];
            //provjera sto je pritisnuto i reakcija kalkulatora s obzirom na pritisnutu tipku
            switch (Vz)
            {

                case VrstaZnaka.znamenka:
                        dodajZnamenku(inPressedDigit);
                    break;
                case VrstaZnaka.binarnaOperacija:
                    obaviOperaciju(inPressedDigit);
                    break;
                case VrstaZnaka.unarnaOperacija:
                    obaviUnarnuOperaciju(inPressedDigit);
                    break;
                case VrstaZnaka.dZarez:
                    unesiDecimalniZarez();
                    break;
                case VrstaZnaka.clear:
                    ocisti();
                    break;
                case VrstaZnaka.jednako:
                    jednako();
                    break;
                case VrstaZnaka.onOff:
                    onOff();
                    break;
                case VrstaZnaka.memory:
                    memory(inPressedDigit);
                    break;

            }

        }
        private void onOff()
        {
            ekran = "0";
            a = b = operandJednako = null;
            pritisnutaOperacija = zatrazeniRezultat = false;
            File.Delete(Path.Combine(Path.GetTempPath(), FILE_NAME));
        }
        private void dodajZnamenku(char c)
        {
            if (pritisnutaOperacija)
            {
                ocistiEkran();
            }
            else if (zatrazeniRezultat)
            {
                ocistiEkran();
            }
            if (brojiZnamenke() < MAX_ZNAMENKI)
            {
                ekran += c;
                formatirajUlaz();
            }
            pritisnutaOperacija = zatrazeniRezultat = false;
        } 
        private void ocistiEkran(){
            ekran = "0";
        }
        private void formatirajUlaz()
        {
            while (ekran[0] == '0' && ekran.Length > 1)
            {
                if (ekran[1] == ',')
                {
                    break;
                }
                ekran = ekran.Substring(1);
            }

        }
        private int brojiZnamenke()
        {
           // int a=ekran.Length;
            return ekran.Count(c =>vrsta[c] == VrstaZnaka.znamenka);

        }
        private double? vrijednost()
        {
            if (ekran == "-E-")
                return null;
            return Convert.ToDouble(ekran);
        }
        private void obaviOperaciju(char c)
        {
            if (a==null)
            {
                a=vrijednost();
                ekran = formatirajIzlaz(a);
            }
            else if (b==null)
            {
                if(!pritisnutaOperacija)
                {
                    b=vrijednost();
                    izvrsiOperaciju();
                    a=vrijednost();
                    b=null;
                }
            }
            pritisnutaOperacija = true;
            zadnjaOperacija = c;
        }
        private void jednako()
        {
            operandJednako = (double?)Convert.ToDouble(ekran);
            pritisnutaOperacija = false;
            obaviOperaciju(zadnjaOperacija);
        }
        private void izvrsiOperaciju()
        {
            Nullable<double> c = null;
            switch (zadnjaOperacija)
            {
                case '+': c = a + b; break;
                case '-': c = a - b; break;
                case '*': c = a * b; break;
                case '/': if (b!=0)
                    {
                        c = a / b;
                        break;
                    }
                    else
                    {
                        ekran = "-E-";
                        break;
                    }
            }
            ekran = formatirajIzlaz(c);
            b = null;
        }
        private string formatirajIzlaz(Nullable<double> c)
        {
            
            double x;
            string f = Convert.ToString(c);
            int cjelobrojneZnamenke = izbrojiCjelobrojneZnamenke(f);
            if (cjelobrojneZnamenke>MAX_ZNAMENKI)
                return "-E-";
            x = Math.Round(c.Value, MAX_ZNAMENKI - cjelobrojneZnamenke);
            f = Convert.ToString(x);
            f.Replace('.', ',');

          //  return ukloniNule(f);
            return f;
        }
        private string ukloniNule(string f)
        {
            double x = Convert.ToDouble(f);
            int y = (int)x;
            if (y == x)
                return Convert.ToString(y);
            
            return f;

        }
        private int izbrojiCjelobrojneZnamenke(string s)
        {
            int a = 0;
            foreach(char c in s)
            {
                if (c == '-')
                    continue;
                if (c == ',')
                    break;
                a++;
            }
            return a;
        }
        private void obaviUnarnuOperaciju(char c)
        {
            switch (c)
            {
                case 'S':
                    ekran = formatirajIzlaz((double?)Math.Sin(Convert.ToDouble(ekran)));
                    break;
                case 'K':
                    ekran = formatirajIzlaz((double?)Math.Cos(Convert.ToDouble(ekran)));
                    break;
                case 'T':
                    ekran = formatirajIzlaz((double?)Math.Tan(Convert.ToDouble(ekran)));
                    break;
                case 'Q':
                    ekran = formatirajIzlaz((double?)Math.Pow((Convert.ToDouble(ekran)),2));
                    break;
                case 'R':
                    ekran = formatirajIzlaz((double?)Math.Sqrt(Convert.ToDouble(ekran)));
                    break;
                case 'I':
                    if (Convert.ToDecimal(ekran) == 0)
                    {
                        ekran = "-E-";
                        break;
                    }
                    ekran = formatirajIzlaz((double?)Math.Pow((Convert.ToDouble(ekran)),-1));
                    break;
                case 'M':
                    ekran = promjeniPredznak(ekran);
                    break;
            }
        }
        private string promjeniPredznak(string s) 
        {
            double x = Convert.ToDouble(s);
            x *= -1;
            return formatirajIzlaz((double?)x);
            //moze i ovo vjerojatno jer Convert.ToString() vraća bez nula iza dec tocke, samo treba exrea zamjenit tocku sa zarezom :-)
            //return Convert.ToString(x);
        }
        private void unesiDecimalniZarez()
        {
            if (!ekran.Contains(','))
            ekran += ',';
        }
        private void ocisti()
        {
            ekran = "0";
        }
        private void memory(char c)
        {
            if (ekran == "-E-")
                throw new NotFiniteNumberException();
            string path = Path.Combine(Path.GetTempPath(), FILE_NAME);
            if (c == 'P')
            {
                File.WriteAllText(path, ekran);
            }
            else
            {
                string a = File.ReadAllText(path);
                ekran=Convert.ToString(formatirajIzlaz((double?) Convert.ToDouble(a)));
            }
            


        }
    }


}
