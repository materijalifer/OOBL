﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
           System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
           return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public static string display="0";
        public static string displayShown = "0";
        public static string memorija = "0";

        private string Racunaj()
        {
            List<string> racun=new List<string>();
            string temp="";
            for (int i = 0; i < display.Length; i++)
            {
                if (display[i] == '+')
                {
                    racun.Add(temp);
                    racun.Add("+");
                    temp = "";
                }
                else if (display[i] == '-')
                {
                    racun.Add(temp);
                    racun.Add("-");
                    temp = "";
                }
                else if (display[i] == '*')
                {
                    racun.Add(temp);
                    racun.Add("*");
                    temp = "";
                }
                else if (display[i] == '/')
                {
                    racun.Add(temp);
                    racun.Add("/");
                    temp = "";
                }
                else
                {
                    temp += display[i];
                }
            }
            int int1, int2;
            double real1,real2;
            for (int i = 0; i < racun.Count; i++)
            {
                try
                {
                    int1 = Convert.ToInt32(racun[i]);
                }
                catch
                {
                    real1 = Convert.ToDouble(racun[i]);
                }
                try
                {
                    int2 = Convert.ToInt32(racun[i+2]);
                }
                catch
                {
                    real2 = Convert.ToDouble(racun[i+2]);
                }
                if (racun[i + 1] == "+")
                {
                    return "0";
                }
                else if (racun[i + 1] == "-")
                {
                    return "0";
                }
                else if (racun[i + 1] == "*")
                {
                    return "0";
                }
                else if (racun[i + 1] == "/")
                {
                    return "0";
                }
            }
                return "0";
        }

        private Boolean ProvjeriNule()
        {
            string provjera="0";
            for (int i = 0; i < 10; i++)
            {
                if (display.Equals(provjera))
                {
                    return true;
                }
                provjera += "0";
            }
            return false;
        }

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'S')
            {
                display = (Math.Round(Math.Sin(Convert.ToDouble(display)), 9)).ToString();
            }
            else if (inPressedDigit == 'K')
            {
                display = (Math.Round(Math.Cos(Convert.ToDouble(display)), 9)).ToString();
            }
            else if (inPressedDigit == 'T')
            {
                display = (Math.Round(Math.Tan(Convert.ToDouble(display)), 9)).ToString();
            }
            else if (inPressedDigit == 'Q')
            {
                try
                {
                    display = (Convert.ToInt32(display) * Convert.ToInt32(display)).ToString();
                }
                catch
                {
                    display = (Math.Round(Convert.ToDouble(display) * Convert.ToDouble(display), 9)).ToString();
                }
            }
            else if (inPressedDigit == 'R')
            {
                display = (Math.Round(Math.Sqrt(Convert.ToDouble(display)), 9)).ToString();
            }
            else if (inPressedDigit == 'I')
            {
                display = (Math.Round(1/(Convert.ToDouble(display)), 9)).ToString();
            }
            else if (ProvjeriNule())
            {
                if (inPressedDigit == '=')
                {
                    display=Racunaj();
                }
                else if (inPressedDigit == ',')
                {
                    display = "0,";
                }
                else
                {
                    display = inPressedDigit.ToString();
                }
            }
            else
            {
                if (inPressedDigit == '=')
                {
                    display=Racunaj();
                }
                else if (inPressedDigit == 'P')
                {
                    memorija = display;
                }
                else if (inPressedDigit == 'G')
                {
                    display = memorija;
                }
                else if (inPressedDigit == 'M')
                {
                    string temp=display;
                    try
                    {
                        int brojInt = Convert.ToInt32(temp);
                        brojInt *= -1;
                        display = brojInt.ToString();
                    }
                    catch
                    {
                        double brojReal = Convert.ToDouble(temp);
                        brojReal *= -1;
                        display = brojReal.ToString();
                    }
                }
                else
                {
                    //if (display.Length <= 10)
                    //{
                        display += inPressedDigit;
                    //}
                }
            }
            if (inPressedDigit=='O')
            {
                display = "0";
                memorija = "0";
            }
            if (inPressedDigit == 'C')
            {
                display = "0";
            }
        }

        public string GetCurrentDisplayState()
        {
            string temp;
            if (display.Length > 10)
            {
                temp = display.Substring(0, 12);
            }
            else
            {
                temp = display;
            }
            display = "0";
            return temp;
        }
    }


}
