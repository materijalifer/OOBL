﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string Name { get; set; }
        public long NumberOfShares { get; set; }
        public long NumberOfSharesInPortfolios { get; set; }
        private SortedDictionary<DateTime, decimal> _dicPrices = new SortedDictionary<DateTime, decimal>(); 

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Name = inStockName;
            NumberOfShares = inNumberOfShares;
            NumberOfSharesInPortfolios = 0;
            _dicPrices.Add(inTimeStamp, inInitialPrice);
        }

        public void SetPrice(decimal inPrice, DateTime inDate)
        {
            if (_dicPrices.ContainsKey(inDate))
                _dicPrices[inDate] = inPrice;
            else
                _dicPrices.Add(inDate, inPrice);
        }

        public decimal GetPrice(DateTime inDate)
        {
            if (inDate < _dicPrices.First().Key)
                throw new StockExchangeException("Cijena nije definirana.");

            decimal price = 0m;
            foreach (KeyValuePair<DateTime, decimal> kvp in _dicPrices)
            {
                if (kvp.Key < inDate)
                    price = kvp.Value;
                else
                    break;
            }

            return price;
        }

        public decimal GetInitialPrice()
        {
            return _dicPrices.First().Value;
        }

        public decimal GetLastPrice()
        {
            return _dicPrices.Last().Value;
        }


    }

    public class Index
    {
        public string Name { get; set; }
        public IndexTypes IndexType { get; set; }
        private List<Stock> _listStocksInIndex = new List<Stock>(); 
 
        public Index(string inName, IndexTypes inIndexType)
        {
            Name = inName;
            IndexType = inIndexType;
        }

        public int GetNumberOfStocks()
        {
            return _listStocksInIndex.Count;
        }

        public void AddStock(Stock inStock)
        {
            foreach (Stock stock in _listStocksInIndex)
                if (stock.Name == inStock.Name)
                    throw new StockExchangeException("Dionica je već dodana indeksu.");

            _listStocksInIndex.Add(inStock);
        }

        public void RemoveStock(Stock inStock)
        {
            if (!IsStockPart(inStock))
                throw new StockExchangeException("Dionica nije dodana indeksu.");
            else
                _listStocksInIndex.Remove(inStock);
        }

        public bool IsStockPart(Stock inStock)
        {
            foreach (Stock stock in _listStocksInIndex)
                if (stock.Name == inStock.Name)
                    return true;

            return false;
        }

        public decimal GetAverage(DateTime inTimeStamp)
        {
            decimal result = 0;

            if (IndexType == IndexTypes.AVERAGE)
            {
                decimal pricesSum = 0;
                long numberOfStocks = 0;

                foreach (Stock stock in _listStocksInIndex)
                {
                    pricesSum += stock.GetPrice(inTimeStamp);
                    numberOfStocks++;
                }

                if (numberOfStocks != 0)
                    result = Math.Round(pricesSum / numberOfStocks, 3);
            }
            else if (IndexType == IndexTypes.WEIGHTED)
            {
                decimal pricesSum = 0;
                decimal average = 0;

                foreach (Stock stock in _listStocksInIndex)
                {
                    pricesSum += stock.GetPrice(inTimeStamp) * stock.NumberOfShares;
                }

                foreach (Stock stock in _listStocksInIndex)
                {
                    average += stock.GetPrice(inTimeStamp) * stock.NumberOfShares / pricesSum * stock.GetPrice(inTimeStamp);
                }

                result = Math.Round(average, 3);
            }

            return result;
        }

    }

    public class Portfolio
    {
        public string ID { get; set; }
        Dictionary<Stock, int> _dicStocksInPortfolio = new Dictionary<Stock, int>();

        public Portfolio(string inPortfolioID)
        {
            ID = inPortfolioID;
        }

        public void AddStock(Stock inStock, int inNumberOfShares)
        {
            if (inStock.NumberOfSharesInPortfolios + inNumberOfShares <= inStock.NumberOfShares)
            {
                if (_dicStocksInPortfolio.ContainsKey(inStock))
                    _dicStocksInPortfolio[inStock] += inNumberOfShares;
                else
                    _dicStocksInPortfolio.Add(inStock, inNumberOfShares);
            }
            else
            {
                throw new StockExchangeException("Preveliki broj zadanih dionica.");
            }
        }

        public bool IsStockPart(Stock inStock)
        {
            if (_dicStocksInPortfolio.ContainsKey(inStock))
                return true;

            return false;
        }

        public int GetNumberOfStocks()
        {
            return _dicStocksInPortfolio.Count;
        }

        public int GetNumberOfSharesOfStock(Stock inStock)
        {

            if (IsStockPart(inStock))
                return _dicStocksInPortfolio[inStock];
            else
                throw new StockExchangeException("Zadana dionica nije u portfelju.");
        }

        public void RemoveStock(Stock inStock)
        {
            if (IsStockPart(inStock))
            {
                inStock.NumberOfSharesInPortfolios -= _dicStocksInPortfolio[inStock];
                _dicStocksInPortfolio.Remove(inStock);
            }
            else
                throw new StockExchangeException("Zadana dionica nije u portfelju.");
        }

        public void RemoveSharesOfStock(Stock inStock, int inNumberOfShares)
        {
            if (IsStockPart(inStock))
            {
                int numberOfSharesOfStock = _dicStocksInPortfolio[inStock];

                if (numberOfSharesOfStock == inNumberOfShares)
                {
                    inStock.NumberOfSharesInPortfolios -= numberOfSharesOfStock;
                    _dicStocksInPortfolio.Remove(inStock);
                }
                else if (numberOfSharesOfStock < inNumberOfShares)
                {
                    throw new StockExchangeException("Nije moguće izbrisati više dionica nego ih postoji.");
                }
                else if (numberOfSharesOfStock > inNumberOfShares)
                {
                    inStock.NumberOfSharesInPortfolios -= inNumberOfShares;
                    _dicStocksInPortfolio[inStock] = numberOfSharesOfStock - inNumberOfShares;
                }
            }
            else
                throw new StockExchangeException("Zadana dionica nije u portfelju.");
        }

        public decimal GetValue(DateTime inTimeStamp)
        {
            decimal valueSum = 0m;

            foreach (KeyValuePair<Stock, int> kvp in _dicStocksInPortfolio)
            {
                valueSum += kvp.Key.GetPrice(inTimeStamp)*kvp.Value;
            }

            return valueSum;
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> _listStocks = new List<Stock>();
         List<Index> _listIndices = new List<Index>();
         List<Portfolio> _listPortfolios = new List<Portfolio>();

         public Stock GetStockByName(string inStockName)
         {
             foreach (Stock stock in _listStocks)
                 if (stock.Name == inStockName)
                     return stock;
             
             throw new StockExchangeException("Dionica sa zadanim imenom ne postoji.");
         }

         public Index GetIndexByName(string inIndexName)
         {
             foreach (Index index in _listIndices)
                 if (index.Name == inIndexName)
                     return index;

             throw new StockExchangeException("Indeks sa zadanim imenom ne postoji.");
         }

         public Portfolio GetPortfolioByID(string inPortfolioID)
         {
             foreach (Portfolio portfolio in _listPortfolios)
                 if (portfolio.ID == inPortfolioID)
                     return portfolio;

             throw new StockExchangeException("Portfolio sa zadanim ID-om ne postoji.");
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             string nameAllCaps = inStockName.ToUpper();

             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica mora biti veći od 0.");

             if (inInitialPrice <= 0)
                 throw new StockExchangeException("Cijena dionice mora biti veća od 0.");

             Stock newStock = new Stock(nameAllCaps, inNumberOfShares, inInitialPrice, inTimeStamp);

             foreach (Stock stock in _listStocks)
                 if (stock.Name == newStock.Name)
                     throw new StockExchangeException("Dionica s istim imenom već postoji.");

             _listStocks.Add(newStock);
         }

         public void DelistStock(string inStockName)
         {
             string nameAllCaps = inStockName.ToUpper();
             Stock stock = GetStockByName(nameAllCaps);

             _listStocks.Remove(stock);

             foreach (Portfolio portfolio in _listPortfolios)
             {
                 if (portfolio.IsStockPart(stock))
                     portfolio.RemoveStock(stock);
             }

             foreach (Index index in _listIndices)
             {
                 if (index.IsStockPart(stock))
                     index.RemoveStock(stock);
             }

         }

         public bool StockExists(string inStockName)
         {
             string nameAllCaps = inStockName.ToUpper();

             try
             {
                 GetStockByName(nameAllCaps);
                 return true;
             }
             catch (StockExchangeException)
             {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return _listStocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             string nameAllCaps = inStockName.ToUpper();
             Stock stock = GetStockByName(nameAllCaps);

             if (inStockValue <= 0)
                 throw new StockExchangeException("Cijena dionice mora biti veća od 0.");

             stock.SetPrice(inStockValue, inTimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             string nameAllCaps = inStockName.ToUpper();
             Stock stock = GetStockByName(nameAllCaps);

             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             string nameAllCaps = inStockName.ToUpper();
             Stock stock = GetStockByName(nameAllCaps);

             return stock.GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             string nameAllCaps = inStockName.ToUpper();
             Stock stock = GetStockByName(nameAllCaps);

             return stock.GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!Enum.IsDefined(typeof(IndexTypes), inIndexType))
                 throw new StockExchangeException("Tip indeksa nije dopušten.");

             string nameAllCaps = inIndexName.ToUpper();
             Index newIndex = new Index(nameAllCaps, inIndexType);

             foreach (Index index in _listIndices)
                 if (index.Name == newIndex.Name)
                     throw new StockExchangeException("Indeks s istim imenom već postoji.");

             _listIndices.Add(newIndex);

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             string indexNameAllCaps = inIndexName.ToUpper();
             string stockNameAllCaps = inStockName.ToUpper();

             Index index = GetIndexByName(indexNameAllCaps);
             Stock stock = GetStockByName(stockNameAllCaps);

             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             string indexNameAllCaps = inIndexName.ToUpper();
             string stockNameAllCaps = inStockName.ToUpper();

             Index index = GetIndexByName(indexNameAllCaps);
             Stock stock = GetStockByName(stockNameAllCaps);

             index.RemoveStock(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             string indexNameAllCaps = inIndexName.ToUpper();
             string stockNameAllCaps = inStockName.ToUpper();

             Index index = GetIndexByName(indexNameAllCaps);
             Stock stock = GetStockByName(stockNameAllCaps);

             return index.IsStockPart(stock);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             string indexAllCaps = inIndexName.ToUpper();
             Index index = GetIndexByName(indexAllCaps);

             return index.GetAverage(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             string nameAllCaps = inIndexName.ToUpper();

             try
             {
                 GetIndexByName(nameAllCaps);
                 return true;
             }
             catch (StockExchangeException)
             {
                 return false;
             }
         }

         public int NumberOfIndices()
         {
             return _listIndices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             string nameAllCaps = inIndexName.ToUpper();
             Index index = GetIndexByName(nameAllCaps);

             return index.GetNumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio newPortfolio = new Portfolio(inPortfolioID);

             foreach (Portfolio portfolio in _listPortfolios)
                 if (portfolio.ID == newPortfolio.ID)
                     throw new StockExchangeException("Portfolio s istim imenom već postoji.");

             _listPortfolios.Add(newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int inNumberOfShares)
         {
             string stockNameAllCaps = inStockName.ToUpper();

             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica mora biti veći od 0.");

             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             Stock stock = GetStockByName(stockNameAllCaps);

             portfolio.AddStock(stock, inNumberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int inNumberOfShares)
         {
             string stockNameAllCaps = inStockName.ToUpper();

             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             Stock stock = GetStockByName(stockNameAllCaps);

             portfolio.RemoveSharesOfStock(stock, inNumberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             string stockNameAllCaps = inStockName.ToUpper();

             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             Stock stock = GetStockByName(stockNameAllCaps);

             portfolio.RemoveStock(stock);
         }

         public int NumberOfPortfolios()
         {
             return _listPortfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             return portfolio.GetNumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             try
             {
                 GetPortfolioByID(inPortfolioID);
                 return true;
             }
             catch (StockExchangeException)
             {
                 return false;
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             string stockNameAllCaps = inStockName.ToUpper();

             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             Stock stock = GetStockByName(stockNameAllCaps);

             return portfolio.IsStockPart(stock);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             string stockNameAllCaps = inStockName.ToUpper();

             Portfolio portfolio = GetPortfolioByID(inPortfolioID);
             Stock stock = GetStockByName(stockNameAllCaps);

             return portfolio.GetNumberOfSharesOfStock(stock);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = GetPortfolioByID(inPortfolioID);

             return portfolio.GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime timeStamp = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             decimal startValue = GetPortfolioValue(inPortfolioID, timeStamp);

             timeStamp = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
             decimal endValue = GetPortfolioValue(inPortfolioID, timeStamp);

             decimal result = (endValue - startValue) / startValue * 100;
             return Math.Round(result, 3);
         }
     }
}
