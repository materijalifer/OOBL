﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public static class Util
    {
        public static void RaiseException(string text)
        {
            throw new StockExchangeException(text);
        }
    }

    public class StockIndex
    {
        private List<Stock> _stockList;
        private string _name;
        private IndexTypes _type;

        public StockIndex(string name, IndexTypes type)
        {
            checkType(type);
            _stockList = new List<Stock>();
            this._name = name;
            this._type = type;
        }

        private void checkType(IndexTypes type)
        {
            switch(type)
            {
                case IndexTypes.AVERAGE:
                    break;
                case IndexTypes.WEIGHTED:
                    break;
                default:
                    Util.RaiseException("Index Type is not valid");
                    break;
            }
        }

        public bool ContainsStock(Stock stock)
        {
            return _stockList.Contains(stock);
        }

        public void AddStock(Stock stock)
        {
            //ovdje se isto provjerava da li je vec stock u indexu, iako se u klasi StockExchange koja koristi ovu metodu, to vec iskljuci
            //zato jer je to u stvari problem domene klase StockIndex, dok klasa StockExchange provjerava da neki drugi index kojeg sadrzi 
            //vec ne koristi taj stock
            if(!ContainsStock(stock))
            {
                _stockList.Add(stock);
            }
            else
            {
                Util.RaiseException("Stock already exists in this index!");
            }
        }


        public int StockCount()
        {
            return _stockList.Count;
        }

        public void RemoveStock(Stock stock)
        {
            if (ContainsStock(stock))
            {
                _stockList.Remove(stock);
            }
            else
            {
                Util.RaiseException("Stock is not part of this index!");
            }
        }

        public decimal GetIndexValue(DateTime inTimeStamp)
        {
            if(_type == IndexTypes.AVERAGE)
            {
                return averageValue(inTimeStamp);
            }
            return weightedValue(inTimeStamp);
        }

        private decimal averageValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            foreach(Stock stock in _stockList)
            {
                sum += stock.GetStockPrice(inTimeStamp);
            }

            return sum/_stockList.Count;
        }

        private decimal weightedValue(DateTime inTimeStamp)
        {
            decimal sum = 0;
            decimal value = 0;
            foreach (Stock stock in _stockList)
            {
                decimal price = stock.GetStockPrice(inTimeStamp);
                sum += price * price * stock.StockCount;
                value += price*stock.StockCount;
            }

            return sum / value;
        }
    }

    public class Stock : IEquatable<Stock>
     {
         string _name;
         private long _stockCount;
         SortedDictionary<DateTime, decimal> _priceHistory;
        private decimal _initialPrice;
        private DateTime _timeStamp;

         public Stock(string name, long stockCount, decimal initialPrice, DateTime timeStamp)
         {
             if ( initialPrice <= decimal.Zero)
             {
                 throw new StockExchangeException("Price must be positive!");
             }
             if (stockCount <= decimal.Zero)
             {
                 throw new StockExchangeException("Stock count must be positive!");
             }
             _priceHistory = new SortedDictionary<DateTime, decimal>()
             {
                 { timeStamp, initialPrice }
             };
             this._name = name;
             this._stockCount = stockCount;
             this._initialPrice = initialPrice;
             this._timeStamp = timeStamp;
         }

         public string Name
         {
             get { return _name; }
         }

         public long InitialPrice
         {
             get { return _stockCount; }
         }

        public long StockCount
        {
            get { return _stockCount; }
        }

        public DateTime TimeStamp
        {
            get { return _timeStamp; }
            set { _timeStamp = value;  }
        }

         public void SetPrice(DateTime timeStamp, Decimal stockValue)
         {
             if(_priceHistory.ContainsKey(timeStamp))
             {
                 Util.RaiseException("Price already set for this timeStamp!");
             }
             _priceHistory.Add(timeStamp, stockValue);
         }
     
        public bool  Equals(Stock other)
        { 
 	        if (this == other)
            {
			    return true;
            }

		    if (other == null)
            {
			    return false;
            }

		    if (_name == null) {
			    if (other._name != null)
				    return false;
		    } else if (!_name.Equals(other.Name))
            {
			    return false;
            }
		    return true;
        }

        public decimal GetStockPrice(DateTime inTimeStamp)
        {
            DateTime min = _priceHistory.Keys.ElementAt(0);
            if(min.CompareTo(inTimeStamp) > 0)
            {
                Util.RaiseException("No price defined for te stock");
            }
            decimal stockPrice = _priceHistory.Values.ElementAt(_priceHistory.Count - 1);
            foreach(DateTime date in _priceHistory.Keys)
            {
                if(date.CompareTo(inTimeStamp) <= 0)
                {
                   _priceHistory.TryGetValue(date, out stockPrice);
                }
            }
            return stockPrice;
        }
     }

    public class Portfolio
    {
        private string inPortfolioID;
        Dictionary<string, Stock> _allStocks;
        Dictionary<string, long> _stockCount;

        public Portfolio(string inPortfolioID)
        {
            // TODO: Complete member initialization
            this.inPortfolioID = inPortfolioID;
            _allStocks = new Dictionary<string, Stock>();
            _stockCount = new Dictionary<string, long>();
        }

        public void Add(Stock stock, long numberOfShares)
        {
           if(!_allStocks.ContainsValue(stock))
           {
               _allStocks.Add(stock.Name, stock);
               _stockCount.Add(stock.Name, numberOfShares);
           }
           else
           {
               _stockCount[stock.Name] += numberOfShares;
           }
        }

        public long StockNumber(string stockName)
        {
            if(!_allStocks.ContainsKey(stockName))
            {
                return 0;
            }
            else
            {
                return _stockCount[stockName];
            }
        }

        public bool ContainsStock(string inPortfolioID)
        {
            return _allStocks.ContainsKey(inPortfolioID);
        }

        internal void Remove(Stock stock, int numberOfShares)
        {
            if(_allStocks.ContainsKey(stock.Name))
            {
                long value = _stockCount[stock.Name];
                if (value < numberOfShares)
                {
                    Util.RaiseException("Not enogh stocks in portfolio!");
                }
                else
                {
                    _stockCount[stock.Name] -= numberOfShares;
                    if (_stockCount[stock.Name] == 0)
                    {
                        Remove(stock);
                    }
                }
            }
            else
            {
                Util.RaiseException("Portfolio doesn't have this stock!");
            }
        }

        public void Remove(Stock stock)
        {
            _stockCount.Remove(stock.Name);
            _allStocks.Remove(stock.Name);
        }

        public int StockCount()
        {
            return _allStocks.Count;
        }

        public decimal getValue(DateTime timeStamp)
        {
            decimal value = 0;

            foreach(string portfolioId in _allStocks.Keys)
            {
                value += _allStocks[portfolioId].GetStockPrice(timeStamp)*_stockCount[portfolioId];
            }

            return value;
        }
    }

    public class StockExchange : IStockExchange
     {
         Dictionary<string, Stock> _allStocks;
         Dictionary<string, long> _stockCount;

         Dictionary<string, StockIndex> _allStockIndexes;

         private Dictionary<string, Portfolio> _allPortfoli; 

         public StockExchange()
         {
             _allStocks = new Dictionary<string, Stock>();
             _stockCount = new Dictionary<string, long>();
             _allStockIndexes = new Dictionary<string, StockIndex>();
             _allPortfoli = new Dictionary<string, Portfolio>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!_allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 _allStocks.Add(inStockName.ToUpper(), new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
                 _stockCount.Add(inStockName.ToUpper(), inNumberOfShares);
             }
             else
             {
                 Util.RaiseException("Stock already exsits!");
             }
         }

         public void DelistStock(string inStockName)
         {
             if (_allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 if(!stockIsUsed(inStockName))
                 {
                     _allStocks.Remove(inStockName.ToUpper());
                     _stockCount.Remove(inStockName.ToUpper());
                 }
                 else
                 {
                     Util.RaiseException("Stock is used in prtfolios or indicies");
                 }
             }
             else
             {
                 Util.RaiseException("Stock doesn't exsits!");
             }
         }

         public bool StockExists(string inStockName)
         {
             return _allStocks.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return _allStocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = getStock(inStockName);
             stock.SetPrice(inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = getStock(inStockName);
             decimal stockPrice = stock.GetStockPrice(inTimeStamp);
             return Math.Round(stockPrice, 3, MidpointRounding.AwayFromZero);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = getStock(inStockName);
             decimal initialStockPrice = stock.InitialPrice;
             return Math.Round(initialStockPrice, 3, MidpointRounding.AwayFromZero); ;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             decimal lastPrice = GetStockPrice(inStockName, DateTime.Now);
             return Math.Round(lastPrice, 3, MidpointRounding.AwayFromZero); ;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (!_allStockIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 _allStockIndexes.Add(inIndexName.ToUpper(), new StockIndex(inIndexName, inIndexType));
             }
             else
             {
                 Util.RaiseException("Stock Index with that name already exsits!");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             StockIndex index = getStockIndex(inIndexName);
             Stock stock = getStock(inStockName);
             foreach(StockIndex stockIndex in _allStockIndexes.Values)
             {
                 if(stockIndex.ContainsStock(stock))
                 {
                     Util.RaiseException("Stock is already in other index!");
                 }
             }
             index.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             StockIndex index = getStockIndex(inIndexName);
             Stock stock = getStock(inStockName);

             index.RemoveStock(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             StockIndex index = getStockIndex(inIndexName);
             Stock stock = getStock(inStockName);

             return index.ContainsStock(stock);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             StockIndex index = getStockIndex(inIndexName);
             return Math.Round(index.GetIndexValue(inTimeStamp), 3, MidpointRounding.AwayFromZero); ;
         }

         public bool IndexExists(string inIndexName)
         {
             return _allStockIndexes.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _allStockIndexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             StockIndex index = getStockIndex(inIndexName);
             return index.StockCount();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!_allPortfoli.ContainsKey(inPortfolioID))
             {
                 _allPortfoli.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
             else
             {
                 Util.RaiseException("Portfolio with that name already exsits!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock stock = getStock(inStockName);
             Portfolio portfolio = getPortfolio(inPortfolioID);

             long sum = 0;
             long maxStockNum;
             _stockCount.TryGetValue(inStockName, out maxStockNum);
             foreach (Portfolio port in _allPortfoli.Values)
             {
                 sum += port.StockNumber(inStockName);
             }

             if(maxStockNum < sum + numberOfShares)
             {
                 Util.RaiseException("Prevelik broj dionica");
             }

             portfolio.Add(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Stock stock = getStock(inStockName);
             Portfolio portfolio = getPortfolio(inPortfolioID);

             portfolio.Remove(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Stock stock = getStock(inStockName);
             Portfolio portfolio = getPortfolio(inPortfolioID);

             portfolio.Remove(stock);
         }

         public int NumberOfPortfolios()
         {
             return _allPortfoli.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             return portfolio.StockCount();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _allPortfoli.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Stock stock = getStock(inStockName);
             Portfolio portfolio = getPortfolio(inPortfolioID);

             return portfolio.ContainsStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Stock stock = getStock(inStockName);
             Portfolio portfolio = getPortfolio(inPortfolioID);

             return (int) portfolio.StockNumber(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);

             decimal value = portfolio.getValue(timeStamp);

             return Math.Round(value, 3, MidpointRounding.AwayFromZero); ;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = getPortfolio(inPortfolioID);
             int daysInMonth = DateTime.DaysInMonth(Year, Month);

             decimal startOfMonth = portfolio.getValue(new DateTime(Year, Month,1, 0, 0, 0));
             decimal endOfMonth = portfolio.getValue(new DateTime(Year, Month, daysInMonth, 23, 59, 99, 999));

             decimal change = ((startOfMonth - endOfMonth)/startOfMonth)*100;

             return Math.Round(change, 3, MidpointRounding.AwayFromZero); ;
         }

         private Stock getStock(string inStockName)
         {
             Stock stock = null;
             if (_allStocks.ContainsKey(inStockName.ToUpper()))
             {
                 try
                 {
                     _allStocks.TryGetValue(inStockName.ToUpper(), out stock);
                    
                 }
                 catch
                 {
                     Util.RaiseException("Stock doesn't exists!");
                 }
             }
             else
             {
                 Util.RaiseException("Stock doesn't exsits!");
             }
             return stock;
         }

         private StockIndex getStockIndex(string inIndexName)
         {
             StockIndex index = null;
             if (_allStockIndexes.ContainsKey(inIndexName.ToUpper()))
             {
                 try
                 {
                     _allStockIndexes.TryGetValue(inIndexName.ToUpper(), out index);

                 }
                 catch
                 {
                     Util.RaiseException("Stock index doesn't exists!");
                 }
             }
             else
             {
                 Util.RaiseException("Stock index doesn't exsits!");
             }
             return index;
         }

         private Portfolio getPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = null;
             if (_allPortfoli.ContainsKey(inPortfolioID))
             {
                 try
                 {
                     _allPortfoli.TryGetValue(inPortfolioID, out portfolio);
                 }
                 catch
                 {
                     Util.RaiseException("Portfolio with Id=" + inPortfolioID + " doesn't exists!");
                 }
             }
             else
             {
                 Util.RaiseException("Portfolio with Id=" + inPortfolioID + " doesn't exists!");
             }
             return portfolio;
         }

         private bool stockIsUsed(string inStockName)
         {
             Stock stock = getStock(inStockName);

             foreach (StockIndex index in _allStockIndexes.Values)
             {
                 if(index.ContainsStock(stock))
                 {
                     return true;
                 }
             }

             foreach (Portfolio portfolio in _allPortfoli.Values)
             {
                 if (portfolio.ContainsStock(inStockName))
                 {
                     return true;
                 }
             }

             return false;
         }
    }
}
