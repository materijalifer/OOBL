﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> Dionice = new List<Stock>();
         List<Portfolio> Portfelji = new List<Portfolio>(); 
         List<Index> Indices = new List<Index>(); 

         public void ListStock(string inStockName, long inNumberOfShares, decimal Price, DateTime inTimeStamp)
         {
             foreach (Stock Dionica in Dionice)
             {
                 if(Dionica.inStockName.ToLower() == inStockName.ToLower())
                     throw new StockExchangeException("nemogu se dvije dionice zvat istim imenom!");
             }
             if (inNumberOfShares > 0 && Price > 0)
             {
                 Dionice.Add(new Stock(inStockName, inNumberOfShares, Price, inTimeStamp));
                 Stock d = Dionice.Last();
                 d.vrijednostiVremenski.Add(inTimeStamp, Price);
             }
             else
                 throw new StockExchangeException("nemoze broj dionicia ili pocetna cjena bit manja ili jednaka nuli!");
         }

         public void DelistStock(string inStockName)
         {
             bool erased = false;
             Stock zaBrisanje = new Stock();
             foreach (Stock s in Dionice)
             {
                 if (s.inStockName.ToLower() == inStockName.ToLower())
                 {
                     zaBrisanje = s;
                     erased = true;
                     break;
                 }
             }
             Dionice.Remove(zaBrisanje);
             foreach (Index i in Indices)
             {
                 foreach (Stock ss in i.Dionice)
                 {
                     if (ss.inStockName.ToLower() == zaBrisanje.inStockName.ToLower())
                     {
                         i.Dionice.Remove(ss);
                         break;
                     }
                 }
             }
             foreach (Portfolio p in Portfelji)
             {
                 foreach (StockInPortfolio sp in p.DioniceUPortfelju)
                 {
                     if (sp.inStockName.ToLower() == zaBrisanje.inStockName.ToLower())
                     {
                         p.DioniceUPortfelju.Remove(sp);
                         break;
                     }
                 }
             }
             if(erased == false)
                 throw new StockExchangeException("nepostoji dionica sa danim nazivom");
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock Dionica in Dionice)
             {
                 if (Dionica.inStockName.ToLower() == inStockName.ToLower())
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return Dionice.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             foreach (Stock s in Dionice)
             {
                 if (s.inStockName.ToLower() == inStockName.ToLower())
                 {
                     s.inTimeStamp = inIimeStamp;
                     s.Price = inStockValue;
                     s.vrijednostiVremenski.Add(s.inTimeStamp,s.Price);
                 }
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             foreach (Stock s in Dionice)
             {
                 if (s.inStockName.ToLower() == inStockName.ToLower())
                 {
                     List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                     Vremena.Sort();
                     for (int i = 0; i < Vremena.Count -1 ;i++)
                     {
                         if (Vremena[i] < inTimeStamp && inTimeStamp < Vremena[i + 1])
                         {
                             return s.vrijednostiVremenski[Vremena[i]];
                         }
                     }
                     return s.vrijednostiVremenski[Vremena.Last()];
                 }
             }
                 throw new StockExchangeException("ne postoji dionica sa danim imenom");


         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock s in Dionice)
             {
                 if (s.inStockName.ToLower() == inStockName.ToLower())
                 {
                     List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                     Vremena.Sort();
                     return s.vrijednostiVremenski[Vremena.First()];
                 }
                     
             }
             throw new StockExchangeException("ne postoji dionica sa tim imenom");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Stock s in Dionice)
             {
                 if (s.inStockName.ToLower() == inStockName.ToLower())
                 {
                     List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                     Vremena.Sort();
                     return s.vrijednostiVremenski[Vremena.Last()];
                 }
            }
             throw new StockExchangeException("ne postoji dionica sa tim imenom");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             foreach (Index i in Indices)
             {
                 if(i.indexName.ToLower()==inIndexName.ToLower())
                     throw new StockExchangeException("postoji index sa ovim imenom vec");
             }
             Indices.Add(new Index(inIndexName,inIndexType));

             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             bool dodano = false;
             foreach (Index i in Indices)
             {
                 if (i.indexName.ToLower() == inIndexName.ToLower())
                 {
                     foreach (Stock s in Dionice)
                     {
                         if(s.inStockName.ToLower() == inStockName.ToLower())
                         {
                             foreach (Stock ss in i.Dionice)
                             {
                                 if(ss.inStockName.ToLower()==s.inStockName.ToLower())
                                   throw new StockExchangeException("ta dionica vec postoji u tom indexu");
                             }
                             i.Dionice.Add(s);
                             dodano = true;
                         }
                     }
                 }
             }
             if(dodano == false)
                 throw new StockExchangeException("opop, nepostoji ta dionica!");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             bool postojiIndex = false;
             bool postojiDionica = false;
             foreach (Index i in Indices)
             {
                 if (i.indexName.ToLower() == inIndexName.ToLower())
                 {
                     postojiIndex = true;
                     foreach (Stock s in i.Dionice)
                     {
                         if (s.inStockName.ToLower() == inStockName.ToLower())
                         {
                             postojiDionica = true;
                             i.Dionice.Remove(s);
                             break;
                         }
                     }
                 }
             }
             if(postojiDionica==false)
                 throw new StockExchangeException("nepostoji dionica sa tim nazivom");
             if(postojiIndex == false)
                 throw new StockExchangeException("nepostoji indeks sa tim nazivom");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             bool postojiIndex = false;
             foreach (Index i in Indices)
             {
                 if (i.indexName.ToLower() == inIndexName.ToLower())
                 {
                     postojiIndex = true;
                     foreach (Stock s in i.Dionice)
                     {
                         if (s.inStockName.ToLower() == inStockName.ToLower())
                             return true;
                     }
                 }
             }
             if(postojiIndex == false)
                 throw new StockExchangeException("nepostoji taj index!");
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             double weightedValue = 0;
             foreach (Index i in Indices)
             {
                if (i.indexName.ToLower() == inIndexName.ToLower())
                 {
                     Dictionary<decimal,long> Dionicesabrojem = new Dictionary<decimal,long>();

                     if (i.tipIndexa == IndexTypes.WEIGHTED)
                     {
                         foreach (Stock s in i.Dionice)
                         {
                             List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                             Vremena.Sort();
                             
                             bool zadnje_vrijeme = true;
                             for (int j = 0; j < Vremena.Count - 1; j++)
                             {
                                 if (Vremena[j] < inTimeStamp && inTimeStamp < Vremena[j + 1])
                                 {
                                     zadnje_vrijeme = false;
                                     Dionicesabrojem.Add(s.vrijednostiVremenski[Vremena[j]], s.inNumberOfShares);
                                 }
                             }
                             if(zadnje_vrijeme == true)
                                 Dionicesabrojem.Add(s.vrijednostiVremenski[Vremena.Last()],s.inNumberOfShares);
                         }
                         //izracun
                         double ukupnaVrijednost=0;
                         foreach(KeyValuePair<decimal,long> D in Dionicesabrojem)
                         {
                             ukupnaVrijednost += (double)D.Key * D.Value;
                         }
                         weightedValue = 0;
                         foreach (KeyValuePair<decimal, long> D in Dionicesabrojem)
                         {
                             for (int k=0; k < D.Value; k++)
                             {
                                 weightedValue += (double) D.Key*((double)D.Key/ukupnaVrijednost);
                             }
                         }
                     }

                     else  if (i.tipIndexa == IndexTypes.AVERAGE)
                     {
                         if (i.Dionice.Count == 0)
                             return 0;
                         foreach (Stock s in i.Dionice)
                         {
                             List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                             Vremena.Sort();

                             bool zadnje_vrijeme = true;
                             for (int j = 0; j < Vremena.Count - 1; j++)
                             {
                                 if (Vremena[j] < inTimeStamp && inTimeStamp < Vremena[j + 1])
                                 {
                                     zadnje_vrijeme = false;
                                     Dionicesabrojem.Add(s.vrijednostiVremenski[Vremena[j]], s.inNumberOfShares);
                                 }
                             }
                             if (zadnje_vrijeme == true)
                                 Dionicesabrojem.Add(s.vrijednostiVremenski[Vremena.Last()], s.inNumberOfShares);
                         }
                         foreach (KeyValuePair<decimal, long> D in Dionicesabrojem)
                         {
                             weightedValue += (double) D.Key;
                         }
                         weightedValue = weightedValue/Dionicesabrojem.Count;
                     }

                 }
             }
             return Math.Round((decimal)weightedValue,3);
         }

         public bool IndexExists(string inIndexName)
         {
             foreach(Index i in Indices)
             {
                 if (i.indexName.ToLower() == inIndexName.ToLower())
                     return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return Indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index i in Indices)
             {
                 if (i.indexName.ToLower() == inIndexName.ToLower())
                     return i.Dionice.Count;
             }
             throw new StockExchangeException("Ne postoji index koji ste naveli");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             foreach (Portfolio p in Portfelji)
             {
                 if(p.ID == inPortfolioID)
                     throw new StockExchangeException("Portfolio sa ovim ID-om vec postoji!");
             }
             Portfelji.Add(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool postojalaJeDionicaVec = false;
             bool postojiPortfolioVec = false;
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     postojiPortfolioVec = true;
                     foreach (StockInPortfolio D in p.DioniceUPortfelju)
                     {
                         if (D.inStockName.ToLower() == inStockName.ToLower())
                         {
                             foreach (Stock s in Dionice)
                             {
                                 if (s.inStockName.ToLower() == D.inStockName.ToLower())
                                 {
                                     if (D.inNumberOfShares + numberOfShares <= s.inNumberOfShares)
                                     {
                                         D.inNumberOfShares += numberOfShares;
                                         postojalaJeDionicaVec = true;
                                     }
                                     else throw new StockExchangeException("nepostoji tolko clanova u dionici!");
                                 }
                             }
                         }
                     }
                     if (postojalaJeDionicaVec == false)
                     {
                         p.DioniceUPortfelju.Add(new StockInPortfolio(inStockName, numberOfShares));
                     }
                 }
             }
             if (postojiPortfolioVec == false)
             {
                 throw new StockExchangeException("ne postoji portfolio sa tim ID-em");
             }

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             bool brejk = false;
             bool postojiPortfolio = false;
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     postojiPortfolio = true;
                     foreach (StockInPortfolio D in p.DioniceUPortfelju)
                     {
                         if (D.inStockName.ToLower() == inStockName.ToLower())
                         {
                             foreach (Stock s in Dionice)
                             {
                                 if (s.inStockName.ToLower() == D.inStockName.ToLower())
                                 {

                                     if (D.inNumberOfShares - numberOfShares < 0)
                                     {
                                         throw new StockExchangeException("nepostoji tolko clanova u dionici za obrisat!");
                                     }
                                     if (D.inNumberOfShares - numberOfShares == 0)
                                     {
                                         RemoveStockFromPortfolio(inPortfolioID,inStockName);
                                         brejk = true;
                                     }
                                     else
                                     {
                                          D.inNumberOfShares -= numberOfShares;
                                     }
                                 }
                                 if (brejk == true)
                                     break;
                             }
                         }
                         if (brejk == true)
                             break;
                     }
                 }
             }
             if (postojiPortfolio == false)
                 throw new StockExchangeException("ne postoji portfolio sa tim ID-em");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             bool postojiPortfolio = false;
             bool postojiDionica = false;

             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     postojiPortfolio = true;
                     StockInPortfolio zaBrisanje = new StockInPortfolio();
                     foreach (StockInPortfolio D in p.DioniceUPortfelju)
                     {
                         if (D.inStockName.ToLower() == inStockName.ToLower())
                         {
                             zaBrisanje = D;
                             postojiDionica = true;
                             break;
                         }
                     }
                     p.DioniceUPortfelju.Remove(zaBrisanje);

                     if(postojiDionica==false)
                         throw new StockExchangeException("ne postoji dionica sa tim imenom");
                 }
             }
             if (postojiPortfolio == false)
                 throw new StockExchangeException("ne postoji portfolio sa tim ID-em");
         }

         public int NumberOfPortfolios()
         {
             return Portfelji.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                     return p.DioniceUPortfelju.Count;
             }
             throw new StockExchangeException("ne postoji portfolio sa tim ID-em");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             bool postojiPortfolio = false;
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     postojiPortfolio = true;
                     foreach (StockInPortfolio sp in p.DioniceUPortfelju)
                     {
                         if (sp.inStockName == inStockName)
                             return true;
                     }
                 }
             }
             if(postojiPortfolio == false)
                 throw new StockExchangeException("ne postoji portfolio sa tim ID-em");
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                    foreach (StockInPortfolio sp in p.DioniceUPortfelju)
                    {
                        if (sp.inStockName.ToLower() == inStockName.ToLower())
                            return (int)sp.inNumberOfShares;
                    }   
                 }
             }
             throw new StockExchangeException("ne postoji portfolio sa tim ID-em ili ta dionica u postojecem portfoliu");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             decimal suma = 0;
             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     foreach (StockInPortfolio sp in p.DioniceUPortfelju)
                     {
                         foreach (Stock s in Dionice)
                         {
                             if (s.inStockName.ToLower() == sp.inStockName.ToLower())
                             {
                                 List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                                 Vremena.Sort();
                                 bool zadnje_vrijeme = true;
                                 for (int j = 0; j < Vremena.Count - 1; j++)
                                 {
                                     if (Vremena[j] < timeStamp && timeStamp < Vremena[j + 1])
                                     {
                                         zadnje_vrijeme = false;
                                         suma += s.vrijednostiVremenski[Vremena[j]] * sp.inNumberOfShares;
                                     }
                                 }
                                 if (zadnje_vrijeme == true)
                                     suma += s.vrijednostiVremenski[Vremena[Vremena.Count-1]] * sp.inNumberOfShares;
                                 
                             }
                         }
                     }
                 }
             }
             return Math.Round(suma,3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             DateTime pocetakMjeseca = new DateTime(Year, Month, 1, 00, 00, 00);
             DateTime krajMjeseca = new DateTime(Year,Month,30,23,59,59,999);
             decimal sumaNaPocetkuMjeseca = 0;
             decimal sumaNaKrajuMjeseca = 0;

             foreach (Portfolio p in Portfelji)
             {
                 if (p.ID == inPortfolioID)
                 {
                     foreach (StockInPortfolio sp in p.DioniceUPortfelju)
                     {
                         foreach (Stock s in Dionice)
                         {
                             if (s.inStockName.ToLower() == sp.inStockName.ToLower())
                             {
                                 List<DateTime> Vremena = s.vrijednostiVremenski.Keys.ToList();
                                 Vremena.Sort();
                                 bool zadnje_vrijeme = true;
                                 for (int j = 0; j < Vremena.Count - 1; j++)
                                 {
                                     if (Vremena[j] <= pocetakMjeseca && pocetakMjeseca < Vremena[j + 1])
                                     {
                                         zadnje_vrijeme = false;
                                         sumaNaPocetkuMjeseca += s.vrijednostiVremenski[Vremena[j]] * sp.inNumberOfShares;
                                     }
                                 }
                                 if (zadnje_vrijeme == true)
                                     sumaNaPocetkuMjeseca += s.vrijednostiVremenski[Vremena[Vremena.Count - 1]] * sp.inNumberOfShares;

                                 zadnje_vrijeme = true;
                                 for (int j = 0; j < Vremena.Count - 1; j++)
                                 {
                                     if (Vremena[j] <= krajMjeseca && krajMjeseca < Vremena[j + 1])
                                     {
                                         zadnje_vrijeme = false;
                                         sumaNaKrajuMjeseca += s.vrijednostiVremenski[Vremena[j]] * sp.inNumberOfShares;
                                     }
                                 }
                                 if (zadnje_vrijeme == true)
                                     sumaNaKrajuMjeseca += s.vrijednostiVremenski[Vremena[Vremena.Count - 1]] * sp.inNumberOfShares;
                             }
                         }
                     }
                 }
             }
             if(sumaNaPocetkuMjeseca==0)
                 throw new StockExchangeException("nemozemo djelit sa nulom!");
             return Math.Round(((sumaNaKrajuMjeseca - sumaNaPocetkuMjeseca)/sumaNaPocetkuMjeseca)*100,3);
         }
     }

     public class Stock
     {
         public string inStockName;
         public long inNumberOfShares;
         public decimal Price;
         public decimal initialPrice;
         public DateTime inTimeStamp;
         public Dictionary<DateTime, decimal> vrijednostiVremenski = new Dictionary<DateTime, decimal>(); 

         public Stock(string _inStockName, long _inNumberOfShares, decimal _Price, DateTime _inTimeStamp)
         {
             this.inStockName = _inStockName;
             this.inNumberOfShares = _inNumberOfShares;
             this.Price = _Price;
             this.initialPrice = _Price;
             this.inTimeStamp = _inTimeStamp;
         }

         public Stock(){}
         
         public decimal GetInitialPrice()
         {
             return this.initialPrice;
         }

         public decimal GetPrice()
         {
             return this.Price;
         }

     }

    public class Index
     {
         public string indexName;
         public IndexTypes tipIndexa;

         public Index(string _indexName, IndexTypes _tipIndexa)
         {
             this.indexName = _indexName;
             this.tipIndexa = _tipIndexa;
         }
         
         public List<Stock> Dionice = new List<Stock>(); 

         
     }

    public class Portfolio
    {
        public string ID;
        //ime dionice, broj dionica u portfoliu
        public List<StockInPortfolio> DioniceUPortfelju = new List<StockInPortfolio>(); 
        public Portfolio(string _ID)
        {
            this.ID = _ID;
        }

    }

    public class StockInPortfolio
    {
        public string inStockName;
        public long inNumberOfShares;

        public StockInPortfolio(string _inStockName, long _inNumberOfShares)
        {
            this.inStockName = _inStockName;
            this.inNumberOfShares = _inNumberOfShares;
        }

        public StockInPortfolio(){}
    }
}

