﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
       
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }

    /// <summary>
    /// Class represents simple calculator.
    /// To add new operation implement one of operation interfaces and initialize operation in InitializeCalc method.
    /// </summary>
    public class Calculator : ICalculator
    {
        public Dictionary<string, ICalcOperation> CalculatorOperations { get; private set; }
        public Dictionary<string, IBinaryMathOperation> BinaryMathOperations { get; private set; }
        public Dictionary<string, IUnaryMathOperation> UnaryMathOperations { get; private set; }

        public IState State { get; set; }

        public Display Display { get; private set; }

        public string Memory { get; set; }

        public Calculator()
        {
            InitializeCalc();
        }

        public void Press(char inPressedDigit)
        {
            State = State.KeyPressed(inPressedDigit);
        }

      
        public string GetCurrentDisplayState()
        {
            return Display.GetDisplayContent();
        }

        //Puts string on display.
        public void PutOnCurrentDisplay(string num)
        {
            Display.PutOnDisplay(num);
        }

        //Clears calculator display.
        public void ClearDisplay()
        {

            Display.ResetDisplay();
        }

        //Initializes calculator.
        //Creates new display, puts calculator into starting state, initializes operations.
        private void InitializeCalc()
        {
            Display = new Display();

            State = new StartingState(this);

            Memory = "";

            CalculatorOperations = new Dictionary<string, ICalcOperation>();
            CalculatorOperations.Add("P", new StoreToMemory());
            CalculatorOperations.Add("G", new RetrieveFromMemory());
            CalculatorOperations.Add("C", new ClearDisplay());
            CalculatorOperations.Add("O", new ResetCalculator());
            CalculatorOperations.Add("M", new FlipSign());

            BinaryMathOperations = new Dictionary<string, IBinaryMathOperation>();
            BinaryMathOperations.Add("+", new Sum());
            BinaryMathOperations.Add("-", new Difference());
            BinaryMathOperations.Add("*", new Multiplication());
            BinaryMathOperations.Add("/", new Division());

            UnaryMathOperations = new Dictionary<string, IUnaryMathOperation>();
            //UnaryMathOperations.Add("M", new Negate());
            UnaryMathOperations.Add("S", new Sine());
            UnaryMathOperations.Add("K", new Cosine());
            UnaryMathOperations.Add("T", new Tangent());
            UnaryMathOperations.Add("Q", new Square());
            UnaryMathOperations.Add("R", new SquareRoot());
            UnaryMathOperations.Add("I", new Inverse());
        }
    }

    /// <summary>
    /// Class representing calculator display.
    /// Contains methods for getting and setting display content, reseting and formating display.
    /// </summary>
    public class Display
    {
        private string currentDisplay;
        private bool isDecimal;

        public Display()
        {
            ResetDisplay();
        }

        //Resets display content to 0.
        public void ResetDisplay()
        {
            currentDisplay = "0";
            isDecimal = false;
        }

        //Adds char to display.
        public void AddChar(char c)
        {
            //check number of digits displayed
            if (currentDisplay.Replace("-", "").Replace(",", "").Length < 10)
            {
                //check if number is decimal
                if (isDecimal)
                {
                    //if number add it
                    if (c != ',')
                    {
                        currentDisplay = currentDisplay + c;
                    }
                }
                //if number is not decimal
                else
                {
                    currentDisplay = currentDisplay + c;
                    if (c == ',')
                    {
                        isDecimal = true;
                    }
                }
            }
            //remove leading zero
            if (currentDisplay.Replace("-", "").Length == 2 && currentDisplay[0] == '0' && currentDisplay[1] != ',')
            {
                currentDisplay = currentDisplay.Substring(1);
            }
        }

        //Puts string on display.
        public void PutOnDisplay(string num)
        {

            PutOnDisplay(Double.Parse(num.Replace(",", ".")));
        }
        //Puts number on display.
        public void PutOnDisplay(double num)
        {
            isDecimal = false;
            string numAsString = num.ToString();
            string wholeNum = numAsString.Split('.')[0];

            if (wholeNum.Length > 10)
            {
                SetError();
            }
            else
            {
                if ((num % 1) == 0)
                {
                    currentDisplay = wholeNum;
                }
                else
                {
                    isDecimal = true;
                    double roundedToDisplay = Math.Round(num, 10 - wholeNum.Replace("-", "").Length);
                    currentDisplay = roundedToDisplay.ToString().Replace(".", ",");
                }
            }
            RemoveLastZeros();
        }

        //Gets content of display.
        public string GetDisplayContent()
        {
            return currentDisplay;
        }

        //Gets number from display.
        public double GetDisplayNumber()
        {
            return Double.Parse(currentDisplay.Replace(",", "."));
        }

        //Sets error msg -E- on display.
        public void SetError()
        {
            currentDisplay = "-E-";
        }

        //Removes any last zero from number.
        public void RemoveLastZeros()
        {
            if (currentDisplay.Length > 1)
            {
                while ((currentDisplay[currentDisplay.Length - 1] == '0') && isDecimal)
                {
                    currentDisplay = currentDisplay.Substring(0, currentDisplay.Length - 1);
                }
                if (currentDisplay[currentDisplay.Length - 1] == ',')
                {
                    isDecimal = false;
                    currentDisplay = currentDisplay.Substring(0, currentDisplay.Length - 1);
                }
            }
        }

        //Method flips sign of current number on display.
        public void FlipSign()
        {
            if (currentDisplay[0] == '-')
            {
                currentDisplay = currentDisplay.Substring(1);
            }
            else
            {
                currentDisplay = "-" + currentDisplay;
            }
        }
    }

    /// <summary>
    /// Interface declaring all states of this calculator.
    /// </summary>
    public interface IState
    {
        /// <summary>
        /// Method gives new char to parse to state.
        /// </summary>
        /// <param name="key">Char to parse.</param>
        /// <returns>State</returns>
        IState KeyPressed(char key);
    }

    #region CalculatorStates
    /// <summary>
    /// Starting calculator state.
    /// Contains flag (instead of more states) for tracking when is the first digit entered.
    /// </summary>
    public class StartingState : IState
    {
        private Calculator calculator;
        private bool firstDigitEntered;

        public StartingState(Calculator calculator)
        {
            this.calculator = calculator;
            this.firstDigitEntered = false;
        }

        public IState KeyPressed(char inPressedKey)
        {
            try
            {
                //if digit or , pass it to display.
                if (Char.IsDigit(inPressedKey) || inPressedKey.Equals(','))
                {
                    //if first digit clear display.
                    if (!firstDigitEntered)
                    {
                        firstDigitEntered = true;
                        calculator.Display.ResetDisplay();
                    }
                    calculator.Display.AddChar(inPressedKey);
                    return this;
                }
                //Char for calc operations
                else if (calculator.CalculatorOperations.ContainsKey(inPressedKey.ToString()))
                {
                    return calculator.CalculatorOperations[inPressedKey.ToString()].Execute(calculator).State;
                }
                //Char for unary math operations, reset state
                else if (calculator.UnaryMathOperations.ContainsKey(inPressedKey.ToString()))
                {
                    double result = calculator.UnaryMathOperations[inPressedKey.ToString()].Execute(calculator.Display.GetDisplayNumber());
                    calculator.Display.PutOnDisplay(result);
                    return new StartingState(calculator);
                }
                //Char for binary math operations, go to binary state
                else if (calculator.BinaryMathOperations.ContainsKey(inPressedKey.ToString()))
                {
                    calculator.Display.RemoveLastZeros();
                    return new BinaryState(inPressedKey.ToString(), calculator);
                }
                else if (inPressedKey == '=')
                {
                    calculator.Display.RemoveLastZeros();
                    return this;
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
            catch (Exception e)
            {
                calculator.Display.SetError();
                return new StartingState(calculator);
            }
        }
    }

    /// <summary>
    /// State when binary operator is entered. 
    /// Contains flags (instead of more states) for tracking entering first digit and using unary operation over result.
    /// </summary>
    public class BinaryState : IState
    {
        private Calculator calculator;
        private string binaryOperator;
        private double firstOperand;
        private bool firstDigitEntered;
        private bool unaryMathOperationUsed;

        public BinaryState(string binaryOperator, Calculator calculator)
        {
            this.calculator = calculator;
            this.binaryOperator = binaryOperator;
            this.firstDigitEntered = false;
            this.unaryMathOperationUsed = false;
            firstOperand = calculator.Display.GetDisplayNumber();
        }

        public IState KeyPressed(char inPressedKey)
        {
            try
            {
                //digit or ,
                if (Char.IsDigit(inPressedKey) || inPressedKey.Equals(','))
                {
                    if (!firstDigitEntered)
                    {
                        firstDigitEntered = true;
                        calculator.Display.ResetDisplay();
                    }
                    calculator.Display.AddChar(inPressedKey);
                    return this;
                }
                //Char for calc operations
                else if (calculator.CalculatorOperations.ContainsKey(inPressedKey.ToString()))
                {
                    return calculator.CalculatorOperations[inPressedKey.ToString()].Execute(calculator).State;
                   
                }
                //Char for unary math operations
                else if (calculator.UnaryMathOperations.ContainsKey(inPressedKey.ToString()))
                {
                    unaryMathOperationUsed = true;
                    double result = calculator.UnaryMathOperations[inPressedKey.ToString()].Execute(calculator.Display.GetDisplayNumber());
                    calculator.Display.PutOnDisplay(result);
                    return this;
                }
                //Char for binary math operations
                else if (calculator.BinaryMathOperations.ContainsKey(inPressedKey.ToString()))
                {
                    if (!firstDigitEntered && !unaryMathOperationUsed)
                    {
                        binaryOperator = inPressedKey.ToString();
                        return this;
                    }
                    else
                    {
                        double result = calculator.BinaryMathOperations[binaryOperator].Execute(firstOperand, calculator.Display.GetDisplayNumber());
                        calculator.Display.PutOnDisplay(result);
                        return new BinaryState(inPressedKey.ToString(), calculator);
                    }
                }
                else if (inPressedKey == '=')
                {
                    double result = 0;
                    if (!firstDigitEntered)
                    {
                        result = calculator.BinaryMathOperations[binaryOperator].Execute(firstOperand, firstOperand);

                    }
                    else
                    {
                        result = calculator.BinaryMathOperations[binaryOperator].Execute(firstOperand, calculator.Display.GetDisplayNumber());
                    }
                    calculator.Display.PutOnDisplay(result);
                    return new StartingState(calculator);
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
            catch (Exception e)
            {
                calculator.Display.SetError();
                return new StartingState(calculator);
            } 
        }
    }
    #endregion


    /// <summary>
    /// Interface declaring all supported calculator operations.
    /// </summary>
    public interface ICalcOperation
    {
        /// <summary>
        /// Executes calculator operation over given calculator.
        /// </summary>
        /// <param name="calculator">Calculator.</param>
        /// <returns>Calculator.</returns>
        Calculator Execute(Calculator calculator);
    }

    #region CalculatorOperations
    /// <summary>
    /// Stores number on display to memory.
    /// </summary>
    public sealed class StoreToMemory : ICalcOperation
    {
        public Calculator Execute(Calculator calculator)
        {
            calculator.Memory = calculator.GetCurrentDisplayState();
            return calculator;
        }
    }

    /// <summary>
    /// Retrieves stored number if there is one in memory else puts 0 on display.
    /// </summary>
    public sealed class RetrieveFromMemory : ICalcOperation
    {
        public Calculator Execute(Calculator calculator)
        {
            if (calculator.Memory.Length > 0)
            {
                calculator.PutOnCurrentDisplay(calculator.Memory);
            }
            else
            {
                calculator.Display.ResetDisplay();
            }
            return calculator;
        }
    }

    /// <summary>
    /// Clears current display.
    /// </summary>
    public sealed class ClearDisplay : ICalcOperation
    {
        public Calculator Execute(Calculator calculator)
        {
            calculator.ClearDisplay();
            return calculator;
        }
    }

    /// <summary>
    /// Resets memory, clears current display and puts calculator into starting state.
    /// </summary>
    public sealed class ResetCalculator : ICalcOperation
    {
        public Calculator Execute(Calculator calculator)
        {
            calculator.Display.ResetDisplay();
            calculator.Memory = "";
            calculator.State = new StartingState(calculator);
            return calculator;
        }
    }

    /// <summary>
    /// Flips sign of current number on display.
    /// </summary>
    public sealed class FlipSign : ICalcOperation
    {
        public Calculator Execute(Calculator calculator)
        {
            calculator.Display.FlipSign();
            return calculator;
        }
    }


    #endregion

    /// <summary>
    /// Interface declaring all supported binary mathematical operations.
    /// </summary>
    public interface IBinaryMathOperation
    {
        /// <summary>
        /// Executes binary mathematical operation over given parameters.
        /// </summary>
        /// <param name="operand_1">First operand.</param>
        /// <param name="operand_2">Second operand.</param>
        /// <returns>Result of binary operation over given operands</returns>
        double Execute(double operand_1, double operand_2);
    }

    #region BinaryMathOperations
    /// <summary>
    /// Adds two given numbers.
    /// </summary>
    public sealed class Sum : IBinaryMathOperation
    {

        public double Execute(double operand_1, double operand_2)
        {
            return operand_1 + operand_2;
        }
    }

    /// <summary>
    /// Substracts second given number from first.
    /// </summary>
    public sealed class Difference : IBinaryMathOperation
    {
        public double Execute(double operand_1, double operand_2)
        {
            return operand_1 - operand_2;
        }
    }

    /// <summary>
    /// Multiplies two given numbers.
    /// </summary>
    public sealed class Multiplication : IBinaryMathOperation
    {
        public double Execute(double operand_1, double operand_2)
        {
            return operand_1 * operand_2;
        }
    }

    /// <summary>
    /// Divides first given number with second given number.
    /// Throws exception if second given number is 0.
    /// </summary>
    public sealed class Division : IBinaryMathOperation
    {
        public double Execute(double operand_1, double operand_2)
        {
            if (operand_2 == 0)
            {
                throw new DivideByZeroException();
            }
            return operand_1 / operand_2;
        }
    }

    #endregion

    /// <summary>
    /// Interface declaring all supported unary mathematical operations.
    /// </summary>
    public interface IUnaryMathOperation
    {
        /// <summary>
        /// Executes unary mathematical operation over given operand.
        /// </summary>
        /// <param name="operand_1">Operand.</param>
        /// <returns>Result of unary operation.</returns>
        double Execute(double operand_1);
    }

    #region UnaryMathOperations

    /// <summary>
    /// Calculates sine for given number.
    /// </summary>
    public sealed class Sine : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            return Math.Sin(operand_1);
        }
    }

    /// <summary>
    /// Calculates cosine for given number.
    /// </summary>
    public sealed class Cosine : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            return Math.Cos(operand_1);
        }
    }

    /// <summary>
    /// Calculates tangent for given number.
    /// </summary>
    public sealed class Tangent : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            return Math.Tan(operand_1);
        }
    }

    /// <summary>
    /// Calculates square for given number.
    /// </summary>
    public sealed class Square : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            return operand_1 * operand_1;
        }
    }

    /// <summary>
    /// Calculates square root for given number.
    /// Throws exception for negative numbers.
    /// </summary>
    public sealed class SquareRoot : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            if (operand_1 < 0)
            {
                throw new ArgumentException();
            }
            return Math.Sqrt(operand_1);
        }
    }
    
    /// <summary>
    /// Inverses given number.
    /// </summary>
    public sealed class Inverse : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            if (operand_1 == 0)
            {
                throw new DivideByZeroException();
            }
            return 1 / operand_1;
        }
    }

    /// <summary>
    /// Not used, replaced by FlipSign calculator operation
    /// </summary>
    public sealed class Negate : IUnaryMathOperation
    {
        public double Execute(double operand_1)
        {
            return -1 * operand_1;
        }
    }

    #endregion
}
