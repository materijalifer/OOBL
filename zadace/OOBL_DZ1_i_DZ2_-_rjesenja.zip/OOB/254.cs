﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public delegate double UnarniDelegat(double x);

    public class Zaslon
    {
        private string ekran;
        public int stanje;  // 1 ili 2 ako je kod upisa znamenke potrebno pobrisati broj, posebno 2 ako je zadnji unesen bio binarni operator
        
        public Zaslon()
        {
            obrisi();
        }

        public void obrisi()
        {
            postavi("0", 1);
        }

        public void postavi(string novi, int novoStanje)
        {
            ekran = trim(novi);
            stanje = novoStanje;
        }

        public void dodajBroj(char znam)
        {
            if (stanje != 0 || ekran == "0")  // pazimo i na slucaj kada upisujemo same nule...
            {
                postavi(znam.ToString(), 0);
            }
            else
            {
                int brZnam = ekran.Length;
                if (ekran.IndexOf(',') != -1) --brZnam;
                if (ekran.IndexOf('-') != -1) --brZnam;

                if (brZnam < 10)
                {
                    postavi(ekran + znam.ToString(), 0);
                    // TODOI: ako imam znamenku x na kraju decimalne, i napisem vecu od 5, onda to treba povecati za jedan (ako nisam prije)
                }
            }
        }


        private string trim(string trenutniEkran)
        {
            if (trenutniEkran.CompareTo("0") == 0)
                trenutniEkran.TrimStart('0');

            bool neg = false;
            if (trenutniEkran[0] == '-') 
            {
                neg = true;
                trenutniEkran = trenutniEkran.Substring(1);
            }

            // nakon ove tocke, ekran vise ne sadrzi znak '-'!

            int pozicijaZareza = trenutniEkran.IndexOf(',');

            int brojZnamenki = trenutniEkran.Length;            
            if (pozicijaZareza != -1) --brojZnamenki;

            if (brojZnamenki > 10) // ako treba kratiti
            {
                if (pozicijaZareza == -1 || pozicijaZareza >= 10) // ne moze se kratiti, previse znamenki!
                    return "-E-";

                // inace, krati:               
                trenutniEkran = Convert.ToString(Math.Round(Convert.ToDouble(trenutniEkran), 10 - pozicijaZareza));
             
                // ako vise nemam decimala na kraju
                trenutniEkran = trenutniEkran.TrimEnd(',');
            }

            if (neg) // vrati znak minusa ako je potreban!
                trenutniEkran = "-" + trenutniEkran;

            return trenutniEkran;
        }

        public void pritisnutZarez()
        {
            if (ekran.IndexOf(',') == -1)
                postavi(ekran + ',', 0); // dopustamo nadopisivanje
        }

        public void izvrsiUnarnuFunkciju(UnarniDelegat F, int ispocetka = 1)
        {
            if (ekran == "-E-") // u tom slucaju, ne mozemo nista napraviti, ostaje greska
                return;

            double trenutnaVrijednost = Convert.ToDouble(ekran);
            double novaVrijednost = F(trenutnaVrijednost);

            postavi(Convert.ToString(novaVrijednost), ispocetka);  // jer ako se pritisne znamenka, zelimo pisati ispocetka
        }
       
        public string trenutno()
        {
            return ekran;
        }

        public double vrijednost()
        {
            if (stanje == 2)
                return 0;
            return Convert.ToDouble(ekran);
        }
    }

    /* za razliku od normalnog, sve operacije imaju isti redoslijed
     * paziti na rezanje - kad upises previse znakova!
     * paziti na ispis -E- kad rezultat ima previse znakova
     * 
     *
     *
     *
     */

    public class Kalkulator:ICalculator
    {
        private string memorija;
        private Zaslon zaslon = new Zaslon();
        private double prviOperand;
        private char trenutnaOperacija; // binarna operacija koja ce se izvrsiti kada unesemo drugi pribrojnik i novu binarnu operaciju, '=' ako nema operacije

        private void resetirajSve()
        {
            zaslon.obrisi();

            memorija = "0";
            trenutnaOperacija = '=';
            prviOperand = 0;
        }

        public Kalkulator() {
            resetirajSve();           
        }

        private void dohvatIzMemorije()
        {
            zaslon.postavi(memorija, 0);  // DILEMA: nakon ucitavanja iz memorije, mogu li nastaviti pisati broj? valjda mogu.
        }

        private void upisUMemoriju()
        {
            memorija = zaslon.trenutno();
        }

        private bool jeBinarnaOperacija(char op)
        {
            const string binarne = "+-/*=";
            return (binarne.IndexOf(op) != -1);
        }

        private void obradiBinarnuOperaciju(char operacija)
        {
            double drugiOperand = zaslon.vrijednost();

            if (zaslon.stanje == 2)
                drugiOperand = prviOperand;

            if (zaslon.stanje != 2 || operacija == '=') {
                switch (trenutnaOperacija)
                {
                    case '=':
                        prviOperand = drugiOperand;
                        break;
                    case '+':
                        prviOperand = prviOperand + drugiOperand;
                        break;
                    case '-':
                        prviOperand = prviOperand - drugiOperand;
                        break;
                    case '/':
                        prviOperand = prviOperand / drugiOperand;
                        break;
                    case '*':
                        prviOperand = prviOperand * drugiOperand;
                        break;
                    default:
                        prviOperand = drugiOperand;
                        break;
                }
            }

            trenutnaOperacija = operacija;            
            zaslon.postavi(prviOperand.ToString(), 2); // jer ce sljedeci broj poceti mijenjati
        }

        private bool jeUnarnaOperacija(char op) 
        {
            const string binarne = "MSKTQRI";
            return (binarne.IndexOf(op) != -1);
        }

        private double invertiraj(double x) { if (x != 0) return 1 / x; return 1e12; }
        private double kvadrat(double x) { return x * x; }
        private double minus(double x) { return -x; }

        private void obradiUnarnuOperaciju(char operacija)
        {
            switch (operacija)
            {
                case 'M':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(minus), 0); // ovdje iznimno dopustam pisanje i nakon izvrsavanja!
                    break;
                case 'S':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(Math.Sin));
                    break;
                case 'K':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(Math.Cos));
                    break;
                case 'T':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(Math.Tan));
                    break;
                case 'Q':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(kvadrat));
                    break;
                case 'R':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(Math.Sqrt));
                    break;
                case 'I':
                    zaslon.izvrsiUnarnuFunkciju(new UnarniDelegat(invertiraj));
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return zaslon.trenutno();
        }

        public void Press(char inPressedDigit)
        {
            // ispis pritisnute tipke
            Debug.WriteLine(inPressedDigit);

            if (Char.IsNumber(inPressedDigit))  // radi li se o znamenki?
            {
                zaslon.dodajBroj(inPressedDigit);
            }
            else if (jeBinarnaOperacija(inPressedDigit))
            {
                obradiBinarnuOperaciju(inPressedDigit);
            }
            else if (inPressedDigit == ',') // ako je zarez, obradi ga
            {
                zaslon.pritisnutZarez();
            }
            else if (jeUnarnaOperacija(inPressedDigit))
            {
                obradiUnarnuOperaciju(inPressedDigit);
            }
            else // operacije kalkulatora
            {
                switch (inPressedDigit)
                {
                    case 'P':
                        upisUMemoriju();
                        break;
                    case 'G':
                        dohvatIzMemorije();
                        break;
                    case 'C':
                        zaslon.obrisi();
                        break;
                    case 'O':
                        resetirajSve();
                        break;
                }
            }

            Debug.WriteLine(zaslon.trenutno());
            Debug.WriteLine("------");
        }

    }




}
