﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        CalculatorDisplay calculatorDisplay;

        double memory = 0;


        char lastOperator = '\0';

        double lastOperand = 0;

        bool operandEntered = false;

        


        public Kalkulator()
        {
            calculatorDisplay = new CalculatorDisplay();
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                if (calculatorDisplay.IsInErrorState)
                {
                    calculatorDisplay.resetScreen();
                  
                }
                switch (inPressedDigit)
                {
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                    case ',':
                        calculatorDisplay.addCharachter(inPressedDigit);
                        operandEntered = true;
                        break;
                    case 'M':
                        calculatorDisplay.ChangeSign();
                        break;
                    case 'O':
                        calculatorDisplay.resetScreen();
                        memory = 0;
                        lastOperator = (char)0;
                        lastOperand = 0;
                       
                        break;
                    case 'C':
                        calculatorDisplay.resetScreen();
                        break;
                    case 'P':
                        memory = calculatorDisplay.getNumber();
                        break;
                    case 'G':
                        calculatorDisplay.setNumber(memory);
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case '*':
                    case '/':
                    case '+':
                    case '-':
                        binaryOperation(inPressedDigit);
                        break;
                    case 'S':
                        calculatorDisplay.setNumber(sin(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case 'K':
                        calculatorDisplay.setNumber(cos(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case 'T':
                        calculatorDisplay.setNumber(tan(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case 'Q':
                        calculatorDisplay.setNumber(pow2(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case 'R':
                        calculatorDisplay.setNumber(sqr(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case 'I':
                        calculatorDisplay.setNumber(inv(calculatorDisplay.getNumber()));
                        calculatorDisplay.clearScreenOnNextKeypress();
                        break;
                    case '=':
                        binaryOperation((char)0);
                        calculatorDisplay.clearScreenOnNextKeypress();
                        calculatorDisplay.removeTrailingZeros();
                        break;
                }
            }
            catch
            {
                //ignore 
            }
        }
        public void binaryOperation(char operation)
        {
            if (lastOperator == (char)0)
            {
                lastOperator = operation;
                lastOperand = calculatorDisplay.getNumber();
                operandEntered = false;
            }
            else
            {
                if (!operandEntered && operation!= '\0')
                {
                    lastOperator = operation;
                    //operandEntered = false;
                    return;
                }
                double result = binaryOperationCalculation(lastOperand, calculatorDisplay.getNumber(), lastOperator);
                calculatorDisplay.setNumber(result);
                lastOperand = calculatorDisplay.getNumber();
                lastOperator = operation;
                operandEntered = false;
             
            }
            calculatorDisplay.clearScreenOnNextKeypress();
        }

        private double binaryOperationCalculation(double op1, double op2, char operation){
            double result = 0;
            switch (operation)
            {
                case '*':
                    result = mul(op1, op2);
                    break;

                case '/':
                    result = div(op1, op2);
                    break;
                case '+':
                    result = add(op1, op2);
                    break;
                case '-':
                    result = sub(op1, op2);
                    break;
                default:
                    result = op2;
                    break;
                    
            }
            return result;
            
        }

        public string GetCurrentDisplayState()
        {
            return calculatorDisplay.getDisplayState();
        }

        private double add(double op1, double op2)
        {
            return op1 + op2;
        }
        private double sub(double op1, double op2)
        {
            return op1 - op2;
        }
        private double mul(double op1, double op2)
        {
            return op1 * op2;
        }
        private double div(double op1, double op2)
        {
            return op1 / op2;
        }

        private double sqr(double op){
            return Math.Sqrt(op);
        }

        private double inv(double op){
            return 1/op;
        }

        private double pow2(double op)
        {
            return op*op;
        }

        private double sin(double op)
        {
            return Math.Sin(op);
        }

        private double cos(double op)
        {
            return Math.Cos(op);
        }

        private double tan(double op)
        {
            return Math.Tan(op);
        }


        private class CalculatorDisplay
        {
            bool isError;

            bool isDecimal;

            bool isMinus;

            bool isClarScreenOnNextKeypress;

            public bool WaitingForNewNumberEntry
            {
                get { return isClarScreenOnNextKeypress; }
            }

            public List<char> preDecimal;
            public List<char> postDecimal;

            public bool IsInErrorState{
                get{ return isError; }
            }



            public CalculatorDisplay()
            {
                this.preDecimal = new List<char>();
                this.postDecimal = new List<char>();
                this.isError = false;
                this.isDecimal = false;
                this.isMinus = false;
                this.isClarScreenOnNextKeypress = false;

            }

            public void setNumber(double number)
            {
                this.resetScreen();
                if (number < 0)
                {
                    number = -number;
                    isMinus = true;
                }
                
                int integerPart = (int)number;
                
                if(number > 9999999999) {
                    showError();
                }
                else if (number < 0.000000001)
                {
                    this.resetScreen();
                }
                else
                {
                    int integerPartLenght = integerPart.ToString().Length;

                    number = Math.Round(number, 10 - integerPartLenght);
                    
                    string [] strTok= number.ToString().Split(',');


                    preDecimal.AddRange(strTok[0].ToCharArray());
                    if (strTok.Length == 2)
                    {
                        isDecimal = true;
                        postDecimal.AddRange(strTok[1].ToCharArray());
                    }
                }
            }

            public double roundNumber(double number)
            {
                double number2 = number;
                if (number < 0)
                {
                    number2 = -number;
                    
                }

                if (number2 > 9999999999)
                {
                    showError();
                }
                else if (number2 < 0.000000001)
                {
                    return 0;
                }
                
                int integerPart = (int)number2;
                int integerPartLenght = integerPart.ToString().Length;

                return Math.Round(number, Math.Max(10 - integerPartLenght,0));
            }

            public void addCharachter(char c)
            {
                if (this.isClarScreenOnNextKeypress) this.resetScreen();
                if (!(c >= '0' && c <= '9' || c == ','))
                {
                    showError();
                }
                if (c == ',')
                {
                    isDecimal = true;
                }
                else
                {
                    if (preDecimal.Count + postDecimal.Count < 10)
                    {
                        if (isDecimal)
                        {
                            postDecimal.Add(c);

                        }
                        else
                        {
                            preDecimal.Add(c);
                        }
                        checkIsCurrentNumberValid();
                    }
                }

            }

            public void checkIsCurrentNumberValid(){
                if (preDecimal.Count + postDecimal.Count > 10)
                {
                    showError();
                }
                
                while (preDecimal.Count > 0 && preDecimal[0] == '0')
                {
                    preDecimal.RemoveAt(0);
                }
            }

            public void removeTrailingZeros()
            {
                
                while (postDecimal.Count > 0 && postDecimal[postDecimal.Count - 1] == '0')
                {
                        postDecimal.RemoveAt(postDecimal.Count - 1);
                }
            }

            public double getNumber()
            {
                checkIsCurrentNumberValid();
                double number = 0;
                double weigth = Math.Pow(10,preDecimal.Count - 1);
                
                for (int i = 0; i < preDecimal.Count; i++)
                {
                    number += weigth * (preDecimal[i]-'0');
                    weigth /= 10;
                }
                for (int i = 0; i < postDecimal.Count; i++)
                {
                    number += weigth * (postDecimal[i] - '0');
                    weigth /= 10;
                }
                if (isMinus) return -number;
                return number;
            }

            public string getDisplayState()
            {
                if (isError) return "-E-";
                StringBuilder strBld = new StringBuilder();
                if (isMinus && this.getNumber() != 0) strBld.Append('-');
                if (preDecimal.Count == 0) strBld.Append("0");
                else
                {
                    strBld.Append(preDecimal.ToArray());
                }
                if (isDecimal && postDecimal.Count > 0)
                {
                    strBld.Append(",");
                    strBld.Append(postDecimal.ToArray());
                }
                return strBld.ToString();
            }

            public void showError()
            {
                this.isError = true;
                throw new Exception("Greska u kalkulatoru");
            }
            public void resetScreen(){
                isError = false;
                isDecimal = false;
                isMinus = false;
                isClarScreenOnNextKeypress = false;
                preDecimal.Clear();
                postDecimal.Clear();

            }

            public void ChangeSign()
            {
                this.isMinus = !this.isMinus;
            }
            public void clearScreenOnNextKeypress(){
                this.isClarScreenOnNextKeypress = true;

            }
        }
        
    }

    

}
