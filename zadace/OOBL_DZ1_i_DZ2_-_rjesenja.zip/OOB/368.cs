﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    /// <summary>
    /// Klasa koja predstavlja Burzu, objekt na kojem se trguje odredenim skupom Dionica.
    /// Osnovna namjena Burze jest izracunavanje vrijednosti Indeksa definiranih u sustavu.
    /// Na burzi se takoder prate i Portfelji.
    /// </summary>
    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Dionica> _dionice;      // dionice koje postoje na burzi
        private Dictionary<string, Index> _indexi;         // indeksi definirani u sustavu
        private Dictionary<string, Portfelj> _portfelji;   // portfelji koji se prate

        /// <summary>
        /// Konstruktor. Obavlja inicijalizaciju članskih varijabli klase StockExchange.
        /// </summary>
        public StockExchange()
        {
            _dionice = new Dictionary<string, Dionica>();
            _indexi = new Dictionary<string, Index>();
            _portfelji = new Dictionary<string, Portfelj>();
        }

        /// <summary>
        /// Funkcija koja dodaje dionicu s početnom cijenom na burzu.
        /// Ako dionica s tim imenom vec postoji, sustav dojavljuje korisniku gresku putem iznimke tipa StockExchangeException.
        /// Cijena i broj dionica ne mogu biti negativni ili 0.
        /// </summary>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom vec postoji!");
            }

            if (inNumberOfShares <= 0 || inInitialPrice <= 0)
            {
                throw new StockExchangeException("Cijena i broj dionica ne mogu biti negativni ili 0!");
            }

            Dionica novaDionica = new Dionica(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
            _dionice.Add(inStockName.ToLower(), novaDionica);
        }

        /// <summary>
        /// Funkcija koja briše dionicu s burze.
        /// </summary>
        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName))
            {
                IzbrisiDionicuIzPortofolia(inStockName.ToLower());
                IzbrisiDionicuIzIndeksa(inStockName.ToLower());
                _dionice.Remove(inStockName.ToLower());
            }
            else
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji!");
            }
        }

        /// <summary>
        /// Pomocna funkcija koja provjerava je li dionica koja se brise dio nekog portofolija.
        /// Ako jest, dionica se uklanja iz portofolija.
        /// </summary>
        private void IzbrisiDionicuIzPortofolia(string imeDionice)
        {
            foreach (KeyValuePair<string, Portfelj> pair in _portfelji)
            {
                if (IsStockPartOfPortfolio(pair.Key, imeDionice))
                {
                    RemoveStockFromPortfolio(pair.Key, imeDionice);
                }
            }
        }

        /// <summary>
        /// Pomocna funkcija koja provjerava je li dionica koja se brise dio nekog indeksa.
        /// Ako jest, dionica se uklanja iz indeksa.
        /// </summary>
        private void IzbrisiDionicuIzIndeksa(string imeDionice)
        {
            foreach (KeyValuePair<string, Index> pair in _indexi)
            {
                if (IsStockPartOfIndex(pair.Key, imeDionice))
                {
                    RemoveStockFromIndex(pair.Key, imeDionice);
                }
            }
        }

        /// <summary>
        /// Funkcija koja provjerava postoji li tražena dionica na burzi.
        /// </summary>
        public bool StockExists(string inStockName)
        {
            return _dionice.ContainsKey(inStockName.ToLower());
        }

        /// <summary>
        /// Funkcija koja vraća broj dionica na burzi.
        /// </summary>
        public int NumberOfStocks()
        {
            return _dionice.Count;
        }

        /// <summary>
        /// Funkcija koja postavlja cijenu dionice za određeno vrijeme.
        /// Cijena ne moze biti negativna ili 0.
        /// Za odredeni trenutak nije moguce unijeti vise zapisa cijena.
        /// </summary>
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue < 0)
            {
                throw new StockExchangeException("Cijena dionice ne može biti negativni ili 0!");
            }
            if (!_dionice.ContainsKey(inStockName.ToLower()))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom!");
            }
            if (_dionice[inStockName.ToLower()].SadrziTimestamp(inIimeStamp))
            {
                throw new StockExchangeException("Timestamp vec postoji!");
            }

            _dionice[inStockName.ToLower()].PostaviNovuCijenu(inIimeStamp, inStockValue);
        }

        /// <summary>
        /// Funkcija koja dohvaća cijenu dionice za neko vrijeme.
        /// </summary>
        public Decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!_dionice.ContainsKey(inStockName.ToLower()))
            {
                throw new StockExchangeException("Ne postoji dionica s tim imenom!");
            }

            return _dionice[inStockName.ToLower()].DohvatCijenu(inTimeStamp);
        }

        /// <summary>
        /// Funkcija koja dohvaća početnu cijenu dionice.
        /// Pri tom se misli na cijenu vezanu za najranije vremensko razdoblje koje je definirano,
        /// a ne na cijenu unesenu pri stvaranju dionice.
        /// </summary>
        public Decimal GetInitialStockPrice(string inStockName)
        {
            return _dionice[inStockName.ToLower()].DohvatiPocetnuCijenu();
        }

        /// <summary>
        /// Funkcija koja dohvaća zadnju cijenu dionice.
        /// Pri tom se misli na cijenu vezanu za najkasnije vremensko razdoblje koje je definirano,
        /// a ne na posljednju unesenu cijenu.
        /// </summary>
        public Decimal GetLastStockPrice(string inStockName)
        {
            return _dionice[inStockName.ToLower()].DohvatiKonacnuCijenu();
        }

        /// <summary>
        /// Funkcija koja stvara novi indeks na burzi.
        /// Tip indeksa smije biti samo AVERAGE ili WEIGHTED.
        /// </summary>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Index tim imenom vec postoji!");
            }
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Tip indeksa smije biti samo ili AVERAGE ili WEIGHTED!");
            }

            Index noviIndex = new Index(inIndexName.ToLower(), inIndexType);
            _indexi.Add(inIndexName.ToLower(), noviIndex);
        }

        /// <summary>
        /// Funkcija koja dodaje dionicu u indeks.
        /// Dionica mora postojati na burzi i smije se samo jednom pridjeliti indeksu.
        /// </summary>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Navedena dionica ne postoji na burzi!");
            }
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index s tim imenom!");
            }
            if (!_indexi[inIndexName.ToLower()].ProvjeriPostojanjeDioniceUIndexu(inStockName.ToLower()))
            {
                _indexi[inIndexName.ToLower()].DodajDionicu(inStockName.ToLower(), _dionice[inStockName.ToLower()]);
            }
        }

        /// <summary>
        /// Funkcija koja briše dionicu iz indeksa.
        /// </summary>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Navedena dionica ne postoji na burzi!");
            }
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index s tim imenom!");
            }
            if (_indexi[inIndexName.ToLower()].ProvjeriPostojanjeDioniceUIndexu(inStockName.ToLower()))
            {
                _indexi[inIndexName.ToLower()].UkloniDionicu(inStockName.ToLower());
            }
        }

        /// <summary>
        /// Funkcija koja provjerava je li dionica u indeksu.
        /// </summary>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Navedena dionica ne postoji na burzi!");
            }
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index s tim imenom!");
            }

            return _indexi[inIndexName.ToLower()].ProvjeriPostojanjeDioniceUIndexu(inStockName.ToLower());
        }

        /// <summary>
        /// Funkcija koja dohvaca vrijednost indeksa.
        /// </summary>
        public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index s tim imenom!");
            }

            return _indexi[inIndexName.ToLower()].DohvatiVrijednostIndeksa(inTimeStamp);
        }

        /// <summary>
        /// Funkcija koja provjerava postoji li traženi indeks na burzi.
        /// </summary>
        public bool IndexExists(string inIndexName)
        {
            return _indexi.ContainsKey(inIndexName.ToLower());
        }

        /// <summary>
        /// Funkcija koja dohvaća broj indeksa na burzi.
        /// </summary>
        public int NumberOfIndices()
        {
            return _indexi.Count;
        }

        /// <summary>
        /// Funkcija koja dohvaća broj dionica u traženom indeksu.
        /// </summary>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
            {
                throw new StockExchangeException("Ne postoji index s tim imenom na burzi!");
            }
            return _indexi[inIndexName.ToLower()].BrojDionica();
        }

        /// <summary>
        /// Funkcija koja stvara novi portfelj na burzi.
        /// </summary>
        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom vec postoji!");
            }

            Portfelj noviPortfelj = new Portfelj(inPortfolioID);
            _portfelji.Add(inPortfolioID, noviPortfelj);
        }

        /// <summary>
        /// Funkcija koja dodaje određeni broj dionica u portfelju.
        /// </summary>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji na burzi!");
            }
            if (numberOfShares <= 0)
            {
                throw new StockExchangeException("Broj dionica koje dodajete mora biti pozitivan!");
            }

            if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                _portfelji[inPortfolioID].UvecajBrojDionica(inStockName.ToLower(), numberOfShares);
            }
            else
            {
                _portfelji[inPortfolioID].DodajDionicuUPortfelj(inStockName.ToLower(), numberOfShares,
                                                                _dionice[inStockName.ToLower()]);
            }
        }

        /// <summary>
        /// Funkcija koja dodaje brise odreden broj dionica iz portfelja.
        /// </summary>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji na burzi!");
            }
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Dionica nije dio tog portfelja!");
            }
            _portfelji[inPortfolioID].UkloniBrojDionica(inStockName.ToLower(), numberOfShares);
        }

        /// <summary>
        /// Funkcija koja briše briše dionicu iz portfelja.
        /// </summary>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji na burzi!");
            }
            if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
            {
                throw new StockExchangeException("Dionica nije dio tog portfelja!");
            }
            _portfelji[inPortfolioID].UkloniDionicu(inStockName.ToLower());
        }

        /// <summary>
        /// Funkcija koja dohvaća broj portfelja na burzi.
        /// </summary>
        public int NumberOfPortfolios()
        {
            return _portfelji.Count;
        }

        /// <summary>
        /// Funkcija koja dohvaća broj dionica u traženom portfelju.
        /// </summary>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }

            return _portfelji[inPortfolioID].BrojDionicaUPortfelju();
        }

        /// <summary>
        /// Funkcija koja provjerava postoji li traženi portfelj na burzi.
        /// </summary>
        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfelji.ContainsKey(inPortfolioID);
        }

        /// <summary>
        /// Funkcija koja provjerava nalazi li se dionica u portfelju.
        /// </summary>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji na burzi!");
            }
            return _portfelji[inPortfolioID].SadrziDionicu(inStockName.ToLower());
        }

        /// <summary>
        /// Funkcija koja dohvaća broj dionice u traženom portfelj.
        /// </summary>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }
            if (!StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica s tim imenom ne postoji na burzi!");
            }
            return _portfelji[inPortfolioID].KolicinaDionicaUPortfelju(inStockName.ToLower());
        }

        /// <summary>
        /// Funkcija koja dohvaća vrijednost portfelja u određenom trenutku
        /// </summary>
        public Decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }

            return _portfelji[inPortfolioID].IzracunajVrijednostPortfelja(timeStamp);
        }

        /// <summary>
        /// Funkcija koja dohvaća mjeseču promjenu vrijednosti portfelja.
        /// </summary>
        public Decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj s tim imenom ne postoji na burzi!");
            }
            return _portfelji[inPortfolioID].IzracunajPostotakMjesecnePromjene(Year, Month);
        }
    }



    /// <summary>
    /// Klasa koja predstavlja Dionicu.
    /// Svaki objekt ovog tipa sadrzi ime, broj tih dionica te cijene kroz vrijeme.
    /// Ime dionice predstavlja kljuc i specificno je za svaku dionicu.
    /// Za svaku se dionicu u odredenim trenucima biljezi cijena koja vrijedni od trenutka u kojem je definirana do trenutka 
    /// definicije nove cijene. Cijena se moze unijeti za svaki trenutak (granularnost definicije vremena je 1ms).
    /// Cijena i broj dionica ne mogu biti negativni niti 0.
    /// </summary>
    public class Dionica
    {
        private string _imeDionice;                           // ime dionice
        private long _brojDionica;                            // broj dionica
        private Decimal _pocetnaCijena;                       // pocetna cijena dionice
        private DateTime _pocetakVazenjaCijene;               // trenutak od kojeg vrijedi pocetna cijena dionice
        private Dictionary<DateTime, decimal> _cijene;        // cijene i trenuci od kojih vrijede te cijene


        /// <summary>
        /// Konstruktor. Obavlja inicijalizaciju članskih varijabli klase Dionica.
        /// </summary>
        public Dionica(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            _imeDionice = inStockName.ToLower();
            _brojDionica = inNumberOfShares;
            _pocetnaCijena = inInitialPrice;
            _pocetakVazenjaCijene = inTimeStamp;
            _cijene = new Dictionary<DateTime, decimal> { { _pocetakVazenjaCijene, _pocetnaCijena } };
        }

        public long GetBrojDionica()
        {
            return _brojDionica;
        }

        /// <summary>
        /// Funkcija koja provjerava je li vec postoji definirana cijena sa danim trenutkom pocetka vazenja.
        /// </summary>
        public bool SadrziTimestamp(DateTime inTimeStamp)
        {
            return _cijene.ContainsKey(inTimeStamp);
        }


        /// <summary>
        /// Funkcija koja dodaje novu cijenu i njen trenutak pocetka vazenja.
        /// </summary>
        public void PostaviNovuCijenu(DateTime inTimeStamp, decimal price)
        {
            _cijene.Add(inTimeStamp, price);
        }


        /// <summary>
        /// Funkcija koja vraca cijenu dionice za neko vrijeme.
        /// </summary>
        public Decimal DohvatCijenu(DateTime vrijeme)
        {
            List<DateTime> listaTimestampova = new List<DateTime>(_cijene.Keys);
            listaTimestampova.Sort();
            if (vrijeme < listaTimestampova[0])
            {
                throw new StockExchangeException("Ne postoji cijena definirana za to vrijeme!");
            }
            if (vrijeme > listaTimestampova[listaTimestampova.Count - 1])
            {
                return _cijene[listaTimestampova[listaTimestampova.Count - 1]];
            }
            if (listaTimestampova.Contains(vrijeme))
            {
                return _cijene[vrijeme];
            }
            int i = 0;
            while (!(vrijeme < listaTimestampova[i]))
            {
                i++;
            }
            return _cijene[listaTimestampova[i - 1]];
        }


        /// <summary>
        /// Funkcija koja dohvaca pocetnu cijenu dionice.
        /// </summary>
        public Decimal DohvatiPocetnuCijenu()
        {
            List<DateTime> listaTimestampova = new List<DateTime>(_cijene.Keys);
            listaTimestampova.Sort();
            return _cijene[listaTimestampova[0]];
        }


        /// <summary>
        /// Funkcija koja dohvaca zadnju cijenu dionice.
        /// </summary>
        public Decimal DohvatiKonacnuCijenu()
        {
            List<DateTime> listaTimestampova = new List<DateTime>(_cijene.Keys);
            listaTimestampova.Sort();
            return _cijene[listaTimestampova[listaTimestampova.Count - 1]];
        }
    }



    /// <summary>
    /// Klasa koja predstavlja Index. Indeksi mogu biti 2 vrste: AVERAGE i WEIGHTED.
    /// Ime indeksa je kljuc bez obzira na tip indeksa.
    /// Indeks moze sadrzavati samo onu dionicu koja je na burzi. 
    /// Ista dionica se moze samo jednom pridjeliti indeksu.
    /// </summary>
    public class Index
    {
        private string _imeIndexa;                                 // ime indeksa
        private IndexTypes _tipIndexa;                             // tip indeksa(Average ili Weighted)
        private Dictionary<string, Dionica> _DioniceUIndexu;       // sve dionice koje pripadaju ovom indeksu

        /// <summary>
        /// Konstruktor. Obavlja inicijalizaciju članskih varijabli klase Index.
        /// </summary>
        public Index(string ime, IndexTypes tip)
        {
            _imeIndexa = ime;
            _tipIndexa = tip;
            _DioniceUIndexu = new Dictionary<string, Dionica>();
        }

        /// <summary>
        /// Funkcija koja dodaje dionicu u index.
        /// </summary>
        public void DodajDionicu(string imeDionice, Dionica dionica)
        {
            _DioniceUIndexu.Add(imeDionice, dionica);
        }

        /// <summary>
        /// Funkcija koja uklanja dionicu iz indeksa.
        /// </summary>
        public void UkloniDionicu(string imeDionice)
        {
            _DioniceUIndexu.Remove(imeDionice);
        }

        /// <summary>
        /// Funkcija koja provjerava je li dionica u indeksu.
        /// </summary>
        public bool ProvjeriPostojanjeDioniceUIndexu(string imeDionice)
        {
            return _DioniceUIndexu.ContainsKey(imeDionice);
        }

        /// <summary>
        /// Funkcija koja dohvaca broj dionica u indeksu.
        /// </summary>
        public int BrojDionica()
        {
            return _DioniceUIndexu.Count;
        }

        /// <summary>
        /// Funkcija za racunanje vrijednosti indeksa koja poziva pomocnu funkciju
        /// ovisno o tipu indeksa.
        /// </summary>
        public Decimal DohvatiVrijednostIndeksa(DateTime timestamp)
        {
            if (this._DioniceUIndexu.Count == 0)
            {
                return 0;
            }
            if (this._tipIndexa == IndexTypes.AVERAGE)
            {
                return IzracunajAwerage(timestamp);
            }
            return IzracunajWeighted(timestamp);
        }

        /// <summary>
        /// Pomocna funkcija racuna average vrijednost indeksa.
        /// </summary>
        private Decimal IzracunajAwerage(DateTime timestamp)
        {
            Decimal vrijednostIndeksa = 0;
            foreach (KeyValuePair<string, Dionica> pair in _DioniceUIndexu)
            {
                vrijednostIndeksa += pair.Value.DohvatCijenu(timestamp);
            }
            vrijednostIndeksa = vrijednostIndeksa / _DioniceUIndexu.Count;
            return Math.Round(vrijednostIndeksa, 3);
        }

        /// <summary>
        /// Pomocna funkcija racuna weighted vrijednost indeksa.
        /// </summary>
        private Decimal IzracunajWeighted(DateTime timestamp)
        {
            Decimal ukupnaVrijednostDionica = 0;
            Decimal vrijednostIndeksa = 0;

            foreach (KeyValuePair<string, Dionica> pair in _DioniceUIndexu)
            {
                ukupnaVrijednostDionica += (pair.Value.GetBrojDionica() * pair.Value.DohvatCijenu(timestamp));
            }
            foreach (KeyValuePair<string, Dionica> pair in _DioniceUIndexu)
            {
                Decimal brojnik = pair.Value.GetBrojDionica() * pair.Value.DohvatCijenu(timestamp);

                vrijednostIndeksa += (brojnik / ukupnaVrijednostDionica) * pair.Value.DohvatCijenu(timestamp);
            }
            return Math.Round(vrijednostIndeksa, 3);
        }
    }



    /// <summary>
    /// Klasa koja predstavlja portfelj. 
    /// ID portfelja je kljuc i jedinstven je za svaki portfelj.
    /// Portfelj sadrzi dionice, pri cemu je za svaku dionicu naznacena i kolicina te dionice sadrzana u portfelju.
    /// Moguce je izracunati vrijednost portfelja te postotak mjesecne promjene vrijednosti portfelja.
    /// </summary>
    public class Portfelj
    {
        private string _portfeljID;
        private Dictionary<string, int> _brojDionicaUPortfelju;
        private Dictionary<string, Dionica> _dioniceUPortfelju;

        /// <summary>
        /// Konstruktor. Obavlja inicijalizaciju članskih varijabli klase Portfelj.
        /// </summary>
        public Portfelj(string ime)
        {
            _portfeljID = ime;
            _brojDionicaUPortfelju = new Dictionary<string, int>();
            _dioniceUPortfelju = new Dictionary<string, Dionica>();
        }

        /// <summary>
        /// Funkcija koja provjerava nalazi li se dionica u portfelju.
        /// </summary>
        public bool SadrziDionicu(string imeDionice)
        {
            return _dioniceUPortfelju.ContainsKey(imeDionice);
        }

        /// <summary>
        /// Funkcija koja dodaje dionicu u portfelj.
        /// Suma broja tih dionica u portfelju ne može biti veća od ukupnog broja takvih izdanih dionica.
        /// </summary>
        public void DodajDionicuUPortfelj(string imeDionice, int brojDionica, Dionica dionica)
        {
            if ((long)brojDionica > dionica.GetBrojDionica())
            {
                throw new StockExchangeException("Ne postoji toliko dionica na burzi!");
            }
            _brojDionicaUPortfelju.Add(imeDionice, brojDionica);
            _dioniceUPortfelju.Add(imeDionice, dionica);
        }

        /// <summary>
        /// Funkcija koja dodaje novu kolicinu dionica koje vec postoje u portofoliju.
        /// Suma broja tih dionica u portfelju ne može biti veća od ukupnog broja takvih izdanih dionica.
        /// </summary>
        public void UvecajBrojDionica(string imeDionice, int brojDionica)
        {
            if ((long)brojDionica + _brojDionicaUPortfelju[imeDionice] > _dioniceUPortfelju[imeDionice].GetBrojDionica())
            {
                throw new StockExchangeException("Ne postoji toliko dionica na burzi!");
            }
            _brojDionicaUPortfelju[imeDionice] = _brojDionicaUPortfelju[imeDionice] + brojDionica;
        }

        /// <summary>
        /// Funkcija koja dohvaća broj dionica u traženom portfelj.
        /// </summary>
        public int BrojDionicaUPortfelju()
        {
            return _dioniceUPortfelju.Count;
        }

        /// <summary>
        /// Funkcija koja brise dionicu iz portfelja.
        /// </summary>
        public void UkloniDionicu(string imeDionice)
        {
            _brojDionicaUPortfelju.Remove(imeDionice);
            _dioniceUPortfelju.Remove(imeDionice);
        }

        /// <summary>
        /// Funkcija koja dohvaca broj neke dionice u portfelju.
        /// </summary>
        public int KolicinaDionicaUPortfelju(string imeDionica)
        {
            if (!SadrziDionicu(imeDionica))
            {
                return 0;
            }
            return _brojDionicaUPortfelju[imeDionica];
        }

        /// <summary>
        /// Funkcija koja brise određeni broj dionica iz portfelja.
        /// Portfelj ne moze sadrzavati 0 dionica te se u tom slucaju dionica brise iz portfelja.
        /// </summary>
        public void UkloniBrojDionica(string imeDionica, int brojDionica)
        {
            if (brojDionica >= _brojDionicaUPortfelju[imeDionica])
            {
                UkloniDionicu(imeDionica);
            }
            else
            {
                _brojDionicaUPortfelju[imeDionica] = _brojDionicaUPortfelju[imeDionica] - brojDionica;
            }
        }

        /// <summary>
        /// Funkcija koja racuna vrijednost portfelja.
        /// </summary>
        public Decimal IzracunajVrijednostPortfelja(DateTime timestamp)
        {
            Decimal vrijednostPortfelja = 0;
            foreach (KeyValuePair<string, Dionica> pair in _dioniceUPortfelju)
            {
                vrijednostPortfelja += pair.Value.DohvatCijenu(timestamp) * _brojDionicaUPortfelju[pair.Key];
            }
            return Math.Round(vrijednostPortfelja, 3);
        }

        /// <summary>
        /// Funkcija koja racuna postotak mjesecne promjene vrijednosti portfelja.
        /// Da bi se mogao izracunati postotak promjene potrebno je imati definiranu cijenu svih dionica
        /// u portfelju za prvi i zadnji dan u mjesecu za koji se trazi ta vrijednost.
        /// </summary>
        public Decimal IzracunajPostotakMjesecnePromjene(int Year, int Month)
        {
            if (this._brojDionicaUPortfelju.Count == 0)
            {
                return 0;
            }

            int brojDana = DateTime.DaysInMonth(Year, Month);
            DateTime pocetak = new DateTime(Year,Month,1,00,00,00);
            DateTime kraj = new DateTime(Year,Month,brojDana,23,59,59,999);

            Decimal vrijednostPortfeljaPocetakMjeseca = IzracunajVrijednostPortfelja(pocetak);
            Decimal vrijednostPortfeljaKrajMjeseca = IzracunajVrijednostPortfelja(kraj);

            Decimal postotakPromjene = ((vrijednostPortfeljaKrajMjeseca - vrijednostPortfeljaPocetakMjeseca)/
                                       vrijednostPortfeljaPocetakMjeseca)*100;

            return Math.Round(postotakPromjene, 3);
        }
    }
}
