﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<String, Stock> currentStocks;
         private Dictionary<String, Index> currentIndexes;
         private Dictionary<String, Portfolio> currentPortfolios;

         public StockExchange () {
             currentIndexes = new Dictionary<string, Index> ();
             currentPortfolios = new Dictionary<string, Portfolio> ();
             currentStocks = new Dictionary<string, Stock> ();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             //provjera postoji li već ta vrsta dionice
             if (!StockExists(inStockName)) {
                 //stvaranje nove dionice
                 if (inNumberOfShares > 0 && inInitialPrice > 0) {
                     Stock stock = new Stock ( inStockName, inNumberOfShares, inInitialPrice, inTimeStamp );
                     //dodavanje dionice u rječnik dionica burze
                     currentStocks.Add(inStockName.ToLower(), stock);
                 } else {
                     throw new StockExchangeException ("Broj i cijena dionica moraju biti veći od 0!");
                 } 
             } else {
                 //dionica s tim imenom već postoji
                 throw new StockExchangeException("Dionica je već definirana");

             }
             
         }

         public void DelistStock(string inStockName)
         {
             try
             {
                 Stock stock = currentStocks[inStockName.ToLower()];
                 //brisanje dionice iz indeksa koji ju sadrže
                 foreach (Index i in currentIndexes.Values)
                 {
                     if (i.IsStockInIndex(stock))
                     {
                         i.RemoveStock(stock);
                     }
                 }
                 //brisanje dionice iz portfelja koji ju sadrže
                 foreach (Portfolio p in currentPortfolios.Values) {
                     if (p.ContainsStock ( inStockName.ToLower () )) {
                         p.RemoveStock ( inStockName.ToLower () );
                     }
                 }
                 currentStocks.Remove ( inStockName.ToLower() );
             }catch (Exception e){
                 //ako takva dionica ne postoji prijavljuje se pogreška
                 throw new StockExchangeException ( "Brisanje nepostojeće dionice! " + e.Message );
             }
         }

         public bool StockExists(string inStockName)
         {
             if (currentStocks.ContainsKey(inStockName.ToLower())) {
                 return true;
             } else {
                 return false;
             }
         }

         public int NumberOfStocks()
         {
             return currentStocks.Count ();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = currentStocks[inStockName.ToLower()];
             stock.SetPrice ( inIimeStamp, inStockValue );
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = currentStocks [inStockName.ToLower ()];
             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = currentStocks [inStockName.ToLower ()];
             return stock.GetInitalPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = currentStocks [inStockName.ToLower ()];
             return stock.GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             Index index;
             switch (inIndexType) {
                 case IndexTypes.AVERAGE:
                     index = new AverageIndex ( inIndexName );
                     currentIndexes.Add(inIndexName.ToLower(), index);
                     break;
                 case IndexTypes.WEIGHTED:
                     index = new WeightedIndex ( inIndexName );
                     currentIndexes.Add ( inIndexName.ToLower (), index );
                     break;
                 default:
                     throw  new StockExchangeException("Neispravan tip!");
                     break;
             }    
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = currentStocks [inStockName.ToLower ()];
             //provjera postoji li ta dionica na burzi
             if (stock != null) {
                 Index index = currentIndexes [inIndexName.ToLower ()];
                 //provjera je li ta dionica već u indeksu
                 if (!index.getStockList ().Contains ( stock )) {
                     index.AddStock ( stock );
                 } else {
                     throw new StockExchangeException ( "Dionica već postoji u tom indeksu!" );
                 }
             } else {
                 throw new StockExchangeException ( "Ne postoji dionica sa zadanim imenom na burzi!" );
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
            Stock stock = currentStocks [inStockName.ToLower ()];
            Index index = currentIndexes [inIndexName.ToLower ()];
            //provjera postoji li ta dionica u indeksu
            if (index.getStockList ().Contains ( stock )) {
                index.RemoveStock ( stock );
            } else {
                throw new StockExchangeException ( "Brisanje nepostojeće dionice iz indeksa!" );
            }

         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Stock stock = currentStocks [inStockName.ToLower ()];
             Index index = currentIndexes [inIndexName.ToLower ()];
             return index.IsStockInIndex ( stock );
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = currentIndexes [inIndexName.ToLower ()];
             return index.countIndexValue ( inTimeStamp );
         }

         public bool IndexExists(string inIndexName)
         {
             return currentIndexes.ContainsKey ( inIndexName.ToLower () );
         }

         public int NumberOfIndices()
         {
             return currentIndexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             try {
                 //hvatanje iznimke u slučaju da je unsesno ime nepostojećeg indeksa
                 Index index = currentIndexes [inIndexName.ToLower ()];
                 return index.getStockList ().Count;
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             try {
                 //hvatanje iznimke u slučaju da već postoji portfelj istoga imena
                 Portfolio portfolio = new Portfolio ( inPortfolioID );
                 currentPortfolios.Add(inPortfolioID, portfolio);
             } catch (Exception e) {
                 throw new StockExchangeException ( "Greska! " + e.Message );
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             long sumNumOfStocks = 0;
             long allowedNumOfShares = 0;
             try {
                 //izračun ukupnog broja dionica u ostalim portfeljima
                 foreach (Portfolio p in currentPortfolios.Values){
                     Stock s = p.findStockByName(inStockName);
                     if (s != null){
                         sumNumOfStocks += p.GetNumOfShares(s);
                     }
                 }
                 Portfolio port = currentPortfolios [inPortfolioID];
                 Stock st = currentStocks [inStockName.ToLower ()];
                 //izračun broja dionica koje je  moguće dodati
                 allowedNumOfShares = st.getNumberOfShares - sumNumOfStocks;
                 //provjera je li zadani broj ispravan i može li se dodati toliko dionica
                 if (numberOfShares <= allowedNumOfShares) {
                     port.AddStock ( st, numberOfShares );
                 }
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 Portfolio port = currentPortfolios [inPortfolioID];
                 port.RemoveStock ( inStockName, numberOfShares );
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 Portfolio port = currentPortfolios [inPortfolioID];
                 port.RemoveStock ( inStockName);
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public int NumberOfPortfolios()
         {
             return currentPortfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 return (int)currentPortfolios [inPortfolioID].CountStocks ();
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 return currentPortfolios.ContainsKey ( inPortfolioID );
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 return currentPortfolios [inPortfolioID].ContainsStock ( inStockName );
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 return (int)currentPortfolios [inPortfolioID].NumberOfShares ( inStockName );
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             try {
                 //hvatanje iznimke u slučaju unosa nepostojećeg naziva
                 return currentPortfolios [inPortfolioID].GetValue(timeStamp);
             } catch (Exception e) {
                 throw new StockExchangeException ( e.Message );
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {

             Portfolio port = currentPortfolios [inPortfolioID];
             return port.GetMonthPercentChange(Year, Month);
         }
     }

    public class Stock {

        private String stockName;
        private SortedDictionary<DateTime, Decimal> stockPrices;
        private long numberOfShares;

        public Stock ( String name, long number, Decimal price, DateTime time ) {
            stockName = name;
            numberOfShares = number;
            stockPrices = new SortedDictionary<DateTime, decimal> ();
            stockPrices.Add ( time, price );
        }

        public String getStockName {
            get {
                return stockName.ToLower();
            }
        }

        public long getNumberOfShares {
            get {
                return numberOfShares;
            }
        }

        public void SetPrice ( DateTime time, Decimal value ) {
            try {
                stockPrices.Add(time, value);
            } catch (Exception e) {
                //prijava pogreške, npr. pokušava se postaviti vrijednost za trenutak koji je već definiran
                throw new StockExchangeException ( e.Message );
            }
        }

        public Decimal GetPrice ( DateTime time ) {
            //vrijeme najbliže zadanom trenutku u kojem je definirana određena cijena
            DateTime maxTime = stockPrices.First().Key;
            //provjera je li dionica bila definirana u zadanom trenutku
            if (time < maxTime) {
                throw  new StockExchangeException("U tom trenutku nije definirana vrijednos dionice!");
            }
            //pronalaženje donje granice intervala u kojem je zadano vrijeme
            foreach (DateTime t in stockPrices.Keys){
                if (t <= time) {
                    maxTime = t;
                } else {
                    break;
                }
            }
            return stockPrices [maxTime];
        }

        public Decimal GetInitalPrice () {
            //vraća najstariju vrijednost dionice
            return stockPrices.First().Value;
        }

        public Decimal GetLastPrice () {
            //vraća vremenski najnoviju vrijednost dionice
            return stockPrices.Last ().Value;
        }

    }

    public abstract class Index {
        private String indexName;
        protected List<Stock> stocks;

        public Index (String name) {
            indexName = name.ToLower();
            stocks = new List<Stock> ();
        }

        public String getIndexName () {
            return indexName;
        }

        public List<Stock> getStockList () {
            return stocks;
        }

        public abstract Decimal countIndexValue ( DateTime time );

        public void AddStock ( Stock stock ) {
            stocks.Add ( stock );
        }

        public void RemoveStock ( Stock stock ) {
            stocks.Remove ( stock );
        }

        public bool IsStockInIndex ( Stock stock ) {
            return stocks.Contains ( stock );
        }
    }

    public class AverageIndex : Index {

        public AverageIndex ( String name ) : base ( name ) { }

        public override Decimal countIndexValue ( DateTime time ) {
            Decimal sum = 0;
            foreach (Stock s in stocks) {
                sum += s.GetPrice ( time );
            }
            //za prazni index vrijednost ostaje 0
            if (sum > 0)
            {
                return Decimal.Round(sum/stocks.Count, 3);
            }
            else
            {
                return sum;
            }
        }
    }

    public class WeightedIndex : Index {

        public WeightedIndex ( String name ) : base ( name ) { }

        public override Decimal countIndexValue ( DateTime time ) {
            Decimal sum = 0;
            Decimal value = 0;
            //Ukupna vrijednost svih dionica u indeksu
            foreach (Stock s in stocks) {
                sum += s.GetPrice ( time ) * s.getNumberOfShares;
            }
            //računanje vrijednosti indeksa ako postoje dionice u indeksu, inače ostaje 0
            if (sum > 0)
            {
                foreach (Stock s in stocks)
                {
                    value += s.GetPrice(time)*s.GetPrice(time)*s.getNumberOfShares/sum;
                }
            }
            return Decimal.Round(value, 3);
        }
    }

    public class Portfolio {
        private String portfolioID;
        private Dictionary<Stock, long> stocks;

        public Portfolio (String id){
            portfolioID = id;
            stocks = new Dictionary<Stock, long> ();
        }

        public void AddStock ( Stock stock, long num ){
            //ako dionica već postoji količina se zbraja, inače se dodaje nova
            if (stocks.ContainsKey(stock)) {
                stocks [stock] = stocks [stock] + num;
            } else{
                stocks.Add ( stock, num ); 
            }
            
        }

        public Stock findStockByName ( String name ) {
            foreach (Stock s in stocks.Keys) {
                if (s.getStockName == name.ToLower()) {
                    return s;
                }
            }
            return null;
        }
        
        public long GetNumOfShares(Stock s){
            return stocks[s];
        }

        public void RemoveStock ( String name, long number) {
            Stock stock = findStockByName (name);
            long newNumber = stocks [stock] - number;
            if (newNumber > 0) {
                stocks [stock] = newNumber;
            } else {
                //portfelj ne smije sadržavati 0 dionica
                stocks.Remove ( stock );
            }
        }

        public void RemoveStock ( string name ) {
            Stock stock = findStockByName ( name );
            if (stock != null)
            {
                stocks.Remove(stock);
            }
            else
            {
                throw new  StockExchangeException("Dionica s takvim imenom ne postoij!");
            }
        }

        public long CountStocks (){
            return stocks.Count;
        }

        public bool ContainsStock ( String name ) {
            Stock stock = findStockByName ( name );
            if (stock != null) {
                return true;
            } else{
                return false;
            }
        }

        public long NumberOfShares ( String name ) {
            Stock stock = findStockByName ( name );
            if (stock != null)
            {
                return stocks[stock];
            }
            else
            {
                throw new StockExchangeException ( "Dionica s takvim imenom ne postoij!" );
            }
        }

        public decimal GetValue ( DateTime time ) {
            decimal value = 0;
            try
            {
                //ako nema dionica vrijednost će ostati 0
                foreach (Stock st in stocks.Keys)
                {
                    value += st.GetPrice(time)*stocks[st];
                }
            }
            catch (Exception e)
            {
                throw  new StockExchangeException("Nije moguće izračunati vrijednost!");
            }
            return value;
        }

        public Decimal GetFirstValueInMonth ( int year, int month ) {
            int day = 1;
            int hour = 0;
            int minute = 0;
            int second = 0;
            int milisec = 0;
            DateTime time = new DateTime ( year, month, day, hour, minute, second, milisec );
            return GetValue ( time );
        }

        public Decimal GetLastValueInMonth ( int year, int month ) {
            int day = DateTime.DaysInMonth ( year, month );
            int hour = 23;
            int minute = 59;
            int second = 59;
            int milisec = 999;
            DateTime time = new DateTime ( year, month, day, hour, minute, second, milisec );
            return GetValue ( time );
        }

        public Decimal GetMonthPercentChange(int y, int m)
        {
            Decimal value = 0;
            Decimal last = GetLastValueInMonth(y, m);
            Decimal first = GetFirstValueInMonth(y, m);
            //vrijednost se računa samo za portfelje koji imaju bar jednu dionicu, inače ostaje 0
            if (last > 0 && first > 0)
            {
                value = (GetLastValueInMonth(y, m) - GetFirstValueInMonth(y, m))/GetFirstValueInMonth(y, m);
            }
            value = value * 100;
            return Decimal.Round ( value, 3 );
        }
    }
}
