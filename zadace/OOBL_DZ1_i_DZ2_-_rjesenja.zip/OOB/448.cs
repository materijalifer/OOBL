﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR"); //upitna korisnost kad pretvaram double->string i obrnuto
            Inicijaliziraj();
        }

        private void Inicijaliziraj()
        {
            prikazNaEkranu = "0";
            prviOperand = "";
            memorija = 0;
            unesenDecimalniZarez = false;
            izvedenaJeUnarnaOperacija = false;
            zadnjiPritisnutiZnak = "";
            noviOperand = true;
            greska = false;
            tmpKodZareza = "";
        }

        private string prikazNaEkranu; //uvijek sadrži ono kaj se treba ispisati na ekranu
        private string prviOperand; //prije uneseni operand za binarne operacije
        private string zadnjiPritisnutiZnak; //pamti samo binarne operatore
        private bool izvedenaJeUnarnaOperacija; //pamti da je u korkau prije izvedena unarna operacija (zbog pravila o ignoriranju u posebnom slučaju)
        private double memorija;
        private bool unesenDecimalniZarez;
        private bool noviOperand; //da nakon operacije ne dodaje novi broj na ono kaj je na ekranu
        private bool greska; //ako nastupi greška, treba stisnut reset
        private string tmpKodZareza; //ako se unese 2Q,= ovaj zarez mi ispisuje 0, pa ne želim imati to nego 2Q=

        public void Press(char inPressedDigit)
        {
            if (!greska)
            {
                ObradiOperaciju(inPressedDigit);
            }
            else
            {
                if (inPressedDigit == 'O')
                {
                    Inicijaliziraj();
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return VratiIspisNaEkranu();
        }

        private void ObradiOperaciju(char znak)
        {
            switch (znak)
            {
                #region UnarneOperacije
                case 'S':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaSinus();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                case 'K':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaKosinus();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                case 'T':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaTangens();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                case 'Q':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaKvadriranje();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                case 'R':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaKorjenovanje();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                case 'I':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaInverz();
                    izvedenaJeUnarnaOperacija = true;
                    break;
                #endregion
                #region BinarneOperacije
                case '+':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    BinarniOperator("+");
                    //noviOperand = true;
                    break;
                case '-':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    BinarniOperator("-");
                    //noviOperand = true;
                    break;
                case '*':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    BinarniOperator("*");
                    //noviOperand = true;
                    break;
                case '/':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    BinarniOperator("/");
                    //noviOperand = true;
                    break;
                #endregion
                case 'P':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    OperacijaSpremanje();
                    break;
                case ',':
                    ZnakZarez();
                    izvedenaJeUnarnaOperacija = false;
                    break;
                case '=':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    ZnakJednako();
                    break;
                case 'C':
                    prikazNaEkranu = "0";
                    break;
                case 'O':
                    Inicijaliziraj();
                    break;
                case 'G':
                    //ZnakBroj(memorija.ToString());
                    prikazNaEkranu = memorija.ToString();
                    break;
                case 'M':
                    MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak();
                    PromijeniPredznak();
                    break;
                #region Brojevi
                case '0':
                    ZnakBroj("0");
                    break;
                case '1':
                    ZnakBroj("1");
                    break;
                case '2':
                    ZnakBroj("2");
                    break;
                case '3':
                    ZnakBroj("3");
                    break;
                case '4':
                    ZnakBroj("4");
                    break;
                case '5':
                    ZnakBroj("5");
                    break;
                case '6':
                    ZnakBroj("6");
                    break;
                case '7':
                    ZnakBroj("7");
                    break;
                case '8':
                    ZnakBroj("8");
                    break;
                case '9':
                    ZnakBroj("9");
                    break;
                #endregion
                default:
                    throw new NotSupportedException();
            }
        }

        private void PromijeniPredznak()
        {
            if (prikazNaEkranu.Length == 1 && prikazNaEkranu == "0")
            {
                return;
            }
            prikazNaEkranu = prikazNaEkranu.Insert(0, "-");
        }


        private void ZnakJednako()
        {
            if (zadnjiPritisnutiZnak != "")
            {
                double rez;
                switch (zadnjiPritisnutiZnak)
                {
                    case "+":
                        rez = double.Parse(prviOperand) + double.Parse(prikazNaEkranu);
                        break;
                    case "-":
                        if (noviOperand == true)
                        {
                            rez = double.Parse(prviOperand) - double.Parse(prikazNaEkranu);
                        }
                        else
                        {
                            rez = -double.Parse(prviOperand) - double.Parse(prikazNaEkranu);
                        }
                        break;
                    case "*":
                        rez = double.Parse(prviOperand) * double.Parse(prikazNaEkranu);
                        break;
                    case "/":
                        if (double.Parse(prikazNaEkranu) == 0)
                        {
                            DogodilaSePogreska();
                            return;
                        }
                        rez = double.Parse(prviOperand) / double.Parse(prikazNaEkranu);
                        break;
                    default:
                        throw new NotSupportedException();
                }
                rez = ZaokruziRezultat(rez);
                if (double.IsNaN(rez))
                {
                    return;
                }
                string[] splitted = (rez.ToString()).Split(',');
                if (splitted.Length == 2)
                {
                    prikazNaEkranu = SrediIspis(splitted[0], splitted[1]);
                }
                else
                {
                    prikazNaEkranu = splitted[0];
                }
                prviOperand = prikazNaEkranu;
                izvedenaJeUnarnaOperacija = false;
                noviOperand = false;
                zadnjiPritisnutiZnak = "";
            }
            else
            {
                string[] splitted = prikazNaEkranu.Split(',');
                if (splitted.Length == 1) //nema decimalnog dijela
                {
                    prikazNaEkranu = SrediIspis(splitted[0], "");
                }
                else
                {
                    prikazNaEkranu = SrediIspis(splitted[0], splitted[1]);
                }
                prviOperand = prikazNaEkranu;
                izvedenaJeUnarnaOperacija = false;
                noviOperand = false;
            }
        }

        /// <summary>
        /// Stavlja vrijednost unesenDecimalniZarez na false
        /// Postavlja znak u zadnjiPritisnutiZnak
        /// Stavlja noviOperand na false
        /// </summary>
        /// <param name="znak"></param>
        private void BinarniOperator(string znak)
        {
            unesenDecimalniZarez = false;
            if (zadnjiPritisnutiZnak != "") //ako je već pritisnut neki binarni operator, znači već postoji prvi operand 
            {
                if (prikazNaEkranu == prviOperand && noviOperand == false && izvedenaJeUnarnaOperacija == false) //2+3+*-/ ili 2+3++++  1+1+1
                {
                    //ne radi ništa
                }
                else
                {
                    double rez;
                    switch (zadnjiPritisnutiZnak)
                    {
                        case "+":
                            rez = double.Parse(prviOperand) + double.Parse(prikazNaEkranu);
                            break;
                        case "-":
                            rez = double.Parse(prviOperand) - double.Parse(prikazNaEkranu);
                            break;
                        case "*":
                            rez = double.Parse(prviOperand) * double.Parse(prikazNaEkranu);
                            break;
                        case "/":
                            if (double.Parse(prikazNaEkranu) == 0)
                            {
                                DogodilaSePogreska();
                                return;
                            }
                            rez = double.Parse(prviOperand) / double.Parse(prikazNaEkranu);
                            break;
                        default:
                            throw new NotSupportedException();
                    }
                    rez = ZaokruziRezultat(rez);
                    if (double.IsNaN(rez))
                    {
                        return;
                    }
                    string[] splitted = (rez.ToString()).Split(',');
                    if (splitted.Length == 2)
                    {
                        prikazNaEkranu = SrediIspis(splitted[0], splitted[1]);
                    }
                    else
                    {
                        prikazNaEkranu = splitted[0];
                    }
                    prviOperand = prikazNaEkranu;
                    izvedenaJeUnarnaOperacija = false;
                    noviOperand = false;
                }
            }
            else // prvi put je pritisnuta binarna operacije, spremi u prvi operand ono kaj je na ekranu
            {
                string[] splitted = prikazNaEkranu.Split(',');
                if (splitted.Length == 1) //nema decimalnog dijela
                {
                    prikazNaEkranu = SrediIspis(splitted[0], "");
                }
                else
                {
                    prikazNaEkranu = SrediIspis(splitted[0], splitted[1]);
                }
                prviOperand = prikazNaEkranu;
                izvedenaJeUnarnaOperacija = false;
                noviOperand = false;
            }
            zadnjiPritisnutiZnak = znak;
        }

        /// <summary>
        /// Ako je pritisnut broj, a na ekranu je rezultat dobiven unarnom operacijom, briše ga
        /// Dodaje broj na kraj ako ima mjesta, inače ga zanemaruje
        /// Poništava vrijednost zastavice izvedenaJeUnarnaOperacija
        /// </summary>
        /// <param name="broj"></param>
        private void ZnakBroj(string broj)
        {
            //ako je pritinsut binarni znak i onda broj ili nakon unarne operacije je pritisnut broj
            if (zadnjiPritisnutiZnak != "" && noviOperand == false || izvedenaJeUnarnaOperacija == true && noviOperand == false)
            {
                noviOperand = true;
                prikazNaEkranu = broj;
                izvedenaJeUnarnaOperacija = false;
                return;
            }

            //ako stisnemo broj, a na ekranu je smao i jedino nula, makni tu nulu
            if (prikazNaEkranu[0] == '0' && prikazNaEkranu.Length == 1)
            {
                prikazNaEkranu = broj;
                return;
            }

            //ako je izvedena unarna operacija, ne smiješ dodati broj na njen kraj
            int duljina = prikazNaEkranu.Length;
            if (izvedenaJeUnarnaOperacija == true)
            {
                prikazNaEkranu = broj;
            }
            else
            {
                //if (noviOperand)
                //{
                //    prikazNaEkranu = broj;
                //    noviOperand = false;
                //    return;
                //}
                if (unesenDecimalniZarez)
                {
                    if (prikazNaEkranu[0] == '-')
                    {
                        if (duljina < 12) //ako je - i , na ekranu, smiješ dodati broj ako je duljina manja od 12
                        {
                            prikazNaEkranu += broj;
                        }
                    }
                    else //nema znaka predznaka, pa smiješ dodati broj ako je duljina manja od 11
                    {
                        if (duljina < 11)
                        {
                            prikazNaEkranu += broj;
                        }
                    }
                }
                else
                {
                    if (prikazNaEkranu[0] == '-')
                    {
                        if (duljina < 11) //ako je - na ekranu, smiješ dodati broj ako je duljina manja od 11
                        {
                            prikazNaEkranu += broj;
                        }
                    }
                    else
                    {
                        if (duljina < 10)
                        {
                            prikazNaEkranu += broj;
                        }
                    }
                }
            }
            izvedenaJeUnarnaOperacija = false;
        }

        #region Znakovi

        /// <summary>
        /// Postavlja unesenDecimalniZarez
        /// Ako je izvedena unarna operacija(na ekranu je rezultat dobiven njome), briše taj rezultat
        /// Ako je zadnjiPritisnutiZnak neprazan, postavlja drugog operanda
        /// </summary>
        private void ZnakZarez()
        {
            if (!unesenDecimalniZarez)
            {
                unesenDecimalniZarez = true;
                tmpKodZareza = prikazNaEkranu;

                if (izvedenaJeUnarnaOperacija == true)
                {
                    prikazNaEkranu = "";
                }

                if (prikazNaEkranu == "")
                {
                    prikazNaEkranu += "0";
                }
                prikazNaEkranu += ",";

                //Prikaz na ekranu mi glumi drugog operanda
                //if (zadnjiPritisnutiZnak != "")//ono na ekranu je početak drugog operanda
                //{
                //    drugiOperand = prikazNaEkranu;
                //}
            }
        }

        private void OperacijaSpremanje()
        {
            memorija = double.Parse(prikazNaEkranu);
        }

        #endregion

        /// <summary>
        /// Brišu unesenDecimalniZarez
        /// Brišu zastavicu novi operand
        /// </summary>
        #region UnarneOperacije

        private void OperacijaInverz()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmp = double.Parse(prikazNaEkranu);
            if (tmp == 0)
            {
                DogodilaSePogreska(); //nema dijeljenja s nulom
                return;
            }

            double tmpRezultat = 1.0d / tmp; //PROVJERI DA NEBI MAKNUL DECIMALNI DIO
            tmpRezultat = ZaokruziRezultat(tmpRezultat);
            if (double.IsNaN(tmpRezultat))
            {
                return;
            }
            prikazNaEkranu = tmpRezultat.ToString();
        }

        private void OperacijaKorjenovanje()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmp = double.Parse(prikazNaEkranu);
            if (tmp < 0)
            {
                DogodilaSePogreska(); //nema korjenovanja negativnih brojeva
                return;
            }

            double tmpRezultat = Math.Sqrt(tmp);
            tmpRezultat = ZaokruziRezultat(tmpRezultat);
            if (double.IsNaN(tmpRezultat))
            {
                return;
            }
            prikazNaEkranu = tmpRezultat.ToString();
        }

        private void OperacijaKvadriranje()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmp = double.Parse(prikazNaEkranu);
            double tmpRezultat = tmp * tmp;

            tmpRezultat = ZaokruziRezultat(tmpRezultat);
            if (double.IsNaN(tmpRezultat))
            {
                return;
            }
            prikazNaEkranu = tmpRezultat.ToString();
        }

        private void OperacijaTangens()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmpRezultat = Math.Tan(double.Parse(prikazNaEkranu)); //Tangens nije definiran za pi/2, al ne mogu pogodit s brojevima 0-9 to
            tmpRezultat = ZaokruziRezultat(tmpRezultat);

            if (double.IsNaN(tmpRezultat))
            {
                return;
            }

            prikazNaEkranu = tmpRezultat.ToString();
        }

        private void OperacijaKosinus()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmpRezultat = Math.Cos(double.Parse(prikazNaEkranu));
            tmpRezultat = ZaokruziRezultat(tmpRezultat);
            if (double.IsNaN(tmpRezultat))
            {
                return;
            }
            prikazNaEkranu = tmpRezultat.ToString();
        }

        private void OperacijaSinus()
        {
            noviOperand = false;
            unesenDecimalniZarez = false;
            double tmpRezultat = Math.Sin(double.Parse(prikazNaEkranu));
            tmpRezultat = ZaokruziRezultat(tmpRezultat);
            if (double.IsNaN(tmpRezultat))
            {
                return;
            }
            prikazNaEkranu = tmpRezultat.ToString();
        }

        #endregion

        private double ZaokruziRezultat(double rez)
        {
            //pretvori u string
            string str = rez.ToString();
            //zamijeni vodeći minus ako postoji s praznim znakom
            if (str.Contains('-'))
            {
                str = str.Replace('-', ' ');
            }
            if (str.Contains('E'))
            {
                DogodilaSePogreska();
                return double.NaN;
            }
            //makni praznine
            str = str.Trim();
            string[] splitted = str.Split(',');
            int brojZnamenakaPrijeDecimalnogZareza = splitted[0].Length;
            if (brojZnamenakaPrijeDecimalnogZareza > 10)
            {
                DogodilaSePogreska();
                return double.NaN; //PAZI I PITAJ ZA OVAJ SLUČAJ
                //return će mi prebrisati(tj. gdje se vratim s return) ono kaj budme zapisal u varijablu prikazNaEkranu u metodi DogodilaSePogreska();
            }
            //imam 0, decimalni dio 
            double decimalniDioBroja;
            if (splitted.Length == 2)
            {
                decimalniDioBroja = double.Parse("0," + splitted[1]);
            }
            else
            {
                decimalniDioBroja = 0;
            }
            //zaokruži
            decimalniDioBroja = Math.Round(decimalniDioBroja, 10 - brojZnamenakaPrijeDecimalnogZareza);
            //parsiraj po zarezu
            string[] splitted2 = decimalniDioBroja.ToString().Split(',');
            //uzmi cjelobrojni dio od prije i decimalni dio od ovdje

            //string zaokruzeniRezultat = splitted[0] + "," + splitted2[1];
            string zaokruzeniRezultat = "";
            if (splitted2.Length == 2)
            {
                zaokruzeniRezultat = SrediIspis(splitted[0], splitted2[1]);
            }
            else
            {
                zaokruzeniRezultat = SrediIspis(splitted[0], "");
            }
            if (rez < 0)
            {
                zaokruzeniRezultat = zaokruzeniRezultat.Insert(0, "-");
            }

            return double.Parse(zaokruzeniRezultat);

        }

        private string VratiIspisNaEkranu()
        {
            return prikazNaEkranu;
        }

        private void DogodilaSePogreska()
        {
            prikazNaEkranu = "-E-";
            greska = true;
        }

        /// <summary>
        /// Miče nule iza decimalnog zareza ako su samo nule, miče zarez ako nema ništa iza njega
        /// Vraća broj sređen za prikaz na ekranu
        /// </summary>
        /// <param name="cjelobrojniDio"> cjelobrojni dio broja</param>
        /// <param name="decimalniDio"> decimalni dio broja(bez zareza)</param>
        /// <returns> valjani ispis na ekranu </returns>
        private string SrediIspis(string cjelobrojniDio, string decimalniDio)
        {
            int duljinaDecimalnogDijela = decimalniDio.Length;
            if (duljinaDecimalnogDijela == 0) //nema decimalnog dijela
            {
                return cjelobrojniDio;
            }
            else
            {
                int brojNula = 0;
                foreach (char c in decimalniDio)
                {
                    if (c == '0')
                    {
                        brojNula++;
                    }
                }
                if (brojNula == duljinaDecimalnogDijela)
                {
                    return cjelobrojniDio;
                }
                else
                {
                    return cjelobrojniDio + "," + decimalniDio;
                }
            }
        }

        private void MakniDecimalniZarezAkoJeIzaNjegaOperatorIliZnak() //pozvati za unarnu/binarnu operaciju, spremanje/dohvaćanje, predznak, jednako
        {
            if (prikazNaEkranu.Length == 2 && prikazNaEkranu[0] == '0' && prikazNaEkranu[1] == ',' && unesenDecimalniZarez==true)
            {
                prikazNaEkranu = tmpKodZareza;
                tmpKodZareza = "";
            }
        }
    }


}
