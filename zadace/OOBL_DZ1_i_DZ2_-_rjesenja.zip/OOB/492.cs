﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Calculator : ICalculator
    {
        private bool jeZakljucan;
        Zaslon zaslon;

        public Calculator()
        {
            jeZakljucan = false;
            zaslon = new Zaslon();
        }

        public void Press(char inPressedDigit)
        {
            if (jeZakljucan)
            {
                if (inPressedDigit == 'O' || inPressedDigit == 'C')
                {
                    zaslon.DodajNaZaslon(inPressedDigit);
                    jeZakljucan = false;
                }
            }
            else
            {
                zaslon.DodajNaZaslon(inPressedDigit);
                String s = zaslon.DohvatiSadrzajZaslona();
                if (s.Equals("-E-"))
                {
                    jeZakljucan = true;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            String s = zaslon.DohvatiSadrzajZaslona();
            return s;
        }
    }

    public class Zaslon
    {
        private static List<char> naredbeSDvaOperanda = new List<char> { '+', '-', '*', '/' };
        private static List<char> naredbeSJednimOperandom = new List<char> { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };

        private List<char> spremnik = new List<char>();
        private List<char> zaslonZaIspis = new List<char>() { '0' };

        private char prethodniUnarniOperator = '\0';
        private char prethodniBinarniOperator = '\0';
        private int brojacZnamenki = 0;
        private List<char> memorija = new List<char>();
        private NositeljNaredba nositelj = new NositeljNaredba();

        public void DodajNaZaslon(char c)
        {
            if (Char.IsNumber(c)) //ako je broj
            {
                if(brojacZnamenki < 10)
                { 
                    if (c == '0' && zaslonZaIspis.Count == 1 && zaslonZaIspis[0] == '0')//ako je ponovno unesena pocetna nula
                    {
                        //ne radi nista
                    }
                    else
                    {
                        brojacZnamenki++;
                        if (spremnik.Count > 0 && spremnik.Last() == ',') //ako je prethodno bio zarez
                        {
                            spremnik.Add(c);
                            zaslonZaIspis.Add(',');
                            zaslonZaIspis.Add(c);
                        }
                        else if (prethodniUnarniOperator != '\0' && prethodniUnarniOperator != 'M') //ako iza unarnog operatora dode broj, izbrisi iz zaslona spremljeni izracun
                        {
                            while (Char.IsNumber(spremnik.Last()) || spremnik.Last() == ',') //dok je zarez ili broj, brisi izracun
                            {
                                spremnik.Remove(spremnik.Last());
                            }
                            spremnik.Add(c); //dodaj novi broj
                            zaslonZaIspis.Clear();
                            zaslonZaIspis.Add(c);
                        }
                        else if (spremnik.Count > 0 && Char.IsNumber(spremnik.Last())) //ako je prethodni znak bio broj, dodaj novi broj
                        {
                            spremnik.Add(c);
                            zaslonZaIspis.Add(c);
                        }
                        else //ako je prethodni znak bio operacija ili pocetni ekran, ocisti zaslon i dodaj novi broj
                        {
                            spremnik.Add(c);
                            zaslonZaIspis.Clear();
                            zaslonZaIspis.Add(c);
                            brojacZnamenki = 1; //dodan jedan broj novog niza
                        }
                    }
                }
            }
            else if (c == ',') //ako je zarez
            {

                if (prethodniUnarniOperator != '\0' && prethodniUnarniOperator != 'M') //ako iza unarnog operatora dode broj, izbrisi iz zaslona spremljeni izracun
                {
                    int velicinaZaslona = zaslonZaIspis.Count() - 1;
                    int velicinaSpremnika = spremnik.Count() - 1;

                    ObrisiZadnjiZapisIzSpremnika(ref velicinaZaslona, ref velicinaSpremnika);
                }

                spremnik.Add(c);
            }
            else if (naredbeSJednimOperandom.Contains(c)) //ako je unarni operator
            {
                prethodniUnarniOperator = c;
                double rezultat = nositelj.izracunajOperacijuUnarnogOperatora(zaslonZaIspis, spremnik, c);
                brojacZnamenki = 0;
                if (spremnik.Contains('E'))
                {
                    
                    zaslonZaIspis = spremnik;
                }
                else
                {
                    zaslonZaIspis = ParserRezultata.skratiRezultat(rezultat);
                }
            }
            else if (naredbeSDvaOperanda.Contains(c)) // ako je binarni operator
            {
                brojacZnamenki = 0; //brojac znamenki zaslona postaviti na 0
                prethodniUnarniOperator = '\0';

                if (prethodniBinarniOperator == '\0') //ako je ovo prvi binarni operator
                {
                    prethodniBinarniOperator = c; //spremi ga na prethodni
                    if (spremnik.Count == 0) //ako je prvi znak binarni operator
                    {
                        spremnik.Add('0');
                    }
                    spremnik.Add(c);// dodaj u zaslon, ali ne zaslon za ispis
                }
                else
                {
                    if(naredbeSDvaOperanda.Contains(spremnik.Last()))//ako je zadnji znak bila naredba nad dva operanda, zanemari prethodnu naredbu
                    {
                        spremnik[spremnik.Count-1] = c;
                    }
                    else
                    {
                        double rezultat = nositelj.izracunajOperacijuBinarnogOperatora(prethodniBinarniOperator, spremnik, zaslonZaIspis);
                     
                        spremnik = ParserRezultata.skratiRezultat(rezultat);
                        spremnik.Add(c);
                        zaslonZaIspis = ParserRezultata.skratiRezultat(rezultat);
                    }
                    prethodniBinarniOperator = c;

                }
            }
            else if (c == '=')
            {
                prethodniUnarniOperator = '\0';
                brojacZnamenki = 0;

                if (spremnik.Count == 0) // prazni zaslon
                {
                    spremnik.Clear();
                    zaslonZaIspis.Clear();
                    zaslonZaIspis.Add('0');
                }
                else
                {
                    char zadnjiUnos = spremnik.Last();
                    if (Char.IsNumber(zadnjiUnos))// ako je zadnji unos broj
                    {   
                        if(prethodniBinarniOperator != '\0')
                        {
                            double rezultat = nositelj.izracunajOperacijuBinarnogOperatora(prethodniBinarniOperator, spremnik, zaslonZaIspis);
                            List<char> skraceniRezultat = ParserRezultata.skratiRezultat(rezultat);
                            StaviSkraceniRezultatNaZaslon(skraceniRezultat);
                            
                            prethodniBinarniOperator = '\0';
                        }
                    }
                    else if (naredbeSDvaOperanda.Contains(zadnjiUnos)) // npr. za 2+=
                    {
                        char broj = spremnik[spremnik.Count - 2];
                        spremnik.Add(broj);
                        double rezultat = nositelj.izracunajOperacijuBinarnogOperatora(prethodniBinarniOperator, spremnik, zaslonZaIspis);
                        List<char> skraceniRezultat = ParserRezultata.skratiRezultat(rezultat);
                        StaviSkraceniRezultatNaZaslon(skraceniRezultat);
                    }
                } 
            }
            else if (c == 'C')
            {
                while (Char.IsNumber(spremnik.Last()) || spremnik.Last() == ',') //dok je zarez ili broj, brisi izracun, odnosno obrisi zadnje dodano
                {
                    spremnik.Remove(spremnik.Last());
                }
                zaslonZaIspis.Clear();
                zaslonZaIspis.Add('0');
            }

            else if (c == 'P')
            {
                memorija.Clear();
                for (int i = 0; i < zaslonZaIspis.Count; i++)
                {
                    memorija.Add(zaslonZaIspis[i]);
                }
            }
            else if (c == 'G')
            {
                int velicinaZaslona = zaslonZaIspis.Count() -1;
                int velicinaSpremnika = spremnik.Count() -1;

                while (velicinaSpremnika >= 0 && velicinaZaslona >= 0) //izbrisati zadnje dodano u spremnik
                {
                    if (spremnik[velicinaSpremnika] == zaslonZaIspis[velicinaZaslona])
                    {
                        spremnik.RemoveAt(velicinaSpremnika);
                    }
                    velicinaSpremnika--;
                    velicinaZaslona--;
                }

                zaslonZaIspis.Clear();
                for (int j = 0; j < memorija.Count(); j++) //dodaj u spremnik dohvaceno iz memorije
                {
                    spremnik.Add(memorija[j]);
                    zaslonZaIspis.Add(memorija[j]);
                }
                
            }
            else if (c == 'O')
            {
                spremnik.Clear();
                memorija.Clear();
                zaslonZaIspis.Clear();
                zaslonZaIspis.Add('0');
            }
            else
            {
                spremnik.Clear();
                memorija.Clear();
                zaslonZaIspis.Clear();

                zaslonZaIspis.Add('-');
                zaslonZaIspis.Add('E');
                zaslonZaIspis.Add('-');
            }
        }

        private void ObrisiZadnjiZapisIzSpremnika(ref int velicinaZaslona, ref int velicinaSpremnika)
        {
            while (velicinaSpremnika >= 0 && velicinaZaslona >= 0) //izbrisati zadnje dodano u spremnik
            {
                if (spremnik[velicinaSpremnika] == zaslonZaIspis[velicinaZaslona])
                {
                    spremnik.RemoveAt(velicinaSpremnika);
                }
                velicinaSpremnika--;
                velicinaZaslona--;
            }
        }

        private void StaviSkraceniRezultatNaZaslon(List<char> skraceniRezultat)
        {
            zaslonZaIspis.Clear();
            spremnik.Clear();
            foreach (char ch in skraceniRezultat)
            {
                spremnik.Add(ch);
                zaslonZaIspis.Add(ch);
            }
        }

        public String DohvatiSadrzajZaslona()
        {
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < zaslonZaIspis.Count(); i++)
            {
                s.Append(zaslonZaIspis[i]);
            }
            string maknuteNulePoslijeZareza = "";
            try
            {
                maknuteNulePoslijeZareza = double.Parse(s.ToString()).ToString();
            }
            catch
            {
                maknuteNulePoslijeZareza = "-E-";
            }

            return maknuteNulePoslijeZareza;
        }
    }

    public class NositeljNaredba
    {
        public double izracunajOperacijuUnarnogOperatora(List<char> broj, List<char> zaslon, char c)
        {
            double clan = dohvatiBrojZaUnarnuOperaciju(broj);
            NaredbaNadJednimOperandom naredba = KreatorNaredbeNadJednimOperandom.dohvatiOperaciju(c);
            double rezultat = naredba.izracunaj(clan);
            urediNakonNaredbeSJednimOperatorom(zaslon, clan, rezultat);

            return rezultat;
        }

        public double izracunajOperacijuBinarnogOperatora(char binarniOperator, List<char> zaslon, List<char> zapisanoNaZaslonu)
        {
            NaredbaNadDvaOperanda naredba = KreatorNaredbeNadDvaOperanda.dohvatiOperaciju(binarniOperator);
            string prviOperand = dohvatiBrojZaBinarnuOperaciju(zaslon);
            String drugiOperand = new String(zapisanoNaZaslonu.ToArray());

            double rezultat = naredba.izracunaj(Double.Parse(prviOperand), Double.Parse(drugiOperand));

            return rezultat;
        }

        public double dohvatiBrojZaUnarnuOperaciju(List<char> lista)
        {
            StringBuilder s = new StringBuilder();

            for (int i = 0; i < lista.Count; i++)
            {
                s.Append(lista[i]);
            }

            return Double.Parse(s.ToString());
        }

        public string dohvatiBrojZaBinarnuOperaciju(List<char> lista)
        {
            StringBuilder s = new StringBuilder();

            for (int i = 0; i < lista.Count; i++)
            {
                if (Char.IsNumber(lista[i]) || lista[i] == ',')
                {
                   s.Append(lista[i]);
                }
                else
                {
                    if (i != 0)
                    {
                        break;
                    }
                    else
                    {
                        s.Append(lista[i]);
                    }
                }
            }

            return s.ToString();
        }

        public void urediNakonNaredbeSJednimOperatorom(List<char> lista, double clan, double rezultat)
        {
            char[] clanArray = clan.ToString().ToCharArray();
            char[] rezultatArray =  rezultat.ToString().ToCharArray();

            int i = lista.Count() - 1 ;
            int j = clanArray.Count() -1;

            if (Double.IsInfinity(rezultat))
            {
                lista.Clear();
                lista.Add('-');
                lista.Add('E');
                lista.Add('-');
            }
            else
            {
                while (i >= 0 && j >= 0)
                {
                    if (lista[i] == clanArray[j])
                    {
                        lista.RemoveAt(i);
                    }
                    i--;
                    j--;
                }

                for (int k = 0; k < rezultatArray.Length; k++)
                {
                    lista.Add(rezultatArray[k]);
                }
            }
        }
    }

    public class ParserRezultata
    {
        public static List<char> skratiRezultat(double rezultat)
        {
            List<char> rezultatLista = new List<char>();

            if (rezultat > Math.Pow(10, 10) || rezultat < -Math.Pow(10, 10))
            {
                rezultatLista.Add('-');
                rezultatLista.Add('E');
                rezultatLista.Add('-');
                return rezultatLista;
            }

            double pomocniRezultat; //pomocni rezultat za izracun broja znamenki prije zareza
            if (rezultat < 0)
            {
                pomocniRezultat = -rezultat;
            }
            else
            {
                pomocniRezultat = rezultat;
            }

            int znamenkiPrijeZareza = ((int)pomocniRezultat).ToString().Length;

            try
            {
                rezultat = Math.Round(rezultat, 10 - znamenkiPrijeZareza, MidpointRounding.AwayFromZero);
            }
            catch
            {}

            char[] r = rezultat.ToString().ToCharArray();
            int i = 0;
            int brojacZnamenki = 0;
            while (i < r.Count() && brojacZnamenki < 10)
            {
                if (Char.IsNumber(r[i]))
                {
                    rezultatLista.Add(r[i]);
                    brojacZnamenki++;
                }
                else if (r[i] == '-' || r[i] == ',')
                {
                    rezultatLista.Add(r[i]);
                }
                i++;
            }


            String s = new String(rezultatLista.ToArray());
            if(rezultatLista.Contains(',')) //ako sadrzi zarez rezi nule s kraja
            {
                s = s.TrimEnd();
            }
            rezultatLista = s.ToCharArray().ToList();
                
            return rezultatLista;
        }
    }

    public class KreatorNaredbeNadJednimOperandom
    {
        public static NaredbaNadJednimOperandom dohvatiOperaciju(char c)
        {
            if (c == 'S')
            {
                return new Sinus();
            }
            else if(c == 'K')
            {
                return new Kosinus();
            }
            else if (c == 'T')
            {
                return new Tangens();
            }
            else if (c == 'Q')
            {
                return new Kvadriranje();
            }
            else if (c == 'R')
            {
                return new Korjenovanje();
            }
            else if (c == 'I')
            {
                return new Inverz();
            }
            else if (c == 'M')
            {
                return new PromjenaPredznaka();
            }
            else
            {
                return null;
            }
        }
    }

    public class KreatorNaredbeNadDvaOperanda
    {
        public static NaredbaNadDvaOperanda dohvatiOperaciju(char c)
        {
            if (c == '+')
            {
                return new Zbrajanje();
            }
            else if (c == '-')
            {
                return new Oduzimanje();
            }
            else if (c == '*')
            {
                return new Mnozenje();
            }
            else if (c == '/')
            {
                return new Dijeljenje();
            }
            else
            {
                return null;
            }
        }
    }


    public abstract class NaredbaNadDvaOperanda
    {
        public abstract double izracunaj(double prviOperand, double drugiOperand);
    }

    public class Zbrajanje : NaredbaNadDvaOperanda
    {
        public override double izracunaj(double prviOperand, double drugiOperand)
        {
            return prviOperand + drugiOperand;
        }
    }

    public class Oduzimanje : NaredbaNadDvaOperanda
    {
        public override double izracunaj(double prviOperand, double drugiOperand)
        {
            return prviOperand - drugiOperand;
        }
    }

    public class Mnozenje : NaredbaNadDvaOperanda
    {
        public override double izracunaj(double prviOperand, double drugiOperand)
        {
            return prviOperand * drugiOperand;
        }
    }

    public class Dijeljenje : NaredbaNadDvaOperanda
    {
        public override double izracunaj(double prviOperand, double drugiOperand)
        {
            return prviOperand / drugiOperand;
        }
    }

    public abstract class NaredbaNadJednimOperandom
    {
        public abstract double izracunaj(double operand);
    }

    public class PromjenaPredznaka : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return -operand;
        }
    }

    public class Kvadriranje : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return operand * operand;
        }
    }

    public class Korjenovanje : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return Math.Sqrt(operand);
        }
    }

    public class Inverz : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return 1 / operand;
        }
    }

    public class Sinus : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return Math.Sin(operand);
        }
    }

    public class Kosinus : NaredbaNadJednimOperandom
    {

        public override double izracunaj(double operand)
        {
            return Math.Cos(operand);
        }
    }

    public class Tangens : NaredbaNadJednimOperandom
    {
        public override double izracunaj(double operand)
        {
            return Math.Tan(operand);
        }
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculator();
        }
    }

}
