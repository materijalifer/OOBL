﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    class DigiNum
    {
        public const string ERROR_STRING = "-E-";
        const int MAX_DIGITS = 10;

        bool isError;

        int decimalPlace;
        bool isNegative;
        string numberString;

        DigiNum(bool isError, bool isNegative, int decimalPlace, string numberString)
        {
            Initialize(isError, isNegative, decimalPlace, numberString);
        }
        public DigiNum()
        {
            Initialize(false, false, 0, "0");
        }

        void Initialize(bool isError, bool isNegative, int decimalPlace, string numberString)
        {
            this.isError = isError;
            this.isNegative = isNegative;
            this.decimalPlace = decimalPlace;
            this.numberString = numberString;
            RoundToTenDigits();
        }

        public DigiNum Clone()
        {
            return new DigiNum(isError, isNegative, decimalPlace, numberString);
        }

        public void Negate()
        {
            isNegative = !isNegative;
        }

        public void SetError()
        {
            isError = true;
        }

        public void AddToNum(char addDigit)
        {
            if (addDigit == ',')
                if (decimalPlace <= 0)
                    decimalPlace = numberString.Length;
                else
                    isError = true;
            else if (numberString == "0" && decimalPlace <= 0)
                numberString = addDigit.ToString();
            else if (numberString.Length < 10)
                numberString += addDigit.ToString();
        }

        public double GetDouble()
        {
            if (!isError)
            {
                return Double.Parse(this.ToString());
            }
            return 0d;
        }
        //public decimal GetDecimal()
        //{
        //    if (!isError)
        //    {
        //        return Decimal.Parse(this.ToString());
        //    }
        //    return 0M;
        //}

        public override string ToString()
        {
            if (isError) return ERROR_STRING;

            string displayString;

            if (decimalPlace <= 0 || decimalPlace == numberString.Length || numberString == ERROR_STRING)
                displayString = numberString;
            else
                displayString = numberString.Substring(0, decimalPlace) + "," + numberString.Substring(decimalPlace);

            if (isNegative) displayString = "-" + displayString;

            return displayString;
        }

        public static DigiNum FromNumeric(double d)
        {
            bool isNegative = d < 0 ? true : false;
            string numberString = d.ToString();
            if (isNegative)
                numberString = numberString.Remove(0, 1);
            int decimalPlace = numberString.IndexOf(',');
            if (decimalPlace >= 0)
                numberString = numberString.Remove(decimalPlace, 1);

            return new DigiNum(false, isNegative, decimalPlace, numberString);
        }
        //public static DigiNum FromNumeric(decimal d)
        //{
        //    bool isNegative = d < 0 ? true : false;
        //    string numberString = d.ToString();
        //    if (isNegative)
        //        numberString = numberString.Remove(0, 1);
        //    int decimalPlace = numberString.IndexOf(',');
        //    numberString = numberString.Remove(decimalPlace, 1);

        //    return new DigiNum(false, isNegative, decimalPlace, numberString);
        //}

        public void RoundToTenDigits()
        {
            if (numberString.Length > MAX_DIGITS)
            {
                if (decimalPlace > 10 || decimalPlace <= 0)
                {
                    isError = true;
                    return;
                }

                string roundedString = "";
                for (int i = 10; i >= 0; i--)
                    if (numberString[i] >= '5')
                    {
                        if (i == 0)
                            roundedString = "1" + roundedString;
                        else
                            if (numberString[i - 1] == '9')
                                roundedString = "0" + roundedString;
                            else
                            {
                                roundedString = (char)(numberString[i - 1] + 1) + roundedString;
                                break;
                            }
                    }
                    else
                        break;
                numberString = (numberString.Remove(MAX_DIGITS - roundedString.Length) + roundedString);
            }
            if (decimalPlace > 0)
                numberString = numberString.TrimEnd(new char[] { '0', ',' });
        }
    }

    public class Digitron : ICalculator
    {
        enum operation
        {
            add, sub, mul, div, none
        }

        DigiNum cumulativeResult;
        DigiNum memoryNum;
        DigiNum currentNum;

        bool hasEnoughOperands;
        operation currentOp;

        public Digitron()
        {
            cumulativeResult = new DigiNum();
            memoryNum = new DigiNum();
            currentNum = new DigiNum();

            hasEnoughOperands = false;
            currentOp = operation.none;
        }

        void doBinaryOpPart(operation newOp, DigiNum d)
        {
            if (!hasEnoughOperands)
            {
                if (currentOp == operation.none)
                {
                    cumulativeResult = d;
                    cumulativeResult.RoundToTenDigits();
                }
            }
            else
                switch (currentOp)
                {
                    case operation.none:
                        cumulativeResult = d;
                        cumulativeResult.RoundToTenDigits();
                        break;
                    case operation.add:
                        cumulativeResult = DigiNum.FromNumeric(cumulativeResult.GetDouble() + d.GetDouble());
                        break;
                    case operation.sub:
                        cumulativeResult = DigiNum.FromNumeric(cumulativeResult.GetDouble() - d.GetDouble());
                        break;
                    case operation.mul:
                        cumulativeResult = DigiNum.FromNumeric(cumulativeResult.GetDouble() * d.GetDouble());
                        break;
                    case operation.div:
                        if (d.GetDouble() == 0d)
                            cumulativeResult.SetError();
                        else
                            cumulativeResult = DigiNum.FromNumeric(cumulativeResult.GetDouble() / d.GetDouble());
                        break;
                    default:
                        break;
                }
            currentOp = newOp;
        }

        #region ICalculator Members

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit >= 48 && inPressedDigit <= 57 || inPressedDigit == ',')
            {
                if (!hasEnoughOperands)
                {
                    hasEnoughOperands = true;
                    currentNum = new DigiNum();
                }
                currentNum.AddToNum(inPressedDigit);
            }
            else
                switch (inPressedDigit)
                {
                    case '+':
                        doBinaryOpPart(operation.add, currentNum);
                        hasEnoughOperands = false;
                        break;
                    case '-':
                        doBinaryOpPart(operation.sub, currentNum);
                        hasEnoughOperands = false;
                        break;
                    case '*':
                        doBinaryOpPart(operation.mul, currentNum);
                        hasEnoughOperands = false;
                        break;
                    case '/':
                        doBinaryOpPart(operation.div, currentNum);
                        hasEnoughOperands = false;
                        break;
                    case '=':
                        if (hasEnoughOperands)
                        {
                            hasEnoughOperands = true;
                            doBinaryOpPart(operation.none, currentNum);
                            currentNum = cumulativeResult.Clone();
                        }
                        else
                        {
                            hasEnoughOperands = true;
                            doBinaryOpPart(operation.none, cumulativeResult);
                            currentNum = cumulativeResult.Clone();
                        }
                        break;
                    case 'M':
                        currentNum.Negate();
                        break;
                    case 'S':
                        currentNum = DigiNum.FromNumeric(Math.Sin(currentNum.GetDouble()));
                        break;
                    case 'K':
                        currentNum = DigiNum.FromNumeric(Math.Cos(currentNum.GetDouble()));
                        break;
                    case 'T':
                        currentNum = DigiNum.FromNumeric(Math.Tan(currentNum.GetDouble()));
                        break;
                    case 'Q':
                        currentNum = DigiNum.FromNumeric(Math.Pow(currentNum.GetDouble(), 2d));
                        break;
                    case 'R':
                        currentNum = DigiNum.FromNumeric(Math.Sqrt(currentNum.GetDouble()));
                        break;
                    case 'I':
                        if (currentNum.GetDouble() == 0d)
                            currentNum.SetError();
                        else
                            currentNum = DigiNum.FromNumeric(1d / currentNum.GetDouble());
                        break;
                    case 'P':
                        memoryNum = currentNum.Clone();
                        break;
                    case 'G':
                        currentNum = memoryNum.Clone();
                        hasEnoughOperands = true;
                        break;
                    case 'C':
                        currentNum = new DigiNum();
                        break;
                    case 'O':
                        cumulativeResult = new DigiNum();
                        memoryNum = new DigiNum();
                        currentNum = new DigiNum();
                        hasEnoughOperands = false;
                        currentOp = operation.none;
                        break;
                    default:
                        break;
                }
        }

        public string GetCurrentDisplayState()
        {
            //if (hasOperands)
            return currentNum.ToString();
            //else
            //    return cumulativeResult.ToString();
        }

        #endregion
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Digitron();
        }
    }
}
