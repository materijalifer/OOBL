using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

    #region indicies

    class AverageIndex : Index
    {
        public AverageIndex(string name)
        {
            this.name = name;
        }

        public override Decimal GetIndexValue(DateTime dt)
        {
            if (stocks.Count == 0) return 0;
            Decimal retVal = 0;
            Decimal wholeVal = 0;
            foreach (Stock stock in stocks)
            {
                wholeVal += stock.GetStockPrice(dt);
            }
            retVal = wholeVal / stocks.Count;
            return Decimal.Round(retVal, 3);
        }
    }

    class WeightedIndex : Index
    {
        public WeightedIndex(string name)
        {
            this.name = name;
        }

        public override Decimal GetIndexValue(DateTime dt)
        {

            Decimal retVal = 0;
            Decimal wholeValue = 0;
            foreach (Stock stock in stocks)
            {
                wholeValue += stock.GetStockPrice(dt) * stock.NumberOfShares;
            }
            if (wholeValue == 0) return 0;
            foreach (Stock stock in stocks)
            {
                retVal += stock.GetLastStockPrice() * stock.GetLastStockPrice() * stock.NumberOfShares / wholeValue;
            }
            return Decimal.Round(retVal, 3);
        }
    }

    abstract class Index
    {
        internal string name;
        internal List<Stock> stocks = new List<Stock>();

        public void AddStockToIndex(Stock stock)
        {
            if (stocks.Contains(stock))
            {
                throw new StockExchangeException("Indeks vec sadrzi zadanu dionicu!");
            }
            stock.addIndex(this);
            stocks.Add(stock);
        }

        public void RemoveStockFromIndex(Stock stock)
        {
            stock.removeIndex(this);
            stocks.Remove(stock);

        }

        public bool IsStockPartOfIndex(Stock stock)
        {
            return stock.containsIndex(this);
        }

        public int getStockNumber()
        {
            return stocks.Count;
        }

        public abstract Decimal GetIndexValue(DateTime dt);


    }

    class IndexFactory
    {
        public static Index CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (inIndexType == IndexTypes.AVERAGE) return new AverageIndex(inIndexName);
            if (inIndexType == IndexTypes.WEIGHTED) return new WeightedIndex(inIndexName);
            throw new StockExchangeException("Nepostoje?i tip indeksa!");
        }
    }

    #endregion


    #region portfolio
    class Portfolio
    {
        private string ID;
        private Dictionary<Stock, int> stocks;

        public Portfolio(string ID)
        {
            this.ID = ID;
            stocks = new Dictionary<Stock, int>();
        }

        public void addStockToPortfolio(Stock stock, int amount)
        {
            if (amount <= 0)
            {
                throw new StockExchangeException("Morate dodati pozitivan broj dionica!");
            }
            if (stocks.ContainsKey(stock))
            {
                int stockNum = stocks[stock];
                stockNum += amount;
                stocks[stock] = stockNum;
            }
            else
            {
                stocks.Add(stock, amount);
                stock.AddPortfolio(this);
            }
            stocks[stock] -= (int)stock.update();
        }

        public void removeStockFromPortfolio(Stock stock)
        {
            if (!stocks.ContainsKey(stock))
            {
                throw new StockExchangeException("Poku?avate portfelju oduzedi dionicu koja mu ne pripada!");
            }
            else
            {
                stocks.Remove(stock);
                stock.RemovePortfolio(this);
            }
        }

        public int getStockNumber()
        {
            return stocks.Count;
        }

        public bool isStockPartOfPortfolio(Stock stock)
        {
            return stocks.ContainsKey(stock);
        }

        public int NumberOfSharesOfStockInPortfolio(Stock stock)
        {
            if (!stocks.ContainsKey(stock))
            {
                return 0;
            }
            else
            {
                return stocks[stock];
            }
        }

        public void removeStockFromPortfolio(Stock stock, int amount)
        {
            if (amount <= 0)
            {
                throw new StockExchangeException("Ne mozete portfelju oduzeti negativan broj dionica!(ili 0)");
            }
            if (stocks.ContainsKey(stock))
            {
                int stockNum = stocks[stock];
                stockNum -= amount;
                if (stockNum <= 0)
                {
                    removeStockFromPortfolio(stock);
                }
                else
                {
                    stocks[stock] = stockNum;
                }

            }
            else
            {
                throw new StockExchangeException("Ne postoji zadana dionica u porfelju!");
            }
        }

        public Decimal GetPortfolioValue(DateTime dt)
        {
            Decimal value = 0;
            foreach (Stock stock in stocks.Keys)
            {
                value += stock.GetStockPrice(dt) * stocks[stock];
            }
            return Decimal.Round(value, 3);
        }

        public Decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            DateTime beginningOfMonth = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime endOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            if (GetPortfolioValue(beginningOfMonth) == 0)
            {
                return 0;
            }
            Decimal ratio = Decimal.Divide(GetPortfolioValue(endOfMonth) - GetPortfolioValue(beginningOfMonth), GetPortfolioValue(beginningOfMonth));
            return Decimal.Round(ratio * 100, 3);
        }
    }
    #endregion

    #region stock
    class Stock
    {
        private string stockName;
        private long numberOfShares;

        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }
        private Dictionary<DateTime, Decimal> priceHistory;
        private List<Index> indexes;
        private List<Portfolio> stockholders;
        private Decimal initialPrice;
        private Decimal currentPrice;
        private DateTime releaseTime;

        public Stock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inInitialPrice <= 0 || inNumberOfShares <= 0)
            {
                throw new StockExchangeException("Ni cijena ni broj dionica za zadanu dionicu ne mogu biti 0 ili negativni!");
            }
            stockholders = new List<Portfolio>();
            priceHistory = new Dictionary<DateTime, Decimal>();
            indexes = new List<Index>();
            releaseTime = inTimeStamp;
            stockName = inStockName;
            numberOfShares = inNumberOfShares;
            initialPrice = inInitialPrice;
            currentPrice = inInitialPrice;
            priceHistory.Add(inTimeStamp, inInitialPrice);
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            Decimal retVal = -1;
            List<DateTime> list = SortAscending(priceHistory);
            foreach (DateTime dt in list)
            {
                if (DateTime.Compare(dt, inTimeStamp) > 0) break;
                retVal = priceHistory[dt];
            }
            if (retVal == -1)
            {
                throw new StockExchangeException("Ne postoji zapis vrijednosti zadane dionice u zadanom vremenu!");
            }
            return retVal;
        }

        public Decimal GetInitialStockPrice()
        {
            return initialPrice;
        }

        public Decimal GetLastStockPrice()
        {
            return currentPrice;
        }

        public void SetStockPrice(DateTime inTimeStamp, Decimal inStockValue)
        {
            foreach (DateTime date in priceHistory.Keys)
            {
                if (date.CompareTo(inTimeStamp) == 0)
                {
                    throw new StockExchangeException("Zadana dionica ve? ima vrijednost definiranu u zadanom vremenu!");
                }
            }
            if (releaseTime.CompareTo(inTimeStamp) > 0)
            {
                initialPrice = inStockValue;
                releaseTime = inTimeStamp;
            }
            priceHistory.Add(inTimeStamp, inStockValue);
            currentPrice = priceHistory[SortAscending(priceHistory).Last()];
        }

        public void AddPortfolio(Portfolio p)
        {
            stockholders.Add(p);
        }

        public void RemovePortfolio(Portfolio p)
        {
            stockholders.Remove(p);
        }

        public long update()
        {
            long totalShares = 0;
            foreach (Portfolio p in stockholders)
            {
                totalShares += p.NumberOfSharesOfStockInPortfolio(this);
            }
            if (totalShares > this.numberOfShares)
            {
                return totalShares - this.numberOfShares;
            }
            else return 0;
        }

        static List<DateTime> SortAscending(Dictionary<DateTime, Decimal> priceHistory)
        {
            List<DateTime> list = priceHistory.Keys.ToList();
            list.Sort((a, b) => a.CompareTo(b));
            return list;
        }

        public void delete()
        {
            foreach (Index i in indexes.ToList())
            {
                i.RemoveStockFromIndex(this);
            }
            foreach (Portfolio p in stockholders.ToList())
            {
                p.removeStockFromPortfolio(this);
            }
        }

        public void addIndex(Index index)
        {
            if (indexes.Contains(index))
            {
                throw new StockExchangeException("Dionica se ve? nalazi u zadanom indexu");
            }
            indexes.Add(index);
        }

        public void removeIndex(Index index)
        {
            if (!indexes.Contains(index))
            {
                throw new StockExchangeException("Dionica se ne nalazi u zadanom indexu!");
            }
            indexes.Remove(index);
        }


        public bool containsIndex(Index index)
        {
            return indexes.Contains(index);
        }
    }

    #endregion

    public class StockExchange : IStockExchange
    {

        private Dictionary<string, Stock> stocks;
        private Dictionary<string, Index> indexes;
        private Dictionary<string, Portfolio> portfolios;

        public StockExchange()
        {
            stocks = new Dictionary<string, Stock>();
            indexes = new Dictionary<string, Index>();
            portfolios = new Dictionary<string, Portfolio>();
        }

        void IStockExchange.ListStock(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
        {
            stockUnCheck(inStockName);
            stocks.Add(inStockName.ToUpper(), new Stock(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp));

        }

        void IStockExchange.DelistStock(string inStockName)
        {
            stockCheck(inStockName);
            stocks[inStockName.ToUpper()].delete();
            stocks.Remove(inStockName.ToUpper());
        }//bri?e dionicu s burze

        bool IStockExchange.StockExists(string inStockName)
        {
            return stocks.ContainsKey(inStockName.ToUpper());
        }//provjerava postoji li tra?ena dionica na burzi
        int IStockExchange.NumberOfStocks()
        {
            return stocks.Count;
        }//vra?a broj dionica na burzi
        void IStockExchange.SetStockPrice(string inStockName, DateTime inIimeStamp, Decimal inStockValue)
        {
            stockCheck(inStockName);
            stocks[inStockName.ToUpper()].SetStockPrice(inIimeStamp, inStockValue);
        }//postavlja
        // cijenu dionice za odre?eno vrijeme
        Decimal IStockExchange.GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            stockCheck(inStockName);
            return stocks[inStockName.ToUpper()].GetStockPrice(inTimeStamp);

        }//dohva?a cijenu dionice
        // za neko vrijeme

        Decimal IStockExchange.GetInitialStockPrice(string inStockName)
        {
            stockCheck(inStockName);
            return stocks[inStockName.ToUpper()].GetInitialStockPrice();

        }//dohva?a po?etnu cijenu dionice
        Decimal IStockExchange.GetLastStockPrice(string inStockName)
        {
            stockCheck(inStockName);
            return stocks[inStockName.ToUpper()].GetLastStockPrice();

        }//dohva?a zadnju cijenu dionice

        void IStockExchange.CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            indexUnCheck(inIndexName);
            indexes.Add(inIndexName.ToUpper(), IndexFactory.CreateIndex(inIndexName.ToUpper(), inIndexType));

        }//stvara novi indeks na burzi

        void IStockExchange.AddStockToIndex(string inIndexName, string inStockName)
        {
            stockCheck(inStockName);
            indexCheck(inIndexName);
            indexes[inIndexName.ToUpper()].AddStockToIndex(stocks[inStockName.ToUpper()]);

        }//dodaje dionicu u indeks

        void IStockExchange.RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            stockCheck(inStockName);
            indexCheck(inIndexName);
            indexes[inIndexName.ToUpper()].RemoveStockFromIndex(stocks[inStockName.ToUpper()]);

        }     //bri?e dionicu iz indeksa

        bool IStockExchange.IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            indexCheck(inIndexName);
            if (!stocks.ContainsKey(inStockName.ToUpper())) return false;
            return indexes[inIndexName.ToUpper()].IsStockPartOfIndex(stocks[inStockName.ToUpper()]);

        }      //provjerava je li dionica
        // u indeksu

        Decimal IStockExchange.GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            indexCheck(inIndexName);
            return indexes[inIndexName.ToUpper()].GetIndexValue(inTimeStamp);
        }//dohva?a vrijednost indeksa
        bool IStockExchange.IndexExists(string inIndexName)
        {
            return indexes.ContainsKey(inIndexName.ToUpper());
        }
        int IStockExchange.NumberOfIndices()
        {
            return indexes.Count;
        }
        int IStockExchange.NumberOfStocksInIndex(string inIndexName)
        {
            indexCheck(inIndexName);
            return indexes[inIndexName.ToUpper()].getStockNumber();
        }

        void IStockExchange.CreatePortfolio(string inPortfolioID)
        {
            portfolioUnCheck(inPortfolioID);
            portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));

        }
        void IStockExchange.AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            portfolioCheck(inPortfolioID);
            stockCheck(inStockName);
            portfolios[inPortfolioID].addStockToPortfolio(stocks[inStockName.ToUpper()], numberOfShares);
        }
        void IStockExchange.RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            portfolioCheck(inPortfolioID);
            stockCheck(inStockName);
            portfolios[inPortfolioID].removeStockFromPortfolio(stocks[inStockName.ToUpper()], numberOfShares);
        }
        void IStockExchange.RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            portfolioCheck(inPortfolioID);
            stockCheck(inStockName);
            portfolios[inPortfolioID].removeStockFromPortfolio(stocks[inStockName.ToUpper()]);
        }
        int IStockExchange.NumberOfPortfolios()
        {
            return portfolios.Count;
        }
        int IStockExchange.NumberOfStocksInPortfolio(string inPortfolioID)
        {
            portfolioCheck(inPortfolioID);
            return portfolios[inPortfolioID].getStockNumber();
        }
        bool IStockExchange.PortfolioExists(string inPortfolioID)
        {
            return portfolios.ContainsKey(inPortfolioID);
        }
        bool IStockExchange.IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            portfolioCheck(inPortfolioID);
            if (!stocks.ContainsKey(inStockName.ToUpper())) return false;
            return portfolios[inPortfolioID].isStockPartOfPortfolio(stocks[inStockName.ToUpper()]);
        }
        int IStockExchange.NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            portfolioCheck(inPortfolioID);
            stockCheck(inStockName);
            return portfolios[inPortfolioID].NumberOfSharesOfStockInPortfolio(stocks[inStockName.ToUpper()]);
        }
        Decimal IStockExchange.GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            portfolioCheck(inPortfolioID);
            return portfolios[inPortfolioID].GetPortfolioValue(timeStamp);
        }
        Decimal IStockExchange.GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            portfolioCheck(inPortfolioID);
            if (Month < 1 || Month > 12)
            {
                throw new StockExchangeException("Neispravan zapis mjeseca!");
            }
            return portfolios[inPortfolioID].GetPortfolioPercentChangeInValueForMonth(Year, Month);
        }








        private void indexCheck(string inIndexName)
        {
            if (!indexes.ContainsKey(inIndexName.ToUpper()))
            {
                throw new StockExchangeException("Zadani indeks ne postoji na burzi!");
            }
        }

        private void indexUnCheck(string inIndexName)
        {
            if (indexes.ContainsKey(inIndexName.ToUpper()))
            {
                throw new StockExchangeException("Zadani indeks vec postoji na burzi!");
            }
        }

        private void stockCheck(string inStockName)
        {
            if (!stocks.ContainsKey(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Zadana dionica ne postoji na burzi!");
            }
        }

        private void stockUnCheck(string inStockName)
        {
            if (stocks.ContainsKey(inStockName.ToUpper()))
            {
                throw new StockExchangeException("Zadana dionica vec postoji na burzi!");
            }
        }

        private void portfolioCheck(string inPortofolioID)
        {
            if (!portfolios.ContainsKey(inPortofolioID))
            {
                throw new StockExchangeException("Zadani portfelj ne postoji na burzi!");
            }
        }

        private void portfolioUnCheck(string inPortofolioID)
        {
            if (portfolios.ContainsKey(inPortofolioID))
            {
                throw new StockExchangeException("Zadani portfelj vec postoji na burzi!");
            }
        }
    }

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange() as IStockExchange;
        }
    }

}