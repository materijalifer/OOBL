﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public static class MappingExtensions
    {

        public static string AddNumber(this char pressedNumber, string display)
        {
            if (display == "0")
                return display = pressedNumber.ToString();
            else
                return display += pressedNumber;
        }

        public static bool IsOperator(this char pressOperator)
        {
            switch (pressOperator)
            {
                case '+':
                    return true;
                case '-':
                    return true;
                case '/':
                    return true;
                case '*':
                    return true;
            }

            return false;
        }

        public static bool ContainsOperator(this string display)
        {
            char[] displayField = display.ToCharArray();

            for (int i = 0; i < displayField.Length; i++)
            {
                if (i == 0)
                    continue;
                if (display[i].IsOperator())
                    return true;
            }

            return false;
        }

        public static string ReduceOperator(this string display)
        {


            string firstNumber = "";
            string secondNumber = "";

            bool operatorFound = false;

            char chosenOperator = '0';

            char[] displayField = display.ToCharArray();

            for (int i = 0; i < displayField.Length; i++) 
            {
                if (displayField[i].IsOperator())
                {
                    if (i == 0)
                    {
                        firstNumber += displayField[i];
                    }
                    else
                    {
                        chosenOperator = displayField[i];
                        operatorFound = true;
                    }
                }
                else
                {
                    if (!operatorFound)
                    {
                        firstNumber += displayField[i];
                    }
                    else
                    {
                        secondNumber += displayField[i];
                    }
                }
            }

            return CalculateWithOperator(firstNumber, secondNumber, chosenOperator);
        }

        private static string CalculateWithOperator(string firstNumber, string secondNumber, char chosenOperator)
        {
            double result = 0;

            double first = double.Parse(firstNumber);
            double second;

            if (secondNumber.Length > 0)
                second = double.Parse(secondNumber);
            else
                second = first;

            switch (chosenOperator)
            {
                case '+':
                    result = first + second;
                    break;
                case '-':
                    result = first - second;
                    break;
                case '*':
                    result = first * second;
                    break;
                case '/':
                    result = first / second;
                    break;
            }

            return result.ToString();
        }

        public static string AddOperator(this char pressedOperator, string display)
        {
            if (display[display.Length - 1].IsOperator() || display[display.Length - 1] == ',')
            {
                string newDisplay = display.Remove(display.Length - 1);
                if (newDisplay.ContainsOperator())
                    newDisplay = newDisplay.ReduceOperator() + pressedOperator;
                else
                    newDisplay += pressedOperator;
                return newDisplay;
            }
            else
            {
                if (display.ContainsOperator() && pressedOperator != ',')
                    display = display.ReduceOperator();

                display += pressedOperator;
                return display;
            }

        }

        public static bool IsEquality(this char pressedSign)
        {
            if (pressedSign == '=')
                return true;
            else
                return false;
        }


        public static string CalculateWithUnaryOperators(this char pressedSign, string display)
        {

            switch (pressedSign)
            {
                case 'M':
                    return display.ChangeSign();
                case 'C':
                    return "0";
                case 'S':
                    return display.Sinus();
                case 'K':
                    return display.Kosinus();
                case 'T':
                    return display.Tangens();
                case 'Q':
                    return display.Quadrat();
                case 'R':
                    return display.Root();
                case 'I':
                    return display.Invers();
            }



            return "0";
        }

        public static string Invers(this string number)
        {
            try
            {
                double result = 1 / double.Parse(number);

                if (result.ToString().Equals("Infinity"))
                    return "-E-";

                return result.ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string Root(this string number)
        {
            try
            {
                return Math.Sqrt(double.Parse(number)).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string Quadrat(this string number)
        {
            try
            {
                return Math.Pow(double.Parse(number), 2).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string Tangens(this string number)
        {
            try
            {
                return Math.Tan(double.Parse(number)).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string Kosinus(this string number)
        {
            try
            {
                return Math.Cos(double.Parse(number)).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string Sinus(this string number)
        {
            try
            {
                return Math.Sin(double.Parse(number)).ToString();
            }
            catch
            {
                return "-E-";
            }
        }

        public static string ChangeSign(this string display)
        {
            if (display[0] == '-')
                return display.Substring(1);
            else
                return "-" + display;
        }

        public static string ChangeSecondNumber(this string state, string display)
        {
            string firstNumber = "";

            char chosenOperator = '0';

            char[] stateField = state.ToCharArray();

            for (int i = 0; i < stateField.Length; i++)
            {
                if (stateField[i].IsOperator())
                {
                    if (i == 0)
                    {
                        firstNumber += stateField[i];
                    }
                    else
                    {
                        chosenOperator = stateField[i];
                        break;
                    }
                }
                else
                {
                    firstNumber += stateField[i];
                }
            }

            if (display[0] == '-')
            {
                if (chosenOperator == '+')
                    chosenOperator = '-';
                else if (chosenOperator == '-')
                    chosenOperator = '+';
                else
                {

                    firstNumber = "-" + firstNumber;
                }
                display = display.Substring(1);
            }

            return firstNumber + chosenOperator + display;
        }

    }

    public class Kalkulator : ICalculator
    {

        private string _displayState = "0";

        private string _state = "0";

        private static int DISPLAY_SIZE = 10;

        private string _memory = "";

        private static string _error = "-E-";

        public void Press(char inPressedDigit)
        {


            if (Char.IsNumber(inPressedDigit))
            {

                if (_state[_state.Length - 1].IsOperator())
                    _displayState = inPressedDigit.ToString();
                else
                    _displayState = inPressedDigit.AddNumber(_displayState);
                _state = inPressedDigit.AddNumber(_state);

            }
            else if (inPressedDigit.IsOperator() || inPressedDigit == ',')
            {
                _state = inPressedDigit.AddOperator(_state);
                if (_state[_state.Length - 1] != ',')
                {
                    _displayState = _state.Remove(_state.Length - 1);
                }
                else
                {
                    _displayState += ',';
                }
            }
            else if (inPressedDigit.IsEquality())
            {
                if (_state.ContainsOperator())
                    _state = _state.ReduceOperator();

                _displayState = roundResult(_state);
            }
            else if (inPressedDigit == 'P')
            {
                _memory = _displayState;
            }
            else if (inPressedDigit == 'G')
            {
                _displayState = _memory;
            }
            else if (inPressedDigit == 'O')
            {
                _displayState = "0";
                _state = "0";
            }
            else
            {
                _displayState = inPressedDigit.CalculateWithUnaryOperators(_displayState);

                _displayState = roundResult(_displayState);

                if (_state.ContainsOperator())
                {
                    if (!_state[_state.Length - 1].IsOperator())
                    {

                    
                    _state = _state.ChangeSecondNumber(_displayState);

                    }
                }
                else
                {
                    _state = _displayState;
                }
                

            }


        }

        private string roundResult(string display)
        {

            string firstPart = "";
            string secondPart = "";

            bool foundSeparator = false;

            foreach (char c in display.ToCharArray())
            {
                if (c == ',')
                {
                    foundSeparator = true;

                    if (firstPart.Length == 0)
                        firstPart = "0";

                    continue;
                }
                if (!foundSeparator)
                {
                    firstPart += c;
                }
                else
                {
                    secondPart += c;
                }
            }

            string firstWithoutMinus = firstPart.Replace("-", "");

            bool onlyZero = true; 

            for(int i = 0; i < secondPart.Length; i++) {

                if (secondPart[i] != '0')
                {
                    onlyZero = false;
                    break;
                }
            }

            

            if (onlyZero)
                secondPart = "";

            int secondPartSize = DISPLAY_SIZE - firstWithoutMinus.Length;

            if (secondPartSize < 0)
                return _error;
            else if (secondPartSize == 0 || secondPart.Length == 0)
                return firstPart;
            else if ((firstWithoutMinus.Length + secondPart.Length) <= 10)
            {
                return Math.Round(Convert.ToDecimal(display),secondPart.Length).ToString();
            }
            else if (secondPart.Length > 0)
            {
                return Math.Round(Convert.ToDecimal(display),secondPartSize).ToString();
            }
            else
                return display;
        }



        public string GetCurrentDisplayState()
        {
            return _displayState;
        }


    }


}
