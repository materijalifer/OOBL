﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        System.Globalization.NumberFormatInfo info = new System.Globalization.NumberFormatInfo();
        private const long BIGGEST_NUMBER = 9999999999;
        private const int MAX_NUMBER_LENGTH = 10;

        private Double unaryOperand = 0;
        private Double firstOperand = 0;
        private Double secondOperand = 0;

        private Double memory = 0;

        private enum decimalPoint { HasDecimalPoint, PutDecimalPoint, NoDecimalPoint }
        private decimalPoint isDecimal = decimalPoint.NoDecimalPoint;

        private enum BinaryOperation { minus, plus, multiply, divide, nothing }
        private BinaryOperation currentBinaryOperation = BinaryOperation.nothing;

        private enum UnaryOperation { sinus, cosinus, tangens, quadrat, root, invers, nothing }
        private UnaryOperation currentUnaryOperation = UnaryOperation.nothing;

        private enum pressed { nothing, digit, result, binaryOperator, unaryOperator, clear }
        private pressed lastPressed = pressed.nothing;

        private String screen = "0";
        private String input = "0";

        public Kalkulator()
        {
            info.NumberDecimalSeparator = ",";
        }

        #region ICalculator functions
        
        public void Press(char inPressedDigit)
        {
            if (screen == "-E-")
            {
                input = "0";
                screen = "0";
            }

            switch (inPressedDigit)
            {
                case '=':
                    {
                        if ((lastPressed == pressed.result))
                        {
                            //više = za redom, ponavlja se prosla operacija
                            firstOperand = Convert.ToDouble(screen, info);
                        }
                        else
                        {
                            secondOperand = Convert.ToDouble(screen, info);
                        }

                        if (currentBinaryOperation != BinaryOperation.nothing)
                        {
                            Double result = calculateBinaryOperation();
                            if (ResultOK(result))
                            {
                                displayNumber(result);
                                firstOperand = Convert.ToDouble(screen, info);
                                isDecimal = decimalPoint.NoDecimalPoint;
                                //currentOperation = operation.nothing;
                                lastPressed = pressed.result;
                            }
                            else
                            {
                                screen = "-E-";
                                initializeCalculator();
                            }

                        }
                        else
                        {
                            //pritisnuto je jednako a nema operacije
                            displayNumber(Convert.ToDouble(screen, info));
                        }

                        break;
                    }
                case '+':
                    {
                        binaryOperation();
                        currentBinaryOperation = BinaryOperation.plus;
                        break;

                    }
                case '-':
                    {
                        binaryOperation();
                        currentBinaryOperation = BinaryOperation.minus;
                        break;
                    }
                case '*':
                    {
                        binaryOperation();
                        currentBinaryOperation = BinaryOperation.multiply;
                        break;
                    }
                case '/':
                    {
                        binaryOperation();
                        currentBinaryOperation = BinaryOperation.divide;
                        break;
                    }
                case ',':
                    {
                        if (isDecimal == decimalPoint.NoDecimalPoint)
                        {
                            isDecimal = decimalPoint.PutDecimalPoint;
                        }
                        if (lastPressed != pressed.digit)
                        {
                            screen = "0,";
                        }
                        break;
                    }
                case 'M':
                    {
                        Double operand = Convert.ToDouble(screen, info);
                        operand = -operand;
                        displayNumber(operand);
                        break;
                    }
                case 'S':
                    {
                        currentUnaryOperation = UnaryOperation.sinus;
                        unaryOperation();
                        break;
                    }
                case 'K':
                    {
                        currentUnaryOperation = UnaryOperation.cosinus;
                        unaryOperation();
                        break;
                    }
                case 'T':
                    {
                        currentUnaryOperation = UnaryOperation.tangens;
                        unaryOperation();
                        break;
                    }
                case 'Q':
                    {
                        currentUnaryOperation = UnaryOperation.quadrat;
                        unaryOperation();
                        break;
                    }
                case 'R':
                    {
                        currentUnaryOperation = UnaryOperation.root;
                        unaryOperation();
                        break;
                    }
                case 'I':
                    {
                        currentUnaryOperation = UnaryOperation.invers;
                        unaryOperation();
                        break;
                    }
                case 'P':
                    {
                        memory = Convert.ToDouble(screen, info);
                        break;
                    }
                case 'G':
                    {
                        screen = memory.ToString(info);
                        break;
                    }
                case 'C':
                    {
                        screen = "0";
                        lastPressed = pressed.clear;
                        break;
                    }
                case 'O':
                    {
                        restartCalculator();
                        break;
                    }
                default:
                    {
                        //pritisnuta je neka znamenka

                        if (lastPressed == pressed.result)
                        {
                            //stavim operacije u ništa ako je zadnje što je pisalo bilo =
                            currentBinaryOperation = BinaryOperation.nothing;
                            currentUnaryOperation = UnaryOperation.nothing;
                        }
                        if (lastPressed != pressed.digit)
                        {
                            input = "0";
                            screen = "0";
                        }
                        addDigit(inPressedDigit);


                        lastPressed = pressed.digit;
                        break;
                    }

            }
        }

        public string GetCurrentDisplayState()
        {
            return screen;
        }

        #endregion

        #region calculate functions
        
        private void binaryOperation()
        {

            if ((lastPressed == pressed.binaryOperator) ||
                                (currentBinaryOperation == BinaryOperation.nothing))
            {   //ako je zadnje sto je pritisnuto binarni, samo ga prebrisem
                //ili obican slucaj kad prije nije bilo operacije
                firstOperand = Convert.ToDouble(screen, info);
            }
            else
            {
                //ako se treba izvesti neka operacija
                secondOperand = Convert.ToDouble(screen, info);
                Double result = calculateBinaryOperation();
                if (ResultOK(result))
                {
                    displayNumber(result);
                    firstOperand = Convert.ToDouble(screen, info);
                }
                else
                {
                    screen = "-E-";
                    initializeCalculator();
                }


            }
            isDecimal = decimalPoint.NoDecimalPoint;
            lastPressed = pressed.binaryOperator;
        }

        private void unaryOperation()
        {
            unaryOperand = Convert.ToDouble(screen, info);
            if (lastPressed == pressed.result)
            {
                currentBinaryOperation = BinaryOperation.nothing;
            }
            Double result = calculateUnaryOperation();
            if (ResultOK(result))
            {
                displayNumber(result);
                lastPressed = pressed.unaryOperator;
                isDecimal = decimalPoint.NoDecimalPoint;
            }
            else
            {
                screen = "-E-";
                initializeCalculator();
            }

        }

        double calculateBinaryOperation()
        {
            switch (currentBinaryOperation)
            {
                case BinaryOperation.minus:
                    {
                        return firstOperand - secondOperand;
                    }
                case BinaryOperation.plus:
                    {
                        return firstOperand + secondOperand;
                    }
                case BinaryOperation.multiply:
                    {
                        return firstOperand * secondOperand;
                    }
                case BinaryOperation.divide:
                    {
                        return firstOperand / secondOperand;
                    }
                default:
                    {
                        //ako je pozvana na izvođenje neka nova operacija koja nije implementirana
                        throw new NotImplementedException();
                    }
            }
        }

        double calculateUnaryOperation()
        {
            switch (currentUnaryOperation)
            {
                case UnaryOperation.sinus:
                    {
                        return Math.Sin(unaryOperand);
                    }
                case UnaryOperation.cosinus:
                    {
                        return Math.Cos(unaryOperand);
                    }
                case UnaryOperation.tangens:
                    {
                        return Math.Tan(unaryOperand);
                    }
                case UnaryOperation.quadrat:
                    {
                        return Math.Pow(unaryOperand, 2);
                    }
                case UnaryOperation.root:
                    {
                        return Math.Sqrt(unaryOperand);
                    }
                case UnaryOperation.invers:
                    {
                        return 1 / unaryOperand;
                    }
                default:
                    {
                        //ako je pozvana na izvođenje neka nova operacija koja nije implementirana
                        throw new NotImplementedException();
                    }
            }
        }

        #endregion
        
        private void addDigit(char inPressedDigit)
        {
            if (input == "0")
            {
                //slucaj kad je na ekranu 0

                if (isDecimal == decimalPoint.PutDecimalPoint)
                {
                    input += "," + inPressedDigit;
                    isDecimal = decimalPoint.HasDecimalPoint;
                }else if (isDecimal == decimalPoint.HasDecimalPoint)
                {
                    input += inPressedDigit;
                }
                else
                {
                    if (inPressedDigit != '0')
                    {
                        input = "" + inPressedDigit;
                    }
                }    
            }
            else
            { 
                //slucaj kad na ekranu pise nesto sto nije nula

                if (isDecimal == decimalPoint.PutDecimalPoint)
                {
                    input += "," + inPressedDigit;
                    isDecimal = decimalPoint.HasDecimalPoint;
                }
                else if (isDecimal == decimalPoint.NoDecimalPoint)
                {
                    if (input.Length < MAX_NUMBER_LENGTH)
                    {
                        input += inPressedDigit;
                    }

                }
                else
                {
                    input += inPressedDigit;
                }
            }

            //postavljanje predznaka

            Double number = Convert.ToDouble(screen, info);
            if (number < 0)
            {
                input = input.Replace("-", "");
                input = "-" + input;
            }
            else
            {
                input = input.Replace("-","");
            }

            int length = input.Replace(".", "").Replace("-", "").Length;

            //zaokruzivanje ako je previse znamenaka

            if (length <= MAX_NUMBER_LENGTH)
            {
                screen = input;
            }
            else
            {
                number = Convert.ToDouble(input, info);

                if (number >= 0)
                {
                    screen = Math.Round(number, 10 - input.IndexOf(',')).ToString(info);
                }
                else
                {
                    screen = Math.Round(number, 11 - input.IndexOf(',')).ToString(info);
                }

            }

        }

        private void displayNumber(Double displayNumber)
        {
            int length = displayNumber.ToString(info).Replace(".", "").Replace("-","").Length;
            if (length <= MAX_NUMBER_LENGTH)
            {
                screen = displayNumber.ToString(info);
            }
            else 
            {
                string pom = displayNumber.ToString(info);
                if (displayNumber >= 0)
                {
                    screen = Math.Round(displayNumber, 10 - pom.IndexOf(',')).ToString(info);
                }
                else
                {
                    screen = Math.Round(displayNumber, 11 - pom.IndexOf(',')).ToString(info);
                }
                   
            }
                    
        }

        private void restartCalculator()
        {
            initializeCalculator();
            memory = 0;
            screen = "0";
        }
       
        private void initializeCalculator()
        {
                      
            unaryOperand = 0;
            firstOperand = 0;
            secondOperand = 0;            
                        
            isDecimal = decimalPoint.NoDecimalPoint;  
            currentUnaryOperation = UnaryOperation.nothing;
            currentBinaryOperation = BinaryOperation.nothing;
            lastPressed = pressed.nothing;
        }

        private bool ResultOK(double number)
        {
            if ((Math.Abs(number) > BIGGEST_NUMBER) || (double.IsNaN(number)))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        
       
        
    }


}
