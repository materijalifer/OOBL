﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string _inputArea;                  // ono što piše na ekranu u nekom trenutku
        private string _memory;                     //varijabla koja predstavlja memoriju kalkulatora
        private int _maxCharsOnTheScreen;           //varijabla koja predstavlja maksimalni broj znamenaka koje se mogu prikazati na ekranu
        private int _NumberOfSoFarInputedDigits;    //broj unesenih znamenki, max. 10
        private string _binarOperator;              //uneseni binarni operator
        private double _firstNumber;                //prvi operand
        private bool _hasDecimal;                   //oznaka da li je unesena decimalna tocka
        private bool _hasLeadingZero;               //oznaka da li se pokusava unijeti broj s vodecim nulama (one se ignoriraju)
        private bool _numberInputed;                //oznaka da li je unesen drugi broj nakon binarnog operatora


        /// <summary>
        /// Konstruktor. Obavlja inicijalizaciju članskih varijabli klase Kalkulator.
        /// </summary>
        public Kalkulator()
        {
            _inputArea = "0";
            _memory = string.Empty;
            _maxCharsOnTheScreen = 10;
            _NumberOfSoFarInputedDigits = 0;
            _binarOperator = string.Empty;
            _firstNumber = 0;
            _hasDecimal = false;
            _hasLeadingZero = true;
            _numberInputed = false;
        }


        /// <summary>
        ///Funkcija koja definira akcije koje nastupaju pritiskom pojedine tipke kalkulatora.
        /// </summary>
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                AddNewDigit(inPressedDigit);
            }
            else if (inPressedDigit.Equals(','))
            {
                AddDecimalPoint(inPressedDigit);
            }
            else if (inPressedDigit.Equals('+') ||
                     inPressedDigit.Equals('-') ||
                     inPressedDigit.Equals('*') ||
                     inPressedDigit.Equals('/'))
            {
                BinaryOperationButtonPressed(inPressedDigit);
            }
            else if (inPressedDigit.Equals('S') ||
                     inPressedDigit.Equals('K') ||
                     inPressedDigit.Equals('T') ||
                     inPressedDigit.Equals('Q') ||
                     inPressedDigit.Equals('R') ||
                     inPressedDigit.Equals('I'))
            {
                UnaryOperationButtonPressed(inPressedDigit);
            }
            else if (inPressedDigit.Equals('C'))
            {
                ClearButtonPressed();
            }
            else if (inPressedDigit.Equals('O'))
            {
                ResetButtonPressed();
            }
            else if (inPressedDigit.Equals('P'))
            {
                PutInMemory();
            }
            else if (inPressedDigit.Equals('G'))
            {
                GetFromMemory();
            }
            else if (inPressedDigit.Equals('M'))
            {
                ChangeSign();
            }
            else if (inPressedDigit.Equals('='))
            {
                EqualSignPressed();
            }
        }


        /// <summary>
        ///Funkcija koja obraduje pokusaj dodavanja nove znamenke na ekran. Ako je na ekranu manje od 10 znamenki, 
        ///dodaje novu znamenku. U suprotnom ne radi nista.
        /// </summary>
        private void AddNewDigit(char inPressedDigit)
        {
            if (_NumberOfSoFarInputedDigits < 10)
            {
                if (_hasLeadingZero)
                {
                    if (inPressedDigit.Equals('0'))
                    {
                        return;
                    }
                    else
                    {
                        _inputArea = string.Empty;
                        _hasLeadingZero = false;
                    }
                }
                _NumberOfSoFarInputedDigits++;
                _inputArea += inPressedDigit;
                _numberInputed = true;
            }
        }


        /// <summary>
        ///Funkcija koja obraduje pokusaj unosa decimalne tocke. Ako je trenutni broj na ekranu kalkulatora bez decimalne tocke, 
        ///dodaje decimalnu tocku. U suprotnom ne radi nista.
        ///</summary>
        private void AddDecimalPoint(char inPressedDigit)
        {
            if (!_hasDecimal)
            {
                if (_hasLeadingZero)
                {
                    _hasLeadingZero = false;
                    _NumberOfSoFarInputedDigits++;
                }
                _hasDecimal = true;
                _inputArea += inPressedDigit;
            }
        }


        /// <summary>
        ///Funkcija koja obraduje pritisak tipke binarnog operatora. Ako prethodno nije unesen binarni operator, 
        ///broj koji se nalazi na ekranu postaje prvi operand, a uneseni operator se pamti. U suprotnom se racuna binarna operacija 
        ///zadana prethodno unesenim binarni operatorom izmedu prethodno pohranjenog prvog operanda i broja koji se nalazi na ekranu.
        ///Rezultat izvedene operacije postaje novi prvi operand, a upravo uneseni binarni operator zamjenjuje prethodno unesenog.
        ///</summary>
        private void BinaryOperationButtonPressed(char inPressedDigit)
        {
            if (_binarOperator == string.Empty)
            {
                _firstNumber = Convert.ToDouble(_inputArea);
                ResetVariables();
                _numberInputed = false;
                _binarOperator += inPressedDigit;

            }
            else
            {
                if (_numberInputed)
                {
                    CalculateBinaryOperation(_firstNumber, Convert.ToDouble(_inputArea), _binarOperator);
                    _firstNumber = Convert.ToDouble(_inputArea);
                    ResetVariables();
                    _numberInputed = false;
                }
                _binarOperator = string.Empty + inPressedDigit;
            }
            _inputArea = Convert.ToString(Convert.ToDouble(_inputArea));
        }


        /// <summary>
        ///Funkcija koja resetira varijable (vezane uz unosenje broja) nakon obavljanja neke operacije.
        ///</summary>
        private void ResetVariables()
        {
            _hasLeadingZero = true;
            _hasDecimal = false;
            _NumberOfSoFarInputedDigits = 0;
        }


        /// <summary>
        ///Funckija koja racuna rezultat zadane binarne operacije i prikazuje ga na ekranu.
        ///U slucaju greske prikazuje se oznaka "-E-".
        ///</summary>
        private void CalculateBinaryOperation(double firstNumber, double secondNumber, string operation)
        {
            double _secondNumber = Convert.ToDouble(_inputArea);

            switch (operation)
            {
                case "+":
                    _inputArea = RoundNumber(firstNumber + secondNumber);
                    break;
                case "-":
                    _inputArea = RoundNumber(firstNumber - secondNumber);
                    break;
                case "*":
                    _inputArea = RoundNumber(firstNumber * secondNumber);
                    break;
                case "/":
                    if (secondNumber.Equals(0.0))
                    {
                        _inputArea = "-E-";
                    }
                    else
                    {
                        _inputArea = RoundNumber(firstNumber / secondNumber);
                    }
                    break;
            }
        }


        /// <summary>
        ///Funkcija koja obraduje pritisak tipke unarnog operatora.
        ///</summary>
        private void UnaryOperationButtonPressed(char inPressedDigit)
        {
            DoUnaryOperation(Convert.ToDouble(_inputArea), inPressedDigit);
            ResetVariables();
        }


        /// <summary>
        ///Funkcija koja racuna rezultat zadane unarne operacije i prikazuje ga na ekranu.
        ///U slucaju greske prikazuje se oznaka "-E-".
        ///</summary>
        private void DoUnaryOperation(double inputNumber, char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'S':
                    _inputArea = RoundNumber(Math.Sin(inputNumber));
                    break;
                case 'K':
                    _inputArea = RoundNumber(Math.Cos(inputNumber));
                    break;
                case 'T':
                    _inputArea = RoundNumber(Math.Tan(inputNumber));
                    break;
                case 'Q':
                    _inputArea = RoundNumber(Math.Pow(inputNumber, 2));
                    break;
                case 'R':
                    if (inputNumber < 0)
                    {
                        _inputArea = "-E-";
                    }
                    else
                    {
                        _inputArea = RoundNumber(Math.Sqrt(inputNumber));
                    }
                    break;
                case 'I':
                    if (inputNumber.Equals(0.0))
                    {
                        _inputArea = "-E-";
                    }
                    else
                    {
                        _inputArea = RoundNumber(1 / inputNumber);
                    }
                    break;
            }
        }


        /// <summary>
        ///Funkcija koja obraduje pritisak tipke "Clear". 
        ///Brise se samo ekran, podaci iz memorije i rezultati prethodnih operacija se ne brisu.
        ///</summary>
        private void ClearButtonPressed()
        {
            _inputArea = "0";
            ResetVariables();
            _numberInputed = false;
        }


        /// <summary>
        ///Funkcija koja obraduje pritisak tipke "On/Off".
        ///Brisu se svi podaci, tj. kalkulator se resetira.
        ///</summary>
        private void ResetButtonPressed()
        {
            ClearButtonPressed();
            _firstNumber = 0;
            _memory = string.Empty;
            _binarOperator = string.Empty;
        }


        /// <summary>
        ///Funkcija koja pohranjuje trenutni broj s ekrana kalkulatora u memoriju.
        ///</summary>
        private void PutInMemory()
        {
            _memory = _inputArea;
        }


        /// <summary>
        ///Funkcija koja dohvaca broj iz memorije i prikazuje ga na ekranu kalkulatora.
        ///</summary>
        private void GetFromMemory()
        {
            _inputArea = _memory;
        }


        /// <summary>
        ///Funkcija koja mijenja predznak broja prikazanog na ekranu.
        ///</summary>
        private void ChangeSign()
        {
            if (_inputArea.Contains("-"))
            {
                _inputArea = _inputArea.Replace("-", "");
            }
            else
            {
                _inputArea = "-" + _inputArea;
            }
        }


        /// <summary>
        ///Funkcija koja zaokruzuje dani broj na 10 znamenaka (ogranicenje ekrana kalkulatora).
        ///U slucaju da cjelobrojni dio danog broja prelazi dano ogranicenje ekrana, ispisuje se oznaka "-E-".
        ///</summary>
        public string RoundNumber(double numberToRound)
        {
            double roundedNumber = numberToRound;
            string number = Convert.ToString(numberToRound);

            if (number.Contains(","))
            {
                int indexOfDecimalPoint = number.IndexOf(",");

                if (indexOfDecimalPoint > _maxCharsOnTheScreen)
                {
                    return "-E-";
                }
                else
                {
                    int numbersLeft = _maxCharsOnTheScreen - indexOfDecimalPoint;
                    if (number.Contains("-"))
                    {
                        roundedNumber = Math.Round(numberToRound, numbersLeft + 1);
                        return Convert.ToString(roundedNumber);
                    }
                    else
                    {
                        roundedNumber = Math.Round(roundedNumber, numbersLeft);
                        return Convert.ToString(roundedNumber);
                    }
                }
            }
            else
            {
                if (number.Length > 10)
                {
                    return "-E-";
                }
                else
                {
                    return number;
                }
            }

        }


        /// <summary>
        ///Funkcija koja obraduje pritisak tipke "=".
        ///</summary>
        public void EqualSignPressed()
        {
            if (!(_binarOperator == string.Empty))
            {
                CalculateBinaryOperation(_firstNumber, Convert.ToDouble(_inputArea), _binarOperator);
            }
            else
            {
                _inputArea = Convert.ToString(Convert.ToDouble(_inputArea));
            }
        }


        /// <summary>
        ///Funkcija koja vraca trenutno stanje ekrana kalkulatora.
        ///</summary>
        public string GetCurrentDisplayState()
        {
            return _inputArea;
        }
    }

}
