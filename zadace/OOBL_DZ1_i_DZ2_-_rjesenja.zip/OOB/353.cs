﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string,Stock> stocks;
         private Dictionary<string, Index> indices;
         private Dictionary<string, Portofilio> portofilios; 

         // Kostruktor burze
         public StockExchange()
         {
             stocks = new Dictionary<string,Stock>();
             indices = new Dictionary<string, Index>();
             portofilios = new Dictionary<string, Portofilio>();
         }
         
         //*********//
         // DIONICA //
         //*********//
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             if(inInitialPrice < 0)
                 throw new StockExchangeException("Cjena dionice ne može biti negativna!");
             
             if(stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inStockName + " već postoji na burzi!");
             
             Stock newStock = new Stock(inStockName.ToUpper(),inNumberOfShares,inInitialPrice,inTimeStamp);
             stocks.Add(newStock.GetStockName(), newStock);
             
         }

         public void DelistStock(string inStockName)
         {
             //throw new NotImplementedException();
             if (!stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");
             
             // Ako mičemo dionicu s burze moramo je maknuti i iz svih indeksa i portofilija
             foreach (var index in indices)
             {
                 if(index.Value.CointainsStock(inStockName.ToUpper()))
                     index.Value.RemoveStock(inStockName.ToUpper());
             }

             foreach (var portofilio in portofilios)
             {
                 if (portofilio.Value.ContainsStock(inStockName.ToUpper()))
                    portofilio.Value.RemoveStock(inStockName.ToUpper());
             }

             stocks.Remove(inStockName.ToUpper());
         
         }

         public bool StockExists(string inStockName)
         {
             //throw new NotImplementedException();
             if(stocks.ContainsKey(inStockName.ToUpper()))
                 return true;
             return false;
         }

         public int NumberOfStocks()
         {
             //throw new NotImplementedException();
             return stocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             //throw new NotImplementedException();
             if (!stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");
             if(inStockValue < 0)
                 throw new StockExchangeException("Cijena dionice ne može biti negativna!");
             if (stocks.ContainsKey(inStockName.ToUpper()))
             {
                 Stock tmpStock = stocks[inStockName.ToUpper()];
                 tmpStock.AddPrice(inIimeStamp, inStockValue);
             }
             
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             if (!stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");
             
             Stock tmpStock = stocks[inStockName.ToUpper()];
             return tmpStock.GetPrice(inTimeStamp);

         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             //throw new NotImplementedException();
             if (stocks.ContainsKey(inStockName.ToUpper()))
             {
                return stocks[inStockName.ToUpper()].GetInitialPrice();
             }
             throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             //throw new NotImplementedException();
             if (stocks.ContainsKey(inStockName.ToUpper()))
             {
                return stocks[inStockName.ToUpper()].GetLastPrice();
             }
             throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");
         }
         
         //********//
         // INDEKS //
         //********//
         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             //throw new NotImplementedException();
             if(inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                 throw new StockExchangeException("Tip indeksa nije podržan!");

             Index tmpIndex = new Index(inIndexName.ToUpper(), inIndexType);
             indices.Add(inIndexName.ToUpper(), tmpIndex);

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             if (!indices.ContainsKey(inIndexName.ToUpper()))
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji na burzi!");
             
             Index tmpIndex = indices[inIndexName.ToUpper()];
            
             if (!stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inStockName + " ne postoji na burzi!");

             Stock tmpStock = stocks[inStockName.ToUpper()];
             
             tmpIndex.AddStock(tmpStock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             if (!indices.ContainsKey(inIndexName.ToUpper()))
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji na burzi!");
             
             Index tmpIndex = indices[inIndexName.ToUpper()];
             
            
             
             tmpIndex.RemoveStock(inStockName.ToUpper());
            
                 

         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             //throw new NotImplementedException();
             if (!indices.ContainsKey(inIndexName.ToUpper()))
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji na burzi!");
             
             Index tmpIndex = indices[inIndexName.ToUpper()];

             return tmpIndex.CointainsStock(inStockName.ToUpper());
         }
        
         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             //throw new NotImplementedException();
             if(!indices.ContainsKey(inIndexName.ToUpper()))
                throw new StockExchangeException("BLA");

             Index tmpIndex = indices[inIndexName.ToUpper()];

             return tmpIndex.Value(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             //throw new NotImplementedException();
             if (indices.ContainsKey(inIndexName.ToUpper()))
                 return true;
             return false;


         }

         public int NumberOfIndices()
         {
             //throw new NotImplementedException();
             return indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             //throw new NotImplementedException();
             if (!indices.ContainsKey(inIndexName.ToUpper()))
                 throw new StockExchangeException("Indeks " + inIndexName + " ne postoji na burzi!");

             Index tmpIndex = indices[inIndexName.ToUpper()];

             return tmpIndex.StockCount();

         }
         
         //************//
         // PORTOFILIO //
         //************//
         public void CreatePortfolio(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if(portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofilio vec postoji");
             
             Portofilio tmpPortofilio = new Portofilio(inPortfolioID);
             portofilios.Add(inPortfolioID,tmpPortofilio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //throw new NotImplementedException();
             if(!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             if(!stocks.ContainsKey(inStockName.ToUpper()))
                 throw new StockExchangeException("Dionica " + inPortfolioID + " ne postoji na burzi");

             Stock tmpStock = stocks[inStockName.ToUpper()];

             if((tmpStock.GetTotalNumberOfSharesInPortofilios() + numberOfShares) > tmpStock.GetNumberOfShares())
                 throw new StockExchangeException("Nedovoljan broj dionica za stavljanje u portifilio");

             
             tmpPortofilio.AddStock(tmpStock,numberOfShares);
             tmpStock.SetTotalNumberOfSharesInPortofilios(numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             tmpPortofilio.RemoveStock(inStockName.ToUpper(),numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             tmpPortofilio.RemoveStock(inStockName.ToUpper());



         }

         public int NumberOfPortfolios()
         {
             //throw new NotImplementedException();
             return portofilios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             return tmpPortofilio.StockCount();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             //throw new NotImplementedException();
             if (portofilios.ContainsKey(inPortfolioID))
                 return true;
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             return tmpPortofilio.ContainsStock(inStockName.ToUpper());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             return tmpPortofilio.NumberOfShares(inStockName.ToUpper());
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             //throw new NotImplementedException();
             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             return tmpPortofilio.Value(timeStamp);

         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             //throw new NotImplementedException();
             if(Month < 1 || Month > 12)
                 throw new StockExchangeException("Pogresan unos mjeseca");

             if (!portofilios.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portofiliio " + inPortfolioID + " ne postoji na burzi");

             Portofilio tmpPortofilio = portofilios[inPortfolioID];

             
             return tmpPortofilio.ValueChange(Year, Month);
         }
     }

     


     public class Stock
     {
         private string _stockName;
         private long _numberOfShares;
         private long _totalNumberOfSharesInPortofilios;
         private Decimal _initialPrice;
         private Decimal _lastPrice;
         private Dictionary<DateTime,Decimal> _price;

         public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _stockName = inStockName;
             _numberOfShares = inNumberOfShares;
             _initialPrice = inInitialPrice;
             _totalNumberOfSharesInPortofilios = 0;
             
             _price = new Dictionary<DateTime,decimal>();
             _price.Add(inTimeStamp, inInitialPrice);
         }

         public string GetStockName()
         {
             return _stockName;
         }

         public void AddPrice(DateTime timeStamp, Decimal price)
         {
             _lastPrice = price;
             _price.Add(timeStamp,price);
         }

         public Decimal GetPrice(DateTime timeStamp)
         {
             for (int i=0;i < _price.Count;i++)
             {
                 var item1 = _price.ElementAt(i);
                 if (i != (_price.Count - 1))
                 {
                     var item2 = _price.ElementAt(i+1);
                     if (timeStamp > item1.Key && timeStamp < item2.Key)
                         return item1.Value;
                 }
                 else
                 {

                     return item1.Value;
                 }
             }

             return _price[timeStamp];
         }

         public Decimal GetInitialPrice()
         {
             return _initialPrice;
         }

         public Decimal GetLastPrice()
         {
             return _lastPrice;
         }

         public long GetNumberOfShares()
         {
             return _numberOfShares;
         }

         public void SetTotalNumberOfSharesInPortofilios(long total)
         {
             _totalNumberOfSharesInPortofilios += total;
         }

         public long GetTotalNumberOfSharesInPortofilios()
         {
             return _totalNumberOfSharesInPortofilios;
         }

         
     }
     
     public class Index
     {
         private string _IndexName;
         private IndexTypes _IndexType;

         private Dictionary<string, Stock> _IndexStocks;

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             _IndexName = inIndexName.ToLower();
             _IndexType = inIndexType;

             _IndexStocks = new Dictionary<string, Stock>();
         }

         public void AddStock(Stock stock)
         {
             if(_IndexStocks.ContainsKey(stock.GetStockName()))
                 throw new StockExchangeException("Indeks " + _IndexName + " ves sadrzi dionice " + stock.GetStockName());
             _IndexStocks.Add(stock.GetStockName(), stock);
         }

         public void RemoveStock(string stockName)
         {
             if (!_IndexStocks.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica " + stockName + " ne postoji u indeksu " + _IndexName);
             _IndexStocks.Remove(stockName);

         }

         public bool CointainsStock(string stockName)
         {
             if (_IndexStocks.ContainsKey(stockName))
                 return true;
             return false;
         }

         public int StockCount()
         {
             return _IndexStocks.Count;
         }

         public Decimal Value(DateTime dateTime)
         {
             Decimal value = 0;
             if (_IndexStocks.Count == 0)
                 return 0;

             if (_IndexType == IndexTypes.AVERAGE)
             {
                 foreach (var stock in _IndexStocks)
                 {
                     value += stock.Value.GetPrice(dateTime);
                 }
                 value /= _IndexStocks.Count;
                 return value;
             }
             else
             {
                 Decimal total = 0;
                 foreach (var stock in _IndexStocks)
                 {
                     total += stock.Value.GetPrice(dateTime)*stock.Value.GetNumberOfShares();
                 }
                 foreach (var stock in _IndexStocks)
                 {
                     value += (stock.Value.GetPrice(dateTime)*stock.Value.GetNumberOfShares())/total*
                              stock.Value.GetPrice(dateTime);
                 }
                 return value;
             }
         }
     }

     public class Portofilio
     {
         private string _portofilioID;

         private Dictionary<string, Tuple<Stock,int>> _stocks;
         
         public Portofilio(string inPortofilioID)
         {
             _portofilioID = inPortofilioID;
             // parametri: naziv dionice, dionica, broj udjela
             _stocks = new Dictionary<string, Tuple<Stock,int>>();
         }

         public void AddStock(Stock stock, int numberOfShares)
         {
             Tuple<Stock, int> tmpStock;
             if (_stocks.ContainsKey(stock.GetStockName()))
             {
                 tmpStock = _stocks[stock.GetStockName()];
                 tmpStock.Second += numberOfShares;
             }
             else
             {
                 tmpStock = new Tuple<Stock, int>(stock, numberOfShares);
                 _stocks.Add(stock.GetStockName(), tmpStock);
             }

            
         }

         public void RemoveStock(string stockName, int numberOfShares)
         {
             if (!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica " + stockName + " ne postoji u portifelju");
             Tuple<Stock, int> tmpStock = _stocks[stockName];
             
             if(tmpStock.Second - numberOfShares < 0)
                 throw new StockExchangeException("Ne moze se skinuti toliki broj dionica s portifelja");
             tmpStock.Second -= numberOfShares;

             if (tmpStock.Second == 0)
                 _stocks.Remove(stockName);
             tmpStock.First.SetTotalNumberOfSharesInPortofilios(-numberOfShares);
         }

         public void RemoveStock(string stockName)
         {
             if(!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica " + stockName + " ne postoji u portifelju");
             
             Tuple<Stock, int> tmpStock = _stocks[stockName];
             
             tmpStock.First.SetTotalNumberOfSharesInPortofilios(-tmpStock.Second);

             _stocks.Remove(stockName);


         }

         public int StockCount()
         {
             return _stocks.Count();
         }

         public bool ContainsStock(string stockName)
         {
             if (_stocks.ContainsKey(stockName))
                 return true;
             return false;
         }

         public int NumberOfShares(string stockName)
         {
             if (!_stocks.ContainsKey(stockName))
                 throw new StockExchangeException("Dionica " + stockName + " ne postoji u portifelju");
             Tuple<Stock, int> tmpStock = _stocks[stockName];

             return tmpStock.Second;

         }

         public Decimal Value(DateTime dateTime)
         {
             Decimal value = 0;
             foreach (var stock in _stocks)
             {
                
                     value += stock.Value.First.GetPrice(dateTime) * stock.Value.Second;
                 
             }
             
             return value;
             
         }

         public Decimal ValueChange(int year, int month)
         {
             Decimal value = 0;
             DateTime startDate = new DateTime(year,month,1,0,0,0,0);
             DateTime endDate = new DateTime(year,month,DateTime.DaysInMonth(year,month),23,59,59,999);

             Decimal changeValue = this.Value(endDate) - this.Value(startDate);
             if (changeValue == 0)
                 return 0;
             value = (changeValue)/this.Value(startDate)*100;

             return value;
         }
    }

     public class Tuple<T1, T2>
     {
         public T1 First { get; set; }
         public T2 Second { get; set; }
         internal Tuple(T1 first, T2 second)
         {
             First = first;
             Second = second;
         }
     }
}
