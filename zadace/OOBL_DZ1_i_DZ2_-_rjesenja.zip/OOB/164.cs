﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        //varijable
        private string broj = "0";
        private string znamenka = "0";

        char znak;
        char lastDigit;
        char binOper = '0';

        int brojac = 1;

        private bool uvjNula = true;      //true = na zaslonu pise samo jedna nula
        private bool uvjZarez = false;    // true = dec zarez ispisan na zaslonu
        private bool reg1BF = false;      //registar 1 za bin operacije pun
        //private bool reg2BF = false;      //registar 2 za binarne operacije pun
        private bool greska = false;    //ako se javi greska -E- onemogucuje se racunanje dok se ne stisne O

        double regBin1;
        double regBin2;
        double rezultat;
        double memorija = 0;
        double pomVar = 0;

        //  kod
        public void izracunajBinOper()
        {
            //reg2BF = true;
            regBin2 = Convert.ToDouble(broj);

            switch (binOper)
            {

                case '+':
                    rezultat = regBin1 + regBin2;
                    break;
                case '-':
                    rezultat = regBin1 - regBin2;
                    break;
                case '*':
                    rezultat = regBin1 * regBin2;
                    break;
                case '/':
                    if (regBin2 != 0)
                    {
                        rezultat = regBin1 / regBin2;
                    }
                    else
                    {
                        broj = "-E-";
                        greska = true;
                    }
                    break;

            }

            regBin1 = rezultat;
           // reg2BF = false;
            binOper = znak;
            brojac = 0;
            uvjZarez = false;
            broj = Convert.ToString(rezultat);

        } 



        public void binOperacija()
        {

            pomVar = Convert.ToDouble(broj);
            broj = Convert.ToString(pomVar);
            if (reg1BF == false)
            {
                reg1BF = true;
                regBin1 = Convert.ToDouble(broj);
                binOper = znak;
                brojac = 0;
                uvjZarez = false;
            }
            else
            {
                switch (lastDigit)
                {
                    case '1':
                        izracunajBinOper();
                        break;
                    case '2':
                        izracunajBinOper();
                        break;
                    case '3':
                        izracunajBinOper();
                        break;
                    case '4':
                        izracunajBinOper();
                        break;
                    case '5':
                        izracunajBinOper();
                        break;
                    case '6':
                        izracunajBinOper();
                        break;
                    case '7':
                        izracunajBinOper();
                        break;
                    case '8':
                        izracunajBinOper();
                        break;
                    case '9':
                        izracunajBinOper();
                        break;
                    case '0':
                        izracunajBinOper();
                        break;
                    case '+':
                        binOper = znak;
                        break;
                    case '-':
                        binOper = znak;
                        break;
                    case '*':
                        binOper = znak;
                        break;
                    case '/':
                        binOper = znak;
                        break;
                    case '=':
                        izracunajBinOper();
                        break;
                    case ',':
                        izracunajBinOper();
                        break;
                    case 'M':
                        izracunajBinOper();
                        break;
                    case 'S':
                        izracunajBinOper();
                        break;
                    case 'K':
                        izracunajBinOper();
                        break;
                    case 'T':
                        izracunajBinOper();
                        break;
                    case 'Q':
                        izracunajBinOper();
                        break;
                    case 'R':
                        izracunajBinOper();
                        break;
                    case 'I':
                        izracunajBinOper();
                        break;
                    case 'P':
                        izracunajBinOper();
                        break;
                    case 'G':
                        izracunajBinOper();
                        break;
                    case 'C':
                        izracunajBinOper();
                        break;
                }
            }
        }

        //kod



        //ako je nula na ekranu dodaje zarez ili umjesto nule upisuje utipkan broj
        //ako nije samo nula na ekranu dodaje utipkan broj i povecava brojac (max 10 znamenki)
        public void dodajZn()
        {

            if (brojac == 0)
            {
                uvjNula = true;
                uvjZarez = false;
                broj = "0";
                brojac++;
            }

            znamenka = Convert.ToString(znak);
            if (uvjNula == true)
            {
                if (znak == ',')
                {
                    broj = broj + znamenka;
                    uvjNula = false;
                    uvjZarez = true;
                }
                else
                {
                    broj = znamenka;
                    uvjNula = false;
                }
            }
            else
            {
                broj = broj + znamenka;
                if (znak == ',')
                {
                    uvjZarez = true;
                }
                else {
                    brojac++;
                }
                
            }

        }





        public void Press(char inPressedDigit)
        {
            znak = inPressedDigit;
            if (greska) {

                if (znak == 'O') greska = false;
           }

            if (greska == false) {
            switch (znak)
            {
                case '1':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100) {
                        broj = "1";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '2':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "2";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '3':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "3";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '4':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "4";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '5':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "5";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '6':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "6";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '7':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "7";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '8':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "8";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '9':
                    if (brojac < 10) dodajZn();
                    if (brojac == 100)
                    {
                        broj = "9";
                        brojac = 1;
                        uvjNula = false;
                        uvjZarez = false;
                    }
                    break;
                case '0':
                    if (brojac < 10) {
                        if (uvjNula == false) dodajZn();
                    }
                    if (brojac == 100)
                    {
                        broj = "0";
                        brojac = 1;
                        uvjNula = true;
                        uvjZarez = false;
                    }
                    break;
                case '+':
                    binOperacija();
                    break;
                case '-':
                    binOperacija();
                    break;
                case '*':
                    binOperacija();
                    break;
                case '/':
                    binOperacija();
                    break;
                case '=':
                    {
                        switch (lastDigit)
                        {
                            case '+':
                               // regBin1 = Convert.ToDouble(broj);
                                izracunajBinOper();
                                break;
                            case '-':
                               // regBin1 = Convert.ToDouble(broj);
                                izracunajBinOper();
                                break;
                            case '*':
                               // regBin1 = Convert.ToDouble(broj);
                                izracunajBinOper();
                                break;
                            case '/':
                               // regBin1 = Convert.ToDouble(broj);
                                izracunajBinOper();
                                break;
                            default:
                                binOperacija();
                                break;

                        }

                        brojac = 0;
                        reg1BF = false;
                       // reg2BF = false;
                        uvjZarez = false;
                        uvjNula = false;
                    }
                    //binOperacija();
                    break;
                case ',':
                    if (uvjZarez == false) dodajZn();
                    break;
                case 'M':
                    pomVar = Convert.ToDouble(broj);
                    if (pomVar >= 0)
                    {
                        znamenka = "-";
                        broj = znamenka + broj;
                    }
                    else
                    {
                        broj = broj.Substring(1);
                    }
                    break;
                case 'S':
                    pomVar = Convert.ToDouble(broj);
                    pomVar = Math.Sin(pomVar);
                    broj = Convert.ToString(pomVar);
                    brojac = 100;
                    break;
                case 'K':
                    pomVar = Convert.ToDouble(broj);
                    pomVar = Math.Cos(pomVar);
                    broj = Convert.ToString(pomVar);
                    brojac = 100;
                    break;
                case 'T':
                    pomVar = Convert.ToDouble(broj);
                    pomVar = Math.Tan(pomVar);
                    broj = Convert.ToString(pomVar);
                    brojac = 100;
                    break;
                case 'Q':
                    pomVar = Convert.ToDouble(broj);
                    pomVar = pomVar * pomVar;
                    broj = Convert.ToString(pomVar);
                    brojac = 100;
                    break;
                case 'R':
                    pomVar = Convert.ToDouble(broj);
                    if (pomVar < 0)
                    {
                        broj = "-E-";
                        greska = true;
                    }
                    else
                    {
                        pomVar = Math.Sqrt(pomVar);
                        broj = Convert.ToString(pomVar);
                    }
                    brojac = 100;
                    break;
                case 'I':
                    pomVar = Convert.ToDouble(broj);
                    if (pomVar == 0)
                    {
                        broj = "-E-";
                        greska = true;
                    }
                    else
                    {
                        pomVar = 1/pomVar;
                        broj = Convert.ToString(pomVar);
                    }
                    brojac = 100;
                    break;
                case 'P':
                    memorija = Convert.ToDouble(broj);
                    break;
                case 'G':
                    broj = Convert.ToString(memorija);
                    brojac = 100;
                    break;
                case 'C':
                    broj = "0";
                    brojac = 1;
                    break;
                case 'O':
                    broj = "0";
                    brojac = 1;
                    reg1BF = false;
                    //reg2BF = false;
                    uvjZarez = false;
                    uvjNula = true;
                    break;
                default:
                    throw new NotImplementedException();
            }

            lastDigit = znak;

            bool decZ = false;
            int br1 = 0;
            int br2 = 0;
            //char d = '0';

            foreach (char c in broj) {

                if (c == '-') {

                }
                else if (c == ',')
                {
                    decZ = true;
                }
                else {
                    if (decZ == false) br1++;
                    br2++;
                }
            
            }

            if (br1 > 10)
            {
                broj = "-E-";
                greska = true;
            }
            else if (br2 > 10) {
                br2 = 10 - br1;
                pomVar = Convert.ToDouble(broj);
                pomVar = Math.Round(pomVar, br2);
                broj = Convert.ToString(pomVar);
            }

        }
            //throw new NotImplementedException();
        }

        public string GetCurrentDisplayState()
        {
            return broj;
            throw new NotImplementedException();
        }

        
    }


}
