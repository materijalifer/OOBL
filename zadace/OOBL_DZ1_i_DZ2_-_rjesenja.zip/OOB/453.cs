﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private CalcController calcController;
        private CalcDisplay calcDisplay;
        private CalcModel calcModel;

        public Kalkulator()
        {
            calcModel = new CalcModel();
            calcController = new CalcController(calcModel);
            calcDisplay = new CalcDisplay(calcModel);
        }

        public void Press(char inPressedDigit)
        {
            calcController.getInput(inPressedDigit.ToString());
        }

        public string GetCurrentDisplayState()
        {
            return calcDisplay.getCurrentDisplay();
        }
    }

    public class Add : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.IsEqual == false)
            {
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
                calcModel.ActiveOperation = operation;
            }
            else
            {
                calcModel.ActiveOperation = operation;
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
            }
        }
    }

    public static class BinaryMethod
    {
        public static void executeBinaryOperation(CalcModel calcModel)
        {
            calcModel.UnaryOperation = false;

            if (calcModel.CurrentState == "x")
            {
                calcModel.CurrentState = calcModel.currentDisplayString();
            }
            else if (calcModel.RepeateOperation == 0)
            {
                switch (calcModel.ActiveOperation)
                {
                    case "+":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) + Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "-":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) - Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "/":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) / Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "*":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) * Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                }
            }
            calcModel.IsEqual = false;
        }
    }

    public class CalcController
    {
        private CalcModel calcModel;
        private OperationFactory operationFactory;

        public CalcController(CalcModel calcModel)
        {
            this.operationFactory = new OperationFactory();
            this.calcModel = calcModel;
        }

        public void getInput(string character)
        {
            IOperation operation = operationFactory.createOperation(character);

            if (calcModel.currentDisplayString() == "-E-" && (character == "O" || character == "R"))
            {
                operation.operationExecute(this.calcModel, character);
            }
            else if (calcModel.currentDisplayString() != "-E-")
            {
                operation.operationExecute(this.calcModel, character);
            }
        }
    }

    public class CalcDisplay
    {
        private CalcModel calcModel;

        public CalcDisplay(CalcModel calcModel)
        {
            this.calcModel = calcModel;
        }

        public string getCurrentDisplay()
        {
            string result = this.calcModel.currentDisplayString().TrimStart('0').TrimEnd('0');

            if (result == "")
            {
                result = "0";
            }
            else if (result[0] == ',')
            {
                result = "0" + result;
            }
            else if (result[result.Length - 1] == ',')
            {
                result = result.Substring(0, result.Length - 1);
            }

            return result;
        }
    }

    public class CalcModel
    {
        private List<string> memory;
        private List<string> currentDisplay;

        private string activeOperation;
        private string currentState;

        private Boolean isEqual;

        private Boolean zeroState;
        private Boolean unaryOperation;

        private int numDigits;
        private int repeateOperation;

        public CalcModel()
        {
            repeateOperation = 0;  
            numDigits = 0;
            
            zeroState = true;
            unaryOperation = false;
            isEqual = false;

            activeOperation = "";
            currentState = "x";

            memory = new List<string>();
            currentDisplay = new List<string>();

            currentDisplay.Add("0");
        }

        public string currentDisplayString()
        {
            string result = "";
            foreach (string str in currentDisplay)
            {
                result += str;
            }

            return result;
        }

        public Boolean IsEqual
        {
            get { return isEqual; }
            set { isEqual = value; }
        }

        public Boolean UnaryOperation
        {
            get { return unaryOperation; }
            set { unaryOperation = value; }
        }

        public int RepeateOperation
        {
            get { return repeateOperation; }
            set { repeateOperation = value; }
        }

        public List<string> CurrentDisplay
        {
            get { return currentDisplay; }
            set { currentDisplay = value; }
        }

        public List<string> Memory
        {
            get { return memory; }
            set { memory = value; }
        }

        public Boolean ZeroState
        {
            get { return zeroState; }
            set { zeroState = value; }
        }

        public int NumDigits
        {
            get { return numDigits; }
            set { numDigits = value; }
        }

        public string CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }

        public string ActiveOperation
        {
            get { return activeOperation; }
            set { activeOperation = value; }
        }
    }


    public class Clear : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            calcModel.CurrentDisplay.Clear();
            calcModel.CurrentDisplay.Add("0");
            calcModel.NumDigits = 0;
        }
    }

    public class Comma : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            calcModel.CurrentDisplay.Add(operation);
        }
    }

    public class Cosinus : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double cos = Math.Cos(Double.Parse(calcModel.currentDisplayString()));

            UnaryMethod.executeUnaryOperation(calcModel, cos.ToString());
        }
    }

    public class Divide : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.IsEqual == false)
            {
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
                calcModel.ActiveOperation = operation;
            }
            else
            {
                calcModel.ActiveOperation = operation;
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
            }
        }
    }

    public class Equal : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            calcModel.RepeateOperation = 0;
            if (calcModel.CurrentState != "x" && calcModel.IsEqual == false)
            {
                string result;
                switch (calcModel.ActiveOperation)
                {
                    case "+":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) + Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "-":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) - Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "/":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) / Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "*":
                        calcModel.CurrentState = (Double.Parse(calcModel.CurrentState) * Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    default:
                        calcModel.CurrentState = "";
                        break;
                }
                if (calcModel.CurrentState == "x")
                    calcModel.CurrentState = calcModel.currentDisplayString();

                calcModel.CurrentDisplay.Clear();

                if (calcModel.CurrentState.Contains(','))
                {
                    if (calcModel.CurrentState.Substring(0, calcModel.CurrentState.IndexOf(',')).Length <= 10)
                    {
                        for (int i = 0; i < calcModel.CurrentState.Length; i++)
                            calcModel.CurrentDisplay.Add(calcModel.CurrentState[i].ToString());
                    }
                    else
                    {
                        calcModel.CurrentDisplay.Add("-");
                        calcModel.CurrentDisplay.Add("E");
                        calcModel.CurrentDisplay.Add("-");
                    }
                }
                else if (calcModel.CurrentState.Length <= 10)
                {
                    calcModel.CurrentDisplay.Clear();
                    for (int i = 0; i < calcModel.CurrentState.Length; i++)
                        calcModel.CurrentDisplay.Add(calcModel.CurrentState[i].ToString());
                }
                else
                {
                    calcModel.CurrentDisplay.Clear();
                    calcModel.CurrentDisplay.Add("-");
                    calcModel.CurrentDisplay.Add("E");
                    calcModel.CurrentDisplay.Add("-");
                }
            }
            else if (calcModel.CurrentState != "x")
            {
                string result;
                switch (calcModel.ActiveOperation)
                {
                    case "+":
                        result = (Double.Parse(calcModel.CurrentState) + Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "-":
                        result = (Double.Parse(calcModel.CurrentState) - Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "/":
                        result = (Double.Parse(calcModel.CurrentState) / Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    case "*":
                        result = (Double.Parse(calcModel.CurrentState) * Double.Parse(calcModel.currentDisplayString())).ToString();
                        break;
                    default:
                        result = "";
                        break;
                }
                calculateCurrnetDisplay(calcModel, result);
            }
            calcModel.IsEqual = true;
        }

        private void calculateCurrnetDisplay(CalcModel calcModel, string result)
        {
            if (calcModel.CurrentState == "x")
                calcModel.CurrentState = calcModel.currentDisplayString();

            calcModel.CurrentDisplay.Clear();

            if (result.Contains(','))
            {
                if (result.Substring(0, result.IndexOf(',')).Length <= 10)
                {
                    for (int i = 0; i < result.Length; i++)
                        calcModel.CurrentDisplay.Add(result[i].ToString());
                }
                else
                {
                    calcModel.CurrentDisplay.Add("-");
                    calcModel.CurrentDisplay.Add("E");
                    calcModel.CurrentDisplay.Add("-");
                }
            }
            else if (result.Length <= 10)
            {
                calcModel.CurrentDisplay.Clear();
                for (int i = 0; i < result.Length; i++)
                    calcModel.CurrentDisplay.Add(result[i].ToString());
            }
            else
            {
                calcModel.CurrentDisplay.Clear();
                calcModel.CurrentDisplay.Add("-");
                calcModel.CurrentDisplay.Add("E");
                calcModel.CurrentDisplay.Add("-");
            }
        }
    }

    public class Get : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            calcModel.CurrentDisplay = calcModel.Memory.ToList();
        }
    }

    public class Invers : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double invers;
            if (calcModel.currentDisplayString() != "0")
            {
                invers = (double)1 / Double.Parse(calcModel.currentDisplayString());
            }
            else
            {
                calcModel.CurrentDisplay.Clear();
                calcModel.CurrentDisplay.Add("-");
                calcModel.CurrentDisplay.Add("E");
                calcModel.CurrentDisplay.Add("-");

                return;
            }

            UnaryMethod.executeUnaryOperation(calcModel, invers.ToString());

        }
    }

    public interface IOperation
    {
        void operationExecute(CalcModel calcModel, string operation);
    }

    public class Multiple : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.IsEqual == false)
            {
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
                calcModel.ActiveOperation = operation;
            }
            else
            {
                calcModel.ActiveOperation = operation;
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
            }
        }
    }

    public class Number : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.UnaryOperation == true)
            {
                calcModel.UnaryOperation = false;
                calcModel.CurrentDisplay.Clear();
                calcModel.NumDigits = 0;
            }

            if (calcModel.RepeateOperation > 0)
            {
                calcModel.CurrentDisplay.Clear();
                calcModel.NumDigits = 0;
            }

            calcModel.RepeateOperation = 0;

            if (calcModel.ZeroState == true)
            {
                calcModel.CurrentDisplay.RemoveAt(0);
                calcModel.ZeroState = false;
            }

            if (calcModel.NumDigits < 10)
            {
                calcModel.CurrentDisplay.Add(operation);
            }

            if (Char.IsDigit(operation, 0))
            {
                calcModel.NumDigits++;
            }
            calcModel.IsEqual = false;
        }
    }

    public class OperationFactory
    {
        public IOperation createOperation(string operation)
        {
            switch (operation)
            {
                case "+":
                    return new Add();
                case "-":
                    return new Substract();
                case "/":
                    return new Divide();
                case "*":
                    return new Multiple();
                case "Q":
                    return new Quadrat();
                case "I":
                    return new Invers();
                case "C":
                    return new Clear();
                case "R":
                    return new Root();
                case "P":
                    return new Put();
                case "G":
                    return new Get();
                case "S":
                    return new Sinus();
                case "T":
                    return new Tangens();
                case "K":
                    return new Cosinus();
                case "M":
                    return new SignChange();
                case "O":
                    return new Reset();
                case "=":
                    return new Equal();
                default:
                    return new Number();
            }

        }
    }

    public class Put : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.Memory.Count != 0)
                calcModel.Memory.RemoveAt(0);
            calcModel.Memory.Add(calcModel.currentDisplayString());
        }
    }

    public class Quadrat : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double quad = Math.Pow(Double.Parse(calcModel.currentDisplayString()), 2);

            UnaryMethod.executeUnaryOperation(calcModel, quad.ToString());

        }
    }

    public class Reset : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            calcModel.CurrentState = "x";
            calcModel.CurrentDisplay.Clear();
            calcModel.Memory.Clear();
            calcModel.ZeroState = true;
            calcModel.NumDigits = 0;
            calcModel.CurrentDisplay.Add("0");
            calcModel.IsEqual = false;
        }
    }

    public class Root : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double root;
            if (Double.Parse(calcModel.currentDisplayString()) >= 0)
            {
                root = Math.Sqrt(Double.Parse(calcModel.currentDisplayString()));
            }
            else
            {
                calcModel.CurrentDisplay.Clear();
                calcModel.CurrentDisplay.Add("-");
                calcModel.CurrentDisplay.Add("E");
                calcModel.CurrentDisplay.Add("-");
                return;
            }

            UnaryMethod.executeUnaryOperation(calcModel, root.ToString());

        }
    }

    public class SignChange : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.CurrentDisplay[0] != "-")
            {
                calcModel.CurrentDisplay.Insert(0, "-");
            }
            else
            {
                calcModel.CurrentDisplay.RemoveAt(0);
            }
            calcModel.IsEqual = false;
        }
    }

    public class Sinus : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double sin = Math.Sin(Double.Parse(calcModel.currentDisplayString()));

            UnaryMethod.executeUnaryOperation(calcModel, sin.ToString());
        }
    }

    public class Substract : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            if (calcModel.IsEqual == false)
            {
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
                calcModel.ActiveOperation = operation;
            }
            else
            {
                calcModel.ActiveOperation = operation;
                BinaryMethod.executeBinaryOperation(calcModel);
                calcModel.RepeateOperation++;
            }
        }
    }

    public class Tangens : IOperation
    {
        public void operationExecute(CalcModel calcModel, string operation)
        {
            double tan = Math.Tan(Double.Parse(calcModel.currentDisplayString()));

            UnaryMethod.executeUnaryOperation(calcModel, tan.ToString());
        }
    }

    public static class UnaryMethod
    {
        public static void executeUnaryOperation(CalcModel calcModel, string value)
        {
            calcModel.UnaryOperation = true;

            if (value.Contains(','))
            {
                if (value.Substring(0, value.IndexOf(',')).Length > 10)
                {
                    calcModel.CurrentDisplay.Clear();
                    calcModel.CurrentDisplay.Add("-");
                    calcModel.CurrentDisplay.Add("E");
                    calcModel.CurrentDisplay.Add("-");
                }
                else
                {
                    int rest;
                    if (Double.Parse(value) > 0)
                    {
                        rest = 10 - value.Substring(0, value.IndexOf(',')).Length;
                    }
                    else
                    {
                        rest = 11 - value.Substring(0, value.IndexOf(',')).Length;
                    }
                    double result = Math.Round(Double.Parse(value), rest);

                    string final = result.ToString();

                    calcModel.CurrentDisplay.Clear();
                    for (int i = 0; i < final.Length; i++)
                        calcModel.CurrentDisplay.Add(final[i].ToString());
                }
            }
            else if (value.Length <= 10)
            {
                calcModel.CurrentDisplay.Clear();
                for (int i = 0; i < value.Length; i++)
                    calcModel.CurrentDisplay.Add(value[i].ToString());
            }
            else
            {
                calcModel.CurrentDisplay.Clear();
                calcModel.CurrentDisplay.Add("-");
                calcModel.CurrentDisplay.Add("E");
                calcModel.CurrentDisplay.Add("-");
            }
            calcModel.IsEqual = false;
        }
    }

}
