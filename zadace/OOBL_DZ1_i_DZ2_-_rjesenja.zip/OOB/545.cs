﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Dionica> listaDionica = new List<Dionica>();
         private List<Index> listaIndexa = new List<Index>(); 
         private List<Portfelj> listaPortfelja = new List<Portfelj>(); 


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (listaDionica.Exists(x => x.ImeDionice == inStockName))
                 throw  new StockExchangeException("Neuspjelo dodavanje : dionica vec postoji");

             Dionica dionica = new Dionica(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             listaDionica.Add(dionica);
         }

         public void DelistStock(string inStockName)
         {

             inStockName = inStockName.ToUpper();
             int pom = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom != -1)
             {
                 listaDionica.RemoveAt(pom);
             }
             else
             {
                 throw new StockExchangeException("Brisanje neuspjelo : ne postoji ta dionica");
             }

             for (int i = 0; i < listaPortfelja.Count(); i++)
             {
                 int pom1 = listaPortfelja[i].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
                 if (pom1 != -1)
                     listaPortfelja[i].ListaDionicaSkupa.RemoveAt(pom1);
             }

             for (int i = 0; i < listaIndexa.Count(); i++)
             {
                 int pom1 = listaIndexa[i].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
                 if (pom1 != -1)
                     listaIndexa[i].ListaDionicaSkupa.RemoveAt(pom1);
             }
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             return (listaDionica.Exists(x => x.ImeDionice == inStockName));

         }

         public int NumberOfStocks()
         {
             return listaDionica.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom == -1)
             {
                 throw new StockExchangeException("Neuspjela promjena cijene : ne postoji ta dionica");
             }
             else
             {
                 for (int i = 0; i < listaDionica[pom].PovijestCijene.Count; i++)
                     if (DateTime.Compare(listaDionica[pom].PovijestCijene[i].Datum, inIimeStamp) == 0)
                         throw new StockExchangeException("Cijena za ovo vrijeme je vec definirana");

                 if (DateTime.Compare(inIimeStamp,listaDionica[pom].PovijestCijene[listaDionica[pom].PovijestCijene.Count() - 1].Datum) > 0)
                     listaDionica[pom].PovijestCijene.Add(new Dionica.strukturaPovijestiCijene(inStockValue, inIimeStamp));
                 else
                 {
                     int j = 0;
                     while (DateTime.Compare(listaDionica[pom].PovijestCijene[j].Datum, inIimeStamp) < 0)
                         j++;
                     listaDionica[pom].PovijestCijene.Insert(j,
                         new Dionica.strukturaPovijestiCijene(inStockValue, inIimeStamp));
                 }
                 //listaDionica[pom].PovijestCijene.Add(new Dionica.strukturaPovijestiCijene(inStockValue, inIimeStamp));
             }
             for (int i = 0; i < listaPortfelja.Count(); i++)
             {
                 int pom1 = listaPortfelja[i].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
                 if (pom1 != -1)
                     listaPortfelja[i].ListaDionicaSkupa[pom1].PovijestCijene = listaDionica[pom].PovijestCijene;
             }

             for (int i = 0; i < listaIndexa.Count(); i++)
             {
                 int pom1 = listaIndexa[i].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
                 if (pom1 != -1)
                     listaIndexa[i].ListaDionicaSkupa[pom1].PovijestCijene = listaDionica[pom].PovijestCijene;
             }




         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom == -1)
             {
                 throw new StockExchangeException("Neuspjelo dohvacanje cijene : ne postoji ta dionica");
             }
             if (DateTime.Compare(inTimeStamp, listaDionica[pom].PovijestCijene[0].Datum) < 0)
                 throw new StockExchangeException("nije definirana cijena za to razdoblje");
             else
             {
                 int i;
                 for (i = listaDionica[pom].PovijestCijene.Count() - 1; i > -1; i--)
                 {

                     //kaj ak je zadan prerani trenutak
                     if (i == 0)
                     {
                         return listaDionica[pom].PovijestCijene[0].Cijena;
                     }
                     else
                     {
                         //mozda ==
                         if (DateTime.Compare(listaDionica[pom].PovijestCijene[i].Datum, inTimeStamp) <= 0)
                             return listaDionica[pom].PovijestCijene[i].Cijena;
                     }
                 }

             }
             return listaDionica[pom].PovijestCijene[0].Cijena; //pazi 
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom == -1)
             {
                 throw new StockExchangeException("Neuspjelo dohvacanje pocetne cijene : ne postoji ta dionica");
             }
             else return listaDionica[pom].PovijestCijene[0].Cijena;

         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom == -1)
             {
                 throw new StockExchangeException("Neuspjelo dohvacanje cijene : ne postoji ta dionica");
             }
             else
             {
                 int br = listaDionica[pom].PovijestCijene.Count();
                 return listaDionica[pom].PovijestCijene[br - 1].Cijena;
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToUpper();
             if ((inIndexType != IndexTypes.AVERAGE) && (inIndexType != IndexTypes.WEIGHTED))
                 throw new StockExchangeException("krivi tip indexa");
             if (listaIndexa.Exists(x => x.ImeSkupaDionica == inIndexName))
                 throw new StockExchangeException("Neuspjelo dodavanje : index vec postoji");

             Index index = new Index(inIndexName, inIndexType);
             listaIndexa.Add(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             int pom = listaIndexa.FindIndex(x => x.ImeSkupaDionica == inIndexName);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u index : ne postoji index");

             int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u index : ne postoji dionica");

             int pom2 = listaIndexa[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 != -1)
                 throw new StockExchangeException("postoji vec ta dionica u indexu");

             listaIndexa[pom].ListaDionicaSkupa.Add(listaDionica[pom1]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             int pom = listaIndexa.FindIndex(x => x.ImeSkupaDionica == inIndexName);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u index : ne postoji index");

             int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u index : ne postoji dionica");
             //mozda samo return

             listaIndexa[pom].ListaDionicaSkupa.RemoveAt(pom1);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             int pom = listaIndexa.FindIndex(x => x.ImeSkupaDionica == inIndexName);
             if (pom == -1)
                 throw new StockExchangeException("neuspjela provjera : ne postoji index");

            /* int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjela provjera : ne postoji dionica");
*/

             return (listaIndexa[pom].ListaDionicaSkupa.Exists(x => x.ImeDionice == inStockName));

         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();
             int pom = listaIndexa.FindIndex(x => x.ImeSkupaDionica == inIndexName);
             if (pom == -1)
                 throw new StockExchangeException("neuspjela provjera : ne postoji index");

             for (int i = 0; i < listaIndexa[pom].ListaDionicaSkupa.Count; i++)
                 if (DateTime.Compare(inTimeStamp, listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[0].Datum) < 0)
                     throw new StockExchangeException("Nije definirana vrijednost tada");

             
             if (listaIndexa[pom].TipIndexa == IndexTypes.AVERAGE)
             {
                 decimal suma = 0;
                 for (int i = 0; i < listaIndexa[pom].ListaDionicaSkupa.Count(); i++)
                 {
                     for (int j =listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene.Count() - 1; j > -1; j--)
                     {

                         //kaj ak je zadan prerani trenutak
                         if (j == 0)
                         {
                             suma += listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[0].Cijena;
                         }
                         else
                         {
                             //mozda ==
                             if (DateTime.Compare(listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Datum,
                                     inTimeStamp) <= 0)
                             {
                                 suma += listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Cijena;
                                 break;
                             }
                         }
                     }

                 }
                 suma = suma/listaIndexa[pom].ListaDionicaSkupa.Count();
                 suma = Decimal.Round(suma, 3);
                 return suma;
             }
             else
             {
                 decimal faktorsuma = 0;
                 for (int i = 0; i < listaIndexa[pom].ListaDionicaSkupa.Count(); i++)
                 {
                     for (int j = listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene.Count() - 1; j > -1; j--)
                     {

                         //kaj ak je zadan prerani trenutak
                         if (j == 0)
                         {
                             faktorsuma += listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[0].Cijena *
                                            listaIndexa[pom].ListaDionicaSkupa[i].BrojDionica;
                         }
                         else
                         {
                             //mozda ==
                             if (DateTime.Compare(listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Datum, inTimeStamp) <= 0)
                             {
                                 faktorsuma += listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Cijena *
                                                listaIndexa[pom].ListaDionicaSkupa[i].BrojDionica;
                                 break;
                             }

                         }
                     }

                 }

                 decimal suma = 0;
                 for (int i = 0; i < listaIndexa[pom].ListaDionicaSkupa.Count(); i++)
                 {
                     for (int j = listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene.Count() - 1; j > -1; j--)
                     {

                         //kaj ak je zadan prerani trenutak
                         if (j == 0)
                         {
                             suma += (listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[0].Cijena *
                                            listaIndexa[pom].ListaDionicaSkupa[i].BrojDionica) /
                                            faktorsuma * listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[0].Cijena;
                         }
                         else
                         {
                             //mozda ==
                             if (DateTime.Compare(listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Datum, inTimeStamp) <= 0)
                             {
                                 suma += (listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Cijena *
                                                listaIndexa[pom].ListaDionicaSkupa[i].BrojDionica) /
                                                faktorsuma * listaIndexa[pom].ListaDionicaSkupa[i].PovijestCijene[j].Cijena;
                                 break;
                             }
                         }

                     }


                 }
                 suma = Decimal.Round(suma, 3);
                 return suma;
             }

             
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             return (listaIndexa.Exists(x => x.ImeSkupaDionica == inIndexName));
         }

         public int NumberOfIndices()
         {
             return listaIndexa.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             int pom = listaIndexa.FindIndex(x => x.ImeSkupaDionica == inIndexName);
             if (pom == -1)
                 throw new StockExchangeException("neuspjela provjera : ne postoji index");

             return listaIndexa[pom].ListaDionicaSkupa.Count();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (listaPortfelja.Exists(x => x.ImeSkupaDionica == inPortfolioID))
                 throw new StockExchangeException("Neuspjelo dodavanje : portfelj vec postoji");

             Portfelj portfelj = new Portfelj(inPortfolioID);
             listaPortfelja.Add(portfelj);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u portfelj : ne postoji portfelj");

             int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo dodavanje u portfelj : ne postoji dionica");


             if (numberOfShares > listaDionica[pom1].BrojDionica)
                 numberOfShares = (int)listaDionica[pom1].BrojDionica;

             int pom2 = listaPortfelja[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 == -1)
             {
                 listaPortfelja[pom].ListaDionicaSkupa.Add(new Dionica(listaDionica[pom1].ImeDionice,
                     numberOfShares,
                     listaDionica[pom1].PovijestCijene[listaDionica[pom1].PovijestCijene.Count() - 1].Cijena,
                     listaDionica[pom1].PovijestCijene[listaDionica[pom1].PovijestCijene.Count() - 1].Datum
                     ));
                 listaPortfelja[pom].ListaDionicaSkupa[listaPortfelja[pom].ListaDionicaSkupa.Count() - 1].PovijestCijene
                     = listaDionica[pom1].PovijestCijene;

                 

                // listaPortfelja[pom].ListaDionicaSkupa.Add(listaDionica[pom1]);
                // listaPortfelja[pom].ListaDionicaSkupa[listaPortfelja[pom].ListaDionicaSkupa.Count() - 1].BrojDionica =
                //     numberOfShares;

                 listaDionica[pom1].BrojDionica -= numberOfShares;
             }
             else
             {
                 listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica += numberOfShares;
                 listaDionica[pom1].BrojDionica -= numberOfShares;
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

             int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");

             int pom2 = listaPortfelja[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");

             if (numberOfShares > listaPortfelja[pom].ListaDionicaSkupa[pom1].BrojDionica)
             {
                 listaDionica[pom1].BrojDionica += listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica;
                 listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica = 0;
                 
                 if (listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica == 0)
                     listaPortfelja[pom].ListaDionicaSkupa.RemoveAt(pom2);
             }
             else
             {
                 listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica -= numberOfShares;
                 listaDionica[pom1].BrojDionica += numberOfShares;

                 if (listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica == 0)
                     listaPortfelja[pom].ListaDionicaSkupa.RemoveAt(pom2);  
             }

             
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

             int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");

             int pom2 = listaPortfelja[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");

             listaDionica[pom1].BrojDionica += listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica;
             listaPortfelja[pom].ListaDionicaSkupa.RemoveAt(pom2);
             
         }

         public int NumberOfPortfolios()
         {
             return listaPortfelja.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

             return listaPortfelja[pom].ListaDionicaSkupa.Count();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return listaPortfelja.Exists(x => x.ImeSkupaDionica == inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

            /* int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");
             */

             int pom2 = listaPortfelja[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 == -1) return false;
             else return true;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

            /* int pom1 = listaDionica.FindIndex(x => x.ImeDionice == inStockName);
             if (pom1 == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji dionica");
             */
             
             int pom2 = listaPortfelja[pom].ListaDionicaSkupa.FindIndex(x => x.ImeDionice == inStockName);
             if (pom2 == -1)
                 return 0;

             //mozda vraca 0 ako nije a ne exception
             //kaje s return vakue int long
             return (int)listaPortfelja[pom].ListaDionicaSkupa[pom2].BrojDionica;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

             for (int i = 0; i < listaPortfelja[pom].ListaDionicaSkupa.Count; i++)
                 if (DateTime.Compare(timeStamp, listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene[0].Datum) < 0)
                     throw new StockExchangeException("Nije definirana vrijednost tada");

             decimal suma = 0;
             for (int i = 0; i < listaPortfelja[pom].ListaDionicaSkupa.Count(); i++)
                 for (int j = listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene.Count() - 1; j > -1; j--)
                 {

                     //kaj ak je zadan prerani trenutak
                     if (j == 0)
                     {
                         suma += listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene[0].Cijena *
                             listaPortfelja[pom].ListaDionicaSkupa[i].BrojDionica;
                     }
                     else
                     {
                         //mozda ==
                         if (DateTime.Compare(listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene[j].Datum, timeStamp) <= 0)
                         {
                             suma += listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene[j].Cijena *
                             listaPortfelja[pom].ListaDionicaSkupa[i].BrojDionica;
                             break;
                         }
                     }
                 }
             suma = Decimal.Round(suma, 3);
             return suma;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (Month < 1 || Month > 12)
                 throw new StockExchangeException("krivi datum");

             int pom = listaPortfelja.FindIndex(x => x.ImeSkupaDionica == inPortfolioID);
             if (pom == -1)
                 throw new StockExchangeException("neuspjelo brisanje iz portfelja : ne postoji portfelj");

             DateTime pocetno = new DateTime(Year,Month,1,0,0,0);
             DateTime konacno = new DateTime(Year,Month,DateTime.DaysInMonth(Year,Month),23,59,59,999);

             for (int i = 0; i < listaPortfelja[pom].ListaDionicaSkupa.Count; i++)
                 if (DateTime.Compare(pocetno,listaPortfelja[pom].ListaDionicaSkupa[i].PovijestCijene[0].Datum) < 0)
                     throw new StockExchangeException("Nije definirana vrijednost tada");
             
             decimal promjena = 0;
             promjena = (GetPortfolioValue(inPortfolioID, konacno) - GetPortfolioValue(inPortfolioID, pocetno))/
                        GetPortfolioValue(inPortfolioID, pocetno)*100;
             return promjena;
         }
     }

    public class Dionica
    {
        private string imeDionice;
        private long brojDionica;
        private decimal pocetnaCijena;
        public struct strukturaPovijestiCijene
        {
            public decimal Cijena;
            public DateTime Datum;
            public strukturaPovijestiCijene(decimal x, DateTime y) 
            {
                this.Cijena = x;
                this.Datum = y;
            }
        }

        private List<strukturaPovijestiCijene> povijestCijene = new List<strukturaPovijestiCijene>();
      

        public string ImeDionice
        {
            get { return imeDionice; }
            set { imeDionice = value; }
        }

        public long BrojDionica
        {
            get { return brojDionica; }
            set
            {
               // if (value <= 0)
               //     throw new StockExchangeException("Pogresan broj dionica");
                brojDionica = value;
            }
        }

        public decimal PocetnaCijena
        {
            get { return pocetnaCijena; }
            set
            {
                if (value <= 0)
                    throw new StockExchangeException("Poresna cijena");
                pocetnaCijena = value;
            }
        }

        public List<strukturaPovijestiCijene> PovijestCijene
        {
            get { return povijestCijene; }
            set { povijestCijene = value; }
        }


        public Dionica(string ime, long broj, decimal cijena, DateTime vrijeme)
        {
            if ((broj <= 0) || (cijena <= 0))
                throw new StockExchangeException("Pogrešni parametri kreiranje dionice");
            imeDionice = ime;
            brojDionica = broj;
            pocetnaCijena = cijena;
            povijestCijene.Add(new strukturaPovijestiCijene(cijena, vrijeme));       
        }

    }

    public class SkupDionica
    {
        private string imeSkupaDionica;
        private List<Dionica> listaDionicaSkupa = new List<Dionica>(); 

        public string ImeSkupaDionica
        {
            get { return imeSkupaDionica; }
            set { imeSkupaDionica = value; }
        }

        public List<Dionica> ListaDionicaSkupa
        {
            get { return listaDionicaSkupa; }
            set { listaDionicaSkupa = value; }
        }
    }

    public class Index : SkupDionica
    {
        private IndexTypes tipIndexa;

        public IndexTypes TipIndexa
        {
            get { return tipIndexa; }
            set { tipIndexa = value; }
        }

        public Index(string ime, IndexTypes tip)
        { 
            ImeSkupaDionica = ime;
            TipIndexa = tip;
        }

    }

    public class Portfelj : SkupDionica
    {
       public Portfelj(string ime)
       {
           ImeSkupaDionica = ime;
       } 
    }



}

//datum na milisekunde ??


//is stack part of port? kaj ak nema niti na burzi
//namespace name