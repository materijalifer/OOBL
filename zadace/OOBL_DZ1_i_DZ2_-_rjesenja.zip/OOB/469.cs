﻿//using Kalkulator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Calculon()
            {
                CurrentData = "0",
                MemoryData = "0",
                AnsData = "",
                CurrentOperation = Operation.None,
                CurrentDataLocked = false,
                UnarOperation = false
            };
        }
    }

    public class Calculon : ICalculator
    {
        public string CurrentData { get; set; }

        public bool CurrentDataLocked { get; set; }

        public string MemoryData { get; set; }

        public string AnsData { get; set; }

        public Operation CurrentOperation { get; set; }

        public bool UnarOperation { get; set; }

        public void Press(char inPressedDigit)
        {
            if (CurrentData != "-E-")
            {
                switch (inPressedDigit)
                {
                    case '1':
                        InputNumber("1");
                        break;
                    case '2':
                        InputNumber("2");
                        break;
                    case '3':
                        InputNumber("3");
                        break;
                    case '4':
                        InputNumber("4");
                        break;
                    case '5':
                        InputNumber("5");
                        break;
                    case '6':
                        InputNumber("6");
                        break;
                    case '7':
                        InputNumber("7");
                        break;
                    case '8':
                        InputNumber("8");
                        break;
                    case '9':
                        InputNumber("9");
                        break;
                    case '0':
                        InputNumber("0");
                        break;
                    case ',':
                        InputComma();
                        break;
                    case 'M':
                        InputPlusMinus();
                        break;
                    case 'P':
                        InputMemoryStore();
                        break;
                    case 'G':
                        InputMemoryRestore();
                        break;
                    case 'I':
                        InputInverse();
                        break;
                    case 'R':
                        InputSqrRoot();
                        break;
                    case 'Q':
                        InputSqr();
                        break;
                    case 'S':
                        InputSin();
                        break;
                    case 'K':
                        InputCos();
                        break;
                    case 'T':
                        InputTan();
                        break;
                    case '+':
                        InputPlus();
                        break;
                    case '-':
                        InputMinus();
                        break;
                    case '/':
                        InputDiv();
                        break;
                    case '*':
                        InputMul();
                        break;
                    case '=':
                        InputEq();
                        break;
                }
            }

            switch (inPressedDigit)
            {
                case 'O':
                    InputOnOff();
                    break;
                case 'C':
                    InputClear();
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            return CurrentData;
        }

        private void InputNumber(string input)
        {
            if (CurrentOperation != Operation.None && CurrentDataLocked && !UnarOperation)
            {
                AnsData = CurrentData;
            }
            if (!CurrentDataLocked)
            {
                if (CurrentData.Replace("-", "").Replace(",", "").Length < 10)
                {
                    if (CurrentData == "0")
                    {
                        CurrentData = input;
                    }
                    else
                    {
                        CurrentData += input;
                    }
                }
            }
            else
            {
                CurrentData = input;
                CurrentDataLocked = false;
            }
        }
        private void InputComma()
        {
            if (CurrentOperation != Operation.None && CurrentDataLocked && !UnarOperation)
            {
                AnsData = CurrentData;
            }
            if (!CurrentDataLocked)
            {
                if (!CurrentData.Contains(','))
                {
                    CurrentData += ",";
                }
            }
            else
            {
                CurrentData = "0,";
                CurrentDataLocked = false;
            }
        }
        private void InputPlusMinus()
        {
            if (Double.Parse(CurrentData) != 0D)
            {
                if (CurrentData.Contains('-'))
                {
                    CurrentData = CurrentData.Replace("-", "");
                }
                else
                {
                    CurrentData = "-" + CurrentData;
                }
            }
        }
        private void InputClear()
        {
            CurrentData = "0";
            CurrentDataLocked = false;
        }
        private void InputMemoryStore()
        {
            MemoryData = FormatResult(Double.Parse(CurrentData));
            //CurrentDataLocked = false;
        }
        private void InputMemoryRestore()
        {
            CurrentData = MemoryData;
            CurrentDataLocked = true;
        }

        private string FormatResult(double input)
        {
            if(Double.IsNaN(input) || Double.IsInfinity(input)){
                return "-E-";
            }
            bool isNegative = input < 0D;
            if (isNegative)
            {
                input *= -1D;
            }
            string negativeString = isNegative ? "-" : "";
            string doubleString = input.ToString();
            string intPart = doubleString.Split(',')[0];
            if (intPart.Length > 10)
            {
                return "-E-";
            }
            string decimalPart = "";
            if (doubleString.Split(',').Count() > 1)
            {
                string[] arr = Math.Round(input, 10 - intPart.Length).ToString().Split(',');
                if (arr.Count() > 1)
                {
                    decimalPart = arr[1];
                }
            }
            if (decimalPart == "")
            {
                return negativeString + intPart;
            }
            else
            {
                return negativeString + intPart + "," + decimalPart;
            }
        }

        private void InputInverse()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(1 / Double.Parse(CurrentData));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }

        private void InputSqrRoot()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    //AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(Math.Sqrt(Double.Parse(CurrentData)));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }
        private void InputSqr()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    //AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(Math.Pow(Double.Parse(CurrentData), 2D));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }

        private void InputSin()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    //AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(Math.Sin(Double.Parse(CurrentData)));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }
        private void InputCos()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    //AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(Math.Cos(Double.Parse(CurrentData)));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }
        private void InputTan()
        {
            try
            {
                if (CurrentOperation != Operation.None)
                {
                    //AnsData = CurrentData;
                    UnarOperation = true;
                }
                CurrentData = FormatResult(Math.Tan(Double.Parse(CurrentData)));
                CurrentDataLocked = true;
            }
            catch
            {
                CurrentData = "-E-";
            }
        }

        private void ExecuteOperation()
        {
            switch (CurrentOperation)
            {
                case Operation.Addition:
                    CurrentData = FormatResult(Double.Parse(AnsData) + Double.Parse(CurrentData));
                    break;
                case Operation.Division:
                    CurrentData = FormatResult(Double.Parse(AnsData) / Double.Parse(CurrentData));
                    break;
                case Operation.Multiplication:
                    CurrentData = FormatResult(Double.Parse(AnsData) * Double.Parse(CurrentData));
                    break;
                case Operation.Subtraction:
                    CurrentData = FormatResult(Double.Parse(AnsData) - Double.Parse(CurrentData));
                    break;
            }
            AnsData = "";
            CurrentOperation = Operation.None;
        }

        private void InputPlus()
        {
            if (AnsData != "")
            {
                ExecuteOperation();
            }
            else
            {
                CurrentData = FormatResult(Double.Parse(CurrentData));
            }
            CurrentOperation = Operation.Addition;
            CurrentDataLocked = true;
            UnarOperation = false;
        }
        private void InputMinus()
        {
            if (AnsData != "")
            {
                ExecuteOperation();
            }
            else
            {
                CurrentData = FormatResult(Double.Parse(CurrentData));
            }
            CurrentOperation = Operation.Subtraction;
            CurrentDataLocked = true;
            UnarOperation = false;
        }
        private void InputDiv()
        {
            if (AnsData != "")
            {
                ExecuteOperation();
            }
            else
            {
                CurrentData = FormatResult(Double.Parse(CurrentData));
            }
            CurrentOperation = Operation.Division;
            CurrentDataLocked = true;
            UnarOperation = false;
        }
        private void InputMul()
        {
            if (AnsData != "")
            {
                ExecuteOperation();
            }
            else
            {
                CurrentData = FormatResult(Double.Parse(CurrentData));
            }
            CurrentOperation = Operation.Multiplication;
            CurrentDataLocked = true;
            UnarOperation = false;
        }
        private void InputEq()
        {
            if (CurrentOperation != Operation.None)
            {
                if (AnsData == "")
                {
                    AnsData = CurrentData;
                }
                ExecuteOperation();
            }
            else
            {
                CurrentData = FormatResult(Double.Parse(CurrentData));
            }
            CurrentDataLocked = true;
            UnarOperation = false;
        }
        private void InputOnOff()
        {
            CurrentData = "0";
            MemoryData = "0";
            AnsData = "";
            CurrentOperation = Operation.None;
            CurrentDataLocked = false;
            UnarOperation = false;
        }
    }
    public enum Operation
    {
        None,
        Addition,
        Subtraction,
        Multiplication,
        Division
    }
}
