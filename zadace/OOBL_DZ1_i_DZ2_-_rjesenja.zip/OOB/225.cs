﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private Display screen;
        private Memory memory;
        private bool errorState;

        #region HelpMethods
        private bool ResultBiggerThanAllowed(double value)
        {
            if (value > Math.Abs(Math.Pow(10, screen.MaxDigits)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private double StringToDouble(string inputValue)
        {
            double result;
            Double.TryParse(inputValue, out result);
            return result;
        }
        private double RoundResult(double value)
        {
            string resultString = value.ToString();
            int allowedLength = screen.MaxDigits;
            if (resultString.Contains(',')) allowedLength++;
            if (resultString.Contains('-')) allowedLength++;
            if (resultString.Length > allowedLength)
            {
                int roundingNumber = resultString.IndexOf(',');
                if (resultString.Contains('-')) roundingNumber--;
                roundingNumber = screen.MaxDigits - roundingNumber;
                return Math.Round(StringToDouble(resultString), roundingNumber);
            }
            else
            {
                return value;
            }
        }
        #endregion

        private void UnaryOperator(char unaryOperator)
        {
            memory.IsLastBinary = false;
            screen.AcceptNewEntry = true;
            double result = StringToDouble(screen.Get());
            try
            {
                switch (unaryOperator)
                {
                    case 'S': result = Math.Sin(result); break;
                    case 'K': result = Math.Cos(result); break;
                    case 'T': result = Math.Tan(result); break;
                    case 'Q': result = Math.Pow(result, 2); break;
                    case 'R': result = Math.Pow(result, 0.5); break;
                    case 'I': result = 1 / result; break;
                }
            }
            catch 
            {
                errorState = true;
            }
            if ((!errorState) && (!ResultBiggerThanAllowed(result)) && (!double.IsNaN(result)))
            {
                result = RoundResult(result);
                screen.SendString(result.ToString());
            }
            else
            {
                errorState = true;
                screen.SetErrorMessage();
            }

        }

        private void BinaryOperator(char binaryOperator)
        {
            screen.AcceptNewEntry = true;
            memory.SelectedBinaryOperator = true;
            if (memory.IsLastBinary)
            {
                memory.LastBinaryOperator = binaryOperator;
            }
            else
            {
                screen.FormatDisplay();
                memory.IsLastBinary = true;
                if (memory.Registers.Count == 0)
                {
                    memory.LastBinaryOperator = binaryOperator;
                    memory.Registers.Add(StringToDouble(screen.Get()));
                }
                else if (memory.Registers.Count == 1)
                {
                    Calculate(memory.Registers[0], StringToDouble(screen.Get()), memory.LastBinaryOperator);
                    memory.Registers.Clear();
                    memory.Registers.Add(StringToDouble(screen.Get()));
                }
                else if (memory.Registers.Count == 2)
                {
                    memory.Registers.Clear();
                    memory.Registers.Add(StringToDouble(screen.Get()));
                }
            }
            memory.LastBinaryOperator = binaryOperator;
                
        }

        private void Calculate(double first, double second, char oper)
        {
            double result = 0;
            try
            {
                switch (oper)
                {
                    case '+': result = first + second; break;
                    case '-': result = first - second; break;
                    case '*': result = first * second; break;
                    case '/': result = first / second; break;
                }
            }
            catch
            {
                errorState = true;
            }
            if ((!errorState) && (!ResultBiggerThanAllowed(result)) && (!double.IsNaN(result)))
            {
                result = RoundResult(result);
                screen.SendString(result.ToString());
            }
            else
            {
                errorState = true;
                screen.SetErrorMessage();
            }
        }

        private void Equals()
        {
            memory.IsLastBinary = false;

            if (memory.SelectedBinaryOperator)
            {
                if (memory.Registers.Count == 2)
                {
                    Calculate(memory.Registers[0], memory.Registers[1], memory.LastBinaryOperator);
                    memory.Registers[0] = (StringToDouble(screen.Get()));
                }
                else
                {
                    memory.Registers.Add(StringToDouble(screen.Get()));
                    Calculate(memory.Registers[0], StringToDouble(screen.Get()), memory.LastBinaryOperator);
                    memory.Registers[0] = (StringToDouble(screen.Get()));
                }
            }
            else
            {
                screen.FormatDisplay();
            }
        }

        public Kalkulator()
        {
            screen = new Display("0", "-E-", 10);
            memory = new Memory();
            errorState = false;
        }

        public void Press(char inPressedDigit)
        {
            if (!errorState)
            {
                switch (inPressedDigit)
                {
                    case 'C': screen.Clear(); break;
                    case 'O': memory.Clear(); screen.Clear(); break;
                    case 'P': memory.Put(screen.Get()); break;
                    case 'G': screen.SendString(memory.Get()); break;
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                    case 'M':
                    case ',': screen.SendChar(inPressedDigit); memory.IsLastBinary = false; break;
                    case 'S': 
                    case 'K': 
                    case 'T': 
                    case 'Q':
                    case 'R':
                    case 'I': UnaryOperator(inPressedDigit); memory.IsLastBinary = false; break;
                    case '+':
                    case '-':
                    case '*':
                    case '/': BinaryOperator(inPressedDigit); break;
                    case '=': Equals(); break;
                }
            }
            else
            {
                    switch (inPressedDigit)
                    {
                        case 'C': screen.Clear(); errorState = false;  break;
                        case 'O': memory.Clear(); screen.Clear(); errorState = false; break;
                    }

             }
            
        }

        public string GetCurrentDisplayState()
        {
            return screen.Get();
        }
    }

    public class Display
    {
        private string _currentDisplayState;
        private string _startDisplayState;
        private string _errorMessage;
        private int _maxDigits;
        private bool _acceptNewEntry;

        public bool AcceptNewEntry
        {
            get { return _acceptNewEntry; }
            set { _acceptNewEntry = value; }
        }

        public int MaxDigits
        {
            get { return _maxDigits; }
            set { _maxDigits = value; }
        }

        public void FormatDisplay()
        {
            if (_currentDisplayState.Contains(','))
            {
                for (int i = _currentDisplayState.Length - 1; i > 0; i--)
                {
                    if (_currentDisplayState[i] == ',')
                    {
                        _currentDisplayState = _currentDisplayState.Substring(0, _currentDisplayState.Length - 1);
                        break;
                    }
                    else if (_currentDisplayState[i] == '0')
                    {
                        _currentDisplayState = _currentDisplayState.Substring(0, _currentDisplayState.Length - 1);
                    }
                    else break;
                }
            }
     
        }  

        private void MinusModifier()
        {
            if (_currentDisplayState != _startDisplayState)
            {
                if (_currentDisplayState[0] != '-')
                {
                    _currentDisplayState = '-' + _currentDisplayState;
                }
                else
                {
                    _currentDisplayState.Remove(0, 1);
                }
            }
        }

        private void DecimalPointModifier(char decimalPointChar)
        {
            if (!_currentDisplayState.Contains(decimalPointChar))
            {
                _currentDisplayState += decimalPointChar;
            }
        }

        private void NumberModifier(char numberChar)
        {
            int allowedLength = _maxDigits;
            if (_currentDisplayState.Contains(',')) allowedLength++;
            if (_currentDisplayState.Contains('-')) allowedLength++;
            if (allowedLength > _currentDisplayState.Length)
            {
                if (_currentDisplayState == _startDisplayState)
                {
                    _currentDisplayState = numberChar.ToString();
                }
                else
                {
                    _currentDisplayState += numberChar;
                }
            }
        }

        public Display(string startDisplayState, string errorMessage, int maxDigits)
        {
            _acceptNewEntry = false;
            _startDisplayState = startDisplayState;
            _currentDisplayState = startDisplayState;
            _errorMessage = errorMessage;
            _maxDigits = maxDigits;
        }

        public void Clear()
        {
            _currentDisplayState = _startDisplayState;
        }

        public string Get()
        {
            FormatDisplay();
            return _currentDisplayState;
        }

        public void SendChar(char inputChar)
        {
            if (_acceptNewEntry)
            {
                if (inputChar != 'M')
                {
                    _currentDisplayState = _startDisplayState;
                }
                _acceptNewEntry = false;
            }
            switch (inputChar)
            {
                case 'M': MinusModifier(); break;
                case ',': DecimalPointModifier(inputChar); break;
                default: NumberModifier(inputChar); break;
            }

        }

        public void SendString(string inputString)
        {
            _currentDisplayState = inputString;
        }

        public void SetErrorMessage()
        {
            _currentDisplayState = _errorMessage;
        }
        
    }

    public class Memory
    {
        private char _lastBinaryOperator;
        private bool _isLastBinary;
        private bool _selectedBinaryOperator;
        private string _storedVariable;
        private List<double> _registers;

        public List<double> Registers
        {
            get { return _registers; }
            set { _registers = value; }
        }

        public bool IsLastBinary
        {
            get { return _isLastBinary; }
            set { _isLastBinary = value; }
        }

        public char LastBinaryOperator
        {
            get { return _lastBinaryOperator; }
            set { _lastBinaryOperator = value; }
        }

        public Memory()
        {
            _registers = new List<double>();
            Clear();
        }


        public bool SelectedBinaryOperator
        {
            get { return _selectedBinaryOperator; }
            set { _selectedBinaryOperator = value; }
        }

        public void Put(string currentDisplay)
        {
            _storedVariable = currentDisplay;
        }
        public string Get()
        {
            return _storedVariable;
        }
        public void Clear()
        {
            _isLastBinary = false;
            _selectedBinaryOperator = false;
            _registers.Clear();
            _storedVariable = "0";
        }


        
    }


}
