﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private string display = "0";
        private string pomocni;
        private double rezFunkcije = 0;
        private string memorija;
        private string[] pomocnaLista = new string[3];
        private double rezultat;
        private double operand1;
        private double operand2;
        private int uzastopniOperand;
        private int predznak;
        private int zastavicaZaNule;
        private int zastavicaZarez;
        private int brojac;
        private int maxZnamenaka = 10;
        private int pokusaj;
        private int brojZnamenaka;
        private int greska;

        public void Press(char inPressedDigit)
        {
            if (char.IsDigit(inPressedDigit))
            {   //ako je pritisnuta znamenka
                if (inPressedDigit.Equals('0') && zastavicaZaNule == 0 && brojac == 0)
                {
                    display = inPressedDigit.ToString(); //kada dolazi vise pocetnih nula                    
                }
                else if (brojac == 0)
                {   //brojac == 0, znaci da je na ekranu 0
                    if (zastavicaZarez == 0)
                    {   //ako prvi znak nije decimalna tocka ni nula
                        zastavicaZaNule = 1;
                        brojac++;
                        display = inPressedDigit.ToString();
                    }
                    else if (zastavicaZarez == 1)
                    {   //ako je vec stavljen ','
                        zastavicaZaNule = 1;
                        brojac++;
                        display = display + inPressedDigit.ToString();
                    }
                }
                else if (brojac > 0 && brojac < maxZnamenaka)
                {   //ogranicenje broja unesenih znamenaka
                    brojac++;
                    display = display + inPressedDigit.ToString();
                }
            }
            else if (inPressedDigit.Equals(',') && zastavicaZarez == 0 && brojac < maxZnamenaka)
            {
                //stavlja ',' sve dok nije na zadnjem mjestu, tj kad iza njega ne stane znamenka
                zastavicaZaNule = 1;
                zastavicaZarez = 1;
                if (brojac != 0)
                {
                    display = display + inPressedDigit.ToString();
                }
                else display = "0" + inPressedDigit.ToString();
            }
            else if (inPressedDigit.Equals('C'))
            {   //resetira ekran
                display = "0";
                Refresh();
            }
            else if (inPressedDigit.Equals('O'))
            {   //resetira cijeli sustav
                display = "0";
                pomocni = null;
                memorija = null;
                pomocnaLista[0] = null;
                pomocnaLista[1] = null;
                pomocnaLista[2] = null;
                rezultat = 0;
                operand1 = 0;
                operand2 = 0;
                Refresh();
            }
            else if (inPressedDigit.Equals('M'))
            {
                pomocni = "";
                if (predznak == 0)
                {   //ako je predznak bio +
                    predznak = 1;
                    display = "-" + display;
                }
                else if (predznak == 1)
                {   //ako je predznak bio -
                    foreach (char c in GetCurrentDisplayState())
                    {
                        if (char.IsDigit(c) || c.Equals(','))
                        {   //preskace '-' na pocetku
                            pomocni = pomocni + c.ToString();
                        }
                    }
                    display = pomocni;
                    predznak = 0;
                }
            }
            else if (inPressedDigit.Equals('P'))
            {
                memorija = GetCurrentDisplayState();
            }
            else if (inPressedDigit.Equals('G'))
            {
                Press('C');
                foreach (char c in memorija)
                {
                    if (c.Equals('-'))
                    {   //oznaka da je predznak bio negativan
                        predznak = 2;

                    }
                    else
                    {
                        Press(c);
                    }
                }
                if (predznak == 2)
                {   //ako predznak treba biti negativan, stavimo da je pozitivan i pritisnemo M koji ga na ekranu izmjeni
                    predznak = 0;
                    Press('M');
                }
            }
            else if (inPressedDigit.Equals('S'))
            {
                rezFunkcije = Math.Sin(Convert.ToDouble(GetCurrentDisplayState()));
                rezFunkcije = Math.Round(rezFunkcije, 9); //sinus je od -1 do 1, tako da uvijek ima mjesta za 9 decimala
                Refresh();
                IspisiNaEkran(rezFunkcije.ToString());
                Refresh();
            }
            else if (inPressedDigit.Equals('K'))
            {
                rezFunkcije = Math.Cos(Convert.ToDouble(GetCurrentDisplayState()));
                rezFunkcije = Math.Round(rezFunkcije, 9);
                Refresh();
                IspisiNaEkran(rezFunkcije.ToString());
                Refresh();
            }
            else if (inPressedDigit.Equals('I'))
            {
                if (!GetCurrentDisplayState().Equals("0"))
                {
                    rezFunkcije = Math.Pow(Convert.ToDouble(GetCurrentDisplayState()), -1);
                    rezFunkcije = Math.Round(rezFunkcije, 9); // 1/n je uvijek manje od 1 pa je slobodno jos 9 decimala
                    Refresh();
                    IspisiNaEkran(rezFunkcije.ToString());
                }
                else
                {
                    Press('E');
                }
                Refresh();
            }
            else if (inPressedDigit.Equals('T'))
            {
                rezFunkcije = Math.Tan(Convert.ToDouble(GetCurrentDisplayState()));
                rezFunkcije = Math.Round(rezFunkcije, 9);
                Refresh();
                IspisiNaEkran(rezFunkcije.ToString());
                Refresh();
            }
            else if (inPressedDigit.Equals('R'))
            {   
                rezFunkcije = Math.Pow(Convert.ToDouble(GetCurrentDisplayState()), 0.5);
                if (double.IsNaN(rezFunkcije))
                {
                    Press('E');
                }
                else
                {
                    rezFunkcije = Math.Round(rezFunkcije, maxZnamenaka - brojiZnamenke(rezFunkcije));
                    Refresh();
                    IspisiNaEkran(rezFunkcije.ToString());
                    Refresh();
                }
            }
            else if (inPressedDigit.Equals('Q'))
            {
                rezFunkcije = Math.Pow(Convert.ToDouble(GetCurrentDisplayState()), 2);
                rezFunkcije = Math.Round(rezFunkcije, maxZnamenaka - brojiZnamenke(rezFunkcije));
                Refresh();
                IspisiNaEkran(rezFunkcije.ToString());
                Refresh();
            }
            else if (inPressedDigit.Equals('E'))
            {
                display = "-E-";
                Refresh();
            }
            else if (inPressedDigit.Equals('+'))
            {
                Refresh();
                uzastopniOperand++;
                if (pokusaj == 1)
                {   //operacija je u pripremi, cekao se novi znak
                    Izracunaj();
                }
                pomocnaLista[1] = "+";
                pomocnaLista[0] = GetCurrentDisplayState();
                if (pomocnaLista[0].Equals("-E-"))
                {
                    pomocnaLista[0] = "0";
                    greska = 1;
                }
                if (Convert.ToDouble(pomocnaLista[0]) == ((int)Convert.ToDouble(pomocnaLista[0])))
                {   //u slucaju da je na ekranu nesto tipa 2,0 --> zaokruzi na 2
                    pomocnaLista[0] = ((int)(Convert.ToDouble(pomocnaLista[0]))).ToString();
                    if (greska == 0)
                    {
                        display = pomocnaLista[0];
                    }
                    else if (greska == 1)
                    {
                        display = "-E-";
                    }
                }
                Refresh();
            }
            else if (inPressedDigit.Equals('-'))
            {
                Refresh();
                uzastopniOperand++;
                if (pokusaj == 1)
                {
                    Izracunaj();
                }
                pomocnaLista[1] = "-";
                pomocnaLista[0] = GetCurrentDisplayState();
                if (pomocnaLista[0].Equals("-E-"))
                {
                    pomocnaLista[0] = "0";
                    greska = 1;
                }
                if (Convert.ToDouble(pomocnaLista[0]) == ((int)Convert.ToDouble(pomocnaLista[0])))
                {   //u slucaju da je na ekranu nesto tipa 2,0 --> zaokruzi na 2
                    pomocnaLista[0] = ((int)(Convert.ToDouble(pomocnaLista[0]))).ToString();
                    if (greska == 0)
                    {
                        display = pomocnaLista[0];
                    }
                    else if (greska == 1)
                    {
                        display = "-E-";
                    }
                }
                Refresh();
            }
            else if (inPressedDigit.Equals('*'))
            {
                Refresh();
                uzastopniOperand++;
                if (pokusaj == 1)
                {
                    Izracunaj();
                }
                pomocnaLista[1] = "*";
                pomocnaLista[0] = GetCurrentDisplayState();
                if (pomocnaLista[0].Equals("-E-"))
                {
                    pomocnaLista[0] = "0";
                    greska = 1;
                }
                if (Convert.ToDouble(pomocnaLista[0]) == ((int)Convert.ToDouble(pomocnaLista[0])))
                {   //u slucaju da je na ekranu nesto tipa 2,0 --> zaokruzi na 2
                    pomocnaLista[0] = ((int)(Convert.ToDouble(pomocnaLista[0]))).ToString();
                    if (greska == 0)
                    {
                        display = pomocnaLista[0];
                    }
                    else if (greska == 1)
                    {
                        display = "-E-";
                    }
                }
                Refresh();
            }
            else if (inPressedDigit.Equals('/'))
            {
                Refresh();
                uzastopniOperand++;
                if (pokusaj == 1)
                {
                    Izracunaj();
                }
                pomocnaLista[1] = "/";
                pomocnaLista[0] = GetCurrentDisplayState();
                if (pomocnaLista[0].Equals("-E-"))
                {
                    pomocnaLista[0] = "0";
                    greska = 1;
                }
                if (Convert.ToDouble(pomocnaLista[0]) == ((int)Convert.ToDouble(pomocnaLista[0])))
                {   //u slucaju da je na ekranu nesto tipa 2,0 --> zaokruzi na 2
                    pomocnaLista[0] = ((int)(Convert.ToDouble(pomocnaLista[0]))).ToString();
                    if (greska == 0)
                    {
                        display = pomocnaLista[0];
                    }
                    else if (greska == 1)
                    {
                        display = "-E-";
                    }
                }
                Refresh();
            }
            else if (pomocnaLista[1] == null && inPressedDigit.Equals('='))
            {
                if (Convert.ToDouble(GetCurrentDisplayState()) == ((int)Convert.ToDouble(GetCurrentDisplayState())))
                {   //u slucaju da je na ekranu nesto tipa 2,0 --> zaokruzi na 2
                    display = ((int)(Convert.ToDouble(GetCurrentDisplayState()))).ToString();
                }
                pomocnaLista[1] = inPressedDigit.ToString();
            }
            
            //ako je zadan operand
            if (pomocnaLista[1] != null && inPressedDigit.Equals('='))
            {
                if (inPressedDigit.Equals('='))
                {   //ako je pritisnuto '='
                    pomocnaLista[2] = GetCurrentDisplayState();
                    if (pomocnaLista[2].Equals("-E-"))
                    {
                        pomocnaLista[2] = "0";
                    }
                    operand1 = Convert.ToDouble(pomocnaLista[0]);
                    operand2 = Convert.ToDouble(pomocnaLista[2]);
                    if (pomocnaLista[1].Equals("+"))
                    {   //ako je operand bio '+'
                        pomocnaLista[1] = null;
                        rezultat = operand1 + operand2;
                        if (rezultat < 10000000000)
                        {
                            rezultat = Math.Round(rezultat, 9);
                            Refresh();
                            IspisiNaEkran(rezultat.ToString());
                        }
                        else
                        {
                            Press('E');
                        }
                        pokusaj = 0;
                        Refresh();
                    }
                    else if (pomocnaLista[1].Equals("-"))
                    {   //ako je operand bio '-'
                        pomocnaLista[1] = null;
                        rezultat = operand1 - operand2;
                        Refresh();
                        IspisiNaEkran(rezultat.ToString());
                        Refresh();
                    }
                    else if (pomocnaLista[1].Equals("*"))
                    {   //ako je operand bio '*'
                        pomocnaLista[1] = null;
                        rezultat = operand1 * operand2;
                        if (rezultat < 10000000000)
                        {
                            rezultat = Math.Round(rezultat, 9);
                            Refresh();
                            IspisiNaEkran(rezultat.ToString());
                        }
                        else
                        {
                            Press('E');
                        }
                        Refresh();
                    }

                    else if (pomocnaLista[1].Equals("/"))
                    {
                        pomocnaLista[1] = null;
                        if (operand2 != 0)
                        {   //zabranjeno je dijeljenje s 0
                            rezultat = operand1 / operand2;
                            if (rezultat < 10000000000)
                            {
                                rezultat = Math.Round(rezultat, 9);
                                Refresh();
                                IspisiNaEkran(rezultat.ToString());
                            }
                            else
                            {
                                Press('E');
                            }                            
                        }
                        else
                        {
                            Press('E');
                        }
                        Refresh();
                    }
                }
            }
            else if(pomocnaLista[1] != null && char.IsDigit(inPressedDigit))
            {
                pomocnaLista[2] = GetCurrentDisplayState();
                pokusaj = 1;
            }            
        }        

        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        private void Refresh()
        {
            brojac = 0;
            zastavicaZaNule = 0;
            zastavicaZarez = 0;
            predznak = 0;
        }

        private void IspisiNaEkran(string s)
        {
            foreach (char c in s)
            {
                if (c.Equals('-'))
                {   //oznaka da je predznak bio negativan
                    predznak = 2;

                }
                else
                {
                    Press(c);
                }
            }
            if (predznak == 2)
            {   //ako predznak treba biti negativan, stavimo da je pozitivan i pritisnemo M koji ga na ekranu izmjeni
                predznak = 0;
                Press('M');
            }
        }

        private void Izracunaj()
        {
            pokusaj = 0;
            uzastopniOperand = 0;
            pomocnaLista[2] = GetCurrentDisplayState();
            if (pomocnaLista[2].Equals("-E-"))
            {
                pomocnaLista[2] = "0";
            }            
            operand1 = Convert.ToDouble(pomocnaLista[0]);
            operand2 = Convert.ToDouble(pomocnaLista[2]);
            if (pomocnaLista[1].Equals("+"))
            {   //ako je operand bio '+'

                rezultat = operand1 + operand2;
                pomocnaLista[1] = null;
                if (rezultat < 10000000000)
                {
                    rezultat = Math.Round(rezultat, maxZnamenaka - brojiZnamenke(rezultat));
                    Refresh();
                    IspisiNaEkran(rezultat.ToString());
                }
                else
                {
                    Press('E');
                }
                Refresh();
            }
            else if (pomocnaLista[1].Equals("-"))
            {   //ako je operand bio '-'
                pomocnaLista[1] = null;
                rezultat = operand1 - operand2;
                Refresh();
                IspisiNaEkran(rezultat.ToString());
                Refresh();
            }
            else if (pomocnaLista[1].Equals("*"))
            {   //ako je operand bio '*'
                pomocnaLista[1] = null;
                rezultat = operand1 * operand2;
                if (rezultat < 10000000000)
                {
                    rezultat = Math.Round(rezultat, maxZnamenaka - brojiZnamenke(rezultat));
                    Refresh();
                    IspisiNaEkran(rezultat.ToString());
                }
                else
                {
                    Press('E');
                }
                Refresh();                
            }
            else if (pomocnaLista[1].Equals("/"))
            {   //ako je operand bio '/'
                pomocnaLista[1] = null;
                rezultat = operand1 / operand2;
                if (rezultat < 10000000000)
                {
                    rezultat = Math.Round(rezultat, maxZnamenaka - brojiZnamenke(rezultat));
                    Refresh();
                    IspisiNaEkran(rezultat.ToString());
                }
                else
                {
                    Press('E');
                }
                Refresh();                
            }
        }
        private int brojiZnamenke(double d)
        {   //broji znamenke prije decimale
            string s = d.ToString();
            foreach (char c in s)
            {                
                if (c.Equals(','))
                {
                    return brojZnamenaka;
                }
                brojZnamenaka++;
            }
            return brojZnamenaka;
        }
    }
}
