﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class MojKalkulator : ICalculator
    {
        private const int DISPLAYSIZE = 12;
        private const int NUMBEROFDIGITSATDISPLAY = 10;
        private const double MAXDISPLAYNUMBER = 9999999999;
        private const double MINDISPLAYNUMBER = 0.000000001;
        private const double ERRORRESULT = 9999999999999;
        private enum Operation {add, sub, mul, div, non};
        private Operation nextOperation = Operation.non;
        private Operation lastOperation = Operation.non;
        System.Globalization.NumberFormatInfo info = new System.Globalization.NumberFormatInfo();


        String display;
        double operand1 = 0;
        double operand2 = 0;
        String buffer="";
        String memory = "0";
        Char lastPressedDigit;
        Char penultimateDigit;


        public MojKalkulator()
        {
            this.display = "0";
            info.NumberDecimalSeparator = ",";
        }

        
       public  void Press(char inPressedDigit)
        {
           lastPressedSign(inPressedDigit);            // Spremanje zadnjeg pritisnutog znaka
           if (OffButtonCheck(inPressedDigit)) return; // O
           if (clearCheck(inPressedDigit)) return;     // C 
           if (firstCommaCheck(inPressedDigit)) return;// Prvi znak ','
           if (signCheck(inPressedDigit)) return;      // +/- 
           if (memoryMenagment(inPressedDigit)) return;// P/G
           if (operation(inPressedDigit)) return;      // +,-,*,/,=,S,K,T,Q,R,I

           if (displayIs0() && (inPressedDigit == '0'))
            {
                display = "0";
            }
            else
            {  
              if(isCharForDisplay(inPressedDigit))     // 0,1,2,3,4,5,6,7,8,9,',','-'
              {
                buffer = buffer + inPressedDigit;
              }
              buffer=displayCheck(buffer);             // Duzina stringa
              
                display = buffer;
            }
        }

       public string GetCurrentDisplayState()
        {
           decimalCheck();                            // Odbaci nulu na okruglim brojevima
           return displayCheck(this.display);
        }

       private bool displayIs0()
       {
           if (this.display=="0")
           {
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool isCharForDisplay(char inPressedDigit)
       {
           if (Char.IsNumber(inPressedDigit) || inPressedDigit == ',')
           {
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool toManyDigits(String buffer)
       {
           int numberOfDigits=0;
           foreach (Char element in buffer)
           {
               if(Char.IsNumber(element))
               {
                   numberOfDigits++;
               }
           }
           if (numberOfDigits > NUMBEROFDIGITSATDISPLAY)
           {
               return true;
           }
           else
           {
               return false;
           }
       }

       private String displayCheck(String buffer)
       {
           if (toManyDigits(buffer))
           {
               int minusFirst;
               if (buffer[0] == '-') minusFirst = 0; else minusFirst = 1;  // Ako je broj negativan minusFirst=0, inace 1
               bool commaFound = false;
               int i;
               for ( i = 0; i < DISPLAYSIZE; i++)
               {
                   try
                   {
                       if (buffer[i] == ',')                                   // Na kojem mjestu se nalazi ','
                       {
                           commaFound = true;
                           break;
                       }
                   }
                   catch (IndexOutOfRangeException e)
                   {
                       commaFound = false;
                   }
               }                                                           
              
               String tempBuffer="";
               if (commaFound)
               {
                   double numericBuffer = Convert.ToDouble(buffer, info);
                   numericBuffer = Math.Round(numericBuffer, (NUMBEROFDIGITSATDISPLAY - (i + minusFirst) + 1)); // Broj decimalnih mjesta --> MaxBrojMjesta(10) - (MjestoZareza + ImaIliNemaMinusa) + 1
                   tempBuffer = Convert.ToString(numericBuffer, info);
               }
               else
               {
                   int numberOfDigits = 0;                               // Ukoliko nema ',' ignoriraj sve doslo poslije 10te znamenke
                   foreach (Char element in buffer)
                   {
                       if (Char.IsNumber(element))
                       {
                           if (numberOfDigits < NUMBEROFDIGITSATDISPLAY)
                           {
                               tempBuffer = tempBuffer + element;
                               numberOfDigits++;
                           }
                       }
                       else
                       {
                           tempBuffer = tempBuffer + element;
                       }
                   }
               }
               return tempBuffer;
           }
           else
           {
               return buffer;
           }
           
       }

       private bool OffButtonCheck(Char inPressedDigit)
       {
           if (inPressedDigit == 'O')
           {
               this.display = "0";
               this.buffer = "";
               this.memory = "0";
               this.operand1 = 0;
               this.operand2 = 0;
               this.nextOperation = Operation.non;
               this.lastPressedDigit = 'O';
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool firstCommaCheck(Char inPressedDigit)
       {
           if ((this.buffer == "" || this.buffer == "0" || this.display=="") && inPressedDigit == ',')
           {
               this.buffer = "0,";
               this.display = this.buffer;
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool signCheck(Char inPressedDigit)
       {
           if (inPressedDigit == 'M' && buffer != "" && buffer !="0") // Nula nema predznaka
           {
               if (buffer[0] != '-')
               {
                   this.buffer = insertMinusOnFirstPlace(this.buffer); // Promijeni predznak
                   this.buffer = displayCheck(buffer);
                   this.display = this.buffer;
                   return true;
               }
               else
               {
                   this.buffer = removeMinusFromFirstPlace(this.buffer); // Promijeni predznak
                   this.buffer = displayCheck(buffer);
                   this.display = this.buffer;
                   return true;
               }
           }
           else
           {
               return false;
           }
       }

       private String insertMinusOnFirstPlace(String buffer)
       {
           String tempBuffer="-";
           foreach (Char element in buffer)
           {
               tempBuffer = tempBuffer + element;
           }
           return tempBuffer;
       }

       private String removeMinusFromFirstPlace(String buffer)
       {
           if (buffer[0] == '-')
           {
               String tempBuffer = "";
               for (int i = 0; i < buffer.Length; i++)
               {
                   tempBuffer += buffer[i + 1];
               }
               return tempBuffer;
           }
           else
           {
               return buffer;
           }
       }

       private bool memoryMenagment(Char inPressedDigit)
       {
           if (inPressedDigit == 'P' && this.display!="") ///Ukoliko ima nesto na ekranu i pritisnut je P
           {
               this.memory = displayCheck(this.display);
               return true;
           }
           else if (inPressedDigit == 'G')
           {
               this.buffer = this.memory;
               this.display = this.memory;
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool operation(Char inPressedDigit)
       {
           if (inPressedDigit == 'S')
           {
               double result = Convert.ToDouble(this.display, info);
               result = Math.Sin(result);
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);              // Upisi rezultat u display, provjeri duzinu stringa, isprazni buffer
               return true;                                               // Javi da je metoda obavila sve  i da ne treba mijenjati display i buffer
           }
           else if (inPressedDigit == 'K')
           {
               double result = Convert.ToDouble(this.display, info);
               result = Math.Cos(result);
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);
               return true;
           }
           else if (inPressedDigit == 'T')
           {
               double result = Convert.ToDouble(this.display, info);
               result = Math.Tan(result);
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);
               return true;
           }
           else if (inPressedDigit == '+')
           {
               if (operationChanged(inPressedDigit))return true;  // Nizanje operacija 
               if (Equal(inPressedDigit)) return true;            // Situacija bez drugog operanda : Broj + =
               operand1 = Convert.ToDouble(this.display, info);
               setOperaton(inPressedDigit);
               this.buffer = "";
               return true;
           }
           else if (inPressedDigit == '-')
           {
               if (operationChanged(inPressedDigit)) return true;
               if (Equal(inPressedDigit)) return true;
               operand1 = Convert.ToDouble(this.display,info);
               setOperaton(inPressedDigit);
               this.buffer = "";
               return true;
           }
           else if (inPressedDigit == '*')
           {
               if (operationChanged(inPressedDigit)) return true;
               if (Equal(inPressedDigit)) return true;
               operand1 = Convert.ToDouble(this.display,info);
               setOperaton(inPressedDigit);
               this.buffer = "";
               return true;
           }
           else if (inPressedDigit == '/')
           {
               if (operationChanged(inPressedDigit)) return true;
               if (Equal(inPressedDigit)) return true;
               operand1 = Convert.ToDouble(this.display,info);
               setOperaton(inPressedDigit);
               this.buffer = "";
               return true;
           }
           else if (inPressedDigit == 'Q')
           {
               double temp = Convert.ToDouble(this.display,info);
               double result = temp * temp;
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);

               return true;
           }
           else if (inPressedDigit == 'R')
           {
               double temp = Convert.ToDouble(this.display,info);
               double result;
               if (temp < 0)                                        // Korijen negativnog broja
               {
                   result = ERRORRESULT;                            // Broj izvan dopustene granice
               }
               else
               {
                   result = Math.Sqrt(temp);
               }
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);

               return true;

           }
           else if (inPressedDigit == 'I')
           {
               double temp = Convert.ToDouble(this.display,info);
               double result = 0;
               try
               {
                   result = 1 / temp;
               }
               catch (DivideByZeroException)
               {
                   result = ERRORRESULT;
               }
               if (rangeCheck(result)) return true;
               houseworkForOperationsWithOneOperand(result);

               return true;
           }

           else if (inPressedDigit == '=')
           {
               if (penultimateDigit == '=')
               {
                   this.nextOperation = this.lastOperation; // Ukoliko nižemo znak '=' 
               }
               
               if (nextOperation != Operation.non) // Ukoliko postoji zadana operacija
               {
                   
                   
                       if (isOperation(this.penultimateDigit)) //Znak prije '=' je bio operacija tako da je situacija : Broj + =
                       {
                           operand2 = operand1;
                       }
                       else if (this.penultimateDigit == '=')
                       {
                         // Do nothing
                       }
                       else
                       {
                           operand2 = Convert.ToDouble(this.display,info);
                       }
                       double result = doOperation();
                       if (rangeCheck(result)) return true;
                       operand1 = result;
                       this.buffer = Convert.ToString(result,info);
                       this.buffer = displayCheck(this.buffer);
                       this.display = this.buffer;
                       this.buffer = "";
                       this.lastOperation = this.nextOperation;
                       this.nextOperation = Operation.non;

                       return true;
                   
               }
               else
               {
                   return true;
               }
           }
           else
           {
               return false;
           }
       }

       private double doOperation()
       {
           switch (nextOperation)
           {
               case Operation.sub:
                   return operand1 - operand2;
               case Operation.mul:
                   return operand1 * operand2;
               case Operation.add:
                   return operand1 + operand2;
               case Operation.div:
                   double result = 0;
                   try
                   {
                       result = operand1 / operand2;
                   }
                   catch (DivideByZeroException)
                   {
                       result = ERRORRESULT;
                   }
                   return result;
           }
           return 0;
       }

       private bool rangeCheck(double result)
       {
           if ((result != 0) && ((Math.Abs(result) > MAXDISPLAYNUMBER) || (Math.Abs(result) < MINDISPLAYNUMBER))) // Rezultati izvan dopuštenog intervala --> ERROR
           {
               this.display = "-E-";
               this.buffer = "";
               this.nextOperation = Operation.non;
               this.operand1 = 0;
               this.operand2 = 0;
               return true;
           }
           else
           {
               return false;                        // Sve ok, metoda nije nasla nista izvan dopustenih vrijednosti
           }
       }
       private void decimalCheck()
       {
           if ((this.lastPressedDigit == '=' || isCharForDisplay(this.lastPressedDigit))&& this.display!="0,") // Treba li zaokruzit na integer
           {
               try
               {
                   double doubleValue = Convert.ToDouble(this.display,info);
                   int intValue = Convert.ToInt32(doubleValue,info);
                   if (doubleValue == intValue)                             //Jesu li integer i double vrijednost broja jednaki
                   {
                       this.display = displayCheck(Convert.ToString(intValue,info)); // Ukoliko jesu zaokruzi na integer : Broj,0 ---> Broj
                   }
               }
               catch (FormatException f)
               {
                   return;
               }
           }
       }

       private void lastPressedSign(Char inPressedDigit)
       {
           this.penultimateDigit = lastPressedDigit;
           this.lastPressedDigit = inPressedDigit;
       }

       private bool isOperation(Char pressedChar)
       {
           if (pressedChar == '+' || pressedChar == '-' || pressedChar == '*' || pressedChar == '/')
           {
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool multiplyOperationCheck(Char inPressedDigit)
       {
           if (isOperation(inPressedDigit) && isOperation(this.penultimateDigit)) // Jesu li zadnja dva unosa su bile operacije
           {
               return true;
           }
           else
           {
               return false;
           }
       }

       private void setOperaton(Char inPressedDigit)
       {
           switch (inPressedDigit)
           {
               case '+':
                   this.nextOperation = Operation.add;
                   return;
               case '-':
                   this.nextOperation = Operation.sub;
                   return;
               case '*':
                   this.nextOperation = Operation.mul;
                   return;
               case '/':
                   this.nextOperation = Operation.div;
                   return;
               
           }
       }

       private bool Equal(Char inPressedDigit) // Pritisnuto '=' nakon operacije
       {
           if (nextOperation != Operation.non) // Poznata je operacija koju radimo
           {
               operand2 = Convert.ToDouble(this.display,info);
               double result = doOperation();
               operand1 = result;
               setOperaton(inPressedDigit);
               this.buffer = "";
               this.display = displayCheck(Convert.ToString(result,info));
               return true;
           }
           else
           {
               return false;
           }
       }

       private bool clearCheck(Char inPressedDigit)
       {
           if (inPressedDigit == 'C')
           {
               this.buffer = "";
               this.display = "";
               return true;
           }
           else
           {
               return false;
           }
       }

       private void houseworkForOperationsWithOneOperand(double result)
       {
           this.buffer = Convert.ToString(result,info);
           this.buffer = displayCheck(this.buffer);
           this.display = this.buffer;
           this.buffer = "";
       }

       private bool operationChanged(Char inPressedDigit)
       {
           if (multiplyOperationCheck(inPressedDigit)) // Provjeri da li zadnji unos takoder bio operacija
           {
               setOperaton(inPressedDigit);
               return true;
           }
           else
           {
               return false;
           }
       }

    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new MojKalkulator();

        }
    }

    
}
