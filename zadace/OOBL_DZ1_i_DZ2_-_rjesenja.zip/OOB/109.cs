﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {                 
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private StockHandler _stockHandler;
         private IndexHandler _indexHandler;
         private PortfolioHandler _portfolioHandler;

         public StockExchange()
         {
             _stockHandler = new StockHandler();
             _indexHandler = new IndexHandler();
             _portfolioHandler = new PortfolioHandler();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _stockHandler.AddStock(new Stock(inStockName, inNumberOfShares, new Price(inTimeStamp, inInitialPrice)));
         }

         public void DelistStock(string inStockName)
         {
             _portfolioHandler.RemoveStockFromPortfolios(inStockName);
             _indexHandler.RemoveStockFromIndexes(inStockName);
             _stockHandler.DelistStock(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             return _stockHandler.StockExists(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stockHandler.NumberOfStocks();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             _stockHandler.SetStockPrice(inStockName, inIimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return Math.Round(_stockHandler.GetStockPrice(inStockName, inTimeStamp),3);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return Math.Round(_stockHandler.GetInitialStockPrice(inStockName),3);
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return Math.Round(_stockHandler.GetLastStockPrice(inStockName),3);
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             _indexHandler.AddIndex(new Index(inIndexName, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Stock stock = _stockHandler.GetStock(inStockName);
             _indexHandler.AddStockToIndex(inIndexName,stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
            _indexHandler.RemoveStockFromIndex(inIndexName,inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _indexHandler.IsStockPartOfIndex(inIndexName, inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return Math.Round(_indexHandler.GetIndexValue(inIndexName, inTimeStamp), 3);
         }

         public bool IndexExists(string inIndexName)
         {
             return _indexHandler.IndexExists(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _indexHandler.NumberOfIndices();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _indexHandler.GetIndex(inIndexName).IndexStockHandler.NumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             _portfolioHandler.AddPortfolio(inPortfolioID);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
          
             Stock stock = _stockHandler.GetStock(inStockName);
       
             if (stock.Quantity < _portfolioHandler.GetStockSum(inStockName) + numberOfShares)
             {
                 throw new StockExchangeException("prevelika kolicina dionica");
             }
             _portfolioHandler.AddStockToPortfolio(inPortfolioID, new Stock(stock.Name, numberOfShares, stock.StockPrices));
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             _portfolioHandler.RemoveStockFromPortfolio(inPortfolioID, inStockName,numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             _portfolioHandler.RemoveStockFromPortfolio(inPortfolioID,inStockName);
         }

         public int NumberOfPortfolios()
         {
             return _portfolioHandler.PortfolioCount();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return _portfolioHandler.NumberOfStocksInPortfolio(inPortfolioID);
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolioHandler.PortfolioExists(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return _portfolioHandler.IsStockPartOfPortfolio(inPortfolioID, inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return _portfolioHandler.NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return Math.Round(_portfolioHandler.GetPortfolioValue(inPortfolioID, timeStamp),3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return Math.Round(_portfolioHandler.GetPortfolioPercentChangeInValueForMonth(inPortfolioID, Year, Month),3);
         }
     }

     public class Index
     {

         private string _name;
         private IndexTypes _indexTypeValue;
         private IndexStockHandler _indexStockHandler;

         public Index(string name, IndexTypes indexType)
         {
             if (name == "")
             {
                 throw new StockExchangeException("Ime ne moze biti prazan niz");
             }
             _name = name;
             if (indexType != IndexTypes.AVERAGE && indexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("tip indeksa ne postoji");
             }
             _indexTypeValue = indexType;
             _indexStockHandler = new IndexStockHandler();
         }

         public string Name
         {
             get { return _name; }
             set { _name = value; }
         }

         public IndexTypes IndexTypeValue
         {
             get { return _indexTypeValue; }
             set { _indexTypeValue = value; }
         }

         public IndexStockHandler IndexStockHandler
         {
             get { return _indexStockHandler; }
             set { _indexStockHandler = value; }
         }
     }

     public class IndexHandler
     {
         private List<Index> _indexes;

         public IndexHandler()
         {
             _indexes = new List<Index>();
         }

         public void AddIndex(Index index)
         {
             if (_indexes.Exists(s => s.Name.Equals(index.Name, StringComparison.CurrentCultureIgnoreCase)))
             {
                 throw new StockExchangeException("index sa istim imenom postoji");
             }
             _indexes.Add(index);
         }

         public int NumberOfIndices()
         {
             return _indexes.Count;
         }

         public bool IndexExists(string indexName)
         {
             return _indexes.Exists(s => s.Name.Equals(indexName, StringComparison.CurrentCultureIgnoreCase));
         }

         public Index GetIndex(string indexName)
         {
             if (!IndexExists(indexName))
             {
                 throw new StockExchangeException("Index ne postoji");
             }
             return _indexes.Select(s => s).Where(s => s.Name.Equals(indexName, StringComparison.CurrentCultureIgnoreCase)).ToList().First();
         }

         public Decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = GetIndex(inIndexName);
             if (index.IndexTypeValue == IndexTypes.AVERAGE)
             {
                 return index.IndexStockHandler.Stocks.Average(s => s.StockPrices.GetPrice(inTimeStamp).PriceValue);
             }
             if (index.IndexTypeValue == IndexTypes.WEIGHTED)
             {
                 Decimal sum =
                     index.IndexStockHandler.Stocks.Sum(s => s.Quantity * s.StockPrices.GetPrice(inTimeStamp).PriceValue);
                 return index.IndexStockHandler.Stocks.Sum(s => s.Quantity *
                     s.StockPrices.GetPrice(inTimeStamp).PriceValue *
                     s.StockPrices.GetPrice(inTimeStamp).PriceValue / sum);
             }
             return 0;
         }

         public void AddStockToIndex(string indexName, Stock stock)
         {
             Index index = GetIndex(indexName);
             index.IndexStockHandler.AddStock(stock);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             index.IndexStockHandler.DelistStock(inStockName);
         }

         public void RemoveStockFromIndexes(string inStockName)
         {
             foreach (Index index in Indexes)
             {
                 if (index.IndexStockHandler.StockExists(inStockName))
                 {
                     index.IndexStockHandler.DelistStock(inStockName);
                 }
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndex(inIndexName).IndexStockHandler.StockExists(inStockName);
         }

         public List<Index> Indexes
         {
             get { return _indexes; }
             set { _indexes = value; }
         }
     }

     public class IndexStockHandler : StockHandler
     {

     }

     public class Portfolio
     {
         private string _portfolioID;
         private PortfolioStockHandler _portfolioStockHandler;

         public Portfolio(string portfolioID)
         {
             if (portfolioID == "")
             {
                 throw new StockExchangeException("Ime je prazno");
             }
             PortfolioId = portfolioID;
             PortfolioStockHandler = new PortfolioStockHandler();
         }

         public Portfolio()
         {
             PortfolioStockHandler = new PortfolioStockHandler();
         }

         public string PortfolioId
         {
             get { return _portfolioID; }
             set { _portfolioID = value; }
         }

         public PortfolioStockHandler PortfolioStockHandler
         {
             get { return _portfolioStockHandler; }
             set { _portfolioStockHandler = value; }
         }
     }

     public class PortfolioHandler
     {
         private List<Portfolio> _portfolios;

         public PortfolioHandler()
         {
             _portfolios = new List<Portfolio>();
         }

         public void AddPortfolio(string id)
         {
             if (PortfolioExists(id))
             {
                 throw new StockExchangeException("Vec postoji portfolio");
             }
             _portfolios.Add(new Portfolio(id));
         }

         public bool PortfolioExists(string id)
         {
             return _portfolios.Exists(p => p.PortfolioId.Equals(id));
         }

         public int PortfolioCount()
         {
             return _portfolios.Count;
         }

         public Portfolio GetPortfolio(string id)
         {
             if (!PortfolioExists(id))
             {
                 throw new StockExchangeException("portfolio ne postoji");
             }
             return _portfolios.Select(s => s).Where(s => s.PortfolioId.Equals(id)).ToList().First();
         }

         public int NumberOfStocksInPortfolio(string id)
         {
             return GetPortfolio(id).PortfolioStockHandler.NumberOfStocks();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return (int)GetPortfolio(inPortfolioID).PortfolioStockHandler.GetStock(inStockName).Quantity;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             return GetPortfolio(inPortfolioID).PortfolioStockHandler.StockExists(inStockName);
         }

         public void AddStockToPortfolio(string inPortfolioID, Stock stock)
         {
             GetPortfolio(inPortfolioID).PortfolioStockHandler.AddStock(stock);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             GetPortfolio(inPortfolioID).PortfolioStockHandler.RemoveNumberOfShares(inStockName, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             GetPortfolio(inPortfolioID).PortfolioStockHandler.DelistStock(inStockName);
         }

         public void RemoveStockFromPortfolios(string stockName)
         {
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.PortfolioStockHandler.StockExists(stockName))
                 {
                     portfolio.PortfolioStockHandler.DelistStock(stockName);
                 }
             }
         }

         public long GetStockSum(string stockName)
         {
             long sum = 0;
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.PortfolioStockHandler.StockExists(stockName))
                 {
                     sum += portfolio.PortfolioStockHandler.GetStock(stockName).Quantity;
                 }
             }
             return sum;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return GetPortfolio(inPortfolioID).PortfolioStockHandler.TotalValueOfShares(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             int daysInMonth = DateTime.DaysInMonth(Year, Month);
             DateTime firstDayOfMonth = new DateTime(Year, Month, 1, 0, 0, 0);
             DateTime lastDayOfMonth = new DateTime(Year, Month, daysInMonth, 23, 59, 59, 999);
             decimal valueOfPortfolioInBeginning = GetPortfolioValue(inPortfolioID, firstDayOfMonth);
             decimal valueAtEnd = GetPortfolioValue(inPortfolioID, lastDayOfMonth);
             return (valueAtEnd / valueOfPortfolioInBeginning) * 100;
         }
         public List<Portfolio> Portfolios
         {
             get { return _portfolios; }
             set { _portfolios = value; }
         }
     }

     public class PortfolioStockHandler : StockHandler
     {
         public void RemoveNumberOfShares(string stockName, int numberOfShares)
         {
             if (numberOfShares < 0)
             {
                 throw new StockExchangeException("broj mora biti pozitivan");
             }
             Stock stock = GetStock(stockName);

             if (numberOfShares > stock.Quantity)
             {
                 DelistStock(stockName);
             }
             else
             {
                 stock.Quantity -= numberOfShares;
             }
         }

         public decimal TotalValueOfShares(DateTime moment)
         {
             return Stocks.Sum(s => s.StockPrices.GetPrice(moment).PriceValue * s.Quantity);
         }

         public override void AddStock(Stock stock)
         {
             if (Stocks.Exists(s => s.Name.Equals(stock.Name, StringComparison.CurrentCultureIgnoreCase)))
             {
                 Stock oldStock = GetStock(stock.Name);
                 oldStock.Quantity += stock.Quantity;
             }
             else
             {
                 Stocks.Add(stock);
             }
         }
     }

     public class Price
     {
         private DateTime _moment;
         private Decimal _price;

         public Price(DateTime moment, Decimal price)
         {
             if (price <= 0)
             {
                 throw new StockExchangeException("Cijena ne moze biti negativna");
             }
             _price = price;
             _moment = moment;
         }

         public Price(Decimal price)
         {
             if (price <= 0)
             {
                 throw new StockExchangeException("Cijena ne moze biti negativna");
             }
             _price = price;
             _moment = DateTime.Now;
         }

         public Price()
         {

         }

         public DateTime Moment
         {
             get { return _moment; }
             set { _moment = value; }
         }

         public decimal PriceValue
         {
             get { return _price; }
             set { _price = value; }
         }
     }

     public class Stock
     {
         private string _name;
         private long _quantity;
         private StockPrices _stockPrices;

         public Stock(string name, long quantity, StockPrices stockPrices)
         {
             _name = name;
             _quantity = quantity;
             _stockPrices = stockPrices;
         }

         public Stock(string name, long quantity, Price initialPrice)
         {
             if (name == "")
             {
                 throw new StockExchangeException("Ime ne moze biti prazno");
             }
             _name = name;
             if (quantity <= 0)
             {
                 throw new StockExchangeException("cijena ne moze biti negativna");
             }
             _quantity = quantity;
             _stockPrices = new StockPrices();
             _stockPrices.AddPrice(initialPrice);
         }

         public Stock(string name, long quantity)
         {
             if (name == "")
             {
                 throw new StockExchangeException("Ime ne moze biti prazno");
             }
             _name = name;
             if (quantity <= 0)
             {
                 throw new StockExchangeException("kolicina ne moze biti negativna");
             }
             _quantity = quantity;
             _stockPrices = new StockPrices();
         }

         public Stock()
         {
             _stockPrices = new StockPrices();
         }

         public Decimal GetStockValue(DateTime moment)
         {
             return Quantity * StockPrices.GetPrice(moment).PriceValue;
         }

         public string Name
         {
             get { return _name; }
             set { _name = value; }
         }

         public long Quantity
         {
             get { return _quantity; }
             set { _quantity = value; }
         }

         public StockPrices StockPrices
         {
             get { return _stockPrices; }
             set { _stockPrices = value; }
         }
     }

     public class StockHandler
     {
         private List<Stock> _stocks;

         public StockHandler()
         {
             Stocks = new List<Stock>();
         }

         public List<Stock> Stocks
         {
             get { return _stocks; }
             set { _stocks = value; }
         }

         public virtual void AddStock(Stock stock)
         {
             if (Stocks.Exists(s => s.Name.Equals(stock.Name, StringComparison.CurrentCultureIgnoreCase)))
             {
                 throw new StockExchangeException("dionica sa istim imenom postoji");
             }
             else
             {
                 Stocks.Add(stock);
             }
         }

         public int NumberOfStocks()
         {
             return Stocks.Count;
         }

         public bool StockExists(string stockName)
         {
             return Stocks.Exists(s => s.Name.Equals(stockName, StringComparison.CurrentCultureIgnoreCase));
         }

         public Stock GetStock(string stockName)
         {
             if (!StockExists(stockName))
             {
                 throw new StockExchangeException("Ne postoji dionica");
             }
             return Stocks.Select(s => s).Where(s => s.Name.Equals(stockName, StringComparison.CurrentCultureIgnoreCase)).ToList().First();
         }

         public Decimal GetStockPrice(string stockName, DateTime moment)
         {
             return GetStock(stockName).StockPrices.GetPrice(moment).PriceValue;
         }

         public void SetStockPrice(string stockName, DateTime moment, Decimal price)
         {
             Stock stock = GetStock(stockName);
             stock.StockPrices.AddPrice(new Price(moment, price));
         }

         public Decimal GetInitialStockPrice(string stockName)
         {
             return GetStock(stockName).StockPrices.GetInitialPrice().PriceValue;
         }

         public Decimal GetLastStockPrice(string stockName)
         {
             return GetStock(stockName).StockPrices.GetLastPrice().PriceValue;
         }

         public void DelistStock(string stockName)
         {
             Stocks.Remove(GetStock(stockName));
         }


     }

     public class StockPrices
     {
         private List<Price> _prices;

         public StockPrices()
         {
             _prices = new List<Price>();
         }

         public void AddPrice(Price price)
         {
             if (_prices.Exists(p => p.Moment == price.Moment))
             {
                 throw new StockExchangeException("Postoji cijena za zadani trenutak");
             }
             if (_prices != null) _prices.Add(price);
         }

         public Price GetPrice(DateTime moment)
         {
             if (_prices.Count == 0)
             {
                 throw new StockExchangeException("Nema cijena");
             }
             _prices = _prices.OrderBy(p => p.Moment).ToList();

             if (_prices[0].Moment > moment)
             {
                 throw new StockExchangeException("Trenutak manji od pocetnog");
             }
             _prices = _prices.OrderBy(p => p.Moment).ToList();

             for (int i = 0; i < _prices.Count; i++)
             {
                 if (_prices[i].Moment > moment)
                 {
                     return _prices[i - 1];
                 }
             }
             return _prices.Last();
         }
         public Price GetPriceWithoutException(DateTime moment)
         {
             Price price = new Price();
             price.Moment = moment;
             price.PriceValue = 0;
             if (_prices.Count == 0)
             {
                 return price;
             }
             _prices = _prices.OrderBy(p => p.Moment).ToList();
             if (_prices[0].Moment > moment)
             {
                 return price;
             }


             for (int i = 0; i < _prices.Count; i++)
             {
                 if (_prices[i].Moment > moment)
                 {
                     return _prices[i - 1];
                 }
             }
             return _prices.Last();
         }
         public Price GetInitialPrice()
         {
             if (_prices.Count == 0)
             {
                 throw new StockExchangeException("Nema cijena");
             }

             return _prices.OrderBy(p => p.Moment).ToList().First();
         }

         public Price GetLastPrice()
         {
             if (_prices.Count == 0)
             {
                 throw new StockExchangeException("Nema cijena");
             }

             return _prices.OrderBy(p => p.Moment).ToList().Last();
         }
     }

}
