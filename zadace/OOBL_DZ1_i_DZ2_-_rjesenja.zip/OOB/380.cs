﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Ovu sam tako fino napravio da komentari nisu ni potrebni ^^ 
// iako da napomenem bilo je par nedoumica oko portofolioPercentage i jos nekih sitnica, 
// ali rjesenih nadam se na pravi nacin!! 
namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         //za svaku dionicu postoji jedan zapis u ovom diksneriju i lista njenih promjena
         public Dictionary<string, List<Stock>> stocks = new Dictionary<string, List<Stock>>();
         // takodjer jedan diksneri za indexe.. iako sam overridao Equals u svojoj klasi, ovo mi je
         // bilo elegantnije rjesenje, osloniti se na dobro definirane stringove ^^ a i ovako je bilo
         // puno prakticnije i preglednije
         public Dictionary<string, Index> indices = new Dictionary<string, Index>();
         // sve isto kao i kod diksnerija za indekse 
         public Dictionary<string, Portofolio> portofolios = new Dictionary<string, Portofolio>();



         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (inNumberOfShares <= 0 || inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Number and price have to be positive");
             }
             else if (stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("Stock with name " + inStockName + " already exists");
             }
             else
             {
                 Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                 List<Stock> newStockHistory = new List<Stock>();
                 newStockHistory.Add(stock);
                 stocks.Add(stock.StockName, newStockHistory);
             }
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else
             {
                 foreach (Index index in indices.Values)
                 {
                     if (index.StockList.Contains(inStockName))
                         index.StockList.Remove(inStockName);
                 }
                 foreach (Portofolio portofolio in portofolios.Values)
                 {
                     if (portofolio.Stocks.ContainsKey(inStockName))
                     {
                         portofolio.Stocks.Remove(inStockName);
                     }
                 }
                 stocks.Remove(inStockName);                 
             }
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
                 return false;
             return true;
         }

         public int NumberOfStocks()
         {
             return stocks.Keys.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (inStockValue <= 0)
             {
                 throw new StockExchangeException("Value has to be positive");
             }
             else
             {
                 Stock stock = new Stock(inStockName, stocks[inStockName].ElementAt(0).NumberOfShares,
                                                inStockValue, inIimeStamp);
                 foreach (Stock stockInHistory in stocks[inStockName])
                 {
                     if (stockInHistory.TimeStamp.Equals(stock.TimeStamp))
                         throw new StockExchangeException("Stock with same time stamp already exists");
                 }
                 stocks[inStockName].Add(stock);
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else
             {
                 Stock stock = findSpecificStock(inStockName, inTimeStamp);
                 return Math.Round(stock.Price, 3);
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else
             {
                 Stock stock = findInitialStock(inStockName, new DateTime(1900, 5, 5));
                 return Math.Round(stock.Price, 3);
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else
             {
                 Stock stock = findLatestStock(inStockName, DateTime.Now);
                 return Math.Round(stock.Price, 3);
             }
         }

        

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToUpper();
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
             {
                 throw new StockExchangeException("Unsuported index type");
             }
             else if (indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " already exists");
             }
             else 
             {
                 Index index = new Index(inIndexName, inIndexType);
                 indices.Add(inIndexName, index);                
             } 
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " doesn't exists");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (indices[inIndexName].StockList.Contains(inStockName))
             {
                 throw new StockExchangeException("Stock with name " + inStockName + " already exists in this index");             
             }
             else 
             {
                 indices[inIndexName].StockList.Add(inStockName);             
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " doesn't exists");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (!indices[inIndexName].StockList.Contains(inStockName))
             {
                 throw new StockExchangeException("Stock with name " + inStockName + " doesn't exists in this index");
             }
             else
             {
                 indices[inIndexName].StockList.Remove(inStockName);
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " doesn't exists");
             }
             // po meni bi ovo trebalo baciti exception jer se trazi dionica koja uopce ne postoji na burzi
             // ali moji kolege se ne slazu samnom.. njih je vise pa sam eto popustio -.-
             //else if (!stocks.ContainsKey(inStockName))
             //{
             //    throw new StockExchangeException("No stock with name " + inStockName);
             //}
             else if (!indices[inIndexName].StockList.Contains(inStockName))
             {
                 return false;
             }   
             return true;
             
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " doesn't exists");
             }
             else if (indices[inIndexName].StockList.Count == 0)
             {
                 return 0;
             }
             else
             {
                 //radim try catch blok zato sto postoji mogucnost da setrazi vrijednost neke dionice u indexu za 
                 // vrijeme u kojem uopce ona nije bila definirana
                 try
                 {

                 decimal indexValue = 0;
                 Index index = indices[inIndexName];
                 List<Stock> stocksInIndex = new List<Stock>();
                 DateTime timeWhenIndexIsCalculating = inTimeStamp;

                 if (index.IndexType == IndexTypes.WEIGHTED)
                 {
                     decimal sumOfAllStocksShares = 0;
                     foreach (string inStockName in index.StockList)
                     {
                         Stock stock = findSpecificStock(inStockName, timeWhenIndexIsCalculating);
                         stocksInIndex.Add(stock);
                         sumOfAllStocksShares += stock.Price * stock.NumberOfShares;
                     }
                     foreach (Stock stock in stocksInIndex)
                     {
                         indexValue += stock.NumberOfShares * (stock.Price * (stock.Price / sumOfAllStocksShares));
                     }
                     return Math.Round(indexValue, 3);
                 }
                 else if (index.IndexType == IndexTypes.AVERAGE)
                 {
                     decimal sumOfAllStocks = 0;
                     foreach (string inStockName in index.StockList)
                     {
                         Stock stock = findSpecificStock(inStockName, timeWhenIndexIsCalculating);
                         sumOfAllStocks += stock.Price;
                     }
                     indexValue = sumOfAllStocks / index.StockList.Count();
                     return Math.Round(indexValue, 3);
                 }
                 else
                 {
                     throw new StockExchangeException("Unknown index type");
                 }
                 }
                 catch (StockExchangeException)
                 {
                     throw new StockExchangeException("Trying to calculate index value with stock that's not "
                                                    + " initialized at given time");
                 }
             }
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 return false;
             }
             return true;
         }

         public int NumberOfIndices()
         {
             return indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             if (!indices.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " doesn't exists");
             }
             else
             {
                 return indices[inIndexName].StockList.Count();
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "already exists");
             }
             else
             {
                 Portofolio portofolio = new Portofolio(inPortfolioID);
                 portofolios.Add(portofolio.PortofolioID, portofolio);             
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("You have to add postive number of shares");
             }
             else
             {
                 Portofolio portofolio = portofolios[inPortfolioID];
                 if (checkNumberOfSharesOfStockInPortofolios(inStockName, numberOfShares))
                 {
                     if (portofolio.Stocks.ContainsKey(inStockName))
                     {
                         int numberOfSharesBefore = portofolio.Stocks[inStockName];
                         int numberOfSharesAfter = numberOfSharesBefore + numberOfShares;
                         portofolio.Stocks.Remove(inStockName);
                         portofolio.Stocks.Add(inStockName, numberOfSharesAfter);
                     }
                     else
                     {
                         portofolio.Stocks.Add(inStockName, numberOfShares);
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("You are trying to add more shares in portofolio then available");
                 }
             }
         }



         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("You have to remove positive number of shares");
             }
             else if (!portofolios[inPortfolioID].Stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName + " in portofolio with id " + inPortfolioID);
             }
             else
             {
                 Portofolio portofolio = portofolios[inPortfolioID];
                 int numberOfSharesBefore = portofolio.Stocks[inStockName];
                 int numberOfSharesAfter = numberOfSharesBefore - numberOfShares;
                 portofolio.Stocks.Remove(inStockName);
                 if (!(numberOfSharesAfter <= 0))
                     portofolio.Stocks.Add(inStockName, numberOfSharesAfter);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (!portofolios[inPortfolioID].Stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName + " in portofolio with id " + inPortfolioID);
             }
             else
             {
                 Portofolio portofolio = portofolios[inPortfolioID];                
                 portofolio.Stocks.Remove(inStockName);                 
             }
         }

         public int NumberOfPortfolios()
         {
             return portofolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else 
             {
                 return portofolios[inPortfolioID].Stocks.Count();
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 return false;
             }
             return true;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
            // takodjer ista stvar kao sa indexom.. opet vecina -.-
            // else if (!stocks.ContainsKey(inStockName))
            // {
            //     throw new StockExchangeException("No stock with name " + inStockName);
            // }
             else
             {
                 if (!portofolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                 {
                     return false;
                 }
                 return true;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else if (!stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
             else if (!portofolios[inPortfolioID].Stocks.ContainsKey(inStockName))
             {
                 throw new StockExchangeException("No stock with name " + inStockName + " in portofolio with id " + inPortfolioID);
             }
             else
             {
                 Portofolio portofolio = portofolios[inPortfolioID];
                 return portofolio.Stocks[inStockName];
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + "doesn't exist");
             }
             else
             {
                 decimal portofolioValue = 0;
                 Portofolio portofolio = portofolios[inPortfolioID];
                 if (portofolio.Stocks.Count == 0)
                 {
                     return 0;
                 }
                 foreach (string inStockName in portofolio.Stocks.Keys)
                 {
                     try
                     {
                         Stock stock = findSpecificStock(inStockName, timeStamp);
                         portofolioValue += stock.Price * portofolio.Stocks[stock.StockName];  
                     }
                     catch (StockExchangeException)
                     {
                         throw new StockExchangeException("Not all stocks in portofolio are defined for given time");
                     }                                        
                 }
                 return Math.Round(portofolioValue,3);
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             //TODO implement portofolio percentage value
             if (!portofolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with id " + inPortfolioID + " doesn't exist");
             }
             else
             {
                 DateTime startOfMonth = new DateTime(Year, Month, 1, 00, 00, 00);
                 DateTime endOfMonth = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
                 decimal startOfMonthPortofolioValue = 0;
                 decimal endOfMonthPortofolioValue = 0;
                 Portofolio portofolio = portofolios[inPortfolioID];

                 if (portofolio.Stocks.Count == 0)
                 {
                     throw new StockExchangeException("No stocks in portofolio. Percentage change can't be calculated");
                 }
                 foreach (string inStockName in portofolio.Stocks.Keys)
                 {
                     try
                     {
                         Stock stockStart = findSpecificStock(inStockName, startOfMonth);
                         Stock stockEnd = findSpecificStock(inStockName, endOfMonth);
                         startOfMonthPortofolioValue += stockStart.Price * portofolio.Stocks[stockStart.StockName];
                         endOfMonthPortofolioValue += stockEnd.Price * portofolio.Stocks[stockEnd.StockName];
                     }
                     catch (StockExchangeException)
                     {                        
                         throw new StockExchangeException("Not all stocks in portofolio are defined for given time span");
                     }                     
                 }
                 return Math.Round(((endOfMonthPortofolioValue - startOfMonthPortofolioValue) / startOfMonthPortofolioValue) * 100, 3);
             }
         }

         private Stock findSpecificStock(string inStockName, DateTime inTimeStamp)
         {
             Stock resultStock = new Stock(inStockName.ToUpper(), 0, 0, new DateTime(300,7,5));
             TimeSpan lowestTimeDifference = inTimeStamp - resultStock.TimeStamp;
             foreach (Stock stock in stocks[inStockName])
             {
                 if (stock.TimeStamp <= inTimeStamp)
                 {
                     TimeSpan currentTimeDifference = inTimeStamp - stock.TimeStamp;
                     if (lowestTimeDifference >= currentTimeDifference)
                     {
                         resultStock = stock;
                         lowestTimeDifference = currentTimeDifference;
                     }
                 }
             }
             if(resultStock.TimeStamp.Equals(new DateTime(300,7,5)))
                 throw new StockExchangeException("Stock is undefined for given date");
             return resultStock;
         }

         private Stock findInitialStock(string inStockName, DateTime inTimeStamp)
         {
             Stock resultStock = stocks[inStockName].ElementAt(0);
             TimeSpan lowestTimeDifference = resultStock.TimeStamp - inTimeStamp;
             foreach (Stock stock in stocks[inStockName])
             {
                 TimeSpan currentTimeDifference = stock.TimeStamp - inTimeStamp;
                 if (lowestTimeDifference >= currentTimeDifference )
                 {
                     resultStock = stock;
                     lowestTimeDifference = currentTimeDifference;
                 }
             }
             return resultStock;
         }

         private Stock findLatestStock(string inStockName, DateTime inTimeStamp)
         {
             Stock resultStock = stocks[inStockName].ElementAt(0);
             TimeSpan lowestTimeDifference = inTimeStamp - resultStock.TimeStamp;
             foreach (Stock stock in stocks[inStockName])
             {
                 TimeSpan currentTimeDifference = inTimeStamp - stock.TimeStamp;
                 if (lowestTimeDifference >= currentTimeDifference)
                 {
                     resultStock = stock;
                     lowestTimeDifference = currentTimeDifference;
                 }
             }
             return resultStock;
         }

         private bool checkNumberOfSharesOfStockInPortofolios(string inStockName, int numberOfShares)
         {
             int sumOfShares = numberOfShares;
             foreach (Portofolio portofolio in portofolios.Values)
             {
                 if (portofolio.Stocks.ContainsKey(inStockName))
                 {
                     sumOfShares += portofolio.Stocks[inStockName];                 
                 }
             }
             if (!(sumOfShares <= stocks[inStockName].ElementAt(0).NumberOfShares))
                 return false;
             return true;
         }
     }

     public class Stock
     {
         public string StockName { get; set; }
         public long NumberOfShares { get; set; }
         public decimal Price { get; set; }
         public DateTime TimeStamp { get; set; }

         public Stock() { }

         public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
         {
             this.StockName = stockName.ToUpper();
             this.NumberOfShares = numberOfShares;
             this.Price = initialPrice;
             this.TimeStamp = timeStamp;
         }         

         public override bool Equals(Object obj)
         {
             Stock second = (Stock)obj;
             if (this.StockName.Equals(second.StockName))
                 return true;
             return false;
         }
     }

     public class Index
     {

         public string IndexName { get; set; }
         public IndexTypes  IndexType { get; set; }
         public List<string> StockList { get; set; }

         public Index(string indexName, IndexTypes indexType)
         {
             this.IndexName = indexName.ToUpper();
             this.IndexType = indexType;
             this.StockList = new List<string>();
         }

         public override bool Equals(Object obj)
         {
             Index second = (Index)obj;
             if (this.IndexName.Equals(second.IndexName))
                 return true;
             return false;
         }
     }

     public class Portofolio
     {
         public string PortofolioID { get; set; }
         public Dictionary<string,int> Stocks { get; set; }

         public Portofolio(string portofolioID) 
         {
             this.PortofolioID = portofolioID;
             this.Stocks = new Dictionary<string, int>();
         }

         public override bool Equals(Object obj)
         {
             Portofolio second = (Portofolio)obj;
             if (this.PortofolioID.Equals(second.PortofolioID))
                 return true;
             return false;
         }
     }


     
}
