﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
     {
         public static IStockExchange CreateStockExchange()
         {
             return new StockExchange();
         }
     }

     public class StockExchange : IStockExchange
     {
         // spremamo dionice
         // indexe i portfolije
         private Dictionary<string, Stock>      _stocks = new Dictionary<string, Stock>();
         private Dictionary<string, Index>      _indices = new Dictionary<string, Index>();
         private Dictionary<string, Portfolio>  _portfolios = new Dictionary<string, Portfolio>();
         //
      
         // STOCKS

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             string name = inStockName.ToUpper();
             if (StockExists(inStockName) || inInitialPrice <= 0 || inNumberOfShares <= 0) 
             {
                 throw new StockExchangeException("ListStockError");
             }

             // ovo je sve proslo pa dodajemo dionicu
             _stocks.Add(name, new Stock(name, inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             string name = inStockName.ToUpper();
            
             if (StockExists(inStockName))
             {
                // prije nego uklonimo dionicu potrebno je maknuti ih takoder u indexima
                 foreach( string a in _indices.Keys)
                 {
                     if (_indices[a].isStockIn(inStockName.ToUpper()))
                    {
                        _indices[a].RemoveStockFromIndex(inStockName.ToUpper());
                       
                    }
                 }

                 // te u portfolijima
                 foreach (string a in _portfolios.Keys)
                 { 
                    if ( _portfolios[a].isStockIn(inStockName.ToUpper()))
                        _portfolios[a].StockRemove(inStockName.ToUpper());
                 }
                 // nakon toga obrisemo dionicu
                 _stocks.Remove(name);
             }
             else throw new StockExchangeException("DelistStockError"); 
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return _stocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             string name = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 _stocks[name].SetPrice(inIimeStamp, inStockValue);
             }
             else throw new StockExchangeException("SetStockPriceError");
       
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             string name = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return _stocks[name].GetPrice(inTimeStamp);
             }
             else throw new StockExchangeException("GetStockPriceError"); 
             
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             string name = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return _stocks[name].GetInitial();
             }
             else throw new StockExchangeException("GetInitialStockPriceError"); 
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             string name = inStockName.ToUpper();
             if (StockExists(inStockName))
             {
                 return _stocks[name].GetLast();
             }
             else throw new StockExchangeException("GetLastStockPriceError"); 
         }

         // INDEXI

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             string name = inIndexName.ToUpper();
             if (IndexExists(inIndexName) || Enum.IsDefined(typeof(IndexTypes), inIndexType) == false) 
                 throw new StockExchangeException("CreateIndexError");
        
             // inace je sve proslo pa mozemo dodati index
             _indices.Add(name, new Index(name, inIndexType));
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
             {
                 // ako je dionica vec dio indexa onda nije slobodna
                 if (IsStockPartOfIndex(inIndexName, inStockName) == false)
                 {

                     _indices[inIndexName.ToUpper()].AddStock(_stocks[inStockName.ToUpper()]);
                 } 
             }

             else throw new StockExchangeException("AddStockToIndex");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName) &&
                 IsStockPartOfIndex(inIndexName, inStockName)) // znamo da postoji
             {
                 _indices[ inIndexName.ToUpper()].RemoveStockFromIndex( inStockName.ToUpper());
                 
             }

             else throw new StockExchangeException("RemoveStockFromIndex");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             string Iname = inIndexName.ToUpper();
             string Sname = inStockName.ToUpper();

             if (IndexExists(inIndexName.ToUpper()) == false || StockExists(Sname) == false)
                 throw new StockExchangeException("necega nema");
             
             return _indices[inIndexName.ToUpper()].isStockIn(inStockName.ToUpper());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (IndexExists(inIndexName))
             {
                 return _indices[inIndexName.ToUpper()].returnValue(inTimeStamp);
             }
             else throw new StockExchangeException("GetIndexValueError");
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.ContainsKey(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return _indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (IndexExists(inIndexName))
             {
                 return _indices[inIndexName.ToUpper()].getNumberOfStocks();   
             }
             throw new StockExchangeException("NumberOfStocksInIndexError");
         }

         // PORTFOLIO

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("CreatePortfolioError");
             else
             {
                 _portfolios.Add(inPortfolioID, new Portfolio(inPortfolioID));
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) == false || StockExists(inStockName) == false
                 || numberOfShares > _stocks[inStockName.ToUpper()].getRShares() || numberOfShares <= 0
                 )
             {
                 throw new StockExchangeException("AddStockToPortfolioError");
             }

             // inace je sve uredu pa dodajemo
             if ( !IsStockPartOfPortfolio(inPortfolioID, inStockName.ToUpper()))
                _portfolios[inPortfolioID].AddStock(inStockName.ToUpper(), _stocks[inStockName.ToUpper()]);

             _portfolios[inPortfolioID].setShares(inStockName.ToUpper(), numberOfShares);
             _stocks[inStockName.ToUpper()].SubRshares(numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (PortfolioExists(inPortfolioID) == false || StockExists(inStockName) == false
                || numberOfShares > _portfolios[inPortfolioID].getShares(inStockName.ToUpper())
                || numberOfShares <= 0
                )
             {
                 throw new StockExchangeException("AddStockToPortfolioError");
             }

             string Sname = inStockName.ToUpper();
             _stocks[Sname].AddRshares(numberOfShares);
             _portfolios[inPortfolioID].SubShares(Sname, numberOfShares);

         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) == false || StockExists(inStockName) == false)
                 throw new StockExchangeException("RemoveStockFromPortfolioError");

             string Sname = inStockName.ToUpper();
             int shares = _portfolios[inPortfolioID].getShares(Sname);
             _stocks[Sname].AddRshares(shares);
             _portfolios[inPortfolioID].StockRemove(Sname);

         }

         public int NumberOfPortfolios()
         {
             return _portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return _portfolios[inPortfolioID].getNumberOfStocks();
             }
             throw new StockExchangeException("NumberOfPorfolioStocksError");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             string Sname = inStockName.ToUpper();
             
             if (PortfolioExists(inPortfolioID) == false || StockExists(inStockName.ToUpper()) == false)
                 throw new StockExchangeException("IsStockPartOfPortfolioError");

             return _portfolios[inPortfolioID].isStockIn(Sname);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (PortfolioExists(inPortfolioID) && StockExists(inStockName))
             {
                 return _portfolios[inPortfolioID].getShares(inStockName.ToUpper());
             }
             else throw new StockExchangeException("NumberOfSharesOfStockInPortfolioError");
         }  

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (PortfolioExists(inPortfolioID))
             {
                 return _portfolios[inPortfolioID].getValue(timeStamp);
             }
             else throw new StockExchangeException("GetPortfoliovalueError");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (PortfolioExists(inPortfolioID) && Year >= 0 && Month >= 1 && Month <= 12)
             {
                 DateTime start = new DateTime(Year, Month, 1, 0, 0, 0);
                 DateTime lastDay = start.AddMonths(1).AddDays(-1);
                 lastDay = lastDay.AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(999);

                 Decimal startValue = _portfolios[inPortfolioID].getValue(start);
                 Decimal endValue = _portfolios[inPortfolioID].getValue(lastDay);

                 if (startValue == 0m) return 0m;
                 Decimal ret = (endValue - startValue)/startValue;

                 return Math.Round(ret * 100, 3);  
             }
             else throw new StockExchangeException("GetPortfoliPercentChangeInMountError");
         }
     }


     // klasa koja sadrzi dionicu
     public class Stock 
     {
         private string     StockName;
         private long       NumberOfShares;
         private long rShares; // preostel dionice za portfolio
         private SortedList<DateTime, Decimal> _prices = new SortedList<DateTime, decimal>();
       

         // metode
         public string GetName() { return StockName; }
         public long getNumberOfShares() {return NumberOfShares; }

         public Stock(string name, long numShares, Decimal price, DateTime time) 
         {
             StockName = name; NumberOfShares = numShares; rShares = numShares;
             _prices.Add(time, price);
         }

         public void SetPrice(DateTime time, Decimal price)
         {
             if (_prices.ContainsKey(time)) throw new StockExchangeException("postojiTrenutak");
             _prices.Add(time, price);
         }

         public Decimal GetPrice(DateTime time)
         {
             if (time >= _prices.ElementAt(_prices.Count() - 1).Key)
             {
                 return _prices.ElementAt(_prices.Count() - 1).Value;
             }
             else
             {
                 for (int i = _prices.Count() - 2; i >= 0; i--)
                 {
                     if (time >= _prices.ElementAt(i).Key)
                         return _prices.ElementAt(i).Value;
                 }
             }

             throw new StockExchangeException("VrijemeManjeOdInicijalnog");
         }

         public Decimal GetInitial()
         {
             return _prices.ElementAt(0).Value;
         }

         public Decimal GetLast()
         {
             return _prices.ElementAt(_prices.Count() - 1).Value;
         }

         public long getRShares() { return rShares; }

         public void SubRshares(int num) { rShares -= num; }

         public void AddRshares(int num) { rShares += num; }
     }



     // klasa koja sadrzi indexe
     public class Index
     {
         private string IndexName;
         private IndexTypes Type;
         private Dictionary<string, Stock> _iStocks = new Dictionary<string, Stock>();


         // metode
         public Index(string _name, IndexTypes _type)
         {
             IndexName = _name;
             Type = _type;
         }

         public void RemoveStockFromIndex(string name) {
             _iStocks.Remove(name);
         }

         public void AddStock(Stock s) {
             _iStocks.Add(s.GetName() , s);
         }

         public bool isStockIn(string name) 
         {
             return _iStocks.ContainsKey(name);
         }

         public int getNumberOfStocks()
         {
             return _iStocks.Count();
         }

         public Decimal returnValue(DateTime time) 
         {
             List<decimal> prices = new List<decimal>();
             List<long> shares = new List<long>();
             Decimal sum = 0m, ret = 0m;
             long stocksCount = _iStocks.Count();

             foreach (string a in _iStocks.Keys)
             {
                 Decimal b = _iStocks[a].GetPrice(time);
                 prices.Add(b);
                 long c = _iStocks[a].getNumberOfShares();
                 shares.Add(c);
                 sum += b * c;
             }
             if (stocksCount == 0m) return 0m;

             if (Type == IndexTypes.WEIGHTED)
             {
                
                 for (int i = 0; i < prices.Count(); i++)
                 {
                     ret += prices[i] * prices[i] * shares[i] / sum;
                 }
                 return Math.Round(ret, 3);
             }
             else
             {
                 for (int i = 0; i < prices.Count(); i++)
                     ret += prices[i];

                 return Math.Round(ret / stocksCount, 3);
             }
         }
     }



     // klasa koja sadrzi portfolije
     public class Portfolio
     {
         private string PortfolioID;
         private Dictionary<string, Stock> pStocks = new Dictionary<string,Stock>();
         // pamti za svaku dionicu koliko ima shares
         private Dictionary<string, int> numberStock = new Dictionary<string, int>();


         //metode
         public Portfolio(string name)
         {
             PortfolioID = name;
         }

         public void AddStock(string name, Stock s) 
         {
             pStocks.Add(name, s);
         }

         public bool isStockIn(string name)
         {
             return pStocks.ContainsKey(name);
         }

         public int getNumberOfStocks()
         {
             return pStocks.Count();
         }

         public void setShares(string name, int number)
         {
             if (numberStock.ContainsKey(name))
             {
                 numberStock[name] += number;
             }
             else
                 numberStock.Add(name, number);
         }

         public void SubShares(string name, int number)
         {
             numberStock[name] -= number;
             if (numberStock[name] == 0)
                 StockRemove(name);
         }

         public int getShares(string name)
         {
             return numberStock[name];
         }

         public void StockRemove(string name)
         {
             pStocks.Remove(name);
             numberStock.Remove(name);
         }

         public Decimal getValue(DateTime time)
         {
             Decimal ret = 0;
             foreach (string a in numberStock.Keys)
             {
                 ret += numberStock[a] * pStocks[a].GetPrice(time);
             }

             return Math.Round(ret, 3);
         }
     }

}
