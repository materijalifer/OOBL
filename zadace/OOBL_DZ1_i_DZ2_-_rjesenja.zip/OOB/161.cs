﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Calculator();
        }
    }


    //***********************************************************************************
    //--------------------------------Kalkulator-----------------------------------------
    //***********************************************************************************
    public class Calculator : ICalculator
    {
        private Display display;
        private Processor processor;

        public Calculator()
        {
            this.display = new Display();
            this.processor = new Processor(this);
        }

        public void Press(char inPressedDigit)
        {
            string displayOutput = processor.ProcessInput(inPressedDigit);
            this.display.SetDisplayState(displayOutput);
        }

        public string GetCurrentDisplayState()
        {
            return this.display.GetDisplayState();
        }

        public int GetDisplayLimit()
        {
            return display.MaxChars;
        }

        public double GetMaxNumberSize()
        {
            return display.MaxNumberSize;
        }

    }

    //*********************************************************************************
    //-------------------------------Display-------------------------------------------
    //**********************************************************************************
    public interface IDisplay
    {
        string GetDisplayState();
        void SetDisplayState(string displayState);
    }

    public class Display : IDisplay
    {
        private string displayState;
        private const int maxChars = 12;
        private const double maxNumberSize = 9999999999;

        public Display()
        {
            this.displayState = "0";
        }

        public string GetDisplayState()
        {
            return displayState;
        }
        public void SetDisplayState(string displayState)
        {
            this.displayState = displayState;
        }
        public int MaxChars
        {
            get { return maxChars; }
        }
        public double MaxNumberSize
        {
            get { return maxNumberSize; }
        }
    }


    //************************************************************************************************
    //-------------------------------------Processor-------------------------------------------------
    //************************************************************************************************
    public class Processor
    {
        private Calculator calculator;
        private Memory memory;
        private string output;


        public Processor(Calculator calculator)
        {
            this.memory = new Memory();
            this.calculator = calculator;
            output = "0";
        }

        public string ProcessInput(char input)
        {
            //Ako je prethodno bila pogreška, resetiraj
            if (output.Equals("-E-"))
                output = "0";

            if (Char.IsDigit(input))
            {
                AddNewDigit(input.ToString());
            }
            else if (memory.BinOperators.Contains(input.ToString()))
            {
                CalculateBinOperations(input);
            }
            else if (memory.UnOperators.Contains(input.ToString()))
            {
                CalculateUnOperations(input);
            }
            else 
            {
                switch (input)
                {
                    case ',' :
                        AddDecimalComma();
                        break;
                    case '=':
                        Calculate();
                        break;
                    case 'C':
                        output = "";
                        break;
                    case 'O':
                        Reset();
                        break;
                }
            }


            return output;
        }

        private void AddNewDigit(string digit)
        {
            if (!memory.SecondOperand)
            {
                if (output.Equals("0"))
                {
                    output = digit;
                }
                else
                {
                    if (NumberOfDigits(output) < calculator.GetDisplayLimit() -2)
                        output += digit;
                }
            }
            else
            {
                output = digit;
                memory.SecondOperand = false;
            }

        }

        private void AddDecimalComma()
        {
            if (!memory.SecondOperand)
            {
                if (NumberOfDigits(output) == 10 || output.Contains(","))
                    return;
                else
                    output += ",";
            }
            else
            {
                return;
            }
        }

        private void CalculateBinOperations(char recvOperator)
        {
            if (memory.CurrentOperator != '0' && !memory.SecondOperand)
            {
                Calculate();

                memory.CurrentOperator = recvOperator;
                memory.FirstOperand = output;
                memory.SecondOperand = true;
            }
            else if (memory.SecondOperand)
            {
                memory.CurrentOperator = recvOperator;
            }
            else
            {
                ThrowExtraZeros();

                memory.FirstOperand = output;
                memory.CurrentOperator = recvOperator;
                memory.SecondOperand = true;
            }
        }

        private void Calculate()
        {
            switch (memory.CurrentOperator)
            {
                case '+':
                    Add();
                    break;
                case '-':
                    Subtract();
                    break;
                case '*':
                    Multiply();
                    break;
                case '/':
                    Divide();
                    break;
            }

            ThrowExtraZeros();
        }
        private void CalculateUnOperations(char recvOperator)
        {
            double result;
            switch (recvOperator)
            {
                case 'M':
                    ChangeSign();
                    break;
                case 'S':
                    result = Math.Sin(Convert.ToDouble(output));
                    FormatNumber(result);
                    break;
                case 'K':
                    result = Math.Cos(Convert.ToDouble(output));
                    FormatNumber(result);
                    break;
                case 'T':
                    result = Math.Tan(Convert.ToDouble(output));
                    FormatNumber(result);
                    break;
                case 'Q':
                   result = Math.Pow(Convert.ToDouble(output), 2);
                    FormatNumber(result);
                    break;
                case 'R':
                    CalculateSquareRoot();
                    break;
                case 'I':
                    CalculateInverse();
                    break;
                case 'P':
                    memory.StoredValue = output;
                    break;
                case 'G':
                    output = memory.StoredValue;
                    break;
            }
            
        }

        private void Reset()
        {
            output = "-E-";
            memory.FirstOperand = memory.StoredValue = "0" ;
            memory.SecondOperand = false;
            memory.CurrentOperator = '0';
        }


        //***********************************************Bin operations**********************************************
        private void Add()
        {
            double result = Convert.ToDouble(memory.FirstOperand) + Convert.ToDouble(output);
            FormatNumber(result);

            memory.CurrentOperator = '0';
        }
        private void Subtract()
        {
            double result = Convert.ToDouble(memory.FirstOperand) - Convert.ToDouble(output);
            FormatNumber(result);

            memory.CurrentOperator = '0';
        }
        private void Multiply()
        {
            double result = Convert.ToDouble(memory.FirstOperand) * Convert.ToDouble(output);
            FormatNumber(result);

            memory.CurrentOperator = '0';
        }

        private void Divide()
        {
            if (Convert.ToDouble(output) == 0)
            {
                Reset();
                output = "-E-";
            }
            else
            {
                double result = Convert.ToDouble(memory.FirstOperand) / Convert.ToDouble(output);
                FormatNumber(result);

            }
            memory.CurrentOperator = '0';
        }

        //********************************************************Un operations******************************************

        private void ChangeSign()
        {
            if (output.Equals("0"))
            {
                return;
            }
            else if (output.StartsWith("-") && !output.EndsWith("-"))
            {
                output = output.Substring(1, output.Length - 1);
            }
            else
            {
                output = "-" + output;
            }
        }

        private void CalculateSquareRoot()
        {
            if (Convert.ToDouble(output) >= 0)
            {
                double result = Math.Sqrt((Convert.ToDouble(output)));
                FormatNumber(result);
            }
            else
            {
                Reset();
                output= "-E-";
            }
        }

        private void CalculateInverse()
        {
            if (Convert.ToDouble( output ) != 0)
            {
                double result  = 1 / Convert.ToDouble(output);
                FormatNumber(result);
            }
            else
            {
                Reset();
                output = "-E-";
            }
        }
        
        //********************************************************Format*************************************************
        private void FormatNumber(double number)
        {
            if (number > calculator.GetMaxNumberSize())
            {
                Reset();
                output = "-E-";
                return;
            }

            if (NumberOfDigits(number.ToString()) > calculator.GetDisplayLimit() - 2)
            {
                string numberString = number.ToString();

                if (numberString.Contains("-") && numberString.Contains(","))
                {
                    string round = RoundCell(numberString);

                    if (round != null)
                    {
                        output = numberString.Substring(0, 11) + round;
                    }
                    else
                    {
                        output = numberString.Substring(0, 12);
                    }
                }
                else if (numberString.Contains("-") || numberString.Contains(","))
                {
                    string round = RoundCell(numberString);

                    if (round != null)
                    {
                        output = numberString.Substring(0, 10) + round;
                    }
                    else
                    {
                        output = numberString.Substring(0, 11);
                    }
                }
                else
                {
                    output = numberString.Substring(0, 10);
                }
            }
            else
            {
                output = number.ToString();
            }

        }

        private int NumberOfDigits(string number)
        {
            int numberOfDigits = 0;

            foreach (char sign in number.ToCharArray())
            {
                if (Char.IsDigit(sign))
                    numberOfDigits++;
            }
            return numberOfDigits;
        }

        private string RoundCell(string number)
        {
            char[] digits = number.ToCharArray();

            int lastIndex;
            if (number.StartsWith("-"))
            {
                lastIndex = calculator.GetDisplayLimit();
            }
            else
            {
                lastIndex = calculator.GetDisplayLimit() - 1;
            }

            if (Int32.Parse(digits[lastIndex].ToString()) >= 5)
            {
                int newValue = Int32.Parse(digits[lastIndex -1 ].ToString()) + 1;
                return newValue.ToString();
            }
            
            return null;
        }

        private void ThrowExtraZeros()
        {
            while (output.Contains(",") && output.EndsWith("0"))
            {
                output = output.Substring(0, output.Length - 1);
            }

            if (output.EndsWith(","))
            {
                output = output.Substring(0, output.Length - 1);
            }
           
        }
    }

    //*********************************************************************************************
    //-----------------------------------------Memory----------------------------------------------
    //*********************************************************************************************
    public class Memory
    {
        private string firstOperand;
        private bool secondOperand;
        private string storedValue;
        private char currentOperator;

        private List<String> binOperators;
        private List<String> unOperators;

        public Memory()
        {
            firstOperand = "";
            secondOperand = false;
            currentOperator = '0'; 
            storedValue = "";
           
            LoadOperators();
        }

        public string FirstOperand
        {
            get { return firstOperand; }
            set { firstOperand = value; }
        }
        public bool SecondOperand
        {
            get { return secondOperand; }
            set { secondOperand = value; }
        }
        public string StoredValue
        {
            get { return storedValue; }
            set { storedValue = value; }
        }
        public char CurrentOperator
        {
            get { return currentOperator; }
            set { currentOperator = value; }
        }
       
        public List<String> BinOperators
        {
            get { return binOperators; }
            set { binOperators = value; }
        }
        public List<String> UnOperators
        {
            get { return unOperators; }
            set { unOperators = value; }
        }
        
        private void LoadOperators()
        {
            binOperators = new List<string>();
            binOperators.Add("+");
            binOperators.Add("-");
            binOperators.Add("*");
            binOperators.Add("/");

            unOperators = new List<string>();
            unOperators.Add("M");
            unOperators.Add("S");
            unOperators.Add("K");
            unOperators.Add("T");
            unOperators.Add("Q");
            unOperators.Add("R");
            unOperators.Add("I");
            unOperators.Add("P");
            unOperators.Add("G");
           
        }
    }

}
