﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    //nova
        public class Factory
        {
            public static ICalculator CreateCalculator()
            {
                // vratiti kalkulator
                return new Kalkulator();
            }
        }

    public class Kalkulator : ICalculator
    {
        bool uspio = false;
        char zarez = ',';
        char t_oper1;
        char t_oper2;
        string p;
        string ekranS = "0";
        string drugaZnam = "";
        double rezI = 0;
        double _ekranN = 0;
        double m = 0;
        string gr = "-E-";



        public void Press(char x)
        {


            if ((x == '0') || (x == '1') || x == '2' || x == '3' || x == '4' || x == '5' || x == '6' || x == '7' || x == '8' || x == '9')
            {
                drugaZnam = drugaZnam + x;

                konvertiraj(drugaZnam);
                return;
            }


            if ((x == '+') || (x == '-') || x == '*' || x == '/')
            {

                if ((rezI != 0) && (drugaZnam != ""))
                {
                    rezI = oper2(rezI, _ekranN, t_oper1, false);
                    var z = roundr(rezI);
                    var a = gr;
                    if (z == a)
                    {
                        ekranS = a;
                        return;
                    }

                    p = roundr(rezI);
                    _ekranN = Convert.ToDouble(p);
                    _ekranN = rezI;
                    ekranS = Convert.ToString(_ekranN);
                    t_oper1 = x;
                    drugaZnam = "";

                    return;
                }


                if (!((rezI != 0) && (drugaZnam != "")))
                {
                    t_oper1 = x;
                    var p = roundr(_ekranN);
                    if (p == gr)
                    {
                        ekranS = gr;
                        return;
                    }
                    else
                    {

                        rezI = Convert.ToDouble(p);

                        drugaZnam = "";
                        return;
                    }
                }
            }


            if ((x == zarez) || (x == 'C') || x == 'O')
            {
                oper3(x);
            }


            if ((x == '=') && ((t_oper1 == '+') || (t_oper1 == '-') || t_oper1 == '*' || t_oper1 == '/'))
            {
                if ((t_oper1 == '/') && (_ekranN == 0))
                {
                    uspio = true;
                    ekranS = gr;
                    return;
                }
                rezI = oper2(rezI, _ekranN, t_oper1, false);
                _ekranN = rezI;
                if (roundr(_ekranN) == gr)
                {
                    ekranS = gr;
                    return;
                }
                rezI = 0;
                drugaZnam = "";
                t_oper1 = '\0';
                _ekranN = Convert.ToDouble(roundr(_ekranN));
                ekranS = Convert.ToString(_ekranN);

            }

            if (x == 'M')
            {
                _ekranN = (-1) * _ekranN;
                _ekranN = Convert.ToDouble(roundr(_ekranN));
                drugaZnam = Convert.ToString(_ekranN);

                ekranS = drugaZnam;
                return;
            }

            if ((x == 'S') || (x == 'K') || x == 'T' || x == 'Q' || x == 'R' || x == 'I')
            {
                t_oper2 = x;
                if ((x == 'I') && (_ekranN == 0))
                {
                    ekranS = gr;
                    return;
                }
                _ekranN = oper1(_ekranN, t_oper2);
                if (roundr(_ekranN) == gr)
                {
                    ekranS = gr;
                    return;
                }
                _ekranN = Convert.ToDouble(roundr(_ekranN));
                ekranS = Convert.ToString(_ekranN);
                return;
            }

            if (x == '=' || x == 'P' || x == 'G')
            {
                if (x == '=')
                {
                    rezI = 0;
                    t_oper1 = '\0';
                    drugaZnam = "";

                    return;
                }

                if (x == 'P')
                {
                    m = 3;
                    m = _ekranN;
                    return;
                }

                if (x == 'G')
                {
                    drugaZnam = "";
                    _ekranN = m;
                    ekranS = Convert.ToString(_ekranN);

                    return;
                }
            }
        }



        public string GetCurrentDisplayState()
        {
            return ekranS;
        }



        public double oper1(double n, char o)
        {
            if (o == 'Q')
            {
                n = Math.Pow(n, 2);
            }

            if (o == 'R')
            {
                n = Math.Sqrt(n);
            }

            if (o == 'I')
            {
                n = 1 / n;
            }
            if (o == 'S')
            {
                n = Math.Sin(n);

            }
            if (o == 'K')
            {
                n = Math.Cos(n);

            }
            if (o == 'T')
            {
                n = Math.Tan(n);

            }

            if (o == 'M')
            {
                n = n * (-1);

            }



            return n;
        }

        public double oper2(double r, double n, char o, bool usp)
        {


            {
                if (o == '*')
                {
                    r = r * n;
                }
                if (o == '/')
                {
                    try
                    {
                        r = r / n;
                        usp = true;
                    }
                    catch (Exception)
                    {

                        usp = false;
                    }

                }
                if (o == '+')
                {
                    r = r + n;
                }
                if (o == '-')
                {
                    r = r - n;
                }


            }
            return r;
        }


        public string roundr(double rI)
        {


            int zarezIndex;
            int _roundIndex;
            string drugaZnam = rI.ToString();
            int _length = 0;
            _length = drugaZnam.Length;


            if ((rI < 0))
            {
                if ((drugaZnam.Contains(",")) && (_length > 12))
                {

                    zarezIndex = drugaZnam.IndexOf(',');
                    _roundIndex = 11 - zarezIndex;
                    if (_roundIndex < 0)
                    {
                        return gr;
                    }
                    rI = Math.Round(rI, _roundIndex);
                    drugaZnam = Convert.ToString(rI);
                    return drugaZnam;

                }

                if ((!drugaZnam.Contains(",")) && (_length > 12))
                    return gr;
            }




            if (rI > 0)
            {
                if ((drugaZnam.Contains(",")) && (_length > 11))
                {
                    string _substring = drugaZnam.Substring(0, 11);
                    zarezIndex = drugaZnam.IndexOf(',');
                    _roundIndex = 10 - zarezIndex;
                    if (_roundIndex < 0)
                    {
                        return gr;
                    }
                    rI = Math.Round(rI, _roundIndex);
                    drugaZnam = Convert.ToString(rI);
                    return drugaZnam;

                }

                if ((_length > 10) && (!drugaZnam.Contains(",")))
                    return gr;
                if ((!drugaZnam.Contains(",")) && (_length > 11))
                    return gr;

            }


            return drugaZnam;



        }
        public void konvertiraj(string drznam)
        {
            _ekranN = Convert.ToDouble(drznam);
            ekranS = Convert.ToString(_ekranN);

        }
        public string oper3(char x)
        {
            if (x == zarez)
            {
                foreach (var item in drugaZnam)
                {
                    if (item == ',')
                        return "";
                }

                drugaZnam = drugaZnam + zarez;
                return "";
            }

            if (x == 'C')
            {
                _ekranN = 0;
                ekranS = "0";
                drugaZnam = "";
                return "";
            }


            if (x == 'O')
            {
                drugaZnam = "0";
                _ekranN = 0;
                ekranS = "0";
                rezI = 0;
                t_oper1 = '\0';
                m = 0;
                return "";
            }
            return "";
        }
    }
}
