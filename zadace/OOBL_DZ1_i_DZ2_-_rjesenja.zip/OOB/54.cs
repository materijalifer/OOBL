﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private static int DECIMAL_SPACES = 10;

        // atrubuti klase Kalkulator

        string currentDisplayState;
        string savedNumber;
        string currentOperator;
        string currentOperand;
        bool decimalPointPressed;
        bool readyForNewOperand;
        bool lastButtonIsBinOperator;
        int freeDecimalSpaces;

        /// <summary>
        /// konstruktor klase Kalkulator inicijalizira njene atribute pozivanjem metode reset()
        /// </summary>
        public Kalkulator()
        {
            reset();
        }

        /// <summary>
        /// metoda Press(char inPressedDigit) omogućuje unos znaka u kalkulator pozivajući odgovarajuće metode s odgovarajućim parametrima
        /// </summary>
        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'O':
                    pressedResetButton();
                    break;
                case 'C':
                    pressedClearButton();
                    break;
                case 'P':
                    pressedPutButton();
                    break;
                case 'G':
                    pressedGetButton();
                    break;
                case 'M':
                    pressedSignChangeButton();
                    break;
                case 'I':
                    pressedInverseButton();
                    break;
                case 'Q':
                    pressedUnarOperationButton('Q');
                    break;
                case 'R':
                    pressedUnarOperationButton('R');
                    break;
                case 'S':
                    pressedUnarOperationButton('S');
                    break;
                case 'K':
                    pressedUnarOperationButton('K');
                    break;
                case 'T':
                    pressedUnarOperationButton('T');
                    break;
                case '+':
                    pressedBinaryOperatorButton('+');
                    break;
                case '-':
                    pressedBinaryOperatorButton('-');
                    break;
                case '*':
                    pressedBinaryOperatorButton('*');
                    break;
                case '/':
                    pressedBinaryOperatorButton('/');
                    break;
                case '=':
                    pressedEuqalsButton();
                    break;
                case ',':
                    pressedDecimalPointButton();
                    break;
                default:
                    pressedDigitButton(inPressedDigit);
                    break;
            }

        }

        /// <summary>
        /// metoda vraća prikaz ekrana
        /// </summary>
        public string GetCurrentDisplayState()
        {
            return this.currentDisplayState;
        }

        /// <summary>
        /// metoda implementira slučaj kada je unesena znamenka
        /// </summary>
        private void pressedDigitButton(char inPressedDigit)
        {
            // 1. slučaj - ekran se briše
            if ((freeDecimalSpaces > 0) && (this.currentDisplayState == "0" || this.currentDisplayState == "-E-" || this.readyForNewOperand))
            {
                this.currentDisplayState = inPressedDigit.ToString();
                if (inPressedDigit != '0')
                    this.freeDecimalSpaces--;
                this.readyForNewOperand = false;
                this.lastButtonIsBinOperator = false;
            }
            // 2. slučaj - znamenka se dodaje na kraj
            else if ((freeDecimalSpaces > 0) && (this.currentDisplayState != "0"))
            {
                this.currentDisplayState += inPressedDigit.ToString();
                this.freeDecimalSpaces--;
                this.readyForNewOperand = false;
                this.lastButtonIsBinOperator = false;
            }
        }

        /// <summary>
        /// metoda implementira unos decimalnog zareza
        /// </summary>
        private void pressedDecimalPointButton()
        {
            // prihvaća unos samo ako decimalni zarez već nije prisutan ili nije unesen cjelobrojni dio decimalnog broja
            if (decimalPointPressed == false && readyForNewOperand == false)
            {
                if (this.currentDisplayState == "0")
                    this.freeDecimalSpaces--;
                this.currentDisplayState += ",";
                this.decimalPointPressed = true;
                this.readyForNewOperand = false;
                this.lastButtonIsBinOperator = false;
            }
            else if (decimalPointPressed == false && readyForNewOperand == true)
            {
                this.currentDisplayState = "0,";
                this.decimalPointPressed = true;
                this.readyForNewOperand = false;
                this.lastButtonIsBinOperator = false;
            }
        }

        /// <summary>
        /// metoda implemenira unos znaka jednakosti
        /// </summary>
        private void pressedEuqalsButton()
        {
            double temp;
            if (this.currentDisplayState != "-E-")
            {
                // ukoliko nije još zadan operator samo se formatira ispis
                if (this.currentOperator == null)
                {
                    temp = double.Parse(this.currentDisplayState);
                    this.currentDisplayState = formatDisplay(temp);
                    this.freeDecimalSpaces += this.currentDisplayState.Length - temp.ToString().Length;
                    this.lastButtonIsBinOperator = false;
                    newInputReady();
                }
                else
                {
                    // ukoliko je zadan operator poziva se metoda za izračun i prikaz rezultata
                    calculate('=');
                }
            }
        }

        /// <summary>
        /// metoda implementira unos binarnog operatora
        /// </summary>
        private void pressedBinaryOperatorButton(char pressedButton)
        {
            if (this.currentDisplayState != "-E-")
            {
                // ako je neposredno zadan binarni operator, on se briše i sprema se novi
                if (this.lastButtonIsBinOperator)
                {
                    this.currentOperator = pressedButton.ToString();
                }
                else if (this.currentOperator == null)
                {
                    // ako nije spremljen binarni operator, trenutni operator postaje uprvo zadani
                    this.currentOperator = pressedButton.ToString();
                    this.currentOperand = this.currentDisplayState;
                    this.lastButtonIsBinOperator = true;
                    newInputReady();
                }
                else
                {
                    // ukoliko prije je zadan binarni operator poziva se metoda za izračun i prikaz rezultata
                    calculate(pressedButton);
                }
            }
        }

        /// <summary>
        /// metoda izračunava rezultat binarne operacije, poziva metodu za prikaz rezultata, te postavlja novi trenutni operator
        /// ili null vrijedost u slučaju da je zadan operator "="
        /// </summary>
        private void calculate(char pressedOperator)
        {
            string nextOperator = pressedOperator.ToString();
            if (nextOperator == "=")
                nextOperator = null;

            double temp;
            switch (this.currentOperator)
            {
                // 1. slučaj - spremljeni binarni operator je zbrajanje
                case "+":
                    temp = double.Parse(this.currentOperand) + double.Parse(this.currentDisplayState);
                    displayOperationResult(nextOperator, temp);
                    newInputReady();
                    break;
                // 2. slučaj - spremljeni binarni operator je oduzimanje
                case "-":
                    temp = double.Parse(this.currentOperand) - double.Parse(this.currentDisplayState);
                    displayOperationResult(nextOperator, temp);
                    newInputReady();
                    break;
                // 3. slučaj - spremljeni binarni operator je množenje
                case "*":
                    temp = double.Parse(this.currentOperand) * double.Parse(this.currentDisplayState);
                    displayOperationResult(nextOperator, temp);
                    newInputReady();
                    break;
                // 4. slučaj - spremljeni binarni operator je dijeljenje
                case "/":
                    // zabranjujemo djeljenju nulom
                    if (double.Parse(this.currentDisplayState) != 0)
                    {
                        temp = double.Parse(this.currentOperand) / double.Parse(this.currentDisplayState);
                        displayOperationResult(nextOperator, temp);
                        newInputReady();
                    }
                    else
                    {
                        this.currentDisplayState = "-E-";
                        this.currentOperator = null;
                        this.currentOperand = null;
                        newInputReady();
                    }
                    break;
            }
        }

        private void pressedUnarOperationButton(char unarOperator)
        {
            double temp = double.Parse(this.currentDisplayState);
            if (this.currentDisplayState != "-E-")
            {
                switch (unarOperator)
                {
                    case 'Q':
                        temp = temp * temp;
                        break;
                    case 'R':
                        temp = Math.Sqrt(temp);
                        break;
                    case 'S':
                        temp = Math.Sin(temp);
                        break;
                    case 'K':
                        temp = Math.Cos(temp);
                        break;
                    case 'T':
                        temp = Math.Tan(temp);
                        break;
                }

                this.currentDisplayState = formatDisplay(temp);
                this.lastButtonIsBinOperator = false;
                newInputReady();
            }
        }

        /// <summary>
        /// metoda implementira unos operatora invertiranja
        /// </summary>
        private void pressedInverseButton()
        {
            // nulu ne možemo invertirati
            if (this.currentDisplayState != "0" && this.currentDisplayState != "-E-")
            {
                double temp = double.Parse(this.currentDisplayState);
                temp = 1 / temp;

                this.currentDisplayState = formatDisplay(temp);
                this.lastButtonIsBinOperator = false;
                newInputReady();
            }
            else if (this.currentDisplayState == "0")
                this.currentDisplayState = "-E-";
        }

        /// <summary>
        /// metoda implementira promjenu predznaka
        /// </summary>
        private void pressedSignChangeButton()
        {
            // ukoliko je je trenuti prikaz ekrana jednak "0" ne želimo ispisati "-0"
            if (this.currentDisplayState != "0" && this.currentDisplayState != "-E-")
            {
                // provjeravamo prisutnost predznaka
                if (this.currentDisplayState[0] == '-')
                {
                    this.currentDisplayState = this.currentDisplayState.Substring(1);
                    this.lastButtonIsBinOperator = false;
                }
                else
                {
                    this.currentDisplayState = "-" + this.currentDisplayState;
                    this.lastButtonIsBinOperator = false;
                }
            }
        }

        /// <summary>
        /// metoda imlpementira spremanje broja u memoriju
        /// </summary>
        private void pressedGetButton()
        {
            this.currentDisplayState = this.savedNumber;
            this.lastButtonIsBinOperator = false;
            newInputReady();
        }

        /// <summary>
        /// metoda imlpementira dohvaćanje broja iz memorije
        /// </summary>
        private void pressedPutButton()
        {
            if (this.currentDisplayState != "-E-")
            {
                this.savedNumber = this.currentDisplayState;
            }
        }

        /// <summary>
        /// metoda implementira brisanje ekrana
        /// </summary>
        private void pressedClearButton()
        {
            this.currentDisplayState = "0";
            this.freeDecimalSpaces = 10;
            this.decimalPointPressed = false;
            this.readyForNewOperand = false;
            this.lastButtonIsBinOperator = false;
        }

        /// <summary>
        /// metoda implementira resetiranja ekrana, poziva metodu reset isto kao i konstruktor klase
        /// </summary>
        private void pressedResetButton()
        {
            reset();
        }

        /// <summary>
        /// metoda prikazuje rezultat binarne operacije te podešava odgovarajuće paramtre potrebne za nizanje operacija
        /// </summary>
        private void displayOperationResult(string nextOperation, double result)
        {
            this.currentDisplayState = formatDisplay(result);
            this.currentOperator = nextOperation;
            this.currentOperand = this.currentDisplayState;
            this.lastButtonIsBinOperator = true;
        }

        /// <summary>
        /// metoda formatira prikaz ekrana na najviše 10 znamenki
        /// </summary>
        private string formatDisplay(double displayNumber)
        {
            // računamo broj cjelobrojnih znamenki
            int nonDecimalDigitNumber = ((long)Math.Round(Math.Abs(displayNumber))).ToString().Length;

            // zaokružujemo broj na odgovarajući broj znamenki
            if (nonDecimalDigitNumber > 10)
            {
                // broj cjelobrojnih znamenki veći od 10
                return "-E-";
            }
            else if (nonDecimalDigitNumber == 10)
            {
                // broj ima točno 10 cjelobrojnih znamenki
                return Math.Round(displayNumber).ToString();
            }
            else
            {
                // broj cjelobrojnih znamenki je manje od 10
                return Math.Round(displayNumber, 10 - nonDecimalDigitNumber).ToString("0.#########");
            }
        }

        /// <summary>
        /// metoda postavlja kalkulator u stanje u kojem je spreman za unos novog broja
        /// primjerice nakon izračunate operacije, javljanja pogreške "-E-" i sl.
        /// </summary>
        private void newInputReady()
        {
            this.readyForNewOperand = true;
            this.freeDecimalSpaces = 10;
            this.decimalPointPressed = false;
        }

        /// <summary>
        /// metoda resetira kalkulator
        /// inicijalizira njene atribute: trenutni prikaz na ekranu, spremljeni broj u memoriji, trenutni binarni operator, 
        /// spremljeni prvi operand, broj slobodnih znamenki na ekranu, spremnost za novi unos, te prisutnost decimalnog zareza 
        /// i predznaka
        /// pozivaju ju konstrukor i metoda pressedResetButton()
        /// </summary>
        private void reset()
        {
            this.currentDisplayState = "0";
            this.savedNumber = "0";
            this.currentOperator = null;
            this.currentOperand = null;
            this.decimalPointPressed = false;
            this.readyForNewOperand = false;
            this.lastButtonIsBinOperator = false;
            this.freeDecimalSpaces = DECIMAL_SPACES;
        }
    }
}
