﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
    public class StockPrice
    {
        public decimal Price {get; set;}
        public DateTime StockTimeStamp { get; set;}

        public StockPrice(decimal inStockPrice, DateTime inStockTimeStamp)
        {
            Price = inStockPrice;
            StockTimeStamp = inStockTimeStamp;
        }
        
    }
    public class Stock
    {
        public string StockName { get; set; }
        public long NumberOfStocks { get; set; }
        public List<StockPrice> StockPrices { get; set; }

        public Stock(string inStockName, long inNumberOfStocks)
        {
            StockName = inStockName;
            NumberOfStocks = inNumberOfStocks;
            StockPrices = new List<StockPrice>();
        }
        public void addStockPrice(decimal inPrice, DateTime inStockTimeStamp)
        {
            foreach (StockPrice time in StockPrices)
            {
                if (time.StockTimeStamp == inStockTimeStamp)
                    throw new StockExchangeException("Price for that moment already exists!");
            }
            StockPrice newStockPrice = new StockPrice(inPrice, inStockTimeStamp);
            StockPrices.Add(newStockPrice);
        }
    }
    
    public class Index
    {
        public string IndexName { get; set; }
        public IndexTypes IndexType { get; set; }
        public List<Stock> StocksInIndex { get; set; }

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            IndexName = inIndexName;
            IndexType = inIndexType;
            StocksInIndex = new List<Stock>();
        }
    }
    public class Portfolio
    {
        public string PortfolioId { get; set; }
        public List<Stock> StocksInPortfolio { get; set; }

        public Portfolio(string inPortfolioId)
        {
            PortfolioId = inPortfolioId;
            StocksInPortfolio = new List<Stock>();
        }
    }

     public class StockExchange : IStockExchange
     {
         private List<Stock> Stocks = new List<Stock>();
         private List<Index> Indexes = new List<Index>();
         private List<Portfolio> Portfolios = new List<Portfolio>();
         
         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (!(inNumberOfShares > 0))
                 throw new StockExchangeException("Number of shares must be greater than 0.");
             if (!(inInitialPrice > 0))
                 throw new StockExchangeException("Initial price must be greater than 0.");
             if(StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " already exist!");
             Stock newStock = new Stock(inStockName.ToUpper(), inNumberOfShares);
             StockPrice newStockPrice = new StockPrice(inInitialPrice, inTimeStamp);
             newStock.StockPrices.Add(newStockPrice);
             Stocks.Add(newStock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             for (int i = 0; i < Stocks.Count; i++)
             {
                 if (Stocks[i].StockName.Equals(inStockName.ToUpper()))
                 {
                     Stocks.RemoveAt(i);
                     break;
                 }
             }
             foreach (Index index in Indexes)
             {
                 if (IsStockPartOfIndex(index.IndexName, inStockName))
                     RemoveStockFromIndex(index.IndexName, inStockName);
             }
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (IsStockPartOfPortfolio(portfolio.PortfolioId, inStockName))
                     RemoveStockFromPortfolio(portfolio.PortfolioId, inStockName);
             }
         }

         public bool StockExists(string inStockName)
         {
             foreach (Stock stock in Stocks)
             {
                 if (stock.StockName.Equals(inStockName.ToUpper()))
                     return true;
             }
             return false;
         }

         public int NumberOfStocks()
         {
             return Stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             if(!(inStockValue > 0))
                 throw new StockExchangeException("Price must be greater than 0.");
             FindStock(Stocks, inStockName).addStockPrice(inStockValue, inTimeStamp);
             return;
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             
             decimal price = 0;
             Stock tempStock = FindStock(Stocks, inStockName);
             
             TimeSpan difference = inTimeStamp - tempStock.StockPrices[0].StockTimeStamp;
             foreach (StockPrice stockPrice in tempStock.StockPrices)
             {
                 if (stockPrice.StockTimeStamp <= inTimeStamp)
                 {
                     
                    if (inTimeStamp - stockPrice.StockTimeStamp <= difference)
                    {
                        difference = inTimeStamp - stockPrice.StockTimeStamp;
                        price = stockPrice.Price;
                    }
                }
             }
             if(price == 0)
                 throw new StockExchangeException("Stock " + inStockName + " has no value defined for this time");
             return price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             decimal price = 0;
             Stock tempStock = FindStock(Stocks, inStockName);
            
             DateTime first = tempStock.StockPrices[0].StockTimeStamp;
             price = tempStock.StockPrices[0].Price;
             foreach (StockPrice stockPrice in tempStock.StockPrices)
             {
                if (stockPrice.StockTimeStamp < first)
                {
                    first = stockPrice.StockTimeStamp;
                    price = stockPrice.Price;
                }
             }
             return price;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             decimal price = 0;
             Stock tempStock = FindStock(Stocks, inStockName);

             DateTime last = tempStock.StockPrices[0].StockTimeStamp;
             price = tempStock.StockPrices[0].Price;
             foreach (StockPrice stockPrice in tempStock.StockPrices)
             {
                if (stockPrice.StockTimeStamp > last)
                {
                    last = stockPrice.StockTimeStamp;
                    price = stockPrice.Price;
                }
             }
             return price;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " already exist!");
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                 throw new StockExchangeException("Index " + inIndexName + " is not correct type");
             Index newIndex = new Index(inIndexName.ToUpper(), inIndexType);
             Indexes.Add(newIndex);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " does not exist!");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             if (IsStockPartOfIndex(inIndexName, inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " is part of index " + inIndexName);
             FindIndex(inIndexName).StocksInIndex.Add(FindStock(Stocks,inStockName));
             return;
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " does not exist!");
             if(!IsStockPartOfIndex(inIndexName, inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " is not part of index " + inIndexName);
             FindIndex(inIndexName).StocksInIndex.Remove(FindStock(FindIndex(inIndexName).StocksInIndex, inStockName));
             return;
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " does not exist!");
             foreach (Index index in Indexes)
             {
                 if (index.IndexName == inIndexName.ToUpper())
                 {
                     foreach (Stock stock in index.StocksInIndex)
                     {
                         if (stock.StockName == inStockName.ToUpper())
                         {
                             return true;
                         }
                     }

                 }
             }
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " does not exist!");
             Index _index = FindIndex(inIndexName);
             if (!(_index.StocksInIndex.Count > 0))
                 return 0;
             return CalculateIndexValue(_index, inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index index in Indexes)
             {
                 if (index.IndexName.Equals(inIndexName.ToUpper()))
                     return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return Indexes.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Index " + inIndexName + " does not exist!");
             return FindIndex(inIndexName).StocksInIndex.Count;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " already exists!");
             Portfolio newPortfolio = new Portfolio(inPortfolioID);
             Portfolios.Add(newPortfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " does not exist!");
             if (!(numberOfShares > 0))
                 throw new StockExchangeException("Number of shares must be greater than 0.");
             long numberOfSharesInAllPortfolios = 0;
             long numberOfSharesStock = Stocks.ElementAt(Stocks.FindIndex(stock => stock.StockName.Equals(inStockName.ToUpper()))).NumberOfStocks;
             
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (IsStockPartOfPortfolio(portfolio.PortfolioId, inStockName))
                     numberOfSharesInAllPortfolios += NumberOfSharesOfStockInPortfolio(portfolio.PortfolioId, inStockName);
             }
             if (numberOfSharesInAllPortfolios + numberOfShares > numberOfSharesStock)
                 throw new StockExchangeException("Sum of number of shares in all portfolios is over maximum number of shares");
             
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 FindStock(FindPortfolio(inPortfolioID).StocksInPortfolio, inStockName).NumberOfStocks += numberOfShares;
                 return;
             }
             else
             {
                 Stock newStock = new Stock(inStockName.ToUpper(), Convert.ToInt64(numberOfShares));
                 newStock.StockPrices = FindStock(Stocks, inStockName).StockPrices;
                 FindPortfolio(inPortfolioID).StocksInPortfolio.Add(newStock);
                 return;
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " is not part of portfolio " + inPortfolioID);
             if(NumberOfSharesOfStockInPortfolio(inPortfolioID,inStockName) < numberOfShares)
                 throw new StockExchangeException("Number of shares of " + inStockName + " stock in portfolio " + inPortfolioID + " is smaller than number you are trying to delete");
            
             if (FindStock(FindPortfolio(inPortfolioID).StocksInPortfolio, inStockName).NumberOfStocks == numberOfShares)
             {
                RemoveStockFromPortfolio(inPortfolioID, inStockName);
                return;
             }
             else
             {
                FindStock(FindPortfolio(inPortfolioID).StocksInPortfolio, inStockName).NumberOfStocks -= numberOfShares;
                return;
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " is not part of portfolio " + inPortfolioID);

             FindPortfolio(inPortfolioID).StocksInPortfolio.Remove(FindStock(FindPortfolio(inPortfolioID).StocksInPortfolio, inStockName));
         }

         public int NumberOfPortfolios()
         {
             return Portfolios.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             return FindPortfolio(inPortfolioID).StocksInPortfolio.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.PortfolioId.Equals(inPortfolioID))
                     return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.PortfolioId == inPortfolioID)
                 {
                     foreach (Stock stock in portfolio.StocksInPortfolio)
                     {
                         if (stock.StockName == inStockName.ToUpper())
                         {
                             return true;
                         }
                     }

                 }
             }
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Stock " + inStockName + " is not part of portfolio " + inPortfolioID);

             return Convert.ToInt32(FindStock(FindPortfolio(inPortfolioID).StocksInPortfolio, inStockName).NumberOfStocks);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if (!(FindPortfolio(inPortfolioID).StocksInPortfolio.Count > 0))
                 return 0;
             Portfolio _portfolio = FindPortfolio(inPortfolioID);

             decimal sumValuesAllStocksInPortfolio = 0;
             foreach (Stock stock in _portfolio.StocksInPortfolio)
             {
                 sumValuesAllStocksInPortfolio += GetStockPrice(stock.StockName, timeStamp)*stock.NumberOfStocks;
             }
             return Math.Round(sumValuesAllStocksInPortfolio,3);

         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Portfolio " + inPortfolioID + " does not exist!");
             if(!(Month > 0 && Month < 13))
                 throw new StockExchangeException("Month must be from 1 to 12");
             if (!(FindPortfolio(inPortfolioID).StocksInPortfolio.Count > 0))
                 return 0;
             decimal monthChangeValue = 0;
             decimal lastDayValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
             decimal firstDayValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00));
             monthChangeValue = Math.Round(Math.Abs((lastDayValue - firstDayValue)/firstDayValue*100),3);
             return monthChangeValue;
         }

/////////////////////////////////////////////////////////////////////////////////Privatne metode///////////////////////////////////////////////////////////////////////////////////////
 
         // Metoda za racunanje vrijednosti indeksa
         private decimal CalculateIndexValue(Index inIndex, DateTime inTimeStamp)
         {
             decimal indexValue = 0;
             decimal sumValuesAllSharesInIndex = 0;
             decimal stockPrice;

             if (inIndex.IndexType.Equals(IndexTypes.AVERAGE))
             {
                 foreach (Stock stock in inIndex.StocksInIndex)
                 {
                     stockPrice = GetStockPrice(stock.StockName, inTimeStamp);
                     sumValuesAllSharesInIndex += stockPrice;
                 }
                 indexValue = sumValuesAllSharesInIndex / inIndex.StocksInIndex.Count;
             }

             else if (inIndex.IndexType.Equals(IndexTypes.WEIGHTED))
             {
                 foreach (Stock stock in inIndex.StocksInIndex)
                 {
                     stockPrice = GetStockPrice(stock.StockName, inTimeStamp);
                     sumValuesAllSharesInIndex += stockPrice*stock.NumberOfStocks;
                 }
                 foreach (Stock stock in inIndex.StocksInIndex)
                 {
                     stockPrice = GetStockPrice(stock.StockName, inTimeStamp);
                     indexValue += stockPrice / sumValuesAllSharesInIndex * stock.NumberOfStocks * stockPrice;
                 }
             }
             return Math.Round(indexValue, 3);

         }
         // Metoda koja pronalazak portfolija
         private Portfolio FindPortfolio(string inPortfolioID)
         {
             Portfolio returnPortfolio = null;
             foreach (Portfolio portfolio in Portfolios)
             {
                 if (portfolio.PortfolioId == inPortfolioID)
                 {
                     returnPortfolio = portfolio;
                 }
             }
             return returnPortfolio;
         }
         //Metoda za pronalazak indeksa
         private Index FindIndex(string inIndexName)
         {
             Index returnIndex = null;
             foreach (Index index in Indexes)
             {
                 if (index.IndexName == inIndexName.ToUpper())
                     returnIndex = index;
             }
             return returnIndex;
         }
         //Metoda za pronalazak dionice u listi
         private Stock FindStock(List<Stock> inStockList, string inStockName)
         {
             Stock returnStock = null;
             foreach (Stock stock in inStockList)
             {
                 if (stock.StockName == inStockName.ToUpper())
                 {
                     returnStock = stock;
                 }
             }
             return returnStock;
         }
     }
}
