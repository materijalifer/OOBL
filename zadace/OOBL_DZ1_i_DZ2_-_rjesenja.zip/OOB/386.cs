﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks;
        private List<Index> _indices;
        private List<Portfolio> _portfolios;

        public StockExchange()
        {
            _stocks = new List<Stock>();
            _indices = new List<Index>();
            _portfolios = new List<Portfolio>();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName) == false)
            {
                if (inNumberOfShares > 0 && inInitialPrice > 0)
                {
                    Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
                    _stocks.Add(stock);
                }
                else throw new StockExchangeException("inNumberOfShares or inInitialPrice is Negative");
            }
            else throw new StockExchangeException("SameNameAlreadyExists");
        }

        public void DelistStock(string inStockName)
        {
            if (StockExists(inStockName) == true)
            {
                _stocks.Remove(_stocks.First(s => s.StockName.ToLower() == inStockName.ToLower()));
            }
            else throw new StockExchangeException("StockNameDoesntExists");
        }

        public bool StockExists(string inStockName)
        {
            return _stocks.Exists(s => s.StockName.ToLower() == inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (StockExists(inStockName) == true)
            {
                if (inStockValue > 0)
                {
                    _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower()).CurrentPrice = inStockValue;
                    _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower()).TimeStamp = inIimeStamp;
                    _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower()).PriceHistory.Add(new StockPriceHistoryEntry(inStockValue, inIimeStamp));
                }
                else throw new StockExchangeException("inStockValue is <=0");
            }
            else throw new StockExchangeException("StockNameDoesntExists");
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (StockExists(inStockName) == true)
            {
                Stock stock = _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower());
                DateTime lastTimeSpan = new DateTime(1900, 1, 1);
                if (stock.PriceHistory.Count > 0)
                {
                    decimal stockPrice = 0;
                    foreach (StockPriceHistoryEntry sphe in stock.PriceHistory)
                    {
                        if (sphe.TimeStamp < inTimeStamp)
                        {
                            if (sphe.TimeStamp >= lastTimeSpan)
                            {
                                lastTimeSpan = sphe.TimeStamp;
                            }
                        }
                    }
                    stockPrice = stock.PriceHistory.FirstOrDefault(ph => ph.TimeStamp == lastTimeSpan).StockPrice;
                    return stockPrice;
                }
                else return 0;
            }
            else throw new StockExchangeException("StockNameDoesntExists");
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (StockExists(inStockName) == true)
            {
                return _stocks.First(s => s.StockName.ToLower() == inStockName.ToLower()).InitialPrice;
            }
            else throw new StockExchangeException("StockNameDoesntExists");
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (StockExists(inStockName) == true)
            {
                return _stocks.First(s => s.StockName.ToLower() == inStockName.ToLower()).CurrentPrice;
            }
            else throw new StockExchangeException("StockNameDoesntExists");
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (IndexExists(inIndexName) == false)
            {
                if (inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
                {
                    Index index = new Index(inIndexName, inIndexType);
                    _indices.Add(index);
                }
                else throw new StockExchangeException("inIndexType NotValid");
            }
            else throw new StockExchangeException("SameNameAlreadyExists");
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) == true)
            {
                if (StockExists(inStockName) == true)
                {
                    _indices.FirstOrDefault(i => i.IndexName.ToLower() == inIndexName.ToLower()).IndexStocks.Add(inStockName);
                    _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower()).AssignedToIndex = true;
                }
                else throw new StockExchangeException("StockNameDoesntExists");
            }
            else throw new StockExchangeException("IndexNameDoesntExists");
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) == true)
            {
                if (StockExists(inStockName) == true)
                {
                    _indices.FirstOrDefault(i => i.IndexName.ToLower() == inIndexName.ToLower()).IndexStocks.Remove(inStockName);
                    _stocks.FirstOrDefault(s => s.StockName.ToLower() == inStockName.ToLower()).AssignedToIndex = false;
                }
                else throw new StockExchangeException("StockNameDoesntExists");
            }
            else throw new StockExchangeException("IndexNameDoesntExists");
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (IndexExists(inIndexName) == true)
            {
                if (StockExists(inStockName) == true)
                {
                    return
                        _indices.FirstOrDefault(i => i.IndexName.ToLower() == inIndexName.ToLower())
                                .IndexStocks.Exists(s => s.ToString() == inStockName);
                }
                else throw new StockExchangeException("StockNameDoesntExists");
            }
            else throw new StockExchangeException("IndexNameDoesntExists");
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal indexValue = 0;
            if (IndexExists(inIndexName) == true)
            {
                Index index = _indices.FirstOrDefault(i => i.IndexName.ToLower() == inIndexName.ToLower());

                switch (index.IndexType)
                {
                    case IndexTypes.AVERAGE:
                        decimal priceSum = 0;
                        foreach (string stockName in index.IndexStocks)
                        {
                            priceSum = priceSum + GetStockPrice(stockName, inTimeStamp);
                        }
                        indexValue = priceSum / index.IndexStocks.Count;
                        break;

                    case IndexTypes.WEIGHTED:
                        decimal totalIndexStockValue = 0;
                        foreach (string stockName in index.IndexStocks)
                        {
                            Stock stock = _stocks.FirstOrDefault(s => s.StockName.ToLower() == stockName.ToLower());
                            totalIndexStockValue = totalIndexStockValue + GetStockPrice(stockName, inTimeStamp) * stock.NumberOfShares;
                        }
                        foreach (string stockName in index.IndexStocks)
                        {
                            decimal singleIndexStockValue = 0;
                            Stock stock = _stocks.FirstOrDefault(s => s.StockName.ToLower() == stockName.ToLower());
                            singleIndexStockValue = GetStockPrice(stockName, inTimeStamp) / totalIndexStockValue;
                            indexValue = indexValue + singleIndexStockValue * stock.CurrentPrice * stock.NumberOfShares;
                        }
                        break;
                }
            }
            else throw new StockExchangeException("IndexNameDoesntExists");
            return Convert.ToDecimal(string.Format("{0:0.000}", indexValue));
        }

        public bool IndexExists(string inIndexName)
        {
            return _indices.Exists(s => s.IndexName.ToLower() == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (IndexExists(inIndexName) == true)
            {
                return
                        _indices.FirstOrDefault(i => i.IndexName.ToLower() == inIndexName.ToLower())
                                .IndexStocks.Count;
            }
            else throw new StockExchangeException("IndexNameDoesntExists");
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID) == false)
            {
                Portfolio portfolio = new Portfolio(inPortfolioID);
                _portfolios.Add(portfolio);
            }
            else throw new StockExchangeException("SameIDAlreadyExists");
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) == true)
            {
                if (StockExists(inStockName))
                {
                    if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == false)
                    {
                        _portfolios.FirstOrDefault(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower()).PortfolioStocks.Add(new PortfolioStock(inStockName, numberOfShares));
                    }
                    else
                    {
                        _portfolios.FirstOrDefault(
                            p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                                   .PortfolioStocks.FirstOrDefault(
                                       ps => ps.StockName.ToLower() == inStockName.ToLower()).NumberOfShares += numberOfShares;
                    }
                }
                else throw new StockExchangeException("StockDosentExists");
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (PortfolioExists(inPortfolioID) == true)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == true)
                {
                    int StockNumberOfShares = 0;
                    StockNumberOfShares = _portfolios.FirstOrDefault(
                        p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                                                .PortfolioStocks.FirstOrDefault(
                                                    ps => ps.StockName.ToLower() == inStockName.ToLower()).NumberOfShares;
                    if (StockNumberOfShares < numberOfShares)
                    {
                        RemoveStockFromPortfolio(inPortfolioID, inStockName);
                    }
                    else
                    {
                        _portfolios.FirstOrDefault(
                            p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                                   .PortfolioStocks.FirstOrDefault(
                                       ps => ps.StockName.ToLower() == inStockName.ToLower()).NumberOfShares -= numberOfShares;
                    }

                }
                else throw new StockExchangeException("StockDosentExists");
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) == true)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == true)
                {
                    PortfolioStock portfolioStock = _portfolios.FirstOrDefault(
                        p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                                                   .PortfolioStocks.FirstOrDefault(
                                                       ps => ps.StockName.ToLower() == inStockName);
                    _portfolios.FirstOrDefault(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                               .PortfolioStocks.Remove(portfolioStock);
                }
                else throw new StockExchangeException("StockDosentExists");
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID) == true)
            {
                return
                    _portfolios.FirstOrDefault(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                               .PortfolioStocks.Count;
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return _portfolios.Exists(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower());
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID.ToLower()) == true)
            {
                return _portfolios.FirstOrDefault(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                           .PortfolioStocks.Exists(ps => ps.StockName.ToLower() == inStockName.ToLower());
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (PortfolioExists(inPortfolioID) == true)
            {
                if (IsStockPartOfPortfolio(inPortfolioID, inStockName) == true)
                {
                    return _portfolios.FirstOrDefault(
                        p => p.PortfolioID.ToLower() == inPortfolioID.ToLower())
                                      .PortfolioStocks.FirstOrDefault(
                                          ps => ps.StockName.ToLower() == inStockName.ToLower()).NumberOfShares;
                }
                else throw new StockExchangeException("StockDosentExists");
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal portfolioValue = 0;
            if (PortfolioExists(inPortfolioID) == true)
            {
                foreach (PortfolioStock ps in _portfolios.FirstOrDefault(p => p.PortfolioID.ToLower() == inPortfolioID.ToLower()).PortfolioStocks)
                {
                    portfolioValue = portfolioValue + (GetStockPrice(ps.StockName, timeStamp) * ps.NumberOfShares);
                }
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
            return Convert.ToDecimal(string.Format("{0:0.000}", portfolioValue)); ;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            decimal portfolioPercentChange = 0;

            if (PortfolioExists(inPortfolioID) == true)
            {
                decimal portfolioStartValue = 0;
                decimal portfolioEndValue = 0;

                portfolioStartValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 1, 00, 00, 00, 000));
                portfolioEndValue = GetPortfolioValue(inPortfolioID, new DateTime(Year, Month, 30, 23, 59, 59, 999));
                portfolioPercentChange = ((portfolioEndValue / portfolioStartValue) - 1) * 100;
            }
            else throw new StockExchangeException("PortfolioIDDosentExists");
            return Convert.ToDecimal(string.Format("{0:0.000}", portfolioPercentChange)); ;
        }
    }

    public class Stock
    {
        public string StockName;
        public long NumberOfShares;
        public decimal InitialPrice;
        public decimal CurrentPrice;
        public DateTime TimeStamp;
        public bool AssignedToIndex;
        public List<StockPriceHistoryEntry> PriceHistory;

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            this.StockName = inStockName;
            this.NumberOfShares = inNumberOfShares;
            this.InitialPrice = inInitialPrice;
            this.TimeStamp = inTimeStamp;
            this.CurrentPrice = this.InitialPrice;
            this.AssignedToIndex = false;

            PriceHistory = new List<StockPriceHistoryEntry>();
            PriceHistory.Add(new StockPriceHistoryEntry(inInitialPrice, inTimeStamp));
        }
    }

    public class StockPriceHistoryEntry
    {
        public decimal StockPrice;
        public DateTime TimeStamp;

        public StockPriceHistoryEntry(decimal inStockPrice, DateTime inTimeStamp)
        {
            this.StockPrice = inStockPrice;
            this.TimeStamp = inTimeStamp;
        }
    }

    public class Index
    {
        public string IndexName;
        public IndexTypes IndexType;
        public List<string> IndexStocks;

        public Index(string inIndexName, IndexTypes inIndexType)
        {
            this.IndexName = inIndexName;
            this.IndexType = inIndexType;
            IndexStocks = new List<string>();
        }
    }

    public class Portfolio
    {
        public string PortfolioID;
        public List<PortfolioStock> PortfolioStocks;

        public Portfolio(string inPortfolioID)
        {
            this.PortfolioID = inPortfolioID;
            PortfolioStocks = new List<PortfolioStock>();
        }
    }
    public class PortfolioStock
    {
        public string StockName;
        public int NumberOfShares;

        public PortfolioStock(string inStockName, int numberOfShares)
        {
            this.StockName = inStockName;
            this.NumberOfShares = numberOfShares;
        }
    }
}
