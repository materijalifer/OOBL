﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        static string operand;
        static string memory;
        public static Stack<String> stack;
        static PossibleState currentState;
        Display calcDisplay = new Display();
        static char[] binaryOperators = { '+', '-', '*', '/' };
        static char[] unaryOperators = {'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G'};

        public Kalkulator()
        {
            operand = "0";
            memory = "";
            stack = new Stack<string>();
            currentState = PossibleState.InitialState;
            calcDisplay.UpdateDisplay("0");
        }

        public static string Memory
        {
            get { return memory; }
            set { memory = value; }
        }

        public static PossibleState CurrentState
        {
            get { return currentState; }
            set { currentState = value; }
        }

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit == 'O')
            {
                calcDisplay.UpdateDisplay("0");
                operand = "0";
                stack.Clear();
                currentState = PossibleState.InitialState;
            }
            else if (inPressedDigit == 'C')
            {
                operand = "0";
                calcDisplay.UpdateDisplay("0");
            }
            else if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',')
            {
                processDigit(inPressedDigit);
            }
            else if (binaryOperators.Contains<char>(inPressedDigit))
            {
                processBinaryOperation(inPressedDigit);
            }
            else if (unaryOperators.Contains<char>(inPressedDigit))
            {
                processUnaryOperation(inPressedDigit);
            }
            else if (inPressedDigit == '=')
            {
                if (stack.Count == 2)
                {
                    char operation_char = char.Parse(stack.Pop());
                    stack.Push(operand);
                    Operation operation = Operation.createOperation(operation_char);
                    operation.Execute(stack);
                    operand = stack.Pop();
                    calcDisplay.UpdateDisplay(operand);
                }
            }
        }

        private void processUnaryOperation(char inPressedDigit)
        {
            stack.Push(operand);
            Operation operation = Operation.createOperation(inPressedDigit);
            try
            {
                operation.Execute(stack);
                operand = stack.Pop();
                calcDisplay.UpdateDisplay(operand);
            }
            catch (Exception e)
            {
                calcDisplay.UpdateDisplay("-E-");
            }
        }

        private static void processBinaryOperation(char inPressedDigit)
        {
            if (stack.Count == 0)
            {
                stack.Push(operand);
                currentState = PossibleState.SecondInitialState;
                stack.Push(inPressedDigit.ToString());

            }
            else if (currentState == PossibleState.SecondInputState)
            {
                char operation_char = char.Parse(stack.Pop());
                stack.Push(operand);
                Operation operation = Operation.createOperation(operation_char);
                operation.Execute(stack);
                currentState = PossibleState.SecondInitialState;
                stack.Push(inPressedDigit.ToString());

            }
            else if (currentState == PossibleState.FirstInputState || currentState == PossibleState.SecondInitialState)
            {
                string stack_top = stack.Peek();
                if (binaryOperators.Contains<char>(stack_top[0]) && stack_top.Length == 1)
                {
                    stack.Pop();
                    stack.Push(inPressedDigit.ToString());
                }
            }
        }

        private void processDigit(char inPressedDigit)
        {
            if (currentState == PossibleState.InitialState)
            {
                operand = inPressedDigit.ToString();
                if (inPressedDigit != '0')
                {
                    currentState = PossibleState.FirstInputState;
                }
            }
            else if (currentState == PossibleState.SecondInitialState)
            {
                operand = inPressedDigit.ToString();
                if (inPressedDigit != '0')
                {
                    currentState = PossibleState.SecondInputState;
                }
            }
            else
            {
                operand += inPressedDigit;
            }
            calcDisplay.UpdateDisplay(operand);
        }

        public string GetCurrentDisplayState()
        {
            return calcDisplay.GetDisplay();
        }

        
    }
    public enum PossibleState
    {
        InitialState,
        SecondInitialState,
        FirstInputState,
        SecondInputState
    }

    abstract class Operation
    {
        public abstract void Execute(Stack<String> stack);

        public static Operation createOperation(char operation)
        {
            var dictionary = new Dictionary<char, Operation>
            {
                {'+', new Add()},
                {'-', new Subtract()},
                {'*', new Multiply()},
                {'/', new Divide()},
                {'S', new Sine()},
                {'K', new Cosine()},
                {'Q', new Square()},
                {'R', new SquareRoot()},
                {'T', new Tangens()},
                {'I', new Inverse()},
                {'M', new SignChange()},
                {'P', new MemorySave()},
                {'G', new MemoryGet()}
            };
            return dictionary[operation];
        }
    }

    abstract class UnaryOperation : Operation
    {
        public override void Execute(Stack<String> stack)
        {
            String value = Kalkulator.stack.Pop();
            Kalkulator.stack.Push(executeUnary(value));
        }

        public abstract String executeUnary(String value);
    }

    abstract class BinaryOperation : Operation
    {
        public override void Execute(Stack<String> stack)
        {
            double value2 = double.Parse(Kalkulator.stack.Pop());
            double value1 = double.Parse(Kalkulator.stack.Pop());
            Kalkulator.stack.Push(executeBinary(value1, value2));
        }

        public abstract String executeBinary(double value1, double value2);
    }


    class MemorySave : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            Kalkulator.Memory = value;
            return value;
        }
    }

    class MemoryGet : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return Kalkulator.Memory;
        }
    }

    class Add : BinaryOperation
    {
        public override string executeBinary(double value1, double value2)
        {
            double result;
            result = value1 + value2;
            return result.ToString();
        }
    }

    class Subtract : BinaryOperation
    {
        public override string executeBinary(double value1, double value2)
        {
            double result;
            result = value1 - value2;
            return result.ToString();
        }
    }

    class Multiply : BinaryOperation
    {
        public override string executeBinary(double value1, double value2)
        {
            double result;
            result = value1 * value2;
            return result.ToString();
        }
    }

    class Divide : BinaryOperation
    {
        public override string executeBinary(double value1, double value2)
        {
            double result;
            result = value1 / value2;
            return result.ToString();
        }
    }

    class Sine : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return String.Format("{0:0.#########;-0.#########}", Math.Sin(double.Parse(value)));
        }
    }

    class Cosine : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return String.Format("{0:0.#########;-0.#########}", Math.Cos(double.Parse(value)));
        }
    }

    class Tangens : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return String.Format("{0:#.#########;-#.#########}", Math.Tan(double.Parse(value)));
        }
    }

    class Square : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return Math.Pow(double.Parse(value), 2).ToString();
                
        }
    }

    class SquareRoot : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            return Math.Sqrt(double.Parse(value)).ToString();

        }
    }

    class SignChange : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            if (value[0] == '-')
            {
                value = value.Remove(0, 1);
            }
            else
            {
                value = '-' + value;
            }
            return value;
        }
    }

    class Inverse : UnaryOperation
    {
        public override string executeUnary(string value)
        {
            decimal new_value = decimal.Parse(value);
            new_value = 1 / new_value;
            return new_value.ToString();
        }
    }


    class Display
    {
        string displayText;

        const int MAX_DIGITS = 10;

        bool displayDecimal = false;

        public bool DisplayDecimal
        {
            set { displayDecimal = value; }
        }

        public void UpdateDisplay(string displayString)
        {
            CheckDisplayValue(ref displayString);
            displayText = displayString;
        }

        public string GetDisplay()
        {
            return displayText;
        }

        private void CheckDisplayValue(ref string checkString)
        {
            if (checkString == "")
            {
                return;
            }
            if (displayDecimal == true && !checkString.Contains(','))
            {
                checkString = checkString + ",0";
                displayDecimal = false;
            }
            if (checkString[0] == ',')
            {
                checkString = "0" + checkString;
            }

            if (checkString.Length > 2 && checkString.Substring(checkString.Length - 2, 2) == ",0")
            {
                checkString = checkString.Substring(0, checkString.Length - 2);
            }
            else if (checkString.Contains(',') && checkString.Contains('-') && checkString.Length > MAX_DIGITS + 2)
            {
                checkString = checkString.Substring(0, MAX_DIGITS + 2);
            }
            else if (!checkString.Contains(',') && checkString.Length > MAX_DIGITS)
            {
                checkString = "-E-";
                return;
            }
            else if (checkString.Contains(',') && !checkString.Contains('-') && checkString.Length > MAX_DIGITS + 1)
            {
                checkString = checkString.Substring(0, MAX_DIGITS + 1);
            }
            else if (!checkString.Contains(',') && checkString.Length > MAX_DIGITS)
            {
                checkString = checkString.Substring(0, MAX_DIGITS);
            }
            if (!checkString.Contains('-') && !checkString.Contains(',') && checkString.Length > MAX_DIGITS)
            {
                checkString = "-E-";
                return;

            }
            return;
        }
    }
}