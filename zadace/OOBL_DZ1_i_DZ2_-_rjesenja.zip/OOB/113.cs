﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock>     stockList;
        private List<Index>     indexList;
        private List<Portfolio> portfolioList;

        public StockExchange()
        {
            stockList     = new List<Stock>();
            indexList     = new List<Index>();
            portfolioList = new List<Portfolio>();
        }

        /*
         *   Stock
         */

        private Stock GetStockByName(string inStockName)
        {
            if (!StockExists(inStockName))  
                throw new StockExchangeException(string.Format("Stock '{0}' doesn't exist", inStockName));

            return stockList.Where(i => i.Name.ToLower() == inStockName.ToLower()).First();
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                if (StockExists(inStockName))
                    throw new StockExchangeException(string.Format("Stock '{0}' exists", inStockName));

                stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            catch (StockExchangeException) { throw; }
        }

        public void DelistStock(string inStockName)
        {
            try
            {
                indexList.ForEach(i => 
                { 
                    if (i.ContainsStock(GetStockByName(inStockName))) 
                        i.RemoveStock(GetStockByName(inStockName));  
                });

                portfolioList.ForEach(p =>
                {
                    if (p.StockExists(GetStockByName(inStockName)))
                        p.RemoveStock(GetStockByName(inStockName));
                });

                stockList.Remove(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public bool StockExists(string inStockName)
        {
            return stockList.Exists(s => s.Name.ToLower() == inStockName.ToLower());
        }

        public int NumberOfStocks()
        {
            return stockList.Count();
        }

        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            try
            {
                GetStockByName(inStockName).AddStockPrice(inTimeStamp, inStockValue);
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                return GetStockByName(inStockName).GetStockPrice(inTimeStamp);
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            try
            {
                return GetStockByName(inStockName).GetInitialPrice();
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            try
            {
                return GetStockByName(inStockName).GetLastPrice();
            }
            catch (StockExchangeException) { throw; }
        }

        /*
         *   Index
         */

        private Index GetIndexByName(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException(string.Format("Index '{0}' doesn't exist", inIndexName));

            return indexList.Where(i => i.Name.ToLower() == inIndexName.ToLower()).First();
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            try
            {
                if (IndexExists(inIndexName))
                    throw new StockExchangeException(string.Format("Index '{0}' exists", inIndexName));
            
                indexList.Add(IndexFactory.GetInstance().CreateIndex(inIndexName, inIndexType));
            }
            catch (StockExchangeException) { throw; }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                GetIndexByName(inIndexName).AddStock(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try
            {
                GetIndexByName(inIndexName).RemoveStock(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                return GetIndexByName(inIndexName).ContainsStock(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                return GetIndexByName(inIndexName).Calculate(inTimeStamp);
            }
            catch (StockExchangeException) { throw; }
        }

        public bool IndexExists(string inIndexName)
        {
            return indexList.Exists(i => i.Name.ToLower() == inIndexName.ToLower());
        }

        public int NumberOfIndices()
        {
            return indexList.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            try
            {
                return GetIndexByName(inIndexName).StockCount();
            }
            catch (StockExchangeException) { throw; }
        }

        /*
         *   Portfolio
         */

        private Portfolio GetPortfolioByID(string inPortfolioID)
        {
            if(!PortfolioExists(inPortfolioID))
                throw new StockExchangeException(string.Format("Portfolio '{0}' doesn't exist", inPortfolioID));

            return portfolioList.Where(p => p.ID == inPortfolioID).First();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if(PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio '{0}' exists");

            portfolioList.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                GetStockByName(inStockName).SubtractShares(numberOfShares);
                GetPortfolioByID(inPortfolioID).AddStock(GetStockByName(inStockName), numberOfShares);
            }
            catch (StockExchangeException) { throw; }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            try
            {
                GetStockByName(inStockName).AddShares(numberOfShares);

                GetPortfolioByID(inPortfolioID).RemoveStock(GetStockByName(inStockName), numberOfShares);
            }
            catch (StockExchangeException) { throw; }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                int numberOfShares = GetPortfolioByID(inPortfolioID).RemoveStock(GetStockByName(inStockName));

                GetStockByName(inStockName).AddShares(numberOfShares);
            }
            catch (StockExchangeException) { throw; }
        }

        public int NumberOfPortfolios()
        {
            return portfolioList.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try
            {
                return GetPortfolioByID(inPortfolioID).StockCount();
            }
            catch (StockExchangeException) { throw; }
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            return portfolioList.Exists(p => p.ID == inPortfolioID);
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                return GetPortfolioByID(inPortfolioID).StockExists(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                return GetPortfolioByID(inPortfolioID).GetNumberOfSockShares(GetStockByName(inStockName));
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            try
            {
                return GetPortfolioByID(inPortfolioID).GetPortfolioValue(timeStamp);
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            try
            {
                return GetPortfolioByID(inPortfolioID).GetPortfolioPercentChangeInValueForMonth(Year, Month);
            }
            catch (StockExchangeException) { throw; }
        }
    }

    public class Stock
    {
        private const int ROUND_FACTOR = 3;

        string   name;
        long     maxShares;
        long     availableShares;
        Dictionary<DateTime, decimal> stockPrices;

        public Stock(string name, long numberOfShares, decimal inInitialPrice, DateTime timeStamp)
        {
            if (inInitialPrice < 0)
                throw new StockExchangeException(string.Format("New stock value = '{0}' is negative", inInitialPrice));
            
            this.name            = name;
            this.maxShares       = numberOfShares;
            this.availableShares = numberOfShares;

            this.stockPrices     = new Dictionary<DateTime, decimal>();

            stockPrices.Add(timeStamp, inInitialPrice);
        }

        public string   Name            { get { return name;            } }
        public long     AvailableShares { get { return availableShares; } }

        public void AddStockPrice(DateTime timeStamp, decimal price)
        {
            try
            {
                if (price < 0)
                    throw new StockExchangeException(string.Format("New stock value = '{0}' is negative", price));
                stockPrices.Add(timeStamp, price);
            }
            catch (ArgumentException)
            {
                throw new StockExchangeException(string.Format("Key timestamp = '{0}' exists", timeStamp));
            }
            catch (StockExchangeException) { throw; }
        }

        public decimal GetStockPrice(DateTime timeStamp)
        {
            try
            {
                DateTime key = stockPrices.Keys.OrderBy(k => k).Where(k => k <= timeStamp).Max();
                
                return Decimal.Round(stockPrices[key], ROUND_FACTOR);
            }
            catch (InvalidOperationException)
            {
                throw new StockExchangeException(string.Format("Price isn't defined for timeStamp '{0}", timeStamp));
            }
        }

        public decimal GetInitialPrice()
        {
            return Decimal.Round(stockPrices[stockPrices.Keys.Min()], ROUND_FACTOR);
        }

        public decimal GetLastPrice()
        {
            return Decimal.Round(stockPrices[stockPrices.Keys.Max()], ROUND_FACTOR);
        }

        public decimal GetTotalValue(DateTime timeStamp)
        {
            try
            {
                return Decimal.Round(GetStockPrice(timeStamp) * maxShares, ROUND_FACTOR);
            }
            catch (StockExchangeException) { throw; }
        }

        public void SubtractShares(int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException(string.Format("Can't subtrack '{0}' shares", numberOfShares));

            if (AvailableShares < numberOfShares)
                throw new StockExchangeException(string.Format("Can't give {0} shares, only {1} avliable", numberOfShares, availableShares));

            availableShares -= numberOfShares;
        }

        public void AddShares(int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException(string.Format("Can't add '{0}' shares", numberOfShares));

            if (AvailableShares + numberOfShares > maxShares)
                throw new StockExchangeException(string.Format("Can't retrive {0} shares, total '{1}', stock has max {2} shares", numberOfShares, numberOfShares + availableShares , maxShares));

            availableShares += numberOfShares;
        }
    }

    public class IndexFactory
    {
        private static IndexFactory instance;

        private IndexFactory()
        { }

        public static IndexFactory GetInstance()
        {
            if (instance == null)
                instance = new IndexFactory();

            return instance;
        }

        public Index CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE :
                    return new AverageIndex(inIndexName);
                case IndexTypes.WEIGHTED :
                    return new WeightedIndex(inIndexName);
                default :
                throw new StockExchangeException(string.Format("Index type '{0}' doesn't exist", inIndexType));
            }
        }
    }

    public abstract class Index
    {
        protected const int ROUND_FACTOR = 3;

        protected string name;
        protected List<Stock> stockList;
    
        public Index(string inIndexName)
        {
            this.name = inIndexName;

            stockList = new List<Stock>();
        }

        public string Name { get { return name; } }

        public void AddStock(Stock stock)
        {
            if (ContainsStock(stock))
                throw new StockExchangeException(string.Format("Index '{0}' contains stock '{1}'", name, stock.Name));
            
            stockList.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            stockList.Remove(stock);
        }

        public bool ContainsStock(Stock stock)
        {
            return stockList.Exists(s => s.Name.ToLower() == stock.Name.ToLower());
        }

        public int StockCount()
        {
            return stockList.Count();
        }

        abstract public decimal Calculate(DateTime inTimeStamp);
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string inIndexName)
            : base(inIndexName)
        { }

        public override decimal Calculate(DateTime inTimeStamp)
        {
            try
            {
                return Decimal.Round(stockList.Average(s => s.GetTotalValue(inTimeStamp)), ROUND_FACTOR);
            }
            catch (StockExchangeException) { throw; }
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string inIndexName)
            : base(inIndexName)
        { }

        public override decimal Calculate(DateTime inTimeStamp)
        {
            try
            {
                decimal totalIndexValue = stockList.Sum(s => s.GetTotalValue(inTimeStamp));

                return Decimal.Round(stockList.Sum(s => s.GetTotalValue(inTimeStamp) * s.GetStockPrice(inTimeStamp) / totalIndexValue), ROUND_FACTOR);
            }
            catch (StockExchangeException) { throw; }
        }
    }

    public class Portfolio
    {
        private const int ROUND_FACTOR = 3;

        string id;
        Dictionary<Stock, int> stockList;

        public Portfolio(string inPortfolioID)
        {
            id = inPortfolioID;

            stockList = new Dictionary<Stock, int>();
        }

        public string ID { get { return id; } }

        public int StockCount()
        {
            return stockList.Count;
        }

        public void AddStock(Stock stock, int numberOfShares)
        {
            if (StockExists(stock))
            {
                stockList[stock] +=  numberOfShares;
            }
            else
            {
                stockList.Add(stock, numberOfShares);
            }
        }

        public void RemoveStock(Stock stock, int numberOfShares)
        {
            if (!StockExists(stock))
                throw new StockExchangeException(string.Format("Stock '{0}' doesn't exist in portfolio '{1}'", stock.Name, id));

            if (numberOfShares > stockList[stock])
                throw new StockExchangeException(string.Format("Can't remove '{0}' shares when only '{1}' shares exists in portfolio '{2}'", numberOfShares, stockList[stock], id));

            stockList[stock] -= numberOfShares;

            if (stockList[stock] == 0)
                RemoveStock(stock);
        }

        public int RemoveStock(Stock stock)
        {
            if(!StockExists(stock))
                throw new StockExchangeException(string.Format("Stock '{0}' doesn't exist in portfolio '{1}'", stock.Name, id));

            int numberOfShares = stockList[stock];

            stockList.Remove(stock);

            return numberOfShares;
        }

        public int GetNumberOfSockShares(Stock stock)
        {
            if (!StockExists(stock))
                throw new StockExchangeException(string.Format("Stock '{0}' doesn't exist in portfolio '{1}'", stock.Name, id));

            return stockList[stock];
        }

        public bool StockExists(Stock stock)
        {
            return stockList.Keys.Contains(stock);
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            try
            {
                return Decimal.Round(stockList.Sum(kvp => kvp.Key.GetStockPrice(timeStamp) * kvp.Value), ROUND_FACTOR);
            }
            catch (StockExchangeException) { throw; };
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int Year, int Month)
        {
            try
            {
                int lastDayOfMonth = DateTime.DaysInMonth(Year, Month);

                DateTime firstDayOfMonth = new DateTime(Year, Month, 1, 0, 0, 0);

                DateTime lastDayInMonth = new DateTime(Year, Month, lastDayOfMonth, 59, 59, 59, 999);

                decimal monthStartValue = GetPortfolioValue(firstDayOfMonth);

                decimal monthEndValue = GetPortfolioValue(lastDayInMonth);

                return decimal.Round( ( (monthEndValue - monthStartValue) / monthStartValue ) * 100, ROUND_FACTOR);
            }
            catch (StockExchangeException) { throw; }
        }
    }
}