﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        public Kalkulator()
        {
            Reset();
        }

        private string ekran { get; set; }
        private bool noviBroj { get; set; }
        private bool noviUnos { get; set; }
        private bool greska { get; set; }

        private double prviOperand { get; set; }
        private char operacija { get; set; }
        private double memorija { get; set; }

        public void Press(char inPressedDigit)
        {
            if (inPressedDigit >= '0' && inPressedDigit <= '9')
            {
                ObradiZnamenku(inPressedDigit);
            }
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        BOperacija('+');
                        break;
                    case '-':
                        BOperacija('-');
                        break;
                    case '*':
                        BOperacija('*');
                        break;
                    case '/':
                        BOperacija('/');
                        break;
                    case '=':
                        Jednako();
                        break;
                    case ',':
                        DecimalniZarez();
                        break;
                    case 'M':
                        UOperacija('M');
                        break;
                    case 'S':
                        UOperacija('S');
                        break;
                    case 'K':
                        UOperacija('K');
                        break;
                    case 'T':
                        UOperacija('T');
                        break;
                    case 'Q':
                        UOperacija('Q');
                        break;
                    case 'R':
                        UOperacija('R');
                        break;
                    case 'I':
                        UOperacija('I');
                        break;
                    case 'P':
                        StaviMemorija();
                        break;
                    case 'G':
                        DohvatiMemorija();
                        break;
                    case 'C':
                        BrisanjeEkrana();
                        break;
                    case 'O':
                        Reset();
                        break;
                }
            }
        }

        private void ObradiZnamenku(char znamenka)
        {
            if (this.ekran == "0" || this.noviUnos)
            {
                this.ekran = znamenka.ToString();
                noviBroj = true;
                noviUnos = false;
            }
            else
            {
                int max = this.ekran.Length;

                if (this.ekran.Contains('-'))
                {
                    max--;
                }

                if (this.ekran.Contains(','))
                {
                    max--;
                }
                if (max <= 10 && this.noviUnos == true)
                {
                    this.ekran = znamenka.ToString();
                    noviUnos = false;
                    noviBroj = true;
                }
                if (max < 10 && this.noviUnos == false)
                    this.ekran += znamenka;
            }
        }

        private void BOperacija(char op)
        {
            Char exOperacija = operacija;

            if (exOperacija != '?' && this.noviBroj)
            {
                Ispisi(IzracunajBOp(exOperacija));
            }

            try
            {
                double pom;
                Double.TryParse(ekran.ToString(), out pom);
                this.prviOperand = pom;
                this.ekran = pom.ToString();
                this.operacija = op;
            }
            catch
            {
                this.prviOperand = Double.NaN;
            }

            this.noviUnos = true;
            this.noviBroj = false;
        }

        private void UOperacija(char op)
        {
            double broj = 0;
            double rez = 0;

            try
            {
                broj = Convert.ToDouble(ekran);
            }
            catch 
            {
                Ispisi(Double.NaN);
            }

            switch (op)
            {
                case 'M':
                    rez = -broj;
                    break;
                case 'S':
                    rez = Math.Sin(broj);
                    break;
                case 'K':
                    rez = Math.Cos(broj);
                    break;
                case 'T':
                    rez = Math.Tan(broj);
                    break;
                case 'Q':
                    rez = Math.Pow(broj, 2);
                    break;
                case 'R':
                    rez = Math.Pow(broj, 0.5);
                    break;
                case 'I':
                    rez = 1 / broj;
                    break;
                default:
                    rez = broj;
                    break;
            }

            Ispisi(rez);
        }

        private double IzracunajBOp(char op)
        {
            double drugiOperand = 0;

            try
            {
                drugiOperand = Convert.ToDouble(this.ekran);
            }
            catch
            {
                return Double.NaN;
            }

            double rez = 0;

            switch (op)
            {
                case '+':
                    rez = this.prviOperand + drugiOperand;
                    break;
                case '-':
                    rez = this.prviOperand - drugiOperand;
                    break;
                case '*':
                    rez = this.prviOperand * drugiOperand;
                    break;
                case '/':
                    rez = this.prviOperand / drugiOperand;
                    break;
                default:
                    break;
            }

            this.prviOperand = 0;
            this.operacija = '?';

            return rez;
        }

        private void Ispisi(double rez)
        {
            if (Double.IsNaN(rez) || Double.IsInfinity(rez))
            {
                Greska();
            }
            else
            {
                    long cijeliBroj = Math.Abs((long)rez);
                    int brZnamenki = rez.ToString().Length;
                    int brZnamenkiIspredTocke = cijeliBroj.ToString().Length;

                    if (brZnamenki > 10)
                    {

                        if (rez.ToString().Contains(',') && brZnamenkiIspredTocke < 10)
                        {
                            rez = Math.Round(rez, 10 - brZnamenkiIspredTocke);
                            this.ekran = rez.ToString();
                        }
                        else
                        {
                            Greska();
                        }
                    }
                    else
                    {
                        this.ekran = rez.ToString();
                    }
            }
        }

        private void Jednako()
        {
            if (this.operacija != '?')
            {
                Ispisi(IzracunajBOp(this.operacija));
            }
            else
            {
                try
                {
                    double rezultat = 0;
                    Double.TryParse(ekran.ToString(), out rezultat);
                    this.ekran = rezultat.ToString();
                }
                catch
                {
                    Greska();
                }
            }
        }

        private void DecimalniZarez()
        {
            if (!this.ekran.Contains(',') && !noviUnos)
            {
                this.ekran += ",";
            }
        }

        private void StaviMemorija()
        {
            try
            {
                memorija = Convert.ToDouble(ekran);
            }
            catch 
            {
                memorija = 0;
            }
        }

        private void DohvatiMemorija()
        {
            Ispisi(memorija);
        }

        private void BrisanjeEkrana()
        {
            ekran = "0";
            greska = false;
        }

        private void Greska()
        {
            this.ekran = "-E-";
            this.greska = true;
        }

        private void Reset()
        {
            this.ekran = "0";
            this.memorija = 0;
            this.prviOperand = 0;
            this.operacija = '?';
            this.noviBroj = false;
            this.noviUnos = false;
            this.greska = false;
        }

        public string GetCurrentDisplayState()
        {
            return this.ekran;
        }
    }


}
