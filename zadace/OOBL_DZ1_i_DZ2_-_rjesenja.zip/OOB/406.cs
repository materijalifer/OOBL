﻿using System;
using System.Globalization;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private decimal memorizedNumber;
        private decimal firstOperand;
        private decimal displayedNumber;
        private bool startNextNumber;
        private bool nextDigitIsDecimal;
        private bool displayError;
        private Func<decimal, decimal, decimal> opetation;
 
        public void Press(char inPressedDigit)
        {

            if (Char.IsDigit(inPressedDigit))
            {
                if (startNextNumber)
                {
                    startNextNumber = false;
                    displayedNumber = 0;
                }
                decimal newDigit = decimal.Parse(inPressedDigit.ToString());
                newDigit = (displayedNumber >= 0 ? newDigit : -newDigit);
                if (displayedNumber.TotalNumberOfdigits() < 10)
                {
                    if (nextDigitIsDecimal)
                    {
                        int decimalPlaces = displayedNumber.NumberOfDigitsAfterDecimal();
                        
                        displayedNumber = displayedNumber + newDigit / (decimal)Math.Pow(10, decimalPlaces + 1);
                    }
                    else
                    {
                        displayedNumber = displayedNumber * 10 + newDigit;
                    }
                }
            }
            else
            {
                try
                {
                    nextDigitIsDecimal = false;
                    switch (inPressedDigit.ToString())
                    {
                        case "+":
                            ExecuteBasicOperation();
                            opetation = (a, b) => a + b;
                            break;
                        case "-":
                            ExecuteBasicOperation();
                            opetation = (a, b) => a - b;
                            break;
                        case "*":
                            ExecuteBasicOperation();
                            opetation = (a, b) => a * b;
                            break;
                        case "/":
                            ExecuteBasicOperation();
                            opetation = (a, b) => a / b;
                            break;

                        case "=":
                            if (opetation != null)
                            {
                                displayedNumber = opetation(firstOperand, displayedNumber).FormatNumber();
                            }
                            startNextNumber = true;
                            break;
                        case ",":
                            nextDigitIsDecimal = true;
                            break;
                        case "M":
                            displayedNumber = -displayedNumber;
                            break;
                        case "S":
                            displayedNumber = ((decimal)Math.Sin((double)displayedNumber)).FormatNumber();
                            break;
                        case "K":
                            displayedNumber = ((decimal)Math.Cos((double)displayedNumber)).FormatNumber();
                            break;
                        case "T":
                            displayedNumber = ((decimal)Math.Tan((double)displayedNumber)).FormatNumber();
                            break;
                        case "Q":
                            displayedNumber = (displayedNumber * displayedNumber).FormatNumber();
                            break;
                        case "R":
                            displayedNumber = ((decimal)Math.Sqrt((double)displayedNumber)).FormatNumber();
                            break;
                        case "I":
                            displayedNumber = (1 / displayedNumber).FormatNumber();
                            break;
                        case "P": // put
                            memorizedNumber = displayedNumber;
                            break;
                        case "G": // get
                            displayedNumber = memorizedNumber;
                            break;
                        case "C": // Clear
                            displayError = false;
                            displayedNumber = 0;
                            break;
                        case "O":
                            displayError = false;
                            displayedNumber = 0;
                            firstOperand = 0;
                            memorizedNumber = 0;
                            break;
                    }
                }
                catch (Exception)
                {
                    displayError = true;
                    firstOperand = 0;
                    displayedNumber = 0;
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            if (displayedNumber.NumberOfDigitsBeforeDecimal() > 10 || displayError) return "-E-";
            return displayedNumber.ToString(CultureInfo.GetCultureInfo("hr-HR"));
        }

        private void ExecuteBasicOperation()
        {
            if (opetation != null && startNextNumber == false)
            {
                displayedNumber = opetation(firstOperand, displayedNumber).FormatNumber();
            }
            firstOperand = displayedNumber;
            startNextNumber = true;
        }
    }

    public static class HelperClass
    {
        public static int NumberOfDigitsBeforeDecimal(this decimal number)
        {
            return Math.Truncate(Math.Abs(number)).ToString(CultureInfo.GetCultureInfo("hr-HR")).Length;
        }

        public static int NumberOfDigitsAfterDecimal(this decimal number)
        {
            int count = BitConverter.GetBytes(decimal.GetBits(number.RemoveTailingZeroes())[3])[2];
            return count;
        }

        public static int TotalNumberOfdigits(this decimal number)
        {
            return number.NumberOfDigitsBeforeDecimal() + number.NumberOfDigitsAfterDecimal();
        }

        public static decimal RemoveTailingZeroes(this decimal number)
        {
            return number / 1.000000000000000000000000000000000m;
        }

        public static decimal FormatNumber(this decimal number)
        {
            int decimalsLeft = 10 - NumberOfDigitsBeforeDecimal(number);
            return Math.Round(number.RemoveTailingZeroes(), decimalsLeft);
        }
    }
}
