﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private List<Stock> _stocks = new List<Stock>(); //stock -> quantity
        private List<Index> _indices = new List<Index>();
        private List<Portfolio> _portfolios=new List<Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if(inNumberOfShares <= 0)
                throw new StockExchangeException("Broj dionica mora biti veći od 0!");
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    throw new StockExchangeException("Dionica već postoji na burzi!");
                }
            }
            _stocks.Add(new Stock(inStockName, inTimeStamp, inInitialPrice, inNumberOfShares));
        }

        public void DelistStock(string inStockName)
        {
            Stock toDelete = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {   
                    toDelete = stock;
                }
            }
            if (toDelete != null)
            {
                _stocks.Remove(toDelete);
                foreach (var portfolio in _portfolios)
                {
                    portfolio.RemoveStockFromPortfolio(toDelete);
                }
                foreach (var index in _indices)
                {
                    index.RemoveStock(toDelete);
                }
            }
            else
                throw new StockExchangeException("Dionica se ne može izbrisati s burze jer tamo ni ne postoji!");
        }

        public bool StockExists(string inStockName)
        {
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return _stocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if(!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stock.AddPrice(inIimeStamp,inStockValue);
                }
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            decimal price = 0;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    price = stock.GetStockPrice(inTimeStamp);
                }
            }
            return price;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            decimal price = 0;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    price = stock.GetInitialStockPrice();
                }
            }
            return price;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            decimal price = 0;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    price = stock.GetLastStockPrice();
                }
            }
            return price;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            _indices.Add(IndexFactory.CreateIndex(inIndexName,inIndexType));
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if(!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            if(!IndexExists(inIndexName))
                throw new StockExchangeException("Index ne postoji!");
            Stock stockToAdd = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToAdd = stock;
                }
            }
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    index.AddStock(stockToAdd);
                }
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index ne postoji!");
            Stock stockToRemove = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToRemove = stock;
                }
            }
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    index.RemoveStock(stockToRemove);
                }
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index ne postoji!");
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    return index.IsStockPartOfIndex(inStockName);
                }
            }
            return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index ne postoji!");
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    return index.GetIndexValue(inTimeStamp);
                }
            }
            return 0;
        }

        public bool IndexExists(string inIndexName)
        {
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }

        public int NumberOfIndices()
        {
            return _indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Index ne postoji!");
            foreach (var index in _indices)
            {
                if (index.Name.ToLower().Equals(inIndexName.ToLower()))
                {
                    return index.NumberOfStocks();
                }
            }
            return 0;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio već postoji!");
            _portfolios.Add(new Portfolio(inPortfolioID));
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if(numberOfShares <= 0)
                throw new StockExchangeException("Broj dionica mora biti veći od 0!");
            if(!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            Stock stockToAdd = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToAdd = stock;
                }
            }
            foreach (var portfolio in _portfolios)
            {
                 if (portfolio.Id.Equals(inPortfolioID))
                     portfolio.AddStockToPortfolio(stockToAdd,numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares <= 0)
                throw new StockExchangeException("Broj dionica mora biti veći od 0!");
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            Stock stockToRemove = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToRemove = stock;
                }
            }
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    portfolio.RemoveStockFromPortfolio(stockToRemove, numberOfShares);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            Stock stockToRemove = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToRemove = stock;
                }
            }
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    portfolio.RemoveStockFromPortfolio(stockToRemove);
            }
        }

        public int NumberOfPortfolios()
        {
            return _portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return portfolio.NumberOfStocksInPortfolio();
            }
            return 0;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return true;
            }
            return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if(!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return portfolio.IsStockPartOfPortfolio(inStockName);
            }
            return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji!");
            Stock stockToCount = null;
            foreach (var stock in _stocks)
            {
                if (stock.Name.ToLower().Equals(inStockName.ToLower()))
                {
                    stockToCount = stock;
                }
            }
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return portfolio.NumberOfSharesOfStockInPortfolio(stockToCount);
            }
            return 0;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return portfolio.GetPortfolioValue(timeStamp);
            }
            return 0;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfolio ne postoji!");
            foreach (var portfolio in _portfolios)
            {
                if (portfolio.Id.Equals(inPortfolioID))
                    return portfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
            }
            return 0;
        }
    }


    public class Stock
    {
        public string Name { get; private set; }
        public long NumberOfShares { get; set; }
        public Dictionary<DateTime, Decimal> Prices{ get; private set; } //date -> price
        public long NumberOfSharesInPortfolios { get; set; }

        public Stock(string name, DateTime time, Decimal price, long inNumberOfShares)
        {
            if(price<=0)
                throw new StockExchangeException("Cijena dionice ne može biti manja ili jednaka 0!");
            if(inNumberOfShares<=0)
                throw new StockExchangeException("Broj dionica ne može biti manji ili jednak 0!");
            Name = name;
            Prices = new Dictionary<DateTime, Decimal> { { time, price } };
            NumberOfShares = inNumberOfShares;
            NumberOfSharesInPortfolios = 0;
        }

        public void AddPrice(DateTime inIimeStamp, Decimal inStockValue)
        {
            if(inStockValue <= 0)
                throw new StockExchangeException("Cijena dionice ne može biti manja ili jednaka 0!");
            try
            {
                Prices.Add(inIimeStamp, inStockValue);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Nije moguće unijeti više od jednog zapisa cijena za određeni trenutak!");
            }
        }

        public Decimal GetStockPrice(DateTime inTimeStamp)
        {
            if (Prices.Count == 1)
                if (Prices.ElementAt(0).Key.CompareTo(inTimeStamp) <= 0)
                    return Prices.ElementAt(0).Value;
            for (int i = 1; i < Prices.Count; i++)
            {
                if (Prices.ElementAt(i - 1).Key.CompareTo(inTimeStamp) <= 0 &&
                    Prices.ElementAt(i).Key.CompareTo(inTimeStamp) > 0)
                {
                    return Prices.ElementAt(i - 1).Value;
                }
                else if (Prices.ElementAt(i).Key.CompareTo(inTimeStamp) <= 0)
                {
                    return Prices.ElementAt(i).Value;
                }
            }
            return 0;
        }

        public Decimal GetInitialStockPrice()
        {
            DateTime min = DateTime.MaxValue;
            foreach (KeyValuePair<DateTime, Decimal> value in Prices)
            {
                if (value.Key < min)
                    min = value.Key;
            }
            return Prices[min];
        }

        public Decimal GetLastStockPrice()
        {
            DateTime max = DateTime.MinValue;
            foreach (KeyValuePair<DateTime, Decimal> value in Prices)
            {
                if (value.Key > max)
                    max = value.Key;
            }
            return Prices[max];
        }
    }


    public static class IndexFactory
    {
        public static Index CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if(inIndexType == IndexTypes.AVERAGE)
                return new AverageIndex(inIndexName);
            else if (inIndexType == IndexTypes.WEIGHTED)
                return new WeightedIndex(inIndexName);
            else
                throw new StockExchangeException("Nepostojeći tip indeksa!");
        }
    }

    public abstract class Index
    {
        public string Name { get; private set; }

        internal readonly List<Stock> Stocks;

        protected Index(string name)
        {
            Name = name;
            Stocks=new List<Stock>();
        }

        public abstract Decimal GetIndexValue(DateTime inTimeStamp);

        public void AddStock(Stock stock)
        {
            foreach (Stock existingStock in Stocks)
            {
                if(stock.Name.ToLower().Equals(existingStock.Name.ToLower()))
                    throw new StockExchangeException("Dionica se ne može dodati jer već postoji u ovom indeksu!");
            }
            Stocks.Add(stock);
        }

        public void RemoveStock(Stock stock)
        {
            int index = -1;
            for (int i = 0; i < Stocks.Count; i++)
            {
                if (stock.Name.ToLower().Equals(Stocks[i].Name.ToLower()))
                    index = i;
            }
            try
            {
                Stocks.RemoveAt(index);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Dionica se ne može izbrisati iz indeksa jer u njemu ne postoji");
            }
        }

        public bool IsStockPartOfIndex(string inStockName)
        {
            foreach (Stock existingStock in Stocks)
            {
                if (inStockName.ToLower().Equals(existingStock.Name.ToLower()))
                    return true;
            }
            return false;
        }

        public int NumberOfStocks()
        {
            return Stocks.Count;
        }
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string name) : base(name){}

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (Stocks.Count == 0)
                return 0;

            Decimal sum = 0;
            foreach (var stock in Stocks)
            {
                sum += stock.GetStockPrice(inTimeStamp);
            }
            sum /= Stocks.Count;
            return Math.Round(sum,3);
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string name) : base(name) { }

        public override Decimal GetIndexValue(DateTime inTimeStamp)
        {
            if (Stocks.Count == 0)
                return 0;
 
            Decimal sum = 0;
            Decimal total = 0;
            foreach (var stock in Stocks)
                sum += stock.NumberOfShares*stock.GetStockPrice(inTimeStamp);
            if(sum==0)
                throw new StockExchangeException("Neispravno vrijeme!");
            foreach (var stock in Stocks)
                total += stock.GetStockPrice(inTimeStamp)*stock.NumberOfShares*stock.GetStockPrice(inTimeStamp)/sum;

            return Math.Round(total, 3);
        }
    }


    public class Portfolio
    {
        public string Id { get; private set; }
        public Dictionary<Stock, long> Stocks { get; private set; } //stock -> quantity

        public Portfolio(string id)
        {
            Id = id;
            Stocks = new Dictionary<Stock, long>();
        }

        public void AddStockToPortfolio(Stock stock, int numberOfShares)
        {
            if (stock.NumberOfShares - stock.NumberOfSharesInPortfolios == 0)
                throw new StockExchangeException("Traženih dionica nema na raspolaganju!");

            long numberToAdd = numberOfShares;
            if (stock.NumberOfShares - stock.NumberOfSharesInPortfolios < numberOfShares)
            {
                throw new StockExchangeException("Nema dovoljno dionica na raspolaganju!");
            }

            foreach (KeyValuePair<Stock, long> keyVal in Stocks)
            {
                if (keyVal.Key.Name.ToLower().Equals(stock.Name.ToLower()))
                {
                    Stocks[keyVal.Key] = keyVal.Value + numberToAdd;
                    stock.NumberOfSharesInPortfolios += numberToAdd;
                    return;
                }
            }
            stock.NumberOfSharesInPortfolios += numberToAdd;
            Stocks.Add(stock, numberToAdd);
        }

        public void RemoveStockFromPortfolio(Stock stock, int numberOfShares)
        {
            long toRemove = numberOfShares;
            if (Stocks[stock] < numberOfShares)
            {
                toRemove = Stocks[stock];
                Stocks.Remove(stock);
            }
            else if (numberOfShares == Stocks[stock])
            {
                Stocks.Remove(stock);
                stock.NumberOfSharesInPortfolios -= toRemove;
            }
            else
            {
                stock.NumberOfSharesInPortfolios -= toRemove;
                Stocks[stock] -= toRemove;
            }
        }

        public void RemoveStockFromPortfolio(Stock stock)
        {
            stock.NumberOfSharesInPortfolios = 0;
            Stocks.Remove(stock);
        }

        public bool IsStockPartOfPortfolio(string inStockName)
        {
            foreach (KeyValuePair<Stock, long> keyVal in Stocks)
            {
                if (keyVal.Key.Name.ToLower().Equals(inStockName.ToLower()))
                    return true;
            }
            return false;
        }

        public int NumberOfStocksInPortfolio()
        {
            return Stocks.Count;
        }

        public int NumberOfSharesOfStockInPortfolio(Stock stock)
        {
            return (int)Stocks[stock];
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            Decimal value = 0;
            foreach (KeyValuePair<Stock, long> keyVal in Stocks)
            {
                value += keyVal.Key.GetStockPrice(timeStamp)*keyVal.Value;
            }
            return Math.Round(value, 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
        {
            var beginning = new DateTime(year,month,1,0,0,0);
            var end = new DateTime(year, month, DateTime.DaysInMonth(year, month),23,59,59,999);

            decimal value = (GetPortfolioValue(end)-GetPortfolioValue(beginning))/GetPortfolioValue(beginning)*100;
            return Math.Abs(Math.Round(value, 3));
        }
    }

}
