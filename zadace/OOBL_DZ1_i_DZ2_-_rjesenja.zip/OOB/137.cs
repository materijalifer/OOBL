﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> stockList = new Dictionary<string, Stock>(new CustomComparer());
        private Dictionary<string, Index> indices = new Dictionary<string, Index>(new CustomComparer());
        private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (StockExists(inStockName))
                throw new StockExchangeException("Dionica vec postoji");
            if (inInitialPrice <= 0)
                throw new StockExchangeException("Krivi unos cijene");
            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stockList.Add(inStockName, stock);
            foreach (Index index in indices.Values)
            {
                if (index.Stocks.ContainsKey(inStockName))
                    index.Stocks.Remove(inStockName);
            }
            foreach (Portfolio portfolio in portfolios.Values)
            {
                if (portfolio.Stocks.ContainsKey(inStockName))
                    portfolio.Stocks.Remove(inStockName);
            }
        }

        public void DelistStock(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            stockList.Remove(inStockName);
        }

        public bool StockExists(string inStockName)
        {
            return stockList.ContainsKey(inStockName);
        }

        public int NumberOfStocks()
        {
            return stockList.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            Stock stock = stockList[inStockName];
            if (stock.Prices.ContainsKey(inIimeStamp))
                throw new StockExchangeException("Cijena za trenutak je vec definirana");
            if (inStockValue <= 0)
                throw new StockExchangeException("Krivi unos cijene");
            stock.Prices.Add(inIimeStamp, inStockValue);
            stockList[inStockName] = stock;
            foreach (Index index in indices.Values)
            {
                if (index.Stocks.ContainsKey(inStockName))
                    index.Stocks[inStockName] = stock;
            }
            foreach (Portfolio portfolio in portfolios.Values)
            {
                if (portfolio.Stocks.ContainsKey(inStockName))
                    portfolio.Stocks[inStockName] = stock;
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            DateTime currentTimestamp = new DateTime(0);
            foreach (DateTime timestamp in stockList[inStockName].Prices.Keys)
            {
                if (timestamp > currentTimestamp && timestamp <= inTimeStamp)
                {
                    currentTimestamp = timestamp;
                }
            }
            return Math.Round(stockList[inStockName].Prices[currentTimestamp], 3);
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            return Math.Round(stockList[inStockName].InitialPrice, 3);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            if (!StockExists(inStockName))
                throw new StockExchangeException("Dionica ne postoji");
            DateTime lastTimestamp = new DateTime(0);
            foreach (DateTime ts in stockList[inStockName].Prices.Keys)
            {
                if (ts > lastTimestamp)
                {
                    lastTimestamp = ts;
                }
            }
            return Math.Round(stockList[inStockName].Prices[lastTimestamp], 3);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            Index index;
            switch (inIndexType)
            {
                case IndexTypes.AVERAGE:
                    index = new AverageIndex(inIndexName);
                    indices.Add(inIndexName, index);
                    break;
                case IndexTypes.WEIGHTED:
                    index = new WeightedIndex(inIndexName);
                    indices.Add(inIndexName, index);
                    break;
                default:
                    throw new StockExchangeException("Vrsta indeksa ne postoji");
            }
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName) || !IndexExists(inIndexName))
                throw new StockExchangeException("Dionica/indeks ne postoji");
            if (indices[inIndexName].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica vec postoji u indeksu");
            indices[inIndexName].Stocks.Add(inStockName, stockList[inStockName]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName) || !IndexExists(inIndexName))
                throw new StockExchangeException("Dionica/indeks ne postoji");
            if (!indices[inIndexName].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica/indeks ne postoji");
            indices[inIndexName].Stocks.Remove(inStockName);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if (!StockExists(inStockName) || !IndexExists(inIndexName))
                throw new StockExchangeException("Dionica/indeks ne postoji");
            if (indices[inIndexName].Stocks.ContainsKey(inStockName))
                return true;
            else
                return false;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Indeks ne postoji");
            return Math.Round(indices[inIndexName].getValue(inTimeStamp), 3);
        }

        public bool IndexExists(string inIndexName)
        {
            if (indices.ContainsKey(inIndexName))
                return true;
            else
                return false;
        }

        public int NumberOfIndices()
        {
            return indices.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            if (!IndexExists(inIndexName))
                throw new StockExchangeException("Indeks ne postoji");
            return indices[inIndexName].Stocks.Count;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj vec postoji");
            Portfolio portfolio = new Portfolio(inPortfolioID);
            portfolios.Add(inPortfolioID, portfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Portfelj/dionica ne postoji");
            if (numberOfShares <= 0)
                return;
            if (portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                portfolios[inPortfolioID].Stocks[inStockName].NumberOfShares += numberOfShares;
            else
            {
                Stock stock = stockList[inStockName];
                stock.NumberOfShares = numberOfShares;
                portfolios[inPortfolioID].Stocks.Add(inStockName, stock);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Portfelj/dionica ne postoji");
            if (!portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica nije u portfelju");
            portfolios[inPortfolioID].Stocks[inStockName].NumberOfShares -= numberOfShares;
            if (portfolios[inPortfolioID].Stocks[inStockName].NumberOfShares <= 0)
            {
                portfolios[inPortfolioID].Stocks.Remove(inStockName);
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Portfelj/dionica ne postoji");
            if (!portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica nije u portfelju");
            portfolios[inPortfolioID].Stocks.Remove(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            return portfolios[inPortfolioID].Stocks.Count;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            if (portfolios.ContainsKey(inPortfolioID))
                return true;
            else
                return false;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Portfelj/dionica ne postoji");
            if (!portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica nije u portfelju");
            if (portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                return true;
            else
                return false;
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName))
                throw new StockExchangeException("Portfelj/dionica ne postoji");
            if (!portfolios[inPortfolioID].Stocks.ContainsKey(inStockName))
                throw new StockExchangeException("Dionica nije u portfelju");
            return (int)portfolios[inPortfolioID].Stocks[inStockName].NumberOfShares;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            return Math.Round(portfolios[inPortfolioID].getValue(timeStamp), 3);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj ne postoji");
            DateTime startTimestamp = new DateTime(Year, Month, 1, 0, 0, 0, 0);
            DateTime endTimestamp = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
            DateTime startOfMonthTimestamp;
            DateTime endOfMonthTimestamp;
            decimal startValue = 0;
            decimal endValue = 0;
            foreach (Stock stock in portfolios[inPortfolioID].Stocks.Values)
            {
                try
                {
                    startOfMonthTimestamp = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
                    endOfMonthTimestamp = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                    foreach (DateTime ts in stock.Prices.Keys)
                    {
                        if (ts < startOfMonthTimestamp && ts >= startTimestamp)
                        {
                            startOfMonthTimestamp = ts;
                        }
                        if (ts > endOfMonthTimestamp && ts <= endTimestamp)
                        {
                            endOfMonthTimestamp = ts;
                        }
                    }
                    startValue += stock.NumberOfShares * stock.Prices[startOfMonthTimestamp];
                    endValue += stock.NumberOfShares * stock.Prices[endOfMonthTimestamp];
                }
                catch
                {
                    throw new StockExchangeException("");
                }
            }
            return Math.Round((endValue - startValue) / startValue, 3) * 100;
        }
    }

    class CustomComparer : IEqualityComparer<string>
    {
        public bool Equals(string x, string y)
        {
            return x.Equals(y, StringComparison.CurrentCultureIgnoreCase);
        }

        public int GetHashCode(string obj)
        {
            return obj.GetHashCode();
        }
    }


    public class Stock
    {
        private string name;

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        private long numberOfShares;

        public long NumberOfShares
        {
            get
            {
                return numberOfShares;
            }
            set
            {
                numberOfShares = value;
            }
        }
        private Dictionary<DateTime, decimal> prices = new Dictionary<DateTime, decimal>();

        public Dictionary<DateTime, decimal> Prices
        {
            get
            {
                return prices;
            }
            set
            {
                prices = value;
            }
        }
        private decimal initialPrice;

        public decimal InitialPrice
        {
            get
            {
                return initialPrice;
            }
            set
            {
                initialPrice = value;
            }
        }

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            name = inStockName;
            numberOfShares = inNumberOfShares;
            prices.Add(inTimeStamp, inInitialPrice);
            initialPrice = inInitialPrice;
        }

        public override bool Equals(object obj)
        {
            String key = (string)obj;
            return name.Equals(key, StringComparison.CurrentCultureIgnoreCase);
        }
    }

    public abstract class Index
    {
        protected string name;

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        protected Dictionary<string, Stock> stocks = new Dictionary<string, Stock>(new CustomComparer());

        public Dictionary<string, Stock> Stocks
        {
            get
            {
                return stocks;
            }
            set
            {
                stocks = value;
            }
        }

        public abstract decimal getValue(DateTime timestamp);

        public override bool Equals(object obj)
        {
            String key = (string)obj;
            return name.Equals(key, StringComparison.CurrentCultureIgnoreCase);
        }
    }

    public class AverageIndex : Index
    {
        private IndexTypes type = IndexTypes.AVERAGE;

        public IndexTypes Type
        {
            get
            {
                return IndexTypes.AVERAGE;
            }
        }

        public AverageIndex(string inIndexName)
        {
            name = inIndexName;
        }

        public override decimal getValue(DateTime timestamp)
        {
            decimal sum = 0;
            foreach (Stock stock in stocks.Values)
            {
                sum += stock.NumberOfShares * stock.Prices[timestamp];
            }
            return sum / stocks.Count;
        }
    }

    public class WeightedIndex : Index
    {
        private IndexTypes type = IndexTypes.WEIGHTED;

        public IndexTypes Type
        {
            get
            {
                return IndexTypes.WEIGHTED;
            }
        }

        public WeightedIndex(string inIndexName)
        {
            name = inIndexName;
        }

        public override decimal getValue(DateTime timestamp)
        {
            decimal totalWeightFactor = 0;
            decimal totalPrice = 0;
            DateTime currentTimestamp = new DateTime(0);
            try
            {
                foreach (Stock stock in stocks.Values)
                {
                    currentTimestamp = new DateTime(0);
                    foreach (DateTime ts in stock.Prices.Keys)
                    {
                        if (ts > currentTimestamp && ts <= timestamp)
                        {
                            currentTimestamp = ts;
                        }
                    }
                    totalPrice += stock.NumberOfShares * stock.Prices[currentTimestamp];
                }
                foreach (Stock stock in stocks.Values)
                {
                    currentTimestamp = new DateTime(0);
                    foreach (DateTime ts in stock.Prices.Keys)
                    {
                        if (ts > currentTimestamp && ts <= timestamp)
                        {
                            currentTimestamp = ts;
                        }
                    }
                    totalWeightFactor += stock.Prices[currentTimestamp] * ((stock.NumberOfShares * stock.Prices[currentTimestamp]) / totalPrice);
                }
            }
            catch
            {
                throw new StockExchangeException("");
            }
            return totalWeightFactor;
        }
    }

    public class Portfolio
    {
        private string ID;

        public string PortfolioID
        {
            get
            {
                return ID;
            }
            set
            {
                ID = value;
            }
        }

        private Dictionary<string, Stock> stocks;

        public Dictionary<string, Stock> Stocks
        {
            get
            {
                return stocks;
            }
            set
            {
                stocks = value;
            }
        }

        public Portfolio(string id)
        {
            stocks = new Dictionary<string, Stock>(new CustomComparer());
            ID = id;
        }

        public decimal getValue(DateTime timestamp)
        {
            decimal value = 0;
            DateTime currentTimestamp = new DateTime(0);
            foreach (Stock stock in stocks.Values)
            {
                currentTimestamp = new DateTime(0);
                foreach (DateTime ts in stock.Prices.Keys)
                {
                    if (ts > currentTimestamp && ts <= timestamp)
                    {
                        currentTimestamp = ts;
                    }
                }
                value += stock.NumberOfShares * stock.Prices[currentTimestamp];
            }
            return value;
        }
    }
}
