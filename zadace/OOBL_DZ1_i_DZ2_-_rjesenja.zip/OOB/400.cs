﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        //============ VARIABLES ===============================================//

        public string display = "0";
        public string memory = "";
        public string ans = "";

        public string[] numbers = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        public string[] operators = { "+", "-", "*", "/", "=", "M", "Q", "R",
                                          "I", "S", "K", "T", "P", "G", ","};
        public string[] systemOperators = { "C", "O" };
        public string[] binaryOperators = { "+", "-", "*", "/" };
        public string[] directOperators = { "Q", "R", "I", "S", "K", "T" };
        public string[] input = { "", "", "", "" };

        public int counter = 1;
        public int index = 1;

        //======================================================================//


        public void Press(char inPressedDigit)
        {
            string inputDigit;
            inputDigit = inPressedDigit.ToString();

            if (!numbers.Contains(inputDigit) && !operators.Contains(inputDigit) && !systemOperators.Contains(inputDigit))
            {
                Error();
                return;
            }

            if (display.Equals("-E-") || input[0].Equals("-E-"))
            {
                if (!inputDigit.Equals('C') && !inputDigit.Equals('O'))
                    return;
            }

            if (systemOperators.Contains(inputDigit))
            {
                InputDigitIsSystemOperator(inputDigit);
            }

            if (operators.Contains(inputDigit))
            {
                InputDigitIsOperator(inputDigit);
            }

            if (numbers.Contains(inputDigit))
            {
                InputDigitIsNumber(inputDigit);
            }
        }

        public void ResetCalc()
        {
            display = "0";
            memory = "0";
            for (int i = 0; i < input.Length; i++)
                input[i] = "";
        }

        public void Error()
        {
            display = "-E-";
            input[0] = "-E-";
        }

        public string Calculate(string o1, string o2, string oper)
        {

            double operand1;
            double operand2;

            operand1 = double.Parse(o1);
            operand2 = double.Parse(o2);

            if (oper.Equals("-"))
                operand1 = operand1 - operand2;

            if (oper.Equals("+"))
                operand1 = operand1 + operand2;

            if (oper.Equals("*"))
                operand1 = operand1 * operand2;

            if (oper.Equals("/"))
                operand1 = operand1 / operand2;

            ans = operand1.ToString();
            display = ans;
            CheckDisplay();
            return ans;
        }

        public string Round(string number, int dec)
        {
            double roundedNumber;
            int k = number.IndexOf(",");

            roundedNumber = double.Parse(number);
            number = Math.Round(roundedNumber, dec - k - 1).ToString();

            return number;
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }

        public void CheckDisplay()
        {
            double tmp = double.Parse(display);
            if (display.Contains("-") && display.Contains(","))
            {
                if (tmp < -999999999999)
                    Error();
                display = Round(display, 12);
            }

            if (display.Contains("-") && !display.Contains(","))
            {
                if (tmp < -99999999999)
                    Error();
                display = Round(display, 11);
            }

            if (!display.Contains("-") && display.Contains(","))
            {
                if (tmp > 99999999999)
                    Error();
                display = Round(display, 11);
            }

            if (!display.Contains("-") && !display.Contains(","))
            {
                if (tmp > 9999999999)
                    Error();
            }

            //if (display.Length > 12)
            //{
            //    if (display.Contains("-") && display.Contains(","))
            //        display = Round(display, 12);
            //    if ((display.Contains("-") && !display.Contains(","))
            //        || (!display.Contains("-") && display.Contains(",")))
            //        display = Round(display, 11);
            //}
            //if ((display.Length > 10) && !display.Contains("-") && !display.Contains(","))
            //    display = Round(display, 10);
        }

        public void InputDigitIsSystemOperator(string inputDigit)
        {
            if (inputDigit.Equals("O"))
                ResetCalc();

            if (inputDigit.Equals("C"))
            {
                ClearCalc();
                return;
            }
        }

        public void InputDigitIsOperator(string inputDigit)
        {
            if (!inputDigit.Equals("="))
                input[0] = inputDigit;

            if ((input[index].Contains(",")) && (input[index].EndsWith("0")))
            {
                input[index] = CheckDecimal(input[index]);
                display = input[index];
            }

            if ((input[index].Contains(",")) && (input[index].IndexOf(",").Equals(input[index].Length - 1)))
            {
                input[index] = input[index].Substring(0, input[index].Length - 1);
                display = input[index];

            }

            if (inputDigit.Equals(","))
            {
                if (display.Contains(","))
                    input[index + 2] += inputDigit;

                else
                {
                    display += inputDigit;
                    input[index] = display;
                    counter++;
                }
            }

            if (inputDigit.Equals("M"))
            {
                if (display[0].Equals('-'))
                {
                    display = display.Substring(1);
                    input[index] = input[index].Substring(1);
                    counter--;
                }

                else
                {
                    display = "-" + display;
                    input[index] = "-" + input[index];
                    counter++;
                }
            }

            if (counter > 12)
            {
                if (input[index].Contains("-") && input[index].Contains(","))
                    Round(input[index], 12);
                if ((input[index].Contains("-") && !input[index].Contains(","))
                    || (!input[index].Contains("-") && input[index].Contains(",")))
                    Round(input[index], 11);
            }

            if (inputDigit.Equals("="))
            {
                if (input[1].Equals("") && input[2].Equals(""))
                    display = "0";
                if (input[2].Equals("") && directOperators.Contains(input[0]) && numbers.Contains(display))
                    input[1] = Calculate(input[1], display, input[3]);

                else
                {

                    if ((!input[2].Equals("")) && !(input[3].Equals("")) && !(input[3].Equals("=")))
                        input[1] = Calculate(input[1], input[2], input[3]);

                    if ((!input[2].Equals("")) && !(input[3].Equals("")) && input[3].Equals("="))
                        input[1] = Calculate(input[1], input[2], input[0]);

                    if (input[2].Equals("") && !input[3].Equals(""))
                    {
                        input[2] = input[1];
                        input[1] = Calculate(input[1], input[2], input[3]);
                        input[3] = inputDigit;
                    }
                    //CheckDisplay();


                }

            }

            if (!inputDigit.Equals(",") && !inputDigit.Equals("M") && !binaryOperators.Contains(inputDigit)
                && !inputDigit.Equals("="))
            {

                if (index.Equals(1) && !(directOperators.Contains(inputDigit)) && !inputDigit.Equals("P"))
                    index = 2;

                if (inputDigit.Equals("P"))
                {
                    //if (operators.Any(display.Contains) || systemOperators.Any(display.Contains))
                    //{
                    //    Error();
                    //    return;
                    //}
                    memory += display;
                    display = "0";

                }

                if (inputDigit.Equals("G"))
                {
                    display = memory;
                    input[index] += display;
                }

                if (!inputDigit.Equals("G") && !inputDigit.Equals("P"))
                {
                    if (index.Equals(2) && input[index].Equals(""))
                        index = 1;

                    double tmp;
                    tmp = double.Parse(display);

                    if (inputDigit.Equals("Q"))
                        tmp = Math.Pow(tmp, 2);
                    if (inputDigit.Equals("R"))
                        tmp = Math.Pow(tmp, 0.5);
                    if (inputDigit.Equals("S"))
                        tmp = Math.Sin(tmp);
                    if (inputDigit.Equals("K"))
                        tmp = Math.Cos(tmp);
                    if (inputDigit.Equals("T"))
                        tmp = Math.Tan(tmp);
                    if (inputDigit.Equals("I"))
                    {
                        if (tmp.Equals(0))
                        {
                            Error();
                            return;
                        }
                        else
                            tmp = 1 / tmp;
                    }
                    if ((tmp > 9999999999) && (tmp < -9999999999) || double.IsNaN(tmp))
                    {
                        Error();
                        return;
                    }
                    display = tmp.ToString();

                    if (!binaryOperators.Contains(input[3]) || index.Equals(2))
                        input[index] = tmp.ToString();

                    CheckDisplay();

                    if (index.Equals(1) && binaryOperators.Contains(input[3]))
                        index = 2;

                    if (!binaryOperators.Contains(input[3]))
                        input[3] = inputDigit;
                }
            }

            if (binaryOperators.Contains(inputDigit))
            {

                if (input[1].Equals(""))
                    input[1] = "0";

                if (input[3].Equals("=") && !inputDigit.Equals("="))
                    input[2] = "";

                if (!input[2].Equals(""))
                {
                    input[1] = Calculate(input[1], input[2], input[3]);
                    input[2] = "";
                }

                input[3] = inputDigit;
                index = 2;
                counter = 1;
            }

        }

        public void InputDigitIsNumber(string inputDigit)
        {
            if (counter.Equals(1) && display.Equals("0"))
            {
                display = inputDigit;
                input[index] = display;
                counter = 0;
            }

            if (counter.Equals(1) && !display.Equals("0"))
            {
                if (directOperators.Contains(input[3]))
                {
                    input[index] = inputDigit;
                    input[3] = "";
                    display = input[index];
                }
                else
                {
                    input[index] += inputDigit;
                    display = input[index];
                }
            }

            if ((counter > 1) && (counter < 10))
            {
                input[index] += inputDigit;
                display = input[index];
            }

            if ((counter >= 10) && (counter < 12))
            {
                if (((display.Contains("-") && display.Contains(",")) && (counter.Equals(11)))
                    || (display.Contains("-") && counter.Equals(10))
                    || (display.Contains(",") && counter.Equals(10)))
                {
                    input[index] += inputDigit;
                    display = input[index];
                }
                else
                    input[index] += inputDigit;
            }

            if ((counter >= 12) && (input[index].Contains(",")))
                input[index] += inputDigit;

            //if ((counter > 10) && (!input[index].Contains(",")))
            //    Error();

            counter++;

        }

        public void ClearCalc()
        {
            display = "0";
            input[index] = "0";
            counter = 1;
            input[0] = "";
        }

        public string CheckDecimal(string number)
        {
            int zeroAfterDec = 0;
            char[] reverseNumber = number.ToCharArray();
            //reverseNumber = reverseNumber.Reverse();
            Array.Reverse(reverseNumber);

            for (int i = 0; i < number.Length; i++)
            {
                if (!reverseNumber[i].Equals('0'))
                    break;
                zeroAfterDec++;
                if (reverseNumber[i + 1].Equals(','))
                    zeroAfterDec += 1;
            }

            number = number.Substring(0, number.Length - zeroAfterDec);

            return number;
        }

    }


}
