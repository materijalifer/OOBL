﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public delegate string Operation();

    public class Kalkulator : ICalculator
    {
        private string memory = "0";
        private string currNum = "0";
        private char prevInput;

        private bool hasErrorOccured = false;
        private bool isCurrNumberMutable = true;


        Stack<double> operands = new Stack<double>(); 
       
        private Operation binOp;              

        public void Press(char inPressedDigit)
        {            
            switch (inPressedDigit)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    updateCurrNum(inPressedDigit);
                    break;
                case ',':
                    addDecimal(inPressedDigit);
                    break;                
                case '=':
                    popCurrentNum();                    
                    doOperation();
                    break;
                case '+':
                    opPressed();
                    binOp = new Operation(addition);
                    break;
                case '-':
                    opPressed();
                    binOp = new Operation(substraction);
                    break;
                case '*':
                    opPressed();
                    binOp = new Operation(multiplication);
                    break;
                case '/':
                    opPressed();
                    binOp = new Operation(division);
                    break;                               
                case 'M':
                    currNum = minus();
                    break;
                case 'S':
                    currNum = sine();
                    break;
                case 'K':
                    currNum = cosine();
                    break;
                case 'T':
                    currNum = tangent();
                    break;
                case 'Q':
                    currNum = square();
                    break;
                case 'R':
                    currNum = root();
                    break;
                case 'I':
                    currNum = invers();
                    break;
                case 'P':
                    store();
                    break;
                case 'G':
                    getStored();
                    break;
                case 'C':
                    clear();
                    break;
                case 'O':
                    reset();
                    break;
                default:
                    break;                   
            }
            prevInput = inPressedDigit;            
        }

        private void updateCurrNum(char inPressedDigit)
        {
            if (!isCurrNumberMutable)
            {
                currNum = "0";
                isCurrNumberMutable = true;
            }
            if (currNum.Equals("0"))
            {
                if (inPressedDigit.Equals('0'))
                {
                    return;
                }                
                else
                {
                    currNum = inPressedDigit.ToString();
                }
            }
            else
            {
                if (currNum.Contains('-'))
                {

                }
                currNum += inPressedDigit.ToString();
            }
        }

        private void opPressed()
        {
            try
            {
                isCurrNumberMutable = false;
                double val = Double.Parse(currNum);
                operands.Push(val);
                if (binOp != null && !(prevInputIsOperation()))
                {
                    doOperation();
                    val = Double.Parse(currNum);
                    operands.Push(val);
                }
            }
            catch
            {
                currNum = "-E-";
            }
        }

        private void doOperation()
        {
            if (binOp != null)
            {
                currNum = binOp();
                isCurrNumberMutable = false;
                binOp = null;
            }
            else
            {
                currNum = checkCurrNum(Double.Parse(currNum));                
            }
        }

        private bool prevInputIsOperation()
        {
            if (prevInput == '+' || prevInput == '-' || prevInput == '*' || prevInput == '/')
                return true;
            return false;
        }

        private void addDecimal(char inPressedDigit)
        {
            if (currNum.Contains(inPressedDigit))
            {                
                return;
            }
            else
            {
                isCurrNumberMutable = true;
                currNum = currNum + inPressedDigit.ToString();
            }
        }

        private void popCurrentNum()
        {            
            try
            {
                isCurrNumberMutable = false;
                double val = Double.Parse(currNum);
                operands.Push(val);                
            }
            catch
            {
                currNum = "-E-";
            }
        }

        public string GetCurrentDisplayState()
        {            
            if (hasErrorOccured)
            {
                return "-E-";
            }
            else
            {
                return currNum;
            }
        }       

        #region Binary operations
        private string addition()
        {
            double fOperand, sOperand;
            getBinaryOperands(out fOperand, out sOperand);
            double result = fOperand + sOperand;
            return checkCurrNum(result);
        }

        private string substraction()
        {
            double fOperand, sOperand;
            getBinaryOperands(out fOperand, out sOperand);
            double result = fOperand - sOperand;
            return checkCurrNum(result);
        }

        private string multiplication()
        {
            double fOperand, sOperand;
            getBinaryOperands(out fOperand, out sOperand);
            double result = fOperand * sOperand;
            return checkCurrNum(result);
        }

        private string division()
        {
            double fOperand, sOperand;
            getBinaryOperands(out fOperand, out sOperand);
            double result = fOperand / sOperand;
            return checkCurrNum(result);
        }

        private void getBinaryOperands(out double fOperand, out double sOperand)
        {
            sOperand = operands.Pop();
            fOperand = operands.Pop();
        }
        #endregion

        #region Unary operations
        private string minus()
        {            
            double operand;
            isCurrNumberMutable = true;
            operand = Double.Parse(currNum);
            operand = -operand;
            return checkCurrNum(operand);            
        }

        private string sine()
        {
            double operand;            
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand = Math.Sin(operand);
            return checkCurrNum(operand);
        }

        private string cosine()
        {
            double operand;           
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand = Math.Cos(operand);
            return checkCurrNum(operand);
        }

        private string tangent()
        {
            double operand;           
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand =  Math.Tan(operand);
            return checkCurrNum(operand);
        }

        private string square()
        {
            double operand;            
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand = Math.Pow(operand, 2);
            return checkCurrNum(operand);
        }

        private string root()
        {
            double operand;            
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand = Math.Sqrt(operand);
            return checkCurrNum(operand);
        }

        private string invers()
        {
            double operand;
            isCurrNumberMutable = false;
            operand = Double.Parse(currNum);
            operand = 1 / operand;
            return checkCurrNum(operand);
        }

        private void store()
        {
            memory = currNum;
        }

        private void getStored()
        {
            currNum = memory;
        }
        #endregion

        private string checkCurrNum(double result)
        { 
            if (Math.Abs(result) >= Math.Pow(10, 10))
            {
                hasErrorOccured = true;
                return "-E-";
            }
            else if (Double.IsInfinity(result) || Double.IsNaN(result))
            {
                hasErrorOccured = true;
                return "-E-";
            }
            else
            {
                string display = result.ToString("0.#########");
                if(display.Contains('-'))
                {
                    display = display.Substring(0, Math.Min(12, display.Length));
                }
                else
                {
                    display = display.Substring(0, Math.Min(11, display.Length));
                }
                return display;
            }
        }

        private void reset()
        {
            operands = new Stack<double>();
            binOp = null;
            hasErrorOccured = false;
            isCurrNumberMutable = true;
            currNum = "0";
            memory = "0";
        }

        private void clear()
        {
            currNum = "0";
        }
    }
}



