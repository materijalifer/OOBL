using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
	public class Factory
	{
		public static ICalculator CreateCalculator ()
		{
			// this is for double ',' separators
			System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
			return new Kalkulator ();
		}
	}

	public class Kalkulator : ICalculator
	{
		const char NO_OP = '\0';
		
		private bool roundOnBinaryOperator = true;
							
		private double prevOperand = 0.0;
		private double memoryOperand = 0.0;
		private char prevOperator = NO_OP;

		private StringBuilder screenStr = new StringBuilder("0");
		
		private bool zero;
		private bool dec;
		
		private bool input = false;
		private bool binop = false;
		private bool error = false;
		
		private void Init ()
		{
			prevOperand = 0.0;
			prevOperand = NO_OP;
			input = false;
			binop = false;
			error = false;
			SetNumberOnScreen(prevOperand);
		}
		
		private void CE ()
		{
			SetNumberOnScreen(0.0);
			input = false;
			binop = false;
			error = false;
		}
		
		private void StartInput ()
		{
			SetNumberOnScreen(0.0);
			
			dec = false;
			zero = true;
			
			input = true;
			binop = false;
		}
		
		private double GetNumberOnScreen ()
		{
			return Double.Parse(screenStr.ToString().Replace(',', '.'),
			                    System.Globalization.CultureInfo.InvariantCulture);
		}
		
		private void SetNumberOnScreen (double d)
		{
			if (d >= 10000000000 || Double.IsNaN(d) || Double.IsInfinity(d)) {
				screenStr.Length = 0;
				screenStr.Append("-E-");
				error = true;
				return;
			}
			
			const int placesTotal = 10;
			
			long intPart = (long)Math.Truncate(d);
			int placesInt = 1;
			if (intPart != 0) {
				placesInt += (int)Math.Floor(Math.Log10(Math.Abs(intPart)));
			}
			int placesDecimal = placesTotal - placesInt;
			
			screenStr.Length = 0;
			screenStr.Append(Math.Round(d, placesDecimal)
			                 .ToString(System.Globalization.CultureInfo.InvariantCulture)
			                 .Replace('.', ','));
			return;
		}
		
		private double FinishInput ()
		{
			input = false;
			return GetNumberOnScreen();
		}
		
		public void Press (char digit)
		{
			if (error && !"OC".Contains(digit)) {
				return;
			}
			
			switch (digit) {
				
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				if (!input) {
					StartInput();
				}
				if (zero) {
					if (digit != '0') {
						screenStr[0] = digit;
						zero = false;
					}
				} else {
					string str = screenStr.ToString();
					int numDigits = str.Length - str.Count(x => x == ',') - str.Count(x => x == '-');
					if (numDigits < 10) {
						screenStr.Append(digit);
					}
				}
				break;
				
			case ',':
				if (!input) {
					StartInput();
				}
				if (!dec) {
					screenStr.Append(',');
					zero = false;
					dec = true;
				}
				break;
				
			case 'M':
				if (input && !zero) {
					if (screenStr[0] == '-') {
						screenStr.Remove(0, 1);
					} else {
						screenStr.Insert(0, '-');
					}
				} else if (!input) {
					SetNumberOnScreen(-GetNumberOnScreen());
					prevOperator = NO_OP;
				}
				break;
				
			case '+':
			case '-':
			case '*':
			case '/': {
				double currOperand = FinishInput();
				if (!binop) {
					if (prevOperator != NO_OP) {
						prevOperand = binary[prevOperator](prevOperand, currOperand);
						if (!roundOnBinaryOperator) {
							SetNumberOnScreen(prevOperand);
						}
					} else {
						prevOperand = currOperand;
					}
					binop = true;
				}
				prevOperator = digit;
				
				if (roundOnBinaryOperator) {
					SetNumberOnScreen(prevOperand);
				}
				break;
			}
				
			case 'S':
			case 'K':
			case 'T':
			case 'R':
			case 'Q':
			case 'I': {
				double currOperand = FinishInput();
				currOperand = unary[digit](currOperand);
				
				SetNumberOnScreen(currOperand);
				break;
			}
				
			case '=': {
				double currOperand = FinishInput();
				if (prevOperator != NO_OP) {
					prevOperand = binary[prevOperator](prevOperand, currOperand);
				} else {
					prevOperand = currOperand;
				}
				
				SetNumberOnScreen(prevOperand);
				break;
			}
				
			case 'O':
				Init();
				memoryOperand = 0;
				break;
				
			case 'C':
				if (error) {
					Init();
				} else {
					CE();
				}
				break;
				
			case 'P': {
				memoryOperand = GetNumberOnScreen();
				break;
			}
				
			case 'G':
				FinishInput();
				SetNumberOnScreen(memoryOperand);
				break;
			}
			
		}

		public string GetCurrentDisplayState ()
		{
			return screenStr.ToString();
		}
		
		private static readonly Dictionary<char, Func<double, double, double>> 
			binary = new Dictionary<char, Func<double, double, double>> 
			{
				{'+', (a, b) => (a + b)},
				{'-', (a, b) => (a - b)},
				{'*', (a, b) => (a * b)},
				{'/', (a, b) => (a / b)},
			};
		private static readonly Dictionary<char, Func<double, double>> 
			unary = new Dictionary<char, Func<double, double>> 
			{
				{'S', Math.Sin       },
				{'K', Math.Cos       },
				{'T', Math.Tan       },
				{'R', Math.Sqrt      },
				{'Q', (a) => (a * a) },
				{'I', (a) => (1 / a) },
			};
	}
}