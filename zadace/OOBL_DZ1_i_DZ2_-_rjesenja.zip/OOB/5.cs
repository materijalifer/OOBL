﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        #region Fields
        private States _currentCalcState;
        private Signs _sign;
        private char _lastPressedSign;

        private readonly uint MAX_NUMBER_OF_DIGITS;

        private List<char> Buffer;
        private List<char> UnarayOpBuffer;//Za spremanje međurezultata kada se unarni rezultat odbacuje, ali prikazuje na ekranu.

        //Imamo samo dva operanda.
        //Unosom treceg prva dva se izracunavaju i postaju lijevi te memoriju.
        private double LeftOperand { get; set; }
        private double RightOperand { get; set; }
        private double Memory { get; set; } 
        #endregion

        /// <summary>
        /// Konstruktor.
        /// </summary>
        public Kalkulator()
        {
            this._currentCalcState = States.None;
            this._sign = Signs.Plus;
            this.Memory = 0;
            this.MAX_NUMBER_OF_DIGITS = 10; // Podrazumijevana vrijednost 10.
            this.Buffer = new List<char>() { '0' };
            this.UnarayOpBuffer = new List<char>();
        } 

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {      
                // Unos znamenki.
                case '0':
                    InsertZero();
                    this._lastPressedSign = inPressedDigit;
                    break;
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    InsertNumber(inPressedDigit);
                    this._lastPressedSign = inPressedDigit;
                    break;
                // Binarne aritmetičke operacije.
                case '+':
                case '-':
                case '*':
                case '/':
                    ChangeCalcState(inPressedDigit);
                    this._lastPressedSign = inPressedDigit;
                    break;
                case '=': // Izvršavanje operacije.
                    EqualSignPressed();
                    this._lastPressedSign = inPressedDigit;
                    break;
                case ',': // Unos decimalnog zareza.
                    CommaSignPressed();
                    this._lastPressedSign = inPressedDigit;
                    break;
                // Unarne operacije
                case 'M': // Promjena predznaka.
                    ChangeSignPressed();
                    this._lastPressedSign = inPressedDigit;
                    break;
                // Unarne operacije.
                // Trigonometrijske funkcije.
                case 'S': // Sinus.
                case 'K': // Kosinus.
                case 'T': // Tangens.
                    TrigonometrySignPressed(inPressedDigit);
                    break;
                //Potenciranje
                case 'Q': // Kvadriranje. x^(1/2)
                case 'R': // Korjenovanje. x^2
                case 'I': // Inverz. x^-1
                    Exponentiation(inPressedDigit);
                    break;
                // Rad sa memorijom
                case 'P': // Stavi u memoriju.
                case 'G': // Uzmi iz memorije.
                    MemorySignsPressed(inPressedDigit);
                    this._lastPressedSign = inPressedDigit;
                    break;
                // Ocisti ekran.
                case 'C':
                    ClearSignPressed();
                    this._lastPressedSign = inPressedDigit;
                    break;
                // Ukljuci/Iskljuci kalkulator.!?
                case 'O':
                    OnOffSignPressed();
                    this._lastPressedSign = inPressedDigit;
                    break;
                default:
                    // Ignoriraj pogresne unose!
                    break;
            }
            
        }
       
        // Glavne metode
        /// <summary>
        /// Dodaje nulu.
        /// </summary>
        private void InsertZero()
        {
            //Ako je stisnut jedan od binarnih operatora, prilikom unosa nove nule, sadrzaj buffera se brise.
            if (_lastPressedSign == '+' || _lastPressedSign == '-' || _lastPressedSign == '*' || _lastPressedSign == '/')
            {
                this.Buffer.Clear();
                this._sign = Signs.Plus;
            }
            //Ako imamo samo nulu u bufferu, ne dodajemo nule, inace dodaj.
            if(!(this.Buffer.Count == 1 && this.Buffer[0] == '0') && this.NumberOfDigits() < MAX_NUMBER_OF_DIGITS)
            {
                this.Buffer.Add('0');
            }
        }
        /// <summary>
        /// Dodavanje znamenki od 1 do 9.
        /// </summary>
        /// <param name="inPressedDigit"></param>
        private void InsertNumber(char inPressedDigit)
        {
            //Ako je stisnut jedan od binarnih operatora, prilikom unosa novog broja, moramo ocistiti buffer.
            if (_lastPressedSign == '+' || _lastPressedSign == '-' || _lastPressedSign == '*' || _lastPressedSign == '/')
            {
                this.Buffer.Clear();
                this._sign = Signs.Plus;
            }
            //Ako stane jos znamenki u buffer dadajemo, inace ignoriramo unos.
            if (this.NumberOfDigits() < MAX_NUMBER_OF_DIGITS)
            {
                //Ako je samo nula u bufferu, onda nova znamenka dolazi umjesto nje.
                if ((this.Buffer.Count == 1 && this.Buffer[0] == '0'))
                {
                    this.Buffer[0] = inPressedDigit;
                }
                else
                {
                    //Inace dodaj znamenku u buffer.
                    this.Buffer.Add(inPressedDigit);
                }
            }
        }
        /// <summary>
        /// Pritisak znaka za binarnu operaciju.
        /// </summary>
        /// <param name="inPressedDigit">-, +, *, /</param>
        private void ChangeCalcState(char inPressedDigit)
        {
            ClearErrorSignFromBuffer();
            if (_currentCalcState == States.None)
            {
                // Prvi put smo pritisnuli znak za binarnu operaciju 
                // i ne racuna se jos nista vec se samo sprema sadrzaj iz buffera.
                this.LeftOperand = BufferToDouble();
                this.LeftOperand *= (_sign == Signs.Minus) ? -1 : 1;
                this._sign = Signs.Plus;
            }
            else if (!(_lastPressedSign == '+' || _lastPressedSign == '-' || _lastPressedSign == '*' || _lastPressedSign == '/'))
            {
                this.RightOperand = BufferToDouble();
                this.RightOperand *= (_sign == Signs.Minus) ? -1 : 1;
                switch (this._currentCalcState)
                {
                    case States.Adding:
                        this.LeftOperand = this.LeftOperand + this.RightOperand;
                        break;
                    case States.Substracting:
                        this.LeftOperand = this.LeftOperand - this.RightOperand;
                        break;
                    case States.Multiplication:
                        this.LeftOperand = this.LeftOperand * this.RightOperand;
                        break;
                    case States.Division:
                        if (this.LeftOperand != 0)
                            this.LeftOperand = this.LeftOperand / this.RightOperand;
                        else
                            WriteErrorSignToBuffer();
                        break;
                    default:
                        // Dodati poruku o gresci!
                        break;
                }
                this._sign = this.LeftOperand < 0 ? Signs.Minus : Signs.Plus;
                this.Buffer = DoubleToBuffer(this.LeftOperand);
                ConvertBufferToLegalDisplay();
            }
            SetState(inPressedDigit);
        }
        /// <summary>
        /// Pritisak znaka jednakosti.
        /// </summary>
        private void EqualSignPressed()
        {
            ClearErrorSignFromBuffer();
            if (_currentCalcState == States.None)
            {
                ConvertBufferToLegalDisplay();
            }
            else
            {
                if(this.Buffer.Count == 0)
                {
                    switch (this._currentCalcState)
                    {
                        case States.Adding:
                            this.LeftOperand += this.LeftOperand;
                            break;
                        case States.Substracting:
                            this.LeftOperand -= this.LeftOperand;
                            break;
                        case States.Multiplication:
                            this.LeftOperand *= this.LeftOperand;
                            break;
                        case States.Division:
                            if (this.LeftOperand != 0)
                                this.LeftOperand *= this.LeftOperand;
                            else
                                WriteErrorSignToBuffer();
                            break;
                        default:
                            // Dodati poruku o gresci!
                            break;
                    }
                }
                else
                {
                    this.RightOperand = BufferToDouble();
                    this.RightOperand *= (_sign == Signs.Minus) ? -1 : 1;
                    switch (this._currentCalcState)
                    {
                        case States.Adding:
                            this.LeftOperand = this.LeftOperand + this.RightOperand;
                            break;
                        case States.Substracting:
                            this.LeftOperand = this.LeftOperand - this.RightOperand;
                            break;
                        case States.Multiplication:
                            this.LeftOperand = this.LeftOperand * this.RightOperand;
                            break;
                        case States.Division:
                            if (this.RightOperand != 0)
                                this.LeftOperand = this.LeftOperand / this.RightOperand;
                            else
                                WriteErrorSignToBuffer();
                            break;
                        default:
                            // Dodati poruku o gresci!
                            break;
                    }
                }
                this._sign = this.LeftOperand < 0 ? Signs.Minus : Signs.Plus;
                this.Buffer = DoubleToBuffer(this.LeftOperand);
                ConvertBufferToLegalDisplay();
                SetState('N');
            }
        }
        /// <summary>
        /// Dodavanje zareza.
        /// </summary>
        private void CommaSignPressed()
        {
            if (this.Buffer.Count < MAX_NUMBER_OF_DIGITS && !this.Buffer.Contains(','))
            {
                this.Buffer.Add(',');
            }
        }
        /// <summary>
        /// Promjena predznaka.
        /// </summary>
        private void ChangeSignPressed()
        {
            if(!(this.Buffer.Count == 1 && this.Buffer[0] == 0))
                this._sign = (this._sign == Signs.Plus) ? Signs.Minus : Signs.Plus;
        }
        /// <summary>
        /// Operacije sinus, kosinus, tanges.
        /// </summary>
        /// <param name="inPressedDigit">'S' - sinus, 'K' - kosinus, 'T' - Tangens.</param>
        private void TrigonometrySignPressed(char inPressedDigit)
        {
            this.ClearErrorSignFromBuffer();
            double _result = BufferToDouble();
            _result *= _sign == Signs.Minus ? -1 : 1;
            switch (inPressedDigit)
            {
                case 'S': // Sinus.
                    _result = Math.Sin(_result);
                    break;
                case 'K': // Kosinus.
                    _result = Math.Cos(_result);
                    break;
                case 'T': // Tangens.
                    _result = Math.Tan(_result);
                    break;
                default:
                    // Ovdje ne smijemo nikada doci.
                    // Dodati poruku o gresci.
                    break;
            }
            this._sign = _result < 0 ? Signs.Minus : Signs.Plus;
            if (_lastPressedSign == '+' || _lastPressedSign == '-' || _lastPressedSign == '*' || _lastPressedSign == '/')
                this.UnarayOpBuffer.AddRange(this.Buffer);
            this.Buffer = DoubleToBuffer(_result);
            ConvertBufferToLegalDisplay();

        }
        /// <summary>
        /// Operacije potenciranja, kvadriranje, korjenovanje i inverz.
        /// </summary>
        /// <param name="inPressedDigit">'Q' - kvadriranje, 'R' - korjenovanje, 'I' - inverz.</param>
        private void Exponentiation(char inPressedDigit)
        {
            this.ClearErrorSignFromBuffer();
            double _result = BufferToDouble();
            _result *= _sign == Signs.Minus ? -1 : 1;
            switch (inPressedDigit)
            {
                case 'Q': // Kvadriranje.
                    _result = Math.Pow(_result, 2);
                    break;
                case 'R': // Korjenovanje.
                    _result = Math.Sqrt(_result);
                    break;
                case 'I': // Inverz.
                    if (_result != 0)
                        _result = 1 / _result;
                    else
                        WriteErrorSignToBuffer();
                        break;
                default:
                    // Ovdje ne smijemo nikada doci.
                    // Dodati poruku o gresci.
                    break;
            }
            this._sign = _result < 0 ? Signs.Minus: Signs.Plus;
            if (inPressedDigit != 'I' || (inPressedDigit == 'I' && _result != 0))
            {
                if (_lastPressedSign == '+' || _lastPressedSign == '-' || _lastPressedSign == '*' || _lastPressedSign == '/')
                    this.UnarayOpBuffer.AddRange(this.Buffer);
                this.Buffer = DoubleToBuffer(_result);
                ConvertBufferToLegalDisplay();
            }
        }
        /// <summary>
        /// Dohvacanje i stavljanje u memoriju kalkulatora.
        /// </summary>
        /// <param name="inPressedDigit">'P' - put in memory, 'G' - get from memory.</param>
        private void MemorySignsPressed(char inPressedDigit)
        {
            ClearErrorSignFromBuffer();
            if (inPressedDigit == 'P')
            {
                Memory = BufferToDouble();
            }
            else if (inPressedDigit == 'G')
            {
                this.Buffer = DoubleToBuffer(Memory);
            }
        }
        /// <summary>
        /// Cisti ekran i postavlja nulu u buffer.
        /// </summary>
        private void ClearSignPressed()
        {
            this.Buffer.Clear();
            this.Buffer.Add('0');
        }
        /// <summary>
        /// Resetiranje cijelog kalkulatora.
        /// </summary>
        private void OnOffSignPressed()
        {
            this._currentCalcState = States.None;
            this._sign = Signs.Plus;
            this.Memory = 0;
            this.Buffer = new List<char>() { '0' };
            this.UnarayOpBuffer = new List<char>();
        }

        //Pomocne metode
        /// <summary>
        /// Stavljamo kalkulator u jedno od dopustenih stanja.
        /// </summary>
        /// <param name="inPressedDigit">'+', '-', '*', '/', 'N'</param>
        private void SetState(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case '+':
                    this._currentCalcState = States.Adding;
                    break;
                case '-':
                    this._currentCalcState = States.Substracting;
                    break;
                case '*':
                    this._currentCalcState = States.Multiplication;
                    break;
                case '/':
                    this._currentCalcState = States.Division;
                    break;

                default:
                    this._currentCalcState = States.None;
                    break;
            }
        }
        /// <summary>
        /// Prilagodba rezultata za prikaz na ekranu.
        /// </summary>
        private void ConvertBufferToLegalDisplay()
        {
            if (this.Buffer.Contains(','))
            {
                while (this.Buffer[this.Buffer.Count - 1] != ',' && this.Buffer[this.Buffer.Count - 1] == '0')
                {
                    this.Buffer.RemoveAt(this.Buffer.Count - 1);
                }
                if (this.Buffer[this.Buffer.Count - 1] == ',')
                    this.Buffer.RemoveAt(this.Buffer.Count - 1);
            }
            if (!this.Buffer.Contains(',') && this.NumberOfDigits() > MAX_NUMBER_OF_DIGITS)// Ako je cijeli broj sadrzi vise od 10 znamenki.
            {
                WriteErrorSignToBuffer();
            }
            else if (this.Buffer.Contains(',') && this.NumberOfDigits() > MAX_NUMBER_OF_DIGITS)// Ako je decimalni broj i cijeli dio ima vise od 10 znamenki pisemo gresku.
            {
                int _numberOfDigitsBeforeComma = 0, i = 0;
                //Brisemo nule na kraju ako je broj decimalan.
                while (this.Buffer[i] != ',')
                {
                    _numberOfDigitsBeforeComma++;
                    i++;
                }
                if (_numberOfDigitsBeforeComma > MAX_NUMBER_OF_DIGITS)
                {
                    WriteErrorSignToBuffer();
                }
                else if (_numberOfDigitsBeforeComma == (MAX_NUMBER_OF_DIGITS - 1))// Ako ne mozemo prikazati decimalni dio vec samo cijeli, micemo zarez, tj. ako imamo 9 znamenki cijelog dijela i zarez.
                {
                    while (this.Buffer[this.Buffer.Count - 1] != ',')
                    {
                        this.Buffer.RemoveAt(this.Buffer.Count - 1);
                    }
                    this.Buffer.RemoveAt(this.Buffer.Count - 1);
                }
                else if (_numberOfDigitsBeforeComma < (MAX_NUMBER_OF_DIGITS - 1))//Zaokruzivanje!
                {
                    RoundNumber();
                }
            }
        }

        private void RoundNumber()
        {
            int _lastNumberRemoved = 0;
            while (this.NumberOfDigits() > MAX_NUMBER_OF_DIGITS)
            {
                _lastNumberRemoved = int.Parse(this.Buffer[this.Buffer.Count - 1].ToString());
                this.Buffer.RemoveAt(this.Buffer.Count - 1);
            }
            if (_lastNumberRemoved >= 5)
            {
                if (this.Buffer[this.Buffer.Count - 1] == ',')
                    this.Buffer.RemoveAt(this.Buffer.Count - 1);
                if (this.Buffer[this.Buffer.Count - 1] < '9')
                    this.Buffer[this.Buffer.Count - 1]++;
                else// Problem kod zaokruzivanja ako su sve znamnke 9!
                { 
                    int i = this.Buffer.Count - 1;
                    while (this.Buffer[i] == '9')
                    {
                        if (this.Buffer[i] == ',') i--;
                        this.Buffer[i] = '0';
                        i--;
                    }
                    if (i == 0 && NumberOfDigits() == MAX_NUMBER_OF_DIGITS && this.Buffer[i] == '0')
                        WriteErrorSignToBuffer();
                    else
                        this.Buffer[i]++;
                }
            }
        }
        /// <summary>
        /// Prebacivanje broja u listu.
        /// </summary>
        /// <param name="_result">double</param>
        /// <returns>List of chars</returns>
        private static List<char> DoubleToBuffer(double _result)
        {
            _result *=_result < 0 ? -1 : 1;
            return new List<char>(_result.ToString().ToCharArray());
        }
        /// <summary>
        /// Prebacivanje sadrzaja liste u double broj.
        /// </summary>
        /// <returns>double</returns>
        private double BufferToDouble()
        {
            return Convert.ToDouble(new string(this.Buffer.ToArray()));
        }
        /// <summary>
        /// Brise znak greske iz buffer i stavlja u buffer 0;
        /// </summary>
        private void ClearErrorSignFromBuffer()
        {
            if (IsErrorSignInBuffer())
            {
                this.Buffer.Clear();
                this.Buffer[0] = '0';
            }
        }
        /// <summary>
        /// Vraca true ako se nalazi znak greske u bufferu.
        /// </summary>
        /// <returns>bool</returns>
        private bool IsErrorSignInBuffer()
        {
            if (this.Buffer.Count == 3 && this.Buffer[0] == '-' && this.Buffer[0] == '0' && this.Buffer[0] == '-')
                return true;
            else
                return false;
        }
        /// <summary>
        /// Zapisuje znak greske u buffer.
        /// </summary>
        private void WriteErrorSignToBuffer()
        {
            this.Buffer.Clear();
            this.Buffer.Add('-');
            this.Buffer.Add('E');
            this.Buffer.Add('-');
            this._currentCalcState = States.None;
            this._sign = Signs.Plus;
        }
        /// <summary>
        /// Broj znamenki koji se nalazi u Bufferu.
        /// </summary>
        /// <returns>uint</returns>
        private uint NumberOfDigits()
        {
            uint _numberOfDigits = 0;
            for (int i = 0; i < this.Buffer.Count; i++)
            {
                if(char.IsDigit(this.Buffer[i]))
                {
                    _numberOfDigits++;
                }
            }
            return _numberOfDigits;
        }
        /// <summary>
        /// Vraca trenutno stanje ekrana kalkulatora.
        /// </summary>
        /// <returns>string</returns>
        public string GetCurrentDisplayState()
        {
            string Display = new string(this.Buffer.ToArray());
            if (this._sign == Signs.Minus)
            {
                Display = "-" + Display;
            }
            if (UnarayOpBuffer.Count > 0)
            {
                this.Buffer.Clear();
                this.Buffer.AddRange(this.UnarayOpBuffer);
                this.UnarayOpBuffer.Clear();
            }
            return Display;
        }
      
        //Enumeracije
        /// <summary>
        /// Kalkulator moze biti u nekom od pet stanja, cekajuci na unos lijevog odnosno desnog operanda.
        /// </summary>
        private enum States { None, Adding, Substracting, Multiplication, Division }
        /// <summary>
        /// Broj moze imati biti pozitivan i negativan. Predznak (eng. sign).
        /// </summary>
        private enum Signs { Plus, Minus }
    }


}
