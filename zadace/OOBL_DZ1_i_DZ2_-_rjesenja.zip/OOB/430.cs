﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrvaDomacaZadaca_Kalkulator
{
    class Kalkulator : ICalculator
    {
        private string currentDisplay; // ono što je trenutno prikazano na zaslonu
        private string memo; // za spremanje rezultata u memoriju
        private string left; // nakon odabira operatora služi za pohranu prethodnog broja
        private string lastOperator; // služi za pomoć oko "+===="
        private string memoOpForEqual; // pomoć oko "+==="
        private double memoRightForEqual; //  pomoć oko "+==="
        private bool clearDisplay; // zastavica koja govori da je prije unesen operator i da prilikom unosa sljedećeg broja treba očistiti ekran
        private string operation; // pamti operaciju sa kojom mora dva broja izračunati, a lastOperation mi služi ====..
        private Dictionary<char, Delegate> operators = new Dictionary<char, Delegate>();

        public Kalkulator()
        {
            this.currentDisplay = "0";
            this.lastOperator = "";
            this.left = "";
            this.clearDisplay = false;
            this.operation = "";
            this.memoRightForEqual = 0;
            this.memoOpForEqual = "";

            // problem oko vraćanja vrijednosti -> ukoliko stavim da je vrijednost koju metoda vraća void -> baca error pa sam stavio da vraća prazan string
            this.operators.Add('+', new Func<string, string>(plus));
            this.operators.Add('-', new Func<string, string>(minus));
            this.operators.Add('*', new Func<string, string>(puta));
            this.operators.Add('/', new Func<string, string>(podijeljeno));
            this.operators.Add('=', new Func<string, string>(jednako));
            this.operators.Add(',', new Func<string, string>(decimalniZarez));
            this.operators.Add('M', new Func<string, string>(promjenaPredznaka));
            this.operators.Add('S', new Func<string, string>(sin));
            this.operators.Add('K', new Func<string, string>(cos));
            this.operators.Add('T', new Func<string, string>(tg));
            this.operators.Add('Q', new Func<string, string>(naKvadrat));
            this.operators.Add('R', new Func<string, string>(korijen));
            this.operators.Add('I', new Func<string, string>(inverz));
            this.operators.Add('P', new Func<string, string>(spremiUMemo));
            this.operators.Add('G', new Func<string, string>(dohvatiIzMemo));
            this.operators.Add('C', new Func<string, string>(ocistiEkran));
            this.operators.Add('O', new Func<string, string>(reset));
        }

        // vraća broj znamenaka koji se nalaze u stringu
        public int noOfDigits()
        {
            int dotIndex = currentDisplay.IndexOf(',');
            int minusIndex = currentDisplay.IndexOf('-');
            int noOfSpecials = 0;

            if (dotIndex >= 0)
                noOfSpecials++;

            if (minusIndex >= 0)   
                noOfSpecials++;

            return currentDisplay.Length - noOfSpecials;
        }

        // odluka da li može spremiti novi znak zbog ograničenja 10(brojeva)+2(predznak i decimalni zarez)
        public void addNewDigitOrNot(char inPressedDigit)
        {
            lastOperator = "";

            if (clearDisplay){
                currentDisplay = "";
                clearDisplay = false;
            }

            if (noOfDigits() < 10)
                currentDisplay += inPressedDigit;
        }

        // metoda za zaokruživanje broja ukoliko su zadovoljena pravila ili bacanje ERROR-a
        public void sizeCheck() 
        {
            if (noOfDigits() > 10 || currentDisplay.Contains("E+") || currentDisplay.Contains("E-"))
            {

                if (currentDisplay.IndexOf(',') < 0 || currentDisplay.Contains("E+") || currentDisplay.Contains("E-") || currentDisplay.IndexOf(',') > 10)
                    currentDisplay = "-E-";

                else 
                {
                    int dotIndex = currentDisplay.IndexOf(',');
                    int dotMin = 0;
                    if (currentDisplay.IndexOf('-') >= 0)
                        dotMin = 1;
                    
                    currentDisplay = Math.Round(Convert.ToDouble(currentDisplay), 10 - dotIndex + dotMin).ToString();
                }
            }
        }

        public string decimalniZarez(string inPressedDigitString) 
        {
            // ako već u stringu postoji ',' zanemarujem ga ... 
            if (currentDisplay.IndexOf(',') >= 0)
                return "";

            else if (currentDisplay == "0" || currentDisplay == "-E-" || clearDisplay == true) 
            {
                clearDisplay = false;
                currentDisplay = "0,";
            }

            else
                currentDisplay += ",";

            return "";
        }

        public string promjenaPredznaka(string inPressedDigitString)
        {
            if (currentDisplay.ElementAt(0) == '-')
                currentDisplay = currentDisplay.Remove(0, 1);

            else
                currentDisplay = currentDisplay.Insert(0, "-");

            return "";
        }

        public string sin(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);
            rez = Math.Sin(rez);
            currentDisplay = rez.ToString();
            sizeCheck();
            clearDisplay = true;
            return "";
        }

        public string cos(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);
            rez = Math.Cos(rez);
            currentDisplay = rez.ToString();
            sizeCheck();
            clearDisplay = true;
            return "";
        }

        public string tg(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);
            rez = Math.Tan(rez);
            currentDisplay = rez.ToString();
            sizeCheck();
            clearDisplay = true;
            return "";
        }

        public string naKvadrat(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);
            rez = rez * rez;
            currentDisplay = rez.ToString();
            clearDisplay = true;
            sizeCheck();
            return "";
        }

        public string korijen(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);
            if (rez >= 0)
            {
                rez = Math.Sqrt(rez);
                currentDisplay = rez.ToString();
                sizeCheck();
                clearDisplay = true;
            }
            else
            {
                left = "";
                currentDisplay = "-E-";
                memoOpForEqual = "";
            }
            return "";
        }

        public string inverz(string inPressedDigitString)
        {
            double rez = Convert.ToDouble(currentDisplay);

            if (rez == 0)
                currentDisplay = "-E-";
            else
            {
                rez = 1 / rez;
                currentDisplay = rez.ToString();
                sizeCheck();
                clearDisplay = true;
            }

            return "";
        }

        public string spremiUMemo(string inPressedDigitString)
        {
            memo = currentDisplay;
            return "";
        }

        public string dohvatiIzMemo(string inPressedDigitString)
        {
            currentDisplay = memo;
            return "";
        }
        
        public Boolean odredi(string inPressedDigitString, string op) 
        {
            if (lastOperator != "" && lastOperator == "=")
            {
                operation = inPressedDigitString;
                lastOperator = inPressedDigitString;
                return true;
            }

            // ako je lijevi prazan spremanje u njega
            if (left == "")
            {
                clearDisplay = true;
                left = currentDisplay;
                operation = op;
                lastOperator = op;
                return true;
            }
            // za kontrolu tj. ignoiranje pretnodno unesenih operatora jednog za drugim
            else if (lastOperator != "" && inPressedDigitString != "=")
            {
                lastOperator = op;
                operation = op;
                return true;
            }

            return false;
        }

        public string plus(string inPressedDigitString)
        {
            // nije potrebno raditi operacije već samo postaviti parametre
            if (odredi(inPressedDigitString, "+"))
                return "";
            // postoji lijevi .. pridodaj mu desni
            else
            {
                if (operation == "+")
                {
                    string right = currentDisplay;

                    double leftDouble = Convert.ToDouble(left);
                    double rightDouble = Convert.ToDouble(right);
                    memoRightForEqual = rightDouble;
                    memoOpForEqual = "+";
                    double rez = leftDouble + rightDouble;

                    currentDisplay = rez.ToString();
                    clearDisplay = true;
                    left = currentDisplay;
                    sizeCheck();
                    operation = "+";
                    operation = "+";
                }
                else
                {
                    if (operation == "-")
                        minus(inPressedDigitString);
                    else if (operation == "*")
                        puta(inPressedDigitString);
                    else
                        podijeljeno(inPressedDigitString);

                    operation = "+";
                    lastOperator = "+";
                }

            }
            return "";
        }

        public string minus(string inPressedDigitString)
        {
            if (odredi(inPressedDigitString, "-"))
                return "";
            else
            {
                if (operation == "-")
                {
                    string right = currentDisplay;

                    double leftDouble = Convert.ToDouble(left);
                    double rightDouble = Convert.ToDouble(right);
                    memoRightForEqual = rightDouble;
                    memoOpForEqual = "-";
                    double rez = leftDouble - rightDouble;

                    currentDisplay = rez.ToString();
                    clearDisplay = true;
                    left = currentDisplay;
                    sizeCheck();
                    operation = "-";
                }
                else
                {
                    if (operation == "+")
                        plus(inPressedDigitString);
                    else if (operation == "*")
                        puta(inPressedDigitString);
                    else
                        podijeljeno(inPressedDigitString);

                    operation = "-";
                    lastOperator = "-";
                }

            }
            return "";
        }

        public string puta(string inPressedDigitString)
        {
            if (odredi(inPressedDigitString, "*"))
                return "";
            else
            {
                if (operation == "*")
                {
                    string right = currentDisplay;

                    double leftDouble = Convert.ToDouble(left);
                    double rightDouble = Convert.ToDouble(right);
                    memoRightForEqual = rightDouble;
                    memoOpForEqual = "*";
                    double rez = leftDouble * rightDouble;

                    currentDisplay = rez.ToString();
                    clearDisplay = true;
                    left = currentDisplay;
                    sizeCheck();
                    operation = "*";
                }
                else
                {
                    if (operation == "-")
                        minus(inPressedDigitString);
                    else if (operation == "+")
                        plus(inPressedDigitString);
                    else
                        podijeljeno(inPressedDigitString);

                    operation = "*";
                    lastOperator = "*";
                }

            }
            return "";
        }

        public string podijeljeno(string inPressedDigitString)
        {
            if (odredi(inPressedDigitString, "/"))
                return "";
            else
            {
                if (operation == "/")
                {
                    string right = currentDisplay;

                    double leftDouble = Convert.ToDouble(left);
                    double rightDouble = Convert.ToDouble(right);
                    memoRightForEqual = rightDouble;
                    memoOpForEqual = "/";

                    if (rightDouble != 0)
                    {
                        double rez = leftDouble / rightDouble;

                        currentDisplay = rez.ToString();
                        clearDisplay = true;
                        left = currentDisplay;
                        sizeCheck();
                        operation = "/";
                    }
                    else
                    {
                        left = "";
                        right = "";
                        currentDisplay = "-E-";
                        memoOpForEqual = "";
                    }
                }
                else
                {
                    if (operation == "-")
                        minus(inPressedDigitString);
                    else if (operation == "*")
                        puta(inPressedDigitString);
                    else
                        plus(inPressedDigitString);

                    operation = "/";
                    lastOperator = "/";
                }

            }
            return "";
        }

        public string jednako(string inPressedDigitString)
        {
            // nema nikakve operacije jer ne postoji lijevi broj
            if (left == "")
            {
                clearDisplay = true;
                currentDisplay = Convert.ToDouble(currentDisplay).ToString();
            }
            // dio za upravljanje za: +========...
            else if (lastOperator == "=")
            {
                lastOperator = "";
                left = currentDisplay;
                currentDisplay = memoRightForEqual.ToString();

                operation = memoOpForEqual;
            }
            // za 5+=
            else if (lastOperator != "=" && lastOperator != "")
            {
                currentDisplay = left;
            }

            if (operation == "-")
                minus(inPressedDigitString);
            else if (operation == "+")
                plus(inPressedDigitString);
            else if (operation == "*")
                puta(inPressedDigitString);
            else
                podijeljeno(inPressedDigitString);

            lastOperator = "=";

            return "";
        }

        public string ocistiEkran(string inPressedDigitString)
        {
            currentDisplay = "0";
            clearDisplay = false;
            lastOperator = "";
            return "";
        }

        public string reset(string inPressedDigitString)
        {
            currentDisplay = "0";
            lastOperator = "";
            left = "";
            clearDisplay = false;
            operation = "";
            memoRightForEqual = 0;
            memoOpForEqual = "";
            currentDisplay = "0";
            memo = "";
            return "";
        }

        public void Press(char inPressedDigit)
        {
            string inPressedDigitString = string.Join("", inPressedDigit);

            if (operators.ContainsKey(inPressedDigit))
                operators[inPressedDigit].DynamicInvoke(inPressedDigitString);

            else if (currentDisplay == "0" || currentDisplay == "-E-")
                currentDisplay = inPressedDigitString;

            else
                addNewDigitOrNot(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            // posljednja provjera za veličinu polja iako je nepotrebna jer se izvršava na kraju svake metode
            sizeCheck();
            if (currentDisplay == "-E-")
                return currentDisplay;
            else if (currentDisplay.ElementAt(currentDisplay.Length - 1).ToString() == ",")
                // rusko riješenje - da sam koristio dio iz else-a ne bi dobio traženi odgovor zbog Convertiranja
                return currentDisplay;
            else
                // sa ovim osiguravam da nikad nebude ispisano ",0" ukoliko ne postoje konkretne decimale
                return Convert.ToDouble(currentDisplay).ToString();
        }
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }
}