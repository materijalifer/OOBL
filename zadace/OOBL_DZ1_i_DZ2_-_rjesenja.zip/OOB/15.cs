﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }



    public class Kalkulator:ICalculator
    {

        string Spremnik;
        string Operator=null;
        bool ZadnjiBinarniOperator=false;
        bool Zanemari=false;
        bool Greska=false;
        string Memorija="0";
        string Prikazano="0";
        double NijePrikazaniBroj;

        public void Press(char inPressedDigit)
        {
            if (Greska==true)
            {
                PostaviPocetno();
            }

            if (Char.IsDigit(inPressedDigit))
            {
                if (ZadnjiBinarniOperator==true)
                {
                    if (!Zanemari)
                    {
                        NijePrikazaniBroj = Convert.ToDouble(Prikazano);
                    }
                    else
                    {
                        NijePrikazaniBroj = Convert.ToDouble(Spremnik);
                        Zanemari = false;
                    }
                    Prikazano = "0";
                    ZadnjiBinarniOperator = false;
                }
                if (!ImaPreviseZnamenaka(Prikazano))
                {
                    ZnakStringu(inPressedDigit);
                }
            }
            else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
            {
                NoviBinarniOperator(inPressedDigit);
                ZadnjiBinarniOperator = true;
            }
            else if (inPressedDigit == ',')
            {
                if (!ImaTocku(Prikazano))
                {
                    DodajZarez();
                }
            }
            else if (inPressedDigit == 'O')
            {
                PostaviPocetno();
            }
            else if (inPressedDigit == 'M')
            {
                Alternativa();
            }

            else if (inPressedDigit == 'I')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        Spremnik = Prikazano;
                        Zanemari = true;
                    }
                }
                Obrni();
            }
            else if (inPressedDigit == 'C')
            {
                Prikazano = "0";
            }
            else if (inPressedDigit == 'O')
            {
                PostaviPocetno();
            }
            else if (inPressedDigit == 'P')
            {
                SnimiMemorija();
            }
            else if (inPressedDigit == 'G')
            {
                PrikaziMemoriju();
            }
            else if (inPressedDigit == 'T')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        NeRacunaj();
                    }
                }
                Tangens();
            }
            else if (inPressedDigit == 'R')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        NeRacunaj();
                    }
                }
                Korijen();
            }
            else if (inPressedDigit == 'K')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        NeRacunaj();
                    }
                }
                Kosinus();
            }
            else if (inPressedDigit == '=')
            {
                if (ZadnjiBinarniOperator)
                {
                    SpremnikJednaZnamenka();
                }
                else
                {
                    if (Operator == null)
                    {
                        Prikazano = SkratiIzaDecimalne(Convert.ToDouble(Prikazano));
                    }
                    else
                    {
                        OdrediSpremnik();
                        Operator = null;
                    }
                }
            }
            else if (inPressedDigit == 'S')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        NeRacunaj();
                    }
                }
                Sinus();
            }
            else if (inPressedDigit == 'Q')
            {
                if (ZadnjiBinarniOperator)
                {
                    if (!Zanemari)
                    {
                        NeRacunaj();
                    }
                }
                Kvadrat();
            }
        }

        public string GetCurrentDisplayState()
        {
            return Prikazano;
        }

        public void PostaviPocetno()
        {
            string Operator = null;
            bool ZadnjiBinarniOperator = false;
            bool Zanemari = false;
            bool Greska = false;
            string Memorija = "0";
            string Prikazano = "0";
            string NijePrikazano = null;
        }

        private void NoviBinarniOperator(char PreneseniOperator)
        {
            if (ZadnjiBinarniOperator==true)
            {
                Operator = PreneseniOperator.ToString();
            }
            else
            {
                if (Operator == null)
                {
                    Operator = PreneseniOperator.ToString();
                }
                else
                {
                    OdrediSpremnik();
                    Operator = PreneseniOperator.ToString();
                }
            }
        }

        private void OdrediSpremnik()
        {
            if (Operator== "+")
            {
                double SpremnikIzracun = NijePrikazaniBroj + Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikIzracun.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikIzracun);
                }
            }
            else if (Operator == "-")
            {
                double SpremnikIzracun = NijePrikazaniBroj - Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikIzracun.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikIzracun);
                }
            }
            else if (Operator == "*")
            {
                double  SpremnikIzracun = NijePrikazaniBroj * Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikIzracun.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikIzracun);
                }
            }
            else if (Operator == "/")
            {
                if (Convert.ToDouble(Prikazano) == 0)
                {
                    ObjaviGresku();
                }
                else
                {
                    double SpremnikIzracun = NijePrikazaniBroj / Convert.ToDouble(Prikazano);
                    if (ImaPreviseZnamenaka(SpremnikIzracun.ToString()))
                    {
                        ObjaviGresku();  
                    }
                    else
                    {
                        Prikazano = SkratiIzaDecimalne(SpremnikIzracun);
                    }
                }
            }
        }

        private void ObjaviGresku()
         {
            Prikazano = "-E-";
            Greska = true;
        }

        private bool ImaPreviseZnamenaka(string StringUnos)
        {
            int BrojZnamenki = 0;
            foreach (char character in StringUnos.ToList())
            {
                if (Char.IsDigit(character))
                {
                    BrojZnamenki++;
                }
            }
            if (BrojZnamenki > 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private string SkratiIzaDecimalne(double Skratiti)
        {
            int ZnamenkeIzaTocke = DostupneZnamenkePoslijeTocke(Skratiti.ToString());
            Skratiti = Math.Round(Skratiti, ZnamenkeIzaTocke);
            if (ImaTocku(Skratiti.ToString()))
            {
                return SkratiNule(Skratiti.ToString());
            }
            else
            {
                return Skratiti.ToString();
            }
        }

        private string SkratiNule(string Skraceno)
        {
            while (Skraceno[Skraceno.Length - 1] == '0' || Skraceno[Skraceno.Length - 1] == ',')
            {
                if (Skraceno[Skraceno.Length - 1] == ',')
                {
                    Skraceno = Skraceno.Remove(Skraceno.Length - 1, 1);
                    break;
                }
                Skraceno = Skraceno.Remove(Skraceno.Length - 1, 1);
            }
            return Skraceno;
        }

        private bool ImaTocku(string DolazniString)
        {
            return DolazniString.Contains(',');
        }

        private int DostupneZnamenkePoslijeTocke(string Broj)
        {
            return 10 - ZnamenkePrijeTocke(Broj);
        }

        private int ZnamenkePrijeTocke(string Broj)
        {
            int Brojac = 0;
            foreach (char c in Broj)
            {
                if (c == ',')
                {
                    break;
                }
                else if (c == '-')
                {
                }
                else
                {
                    Brojac++;
                }
            }
            return Brojac;
        }

        private void DodajZarez()
        {
            Prikazano += ',';
        }

        private void Alternativa()
        {
            if (Prikazano[0] == '-')
            {
                Prikazano.Remove(0, 1);
            }
            else
            {
                Prikazano = Prikazano.Insert(0, "-");
            }
        }

        private void ZnakStringu(char inPressedDigit)
        {
            if (Prikazano == "0")
            {
                Prikazano = inPressedDigit.ToString();
            }
            else
            {
                Prikazano += inPressedDigit.ToString();
            }
        }

        private void Obrni()
        {
            if (Convert.ToDouble(Prikazano) == 0)
            {
                ObjaviGresku();
            }
            else
            {
                double obrnuto = 1 / Convert.ToDouble(Prikazano);
                if (ZnamenkePrijeTocke(obrnuto.ToString()) > 10)
                {
                    ObjaviGresku();
                }
                else
                {
                    if (ImaTocku(obrnuto.ToString()))
                    {
                        Prikazano = SkratiIzaDecimalne(obrnuto);
                    }
                    else
                    {
                        Prikazano = obrnuto.ToString();
                    }
                }
            }
        }

        private void SnimiMemorija()
        {
            Memorija = Prikazano;
        }

        private void PrikaziMemoriju()
        {
            Prikazano = Memorija;
        }

        private void Tangens()
        {
            double Broj = Convert.ToDouble(Prikazano);

            double tan = Math.Tan(Broj);
            if (ZnamenkePrijeTocke(tan.ToString()) > 10)
            {
                ObjaviGresku();
            }
            else
            {
                if (ImaTocku(tan.ToString()))
                {
                    Prikazano = SkratiIzaDecimalne(tan);
                }
                else
                {
                    Prikazano = tan.ToString();
                }
            }
        }

        private void Korijen()
        {
            double korijen = Math.Sqrt(Convert.ToDouble(Prikazano));

            if (ZnamenkePrijeTocke(korijen.ToString()) > 10)
            {
                ObjaviGresku();
            }
            else
            {
                if (ImaTocku(korijen.ToString()))
                {
                    Prikazano = SkratiIzaDecimalne(korijen);
                }
                else
                {
                    Prikazano = korijen.ToString();
                }

            }
        }

        private void NeRacunaj()
        {
            Spremnik = Prikazano;
            Zanemari = true;
        }

        private void Kosinus()
        {
            double BrojKos = Convert.ToDouble(Prikazano);
            double cos = Math.Cos(BrojKos);
            Prikazano = SkratiIzaDecimalne(cos);
        }

        private void SpremnikJednaZnamenka()
        {
            if (Operator == "+")
            {
                double SpremnikRez = Convert.ToDouble(Prikazano) + Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikRez.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikRez);
                }
            }
            else if (Operator == "-")
            {
                double SpremnikRez = Convert.ToDouble(Prikazano) - Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikRez.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikRez);
                }
            }
            else if (Operator == "*")
            {
                double SpremnikRez = Convert.ToDouble(Prikazano) * Convert.ToDouble(Prikazano);
                if (ImaPreviseZnamenaka(SpremnikRez.ToString()))
                {
                    ObjaviGresku();
                }
                else
                {
                    Prikazano = SkratiIzaDecimalne(SpremnikRez);
                }
            }
            else if (Operator == "/")
            {
                if (Convert.ToDouble(Prikazano) == 0)
                {
                    ObjaviGresku();
                }
                else
                {
                    double bufferResult = Convert.ToDouble(Prikazano) / Convert.ToDouble(Prikazano);
                    if (ImaPreviseZnamenaka(bufferResult.ToString()))
                    {
                        ObjaviGresku();
                    }
                    else
                    {
                        Prikazano = SkratiIzaDecimalne(bufferResult);
                    }
                }
            }
        }

        private void Sinus()
        {
            double BrojSin = Convert.ToDouble(Prikazano);
            double sinus = Math.Sin(BrojSin);
            Prikazano = SkratiIzaDecimalne(sinus);

        }

        private void Kvadrat()
        {
            double kvadrat = Math.Pow(Convert.ToDouble(Prikazano), 2);

            if (ZnamenkePrijeTocke(kvadrat.ToString()) > 10)
            {
                ObjaviGresku();
            }
            else
            {
                if (ImaTocku(kvadrat.ToString()))
                {
                    Prikazano = SkratiIzaDecimalne(kvadrat);
                }
                else
                {
                    Prikazano = kvadrat.ToString();
                }
            }
        }
    }


}
