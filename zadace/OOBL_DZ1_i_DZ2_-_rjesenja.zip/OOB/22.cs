﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        string mMemory;
        string mInput;

        public Kalkulator()
        {
            mMemory = "";
            mInput = "0";
        }
        public void Press(char inPressedDigit)
        {

           processInput(inPressedDigit);
           if (Math.Abs(Convert.ToDouble(mInput)) > 9999999999) mInput = "-E-";
           
        }

        public string GetCurrentDisplayState()
        {
            return mInput;
        }
        private void processInput(char inPressedDigit)
        {

            if (mInput.Length == 1 && mInput[0] == '0' && inPressedDigit!=',') mInput = "";
            if (inPressedDigit == '+') mInput += inPressedDigit; 
            if (inPressedDigit == '-') mInput += inPressedDigit;
            if (inPressedDigit == '/') mInput += inPressedDigit;
            if (inPressedDigit == '*') mInput += inPressedDigit; 
            if (inPressedDigit == '=') equals();
            if (inPressedDigit == ',') mInput += inPressedDigit;
            if (inPressedDigit == 'M') minus();
            if (inPressedDigit == 'S') sinus();
            if (inPressedDigit == 'K') cosinus();
            if (inPressedDigit == 'T') tangents();
            if (inPressedDigit == 'Q') square();
            if (inPressedDigit == 'R') root();
            if (inPressedDigit == 'I') invers();
            if (inPressedDigit == 'P') put();
            if (inPressedDigit == 'G') get();
            if (inPressedDigit == 'C') clear();
            if (inPressedDigit == 'O') on();
            if (char.IsNumber(inPressedDigit)&&(mInput.Length < 10)) mInput += inPressedDigit;
            
        }
        private double getPreviousNoumber(int k)
        {
            int i = k;
            string debuger;
            while(k>0 && mInput[k]!='+'&& mInput[k]!='-'&& mInput[k]!='*'&& mInput[k]!='/') 
            {
            k--;
            }
            debuger = mInput.Substring(k, i+1);
            return Convert.ToDouble(debuger);
        }
        private double getNextNoumber(int k)
        {
            string helper = "";
            while (k < (mInput.Length) && mInput[k] != '+' && mInput[k] != '-' && mInput[k] != '*' && mInput[k] != '/') 
            {
            helper+=mInput[k];
            k++;
            }
            return Convert.ToDouble(helper);
        }
        private void removePreviousNoumber(int i)
        {
            while (i >= 0 && mInput[i] != '+' && mInput[i] != '-' && mInput[i] != '*' && mInput[i] != '/')
            {
                i--;
            }
            if (i > 0) mInput = mInput.Substring(0, i); else mInput = "";

        }
        private void equals()
        {
            double result = 0;
            for (int i = 0; i < mInput.Length; i++)
            {
                switch (mInput[i])
                {
                    case '+':
                        {
                            result+=getPreviousNoumber(i-1) + getNextNoumber(i+1);
                            break;
                        }
                    case '-':
                        {
                            result += getPreviousNoumber(i-1) - getNextNoumber(i+1);
                            break;
                        }
                    case '*':
                        {
                            result += getPreviousNoumber(i-1) * getNextNoumber(i+1);
                            break;
                        }
                    case '/':
                        {
                            result += getPreviousNoumber(i-1) / getNextNoumber(i+1);
                            break;
                        }
                  
                }
            }
            mInput = Convert.ToString(result);
        }
        private void square()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(noumber*noumber);
        }
        private void minus()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(-noumber);
        }

        private void sinus()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(Math.Sin(noumber));
         
        }
        private void cosinus()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(Math.Cos(noumber));
        }
        private void tangents()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(Math.Tan(noumber));
           
        }
        private void root()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(Math.Sqrt(noumber));
        }
        private void invers()
        {
            double noumber = getPreviousNoumber(mInput.Length - 1);
            removePreviousNoumber(mInput.Length - 1);
            mInput += Convert.ToString(1/noumber);
        }
        private void put()
        {
            mMemory = mInput;
        }
        private void get()
        {
            mInput = mMemory; 
        }
        private void clear()
        {
            mInput = "0";
        }
        private void on()
        {
            mInput = "0";
            mMemory = "";
        }
    }


}
