﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        
        private Number currentNumber;
        private Number accumulator;

        private Operation currentOperation;
        private Display display;
        private Memory memory;

        public Kalkulator()
        {
            currentNumber = new Number();
            accumulator = null;
            currentOperation = null;
            display = new Display();

            memory = new Memory();
        }

        public void Press(char inPressedDigit)
        {
            if(display.Status == DisplayStatus.Error)
            {
                resetCalculator();
            }

            if(Char.IsDigit(inPressedDigit))
            {
                processInputDigit(inPressedDigit);
                
            }else 
            if(Char.IsLetter(inPressedDigit))
            {
                processInputLetter(inPressedDigit);

            }else 
            if(Char.IsSymbol(inPressedDigit))
            {
                processInputSymbol(inPressedDigit);
                
            }else
            if(Char.IsPunctuation(inPressedDigit))
            {
                processInputPunctuation(inPressedDigit);
                
            }
        }

        public string GetCurrentDisplayState()
        {
            String screenDigits = display.showOutput();
            return screenDigits;
        }

        private void resetCalculator()
        {
            currentNumber = new Number();
            accumulator = null;
            memory = new Memory();
            display.Status = DisplayStatus.NumberInput;
        }

        private void processInputDigit(char inPressedDigit)
        {
            display.Status = DisplayStatus.NumberInput;
            if (currentNumber == null || !currentNumber.Changeable)
            {
                currentNumber = new Number();
            }

            try
            {
                currentNumber.addDigit(inPressedDigit);
                display.refreshOutput(currentNumber, accumulator);
            }
            catch (Exception e)
            {
                display.Status = DisplayStatus.Error;
                display.refreshOutput(currentNumber, accumulator);
            }
        }

        private void processInputLetter(char inPressedDigit)
        {
            if (display.Status == DisplayStatus.ResultDisplay || display.Status == DisplayStatus.TrimResultDisplay)
            {
                display.Status = DisplayStatus.NumberInput;
                currentNumber = accumulator.copy();
            }
            if (isUnaryOperator(inPressedDigit))
            {
                performUnaryOperation(inPressedDigit);
            }
            else
            {
                performMemoryAction(inPressedDigit);
            }
        }

        private void processInputSymbol(char inPressedDigit)
        {
            if (isBinaryOperator(inPressedDigit))
            {
                addBinaryOperation(inPressedDigit);
            }
            else
            {
                if (inPressedDigit.Equals('='))
                {
                    performEquals();
                }
            }
        }

        private void processInputPunctuation(char inPressedDigit)
        {
            if (isBinaryOperator(inPressedDigit))
            {
                addBinaryOperation(inPressedDigit);
            }
            else
                if (inPressedDigit.Equals(','))
                {
                    if (currentNumber == null || !currentNumber.Changeable)
                    {
                        currentNumber = new Number();
                    }
                    currentNumber.turnDecimal();
                }
        }

        private bool isUnaryOperator(char inChar)
        {
            if(inChar.Equals('M') || inChar.Equals('S') || inChar.Equals('K') || inChar.Equals('T') ||
                inChar.Equals('Q') || inChar.Equals('R') || inChar.Equals('I'))
                {
                    return true;
                }   
                else
                {   
                    return false;
                }   
        }

        private bool isBinaryOperator(char inChar)
        {
            if (inChar.Equals('+') || inChar.Equals('-') || inChar.Equals('*') || inChar.Equals('/'))
            {
                return true;
            }
            else
            {
                return false;
            }   
        }

        private void performUnaryOperation(char inOperator)
        {
            double currentValue = this.currentNumber.Value;
            double newValue;

            switch(inOperator)
            {
                case 'M': newValue = currentValue * (-1);
                            break;
                case 'S': newValue = Math.Sin(currentValue);
                            break;
                case 'K': newValue = Math.Cos(currentValue);
                            break;
                case 'T': newValue = Math.Tan(currentValue);
                            break;
                case 'Q': newValue = Math.Pow(currentValue, 2);
                            break;
                case 'R': newValue = Math.Sqrt(currentValue);
                            break;
                case 'I': if(currentValue == 0)
                            {
                                display.Status = DisplayStatus.Error;
                                newValue = currentValue;
                            }else
                            {
                                newValue = 1 / currentValue;
                            }
                            break;
                default: throw new Exception("Unesen nepostojeci unarni operator");
            }

            if(!inOperator.Equals('M'))
            {
                currentNumber.Changeable = false;
            }

            currentNumber.Value = newValue;
            currentNumber.calculateNumberSize();
            try
            {
                currentNumber.correctNumberSize();
            }catch(Exception e)
            {
                if(e.Message.Equals(Number.TOO_LARGE_NUMBER))
                {
                    display.Status = DisplayStatus.Error;
                }
            }
            currentNumber.calculateNumberSize();
            display.refreshOutput(currentNumber, accumulator);
        }

        private void performMemoryAction(char inActionMark)
        {
            switch(inActionMark)
            {
                case 'P': memory.storeNumber(currentNumber.copy());
                            break;
                case 'G': currentNumber = memory.retriveNumber().copy();
                            break;
                case 'C': currentNumber = new Number();
                            break;
                case 'O': memory = new Memory();
                            accumulator = new Number();
                            currentNumber = new Number();
                            break;
                default: throw new Exception("Zatrazena operacija nije implementirana");
            }

            if(!inActionMark.Equals('P'))
            {
                currentNumber.Changeable = false;
            }
            display.refreshOutput(currentNumber, accumulator);
        }

        private void addBinaryOperation(char inOperation)
        {
            display.Status = DisplayStatus.ResultDisplay;

            if(currentNumber != null)
            {
            calculateResult();   
            }
         
            switch(inOperation)
            {
                case '+' : currentOperation = new Operation(OperationType.Add);
                            break;
                case '-': currentOperation = new Operation(OperationType.Subtract);
                            break;
                case '*': currentOperation = new Operation(OperationType.Multiply);
                            break;
                case '/': currentOperation = new Operation(OperationType.Divide);
                            break;
                default: throw new Exception("Zatrazeni binarni operator nije implementiran");
            }   
            display.refreshOutput(currentNumber, accumulator);
        }

        private void performEquals()
        {
            if(currentNumber == null)
            {
                currentNumber = accumulator.copy();
            }
            display.Status = DisplayStatus.TrimResultDisplay;
            calculateResult(); 
            display.refreshOutput(currentNumber, accumulator);
        }

        private void calculateResult()
        {
            if (currentOperation != null)
            {
                performOperation();
                currentNumber = null;
            }
            else
            {
                if (currentNumber != null)
                {
                    accumulator = currentNumber.copy();
                    currentNumber = null;
                }
            }
        }

        private void performOperation()
        {
            try
            {
                accumulator = currentOperation.performOperation(accumulator, currentNumber);
                accumulator.Changeable = false;

            }
            catch(Exception e){
                display.Status = DisplayStatus.Error;
            }     
            currentOperation = null;
        }
    }

    public class Memory
    {
        private Number memoNumber;

        public Memory()
        {
            this.memoNumber = new Number();
        }

        public void storeNumber(Number number)
        {
            this.memoNumber = number;
        }

        public Number retriveNumber()
        {   
            return memoNumber;
        }
    }

    public class Number
    {
        private double value;

        private bool isDecimal;
        private bool isNegative;
        private int numDigitsLeft;
        private int numDigitsRight;

        private bool changeable;
        
        private const int SCREEN_SIZE = 10;

        public static String TOO_LARGE_NUMBER ="LARGE"; 

        public double Value{
            get{
                return this.value;
            }
            set{
                this.value = value;
            }
        }

        public bool Changeable
        {
            get{
                return this.changeable;
            }
            set{
                this.changeable = value;
            }

        }

        public Number()
        {
            this. value = 0;
            this.isDecimal = false;
            this.isNegative = false;
            this.numDigitsLeft = 0;
            this.numDigitsRight = 0;
            this.changeable = true;
        }

        public void addDigit(char inDigit)
        {
            int digitValue = Int32.Parse(inDigit.ToString());

            if(!this.isDecimal)
            {
                if(!this.isNegative)
                {
                    this.value = this.value * 10 + digitValue;
                }else
                {
                    this.value = this.value * 10 - digitValue;       
                }
                if(numDigitsLeft != 0 || digitValue != 0)
                { 
                numDigitsLeft++;
                }
            }else
            {
                if(!this.isNegative)
                {
                    this.value = this.value + (digitValue / Math.Pow(10, numDigitsRight + 1));
                }else
                {
                    this.value = this.value - (digitValue / Math.Pow(10, numDigitsRight + 1));     
                }
                numDigitsRight++;
            }
            correctNumberSize(); 
        }

        public void correctNumberSize()
        {
            if (numDigitsLeft > SCREEN_SIZE)
            {
                throw new Exception(TOO_LARGE_NUMBER);
            }
            else
                if (numDigitsLeft + numDigitsRight > SCREEN_SIZE)
                {
                    this.value = Math.Round(this.value, 10 - numDigitsLeft);
                }
        }

        public void calculateNumberSize()
        {
            String valueString = value.ToString();

            int valueLength = valueString.Length;

            bool isNegative = valueString.Contains("-");
            this.isNegative = isNegative;

            bool isDecimal = valueString.Contains(",");
            this.isDecimal = isDecimal;

            int comaIndex = valueString.IndexOf(',');

            if (isDecimal)
            {
                if (isNegative)
                {
                    numDigitsLeft = comaIndex - 1;
                    numDigitsRight = valueLength - comaIndex - 1;
                }
                else
                {
                    numDigitsLeft = comaIndex;
                    numDigitsRight = valueLength - comaIndex - 1;
                }
            }
            else
            {
                if (isNegative)
                {
                    numDigitsLeft = valueLength - 1;
                    numDigitsRight = 0;
                }
                else
                {
                    numDigitsLeft = valueLength;
                    numDigitsRight = 0;
                }
            }
        }

        public Number copy(){
            Number newNum = new Number();
            newNum.value = this.value;
            newNum.isDecimal = this.isDecimal;
            newNum.isNegative = this.isNegative;
            newNum.numDigitsLeft = this.numDigitsLeft;
            newNum.numDigitsRight = this.numDigitsRight;
            return newNum;
        }

        public void turnDecimal(){
            this.isDecimal = true;
        }

        public string ToString(bool zeroExtended)
        {
            return value.ToString("F"+numDigitsRight);
        }
    }

    public class Operation
    {
        OperationType operationT;

        public Operation(OperationType operationType){
            this.operationT = operationType;
        }
        
        public Number performOperation(Number firstOperand, Number secondOperand)
        {
            Number operationResult = new Number();
            switch(operationT){
                case OperationType.Add : operationResult.Value = firstOperand.Value + secondOperand.Value;
                                            break;
                case OperationType.Subtract: operationResult.Value = firstOperand.Value - secondOperand.Value;
                                            break;
                case OperationType.Multiply: operationResult.Value = firstOperand.Value * secondOperand.Value;
                                            break;
                case OperationType.Divide: if(secondOperand.Value == 0)
                                           {
                                                throw new ArgumentException("Djeljenje s nulom!");
                                           }
                                            operationResult.Value = firstOperand.Value / secondOperand.Value;
                                            break;
                default: throw new Exception("Zatrazena operacija nije implementirana");
            }
            operationResult.calculateNumberSize();
            operationResult.correctNumberSize();
            operationResult.calculateNumberSize();
            return operationResult;
        } 
    }

    public enum OperationType
    {
        Add,
        Subtract,
        Multiply,
        Divide
    }

    public class Display
    {
        private String figuresToShow;
        public DisplayStatus Status;

        public Display()
        {
            figuresToShow = "0";
            Status = DisplayStatus.NumberInput;
        }

        public String showOutput()
        {
            return figuresToShow;
        }

        public void refreshOutput(Number currentNumber, Number accumulator)
        {
            switch(Status)
            {
                case DisplayStatus.NumberInput : figuresToShow = currentNumber.ToString(true);
                                                 break;
                case DisplayStatus.ResultDisplay : figuresToShow = accumulator.ToString(true);
                                                   break;
                case DisplayStatus.TrimResultDisplay : figuresToShow = accumulator.Value.ToString();
                                                       break;
                case DisplayStatus.Error : figuresToShow = "-E-";
                                           break;
                default: throw new Exception("Zatrazena operacija nije implementirana");

            }
        }
    }

    public enum DisplayStatus
    {
        NumberInput,
        ResultDisplay,
        TrimResultDisplay,
        Error
    }
}
