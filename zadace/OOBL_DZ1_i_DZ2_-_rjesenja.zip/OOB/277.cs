﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Rotaluklak();
        }
    }

    public class Rotaluklak : ICalculator
    {
        private enum state
        {
            init,
            work
        }
        
        private state calcState;
        private string display;
        private string memory;
        private string firstOperand;
        private char lastOperator;
        

        private bool decimalPointExists;
        private bool numberIsSigned;
        private bool operatorExists;
        private bool lastPressedOperator;

        private const int ALLOWED_NUM_OF_DIGITS = 10;
        private const string EMPTY = "0";
        

        public Rotaluklak()
        {
            this.display = EMPTY;
            this.memory = EMPTY;
            this.firstOperand = EMPTY;
            this.lastOperator = '\0';
            this.calcState = state.init;
            this.decimalPointExists = false;
            this.numberIsSigned = false;
            this.operatorExists = false;
            this.lastPressedOperator = false;

        }

        public void Press(char inPressedDigit)
        {
            if (char.IsDigit(inPressedDigit))
                writeDigitToDisplay(inPressedDigit);
            else
            {
                switch (inPressedDigit)
                {
                    case '+':
                        this.operatorActions(inPressedDigit);                       
                        break;
                    case '-':
                        this.operatorActions(inPressedDigit);
                        break;
                    case '*':
                        this.operatorActions(inPressedDigit);
                        break;
                    case '/':
                        this.operatorActions(inPressedDigit);
                        break;
                    case '=':
                        this.getResult();
                        break;
                    case ',':
                        this.addDecimalPoint();
                        break;
                    case 'M':
                        this.signNumber();
                        break;
                    case 'S':
                        this.sine(this.display);
                        break;
                    case 'K':
                        this.cosine(this.display);
                        break;
                    case 'T':
                        this.tangent(this.display);
                        break;
                    case 'Q':
                        this.square(this.display);
                        break;
                    case 'R':
                        this.squareRoot(this.display);
                        break;
                    case 'I':
                        this.inverse(this.display);
                        break;
                    case 'P':
                        this.putToMemory();
                        break;
                    case 'G':
                        this.getFromMemory();
                        break;
                    case 'C':
                        this.clearDisplay();
                        break;
                    case 'O':
                        this.reset();
                        break;
                    default:
                        throwError();
                        break;
                }
            }
        }

        private void getResult()
        {
            this.display = this.roundNumber(this.display);

            if (this.lastPressedOperator.Equals(true))            
                this.firstOperand = this.display;                
            
            if(this.operatorExists.Equals(true))
                this.calculate();
            
        }

        private void operatorActions(char op)
        {           
            this.display = this.roundNumber(this.display);

            //Ako je unesen operator binarne operacije i ako posljednje unesen znak nije operator (znaci 
            if (this.operatorExists.Equals(true) && this.lastPressedOperator.Equals(false)) 
            {            
                this.calculate();
            }
            else
                this.save1stOperand();

            this.lastPressedOperator = true;
            this.saveOperator(op);           
        }

        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        private string roundNumber(string wildNumber)
        {
            int wholeDigits = 0;
            int roundTo = 0;
            double number = 0;

            //Cisti sve nule viska i samostojeci decimalni zarez, ako postoji
            while (wildNumber.EndsWith(",") || ((wildNumber.EndsWith("0") && this.decimalPointExists.Equals(true))))
                wildNumber = wildNumber.Remove(wildNumber.Length - 1);

            foreach (char c in wildNumber)
            {
                if(c.Equals(','))
                    break;

                if (char.IsDigit(c)) wholeDigits++;
            }

            roundTo = Math.Min(wildNumber.Count(char.IsDigit) - wholeDigits,ALLOWED_NUM_OF_DIGITS-wholeDigits);
            number = Math.Round(double.Parse(wildNumber), roundTo);

            return number.ToString();           
        }

        private void checkForSignAndDecimalPoint()
        {
            if (this.display.Contains("-"))
                this.numberIsSigned = true;
            else 
                this.numberIsSigned = false;

            if (this.display.Contains(","))
                this.decimalPointExists = true;
            else 
                this.decimalPointExists = false;
        }

        private void writeDigitToDisplay(char digit)
        {
            if (lastPressedOperator == true)
            {
                this.clearDisplay();
                this.lastPressedOperator = false;
            }


            if (this.display.Count(char.IsDigit) < ALLOWED_NUM_OF_DIGITS)
            {
                //if display already contains some digits
                if (this.calcState.Equals(state.work))
                    this.display += digit;
                //if display is in the initial state, with only 0 being displayed
                else if (this.calcState.Equals(state.init))
                {
                    this.display = digit.ToString();
                    if(digit != '0')
                        this.calcState = state.work;
                }               
            }           
        }

        private void clearDisplay()
        {
            this.display = EMPTY;
            this.calcState = state.init;
            this.decimalPointExists = false;
            this.numberIsSigned = false;
        }

        private void save1stOperand()
        {
            this.firstOperand = this.roundNumber(this.display);                 
        }

        private void saveOperator(char op)
        {
            this.operatorExists = true;
            this.lastOperator = op;
        }

        private void signNumber()
        {
            if (this.numberIsSigned.Equals(false))
            {
                this.display = this.display.Insert(0, "-");
                this.numberIsSigned = true;
            }
            else
            {
                this.display.Replace("-", "");
            }
        }

        private void addDecimalPoint()
        {
            if (this.decimalPointExists.Equals(false))
            {
                this.display += ",";
                this.decimalPointExists = true;
                this.calcState = state.work;
            }
        }

        private void add(string num1, string num2)
        {
            double oper1 = double.Parse(num1);
            double oper2 = double.Parse(num2);
            double result = oper1 + oper2;

            if (result.ToString().Count(char.IsDigit) > ALLOWED_NUM_OF_DIGITS)
                throwError();
            else
            {
                this.display = this.roundNumber(result.ToString());
                this.firstOperand = this.display;
            }

        }

        private void substract(string num1, string num2)
        {
            double oper1 = double.Parse(num1);
            double oper2 = double.Parse(num2);
            double result = oper1 - oper2;

            if (result.ToString().Count(char.IsDigit) > ALLOWED_NUM_OF_DIGITS)
                throwError();
            else
            {
                this.display = this.roundNumber(result.ToString());
                this.firstOperand = this.display;
            }
        }

        private void multiply(string num1, string num2)
        {
            double oper1 = double.Parse(num1);
            double oper2 = double.Parse(num2);
            double result = oper1 * oper2;

            if (result.ToString().Count(char.IsDigit) > ALLOWED_NUM_OF_DIGITS)
                throwError();
            else
            {
                this.display = this.roundNumber(result.ToString());
                this.firstOperand = this.display;
            }
        }

        private void divide(string num1,string num2)
        {
            double oper1 = double.Parse(num1);
            double oper2 = double.Parse(num2);            
            double result = oper1 / oper2;

            if (double.IsInfinity(result) || result.ToString().Count(char.IsDigit) > ALLOWED_NUM_OF_DIGITS)
                throwError();
            else
            {
                this.display = this.roundNumber(result.ToString());
                this.firstOperand = this.display;
            }

           
        }

        private void sine(string num)
        {
            this.display = this.roundNumber(this.display);
            
            try
            {
                this.display = this.roundNumber(Math.Sin(double.Parse(this.display)).ToString());
            }
            catch
            {
                this.throwError();
            }
        }

        private void cosine(string num)
        {
            this.display = this.roundNumber(this.display);

            try
            {
                this.display = this.roundNumber(Math.Cos(double.Parse(this.display)).ToString());
            }
            catch
            {
                this.throwError();
            }
        }

        private void tangent(string num)
        {
            this.display = this.roundNumber(this.display);

            try
            {
                this.display = this.roundNumber(Math.Tan(double.Parse(this.display)).ToString()); 
            }
            catch
            {
                this.throwError();
            }
        }

        private void square(string num)
        {
            this.display = this.roundNumber(this.display);

            try
            {
                this.display = this.roundNumber(Math.Pow(double.Parse(this.display), 2).ToString());
            }
            catch
            {
                this.throwError();
            }
        }

        private void squareRoot(string num)
        {
            this.display = this.roundNumber(this.display);

            try
            {
                this.display = this.roundNumber(Math.Sqrt(double.Parse(this.display)).ToString());
            }
            catch
            {
                this.throwError();
            }
        }

        private void inverse(string num)
        {
            this.display = this.roundNumber(this.display);

            if (double.Parse(this.display).Equals(0))
                this.throwError();
            else
                this.display = this.roundNumber((1/double.Parse(this.display)).ToString());           
        }

        private void putToMemory()
        {           
            this.display = this.roundNumber(this.display);
            this.memory = this.display;
        }

        private void getFromMemory()
        {
            this.display = this.memory;
            this.checkForSignAndDecimalPoint();
        }

        private void reset()
        {
            this.display = EMPTY;
            this.memory = EMPTY;
            this.firstOperand = EMPTY;
            this.lastOperator = '\0';
            this.calcState = state.init;
            this.decimalPointExists = false;
            this.numberIsSigned = false;
            this.operatorExists = false;
            this.lastPressedOperator = false;
        }

        private void calculate()
        {
            switch (this.lastOperator)
            {
                case '+':
                    this.add(this.firstOperand, this.display);
                    break;
                case '-':
                    this.substract(this.firstOperand, this.display);
                    break;
                case '*':
                    this.multiply(this.firstOperand, this.display);
                    break;
                case '/':
                    this.divide(this.firstOperand, this.display);
                    break;
                default:
                    throwError();
                    break;
            }
            
        }

        private void throwError()
        {
            this.display = "-E-";
        }
    }


}
