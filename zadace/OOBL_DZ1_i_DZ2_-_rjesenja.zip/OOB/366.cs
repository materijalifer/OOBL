﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string Name { get; set; }
        public decimal InitialPrice { get; set; }
        public long NumberOfShares { get; set; }
        public DateTime TimeStamp { get; set; }
        public List<StockPrice> StockPrices = new List<StockPrice>();

    }

    public class StockPrice : IComparable<StockPrice>
    {
        public decimal Price { get; set; }
        public DateTime TimeStamp { get; set; }

        public int CompareTo(StockPrice other)
        {
            var retVal = -1;
            if (!(TimeStamp >= other.TimeStamp))
                retVal = -1;
            else if (other.TimeStamp >= TimeStamp)
                retVal = 1;
            else if (Equals(TimeStamp, other.TimeStamp))
                retVal = 0;
            return retVal;
        }
    }

    public class Index
    {
        public IndexTypes IndexType { get; set; }
        public string IndexName { get; set; }

       public  List<String> Stocks = new List<String>() ;

        private bool StockInIndex(string stockName)
        {
            return Stocks.Contains(stockName);
        }
    }

    public class Portfolio
    {
        public string Id { get; set; }
        public List<PortfolioStocks> Stocks = new List<PortfolioStocks>(); // llista imena dionica portfelja
    }

    public class PortfolioStocks
    {
        public int NumberOfShares;
        public string StockName;
    }

    public class StockExchange : IStockExchange
    {
        public List<Stock> Stocks = new List<Stock>();
        public List<Index> Indices = new List<Index>();
        public List<Portfolio> Portfolios = new List<Portfolio>();

        public Stock GetStockByName(string stockName)
        {
            return Stocks.FirstOrDefault(stock => string.Equals(stock.Name, stockName, StringComparison.CurrentCultureIgnoreCase));
        }

        public Index GetIndexByName(string indexName)
        {
            return Indices.FirstOrDefault(index => string.Equals(index.IndexName, indexName, StringComparison.CurrentCultureIgnoreCase));
        }

        public Portfolio GetPortfolioById(string portfolioId)
        {
            return Portfolios.FirstOrDefault(portfolio => string.Equals(portfolio.Id, portfolioId));
        }

        public int NumberOfSharesInPortfolios(string stockName) // returns number od shares for stock in ALL portfolios
        {
            var sum = Portfolios.Sum(portfolio => portfolio.Stocks.Where(stock => stock.StockName == stockName).Sum(stock => stock.NumberOfShares));
            return sum;
        }

        public PortfolioStocks GetStockInPortfolioByName(string portfolioId,string stockName) //returns reference to stock in Portfolio
        {
            for (int i = 0; i < GetPortfolioById(portfolioId).Stocks.Count; i++)
            {
                PortfolioStocks stock = GetPortfolioById(portfolioId).Stocks[i];
                if (string.Equals(stock.StockName, stockName)) return stock;
            }
            return null;
        }


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (StockExists(inStockName) || inInitialPrice <= 0 || inNumberOfShares <= 0)
                 throw new StockExchangeException("Error");
             var stock = new Stock {Name = inStockName, InitialPrice = inInitialPrice, TimeStamp = inTimeStamp, NumberOfShares = inNumberOfShares};
             var stockPrice = new StockPrice {Price = inInitialPrice, TimeStamp = inTimeStamp};
             stock.StockPrices.Add(item: stockPrice);
             Stocks.Add(item: stock);
         }

         public void DelistStock(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Error");
             foreach (var stock in Stocks.Where(stock => string.Equals(stock.Name, inStockName, StringComparison.CurrentCultureIgnoreCase)))
                 Stocks.Remove(stock);
             foreach (var index in Indices)
                 index.Stocks.Remove(inStockName);
             foreach (var portfolio in from portfolio in Portfolios from stock in portfolio.Stocks.Where
                                           (stock => String.Equals(stock.StockName,inStockName,StringComparison.CurrentCultureIgnoreCase)) select portfolio)
             {
                 RemoveStockFromPortfolio(portfolio.Id,inStockName);
             }                                                                                            
         }

        public bool StockExists(string inStockName)
         {
             return Stocks != null && Stocks.Any(stock => string.Equals(stock.Name, inStockName, StringComparison.CurrentCultureIgnoreCase));
         }

        public int NumberOfStocks()
        {
            return Stocks != null ? Stocks.Count : 0;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            if (inStockValue <= 0 || !StockExists(inStockName))
                throw new StockExchangeException("Error");

            var stockPrice = new StockPrice { Price = inStockValue, TimeStamp = inIimeStamp };
            foreach (var stock in Stocks.Where(stock => string.Equals(stock.Name, inStockName, StringComparison.CurrentCultureIgnoreCase)))
            {
                stock.StockPrices.Add(stockPrice);
                stock.StockPrices.Sort();
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Error");
            var stock = GetStockByName(inStockName);
            for (var i = 0; i < stock.StockPrices.Count; i++)
            {
                var stockPrice = stock.StockPrices[i];
                if (stock.StockPrices.Count > i+1)
                {
                    var stockPrice1 = stock.StockPrices[i+1];
                    if (stockPrice.TimeStamp < inTimeStamp && inTimeStamp < stockPrice1.TimeStamp)
                        return stockPrice.Price;
                }
            }
            return stock.StockPrices.Last().Price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Error");
             return GetStockByName(inStockName).InitialPrice;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!StockExists(inStockName))
                 throw new StockExchangeException("Error");
             return GetStockByName(inStockName).StockPrices.Last().Price;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (IndexExists(inIndexName))
                 throw new StockExchangeException("Error");
             var index = new Index {IndexName = inIndexName, IndexType = inIndexType};
             Indices.Add(index);

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!StockExists(inStockName) || !IndexExists(inIndexName))
                 throw new StockExchangeException("Error");
             GetIndexByName(inIndexName).Stocks.Add(inStockName);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
            if ( !GetIndexByName(inIndexName).Stocks.Remove(inStockName))
                throw new StockExchangeException("Error");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return GetIndexByName(inIndexName).Stocks.Contains(inStockName);
         }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!IndexExists(inIndexName))
                 throw new StockExchangeException("Error");
            var index = GetIndexByName(inIndexName);
            var sum =
                    index.Stocks.Sum(stock => GetStockPrice(stock, inTimeStamp) * GetStockByName(stock).NumberOfShares);
            if (index.IndexType.Equals(1))
                return Math.Round(sum /= index.Stocks.Count, 3);
            var factors = index.Stocks.Select(stock => GetStockPrice(stock, inTimeStamp)/sum).ToList();
            decimal sums = 0;
            for (int i = 0; i < index.Stocks.Count; i++)
                sums += factors[i]*GetStockPrice(index.Stocks[i], inTimeStamp)*GetStockByName(index.Stocks[i]).NumberOfShares;
            return Math.Round(sums, 3);
         }

         public bool IndexExists(string inIndexName)
         {
             return Indices.Any(index => string.Equals(index.IndexName, inIndexName, StringComparison.CurrentCultureIgnoreCase));
         }

        public int NumberOfIndices()
         {
             return Indices != null ? Indices.Count : 0;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             var index = GetIndexByName(inIndexName);
             return index.Stocks != null ? index.Stocks.Count : 0;
         }


        public void CreatePortfolio(string inPortfolioID)
         {
            if (Portfolios.Contains(GetPortfolioById(inPortfolioID)))
                throw new StockExchangeException("Error");

            var portfolio = new Portfolio {Id = inPortfolioID};
            Portfolios.Add(portfolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!Portfolios.Contains(GetPortfolioById(inPortfolioID))||!StockExists(inStockName)|| GetStockByName(inStockName).NumberOfShares<numberOfShares)
                 throw new StockExchangeException("Error");
             var portfolio = GetPortfolioById(inPortfolioID);
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 foreach (var stock in portfolio.Stocks.Where(stock => String.Equals(stock.StockName, inStockName, StringComparison.CurrentCultureIgnoreCase)))
                 {
                     if (numberOfShares + stock.NumberOfShares > GetStockByName(inStockName).NumberOfShares)
                         throw new StockExchangeException("Error");
                     stock.NumberOfShares += numberOfShares;
                 }
             }
             else
             {
                 var stockPortfolio = new PortfolioStocks {NumberOfShares = numberOfShares, StockName = inStockName};
                 portfolio.Stocks.Add(stockPortfolio);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID) || !IsStockPartOfPortfolio(inPortfolioID, inStockName) ||
                 GetStockInPortfolioByName(inPortfolioID, inStockName).NumberOfShares <= numberOfShares)
                 throw new StockExchangeException("Error");
             GetStockInPortfolioByName(inPortfolioID, inStockName).NumberOfShares -= numberOfShares;
         }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID) || !IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 throw new StockExchangeException("Error");
             GetPortfolioById(inPortfolioID).Stocks.Remove(GetStockInPortfolioByName(inPortfolioID,inStockName));
         }

         public int NumberOfPortfolios()
         {
             return Portfolios != null ? Portfolios.Count : 0;
         }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Error");
            var portfolio = GetPortfolioById(inPortfolioID);
            return portfolio.Stocks.Count();
        }

         public bool PortfolioExists(string inPortfolioID)
         {
             return Portfolios.Contains(GetPortfolioById(inPortfolioID));
         }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
            if (!PortfolioExists(inPortfolioID))
                throw new StockExchangeException("ERROR");

            var portfolio = GetPortfolioById(inPortfolioID);
            return portfolio.Stocks.Any(portfolioStocks => String.Equals(portfolioStocks.StockName, inStockName));
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID)|| !IsStockPartOfPortfolio(inPortfolioID,inStockName))
                 throw new StockExchangeException("Error");
             var portfolio = GetPortfolioById(inPortfolioID);
             var firstOrDefault = portfolio.Stocks.FirstOrDefault(stock => String.Equals(stock.StockName, inStockName));
             return firstOrDefault != null ? firstOrDefault.NumberOfShares : 0;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("ERROR");
             var portfolio = GetPortfolioById(inPortfolioID);
             return Math.Round(portfolio.Stocks.Sum(stock => GetStockPrice(stock.StockName, timeStamp)*stock.NumberOfShares),3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("ERROR");
             var startSum = GetPortfolioValue(inPortfolioID,new DateTime(Year,Month,1,0,0,0,0));
             var endSum = GetPortfolioValue(inPortfolioID,new DateTime(Year,Month,DateTime.DaysInMonth(Year,Month),23,59,59,999));

             return Math.Round(endSum/startSum, 3)*100;

         }
     }
}
