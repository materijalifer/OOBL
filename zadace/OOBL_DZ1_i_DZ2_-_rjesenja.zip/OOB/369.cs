﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         List<Stock> stocksOnMarket = new List<Stock>();
         List<Index> indicesOnMarket = new List<Index>(); 
         List<Portfolio> portfoliosOnMarket = new List<Portfolio>(); 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if ((!StockExists(inStockName)) && (inNumberOfShares > 0) && (inInitialPrice > 0))
             {
                 Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);

                 stocksOnMarket.Add(newStock);
             }
             else if (StockExists(inStockName))
             {
                 throw new StockExchangeException("Dionica s tim imenom već postoji!");
             }
             else if (inNumberOfShares < 0)
             {
                 throw new StockExchangeException("Broj dionica mora biti pozitivan broj!");
             }
             else if (inInitialPrice < 0)
             {
                 throw new StockExchangeException("Cijena dionica mora biti pozitivan broj!");
             }
         }

         public void DelistStock(string inStockName)
         {
             Stock stockToRemove = GetStock(inStockName);

             stocksOnMarket.Remove(stockToRemove);

             foreach (Index index in indicesOnMarket)
             {
                if (index.DoesContainStock(stockToRemove))
                    index.RemoveStock(stockToRemove);
             }

             foreach (Portfolio portfolio in portfoliosOnMarket)
             {
                if (portfolio.DoesContainStock(stockToRemove.Name))
                    portfolio.RemoveStock(stockToRemove);
             }
         }

         public bool StockExists(string inStockName)
         {
             bool stockExists = false;

             foreach (Stock stock in stocksOnMarket)
             {
                if (stock.Name.ToUpper() == inStockName.ToUpper())
                    stockExists = true;
             }

             return stockExists;
         }

         public Stock GetStock(string inStockName)
         {
             foreach (Stock stock in stocksOnMarket)
             {
                 if (stock.Name.ToUpper() == inStockName.ToUpper())
                     return stock;
             }

             throw new StockExchangeException("Dionica ne postoji!");
         }

         public int NumberOfStocks()
         {
             return stocksOnMarket.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock = GetStock(inStockName);

             if (inStockValue > 0)
             {
                 stock.SetPrice(inStockValue, inIimeStamp);
             }
             else
             {
                 throw new StockExchangeException("Cijena dionice mora biti pozitivna!");
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock = GetStock(inStockName);

             return stock.GetPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock = GetStock(inStockName);

             return stock.GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock = GetStock(inStockName);

             return stock.GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if ((inIndexType != IndexTypes.AVERAGE) && (inIndexType != IndexTypes.WEIGHTED))
             {
                 throw new StockExchangeException("Tip indeksa mora biti AVERAGE ili WEIGHTED!");
             }

             if (!IndexExists(inIndexName))
             {
                 Index index = new Index(inIndexName, inIndexType);

                 indicesOnMarket.Add(index);
             }
             else
             {
                 throw new StockExchangeException("Indeks s navedenim imenom već postoji!");
             }
             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stock = GetStock(inStockName);

             if (stocksOnMarket.Contains(stock))
             {
                 index.AddStock(stock);
             }
             else
             {
                 throw new StockExchangeException("U indeks se mogu dodavati samo dionice koje su na tržištu!");
             }
             
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stock = GetStock(inStockName);

             index.RemoveStock(stock);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             Index index = GetIndex(inIndexName);
             Stock stock = GetStock(inStockName);

             return index.DoesContainStock(stock);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index = GetIndex(inIndexName);

             return index.GetValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             bool indexExists = false;

             foreach (Index index in indicesOnMarket)
             {
                 if (index.Name.ToUpper() == inIndexName.ToUpper())
                     indexExists = true;
             }

             return indexExists;
         }

         public Index GetIndex(string inIndexName)
         {
             foreach (Index index in indicesOnMarket)
             {
                 if (index.Name.ToUpper() == inIndexName.ToUpper())
                     return index;
             }

             throw new StockExchangeException("Indeks ne postoji!");
         }

         public int NumberOfIndices()
         {
             return indicesOnMarket.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index = GetIndex(inIndexName);

             return index.NumberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);

                 portfoliosOnMarket.Add(portfolio);
             }
             else
             {
                 throw new StockExchangeException("Portfolio s navedenim ID-jem već postoji!");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             Stock stock = GetStock(inStockName);

             portfolio.AddStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             Stock stock = GetStock(inStockName);

             portfolio.RemoveStock(stock, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);
             Stock stock = GetStock(inStockName);

             portfolio.RemoveStock(stock);
         }

         public int NumberOfPortfolios()
         {
             return portfoliosOnMarket.Count;
         }

         public Portfolio GetPortfolio(string inPortfolioID)
         {
             foreach (Portfolio portfolio in portfoliosOnMarket)
             {
                 if (portfolio.ID.ToUpper() == inPortfolioID.ToUpper())
                     return portfolio;
             }

             throw new StockExchangeException("Portfolio ne postoji!");
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);

             return portfolio.GetNumberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             bool portfolioExists = false;

             foreach (Portfolio portfolio in portfoliosOnMarket)
             {
                 if (portfolio.ID == inPortfolioID)
                     portfolioExists = true;
             }

             return portfolioExists;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);

             return portfolio.DoesContainStock(inStockName);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);

             return portfolio.GetNumberOfShares(inStockName);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);

             return portfolio.GetValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio = GetPortfolio(inPortfolioID);

             if ((Year > 0) && (Month >= 1) && (Month <= 12))
             {
                 return portfolio.GetPercentChange(Year, Month);
             }
             else if (Year <= 0)
             {
                 throw new StockExchangeException("Godina mora biti pozitivan broj!");
             }
             else
             {
                 throw new StockExchangeException("Mjesec mora biti broj između 1 i 12!");
             }
             
         }
     }

     public class Stock
     {
         private string name;
         private long numberOfShares;
         private long sharesInPortfolios = 0;
         private decimal currentPrice;
         private decimal weightedFactor;
         private DateTime timeStamp;
         private SortedDictionary<DateTime, decimal> priceHistory = new SortedDictionary<DateTime, decimal>();

         #region Properties
         public string Name
         {
             get { return name; }
             set { name = value; }
         }

         public long NumberOfShares
         {
             get { return numberOfShares; }
             set { numberOfShares = value; }
         }

         public decimal CurrentPrice
         {
             get { return currentPrice; }
             set { currentPrice = value; }
         }
         public DateTime TimeStamp
         {
             get { return timeStamp; }
             set { timeStamp = value; }
         }

         public decimal WeightedFactor
         {
             get { return weightedFactor; }
             set { weightedFactor = value; }
         }

         public long SharesInPortfolios
         {
             get { return sharesInPortfolios; }
             set { sharesInPortfolios = value; }
         }
         #endregion

         #region Constructor
         public Stock(string name, long numberOfShares, decimal initialPrice, DateTime timeStamp)
         {
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica mora biti veći od nule!");
             }

             if (initialPrice <= 0)
             {
                 throw new StockExchangeException("Cijena dionica mora biti veća od nule!");
             }

             this.name = name;
             this.numberOfShares = numberOfShares;
             this.currentPrice = initialPrice;
             this.timeStamp = timeStamp;

             priceHistory.Add(timeStamp, initialPrice);
         }
        #endregion

         #region Methods
         public void SetPrice(decimal newPrice, DateTime timeStamp)
         {
             if (!priceHistory.ContainsKey(timeStamp))
             {
                 priceHistory.Add(timeStamp, newPrice);

                 this.currentPrice = priceHistory.Last().Value;
                 this.timeStamp = priceHistory.Last().Key;
             }
             else
             {
                 throw new StockExchangeException("Cijena za taj trenutak je već postavljena!");
             }
             
         }

         public decimal GetPrice(DateTime timeStamp)
         {
             if (timeStamp >= this.timeStamp)
             {
                 return this.GetLastPrice();
             }
             else
             {
                 for (int i = 0; i < priceHistory.Count; i++)
                 {
                     if ((timeStamp >= priceHistory.ElementAt(i).Key) && (timeStamp < priceHistory.ElementAt(i+1).Key))
                     {
                         return priceHistory.ElementAt(i).Value;
                     }
                 }
             }

             throw new StockExchangeException("Cijena dionice nije postavljena za taj trenutak!");
         }

         public decimal GetInitialPrice()
         {
             return priceHistory.First().Value;
         }

         public decimal GetLastPrice()
         {
             return priceHistory.Last().Value;
         }
        #endregion
     }

    public class Index
    {
         private string name;
         private IndexTypes type;
         private List<Stock> stocks = new List<Stock>();

         #region Properties
         public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public IndexTypes Type
        {
            get { return type; }
            set { type = value; }
        }
        #endregion

         #region Constructor
        public Index(string name, IndexTypes type)
        {
            this.name = name;
            this.type = type;
        }
        #endregion

         #region Methods
        public void AddStock(Stock stock)
        {
            if (!stocks.Contains(stock))
            {
                stocks.Add(stock);
            }
            else
            {
                throw new StockExchangeException("Indeks već sadrži navedenu dionicu!");
            } 
        }

        public void RemoveStock(Stock stock)
        {
            if (stocks.Contains(stock))
            {
                stocks.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Indeks ne sadrži navedenu dionicu!");
            }
        }

        public bool DoesContainStock(Stock stock)
        {
            if (stocks.Contains(stock))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
        }

        public decimal GetValue(DateTime time)
        {
            if (this.Type == IndexTypes.AVERAGE)
            {
                return this.CalculateAverage(time);
            }
            else
            {
                return this.CalculateWeighted(time);
            }
        }

        private decimal CalculateAverage(DateTime time)
        {
            if (stocks.Count == 0)
            {
                return 0;
            }
            else
            {
                decimal sum = 0;

                foreach (Stock stock in stocks)
                {
                    sum += stock.GetPrice(time);
                }

                decimal average = sum/stocks.Count;
                return Math.Round(average, 3);
            }
            
        }

        private decimal CalculateWeighted(DateTime time)
        {
            decimal sum = 0;
            decimal weightedWorth = 0;

            foreach (Stock stock in stocks)
            {
                decimal price = stock.GetPrice(time);
                sum += price*stock.NumberOfShares;
            }

            foreach (Stock stock in stocks)
            {
                decimal price = stock.GetPrice(time);
                stock.WeightedFactor = price/sum;

                weightedWorth += price*stock.WeightedFactor*stock.NumberOfShares;
            }

            weightedWorth = Math.Round(weightedWorth, 3);
            return weightedWorth;
        }
        #endregion
    }

    public class Portfolio
    {
        private string id; 
        private Dictionary<string, int> stocks = new Dictionary<string, int>(); 
        private List<Stock> stocksInPortfolio = new List<Stock>();

        #region Properties
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        #endregion

        #region Constructor
        public Portfolio(string ID)
        {
            this.id = ID;
        }
        #endregion

        #region Methods
        public bool DoesContainStock(String stockName)
        {
            if (stocks.ContainsKey(stockName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void AddStock(Stock stock, int numberOfShares)
        {
            if (!stocks.ContainsKey(stock.Name) && ((stock.SharesInPortfolios + numberOfShares) <= stock.NumberOfShares))
            {
                stocks.Add(stock.Name, numberOfShares);
                stocksInPortfolio.Add(stock);

                stock.SharesInPortfolios += numberOfShares;
            }
            else if (stocks.ContainsKey(stock.Name) && ((stock.SharesInPortfolios + numberOfShares) <= stock.NumberOfShares))
            {
                stocks[stock.Name] += numberOfShares;

                stock.SharesInPortfolios += numberOfShares;
            }
            else
            {
                throw new StockExchangeException("Nema toliko neraspodijeljenih dionica!");
            }
        }


        public void RemoveStock(Stock stock, int numberOfShares)
        {
            if (stocks.ContainsKey(stock.Name))
            {
                if (numberOfShares >= stocks[stock.Name])
                {
                    RemoveStock(stock);
                }
                else
                {
                    stocks[stock.Name] -= numberOfShares;
                }
            }
            else
            {
                throw new StockExchangeException("Navedena dionica ne postoji u portfelju!");
            }
        }

        public void RemoveStock(Stock stock)
        {
            if (stocks.ContainsKey(stock.Name))
            {
                stocks.Remove(stock.Name);
                stocksInPortfolio.Remove(stock);
            }
            else
            {
                throw new StockExchangeException("Navedena dionica ne postoji u portfelju!");
            }
        }

        public int GetNumberOfStocks()
        {
            return stocks.Count;
        }

        public int GetNumberOfShares(string stockName)
        {
            if (stocks.ContainsKey(stockName))
            {
                return stocks[stockName];
            }
            else
            {
                throw new StockExchangeException("Portfolio ne sadrži traženu dionicu!");
            }
        }

        public decimal GetValue(DateTime time)
        {
            decimal value = 0;

            foreach (Stock stock in stocksInPortfolio)
            {
                int numberOfShares = stocks[stock.Name];

                value += numberOfShares*stock.GetPrice(time);
            }

            return Math.Round(value, 3);
        }

        public decimal GetPercentChange(int year, int month)
        {
            decimal valueBefore = 0;
            decimal valueAfter = 0;

            foreach (Stock stock in stocksInPortfolio)
            {
                int numberOfShares = stocks[stock.Name];

                valueBefore += numberOfShares * stock.GetPrice(new DateTime(year, month, 1, 0, 0, 0));
                valueAfter += numberOfShares*
                              stock.GetPrice(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
            }

            if (valueBefore == 0)
            {
                return 0;
            }
            else
            {
                decimal value = 0;
                value = (valueAfter / valueBefore - 1) * 100;
                return Math.Round(value, 3);
                
            }
        }
        #endregion
    }
}
