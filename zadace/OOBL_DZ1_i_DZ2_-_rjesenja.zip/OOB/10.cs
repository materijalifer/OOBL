﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        //string[] numberA = new string[10];
        //StringBuilder numberA = new StringBuilder(null, 10);
        string numberA;
        string numberB;
        bool dec = false;
        char operat;
        char operatOld;
        string display;
        string mem;
        int maxLength = 10;
        string defaultDisplay = "0";
        char empty = '\0';
        string error = "-E-";

        public void Press(char inPressedDigit)
        {
            char[] symbols = { '+', '-', '*', '/', '=' };

            if (Char.IsDigit(inPressedDigit)) 
            {
                if (operat.Equals(empty))
                {
                    numberA = Number(numberA, inPressedDigit);
                }
                else
                {
                    numberB = Number(numberB, inPressedDigit);
                }
            }
            
            else if (Char.IsLetter(inPressedDigit)) 
            {
                if (dec) DefineDecNumber();
                display = UnaryOperation(DefineNumber(), inPressedDigit);
                
            }
           
            else if (symbols.Contains(inPressedDigit)) 
            {
                if (dec) DefineDecNumber();
                if (operat.Equals(empty)) BinaryOperation(inPressedDigit);
                if (inPressedDigit.Equals('=') && String.IsNullOrEmpty(numberB)) BinaryOperation(inPressedDigit);
                else
                {
                    operatOld = operat;
                    BinaryOperation(operat);
                    operat = inPressedDigit;
                }
            }
            else if (Char.IsPunctuation(inPressedDigit) && (dec == false)) OtherOperation(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            if (String.IsNullOrEmpty(display)) return defaultDisplay;
            return display;
        }

        public string DefineNumber()
        {
            string number;

            if (String.IsNullOrEmpty(numberB))
            {
               number = numberA;
            }
            else
            {
                number = numberB;
            }

            return number;
        }

        public void DefineDecNumber()
        {
            if (String.IsNullOrEmpty(numberB))
            {
                numberA = DoDecimal(numberA);
                display = numberA;
            }

            else
            {
                numberB = DoDecimal(numberB);
                display = numberB;
            } 
        }
        
        public void SaveNumber(string num)
        {
            if (operat.Equals(empty))
            {
                numberA = num;
            }
            else if (String.IsNullOrEmpty(numberB))
            {
                numberA = num;
            }
            else
            {
                numberB = num;
            }
        }

        public string Number(string num, char input)
        {
            if (String.IsNullOrEmpty(num) || num.Equals(defaultDisplay))
            {
                num = input.ToString();
                display = num;
            }
            else if (num.Length < maxLength || dec)
            {
                num += input.ToString();
                display = num;
            }
            else
            {
                display = error;
            }
               
            return num;
        }

        public string DoDecimal(string num)
        {
            double numMath;
            int numInt;
            string round;

            numMath = Convert.ToDouble(num);
            numInt = Convert.ToInt32(numMath);
            round = numInt.ToString();
            numMath = Math.Round(numMath, (maxLength - round.Length));
            num = numMath.ToString();
            return num;

        }

        public string BinaryOperation(char input)
        {
            dec = false;
            double numMath;
            double numMath2;
          //  if (String.IsNullOrEmpty(numberA)) numberA = "0";
            Double.TryParse(numberA, out numMath);
            Double.TryParse(numberB, out numMath2);
           // double numMath = double.Parse(numberA + 1);
          //  double numMath2 = Convert.ToDouble(numberB);
            double result;

            switch (input)
            {
                
                case '-':
                    {
                        operat = input;
                        result = numMath - numMath2;
                        if (result.ToString().Length <= maxLength) display = result.ToString();
                        else display = error;
                    }
                    break;
                case '+':
                    {
                        operat = input;
                        result = numMath + numMath2;
                        display = result.ToString();
                        if (result.ToString().Length <= maxLength) display = result.ToString();
                        else display = error;
                    }
                    break;
                case '*':
                    {
                        operat = input;
                        result = numMath * numMath2;
                        display = result.ToString();
                        if (result.ToString().Length <= maxLength) display = result.ToString();
                        else display = error;
                    }
                    break;
                case '/':
                    {
                        operat = input;
                        result = numMath / numMath2;
                        display = result.ToString();
                        if (display == "Infinity") display = error;
                        else if (result.ToString().Length <= maxLength) display = result.ToString();
                        else display = error;
                    }
                    break;
                case '=':
                    {
                        if (String.IsNullOrEmpty(display)) display = "0";
                        if (String.IsNullOrEmpty(numberB) && !String.IsNullOrEmpty(numberA))
                        {
                            numberB= String.Copy(numberA);
                            BinaryOperation(operatOld);
                        }
                        operat = empty;
                    }
                    break;
            /*    default:
                    {
                        display = "-E-";
                    }
                    break;*/
            }

            return display;
        }

        public string UnaryOperation(string number, char input)
        {
            double numMath = Convert.ToDouble(number);
           // double numMath2 = Convert.ToDouble(numberB);
            double result;

            switch (Char.ToUpper(input))
            {
                case 'M':
                    {
                        result = -numMath;
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                         
                    }
                    break;
                case 'S':
                    {
                        result = Math.Sin(numMath);
                        result = Math.Round(result, 9);
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                    }
                    break;
                case 'K':
                    {
                        result = Math.Cos(numMath);
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                    }
                    break;
                case 'T':
                    {
                        result = Math.Tan(numMath);
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                    }
                    break;
                case 'Q':
                    {
                        result = Math.Pow(numMath, 2);
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                    }
                    break;
                case 'R':
                    {
                        result = Math.Sqrt(numMath);
                        number = result.ToString();
                        if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                        else SaveNumber(number);
                        display = result.ToString();
                    }
                    break;
                case 'I':
                    {
                        result = 1/numMath;
                        number = result.ToString();
                        if (number == "Infinity") display = error;
                        else
                        {
                            if (!operat.Equals(empty) && String.IsNullOrEmpty(numberB)) display = result.ToString();
                            else SaveNumber(number);
                            display = result.ToString();
                        }
                    }
                    break;
                case 'P':
                    {

                        mem = numMath.ToString();
                    }
                    break;
                case 'G':
                    {
                        result = Convert.ToDouble(mem);
                        display = result.ToString();
                    }
                    break;
                case 'O':
                    {
                        mem = null;
                        display = null;
                        operat = empty;
                        numberA = null;
                        numberB = null;
                    }
                    break;
                case 'C':
                    {
                        display = defaultDisplay;
                    }
                    break;
                default:
                    {
                        display = "-E-";
                    }
                    break;
            }

            return display;

        }

        public string OtherOperation(char input)
        {
            switch (input)
            {
                case ',':
                    {
                        dec = true;
                        if (operat.Equals(empty) && String.IsNullOrEmpty(numberA))
                        {
                           // maxLength = maxLength + 1;
                            numberA = "0";
                            numberA += input;
                            display = numberA;
                        }
                        else if (operat.Equals(empty) && String.IsNullOrEmpty(numberB))
                        {
                           // maxLength = maxLength + 1;
                            numberA += input;
                            display = numberA;
                        }
                        else if (String.IsNullOrEmpty(numberB))
                        {
                            numberB = "0";
                            numberB += input;
                            display = numberB;
                        }
                        else
                        {
                            numberB += input;
                            display = numberB;
                        }
                        
                    }
                    break;
            }
            return display;
        }
    }


}
