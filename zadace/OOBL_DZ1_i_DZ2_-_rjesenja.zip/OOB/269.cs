﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private readonly string errCode_ = "-E-";

        private readonly string defaultScreen_ = "0";
        // decimalni zarez
        private readonly string decimalPoint_ = ",";
        // max brojeva na ekranu
        private readonly int maxScreenLength_ = 10;
        // decimalni zarez
       // private bool hasDecimalPoint_ = false;
        // predznak : T = + ; F = -
        private bool foretoken_ = true;
        // stanje ekrana
        private string screen_ = "0";
        //memorija
        private string memory_ = "";
        //aktivni binarni operator
        private char op_ = ' ';
        //
        private bool binaryLast_ = false;

        private string lastN_ = "";

        public Kalkulator()
        {
        }

        private bool hasDecimalPoint_()
        {
            if (screen_.IndexOf(decimalPoint_) != -1)
                return true;
            return false;
        }
        private void clearLeadingZeros()
        {
            if ((screen_.IndexOf(decimalPoint_)) != 1)
            {
                while (screen_.StartsWith("0"))
                {
                    screen_ = screen_.Substring(1);
                }
            }
        }
        private string tokenize()
        {
            return (foretoken_ ? "" : "-") + screen_;
        }

        private bool isVoid()
        {
            if (screen_.Equals(defaultScreen_))
                return true;
            return false;
        }

        private bool checkForSize()
        {
            if (screen_.Length > (maxScreenLength_+(hasDecimalPoint_() ? 1 : 0)))
            {
                return false;
            }
            return true;
        }

        private void roundToFit()
        {
            double buf = Convert.ToDouble(screen_);
            buf = Math.Round(buf, 10 - screen_.IndexOf(decimalPoint_) + (buf < 0 ? 1 : 0));
            screen_ = Convert.ToString(buf);
        }
        

        private void trim()
        {
            if (screen_ != errCode_)
            {
                if (Convert.ToDouble(screen_) >= 10000000000)
                {
                    screen_ = errCode_;
                }
                else if (!checkForSize())
                {
                    if (hasDecimalPoint_())
                    {
                        roundToFit();
                    }
                    else
                    {
                        screen_ = errCode_;
                    }
                }
                else
                {
                    screen_ = Convert.ToString(Convert.ToDouble(screen_));
                }
            }
        }

        private void keyOperator_(char op)
        {
            trim();
            if (op_ != ' ' && !binaryLast_)
            {
                binaryOperator();
            }
            op_ = op;
            if (!binaryLast_)
            {
                lastN_ = tokenize();
            }
            foretoken_ = true;
            //hasDecimalPoint_ = false;
            screen_ = defaultScreen_;
            //binaryLast_ = true;
        }

        private void binaryOperator()
        {
            double first = Convert.ToDouble(lastN_);
            double second = Convert.ToDouble(tokenize());

            switch(op_){
                case '+':
                    screen_ = Convert.ToString(first + second);
                    break;
                case '-':
                    screen_ = Convert.ToString(first - second);
                    break;
                case '*':
                    screen_ = Convert.ToString(first * second);
                    break;
                case '/':
                    screen_ = Convert.ToString(first / second);
                    break;
                default:
                    break;

            }
            trim();
            foretoken_ = true;
        }

        private void keyM_()
        {
            if (!isVoid())
            {
                foretoken_ = !foretoken_;
            }
        }

        private void keyDec_()
        {
            if (!hasDecimalPoint_())
            {
                screen_ += decimalPoint_;
                //hasDecimalPoint_ = true;
            }
            else
            {
                screen_ = errCode_;
            }
        }
        private void keySin_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(Math.Sin(Convert.ToDouble(lastN_)));
            }
            else
            {
                screen_ = Convert.ToString(Math.Sin(Convert.ToDouble(screen_)));
            }
            trim();
        }

        private void keyCos_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(Math.Cos(Convert.ToDouble(lastN_)));
            }
            else
            {
                screen_ = Convert.ToString(Math.Cos(Convert.ToDouble(screen_)));
            } 
            trim();
        }

        private void keyTan_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(Math.Tan(Convert.ToDouble(lastN_)));
            }
            else
            {
                screen_ = Convert.ToString(Math.Tan(Convert.ToDouble(screen_)));
            } 
            trim();
        }

        private void keySquare_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(Math.Pow(Convert.ToDouble(lastN_),2));
            }
            else
            {
                screen_ = Convert.ToString(Math.Pow(Convert.ToDouble(screen_),2));
            } 
            trim();
        }

        private void keyRoot_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(Math.Sqrt(Convert.ToDouble(lastN_)));
            }
            else
            {
                screen_ = Convert.ToString(Math.Sqrt(Convert.ToDouble(screen_)));
            } 
            trim();
        }

        private void keyInv_()
        {
            if (binaryLast_)
            {
                lastN_ = Convert.ToString(1.0 / Convert.ToDouble(lastN_));
            }
            else
            {
                screen_ = Convert.ToString(1.0 / Convert.ToDouble(screen_));
            }
            trim();
        }

        private void keyMemp_()
        {
            memory_ = screen_;
        }

        private void keyMemg_()
        {
            screen_ = memory_;
        }

        private void keyClear_()
        {
            screen_ = defaultScreen_;
            foretoken_ = true;
        }

        private void keyReset_()
        {
            screen_ = defaultScreen_;
            memory_ = "";
            lastN_ = "";
            //hasDecimalPoint_ = false;
            foretoken_ = true;
            op_ = ' ';
        }

        private void keyEqual_()
        {
            if (binaryLast_)
            {
                screen_ = lastN_;
            }

            if (op_ != ' ')
            {
                binaryOperator();
            }

            trim();
        }

        public void Press(char inPressedDigit)
        {
            switch (inPressedDigit)
            {
                case 'M': 
                    keyM_(); 
                    break;
                case ',':
                    keyDec_(); 
                    break;
                case 'S':
                    keySin_();
                    break;
                case 'K':
                    keyCos_();
                    break;
                case 'T':
                    keyTan_();
                    break;
                case 'Q':
                    keySquare_();
                    break;
                case 'R':
                    keyRoot_();
                    break;
                case 'I':
                    keyInv_();
                    break;
                case 'P':
                    keyMemp_();
                    break;
                case 'G':
                    keyMemg_();
                    break;
                case 'C':
                    keyClear_();
                    break;
                case 'O':
                    keyReset_();
                    break;
                case '+':
                    keyOperator_(inPressedDigit);
                    break;
                case '-':
                    keyOperator_(inPressedDigit);
                    break;
                case '*':
                    keyOperator_(inPressedDigit);
                    break;
                case '/':
                    keyOperator_(inPressedDigit);
                    break;
                case '=':
                    keyEqual_();
                    break;
                default:
                    if (!(screen_.Length == (10 + (hasDecimalPoint_() ? 1 : 0)))){
                        clearLeadingZeros();
                        screen_ += inPressedDigit;
                    }
                    break;
            }
            if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/' 
                || binaryLast_ && (inPressedDigit == 'S' || inPressedDigit == 'K'|| inPressedDigit =='I' || inPressedDigit == 'R'
                                    || inPressedDigit =='Q' || inPressedDigit =='T'))
                binaryLast_ = true;
            else
                binaryLast_ = false;
        }

        public string GetCurrentDisplayState()
        {
            return binaryLast_? lastN_:tokenize();
        }


    }


}
