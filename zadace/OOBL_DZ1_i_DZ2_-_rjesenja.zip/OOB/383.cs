﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         Dictionary<string, Stock> stockCollection = new Dictionary<string, Stock>();
         Dictionary<string, Index> indexCollection = new Dictionary<string, Index>();
         Dictionary<string, Portfolio> portfolioCollection = new Dictionary<string, Portfolio>(); 

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (stockCollection.Keys.Contains(inStockName.ToUpper())) throw new StockExchangeException("Zadana dionica već postoji");
             if (inInitialPrice == 0) throw new StockExchangeException("Cijena ne moze biti nula");
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stockCollection.Add(inStockName.ToUpper(), stock);
         }

         public void DelistStock(string inStockName)
         {
             if (!stockCollection.Keys.Contains(inStockName.ToUpper())) throw new StockExchangeException("Dionicu nije moguće obrisati jer ne postoji");
             stockCollection.Remove(inStockName.ToUpper());

             string[] keys = indexCollection.Keys.ToArray();
             foreach (string key in keys)
             {
                 Index index = indexCollection[key];
                 if (index.indexStocks.Contains(inStockName.ToUpper()))
                     index.indexStocks.Remove(inStockName.ToUpper());
             }

             keys = portfolioCollection.Keys.ToArray();
             foreach (string key in keys)
             {
                 Portfolio portfolio = portfolioCollection[key];
                 if (portfolio.stocksInPortfolio.ContainsKey(inStockName.ToUpper()))
                     portfolio.stocksInPortfolio.Remove(inStockName.ToUpper());
             }
         }

         public bool StockExists(string inStockName)
         {
             return stockCollection.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return stockCollection.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             
             Stock stock;
             try{
                 stock = stockCollection[inStockName.ToUpper()];
             } catch (KeyNotFoundException){
                 throw new StockExchangeException("Ne postoji dionica sa traženim imenom");
             }
             StockPriceHistory history = new StockPriceHistory(inStockValue, inIimeStamp);
             List<StockPriceHistory> historyList = stock.priceHistory;

             foreach (StockPriceHistory price in historyList)
             {
                 if (price.stockTime.Equals(inIimeStamp)) throw new StockExchangeException("Postoji već vrijednost za zadano vrijeme i dionicu");
             }

             stock.priceHistory.Add(history);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock;
             try
             {
                 stock = stockCollection[inStockName.ToUpper()];
             }
             catch (KeyNotFoundException)
             {
                 throw new StockExchangeException("Ne postoji dionica sa traženim imenom");
             }

             List<StockPriceHistory> historyList = stock.priceHistory;
             double timeDifference = -1;
             Decimal bestTimePrice = 0;

             foreach (StockPriceHistory stockHistory in historyList)
             {
                 DateTime startTime = stockHistory.stockTime;
                 double difference = inTimeStamp.Subtract(startTime).TotalMilliseconds;
                 if (difference < 0) continue;
                 else
                 {
                     if (timeDifference == -1)
                     {
                         timeDifference = difference;
                         bestTimePrice = stockHistory.stockPrice;
                     }
                     else
                     {
                         if (difference < timeDifference)
                         {
                             timeDifference = difference;
                             bestTimePrice = stockHistory.stockPrice;
                         }
                     }
                 }
             }

             if (timeDifference == -1) throw new StockExchangeException("Ne postoji nijedna vrijednost dionice za traženo vrijeme");

             return bestTimePrice;

         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock;
             try
             {
                 stock = stockCollection[inStockName.ToUpper()];
             }
             catch (KeyNotFoundException)
             {
                 throw new StockExchangeException("Ne postoji dionica sa traženim imenom");
             }
             List<StockPriceHistory> historyList = stock.priceHistory;
             Decimal bestTimePrice = historyList[0].stockPrice;
             DateTime bestTime = historyList[0].stockTime;

             for (int i = 1; i < historyList.Count; i++)
             {
                 StockPriceHistory stockHistory = historyList[i];
                 DateTime newTime = stockHistory.stockTime;
                 int result = DateTime.Compare(bestTime, newTime);
                 if (result > 0)
                 {
                     bestTime = newTime;
                     bestTimePrice = stockHistory.stockPrice;
                 }

             }

             return bestTimePrice;

         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock;
             try
             {
                 stock = stockCollection[inStockName.ToUpper()];
             }
             catch (KeyNotFoundException)
             {
                 throw new StockExchangeException("Ne postoji dionica sa traženim imenom");
             }
             List<StockPriceHistory> historyList = stock.priceHistory;
             Decimal lastTimePrice = historyList[0].stockPrice;
             DateTime lastTime = historyList[0].stockTime;
             

             for (int i = 1; i < historyList.Count; i++)
             {
                 StockPriceHistory stockHistory = historyList[i];
                 DateTime newTime = stockHistory.stockTime;
                 int result = DateTime.Compare(lastTime, newTime);
                 if (result < 0)
                 {
                     lastTime = newTime;
                     lastTimePrice = stockHistory.stockPrice;
                 }

             }

             return lastTimePrice;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (indexCollection.Keys.Contains(inIndexName.ToUpper())) throw new StockExchangeException("Index sa tim imenom već postoji");
             if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED) throw new StockExchangeException("Ne postoji takav tip indeksa");
             Index index = new Index(inIndexName, inIndexType);
             indexCollection.Add(inIndexName.ToUpper(), index);
         }

         public void AddStockToIndex(string inIndexsName, string inStockName)
         {
             if (!stockCollection.Keys.Contains(inStockName.ToUpper())) throw new StockExchangeException("Zadana dionica ne postoji na burzi");
             if (!indexCollection.Keys.Contains(inIndexsName.ToUpper())) throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
             Index index = indexCollection[inIndexsName.ToUpper()];
             if (index.indexStocks.Contains(inStockName.ToUpper())) throw new StockExchangeException("Dionica je već dodana u index");
             index.indexStocks.Add(inStockName.ToUpper());       
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!stockCollection.Keys.Contains(inStockName.ToUpper())) throw new StockExchangeException("Zadana dionica ne postoji na burzi");
             if (!indexCollection.Keys.Contains(inIndexName.ToUpper())) throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
             Index index = indexCollection[inIndexName.ToUpper()];
             if (!index.indexStocks.Contains(inStockName.ToUpper())) throw new StockExchangeException("Index ne sadrži zadanu dionicu");
             index.indexStocks.Remove(inStockName);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!stockCollection.Keys.Contains(inStockName.ToUpper())) throw new StockExchangeException("Zadana dionica ne postoji na burzi");
             if (!indexCollection.Keys.Contains(inIndexName.ToUpper())) throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
             Index index = indexCollection[inIndexName.ToUpper()];
             return index.indexStocks.Contains(inStockName.ToUpper());
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!indexCollection.Keys.Contains(inIndexName.ToUpper())) throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
             Index index = indexCollection[inIndexName.ToUpper()];
             List<string> stocks = index.indexStocks;

             if (index.indexType == IndexTypes.AVERAGE)
             {
                 decimal value = 0;
                 foreach (string stockName in stocks)
                 {
                     value += GetStockPrice(stockName, inTimeStamp);
                 }
                 if (value == 0) return 0;
                 else return decimal.Round(value/stocks.Count, 3, MidpointRounding.AwayFromZero);
             }
             else
             {
                 decimal value = 0;
                 decimal sum = 0;
                 foreach (string stockName in stocks)
                 {
                     value += GetStockPrice(stockName, inTimeStamp) * GetStockPrice(stockName, inTimeStamp) * stockCollection[stockName.ToUpper()].numberOfShares;
                     sum += GetStockPrice(stockName, inTimeStamp) * stockCollection[stockName.ToUpper()].numberOfShares;
                 }
                 if (value == 0) return 0;
                 else return decimal.Round(value / sum, 3, MidpointRounding.AwayFromZero);
             }
         }

         public bool IndexExists(string inIndexName)
         {
             return indexCollection.ContainsKey(inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return indexCollection.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!indexCollection.Keys.Contains(inIndexName.ToUpper())) throw new StockExchangeException("Index sa tim imenom ne postoji na burzi");
             return indexCollection[inIndexName.ToUpper()].indexStocks.Count();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolioCollection.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio sa tim imenom već postoji");
             portfolioCollection.Add(inPortfolioID, new Portfolio());
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio ne postoji na burzi");
             if (!stockCollection.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji na burzi");
             Portfolio portfolio = portfolioCollection[inPortfolioID];
             if (portfolio.stocksInPortfolio.ContainsKey(inStockName.ToUpper()))
             {
                 Stock stock = stockCollection[inStockName.ToUpper()];
                 if (stock.numberOfSharesLeftToAddToPortfolio < numberOfShares)
                     throw new StockExchangeException("Nije moguce dodati toliko primjeraka dionice");
                 else
                 {
                     portfolio.stocksInPortfolio[inStockName.ToUpper()] += numberOfShares;
                     stock.numberOfSharesLeftToAddToPortfolio -= numberOfShares;
                 }
             }
             else
             {
                 Stock stock = stockCollection[inStockName.ToUpper()];
                 if (stock.numberOfSharesLeftToAddToPortfolio < numberOfShares)
                     throw new StockExchangeException("Nije moguce dodati toliko primjeraka dionice");
                 else
                 {
                     portfolio.stocksInPortfolio.Add(inStockName.ToUpper(), numberOfShares);
                     stock.numberOfSharesLeftToAddToPortfolio -= numberOfShares;
                 }
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio ne postoji na burzi");
             if (!stockCollection.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji na burzi");
             Portfolio portfolio = portfolioCollection[inPortfolioID];
             if (!portfolio.stocksInPortfolio.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji u portfoliu");
             int number = portfolio.stocksInPortfolio[inStockName.ToUpper()];
             if (numberOfShares > number)
                 throw new StockExchangeException("Portfolio ne sadrži dovoljno dionica koje treba obrisati");
             else if (numberOfShares == number)
             {
                 portfolio.stocksInPortfolio.Remove(inStockName.ToUpper());
                 Stock stock = stockCollection[inStockName.ToUpper()];
                 stock.numberOfSharesLeftToAddToPortfolio += number; 
             }else 
             {
                 portfolio.stocksInPortfolio[inStockName.ToUpper()] -= numberOfShares;
                 Stock stock = stockCollection[inStockName.ToUpper()];
                 stock.numberOfSharesLeftToAddToPortfolio += number; 
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio ne postoji na burzi");
             if (!stockCollection.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji na burzi");
             Portfolio portfolio = portfolioCollection[inPortfolioID];
             if (!portfolio.stocksInPortfolio.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji u portfoliu");
             int number = portfolio.stocksInPortfolio[inStockName.ToUpper()];
             portfolio.stocksInPortfolio.Remove(inStockName.ToUpper());
             Stock stock = stockCollection[inStockName.ToUpper()];
             stock.numberOfSharesLeftToAddToPortfolio += number;
         }

         public int NumberOfPortfolios()
         {
             return portfolioCollection.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio sa tim imenom ne postoji");
             else return portfolioCollection[inPortfolioID].stocksInPortfolio.Count;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolioCollection.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio ne postoji na burzi");
             if (!stockCollection.ContainsKey(inStockName.ToUpper())) throw new StockExchangeException("Dionica ne postoji na burzi");
             return portfolioCollection[inPortfolioID].stocksInPortfolio.ContainsKey(inStockName.ToUpper());
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
             {
                 return portfolioCollection[inPortfolioID].stocksInPortfolio[inStockName.ToUpper()];
             } else throw new StockExchangeException("Portfolio doesn't containt that stock");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio sa tim imenom ne postoji");
             Portfolio portfolio = portfolioCollection[inPortfolioID];

             string[] keys = portfolio.stocksInPortfolio.Keys.ToArray();
             decimal value = 0;
             
             foreach (string key in keys)
             {
                 value += GetStockPrice(key, timeStamp)*portfolio.stocksInPortfolio[key];
             }
             
             return Decimal.Round(value, 3, MidpointRounding.AwayFromZero);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!portfolioCollection.ContainsKey(inPortfolioID))
                 throw new StockExchangeException("Portfolio sa tim imenom ne postoji");
             Portfolio portfolio = portfolioCollection[inPortfolioID];
             int days = DateTime.DaysInMonth(Year, Month);

             DateTime start = new DateTime(Year, Month,1,0,0,0,0);
             DateTime end = new DateTime(Year, Month, days,23,59,59,999);

             decimal startValue = GetPortfolioValue(inPortfolioID, start);
             decimal endValue = GetPortfolioValue(inPortfolioID, end);

             return Decimal.Round((endValue - startValue) / startValue * 100, 3, MidpointRounding.AwayFromZero);

         }
     }

     public class Stock
     {
         public string stockName { get; set; }
         public long numberOfShares { get; set; }
         public List<StockPriceHistory> priceHistory { get; set; }
         public long numberOfSharesLeftToAddToPortfolio { get; set; }

         public Stock(string inStockName, long inNumberofShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberofShares <= 0) throw new StockExchangeException("Mora postojati barem jedna dionica");
             this.stockName = inStockName.ToUpper();
             numberOfShares = inNumberofShares;
             priceHistory = new List<StockPriceHistory>();
             StockPriceHistory history = new StockPriceHistory(inInitialPrice, inTimeStamp);
             priceHistory.Add(history);
             numberOfSharesLeftToAddToPortfolio = inNumberofShares;
         }
     }

     public class StockPriceHistory
     {
         public Decimal stockPrice { get; set; }
         public DateTime stockTime { get; set; }

         public StockPriceHistory(Decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice <= 0) throw new StockExchangeException("Cijena dionice mora biti nenegativan broj");
             this.stockPrice = inInitialPrice;
             this.stockTime = inTimeStamp;
         }
     }

     public class Index
     {
         public IndexTypes indexType { get; set; }
         private string indexName;
         public List<string> indexStocks { get; set; }

         public Index(string inIndexName, IndexTypes inIndexType)
         {
             this.indexName = inIndexName.ToUpper();
             this.indexType = inIndexType;
             this.indexStocks = new List<string>();
         }
     }

    public class Portfolio
    {
        public Dictionary<string, int> stocksInPortfolio { get; set; }

        public Portfolio()
        {
            this.stocksInPortfolio = new Dictionary<string, int>();
        }
    }
}
