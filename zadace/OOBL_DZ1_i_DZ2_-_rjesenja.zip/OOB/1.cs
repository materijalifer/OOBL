﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {     // vratiti kalkulator
            return new Kalkulator();
        }
    }


    public class Kalkulator : ICalculator
    {
        public string[] ulazi = { "", "", "", "", ""};
        public string displej = "0";
        public string memorija = "0";
        public int i = 0;
        private Regex brojevi = new Regex(@"\d");
        private Regex znakovi = new Regex(@"\,|\+|\-|\*|\/|\=|M|S|K|T|Q|R|I|P|G|C|O");
        private Regex binarni = new Regex(@"\+|\-|\*|\/");

        public void Press(char inPressedDigit)
        {
            string ulaz = Convert.ToString(inPressedDigit);

            if (ulazi[0].Equals("-E-"))
                if (!ulaz.Equals("C"))
                    return;

            if (brojevi.IsMatch(ulaz))
            {
                if (i == 1)
                    if (brojevi.IsMatch(ulazi[0]))
                    {
                        i  = 0;
                        ulazi[0] = "";
                    }

                int duzina = ulazi[i].Length;
                if (ulazi[i].StartsWith("-"))
                    duzina--;
                if (ulazi[i].Contains(","))
                    duzina--;
                if (duzina < 10)
                {
                    if (brojevi.IsMatch(@"[1-9]"))
                        if (!ulazi[i].Contains(","))
                            ulazi[i] = ulazi[i].TrimStart('0');

                    ulazi[i] += ulaz;
                    displej = ulazi[i];
                }
            }
            else if (znakovi.IsMatch(ulaz))
            {
                if (ulaz == "+")
                {
                    ulazi[0] = racunaj(ulazi[0], ulazi[1], ulazi[2]);
                    ulazi[2] = "";
                    i = 1;
                    ulazi[i] = "+";
                    i++;
                }
                if (ulaz == "-")
                {
                    ulazi[0] = racunaj(ulazi[0], ulazi[1], ulazi[2]);
                    ulazi[2] = "";
                    i = 1;
                    ulazi[i] = "-";
                    i++;
                }
                if (ulaz == ",")
                {
                    if (ulazi[i].Equals(""))
                        ulazi[i] += "0";
                    if (!ulazi[i].Contains(","))
                        ulazi[i] += ulaz;
                }
                if (ulaz == "M")
                {
                    ulazi[i] = "-" + ulazi[i];
                    displej = ulazi[i];
                }
                if (ulaz == "P")
                    memorija = displej;
                if (ulaz == "G")
                {

                    ulazi[i] = memorija;
                    displej = ulazi[i];
                }
                if (ulaz == "S")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj(ulazi[0], ulaz, "0");
                        i++;
                    }
                    else
                    {
                        ulazi[i] = racunaj(ulazi[i], ulaz, "0");
                        displej = ulazi[i];
                    }
                }

                if (ulaz == "K")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj(ulazi[0], ulaz, "0");
                        i++;
                    }
                    else
                    {
                        ulazi[i] = racunaj(ulazi[i], ulaz, "0");
                        displej = ulazi[i];
                    }
                }
                if (ulaz == "T")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj(ulazi[0], ulaz, "0");
                        i++;
                    }
                    else
                    {
                        ulazi[i] = racunaj(ulazi[i], ulaz, "0");
                        displej = ulazi[i];
                    }
                }
                if (ulaz == "=")
                {
                    if (ulazi[2].Equals(""))
                        ulazi[2] = ulazi[0];

                    //if ((brojevi.IsMatch(ulazi[1]) || ulazi[1].Equals("")) && (ulazi[3].Equals("-") || ulazi[3].Equals("+")))
                    if (brojevi.IsMatch(ulazi[1]) || ulazi[1].Equals("")) 
                    {
                        ulazi[1] = ulazi[3];
                        ulazi[2] = ulazi[4];
                    }

                    ulazi[0] = formatiraj(racunaj(ulazi[0], ulazi[1], ulazi[2]));
                    ulazi[3] = ulazi[1];
                    ulazi[4] = ulazi[2];
                    ulazi[1] = "";
                    ulazi[2] = "0";
                    displej = ulazi[0];
                    i = 1;
                }
                if (ulaz == "*")
                {
                    ulazi[0] = racunaj(ulazi[0], ulazi[1], ulazi[2]);
                    ulazi[2] = "";
                    i = 1;
                    ulazi[i] = "*";
                    i++;
                }
                if (ulaz == "/")
                {
                    ulazi[0] = racunaj(ulazi[0], ulazi[1], ulazi[2]);
                    ulazi[2] = "";
                    i = 1;
                    ulazi[i] = "/";
                    i++;
                }
                if (ulaz == "O")
                {
                    displej = "0";
                    ulazi[0] = "";
                    ulazi[1] = "";
                    ulazi[2] = "";
                    ulazi[3] = "";
                    i = 0;
                }
                if (ulaz == "Q")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj(ulazi[0], "*", ulazi[0]);
                        i++;
                    }
                    else
                    {
                       // ulazi[4] = ulazi[0];
                        ulazi[i] = racunaj(ulazi[i], "*", ulazi[i]);
                        displej = ulazi[i];
                    }
                }
                if (ulaz == "R")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj(ulazi[0], ulaz, "0");
                        i++;
                    }
                    else
                    {
                        ulazi[i] = racunaj(ulazi[i], ulaz, "0");
                        displej = ulazi[i];
                    }
                }
                if (ulaz == "I")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    if (binarni.IsMatch(ulazi[1]) && ulazi[2].Equals(""))
                    {
                        displej = racunaj("1", "/", ulazi[0]);
                        i++;
                    }
                    else
                    {
                        ulazi[i] = racunaj("1", "/", ulazi[i]);
                        displej = ulazi[i];
                    }
                }
                if (ulaz == "C")
                {
                    if (ulazi[i].Equals(""))
                        i--;
                    ulazi[i] = "";
                    displej = "0";
                }
            }

        }


        public string formatiraj(string formatiranjeIzlaz)
        {
            double formatiranjeBroj;
            try
            {
                formatiranjeBroj = double.Parse(formatiranjeIzlaz);
                formatiranjeIzlaz = formatiranjeBroj.ToString("##########.#########");
                if ((formatiranjeIzlaz == "") || (formatiranjeIzlaz[0].Equals(',')))
                    formatiranjeIzlaz = formatiranjeIzlaz.Insert(0, "0");
                if ((formatiranjeIzlaz[0].Equals('-')) && (formatiranjeIzlaz[1].Equals(',')))
                    formatiranjeIzlaz = formatiranjeIzlaz.Insert(1, "0");
            }
            catch
            {
                formatiranjeIzlaz = "-E-";
            }
            return formatiranjeIzlaz;
        }


        public string racunaj(string broj1, string oper, string broj2)
        {
            string rezultat = "0";
            double lijevi = 0;
            double desni = 0;
            double rez = 0;

            try
            {
                rez = double.Parse(broj1);
                lijevi = double.Parse(broj1);
                desni = double.Parse(broj2);
                switch (oper)
                {
                    case "+":
                        rez = lijevi + desni;
                        break;
                    case "-":
                        rez = lijevi - desni;
                        break;
                    case "/":
                        rez = lijevi / desni;
                        break;
                    case "S":
                        rez = Math.Sin(rez);
                        break;
                    case "K":
                        rez = Math.Cos(rez);
                        break;
                    case "T":
                        rez = Math.Tan(rez);
                        break;
                    case "*":
                        rez = lijevi * desni;
                        break;
                    case "R":
                        rez = Math.Sqrt(rez);
                        break;
                    default:
                        break;
                }
            }
            catch
            {
                rezultat = "-E-";
            }
            if ((rez < -9999999999) || (rez > 9999999999) || double.IsNaN(rez))
                rezultat = "-E-";
            else
            {
                rez = Math.Round(rez, 9);
                rezultat = formatiraj(rez.ToString());
            }
            return rezultat;
        }


        public string GetCurrentDisplayState()
        {
            return displej;
        }
    }

}
