﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

    // Console.WriteLine("klasa.metoda.uzrok");

    


     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    

     public interface IIndex 
     {
         string getIndexName{ get;  }

         Dictionary<string, Dionica> getDionice { get; set; }

         Decimal indexPrice(DateTime time);

     }


     #region glavni razredi



     public class Dionica
     {
         
         #region privatne varijable

         private string inStockName;
         private long inNumberOfShares;
         private Decimal inInitialPrice;
         private DateTime inTimeStamp;
         private Dictionary<DateTime, Decimal> cijene;
         private Decimal momentPrice;

         //daje broj slobodnih dionica
         private long freeShares;

         #endregion

         #region konstruktori

        
         public Dionica(string inStockName, long inNumberOfShares, Decimal inInitialPrice, DateTime inTimeStamp)
         {


             if (inNumberOfShares < 1)
             {
                 throw new StockExchangeException("Broj dionica je nula ili negativna vrijednost");
             }

             if (inInitialPrice < 0)
             {
                 throw new StockExchangeException("Vrijednost dionica je nula ili negativna vrijednost");
             }

             this.inStockName = inStockName;
             this.inNumberOfShares = inNumberOfShares;
             this.inInitialPrice = inInitialPrice;
             this.inTimeStamp = inTimeStamp;
             this.momentPrice = inInitialPrice;

             //inicijalizira se kolekcija cijena za postavljena vremena 
             //MYBE time     throw new StockExchangeException(" Vrijeme nije dobro postavljeno ");
             this.getCijene = new Dictionary<DateTime, decimal>();

             //postavlja se početna cijena za početno vrijeme za dionicu
             this.getCijene.Add(inTimeStamp, inInitialPrice);
             this.getFreeShares = inNumberOfShares;
         }
        

         #endregion

         #region get set

         public string getStockName 
         {
             get { return  Key.getKey(this.inStockName); }
         }
         public long getNumberOfShares 
         {
             get { return this.inNumberOfShares; }
         }
         public Decimal getInitialPrice 
         {
             get { return this.inInitialPrice; }
         }
         public Decimal getMomentPrice 
         {
             get { return this.momentPrice; }
         }
         public long getFreeShares 
         {
             get { return this.freeShares; }
             set { this.freeShares = value; }
         }

        //MYBE time
         public Dictionary<DateTime,Decimal> getCijene 
         {
             get { return this.cijene; }
             set { this.cijene = value; }
         }

         #endregion
         
         
         #region metode
         //provjeri vrijeme
         /// <summary>
         /// Postavlja se nova cijena dionice u određenom trenutku
         /// </summary>
         /// <param name="time"></param>
         /// <param name="cijena"></param>
         public void setPrice(DateTime time, Decimal cijena)
         {
             if(cijena<0)
                 throw new StockExchangeException("Vrijednost dionica je nula ili negativna vrijednost");



             this.momentPrice = cijena;
             this.getCijene.Add(time, cijena);

         }

         // PROVJERENO
         public Decimal getTimePrice(DateTime time) 
         {
             var times = getCijene.Keys.ToList();
             times.Sort();

             for (int i = 0; i < getCijene.Count(); i++)
             {
                 //RIJEŠENJE AKO SE ZAJEBE

                 
                 if( times.ElementAt(i)>time){
                     return getCijene[times.ElementAt(i-1)];
                
                 }
             
             }
             return getCijene[times.ElementAt(getCijene.Count()-1)];
             
         }

         //PART STOCK
         public void takeFreeShare(long share) 
         {   // PORTFOLIO
             if(share<1)
                 throw new StockExchangeException("Vrijednost dijela dionica je nula ili negativna vrijednost");

             
             this.getFreeShares = this.getFreeShares - share;

             if (this.getFreeShares < 1)
                 throw new StockExchangeException("Nema slobodnih dionica vise na burzi");
         }

         //PART STOCK
         public void addFreeShares(long share) 
         { 
         // PORTFOLIO 
             if (share < 1)
                 throw new StockExchangeException("Vrijednost dijela dionica je nula ili negativna vrijednost");

             
             this.getFreeShares = this.getFreeShares + share;

             if (this.getFreeShares > this.getNumberOfShares)
                 throw new StockExchangeException("Nemoze se dodati dionica vise nego je napocetku definirano");
         }


         #endregion
     }
        


     public class AvarageIndex:IIndex
     {

         #region privatne varijable
         
         private StockExchange burza;
         private string _indexName;
         private Dictionary<string, Dionica> dionice;

         #endregion
         
         #region konstruktor

        public AvarageIndex(string indexName) 
         {
             this.getDionice = new Dictionary<string, Dionica>();
             this._indexName = indexName;
         }

         #endregion
         
         #region get set

         public string getIndexName 
         {
             get { return this._indexName; }
         }

         public StockExchange getBurza 
         {
             get { return this.burza; }
             set { this.burza = value; }
         }

         public Dictionary<string, Dionica> getDionice 
         {
             get { return this.dionice; }
             set { this.dionice = value; }
         }

         #endregion
         
         #region metode

         public Decimal indexPrice(DateTime time )
         {
             Decimal sum = 0;
             Decimal count =0;
             for (int i=0; i < this.getDionice.Count();i++ ){
                 sum += this.getDionice.ElementAt(i).Value.getTimePrice(time) * this.getDionice.ElementAt(i).Value.getNumberOfShares;
                 count += this.getDionice.ElementAt(i).Value.getNumberOfShares;
             }
             return  Math.Round(sum/count,3);
         }

         #endregion
     }
       
     public class WeigthIndex:IIndex
     {
       
         #region privatne varijable
         
       
         private string _indexName;
         private Dictionary<string, Dionica> dionice;

         #endregion
                  
         #region konstruktori
                  
         public WeigthIndex(string indexName) 
         {   

             this.getDionice = new Dictionary<string, Dionica>();
             this._indexName = indexName;
            
         }

         #endregion
         
         #region get set

         public string getIndexName
         {
             get { return this._indexName; }
         }

         public Dictionary<string, Dionica> getDionice 
         {
             get { return this.dionice; }
             set { this.dionice = value; }
         }

         #endregion
         
         #region metode

         //NE POUZDANO
         public Decimal indexPrice(DateTime time)
         {
             Decimal sum = 0;
             Decimal weight = 0;
             for (int i = 0; i < this.getDionice.Count(); i++)
             {
                 sum += this.getDionice.ElementAt(i).Value.getTimePrice(time) * this.getDionice.ElementAt(i).Value.getNumberOfShares;
             }

             for (int i = 0; i < this.getDionice.Count(); i++)
             {
                 weight += ((this.getDionice.ElementAt(i).Value.getTimePrice(time) * this.getDionice.ElementAt(i).Value.getNumberOfShares) / sum) * this.getDionice.ElementAt(i).Value.getTimePrice(time);
             }

             return Math.Round(weight , 3);
         }

         #endregion
     }



     public class Portofolio
     {

         #region privatne varijable
        

         private string _portofolio;
         private Dictionary<string, PartStock> _dionice;
         private Decimal _cijenaPortofolia=0;

         #endregion

     
         #region konstruktor

         public Portofolio(string name)
         {
             this._portofolio = name;
             this.getDionice = new Dictionary<string, PartStock>();
             
         }

         #endregion


         #region get set

         public string getName 
         {
             get { return this._portofolio; }
         }

         public Dictionary<string, PartStock> getDionice 
         {
             get { return this._dionice; }
             set { this._dionice = value; }
         }

         private Decimal getCijena 
         {
             get { return this._cijenaPortofolia; }
             set { this._cijenaPortofolia = value; }
         }

         #endregion


         #region metode
         //IZNIMKE NA NIŽIM RAZINAMA
         public void dodajDionicu(string name,Dionica dionica,long brojDionica) 
         {
             this.getDionice.Add(Key.getKey(name), new PartStock(dionica, brojDionica));
         }

         //IZNIMKE NA NIŽIM RAZINAMA
         public void oduzmiDionicu(string name,Dionica dionica) 
         {
             this.getDionice.Remove(Key.getKey(name));
         }

         
         public Decimal cijenaPortofolia(DateTime time) 
         {
             Decimal cijena = 0;
             for (int i = 0; i < this.getDionice.Count;i++ ) {
                 cijena += this.getDionice.ElementAt(i).Value.TimePriceStock(time);
                 
             }

             return cijena;
         }



         #endregion

     }





     public class StockExchange:IStockExchange
     {
         #region privatne varijable

         private Dictionary<string, Dionica> _dionice;

         private Dictionary<string, IIndex> _indexi;

         private Dictionary<string, Portofolio> _portfoliji;

         #endregion

         
         #region kontruktor 

         public StockExchange()
         {
             this.getDionice = new Dictionary<string, Dionica>();
             this.getIndexi = new Dictionary<string, IIndex>();
             this.getPortfoliji = new Dictionary<string, Portofolio>();

         }

         #endregion

         
         #region get set

         public Dictionary<string, Dionica> getDionice 
         {
             get { return this._dionice; }
             set { this._dionice = value; }
         }

         public Dictionary<string, IIndex> getIndexi
         {
             get { return this._indexi; }
             set { this._indexi= value; }
         }

         public Dictionary<string, Portofolio> getPortfoliji 
         {
             get { return this._portfoliji; }
             set { this._portfoliji = value; }
         }

         #endregion





         #region dionice metode

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {   
             if(this.getDionice.ContainsKey(Key.getKey(inStockName))==true)
                throw new StockExchangeException("Isto ime dionice vec postoji");


             for (int i = 0; i < this.getDionice.Count; i++) {

                 for (int j = 0; j < this.getDionice.ElementAt(i).Value.getCijene.Count; j++) {

                     if (this.getDionice.ElementAt(i).Value.getCijene.ContainsKey(inTimeStamp)){
                     throw new StockExchangeException("To vrijeme je vec uneseno u burzu");
                     }
                 }
             
             }


             this.getDionice.Add(Key.getKey(inStockName),new Dionica(inStockName,inNumberOfShares,inInitialPrice,inTimeStamp));

            
         }

         public void DelistStock(string inStockName)
         {
             //POST   
             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
              throw new StockExchangeException("Dionica ne postoji na burzi ");

             this.getDionice.Remove( Key.getKey(inStockName));
             
         }

         public bool StockExists(string inStockName)
         {
             return this.getDionice.ContainsKey(Key.getKey(inStockName));
            
         }

         public int NumberOfStocks()
         {
             return this.getDionice.Count;
             
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             DateTime time = inIimeStamp;
             
                     if (this.getDionice[Key.getKey(inStockName)].getCijene.ContainsKey(time))
                     {
                         throw new StockExchangeException("To vrijeme je vec uneseno u burzu");
                     }
                


             //MYBE time
             this.getDionice[Key.getKey(inStockName)].setPrice(inIimeStamp, inStockValue);
            
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             //POSTAVITI IZNIMKU ZA KRIVO VRIJEME 
             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji na burzi ");



             //još jednom provjeri kvalitetu te metode
            return this.getDionice[Key.getKey(inStockName)].getTimePrice(inTimeStamp);
             throw new NotImplementedException();
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji na burzi ");


             return this.getDionice[Key.getKey(inStockName)].getInitialPrice;
             throw new NotImplementedException();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji na burzi ");


             return this.getDionice[Key.getKey(inStockName)].getMomentPrice;
             
         }


         # endregion


         #region index metode

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {   //POST
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == true)
                 throw new StockExchangeException("Index vec postoji");

             switch (inIndexType) {
                 case IndexTypes.AVERAGE: 
                     this.getIndexi.Add(Key.getKey(inIndexName),new AvarageIndex(Key.getKey(inIndexName)));
                     break;
                 case IndexTypes.WEIGHTED:
                     this.getIndexi.Add(Key.getKey(inIndexName), new WeigthIndex(Key.getKey(inIndexName))); 
                     break;
                 default:
                     throw new StockExchangeException("Nedopušteni indeksni tip ");
                     
             }

             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             //POST
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == false)
                 throw new StockExchangeException("Index ne postoji");

             if (this.getIndexi[Key.getKey(inIndexName)].getDionice.ContainsKey(Key.getKey(inStockName)) == true)
                 throw new StockExchangeException("Dionica vec postoji u indexu");

             this.getIndexi[Key.getKey(inIndexName)].getDionice.Add(Key.getKey(inStockName), this.getDionice[Key.getKey(inStockName)]);
             
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             //POST
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == false)
                 throw new StockExchangeException("Index ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji");


             this.getIndexi[Key.getKey(inIndexName)].getDionice.Remove(Key.getKey(inStockName));
             
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             //POST
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == false)
                 throw new StockExchangeException("Index ne postoji");

           return  this.getIndexi[Key.getKey(inIndexName)].getDionice.ContainsKey(Key.getKey(inStockName));
             
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             //IZNIMKA ZA IME INDEXAS
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == false)
                 throw new StockExchangeException("Index ne postoji");

            return this.getIndexi[Key.getKey(inIndexName)].indexPrice(inTimeStamp);
             
         }

         public bool IndexExists(string inIndexName)
         {
             return this.getIndexi.ContainsKey(Key.getKey(inIndexName));
           
         }

         public int NumberOfIndices()
         {
            return this.getIndexi.Count;
          
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             //POST
             if (this.getIndexi.ContainsKey(Key.getKey(inIndexName)) == false)
                 throw new StockExchangeException("Index ne postoji");


             return this.getIndexi[Key.getKey(inIndexName)].getDionice.Count;
           
         }


         #endregion


         #region portfolio metode

         public void CreatePortfolio(string inPortfolioID)
         {
             //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == true)
                 throw new StockExchangeException("Portfolio tog imena vec postoji");

             this.getPortfoliji.Add(inPortfolioID, new Portofolio(inPortfolioID));

           
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             // POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji");


             if (numberOfShares < 1)
                 throw new StockExchangeException("Vrijednost dijela dionice je negativna ili jednaka nuli");

             if (this.getPortfoliji[inPortfolioID].getDionice.ContainsKey(Key.getKey(inStockName)) == true)
             {
                 this.getPortfoliji[inPortfolioID].getDionice[Key.getKey(inStockName)].dodajDionice(numberOfShares);
             }
             else
             {
                 this.getPortfoliji[inPortfolioID].dodajDionicu(Key.getKey(inStockName), this.getDionice[Key.getKey(inStockName)], numberOfShares);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {  //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji");

             if (numberOfShares < 1)
                 throw new StockExchangeException("Vrijednost dijela dionice je negativna ili jednaka nuli");



             this.getPortfoliji[inPortfolioID].getDionice[Key.getKey(inStockName)].oduzmiDionice(numberOfShares);

             if(this.getDionice[Key.getKey(inStockName)].getFreeShares==0)
                 this.getPortfoliji[inPortfolioID].oduzmiDionicu(Key.getKey(inStockName), this.getDionice[Key.getKey(inStockName)]);

             //this.getPortfoliji[inPortfolioID].oduzmiDionicu(Key.getKey(inStockName), this.getDionice[Key.getKey(inStockName)]);
            
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji");


             this.getPortfoliji[inPortfolioID].oduzmiDionicu(Key.getKey(inStockName), this.getDionice[Key.getKey(inStockName)]);
            
         }

         public int NumberOfPortfolios()
         {
             return this.getPortfoliji.Count;
             
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             //POST

             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");
             
             return this.getPortfoliji[inPortfolioID].getDionice.Count;
            
         }

         public bool PortfolioExists(string inPortfolioID)
         {
            
             return this.getPortfoliji.ContainsKey(inPortfolioID);
             
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji na burzi");


             return this.getPortfoliji[inPortfolioID].getDionice.ContainsKey(Key.getKey(inStockName));
            
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {  //POST

             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if (this.getDionice.ContainsKey(Key.getKey(inStockName)) == false)
                 throw new StockExchangeException("Dionica ne postoji na burzi");


             return (int)this.getPortfoliji[inPortfolioID].getDionice[inStockName].getBrojDionica;
            
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {  //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");


             return this.getPortfoliji[inPortfolioID].cijenaPortofolia(timeStamp);
             
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             //POST
             if (this.getPortfoliji.ContainsKey(inPortfolioID) == false)
                 throw new StockExchangeException("Portfolio tog imena ne postoji");

             if( (Month<1) || (Month>12))
                 throw new StockExchangeException("Nedopustena vrijednosti mjeseca");

             if (Year < 0)
                 throw new StockExchangeException("Nedopustena vrijednost godine");


             int lastDay = DateTime.DaysInMonth(Year, Month);
             decimal StartMonthValue = this.getPortfoliji[inPortfolioID].cijenaPortofolia(new DateTime(Year,Month,0,0,0,0,0));
             decimal EndMonthValue = this.getPortfoliji[inPortfolioID].cijenaPortofolia(new DateTime(Year,Month,lastDay-1,23,59,59,999));

             return (EndMonthValue - StartMonthValue) * 100; 



            
         }

         #endregion




         #region pomocne metode



         #endregion


     }



     #endregion

 

     #region pomocni razredi



     public class PartStock
     {

         #region privatne varijable

         
         private long _brojDionica=0;
         
         private Dionica _dionica;

         #endregion 


         #region konstruktor
        
         public PartStock(Dionica dionica,long brojDionica)
         {  
             this.getDionica = dionica;
             this.getBrojDionica += brojDionica;
             
             this.getDionica.takeFreeShare(brojDionica);
         }

         #endregion


         #region get set

         //moraš namjestiti još kontrolu dotoka i odtoka dionica
         public long getBrojDionica 
         {
             get { return this._brojDionica; }
             set { this._brojDionica = value; }
         }

         public Dionica getDionica 
         {
             get { return this._dionica; }
             set { this._dionica = value; }
         }

       


         #endregion



         #region metode

         //dodaj iznimke također

         public Decimal cijenaDionica() 
         {

             return this.getDionica.getMomentPrice*this.getBrojDionica;
         }
         

         public Decimal TimePriceStock(DateTime time) {
             return this.getDionica.getTimePrice(time) * this.getBrojDionica;
         }

         //iznimka
         public void dodajDionice(long broj)
         {
             this.getBrojDionica += broj;
             this.getDionica.takeFreeShare(broj);
         }

         //iznimka
         public void oduzmiDionice(long broj) 
         {
             this.getBrojDionica -= broj;
             this.getDionica.addFreeShares(broj);
         }


         #endregion
     }




   

     

     public static class Key 
     {
         
         //vraća ključ u velikim slovima
         public static string getKey(string key)
         {
             return key.ToUpper();
         }
     }



     #endregion
   



}
