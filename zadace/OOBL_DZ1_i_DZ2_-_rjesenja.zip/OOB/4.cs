﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private string ekran = "0";
        private List<string> uneseniBrojeviIOperacije = new List<string>();
        private static List<char> binarniOperatori = new List<char>() { '+', '-', '*', '/' };
        private static List<char> unarniOperatori = new List<char>() { '=', 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        private static List<char> tehnickeAkcije = new List<char>() { 'P', 'G', 'C', 'O' };
        private const char DECIMALNI_ZAREZ = ',';
        private bool prethodniZnakBioJeBroj = false;
        private bool prethodniZnakJeRezultat = false;
        private bool prethodniBrojJeIzMemorije = false;
        private bool visekratnoPritiskanjeJednako = false;
        private string broj = "";
        private const int DOPUSTENA_DULJINA_BROJA = 10;
        private const string GRESKA = "-E-";
        private string memorija = "0";
        private bool imaJednaBinOperacija = false;
        private string binarnaOperacijaPrijeJednako = "";
        private string brojPrijeBinOperacijePrijeJednako = "";

        public void Press(char inPressedDigit)
        {
            odaberiAkciju(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return this.ekran;
        }

        private void odaberiAkciju(char znak)
        {
            int broj;
            if (this.ekran != GRESKA)
            {
                if (int.TryParse(znak.ToString(), out broj))
                {
                    obradaUnesenogBroja(broj);
                }
                else if (binarniOperatori.Contains(znak))
                {
                    obradaBinarneOperacije(znak);
                }
                else if (unarniOperatori.Contains(znak))
                {
                    obradaUnarneOperacije(znak);
                }
                else if (tehnickeAkcije.Contains(znak))
                {
                    obradaTehnickeAkcije(znak);
                }
                else if (znak == DECIMALNI_ZAREZ)
                {
                    obradaDecimalnogZareze();
                }
                else
                {
                    this.ekran = GRESKA;
                }
            }
            else
            {
                if (znak == 'O')
                {
                    resetiraj();
                }
            }

        }

        private void obradaUnesenogBroja(int znamenka)
        {
            double brojNaEkranu;
            if (double.TryParse(this.ekran, out brojNaEkranu))
            {
                if (brojNaEkranu != 0 || this.ekran == "0,")
                {
                    if (prethodniZnakBioJeBroj && !prethodniZnakJeRezultat && !prethodniBrojJeIzMemorije)
                    {
                        if (provjeraDuljineZapisaNaEkranu())
                        {
                            this.broj += znamenka.ToString();
                        }
                    }
                    else if (!prethodniZnakBioJeBroj)
                    {
                        this.broj = "";
                        this.broj += znamenka.ToString();
                        prethodniZnakBioJeBroj = true;
                    }
                    else if (prethodniZnakJeRezultat)
                    {
                        this.uneseniBrojeviIOperacije.Clear();
                        this.broj = "";
                        this.broj += znamenka.ToString();
                        this.ekran = "";
                        prethodniZnakBioJeBroj = true;
                        this.binarnaOperacijaPrijeJednako = "";// ponistava operaciju koja je bila potrebna operaciji "="
                        this.brojPrijeBinOperacijePrijeJednako = "";//ponistava broj koji je bio potreban operaciji "="
                        this.visekratnoPritiskanjeJednako = false;//proslo je visestruko koristenje "="
                        prethodniZnakJeRezultat = false;
                    }
                    else if (prethodniBrojJeIzMemorije)
                    {
                        this.broj = "";
                        this.broj += znamenka.ToString();
                        prethodniBrojJeIzMemorije = false;
                    }

                    this.ekran = this.broj;
                }
                else
                {
                    this.ekran = znamenka.ToString();
                    this.broj = znamenka.ToString();
                    if (znamenka != 0)
                    {
                        prethodniZnakBioJeBroj = true;
                    }
                }
            }

        }

        private void obradaBinarneOperacije(char operacija)
        {

            if (this.prethodniZnakBioJeBroj)
            {
                this.prethodniZnakBioJeBroj = false;
                if (!prethodniZnakJeRezultat)
                {
                    this.uneseniBrojeviIOperacije.Add(broj);
                }
                else
                {
                    this.binarnaOperacijaPrijeJednako = "";// ponistava operaciju koja je bila potrebna operaciji "="
                    this.brojPrijeBinOperacijePrijeJednako = "";//ponistava broj koji je bio potreban operaciji "=" 
                    this.visekratnoPritiskanjeJednako = false;//proslo je visestruko koristenje "="
                    prethodniZnakJeRezultat = false;
                }
            }
            else if (prethodniZnakBioJeBinarniOperator() && uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 2] != this.ekran)// ako se unesao unarni operator nakon binarnog i onda ponovno binarni operator, tada promjena prouzrocena unarnim operatorom treba biti evaluirana
            {
                int indexPoslijednjegBroja = uneseniBrojeviIOperacije.Count - 2;
                this.uneseniBrojeviIOperacije[indexPoslijednjegBroja] = this.ekran;
            }

            if (uneseniBrojeviIOperacije.Count == 3)//provjerava dal' lista unesenih brojeva i operacija ima tri elementa, ako ima, to onda znaci da se dolaskom novog binarnog operatora operacija u listi treba izracunati i prikazati na ekranu rezultat
            {
                this.imaJednaBinOperacija = true;
            }
            else
            {
                this.imaJednaBinOperacija = false;
            }

            unosBinarnogOperatora(operacija);

            if (imaJednaBinOperacija)// izracun prethodnog binarne operacije
            {
                double prviOperand;
                double drugiOperand;
                int indexPrvogOperanda = 0;
                int indexDrugogOperanda = 2;
                double trenutniRezultat = 0;
                string binOperator = uneseniBrojeviIOperacije[1];

                if (double.TryParse(uneseniBrojeviIOperacije[indexPrvogOperanda], out prviOperand))
                {
                    if (double.TryParse(uneseniBrojeviIOperacije[indexDrugogOperanda], out drugiOperand))
                    {
                        trenutniRezultat = evaluacijaBinarneOperacije(prviOperand, drugiOperand, binOperator);
                    }

                }
                else
                {
                    this.ekran = GRESKA;
                    return;
                }

                if (!provjeraDuljineZapisa(trenutniRezultat.ToString()))
                {
                    string rezUString = trenutniRezultat.ToString();
                    rezUString = urediIzgledBroja(rezUString);
                    if (rezUString != GRESKA)
                    {
                        uneseniBrojeviIOperacije[0] = rezUString;
                        uneseniBrojeviIOperacije.RemoveAt(1);
                        uneseniBrojeviIOperacije.RemoveAt(indexDrugogOperanda);
                        this.ekran = rezUString;
                    }
                    else
                    {
                        this.ekran = GRESKA;
                    }
                }
                else
                {
                    uneseniBrojeviIOperacije[0] = trenutniRezultat.ToString();
                    uneseniBrojeviIOperacije.RemoveAt(1);//brisanje odradene operacije
                    uneseniBrojeviIOperacije.RemoveAt(1);//brisanje drugog operanda
                    this.ekran = trenutniRezultat.ToString();
                }
            }
        }

        private void obradaUnarneOperacije(char operacija)
        {
            switch (operacija)
            {
                case '=':
                    jednako();
                    break;
                case 'M':
                    M();
                    break;
                case 'S':
                    S();
                    break;
                case 'K':
                    K();
                    break;
                case 'T':
                    T();
                    break;
                case 'Q':
                    Q();
                    break;
                case 'R':
                    R();
                    break;
                case 'I':
                    I();
                    break;
                default:
                    break;
            }
        }

        private void obradaTehnickeAkcije(char operacija)
        {
            switch (operacija)
            {
                case 'P':
                    dodajUMemoriju();
                    break;
                case 'G':
                    dohvatiIzMemorije();
                    break;
                case 'C':
                    obrisiEkran();
                    break;
                case 'O':
                    resetiraj();
                    break;
                default:
                    break;
            }

        }

        private void obradaDecimalnogZareze()
        {
            if (prethodniZnakBioJeBroj)
            {
                this.broj += ",";
            }
            else if (this.ekran == "0" && broj == "0")
            {
                prethodniZnakBioJeBroj = true;
                this.broj += ",";
                this.ekran += ",";
            }
            else
            {
                prethodniZnakBioJeBroj = true;
                this.broj += "0,";
                this.ekran += ",";
            }
        }

        private bool provjeraDuljineZapisaNaEkranu()
        {
            bool duljinaJeDopustena = false;
            bool imaZarez = false;
            bool imaMinus = false;

            if (this.ekran.Contains('-'))
            {
                imaMinus = true;
            }

            if (this.ekran.Contains(','))
            {
                imaZarez = true;
            }

            if (imaZarez && imaMinus)
            {
                if (this.ekran.Count() < DOPUSTENA_DULJINA_BROJA + 2)
                {
                    duljinaJeDopustena = true;
                }
            }
            else if (imaMinus || imaZarez)
            {
                if (this.ekran.Count() < DOPUSTENA_DULJINA_BROJA + 1)
                {
                    duljinaJeDopustena = true;
                }

            }
            else
            {
                if (this.ekran.Count() < DOPUSTENA_DULJINA_BROJA)
                {
                    duljinaJeDopustena = true;
                }
            }

            return duljinaJeDopustena;
        }

        private bool provjeraDuljineZapisa(string znakovi)
        {
            bool duljinaJeDopustena = false;
            bool imaZarez = false;
            bool imaMinus = false;

            if (znakovi.Contains("E+"))
            {
                return duljinaJeDopustena;
            }

            if (znakovi.Contains('-'))
            {
                imaMinus = true;
            }

            if (znakovi.Contains(','))
            {
                imaZarez = true;
            }

            if (imaZarez && imaMinus)
            {
                if (znakovi.Count() <= DOPUSTENA_DULJINA_BROJA + 2)
                {
                    duljinaJeDopustena = true;
                }
            }
            else if (imaMinus || imaMinus)
            {
                if (znakovi.Count() <= DOPUSTENA_DULJINA_BROJA + 1)
                {
                    duljinaJeDopustena = true;
                }

            }
            else
            {
                if (znakovi.Count() <= DOPUSTENA_DULJINA_BROJA)
                {
                    duljinaJeDopustena = true;
                }
            }

            return duljinaJeDopustena;
        }

        private string urediIzgledBroja(string broj)
        {
            double zaokruzeniBroj;
            bool imaZarez = false;
            bool imaMinus = false;
            string noviBroj = broj;


            if (broj.Contains("E+"))
            {
                this.ekran = GRESKA;
                return GRESKA;
            }

            if (broj.Contains('-'))
            {
                imaMinus = true;
            }

            if (broj.Contains(','))
            {
                imaZarez = true;
            }

            if (imaZarez && imaMinus)
            {
                if (broj.Count() > DOPUSTENA_DULJINA_BROJA + 2)
                {
                    int indexZareza = broj.IndexOf(',');

                    if (indexZareza < DOPUSTENA_DULJINA_BROJA + 1)
                    {
                        zaokruzeniBroj = Math.Round(double.Parse(broj), DOPUSTENA_DULJINA_BROJA + 1 - indexZareza);
                        noviBroj = zaokruzeniBroj.ToString();
                    }
                    else if (indexZareza == DOPUSTENA_DULJINA_BROJA + 1)
                    {
                        zaokruzeniBroj = Math.Round(double.Parse(broj), 0);
                        noviBroj = zaokruzeniBroj.ToString();
                    }
                    else
                    {
                        noviBroj = GRESKA;
                    }
                }
            }
            else if (imaZarez)
            {
                if (broj.Count() > DOPUSTENA_DULJINA_BROJA + 1)
                {
                    int indexZareza = broj.IndexOf(',');

                    if (indexZareza < DOPUSTENA_DULJINA_BROJA)
                    {
                        zaokruzeniBroj = Math.Round(double.Parse(broj), DOPUSTENA_DULJINA_BROJA - indexZareza);
                        noviBroj = zaokruzeniBroj.ToString();
                    }
                    else if (indexZareza == DOPUSTENA_DULJINA_BROJA)
                    {
                        zaokruzeniBroj = Math.Round(double.Parse(broj), 0);
                        noviBroj = zaokruzeniBroj.ToString();
                    }
                    else
                    {
                        noviBroj = GRESKA;
                    }
                }

            }
            else if (imaMinus)
            {
                if (broj.Count() > DOPUSTENA_DULJINA_BROJA + 1)
                {
                    noviBroj = GRESKA;

                }
            }
            else
            {
                if (broj.Count() > DOPUSTENA_DULJINA_BROJA)
                {
                    noviBroj = GRESKA;
                }
            }

            return noviBroj;

        }

        private void M()
        {
            double pretvorenBroj;
            if (this.ekran != "0")
            {
                if (double.TryParse(this.ekran, out pretvorenBroj))
                {
                    if (!prethodniZnakBioJeBinarniOperator() || prethodniZnakBioJeBroj)
                    {

                        if (this.ekran[0] == '-')
                        {
                            string noviBroj = "";
                            foreach (char znak in this.ekran)
                            {
                                if (znak != '-')
                                {
                                    noviBroj += znak.ToString();
                                }
                            }

                            this.ekran = noviBroj;
                        }
                        else
                        {
                            this.ekran = "-" + this.ekran;
                        }

                        this.broj = this.ekran;

                    }
                    else // ako je prije unarnog operatora unesen binarni tada je potrebno unarni operator upotrijebiti za ispis a ekran, ali da nema utjecaja na daljnji rezultat
                    {
                        string pomocniBroj = this.broj;
                        if (pomocniBroj[0] == '-')
                        {
                            string noviBroj = "";
                            foreach (char znak in pomocniBroj)
                            {
                                if (znak != '-')
                                {
                                    noviBroj += znak.ToString();
                                }
                            }

                            pomocniBroj = noviBroj;
                        }

                        this.ekran = pomocniBroj;
                    }

                }

            }

        }

        private void S()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;

            if (!prethodniZnakBioJeBinarniOperator())
            {
                if (uneseniBrojeviIOperacije.Count > 0)
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    return;
                }

                if (this.ekran != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        broj = Math.Sin(broj);

                        string brojKaoZnakovi = broj.ToString();

                        uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                        this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                    }
                }
            }
            else
            {
                znakovi = this.ekran;

                if (znakovi != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        broj = Math.Sin(broj);

                        this.ekran = urediIzgledBroja(broj.ToString());
                    }
                }

            }

        }

        private void K()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;

            if (!prethodniZnakBioJeBinarniOperator())
            {
                if (uneseniBrojeviIOperacije.Count > 0)
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    uneseniBrojeviIOperacije.Add("1");
                    prethodniZnakBioJeBroj = true;
                    prethodniZnakJeRezultat = true;
                    this.ekran = "1";
                    return;
                }

                if (this.ekran != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        broj = Math.Cos(broj);

                        string brojKaoZnakovi = broj.ToString();

                        uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                        this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                    }
                }
                else
                {
                    uneseniBrojeviIOperacije.Add("1");
                    prethodniZnakBioJeBroj = true;
                    prethodniZnakJeRezultat = true;
                    this.ekran = "1";
                }
            }
            else // ukoliko je prije unarnog operatora pritisnut binarni 
            {
                znakovi = this.ekran;

                double broj;
                if (double.TryParse(znakovi, out broj))
                {
                    broj = Math.Cos(broj);
                    this.ekran = urediIzgledBroja(broj.ToString());
                }
            }
        }

        private void T()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;

            if (!prethodniZnakBioJeBinarniOperator())
            {

                if (uneseniBrojeviIOperacije.Count > 0) // ako je upisan prethodno neki broj
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    return;
                }

                if (this.ekran != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        broj = Math.Tan(broj);

                        string brojKaoZnakovi = broj.ToString();

                        uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                        this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                    }
                }
            }
            else
            {
                znakovi = this.ekran;

                double broj;
                if (double.TryParse(znakovi, out broj))
                {
                    broj = Math.Tan(broj);
                    this.ekran = urediIzgledBroja(broj.ToString());
                }
            }

        }

        private void Q()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;
            if (!prethodniZnakBioJeBinarniOperator())
            {
                if (uneseniBrojeviIOperacije.Count > 0)
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    return;
                }

                if (this.ekran != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        broj = Math.Pow(broj, 2);

                        string brojKaoZnakovi = broj.ToString();

                        uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                        this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                    }
                }
            }
            else
            {
                znakovi = this.ekran;

                double broj;
                if (double.TryParse(znakovi, out broj))
                {
                    broj = Math.Pow(broj, 2);
                    this.ekran = urediIzgledBroja(broj.ToString());
                }
            }

        }

        private void R()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;
            if (!prethodniZnakBioJeBinarniOperator())
            {
                if (uneseniBrojeviIOperacije.Count > 0)
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    return;
                }

                if (this.ekran != "0")
                {
                    double broj;
                    if (double.TryParse(znakovi, out broj))
                    {
                        if (znakovi[0] != '-')
                        {
                            broj = Math.Sqrt(broj);

                            string brojKaoZnakovi = broj.ToString();

                            uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                            this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                        }
                        else
                        {
                            this.ekran = GRESKA;
                        }
                    }
                }
            }
            else
            {
                znakovi = this.ekran;

                double broj;
                if (double.TryParse(znakovi, out broj))
                {
                    if (znakovi[0] != '-')
                    {
                        broj = Math.Sqrt(broj);
                        this.ekran = urediIzgledBroja(broj.ToString());
                    }
                    else
                    {
                        this.ekran = GRESKA;
                    }
                }
            }
        }

        private void I()
        {
            if (this.prethodniZnakBioJeBroj && !this.visekratnoPritiskanjeJednako)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }

            string znakovi;
            if (!prethodniZnakBioJeBinarniOperator())
            {
                if (uneseniBrojeviIOperacije.Count > 0)
                {
                    znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                }
                else
                {
                    if (this.ekran == "0")
                    {
                        this.ekran = GRESKA;
                    }
                    return;
                }

                if (this.ekran != "0")
                {
                    if (uneseniBrojeviIOperacije.Count > 0)
                    {
                        znakovi = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];

                        double broj;
                        if (double.TryParse(znakovi, out broj))
                        {
                            broj = Math.Pow(broj, -1);

                            string brojKaoZnakovi = broj.ToString();

                            uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = urediIzgledBroja(brojKaoZnakovi);

                            this.ekran = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
                        }

                    }
                }
                else
                {
                    this.ekran = GRESKA;
                }
            }
            else
            {
                znakovi = this.ekran;

                double broj;
                if (double.TryParse(znakovi, out broj))
                {
                    if (znakovi != "0")
                    {
                        broj = Math.Pow(broj, -1);
                        this.ekran = urediIzgledBroja(broj.ToString());
                    }
                    else
                    {
                        this.ekran = GRESKA;
                    }
                }
            }
        }

        private void unosBinarnogOperatora(char binOperator)
        {
            if (uneseniBrojeviIOperacije.Count == 0 && this.ekran == "0")
            {
                uneseniBrojeviIOperacije.Add("0");
            }

            if (prethodniZnakBioJeBinarniOperator())
            {
                uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1] = binOperator.ToString(); ;
            }
            else
            {
                uneseniBrojeviIOperacije.Add(binOperator.ToString());
            }
        }

        private void jednako()
        {
            double prviOperand = 0;
            double drugiOperand = 0;
            string operacija = "";
            bool ucitanPrviOperand = false;
            bool ucitanDrugiOperand = false;
            bool ucitanaOperacija = false;
            double rezultat = 0;

            if (this.prethodniZnakBioJeBroj)
            {
                this.prethodniZnakBioJeBroj = false;
                this.uneseniBrojeviIOperacije.Add(broj);
            }
            else
            {
                if (this.binarnaOperacijaPrijeJednako == "" && uneseniBrojeviIOperacije.Count > 1)
                {
                    this.binarnaOperacijaPrijeJednako = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1]; //ukoliko je zadnji znak binarni operator portrebno ga je zapamtiti ukoliko se "=" bude odabiralo vise puta za redom
                }
            }


            foreach (string zapis in this.uneseniBrojeviIOperacije)
            {
                if (!ucitanPrviOperand)
                {
                    if (double.TryParse(zapis, out prviOperand))
                    {
                        ucitanPrviOperand = true;
                    }
                }
                else if (!ucitanaOperacija)
                {
                    operacija = zapis;
                    ucitanaOperacija = true;
                }
                else
                {
                    if (double.TryParse(zapis, out drugiOperand))
                    {
                        ucitanDrugiOperand = true;
                    }
                }
            }

            if (ucitanaOperacija && ucitanDrugiOperand && ucitanPrviOperand)
            {
                rezultat = evaluacijaBinarneOperacije(prviOperand, drugiOperand, operacija);
            }
            else if (ucitanPrviOperand && !ucitanDrugiOperand && !ucitanaOperacija && this.binarnaOperacijaPrijeJednako == "")
            {
                rezultat = prviOperand;
            }
            else if (this.binarnaOperacijaPrijeJednako != "")
            {

                if (this.brojPrijeBinOperacijePrijeJednako == "")
                {
                    this.brojPrijeBinOperacijePrijeJednako = uneseniBrojeviIOperacije[0]; // prvi zapis je broj, a  je operator
                    this.visekratnoPritiskanjeJednako = true;
                }
                drugiOperand = double.Parse(this.brojPrijeBinOperacijePrijeJednako);
                prviOperand = double.Parse(this.ekran);
                rezultat = evaluacijaBinarneOperacije(prviOperand, drugiOperand, binarnaOperacijaPrijeJednako);
            }


            if (this.ekran != GRESKA)
            {
                this.uneseniBrojeviIOperacije.Clear();
                string rezultatZaIspis = rezultat.ToString();

                if (provjeraDuljineZapisa(rezultatZaIspis))
                {
                    uneseniBrojeviIOperacije.Add(rezultatZaIspis);
                    this.ekran = rezultatZaIspis;

                    this.prethodniZnakJeRezultat = true;
                    this.prethodniZnakBioJeBroj = true;
                }
                else
                {
                    rezultatZaIspis = urediIzgledBroja(rezultatZaIspis);

                    if (rezultatZaIspis != GRESKA)
                    {
                        uneseniBrojeviIOperacije.Add(rezultatZaIspis);
                        this.ekran = rezultatZaIspis;
                        this.prethodniZnakJeRezultat = true;
                        this.prethodniZnakBioJeBroj = true;
                    }
                    else
                    {
                        this.ekran = GRESKA;
                    }
                }
            }
        }

        private bool prethodniZnakBioJeBinarniOperator()
        {
            string prethodniZnak = "0";
            if (uneseniBrojeviIOperacije.Count > 0)
            {
                prethodniZnak = uneseniBrojeviIOperacije[uneseniBrojeviIOperacije.Count - 1];
            }

            bool bioJeBinOperator = false;

            if (binarniOperatori.Contains(prethodniZnak[0]) && prethodniZnak.Length == 1)
            {
                bioJeBinOperator = true;
            }

            return bioJeBinOperator;
        }

        private double evaluacijaBinarneOperacije(double prviOperand, double drugiOperand, string operacija)
        {
            double rezultat;

            switch (operacija)
            {
                case "+":
                    rezultat = prviOperand + drugiOperand;
                    break;
                case "-":
                    rezultat = prviOperand - drugiOperand;
                    break;
                case "*":
                    rezultat = prviOperand * drugiOperand;
                    break;
                case "/":
                    if (drugiOperand != 0)
                    {
                        rezultat = prviOperand / drugiOperand;
                    }
                    else
                    {
                        this.ekran = GRESKA;
                        rezultat = 0;
                    }
                    break;

                default:
                    rezultat = 0;
                    this.ekran = GRESKA;
                    break;
            }
            return rezultat;
        }

        private void dodajUMemoriju()
        {
            string zapis = this.ekran;
            double broj;
            if (double.TryParse(zapis, out broj))
            {
                this.memorija = broj.ToString();
            }
        }

        private void dohvatiIzMemorije()
        {
            this.broj = memorija;
            this.ekran = this.broj;
            prethodniBrojJeIzMemorije = true;
            prethodniZnakBioJeBroj = true;
        }

        private void obrisiEkran()
        {
            if (prethodniZnakBioJeBroj)
            {
                this.ekran = "0";
                this.broj = "";
                prethodniZnakBioJeBroj = false;
            }
        }

        private void resetiraj()
        {
            this.broj = "";
            this.ekran = "0";
            this.prethodniBrojJeIzMemorije = false;
            this.prethodniZnakBioJeBroj = false;
            this.prethodniZnakJeRezultat = false;
            this.brojPrijeBinOperacijePrijeJednako = "";
            this.binarnaOperacijaPrijeJednako = "";
            this.imaJednaBinOperacija = false;
            this.visekratnoPritiskanjeJednako = false;
            this.memorija = "0";
            this.uneseniBrojeviIOperacije.Clear();
        }
    }
}
