﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private State state;

        public Kalkulator()
        {
            State.Init();
        }

        /// <summary>
        /// handlanje user input-a
        /// </summary>
        /// <param name="inPressedDigit"></param>
        public void Press(char inPressedDigit)
        {
            state = State.GetCurrentState();

            //broj
            if (Char.IsDigit(inPressedDigit))
            {
                state.HandleDigit(inPressedDigit);
            }

            //binarni operator
            else if (BinaryOperators.Contains(inPressedDigit))
            {
                state.HandleBinaryOperator(inPressedDigit);
            }

            //unarni operator
            else if (UnaryOperators.Contains(inPressedDigit))
            {
                state.HandleUnaryOperator(inPressedDigit);
            }

            //ostali operatori
            else
            {
                switch (inPressedDigit)
                {
                    case 'M':
                        state.handleSignChange();
                        break;
                    case '=':
                        state.HandleEqualsOperator();
                        break;
                    case ',':
                        state.HandleComma();
                        break;
                    case 'P':
                        state.HandleMemoryPut();
                        break;
                    case 'G':
                        state.HandleMemoryGet();
                        break;
                    case 'C':
                        state.HandleClear();
                        break;
                    case 'O':
                        state.HandleReset();
                        break;
                    default:
                        break;
                }
            }

            //zaokruzimo ako mozemo i bacimo error ako treba
            state.CheckDisplayState();
        }

        public string GetCurrentDisplayState()
        {
            return State.GetDisplayState();
        }
    }

    public static class BinaryOperators
    {
        private static char[] operators = { '+', '-', '*', '/' };

        /// <summary>
        /// checks if operator 'op' exits
        /// </summary>
        /// <param name="op"></param>
        /// <returns></returns>
        public static bool Contains(char op)
        {
            return operators.Contains(op);
        }

        /// <summary>
        /// calculates op(n, m)
        /// </summary>
        /// <param name="op"></param>
        /// <param name="n"></param>
        public static double Operate(char op, double n, double m)
        {
            double r = Double.NaN;
            switch (op)
            {
                case '+':
                    r = n + m;
                    break;
                case '-':
                    r = n - m;
                    break;
                case '*':
                    r = n * m;
                    break;
                case '/':
                    r = n / m;
                    break;
                //nedefinirani operator
                case '\0':
                    r = m;
                    break;
            }
            return r;
        }
    }

    class BinaryState : State
    {

        public override void HandleBinaryOperator(char bOp)
        {
            State.bOp = bOp;
        }

        public override void HandleEqualsOperator()
        {
            inc = result;
            result = BinaryOperators.Operate(State.bOp, result, GetDisplayNumber());
            displayState = result.ToString();

            currentState = equalsState;
            State.equalsBinaryFlag = true;
        }

        //public override void handleSignChange() { }
    }

    class EqualsState : State
    {
        public override void HandleBinaryOperator(char bOp)
        {
            inc = BinaryOperators.Operate(State.bOp, result, GetDisplayNumber());
            State.bOp = bOp;

            currentState = binaryState;
            State.equalsBinaryFlag = false;
        }

        public override void HandleEqualsOperator()
        {
            result = BinaryOperators.Operate(State.bOp, result, inc);
            displayState = result.ToString();
        }

        //public override void handleSignChange() { }
    }

    class ErrorState : State
    {
        public override void HandleDigit(char d) { }

        public override void HandleBinaryOperator(char bOp) { }

        public override void HandleUnaryOperator(char uOp) { }

        public override void handleSignChange() { }

        public override void HandleEqualsOperator() { }

        public override void HandleComma() { }

        public override void HandleMemoryPut() { }

        public override void HandleMemoryGet() { }
    }

    class NumberState : State
    {
        /// <summary>
        /// adds digit to display if total number of digits doesn't exceed max number
        /// </summary>
        /// <param name="d"></param>
        private void AddDigit(char d)
        {
            if (NumberOfDigits() < maxNumberOfDigits)
            {
                State.displayState += d;
            }
        }

        /// <summary>
        /// removes unnecesary zeros from the start of the number, if any
        /// </summary>
        private void TrimStartZeros()
        {
            if (displayState.IndexOf(',') == -1 & displayState[0] == '0')
            {
                displayState = displayState.Remove(0, 1);
            }
        }

        public override void HandleDigit(char d)
        {
            //provjerimo je li broj u stanju definiranja
            if (inStateOfDefining)
            {
                AddDigit(d);
                TrimStartZeros();
            }
            else
            {
                displayState = d.ToString();
                inStateOfDefining = true;
            }
        }

        public override void HandleBinaryOperator(char bOp)
        {
            if (equalsBinaryFlag)
            {
                result = GetDisplayNumber();
            }
            else
            {
                result = BinaryOperators.Operate(State.bOp, result, GetDisplayNumber());
            }

            State.bOp = bOp;
            displayState = result.ToString();
            inc = result;

            currentState = binaryState;
            State.equalsBinaryFlag = false;
        }

        public override void HandleEqualsOperator()
        {
            if (State.equalsBinaryFlag)
            {
                result = GetDisplayNumber();
                if (bOp != '\0')
                {
                    result = BinaryOperators.Operate(State.bOp, result, inc);
                }
            }
            else
            {
                inc = GetDisplayNumber();
                result = BinaryOperators.Operate(State.bOp, result, inc);
            }

            displayState = result.ToString();

            currentState = equalsState;
            State.equalsBinaryFlag = true;
        }
    }

    public abstract class State
    {
        public static State numberState;
        public static State binaryState;
        public static State equalsState;
        public static State errorState;
        public const int maxNumberOfDigits = 10;
        protected static string displayState;
        protected static double mem, result;
        protected static char bOp;
        protected static double inc;
        protected static State currentState;
        protected static bool inStateOfDefining;
        protected static bool equalsBinaryFlag;

        public static void Init()
        {
            numberState = currentState = new NumberState();
            binaryState = new BinaryState();
            equalsState = new EqualsState();
            errorState = new ErrorState();
            displayState = "0";
            inStateOfDefining = true;
            mem = 0;
            result = Double.NaN;
            bOp = '\0';
            equalsBinaryFlag = false;
        }

        public static State GetCurrentState()
        {
            return currentState;
        }

        //==========================funckije koje mijenjaju stanja===========================

        public virtual void HandleDigit(char d)
        {
            displayState = d.ToString();

            currentState = numberState;
        }

        public abstract void HandleBinaryOperator(char bOp);

        public virtual void HandleUnaryOperator(char uOp)
        {
            double result = UnaryOperators.Operate(uOp, State.GetDisplayNumber());
            displayState = result.ToString();

            inStateOfDefining = false;
            currentState = numberState;
        }

        public virtual void handleSignChange()
        {
            displayState = (-GetDisplayNumber()).ToString();
        }

        public abstract void HandleEqualsOperator();

        public virtual void HandleComma()
        {
            //provjerimo je li broj u stanju definiranja
            if (inStateOfDefining)
            {
                if (displayState.IndexOf(',') == -1)
                {
                    displayState += ',';
                }
            }
            else
            {
                displayState = "0,";
                inStateOfDefining = true;
            }

            currentState = numberState;
        }

        public virtual void HandleMemoryPut()
        {
            mem = GetDisplayNumber();
        }

        public virtual void HandleMemoryGet()
        {
            displayState = mem.ToString();

            inStateOfDefining = false;
            currentState = numberState;
        }

        public virtual void HandleClear()
        {
            displayState = "0";

            currentState = numberState;
        }

        public virtual void HandleReset()
        {
            Init();
        }

        //===================================================================================

        public void CheckDisplayState()
        {
            double n = GetDisplayNumber();

            //nije doslo do pogreske u RACUNANJU
            if (!Double.IsInfinity(n) & !Double.IsNaN(n))
            {
                //previse znamenaka
                if ((NumberOfDigits() > maxNumberOfDigits))
                {
                    displayState = displayState.TrimStart('-');
                    int commaIndex = displayState.IndexOf(',');

                    //potrebno zaokruziti
                    if (commaIndex != -1 & commaIndex < maxNumberOfDigits)
                    {
                        n = Math.Round(n, maxNumberOfDigits - commaIndex);
                        displayState = n.ToString();
                    }

                    //prevelik broj
                    else
                    {
                        GenerateError();
                    }
                }
            }

            //aritmeticka greska
            else
            {
                GenerateError();
            }
        }

        public void GenerateError()
        {
            currentState = errorState;
            displayState = "-E-";
        }

        /// <summary>
        /// gets display string
        /// </summary>
        /// <returns></returns>
        public static string GetDisplayState()
        {
            return displayState;
        }

        /// <summary>
        /// gets display double
        /// </summary>
        /// <returns></returns>
        public static double GetDisplayNumber()
        {
            try
            {
                return Convert.ToDouble(displayState);
            }
            catch
            {
                //generate error
                currentState = errorState;
                displayState = "-E-";
                return 0;
            }
        }

        /// <summary>
        /// returns number of digits on display
        /// </summary>
        /// <returns></returns>
        public int NumberOfDigits()
        {
            int digits = 0;
            foreach (char c in State.displayState)
            {
                if (Char.IsDigit(c))
                {
                    digits++;
                }
            }
            return digits;
        }
    }

    public static class UnaryOperators
    {
        private static char[] operators = { 'S', 'K', 'T', 'Q', 'R', 'I' };

        /// <summary>
        /// checks if operator 'op' exits
        /// </summary>
        /// <param name="op"></param>
        /// <returns></returns>
        public static bool Contains(char op)
        {
            return operators.Contains(op);
        }

        /// <summary>
        /// calculates op(n)
        /// </summary>
        /// <param name="op"></param>
        /// <param name="n"></param>
        public static double Operate(char op, double n)
        {
            switch (op)
            {
                case 'S':
                    n = Math.Sin(n);
                    break;
                case 'K':
                    n = Math.Cos(n);
                    break;
                case 'T':
                    n = Math.Tan(n);
                    break;
                case 'Q':
                    n = Math.Pow(n, 2);
                    break;
                case 'R':
                    n = Math.Sqrt(n);
                    break;
                case 'I':
                    n = 1 / n;
                    break;
                default:
                    break;
            }
            return n;
        }
    }
}

