﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator {

        public static readonly long MAX_NUM = 9999999999;
        public static readonly float MIN_NUM = .000000001f;
        public static readonly int MAX_DIGITS = 10;
        public static readonly int MAX_DECIMALS = 9;

        private KalkulatorDisplay _display;
        private KalkulatorBuffer _buffer;
        private double _operand, _result, _memory, _unary;
        private char _operation, _lastDigit;

        public Kalkulator() {
            _operand = _result = _memory = 0;
            _display = new KalkulatorDisplay();
            _buffer = new KalkulatorBuffer();
            _operation = ' ';
        }
        public void Press(char inPressedDigit) {

            char d = inPressedDigit;

            if(d == ',' || (d >= 48 && d <= 57)) Digit(d);
            else if(d == '+' || d == '-' || d == '*' || d == '/') BinaryOperation(d);
            else if(d == 'S' || d == 'K' || d == 'T' || d == 'Q' || d == 'R' || d == 'I') UnaryOperation(d);
            else if(d == '=') Equals();
            else if(d == 'M') RevertSign();
            else if(d == 'P') SaveToMemory();
            else if(d == 'G') RestoreFromMemory();
            else if(d == 'C') Clear();
            else if(d == 'O') Reset();
            else return;

            _lastDigit = d;

            //DebugPrint(d);
        }
        public string GetCurrentDisplayState() {
            return _display.Msg;
        }

        //////////////////////////////////////////////////////////////////////////////////

        private void Digit(char d) {
            if(_buffer.State == KalkulatorBuffer.BUFF_RESULT) {
                _buffer.Clear();
                _buffer.State = KalkulatorBuffer.BUFF_APPENDING;
            }
            _buffer.AddDigit(d);
            _display.Refresh(_buffer);
        }
        private void BinaryOperation(char o) {
            if(!LastDigitIsBinaryOperation()) {

                // SAVE BUFFER TO OPERAND
                try { SaveBufferToOperand(); }
                catch(Exception e) {
                    Console.WriteLine("BinaryOperation() -> SaveBufferToOperand() : " + e.Message);
                    Error(); return;
                }

                // PERFORM LAST OPERATION OR SAVE OPERAND TO RESULT
                if(LastOperationExist()) {
                    try { CalculateLastBinaryOperation(); }
                    catch(Exception e) {
                        Console.WriteLine("BinaryOperation()->CalculateLastBinaryOperation() : " + e.Message);
                        Error(); return;
                    }
                }
                else SaveOperandToResult();

                // PUT RESULT INTO BUFFER
                if(_buffer.State != KalkulatorBuffer.BUFF_ERROR) {
                    try { _buffer.PutNumber(_result); }
                    catch(Exception e) {
                        Console.WriteLine("BinaryOperation()->_buffer.PutNumber() : " + e.Message);
                        Error(); return;
                    }
                    _buffer.State = KalkulatorBuffer.BUFF_RESULT;
                }
            }

            _display.Refresh(_buffer);

            SaveOperation(o);
        }
        private void UnaryOperation(char o) {
            // SAVE BUFFER TO UNARY OPERAND
            try { SaveBufferToUnaryOperand(); }
            catch(Exception e) {
                Console.WriteLine("UnaryOperation()->SaveBufferToUnaryOperand() : " + e.Message);
                return;
            }

            // CALCULATE UNARY OPERATION
            try { CalculateUnaryOperation(o); }
            catch(Exception e) {
                Console.WriteLine("UnaryOperation()->CalculateLastUnaryOperation() : " + e.Message);
                Error(); return;
            }

            // PUT RESULT INTO BUFFER
            if(_buffer.State != KalkulatorBuffer.BUFF_ERROR) {
                try { _buffer.PutNumber(_unary); }
                catch(Exception e) {
                    Console.WriteLine("UnaryOperation()->_buffer.PutNumber() : " + e.Message);
                    Error(); return;
                }
                _buffer.State = KalkulatorBuffer.BUFF_RESULT;
            }
            _unary = 0;
            _display.Refresh(_buffer);
        }
        private void Equals() {
            // SAVE BUFFER TO OPERAND
            try { SaveBufferToOperand(); }
            catch(Exception e) {
                Console.WriteLine("Equals() -> SaveBufferToOperand() : " + e.Message);
                Error(); return;
            }

            // PERFORM LAST OPERATION OR SAVE OPERAND TO RESULT
            if(LastOperationExist()) {
                try { CalculateLastBinaryOperation(); }
                catch(Exception e) {
                    Console.WriteLine("Equals()->CalculateLastBinaryOperation() : " + e.Message);
                    Error(); return;
                }
            }
            else SaveOperandToResult();

            // PUT RESULT INTO BUFFER
            if(_buffer.State != KalkulatorBuffer.BUFF_ERROR) {
                try { _buffer.PutNumber(_result); }
                catch(Exception e) {
                    Console.WriteLine("Equals()->_buffer.PutNumber() : " + e.Message);
                    Error(); return;
                }
                _buffer.State = KalkulatorBuffer.BUFF_RESULT;
            }

            _display.Refresh(_buffer);
            _operation = ' ';

        }
        private void RevertSign() {
            _buffer.RevertSign();
            _display.Refresh(_buffer);
        }
        private void SaveToMemory() {
            try { _memory = _buffer.GetNumber(); }
            catch(Exception e) {
                Console.WriteLine("SaveToMemory()->_buffer.GetNumber() : " + e.Message);
                Error();
            }
        }
        private void RestoreFromMemory() {
            // PUT MEMORY INTO BUFFER
            try { _buffer.PutNumber(_memory); }
            catch(Exception e) {
                Console.WriteLine("RestoreFromMemory()->_buffer.PutNumber() : " + e.Message);
                Error(); return;
            }
            _buffer.State = KalkulatorBuffer.BUFF_APPENDING;
            _display.Refresh(_buffer);
        }
        private void Clear() {
            //_operation = ' ';
            _buffer.Clear();
            _display.Clear();
        }
        private void Error() {
            Reset();
            _display.Error();
        }
        private void Reset() {
            _result = _operand = 0;
            _operation = ' ';
            _memory = 0;
            _buffer.Clear();
            _display.Clear();
        }

        //////////////////////////////////////////////////////////////////////////////////

        private void CalculateLastBinaryOperation() {
            switch(_operation) {
                case '+':
                    _result += _operand;
                    break;
                case '-':
                    _result -= _operand;
                    break;
                case '*':
                    _result *= _operand;
                    break;
                case '/':
                    if(_operand == 0) throw new ArithmeticException();
                    _result /= _operand;
                    break;
            }
            if(!NumIsValid(_result)) throw new ArithmeticException();
            else _result = Math.Round(_result, MAX_DECIMALS);
        }
        private void CalculateUnaryOperation(char o) {
            switch(o) {
                case 'S':
                    _unary = Math.Sin(_unary);
                    break;
                case 'K':
                    _unary = Math.Cos(_unary);
                    break;
                case 'T':
                    _unary = Math.Tan(_unary);
                    break;
                case 'Q':
                    _unary = Math.Pow(_unary, 2);
                    break;
                case 'R':
                    _unary = (Math.Sqrt(_unary));
                    break;
                case 'I':
                    if(_unary == 0)
                        throw new ArithmeticException();
                    _unary = (double)1 / _unary;
                    break;
            }
            if(!NumIsValid(_unary)) throw new ArithmeticException();
            else _unary = Math.Round(_unary, MAX_DECIMALS);

        }
        private void SaveBufferToOperand() {
            if(_buffer.DigitCount == 0) _operand = 0;
            else {
                try { _operand = _buffer.GetNumber(); }
                catch(Exception e) { throw e; }
                _buffer.Clear();
            }
        }
        private void SaveBufferToUnaryOperand() {
            if(_buffer.DigitCount == 0) _operand = 0;
            else {
                try { _unary = _buffer.GetNumber(); }
                catch(Exception e) { throw e; }
                _buffer.Clear();
            }
        }
        private void SaveOperandToResult() {
            _result = _operand;
        }
        private void SaveOperation(char o) {
            if(o != '+' && o != '-' && o != '*' && o != '/') _operation = ' ';
            else _operation = o;
        }
        private bool LastOperationExist() {
            char o = _operation;
            return (o == '+' || o == '-' || o == '*' || o == '/');
        }
        private bool LastDigitIsBinaryOperation() {
            return _lastDigit == '+' || _lastDigit == '-' || _lastDigit == '*' || _lastDigit == '/';
        }

        public static bool NumIsValid(double num) {
            return !(num > MAX_NUM || (num < MIN_NUM && num > 0) ||
                    (num > (MIN_NUM * (-1)) && num < 0) || num < (MAX_NUM * (-1))
                   );
        }


        //////////////////////////////////////////////////////////////////////////////////

        private class KalkulatorBuffer {

            public static readonly int BUFF_ERROR = -1;
            public static readonly int BUFF_APPENDING = 0;
            public static readonly int BUFF_RESULT = 1;

            private List<char> _buf;
            private int _state;

            public KalkulatorBuffer() {
                _buf = new List<char>();
                _state = BUFF_APPENDING;
            }
            public char[] Buffer {
                get {
                    char[] res = _buf.ToArray();
                    return res;
                }
            }
            public int State {
                get {
                    return _state;
                }
                set {
                    if(value != BUFF_APPENDING && value != BUFF_ERROR && value != BUFF_RESULT)
                        throw new ArgumentOutOfRangeException();
                    else _state = value;
                }
            }
            public double Number {
                get {
                    if(_buf.Count <= 0) throw new ArithmeticException();

                    char[] arr = _buf.ToArray();
                    for(int i = 0; i < arr.Length; i++) {
                        if(arr[i] == ',') arr[i] = '.';
                    }

                    double res = 0;

                    try { res = Convert.ToDouble(new string(arr)); }
                    catch(Exception e) { throw e; }

                    return res;
                }
            }
            public int DigitCount {
                get {
                    int count = 0;
                    for(int i = 0; i < _buf.Count; i++) {
                        if(_buf[i] >= '0' && _buf[i] <= '9') count++;
                    }
                    return count;
                }
            }
            public void AddDigit(char d) {
                if(this.DigitIsValid(d)) {
                    if(_buf.Count == 0 && d == ',') _buf.Add('0');
                    _buf.Add(d);
                }
            }
            public double GetNumber() {
                if(_buf.Count <= 0) throw new ArithmeticException();

                char[] arr = _buf.ToArray();
                for(int i = 0; i < arr.Length; i++) {
                    if(arr[i] == ',') arr[i] = '.';
                }

                double res = 0;

                try { res = Convert.ToDouble(new string(arr)); }
                catch(Exception e) { throw e; }

                return res;
            }
            public void PutNumber(double num) {
                if(NumIsValid(num)) {
                    _buf.Clear();
                    char[] tmp = num.ToString().ToCharArray();
                    for(int i = 0; i < tmp.Length; i++) {
                        if(tmp[i] == '.') _buf.Add(',');
                        else _buf.Add(tmp[i]);
                    }
                }
                else
                    throw new ArithmeticException();
            }
            public void Clear() {
                _buf.Clear();
            }
            public void RevertSign() {
                if(_buf.Count == 0) return;
                if(_buf[0] == '-') _buf.RemoveAt(0);
                else _buf.Insert(0, '-');
            }

            private bool DigitIsValid(char d) {
                if(d == ',' && (_buf.Contains(',') || this.DigitCount == MAX_DIGITS)) return false;
                if(_buf.Count == 0 && d == '0') return false;
                if(d >= '0' && d <= '9' && this.DigitCount == MAX_DIGITS) return false;
                return true;
            }

        }

        private class KalkulatorDisplay {

            private const string DISP_CLEAR = "0";
            private const string DISP_ERROR = "-E-";
            private readonly int DISP_LEN = 12;

            private String _msg;

            public KalkulatorDisplay() { _msg = DISP_CLEAR; }
            public string Msg {
                get { return _msg; }
            }
            public void Refresh(char[] buf) {
                if(buf.Length <= 0) {
                    Clear();
                }
                else if(buf.Length > DISP_LEN) {
                    char[] tmp = new char[DISP_LEN];
                    for(int i = 0; i < DISP_LEN; i++)
                        tmp[i] = buf[i];
                    _msg = new String(tmp);
                }
                else {
                    _msg = new String(buf);
                }
            }
            public void Refresh(KalkulatorBuffer buf) {
                this.Refresh(buf.Buffer);
            }
            public void Clear() { 
                _msg = DISP_CLEAR; 
            }
            public void Error() { 
                _msg = DISP_ERROR; 
            }

        }

        private void DebugPrint(char d) {
            Console.WriteLine(d + " |" + GetCurrentDisplayState() + "|");
            /*Console.Out.WriteLine(
                d + " |" + 
                GetCurrentDisplayState() + "|     |" + 
                _result + "|" + 
                _operand + "|" + 
                _operation + "|" + 
                _memory + "|"
            );*/
        }

    }


}
