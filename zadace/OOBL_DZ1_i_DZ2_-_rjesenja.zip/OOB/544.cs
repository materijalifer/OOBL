﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{

    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class Stock
    {
        private string _name;
        private long _numberOfShares;
        private Decimal _initialPrice;
        private DateTime _timeStamp;

        public long AvailableShares;

        
        private SortedDictionary<DateTime, Decimal> _pricesHistory = new SortedDictionary<DateTime, decimal>();


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public long NumberOfShares
        {
            get { return _numberOfShares; }
            set { _numberOfShares = value; }
        }

        public Decimal InitialPrice
        {
            get { return _initialPrice; }
            set { _initialPrice = value; }
        }

        public DateTime TimeStamp
        {
            get { return _timeStamp; }
            set { _timeStamp = value; }
        }


        public Stock(string name, long numOfShares, Decimal initPrice, DateTime ts)
        {
            Name = name;
            NumberOfShares = numOfShares;
            InitialPrice = initPrice;
            TimeStamp = ts;

            AvailableShares = numOfShares;

            _pricesHistory[ts] = initPrice;
        }


        public void SetPrice(Decimal price, DateTime ts)
        {
            if (_pricesHistory.ContainsKey(ts))
                throw new StockExchangeException("Za ovaj trenutak je vec postavljena cijena");
            TimeStamp = ts;
            InitialPrice = price;

            _pricesHistory[ts] = price;
        }

        private DateTime closestTime(DateTime time)
        {
            if (DateTime.Compare(time, _pricesHistory.Keys.First()) < 0)
                throw new StockExchangeException("Trazite vrijeme ranije od prvog unosa!");

            DateTime closest = _pricesHistory.Keys.First();
            foreach (KeyValuePair<DateTime, Decimal> kvp in _pricesHistory)
            {
                if (DateTime.Compare(kvp.Key, time) > 0)
                    return closest;
                closest = kvp.Key;
            }
            return closest;
        }

        public Decimal GetPriceForTime(DateTime time)
        {
            DateTime closest = closestTime(time);
            return _pricesHistory[closest];
        }

        public Decimal GetInitialPrice()
        {
            return _pricesHistory.Values.First();
        }

        public Decimal GetLastPrice()
        {
            return _pricesHistory.Values.Last();
        }
    }


    public class StockRep
    {
        List<Stock> _listStocks = new List<Stock>();

        public StockRep() { }


        public void AddStock(Stock st)
        {
            if (StockInRep(st.Name))
                throw new StockExchangeException("Ova vec postoji!");
            if (st.NumberOfShares <= 0)
                throw new StockExchangeException("Br. dionica mora biti strogo veci od nule!");
            if (st.InitialPrice <= 0)
                throw new StockExchangeException("Cijena dionice mora biti strogo veca od nule!");

            _listStocks.Add(st);
        }

        public void RemoveStock(Stock stock)
        {
            if (!StockInRep(stock.Name))
                throw new StockExchangeException("Sa burze pokusavate izbrisati dionicu koja na njoj ne postoji");
            _listStocks.Remove(stock);
        }

        public bool StockInRep(string stockName)
        {
            foreach (Stock st in _listStocks)
            {
                if (string.Equals(st.Name, stockName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        public Stock ReturnStock(string stockName)
        {
            foreach (Stock stock in _listStocks)
            {
                if (string.Equals(stock.Name, stockName, StringComparison.OrdinalIgnoreCase))
                    return stock;
            }
            throw new StockExchangeException("Nema dionice koju trazite");
        }

        public int Count()
        {
            return _listStocks.Count;
        }
    }


    public abstract class StockIndex
    {
        protected string _name;
        protected IndexTypes _type;

        protected List<Stock> _listStocksOfIndex = new List<Stock>();

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public IndexTypes Type
        {
            get { return _type; }
            set { _type = value; }
        }

        public StockIndex(string name, IndexTypes type)
        {
            Name = name;
            Type = type;
        }


        public void AddStockToIndex(Stock stock)
        {
            if (StockInIndex(stock.Name))
                throw new StockExchangeException("Dionica vec postoji u ovom indeksu");
            _listStocksOfIndex.Add(stock);
        }

        public void RemoveStockFromIndex(Stock stock)
        {
            if (!StockInIndex(stock.Name))
                throw new StockExchangeException("Iz indeksa pokusavate izbrisati dionicu koja u njemu ne postoji");
            _listStocksOfIndex.Remove(stock);
        }

        public bool StockInIndex(string stockName)
        {
            foreach (Stock stock in _listStocksOfIndex)
            {
                if (string.Equals(stock.Name, stockName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        public int CountOfStocks()
        {
            return _listStocksOfIndex.Count;
        }

        public abstract Decimal IndexValueInTime(DateTime time);

    }


    public class AvgStockIndex : StockIndex
    {
        public AvgStockIndex(string name, IndexTypes type) : base(name, type) { }

        public override Decimal IndexValueInTime(DateTime time)
        {
            Decimal sum = 0;  
            foreach (Stock stock in _listStocksOfIndex)
            {
                sum += stock.GetPriceForTime(time);
            }
            if (CountOfStocks() > 0)
                return decimal.Round((sum / CountOfStocks()), 3);
            return 0;
        }
    }

    public class WtdStockIndex : StockIndex
    {
        public WtdStockIndex(string name, IndexTypes type) : base(name, type) { }

        public override Decimal IndexValueInTime(DateTime time)
        {
            Decimal sumOfAll = 0;
            Decimal sum = 0;

            foreach (Stock stock in _listStocksOfIndex)
            {
                sumOfAll += stock.GetPriceForTime(time) * stock.NumberOfShares;
            }

            foreach (Stock stock in _listStocksOfIndex)
            {
                Decimal factor = stock.GetPriceForTime(time) / sumOfAll;

                sum += factor * (stock.GetPriceForTime(time) * stock.NumberOfShares);
            }

            return decimal.Round(sum, 3);
        }
    }



    public static class StockIndexFactory
    {

        public static StockIndex CreateStockIndex(IndexTypes type, string name)
        {
            if (type == IndexTypes.AVERAGE)
                return new AvgStockIndex(name, type);
            else if (type == IndexTypes.WEIGHTED)
                return new WtdStockIndex(name, type);

            throw new StockExchangeException("Nema tog tipa indeksa");
        }
    }


    public class StockIndexRep
    {
        List<StockIndex> _listStockIndices = new List<StockIndex>();

        public StockIndexRep()
        {
        }

        public void AddStockIndex(StockIndex index)
        {
            if (StockIndexInRep(index.Name))
                throw new StockExchangeException("Ovaj vec postoji!");

            _listStockIndices.Add(index);
        }


        public bool StockIndexInRep(string indexName)
        {
            foreach (StockIndex index in _listStockIndices)
            {
                if (string.Equals(index.Name, indexName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }


        public StockIndex ReturnStockIndex(string indexName)
        {
            foreach (StockIndex index in _listStockIndices)
            {
                if (string.Equals(index.Name, indexName, StringComparison.OrdinalIgnoreCase))
                    return index;
            }

            throw new StockExchangeException("Nema indeksa");
        }


        public void RemoveStockFromAllIndices(Stock stock)
        {
            foreach (StockIndex index in _listStockIndices)
            {
                if (index.StockInIndex(stock.Name))
                    index.RemoveStockFromIndex(stock);
            }
        }


        public int Count()
        {
            return _listStockIndices.Count;
        }
    }




    public class Portfolio
    {
        private string _id;

        private Dictionary<Stock, int> _sharesInPortfolio = new Dictionary<Stock, int>();

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public Portfolio(string id)
        {
            Id = id;
        }


        public void AddSharesToPortfolio(Stock stock, int numberOfShares)
        {
            if (_sharesInPortfolio.ContainsKey(stock))
                _sharesInPortfolio[stock] += numberOfShares;
            else
                _sharesInPortfolio[stock] = numberOfShares;

            stock.AvailableShares -= numberOfShares;
        }

        public void RemoveSharesFromPortfolio(Stock stock, int numberOfShares)
        {
            if (_sharesInPortfolio.ContainsKey(stock))
            {
                int numOfSharesToRemove;

                if (_sharesInPortfolio[stock] > numberOfShares)
                {
                    numOfSharesToRemove = _sharesInPortfolio[stock] - numberOfShares;
                    _sharesInPortfolio[stock] -= numOfSharesToRemove;
                }
                else
                {
                    numOfSharesToRemove = _sharesInPortfolio[stock];
                    RemoveStockFromPortfolio(stock);
                }

                stock.AvailableShares += numOfSharesToRemove;

            }
            else
                throw new StockExchangeException("Dionice ciji udio zelite obrisati iz portfelja ne nalazi se u njemu");
        }

        public void RemoveStockFromPortfolio(Stock stock)
        {
            if (_sharesInPortfolio.ContainsKey(stock))
            {
                _sharesInPortfolio.Remove(stock);
            }
            else
                throw new StockExchangeException("Dionica koju zelite obrisati iz portfelja ne nalazi se u njemu");
        }

        public bool HasSharesOfStock(Stock stock)
        {
            if (_sharesInPortfolio.ContainsKey(stock))
                return true;
            return false;
        }

        public int NumberOfStocksInPortfolio()
        {
            return _sharesInPortfolio.Count;
        }

        public int NumberOfSharesOfStockInPortfolio(Stock stock)
        {
            if (_sharesInPortfolio.ContainsKey(stock))
                return _sharesInPortfolio[stock];
            return 0;
        }


        public Decimal PortfolioValue(DateTime time)
        {
            Decimal sum = 0;
            foreach (KeyValuePair<Stock, int> kvp in _sharesInPortfolio)
            {
                sum += kvp.Key.GetPriceForTime(time) * kvp.Value;
            }
            return decimal.Round(sum, 3);
        }


        public Decimal PortfolioPercentChange(int year, int month)
        {
            if (month > 12 || month < 1)
                throw new StockExchangeException("Kakav je to mjesec?");
            Decimal lastDayPrice = PortfolioValue(new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999));
            Decimal firstDayPrice = PortfolioValue(new DateTime(year, month, 1, 00, 00, 00));

            if (firstDayPrice > 0)
                return decimal.Round(((lastDayPrice - firstDayPrice) / firstDayPrice) * 100, 3);
            return 0;
        }

    }




    public class PortfolioRep
    {
        List<Portfolio> _listPortfolios = new List<Portfolio>();

        public PortfolioRep()
        {

        }


        public void AddPortfolio(Portfolio pfl)
        {
            if (PortfolioInRep(pfl.Id))
                throw new StockExchangeException("Ovaj portfelj vec postoji!");

            _listPortfolios.Add(pfl);
        }

        public bool PortfolioInRep(string portfolioId)
        {
            foreach (Portfolio pfl in _listPortfolios)
            {
                if (string.Equals(pfl.Id, portfolioId))
                    return true;
            }
            return false;
        }

        public Portfolio ReturnPortfolio(string portfolioId)
        {
            foreach (Portfolio pfl in _listPortfolios)
            {
                if (string.Equals(pfl.Id, portfolioId))
                    return pfl;
            }

            throw new StockExchangeException("Nema trazenog portfelja na burzi");
        }


        public void RemoveStockFromAllPortfolios(Stock stock)
        {
            foreach (Portfolio pfl in _listPortfolios)
            {
                if (pfl.HasSharesOfStock(stock))
                    pfl.RemoveStockFromPortfolio(stock);
            }
        }


        public int Count()
        {
            return _listPortfolios.Count;
        }
    }



    public class StockExchange : IStockExchange
    {

        private StockRep _stockRepository;
        private StockIndexRep _stockIndicesRepository;
        private PortfolioRep _portfoliosRepository;

        public StockExchange()
        {
            _stockRepository = new StockRep();
            _stockIndicesRepository = new StockIndexRep();
            _portfoliosRepository = new PortfolioRep();
        }


         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             _stockRepository.AddStock(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
         }


         public void DelistStock(string inStockName)
         {
             if (!_stockRepository.StockInRep(inStockName))
                 throw new StockExchangeException("Sa burze pokusavate izbrisati dionicu koja na njoj ne postoji");

             Stock stock = _stockRepository.ReturnStock(inStockName);

             _stockIndicesRepository.RemoveStockFromAllIndices(stock);
             _portfoliosRepository.RemoveStockFromAllPortfolios(stock);
             _stockRepository.RemoveStock(stock);
         }

         public bool StockExists(string inStockName)
         {
             return _stockRepository.StockInRep(inStockName);
         }

         public int NumberOfStocks()
         {
             return _stockRepository.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             _stockRepository.ReturnStock(inStockName).SetPrice(inStockValue, inTimeStamp);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             return _stockRepository.ReturnStock(inStockName).GetPriceForTime(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             return _stockRepository.ReturnStock(inStockName).GetInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             return _stockRepository.ReturnStock(inStockName).GetLastPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
            StockIndex index = StockIndexFactory.CreateStockIndex(inIndexType, inIndexName);
            _stockIndicesRepository.AddStockIndex(index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!_stockIndicesRepository.StockIndexInRep(inIndexName))
                 throw new StockExchangeException("Ne postoji indeks kojem bi se pridijelila ova dionica");
             if (!_stockRepository.StockInRep(inStockName))
                 throw new StockExchangeException("Ne postoji dionica koju dodjeljujete indeksu");

             _stockIndicesRepository.ReturnStockIndex(inIndexName).AddStockToIndex(_stockRepository.ReturnStock(inStockName));
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!_stockIndicesRepository.StockIndexInRep(inIndexName))
                 throw new StockExchangeException("Ne postoji indeks iz kojeg bi se izbrisala ova dionica");
             if (!_stockRepository.StockInRep(inStockName))
                 throw new StockExchangeException("Ne postoji dionica na burzi");

             _stockIndicesRepository.ReturnStockIndex(inIndexName).RemoveStockFromIndex(_stockRepository.ReturnStock(inStockName));
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             return _stockIndicesRepository.ReturnStockIndex(inIndexName).StockInIndex(inStockName);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return _stockIndicesRepository.ReturnStockIndex(inIndexName).IndexValueInTime(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             return _stockIndicesRepository.StockIndexInRep(inIndexName);
         }

         public int NumberOfIndices()
         {
             return _stockIndicesRepository.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return _stockIndicesRepository.ReturnStockIndex(inIndexName).CountOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             _portfoliosRepository.AddPortfolio(new Portfolio(inPortfolioID));
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares <= 0)
                 throw new StockExchangeException("Dodajete negativnu vrijednost sto nije dozvoljeno!");
             Stock st = _stockRepository.ReturnStock(inStockName);
             if (st.AvailableShares < numberOfShares)
                 numberOfShares = (int)st.AvailableShares;
             Portfolio pfl = _portfoliosRepository.ReturnPortfolio(inPortfolioID);
             pfl.AddSharesToPortfolio(st, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (numberOfShares <= 0)
                 throw new StockExchangeException("Oduzimate negativnu vrijednost sto nije dozvoljeno!");
             Stock st = _stockRepository.ReturnStock(inStockName);
             Portfolio pfl = _portfoliosRepository.ReturnPortfolio(inPortfolioID);
             pfl.RemoveSharesFromPortfolio(st, numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             _portfoliosRepository.ReturnPortfolio(inPortfolioID).RemoveStockFromPortfolio(_stockRepository.ReturnStock(inStockName));
         }

         public int NumberOfPortfolios()
         {
             return _portfoliosRepository.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             return _portfoliosRepository.ReturnPortfolio(inPortfolioID).NumberOfStocksInPortfolio();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return _portfoliosRepository.PortfolioInRep(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (_stockRepository.StockInRep(inStockName))
                 return _portfoliosRepository.ReturnPortfolio(inPortfolioID).HasSharesOfStock(_stockRepository.ReturnStock(inStockName));
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             return _portfoliosRepository.ReturnPortfolio(inPortfolioID).NumberOfSharesOfStockInPortfolio(_stockRepository.ReturnStock(inStockName));
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return _portfoliosRepository.ReturnPortfolio(inPortfolioID).PortfolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return _portfoliosRepository.ReturnPortfolio(inPortfolioID).PortfolioPercentChange(Year, Month);
         }
     }
}
