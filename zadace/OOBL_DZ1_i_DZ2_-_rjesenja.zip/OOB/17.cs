﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    //Pobrojani tip koji označava trenutno stanje kalkulatora
    //Start-kalkulator upaljen/resetiran
    //PrviOperand/DrugiOperand-u tijeku je unos znamenki prvog/drugog operanda
    //Binarna-Pritisnuta je +,-,* ili / tipka
    //Unarna-Na nekom od operanada je provedena binarna operacija
    enum Stanje { Start, PrviOperand, DrugiOperand, Binarna, Unarna }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }



    public class Kalkulator : ICalculator
    {
        char[] binarneOperacije = { '+', '-', '*', '/' };
        char[] unarneOperacije = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'P', 'G', 'C', 'O' };

        Stanje stanje;
        StringBuilder ekran;
        StringBuilder operand;
        char lastNum;
        double prviOperand, drugiOperand;

        string memorija;
        public Kalkulator()
        {
            ekran = new StringBuilder("0");
            prviOperand = double.NaN;
            drugiOperand = double.NaN;
            lastNum = ' ';
            operand = new StringBuilder();
            stanje = Stanje.Start;

        }


        //Funkcija koja obrađuje unesenu znamenku
        public void Press(char inPressedDigit)
        {
            //ako je ulazna znamenka '='
            if (inPressedDigit == '=')
            {
                //Za svaku znamenku provjeravamo u kojem se stanju nalazimo,i na temelju toga
                //izvršavamo neku akciju
                switch (stanje)
                {

                    case Stanje.Start:
                        operand = new StringBuilder("0");
                        break;

                    //ne radi ništa
                    case Stanje.PrviOperand:
                        break;

                    //Izvrši binarnu operaciju, spremi rezultat u prviOperand
                    //očisti međuspremnik (operand)
                    case Stanje.DrugiOperand:
                        drugiOperand = double.Parse(operand.ToString());
                        BinarnaOperacija(prviOperand, drugiOperand, lastNum);
                        operand = operand.Clear();
                        stanje = Stanje.PrviOperand;
                        break;

                    //Ako je drugiOperand NaN(nije unesen) to znači da je unesen niz komandi
                    //tipa operand_Binarna_= što se inerpretira kao operand_binarna_operand_=
                    case Stanje.Binarna:
                        if (drugiOperand.ToString() == "NaN")
                            BinarnaOperacija(prviOperand, prviOperand, lastNum);
                        stanje = Stanje.Binarna;
                        break;

                    case Stanje.Unarna:
                        UnarnaOperacija(inPressedDigit);
                        break;

                    default:
                        break;


                }

            }
            //ako je ulazna znamenka +,-,*,/
            else if (binarneOperacije.Contains(inPressedDigit))
            {
                switch (stanje)
                {
                    //ako odmah na početku stisnemo binarno,inerpretira se kao 0 + ...
                    //jer je na početku na ekranu prikazana 0
                    case Stanje.Start:
                        prviOperand = 0;
                        stanje = Stanje.Binarna;
                        break;

                    //završavamo s unosom prvog operanda
                    case Stanje.PrviOperand:
                        prviOperand = double.Parse(operand.ToString());
                        stanje = Stanje.Binarna;
                        break;

                    //završavamo s unosom drugog operanda i napravimo operaciju
                    case Stanje.DrugiOperand:
                        drugiOperand = double.Parse(operand.ToString());
                        BinarnaOperacija(prviOperand, drugiOperand, lastNum);
                        stanje = Stanje.Binarna;
                        break;

                    //ako je ponovno onesena operacija,samo promijenimo vrstu operacije
                    case Stanje.Binarna:
                        break;

                    //nešto tipa 2u+ i 2+2u+ (za to je ovaj if) - u=unarna operacija
                    case Stanje.Unarna:
                        if (drugiOperand.ToString() == "NaN")
                            stanje = Stanje.Binarna;
                        else
                        {
                            BinarnaOperacija(prviOperand, drugiOperand, lastNum);
                            stanje = Stanje.Binarna;
                        }
                        break;

                    default:
                        break;
                }
                //to je varijabla u kojoj se pamti zadnja operacija
                lastNum = inPressedDigit;
            }
            else if (unarneOperacije.Contains(inPressedDigit))
            {
                switch (stanje)
                {

                    //ako je bilo šta ,napravi unarnu :)
                    case Stanje.Start:
                    case Stanje.PrviOperand:
                    case Stanje.DrugiOperand:
                    case Stanje.Binarna:
                    case Stanje.Unarna:
                        UnarnaOperacija(inPressedDigit);
                        break;

                    default:
                        break;
                }

            }
            //to je ako se unose brojke ili ','
            else
            {
                switch (stanje)
                {

                    case Stanje.Start:
                        //ne dopušta unos više nula zaredom na početku ( 00000 )
                        if (inPressedDigit == '0')
                            operand = new StringBuilder("0");
                        //ne dopušta unos ',nešto' nego konvertira u '0,nešto'
                        else if (inPressedDigit == ',')
                        {
                            operand = new StringBuilder("0,");

                        }
                        else
                        {
                            operand = new StringBuilder(inPressedDigit.ToString());

                        }
                        stanje = Stanje.PrviOperand;
                        break;

                    case Stanje.PrviOperand:
                        operand.Append(inPressedDigit);
                        break;

                    case Stanje.DrugiOperand:
                        operand.Append(inPressedDigit);
                        break;

                    case Stanje.Binarna:
                        drugiOperand = double.NaN;
                        if (inPressedDigit == '0')
                            operand = new StringBuilder("0");
                        else if (inPressedDigit == ',')
                        {
                            operand = new StringBuilder("0,");

                        }
                        else
                        {
                            operand = new StringBuilder(inPressedDigit.ToString());

                        }
                        stanje = Stanje.DrugiOperand;
                        break;

                    case Stanje.Unarna:
                        if (inPressedDigit == '0')
                            operand = new StringBuilder("0");
                        else if (inPressedDigit == ',')
                        {
                            operand = new StringBuilder("0,");

                        }
                        else
                        {
                            operand = new StringBuilder(inPressedDigit.ToString());

                        }
                        break;
                    default:
                        break;
                }
            }

        }

        //vraća stanje ekrana
        public string GetCurrentDisplayState()
        {

            UpdScreen();
            return ekran.ToString();
        }


        //izvršava unarnu operaciju op
        void UnarnaOperacija(char op)
        {
            if (operand.ToString() == "")
                operand = new StringBuilder("0");

            switch (op)
            {
                // +/-
                case 'M':
                    if (operand[0] == '-')
                    {
                        operand.Remove(0, 1);
                    }
                    else
                    {
                        operand.Insert(0, '-');
                    }
                    break;

                //sinus
                case 'S':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder(Math.Sin(opr).ToString());
                        //if služi za stvari tipa 2+S -na ekranu mora prikazati rezultat sin(2),
                        // ali u varijabli prviOperand mora ostati vrijednost 2
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'K':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder(Math.Cos(opr).ToString());
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'T':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder(Math.Tan(opr).ToString());
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'Q':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder((opr * opr).ToString());
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'R':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder(Math.Sqrt(opr).ToString());
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'I':
                    try
                    {
                        double opr = double.Parse(operand.ToString());
                        operand = new StringBuilder((1 / opr).ToString());
                        if (stanje != Stanje.Binarna && stanje != Stanje.DrugiOperand)
                            stanje = Stanje.Unarna;
                        if (operand.ToString() == "Infinity")
                        {
                            operand = new StringBuilder("-E-");
                            return;
                        }

                    }
                    catch
                    {
                        ekran = new StringBuilder("-E-");
                    }
                    break;

                case 'P':
                    memorija = operand.ToString();
                    break;

                case 'G':
                    operand = new StringBuilder(memorija);
                    break;
                case 'C':
                    operand = new StringBuilder("0");
                    return;

                case 'O':
                    prviOperand = double.NaN;
                    drugiOperand = double.NaN;
                    memorija = "";
                    ekran = new StringBuilder("0");
                    operand = new StringBuilder();
                    lastNum = ' ';
                    stanje = Stanje.Start;
                    return;
            }

            if (stanje != Stanje.Binarna && prviOperand.ToString() == "NaN")
            {
                prviOperand = double.Parse(operand.ToString());
                return;
            }

            if (stanje != Stanje.Binarna && prviOperand.ToString() != "NaN")
                drugiOperand = double.Parse(operand.ToString());



        }

        void BinarnaOperacija(double a, double b, char op)
        {
            switch (op)
            {
                case '+':
                    prviOperand = a + b;
                    operand = new StringBuilder(prviOperand.ToString());
                    break;
                case '-':
                    prviOperand = a - b;
                    operand = new StringBuilder(prviOperand.ToString());
                    break;
                case '*':
                    prviOperand = a * b;
                    operand = new StringBuilder(prviOperand.ToString());
                    break;
                case '/':
                    prviOperand = a / b;
                    operand = new StringBuilder(prviOperand.ToString());
                    break;
            }

            ekran = new StringBuilder(prviOperand.ToString());
        }

        void UpdScreen()
        {
            if (operand.ToString() == "")
            {
                if (prviOperand.ToString() != "NaN")
                {
                    operand = new StringBuilder(prviOperand.ToString());
                    Zaokruzi();

                }
                else
                    operand = new StringBuilder("0");


            }
            else if (operand.ToString() != "-E-" && stanje != Stanje.Binarna)
                Zaokruzi();

            ekran = new StringBuilder(operand.ToString());

        }

        void Zaokruzi()
        {
            //pretvorba također miče višak nula...tipa 00.3 i 2.000
            double op = double.Parse(operand.ToString());

            if (op > 10000000000)
            {
                operand = new StringBuilder("-E-");
                return;
            }

            int indeks = operand.ToString().IndexOf(',');
            if (indeks != -1)
            {
                if (operand.ToString().Contains('-'))
                    op = Math.Round(op, 11 - indeks);
                else
                    op = Math.Round(op, 10 - indeks);
            }
            operand = new StringBuilder(op.ToString());
        }
    }


}


