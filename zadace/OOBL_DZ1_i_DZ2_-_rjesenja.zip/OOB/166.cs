﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private double ans, tren,memorija;
        private String ekran;
        private int stanje;
        private char bop;
        private bool jeGreska;
        public Kalkulator()
        {
            this.On();
        }
        public void Press(char inPressedDigit)
        {
            if (VrstaOperanda(inPressedDigit).Equals("On"))
                this.On();
            if (inPressedDigit == 'C')
                this.Clear();
            if (!jeGreska)
            {
                if (VrstaOperanda(inPressedDigit).Equals("Znamenka"))
                {
                    if (stanje == 1)
                        stanje = 2;
                    if (stanje != 2 && stanje != 1)
                        stanje = 1;
                    DodajZnamenku(inPressedDigit);
                }
                if (VrstaOperanda(inPressedDigit).Equals("UnarniOperator"))
                {
                    stanje = 0;
                    UnarnoOperiraj(inPressedDigit);
                }
                if (VrstaOperanda(inPressedDigit).Equals("BinarniOperator"))
                {
                    if (stanje == 4)
                        bop = inPressedDigit;
                    else
                    {
                        stanje = 4;
                        BinarnoOperiraj(inPressedDigit);
                    }
                }
                if (VrstaOperanda(inPressedDigit).Equals("UnarniSNastavkom"))
                {
                    if (inPressedDigit == 'P')
                        memorija = tren;
                    else UnarnoNastavakOper(inPressedDigit);
                }
                if (VrstaOperanda(inPressedDigit).Equals("Jednako"))
                {
                    stanje = 0;
                    BinarnoOperiraj(inPressedDigit);
                }

            }
            /*if (VrstaOperanda(inPressedDigit).Equals("Znamenka"))
                DodajZnamenku(inPressedDigit);            
            if (VrstaOperanda(inPressedDigit).Equals("BinarniOperator"))
                BinarnoOperiraj(inPressedDigit);*/
        }
        private void DodajZnamenku(char znamenka)
        {
            if (stanje == 1)
            {
                if (znamenka == ',')
                    ekran = "0,";
                else ekran = znamenka.ToString();
                tren = Double.Parse(ekran);
                stanje = 2;
            }
            else
            {
                if (tren != 0 || znamenka != '0')
                {
                    int a = 0;
                    if (ekran.Contains(",")) a++;
                    if (ekran.Contains('-')) a++;
                    if (!ekran.Contains(",") && znamenka == ',')
                        ekran += znamenka;
                    else if ((ekran.Length - a < 10) && znamenka != ',')
                        ekran += znamenka;
                    tren = Double.Parse(ekran);
                }
            }
        }
        private void UnarnoOperiraj(char _operator)
        {
            if (_operator == 'S')
                tren = Math.Sin(tren);
            if (_operator == 'K')
                tren = Math.Cos(tren);
            if (_operator == 'T')
                tren = Math.Tan(tren);
            if (_operator == 'Q')
                tren = tren * tren;
            if (_operator == 'I')
            {
                if (tren == 0)
                    jeGreska = true;
                else tren = 1/tren;
            }
            if (_operator == 'R')
            {
                if (tren < 0)
                    jeGreska = true;
                else tren = Math.Sqrt(tren);
            }
            if (_operator == 'G')
                tren = memorija;
            visakZnamenaka();
            izracunajEkran();
        }
        private void UnarnoNastavakOper(char _operator)
        {
            if (_operator == 'M')
            {
                if (stanje != 1 && stanje != 2)
                {
                    tren = tren * (-1);
                    izracunajEkran();
                }
                else
                {
                    if (ekran.StartsWith("-"))
                        ekran = ekran.Substring(1);
                    if (tren > 0)
                        ekran = "-" + ekran;
                    tren = Double.Parse(ekran);
                }
            }
        }
        private bool visakZnamenaka()
        {
            if (tren >= 1000000000 || tren <= -1000000000)
                jeGreska = true;
            return jeGreska;
        }
        private void BinarnoOperiraj(char _operator)
        {
            if (bop == '+')
                tren += ans;
            if (bop == '-')
                tren = ans - tren;
            if (bop == '*')
                tren *= ans;
            if (bop == '/')
            {
                if (tren != 0)
                    tren = ans / tren;
                else jeGreska = true;
            }
            visakZnamenaka();
            if (!jeGreska)
            {
                ans = tren;
                if (_operator == '=')
                {
                    ans = 0;
                    bop = '+';
                }
                else
                    bop = _operator;
            }
            izracunajEkran();   
        }
        private string VrstaOperanda(char tipkaUnosa)
        {
            VrstaOperanda vrstaOperanda = new VrstaOperanda(tipkaUnosa);
            return vrstaOperanda.GetVrstaOperanda();
        }

        public string GetCurrentDisplayState()
        {
            //Double i=942765.669;
            //Char a='7';
            //int b;
            //b = (int) a;
            return ekran;
        }
        private void On()
        {
            tren=ans=memorija = 0;
            stanje = 0;
            jeGreska = false;
            izracunajEkran();
        }
        private void Clear()
        {
            jeGreska = false;
            stanje = 0;
            tren = 0;
            izracunajEkran();
        }
        private void izracunajEkran()
        {
            if (jeGreska)
                ekran = "-E-";
            else
            {
                int brojCijelih=(int) (Math.Truncate(Math.Log10(Math.Abs(tren))));
                if (brojCijelih<1) brojCijelih=1;
                tren = Math.Round(tren, 10 - brojCijelih);
                ekran = tren.ToString();
            }
        }
    }
    public class VrstaOperanda
    {
        private string vrstaOperanda;
        public VrstaOperanda(char tipka)
        {
            if ((tipka >='0' && tipka <='9')||tipka==',')
                vrstaOperanda="Znamenka";
            else if(tipka=='+'||tipka=='-'||tipka=='*'||tipka=='/')
                vrstaOperanda="BinarniOperator";
            else if(tipka=='S'||tipka=='K'||tipka=='T'||tipka=='R'||tipka=='Q'||tipka=='I'||tipka=='C'||tipka=='G')
                vrstaOperanda="UnarniOperator";
            else if(tipka=='=')
                vrstaOperanda="Jednako";
            else if(tipka=='M'||tipka=='P'/*||tipka==','*/)
                vrstaOperanda="UnarniSNastavkom";
            else if(tipka=='O')
                vrstaOperanda="On";
            else vrstaOperanda="Gresaka";
        }
        public string GetVrstaOperanda()
        {
            return this.vrstaOperanda;
        }
    }


}
