﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Dionica
    {
        public string Naziv;
        public Decimal ZadnjaCijena;
        public DateTime DatumNastanka;
        public long BrojDionica;
        public List<KeyValuePair<DateTime, decimal>> PovijestCijena = new List<KeyValuePair<DateTime, decimal>>();

        // Konstruktori
        public Dionica(string naziv, Decimal zadnjaCijena, DateTime datumNastanka, long brojDionica)
        {
            Naziv = naziv;
            BrojDionica = brojDionica;
            DodajNovuCijenu(datumNastanka, zadnjaCijena);
        }
        public Dionica()
        {
        }

        // Metoda za sortiranje liste PovijestCijena po datumu uzlazno
        static int PoredajKronoloski(KeyValuePair<DateTime, decimal> a, KeyValuePair<DateTime, decimal> b)
        {
            return a.Key.CompareTo(b.Key);
        }

        // Unos nove cijene za odredeni datum; postavljanje aktualnog datuma i cijene
        public void DodajNovuCijenu(DateTime datum, Decimal novaCijena)
        {
            if (novaCijena <= 0 || PovijestCijena.Any(k => k.Key == datum))
                throw new StockExchangeException("");

            PovijestCijena.Add(new KeyValuePair<DateTime, decimal>(datum, novaCijena));
            PovijestCijena.Sort(PoredajKronoloski);

            ZadnjaCijena = PovijestCijena.Last().Value;
            DatumNastanka = PovijestCijena.Last().Key;
        }

        // Vraca cijenu za zadnji datum u povijesti cijena koji je manji ili jednak od trazenog datuma
        public decimal NadiCijenuZaDatum(DateTime datum)
        {
            decimal cijena = 0;
            foreach (var v in PovijestCijena.Where(v => v.Key <= datum))
                cijena = v.Value;

            if (cijena == 0) throw new StockExchangeException("Nema takve cijene");
            return cijena;
        }
    }

    public class Indeks
    {
        public string Naziv;
        public IndexTypes Tip;
        public Dictionary<string, Dionica> DioniceUIndeksu = new Dictionary<string, Dionica>();

        // Konstruktor; tip mora biti iz definiranog enuma
        public Indeks(string naziv, IndexTypes tip)
        {
            if (!Enum.IsDefined(typeof(IndexTypes), tip))
                throw new StockExchangeException("Krivi tip indeksa");
            Naziv = naziv;
            Tip = tip;
        }

        // Dodavanje i brisanje dionica iz indeksa
        public void DodajDionicu(Dionica dionica)
        {
            // Ne smije se dodati ista dionica
            if (DioniceUIndeksu.ContainsKey(dionica.Naziv.ToUpper()))
                throw new StockExchangeException("Vec postoji ista dionica");

            DioniceUIndeksu.Add(dionica.Naziv.ToUpper(), dionica);
        }
        public void MakniDionicu(string imeDionice)
        {
            if (!DioniceUIndeksu.ContainsKey(imeDionice.ToUpper()))
                throw new StockExchangeException("nepostojeca dionica u indeksu");
            DioniceUIndeksu.Remove(imeDionice.ToUpper());
        }

        // Izracun vrijednosti indeksa (ovisno o tipu) za odredeni datum
        public decimal IzracunajVrijednost(DateTime datum, Dictionary<string, Dionica> popisDionica)
        {
            decimal vrijednost = 0, ukupnaVrijednost = 0;
            long ukupanBroj = 0, brojGresaka = 0;

            switch (Tip)
            {
                // Izracun vrijednosti za odredeni datum i tip indeksa "Average"
                case IndexTypes.AVERAGE:
                    foreach (var d in DioniceUIndeksu)
                    {
                        try
                        {
                            vrijednost += popisDionica[d.Key].NadiCijenuZaDatum(datum);
                        }
                        catch (StockExchangeException)
                        {
                            // Broji greske za dionicu koja ne vrijedi za zadani datum
                            brojGresaka++;
                        }
                    }

                    //if(vrijednost == 0)
                    //    throw new StockExchangeException("");

                    // Ako za neki datum ne vrijedi neki broj dionica,onda se taj broj oduzima od ukupnog broja dionica
                    // U slucaju dijeljenja s nulom, vrati 0
                    try
                    {
                        return decimal.Round(vrijednost / (DioniceUIndeksu.Count - brojGresaka), 3);
                    }
                    catch (Exception)
                    {
                        return 0;
                    }


                // Izracun vrijednosti za odredeni datum i tip indeksa "Weighted"
                case IndexTypes.WEIGHTED:
                    // Trazenje ukupne vrijednosti dionica; varijabla za kasniji izracun
                    foreach (var d in DioniceUIndeksu.Where(d => d.Value.PovijestCijena.Last().Key <= datum))
                    {
                        ukupnaVrijednost += d.Value.BrojDionica * d.Value.NadiCijenuZaDatum(datum);
                    }
                    // Izracun tezinskih faktora svake dionice i pribrajanje tezinske vrijednosti dionice
                    foreach (var d in DioniceUIndeksu.Where(d => d.Value.PovijestCijena.Last().Key <= datum))
                    {
                        var tezinskiFaktor = (decimal)(d.Value.BrojDionica * d.Value.NadiCijenuZaDatum(datum)) / ukupnaVrijednost;
                        vrijednost += d.Value.NadiCijenuZaDatum(datum) * tezinskiFaktor;
                    }

                    //if(vrijednost == 0)
                    //    throw new StockExchangeException("");

                    return decimal.Round(vrijednost, 3);
                default:
                    return 0;
            }
        }
    }

    public class Portfelj
    {
        public string PortfeljID;
        public Dictionary<string, Dionica> DionicePortfelj = new Dictionary<string, Dionica>();

        // Konstruktor
        public Portfelj(string id)
        {
            PortfeljID = id;
        }

        // Dodavanje i brisanje dionica iz portfelja
        public void DodajDionicu(Dionica dionica)
        {
            DionicePortfelj.Add(dionica.Naziv.ToUpper(), dionica);
        }
        public void MakniDionicu(string imeDionice)
        {
            try
            {
                DionicePortfelj.Remove(imeDionice.ToUpper());
            }
            catch (Exception)
            {
                throw new StockExchangeException("nepostojeca dionica u indeksu");
            }
        }

        // Izracun umnoska cijene i broj dionica za sve dionice u portfelju
        public decimal IzracunajVrijednost(DateTime datum, Dictionary<string, Dionica> popisDionica)
        {
            try
            {
                return DionicePortfelj.Sum(dp => popisDionica[dp.Key].NadiCijenuZaDatum(datum) * dp.Value.BrojDionica);
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }
    }

    public class StockExchange : IStockExchange
    {
        public Dictionary<string, Dionica> DioniceBurza = new Dictionary<string, Dionica>();
        public Dictionary<string, Indeks> IndeksiBurza = new Dictionary<string, Indeks>();
        public Dictionary<string, Portfelj> PortfeljiBurza = new Dictionary<string, Portfelj>();
        public Dictionary<string, long> BrojDionicaUPortfeljima = new Dictionary<string, long>();


        #region Metode za rad s dionicama

        // Dodaje dionicu na burzu (uvrstavanjem na popis svih dionica)
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (!StockExists(inStockName) && inNumberOfShares > 0 && inInitialPrice > 0)
                DioniceBurza.Add(inStockName.ToUpper(),
                                 new Dionica(inStockName, inInitialPrice, inTimeStamp, inNumberOfShares));
            else
                throw new StockExchangeException("Neipravan unos dionice");
        }

        // Brise dionicu s burze (micanjem s popisa svih dionica)
        public void DelistStock(string inStockName)
        {
            string imeDionice = inStockName.ToUpper();
            if (!DioniceBurza.Remove(imeDionice))
            {
                throw new StockExchangeException("greska");
            }
            // Ako se obrise dionica s burze, brise se i iz indeksa i portfelja
            foreach (var indeks in IndeksiBurza.Where(indeks => indeks.Value.DioniceUIndeksu.Any(dionica => dionica.Key == imeDionice)))
                indeks.Value.DioniceUIndeksu.Remove(imeDionice);

            foreach (var portfelj in PortfeljiBurza.Where(portfelj => portfelj.Value.DionicePortfelj.Any(dionica => dionica.Key == imeDionice)))
                portfelj.Value.DionicePortfelj.Remove(imeDionice);
        }

        // Vraca true ako pronadje trazenu dionicu medju popisom svih dionicana burzi
        public bool StockExists(string inStockName)
        {
            return DioniceBurza.ContainsKey(inStockName.ToUpper());
        }

        // Prebrojava sve dionice na burzi
        public int NumberOfStocks()
        {
            return DioniceBurza.Count();
        }

        // Postavlja novu cijenu dionice; baca iznimku ako nema trazene dionice
        public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
        {
            try
            {
                DioniceBurza[inStockName.ToUpper()].DodajNovuCijenu(inTimeStamp, inStockValue);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Nema takve dionice");
            }
        }

        // Dohvaca cijenu dionice; baca iznimku ako nema trazene dionice
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            try
            {
                return DioniceBurza[inStockName.ToUpper()].NadiCijenuZaDatum(inTimeStamp);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Nema takve dionice");
            }
        }

        // Dohvaca pocetnu, najraniju cijenu dionice; baca iznimku ako nema trazene dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            try
            {
                return DioniceBurza[inStockName.ToUpper()].PovijestCijena.First().Value;
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        // Dohvaca aktualnu, posljednju cijenu dionice; baca iznimku ako nema trazene dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            try
            {
                return DioniceBurza[inStockName.ToUpper()].PovijestCijena.Last().Value;
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        #endregion

        #region Metode za rad s indeksima

        // Stvaranje novog indeksa postavljanjem imena i tipa indeksa (average ili weighted)
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            // Ako se pokusa dodati indeks imena koje vec postoji na burzi, baca se iznimka
            if (!IndexExists(inIndexName))
                IndeksiBurza.Add(inIndexName.ToUpper(), new Indeks(inIndexName, inIndexType));
            else
                throw new StockExchangeException("Vec postoji takav indeks");
        }

        // Dodavanje nove dionice u indeks; u slucaju greske ili postojece dionice, baca se iznimka
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            try
            {
                IndeksiBurza[inIndexName.ToUpper()].DodajDionicu(DioniceBurza[inStockName.ToUpper()]);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Greska");
            }
        }

        // Brisanje dionice iz indeksa; baca se iznimka ako je argument nepostojeci indeks ili dionica
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            try
            {
                IndeksiBurza[inIndexName.ToUpper()].MakniDionicu(inStockName);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Greska");
            }
        }

        // Pretragom liste dionica u indeksu vraca se true ako je nadjena trazena dionica, inace false
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            try
            {
                return IndeksiBurza[inIndexName.ToUpper()].DioniceUIndeksu.ContainsKey(inStockName.ToUpper());
            }
            catch (Exception)
            {
                throw new StockExchangeException("Greska");
            }
        }

        // Indeks sam izracunava svoju vrijednost, bez obzira o kojem se tipu radi
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            try
            {
                return IndeksiBurza[inIndexName.ToUpper()].IzracunajVrijednost(inTimeStamp, DioniceBurza);
            }
            catch (Exception)
            {
                throw new StockExchangeException("Greska");
            }
        }

        // Vraca true ako pronadje indeks na popisu indeksa na burzi, inace false 
        public bool IndexExists(string inIndexName)
        {
            return IndeksiBurza.ContainsKey(inIndexName.ToUpper());
        }

        // Prebrojava sve indekse na burzi (u listi svih indeksa)
        public int NumberOfIndices()
        {
            return IndeksiBurza.Count();
        }

        // Za trazeni indeks vraca broj dionica koje mu pripadaju
        public int NumberOfStocksInIndex(string inIndexName)
        {
            try
            {
                return IndeksiBurza[inIndexName.ToUpper()].DioniceUIndeksu.Count;
            }
            catch (Exception)
            {
                throw new StockExchangeException("Greska");
            }
        }

        #endregion

        #region Metode za rad s portfeljima

        // Stvara se novi portfelj sa zadanim ID-em i dodaje na listu svih portfelja na burzi
        public void CreatePortfolio(string inPortfolioID)
        {
            // Ako vec postoji portfelj s istim ID-em, baca se iznimka
            if (!PortfolioExists(inPortfolioID))
                PortfeljiBurza.Add(inPortfolioID, new Portfelj(inPortfolioID));
            else
                throw new StockExchangeException("er");
        }

        // Dodavanje dionice (odredenog broja dionica) u portfelj
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            // Mora se dodati neki broj dionica
            if(numberOfShares <= 0)
                throw new StockExchangeException("greska");

            string imeDionice = inStockName.ToUpper();
            try
            {
                // Ne moze se dodati vise dionica nego sto ih ima na raspolaganju
                if (numberOfShares > DioniceBurza[imeDionice].BrojDionica)
                    throw new StockExchangeException("");

                // Ako dionica nije dio portfelja, treba napraviti novi zapis i dodati ga
                if (!IsStockPartOfPortfolio(inPortfolioID, inStockName))
                {
                    var dionica = new Dionica();
                    dionica.Naziv = DioniceBurza[imeDionice].Naziv;
                    dionica.BrojDionica += numberOfShares;
                    dionica.DatumNastanka = DioniceBurza[imeDionice].DatumNastanka;
                    dionica.ZadnjaCijena = DioniceBurza[imeDionice].ZadnjaCijena;
                    foreach (var c in DioniceBurza[imeDionice].PovijestCijena)
                        dionica.PovijestCijena.Add(c);
                    PortfeljiBurza[inPortfolioID].DodajDionicu(dionica);

                    if (!BrojDionicaUPortfeljima.ContainsKey(imeDionice))
                        BrojDionicaUPortfeljima.Add(imeDionice, numberOfShares);
                    else
                        BrojDionicaUPortfeljima[imeDionice] += numberOfShares;
                }
                else
                {
                    // Dodaj zadani broj dionica u postojecu dionicu, ako je taj broj dozvoljen
                    if (numberOfShares <= DioniceBurza[imeDionice].BrojDionica -
                        BrojDionicaUPortfeljima[imeDionice])
                    {
                        PortfeljiBurza[inPortfolioID].DionicePortfelj[imeDionice].BrojDionica += numberOfShares;
                        BrojDionicaUPortfeljima[imeDionice] += numberOfShares;
                    }
                    else
                        throw new StockExchangeException("err");
                }
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        // Brisanje odredenog broja dionica iz portfelja; ako taj broj padne na 0, brisi cijeli zapis o dionici
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            string imeDionice = inStockName.ToUpper();
            try
            {
                BrojDionicaUPortfeljima[imeDionice] -= numberOfShares;
                if (BrojDionicaUPortfeljima[imeDionice] <= 0)
                    BrojDionicaUPortfeljima.Remove(imeDionice);

                PortfeljiBurza[inPortfolioID].DionicePortfelj[imeDionice].BrojDionica -= numberOfShares;
                if (PortfeljiBurza[inPortfolioID].DionicePortfelj[imeDionice].BrojDionica <= 0)
                    PortfeljiBurza[inPortfolioID].DionicePortfelj.Remove(imeDionice);
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }

        }

        // Obrisi citavu dionicu iz portfelja
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            string imeDionice = inStockName.ToUpper();
            try
            {
                // Oduzimanje broja obrisanih dionica iz evidencije o broju dionica u svim portfeljima
                BrojDionicaUPortfeljima[imeDionice] -=
                    PortfeljiBurza[inPortfolioID].DionicePortfelj[imeDionice].BrojDionica;
                if (BrojDionicaUPortfeljima[imeDionice] == 0)
                    BrojDionicaUPortfeljima.Remove(imeDionice);

                PortfeljiBurza[inPortfolioID].DionicePortfelj.Remove(imeDionice);
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        // Vraca broj portfelja na burzi
        public int NumberOfPortfolios()
        {
            return PortfeljiBurza.Count;
        }

        // Prebrojava sve dionice u trazenom portfelju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            try
            {
                return PortfeljiBurza[inPortfolioID].DionicePortfelj.Count;
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        // Provjerava postoji li portfelj s trazenim ID-om
        public bool PortfolioExists(string inPortfolioID)
        {
            return PortfeljiBurza.ContainsKey(inPortfolioID);
        }

        // Provjerava je li dionica dio portfelja
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                if(!StockExists(inStockName.ToUpper()))
                    throw new Exception();
                return PortfeljiBurza[inPortfolioID].DionicePortfelj.ContainsKey(inStockName.ToUpper());
            }
            catch (Exception)
            {
                throw new StockExchangeException("err");
            }
        }

        // Vraca broj dionica pojedine dionice u portfelju
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            try
            {
                return (int)PortfeljiBurza[inPortfolioID].DionicePortfelj[inStockName.ToUpper()].BrojDionica;
            }
            catch (Exception)
            {
                if (!PortfolioExists(inPortfolioID))
                    throw new StockExchangeException("Nema portfelja takovog");
                return 0;
            }
        }

        // Vraca zbroj vrijednosti svih dionica u portfelju (broj dionica * cijena dionice)
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            if (PortfolioExists(inPortfolioID))
                return PortfeljiBurza[inPortfolioID].IzracunajVrijednost(timeStamp, DioniceBurza);
            throw new StockExchangeException("err");
        }

        // Vraca postotak promjene vrijednosti portfelja na pocetku i na kraju mjeseca
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            DateTime pocetakMjeseca = new DateTime(Year, Month, 1);
            DateTime krajMjeseca = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

            try
            {
                Portfelj portfelj = PortfeljiBurza[inPortfolioID];
                decimal mjesecnaPromjena = (portfelj.IzracunajVrijednost(krajMjeseca, DioniceBurza) -
                                            portfelj.IzracunajVrijednost(pocetakMjeseca, DioniceBurza)) /
                                           portfelj.IzracunajVrijednost(pocetakMjeseca, DioniceBurza);
                return mjesecnaPromjena * 100;
            }
            catch (Exception ex)
            {
                if (!PortfolioExists(inPortfolioID))
                    throw new StockExchangeException("");
                if (PortfeljiBurza[inPortfolioID].DionicePortfelj.Count == 0)
                    return 0;
                throw new StockExchangeException("");
            }
        }

        #endregion
    }
}
