﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PrvaDomacaZadaca_Kalkulator
{
    using Function = Action;
    using UnaryOperator = Func<double, double>;
    using BinaryOperator = Func<double, double, double>;

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        public void Press(char inPressedDigit)
        {
            if (char.IsDigit(inPressedDigit))
            {
                AddDigitToDisplay(inPressedDigit);
            }
            else if (Functions.ContainsKey(inPressedDigit))
            {
                Functions[inPressedDigit]();
            }
            else if (UnaryOperators.ContainsKey(inPressedDigit))
            {
                CurrentNumber = UnaryOperators[inPressedDigit](CurrentNumber);
                ClearDisplayOnNextDigit = true;
            }
            else if (BinaryOperators.ContainsKey(inPressedDigit))
            {
                LastOperand = CurrentNumber;

                // izvrsi posljednju binarnu operaciju, ako takva postoji
                if (LastBinaryOperation != null && !IsBinaryOperationSet)
                {
                    // ako je IsBinaryOperationSet jednako true, vise binarnih operatora je  
                    // uzastupno pritisnuto - svi takvi operatori, osim zadnjeg, se zanemaruju
                    double secondNumber = CurrentNumber;
                    double firstNumber = Operands.Pop();
                    double result = LastBinaryOperation(firstNumber, secondNumber);
                    Operands.Push(result);
                    CurrentNumber = result;
                }
                else
                {
                    Operands.Push(CurrentNumber);
                }

                // spremi trenutnu binarnu operaciju
                LastBinaryOperation = BinaryOperators[inPressedDigit];
                // osvjezi trenutni broj (obrisi decimalne nule viska)
                CurrentNumber = CurrentNumber;
                ClearDisplayOnNextDigit = true;
                IsBinaryOperationSet = true;
            }
            else
            {
                CurrentNumber = double.NaN;
                ClearDisplayOnNextDigit = true;
            }
        }

        public string GetCurrentDisplayState()
        {
            return CurrentDisplay;
        }

        public Kalkulator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("hr-HR");
            CurrentNumber = 0.0;
            Operands = new Stack<double>();

            UnaryOperators = new Dictionary<char, UnaryOperator>
            {
                { 'S', x => Math.Sin(x) },
                { 'K', x => Math.Cos(x) },
                { 'T', x => Math.Tan(x) },
                { 'Q', x => x * x },
                { 'R', x => Math.Sqrt(x) },
                { 'I', x => 1.0 / x }
            };
            BinaryOperators = new Dictionary<char, BinaryOperator>
            {
                { '+', (x, y) => x + y },
                { '-', (x, y) => x - y },
                { '*', (x, y) => x * y },
                { '/', (x, y) => x / y },
            };
            Functions = new Dictionary<char, Function>
            {
                { '=', () => 
                    {
                        // osvjezi trenutni broj (obrisi decimalne nule viska)
                        CurrentNumber = CurrentNumber;

                        if (LastBinaryOperation != null) // izvrsi zadnju operaciju
                        {
                            // firstNumber je rezultat prethodne operacije ili prvi parametar trenutne binarne operacije
                            double firstNumber = IsBinaryOperationSet ? CurrentNumber : Operands.Pop();
                            // secondNumber je drugi parametar posljednje binarne operacije spremljen u LastOperand
                            // (ili firstNumber ako on nije jos unesen) ili trenutno prikazani broj
                            double secondNumber = IsBinaryOperationSet ? LastOperand ?? firstNumber : CurrentNumber;

                            double result = LastBinaryOperation(firstNumber, secondNumber);
                            CurrentNumber = result;
                            LastOperand = secondNumber;
                            ClearDisplayOnNextDigit = true;
                        }
                    }
                },
                { 'M', () => CurrentNumber = -CurrentNumber },
                { ',', () => AddDigitToDisplay(',') },
                { 'P', () => Memory = CurrentNumber },
                { 'G', () => CurrentNumber = Memory ?? CurrentNumber },
                { 'C', () => CurrentNumber = 0.0 },
                { 'O', () => {
                        Operands.Clear();
                        LastBinaryOperation = null;
                        Memory = null;
                        CurrentNumber = 0.0;
                    }
                }
            };
        }

        /// <summary>
        /// Dodaje novi znak na ekran.
        /// </summary>
        /// <param name="value">
        /// Novi znak.
        /// </param>
        /// <remarks>
        /// Ako bi dodavanjem novog znaka ogranicenje na najveci dopusteni
        /// broj znakova postalo nezadovoljeno funkcija ne dodaje novi znak.
        /// </remarks>
        public void AddDigitToDisplay(char value)
        {
            // Nakon binarne operacije u CurrentDisplay ostaje pohranjen
            // rezultat te operacije. Pritiskom na neku znamenku ekran se
            // postavlja na default vrijednost i vraca u normalno stanje.
            if (ClearDisplayOnNextDigit)
            {
                CurrentDisplay = "0";
                ClearDisplayOnNextDigit = false;
            }

            IsBinaryOperationSet = false;

            bool currentDisplayHasDecimalPoint = value == ',' && CurrentDisplay.Contains(',');
            if (!currentDisplayHasDecimalPoint)
            {
                if (CurrentDisplay == "0" && value != ',')
                {
                    CurrentDisplay = "";
                }

                int digitsCount = CurrentDisplay.Count(c => char.IsDigit(c));
                if (digitsCount < MaxNumberOfDigits)
                {
                    CurrentDisplay += value;
                }
            }
        }

        /// <summary>
        /// Stog s operandima.
        /// </summary>
        public Stack<double> Operands { get; protected set; }

        /// <summary>
        /// Drugi operand posljednje binarne operacije.
        /// </summary>
        public double? LastOperand { get; protected set; }

        /// <summary>
        /// Posljednja binarna operacija.
        /// </summary>
        public BinaryOperator LastBinaryOperation { get; protected set; }

        /// <summary>
        /// Postavlja se kod prikaza rezultata neke operacije da bi se
        /// onemogucilo dodavanje novih znamenaka prikazanom rezultatu, 
        /// odnosno da bi se DisplayState postavio na nulu pritiskom
        /// na prvu sljedecu znamenku.
        /// </summary>
        public bool ClearDisplayOnNextDigit { get; protected set; }

        /// <summary>
        /// Postavlja se prilikom pritiska na binarnu operaciju kako
        /// bi se moguce uzastopne binarne operacije zanemarile
        /// (samo se zadnja operacija u nizu treba izvrsiti).
        /// </summary>
        public bool IsBinaryOperationSet { get; protected set; }

        /// <summary>
        /// Dohvaca i sprema trenutni broj.
        /// </summary>
        /// <remarks>
        /// Trenutni broj se ne pohranjuje u decimalnom obliku vec samo kao
        /// niz znakova prikazanih na ekranu. Prilikom dohvacanja ili spremanja
        /// trenutnog broja navedeni niz znakova se svaki puta parsira u double.
        /// </remarks>
        public double CurrentNumber
        {
            get
            {
                double value;
                if (double.TryParse(CurrentDisplay, out value))
                {
                    return value;
                }
                else
                {
                    return double.NaN;
                }
            }
            protected set
            {
                double display = customRound(value);
                if (!double.IsInfinity(display) && !double.IsNaN(display))
                {
                    CurrentDisplay = display.ToString("0.#########");
                }
                else
                {
                    CurrentDisplay = ErrorDisplayState;
                }
            }
        }

        /// <summary>
        /// Trenutni znakovni prikaz na ekranu.
        /// </summary>
        public string CurrentDisplay { get; protected set; }

        /// <summary>
        /// Pohranjuje broj spremljen u memoriju kalkulatora.
        /// </summary>
        public double? Memory { get; protected set; }

        /// <summary>
        /// Funkcije unarnih operacija:
        ///     Sinus S
        ///     Kosinus K
        ///     Tangens T
        ///     Kvadriranje Q
        ///     Korjenovanje R
        ///     1/x I
        /// </summary>
        public IDictionary<char, UnaryOperator> UnaryOperators { get; protected set; }
        /// <summary>
        /// Funkcije binarnih operacija:
        ///     Plus +
        ///     Minus -
        ///     Puta *
        ///     Podijeljeno /
        /// </summary>
        public IDictionary<char, BinaryOperator> BinaryOperators { get; protected set; }
        /// <summary>
        /// Ostale funkcije kalkulatora:
        ///     Jednako =
        ///     Promjena predznaka M
        ///     Decimalni zarez ,
        ///     Spremanje u memoriju P
        ///     Dohvaćanje iz memorije G
        ///     Brisanje ekrana C
        ///     Resetiranje kalkulatora O
        /// </summary>
        public IDictionary<char, Function> Functions { get; protected set; }

        /// <summary>
        /// Prikaz na ekranu u slucaju aritmeticke pogreske.
        /// </summary>
        public const string ErrorDisplayState = "-E-";

        /// <summary>
        /// Najveci broj znamenaka koje se mogu prikazati na ekranu.
        /// </summary>
        public const int MaxNumberOfDigits = 10;

        /// <summary>
        /// Zaokruzuje proizvoljan decimalan broj na MaxNumberOfDigits znamenaka.
        /// </summary>
        /// <remarks>
        /// U slucaju da se cjelobrojni dio broja ne moze prikazati s navedenim
        /// ogranicenjem na broj znamenaka, vraca se beskonacno - double.Infinity.
        /// 
        /// Znak predznaka i decimalni zarez ne ulaze u ogranicenje MaxNumberOfDigits.
        /// </remarks>
        /// <param name="number">
        /// Broj koji se zaokruzuje.
        /// </param>
        /// <returns>
        /// Broj dobiven nakon zaokruzivanja.
        /// </returns>
        protected double customRound(double number)
        {
            if (double.IsInfinity(number) || double.IsNaN(number))
            {
                return number;
            }

            double roundedNumber;
            int digitsCount = Math.Abs(number) < 10.0 ? 1 :
                ((int)Math.Log10(Math.Abs(number)) + 1); // broj znamenaka cjelobrojnog dijela

            if (digitsCount <= MaxNumberOfDigits)
            {
                int availableDecimalDigits = MaxNumberOfDigits - digitsCount;
                roundedNumber = Math.Round(number, availableDecimalDigits, MidpointRounding.AwayFromZero);
            }
            else // broj je prevelik, vrati beskonacno
            {
                roundedNumber = double.PositiveInfinity;
            }

            return roundedNumber;
        }
    }
}