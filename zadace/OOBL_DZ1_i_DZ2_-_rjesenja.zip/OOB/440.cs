﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            Operations createOper = new Operations();
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {    
        private decimal num1 = 0;
        private decimal num2 = 0;
        private decimal result = 0;
        private char symbol;
        private string number = "0";
        private bool isFirst = true;
        private bool isDecimal = false;
        private bool operateFlag = false;

        public static Stack<decimal> Memory = new Stack<decimal>();

        public Kalkulator()
        {
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ",";

            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;
        }

        private void turnOffOn()
        {
            result = 0;
            num1 = 0;
            num2 = 0;
            number = "0";
            operateFlag = false;
            isFirst = true;
            isDecimal = false;
            Memory.Clear();
        }

        private void clearPressed()
        {
            result = 0;
            number = "0";
            isDecimal = false;
        }

        private void checkResult(string str)
        {
            int numDigits = 0;
            int numBefComma = 0;
            bool flag = false;
            
            foreach (char item in str)
            {
                if (Char.IsDigit(item))
                {
                    numDigits++;
                }

                if (item == ',') flag = true;

                if (Char.IsDigit(item) && !flag)
                {
                    numBefComma++;
                }
            }

            if (numDigits > 10 && !str.Contains(','))
            {
                throw new System.Exception("Too much digits");
            }
            else
            {             
                result = decimal.Round(result, (10-numBefComma));
            }
        }

        private string checkLenght(string str)
        {
            int lenght = str.Length;
            int numDigits = 0;
            int additionalSigns = 0;

            if (lenght < 10)
            {
                return str;
            }

            foreach (char item in str)
            {
                if (Char.IsDigit(item))
                {
                    numDigits++;
                }
                else
                {
                    additionalSigns++;
                }
            }

            if (numDigits > 10)
            {
                return str.Substring(0, (additionalSigns+10));
            }

            return str;
         
        }

        private void operatorPressed(char operatorSymbol)
        {
            num1 = result;
            num2 = result;

            if (isFirst) isFirst = false;

            operateFlag = true;
            symbol = operatorSymbol;
            number = "0";
        }
       
        private void calculate(char inPressed)
        {
            isDecimal = false;

            if (!Operations.dictOper.ContainsKey(symbol)) return;

            if (isFirst && inPressed != '=') return;

            if (operateFlag && inPressed != '=') return;

            result = (decimal) Operations.dictOper[symbol].DynamicInvoke(num1, num2);
            result = decimal.Round(result, 9);        
            checkResult(result.ToString());
            num1 = result;
            number = "0";
            
            isFirst = true;
            
        }

        private void calculateLetters(char inPressedDigit)
        {
            num2 = (decimal)Operations.dictLetters[inPressedDigit].DynamicInvoke(result);
            result = num2;
            checkResult(num2.ToString());          
        }

        public void Press(char inPressedDigit)
        {
            try
            {
                if (Char.IsDigit(inPressedDigit))
                {
                    if (number == "0" || operateFlag)
                    {
                        number = string.Empty;
                    }
                    number += inPressedDigit;
                    number = checkLenght(number);
                    result = decimal.Parse(number);
                    if (isFirst)
                    {
                        num1 = result;
                    }
                    else
                    {
                        num2 = result;
                    }
                    
                    operateFlag = false;
                }
                else if (inPressedDigit == ',')
                {
                    if (!isDecimal)
                    {
                        number += inPressedDigit;
                        isDecimal = true;  
                    }                                                  
                }
                else if (inPressedDigit == 'C')
                {
                    clearPressed();
                }
                else if (inPressedDigit == 'O')
                {
                    turnOffOn();
                }
                else if (inPressedDigit == '=')
                {
                    calculate(inPressedDigit);
                }
                else if (Char.IsLetter(inPressedDigit))
                {
                    calculateLetters(inPressedDigit);
                    number = result.ToString();
                }
                else
                {                 
                    calculate(inPressedDigit);
                    operatorPressed(inPressedDigit);                
                }

            }
            catch (Exception ex)
            {
                number = "-E-";
            }


        }

        public string GetCurrentDisplayState()
        {
            if (isDecimal)
            {
                number = number.Replace('.', ',');
                return number;
            }

            string ispis = result.ToString("0.#########");
            ispis = checkLenght(ispis);
            result = Decimal.Parse(ispis);
            ispis = ispis.Replace('.', ',');

            if (number == "-E-")
                return "-E-";

            return ispis;
        }

    }



    public class Operations
    {
        public static Dictionary<char, Delegate> dictOper;
        public static Dictionary<char, Delegate> dictLetters;

        public Operations()
        {   
            dictOper = new Dictionary<char, Delegate>();
            dictLetters = new Dictionary<char, Delegate>();

            dictOper.Add('+', new Func<decimal, decimal, decimal>(plusOper));
            dictOper.Add('-', new Func<decimal, decimal, decimal>(minusOper));
            dictOper.Add('*', new Func<decimal, decimal, decimal>(multipleOper));
            dictOper.Add('/', new Func<decimal, decimal, decimal>(divideOper));

            dictLetters.Add('Q', new Func<decimal, decimal>(squreOper));
            dictLetters.Add('S', new Func<decimal, decimal>(sinOper));
            dictLetters.Add('K', new Func<decimal, decimal>(cosOper));
            dictLetters.Add('T', new Func<decimal, decimal>(tanOper));
            dictLetters.Add('I', new Func<decimal, decimal>(inverseOper));
            dictLetters.Add('M', new Func<decimal, decimal>(chgSignOper));
            dictLetters.Add('P', new Func<decimal, decimal>(putMemOper));
            dictLetters.Add('G', new Func<decimal, decimal>(getMemOper));
            dictLetters.Add('R', new Func<decimal, decimal>(rootOper));
        }

        #region binOperators

        private decimal plusOper(decimal num1, decimal num2)
        {
            return num1 + num2;
        }

        private decimal minusOper(decimal num1, decimal num2)
        {
            return num1 - num2;
        }

        private decimal multipleOper(decimal num1, decimal num2)
        {
            return num1 * num2;
        }

        private decimal divideOper(decimal num1, decimal num2)
        {
            return num1 / num2;
        }

        #endregion

        #region letters

        private decimal squreOper(decimal num1)
        {
            return num1 * num1;
        }

        private decimal sinOper(decimal num1)
        {
            
            return (decimal) Math.Sin((double)num1);
        }

        private decimal cosOper(decimal num1)
        {
            return (decimal)Math.Cos((double)num1);
        }

        private decimal tanOper(decimal num1)
        {
            return (decimal)Math.Tan((double)num1);
        }

        private decimal inverseOper(decimal num1)
        {
            return 1m / num1;
        }

        private decimal chgSignOper(decimal num1)
        {
            return num1 * (-1m);
        }

        private decimal rootOper(decimal num1)
        {
            return (decimal) Math.Sqrt((double)num1);
        }

        private decimal putMemOper(decimal num1)
        {
            Kalkulator.Memory.Clear();
            Kalkulator.Memory.Push(num1);
            return num1;
        }

        private decimal getMemOper(decimal num1)
        {   
            return Kalkulator.Memory.Peek();
        }

        #endregion

    }

}
