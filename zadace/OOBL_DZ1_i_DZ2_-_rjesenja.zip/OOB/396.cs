﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class Stock
     {
         public long inNumberOfShares;
         public long numAvailableShares;
         Dictionary<DateTime, decimal> stockValues = new Dictionary<DateTime, decimal>();

         public Stock(long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inNumberOfShares < 1) throw new StockExchangeException("Number of shares must be positive");
             if (inInitialPrice <= 0) throw new StockExchangeException("Price must be positive");
             this.inNumberOfShares = inNumberOfShares;
             this.numAvailableShares = inNumberOfShares;
             stockValues.Add(inTimeStamp, inInitialPrice);
         }

         public void setPrice(DateTime inTimeStamp, decimal inStockValue) 
         {
             if (inStockValue <= 0) throw new StockExchangeException("Price must be positive");
             if (stockValues.ContainsKey(inTimeStamp)) throw new StockExchangeException("Duplicate time stamps not allowed");
             stockValues.Add(inTimeStamp, inStockValue);
         }

         public decimal getPrice(DateTime inTimeStamp)
         {
             DateTime latestDate = DateTime.MinValue;
             foreach (DateTime date in stockValues.Keys)
             {
                 if (date <= inTimeStamp && date > latestDate) latestDate = date;
             }
             if (!stockValues.ContainsKey(latestDate)) throw new StockExchangeException("Price is undefined for requested time");
             return stockValues[latestDate];
         }

         public decimal getLatestPrice()
         {
             DateTime latestDate = DateTime.MinValue;
             foreach (DateTime date in stockValues.Keys)
             {
                 if (date > latestDate) latestDate = date;
             }
             return stockValues[latestDate];
         }

         public decimal getInitialPrice()
         {
             DateTime initialDate = DateTime.MaxValue;
             foreach (DateTime date in stockValues.Keys)
             {
                 if (date < initialDate) initialDate = date;
             }
             return stockValues[initialDate];
         }
     }

     public abstract class Index
     {
         protected List<Stock> stocks = new List<Stock>();

         public abstract decimal getValue(DateTime inTimeStamp);

         public int numOfStocks()
         {
             return stocks.Count;
         }

         public void addStock(Stock inStock)
         {
             if (stocks.Contains(inStock)) throw new StockExchangeException("Index already contains stock");
             stocks.Add(inStock);
         }

         public void removeStock(Stock inStock)
         {
             if (!stocks.Contains(inStock)) throw new StockExchangeException("Index doesn't contain stock");
             stocks.Remove(inStock);
         }

         public void delistedStock(Stock stock)
         {
             if (stocks.Contains(stock)) stocks.Remove(stock);
         }
         public bool containsStock(Stock inStock)
         {
             return stocks.Contains(inStock);
         }
     }

     public class AvgIndex : Index
     {
         public override decimal getValue(DateTime inTimeStamp)
         {
             if (stocks.Count == 0) return 0;
             decimal value = 0;
             foreach (Stock stock in stocks)
             {
                 value += stock.getPrice(inTimeStamp);
             }
             value /= stocks.Count;
             return decimal.Round(value, 3);
         }
     }

     public class WgtIndex : Index
     {
         public override decimal getValue(DateTime inTimeStamp)
         {
             if (stocks.Count == 0) return 0;
             decimal totalValue = 0;
             decimal weightedAverage = 0;
             long totalSharesNum = 0;
             foreach (Stock stock in stocks)
             {
                 totalValue += stock.getPrice(inTimeStamp)*stock.inNumberOfShares;
                 weightedAverage += stock.getPrice(inTimeStamp) * stock.getPrice(inTimeStamp) * stock.inNumberOfShares;
                 totalSharesNum += stock.inNumberOfShares;
             }
             weightedAverage /= totalValue;
             return decimal.Round(weightedAverage, 3);
         }
     }

     public class Portfolio
     {
         Dictionary<Stock, int> sharesList = new Dictionary<Stock, int>();

         public void addShares(Stock stock, int numberOfShares)
         {
             if (stock.numAvailableShares < numberOfShares) throw new StockExchangeException("Not enough shares in stock");
             if (numberOfShares <= 0) throw new StockExchangeException("Number of shares must be positive");
             if (!sharesList.ContainsKey(stock)) sharesList.Add(stock, 0);
             sharesList[stock] += numberOfShares;
             stock.numAvailableShares -= numberOfShares;
         }

         public void removeShares(Stock stock, int numberOfShares)
         {
             if (!sharesList.ContainsKey(stock)) throw new StockExchangeException("Stock is not in portfolio");
             if (numberOfShares <= 0) throw new StockExchangeException("Number of shares must be positive");
             if (sharesList[stock] < numberOfShares) throw new StockExchangeException("Not enough shares in stock");
             sharesList[stock] -= numberOfShares;
             stock.numAvailableShares += numberOfShares;
             if (sharesList[stock] == 0) sharesList.Remove(stock);
         }

         public void removeStock(Stock stock)
         {
             if (!sharesList.ContainsKey(stock)) throw new StockExchangeException("Stock is not in portfolio");
             stock.numAvailableShares += sharesList[stock];
             sharesList.Remove(stock);
         }

         public void delistedStock(Stock stock)
         {
             if (sharesList.ContainsKey(stock)) sharesList.Remove(stock);
         }

         public int numOfStocks()
         {
             return sharesList.Count;
         }

         public bool containsStock(Stock stock)
         {
             return sharesList.ContainsKey(stock);
         }

         public int numOfSharesFromStock(Stock stock)
         {
             if (!sharesList.ContainsKey(stock)) return 0;
             else return sharesList[stock];
         }

         public decimal getValue(DateTime inTimeStamp)
         {
             decimal value = 0;
             foreach (Stock stock in sharesList.Keys)
             {
                 value += stock.getPrice(inTimeStamp) * sharesList[stock];
             }
             return value;
         }

         public decimal getPercentChange(int Year, int Month)
         {
             if(Month < 0 || Month > 12) throw new StockExchangeException("Illegal month");
             DateTime monthStart = new DateTime(Year, Month, 1, 0, 0, 0, 0);
             int lastDay;
             if (Month == 2 && Year % 4 == 0) lastDay = 29;
             else if (Month == 2) lastDay = 28;
             else if (Month < 8 && Month % 2 == 1 || Month > 7 && Month % 2 == 0) lastDay = 31;
             else lastDay = 30;
             DateTime monthEnd = new DateTime(Year, Month, lastDay, 23, 59, 59, 999);
             if (this.getValue(monthEnd) == this.getValue(monthStart)) return 0;
             if (this.getValue(monthStart) == 0) throw new StockExchangeException("Value undefined for beginning of month");
             decimal percentChange = (this.getValue(monthEnd) / this.getValue(monthStart) - 1) * 100;
             return decimal.Round(percentChange, 3);
         }
     }

     public class StockExchange : IStockExchange
     {

         Dictionary<string, Stock> stockList = new Dictionary<string, Stock>();
         Dictionary<string, Index> indexList = new Dictionary<string, Index>();
         Dictionary<string, Portfolio> portfolioList = new Dictionary<string, Portfolio>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (stockList.ContainsKey(inStockName)) throw new StockExchangeException("Same name already exists");
             stockList.Add(inStockName, new Stock(inNumberOfShares, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             foreach (Index index in indexList.Values) index.delistedStock(stockList[inStockName]);
             foreach (Portfolio portfolio in portfolioList.Values) portfolio.delistedStock(stockList[inStockName]);
             stockList.Remove(inStockName);
         }

         public bool StockExists(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (stockList.ContainsKey(inStockName)) return true;
             else return false;
         }

         public int NumberOfStocks()
         {
             return stockList.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inTimeStamp, decimal inStockValue)
         {
             inStockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             stockList[inStockName].setPrice(inTimeStamp, inStockValue);
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             inStockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return stockList[inStockName].getPrice(inTimeStamp);
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return stockList[inStockName].getInitialPrice();
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return stockList[inStockName].getLatestPrice();
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             inIndexName = inIndexName.ToUpper();
             if (indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Duplicate indices not allowed");
             if (inIndexType == IndexTypes.AVERAGE) indexList.Add(inIndexName, new AvgIndex());
             else if (inIndexType == IndexTypes.WEIGHTED) indexList.Add(inIndexName, new WgtIndex());
             else throw new StockExchangeException("Unrecognized index type");
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Index does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             indexList[inIndexName].addStock(stockList[inStockName]);
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Index does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             indexList[inIndexName].removeStock(stockList[inStockName]);
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             inIndexName = inIndexName.ToUpper();
             inStockName = inStockName.ToUpper();
             if (!indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Index does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return indexList[inIndexName].containsStock(stockList[inStockName]);
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             inIndexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Index does not exist");
             return indexList[inIndexName].getValue(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             return indexList.ContainsKey(inIndexName);
         }

         public int NumberOfIndices()
         {
             return indexList.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             inIndexName = inIndexName.ToUpper();
             if (!indexList.ContainsKey(inIndexName)) throw new StockExchangeException("Index does not exist");
             return indexList[inIndexName].numOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Duplicate portfolios not allowed");
             portfolioList.Add(inPortfolioID, new Portfolio());
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             portfolioList[inPortfolioID].addShares(stockList[inStockName], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             inStockName = inStockName.ToUpper();
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             portfolioList[inPortfolioID].removeShares(stockList[inStockName], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             portfolioList[inPortfolioID].removeStock(stockList[inStockName]);
         }

         public int NumberOfPortfolios()
         {
             return portfolioList.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             return portfolioList[inPortfolioID].numOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolioList.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return portfolioList[inPortfolioID].containsStock(stockList[inStockName]);
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             inStockName = inStockName.ToUpper();
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             if (!stockList.ContainsKey(inStockName)) throw new StockExchangeException("Stock does not exist");
             return portfolioList[inPortfolioID].numOfSharesFromStock(stockList[inStockName]);
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             return decimal.Round(portfolioList[inPortfolioID].getValue(timeStamp), 3);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if (!portfolioList.ContainsKey(inPortfolioID)) throw new StockExchangeException("Portfolio does not exist");
             return portfolioList[inPortfolioID].getPercentChange(Year, Month);
         }
     }
}
