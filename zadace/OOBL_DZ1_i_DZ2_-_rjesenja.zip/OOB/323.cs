﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new Burza();
        }
    }

    public class Burza : IStockExchange
    {
        private List<PovijestDionice> burzovnaPovijestDionica = new List<PovijestDionice>();
        private List<Indeks> burzovniIndeksi = new List<Indeks>();
        private List<Portfelj> burzovniPortfelji = new List<Portfelj>();

        /// <summary>
        /// Dodavanje dionice na burzu
        /// </summary>
        /// <param name="inStockName">Ime dionice koju dodajemo</param>
        /// <param name="inNumberOfShares">Broj udjela dionice za trgovanje na burzi</param>
        /// <param name="inInitialPrice">Cijena dionice</param>
        /// <param name="inTimeStamp">Datum od kojega vrijedi navedena cijena</param>
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            try
            {
                //Stvaramo novu dionicu zadanog imena i broja udjela dionice
                Dionica novaDionica = new Dionica(inStockName, inNumberOfShares);

                //Provjeravamo da li je navedena dionica već na burzi
                if (burzovnaPovijestDionica.Exists(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase)))
                {
                    throw new StockExchangeException("Dionica koju želite unijeti već se nalazi u listi dionica!");
                }

                //Ako dionica nije na burzi dodajemo je na burzu
                PovijestDionice povijest = new PovijestDionice(novaDionica, inInitialPrice, inTimeStamp);
                burzovnaPovijestDionica.Add(povijest);
            }
            catch(StockExchangeException)
            {
                throw;
            }
        }
        
        /// <summary>
        /// Brisanje dionice sa burze
        /// </summary>
        /// <param name="inStockName">Ime dionice koju želimo pobrisati</param>
        public void DelistStock(string inStockName)
        {
            //Najprije gledamo da li na burzi uopće postoje dionice
            if (burzovnaPovijestDionica != null)
            {
                //Pronalaziom dionicu koju želimo pobrisati
                PovijestDionice povijestZaIzbirisati = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));

                //Moguće da dionica ne postoji, tj. krivo je upisano ime dionice u tom slučaju vraćamo grešku
                if (povijestZaIzbirisati == null)
                {
                    throw new StockExchangeException("Unesena dionica ne postoji na burzi!");
                }
                //Inače brišemo dionicu sa burze
                else
                {
                    //Najprije pobrišemo dionicu iz svih indeksa
                    foreach (Indeks indeks in burzovniIndeksi)
                    {
                        if (indeks.DionicaUIndeksu.Contains(povijestZaIzbirisati.Dionica))
                        {
                            indeks.DionicaUIndeksu.Remove(povijestZaIzbirisati.Dionica);
                        }
                    }
                    //Zatim i iz portfelja
                    foreach (Portfelj portfelj in burzovniPortfelji)
                    {
                        Dionica dionicaZaIzbrisati = portfelj.DionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(povijestZaIzbirisati.Dionica.ImeDionice, StringComparison.OrdinalIgnoreCase));
                        if (dionicaZaIzbrisati != null)
                        {
                            portfelj.DionicePortfelja.Remove(dionicaZaIzbrisati);
                        }
                    }
                    //Konačno brišemo dionicu i sa burze
                    burzovnaPovijestDionica.Remove(povijestZaIzbirisati);
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji nitijedna dionica na burzi!");
            }
        }

        /// <summary>
        /// Provjeravamo da li postoji tražena dionica na burzi
        /// </summary>
        /// <param name="inStockName">Ime dionice za koju nas zanima da li postoji na burzi</param>
        /// <returns>Istina ako dionica postoji na burzi, neistina inače</returns>
        public bool StockExists(string inStockName)
        {
            //Ako postoji barem jedna dionica
            if (burzovnaPovijestDionica != null)
            {
                //Pregledaj da li postoji dionica traženog imena na burzi
                return burzovnaPovijestDionica.Exists(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            }

            return false;
        }

        /// <summary>
        /// Računa broj dionica na burzi
        /// </summary>
        /// <returns>Broj dionica na burzi</returns>
        public int NumberOfStocks()
        {
            //Ako burza uopće sadrži dionice
            if (burzovnaPovijestDionica != null)
            {
                //Vrati broj dionica
                return burzovnaPovijestDionica.Count;
            }
            //Inače vrati nula
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Postavlja cijenu dionice na zadani datum
        /// </summary>
        /// <param name="inStockName">Ime dionice kojoj mijenjamo cijenu</param>
        /// <param name="inIimeStamp">Vrijeme od kada cijena vrijedi</param>
        /// <param name="inStockValue">Vrijednost dionice od zadanog datuma</param>
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            //Pronađi dionicu zadanog imena
            PovijestDionice dodajCijenu = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            
            //Ako ona postoji
            if (dodajCijenu != null)
            {
                //Postavi cijenu dionice na zadani datum
                dodajCijenu.dodajVrijednost(inStockValue, inIimeStamp);
            }
            else
            {
                throw new StockExchangeException("Ne postoji zadana dionica!");
            }
        }

        /// <summary>
        /// Računa cijenu zadane dionice
        /// </summary>
        /// <param name="inStockName">Ime dionice čija nas cijena zanima</param>
        /// <param name="inTimeStamp">Datum na koji nas zanima cijena dionice</param>
        /// <returns>Cijenu dionice na zadani datum</returns>
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            //Pronađi dionicu
            PovijestDionice povijest = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            
            if (povijest != null)
            {
                //Izračunaj vrijednost dionice na zadani datum
                Decimal vrijednost = VrijednostDionicaZaDatum(povijest, inTimeStamp);

                return vrijednost;
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazena dionica!");
            }
        }

        /// <summary>
        /// Pronađi najstariju vrijednost dionice
        /// </summary>
        /// <param name="inStockName">Ime dionice čija nas cijena zanima</param>
        /// <returns>Najstariju zabilježenu cijenu dionice na burzi</returns>
        public decimal GetInitialStockPrice(string inStockName)
        {
            PovijestDionice povijest = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            
            //Ako se dionica nalazi na burzi
            if (povijest != null)
            {
                //Pronađi najstariji datum za koji je zabilježena cijena dionice
                DateTime prvaZabiljezenaVrijednost = povijest.PovijestVrijednosti.Min(datum => datum.OdKadaVrijediCijena);
                //Pronađi vrijednost dionice na pronađeni datum
                PovijestVrijednosti vrijednost = povijest.PovijestVrijednosti.Find(datum => datum.OdKadaVrijediCijena.Equals(prvaZabiljezenaVrijednost));
                return vrijednost.VrijednostDionice;
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazena dionica!");
            }
        }

        /// <summary>
        /// Pronađi posljednje postavljenu vrijednost dionice
        /// </summary>
        /// <param name="inStockName">Ime dionice</param>
        /// <returns>Vrijednost dionice na posljednji zabilježeni datum datum (moguće i u budućnosti)</returns>
        public decimal GetLastStockPrice(string inStockName)
        {
            PovijestDionice povijest = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            
            if (povijest != null)
            {
                //Pogledaj posljednji datum za koji je zabilježena cijena dionice
                DateTime prvaZabiljezenaVrijednost = povijest.PovijestVrijednosti.Max(datum => datum.OdKadaVrijediCijena);
                //Pronađi vrijednost dionice na pronađeni datum
                PovijestVrijednosti vrijednost = povijest.PovijestVrijednosti.Find(datum => datum.OdKadaVrijediCijena.Equals(prvaZabiljezenaVrijednost));
                return vrijednost.VrijednostDionice;
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazena dionica!");
            }
        }

        /// <summary>
        /// Stvara novi indeks na burzi
        /// </summary>
        /// <param name="inIndexName">Ime indeksa (mora biti jedinstveno)</param>
        /// <param name="inIndexType">Tip indeksa, zadani AVERAGE ili Weighted</param>
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            //Ako indeks već postoji na burzi vrati grešku
            if (burzovniIndeksi.Exists(indeks => indeks.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)))
            {
                throw new StockExchangeException("Indeks zadanog imena već postoji!");
            }
            //Ukoliko nije zadana ispravan tip indeksa vrati grešku
            if ((IndexTypes.AVERAGE != inIndexType) && (IndexTypes.WEIGHTED != inIndexType))
            {
                throw new StockExchangeException("Nije zadan ispravan tip indeksa!");
            }
            //Ako je novi indeks tipa AVERAGE stvori novi AverageIndeks i dodaj ga na burzu
            if (inIndexType == IndexTypes.AVERAGE)
            {
                AverageIndeks noviAverageIndeks = new AverageIndeks(inIndexName);
                burzovniIndeksi.Add(noviAverageIndeks);
            }
            //Ako je novi indeks tipa WEIGHTED stvori novi WeightedIndeks i dodaj ga na burzu
            else
            {
                WeightedIndeks noviWIndeks = new WeightedIndeks(inIndexName);
                burzovniIndeksi.Add(noviWIndeks);
            }
        }

        /// <summary>
        /// Dodaje dionicu indeksu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa kojemu želimo dodati dionicu</param>
        /// <param name="inStockName">Ime dionice koju dodajemo indeksu</param>
        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            if(burzovniIndeksi.Exists(indeks => indeks.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)))
            {
                Dionica dionica = burzovnaPovijestDionica.Find(dio => dio.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase)).Dionica;
                if (dionica != null)
                {
                    //Ako postoje indeks i dionica dodaj dionicu zadanom indeksu
                    burzovniIndeksi.Find(indeks => indeks.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)).DodajDionicu(dionica);
                }
                else
                {
                    throw new StockExchangeException("Unijeli ste nepostojeću dionicu!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji indeks zadanog imena!");
            }
        }

        /// <summary>
        /// Briše dionicu iz indeksa
        /// </summary>
        /// <param name="inIndexName">Ime indeksa iz kojeg želimo pobrisati dionicu</param>
        /// <param name="inStockName">Ime dionice koju želimo pobrisati iz indeksa</param>
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            if(burzovniIndeksi.Exists(indeks => indeks.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)))
            {
                Dionica dionica = burzovnaPovijestDionica.Find(dio => dio.Dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase)).Dionica;
                if (dionica != null)
                {
                    try
                    {
                        //Ako indeks sadrži dionicu, pobriši je
                        burzovniIndeksi.Find(ind => ind.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase)).IzbrisiDionicu(dionica);
                    }
                    catch (StockExchangeException)
                    {
                        throw;
                    }
                }
                else
                {
                    throw new StockExchangeException("Unijeli ste nepostojeću dionicu!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji indeks zadanog imena!");
            }
        }

        /// <summary>
        /// Postoji li dionica u indeksu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa za kojeg nas zanima sadrži li dionicu</param>
        /// <param name="inStockName">Ime dionice za koju nas zanima nalazi li se u ind.</param>
        /// <returns>Istinu ako dionica postoji, inače vraća neistina</returns>
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            if(burzovniIndeksi.Find(ind => ind.ImeIndeksa.Equals(inIndexName)).SadrziLiIndeksDionicu(inStockName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Izračunava vrijednost indeksa prema formuli ovisno o tipu indeksa
        /// </summary>
        /// <param name="inIndexName">Ime indeksa</param>
        /// <param name="inTimeStamp">Datum za koji nas zanima vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa na zadani datum</returns>
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Indeks indeks = burzovniIndeksi.Find(ind => ind.ImeIndeksa.Equals(inIndexName, StringComparison.OrdinalIgnoreCase));

            if (indeks != null)
            {
                //Dinamički izračunava vrijednost indeksa ovisno o tipu (auto. se odlučuje da li je WI ili AI)
                return indeks.IzracunajVrijednostIndeksa(burzovnaPovijestDionica, inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Ne postoji zadani indeks!");
            }
        }

        /// <summary>
        /// Postoji li indeks
        /// </summary>
        /// <param name="inIndexName">Ime indeksa</param>
        /// <returns>Istina ako indeks postoji, laž inače</returns>
        public bool IndexExists(string inIndexName)
        {
            if (burzovniIndeksi.Exists(indeks => indeks.ImeIndeksa.Equals(inIndexName)))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Računa broj indeksa na burzi
        /// </summary>
        /// <returns>Broj indeksa na burzi</returns>
        public int NumberOfIndices()
        {
            if (burzovniIndeksi != null)
            {
                return burzovniIndeksi.Count;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Računa broj udjela dionica u indeksu
        /// </summary>
        /// <param name="inIndexName">Ime indeksa</param>
        /// <returns>Broj dionica u indeksu</returns>
        public int NumberOfStocksInIndex(string inIndexName)
        {
            Indeks trazeniIndeks = burzovniIndeksi.Find(indeks => indeks.ImeIndeksa.Equals(inIndexName));
            if (trazeniIndeks != null)
            {
                return trazeniIndeks.dohvatiBrojDionicaUIndeksu();
            }
            else
            {
                throw new StockExchangeException("Ne postoji zadani indeks!");
            }
        }

        /// <summary>
        /// Stvara novi portfelj
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja (jedinstveno)</param>
        public void CreatePortfolio(string inPortfolioID)
        {
            if (burzovniPortfelji.Exists(portfelj => portfelj.PortfeljID.Equals(inPortfolioID)) || String.IsNullOrEmpty(inPortfolioID))
            {
                throw new StockExchangeException("Portfelj zadanog id-ja već postoji!");
            }
            else
            {
                Portfelj noviPortfelj = new Portfelj(inPortfolioID);
                burzovniPortfelji.Add(noviPortfelj);
            }
        }

        /// <summary>
        /// Dodaje dionicu portfelju
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="inStockName">Ime dionice</param>
        /// <param name="numberOfShares">Broj udjela dionice</param>
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            if (numberOfShares < 0)
            {
                throw new StockExchangeException("Broj dionica nemože biti manji od 0 prilikom daodavanja u portfelj!");
            }

            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
            
            if (trazeniPortfelj != null)
            {
                Dionica trazenaDionica = burzovnaPovijestDionica.Find(dionica => dionica.Dionica.ImeDionice.Equals(inStockName)).Dionica;
                long brojDionicaUportfeljima = 0;

                //Provjeri ukupan brij dionica u portfeljima on nesmije biti veći od ukupnog broja trežene dionice na burzi
                foreach (Portfelj portfelj in burzovniPortfelji)
                {
                    Dionica dionicaPortfelja = portfelj.DionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
                    if(dionicaPortfelja != null)
                    {
                        brojDionicaUportfeljima += dionicaPortfelja.BrojDionica;
                    }
                }

                //Ako je nakon dodavanja broja dionica u portfelj ukupan broj dionica u portfeljima manji do ukupnog broja udjela dionice na burzi
                if ((brojDionicaUportfeljima + numberOfShares) <= trazenaDionica.BrojDionica)
                {
                    //Dodaj dionicu u portfelj
                    trazeniPortfelj.DodajDionicu(inStockName, numberOfShares);
                }
                else
                {
                    throw new StockExchangeException("Portfelji sadrže više dionica nego što je raspoloživo na burzi!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji portfelj zadanog imena na burzi!");
            }
        }

        /// <summary>
        /// Briše zadani broj udjela dionice iz portfelja
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="inStockName">Ime dionice</param>
        /// <param name="numberOfShares">Broj udjela dionice</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));

            if (numberOfShares < 0 || trazeniPortfelj == null)
            {
                throw new StockExchangeException("Broj dionica za izbrisati iz portfelja nemoze biti manji od 0 ili ne postoji zadani portfelj!");
            }

            try
            {
                trazeniPortfelj.IzbrisiDionicu(inStockName, numberOfShares);
            }
            catch(StockExchangeException)
            {
                throw;
            }
        }

        /// <summary>
        /// Briše kompletnu dionicu iz portfelja
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="inStockName">Ime dionice</param>
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
            if(trazeniPortfelj != null)
            {
                Dionica trazenaDionica = trazeniPortfelj.DionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
                if (trazenaDionica != null)
                {
                    trazeniPortfelj.IzbrisiDionicu(trazenaDionica);
                }
                else
                {
                    throw new StockExchangeException("U zadanom portfelju ne postoji trazena dionica!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazeni portfelj!");
            }
        }

        /// <summary>
        /// Računa broj portfelja na burzi
        /// </summary>
        /// <returns>Broj portfelja na burzi</returns>
        public int NumberOfPortfolios()
        {
            if (burzovniPortfelji != null)
            {
                return burzovniPortfelji.Count;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Računa broj dionica u portfelju
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <returns>Broj dionica u portfelju</returns>
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
            if (trazeniPortfelj != null)
            {
                return trazeniPortfelj.BrojDionicaPortfelja();
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazeni portfelj!");
            }
        }

        /// <summary>
        /// Provjerava postoji li portfelj zadanog imena
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <returns>Istina ako portfelj postoji, laž inače</returns>
        public bool PortfolioExists(string inPortfolioID)
        {
            return burzovniPortfelji.Exists(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
        }

        /// <summary>
        /// Provjrava da li portfelj sadrži dionicu
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="inStockName">Ime dionice</param>
        /// <returns>Istina ako portfelj sadrži dionicu, laž inače</returns>
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
            if (trazeniPortfelj != null)
            {
                return trazeniPortfelj.DionicePortfelja.Exists(dionica => dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            }
            else
            {
                throw new StockExchangeException("Ne postoji trazeni portfelj!");
            }
        }

        /// <summary>
        /// Računa broj udjela dionice u portfelju
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="inStockName">Ime dionice</param>
        /// <returns>Broj udjela dionice u portfelju</returns>
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));
            
            if(trazeniPortfelj == null)
            {
                throw new StockExchangeException("Portfelj: " + inPortfolioID + " ne postoji na našoj burzi!");
            }

            try
            {
                return trazeniPortfelj.BrojDionicaPortfelja(inStockName);
            }
            catch(StockExchangeException)
            {
                throw;
            }
        }

        /// <summary>
        /// Računa vrijednost portfelja
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="timeStamp">Datum vrijednosti</param>
        /// <returns>Vrijednost portfelja na traženi datum</returns>
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));

            if (trazeniPortfelj == null)
            {
                throw new StockExchangeException("Trazeni portfelj ne postoji na burzi!");
            }

            try
            {
                return trazeniPortfelj.UkupnaVrijednost(burzovnaPovijestDionica, timeStamp);
            }
            catch(StockExchangeException)
            {
                throw;
            }
        }

        /// <summary>
        /// Računa promjenu vrijednosti portfelja u periodu od mjesec dana
        /// </summary>
        /// <param name="inPortfolioID">Ime portfelja</param>
        /// <param name="Year">Godina</param>
        /// <param name="Month">Mjesec</param>
        /// <returns>Veijdenost promjene portfelja u mjesecu</returns>
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfelj trazeniPortfelj = burzovniPortfelji.Find(portfelj => portfelj.PortfeljID.Equals(inPortfolioID));

            if (trazeniPortfelj == null)
            {
                throw new StockExchangeException("Trazeni portfelj ne postoji na burzi!");
            }

            try
            {
                return trazeniPortfelj.IzracunajMjesecnuPromjenu(burzovnaPovijestDionica, Year, Month);
            }
            catch (StockExchangeException)
            {
                throw;
            }
        }

        //Računa vrijednost neke od dionica na zadani datum
        internal static Decimal VrijednostDionicaZaDatum(PovijestDionice vrijednostiDionice, DateTime datum)
        {
            Decimal vrijednostDionice = 0;

            List<PovijestVrijednosti> sortiraniPovijestVrijednosti = vrijednostiDionice.PovijestVrijednosti.OrderByDescending(dat => dat.OdKadaVrijediCijena).ToList();

            foreach (PovijestVrijednosti pov in sortiraniPovijestVrijednosti)
            {
                if (datum > pov.OdKadaVrijediCijena)
                {
                    vrijednostDionice = pov.VrijednostDionice;
                    break;
                }
            }
            return vrijednostDionice;
        }
    }

    /// <summary>
    /// Klasa koja sadrži podatke o dionici
    /// </summary>
    class Dionica
    {
        private string imeDionice;

        public string ImeDionice
        {
            get { return imeDionice; }
        }

        private long brojDionica;

        public long BrojDionica
        {
            get { return brojDionica; }
            set { brojDionica = value; }
        }

        public Dionica(string ime, long broj)
        {
            if (String.IsNullOrEmpty(ime))
            {
                throw new StockExchangeException("Niste unijeli ime dionice!");
            }
            else
            {
                this.imeDionice = ime;
            }
            if (broj <= 0)
            {
                throw new StockExchangeException("Broj dionica nemože biti manji od 0!");
            }
            else
            {
                this.brojDionica = broj;
            }
        }
    }

    /// <summary>
    /// Klasa koju nasljeđuju tipovi indeksa
    /// </summary>
    abstract class Indeks
    {
        private string imeIndeksa;

        public string ImeIndeksa
        {
            get { return imeIndeksa; }
            set { imeIndeksa = value; }
        }

        private List<Dionica> dionicaUIndeksu;

        internal List<Dionica> DionicaUIndeksu
        {
            get { return dionicaUIndeksu; }
        }

        /// <summary>
        /// Kreira novu listu dionica za indeks
        /// </summary>
        public Indeks()
        {
            dionicaUIndeksu = new List<Dionica>();
        }

        /// <summary>
        /// Računa broj dionica u indeksu
        /// </summary>
        /// <returns>Broj dionica u indeksu</returns>
        public int dohvatiBrojDionicaUIndeksu()
        {
            if (dionicaUIndeksu != null)
            {
                return dionicaUIndeksu.Count;
            }
            else
            {
                return 0;
            }
        }

        public void DodajDionicu(Dionica dionica)
        {
            if (dionicaUIndeksu.Contains(dionica))
            {
                throw new StockExchangeException("Dionica se već nalazi u indeksu!");
            }
            dionicaUIndeksu.Add(dionica);
        }

        public void IzbrisiDionicu(Dionica dionica)
        {
            if (dionicaUIndeksu.Contains(dionica))
            {
                dionicaUIndeksu.Remove(dionica);
            }
            else
            {
                throw new StockExchangeException("Trazena dionica se ne nalazi u indeksu!");
            }
        }

        public bool SadrziLiIndeksDionicu(string imeDionice)
        {
            if (dionicaUIndeksu.Exists(dionica => dionica.ImeDionice.Equals(imeDionice, StringComparison.OrdinalIgnoreCase)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public abstract Decimal IzracunajVrijednostIndeksa(List<PovijestDionice> povijestCijena, DateTime datumCijeneDionica);
    }

    /// <summary>
    /// Average tip indeksa nasljeđuje od klase Indeks
    /// </summary>
    class AverageIndeks : Indeks
    {
        public AverageIndeks(string imeIndeksa):base()
        {
            this.ImeIndeksa = imeIndeksa;
        }

        /// <summary>
        /// Računa vrijednost indeksa prema formuli (zbroj vrijednosti svih dionica u indeksu)/(broj dionica u indeksu)
        /// </summary>
        /// <param name="povijestCijena">Kretranje cijena dionice</param>
        /// <param name="datumCijeneDionica">Datum za koji nas zanima vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public override Decimal IzracunajVrijednostIndeksa(List<PovijestDionice> povijestCijena, DateTime datumCijeneDionica)
        {
            Decimal tezinskiFaktor = 0;

            foreach (Dionica dionica in DionicaUIndeksu)
            {
                PovijestDionice kretanjeCijena = povijestCijena.Find(dio => dio.Dionica == dionica);
                Decimal trenutnaVrijednost = Burza.VrijednostDionicaZaDatum(kretanjeCijena, datumCijeneDionica);

                tezinskiFaktor += trenutnaVrijednost;
            }
            try
            {
                tezinskiFaktor = tezinskiFaktor / DionicaUIndeksu.Count;
                return Decimal.Round(tezinskiFaktor, 3);
            }
            catch(Exception)
            {
                throw new StockExchangeException("Greska prilikom izracuna indeksa");
            }
            
        }
    }

    /// <summary>
    /// Klasa koja računa Weighted indeks
    /// </summary>
    class WeightedIndeks : Indeks
    {
        public WeightedIndeks(string imeIndeksa):base()
        {
            this.ImeIndeksa = imeIndeksa;
        }

        /// <summary>
        /// Računa vrijednost indeksa prema formuli ((broj dionica * vrijednost dionice) / ukupna vrijednost svih dionica u indeksu) * vrijednost dionice i zbraja te vrijednosti za svaku dionicu u indeksu
        /// </summary>
        /// <param name="povijestCijena">Kretanje cijena dionica</param>
        /// <param name="datumCijeneDionica">Datum za koji nas zanima vrijednost indeksa</param>
        /// <returns>Vrijednost indeksa</returns>
        public override Decimal IzracunajVrijednostIndeksa(List<PovijestDionice> povijestCijena, DateTime datumCijeneDionica)
        {
            Decimal ukupnaVrijednost = 0;
            foreach (Dionica dionica in DionicaUIndeksu)
            {
                PovijestDionice kretanjeCijena = povijestCijena.Find(dio => dio.Dionica == dionica);
                Decimal trenutnaVrijednost = Burza.VrijednostDionicaZaDatum(kretanjeCijena, datumCijeneDionica);

                ukupnaVrijednost += kretanjeCijena.Dionica.BrojDionica * trenutnaVrijednost;
            }

            Decimal tezinskiFaktor = 0;

            foreach (Dionica dionica in DionicaUIndeksu)
            {
                PovijestDionice kretanjeCijena = povijestCijena.Find(dio => dio.Dionica == dionica);
                Decimal trenutnaVrijednost = Burza.VrijednostDionicaZaDatum(kretanjeCijena, datumCijeneDionica);

                tezinskiFaktor += ((kretanjeCijena.Dionica.BrojDionica * trenutnaVrijednost) / ukupnaVrijednost) * trenutnaVrijednost;
            }

            return Decimal.Round(tezinskiFaktor, 3);
        }
    }

    /// <summary>
    /// Klasa koja opisuje burzovni portfelj
    /// </summary>
    class Portfelj
    {
        private string portfeljID;

        public string PortfeljID
        {
            get { return portfeljID; }
        }

        private List<Dionica> dionicePortfelja;

        public Portfelj(string IDportfelja)
        {
            this.portfeljID = IDportfelja;
            dionicePortfelja = new List<Dionica>();
        }

        internal List<Dionica> DionicePortfelja
        {
            get { return dionicePortfelja; }
        }

        /// <summary>
        /// Briše dionicu iz portfelja
        /// </summary>
        /// <param name="trazenaDionica">Ime dionice</param>
        internal void IzbrisiDionicu(Dionica trazenaDionica)
        {
            this.dionicePortfelja.Remove(trazenaDionica);
        }

        /// <summary>
        /// Računa broj dionica u portfelju
        /// </summary>
        /// <returns>Broj dionica</returns>
        internal int BrojDionicaPortfelja()
        {
            if (dionicePortfelja != null)
            {
                return dionicePortfelja.Count;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Dodaje dionicu u portfelj
        /// </summary>
        /// <param name="inStockName">Ime dionice</param>
        /// <param name="numberOfShares">Broj udjela</param>
        internal void DodajDionicu(string inStockName, int numberOfShares)
        {
            Dionica dodajDionicu = dionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));
            if (dodajDionicu != null)
            {
                dodajDionicu.BrojDionica += numberOfShares; 
            }
            else
            {
                dodajDionicu = new Dionica(inStockName, numberOfShares);
                dionicePortfelja.Add(dodajDionicu);
            }
        }

        /// <summary>
        /// Briše broj udjela dionice iz portfelja
        /// </summary>
        /// <param name="inStockName">Ime dionice</param>
        /// <param name="numberOfShares">Broj udjela</param>
        internal void IzbrisiDionicu(string inStockName, int numberOfShares)
        {
            Dionica prodanaDionica = dionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(inStockName, StringComparison.OrdinalIgnoreCase));

            if (prodanaDionica == null)
            {
                throw new StockExchangeException("U portfelju " + portfeljID + " ne postoji dionica: " + inStockName + "!");
            }
            else
            {
                if ((prodanaDionica.BrojDionica - numberOfShares) < 0)
                {
                    throw new StockExchangeException("Ne možete prodati " + numberOfShares + "dionica " + inStockName + " iz portfelja " + portfeljID + " s obzirom da portfelj ima samo " + prodanaDionica.BrojDionica + "dionica.");
                }
                else
                {
                    prodanaDionica.BrojDionica -= numberOfShares;
                }
            }
        }

        /// <summary>
        /// Računa broj udjela dionice u portfelju
        /// </summary>
        /// <param name="inStockName">Ime dionice</param>
        /// <returns>Broj udjela</returns>
        internal int BrojDionicaPortfelja(string inStockName)
        {
            Dionica trazenaDionica = dionicePortfelja.Find(dionica => dionica.ImeDionice.Equals(inStockName));

            if (trazenaDionica == null)
            {
                throw new StockExchangeException("Dionica ne postoji u portfelju");
            }

            else
            {
                return (int)trazenaDionica.BrojDionica;
            }
        }

        /// <summary>
        /// Računa ukupnu vrijednost portfelja po formuli zbroji(broj udjela * cijena dionice)
        /// </summary>
        /// <param name="burzovnaPovijestDionica">Kretanje cijene dionice</param>
        /// <param name="timeStamp">Datum za koji nas zanima vrijednost</param>
        /// <returns>Vrijednost portfelja</returns>
        internal decimal UkupnaVrijednost(List<PovijestDionice> burzovnaPovijestDionica, DateTime timeStamp)
        {
            try
            {
                decimal ukupnaVrijednost = 0;

                foreach (Dionica dionica in dionicePortfelja)
                {
                    PovijestDionice trazenaDionica = burzovnaPovijestDionica.Find(dion => dion.Dionica.ImeDionice.Equals(dionica.ImeDionice, StringComparison.OrdinalIgnoreCase));
                    ukupnaVrijednost += dionica.BrojDionica * Burza.VrijednostDionicaZaDatum(trazenaDionica, timeStamp);
                }

                return ukupnaVrijednost;
            }
            catch
            {
                throw new StockExchangeException("Nisu definirane cijene svih dionica u zadanom vremenu!");
            }
        }

        /// <summary>
        /// Računa promjenu vrijednosti portfelja u mjesecu prema formuli (vrijednost na početku mjeseca / vrijednost na kraju mjeseca) * 100
        /// </summary>
        /// <param name="burzovnaPovijestDionica">Kretanje cijena dionica</param>
        /// <param name="Year">Godina</param>
        /// <param name="Month">Mjesec</param>
        /// <returns>Promjenu vrijednosti portfelja</returns>
        internal decimal IzracunajMjesecnuPromjenu(List<PovijestDionice> burzovnaPovijestDionica, int Year, int Month)
        {
            try
            {
                DateTime pocetakMjeseca = new DateTime(Year, Month, 1, 0, 0, 0, 0);
                DateTime krajMjeseca = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);

                decimal vrijednostNaPocetkuMjeseca = 0;
                decimal vrijednostNaKrajuMjeseca = 0;

                vrijednostNaPocetkuMjeseca = UkupnaVrijednost(burzovnaPovijestDionica, pocetakMjeseca);
                vrijednostNaKrajuMjeseca = UkupnaVrijednost(burzovnaPovijestDionica, krajMjeseca);

                return Decimal.Round(((vrijednostNaKrajuMjeseca - vrijednostNaPocetkuMjeseca) / vrijednostNaPocetkuMjeseca) * 100, 3);
            }
            catch
            {
                throw new StockExchangeException("Greska nije definirana cijena svih dionica portfelja!");
            }
        }
    }

    /// <summary>
    /// Klasa PovijestDionice čuva vrijednosti dionice kroz povijest
    /// </summary>
    class PovijestDionice
    {
        private Dionica dionica;

        internal Dionica Dionica
        {
            get { return dionica; }
        }

        private List<PovijestVrijednosti> povijestVrijednosti = new List<PovijestVrijednosti>();

        internal List<PovijestVrijednosti> PovijestVrijednosti
        {
            get { return povijestVrijednosti; }
        }

        public PovijestDionice(Dionica stock, Decimal cijena, DateTime odKadaVrijediNavedenaCijena)
        {
            dionica = stock;
            
            if (cijena <= 0)
            {
                throw new StockExchangeException("Cijena dionice nemože biti manja od 0 valuta!");
            }

            PovijestVrijednosti povijest = new PovijestVrijednosti();
            povijest.OdKadaVrijediCijena = odKadaVrijediNavedenaCijena;
            povijest.VrijednostDionice = cijena;
            povijestVrijednosti.Add(povijest);
        }

        public void dodajVrijednost(Decimal cijena, DateTime odKadaVrijedi)
        {
            if (cijena < 0)
            {
                throw new StockExchangeException("Cijena dionice nemože biti manja od 0 valuta!");
            }
            if (povijestVrijednosti.Exists(vrijednost => vrijednost.OdKadaVrijediCijena.Equals(odKadaVrijedi)))
            {
                throw new StockExchangeException("Za zadano vrijeme već postoji cijena!");
            }
            PovijestVrijednosti novaVrijednost = new PovijestVrijednosti();
            novaVrijednost.OdKadaVrijediCijena = odKadaVrijedi;
            novaVrijednost.VrijednostDionice = cijena;
            povijestVrijednosti.Add(novaVrijednost);
        }
    }

    /// <summary>
    /// Klasa koja sadrži vrijednost dionice na datum
    /// </summary>
    class PovijestVrijednosti
    {
        private DateTime odKadaVrijediCijena;

        public DateTime OdKadaVrijediCijena
        {
            get { return odKadaVrijediCijena; }
            set { odKadaVrijediCijena = value; }
        }

        private Decimal vrijednostDionice;

        public Decimal VrijednostDionice
        {
            get { return vrijednostDionice; }
            set { vrijednostDionice = value; }
        }
    }
}
