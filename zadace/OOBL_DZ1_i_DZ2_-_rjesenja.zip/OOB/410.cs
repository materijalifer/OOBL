﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private static int i = 0;

        
        private const int maxNumberOfDigitsDisplayed = 30;
        private const int maxDigits = 10;

        private const int indexOfLastDigit = 0;

        //brojač znamenki
        private static int counterDigits = 0;

        //brojač ukupnog broja znakova
        private static int counterOverAll = 0;


        private static char[] pressed = new char[maxNumberOfDigitsDisplayed];
        private static char[] pressedTwo = new char[maxNumberOfDigitsDisplayed];


        private static string memory="";

        //zastavica koja prati decimalni zarez kako bi spriječili unošenje zareza dvaput ili više puta i varijabla koja označava na kojem je mjestu decimalni zarez
        public static Boolean flagDecimal = false;
        private static Boolean firstNumberFlag = false;
        private static Boolean secondNumberFlag = false;
        private static Boolean minusOperationFlag = false;
        
        private static int decimalFlagIndex;

        /* varijable i zastavice za rad s operatorima; operationEndFlag označava unos znaka "=", a operationFlag označava da je u tijeku matematička
        operacija  između dva broja. varijabla op pohranjuje trenutnu matematičku operaciju koja je u tijeku dok je zastavica operation flag podignuta.*/
        private static Boolean operationEndFlag = false;
        private static Boolean operationFlag = false;
        private static char op;

        //varijable za pohranu i računanje trenutnih vrijednosti u kalkulatoru
        private static double counter=0;
        public  string buffNumber="";
        public string bufferNumberTwo = "";
        private static string buffOperand = "";
        private static string firstOperand="";
        private static string secondOperand="";
        private static string result="";

        //rječnik koji služi za pohranu memorijskih operacija
        private static Dictionary<char, Action> memoryOperator= new Dictionary<char, Action>()
         {
            
            {'P',put},
            {'G',get},
            {'C',clear},
            {'O',onAndOff},
            
         
        };

        //rječnik koji služi za pohranu unarnih operacija
        private static Dictionary<char, Action> unarOperator= new Dictionary<char, Action>()
        {
            
            {'M',minus},
            {'S',sinus},
            {'K',cosinus},
            {'T',tangens},
            {'Q',square},
            {'R', root},
            {'I',inverse}
         
        };

        
        public void Press(char inPressedDigit)
        {
            //try
            //{
                //provjera unosa od 12 znakova ( 10 znamenki uključujući operator i znak decimalne točke )
                //paziti da se ne unese dva operatora za redom

                //if (!firstOperand.Length.Equals(10) && )
                //{
                    counterOverAll++;
                    //ako uneseni znak nije znamenka
                    if (inPressedDigit < '0' || inPressedDigit > '9')
                    {  
                        switch (inPressedDigit)
                        {
                            case ',':  //prenosimo decimalni zarez u polje znakova i pazimo da nema dva unesena zareza jer je to greška( izbacujemo u rezultat -E-), postavljamo zastavicu kako bismo znali je li jedan zarez već postavljen
                                if (!flagDecimal)
                                {    
                                    
                                    //ako je prvo unesen zarez onda treba postaviti 0 na početku
                                    if (string.IsNullOrEmpty(buffNumber))
                                    {
                                        pressed[i] = '0';
                                        i++;
                                    }
                                    
                                    pressed[i] = inPressedDigit;
                                    flagDecimal = true;
                                    i++;
                                }
                                else
                                {
                                    result = "-E-";
                                    return;
                                }
                                break;

                            case '=':
                                if (firstNumberFlag)
                                {
                                    secondOperand = buffNumber;
                                    firstNumberFlag = false;
                                }
                                else
                                {
                                    firstOperand = buffNumber;
                                }
                                
                                //ako je prazan operand onda je rezultat 0
                                if (string.IsNullOrEmpty(firstOperand))
                                {
                                    result = "0";
                                    secondOperand = "";
                                    
                                }
                                    //ako je npr. 2*=
                                //else if (operationFlag)
                                //{
                                //    operationEndFlag = true;
                                //    if(result.Substring(0,1).Equals("-"))
                                //    {
                                //    selectMathOperator('-');
                                //    }


                                //}

                                else
                                {
                                    result = Math.Round(double.Parse(firstOperand)).ToString();
                                    
                                    secondOperand = "";
                                }
                                break;
                            default:

                                operationFlag = true;
                                op = inPressedDigit;
                                if (op.Equals("M"))
                                {
                                    minusOperationFlag = true;

                                }
                                //spremi broj 
                                if (string.IsNullOrEmpty(firstOperand) && !minusOperationFlag)
                                {
                                    firstOperand = buffNumber;
                                    flagDecimal = false;
                                    firstNumberFlag = true;
                                    Array.Clear(pressed, 0, pressed.Length);
                                    i = 0;
                                    buffNumber = "";  //nakon što smo predali prvi broj,buffer treba inicijalizirat na prazni string 
                                   
                                   
                                }
                                else if (!minusOperationFlag)
                                {
                                    secondOperand = buffNumber;
                                    Array.Clear(pressed, 0, pressed.Length);
                                    flagDecimal = false;
                                    secondNumberFlag = true;
                                    i = 0;
                                    buffNumber = ""; //isto kao i za prvi broj
                                }
                                else
                                {
                                    firstOperand = buffNumber;
                                    if (!op.Equals("M"))
                                    {
                                        minusOperationFlag = false;
                                    }
                                }

                               
                                //odrediti koji je operator pozvan, unarni ili matematički 
                                if (unarOperator.ContainsKey(inPressedDigit))
                                {
                                    unarOperator[inPressedDigit]();
                                }
                                else
                                {

                                    selectMathOperator(inPressedDigit);
                                }
                                break;

                        }

                    }

                    else        //znamenka je
                    {    //provjera unosa od 10 znamenki 
                        //if (!counterDigits.Equals(maxDigits))
                        //{
                            counterDigits++;
                            pressed[i] = inPressedDigit;
                            result = new string(pressed);
                            i++;
                        //}

                    }
                    buffNumber = new string(pressed);
                  
                    


                    
                }
                
                
            //}

            // //upisan je prevelik broj, treba ga zaokružiti i uzeti samo 10 znamenaka
            //catch (IndexOutOfRangeException ex)
            //{
            //    result = "-E-"; 
                

            //    return;
            //}
        


        public string GetCurrentDisplayState()
        {
            //result = result.TrimStart('0');
            if (result.Equals(""))
            {
                result = "0";
            }
            else if (result.Equals("-E-"))
            {
                return result;
            }
            else if (result.Count() > 12 && result.Contains('-'))
            {
                return result.Substring(0, 12);
            }

            else if (result.Replace("\0", "").Count() > 12)
            {
                return "-E-";
            }
            
            return result.Replace("\0", "");
                    

           }
        



        //pomoćna metoda koja zaokružuje vrijednost broja 
        private static double roundValue(double press)
        {

            return Math.Round(press);


        }
        private static double roundValue(Char[] press)
        {
            
           return Math.Round(double.Parse(new string(press)));


        }

        // pomoćna metoda za odabir matematičkog operatora (oduzimanje, zbrajanje, množenje, dijeljenje)
        private static void selectMathOperator(char inPressed)
        {
            switch (inPressed){
                case '+':
                    add();
                    break;
                case '-':
                    sub();
                    break;
                case '*':
                    multiply();
                    break;
                case '/':
                    divide();
                    break;

                default:
                    selectMemoryOperator(inPressed);
                    break;
            }


        }



        // pomoćna metoda za odabir načina rada s memorijom kalkulatora 
         private static void selectMemoryOperator(char inPressed)
        {
            switch (inPressed){
                case 'P':
                    put();
                    break;
                case 'G':
                    get();
                    break;
                case 'C':
                    clear();
                    break;
                case 'O':
                    onAndOff();
                    break;


            }
         }




        // matematičke operacije zbrajanja, oduzimanja, množenja i dijeljenja
        #region mathOperations


        private static void add()
        {   
            //ako je odmah pritisnuto "+" onda je prvi operand "0"
            if (firstOperand.Equals(""))
            {
                firstOperand = "0";
                counter = double.Parse(firstOperand) + double.Parse(secondOperand);
                result = roundValue(counter).ToString();
                operationFlag = false;
                firstOperand = result;
                secondOperand = "";
            }
            //skraćeni zapis npr. 2+=, gdje nedostaje drugi operand
            else if (secondOperand.Equals("") && operationEndFlag)
            {

                counter = double.Parse(firstOperand) + double.Parse(firstOperand);
                result = roundValue(counter).ToString();

                firstOperand = result;
                operationEndFlag = false;
                operationFlag = false;
                secondOperand = "";
            }
            
                //"obično zbrajanje"
            else if (operationEndFlag)
            {
                counter = double.Parse(firstOperand) + double.Parse(secondOperand);
                result = roundValue(counter).ToString();
                firstOperand = result;
                operationFlag = false;
                operationEndFlag = false;
                secondOperand = "";
            }
            else
            {
                result =firstOperand;
                firstOperand = result;
            }

        }

        private static void sub()
        {
            //ako je odmah pritisnuto - onda je prvi operand s predznakom minus
            if (firstOperand.Equals(""))
            {
                firstOperand = "-";
                result= firstOperand;
                
                operationFlag = false;
                
            }
            //skraćeni zapis npr. 2-=, gdje nedostaje drugi operand iako je ovo očito uvijek 0
            else if (secondOperand.Equals("")&& operationEndFlag)
            {   
                operationEndFlag = false;
                operationFlag = false;
               
                result = "0";
                
            }
            else if (operationEndFlag && !secondOperand.Equals("0"))
            {
                counter = double.Parse(firstOperand) - double.Parse(result);
                result = counter.ToString();
                firstOperand = result;
                operationFlag = false;
                secondOperand = "";
            }
            //"obično oduzimanje"
            else if (operationEndFlag)
            {
                counter = double.Parse(firstOperand) - double.Parse(secondOperand);
                result = counter.ToString();
                firstOperand = result;
                operationFlag = false;
                secondOperand = "";

            }

        }


        private static void multiply()
        {
            //ako je odmah pritisnuto * onda je prvi operand 0 i to je množenje s nulom
            if (firstOperand.Equals(""))
            {
                result = "0";
                firstOperand = result; ;
            }
            //skraćeni zapis npr. 2*, gdje nedostaje drugi operand
            else if (secondOperand.Equals("") && operationEndFlag)
            {

                counter = double.Parse(firstOperand) * double.Parse(firstOperand);
                result = roundValue(counter).ToString();
                operationEndFlag = false;
                operationFlag = false;
                firstOperand = result;
                secondOperand = "";
            }
            //"obično množenje"
            else if (operationEndFlag)
            {
                counter = double.Parse(firstOperand) * double.Parse(secondOperand);
                result = counter.ToString();
                firstOperand = result;
                operationFlag = false;
                secondOperand = "";
            }

        }

        private static void divide()
        {   //zabraniti dijeljenje s 0
            if (secondOperand.Equals("0") || string.IsNullOrEmpty(secondOperand))
            {
                result = "-E-";
                
            }
              
            else
            {
                counter = double.Parse(firstOperand) / double.Parse(secondOperand);
                result = roundValue(counter).ToString();
                firstOperand = result;
               operationFlag= false;
                secondOperand = "";
            }
        }


        #endregion


        // unarne operacije
        #region unarOperations

        private static void minus()
        {  //promjena predznaka pozvana na prvom operandu i provjera je li prvi operand unešen
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = double.Parse(firstOperand) * (-1);
                
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
            }
           

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = double.Parse(secondOperand) * (-1);
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);
            }
            else if (operationEndFlag)
            {
                counter = double.Parse(firstOperand) * (-1);
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }

        }


        private static void sinus()
        {  //sinus pozvan na prvom operandu
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = Math.Sin(double.Parse(firstOperand));
               
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = Math.Sin(double.Parse(secondOperand));
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);

            }
            else if (operationEndFlag)
            {
                counter = Math.Sin(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }


        }

        private static void cosinus()
        {  
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = Math.Cos(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                Console.WriteLine(result);

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = Math.Cos(double.Parse(secondOperand));
                result = Math.Round(counter, 9).ToString();
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);
                
            }

            else if (operationEndFlag)
            {
                counter = Math.Cos(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                Console.WriteLine(result);
                operationEndFlag = false;
            }


        }


        private static void tangens()
        {  
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = Math.Tan(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = Math.Tan(double.Parse(secondOperand));
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);

            }
            else if (operationEndFlag)
            {
                counter = Math.Tan(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }

        }

        private static void root()
        {  
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = Math.Sqrt(double.Parse(firstOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = Math.Sqrt(double.Parse(secondOperand));
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);

            }
            else if (operationEndFlag)
            {
                counter = Math.Sqrt(double.Parse(secondOperand));
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }

        }

        private static void square()
        {  
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {
                counter = Math.Pow(double.Parse(firstOperand),2);
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                counter = Math.Pow(double.Parse(secondOperand),2);
                secondOperand = Math.Round(counter, 9).ToString();
                selectMathOperator(op);

            }
            else if (operationEndFlag)
            {
                counter = Math.Pow(double.Parse(firstOperand), 2);
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }

        }


        private static void inverse()
        {  //spriječiti dijeljenje s 0
            if (secondOperand.Equals("") && !string.IsNullOrEmpty(firstOperand))
            {

                if (!double.Parse(firstOperand).Equals(0))
                {
                    counter = 1 / double.Parse(firstOperand);
                    result = Math.Round(counter, 9).ToString();
                    firstOperand = result;
                }
                else
                {
                    result = "-E-";
                }

            }

            else if (!string.IsNullOrEmpty(secondOperand) && operationFlag)
            {
                if (!double.Parse(firstOperand).Equals(0))
                {
                    counter = 1 / double.Parse(firstOperand);
                    result = Math.Round(counter, 9).ToString();
                    firstOperand = Math.Round(counter, 9).ToString();
                    selectMathOperator(op);
                }
                else
                {
                    result = "-E-";
                }

            }
            else if (operationEndFlag)
            {
                counter = 1 / double.Parse(firstOperand);
                result = Math.Round(counter, 9).ToString();
                firstOperand = result;
                operationEndFlag = false;
            }

            else
            {
                result = "-E-";
            }


        }


        #endregion



        // u ovoj regiji se nalaze metode podijeljene za rad s memorijom kalkulatora(spremanje, brisanje, dohvat)
        #region memoryOperations


        // metoda za spremanje trenutnog broja u memoriju
        private static void put()
        {
            if (firstNumberFlag)
            {   
                string digit = firstOperand;
                firstNumberFlag = false;
                memory += digit;
            }
            else if(secondNumberFlag)
            {
                string digit = secondOperand;
                secondNumberFlag = false;
                memory += digit;
            }
        
        }


        //metoda za dohvat broja iz memorije
        private static void get()
        {
            result = memory;
        }

       // metoda za brisanje stanaj s ekrana
        private static void clear()
        {
            //briši trenutni broj na ekranu
            firstOperand= string.IsNullOrEmpty(secondOperand) ? "" : firstOperand ;
            secondOperand=(!string.IsNullOrEmpty(firstOperand) && !string.IsNullOrEmpty(secondOperand)) ? "" : secondOperand;


        }



        //metoda za gašenje kalkulatora
        private static void onAndOff()
        { //sve treba postaviti na početne vrijednosti
            result="0";
            firstOperand="0";
            secondOperand="0";
           
            buffOperand = "";
            memory="";
            counter = 0;
            operationEndFlag=false;
            operationFlag=false;
            flagDecimal = false;
            
        }


        #endregion



    }


   


}
