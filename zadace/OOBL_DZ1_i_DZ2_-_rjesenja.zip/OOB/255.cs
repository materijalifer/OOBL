﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        char pritisnutiZnak;
        string display = "0";
        string znakUString;
        double vrijednost;
        string prviOperand;
        string memorija;
        string drugiOperand;
        double vrijednost2;
        string operacija;
        char pamtiZaSkraceno;
        char op;
        string prviPrije;
        

        public void Press(char inPressedDigit)
        {
            pritisnutiZnak = inPressedDigit;

            if (inPressedDigit == '.')
            {
                inPressedDigit = ',';
            }

            znakUString = new string(inPressedDigit, 1);

            if (display != "0"
              && (inPressedDigit != 'S'
                && inPressedDigit != 'K'
                && inPressedDigit != 'T'
                && inPressedDigit != 'Q'
                && inPressedDigit != 'R'
                && inPressedDigit != 'I'
                && inPressedDigit != 'P'
                && inPressedDigit != 'G'
                && inPressedDigit != 'C'
                && pritisnutiZnak != '='
                && pritisnutiZnak != '-'
                && pritisnutiZnak != '*'
                && pritisnutiZnak != '/'
                && pritisnutiZnak != '+'
                && pritisnutiZnak != 'M'
                && pritisnutiZnak != 'O'
                ))
            {

                // prviOperand = display;
                display = display + znakUString;
                if (drugiOperand == null)
                {
                    prviOperand = display;
                }
                else
                {
                    if (drugiOperand == "")
                    {
                        display = znakUString;
                    }

                    drugiOperand = display;
                }


            }

            else if (pritisnutiZnak == 'S'
                || pritisnutiZnak == 'K'
                || pritisnutiZnak == 'T'
                || pritisnutiZnak == 'Q'
                || pritisnutiZnak == 'R'
                || pritisnutiZnak == 'P'
                || pritisnutiZnak == 'G'
                || pritisnutiZnak == 'C'
                || pritisnutiZnak == '='
                || pritisnutiZnak == '-'
                || pritisnutiZnak == '*'
                || pritisnutiZnak == '/'
                || pritisnutiZnak == '+'
                || pritisnutiZnak == 'M'
                || pritisnutiZnak == 'O')
            {
                op = pritisnutiZnak;
                znakUString = "";
                display = display + znakUString;
                if (drugiOperand == null)
                {
                    prviOperand = display;
                }
                else
                {
                    drugiOperand = display;
                }


            }

            

            if (pritisnutiZnak == 'I')
            {
                op = pritisnutiZnak;
                znakUString = "";
                display = display + znakUString;
                prviOperand = display;
            }


            if (display == "0" && znakUString == ",")
            {
                display = display + znakUString;
            }

            if (display == "0")
            {
                if (op != 'O' && op != '=' && op != 'I')
                {
                    display = znakUString;
                }
                else
                {
                    display = "0";
                }

                prviOperand = display;
            }

            if (inPressedDigit == 'M')
            {
                if (display == prviOperand)
                {
                    double temp = Convert.ToDouble(display) * -1;
                    display = temp.ToString();



                    prviOperand = display;
                }
                else
                {
                    if (display.Contains('-'))
                    {
                        display = display.Remove(0, 1);
                    }
                    else
                    {
                        display = display.Insert(0, "-");
                    }
                    drugiOperand = display;
                }

            }

            if (inPressedDigit == 'P')
            {
                memorija = memorija + display;
                display = "";
            }


            if (op == 'O')
            {
                display = "0";
                memorija = "";
                prviOperand = display;
            }

            vrijednost = Convert.ToDouble(prviOperand);

            if (op == 'S')
            {
                vrijednost = Math.Sin(vrijednost);
                display = vrijednost.ToString();
            }

            if (op == 'Q')
            {
                operacija = "kvadriranje";
            }
            if (op == 'T')
            {
                vrijednost = Math.Tan(vrijednost);
                display = vrijednost.ToString();
            }

            if (op == 'R')
            {
                vrijednost = Math.Sqrt(vrijednost);
                display = vrijednost.ToString();
            }

            if (op == 'C')
            {
                display = "0";
            }

            if (op == '-'
                 || op == '*'
                 || op == '/'
                 || op == '+')
            {
                //display = "0";
                if (drugiOperand == null)
                {
                    drugiOperand = "";
                }
                pamtiZaSkraceno = pritisnutiZnak;

            }

            if (op == '+')
            {
                //display = "0";
                operacija = "zbrajanje";
            }

            if (op == '-')
            {
                //display = "0";
                operacija = "oduzimanje";
            }

            if (op == '*')
            {
                //display = "0";
                operacija = "mnozenje";
            }

            if (op == 'I')
            {
                //display = "0";
                operacija = "inverz";
                if (vrijednost == 0)
                {
                    display = "-E-";
                }
                else
                {
                    vrijednost = 1 / vrijednost;

                    display = vrijednost.ToString();
                    prviOperand = display;
                }
            }


            if (op == '=')
            {
                if (pamtiZaSkraceno != null)
                {
                    drugiOperand = prviOperand;
                }
                drugiOperand = display;
                vrijednost2 = Convert.ToDouble(drugiOperand);

                if (operacija == "zbrajanje")
                {
                    vrijednost = vrijednost + vrijednost2;
                    display = vrijednost.ToString();
                }

                if (operacija == "oduzimanje")
                {
                    vrijednost = vrijednost - vrijednost2;
                    display = vrijednost.ToString();
                }

                if (operacija == "mnozenje")
                {
                    vrijednost = vrijednost * vrijednost2;
                    display = vrijednost.ToString();
                }

                if (operacija == "kvadriranje")
                {
                    vrijednost = vrijednost * vrijednost;
                    display = vrijednost.ToString();
                }

                if (operacija == "inverz")
                {
                    if (vrijednost == 0)
                    {
                        display = "-E-";

                    }
                    else
                    {
                        vrijednost = 1 / vrijednost;
                        display = vrijednost.ToString();
                    }

                }

                /*else
                {
                    if (vrijednost < 999999.0)
                    {
                        int cjelobrojno = Convert.ToInt32(vrijednost);
                        if (vrijednost == cjelobrojno)
                        {
                        vrijednost = Convert.ToInt32(vrijednost);
                        display = vrijednost.ToString();
                    }
                    }
                }*/
            }

            if (vrijednost < 999999999)
            {
                if (display.Length > 10)
                {
                    int ukupnoDecimala = 10 - Convert.ToInt32(Math.Round(vrijednost)).ToString().Length;
                    //int temp = Math.Round(vrijednost)
                    if (vrijednost < 0)
                    {
                        ukupnoDecimala++;
                    }
                    vrijednost = Math.Round(vrijednost, ukupnoDecimala);
                    display = vrijednost.ToString();
                }
            }

        }

        public string GetCurrentDisplayState()
        {
            // string display = "0";

            if (vrijednost < 999999999)
            {
                if (display.Length > 10)
                {
                    int ukupnoDecimala = 10 - Convert.ToInt32(Math.Round(vrijednost)).ToString().Length;
                    //int temp = Math.Round(vrijednost)
                    if (vrijednost < 0)
                    {
                        ukupnoDecimala++;
                    }
                    vrijednost = Math.Round(vrijednost, ukupnoDecimala);
                    display = vrijednost.ToString();
                }

                if (pritisnutiZnak == 'G')
                {
                    display = memorija;
                }

                if (display.Contains(','))
                {
                    if (Convert.ToInt32(display.Split(',')[1]) == 0)
                    {
                        display = display.Split(',')[0];
                    }
                }

                /*if (vrijednost < 999999.0)
                {
                    int cjelobrojno = Convert.ToInt32(vrijednost);
                    if (vrijednost == cjelobrojno)
                    {
                        vrijednost = Convert.ToInt32(vrijednost);
                        display = vrijednost.ToString();
                    }
                }*/

            }

            else
            {
                display = "-E-";
            }



            return display;
        }




    }
}
