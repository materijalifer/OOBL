﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new MyCalculator();
        }
    }

    public class MyCalculator : ICalculator
    {
        private const int MAX_DIGITS = 10;
        private const int MAX_CHARACTERS = 12;
        private const double MAX_NUMBER = 10000000000.0 - 1.0; //Maksimalni broj na kalkulatoru je 10^MAX_DIGITS - 1 = 10 000 000 000 - 1
        private const string INIT_DISPLAY = "0";
        private const string ERROR_STRING = "-E-";
        

        private static readonly char[] legalCharacters = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ',' };
        private static readonly char[] unaryOperators  = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        private static readonly char[] binaryOperators = { '+', '-', '*', '/', '=' };        
        private static readonly char[] instructions    = { 'P', 'G', 'C', 'O' };

        private class Memory
        {
            private double _value = default(float);

            public double Value
            {
                get { return _value; }
                set { _value = value; _isInitialised = true; }
            }

            private bool _isInitialised = false;

            public bool IsInitialised
            {
                get { return _isInitialised; }
            }

            public void Erase()
            {
                _value = default(float);
                _isInitialised = false;
            }

            public static implicit operator Memory(double rhs)
            {
                return new Memory{ _value = rhs, _isInitialised = true };
            }

            public static implicit operator double(Memory rhs)
            {
                return rhs._value;
            }

            public override string ToString()
            {
                return _value.ToString();
            } 
        }
        private Memory memory = new Memory();

        //Ekran
        private string display = INIT_DISPLAY;
        private char lastCharacter;
        //Pokazuje je li vec bilo unosa
        private bool displayInitialized = false;
        //Pokazuje treba li ocisiti ekran prilikom iduceg unosa, npr. nakon unarnih ili binarnih operacija
        private bool shouldClear = true;

        private double firstOperand = 0.0;
        private double lastOperand = 0.0;
        private int numberOfOperands = 0;
        private char currentBinaryOperator = '=';

        //Pokazuje je li broj trenutno na ekranu decimalni, tj.je li unesen zarez
        private bool isDecimalNumber = false;
        //Cuva broj znamenaka na ekranu
        private int numberOfDigits = 0;

        // Metoda koja pretvara niz znakova na ekranu u realni broj
        private double DisplayToNumber()
        {
            string numberString = display.TrimEnd(',');
            double number;
            bool isNumber = double.TryParse(numberString, out number);
            if (isNumber)
                return number;
            else
                return MAX_NUMBER + 1.0;
        }

        // Metoda koja ispisuje broj ili poruku o gresci na ekran 
        private void NumberToDisplay(double displayNumber)
        {
            if (Math.Abs(displayNumber) > MAX_NUMBER)
            {
                DisplayError();
            }
            else
            {
                // Odreduje se broj znamenaka cijelog dijela realnog broja:
                int integerLength = Convert.ToInt32(
                    displayNumber >= 0 ? Math.Floor(displayNumber) : Math.Ceiling(displayNumber)
                    )
                    .ToString()
                    .TrimStart('-')
                    .Length;

                //Zaokruzivanje broja na odgovarajuci broj decimalnih mjesta:
                display = Math.Round(
                    displayNumber,
                    MAX_DIGITS - integerLength,
                    MidpointRounding.AwayFromZero
                    )
                    .ToString();
                //Dobiveni broj moze zavrsavati na 0 i biti cijeli broj pa
                //treba prvo provjeriti ima li dio iza decimalne tocke
                //da ne bi uklonili nule iz cjelobrojnog dijela
                if (display.Contains(','))
                {
                    //Uklanjanje viska nula iza decimalnog zareza:
                    display = display
                        .TrimEnd('0')
                        .TrimEnd(',');
                }
            }
        }

        // Metoda koja se poziva nakon svake binarne ili unarne operacije
        // da bi se znalo da se nakon unosa sljedeceg znaka treba ocistiti ekran.
        private void OperationDone()
        {
            displayInitialized = true;
            shouldClear = true;
        }

        private void DisplayError()
        {
            display = ERROR_STRING;
            displayInitialized = false;
            shouldClear = true;
        }

        private void Reset()
        {
            memory.Erase();            
            Clear();
            firstOperand = 0.0;
            numberOfOperands = 0;
            currentBinaryOperator = '=';
        }

        private void Clear()
        {
            display = INIT_DISPLAY;
            displayInitialized = false;
            shouldClear = true;
            isDecimalNumber = false;
            numberOfDigits = 0;
        }        

        private double ChangeSign(double number)
        {
            return -number;
        }
        
        private double Sinus(double number)
        {
            return Math.Sin(number);
        }

        private double Cosine(double number)
        {
            return Math.Cos(number);
        }

        private double Tan(double number)
        {
            try
            {
                return Math.Tan(number);
            }
            catch
            {
                return MAX_NUMBER + 1.0;
            }
        }

        private double Square(double number)
        {
            return Math.Pow(number, 2.0);
        }

        private double SquareRoot(double number)
        {
            try
            {
                return Math.Sqrt(number);
            }
            catch
            {
                return MAX_NUMBER + 1.0;
            }
        }

        private double Invers(double number)
        {
            try
            {
                return 1.0 / number;
            }
            catch
            {
                return MAX_NUMBER + 1.0;
            }
        }

        private double BinaryOperation(double secondOperand)
        {
            double result = 0.0;

            switch (currentBinaryOperator)
            {
                case '+':
                    result = firstOperand + secondOperand;
                    break;
                case '-':
                    result =  firstOperand - secondOperand;
                    break;
                case '*':
                    result =  firstOperand * secondOperand;
                    break;
                case '/':
                    result = firstOperand / secondOperand;
                    break;
                case '=':
                    result = secondOperand;
                    break;
                default:
                    break;                    
            }
            return result;
        }

        private void ProcessLegalCharacter(char inPressedDigit)
        {
            if (shouldClear)
            {
                Clear();
            }
            //Ako je decimalni zarez vec unesen, nista se ne dogada
            if ((inPressedDigit == ',') && isDecimalNumber)
            {
                return;
            }

            //Ako je premasen maksimalni dozvoljeni broj znakova na ekranu
            if (display.Length >= MAX_CHARACTERS)
            {
                return;
            }

            //Ako je na ekranu 0, treba se sprijeciti dodavaje novih vodecih nula:
            if ((inPressedDigit == '0') && (display == INIT_DISPLAY))
            {
                return;
            }

            //Ako je premasen maksimalni broj znamenaka broja na ekranu
            if ((inPressedDigit != ',') && (numberOfDigits >= MAX_DIGITS))
            {
                return;
            }

            //Ako je vec bilo unosa
            if (displayInitialized)
            {
                if (inPressedDigit == ',')
                {
                    isDecimalNumber = true;
                }
                else
                {
                    numberOfDigits++;
                }
                display += inPressedDigit;
            }
            else
            {
                //Da se ne bi dodavale vodece nule:
                if (inPressedDigit != ',')
                {
                    display = inPressedDigit.ToString();
                    numberOfDigits++;
                }
                else
                {
                    display = "0,";
                    isDecimalNumber = true;
                    numberOfDigits++;
                }
                displayInitialized = true;
                shouldClear = false;
            }
        }

        private void ProcessUnaryOperator(char inPressedDigit)
        {
            double number = DisplayToNumber(); //Ovo je broj koji se dobije s display-a
            double displayNumber;              //Ovaj ce se broj na kraju pretvoriti u string koji ide u display
            
            switch (inPressedDigit)
            {
                case 'M':
                    displayNumber = ChangeSign(number);
                    break;
                case 'S':
                    displayNumber = Sinus(number);
                    break;
                case 'K':
                    displayNumber = Cosine(number);
                    break;
                case 'T':
                    displayNumber = Tan(number);
                    break;
                case 'Q':
                    displayNumber = Square(number);
                    break;
                case 'R':
                    displayNumber = SquareRoot(number);
                    break;
                case 'I':
                    displayNumber = Invers(number);
                    break;
                default:
                    displayNumber = MAX_NUMBER + 1.0;
                    break;
            }

            NumberToDisplay(displayNumber);
            if (inPressedDigit != 'M')
                OperationDone();
        }

        private void ProcessBinaryOperator(char inPressedDigit)
        {
            double number = DisplayToNumber();
            double displayNumber;

            if (inPressedDigit == '=')
            {
                if (binaryOperators.Contains(lastCharacter) && (lastCharacter != '='))
                {
                    // Ako je korisnik unio binarni operator pa odmah nakon njega =, tada
                    // se treba izvrsiti ta binarna operacija s operandom samima, npr.
                    // 2, +, = je 2 + 2, sto je 4 ili 2*= je 2 * 2
                    displayNumber = BinaryOperation(firstOperand);
                    lastOperand = firstOperand;
                    firstOperand = displayNumber;
                }
                else if ((currentBinaryOperator != '=') && (!displayInitialized))
                {
                    //Ako korisnik zeli ponoviti zadnju operaciju, npr. napisao je
                    //2, +, 5, što je 7, zadnja je opreacija bila +5, pa kad stisne =
                    //ponovi se sa zadnjim rezultatom, tj. 7 + 5 = 13
                    displayNumber = BinaryOperation(lastOperand);
                    firstOperand = displayNumber;
                }
                else
                {
                    // Slucaj kada je korisnik unio prvi operand, operator, drugi operand
                    // i stisnuo =
                    displayNumber = BinaryOperation(number);
                    firstOperand = displayNumber;
                    lastOperand = number;
                }
            }
            else
            {
                //Kada uneeni operator nije =

                if (numberOfOperands == 0)
                {
                    //Ako jos nije bilo operacija, npr. odmah nakon paljenja ili reseta
                    numberOfOperands++;
                    displayNumber = number;
                    firstOperand = number;

                    //Prikaz se nakon unosa prvog operatora ne smije promijeniti
                    currentBinaryOperator = inPressedDigit;
                    OperationDone();
                    return;
                }
                else if (binaryOperators.Contains(lastCharacter))
                {
                    //Ako se odmah nakon unosa jednog operatora unese i drugi,
                    //npr. 2, +, -
                    currentBinaryOperator = inPressedDigit;
                    displayNumber = number;
                    return;
                }
                else
                {
                    //Ako se unesu prvi operand, operator, drugi operand, pa ponovno operator,
                    //tada se treba izracunati rezultat prve operacije nad operandima i taj
                    //rezultat postaje prvi operand za sljedeci operator; Također se mora spremiti
                    //posljednji operator, za slucaj da korisnik stisne clear, pa = kako bi se mogla
                    //ponoviti zadnja operacija
                    displayNumber = BinaryOperation(number);
                    firstOperand = displayNumber;
                    lastOperand = number;
                }
                currentBinaryOperator = inPressedDigit; 
            }

            NumberToDisplay(displayNumber);
            OperationDone();
        }

        private void ProcessInstruction(char inPressedDigit)
        {
            double number = DisplayToNumber();

            switch (inPressedDigit)
            {
                case 'P':
                    memory = number;
                    break;
                case 'G':
                    NumberToDisplay(memory);
                    break;
                case 'C':
                    Clear();
                    break;
                case 'O':
                    Reset();
                    break;
                default:
                    DisplayError();
                    break;
            }
        }

        public void Press(char inPressedDigit)
        {
            if (legalCharacters.Contains(inPressedDigit))
            {
                ProcessLegalCharacter(inPressedDigit);
            }
            else if (binaryOperators.Contains(inPressedDigit))
            {
                ProcessBinaryOperator(inPressedDigit);    
            }
            else if (unaryOperators.Contains(inPressedDigit))
            {
                ProcessUnaryOperator(inPressedDigit);
            }
            else if (instructions.Contains(inPressedDigit))
            {
                ProcessInstruction(inPressedDigit);
            }
            else
            {
                DisplayError();
            }
            lastCharacter = inPressedDigit;
        }

        public string GetCurrentDisplayState()
        {
            return display;
        }
    }
}
