﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new Burza();
        }
    }

     public class Burza : IStockExchange
     {
         Dictionary<string, Dionica> dionice = new Dictionary<string, Dionica>();
         Dictionary<string, Index> indeksi = new Dictionary<string, Index>();
         Dictionary<string, Portfelj> portfelji = new Dictionary<string, Portfelj>();

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inInitialPrice <= 0)
                 throw new StockExchangeException("Cijena ne moze biti negativna!");
             if (inNumberOfShares <= 0)
                 throw new StockExchangeException("Broj dionica ne moze biti negativan!");
             if (StockExists(inStockName))
                 throw new StockExchangeException("Dionica vec postoji!");
             Dionica dionica = new Dionica(inStockName.ToUpper(), inNumberOfShares, inInitialPrice, inTimeStamp);
             dionice.Add(inStockName.ToUpper(), dionica);
         }

         //ukloni iz portfelja i indeksa
         public void DelistStock(string inStockName)
         {
             if (StockExists(inStockName))
             {
                 foreach (Index a in indeksi.Values)
                 {
                     if (IsStockPartOfIndex(a.naziv, inStockName))
                         RemoveStockFromIndex(a.naziv, inStockName);
                 }
                 foreach (Portfelj a in portfelji.Values)
                 {
                     if (IsStockPartOfPortfolio(a.id, inStockName))
                         RemoveStockFromPortfolio(a.id, inStockName);
                 }
                 dionice.Remove(inStockName.ToUpper());
             }
             else
                 throw new StockExchangeException("Ne postoji dionica!");
         }

         public bool StockExists(string inStockName)
         {
             if (dionice.ContainsKey(inStockName.ToUpper()))
                 return true;
             else
                 return false;
         }

         public int NumberOfStocks()
         {
             return dionice.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (StockExists(inStockName))
                 dionice[inStockName.ToUpper()].addNewStockValue(inIimeStamp, inStockValue);
             else
                 throw new StockExchangeException("Ne postoji ta dionica!");
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (StockExists(inStockName))
                return dionice[inStockName.ToUpper()].getStockValue(inTimeStamp);
             else
                 throw new StockExchangeException("Ne postoji ta dionica!");
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
                return dionice[inStockName.ToUpper()].getInitialStockValue();
             else
                 throw new StockExchangeException("Ne postoji ta dionica!");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (StockExists(inStockName))
                return dionice[inStockName.ToUpper()].getLastStockValue();
             else
                 throw new StockExchangeException("Ne postoji ta dionica!");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (indeksi.ContainsKey(inIndexName.ToUpper()))
                 throw new StockExchangeException("Index je vec unesen");
             Index novi = new Index(inIndexName.ToUpper(), inIndexType);
             indeksi.Add(inIndexName.ToUpper(), novi);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && StockExists(inStockName))
                indeksi[inIndexName].AddStock(dionice[inStockName]);
             else
                 throw new StockExchangeException("Ne postoji indeks ili dionica");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (IndexExists(inIndexName) && IsStockPartOfIndex(inIndexName, inStockName))
                     indeksi[inIndexName].RemoveStock(dionice[inStockName]);
                 else
                     throw new StockExchangeException("Nije dio indeksa");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (indeksi[inIndexName].containsStock(inStockName))
                 return true;
             return false;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             return indeksi[inIndexName].calculateIndex(inTimeStamp);
         }

         public bool IndexExists(string inIndexName)
         {
             if (indeksi.ContainsKey(inIndexName))
                 return true;
             return false;
         }

         public int NumberOfIndices()
         {
             return indeksi.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             return indeksi[inIndexName].numberOfStocks();
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Index je vec unesen");
             Portfelj novi = new Portfelj(inPortfolioID);
             portfelji.Add(inPortfolioID, novi);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID) || !StockExists(inStockName) || numberOfShares<=0)
                 throw new StockExchangeException("Ovaj portfelj ne postoji na burzi ili nema dionice ili je negativan broj shareova!");
             int broj = 0;
             foreach(Portfelj p in portfelji.Values)
             {
                 broj += p.numberOfShareOfStock(inStockName);
             }
             if (broj + numberOfShares > dionice[inStockName].brojDionica)
                 throw new StockExchangeException("Iskoristena dionica");
             portfelji[inPortfolioID].AddStocks(dionice[inStockName], numberOfShares);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ovaj portfelj ne postoji na burzi!");
             portfelji[inPortfolioID].removeStock(dionice[inStockName], numberOfShares);
             if (portfelji[inPortfolioID].numberOfShareOfStock(inStockName) == 0)
                 RemoveStockFromPortfolio(inPortfolioID, inStockName);
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID) || !IsStockPartOfPortfolio(inPortfolioID,inStockName))
                 throw new StockExchangeException("Ovaj portfelj ne postoji na burzi ili ne sadrzi dionicu!");
             portfelji[inPortfolioID].removeStock(dionice[inStockName]);
         }

         public int NumberOfPortfolios()
         {
             return portfelji.Count;
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ovaj portfelj ne postoji na burzi!");
             return portfelji[inPortfolioID].numberOfStocks();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             if (portfelji.ContainsKey(inPortfolioID))
                 return true;
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (!PortfolioExists(inPortfolioID))
                 throw new StockExchangeException("Ovaj portfelj ne postoji na burzi!");
             if (portfelji[inPortfolioID].containsStock(inStockName))
                 return true;
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             if (IsStockPartOfPortfolio(inPortfolioID, inStockName))
                 return portfelji[inPortfolioID].numberOfShareOfStock(inStockName);
             else
                 throw new StockExchangeException("Nije dio portfelja");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             return portfelji[inPortfolioID].calculatePortfolioValue(timeStamp);
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             return portfelji[inPortfolioID].calculateMonthPercentage(Year, Month);
         }
     }

     public class Dionica
     {
         public string ime { get; set; }
         public long brojDionica { get; set; }
         private Dictionary<DateTime, Decimal> vrijednostDioniceUTrenutku = new Dictionary<DateTime, decimal>();

         public Dionica(string ime, long brojDionica, Decimal cijena, DateTime trenutakVazenja)
         {
             this.ime = ime;
             this.brojDionica = brojDionica;
             vrijednostDioniceUTrenutku.Add(trenutakVazenja, cijena);
         }

         public void addNewStockValue(DateTime trenutakVazenja, Decimal cijena)
         {
             if(vrijednostDioniceUTrenutku.ContainsKey(trenutakVazenja))
                 throw new StockExchangeException("Ne postoji ta dionica!");
             else
                vrijednostDioniceUTrenutku.Add(trenutakVazenja, cijena);
         }

         public Decimal getStockValue(DateTime trenutak)
         {
             Decimal vr = vrijednostDioniceUTrenutku.OrderBy(x=>x.Key).LastOrDefault(x => x.Key <= trenutak).Value;
             if (vr == 0)
                 throw new StockExchangeException("Ne postoji definirina vrijednost dionice prije tog datuma!");
             return vr;
         }

         public Decimal getInitialStockValue()
         {
             return vrijednostDioniceUTrenutku.OrderBy(x => x.Key).First(x => x.Key <= DateTime.Now).Value;
         }

         public Decimal getLastStockValue()
         {
             return vrijednostDioniceUTrenutku.OrderBy(x => x.Key).Last(x => x.Key <= DateTime.Now).Value;
         }
     }

     public class Index
     {
         public string naziv { get; set; }
         public IndexTypes tip { get; set; }
         private Dictionary<string, Dionica> dionice = new Dictionary<string, Dionica>();

         public Index(string naziv, IndexTypes tip)
         {
             this.naziv = naziv.ToUpper();
             if (tip == IndexTypes.AVERAGE || tip == IndexTypes.WEIGHTED)
                 this.tip = tip;
             else
                 throw new StockExchangeException("Neispravan indeks");
         }

         public void AddStock(Dionica d)
         {
             if (containsStock(d.ime))
                 throw new StockExchangeException("Ova dionica vec postoji u indeksu!");
             dionice.Add(d.ime, d);
         }

         public void RemoveStock(Dionica d)
         {
             if (!containsStock(d.ime))
                 throw new StockExchangeException("Ova dionica ne postoji u indeksu!");
             dionice.Remove(d.ime);
         }
 
         public bool containsStock(string name)
         {
             if (dionice.ContainsKey(name))
                 return true;
             return false;
         }

         public int numberOfStocks()
         {
             return dionice.Count;
         }

         public long numberOfShares()
         {
             long brDionica = 0;
             foreach (Dionica d in dionice.Values)
             {
                 brDionica += d.brojDionica;
             }
             return brDionica;
         }

         public Decimal calculateIndex(DateTime trenutak)
         {
             Decimal rezultat = 0;
             switch (tip)
             {
                 case IndexTypes.AVERAGE:
                     foreach (Dionica d in dionice.Values)
                     {
                         rezultat += d.getStockValue(trenutak);
                     }
                     rezultat /= numberOfStocks();
                     break;

                 case IndexTypes.WEIGHTED:
                     decimal tezinskiFaktor = 0, ukupnaVrijednostDionica = 0;
                     foreach (Dionica d in dionice.Values)
                     {
                         ukupnaVrijednostDionica += d.getStockValue(trenutak) * d.brojDionica;
                     }
                     foreach (Dionica d in dionice.Values)
                     {
                         tezinskiFaktor = d.getStockValue(trenutak) / ukupnaVrijednostDionica;
                         rezultat += d.getStockValue(trenutak)*tezinskiFaktor*d.brojDionica; 
                     }
                     break;
             }
             rezultat = Math.Round(rezultat, 3);
             return rezultat;
         }
     }

     public class Portfelj
     {
         public string id { get; set; }
         Dictionary<string, KeyValuePair<Dionica, int>> dionice = new Dictionary<string, KeyValuePair<Dionica, int>>();

         public Portfelj(string id)
         {
             this.id = id;
         }

         public void AddStocks(Dionica d, int number)
         {
             if (containsStock(d.ime))
             {
                 int trenutno = dionice[d.ime].Value;
                 dionice[d.ime] = new KeyValuePair<Dionica, int>(d, number + trenutno);
             }
             else
                 dionice.Add(d.ime, new KeyValuePair<Dionica, int>(d, number));

         }

         public void removeStock(Dionica d)
         {
             if (!containsStock(d.ime))
                 throw new StockExchangeException("Dionica ne postoji u ovom portfelju!");
             dionice.Remove(d.ime);
         }

         public void removeStock(Dionica d, int number)
         {
             if (!containsStock(d.ime))
                 throw new StockExchangeException("Dionica ne postoji u ovom portfelju!");
             else
             {
                 int trenutno = dionice[d.ime].Value;
                 if (trenutno - number > 0)
                 {
                     dionice[d.ime] = new KeyValuePair<Dionica, int>(d, trenutno - number);
                 }
                 else if (trenutno - number == 0)
                 {
                     dionice.Remove(d.ime);
                 }
                 else
                 {
                     throw new StockExchangeException("Ova dionica nema toliko share-ova!");
                 }
                 dionice[d.ime] = new KeyValuePair<Dionica, int>(d, trenutno - number);
             }

         }

         public int numberOfStocks()
         {
             return dionice.Count;
         }

         public bool containsStock(string name)
         {
             if (dionice.ContainsKey(name))
                 return true;
             return false;
         }

         public int numberOfShareOfStock(string name)
         {
             if (!containsStock(name))
             {
                 //throw new StockExchangeException("Ova dionica ne postoji u portfelju!");
                 return 0;
             }
             return dionice[name].Value;
         }

         public Decimal calculatePortfolioValue(DateTime trenutak)
         {
             Decimal rez = 0;
             foreach (var d in dionice.Values)
             {
                 rez += d.Key.getStockValue(trenutak)*numberOfShareOfStock(d.Key.ime);
             }
             rez = Math.Round(rez, 3);
             return rez;
         }

         public Decimal calculateMonthPercentage(int Year, int Month)
         {
             Decimal rez = 0;
             Decimal pocVrij = calculatePortfolioValue(new DateTime(Year, Month, 1, 0, 0, 0, 0));
             rez = pocVrij - calculatePortfolioValue(new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999));
             rez = (pocVrij - rez) / pocVrij * 100;
             rez = 100 - rez;
             rez = Math.Round(rez, 3);
             return rez*(-1);
         }

     }
}
