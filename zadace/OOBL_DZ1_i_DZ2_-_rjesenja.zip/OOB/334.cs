﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class StockExchange : IStockExchange
    {
        private Dictionary<string, Stock> stocks = new Dictionary<string, Stock>();
        private Dictionary<string, Index> indexs = new Dictionary<string, Index>();
        private Dictionary<string, Portfolio> portfolios = new Dictionary<string, Portfolio>();



        public string FindStock(string inStockName)
        {
            foreach (var x in stocks.Keys)
            {
                if (string.Compare(x, inStockName, true) == 0)
                {
                    return x;
                }
            }
            return null;
        }

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {

            //throw new NotImplementedException();

            if (StockExists(inStockName))
            {
                throw new StockExchangeException("Dionica sa tim imenom vec postoji!!");
            }
            if (inNumberOfShares <= 0 || inInitialPrice <= 0)
            {
                throw new StockExchangeException("Ne smiju biti unesene negativne vrijednosti ili 0!!");
            }
            Stock newStock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            stocks.Add(inStockName, newStock);

        }

        public void DelistStock(string inStockName)
        {
            //throw new NotImplementedException();
            if (StockExists(inStockName))
            {
                string key = FindStock(inStockName);
                stocks.Remove(key);
                foreach (var x in indexs.Keys)
                {
                    if (indexs[x].CheckStock(inStockName) == true)
                    {
                        indexs[x].RemoveStock(inStockName);
                    }
                    //RemoveStockFromIndex(x, inStockName);
                }
                foreach (var x in portfolios.Keys)
                {
                    if (portfolios[x].FindPortfolioStock(inStockName))
                    {
                        portfolios[x].RemoveStock(inStockName);
                    }
                    //RemoveStockFromPortfolio(x, inStockName);
                }
            }
            else
            {
                throw new StockExchangeException("Nije moguce obrisati dionicu koja ne postoji u burzi!!");
            }
        }

        public bool StockExists(string inStockName)
        {
            //throw new NotImplementedException();
            string key = FindStock(inStockName);
            if (key == null)
                return false;
            else
            {
                return true;
            }
        }

        public int NumberOfStocks()
        {
            return stocks.Count;
            //throw new NotImplementedException();
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            //throw new NotImplementedException();
            if (StockExists(inStockName))
            {
                string key = FindStock(inStockName);
                stocks[key].SetPrice(inIimeStamp, inStockValue);
            }
            else
            {
                throw new StockExchangeException("Nije moguce promjeniti cijenu dionice koja ne postoji u burzi!!");
            }

        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            //throw new NotImplementedException();
            if (StockExists(inStockName))
            {
                string key = FindStock(inStockName);
                return stocks[key].GetPrice(inTimeStamp);
            }
            else
            {
                throw new StockExchangeException("Nije moguce dohvatiti cijenu dionice koja ne postoji u burzi!!");
            }

        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            //throw new NotImplementedException();
            if (StockExists(inStockName))
            {
                string key = FindStock(inStockName);
                return stocks[key].GetInitialPrice();
            }
            else
            {
                throw new StockExchangeException("Nije moguce dohvatiti cijenu dionice koja ne postoji u burzi!!");
            }

        }

        public decimal GetLastStockPrice(string inStockName)
        {
            //throw new NotImplementedException();
            if (StockExists(inStockName))
            {
                string key = FindStock(inStockName);
                return stocks[key].GetLastPrice();
            }
            else
            {
                throw new StockExchangeException("Nije moguce dohvatiti cijenu dionice koja ne postoji u burzi!!");
            }
        }

        public string FindIndex(string inIndexName)
        {
            foreach (var x in indexs.Keys)
            {
                if (string.Compare(x, inIndexName, true) == 0)
                {
                    return x;
                }
            }
            return null;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            //throw new NotImplementedException();
            if (IndexExists(inIndexName))
            {
                throw new StockExchangeException("Indeks sa tim nazivom vec postoji!!");
            }
            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
            {
                throw new StockExchangeException("Pogresna vrijednost tipa indeksa!!!");
            }
            Index newIndex = new Index(inIndexName, inIndexType);
            indexs.Add(inIndexName, newIndex);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            //throw new NotImplementedException();
            string keyIndex = FindIndex(inIndexName);
            if (keyIndex == null)
            {
                throw new StockExchangeException("Ne postoji indeks sa takvim imenom!!");
            }
            if (indexs[keyIndex].CheckStock(inStockName) == true)
            {
                throw new StockExchangeException("Vec je unesena takva dionica");
            }
            string key = FindStock(inStockName);
            if (key == null)
            {
                throw new StockExchangeException("Ne postoji takva dionica u burzi!!");
            }
            indexs[keyIndex].AddStockToIndex(stocks[key]);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            //throw new NotImplementedException();
            string key = FindIndex(inIndexName);
            if (key == null)
            {
                throw new StockExchangeException("Ne postoji indeks sa takvim imenom!!");
            }
            if (indexs[key].CheckStock(inStockName) == true)
            {
                indexs[key].RemoveStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("U ovom indeksu ne postoji ta dionica!!");
            }

        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            //throw new NotImplementedException();
            string key = FindIndex(inIndexName);
            if (key == null)
            {
                throw new StockExchangeException("Ne postoji indeks sa takvim imenom!!");
            }
            return indexs[key].CheckStock(inStockName);
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            //throw new NotImplementedException();
            string key = FindIndex(inIndexName);
            if (key == null)
            {
                throw new StockExchangeException("Ne postoji indeks sa takvim imenom!!");
            }
            return indexs[key].GetValue(inTimeStamp);
        }

        public bool IndexExists(string inIndexName)
        {
            //throw new NotImplementedException();
            string key = FindIndex(inIndexName);
            if (key == null)
                return false;
            else
                return true;
        }

        public int NumberOfIndices()
        {
            //throw new NotImplementedException();
            return indexs.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            //throw new NotImplementedException();
            string key = FindIndex(inIndexName);
            if (key == null)
            {
                throw new StockExchangeException("Ne postoji indeks unesenog imena!!");
            }
            return indexs[key].GetNumberOfStocks();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            //throw new NotImplementedException();
            if (portfolios.Keys.Contains(inPortfolioID))
            {
                throw new StockExchangeException("Vec postoji taj portfolio!!");
            }
            Portfolio newPortfolio = new Portfolio(inPortfolioID);
            portfolios.Add(inPortfolioID, newPortfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                string key = FindStock(inStockName);
                if (key == null)
                {
                    throw new StockExchangeException("U burzi ne postoji ta dionica!!");
                }
                int numStock = (int)stocks[key].GetNumber();
                int total = 0;
                foreach (var x in portfolios.Keys)
                {
                    total = total + NumberOfStocksInPortfolio(x);
                }
                if (numberOfShares > numStock - total)
                {
                    throw new StockExchangeException("Nema toliko dionica!!");
                }
                Stock newStock = new Stock(stocks[key].GetName(), (long)numberOfShares, stocks[key].GetDict());
                portfolios[inPortfolioID].AddStock(newStock);
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                if (NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName) < numberOfShares)
                {
                    throw new StockExchangeException("Nema toliko te dionice u portfoliju!!");
                }
                else if (NumberOfSharesOfStockInPortfolio(inPortfolioID, inStockName) == numberOfShares)
                {
                    RemoveStockFromPortfolio(inPortfolioID, inStockName);
                }
                else
                {
                    portfolios[inPortfolioID].RemoveStock(inStockName, (long)numberOfShares);
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                if (portfolios[inPortfolioID].FindPortfolioStock(inStockName))
                {
                    portfolios[inPortfolioID].RemoveStock(inStockName);
                }
                else
                {
                    throw new StockExchangeException("Ne postoji ta dionica u odabranom portfoliju!!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }
        }

        public int NumberOfPortfolios()
        {
            //throw new NotImplementedException();
            return portfolios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                return portfolios[inPortfolioID].GetNumberOfStocks();
            }
            else
            {
                throw new StockExchangeException("Ne postoji uneseni portfolio!!");
            }

        }

        public bool PortfolioExists(string inPortfolioID)
        {
            //throw new NotImplementedException();
            if (portfolios.Keys.Contains(inPortfolioID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                return portfolios[inPortfolioID].FindPortfolioStock(inStockName);
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                if (portfolios[inPortfolioID].FindPortfolioStock(inStockName))
                {
                    return portfolios[inPortfolioID].GetNumberStock(inStockName);
                }
                else
                {
                    throw new StockExchangeException("U izabranom portfoliu ne postoji ta dionica!!");
                }
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }

        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                return portfolios[inPortfolioID].GetValue(timeStamp);
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }

        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            //throw new NotImplementedException();
            if (PortfolioExists(inPortfolioID))
            {
                DateTime startDate = new DateTime(Year, Month, 1, 00, 00, 00, 000);
                DateTime endDate = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59, 999);
                return portfolios[inPortfolioID].GetPercentChange(startDate, endDate);
            }
            else
            {
                throw new StockExchangeException("Ne postoji taj portfolio!!");
            }
        }
    }


    class Index
    {
        private string indexName;
        private IndexTypes indexType;
        private List<Stock> indexStocks = new List<Stock>();


        public Index(string inputName, IndexTypes inputType)
        {
            this.indexName = inputName;
            this.indexType = inputType;
        }

        public bool CheckStock(string inputStockName)
        {
            foreach (var x in indexStocks)
            {
                if (string.Compare(inputStockName, x.GetName(), true) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        public void AddStockToIndex(Stock addStock)
        {
            indexStocks.Add(addStock);
        }

        public int GetNumberOfStocks()
        {
            return indexStocks.Count;
        }

        public void RemoveStock(string inputStockName)
        {
            foreach (var x in indexStocks)
            {
                if (string.Compare(inputStockName, x.GetName(), true) == 0)
                {
                    indexStocks.Remove(x);
                    break;
                }
            }
        }

        public decimal GetValue(DateTime inputTime)
        {
            if (indexType == IndexTypes.AVERAGE)
            {
                return GetValueAverage(inputTime);
            }
            else if (indexType == IndexTypes.WEIGHTED)
            {
                return GetValueWeighted(inputTime);
            }
            else
            {
                throw new StockExchangeException("Krivi unos tipa indeksa!!");
            }
        }

        public decimal GetValueAverage(DateTime inputTime)
        {
            decimal value = 0;
            foreach (var x in indexStocks)
            {
                value = value + x.GetPrice(inputTime);
            }
            if (indexStocks.Count == 0)
            {
                return 0;
            }
            value = value / (decimal)indexStocks.Count;
            value = Math.Round(value, 3);
            return value;
        }

        public decimal GetValueWeighted(DateTime inputTime)
        {
            decimal value = 0;
            decimal total = 0;
            foreach (var x in indexStocks)
            {
                total = total + x.GetPrice(inputTime) * x.GetNumber();
            }
            foreach (var x in indexStocks)
            {
                value = value + x.GetPrice(inputTime) / total * x.GetNumber() * x.GetPrice(inputTime);
            }
            value = Math.Round(value, 3);
            return value;
        }

    }

    class Portfolio
    {
        private string ID;
        private List<Stock> portfolioStocks = new List<Stock>();

        public Portfolio(string inputID)
        {
            this.ID = inputID;
        }

        public int GetNumberOfStocks()
        {
            return portfolioStocks.Count;
        }

        public bool FindPortfolioStock(string inputStockName)
        {
            foreach (var x in portfolioStocks)
            {
                if (string.Compare(x.GetName(), inputStockName, true) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        public int GetNumberStock(string inputStockName)
        {
            foreach (var x in portfolioStocks)
            {
                if (string.Compare(x.GetName(), inputStockName, true) == 0)
                    return (int)x.GetNumber();
            }
            return 0;
        }

        public void AddStock(Stock inputStock)
        {
            foreach (var x in portfolioStocks)
            {
                if (string.Compare(x.GetName(), inputStock.GetName(), true) == 0)
                {
                    x.SetNumber(inputStock.GetNumber());
                    return;
                }
            }
            this.portfolioStocks.Add(inputStock);
        }

        public void RemoveStock(string inputStockName)
        {
            foreach (var x in portfolioStocks)
            {
                if (string.Compare(x.GetName(), inputStockName, true) == 0)
                {
                    portfolioStocks.Remove(x);
                    break;
                }
            }
        }

        public void RemoveStock(string inputStockName, long numberStock)
        {
            foreach (var x in portfolioStocks)
            {
                if (string.Compare(x.GetName(), inputStockName, true) == 0)
                {
                    x.SetNumber(-numberStock);
                    return;
                }
            }
        }

        public decimal GetValue(DateTime inputTime)
        {
            decimal value = 0;
            if (portfolioStocks.Count == 0)
            {
                return value;
            }
            else
            {
                foreach (var x in portfolioStocks)
                {
                    value = value + x.GetPrice(inputTime) * x.GetNumber();
                }
                value = Math.Round(value, 3);
                return value;
            }
        }

        public decimal GetPercentChange(DateTime start, DateTime end)
        {
            decimal value;
            decimal beginTotal = 0;
            decimal endTotal = 0;
            if (portfolioStocks.Count == 0)
                throw new StockExchangeException("Nema unesenih dionica za portfolio!!");
            foreach (var x in portfolioStocks)
            {
                beginTotal = beginTotal + x.GetPrice(start) * x.GetNumber();
                endTotal = endTotal + x.GetPrice(end) * x.GetNumber();
            }
            value = Math.Abs((beginTotal - endTotal) / beginTotal) * 100;
            return Math.Round(value, 3);

        }

    }

    class Stock
    {
        private string name;
        private long number;
        Dictionary<DateTime, decimal> prices = new Dictionary<DateTime, decimal>();

        public Stock(string inputName, long inputNumber, decimal inputPrice, DateTime inputDate)
        {
            this.name = inputName;
            this.number = inputNumber;
            this.prices.Add(inputDate, inputPrice);
        }

        public Stock(string inputName, long inputNumber, Dictionary<DateTime, decimal> inputPrices)
        {
            this.name = inputName;
            this.number = inputNumber;
            this.prices = inputPrices;
        }

        public void SetPrice(DateTime inTime, decimal inPrice)
        {
            if (inPrice <= 0)
            {
                throw new StockExchangeException("Krivi unos cijene!!");
            }
            if (prices.ContainsKey(inTime))
            {
                throw new StockExchangeException("Vec je unesena cijena dionice u to vrijeme!!");
            }
            prices[inTime] = inPrice;
        }


        public decimal GetPrice(DateTime inTime)
        {
            DateTime search = prices.Keys.Min();
            foreach (var x in prices.Keys)
            {
                if (x <= inTime && search <= x)
                {
                    search = x;
                }
            }
            if (inTime < search)
            {
                throw new StockExchangeException("U tom trenutku cijena dionice nije definirana");
            }
            return prices[search];
        }
        public decimal GetInitialPrice()
        {
            return prices[prices.Keys.Min()];
        }
        public decimal GetLastPrice()
        {
            return prices[prices.Keys.Max()];
        }

        public string GetName()
        {
            return name;
        }

        public long GetNumber()
        {
            return number;
        }

        public Dictionary<DateTime, decimal> GetDict()
        {
            return prices;
        }

        public void SetNumber(long inputNumber)
        {
            this.number = this.number + inputNumber;
        }

    }
}
