﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        static int MAX_ZNAMENKI = 10;

        public Kalkulator()
        {
            display = "0";
            zadnjeUpisani = '0';
            sadrziZarez = false;
            brojZnamenki = 1;
        }

        private bool sadrziZarez;
        private int brojZnamenki;
        private string display;
        private double operand1;
        private double operand2;
        private bool op1Data = false;
        private bool op2Data = false;
        private bool error = false;
        private char zadnjeUpisani = '0';
        private char operacija = 'x';

        List<char> unarniOp = new List<char>() { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' };
        List<char> binarniOp = new List<char>() { '+', '-', '*', '/' };
        List<char> memOp = new List<char>() { 'P', 'C', 'G', 'O' };

        //put, get
        private double memorija = 0;

        private string predznak = "";

        public string GetCurrentDisplayState()
        {
            if (error == true) return "-E-";
            else return this.predznak + zaokruziObradi(display);
        }

        public void Press(char inPressedDigit)
        {

            string tipPrethodnoUpisanog = "";
            if (jeMemOp(zadnjeUpisani)) tipPrethodnoUpisanog = "memOp";
            else if (jeBinarniOperator(zadnjeUpisani)) tipPrethodnoUpisanog = "binOp";
            else if (jeUnarnioperator(zadnjeUpisani)) tipPrethodnoUpisanog = "unOp";
            else if (jeZnamenka(zadnjeUpisani) || jeZarez(zadnjeUpisani)) tipPrethodnoUpisanog = "zarZnam";
            else if (zadnjeUpisani == '=') tipPrethodnoUpisanog = "jednako";

            switch (tipPrethodnoUpisanog)
            {
                case ("memOp"):
                    if (jeZarez(inPressedDigit) || jeZnamenka(inPressedDigit)) handleZarezZnamenka(inPressedDigit);
                    if (inPressedDigit == 'M') promjenaPredznaka();
                    if (jeUnarnioperator(inPressedDigit)) handleUnarni(inPressedDigit);
                    if (jeBinarniOperator(inPressedDigit)) handleBinarni(inPressedDigit);
                    if (inPressedDigit == '=') handleEq(inPressedDigit);
                    break;
                case ("binOp"):
                    if (jeZnamenka(inPressedDigit))
                    {
                        if (zadnjeUpisani != 'M') resetirajDisplay();
                        if (jeZarez(inPressedDigit) || jeZnamenka(inPressedDigit)) handleZarezZnamenka(inPressedDigit);
                    }
                    if (jeBinarniOperator(inPressedDigit)) handleBinarni(inPressedDigit);
                    if (inPressedDigit == '=') handleEq(inPressedDigit);
                    if (jeUnarnioperator(inPressedDigit))
                    {
                        if (inPressedDigit == 'M')
                        {
                            promjenaPredznaka();
                            operand1 *= -1;
                        }
                        if (jeUnarnioperator(inPressedDigit)) handleUnarni(inPressedDigit);
                    }
                    break;
                case ("unOp"):
                    if (jeZnamenka(inPressedDigit) || jeZarez(inPressedDigit))
                    {
                        if (zadnjeUpisani != 'M') resetirajDisplay();
                        handleZarezZnamenka(inPressedDigit);
                    }
                    if (jeBinarniOperator(inPressedDigit)) handleBinarni(inPressedDigit);
                    if (jeUnarnioperator(inPressedDigit))
                    {
                        if (inPressedDigit == 'M') promjenaPredznaka();
                        if (jeUnarnioperator(inPressedDigit)) handleUnarni(inPressedDigit);
                    }
                    if (inPressedDigit == '=') handleEq(inPressedDigit);
                    break;
                case ("zarZnam"):
                    if (jeZarez(inPressedDigit) || jeZnamenka(inPressedDigit)) handleZarezZnamenka(inPressedDigit);
                    if (inPressedDigit == 'M') promjenaPredznaka();
                    if (jeUnarnioperator(inPressedDigit)) handleUnarni(inPressedDigit);
                    if (jeBinarniOperator(inPressedDigit)) handleBinarni(inPressedDigit);
                    if (inPressedDigit == '=') handleEq(inPressedDigit);
                    break;
                case ("jednako"):
                    if (inPressedDigit == 'M')
                    {
                        promjenaPredznaka();
                        operand1 *= -1;
                    }
                    if (jeUnarnioperator(inPressedDigit)) handleUnarni(inPressedDigit);
                    if (inPressedDigit == '=') handleEq(inPressedDigit);
                    break;
            }

            if (jeMemOp(inPressedDigit))
            {
                if (inPressedDigit == 'C') resetirajDisplay();
                if (inPressedDigit == 'O')
                {
                    operand1 = 0;
                    operand2 = 0;
                    op1Data = false;
                    op2Data = false;
                    operacija = ' ';
                    resetirajDisplay();
                    error = false;
                    zadnjeUpisani = '0';
                }
                if (inPressedDigit == 'P') memorija = Convert.ToDouble(predznak + display);
                if (inPressedDigit == 'G')
                {
                    display = memorija.ToString();
                    srediPredznak(display);
                }
            }


            if (!(jeBinarniOperator(zadnjeUpisani) && inPressedDigit == 'M')) zadnjeUpisani = inPressedDigit;
        }

        private bool operacijaUnesena()
        {
            if (jeBinarniOperator(operacija)) return true;
            else return false;
        }

        private double izracunajOperaciju(double op1, double op2, char oper)
        {

            if (oper == '+') return zbroji(op1, op2);
            else if (oper == '-') return oduzmi(op1, op2);
            else if (oper == '*') return pomnozi(op1, op2);
            else if (oper == '/') return podijeli(op1, op2);

            else return 0;
        }

        private void upisiOperaciju(char oper)
        {
            this.operacija = oper;
        }

        private double oduzmi(double op1, double op2)
        {
            return op1 - op2;
        }

        private double zbroji(double op1, double op2)
        {
            return (double)op1 + (double)op2;
        }

        private double pomnozi(double op1, double op2)
        {
            return op1 * op2;
        }

        private double podijeli(double op1, double op2)
        {
            if (op2 == 0) error = true;
            return op1 / op2;
        }

        private string srediStr(string display)
        {

            return this.predznak + this.display;
        }

        private string zaokruziObradi(string broj)
        {
            int brZnamenki = 0;
            int brPrijeZareza = 0;
            int brIzaZareza = 0;
            bool nadenZarez = false;
            if (broj != "-E-")
            {
                double dBroj = Convert.ToDouble(broj);
                foreach (char zn in broj)
                {
                    if (jeZnamenka(zn))
                    {
                        brZnamenki++;
                        if (nadenZarez) brIzaZareza++;
                        if (!nadenZarez) brPrijeZareza++;
                    }
                    else if (jeZarez(zn)) nadenZarez = true;
                }
                if (brPrijeZareza > 10) return "-E-";
                else if (brIzaZareza + brPrijeZareza > 10) return Math.Round(dBroj, 10 - brPrijeZareza).ToString();
                else return dBroj.ToString();
            }
            else return broj;
        }

        private void unosZnamenke(char znamenka)
        {
            if (display != "0")
            {
                display += znamenka;
                brojZnamenki++;
            }
            else if (this.display == "0" && znamenka != '0') display = znamenka.ToString();

        }

        private void unosNule()
        {
            if (display != "0") this.display += "0";
        }

        private void unosZareza()
        {
            if (!this.sadrziZarez)
            {
                this.display += ",";
                this.sadrziZarez = true;
            }
        }

        private bool jeZnamenka(char znak)
        {
            if (znak >= '0' && znak <= '9') return true;
            else return false;
        }

        private void srediPredznak(string display)
        {
            if (this.display != "-E-")
            {
                double temp = Convert.ToDouble(display);
                if (temp < 0)
                {
                    temp *= -1;
                    this.predznak = "-";
                    this.display = temp.ToString();
                }
            }
        }

        private void promjenaPredznaka()
        {
            if (this.display != "0")
            {
                if (predznak == "-") predznak = "";
                else predznak = "-";
            }
        }

        private string Sinus(string predznak, string display)
        {
            double ret = Math.Sin(Convert.ToDouble(predznak + display));
            return ret.ToString();
        }
        private string Cosinus(string predznak, string display)
        {
            double ret = Math.Cos(Convert.ToDouble(predznak + display));
            return ret.ToString();
        }
        private string Tangens(string predznak, string display)
        {
            double ret = Math.Tan(Convert.ToDouble(predznak + display));
            return ret.ToString();
        }
        private string Quadrat(string predznak, string display)
        {
            double ret = Math.Pow(Convert.ToDouble(predznak + display), 2);
            return ret.ToString();
        }
        private string Root(string predznak, string display)
        {
            if (predznak != "-" && display[0] != '-')
            {
                double ret = Math.Pow(Convert.ToDouble(predznak + display), 0.5);
                return ret.ToString();
            }
            else
            {
                this.predznak = "";
                return "-E-";
            }
        }
        private string Invers(string predznak, string display)
        {
            if (display != "0" && display != "0,")
            {

                double ret = Math.Pow(Convert.ToDouble(predznak + display), -1);

                return ret.ToString();
            }
            else
            {
                this.predznak = "";
                return "-E-";
            }
        }

        private bool jeZarez(char znak)
        {
            if (znak == ',') return true;
            else return false;
        }
        private bool jeUnarnioperator(char znak)
        {
            if (unarniOp.Contains(znak)) return true;
            else return false;
        }
        private bool jeBinarniOperator(char znak)
        {
            if (binarniOp.Contains(znak)) return true;
            else return false;
        }
        private bool jeMemOp(char znak)
        {
            if (memOp.Contains(znak)) return true;
            else return false;
        }

        private void resetirajDisplay()
        {
            display = "0";
            predznak = "";
            sadrziZarez = false;
            brojZnamenki = 1;
        }

        private void handleUnarni(char inPressedDigit)
        {
            if (inPressedDigit == 'S') { display = Sinus(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
            if (inPressedDigit == 'K') { display = Cosinus(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
            if (inPressedDigit == 'T') { display = Tangens(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
            if (inPressedDigit == 'Q') { display = Quadrat(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
            if (inPressedDigit == 'R') { display = Root(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
            if (inPressedDigit == 'I') { display = Invers(predznak, display); srediPredznak(display); display = zaokruziObradi(display); }
        }
        private void handleZarezZnamenka(char inPressedDigit)
        {
            if (jeZnamenka(inPressedDigit) && brojZnamenki < MAX_ZNAMENKI + 1) unosZnamenke(inPressedDigit);
            if (jeZarez(inPressedDigit) && !sadrziZarez) unosZareza();
        }
        private void handleBinarni(char inPressedDigit)
        {
            if (op1Data == false && !operacijaUnesena())
            {
                if (!jeBinarniOperator(zadnjeUpisani))
                {
                    operand1 = Convert.ToDouble(predznak + zaokruziObradi(display));
                    op1Data = true;
                }
            }
            else if (op1Data == true && operacijaUnesena())
            {
                if (!jeBinarniOperator(zadnjeUpisani))
                {
                    operand2 = Convert.ToDouble(predznak + zaokruziObradi(display));
                    op2Data = true;
                    operand1 = izracunajOperaciju(operand1, operand2, operacija);
                    display = zaokruziObradi(operand1.ToString());
                }
            }
            upisiOperaciju(inPressedDigit);
        }
        private void handleEq(char inPressedDigit)
        {
            if (jeBinarniOperator(zadnjeUpisani) || jeMemOp(zadnjeUpisani))
            {

                operand2 = Convert.ToDouble(predznak + zaokruziObradi(display));
                op2Data = true;

                if (op1Data == true && operacijaUnesena())
                {
                    operand1 = izracunajOperaciju(operand1, operand1, operacija);
                    display = operand1.ToString();
                    srediPredznak(display);
                }
            }
            else if (jeUnarnioperator(zadnjeUpisani))
            {
                if (inPressedDigit == '=')
                {
                    if (op1Data == true && operacijaUnesena())
                    {
                        if (zadnjeUpisani != 'M')
                        {
                            operand2 = Convert.ToDouble(predznak + zaokruziObradi(display));
                            op2Data = true;
                        }
                        operand1 = izracunajOperaciju(operand1, operand2, operacija);
                        display = zaokruziObradi(operand1.ToString());
                        srediPredznak(display);
                    }
                }
            }
            else if (jeZnamenka(zadnjeUpisani) || jeZarez(zadnjeUpisani))
            {
                if (op1Data == true && operacijaUnesena())
                {
                    operand2 = Convert.ToDouble(predznak + zaokruziObradi(display));
                    op2Data = true;
                    operand1 = izracunajOperaciju(operand1, operand2, operacija);
                    display = zaokruziObradi(operand1.ToString());
                    srediPredznak(display);
                }
            }
            else if (zadnjeUpisani == '=')
            {
                if (op1Data && operacijaUnesena() && !op2Data)
                {
                    operand2 = Convert.ToDouble(predznak + zaokruziObradi(display));
                    op2Data = true;
                    operand1 = izracunajOperaciju(operand1, operand2, operacija);
                    display = zaokruziObradi(operand1.ToString());
                    srediPredznak(display);
                }
                else if (op1Data && operacijaUnesena() && op2Data)
                {
                    operand1 = izracunajOperaciju(operand1, operand2, operacija);
                    display = zaokruziObradi(operand1.ToString());
                    srediPredznak(display);
                }
            }
        }
    }

}