﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        public string displayState { get; set; }
        public Operation operationWait { get; set; }
        public bool waitFlag { get; set; }
        public bool numReady { get; set; }
        public double? Result { get; set; }
        public double? Memory { get; set; }
        
        public Kalkulator()
        {
            new Initializer();
            displayState = "0";
            waitFlag = false;
            numReady = false;
        }

        public void RefreshDisplayNumber(char digit)
        {
            if (Error() == true)
                return;
            if (waitFlag == false)
            {
                if (digit == ',')
                {
                    if (displayState.Contains(","))
                        DisplayError();
                    else
                        displayState += digit;
                }
                else
                {
                    if (displayState == "0")
                        displayState = digit.ToString();
                    else
                        displayState += digit;
                    RoundDisplay();
                }
                
            }
            else
            {
                
                if (digit == ',')
                    displayState = "0,";
                else
                    displayState = digit.ToString();
                waitFlag = false;
                numReady = true;
            }
        }

        public double GetDisplayNumber()
        {
            return double.Parse(displayState);
        }

        public bool Error()
        {
            if (displayState == "-E-")
                return true;
            else
                return false;
        }

        public void DisplayError()
        {
            displayState = "-E-";
        }

        public void HandleOperation(char code)
        {
            Operation op = OperationFactory.Instance().getOperation(code.ToString());

            op.Execute(this);
        }

        public void RoundDisplay()
        {
            double number = double.Parse(displayState);
            int length = ((int)Math.Abs(number)).ToString().Length;

            if (length > 10)
                DisplayError();
            else if (Math.Abs(number).ToString().Length > 11)
            {
                number = Math.Round(number, 10 - length);
                displayState = number.ToString();
            }
        }

        public void FormatDisplay()
        {
            if (displayState.Contains(','))
            {
                while (displayState.Last() == '0')
                    displayState = displayState.Remove(displayState.Length - 1);
                if (displayState.Last() == ',')
                    displayState = displayState.Remove(displayState.Length - 1);
            }
        }

        public void Press(char inPressedDigit)
        {
            if ("0123456789,".Contains(inPressedDigit.ToString()))
                RefreshDisplayNumber(inPressedDigit);
            else
                HandleOperation(inPressedDigit);
        }

        public string GetCurrentDisplayState()
        {
            return displayState;
        }
    }

    public class Initializer
    {
        public Initializer()
        {
            Add.start = true;
            Subtract.start = true;
            Multiply.start = true;
            Divide.start = true;
            Minus.start = true;
            Sinus.start = true;
            Kosinus.start = true;
            Quadrat.start = true;
            Root.start = true;
            Invers.start = true;
            Clear.start = true;
            Put.start = true;
            Get.start = true;
            Equal.start = true;
            On.start = true;
        } 
    }

    public class OperationFactory
    {
        private static OperationFactory _instance = null;

        Dictionary<string, object> operations = new Dictionary<string, object>();

        private OperationFactory() {}
        
        public static OperationFactory Instance()
        {
            if (_instance == null)
            {
                _instance = new OperationFactory();
            }
            return _instance;
        }

        public void registerOperation(string code, Operation op)
        {
            operations.Add(code, op);
        }

        public Operation getOperation(string code)
        {
            return (Operation)operations[code];
        }
    }

    public abstract class Operation
    {
        abstract public void Execute(Kalkulator kal);
    }


    public class Add : Operation
    {
        public static bool start;

        static Add()
        {
            OperationFactory.Instance().registerOperation("+", new Add());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            if (kal.numReady == false)
            {
                kal.Result = kal.GetDisplayNumber();
                kal.waitFlag = true;
                kal.operationWait = this;
                kal.FormatDisplay();
            }
            else if (kal.waitFlag == false)
            {
                kal.waitFlag = true;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.operationWait = this;
            }
            else
            {
                kal.Result = kal.Result + kal.GetDisplayNumber();
                kal.displayState = kal.Result.ToString();
                kal.RoundDisplay();
            }
        }
    }

    public class Subtract : Operation
    {
        public static bool start;

        static Subtract()
        {
            OperationFactory.Instance().registerOperation("-", new Subtract());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            if (kal.numReady == false)
            {
                kal.Result = kal.GetDisplayNumber();
                kal.waitFlag = true;
                kal.operationWait = this;
                kal.FormatDisplay();
            }
            else if (kal.waitFlag == false)
            {
                kal.waitFlag = true;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.operationWait = this;
            }
            else
            {
                kal.Result = kal.Result - kal.GetDisplayNumber();
                kal.displayState = kal.Result.ToString();
                kal.RoundDisplay();
            }
        }
    }

    public class Multiply : Operation
    {
        public static bool start;

        static Multiply()
        {
            OperationFactory.Instance().registerOperation("*", new Multiply());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            if (kal.numReady == false)
            {
                kal.Result = kal.GetDisplayNumber();
                kal.waitFlag = true;
                kal.operationWait = this;
                kal.FormatDisplay();
            }
            else if (kal.waitFlag == false)
            {
                kal.waitFlag = true;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.operationWait = this;
            }
            else
            {
                kal.Result = kal.Result * kal.GetDisplayNumber();
                kal.displayState = kal.Result.ToString();
                kal.RoundDisplay();
            }
        }
    }

    public class Divide : Operation
    {
        public static bool start;

        static Divide()
        {
            OperationFactory.Instance().registerOperation("/", new Divide());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            if (kal.numReady == false)
            {
                kal.Result = kal.GetDisplayNumber();
                kal.waitFlag = true;
                kal.operationWait = this;
                kal.FormatDisplay();
            }
            else if (kal.waitFlag == false)
            {
                kal.waitFlag = true;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.operationWait = this;
            }
            else
            {
                kal.Result = kal.Result / kal.GetDisplayNumber();
                kal.displayState = kal.Result.ToString();
                kal.RoundDisplay();
            }
        }
    }

    public class Minus : Operation
    {
        public static bool start;

        static Minus()
        {
            OperationFactory.Instance().registerOperation("M", new Minus());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (kal.GetDisplayNumber() * -1).ToString();
        }
    }

    public class Sinus : Operation
    {
        public static bool start;

        static Sinus()
        {
            OperationFactory.Instance().registerOperation("S", new Sinus());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (Math.Sin(kal.GetDisplayNumber())).ToString();
            kal.RoundDisplay();
        }
    }

    public class Kosinus : Operation
    {
        public static bool start;

        static Kosinus()
        {
            OperationFactory.Instance().registerOperation("K", new Kosinus());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (Math.Cos(kal.GetDisplayNumber())).ToString();
            kal.RoundDisplay();
        }
    }

    public class Tangens : Operation
    {
        public static bool start;

        static Tangens()
        {
            OperationFactory.Instance().registerOperation("T", new Tangens());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (Math.Tan(kal.GetDisplayNumber())).ToString();
            kal.RoundDisplay();
        }
    }

    public class Quadrat : Operation
    {
        public static bool start;

        static Quadrat()
        {
            OperationFactory.Instance().registerOperation("Q", new Quadrat());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (Math.Pow(kal.GetDisplayNumber(), 2)).ToString();
            kal.RoundDisplay();
        }
    }

    public class Root : Operation
    {
        public static bool start;

        static Root()
        {
            OperationFactory.Instance().registerOperation("R", new Root());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (Math.Sqrt(kal.GetDisplayNumber())).ToString();
            kal.RoundDisplay();
        }
    }

    public class Invers : Operation
    {
        public static bool start;

        static Invers()
        {
            OperationFactory.Instance().registerOperation("I", new Invers());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = (1 / kal.GetDisplayNumber()).ToString();
            kal.RoundDisplay();
        }
    }

    public class Clear : Operation
    {
        public static bool start;

        static Clear()
        {
            OperationFactory.Instance().registerOperation("C", new Clear());
        }

        public override void Execute(Kalkulator kal)
        {
            kal.displayState = "0";
        }
    }

    public class On : Operation
    {
        public static bool start;

        static On()
        {
            OperationFactory.Instance().registerOperation("O", new On());
        }

        public override void Execute(Kalkulator kal)
        {
            kal.displayState = "0";
            kal.waitFlag = false;
            kal.numReady = false;
            kal.operationWait = null;
            kal.Memory = null;
        }
    }

    public class Put : Operation
    {
        public static bool start;

        static Put()
        {
            OperationFactory.Instance().registerOperation("P", new Put());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.Memory = kal.GetDisplayNumber();
        }
    }

    public class Get : Operation
    {
        public static bool start;

        static Get()
        {
            OperationFactory.Instance().registerOperation("G", new Get());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            kal.displayState = kal.Memory.ToString();
        }
    }

    public class Equal : Operation
    {
        public static bool start;

        static Equal()
        {
            OperationFactory.Instance().registerOperation("=", new Equal());
        }

        public override void Execute(Kalkulator kal)
        {
            if (kal.Error() == true)
                return;
            if (kal.numReady == false && kal.waitFlag == false)
            {
                kal.FormatDisplay();
            }
            else if (kal.numReady == false && kal.waitFlag == true)
            {
                kal.Result = kal.GetDisplayNumber();
                kal.waitFlag = true;
                kal.numReady = true;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.waitFlag = false;
                kal.operationWait = null;
            }
            else if (kal.waitFlag == false)
            {
                kal.waitFlag = false;
                kal.operationWait.Execute(kal);
                kal.numReady = false;
                kal.operationWait = null;
            }
        }
    }

}
