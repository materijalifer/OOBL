﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string stockName { get; set; }
        public long stockAmount { get; set; }
        public decimal stockInitialPrice { get; set; }
        public DateTime stockInitDate { get; set; }
        public List<decimal> listStockPrice = new List<decimal>();
        public List<DateTime> listStockDate = new List<DateTime>();

        public Stock()
        { }

        public Stock(string name, long amount, decimal initPrice, DateTime date)
        {
            this.stockName = name;
            this.stockAmount = amount;
            this.stockInitialPrice = initPrice;
            this.stockInitDate = date;
        }      

        public Stock getStockByName(ArrayList stockList, string inStockName)
        {
            foreach (Stock stock in stockList)
            {
                if (Regex.IsMatch(stock.stockName, inStockName, RegexOptions.IgnoreCase))
                {
                    return stock;
                }
            }

            return null;
        }
    }

    public class Index
    {
        public string indexName { get; set; }
        public IndexTypes indexType { get; set; }
        public List<Stock> listIndexStock = new List<Stock>();

        public Index()
        { }

        public Index(string name, IndexTypes type)
        {
            this.indexName = name;
            this.indexType = type;
        }

        public Index getIndexByName(ArrayList indexList, string inIndexName)
        {
            foreach (Index ind in indexList)
            {
                if (Regex.IsMatch(ind.indexName, inIndexName, RegexOptions.IgnoreCase))
                {
                    return ind;
                }
            }
            return null;
        }

        public bool stockExsistInIndex(Stock inStock, Index inIndex)
        {
            bool exsist = false;
            foreach (Stock lIndexStock in listIndexStock)
            {
                if (lIndexStock.stockName == inStock.stockName)
                    exsist = true;
            }
            return exsist;
        }
    }

    public class Portfolio
    {
        public string portfolioIndex { get; set; }
        public List<Stock> listPortfolioStock = new List<Stock>();

        public Portfolio(string index)
        {
            this.portfolioIndex = index;
        }
        public Portfolio()
        { }

        public int numOfStockInPortfolio(ArrayList portList, string stockName)
        {
            int numOfStocks = 0;

            foreach(Portfolio port in portList)
            {
                foreach(Stock stockPort in port.listPortfolioStock)
                {
                    if(stockPort.stockName == stockName)
                    {
                        numOfStocks += (int)stockPort.stockAmount;
                    }
                }
            }

            return numOfStocks;
        }

        public Portfolio getPortfolioByID(ArrayList portfolioList, string inPortfolioID)
        {
            foreach (Portfolio portfolio in portfolioList)
            {
                if ((portfolio.portfolioIndex == inPortfolioID))
                {
                    return portfolio;
                }
            }
            return null;
        }
    }

    public class StockExchange : IStockExchange
    {
        Stock currentStock = new Stock();
        ArrayList stockList = new ArrayList();

        Index currentIndex = new Index();
        ArrayList indexList = new ArrayList();
        
        Portfolio currentPortfolio = new Portfolio();
        ArrayList portfolioList = new ArrayList();

        #region StockFunction

        // Dodaje dionicu s početnom cijenom na burzu
        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            Stock stock = null;

            if (inNumberOfShares > 0 && inInitialPrice > 0)
            {
                if (stockList.Count > 0)
                {
                    stock = currentStock.getStockByName(stockList, inStockName);

                    if (stock != null)
                    {
                        throw new StockExchangeException("Stock already exsists");
                    }
                    else
                    {
                        stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
                    }
                }
                else
                    stockList.Add(new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp));
            }
            else
                throw new StockExchangeException("Can't add stock, wrong input data!!!");
        }

        // Briše dionicu s burze
        public void DelistStock(string inStockName)
        {
            Stock stock = null;

            if (stockList.Count > 0)
            {
                stock = currentStock.getStockByName(stockList, inStockName);
                if (stock != null)
                {
                    StockListHasChanged(inStockName);
                    stockList.Remove(stock);
                }
                else
                    throw new StockExchangeException("Stock doesn't exsists so it can't be deleted!");
            }
            else
                throw new StockExchangeException("StockList is empty!");
        }

        public void StockListHasChanged(string inStockName)
        {
            Stock stock = null;

            if (stockList.Count > 0)
            {
                stock = currentStock.getStockByName(stockList, inStockName);
                if (stock != null)
                {
                    if (indexList.Count > 0)
                    {
                        foreach (Index index1 in indexList)
                        {
                            if(index1.listIndexStock.Count > 0)
                            {
                                foreach (Stock stock2 in index1.listIndexStock)
                                {
                                    if (inStockName == stock2.stockName)
                                    {
                                        RemoveStockFromIndex(index1.indexName, inStockName);
                                        foreach (Portfolio port in portfolioList)
                                        {
                                            if (port.listPortfolioStock.Count > 0)
                                            {
                                                foreach (Stock stock3 in port.listPortfolioStock)
                                                {
                                                    if (inStockName == stock3.stockName)
                                                    {
                                                        RemoveStockFromPortfolio((string)port.portfolioIndex, inStockName);
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    else if (portfolioList.Count > 0)
                    {
                        foreach (Portfolio port in portfolioList)
                        {
                            if (port.listPortfolioStock.Count > 0)
                            {
                                foreach (Stock stock3 in port.listPortfolioStock)
                                {
                                    if (inStockName == stock3.stockName)
                                    {
                                        RemoveStockFromPortfolio((string)port.portfolioIndex, inStockName);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Provjerava postoji li tražena dionica na burzi
        public bool StockExists(string inStockName)
        {
            Stock stock = null;
            bool exsist = false;

            if (stockList.Count > 0)
            {
                stock = currentStock.getStockByName(stockList, inStockName);
                if (stock != null)
                    exsist = true;
                else
                    exsist = false;
            }
            else
                throw new StockExchangeException("StockList is empty!");

            return exsist;
        }

        // Vraća broj dionica na burzi
        public int NumberOfStocks()
        {
            int nStock = 0;
            nStock = stockList.Count;

            return nStock;
        }
        
        // Postavlja cijenu dionice za određeno vrijeme
        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            bool addPrice = false;
            Stock stockAdd = null;
            Stock stock = new Stock();

            if (stockList.Count > 0)
            {
                if (inStockValue > 0)
                {
                    stock = stock.getStockByName(stockList, inStockName);
                    if(stock != null)
                    {
                        if (stock.listStockDate.Count() != 0)
                        {
                            foreach (DateTime dat in stock.listStockDate)
                            {
                                if (dat != inIimeStamp)
                                {
                                    addPrice = true;
                                    stockAdd = stock;
                                }
                            }
                        }
                        else
                        {
                            addPrice = true;
                            stockAdd = stock;
                        }  
                    }
                }
                else
                    throw new StockExchangeException("StockValue is wrong!");
            }
            else
                throw new StockExchangeException("StockList is empty!");

            if (addPrice)
            {
                stockAdd.listStockPrice.Add(inStockValue);
                stockAdd.listStockDate.Add(inIimeStamp);
                SetPriceChanged(inStockName, inIimeStamp, inStockValue);
            }
            else
                throw new StockExchangeException("Price for time already exsists!");
        }

        public void SetPriceChanged(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock1 = null;
            int inNumOfShares = 0;

            if (stockList.Count > 0)
            {
                stock1 = currentStock.getStockByName(stockList, inStockName);
                if (stock1 != null)
                {
                    if (indexList.Count > 0)
                    {
                        foreach (Index index1 in indexList)
                        {
                            if (index1.listIndexStock.Count > 0)
                            {
                                foreach (Stock stock2 in index1.listIndexStock)
                                {
                                    if (inStockName == stock2.stockName)
                                    {
                                        RemoveStockFromIndex(index1.indexName, inStockName);
                                        AddStockToIndex(index1.indexName, inStockName);
                                        foreach (Portfolio port in portfolioList)
                                        {
                                            if (port.listPortfolioStock.Count > 0)
                                            {
                                                foreach (Stock stock3 in port.listPortfolioStock)
                                                {
                                                    if (inStockName == stock3.stockName)
                                                    {
                                                        inNumOfShares = (int)stock3.stockAmount;
                                                        RemoveStockFromPortfolio((string)port.portfolioIndex, inStockName);
                                                        AddStockToPortfolio(port.portfolioIndex, inStockName, inNumOfShares); 
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dohvaća cijenu dionice za neko vrijeme
        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = new Stock();
            decimal price = 0;
            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;

            fileDate = inTimeStamp;       //set to the file date
            Stock stockMin = (Stock)stockList[0];

                if (stockMin.listStockDate.Count > 0)
                {
                    min = Math.Abs(fileDate.Ticks - stockMin.listStockDate[0].Ticks);

                    stock = stock.getStockByName(stockList, inStockName);
                    
                    if (stock != null)
                    {
                        foreach (DateTime date in stock.listStockDate)
                        {
                            diff = Math.Abs(fileDate.Ticks - date.Ticks);
                            if (diff <= min)
                            {
                                min = diff;
                                closestDate = date;
                            }
                            indexOfDate = stock.listStockDate.IndexOf(closestDate);
                        }
                    }

                    foreach (decimal pr in stock.listStockPrice)
                    {
                        if (stock.listStockPrice.IndexOf(pr) == indexOfDate)
                            price = pr;
                    }
                    
                }
                else
                {
                    price = currentStock.stockInitialPrice;
                    return price;
                }

            return price;
        }

        // Dohvaća početnu cijenu dionice
        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = new Stock();
            decimal initPrice = 0;

            if (stockList.Count > 0)
            {
                stock = stock.getStockByName(stockList, inStockName);
                if (stock != null)
                {
                    initPrice = stock.stockInitialPrice;
                }                
            }
            else
                throw new StockExchangeException("StockList is empty!");

            return initPrice;

            //throw new NotImplementedException();
        }

        // Dohvaća zadnju cijenu dionice
        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = new Stock();
            int indexOfLastDate;
            decimal price = 0;

            if (stockList.Count > 0)
            {
                stock = stock.getStockByName(stockList, inStockName);
                if (stock != null)
                {
                    if (stock.listStockDate.Count > 0)
                    {
                        indexOfLastDate = stock.listStockDate.Count;
                        price = stock.listStockPrice.Last();
                    }
                    else
                        price = stock.stockInitialPrice;
                }
            }
            else
                throw new StockExchangeException("StackList is empty!!!");

            return price;

            //throw new NotImplementedException();
        }
        
        #endregion

        #region IndexFunctions
        
        //stvara novi indeks na burzi
        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            bool addNew = false;

            if(inIndexType == IndexTypes.AVERAGE || inIndexType == IndexTypes.WEIGHTED)
            {
                if (indexList.Count > 0)
                {
                    foreach (Index index in indexList)
                    {
                        if (Regex.IsMatch(index.indexName, inIndexName, RegexOptions.IgnoreCase))
                        {
                            throw new StockExchangeException("Index already exsists!!!");
                        }
                        else
                        {
                            addNew = true;
                        }
                    }
                }
                else
                {
                    indexList.Add(new Index(inIndexName, inIndexType));
                }

                if(addNew)
                    indexList.Add(new Index(inIndexName, inIndexType));
            }
            else
                throw new StockExchangeException("Wrong index import data!!!");
        }

        //dodaje dionicu u indeks
        public void AddStockToIndex(string inIndexName, string inStockName)
        {    
            Stock stockForIndex = null;
            Index index = new Index();
            bool add = false;

            if (indexList.Count > 0 && stockList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);
                if (index != null)
                {
                    if (StockExists(inStockName))
                    {
                        stockForIndex = currentStock.getStockByName(stockList, inStockName);

                        if (stockForIndex != null)
                        {
                            if (index.listIndexStock.Count > 0)
                            {
                                if (!index.stockExsistInIndex(stockForIndex, index))
                                {
                                    add = true;
                                }
                                else
                                    throw new StockExchangeException("Duplicate!");
                            }
                            else
                            {
                                add = true;
                            }
                        }
                    }                    
                    else
                        throw new StockExchangeException("Stock doesn't exsists!");
                }
                else
                    throw new StockExchangeException("Index doesn't exsist");                
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");
                        
            if(add)
                index.listIndexStock.Add(stockForIndex);
        }

        //briše dionicu iz indeksa
        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Stock stockForIndex;
            Index index = new Index();
            
            if (indexList.Count > 0 && stockList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);

                if (index != null)
                {
                    stockForIndex = currentStock.getStockByName(stockList, inStockName);

                    if(stockForIndex != null)
                        index.listIndexStock.Remove(stockForIndex);
                    else
                        throw new StockExchangeException("There is no stock with required name");
                }            
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");
        }

        //provjerava je li dionica u indeksu
        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Stock stockForIndex;
            Index index = new Index();
            bool partOf = false;

            if (indexList.Count > 0 && stockList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);
                if (index != null)
                {
                    stockForIndex = currentStock.getStockByName(stockList, inStockName);

                    if (stockForIndex != null)
                    {
                        if (index.listIndexStock.Contains(stockForIndex))
                        {
                            partOf = true;
                            return partOf;
                        }
                        else
                            partOf = false;
                    }
                }                
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");

            return partOf;
        }

        //dohvaća vrijednost indeksa
        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal averageValue = 0;
            decimal weightedValue = 0;
            int nAverage = 0;
            decimal addStocks = 0;
            decimal sumOfStock = 0;
            decimal divi = 0;
            bool w = false;
            bool a = false;
            decimal returnValue;
            Stock stockMin = null;
            Index index = new Index();

            List<decimal> array = new List<decimal>();
            int j = 0;

            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;

            fileDate = inTimeStamp;

            if (indexList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);

                if (index != null)
                {
                    if (index.listIndexStock.Count > 0)
                    {
                        if (index.indexType == IndexTypes.WEIGHTED)
                            w = true;
                        else if (index.indexType == IndexTypes.AVERAGE)
                            a = true;
                        if (index.listIndexStock.Count > 0)
                        {
                            stockMin = (Stock)index.listIndexStock[0];

                            foreach (Stock stock1 in index.listIndexStock)
                            {
                                if (stock1.listStockDate.Count > 0)
                                {
                                    min = Math.Abs(fileDate.Ticks - stockMin.listStockDate[0].Ticks);
                                    foreach (DateTime date in stock1.listStockDate)
                                    {
                                        diff = Math.Abs(fileDate.Ticks - date.Ticks);

                                        if ((inTimeStamp.Ticks - stockMin.stockInitDate.Ticks) < (Math.Abs(inTimeStamp.Ticks - stock1.listStockDate[0].Ticks)))
                                        {
                                            for (int i = 0; i < stock1.stockAmount; i++)
                                            {
                                                averageValue += stock1.stockInitialPrice;
                                                nAverage++;

                                                addStocks = stock1.stockAmount * stock1.stockInitialPrice;
                                                sumOfStock += addStocks;
                                                array.Add(stock1.stockInitialPrice);

                                                foreach (decimal p in array)
                                                {
                                                    divi = p / sumOfStock;
                                                    weightedValue += p * divi;
                                                }

                                                if (w)
                                                    returnValue = Math.Round(weightedValue, 3);
                                                else
                                                    returnValue = Math.Round(averageValue, 3);

                                                return returnValue;
                                            }
                                        }

                                        if (diff <= min)
                                        {
                                            min = diff;
                                            closestDate = date;
                                        }
                                        indexOfDate = stock1.listStockDate.IndexOf(closestDate);
                                    }

                                    foreach (decimal pr in stock1.listStockPrice)
                                    {
                                        if (stock1.listStockPrice.IndexOf(pr) == indexOfDate)
                                        {
                                            averageValue += pr;
                                            nAverage++;

                                            addStocks = stock1.stockAmount * pr;
                                            sumOfStock += addStocks;
                                            for (int i = 0; i < stock1.stockAmount; i++)
                                            {
                                                array.Add(pr);
                                            }
                                        }
                                    }
                                }

                                else
                                {
                                    j++;
                                    if (j < index.listIndexStock.Count)
                                    {
                                        stockMin = (Stock)index.listIndexStock[j];
                                    }
                                    averageValue += stock1.stockInitialPrice;
                                    nAverage++;

                                    addStocks = stock1.stockAmount * (decimal)stock1.stockInitialPrice;
                                    sumOfStock += addStocks;
                                    for (int i = 0; i < stock1.stockAmount; i++)
                                    {
                                        array.Add(stock1.stockInitialPrice);
                                    }
                                }
                            }
                        }

                        else
                            return 0;

                        foreach (decimal p in array)
                        {
                            divi = p / sumOfStock;
                            weightedValue += p * divi;
                        }
                    }
                    else
                        return 0;
                }
            }

            averageValue = averageValue / nAverage;
            if (w)
                returnValue = Math.Round(weightedValue, 3);
            else
                returnValue = Math.Round(averageValue, 3);

            return returnValue;
        }

        //provjerava postoji li traženi indeks na burzi
        public bool IndexExists(string inIndexName)
        {
            Index index = new Index();
            bool exsists = false; 

            if (indexList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);
                if (index != null)
                {
                    exsists = true;
                    return exsists;
                }
                else
                    exsists = false;
            }
            else
                throw new StockExchangeException("IndexList or StockList is empty!!!");

            return exsists;
        }

        //dohvaća broj indeksa na burzi
        public int NumberOfIndices()
        {
            int nIndex = 0;
            nIndex = indexList.Count;

            return nIndex;
        }

        //dohvaća broj dionica u traženom indeksu
        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = new Index();
            int nStockInIndex = 0;

            if (indexList.Count > 0)
            {
                index = index.getIndexByName(indexList, inIndexName);
                if (index != null)
                {
                    if (index.listIndexStock.Count > 0)
                    {
                        foreach (Stock stock in index.listIndexStock)
                        {
                            nStockInIndex++;
                        }
                    }
                    else
                        return 0;
                }
            }
            else
                throw new StockExchangeException("IndexList is empty!!!");

            return nStockInIndex;
        }

        #endregion

        #region PortfolioFunctions

        // Stvara novi portfelj na burzi
        public void CreatePortfolio(string inPortfolioID)
        {
            Portfolio portfolio = new Portfolio();
            bool addNew = false;

            if (portfolioList.Count > 0)
            {
                portfolio = portfolio.getPortfolioByID(portfolioList, inPortfolioID);
                if (portfolio != null)
                {
                    throw new StockExchangeException("Portfolio already exsists!!!");
                }
                else
                {
                    addNew = true;
                }
            }
            else
            {
                portfolioList.Add(new Portfolio(inPortfolioID));
            }

            if (addNew)
                portfolioList.Add(new Portfolio(inPortfolioID));
 
        }

        // Dodaje određeni broj dionica u portfelju 
        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock portStock = null;
            Stock portStock1 = null;
            Portfolio porfo = null;
            Portfolio portfolio = new Portfolio();
            int numShare;
            int numOnStock = 0;
            int newNumShare = 0;
            int shareInSpecificPort = 0;
            Stock newStock = new Stock();
            bool addStock = false;
            bool removeStock = false;
            bool ex = false;

            Portfolio po = new Portfolio(inPortfolioID);

            if (portfolioList.Count > 0 && numberOfShares > 0)
            {
                portfolio = portfolio.getPortfolioByID(portfolioList, inPortfolioID);
                if (portfolio != null)
                {
                    // Provjerava koliko je dionica sa određenim imenom u svim portfolijima
                    numShare = currentPortfolio.numOfStockInPortfolio(portfolioList, inStockName);

                    //Provjerava koliko ima dionica sa određenim imenom na burzi
                    if (stockList.Count > 0)
                    {
                        portStock1 = currentStock.getStockByName(stockList, inStockName);
                        if (portStock1 != null)
                        {
                            numOnStock = (int)portStock1.stockAmount;
                        }
                    }

                    if ((numberOfShares + numShare) > numOnStock)
                    {
                        throw new StockExchangeException("There is no more stocks");
                    }
                    else
                    {
                        if (stockList.Count > 0)
                        {
                            portStock = currentStock.getStockByName(stockList, inStockName);
                            if (portStock != null)
                            {
                                porfo = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);

                                if (porfo != null)
                                {
                                    if (porfo.listPortfolioStock.Count > 0)
                                    {
                                        foreach (Stock stockinPor in porfo.listPortfolioStock)
                                        {
                                            if (stockinPor.stockName == inStockName)
                                            {
                                                shareInSpecificPort = (int)stockinPor.stockAmount;
                                                newNumShare = (int)stockinPor.stockAmount;
                                                newStock = stockinPor;
                                                removeStock = true;
                                                //porfo.PortfolioStockList.Remove(stockinPor);
                                                newNumShare += numberOfShares;
                                                newStock.stockName = portStock.stockName;
                                                newStock.stockAmount = numberOfShares + shareInSpecificPort;
                                                newStock.listStockDate = portStock.listStockDate;
                                                newStock.stockInitDate = portStock.stockInitDate;
                                                newStock.stockInitialPrice = portStock.stockInitialPrice;
                                                newStock.listStockPrice = portStock.listStockPrice;
                                                addStock = true;
                                            }
                                            else
                                            {
                                                newStock.stockName = portStock.stockName;
                                                newStock.stockAmount = numberOfShares + shareInSpecificPort;
                                                newStock.listStockDate = portStock.listStockDate;
                                                newStock.stockInitDate = portStock.stockInitDate;
                                                newStock.stockInitialPrice = portStock.stockInitialPrice;
                                                newStock.listStockPrice = portStock.listStockPrice;
                                                addStock = true;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        newStock.stockName = portStock.stockName;
                                        newStock.stockAmount = numberOfShares;
                                        newStock.listStockDate = portStock.listStockDate;
                                        newStock.stockInitDate = portStock.stockInitDate;
                                        newStock.stockInitialPrice = portStock.stockInitialPrice;
                                        newStock.listStockPrice = portStock.listStockPrice;
                                        addStock = true;
                                    }
                                }
                                else
                                    throw new StockExchangeException("Portfolio doesn't exsists");
                            }
                            else
                                throw new StockExchangeException("Stock doesn't exsits on stockMarket");
                        }
                        else
                            throw new StockExchangeException("StockList is empty!");
                    }
                }
                else
                    throw new StockExchangeException("Portfolio doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if(addStock && removeStock == false)
                porfo.listPortfolioStock.Add(newStock);
            else if (addStock && removeStock)
            {
                porfo.listPortfolioStock.Remove(newStock);
                porfo.listPortfolioStock.Add(newStock);
            }
        }

        // Briše određeni broj dionica iz portfelja 
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock portStock = null;
            Portfolio porfo = null;
            int numShare;
            int newNumShare = 0;
            Stock newStock = new Stock();
            Stock removeStock = null;
            bool removeStockBool = false;

            if (portfolioList.Count > 0)
            {
                numShare = currentPortfolio.numOfStockInPortfolio(portfolioList, inStockName);
                if (numberOfShares >= numShare)
                {
                    throw new StockExchangeException("There is no more stocks");
                }
                else
                {
                    if (stockList.Count > 0)
                    {
                        portStock = currentStock.getStockByName(stockList, inStockName);
                        if (portStock != null)
                        {
                            porfo = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
                            if (porfo != null)
                            {
                                if (porfo.listPortfolioStock.Count > 0)
                                {
                                    foreach (Stock stockinPor in porfo.listPortfolioStock)
                                    {
                                        if (stockinPor.stockName == inStockName)
                                        {
                                            newNumShare = (int)stockinPor.stockAmount - numberOfShares;
                                            removeStockBool = true;
                                            //porfo.PortfolioStockList.Remove(stockinPor);
                                            removeStock = stockinPor;
                                        }
                                    }
                                }
                                else
                                {
                                    throw new StockExchangeException("No stock in portfolio");
                                }
                            }
                            else
                                throw new StockExchangeException("Portfolio doesn't exsists");
                        }
                        else
                            throw new StockExchangeException("Stock doesn't exsits on stockMarket");
                    }
                    else
                        throw new StockExchangeException("StockList is empty!");
                }
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if (removeStockBool)
            {
                if (newNumShare == 0)
                    porfo.listPortfolioStock.Remove(removeStock);
                else
                {
                    newStock.stockAmount = newNumShare;
                    newStock.listStockDate = removeStock.listStockDate;
                    newStock.stockInitDate = removeStock.stockInitDate;
                    newStock.stockInitialPrice = removeStock.stockInitialPrice;
                    newStock.stockName = removeStock.stockName;
                    newStock.listStockPrice = removeStock.listStockPrice;
                    porfo.listPortfolioStock.Remove(removeStock);
                    porfo.listPortfolioStock.Add(newStock);
                }
            }
        }

        // Briše dionicu iz portfelja 
        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio porfo = null;

            Stock removeStock = null;
            bool removeStockBool = false;

            if (portfolioList.Count > 0)
            {
                porfo = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
                if (porfo != null)
                {
                    if (porfo.listPortfolioStock.Count > 0)
                    {
                        foreach (Stock stock1 in porfo.listPortfolioStock)
                        {
                            if (Regex.IsMatch(stock1.stockName, inStockName, RegexOptions.IgnoreCase))
                            {
                                removeStock = stock1;
                                removeStockBool = true;
                            }
                        }
                    }
                    else
                        throw new StockExchangeException("Portfolio stackList is empty");
                }
                else
                    throw new StockExchangeException("Stock doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            if (removeStockBool)
            {
                porfo.listPortfolioStock.Remove(removeStock);
            }
            
        }

        // Dohvaća broj portfelja na burzi
        public int NumberOfPortfolios()
        {
            int numOfPortfolios = 0;
            numOfPortfolios = portfolioList.Count;

            return numOfPortfolios;
        }

        // Dohvaća broj dionica u traženom portfelju
        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int numOfStocks = 0;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
                numOfStocks = portf.listPortfolioStock.Count;
            }
            else
                return 0;

            return numOfStocks;
        }

        // Provjerava postoji li traženi portfelj na burzi
        public bool PortfolioExists(string inPortfolioID)
        {
            bool exsists;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
                if (portf != null)
                {
                    exsists = true;
                }
                else
                    exsists = false;
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            return exsists;
        }

        // Provjerava nalazi li se dionica u portfelju
        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            bool exsists = false;
            Portfolio portf = null;

            if (portfolioList.Count > 0)
            {
                portf = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
                if (portf != null)
                {
                    foreach (Stock stock1 in portf.listPortfolioStock)
                    {
                        if (Regex.IsMatch(stock1.stockName, inStockName, RegexOptions.IgnoreCase))
                        {
                            exsists = true;
                            return true;
                        }
                        else
                            exsists = false;
                    }
                }
                else
                    throw new StockExchangeException("Portfolio doesn't exsists!");
            }
            else
                throw new StockExchangeException("PortfolioList is empty!");

            return exsists;
        }

        // Dohvaća broj dionice u traženom portfelj
        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            int numOfStockShares = 0;
            Portfolio portf = null;

            portf = currentPortfolio.getPortfolioByID(portfolioList, inPortfolioID);
            if (portf != null)
            {
                foreach (Stock stock1 in portf.listPortfolioStock)
                {
                    if (Regex.IsMatch(stock1.stockName, inStockName, RegexOptions.IgnoreCase))
                    {
                        numOfStockShares = (int)stock1.stockAmount;
                        return numOfStockShares;
                    }
                }
            }
            else
                throw new StockExchangeException("Portfolio doesn't exsists!");

            return numOfStockShares;
        }

        // Dohvaća vrijednost portfelja u određenom trenutku
        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            decimal sum = 0;
            Stock stockMin = null;

            List<decimal> array = new List<decimal>();
            int j = 0;

            DateTime fileDate, closestDate;
            closestDate = DateTime.MinValue;
            long min = 0;
            long diff;
            int indexOfDate = 0;
            fileDate = timeStamp;
            bool cal = false;
            bool changed = false;
            bool exs = false;

            foreach (Portfolio portfolio in portfolioList)
            {
                if (portfolio.portfolioIndex == inPortfolioID)
                {
                    exs = true;
                    if (portfolio.listPortfolioStock.Count > 0)
                    {
                        if (portfolio.listPortfolioStock[j].listStockDate.Count > 0)
                        {
                            stockMin = (Stock)portfolio.listPortfolioStock[j];
                            cal = true;
                        }

                        foreach (Stock stock1 in portfolio.listPortfolioStock)
                        {
                            if (changed)
                            {
                                stockMin = (Stock)portfolio.listPortfolioStock[j];
                                if (stockMin.listStockDate.Count > 0)
                                    cal = true;
                            }

                            if (cal)
                            {
                                min = Math.Abs(fileDate.Ticks - stockMin.listStockDate[0].Ticks);
                                foreach (DateTime date in stock1.listStockDate)
                                {
                                    diff = Math.Abs(fileDate.Ticks - date.Ticks);

                                    if ((timeStamp.Ticks - stockMin.stockInitDate.Ticks) < (Math.Abs(timeStamp.Ticks - stock1.listStockDate[0].Ticks)))
                                    {
                                        closestDate = stock1.stockInitDate;
                                        for (int i = 0; i < stock1.stockAmount; i++)
                                            sum += stock1.stockInitialPrice;

                                        return sum;
                                    }
                                    else if (diff <= min)
                                    {
                                        min = diff;
                                        closestDate = date;
                                    }
                                    indexOfDate = stock1.listStockDate.IndexOf(closestDate);
                                }

                                foreach (decimal pr in stock1.listStockPrice)
                                {
                                    if (stock1.listStockPrice.IndexOf(pr) == indexOfDate)
                                    {
                                        for (int i = 0; i < stock1.stockAmount; i++)
                                            sum += pr;
                                    }
                                }

                                cal = false;
                                changed = false;
                            }

                            else
                            {
                                j++;
                                for (int k = 0; k < stock1.stockAmount; k++)
                                    sum += stock1.stockInitialPrice;
                                changed = true;
                            }
                        }
                    }
                    else
                        return 0;
                }
            }

            if(exs == false)
                throw new StockExchangeException("Portfolio doesn't exsists");
            
            return sum;
        }

        // Dohvaća mjeseću promjenu vrijednosti portfelja
        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = new Portfolio();
            List<decimal> listOfMonthPrices = new List<decimal>();
            bool calculate = false;
            bool noAdd = false;
            decimal cijena = 0;
            decimal cijenaPrvog = 0;
            decimal cijenaZadnjeg = 0;
            int index = 0;
            decimal pricePrevMonth = 0;

            portfolio = portfolio.getPortfolioByID(portfolioList, inPortfolioID);
            if (portfolio != null)
            {
                if (portfolio.listPortfolioStock.Count > 0)
                {
                    foreach (Stock stock in portfolio.listPortfolioStock)
                    {
                        foreach (DateTime dt in stock.listStockDate)
                        {
                            if (dt.Month == Month && dt.Year == Year)
                            {
                                if (dt.Day != 1)
                                {
                                    noAdd = true;
                                }
                                listOfMonthPrices.Add(stock.listStockPrice[index]);
                                calculate = true;
                            }
                            else
                            {                                
                                pricePrevMonth = stock.listStockPrice[index];
                            }
                            index++;
                        }
                        index = 0;

                        if (noAdd)
                        {
                            if (listOfMonthPrices.Count == 1)
                            {
                                if (pricePrevMonth != 0)
                                {
                                    cijenaPrvog += pricePrevMonth;
                                }
                                else
                                {
                                    cijenaPrvog += stock.stockInitialPrice;
                                }
                            }
                        }

                        if (calculate)
                        {
                            if (!noAdd)
                            {
                                cijenaPrvog += listOfMonthPrices[0];
                            }
                            cijenaZadnjeg += listOfMonthPrices[listOfMonthPrices.Count - 1];
                        }

                        noAdd = false;
                        listOfMonthPrices.Clear();
                    }
                }            
            }
            else
                throw new StockExchangeException("Portfolio doesn't exsists!");
            if (calculate)
            {
                cijena = (Math.Abs(cijenaZadnjeg - cijenaPrvog) / cijenaPrvog) * 100;
            }

            return cijena;
        }

        #endregion
    }
}