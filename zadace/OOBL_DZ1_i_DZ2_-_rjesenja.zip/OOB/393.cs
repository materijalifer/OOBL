﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

    public class Stock
    {
        public string StockName { get; set; }
        public long NumberOfShares { get; set; }
        public long SharesInPortfolio { get; set; }
        public decimal InitialPrice { get; set; }
        public DateTime TimeStamp { get; set; }
        public bool inIndex { get; set; }

        public Stock(string stockName, long numberOfShares, decimal initialPrice, DateTime timeStamp)
        {
            this.StockName = stockName;
            this.NumberOfShares = numberOfShares;
            this.SharesInPortfolio = 0;
            this.InitialPrice = initialPrice;
            this.TimeStamp = timeStamp;
            this.inIndex = false;
        }
    }

    public class StockTime
    {
        public string StockName { get; set; }
        public decimal Price { get; set; }
        public DateTime TimeStamp { get; set; }

        public StockTime(string stockName, decimal price, DateTime timeStamp)
        {
            StockName = stockName;
            Price = price;
            TimeStamp = timeStamp;
        }
    }

    public class Index
    {
        public string IndexName { get; set; }
        public IndexTypes Tip { get; set; }
        public List<Stock> StockList { get; set; }
        private decimal IndexValue { get; set; }

        public Index(string indexName, IndexTypes tip)
        {
            IndexName = indexName;
            Tip = tip;
            StockList = new List<Stock>();
            IndexValue = 0;
        }
    }

    public class Portfolio
    {
        public string PortfolioID { get; set; }
        public List<Stock> StockList { get; set; }

        public Portfolio(string ID)
        {
            PortfolioID = ID;
            StockList = new List<Stock>();
        }
    }

    public class StockExchange : IStockExchange
    {
        // Kreiranje nove liste dionica
        public List<Stock> Burza = new List<Stock>();

        // Kreiranje "timelinea" - liste dionica s pripadnim cijenama i vremenima u kojima vrijede
        public List<StockTime> BurzaVrijeme = new List<StockTime>();

        // Kreiranje nove liste dionica
        public List<Index> Index = new List<Index>();

        // Kreiranje nove liste portfelja
        public List<Portfolio> Portfolio = new List<Portfolio>();

        private int _stockNumber;
        private int _indexNumber;
        private int _portfolioNumber;

        /// <summary>
        /// Funkcija za sortiranje timelinea dionica
        /// </summary>
        /// <param name="that">Timeline cijena svih dionica</param>
        public void SortTimeline(List<StockTime> that)
        {
            that.Sort((ps1, ps2) => DateTime.Compare(ps1.TimeStamp, ps2.TimeStamp));
        }


        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {

            if (StockExists(inStockName.ToLower()))
                throw new StockExchangeException("Dionica postoji u sustavu");

            if (inInitialPrice <= 0)
                throw new StockExchangeException("Negativna cijena");

            if (inNumberOfShares <= 0)
                throw new StockExchangeException("Negativan broj dionica");

            Stock dionica = new Stock(inStockName.ToLower(), inNumberOfShares, inInitialPrice, inTimeStamp);
            StockTime dionicaVrijeme = new StockTime(inStockName.ToLower(), inInitialPrice, inTimeStamp);

            // Dodavanje dionica na burzu i u timeline
            Burza.Add(dionica);
            BurzaVrijeme.Add(dionicaVrijeme);

            // Sortiranje liste dionica na timelineu
            SortTimeline(BurzaVrijeme);
        }

        public void DelistStock(string inStockName)
        {
            bool exists = StockExists(inStockName);
            int stockCount = NumberOfStocks();

            if (stockCount == 0)
                throw new StockExchangeException("Burza je prazna!");

            // ukoliko postoji -> obriši dionicu
            if (exists)
            {
                Stock dionica = Burza.First(item => item.StockName == inStockName.ToLower());
                StockTime dionicaVrijeme = BurzaVrijeme.First(item2 => item2.StockName == inStockName.ToLower());

                RemoveStockFromAllIndicies(dionica.StockName.ToLower());
                Burza.Remove(dionica);
                BurzaVrijeme.Remove(dionicaVrijeme);
            }
            // ukoliko ne postoji -> baci iznimku
            else
            {
                throw new StockExchangeException("Dionica ne postoji u sustavu");
            }
        }

        public bool StockExists(string inStockName)
        {
            bool exists = Burza.Any(item => item.StockName == inStockName.ToLower());
            return exists;
        }

        public int NumberOfStocks()
        {
            _stockNumber = Burza.Count;
            return _stockNumber;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            bool exists = StockExists(inStockName.ToLower());

            if (exists)
            {
                StockTime dionicaVrijeme = new StockTime(inStockName.ToLower(), inStockValue, inIimeStamp);
                BurzaVrijeme.Add(dionicaVrijeme);
            }
            else
            {
                throw new StockExchangeException("Dionica ne postoji");
            }
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            decimal retPrice = 0;
            bool exists = Burza.Any(item => item.StockName == inStockName.ToLower());

            if (!exists)
                throw new StockExchangeException("Dionica ne postoji");

            // kretanje po sortiranom timelineu dionica
            foreach (StockTime item in BurzaVrijeme.Where(item => item.StockName == inStockName.ToLower()))
            {
                int result = DateTime.Compare(inTimeStamp, item.TimeStamp);
                if (result >= 0)
                {
                    retPrice = item.Price;
                }
            }

            return retPrice;
        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            decimal retPrice = 0;

            foreach (Stock item in Burza.Where(item => item.StockName == inStockName.ToLower()))
            {
                retPrice = item.InitialPrice;
            }

            return retPrice;
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            decimal retPrice = 0;

            foreach (Stock item in Burza.Where(item => item.StockName == inStockName.ToLower()))
            {
                retPrice = item.InitialPrice;
            }

            foreach (StockTime item in BurzaVrijeme.Where(item => item.StockName == inStockName.ToLower()))
            {
                retPrice = item.Price;
            }

            return retPrice;
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            bool exists = IndexExists(inIndexName);

            if (exists)
                throw new StockExchangeException("Index postoji u sustavu");

            if (inIndexType != IndexTypes.AVERAGE && inIndexType != IndexTypes.WEIGHTED)
                throw new StockExchangeException("Pogrešan tip indexa");

            Index noviIndeks = new Index(inIndexName.ToLower(), inIndexType);
            Index.Add(noviIndeks);
        }

        public Stock GetStock(string inStockName)
        {
            Stock result = Burza.First(dionica => dionica.StockName == inStockName.ToLower());
            return result;
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            bool indexExists = IndexExists(inIndexName.ToLower());
            bool stockExists = StockExists(inStockName.ToLower());

            if (!indexExists)
                throw new StockExchangeException("Index ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            // odabir traženog indeksa
            foreach (Index indeks in Index.Where(indeks => indeks.IndexName == inIndexName.ToLower()))
            {
                // odabir dionice za dodavanje
                Stock stockToAdd = Burza.First(dionica => dionica.StockName == inStockName.ToLower());
                {
                    // ukoliko tražena dionica nije pridjeljena indeksu
                    if (!stockToAdd.inIndex)
                    {
                        indeks.StockList.Add(stockToAdd);
                        foreach (Stock item in Burza.Where(item => item.StockName == inStockName.ToLower()))
                        {
                            item.inIndex = true;
                        }
                    }
                    else
                    {
                        throw new StockExchangeException("Dionica već pridjeljena indexu");
                    }

                }
            }
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            bool indexExists = IndexExists(inIndexName.ToLower());
            bool stockExists = StockExists(inStockName.ToLower());
            bool stockInIndex = IsStockPartOfIndex(inIndexName, inStockName);

            if (!indexExists)
                throw new StockExchangeException("Index ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            if (!stockInIndex)
                throw new StockExchangeException("Dionica nije u indeksu");

            foreach (Index item in Index.Where(item => item.IndexName == inIndexName.ToLower()))
            {
                foreach (Stock dionica in Burza.Where(dionica => dionica.StockName == inStockName.ToLower()))
                {
                    item.StockList.Remove(dionica);
                    dionica.inIndex = false;
                }
            }
        }

        public void RemoveStockFromAllIndicies(string inStockName)
        {
            bool stockExists = StockExists(inStockName.ToLower());

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            foreach (Index item in Index)
            {
                foreach (Stock dionica in Burza.Where(dionica => dionica.StockName == inStockName.ToLower()))
                {
                    item.StockList.Remove(dionica);
                    dionica.inIndex = false;
                }
            }
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            bool indexExists = IndexExists(inIndexName.ToLower());
            bool stockExists = StockExists(inStockName.ToLower());
            bool exists = false;

            if (!indexExists)
                throw new StockExchangeException("Index ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            foreach (Index item in Index.Where(item => item.IndexName == inIndexName.ToLower()))
            {
                exists = item.StockList.Any(dionica => dionica.StockName == inStockName.ToLower());
            }

            return exists;
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            decimal result = 0;
            decimal sum = 0;
            int n = 0;

            foreach (Index item in Index.Where(item => item.IndexName == inIndexName.ToLower()))
            {
                if (!item.StockList.Any())
                    return 0;

                if (item.Tip == IndexTypes.AVERAGE)
                {
                    foreach (Stock dionica in item.StockList)
                    {
                        result += GetStockPrice(dionica.StockName, inTimeStamp);
                        n++;
                    }
                    result = result / n;
                }

                if (item.Tip == IndexTypes.WEIGHTED)
                {
                    // računanje ukupne vrijednosti svih dionica u indexu (LINQ expression)
                    sum += item.StockList.Sum(dionica => dionica.NumberOfShares * GetStockPrice(dionica.StockName, inTimeStamp));

                    // računanje težinske vrijednosti svake dionice (LINQ expression)
                    result += item.StockList.Sum(dionica => dionica.NumberOfShares * (GetStockPrice(dionica.StockName, inTimeStamp) / sum) * (GetStockPrice(dionica.StockName, inTimeStamp)));
                }
            }
            return Math.Round(result, 3);
        }

        public bool IndexExists(string inIndexName)
        {
            bool exists = Index.Any(item => item.IndexName == inIndexName.ToLower());
            return exists;
        }

        public int NumberOfIndices()
        {
            _indexNumber = Index.Count;
            return _indexNumber;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            bool indexExists = IndexExists(inIndexName.ToLower());
            int number = 0;

            if (!indexExists)
                throw new StockExchangeException("Index ne postoji");

            foreach (Index item in Index.Where(item => item.IndexName == inIndexName.ToLower()))
            {
                number = item.StockList.Count;
            }

            return number;
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (PortfolioExists(inPortfolioID))
                throw new StockExchangeException("Portfelj već postoji");

            Portfolio noviPortfolio = new Portfolio(inPortfolioID);
            Portfolio.Add(noviPortfolio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            bool stockExists = StockExists(inStockName);

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            if (numberOfShares <= 0)
                throw new StockExchangeException("Neispravan unos broja dionica");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                foreach (Stock dionica in Burza.Where(dionica => dionica.StockName == inStockName.ToLower()))
                {
                    if (dionica.NumberOfShares - dionica.SharesInPortfolio >= numberOfShares)
                    {
                        if (item.StockList.Any(dio => dio.StockName == dionica.StockName.ToLower()))
                        {
                            foreach (
                                Stock dionica2 in
                                    item.StockList.Where(dionica2 => dionica2.StockName == inStockName.ToLower()))
                            {
                                dionica2.NumberOfShares += numberOfShares;
                                dionica.SharesInPortfolio += numberOfShares;
                            }
                        }
                        else
                        {
                            Stock novaDionica = new Stock(inStockName.ToLower(), numberOfShares, dionica.InitialPrice, dionica.TimeStamp);
                            item.StockList.Add(novaDionica);
                            dionica.SharesInPortfolio += numberOfShares;
                        }
                        
                    }
                    else
                    {
                        throw new StockExchangeException("Ne valja");
                    }
                }
            }

        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            bool stockExists = StockExists(inStockName);

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            if (numberOfShares <= 0)
                throw new StockExchangeException("Neispravan unos broja dionica");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                if (item.StockList.Any(dio => dio.StockName == inStockName.ToLower()))
                {
                    foreach (
                        Stock dionica in item.StockList.Where(dionica => dionica.StockName == inStockName.ToLower()))
                    {
                        if (dionica.NumberOfShares > numberOfShares) 
                        {
                            // smanjenje broja dionica u portfelju
                            dionica.NumberOfShares -= numberOfShares;
                            
                            // povecanje broja dostupnih dionica na burzi
                            foreach (Stock dionica2 in Burza.Where(dionica2 => dionica2.StockName == inStockName.ToLower()))
                            {
                                dionica2.SharesInPortfolio -= numberOfShares;
                            }
                        }

                        if (dionica.NumberOfShares == numberOfShares)
                        {
                            item.StockList.Remove(dionica);
                        }

                        if (dionica.NumberOfShares < numberOfShares)
                            throw new StockExchangeException("Ne valja");
                }

                }
            }
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            bool stockExists = StockExists(inStockName);

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                if (item.StockList.Any(dio => dio.StockName == inStockName.ToLower()))
                {
                    foreach (
                        Stock dionica in item.StockList.Where(dionica => dionica.StockName == inStockName.ToLower()))
                    {
                        item.StockList.Remove(dionica);
                    }
                }
                else
                {
                    throw new StockExchangeException("Dionica ne postoji u portfelju");
                }
            }
        }

        public int NumberOfPortfolios()
        {
            _portfolioNumber = Portfolio.Count;
            return _portfolioNumber;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            int temp = 0;
            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                temp = item.StockList.Count;
            }
            return temp;
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            bool exists = Portfolio.Any(item => item.PortfolioID == inPortfolioID);
            return exists;
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            bool stockExists = StockExists(inStockName);
            bool result = false;

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                result = item.StockList.Any(dionica => dionica.StockName == inStockName.ToLower());
                
            }

            return result;

        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            int result = 0;
            bool portfolioExists = PortfolioExists(inPortfolioID);
            bool stockExists = StockExists(inStockName);

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            if (!stockExists)
                throw new StockExchangeException("Dionica ne postoji");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                foreach (Stock dionica in item.StockList)
                {
                    if(dionica.StockName == inStockName.ToLower())
                    result += (int) dionica.NumberOfShares;
                }
            }

            return result;
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            decimal result = 0;

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            foreach (Portfolio item in Portfolio.Where(item => item.PortfolioID == inPortfolioID))
            {
                foreach (Stock dionica in item.StockList)
                {
                    result += dionica.NumberOfShares*dionica.InitialPrice;
                }
            }

            return result;
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            bool portfolioExists = PortfolioExists(inPortfolioID);
            decimal result = 0;

            if (!portfolioExists)
                throw new StockExchangeException("Portfolio ne postoji");

            return result;
        }
    }
}
