﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {

        public enum Operator
        {
            NONE,
            PLUS,
            MINUS,
            TIMES,
            DIVIDE,

            SIN,
            COS,
            TG,
            INVERSE,
            SQUARE,
            ROOT
        }

        public Kalkulator()
        {
            resetCalculator();
        }

        //do not calculate until needed
        private Operator lastOperator;

        //current display state
        private string _display;

        //memory
        private string _memory = null;

        //variables for saving the number entry
        private bool clearNumberOnEntry = false;
        private string _number;

        //left operand for binary operators
        private double _leftOperand;

        //ran out of creativity in the switch-case statement, and cannot declare same name variables inside
        private string _tmpNumber;

        //"state" of the calculator, if error occured, block until 
        private bool _error = false;
        private bool Error
        {
            get { return _error; }
            set 
            {
                if (value)
                {
                    //if error happened
                    _display = "-E-";
                }
                _error = value;
            }

        }

        public void Press(char inPressedDigit)
        {
            //could use the State design pattern but KISS
            if (Error)
            {
                //if the error message is on the screen, only accept command that resets the calculator
                if (inPressedDigit == 'O')
                {
                    resetCalculator();
                }
            }
            else
            {

                try
                {

                    //do commands normally
                    switch (inPressedDigit)
                    {
                        case '+':
                            //plus command
                            doBinaryOperator(Operator.PLUS);
                            break;
                        case '-':
                            //minus command
                            doBinaryOperator(Operator.MINUS);
                            break;
                        case '*':
                            //multiply command
                            doBinaryOperator(Operator.TIMES);
                            break;
                        case '/':
                            //divide command
                            doBinaryOperator(Operator.DIVIDE);
                            break;
                        case '=':
                            //show result

                            if (lastOperator == Operator.NONE)
                            {
                                //no operators, just show result
                                _display = formatNumber(double.Parse(_display));
                                
                            }
                            else
                            {
                                //if no number was written, use the one from display (2+= is 2 +2 || 2*= is 2*2)
                                if(_number.Equals("")) _number = _display;
                                //check for errors
                                checkForChainedOperator();
                                //calculated result is in _leftOperant, show it
                                _display = formatNumber(_leftOperand);
                                lastOperator = Operator.NONE;
                            }
                            _number = "";
                            break;
                        case ',':
                            //decimal point
                            if (clearNumberOnEntry)
                            {
                                _number = "";
                                clearNumberOnEntry = false;
                            }
                            if (!_number.Contains(",") && _number.Replace("-", "").Length < 10)
                            {

                                //ignore multiple commas, and make sure there is place for decimal digits
                                if(_number.Equals("")) _number="0";
                                _number += inPressedDigit;
                                //copy directly to screen because the format would remove the comma
                                _display = _number;

                            }
                            break;
                        case 'M':
                            //change - to +, and + to -
                            _tmpNumber = _display;
                            if (_tmpNumber.Equals("0"))
                            {
                                //do nothing
                            }
                            else
                            {
                                _tmpNumber = _tmpNumber.Contains("-") ? _tmpNumber.Replace("-", "") : "-" + _tmpNumber;
                            }

                            _display = _tmpNumber;
                            _number = _tmpNumber;

                            break;
                        case 'S':
                            //sinus
                            doUnaryOperator(Operator.SIN);
                            break;
                        case 'K':
                            //cosinus command
                            doUnaryOperator(Operator.COS);
                            break;
                        case 'T':
                            //tangens command
                            doUnaryOperator(Operator.TG);
                            break;
                        case 'Q':
                            //square the number
                            doUnaryOperator(Operator.SQUARE);
                            break;
                        case 'R':
                            //square root the number
                            //if the number is <0 it will cause an exception
                            doUnaryOperator(Operator.ROOT);
                            break;
                        case 'I':
                            //Inverse he number
                            //Exception will be caught
                            doUnaryOperator(Operator.INVERSE);
                            break;
                        case 'P':
                            //store in memory
                            _memory = _display;
                            break;
                        case 'G':
                            //get from memory
                            if (_memory == null) Error = true;
                            else
                            {
                                _display = _memory;
                                _number = _memory;
                            }
                            break;
                        case 'C':
                            //clear screen
                            _number = "";
                            _display = "0";
                            break;
                        case 'O':
                            //reset calculator
                            resetCalculator();
                            break;
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                            //digit is pressed
                            if (clearNumberOnEntry)
                            {
                                _number = "";
                                clearNumberOnEntry = false;
                            }
                            //ignore more than 10 digits
                            if (_number.Replace(",", "").Replace("-", "").Length >= 10) break;

                            _number += inPressedDigit;

                            //if we are writing in the number, and it has a decimal point, allow zeroes
                            if (_number.Contains(","))
                            {
                                _display = _number;
                            }
                            else
                            {
                                //_number is always pareseable
                                _display = formatNumber(double.Parse(_number));
                                _number = _display;
                            }
                            break;
                        default:
                            //nothing else is acceptable, error
                            Error = true;
                            break;
                    }
                }
                catch { Error = true;/* Exception means error, so set if*/ }
            }
        }

        public string GetCurrentDisplayState()
        {
            return _display;
        }

        /// <summary>
        /// Does the binary operation
        /// </summary>
        /// <param name="currentOperator">Current operator</param>
        private void doBinaryOperator(Operator currentOperator)
        {
            if (lastOperator == Operator.NONE)
            {
                //none was chained
                _leftOperand = double.Parse(_display);
                //refresh screen
                _display = formatNumber(_leftOperand);
            }
            else
            {
                //will throw exception if any errors
                checkForChainedOperator();
            }
            lastOperator = currentOperator;
            _number = "";
        }

        /// <summary>
        /// Checks if there are any chained operators, and if there are, calculates them and stores in the leftOperand section
        /// </summary>
        /// <exception>Throws exception if any error occur during the calculations</exception>
        private void checkForChainedOperator()
        {
            if (!_number.Equals(""))
            {
                //only do the last operation
                switch (lastOperator)
                {
                    case Operator.PLUS:
                        //last one was plus
                        _leftOperand = _leftOperand + double.Parse(_display);
                        break;
                    case Operator.MINUS:
                        //last one was minus
                        _leftOperand = _leftOperand - double.Parse(_display);
                        break;
                    case Operator.TIMES:
                        //last one was times
                        _leftOperand = _leftOperand * double.Parse(_display);
                        break;
                    case Operator.DIVIDE:
                        //last one was divide. In case of division by zero, exception will be thrown
                        _leftOperand = _leftOperand / double.Parse(_display);

                        break;
                }
            }
        }

        /// <summary>
        /// Calculates the specified unary operator. Causes Exception if any error occur (division by zero, root from a negative number)
        /// </summary>
        /// <param name="unary">Operator to calculate</param>
        private void doUnaryOperator(Operator unary)
        {
            double unaryResult = 0;//compile-time error if not assigned
            double numberOnScreen = double.Parse(_display);

            switch (unary)
            {
                case Operator.SIN:
                    unaryResult = Math.Sin(numberOnScreen);
                    break;
                case Operator.COS:
                    unaryResult = Math.Cos(numberOnScreen);
                    break;
                case Operator.TG:
                    unaryResult = Math.Tan(numberOnScreen);
                    break;
                case Operator.SQUARE:
                    unaryResult = Math.Pow(numberOnScreen, 2);
                    break;
                case Operator.ROOT:
                    unaryResult = Math.Sqrt(numberOnScreen);
                    break;
                case Operator.INVERSE:
                    unaryResult = Math.Pow(numberOnScreen,-1);
                    break;
            }

            _tmpNumber = formatNumber(unaryResult);

            _display = _tmpNumber;
            _number = _tmpNumber;
            clearNumberOnEntry = true;
        }

        /// <summary>
        /// Formates the number with the specification given in the assigment
        /// </summary>
        /// <param name="number">Number to format</param>
        /// <returns>String representation of a number</returns>
        /// <exception>Throws ArgumentException if the length of the number before the decimal point is greater than 10</exception>
        private string formatNumber(double number)
        {

            //chceck if "-" is needed
            string prefix = number < 0 ? "-" : "";

            //already added "-", work with the positive number
            number = Math.Abs(number);
            string numberString = number.ToString("##########.##########");
            int intNumber = (int)number;

            string body = intNumber.ToString();
            if (body.Length > 10)
            {
                throw new ArgumentException("Number length is to big!");
            }

            int lengthLeft = 10 - body.Length;

            //round apropriate
            numberString = Math.Round(number,lengthLeft).ToString();

            string decimalPart = "";
            if(lengthLeft>0 && numberString.Contains(",")){

                int startIndex = numberString.IndexOf(",");
                int decimalLength = startIndex; //do not count ","

                if (startIndex + lengthLeft + 1 > numberString.Length)
                {
                    //Do not need all available space
                    decimalLength = numberString.Length - startIndex ;

                }
                else
                {
                    //can take all space
                    decimalLength = lengthLeft + 1;
                }

                decimalPart = numberString.Substring(startIndex,decimalLength);

                //remove zeroes at the end
                //example : number 123456.78901
                //round to 10 digits :
                // 123456.7890 - got a zero at the end

                for (int i = decimalPart.Length - 1; i >= 0;i-- )
                {
                    char current = decimalPart.ElementAt(i);
                    if (current == '0' || current == ',')
                    {
                        //zero from the back, or we came to the end and reached ,
                        decimalPart = decimalPart.Substring(0, decimalPart.Length - 1);
                    }
                    else
                    {
                        //no more zeroes from the back, done
                        break;
                    }
                }

            }
            

            return prefix + body + decimalPart;
        }

        /// <summary>
        /// Resets the calculator
        /// </summary>
        private void resetCalculator()
        {
            _number = "";
            _display = "0";
            _leftOperand = 0;
            Error = false;
            lastOperator = Operator.NONE;
        }
    }



}
