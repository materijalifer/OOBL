using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private char[] znamenke = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };  //sve dozvoljene znamenke
        private char[] operacijeOsnovne = { '+', '-', '*', '/', '=' }; //najobicnije operacije
        private char[] operacijeUnarne = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I' }; //unarne operacije
        private char[] operacijePosebne = { 'O', 'P', 'G' , 'C'};
        private bool zadnjaOperacija = false; //oznacava koja je zadnja operacija, false-nije bio broj, true-bila je znamenka
        private string konacno="0";
        private bool postojiOperatorOsnovni = false; //oznacava dal postoji osnovni (binarni) operator prije
        private double stariBroj=0;
        private char stariOperator; //oznacavaju nam prijasni broj i operator kod osnovnih operacija
        private bool pritisnutiZarez = false; //oznacava dal je pritisnuti decimalni zarez
        private double dec;
        private string memorija="0";
        private bool pritisnutBinarni=false; //dal je vise uzastopnih binarnih
        public void Press(char inPressedDigit)
        {
            if (znamenke.Contains(inPressedDigit))
            {
                this.pritisnutaZnamenka(inPressedDigit);
            }
            else if (inPressedDigit == ',')
            {
                pritisnutiZarez = true; //zarez je pritisnut
                dec=0.1;
                if (zadnjaOperacija == false)
                {
                    konacno = "0";
                }
                zadnjaOperacija = true; //kazemo da je zadnje bio broj, jer smo pritisnuli zarez, dakle to je dec broj
            }
            else if (operacijeOsnovne.Contains(inPressedDigit))
            {
                this.pritisnutaOperacijaOsnovna(inPressedDigit, konacno);
            }
            else if (operacijeUnarne.Contains(inPressedDigit))
            {
                this.pritisnutaOperacijaUnarna(inPressedDigit, konacno);
            }
            else if (operacijePosebne.Contains(inPressedDigit)) 
            {
                this.pritisnutaOperacijaPosebna(inPressedDigit);
            }
        }

        public string GetCurrentDisplayState()
        {
            return konacno;
        }
        private void pritisnutaOperacijaPosebna(char znamenka)
        {
            if (znamenka == 'O') //brise se sve
            {
                konacno = "0";
                zadnjaOperacija = false;
                postojiOperatorOsnovni = false;
                stariBroj = 0;
                stariOperator = 'n';
                pritisnutiZarez = false;
                memorija = "0";
                pritisnutBinarni = false;
            }
            else if (znamenka == 'P') //stavljanje u memoriju brojke
            {
                memorija = konacno;
            }
            else if (znamenka == 'G') //uzimanje iz memorije
            {
                konacno = memorija;
            }
            else if (znamenka == 'C') //brisanje ekrana
            {
                konacno = "0";
                zadnjaOperacija = false; //kazemo da zadnja operacija nije brojka, jer smo izbrisali ekran
            }
        }
        private void pritisnutaZnamenka(char znamenka)
        {
            double pomocni;
            double konacnoBroj;
            pritisnutBinarni = false;
            if (zadnjaOperacija == true) //ako zadnja operacija je bila znamenka, stavi ju samo uz novu znamenku
            {
                konacnoBroj = double.Parse(konacno); //pretvorimo u double trenutni broj
                if (pritisnutiZarez == true) //ako je bio prije pritisnut zarez
                {
                    if (Math.Abs(konacnoBroj).ToString().Length < 11) //i ako jos stane brojki na ekran
                    {
                        pomocni = double.Parse(znamenka.ToString()); //pritisnuta znamenka
                        if (konacnoBroj >= 0)
                        {
                            pomocni = konacnoBroj + dec * pomocni; //pribroji decimalnu znamenku ako je pozitivan
                        }
                        else
                            pomocni = konacnoBroj - dec * pomocni; //pribroji decimalnu znamenku ali tako da je oduzmes jer je br neg
                        konacno = pomocni.ToString();
                        dec = dec / 10;
                    }
                }
                else if (Math.Abs(konacnoBroj).ToString().Length < 10) //ako nema zareza, i ako stane brojki
                {
                    if (!(konacno == "0"))
                    {
                        konacno = konacno + znamenka; //ogranicenje ako je vise nula na ekranu prikazuje se samo jedna
                    }
                }
            }
            else
            {
                konacno = znamenka.ToString();
                zadnjaOperacija = true;
            }
        }
        private void pritisnutaOperacijaOsnovna(char osnOperator, string broj)
        {
            double pomoc;
            
            if (!(konacno == "-E-"))
            {
                pomoc = double.Parse(broj);
                pritisnutiZarez = false;
                if (postojiOperatorOsnovni == true)
                {
                    if ((stariOperator == '/') && (pomoc == 0)) //ako se dijeli s nulom javi gresku
                    {
                        konacno = "-E-";
                    }
                    else if((pritisnutBinarni==true) && (osnOperator!='=')) //znaci da su 2 binarna za redom
                    {
                        stariOperator = osnOperator; //uzimam samo zadnji operator
                    }
                    else
                    {
                        if (stariOperator == '+')
                        {
                            stariBroj = stariBroj + pomoc; //u stari broj spremimo rezultat do novog binarnog operatora
                            stariOperator = osnOperator; //u stari operator, spremimo novi binarni operator
                        }
                        else if (stariOperator == '-')
                        {
                            stariBroj = stariBroj - pomoc;
                            stariOperator = osnOperator;
                        }
                        else if (stariOperator == '*')
                        {
                            stariBroj = stariBroj * pomoc;
                            stariOperator = osnOperator;
                        }
                        else if (stariOperator == '/')
                        {
                            stariBroj = stariBroj / pomoc;
                            stariOperator = osnOperator;
                        }
                        konacno = stariBroj.ToString();
                    }
                    if (!konacno.Contains(',') && Math.Abs(stariBroj).ToString().Length > 10)  //ako rezultat ne sadrzi zarez, i ako je prevelik error
                    {
                        konacno = "-E-";
                    }
                    else if (konacno.Contains(',')) //ako rezultat sadrzi zarez
                    {
                        string[] dijeloviStringa = konacno.Split(','); //splitamo taj rezultat
                        double prvi = double.Parse(dijeloviStringa[0]); //i cjelobrojni dio pretvorimo u double
                        if (Math.Abs(prvi).ToString().Length > 10) //ako je cjelobrojni dio veci od 10 znamenki
                        {
                            konacno = "-E-"; //to je greska
                        }
                        else if (Math.Abs(prvi).ToString().Length + dijeloviStringa[1].Length > 10)//a ako je ukupno duljina >10
                        {
                            konacno = Math.Round(stariBroj, (10 - Math.Abs(prvi).ToString().Length)).ToString(); //zaokruzujemo 
                        }
                    }

                }
                else
                {
                    stariBroj = pomoc;
                    stariOperator = osnOperator;
                    postojiOperatorOsnovni = true;
                }
                pritisnutBinarni = true;
            }
            zadnjaOperacija = false;
        }
        private void pritisnutaOperacijaUnarna(char unOperator, string broj)
        {
            double pomocni;
            double rezultat=0;
            if ((broj == "0") && (unOperator == 'I'))
            {
                konacno = "-E-";
            }
			else if ((Double.Parse(broj)<0) && (unOperator=='R'))
			{
				konacno="-E-";
			}
            else if (!(konacno == "-E-"))
            {
                pomocni = double.Parse(broj);
                if (unOperator == 'M')
                {
                    rezultat = -pomocni;
                }
                else if (unOperator == 'S')
                {
                    rezultat = Math.Sin(pomocni);
                }
                else if (unOperator == 'K')
                {
                    rezultat = Math.Cos(pomocni);
                }
                else if (unOperator == 'T')
                {
                    rezultat = Math.Tan(pomocni);
                }
                else if (unOperator == 'Q')
                {
                    rezultat = Math.Pow(pomocni, 2);
                }
                else if (unOperator == 'R')
                {
                    rezultat = Math.Pow(pomocni, 0.5);
                }
                else if (unOperator == 'I')
                { 
                    rezultat = 1 / pomocni;
                }
                konacno = rezultat.ToString();

                if (!konacno.Contains(',') && Math.Abs(rezultat).ToString().Length > 10)  //ako rezultat ne sadrzi zarez
                {                                                                       // i ako je prevelik error
                    konacno = "-E-";
                }
                else if (konacno.Contains(',')) //ako rezultat sadrzi zarez
                {
                    string[] dijeloviStringa = konacno.Split(','); //splitamo taj rezultat
                    double prvi = double.Parse(dijeloviStringa[0]); //i cjelobrojni dio pretvorimo u double
                    if (Math.Abs(prvi).ToString().Length > 10) //ako je cjelobrojni dio veci od 10 znamenki
                    {
                        konacno = "-E-"; //to je greska
                    }
                    else if (Math.Abs(prvi).ToString().Length + dijeloviStringa[1].Length > 10)//a ako je ukupno duljina >10
                    {
                        konacno = Math.Round(rezultat, (10 - Math.Abs(prvi).ToString().Length)).ToString(); //zaokruzujemo 
                    }
                }
                if (!(unOperator=='M')) //unarni operator - ne mijenja stvar da je prije bila znamenka
                    zadnjaOperacija = false;
            }
        }
    }
}

