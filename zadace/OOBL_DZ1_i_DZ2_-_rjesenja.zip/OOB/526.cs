﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }
     

     public class StockExchange:IStockExchange
     {
         private List<Stock> Stocks= new List<Stock>();
         private List<Index> Indexes = new List<Index>();
         private List<Portfolio> Portfolios = new List<Portfolio>();

         private int findStock(string inStockName)
         {
             int i = 0;
             foreach (Stock s in Stocks)
             {
                 if (s.inStockName.ToUpper() == inStockName.ToUpper())
                 {
                     return i;
                 }
                 i++;
             }
             return -1;
         }
         private int findIndex(string inIndexName)
         {
             int i = 0;
             foreach (Index indx in Indexes)
             {
                 if (indx.inIndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     return i;
                 }
                 i++;
             }
             return -1;
         }
         private int findPortfolio(string inPortfolioID)
         {
             int i = 0;
             foreach (Portfolio p in Portfolios)
             {
                 if (p.inPortfolioID == inPortfolioID)
                 {
                     return i;
                 }
                 i++;
             }
             return -1;
         }
         

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             Stock nStock = new Stock();
             nStock.inStockName = inStockName;
             nStock.inNumberOfShares = inNumberOfShares;
             nStock.numberOfSharesAvailable = inNumberOfShares;
             nStock.inInitialPrice = inInitialPrice;
             nStock.inTimeStamp = inTimeStamp;
             Value v = new Value();
             v.inTimeStamp = inTimeStamp;
             v.price = inInitialPrice;

             if ((!StockExists(inStockName)) && (inInitialPrice > 0) && (inNumberOfShares>0))
             {
                 Stocks.Add(nStock);
                 nStock.stockValue.Add(v);
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void DelistStock(string inStockName)
         {
             int s=findStock(inStockName);
             if (s != -1)
             {
                 Stocks.Remove(Stocks[s]);
                 foreach (Index i in Indexes)
                 {
                     foreach (string st in i.stocksI)
                     {
                         if (st.ToUpper() == inStockName.ToUpper())
                         {
                             i.stocksI.Remove(inStockName);
                             break;
                         }
                     }
                 }
                 foreach (Portfolio p in Portfolios)
                 {
                     foreach (StocksP st in p.stocks)
                     {
                         if (st.inStockName.ToUpper() == inStockName.ToUpper())
                         {
                             p.stocks.Remove(st);
                             break;
                         }
                     }
                 }
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public bool StockExists(string inStockName)
         {             
             int s = findStock(inStockName);
             if (s != -1)
             {
                 return true;
             }
             return false;             
         }

         public int NumberOfStocks()
         {
             return Stocks.Count();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             int s = findStock(inStockName);

             if ((s != -1) && (!Stocks[s].findDatum(inIimeStamp)))
             {
                 Value v = new Value();
                 v.inTimeStamp = inIimeStamp;
                 v.price = inStockValue;
                 Stocks[s].stockValue.Add(v);
                 Stocks[s].stockValue = Stocks[s].stockValue.OrderBy(o => o.inTimeStamp).ToList();
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
             
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             int s = findStock(inStockName);
             if (s != -1)
             {
                 return Stocks[s].stockValue[Stocks[s].findStock(inTimeStamp)].price;
             }
             else
             {
                 throw new StockExchangeException("greska");
             }                   
             
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             int s = findStock(inStockName);
             if (s != -1)
             {
                 return Stocks[s].stockValue[0].price;
             }
             else
             {
                 return 0;
             }     
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             int s = findStock(inStockName);
             if (s != -1)
             {
                 return Stocks[s].stockValue[Stocks[s].stockValue.Count() - 1].price;
             }
             else
             {
                 return 0;
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (((inIndexType == IndexTypes.AVERAGE) || (inIndexType == IndexTypes.WEIGHTED)) && !(IndexExists(inIndexName)))
             {
                 Index i = new Index();
                 i.inIndexName = inIndexName;
                 i.inIndexType = inIndexType;
                 if (!(Indexes.Contains(i)))
                 {
                     Indexes.Add(i);
                 }
                 else
                 {
                     throw new StockExchangeException("greska");
                 }
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             int s = findIndex(inIndexName);
        
             if ((s != -1) && (IsStockPartOfIndex(inIndexName,inStockName)!=true) && (!(Indexes[s].stocksI.Contains(inStockName))) && StockExists(inStockName) )
             {
                Indexes[s].stocksI.Add(inStockName);                 
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             int s = findIndex(inIndexName);
             int i = -1;
             if (s != -1)
             {
                 i = Indexes[s].findStock(inStockName);
             }
             
             if ((s != -1) && (i !=-1))
             {
                 if ((i!=-1) && StockExists(inStockName))
                 {
                     Indexes[s].stocksI.Remove(inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             int s = findIndex(inIndexName);
             if (s != -1)
             {
                 if ((Indexes[s].stocksI.Contains(inStockName)))
                 {
                     return true;
                 }
             }
             return false;   
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             int pos = findIndex(inIndexName);
             decimal sum=0;
             int br = 0;
             if (Indexes[pos].inIndexType == IndexTypes.AVERAGE)
             {
                 foreach (string s in Indexes[pos].stocksI)
                 {
                     sum += GetStockPrice(s, inTimeStamp);
                     br++;
                 }
                 return  Math.Round((sum / br),3);
             }
             else if (Indexes[pos].inIndexType == IndexTypes.WEIGHTED)
             {
                 int brStock = 0;
                 decimal sum2 = 0;
                 
                 foreach (string s in Indexes[pos].stocksI)
                 {
                     brStock = 0;
                     foreach (Stock st in Stocks)
                     {
                         if (st.inStockName.ToUpper() == s.ToUpper())
                         {
                             break;
                         }
                         brStock++;
                     }
                     sum += GetStockPrice(s, inTimeStamp) * Stocks[brStock].inNumberOfShares;
                 }
                 foreach (string s in Indexes[pos].stocksI)
                 {
                     brStock = 0;
                     foreach (Stock st in Stocks)
                     {
                         if (st.inStockName.ToUpper() == s.ToUpper())
                         {
                             break;
                         }
                         brStock++;
                     }
                     sum2 += GetStockPrice(s, inTimeStamp) * GetStockPrice(s, inTimeStamp) * Stocks[brStock].inNumberOfShares / sum;
                 }
                 return Math.Round(sum2, 3);
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public bool IndexExists(string inIndexName)
         {
             int s = findIndex(inIndexName);
             if (s != -1)
             {
                 return true;
             }
             return false;
         }

         public int NumberOfIndices()
         {
             return Indexes.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             int s = findIndex(inIndexName);
             if (s != -1)
             {
                 return Indexes[s].stocksI.Count();
             }
             return 0;
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             Portfolio p = new Portfolio();
             p.inPortfolioID = inPortfolioID;
             int s = findPortfolio(inPortfolioID);
             if (s == -1)
                 Portfolios.Add(p);
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int s = findPortfolio(inPortfolioID);
             int i = -1;
             if ((s != -1) && StockExists(inStockName))
             {
                 i = findStock(inStockName);
                 if (numberOfShares > Stocks[i].numberOfSharesAvailable)
                 {
                     numberOfShares = Convert.ToInt32(Stocks[i].numberOfSharesAvailable);
                 }
             }
             if ((s != -1) && (StockExists(inStockName)) && (numberOfShares <= Stocks[i].numberOfSharesAvailable) && (numberOfShares>0))
             {
                 if(IsStockPartOfPortfolio(inPortfolioID,inStockName))
                 {
                     int j = Portfolios[s].findStock(inStockName);
                     Portfolios[s].stocks[j].numberOfShares+=numberOfShares;
                     Stocks[i].numberOfSharesAvailable -= numberOfShares;
                 }
                 else
                 {
                    StocksP p = new StocksP();
                    p.inStockName = inStockName;
                    p.numberOfShares = numberOfShares;
                    Stocks[i].numberOfSharesAvailable -= numberOfShares;
                    Portfolios[s].stocks.Add(p);
                 }
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int s = findPortfolio(inPortfolioID);
             int i = -1;
             if ((s != -1) && StockExists(inStockName))
             {
                 i = findStock(inStockName);
                 if (numberOfShares > Portfolios[s].stocks[i].numberOfShares)
                 {
                     numberOfShares = Convert.ToInt32(Portfolios[s].stocks[i].numberOfShares);
                 }
             }
             int j = findStock(inStockName);
             if ((s != -1) && (StockExists(inStockName)) && (numberOfShares <= Portfolios[s].stocks[i].numberOfShares))
             {
                 Portfolios[s].stocks[i].numberOfShares -= numberOfShares;
                 if (Portfolios[s].stocks[i].numberOfShares == 0)
                 {
                     Portfolios[s].stocks.Remove(Portfolios[s].stocks[i]);
                 }
                 Stocks[j].numberOfSharesAvailable += numberOfShares;                                
             }
             else if ((s != -1) && (StockExists(inStockName)) && (numberOfShares > Portfolios[s].stocks[i].numberOfShares))
             {
                 Portfolios[s].stocks.Remove(Portfolios[s].stocks[i]);
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             int s = findPortfolio(inPortfolioID);
             
             int j = findStock(inStockName);
             if ((s != -1) && (StockExists(inStockName)))
             {
                 int i = Portfolios[s].findStock(inStockName);
                 Stocks[j].numberOfSharesAvailable += Portfolios[s].stocks[i].numberOfShares;
                 Portfolios[s].stocks.Remove(Portfolios[s].stocks[i]);
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }

         public int NumberOfPortfolios()
         {
             return Portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             int s = findPortfolio(inPortfolioID);
             if (s != -1)
             {
                 return Portfolios[s].stocks.Count();
             }
             return 0;
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             int s = findPortfolio(inPortfolioID);
             if (s != -1)
             {
                 return true;
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             int s = findPortfolio(inPortfolioID);
             int i = -1;
             if (s != -1)
             {
                 i = Portfolios[s].findStock(inStockName);
             }
             if ((s != -1) && (i !=-1))
             {
                 return true;
             }
             return false;
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             int s = findPortfolio(inPortfolioID);
             int i = -1;
             if (s != -1)
             {
                 i = Portfolios[s].findStock(inStockName);
             }
             if ((s != -1) && (i != -1))
             {
                 return Convert.ToInt32(Portfolios[s].stocks[i].numberOfShares);
             }
             return 0;
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             int s = findPortfolio(inPortfolioID);
             decimal sum = 0;
             if (s != -1)
             {
                 foreach (StocksP sp in Portfolios[s].stocks)
                 {
                     sum += GetStockPrice(sp.inStockName, timeStamp) * sp.numberOfShares;
                 }
                 return sum;
             }
             return sum;
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             if ((Year > 0) && (Month > 0) && (Month < 13))
             {
                 DateTime tSPoc = new DateTime(Year, Month, 1, 0, 0, 0);
                 DateTime tsKraj = new DateTime(Year, Month, DateTime.DaysInMonth(Year, Month), 23, 59, 59);
                 Decimal vrijednostPoc = GetPortfolioValue(inPortfolioID, tSPoc);
                 Decimal vrijednostKraj = GetPortfolioValue(inPortfolioID, tsKraj);
                 if (vrijednostPoc != 0 && vrijednostKraj != 0)
                 {
                     return Math.Round((vrijednostKraj - vrijednostPoc) / vrijednostPoc, 2) * 100;
                 }
                 return 0;
             }
             else
             {
                 throw new StockExchangeException("greska");
             }
         }
     }

     public class Stock
     {
         public string inStockName { get; set; }
         public long inNumberOfShares;
         public long numberOfSharesAvailable;
         public Decimal inInitialPrice;
         public DateTime inTimeStamp;        
         public List<Value> stockValue = new List<Value>();

         public int findStock(DateTime inTimeStamp)
         {
             int pos = 0;
             foreach (Value v in stockValue)
             {
                 if (inTimeStamp >= v.inTimeStamp)
                     pos++;
                /* if (inTimeStamp == v.inTimeStamp)
                     pos++;*/
             }
             pos--;
             if (pos < 0)
             {
                 throw new StockExchangeException("greska");
             }
             return pos;
         }
         public bool findDatum(DateTime inTimeStamp)
         {
             foreach (Value v in stockValue)
             {
                 if (inTimeStamp == v.inTimeStamp)
                     return true;
             }
             
             return false;
         } 

     }
     public class Value
     {
         public decimal price;
         public DateTime inTimeStamp;
     }
     public class Index
     {
         public string inIndexName;
         public IndexTypes inIndexType;
         public List<String> stocksI = new List<string>();

         public int findStock(string inStockName)
         {
             int i = 0;
             foreach (string s in stocksI)
             {
                 if (s.ToUpper() == inStockName.ToUpper())
                 {
                     return i;
                 }
                 i++;
             }
             return -1;
         }   
     }
     public class Portfolio
     {
         public string inPortfolioID;
         public List<StocksP> stocks = new List<StocksP>();

         public int findStock(string inStockName)
         {
             int i = 0;
             foreach (StocksP s in stocks)
             {
                 if (s.inStockName.ToUpper() == inStockName.ToUpper())
                 {
                     return i;
                 }
                 i++;
             }
             return -1;
         }         
     }

     public class StocksP
     {
         public string inStockName;
         public long numberOfShares;
     }
    
}
