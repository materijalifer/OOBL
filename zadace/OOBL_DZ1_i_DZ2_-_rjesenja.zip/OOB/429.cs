﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {

        double result = 0;
        private char lastOperation = '=';
        private bool refresh = false;
        private bool negative = false;
        private bool isFloating = false;
        private bool lastInputWasDigit = false;
        private StringBuilder currentDisplay = new StringBuilder("0", 13);
        private StringBuilder lastDisplay = new StringBuilder("0", 13);
        private StringBuilder memorizedDisplay = new StringBuilder("0", 13);


        public void Press(char inPressedDigit)
        {
            if (currentDisplay.ToString().Equals("-E-") && inPressedDigit != 'O') return;
            if (Char.IsDigit(inPressedDigit) || inPressedDigit == ',' || inPressedDigit == 'M')
            {
                ProcessDigit(inPressedDigit);
                lastInputWasDigit = true;
            }
            else
            {
                ProcessOperation(inPressedDigit);
            }
        }


        public string GetCurrentDisplayState()
        {
            return currentDisplay.ToString();
        }

        private void ProcessDigit(char digit)
        {
            if (!refresh)
            {
                if (currentDisplay.Length < 12)
                {
                    if ((Char.IsDigit(digit) || (digit == ',' && !isFloating)) && currentDisplay.ToString().Count(Char.IsDigit) < 10)
                    {
                        if (currentDisplay.ToString().Equals("0") && Char.IsDigit(digit))
                        {
                            currentDisplay[0] = digit;
                        }
                        else
                        {
                            currentDisplay.Append(digit);
                        }
                        if (digit == ',') isFloating = true;
                    }
                    else if (digit == 'M')
                    {
                        if (!negative)
                        {
                            currentDisplay.Insert(0, '-');
                            negative = true;
                        }
                        else
                        {
                            currentDisplay.Remove(0, 1);
                            negative = false;
                        }
                    }
                }
            }
            else
            {
                currentDisplay = new StringBuilder(digit.ToString(), 13);
                isFloating = false;
                negative = false;
                refresh = false;
            }
        }

        private void ProcessOperation(char operation)
        {
            String currentText = currentDisplay.Replace(',', ',').ToString();
            String lastText = lastDisplay.Replace(',', ',').ToString();

            double currentNumber = double.Parse(currentText);
            double lastNumber = double.Parse(lastText);

            Char[] unary = { 'Q', 'S', 'K', 'T', 'R', 'I' };
            Char[] binary = { '+', '-', '/', '*' };

            if (operation == 'O')
            {
                lastOperation = '=';
                currentDisplay = new StringBuilder("0", 13);
                lastDisplay = new StringBuilder("0", 13);
                negative = false;
            }

            if (operation == 'C')
            {
                currentDisplay = new StringBuilder("0", 13);
                negative = false;
            }

            if (operation == 'P')
            {
                memorizedDisplay.Length = 0;
                foreach (char c in currentDisplay.ToString())
                {
                    memorizedDisplay.Append(c);
                }
            }

            if (operation == 'G')
            {
                currentDisplay.Length = 0;
                foreach (char c in memorizedDisplay.ToString())
                {
                    currentDisplay.Append(c);
                }
                refresh = true;
            }

            if (binary.Contains(operation) || operation == '=')
            {
                switch (lastOperation)
                {
                    case '-':
                        result = lastNumber - currentNumber;
                        break;
                    case '+':
                        result = currentNumber + lastNumber;
                        break;
                    case '/':
                        if (currentNumber == 0)
                        {
                            currentDisplay.Length = 0;
                            currentDisplay.Append("-E-");
                            lastDisplay.Length = 0;
                            refresh = true;
                            return;
                        }
                        result = lastNumber / currentNumber;
                        break;
                    case '*':
                        result = currentNumber * lastNumber;
                        break;
                    default:
                        result = currentNumber;
                        break;

                }
                negative = (result < 0);
                if (operation == '=' || lastInputWasDigit) GetBinaryResult(result);
                lastOperation = operation;
                refresh = true;
                lastDisplay = currentDisplay;
                lastInputWasDigit = false;
 
            }

            if (unary.Contains(operation))
            {
                switch (operation)
                {
                    case 'S':
                        result = Math.Sin(currentNumber);
                        break;
                    case 'K':
                        result = Math.Cos(currentNumber);
                        break;
                    case 'T':
                        result = Math.Tan(currentNumber);
                        break;
                    case 'R':
                        if (currentNumber < 0)
                        {
                            currentDisplay.Length = 0;
                            currentDisplay.Append("-E-");
                            lastDisplay.Length = 0;
                            refresh = true;
                            return;
                        }
                        result = Math.Sqrt(currentNumber);
                        break;
                    case 'I':
                        if (currentNumber == 0)
                        {
                            currentDisplay.Length = 0;
                            currentDisplay.Append("-E-");
                            lastDisplay.Length = 0;
                            refresh = true;
                            return;
                        }
                        result = 1 / currentNumber;
                        break;
                    case 'Q':
                        result = currentNumber * currentNumber;
                        break;
                }
                negative = (result < 0);
                refresh = true;
                GetUnaryResult(result);
            }

        }




        private void GetBinaryResult(double number)
        {
            StringBuilder newDisplay = new StringBuilder(13);
            int i = 0;
            if (number < 9999999999.5)
            {

                if (number.ToString().Length > (negative ? 12 : 11))
                {
                    number = (double)Math.Round((decimal)result, (negative ? 10 : 9) - (int)Math.Log10(Math.Abs(number)));
                }

                foreach (char c in number.ToString())
                {
                    if (c == '.') newDisplay.Append(',');
                    newDisplay.Append(c);
                    i++;
                    if (i == (negative ? 12 : 11)) break;
                }

                refresh = true;
                currentDisplay = newDisplay;
            }
            else
            {
                currentDisplay.Length = 0;
                currentDisplay.Append("-E-");
                lastDisplay.Length = 0;
                refresh = true;
            }
        }

        private void GetUnaryResult(double number)
        {
            StringBuilder newDisplay = new StringBuilder(13);
            int i = 0;
            int j = 0;
            if (number < 9999999999.5)
            {

                if (number.ToString().Length > (negative ? 12 : 11))
                {
                    j = (int)Math.Log10(Math.Abs(number)) + 1;
                    number = (double) Math.Round((decimal) result, 10 - j);
                }

                foreach (char c in number.ToString())
                {
                    if (c == '.') newDisplay.Append(',');
                    newDisplay.Append(c);
                    i++;
                    if (i == (negative ? 12 : 11)) break;
                }

                refresh = true;
                currentDisplay = newDisplay;
            }
            else
            {
                currentDisplay.Length = 0;
                currentDisplay.Append("-E-");
                lastDisplay.Length = 0;
                refresh = true;
            }
        }


    }


}
