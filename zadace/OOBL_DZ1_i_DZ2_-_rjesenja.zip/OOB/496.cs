﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
  
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new MojCalc();
        }
    }


    public class MojCalc : ICalculator
    {
        const int MAX_NUMBERS_ONSCREEN = 10;

        private string currentDisplay = "0";

        bool LastPressIsBinaryOperation = false;
        bool LastPressIsUnaryOperation = false;

        private string memory = "0"; //defaultna mem je 0 ipak!



        private char lastOperator = '\0';
        private char currentOperator = '\0';

        private bool keyboardLocked = false; //za -E- slučajeve! C otključava


        private string[] operandsArray;

        private int currentOperand = 0;


        HashSet<char> binaryOperators = new HashSet<char> { '+', '-', '*', '/' };
        HashSet<char> unaryOperators = new HashSet<char> { 'S', 'K', 'T', 'Q', 'R', 'I' }; //M izbacen iz unarnih -> funkc
        HashSet<char> numbers = new HashSet<char> { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ',' };
        HashSet<char> functions = new HashSet<char> { 'P', 'G', 'C', 'O','M' };


        public MojCalc()
        {
            operandsArray = new string[2];
            operandsArray[0] = "0";
            operandsArray[1] = "0";
        }

        public void Press(char inPressedDigit)
        {

            if (numbers.Contains(inPressedDigit))
            {
                handleNumber(inPressedDigit);
                LastPressIsBinaryOperation = false;
                LastPressIsUnaryOperation = false;
            }
            else
            {
                if (binaryOperators.Contains(inPressedDigit))
                {
                    handleBinaryOperator(inPressedDigit);
                    LastPressIsBinaryOperation = true;
                    LastPressIsUnaryOperation = false;
                }

                else if (unaryOperators.Contains(inPressedDigit))
                {
                    handleUnaryOperator(inPressedDigit);
                    LastPressIsBinaryOperation = false;
                    LastPressIsUnaryOperation = true;
                }

                else if (functions.Contains(inPressedDigit))
                {
                    handleFunction(inPressedDigit);
                    LastPressIsBinaryOperation = false;
                    LastPressIsUnaryOperation = false;
                }

                else if (inPressedDigit.Equals('=')) // = je specijalni slučaj
                {
                    handleEquals();
                    LastPressIsBinaryOperation = false;
                    LastPressIsUnaryOperation = false;
                }

                else
                {
                    // nemoguca situacija, neki error
                }
            }
        }

        void handleEquals()
        {
            if (lastOperator.Equals('\0') && currentOperator.Equals('\0'))
            { //nekoliko = za redom
                //operandsArray[currentOperand] = "0";
                //currentOperand = 1; //iako bi vec i trebao biti
            }
            else if (LastPressIsBinaryOperation)
            {
                operandsArray[1] = operandsArray[0];
                executeBinaryOperation(currentOperator);
            }
            else
            {
                executeBinaryOperation(currentOperator);
                lastOperator = '\0';
                currentOperator = '\0';
            }
            
            currentOperand = 0;
            Maintenance(0);
            UpdateDisplay(0);
        }
 
        void UpdateDisplay(int x)
        {
            currentDisplay = operandsArray[x];
        }

        void Maintenance(int ID) //provjerava limite, pretvara 2, -> 2, 2,0000->2 itd, NE ispisuje na ekran!
        {
            if (!operandsArray[ID].Equals("-E-"))
            {
                if(operandsArray[ID].Equals(',')){
                    operandsArray[ID] = "0,0";
                }

                double num = double.Parse(operandsArray[ID]);
                int Position = 0;

                if (num < -9999999999 || num > 9999999999)
                {
                    ExecuteError();
                    return;
                }
                else
                {
                    int currentNumLimit = MAX_NUMBERS_ONSCREEN;
                    if (operandsArray[ID].Contains("-"))
                    {
                        currentNumLimit++;
                    }

                    Position = currentNumLimit - operandsArray[ID].IndexOf(",");
                    num = Math.Round(num, Position);

                    operandsArray[ID] = num.ToString(); //parse i tostring su izbacili i 2,0 i pretvorili ,5 -> 0,5, jedino nije , -> 0,0->fix'd???
                }
            }
        }


        public string GetCurrentDisplayState()
        {
            return currentDisplay;
        }


        void handleNumber(char c)
        {         

            if (getNumberOfDigits(currentOperand) < MAX_NUMBERS_ONSCREEN)
            {
                if(LastPressIsUnaryOperation){
                    operandsArray[currentOperand] = "0";
                }
                if (operandsArray[currentOperand].Equals("0") && !c.Equals(','))
                {
                    operandsArray[currentOperand] = c.ToString(); 
                }
                else
                {
                    if(!(c.Equals(',') && operandsArray[currentOperand].Contains(c))){
                        operandsArray[currentOperand] += c.ToString();
                    }                   
                }

                UpdateDisplay(currentOperand);
            }

        }

        void handleBinaryOperator(char c)
        {           
            //ako lastOperator nije \0 onda ga izvrsi, koji god novi operator doso
            //ako je \0 onda trenutni postaje Last
            if (!LastPressIsBinaryOperation)
            {
                if (currentOperator.Equals('\0'))
                {
                    currentOperator = c;
                    Maintenance(0);
                    UpdateDisplay(0);
                    currentOperand = 1; //prikazuje prvi, a prebacuje se na 2. operand
                }
                else
                {
                    lastOperator = currentOperator;
                    currentOperator = c;

                    executeBinaryOperation(lastOperator);
                    Maintenance(0);
                    UpdateDisplay(0);
                }
                
            }
            else
            {
                currentOperator = c;
            }

        }

        void executeBinaryOperation(char c)
        {
            string result = "0";

            if (c.Equals('+'))
            {
                result = (Double.Parse(operandsArray[0]) + Double.Parse(operandsArray[1])).ToString();
            }
            else if (c.Equals('-'))
            {
                result = (Double.Parse(operandsArray[0]) - Double.Parse(operandsArray[1])).ToString();
            }
            else if (c.Equals('*'))
            {
                result = (Double.Parse(operandsArray[0]) * Double.Parse(operandsArray[1])).ToString();
            }
            else if (c.Equals('/'))
            {
                if (Double.Parse(operandsArray[1]) == 0)
                {
                    handleFunction('O');
                    ExecuteError();
                }
                result = (Double.Parse(operandsArray[0]) / Double.Parse(operandsArray[1])).ToString();
            }

            else
            {  //slucajevi kad su iz prve samo unarni operatori
                return;
            }

            operandsArray[0] = result;
            operandsArray[1] = "0";

        }
        //TREBA ZAOKRUZIT nakon svake UN/BIN operacije!!!!!!!!!!!

        void handleUnaryOperator(char c)
        {           
            int tempOperand = currentOperand;
            if (LastPressIsBinaryOperation)
            {               
                tempOperand = 0;
            }
            

           if (c.Equals('S')) //sin u RADIJANIMA!!!!
            {
                operandsArray[currentOperand] = Math.Sin(Double.Parse(operandsArray[tempOperand])).ToString();
            }
            else if (c.Equals('K')) //cos u RADIJANIMA!!!!
            {
                operandsArray[currentOperand] = Math.Cos(Double.Parse(operandsArray[tempOperand])).ToString();
            }

            else if (c.Equals('I'))
            {
                if (operandsArray[tempOperand].Equals("0"))
                {
                    handleFunction('O');
                    ExecuteError();
                    return;
                }
                else
                {
                    operandsArray[currentOperand] = (1 / Double.Parse(operandsArray[tempOperand])).ToString();
                }
                
            }

            else if (c.Equals('Q'))
            {
                operandsArray[currentOperand] = Math.Pow(Double.Parse(operandsArray[tempOperand]), 2).ToString();
            }

            else if (c.Equals('R'))
            {
                if (Double.Parse(operandsArray[currentOperand]) < 0)
                {
                    handleFunction('O');
                    ExecuteError();
                    return;
                }
                operandsArray[currentOperand] = Math.Sqrt(Double.Parse(operandsArray[tempOperand])).ToString();
            }

            Maintenance(currentOperand);
            UpdateDisplay(currentOperand);

        }

        void handleFunction(char c)
        {
            if (c.Equals('M') && !operandsArray[currentOperand].Equals("0"))
            { // - NULA???!
                if (operandsArray[currentOperand][0].Equals('-'))
                {
                    operandsArray[currentOperand] = operandsArray[currentOperand].Remove(0, 1);  //izbrisi 1. znak
                }  
                else
                {  //dodaj - na pocetku
                    operandsArray[currentOperand] = "-" + operandsArray[currentOperand];
                }
                Maintenance(currentOperand);
                UpdateDisplay(currentOperand);
            }
            else 
            if (c.Equals('C'))
            {
                currentDisplay = "0";
                operandsArray[currentOperand] = "0";
             
                keyboardLocked = false; //mozda ipak true???? tj. samo O unlocka nakon errora???
                UpdateDisplay(currentOperand);
            }

            else if (c.Equals('P'))
            {
                memory = operandsArray[currentOperand];
            }

            else if (c.Equals('G'))
            {
                operandsArray[currentOperand] = memory;
                UpdateDisplay(currentOperand);
            }

            else if (c.Equals('O'))
            {
                memory = "0";
                currentDisplay = "0";
                operandsArray[0] = "0";
                operandsArray[1] = "0";
                lastOperator = '\0';
                currentOperator = '\0';
                currentOperand = 0;
                keyboardLocked = false;
            }

        }

        int getNumberOfDigits(int numOperand)
        { //broj Operanda

            int numberOfDigits = 0;
            foreach (char x in operandsArray[numOperand])
            {
                if (Char.IsDigit(x))
                {
                    numberOfDigits++;
                }
            }
            return numberOfDigits;
        }

        void ExecuteError()
        {
            keyboardLocked = true;
            operandsArray[0] = "-E-";
            operandsArray[1] = "-E-";
            currentDisplay = "-E-";
            //lastOperator = '\0'; //neznam jel se sve mora resetirati il samo zadnja operacija sa errorom izbaci???
            //currentOperator = '\0';
        }
    }     
}