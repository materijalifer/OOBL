﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     public class StockExchange : IStockExchange
     {
         private Dictionary<string, Stock> stocks;

         private Dictionary<string, Index> indices;

         private Dictionary<string, Portfolio> portfolios;

         public StockExchange()
         {
             stocks = new Dictionary<string, Stock>();
             indices = new Dictionary<string, Index>();
             portfolios = new Dictionary<string, Portfolio>();           
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (stocks.ContainsKey(inStockName.ToLower()))
             {
                 throw new StockExchangeException("Stock with name " + inStockName + " already exists.");
             }
             Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
             stocks.Add(inStockName.ToLower(), stock);
         }

         public void DelistStock(string inStockName)
         {
             Stock stock;
             if (stocks.TryGetValue(inStockName.ToLower(), out stock))
             {
                 stocks.Remove(inStockName.ToLower());
                 foreach (Index index in indices.Values)
                 {
                     index.RemoveStock(stock);
                 }

                 foreach (Portfolio portfolio in portfolios.Values)
                 {
                     portfolio.RemoveStockFromPortfolio(stock);
                 }
             }
             else
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
         }

         public bool StockExists(string inStockName)
         {
             return stocks.ContainsKey(inStockName.ToLower());
         }

         public int NumberOfStocks()
         {
             return stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             Stock stock;
             if (stocks.TryGetValue(inStockName.ToLower(), out stock))
             {
                 stock.SetStockPrice(inStockValue, inIimeStamp);              
             }
             else
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             Stock stock;
             if (stocks.TryGetValue(inStockName.ToLower(), out stock))
             {
                 return stock.GetStockPrice(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             Stock stock;
             if (stocks.TryGetValue(inStockName.ToLower(), out stock))
             {
                 return stock.GetFirstStockPrice();
             }
             else
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             Stock stock;
             if (stocks.TryGetValue(inStockName.ToLower(), out stock))
             {
                 return stock.GetLastStockPrice();
             }
             else
             {
                 throw new StockExchangeException("No stock with name " + inStockName);
             }
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (indices.ContainsKey(inIndexName.ToLower()))
             {
                 throw new StockExchangeException("Index with name " + inIndexName + " already exists.");
             }
             Index index = IndexFactory.GetTypeIndex(inIndexName, inIndexType);
             indices.Add(inIndexName.ToLower(), index);
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             Index index;
             if (indices.TryGetValue(inIndexName.ToLower(), out index))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     index.AddStock(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No index with name " + inIndexName);
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             Index index;
             if (indices.TryGetValue(inIndexName.ToLower(), out index))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     index.RemoveStock(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No index with name " + inIndexName);
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (stocks.ContainsKey(inStockName.ToLower()))
             {

                 Index index;
                 if (indices.TryGetValue(inIndexName.ToLower(), out index))
                 {
                     Stock stock;
                     if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                     {
                         return index.ContainsStock(stock);
                     }
                     else
                     {
                         throw new StockExchangeException("No stock with name " + inStockName);
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("No index with name " + inIndexName);
                 }
             }
             else
             {
                 return false;
             }

         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             Index index;
             if (indices.TryGetValue(inIndexName.ToLower(), out index))
             {
                 return index.GetIndexValue(inTimeStamp);
             }
             else
             {
                 throw new StockExchangeException("No index with name " + inIndexName);
             }
         }

         public bool IndexExists(string inIndexName)
         {
             return indices.ContainsKey(inIndexName.ToLower());
         }

         public int NumberOfIndices()
         {
             return indices.Count();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             Index index;             
             if (indices.TryGetValue(inIndexName.ToLower(), out index))
             {
                 return index.GetNumberOfStocksContaining();
             }
             else
             {
                 throw new StockExchangeException("No index with name " + inIndexName);
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (portfolios.ContainsKey(inPortfolioID))
             {
                 throw new StockExchangeException("Portofolio with ID " + inPortfolioID + " already exists.");
             }
             Portfolio portofolio = new Portfolio(inPortfolioID);
             portfolios.Add(inPortfolioID, portofolio);
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     portfolio.AddStockToPortfolio(stock, numberOfShares);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     portfolio.RemoveStockFromPortfolio(stock, numberOfShares);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     portfolio.RemoveStockFromPortfolio(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public int NumberOfPortfolios()
         {
             return portfolios.Count();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 return portfolio.GetNumberOfStocks();
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             return portfolios.ContainsKey(inPortfolioID);
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             if (stocks.ContainsKey(inStockName.ToLower()))
             {

                 Portfolio portfolio;
                 if (portfolios.TryGetValue(inPortfolioID, out portfolio))
                 {
                     Stock stock;
                     if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                     {
                         return portfolio.ContainsStock(stock);
                     }
                     else
                     {
                         throw new StockExchangeException("No stock with name " + inStockName);
                     }
                 }
                 else
                 {
                     throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
                 }
             }
             else
             {
                 return false;
             }
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 Stock stock;
                 if (stocks.TryGetValue(inStockName.ToLower(), out stock))
                 {
                     return portfolio.GetNumberOfStockShares(stock);
                 }
                 else
                 {
                     throw new StockExchangeException("No stock with name " + inStockName);
                 }
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 return portfolio.GetPortfolioValue(timeStamp);
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             Portfolio portfolio;
             if (portfolios.TryGetValue(inPortfolioID, out portfolio))
             {
                 try
                 {
                     return portfolio.GetPortfolioPercentChangeInValueForMonth(Year, Month);
                 }
                 catch (ArgumentOutOfRangeException e)
                 {
                     throw new StockExchangeException("Impossible date.");
                 }
             }
             else
             {
                 throw new StockExchangeException("No portofolio with ID " + inPortfolioID);
             }
         }
     }

     public class Stock
     {
         public string Name { get; private set; }
         public long NumberOfShares { get; private set; }
         public long NumberOfOwnedShares { get; private set; }
         private List<StockPrice> PriceHistory { get; set; }

         public Stock(string stockName, long numberOfShares, Decimal initialPrice, DateTime timeStamp)
         {
             if (numberOfShares <= 0)
             {
                 throw new StockExchangeException("Number of shares must be greater than zero.");
             }
             Name = stockName;
             NumberOfShares = numberOfShares;
             NumberOfOwnedShares = 0;
             StockPrice stockPrice = new StockPrice(initialPrice, timeStamp);
             PriceHistory = new List<StockPrice>();
             PriceHistory.Add(stockPrice);
         }

         public void SetStockPrice(Decimal newPrice, DateTime timeStamp) 
         {
             StockPrice newStockPrice = new StockPrice(newPrice, timeStamp);

             if (timeStamp > PriceHistory.Last().From)
             {
                 PriceHistory.Add(newStockPrice);
             }
             else
             {
                 for (int i = 0; i < PriceHistory.Count; i++)
                 {
                     if (PriceHistory.ElementAt(i).From > timeStamp)
                     {
                         PriceHistory.Insert(i, newStockPrice);
                         break;
                     }
                     else if (PriceHistory.ElementAt(i).From == timeStamp)
                     {
                         throw new StockExchangeException("Price already set for time " + timeStamp);
                     }
                 }
             }
         }

         public Decimal GetStockPrice(DateTime timeStamp)
         {
             if (timeStamp < PriceHistory.First().From)
             {
                 throw new StockExchangeException("Time before stock creation");
             }
             else
             {
                 for (int i = 0; i < PriceHistory.Count; i++)
                 {
                     if (PriceHistory.ElementAt(i).From > timeStamp)
                     {
                         return PriceHistory.ElementAt(i - 1).Price;
                     }
                 }
                 return PriceHistory.Last().Price;
             }
         }

         public Decimal GetFirstStockPrice()
         {
             return PriceHistory.First().Price;
         }

         public Decimal GetLastStockPrice()
         {
             return PriceHistory.Last().Price;
         }

         public int BuyStock(int numberOfSharesToBuy)
         {
             if (numberOfSharesToBuy + NumberOfOwnedShares > NumberOfShares)
             {
                 int numberOfSharesBought = Convert.ToInt32(NumberOfShares - NumberOfOwnedShares);
                 return numberOfSharesBought;

             }
             else
             {
                 NumberOfOwnedShares += numberOfSharesToBuy;
                 return Convert.ToInt32(numberOfSharesToBuy);
             }
         }

         public void SellStock(int numberOfSharesToSell)
         {
             if (NumberOfOwnedShares - numberOfSharesToSell < 0)
             {
                 throw new StockExchangeException("Not enough shares on stock for such operation.");
             }
             else
             {
                 NumberOfOwnedShares -= numberOfSharesToSell;
             }
         }
     }

     public abstract class Index
     {
         public string Name { get; protected set; }
         public IndexTypes Type {get; protected set;}
         protected Dictionary<string, Stock> Stocks {get; set;}

        
         public void AddStock(Stock stock)
         {
             if (Stocks.ContainsKey(stock.Name.ToLower())) 
             {
                 throw new StockExchangeException("Stock already in index.");
             }
             Stocks.Add(stock.Name.ToLower(), stock);
         }

         public void RemoveStock(Stock stock)
         {
             if (ContainsStock(stock))
             {
                 Stocks.Remove(stock.Name.ToLower());
             }
             else
             {
                 throw new StockExchangeException("No stock " + stock.Name + " in index.");
             }
         }

         public bool ContainsStock(Stock stock)
         {
             return Stocks.ContainsKey(stock.Name.ToLower());
         }

         public int GetNumberOfStocksContaining()
         {
             return Stocks.Count;
         }

         abstract public Decimal GetIndexValue(DateTime timeStamp);

     }

     public class WeightedIndex : Index
     {
         public WeightedIndex(string name)
         {
             Type = IndexTypes.WEIGHTED;
             Name = name;
             Stocks = new Dictionary<string, Stock>();
         }

         public override Decimal GetIndexValue(DateTime timeStamp)
         {
             Decimal indexValue = 0;
             if (Stocks.Count == 0)
             {
                 return 0;
             }
             Decimal valueSum = 0;
             foreach (Stock stock in Stocks.Values)
             {
                 valueSum += stock.GetStockPrice(timeStamp) * stock.NumberOfShares;
             }
             Decimal weightFactor = 0;
             Decimal priceSum = 0;
             foreach (Stock stock in Stocks.Values)
             {
                 weightFactor = stock.GetStockPrice(timeStamp) * stock.NumberOfShares / valueSum;
                 priceSum += weightFactor * stock.GetStockPrice(timeStamp);
             }
             indexValue = priceSum;

             return Decimal.Round(indexValue, 3);
         }
     }

     public class AverageIndex : Index
     {

         public AverageIndex(string name)
         {
             Type = IndexTypes.AVERAGE;
             Name = name;
             Stocks = new Dictionary<string, Stock>();
         }

         public override decimal GetIndexValue(DateTime timeStamp)
         {
 	        Decimal indexValue = 0;
            if (Stocks.Count == 0)
            {
                return 0;
            }             
            Decimal valueSum = 0;
            foreach (Stock stock in Stocks.Values)
            {
               valueSum += stock.GetStockPrice(timeStamp) * stock.NumberOfShares;
            }
            Decimal priceSum = 0;
            foreach (Stock stock in Stocks.Values)
            {
                priceSum += stock.GetStockPrice(timeStamp);
            }
            indexValue = priceSum / Stocks.Count;
            return Decimal.Round(indexValue, 3);
        }       
     }

     public static class IndexFactory
     {
         public static Index GetTypeIndex(string name, IndexTypes type)
         {
             if (type == IndexTypes.AVERAGE)
             {
                 return new AverageIndex(name);
             }
             else if (type == IndexTypes.WEIGHTED)
             {
                 return new WeightedIndex(name);
             }
             else
             {
                 throw new StockExchangeException("Index of type " + type + " is not supported.");
             }
         }
     }

             

     public class Portfolio
     {
         //private Dictionary<string, Tuple<Stock, int> stocks;  .NET 3.5 -_-
         private Dictionary<string, Stock> stocks;
         private Dictionary<string, int> stockShares;

         public string PortofolioID;

         public Portfolio(string portofolioID)
         {
             PortofolioID = portofolioID;
             stocks = new Dictionary<string, Stock>();
             stockShares = new Dictionary<string, int>();
         }

         public void AddStockToPortfolio(Stock stock, int numberOfSharesToBuy)
         {
             if (numberOfSharesToBuy > 0)
             {
                 int sharesBought = stock.BuyStock(numberOfSharesToBuy);
                 if (stocks.ContainsKey(stock.Name.ToLower()))
                 {
                     int oldShares = stockShares[stock.Name.ToLower()];
                     stockShares[stock.Name.ToLower()] = oldShares + sharesBought;
                 }
                 else
                 {
                     stocks.Add(stock.Name.ToLower(), stock);
                     stockShares.Add(stock.Name.ToLower(), sharesBought);
                 }
             }
             else
             {
                 throw new StockExchangeException("Can't buy less than one share.");
             }
         }
         public void RemoveStockFromPortfolio(Stock stock, int numberOfSharesToSell)
         {
             if (stocks.ContainsKey(stock.Name.ToLower()))
             {
                 int oldShares = stockShares[stock.Name.ToLower()];
                 if (oldShares > numberOfSharesToSell)
                 {
                     stockShares[stock.Name.ToLower()] = oldShares - numberOfSharesToSell;
                 }
                 else if (oldShares == numberOfSharesToSell)
                 {
                     stockShares.Remove(stock.Name.ToLower());
                     stocks.Remove(stock.Name.ToLower());
                 }
                 else
                 {
                     stockShares.Remove(stock.Name.ToLower());
                     stocks.Remove(stock.Name.ToLower());
                     numberOfSharesToSell = oldShares;
                 }
                 stock.SellStock(numberOfSharesToSell);
             }
             else
             {
                 throw new StockExchangeException("No " + stock.Name + " stock in portofolio " + PortofolioID + ".");
             }
         }

         public void RemoveStockFromPortfolio(Stock stock)
         {
             if (stocks.ContainsKey(stock.Name.ToLower()))
             {
                 stock.SellStock(stockShares[stock.Name.ToLower()]);                
                 stockShares.Remove(stock.Name.ToLower());
                 stocks.Remove(stock.Name.ToLower());     
             }
             else
             {
                 throw new StockExchangeException("No " + stock.Name + " stock in portofolio " + PortofolioID + ".");
             }
         }

         public int GetNumberOfStocks()
         {
             return stocks.Count();
         }

         public bool ContainsStock(Stock stock)
         {
             return stocks.ContainsKey(stock.Name.ToLower());
         }

         public int GetNumberOfStockShares(Stock stock)
         {
             int numberOfShares;
             if (stockShares.TryGetValue(stock.Name.ToLower(), out numberOfShares))
             {
                 return numberOfShares;
             }
             else
             {
                 return 0;
             }
         }

         public Decimal GetPortfolioValue(DateTime timeStamp)
         {
             Decimal value = 0;
             foreach (Stock stock in stocks.Values)
             {
                 value += stockShares[stock.Name.ToLower()] * stock.GetStockPrice(timeStamp);
             }
             return Decimal.Round(value, 3);
         }

         public Decimal GetPortfolioPercentChangeInValueForMonth(int year, int month)
         {
             DateTime monthStart = new DateTime(year, month, 1, 0, 0, 0);
             DateTime monthEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month), 23, 59, 59, 999);

             Decimal valueAtStart = 0;
             Decimal valueAtEnd = 0;
             foreach (Stock stock in stocks.Values)
             {
                 valueAtStart += stockShares[stock.Name.ToLower()] * stock.GetStockPrice(monthStart);
                 valueAtEnd += stockShares[stock.Name.ToLower()] * stock.GetStockPrice(monthEnd);
             }
             if (valueAtStart == 0)
             {
                 throw new StockExchangeException("Starting portfolio value was zero.");
             }
             return Decimal.Round((valueAtEnd - valueAtStart) / valueAtStart * 100, 3);
         }

         
     }

    public class StockPrice
    {
        public Decimal Price { get; set; }
        public DateTime From { get; set; }       

        public StockPrice(Decimal price, DateTime from)
        {
            if (price > 0)
            {
                Price = price;
                From = from;
            }
            else
            {
                throw new StockExchangeException("Price must be greater than zero");
            }                       
        }
    }
}
