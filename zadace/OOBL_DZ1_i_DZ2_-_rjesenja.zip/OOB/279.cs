﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{

    public class Factory
    {

        public static ICalculator CreateCalculator()
        {
            //return calculator object
            return new Kalkulator();
        }

    }

    /**
     * Razred Kalkulator implementira funkcionalnost
     * klasicnog stolnog kalkulatora.
     **/
    public class Kalkulator : ICalculator
    {
        private String firstOperand, secondOperand, lastPressedDigit;
        private Double memoryVar;
        private Char binOpSymbol;
        private Display display;
        private Dictionary<Char, Operation> operations;

        /**
         * Konstruktor razreda Kalkulator
         **/
        public Kalkulator()
        {
            SetCalculator();
        }

        /**
         * Metoda postavlja globalne varijable razreda 
         * Kalkulator na inicijalne vrijednosti.
         **/
        private void SetCalculator()
        {
            this.firstOperand = null;
            this.secondOperand = null;

            this.binOpSymbol = new Char();
            
            this.lastPressedDigit = null;

            this.memoryVar = new Double();
            this.display = new Display("0", 10);

            operations = new Dictionary<Char, Operation>();

        }

        /**
         * Metoda omogucuje unos znaka u kalkulator.
         * Na temelju unijetog znaka pokrecu se potrebne akcije
         * za ostvarivanje trazene funkcionalnosti.
         * Za svaku binarnu ili unarnu operaciju stvara se
         * posebni objekt koji ce obraditi trazenu operciju
         * 
         * @param char inPressedDigit - unos korisnika
         **/
        public void Press(char inPressedDigit)
        {
            if (!display.IsDisplayError())
            {
                if (inPressedDigit >= 48 && inPressedDigit <= 57)
                    ProcessNumber(inPressedDigit);
                else if (inPressedDigit == '+' || inPressedDigit == '-' || inPressedDigit == '*' || inPressedDigit == '/')
                {
                    if (!operations.ContainsKey(inPressedDigit))
                    {
                        BinaryOperation binOp = null;
                        switch (inPressedDigit)
                        {
                            case '+': binOp = new Plus("+"); break;
                            case '-': binOp = new Minus("-"); break;
                            case '*': binOp = new Multiply("*"); break;
                            case '/': binOp = new Divide("/"); break;
                            default: display.PrintError(); break;
                        }
                        operations.Add(inPressedDigit, binOp);
                    }

                    ProcessBinaryOperation(inPressedDigit);
                    this.lastPressedDigit = "BinaryOperation";

                    return;
                }
                else if (inPressedDigit == 'S' || inPressedDigit == 'K' || inPressedDigit == 'T' || inPressedDigit == 'Q' || inPressedDigit == 'R' || inPressedDigit == 'I')
                {
                    if (!operations.ContainsKey(inPressedDigit))
                    {
                        UnaryOperation unaryOp = null;
                        switch (inPressedDigit)
                        {
                            case 'S': unaryOp = new Sinus("S"); break;
                            case 'K': unaryOp = new Cosinus("K"); break;
                            case 'T': unaryOp = new Tangens("T"); break;
                            case 'Q': unaryOp = new Square("Q"); break;
                            case 'R': unaryOp = new SquareRoot("R"); break;
                            case 'I': unaryOp = new Inverse("I"); break;
                            default: display.PrintError(); break;
                        }
                        operations.Add(inPressedDigit, unaryOp);
                    }
                    ProcessUnaryOperation( ((UnaryOperation)operations[inPressedDigit]) ); 
                }
                else
                {
                    switch (inPressedDigit)
                    {
                        case '=': ProcessEqual(); break;
                        case ',': ProcessDecimalPoint(); break;
                        case 'M': ProcessSign(); break;
                        case 'P': SetMemoryContent(); break;
                        case 'G': GetMemoryContent(); break;

                        default: display.PrintError(); break;
                    }
                }
            }

            if (inPressedDigit == 'C')
                display.ClearDisplay();
            else if (inPressedDigit == 'O')
                SetCalculator();

            lastPressedDigit = inPressedDigit.ToString();
        }

        /**
         * Metoda obradjuje slucaj unosa znamenke od strane korisnika.
         * Unijeta znamenka moze biti dio nekog prije unijetog 
         * broja ili pocetak novog broja na ekranu
         * 
         * @param char numberChar - znamenka
         **/
        public void ProcessNumber(char numberChar)
        {
            String numberString = numberChar.ToString();

            if (display.IsDisplayDefault())
                display.DisplayText = numberString;
            else if (display.DisplayTextDataTaken)
            {
                display.DisplayText = numberString;
                initializeOperationParameters();
            }
            else if (!display.DisplayTextDataTaken && !display.CheckPossibleOverflow())
                display.AppendToDisplay(numberString);
        }

        /**
         * Metoda se zove ukoliko je korisnik unio decimalnu tocku.
         * Decimalna tocka se nadodaje na vec unijeti broj (ili 0).
        **/
        public void ProcessDecimalPoint()
        {
            if (display.IsDisplayDefault())
                display.AppendToDisplay(",");
            else if (display.DisplayTextDataTaken)
            {
                display.ClearDisplay();
                display.AppendToDisplay(",");

                initializeOperationParameters();
            }
            else if (!display.DisplayTextDataTaken && !display.DisplayText.Contains(",") && !display.CheckPossibleOverflow())
                display.AppendToDisplay(",");
        }

        /**
         * Metoda se zove prilikom unosa znamenke ili decimalne
         * tocke. Ako unos prethodno naverenih znakova znaci 
         * pocetak nove operacije, podaci vezani za prethodnu operaciju
         * se brisu.
        **/
        public void initializeOperationParameters()
        {
            display.DisplayTextDataTaken = false;

            if (lastPressedDigit.CompareTo("=") == 0)
            {
                firstOperand = null; secondOperand = null;
                binOpSymbol = new Char();
            }
        }

        /**
         * Metoda obradjuje slucaj kada korisnik unese 
         * znak za promjenu predznaka broja na ekranu.
         * Predznak broja na ekranu se mijenja samo ako
         * taj broj nije 0.
        **/
        public void ProcessSign()
        {
            if (!display.IsDisplayDefault())
            {
                if (Math.Sign(Convert.ToDouble(display.DisplayText)) == 1)
                {
                    String numNegative = "-" + display.DisplayText;
                    display.DisplayText = numNegative;
                }
                else
                {
                    Double numDoublePositive = 0.0 - Convert.ToDouble(display.DisplayText);
                    display.DisplayText = Convert.ToString(numDoublePositive);
                }
            }
        }

        /**
         * Metoda obradjuje slucaj prilikom unosa znaka za unarnu operaciju.
         * Poziva metodu za izvrsavanje unarne operacije nad odredjenim
         * objektom i metode za provjeru te eventualno zaokruzivanje
         * rezultata.
         * 
         * @param UnaryOperation opObject - objekt koji izvrsava specificnu
         *                                  unarnu operaciju
        **/
        public void ProcessUnaryOperation(UnaryOperation opObject)
        {
            opObject.executeUnaryOperation(Convert.ToDouble(display.DisplayText));

            if (validateResult(opObject.Result))
                display.DisplayText = display.ResultRounding(opObject.Result.ToString());
           
            display.DisplayTextDataTaken = true;
        }

        /**
         * Metoda obradjuje slucaj unosa znaka za binarnu operaciju.
         * Postavlja operande, poziva metodu za izvrsavanje binarne 
         * operacije nad odredjenim objektom i metode za provjeru te
         * eventualno zaokruzivanje rezultata.
         * 
         * @param Char currentBinaryOpKey - kljuc (oznaka) trenutne
         *                                  binarne operacije
        **/
        public void ProcessBinaryOperation(Char currentBinaryOpKey)
        {
            display.CheckDisplayTextRedundancy();

            if (firstOperand == null)
            {
                firstOperand = display.DisplayText;

                this.binOpSymbol = currentBinaryOpKey;
                display.DisplayTextDataTaken = true;
            }
            else if ( firstOperand != null )
            {
                if (lastPressedDigit.CompareTo("BinaryOperation") != 0 && lastPressedDigit.CompareTo("=") != 0)
                {
                    secondOperand = display.DisplayText;

                    checkAndSetBinaryOperation();

                    this.binOpSymbol = currentBinaryOpKey;
                }
                else
                    this.binOpSymbol = currentBinaryOpKey;
            }
        }

        /**
         * Metoda obraduje scenarij prilikom poziva znaka jednakosti.
         * Ukoliko je korisnik nekad prije unosa znaka jednakosti unio
         * znak za binarnu operaciju, pozivaju se metode za izvrsavanje
         * trazene operacije i provjeru dobivenog rezulata.
        **/
        public void ProcessEqual()
        {
            display.CheckDisplayTextRedundancy();

            if ( firstOperand != null )
            {
                if (lastPressedDigit.CompareTo("=") != 0)
                    secondOperand = display.DisplayText;

                checkAndSetBinaryOperation();

                display.DisplayTextDataTaken = true;
            }
        }

        /**
         * Metoda poziva metodu za izvrsavanje binarne operacije
         * i metode za provjeru i eventualno zaokruzivanje rezultata.
        **/
        public void checkAndSetBinaryOperation()
        {
            ((BinaryOperation)operations[this.binOpSymbol]).executeBinaryOperation(Convert.ToDouble(firstOperand), Convert.ToDouble(secondOperand));

            if( validateResult(operations[this.binOpSymbol].Result) )
                firstOperand = display.DisplayText = display.ResultRounding(operations[this.binOpSymbol].Result.ToString());
            
            display.DisplayTextDataTaken = true;
        }

        /**
         * Metoda provjerava ispravnost rezultata (valjanost rezultata
         * i mogucnost prikaza na ekranu). Ukoliko rezultat nije valjan
         * ili se ne moze prikazati na ekranu, ispisuje se pogreska.
         * 
         * @param Double currentResult - rezultat ciju valjanost treba povjeriti
         * @return bool - true ako je rezultat valjan, false inace
        **/
        public bool validateResult(Double currentResult)
        {
            try
            {
                if (double.IsNaN(currentResult) || double.IsInfinity(currentResult))
                    throw new ArithmeticException();
            }
            catch (ArithmeticException)
            {
                display.PrintError();
                return false;
            }

            if (display.CheckResultValueOverFlow(currentResult.ToString()))
            {
                display.PrintError();
                return false;
            }
            return true;
        }

        /**
         * Metoda sprema trenutne podatke s ekrana kalkulatora
         * u varijablu koja predstavlja memoriju
        **/
        public void SetMemoryContent()
        {
            memoryVar = Convert.ToDouble(display.DisplayText);
        }

        /**
         * Metoda dohvaca sadrzaj varijable koja predstavlja
         * memoriju i prikazuje na ekranu
        **/
        public void GetMemoryContent()
        {
            display.DisplayText = Convert.ToString(memoryVar);
        }

        /**
         * Metoda omogucuje uvid u trenutno stanje ekrana
         * kalkulatora
         **/
        public string GetCurrentDisplayState()
        {
            return this.display.DisplayText;
        }
    }

    /**
     * Razred Display predstavlja ekran kalkulatora. 
     * Sadrzi metode za dohvat i prikaz sadrzaja ekranu 
     * te za provjeru ispravnosti sadrzaja za prikaz na 
     * ekranu i eventualnu prilagodbu za isto.
     **/
    public class Display
    {

        private String displayText;
        private bool displayTextDataTaken;
        private int maxNumOfDigits;

        /**
         * Konstruktor razreda Display
         * Postavlja inicijane vrijednosti podataka bitnih za 
         * prikaz na ekranu. Ekran inicijalno pokazuje 0.
         * 
         * @param String displayText - tekst koji se treba prikazati na ekranu
         *        int maxNumOfDigits - maksimalni dopusteni broj znakova 
         **/
        public Display(String displayText, int maxNumOfDigits)
        {
            this.displayText = displayText;
            this.displayTextDataTaken = false;
            this.maxNumOfDigits = maxNumOfDigits;
        }

        /**
         * Metoda za ispis pogreske.
         **/
        public void PrintError()
        {
            this.displayText = "-E-";
        }

        /**
         * Metoda ispituje stanje ekrana- odnosno prikazana
         * li je na ekranu pogreska. 
         * 
         * @return bool true - prikazana je pogreska
         *              false - prikazani su neki drugi znak/ovi
        **/
        public bool IsDisplayError()
        {
            if (displayText.CompareTo("-E-") == 0)
                return true;

            return false;
        }


        /**
         * Metoda za resetiranje ekrana.
         **/
        public void ClearDisplay()
        {
            this.displayText = "0";
        }

        /**
         * Metoda za ispitivanje je lina ekranu 
         * prikazana 0 (inicijalna postavka).
         * 
         * @return bool true - prikazana je nula
         *              false - prikazani su neki drugi znak/ovi
        **/
        public bool IsDisplayDefault()
        {
            if (displayText.CompareTo("0") == 0)
                return true;

            return false;
        }

        /**
         * Metoda provjerava je li na ekranu prikazan maksimalni 
         * bopusteni broj znamenki.
         * 
         * @return bool true - prikazan je maximalan broj znamenki
         *              false - nije prikazan je maximalan broj znamenki
        **/
        public bool CheckPossibleOverflow()
        {
            int numOfDigits = displayText.Count(c => Char.IsDigit(c));

            if (numOfDigits == maxNumOfDigits)
                return true;
            else
                return false;
        }

        /**
         * Metoda dodaje znak na sadrzaj prikazan na ekranu.
         * 
         * @param String character - znak koji se dodaje
        **/
        public void AppendToDisplay(String character)
        {
            displayText += character;
        }

        /**
         * Metoda na temelju maksimalnog dopustnog broja znakova na 
         * ekranu generira najveci broj koji se prilikom zaokruzivanja 
         * moze prikazati
         * 
         * @return String - najveci deciamlni broj koji se moze prikazati 
         *                  na ekranu nakon zaokruzivanja
         **/
        public String ComputeFinalValidResult()
        {
            StringBuilder number = new StringBuilder("9");

            for (int i = 1; i < maxNumOfDigits; i += 1)
                number.Append("9");

            double numDouble = Convert.ToDouble(number.ToString());
            double numDoubleDecimal = numDouble;

            while (Math.Round(numDoubleDecimal) == numDouble)
                numDoubleDecimal += 0.1;

            numDoubleDecimal -= 0.1;

            return Convert.ToString(numDoubleDecimal).Replace(".", ",");
        }

        /**
         * Metoda provjerava je li broj znkova predanog rezultata unutar 
         * dozvoljenih granica za prikaz na ekranu.
         * 
         * @param String result - rezultat cija duljina se ispituje
         * @return bool - false - broj znakova rezultata je u dozvoljenim 
         *                        granicama
         *              - true  - broj znakova rezultata je izvan dozvoljenih 
         *                        granica
        **/
        public bool CheckResultDigitsOverflow(String result)
        {
            int numOfDigits = result.Count(c => Char.IsDigit(c));

            if (numOfDigits <= maxNumOfDigits)
                return false;
            else
                return true;
        }

        /**
         * Metoda provjerava je li predani rezultat veći ili manji od najveceg 
         * i najmanjeg decimalnog broja koji se može prikazati na ekranu nakon 
         * zaokruzivanja.
         * 
         * @param String currentResult - rezultat koji se provjerava
         * @return bool - false - rezultat se ne moze prikazati na ekranu
         *              - true  - rezultat se moze prikazati na ekranu
        **/
        public bool CheckResultValueOverFlow(String currentResult)
        {
            Double finalValidResult = Convert.ToDouble(ComputeFinalValidResult());

            if (Math.Round(Convert.ToDecimal(currentResult), 1, MidpointRounding.AwayFromZero) > Convert.ToDecimal(finalValidResult) || Math.Round(Convert.ToDecimal(currentResult), 1, MidpointRounding.AwayFromZero) < Convert.ToDecimal((0.0 - finalValidResult)))
                return true;

            return false;
        }

        /**
         * Metoda prikazuje rezultat na ekranu ukoliko ne prelazi definirani
         * broj znakova. Ako je rezultat decimalni broj, zaokruzuje se na max
         * dopusteni broj znamenki.
         * 
         * @param String currentResult - rezultat koji se treba ispitati
         * @retun String - rezultat spreman za ispis na ekranu
        **/
        public String ResultRounding(String currentResult)
        {
            if (!CheckResultDigitsOverflow(currentResult))
                return currentResult;

            string[] doubleNumberParts = currentResult.Split(',');
            int resultIntegerPartLen = doubleNumberParts[0].Length;

            if (doubleNumberParts[0].Contains("-"))
                resultIntegerPartLen--;

            int roundResultDecimalPartLen = MaxNumOfDisplayDigits - resultIntegerPartLen;

            return Convert.ToString(Math.Round(Convert.ToDouble(currentResult), roundResultDecimalPartLen));
        }

        /**
         * Metoda uklanja visak nula i decimalne tocke prikazane na ekranu
         **/
        public void CheckDisplayTextRedundancy()
        {
            if (displayText.Contains(","))
            {
                if (displayText.EndsWith(","))
                    displayText = displayText.Substring(0, displayText.Length - 1);
                else
                {
                    string[] partsOfText = displayText.Split(',');
                    String decimalPartOfText = partsOfText[1];

                    var zeroCount = decimalPartOfText.Count(x => x == '0');

                    if (zeroCount == decimalPartOfText.Length)
                        displayText = partsOfText[0];
                }
            }
        }

        /**
         * Getter i Setter metode za maximalan bopusteni broj
         * znamenki na ekranu
        **/
        public int MaxNumOfDisplayDigits
        {
            get { return maxNumOfDigits; }
            set { maxNumOfDigits = value; }
        }

        /**
         * Getter i Setter metode text koji se prikazuje na ekranu
         **/
        public String DisplayText
        {
            get { return displayText; }
            set { displayText = value; }
        }

        /**
         * Getter i Setter metode za zastavicu koja oznacava
         * je li text s ekrana uzet prilikom izracunavanja 
         * odredene operacije
         **/
        public bool DisplayTextDataTaken
        {
            get { return displayTextDataTaken; }
            set { displayTextDataTaken = value; }
        }
    }

    /**
     * Abstract razred koji predstavlja racunalnu operaciju
     **/
    public abstract class Operation
    {
        private String symbol;
        protected Double result;

        /**
         * Konstruktor razreda.
         * Postavlja inicijalne vrijednosti
         **/
        public Operation(String symbol)
        {
            this.symbol = symbol;
            this.result = new Double();
        }

        /**
         * Getter metoda za rezultat operacije 
         **/
        public Double Result
        {
            get { return result; }
        }

        /**
         * Getter metoda za znak kojim je 
         * predstavljena operacija
         **/
        public String Symbol
        {
            get { return symbol; }
        }
    }

    /**
     * Abstract razred predstavlja unarnu operaciju
     **/
    public abstract class UnaryOperation : Operation
    {
        /**
         * Konstruktor razreda.
         **/
        public UnaryOperation(String symbol) : base(symbol) { }

        /**
         * Metoda za postavljanje rezultata i pokretanje odredjene 
         * unarne operacije
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         **/
        public void executeUnaryOperation(Double operand)
        {
            this.result = computeOperationResult(operand);
        }

        /**
         * Abstract metoda koju implementiraju podklase i koja se koristi za 
         * izracun odredjene binarne operacije.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public abstract double computeOperationResult(Double operand);
    }

    /**
     * Razred koji predstavlja sinus operaciju
     **/
    public class Sinus : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Sinus(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun sinus operacije.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return Math.Sin(operand);
        }
    }

    /**
     * Razred koji predstavlja kosinus operaciju
     **/
    public class Cosinus : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Cosinus(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun kosinus operacije.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return Math.Cos(operand);
        }
    }

    /**
     * Razred koji predstavlja tangens operaciju
     **/
    public class Tangens : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Tangens(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun tangens operacije.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return Math.Tan(operand);
        }
    }

    /**
     * Razred koji predstavlja kvadriranje
     **/
    public class Square : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Square(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun kvadriranja.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return Math.Pow(operand, 2.0);
        }
    }

    /**
     * Razred koji predstavlja korjenjovanje
     **/
    public class SquareRoot : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public SquareRoot(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun korjenovanja.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return Math.Sqrt(operand);
        }
    }

    /**
     * Razred koji predstavlja operaciju za izracun inverza broja
     **/
    public class Inverse : UnaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Inverse(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun inverza broja.
         * 
         * @param Double operand - operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije
         **/
        public override double computeOperationResult(Double operand)
        {
            return (1.0 / (Double)operand);
        }
    }

    /**
     * Abstract razred predstavlja binarnu operaciju
     **/
    public abstract class BinaryOperation : Operation
    {
        /**
         * Konstruktor razreda.
         **/
        public BinaryOperation(String symbol) : base(symbol) { }

        /**
         * Metoda za postavljanje rezultata i pokretanje odredjene 
         * binarne operacije
         * 
         * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
         *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
         **/
        public void executeBinaryOperation(Double firstOperand, Double secondOperand)
        {
            this.result = computeOperationResult(firstOperand, secondOperand);
        }

        /**
         * Abstract metoda koju implementiraju podklase i koja se koristi za izracun odredjene 
         * binarne operacije.
         * 
         * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
         *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije     
         **/
        public abstract double computeOperationResult(Double firstOperand, Double secondOperand);
    }

    /**
     * Razred koji predsaavlja operaciju oduzimanja
     **/
    public class Minus : BinaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Minus(String symbol) : base(symbol) { }

        /**
          * Metoda koja se koristi za izracun operacije oduzimanja.
          * 
          * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
          *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
          * @return double - rezultat operacije     
          **/
        public override double computeOperationResult(Double firstOperand, Double secondOperand)
        {
            return (firstOperand - secondOperand);
        }
    }

    /**
     * Razred koji predstavlja operaciju zbrajanja
     **/
    public class Plus : BinaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Plus(String symbol) : base(symbol) { }

        /**
           * Metoda koja se koristi za izracun operacije zbrajanja.
           * 
           * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
           *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
           * @return double - rezultat operacije     
           **/
        public override double computeOperationResult(Double firstOperand, Double secondOperand)
        {
            return (firstOperand + secondOperand);
        }
    }

    /**
     * Razred koji predstavlja operaciju mnozenja
     **/
    public class Multiply : BinaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Multiply(String symbol) : base(symbol) { }

        /**
          * Metoda koja se koristi za izracun operacije mnozenja.
          * 
          * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
          *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
          * @return double - rezultat operacije     
          **/
        public override double computeOperationResult(Double firstOperand, Double secondOperand)
        {
            return (firstOperand * secondOperand);
        }
    }

    /**
     * Razred koji predstavlja operaciju dijeljenja
     **/
    public class Divide : BinaryOperation
    {
        /**
         * Konstruktor razreda.
         **/
        public Divide(String symbol) : base(symbol) { }

        /**
         * Metoda koja se koristi za izracun operacije dijeljenja.
         * 
         * @param Double firstOperand - prvi operand nad kojim se izvrsava operacija
         *        Double secondOperand - drugi operand nad kojim se izvrsava operacija
         * @return double - rezultat operacije     
         **/
        public override double computeOperationResult(Double firstOperand, Double secondOperand)
        {
            return (firstOperand / secondOperand);
        }
    }

}
