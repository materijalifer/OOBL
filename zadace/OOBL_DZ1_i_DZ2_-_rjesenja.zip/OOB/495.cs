﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public interface IOperator
    {
        double calculate(double secondOperand);
    }

    public class PlusOperator : IOperator
    {
        private double firstOperand;
        private double secondOperand;

        public PlusOperator(double firstOperand)
        {
            this.firstOperand = firstOperand;
        }

        public double calculate(double secondOperand)
        {
            return firstOperand + secondOperand;
        }
    }

    public class MinusOperator : IOperator
    {
        private double firstOperand;
        private double secondOperand;

        public MinusOperator(double firstOperand)
        {
            this.firstOperand = firstOperand;
        }

        public double calculate(double secondOperand)
        {
            return firstOperand - secondOperand;
        }
    }

    public class MultiplyOperator : IOperator
    {
        private double firstOperand;
        private double secondOperand;

        public MultiplyOperator(double firstOperand)
        {
            this.firstOperand = firstOperand;
        }

        public double calculate(double secondOperand)
        {
            return firstOperand * secondOperand;
        }
    }

    public class DivideOperator : IOperator
    {
        private double firstOperand;
        private double secondOperand;

        public DivideOperator(double firstOperand)
        {
            this.firstOperand = firstOperand;
        }

        public double calculate(double secondOperand)
        {
            return firstOperand / secondOperand;
        }
    }

    public class Kalkulator:ICalculator
    {
        private static int SCREEN_SIZE = 10;

        private Double display;
        private Double memoryDisplay;
        private IOperator oper;
        private double lastValue;
        private bool adding;
        private bool decimalAdding;
        private bool wasLastPressOperator;
        private bool displayError;

        public Kalkulator()
        {
            oper = null;
            display = 0;
            adding = true;
            decimalAdding = false;
            wasLastPressOperator = false;
            displayError = false;
        }

        private void appendDigit(int digit)
        {
            if (!adding)
            {
                display = digit;
                adding = true;
                displayError = false;
            }
            else if (getNumberOfDigits() < 10)
            {
                if (decimalAdding)
                {
                    if (display < 0)
                    {
                        display -= digit * Math.Pow(10, -(getNumberOfDecimals() + 1));
                    }
                    else
                    {
                        display += digit * Math.Pow(10, -(getNumberOfDecimals() + 1));
                    }
                }
                else
                {
                    display *= 10;
                    if (display < 0)
                    {
                        display -= digit;
                    }
                    else
                    {
                        display += digit;
                    }
                }
            }
        }

        private int getNumberOfDecimals()
        {
            int count = 0;
            bool foundComma = false;

            foreach(char c in display.ToString())
            {
                if (c == ',')
                {
                    foundComma = true;
                }
                else if (foundComma)
                {
                    count++;
                }
            }

            return count;
        }

        private int getNumberOfNonDecimals()
        {
            int count = 0;

            foreach (char c in display.ToString())
            {
                if (c == ',')
                {
                    return count;
                }
                else if (c != '-')
                {
                    count++;
                }
            }

            return count;
        }

        private int getNumberOfDigits()
        {
            int count = 0;

            if (display.Equals((double)(int)display))
            {
                count = display.ToString().Length;
            }
            else
            {
                count = display.ToString().Length - 1;
            }

            if (display < 0)
            {
                return count - 1;
            }
            else
            {
                return count;
            }
        }

        private void adjustScreen()
        {
            if (display == Double.NaN)
            {
                displayError = true;
            }
            else if (getNumberOfDigits() > SCREEN_SIZE || display > 9999999999)
            {
                if (getNumberOfDecimals() > 0)
                {
                    display = Math.Round(display, SCREEN_SIZE - getNumberOfNonDecimals());
                }
                else
                {
                    displayError = true;
                }
            }
        }

        public void Press(char inPressedDigit)
        {
            if (displayError && inPressedDigit != 'C' && inPressedDigit != 'O')
            {
                return;
            }
            if (char.IsDigit(inPressedDigit))
            {
                appendDigit(inPressedDigit - '0');
                wasLastPressOperator = false;
                return;
            }

            switch (inPressedDigit)
            {
                case '+':
                    if (oper != null)
                    {
                        if (!wasLastPressOperator)
                        {
                            display = oper.calculate(display);
                        }
                        oper = new PlusOperator(display);
                    }
                    else
                    {
                        lastValue = display;
                        oper = new PlusOperator(display);
                    }
                    wasLastPressOperator = true;
                    adding = false;
                    decimalAdding = false;
                    break;
                case '-':
                    if (oper != null)
                    {
                        if (!wasLastPressOperator)
                        {
                            display = oper.calculate(display);
                        }
                        oper = new MinusOperator(display);
                    }
                    else
                    {
                        lastValue = display;
                        oper = new MinusOperator(display);
                    }
                    wasLastPressOperator = true;
                    adding = false;
                    decimalAdding = false;
                    break;
                case '*':
                    if (oper != null)
                    {
                        if (!wasLastPressOperator)
                        {
                            display = oper.calculate(display);
                        }
                        oper = new MultiplyOperator(display);
                    }
                    else
                    {
                        lastValue = display;
                        oper = new MultiplyOperator(display);
                    }
                    wasLastPressOperator = true;
                    adding = false;
                    decimalAdding = false;
                    break;
                case '/':
                    if (oper != null)
                    {
                        if (!wasLastPressOperator)
                        {
                            display = oper.calculate(display);
                        }
                        oper = new DivideOperator(display);
                    }
                    else
                    {
                        lastValue = display;
                        oper = new DivideOperator(display);
                    }
                    wasLastPressOperator = true;
                    adding = false;
                    decimalAdding = false;
                    break;
                case '=':
                    if (wasLastPressOperator)
                    {
                        display = oper.calculate(lastValue);
                    }
                    else if (oper != null)
                    {
                        display = oper.calculate(display);
                    }
                    adjustScreen();
                    wasLastPressOperator = true;
                    adding = false;
                    decimalAdding = false;
                    break;
                case ',':
                    decimalAdding = true;
                    wasLastPressOperator = false;
                    break;
                case 'M':
                    display *= (-1);
                    lastValue = display;
                    break;
                case 'S':
                    display = Math.Sin(display);
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'K':
                    display = Math.Cos(display);
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'T':
                    display = Math.Tan(display);
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'Q':
                    display *= display;
                    adjustScreen();
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'R':
                    display = Math.Sqrt(display);
                    adjustScreen();
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'I':
                    display = 1 / display;
                    adjustScreen();
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    break;
                case 'P':
                    memoryDisplay = display;
                    break;
                case 'G':
                    display = memoryDisplay;
                    if (memoryDisplay.Equals((double)(int)memoryDisplay))
                    {
                        decimalAdding = false;
                    }
                    else
                    {
                        decimalAdding = true;
                    }
                    displayError = false;
                    break;
                case 'C':
                    display = 0;
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    displayError = false;
                    break;
                case 'O':
                    display = 0;
                    memoryDisplay = 0;
                    adding = false;
                    decimalAdding = false;
                    wasLastPressOperator = false;
                    oper = null;
                    displayError = false;
                    break;
            }
        }

        public string GetCurrentDisplayState()
        {
            if (displayError)
            {
                return "-E-";
            }

            return Math.Round(display, 10 - getNumberOfNonDecimals()).ToString();
        }
    }


}
