﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class StockExchange : IStockExchange
    {
        const int DECIMALPLACES = 3;
        List<Stock> listOfStocks = new List<Stock>();
        List<Index> listOfIndex = new List<Index>();
        List<Portfolio> listOfPortfilios = new List<Portfolio>();



        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
                if (ReturnStockFromList(inStockName)!=null)
                {
                    throw new StockExchangeException("The stock already exists");
                }
            
            Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inTimeStamp);
            listOfStocks.Add(stock);

        }

        public void DelistStock(string inStockName)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock != null)
            {
                foreach (Index index in listOfIndex)
                {
                    if (index.FindStockInIndex(inStockName) != null)
                    {
                        throw new StockExchangeException("Stock in index");
                    }
                }
                foreach (Portfolio portfolio in listOfPortfilios)
                {
                    if (portfolio.FindStockInPortfolio(inStockName) != null)
                    {
                        throw new StockExchangeException("Portfolio in index");
                    }
                }

                listOfStocks.Remove(stock); }
            else
            { throw new StockExchangeException("Not found"); }
        }

        public bool StockExists(string inStockName)
        {
            if (ReturnStockFromList(inStockName) != null)
            { return true; }
            else
            { return false; }
        }

        public int NumberOfStocks()
        {
            return listOfStocks.Count;
        }

        public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock != null)
            {
                stock.setStockPrice(inStockValue, inIimeStamp);
            }
            else
            {throw new StockExchangeException("Not found");}
        }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock == null)
            { throw new StockExchangeException("Not found"); }
            Price price = stock.GetStockPrice(inTimeStamp);
            if (price == null)
            {  throw new StockExchangeException("Time Error"); }
            return Math.Round(price.getPrice,DECIMALPLACES);

        }

        public decimal GetInitialStockPrice(string inStockName)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock == null)
            { throw new StockExchangeException("Not found"); }
            return Math.Round( stock.GetInitialStockPrice().getPrice,DECIMALPLACES);
        }

        public decimal GetLastStockPrice(string inStockName)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock == null)
            { throw new StockExchangeException("Not found"); }
            return Math.Round( stock.GetLastStockPrice().getPrice,DECIMALPLACES);
        }

        public void CreateIndex(string inIndexName, IndexTypes inIndexType)
        {
            if (ReturnIndexFromList(inIndexName) != null)
            { throw new StockExchangeException("Index already in list"); }
            Index index = IndexFactory.CreateIndex(inIndexName,inIndexType);
            listOfIndex.Add(index);
        }

        public void AddStockToIndex(string inIndexName, string inStockName)
        {
            Index index = ReturnIndexFromList(inIndexName);
            Stock stock = ReturnStockFromList(inStockName);
            if (index == null) { throw new StockExchangeException("Index Not Found"); }
            if (stock == null) { throw new StockExchangeException("Stock Not Found"); }
            
            index.AddStockToIndex(stock);
        }

        public void RemoveStockFromIndex(string inIndexName, string inStockName)
        {
            Index index = ReturnIndexFromList(inIndexName);
            Stock stock = ReturnStockFromList(inStockName);
            if (index == null) { throw new StockExchangeException("Index Not Found"); }
            if (stock == null) { throw new StockExchangeException("Stock Not Found"); }

            index.RemoveStockFromIndex(stock);
        }

        public bool IsStockPartOfIndex(string inIndexName, string inStockName)
        {
            Index index = ReturnIndexFromList(inIndexName);
            Stock stock = ReturnStockFromList(inStockName);
            if (index == null) { throw new StockExchangeException("Index Not Found"); }
            if (stock == null) { throw new StockExchangeException("Stock Not Found"); }

            if (index.FindStockInIndex(stock.StockName) != null)
            { return true; }
            else
            { return false; }
        }

        public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
        {
            Index index = ReturnIndexFromList(inIndexName);
            if (index == null) { throw new StockExchangeException("Index Not Found"); }
            return Math.Round( index.GetIndexValue(inTimeStamp),DECIMALPLACES);
        }

        public bool IndexExists(string inIndexName)
        {
            if (ReturnIndexFromList(inIndexName) != null)
            { return true; }
            else
            { return false; }
        }

        public int NumberOfIndices()
        {
            return listOfIndex.Count;
        }

        public int NumberOfStocksInIndex(string inIndexName)
        {
            Index index = ReturnIndexFromList(inIndexName);
            if (index == null) { throw new StockExchangeException("Index Not Found"); }
            return index.StockCount();
        }

        public void CreatePortfolio(string inPortfolioID)
        {
            if (ReturnPortfolioFromList(inPortfolioID) != null)
            { throw new StockExchangeException("Portfolio already exists"); }
            Portfolio portfilio = new Portfolio(inPortfolioID);
            listOfPortfilios.Add(portfilio);
        }

        public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Stock stock = ReturnStockFromList(inStockName);
            if (stock == null) { throw new StockExchangeException("Not found"); }
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            if (stock.NumberOfShares < numberOfShares) { throw new StockExchangeException("Wrong number of shares"); }
            if ((stock.NumberOfShares - NumberOfSharesInProtfolios(inStockName)) < numberOfShares)
             { throw new StockExchangeException("Wrong number of shares"); }

            portfolio.AddStockToPortfolio(stock,numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            portfolio.RemoveStockFromPortfolio(inStockName, numberOfShares);
        }

        public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            portfolio.RemoveStockFromPortfolio(inStockName);
        }

        public int NumberOfPortfolios()
        {
            return listOfPortfilios.Count;
        }

        public int NumberOfStocksInPortfolio(string inPortfolioID)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            return portfolio.NumberOfStocksInPortfolio();
        }

        public bool PortfolioExists(string inPortfolioID)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio != null) { return true; }
            else { return false; }
        }

        public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            Stock stock =  portfolio.FindStockInPortfolio(inStockName);
            if (stock != null) { return true; }
            else { return false; }
        }

        public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            return portfolio.NumberOfSharesAtPortfolio(inStockName);
        }

        public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            return Math.Round(portfolio.GetPortfolioValue(timeStamp),DECIMALPLACES);
        }

        public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
        {
            Portfolio portfolio = ReturnPortfolioFromList(inPortfolioID);
            if (portfolio == null) { throw new StockExchangeException("Not found"); }
            return Math.Round(portfolio.PercentChangePerMonth(Year,Month) ,DECIMALPLACES);
        }

        private Stock ReturnStockFromList(string StockName)
        {
            foreach (Stock stockInList in listOfStocks)
            {
                if(stockInList.StockName.ToUpper()==StockName.ToUpper())
                { return stockInList; }
            }
            return null;
        }

        private Index ReturnIndexFromList(string IndexName)
        {
            foreach (Index index in listOfIndex)
            {
                if (index.IndexName.ToUpper() == IndexName.ToUpper())
                { return index; }
            }
            return null;
        }

        private Portfolio ReturnPortfolioFromList(string PortfolioID)
        {
            foreach (Portfolio portfolio in listOfPortfilios)
            {
                if(portfolio.PortfolioID==PortfolioID)
                { return portfolio; }
            }
            return null;
        }

        private int NumberOfSharesInProtfolios(string StockName)
        {
            int sum = 0;
            foreach (Portfolio protfolio in listOfPortfilios)
            {
                sum += protfolio.NumberOfSharesAtPortfolio(StockName);
            }
            return sum;
        }

    }

    /// <summary>
    /// Dodane klase
    /// </summary>
    
    public class Price
    {
        decimal price;
        DateTime timeStamp;

        public Price(Decimal inPrice, DateTime inTimeStamp)
        {
            this.price = inPrice;
            this.timeStamp = inTimeStamp;
        }
        public DateTime TimeStamp
        {
            get { return this.timeStamp; }
        }

        public decimal getPrice
        {
            get { return this.price; }
        }

    }

    public class Stock
    {
        string stockName;
        public string StockName
        {
            get { return this.stockName; }
        }
        long numberOfShares;
        public long NumberOfShares
        {
            get { return this.numberOfShares; }
        }
        Price initialPrice;
        List<Price> listOfPrices = new List<Price>();

        public Stock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            if (inNumberOfShares <= 0) { throw new StockExchangeException("Negative Number of Shares"); }
            if (inInitialPrice <= 0) { throw new StockExchangeException("Negative Price"); }
            this.stockName = inStockName;
            this.numberOfShares = inNumberOfShares;
            initialPrice = new Price(inInitialPrice, inTimeStamp);
            listOfPrices.Add(initialPrice);
        }

        public void setStockPrice(decimal inPrice, DateTime inTimeStamp)
        {
            if (TimeStampExists(inTimeStamp))
            { throw new StockExchangeException("Time already exists"); }
            Price price = new Price(inPrice, inTimeStamp);
            listOfPrices.Add(price);
        }

        public bool TimeStampExists(DateTime inTimeStamp)
        {
            foreach (Price price in listOfPrices)
            {
                if (price.TimeStamp == inTimeStamp)
                { return true; }
            }
            return false;
        }

        private List<Price> SortListOfPriceByDate(List<Price> list)
        {
            List<Price> newList = new List<Price>(list);
            List<Price> sortedList = new List<Price>();
            int i = 0;
            while (newList.Count != 0)
            {
               Price price = FindOldestPrice(newList);
               newList.Remove(price);
               sortedList.Add(price);
               i++;
            }
            return sortedList;
        }

        private Price FindOldestPrice(List<Price> list)
        {
            DateTime dateTime = new DateTime(2500, 1, 1, 12, 00, 00, 000);
            Price min = new Price(0, dateTime);
            foreach (Price price in list)
            {
                if (price.TimeStamp < min.TimeStamp)
                {
                    min = price;
                }
            }
            return min;
        }
   

        public Price GetStockPrice(DateTime inTimeStamp)
        {
            if (inTimeStamp < initialPrice.TimeStamp)
            { return null; }
            Price previous=null;
            List<Price> sortedList = SortListOfPriceByDate(listOfPrices);
            foreach (Price price in sortedList)
            {
                if (inTimeStamp < price.TimeStamp)
                { return previous; }
                previous = price;
            }
            return sortedList.Last<Price>();
        }


        public Price GetInitialStockPrice()
        {
            return initialPrice;
        }

        public Price GetLastStockPrice()
        {
            List<Price> sortedList = SortListOfPriceByDate(listOfPrices);
            return sortedList.Last<Price>();
        }

    }

    public abstract class Index
    {
       protected string indexName;
       public string IndexName
       {
           get { return this.indexName; }
       }
       protected List<Stock> indexListOfStocks = new List<Stock>();
       protected IndexTypes typeOfIndex;

       public void AddStockToIndex(Stock stock)
       {
           if (FindStockInIndex(stock.StockName) != null) { throw new StockExchangeException("Stock already in index"); }
           indexListOfStocks.Add(stock);
       }

       public void RemoveStockFromIndex(Stock stock)
       {
           if(FindStockInIndex(stock.StockName)!=null)
           {
               indexListOfStocks.Remove(stock);
           }
           else
           {
               throw new StockExchangeException("Stock not in the list");
           }
       }

       public int StockCount()
       {
           return indexListOfStocks.Count;
       }

       public Stock FindStockInIndex(string inStockName)
       {
           foreach (Stock stock in indexListOfStocks)
           {
               if (stock.StockName == inStockName)
               { return stock; }
           }
           return null;
       }

        public abstract decimal GetIndexValue(DateTime inTimeStamp);
        
       
    }

    public class AverageIndex : Index
    {
        public AverageIndex(string indexName)
        {
            this.indexName = indexName;
            this.typeOfIndex = IndexTypes.AVERAGE;
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal sum=0;
            int br=0;
            foreach (Stock stock in indexListOfStocks)
            {
                sum += stock.GetStockPrice(inTimeStamp).getPrice;
                br++;
            }
            return  (sum / br);
        }
    }

    public class WeightedIndex : Index
    {
        public WeightedIndex(string indexName)
        {
            this.indexName = indexName;
            this.typeOfIndex = IndexTypes.WEIGHTED;
        }

        public override decimal GetIndexValue(DateTime inTimeStamp)
        {
            decimal sumOfAllStocksInIndex = 0;
            decimal sum = 0;
            foreach (Stock stock in indexListOfStocks)
            { sumOfAllStocksInIndex += (stock.GetLastStockPrice().getPrice*stock.NumberOfShares); }

            foreach (Stock stock in indexListOfStocks)
            {
                decimal factor = (stock.NumberOfShares * stock.GetStockPrice(inTimeStamp).getPrice)/sumOfAllStocksInIndex;
                sum += factor * stock.GetStockPrice(inTimeStamp).getPrice;
            }
            return sum;
        }
    }

    public static class IndexFactory
    {
        public static Index CreateIndex(string indexName,IndexTypes typeOfIndex)
        {
            if (typeOfIndex == IndexTypes.AVERAGE)
            {
                return new AverageIndex(indexName);
            }
            else if (typeOfIndex == IndexTypes.WEIGHTED)
            {
                return new WeightedIndex(indexName);
            }
            else
            {
                throw new StockExchangeException("Wrong type of Index");
            }
        }
    }

    public class Portfolio
    {
        string portfolioID;
        Dictionary<Stock, int> dictOfStocks = new Dictionary<Stock, int>();
        public string PortfolioID
        {
            get { return this.portfolioID; }
        }

        public Portfolio(string inPortfolioID)
        {
            this.portfolioID = inPortfolioID;
        }

        public void AddStockToPortfolio(Stock stock, int numberOfShares)
        {
            if (numberOfShares < 0)
            { throw new StockExchangeException("Wrong Number of Shares"); }
            if (FindStockInPortfolio(stock.StockName) != null)
            {
                dictOfStocks[stock] = dictOfStocks[stock] + numberOfShares;
            }
            else
            {
                dictOfStocks.Add(stock, numberOfShares);
            }
        }

        public int NumberOfSharesAtPortfolio(string inStockName)
        {
            foreach (KeyValuePair<Stock, int> Stock_NumberOfShares in dictOfStocks)
            {
                if (Stock_NumberOfShares.Key.StockName == inStockName)
                { return Stock_NumberOfShares.Value; }
            }
            return 0;
        }

        public Stock FindStockInPortfolio(string inStockName)
        {
            foreach (KeyValuePair<Stock, int> Stock_NumberOfShares in dictOfStocks)
            {
                if (Stock_NumberOfShares.Key.StockName == inStockName)
                {
                    return Stock_NumberOfShares.Key;
                }
            }
            return null;
            
        }

        public void RemoveStockFromPortfolio(string inStockName, int NumberOfShares)
        {
            if (NumberOfShares < 0)
            { throw new StockExchangeException("Wrong Number of Shares"); }
            Stock stock = FindStockInPortfolio(inStockName);
            if (stock == null) { throw new StockExchangeException("Stock not in the list"); }
            int numberOfSharesPorfolio=NumberOfSharesAtPortfolio(inStockName);

            if (numberOfSharesPorfolio < NumberOfShares)
            { throw new StockExchangeException("Wrong Number of Shares"); }
            else if (numberOfSharesPorfolio > NumberOfShares)
            {
                 stock = FindStockInPortfolio(inStockName);
                dictOfStocks[stock] = dictOfStocks[stock] - NumberOfShares;
            }
            else if (numberOfSharesPorfolio == NumberOfShares)
            {
                 stock = FindStockInPortfolio(inStockName);
                dictOfStocks.Remove(stock);
            }
        }

        public void RemoveStockFromPortfolio(string inStockName)
        {
            Stock stock = FindStockInPortfolio(inStockName);
            if (stock == null) { throw new StockExchangeException("Stock not in the list"); }
            dictOfStocks.Remove(stock);
        }

        public int NumberOfStocksInPortfolio()
        {
            return dictOfStocks.Count;
        }

        public decimal GetPortfolioValue(DateTime timeStamp)
        {
            decimal sum = 0;
            foreach (KeyValuePair<Stock, int> Stock_NumberOfShares in dictOfStocks)
            {
                if (Stock_NumberOfShares.Key.GetStockPrice(timeStamp) == null)
                { throw new StockExchangeException("Stock price not defined"); }
                sum += Stock_NumberOfShares.Value * Stock_NumberOfShares.Key.GetStockPrice(timeStamp).getPrice;
            }
            return sum;
        }

        public decimal PercentChangePerMonth(int Year, int Month)
        {
            DateTime firstDay = new DateTime(Year, Month, 1, 00,00,00,000);
            DateTime lastDay = new DateTime(Year, Month, DateTime.DaysInMonth(Year,Month),23, 59, 59, 999);
            decimal firsDayValue = GetPortfolioValue(firstDay);
            decimal lastDayValue = GetPortfolioValue(lastDay);
            decimal percentage =((lastDayValue-firsDayValue)/firsDayValue)*100;
            return percentage;
        }

    }


}
