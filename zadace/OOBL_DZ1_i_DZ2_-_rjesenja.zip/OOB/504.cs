﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator : ICalculator
    {
        private bool initial = true;
        private bool doneUnary = false;
        private bool pressedEqual = false;
        private int state = 0;
        private string display = "0";
        private char operation = 'N';
        private char unaryOperation;
        private Decimal oper1 = 0;
        private Decimal rez = 0;
        private bool ready = false;
        private string memory = "";
        private char pressedDigit;
        private char[] binaryOp = { '+', '-', '*', '/', '=' };
        private char[] unaryOp = { 'M', 'S', 'K', 'T', 'Q', 'R', 'I', 'C', 'O' };
        private char[] memoryOp = { 'P', 'G' };
        private char[] digit = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        private List<char> operator_list = new List<char>();

        private void resetCalc()
        {
            this.rez = 0;
            this.display = "0";
            this.ready = false;
            this.initial = true;
            this.doneUnary = false;
            this.oper1 = 0;
            this.state = 0;
            this.memory = "";
            this.pressedEqual = false;
        }
        private void miniReset()
        {
            this.rez = 0;
            this.display = "0";
            this.ready = false;
            this.initial = true;
            this.doneUnary = false;
            this.oper1 = 0;
            this.state = 0;
            this.pressedEqual = false;
        }
        private bool containsBinary(char query)
        {
            for (int i = 0; i < this.binaryOp.Length; i++)
                if (this.binaryOp[i] == query)
                    return true;
            return false;
        }

        private bool containsUnary(char query)
        {
            for (int i = 0; i < this.unaryOp.Length; i++)
                if (this.unaryOp[i] == query)
                    return true;
            return false;
        }

        private bool containsDigit(char query)
        {
            for (int i = 0; i < this.digit.Length; i++)
                if (this.digit[i] == query)
                    return true;
            return false;
        }

        private void saveDigit()
        {
            this.memory = this.memory + Convert.ToString(this.pressedDigit);
        }
        private void getNumber()
        {
            this.display = this.memory;
        }
        private void resetMemory()
        {
            this.memory = "";
        }
        private int countDigits()
        {
            int num = 0;
            int last_pos = this.display.Length;
            for (int i = 0; i < this.display.Length; i++)
            {
                if (this.containsDigit(this.display[i]) || this.display[i] == '0')
                    num++;
                if (num > 10)
                    last_pos = i;

            }
            return last_pos;
        }

        private void setLimits(int position)
        {
            this.display = this.display.Substring(0, position);
        }

        private void stripComma()
        {
            if (this.display[this.display.Length - 1] == ',')
                this.display = this.display.Substring(0, this.display.Length - 1);
        }

        private void stripZeros()
        {
            int position;
            bool all_zeros = true;
            if ((position = this.display.IndexOf(',')) != -1)
            {
                for (int i = position + 1; i < this.display.Length; i++)
                    if (this.display[i] != '0')
                        all_zeros = false;
                if (all_zeros)
                    this.display = this.display.Substring(0, position);
            }
        }

        private void checkRealLength()
        {
            Decimal num;
            string limited;
            int act_length = 0;
            if (this.display != "-E-")
            {
                num = Convert.ToDecimal(this.display);
                num = Math.Truncate(num);
                limited = Convert.ToString(num);
                for (int i = 0; i < limited.Length; i++)
                    if (this.containsDigit(limited[i]) || limited[i] == '0')
                        act_length = act_length + 1;
                if (act_length >= 10)
                {
                    this.display = "-E-";
                    this.state = 4;
                }
            }

        }

        public int roundTo()
        {
            int[] part_len = { 0, 0 };
            int num = 0;
            int round = 0;
            Decimal rounded;
            if (this.display != "-E-")
            {
                string[] parts = this.display.Split(',');
                foreach (string part in parts)
                {
                    part_len[num++] = part.Length;
                }
                if (parts[0][0] == '-')
                    round = 11 - part_len[0];
                else
                    round = 10 - part_len[0];
                if (round > 0)
                {
                    rounded = Math.Round(Convert.ToDecimal(this.display), round);
                    this.display = Convert.ToString(rounded);
                    if (this.display.IndexOf(',') != -1)
                        this.display = this.display.TrimEnd('0');
                }

            }
            return round;


        }
        private bool special()
        {
            if ((this.unaryOperation == 'M') || (this.unaryOperation == 'C') || (this.unaryOperation == 'O'))
            {
                return true;
            }
            return false;
        }

        private void izracunaj()
        {
            switch (this.operation)
            {
                case '+':
                    this.rez = this.rez + this.oper1;
                    this.display = this.rez.ToString("G29");
                    this.oper1 = this.rez;
                    break;
                case '-':
                    this.rez = this.rez - this.oper1;
                    this.display = this.rez.ToString("G29");
                    this.oper1 = this.rez;
                    break;
                case '*':
                    this.rez = this.rez * this.oper1;
                    this.display = this.rez.ToString("G29");
                    this.oper1 = this.rez;
                    break;
                case '/':
                    if (this.oper1 == 0)
                    {
                        this.display = "-E-";
                        this.state = 4;
                    }
                    else
                    {
                        this.rez = this.rez / this.oper1;
                        this.oper1 = this.rez;
                        this.display = this.rez.ToString("G29");
                    }
                    break;
                case '=':
                    this.rez = this.rez;
                    this.oper1 = this.rez;
                    break;

            }
        }
        private void calculateUnary()
        {
            Decimal num;
            switch (this.unaryOperation)
            {
                case 'M':
                    num = (-1) * Convert.ToDecimal(this.display);
                    this.display = num.ToString("G29");
                    break;
                case 'S':
                    num = Convert.ToDecimal(Math.Sin((double)(Convert.ToDecimal(this.display))));
                    this.display = num.ToString("G29");
                    this.oper1 = Convert.ToDecimal(this.display);
                    break;
                case 'K':
                    num = Convert.ToDecimal(Math.Cos((double)(Convert.ToDecimal(this.display))));
                    this.display = num.ToString("G29");
                    this.oper1 = Convert.ToDecimal(this.display);
                    break;
                case 'T':
                    num = Convert.ToDecimal(Math.Tan((double)(Convert.ToDecimal(this.display))));
                    this.display = num.ToString("G29");
                    this.oper1 = Convert.ToDecimal(this.display);
                    break;
                case 'Q':
                    num = Convert.ToDecimal(Math.Pow((double)(Convert.ToDecimal(this.display)), 2));
                    this.display = num.ToString("G29");
                    this.oper1 = Convert.ToDecimal(this.display);
                    break;
                case 'R':
                    Decimal test = Convert.ToDecimal(this.display);
                    if (test >= 0)
                    {
                        num = Convert.ToDecimal(Math.Sqrt((double)(Convert.ToDecimal(this.display))));
                        this.display = num.ToString("G29");
                        this.oper1 = Convert.ToDecimal(this.display);
                    }
                    else
                    {
                        this.display = "-E-";
                        this.state = 4;
                    }
                    break;
                case 'I':
                    if (this.display == "0")
                    {
                        this.display = "-E-";
                        this.state = 4;
                    }
                    else
                    {
                        num = 1 / Convert.ToDecimal(this.display);
                        this.display = num.ToString("G29");
                        this.oper1 = Convert.ToDecimal(this.display);
                    }
                    break;
                case 'O':
                    this.resetCalc();
                    break;
                case 'C':
                    this.display = "0";
                    this.oper1 = 0;
                    break;

            }
        }
        public void Press(char inPressedDigit)
        {
            this.pressedDigit = inPressedDigit;
            if ((this.containsDigit(this.pressedDigit) == true || (this.pressedDigit == ',') || 
                (this.pressedDigit == '0') || (this.pressedDigit == 'P')) && (this.pressedEqual == true))
            {
                if (this.pressedDigit == 'P')
                    this.memory = this.display;
                this.miniReset();
                this.state = 0;
                if (this.pressedDigit != 'P')
                    this.display = Convert.ToString(this.pressedDigit);
                else
                    this.display = "0";
                this.pressedEqual = false;
            }
            this.pressedEqual = false;
            if ((this.containsDigit(this.pressedDigit) == true || (this.pressedDigit == ',') || 
                (this.pressedDigit == '0')) && (this.doneUnary == true) && (this.special() == false))
            {
                this.miniReset();
                this.state = 1;
                this.display = Convert.ToString(this.pressedDigit);
                this.doneUnary = false;
            }
            else
            {
                this.doneUnary = false;
                if (this.containsBinary(this.pressedDigit))
                    this.operator_list.Add(this.pressedDigit);
                if (this.state == 0)
                {
                    if (this.containsDigit(this.pressedDigit) == true || (this.pressedDigit == ','))
                    {
                        this.state = 1; //stanje akumuliranja znamenaka, nemoj zaboravit za ovo stanje dio s mem. impl.
                        if (this.pressedDigit == ',')
                            this.display = this.display + this.pressedDigit;
                        else
                            this.display = Convert.ToString(this.pressedDigit);
                    }
                    else if (this.pressedDigit == 'K')
                    {
                        this.display = "1";
                    }
                    else if (this.pressedDigit == 'I')
                    {
                        this.display = "-E-";
                        this.state = 4;
                    }
                    else if (this.pressedDigit == '0')
                    {
                        this.display = "0";
                    }
                    else
                    {
                        //this.display = "0";
                        //return this.initDisplay;
                    }
                }
                else if (this.state == 1)
                {
                    if ((this.containsDigit(this.pressedDigit) == true) || (this.pressedDigit == '0') || 
                        ((this.pressedDigit == ',') && (this.display.IndexOf(',') == -1)))
                    {
                        this.state = 1;
                        this.display = this.display + Convert.ToString(this.pressedDigit);
                        this.setLimits(this.countDigits());
                    }
                    else if (this.pressedDigit == 'P')
                    {

                        this.display = this.display.TrimStart('0');
                        this.display = this.display.TrimEnd('0');
                        this.memory = this.display;
                        this.state = 1;
                    }
                    else if (this.pressedDigit == 'G')
                    {
                        this.display = this.memory;
                        this.state = 1;
                    }
                    else if (this.containsUnary(this.pressedDigit))
                    {
                        this.unaryOperation = this.pressedDigit;
                        this.calculateUnary();
                        if (this.display != "-E-")
                        {
                            this.checkRealLength();
                            this.stripZeros();
                            this.stripComma();
                            int position = this.countDigits(); //ovo dodati u binarne
                            this.setLimits(position);
                            this.roundTo();
                            this.oper1 = Convert.ToDecimal(this.display); //SPORNA LINIJA
                            this.state = 1;
                            this.doneUnary = true;
                        }
                        else
                            this.state = 4;
                    }
                    else if (this.containsBinary(this.pressedDigit))
                    {
                        this.stripZeros();
                        this.stripComma();
                        if (this.pressedDigit == '=')
                            this.pressedEqual = true;
                        if (this.initial == true)
                        {
                            this.rez = Convert.ToDecimal(this.display);
                            this.oper1 = this.rez;
                            this.operation = this.pressedDigit;
                            this.initial = false;
                            this.state = 3;

                        }
                        if (this.ready == false)
                        {
                            this.operation = this.pressedDigit;
                            this.state = 3;
                        }
                        else
                        {
                            if (this.display != "-E-")
                            {
                                this.oper1 = Convert.ToDecimal(this.display); //OVO VRATI AKO CE STEKAT
                            }

                            this.izracunaj();
                            if (this.display != "-E-")
                            {
                                this.operation = this.pressedDigit;
                                this.checkRealLength();
                                this.ready = false;
                                this.stripZeros();
                                this.stripComma();
                                this.roundTo();
                                this.state = 3;
                            }
                            else
                                this.state = 4;
                        }
                    }
                }
                else if (this.state == 3) //ready state
                {
                    this.doneUnary = false;
                    if (this.containsBinary(this.pressedDigit) && (this.pressedDigit != '='))
                    {
                        this.oper1 = this.rez;
                        this.state = 3;
                        this.operation = this.pressedDigit;

                    }
                    else if (this.pressedDigit == '=')
                    {
                        this.izracunaj();
                        this.checkRealLength();
                        this.stripZeros();
                        this.stripComma();
                        int position = this.countDigits();
                        this.setLimits(position);
                        this.roundTo();
                        this.state = 3;
                        this.pressedEqual = true;
                    }
                    else if (this.pressedDigit == 'P')
                    {
                        this.checkRealLength();
                        this.stripZeros();
                        this.stripComma();
                        int position = this.countDigits();
                        this.setLimits(position);
                        this.roundTo();
                        this.display = this.display.TrimStart('0');
                        this.display = this.display.TrimEnd('0');
                        this.memory = this.display;
                        this.state = 3;
                    }
                    else if (this.pressedDigit == 'G')
                    {
                        this.display = this.memory;
                        this.oper1 = Convert.ToDecimal(this.display);
                        this.ready = true;
                        this.state = 1;
                    }
                    else if (this.containsUnary(this.pressedDigit))
                    {
                        this.unaryOperation = this.pressedDigit;
                        this.calculateUnary(); //ovdje bi trebalo dodati ogranicenja mozda

                        if (this.display != "-E-")
                        {
                            this.checkRealLength();
                            this.stripZeros();
                            this.stripComma();
                            int position = this.countDigits(); //ovo dodati u binarne
                            this.setLimits(position);
                            this.roundTo();
                            this.stripZeros();
                            this.state = 3;
                        }
                        else
                        {
                            this.state = 4;
                        }
                    }
                    else
                    {
                        this.ready = true;
                        this.initial = false;
                        this.state = 1;
                        this.display = Convert.ToString(this.pressedDigit);


                    }
                }
                else if (this.state == 4) //error state
                    this.doneUnary = false;
                if (this.pressedDigit == 'O')
                {
                    this.state = 0;
                    this.resetCalc();
                }
            }
        }

        public string GetCurrentDisplayState()
        {
            return this.display;
        }
    }
 
}
    