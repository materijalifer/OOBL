﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
     public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }

     class Stock
     {
         public string StockName {get; set;}
         public long NumberOfShares { get; set; }

        public Stock(string stockName, long numberOfShares)
        {
            StockName = stockName.ToUpper();
            NumberOfShares = numberOfShares;
        }
    }

     class StockPrice
     {
         public Stock Stock {get; set;}
         public DateTime TimeStamp { get; set; }
         public Decimal Price { get; set; }
    
         public StockPrice(Stock stock, Decimal initialPrice, DateTime timeStamp)
         {
             Stock = stock;
             Price = initialPrice;
             TimeStamp = timeStamp;
         }
     }

     class Index
     {
         public IndexTypes IndexType { get; set; }
         public String IndexName { get; set; }

         public Index(string indexName, IndexTypes indexType)
         {
             IndexName = indexName;
             IndexType = indexType;
         }
     }

     public class StockExchange : IStockExchange
     {
         private List<Stock> _stocks;
         private List<StockPrice> _stockPrices;
         private List<Index> _indices;
         private Dictionary<string, List<string>> _indexStocks;

         public StockExchange()
         {
             _stocks = new List<Stock>();
             _stockPrices = new List<StockPrice>();
             _indices = new List<Index>();
             _indexStocks = new Dictionary<string, List<string>>();
         }

         public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
         {
             if (inStockName == "")
             {
                 throw new StockExchangeException("Ime dionice ne smije biti prazno!");
             }

             if (inNumberOfShares <= 0)
             {
                 throw new StockExchangeException("Broj dionica mora biti veći ili jednak 0!");
             }

             if (inInitialPrice <= 0)
             {
                 throw new StockExchangeException("Cijena dionice mora biti veća ili jednaka 0!");
             }

             if (_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice već postoji!");
             }

             _stocks.Add(new Stock(inStockName.ToUpper(), inNumberOfShares));
             Stock stock = _stocks.Find(s => s.StockName == inStockName.ToUpper());
             _stockPrices.Add(new StockPrice(stock, inInitialPrice, inTimeStamp));
         }

         public void DelistStock(string inStockName)
         {
             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             _stockPrices.RemoveAll(sp => sp.Stock.StockName == inStockName.ToUpper());
             _stocks.RemoveAll(s => s.StockName == inStockName.ToUpper());
         }

         public bool StockExists(string inStockName)
         {
             return _stocks.Exists(stock => stock.StockName == inStockName.ToUpper());
         }

         public int NumberOfStocks()
         {
             return _stocks.Count;
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             Stock stock = _stocks.Find(s => s.StockName == inStockName.ToUpper());
             _stockPrices.Add(new StockPrice(stock, inStockValue, inIimeStamp));         
         }

         public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
         {
             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             return (from stockPrice in _stockPrices
                     where stockPrice.Stock.StockName == inStockName.ToUpper()
                       && stockPrice.TimeStamp <= inTimeStamp
                     select stockPrice).OrderByDescending(stockPrice => stockPrice.TimeStamp).First().Price;
         }

         public decimal GetInitialStockPrice(string inStockName)
         {
             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             return (from stockPrice in _stockPrices
                        where stockPrice.Stock.StockName == inStockName.ToUpper()
                        select stockPrice).OrderBy(stockPrice => stockPrice.TimeStamp).First().Price;
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             return (from stockPrice in _stockPrices
                     where stockPrice.Stock.StockName == inStockName.ToUpper()
                     select stockPrice).OrderByDescending(stockPrice => stockPrice.TimeStamp).First().Price;
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             if (inIndexName == "")
             {
                 throw new StockExchangeException("Ime indeksa ne smije biti prazno!");
             }

             if (_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa već postoji!");
             }

             _indices.Add(new Index(inIndexName.ToUpper(), inIndexType));             
         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             if (!_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa ne postoji!");
             }

             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             if (!_indexStocks.ContainsKey(inIndexName))
             {
                 _indexStocks[inIndexName] = new List<string>();
                 _indexStocks[inIndexName].Add(inStockName.ToUpper());
             }
             else
             {
                 if (_indexStocks[inIndexName].Contains(inIndexName.ToUpper())) {
                    throw new StockExchangeException("Indeks već sadrži dionicu!");
                 }
                 else {
                    _indexStocks[inIndexName].Add(inStockName.ToUpper());
                 }
             }
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             if (!_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa ne postoji!");
             }

             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             if (!_indexStocks.ContainsKey(inIndexName))
             {
                 throw new StockExchangeException("Ime dionice ne postoji u indeksu!");
             }
             else
             {
                 if (!_indexStocks[inIndexName].Contains(inStockName.ToUpper()))
                 {
                     throw new StockExchangeException("Ime dionice ne postoji u indeksu!");
                 }
                 else
                 {
                     _indexStocks[inIndexName].Remove(inStockName.ToUpper());
                 }
             }
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             if (!_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa ne postoji!");
             }

             if (!_stocks.Exists(s => s.StockName == inStockName.ToUpper()))
             {
                 throw new StockExchangeException("Ime dionice ne postoji!");
             }

             var result = false;

             if (!_indexStocks.ContainsKey(inIndexName))
             {
                 result = false;
             }
             else
             {
                 if (!_indexStocks[inIndexName].Contains(inStockName.ToUpper()))
                 {
                     result = false;
                 }
                 else
                 {
                     result = true;
                 }
             }

             return result;
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             if (!_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa ne postoji!");
             }

             if (!_indexStocks.ContainsKey(inIndexName))
             {
                 new StockExchangeException("Indeks ne sadrži nijednu dionicu!");
             }
             else
             {
                 Index index = _indices.Find(i => i.IndexName == inIndexName.ToUpper());
                 if (index.IndexType == IndexTypes.AVERAGE)
                 {
                     decimal result = 0.000M;                     
                     foreach (string stockName in _indexStocks[inIndexName])
                     {
                         Stock stock = _stocks.Find(s => s.StockName == stockName);
                         result += stock.NumberOfShares * GetStockPrice(stockName, inTimeStamp);
                     }
                     result /= _indexStocks[inIndexName].Count;
                     return Math.Round(result, 3);
                 }
                 else if (index.IndexType == IndexTypes.WEIGHTED)
                 {
                     decimal result = 0.000M;
                     decimal totalIndexStockSum = 0.000M;
                     foreach (string stockName in _indexStocks[inIndexName])
                     {
                         Stock stock = _stocks.Find(s => s.StockName == stockName);
                         totalIndexStockSum += stock.NumberOfShares * GetStockPrice(stockName, inTimeStamp);
                     }
                     foreach (string stockName in _indexStocks[inIndexName])
                     {
                         Stock stock = _stocks.Find(s => s.StockName == stockName);
                         decimal weight = stock.NumberOfShares * GetStockPrice(stockName, inTimeStamp) / totalIndexStockSum;
                         result += weight * stock.NumberOfShares * GetStockPrice(stockName, inTimeStamp);
                     }

                     result /= _indexStocks[inIndexName].Count;
                     return Math.Round(result, 3);
                 }
             }
             return 0.000M;
         }

         public bool IndexExists(string inIndexName)
         {
             return _indices.Exists(i => i.IndexName == inIndexName.ToUpper());
         }

         public int NumberOfIndices()
         {
             return _indices.Count;
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             if (!_indices.Exists(i => i.IndexName == inIndexName.ToUpper()))
             {
                 throw new StockExchangeException("Ime indeksa ne postoji!");
             }

             if (!_indexStocks.ContainsKey(inIndexName))
             {
                 return 0;
             }
             else
             {
                 return _indexStocks[inIndexName].Count;
             }
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             throw new NotImplementedException();
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfPortfolios()
         {
             throw new NotImplementedException();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             throw new NotImplementedException();
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             throw new NotImplementedException();
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new NotImplementedException();
         }
     }
}
