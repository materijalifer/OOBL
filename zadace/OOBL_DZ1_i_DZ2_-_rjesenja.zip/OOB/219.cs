﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PrvaDomacaZadaca_Kalkulator
{
    public class MyCalculator : ICalculator
    {
        private string display = "0";
        private string memoriraniPodatak = "0";
        private string prviElementOperacije= null;
        private bool drugiElementOperacije = false;
        private char zadnjaIzvodenaOperacija = '0';
        public const int moguciBrojZnakova = 12;
        
        //omogućuje unos znaka u MyCalculator
        public void Press(char inPressedDigit)
        {
            if (Char.IsDigit(inPressedDigit))
            {
                dodajZnamenkuNaEkran(inPressedDigit);
            }
            else
            {
                if (Char.IsLetter(inPressedDigit))
                {
                    unarnaOperacija(inPressedDigit);
                }
                else
                {
                    switch (inPressedDigit)
                    {
                        case '+':
                            pripremaSustavaZaIzvodenjeOperacije('+');
                            break;
                        case '-':
                            pripremaSustavaZaIzvodenjeOperacije('-');
                            break;
                        case '*':
                            pripremaSustavaZaIzvodenjeOperacije('*');
                            break;
                        case '/':
                            pripremaSustavaZaIzvodenjeOperacije('/');
                            break;
                        case '=':
                            odredivanjeOperacije();
                            break;
                        case ',':
                            dodajDecimalniZarez();
                            break;
                    }
                }
            }
        }

        //omogućuje uvid u trenutno stanje 
        //ekrana kalkulatora
        public string GetCurrentDisplayState()
        {
            return this.display;
        }

        private void dodajZnamenkuNaEkran(char znamenka)
        {
            if (!this.drugiElementOperacije)
            {
                if (this.display.Equals("0"))
                {
                    this.display = znamenka.ToString();
                }
                else
                {
                    if (provjeraDuljineBroja(this.display) < moguciBrojZnakova - 2)
                    {
                        this.display = this.display + znamenka.ToString();
                    }
                }
            }
            else
            {
                this.display = znamenka.ToString();
                this.drugiElementOperacije = false;
            }
        }
        private void dodajDecimalniZarez()
        {
            if (!this.drugiElementOperacije)
            {
                if (provjeraDuljineBroja(this.display) == moguciBrojZnakova - 2 || this.display.Contains(","))
                {
                    return;
                }
                else
                {
                    this.display = this.display + ",";
                }
            }
            else
            {
                return;
            }
        }

        #region UPIS SLOVA NA EKRAN
        private void unarnaOperacija(char slovo)
        {
            switch (slovo)
            {
               
                case 'M':
                    promjeniPredznak();
                    break;
                case 'Q':
                    Kvadriranje();
                    break;
                case 'R':
                    Korjenovanje();
                    break;
                case 'S':
                    Sinus();
                    break;
                case 'K':
                    Kosinus();
                    break;
                case 'T':
                    Tangens();
                    break;
                case 'I':
                    Inverz();
                    break;
                case 'P':
                    Memory();
                    break;
                case 'G':
                    MemoryFetch();
                    break;
                case 'C':
                    Clear();
                    break;
                case 'O':
                    Reset();
                    break;
               
            }
        }
        #endregion 


        #region TRIGNOMETRIJA
        private void Sinus()
        {
            double novaVrijednost = Math.Sin(Convert.ToDouble(this.display));
            kontrolaZnamenkiBroja(novaVrijednost);
        }

        private void Kosinus()
        {
            double novaVrijednost = Math.Cos(Convert.ToDouble(this.display));
            kontrolaZnamenkiBroja(novaVrijednost);
        }

        private void Tangens()
        {
            double novaVrijednost = Math.Tan(Convert.ToDouble(this.display));
            kontrolaZnamenkiBroja(novaVrijednost);
        }
        #endregion 


        #region KVADRIRANJE, KORJENOVANJE I INVERZ
        private void Kvadriranje()
        {
            double novaVrijednost = Math.Pow((Convert.ToDouble(this.display)), 2);
            kontrolaZnamenkiBroja(novaVrijednost);
        }

        private void Korjenovanje()
        {
            if (Convert.ToDouble(this.display) >= 0)
            {
                double novaVrijednost = Math.Sqrt((Convert.ToDouble(this.display)));
                kontrolaZnamenkiBroja(novaVrijednost);
            }
            else
            {
                Reset();
                this.display = "-E-";
            }
        }

        private void Inverz()
        {
            if (Convert.ToDouble(this.display) != 0)
            {
                double novaVrijednost = 1 / Convert.ToDouble(this.display);
                kontrolaZnamenkiBroja(novaVrijednost);
            }
            else
            {
                Reset();
                this.display = "-E-";
            }
        }
        #endregion 


        private void odredivanjeOperacije()
        {
            switch (this.zadnjaIzvodenaOperacija)
            {
                case '+':
                    Zbroj();
                    break;
                case '-':
                    Razlika();
                    break;
                case '*':
                    Umnozak();
                    break;
                case '/':
                    Kvocijent();
                    break;
                case '0':
                    uklanjanjeNepotrebnihNula();
                    break;
            }
        }


        #region OSNOVNE MATEMATIČKE OPERACIJE
        private void Zbroj()
        {

            double novaVrijednost = Convert.ToDouble(this.prviElementOperacije) + Convert.ToDouble(this.display);
            
            kontrolaZnamenkiBroja(novaVrijednost);
           
            this.zadnjaIzvodenaOperacija = '0';
        }

        private void Razlika()
        {
            double novaVrijednost = Convert.ToDouble(this.prviElementOperacije) - Convert.ToDouble(this.display);
            kontrolaZnamenkiBroja(novaVrijednost);

            this.zadnjaIzvodenaOperacija = '0';
        }

        private void Umnozak()
        {
            double novaVrijednost = Convert.ToDouble(this.prviElementOperacije) * Convert.ToDouble(this.display);
            kontrolaZnamenkiBroja(novaVrijednost);

            this.zadnjaIzvodenaOperacija = '0';
        }

        private void Kvocijent()
        {
            if (Convert.ToDouble(this.prviElementOperacije) == 0)
            {
                Reset();
                this.display = "-E-";
            }
            else
            {
                double novaVrijednost = Convert.ToDouble(this.prviElementOperacije) / Convert.ToDouble(this.display);
                kontrolaZnamenkiBroja(novaVrijednost);
            }

            this.zadnjaIzvodenaOperacija = '0';
        }
        #endregion 


        #region KONTROLNE OPERACIJE
        private int provjeraDuljineBroja(string niz)
        {
            int brojZnamenki = 0;

            char[] reprezentacijaBrojaZaKontrolu = niz.ToCharArray();

            for (int i = 0; i < reprezentacijaBrojaZaKontrolu.Length; i++)
            {
                if (Char.IsDigit(reprezentacijaBrojaZaKontrolu[i]))
                {
                    brojZnamenki++;
                }
            }

            return brojZnamenki;
        }

        private string zaokruziBroj(string broj)
        {
            if (broj.Contains("-") && broj.Contains(","))
            {
               
                string zaokruzeniDio = zaokruzivanjeVrijednosti(broj);

                if (zaokruzeniDio != null)
                {
                    return broj.Substring(0, moguciBrojZnakova - 1) + zaokruzeniDio;
                }
                else
                {
                    return broj.Substring(0, moguciBrojZnakova);
                }
            }
            else if (broj.Contains("-") || broj.Contains(","))
            {
                string zaokruzeniDio = zaokruzivanjeVrijednosti(broj);

                if (zaokruzeniDio != null)
                {
                    return broj.Substring(0, moguciBrojZnakova - 2 ) + zaokruzeniDio;
                }
                else
                {
                    return broj.Substring(0, moguciBrojZnakova - 1);
                }
            }
            else
            {
                return broj.Substring(0, moguciBrojZnakova - 2);
            }
        }

        private void kontrolaZnamenkiBroja(double novaVrijednost)
        {
            provjeraVrijednosti(novaVrijednost);

            if (this.display.Equals("-E-"))
            {
                return;
            }

            if (provjeraDuljineBroja(novaVrijednost.ToString()) > moguciBrojZnakova - 2)
            {
                this.display = zaokruziBroj(novaVrijednost.ToString());
            }
            else
            {
                this.display = novaVrijednost.ToString();
            }
        }

        private void provjeraVrijednosti(double broj)
        {
            if (broj > 999999999)
            {
                Reset();
                this.display = "-E-";
            }
        }

        private string zaokruzivanjeVrijednosti(string broj)
        {
            char[] reprezentacijaBrojaZaKontrolu = broj.ToCharArray();

            if (broj.StartsWith("-"))
            {
                if (Int32.Parse(reprezentacijaBrojaZaKontrolu[12].ToString()) >= 5)
                {
                    int zaokruzenaVrijednost = Int32.Parse(reprezentacijaBrojaZaKontrolu[11].ToString()) + 1;

                    return zaokruzenaVrijednost.ToString();
                }
            }
            else
            {
                if (Int32.Parse(reprezentacijaBrojaZaKontrolu[11].ToString()) >= 5)
                {
                    int zaokruzenaVrijednost = Int32.Parse(reprezentacijaBrojaZaKontrolu[10].ToString()) + 1;

                    return zaokruzenaVrijednost.ToString();
                }
            }

            return null;
        }

        private void uklanjanjeNepotrebnihNula()
        {
            while (this.display.Contains(",") && (this.display.EndsWith("0") || (this.display.EndsWith(","))))
            {
                this.display = this.display.Substring(0, this.display.Length - 1);
            }
        }

        private void pripremaSustavaZaIzvodenjeOperacije(char operacija)
        {
            uklanjanjeNepotrebnihNula();
            if (this.zadnjaIzvodenaOperacija != '0' && !this.drugiElementOperacije)
            {
                
                odredivanjeOperacije();
                this.zadnjaIzvodenaOperacija = operacija;
                this.prviElementOperacije = this.display;
                this.drugiElementOperacije = true;
            }
            else if (this.drugiElementOperacije)
            {
                this.zadnjaIzvodenaOperacija = operacija;
            }
            else
            {
                this.prviElementOperacije = this.display;
                this.zadnjaIzvodenaOperacija = operacija;
                this.drugiElementOperacije = true;
            }
        }
        #endregion 


        #region FUNKCIJE EKRANA I MEMORIJE
        private void promjeniPredznak()
        {
            if (this.display.Equals("0"))
            {
                return;
            }
            else if (this.display.StartsWith("-") && (this.display.Length > 1))
            {
                this.display = this.display.Substring(1, this.display.Length - 1);
            }
            else
            {
                this.display = "-" + this.display;
            }
        }
        private void Clear()
        {
            this.display = "0";
        }

       private void Reset()   // vracanje pocetnih postavki za varijable
       {
           this.display = "0";
           this.memoriraniPodatak = "0";
           this.prviElementOperacije = null;
           this.zadnjaIzvodenaOperacija = '0';
           this.drugiElementOperacije = false;
       }
       private void Memory()
       {
           this.memoriraniPodatak = this.display;
       }
       private void MemoryFetch()
       {
           this.display = this.memoriraniPodatak;
       }
        #endregion 
    }

    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            return new MyCalculator();
        }
    }
}