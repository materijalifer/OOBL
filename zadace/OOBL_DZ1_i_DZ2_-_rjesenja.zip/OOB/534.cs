﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace DrugaDomacaZadaca_Burza
{
    public static class Factory
    {
        public static IStockExchange CreateStockExchange()
        {
            return new StockExchange();
        }
    }


    public class Stock
    {
        private string stockName;
        private long numberOfShares;
        private Decimal initialPrice;
        private Decimal price;
        private DateTime timeStamp;
        public List<DateTime> timeHistory = new List<DateTime>();
        public List<Decimal> priceHistory = new List<decimal>();
        public int StockInPortfolio = 0;

        public Stock(string stockName, long numbreOfShares, Decimal initialPrice, Decimal price, DateTime timeStamp)
        {
            this.stockName = stockName;
            this.numberOfShares = numbreOfShares;
            this.initialPrice = initialPrice;
            this.price = price;
            this.timeStamp = timeStamp;

        }


        public string StockName
        {
            get { return stockName; }
            set { stockName = value; }
        }

        public long NumberOfShares
        {
            get { return numberOfShares; }
            set { numberOfShares = value; }
        }

        public decimal InitialPrice
        {
            get { return initialPrice; }
            set { initialPrice = value; }
        }

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public DateTime TimeStamp
        {
            get { return timeStamp; }
            set { timeStamp = value; }
        }
    }


    public abstract class Index
    {
        private string _indexName;
        public List<Stock> IndexStockList = new List<Stock>();
        public List<string> StockNamesInIndex = new List<string>();
        //private IndexTypes _typeOfIndex;
        public Decimal indexValue;
       

        public string IndexName
        {
            get { return _indexName; }
            set { _indexName = value; }
        }


        public virtual void SetIndexValue()
        {
        }


    }

    public class AverageIndex : Index
    {
        
        public IndexTypes typeOfIndex = IndexTypes.AVERAGE;



        public override void SetIndexValue()
        {
            decimal suma = 0m;
            decimal indexV = 0m;
            foreach (Stock stock in IndexStockList)
            {
                suma += stock.Price;
            }
            indexV = suma/IndexStockList.Count;
            indexValue = Decimal.Round(indexV, 3);
        }
    }

    public class WeightedIndex : Index
    {
        public  IndexTypes typeOfIndex = IndexTypes.WEIGHTED;


        public override void SetIndexValue()
        {
            decimal suma = 0m;
            decimal indexV = 0m;
            foreach (Stock stock in IndexStockList)
            {
                suma += stock.Price*stock.NumberOfShares;
            }
            indexValue = 0;

            foreach (Stock stock in IndexStockList)
            {
                indexV += stock.NumberOfShares * stock.Price * stock.Price / suma;
            }
            indexValue = Decimal.Round(indexV, 3);
        }
    }

    public class Portfolio
    {
        private string ID;
        public List<string> StockNamesInPortfolio = new List<string>();
        public List<Stock> StocksInPortfolio = new List<Stock>();
        public List<int> SharesInPortfolio = new List<int>(); 
        public string Id
        {
            get { return ID; }
            set { ID = value; }
        }

        public Portfolio(string ID)
        {
            this.ID = ID;
        }
    }


    public class StockExchange : IStockExchange
     {

        List<Stock> newStockList = new List<Stock>();
        List<string> newStockNameList = new List<string>();
        List<Portfolio> newPortfolioList = new List<Portfolio>();  
        List<Index> newIndexList = new List<Index>(); 
        List<string> newIndexNameList = new List<string>();
        List<string> newPortfolioIDList = new List<string>();

        public void ListStock(string inStockName, long inNumberOfShares, decimal inInitialPrice, DateTime inTimeStamp)
        {
            string name = inStockName.ToUpper();
            if (!newStockNameList.Contains(name) && (inNumberOfShares > 0)
                && (inInitialPrice > 0))
                {
                    Stock stock = new Stock(inStockName, inNumberOfShares, inInitialPrice, inInitialPrice, inTimeStamp);
                    stock.timeHistory.Add(inTimeStamp);
                    stock.priceHistory.Add(inInitialPrice);
                    newStockList.Add(stock);
                    newStockNameList.Add(name);
                    return;
                }
            else
                {
                    throw new StockExchangeException("Uneseni parametri nisu valjani");
                }


         }

         public void DelistStock(string inStockName)
         {
             if (newStockNameList.Contains(inStockName.ToUpper()))
             {
                 foreach (Stock stock in newStockList)
                 {
                     if (stock.StockName.ToUpper() == inStockName.ToUpper())
                     {
                         newStockList.Remove(stock);
                     }
                 }
                 foreach (string s in newStockNameList)
                 {
                     if (s.ToUpper() == inStockName.ToUpper())
                     {
                         newStockNameList.Remove(s);
                     }
                 }

                 foreach (Portfolio portfolio in newPortfolioList)
                 {
                     if (IsStockPartOfPortfolio(portfolio.Id, inStockName.ToUpper()))
                     {
                         RemoveStockFromPortfolio(portfolio.Id, inStockName);
                     }
                 }

                 foreach (Index index in newIndexList)
                 {
                     if (IsStockPartOfIndex(index.IndexName, inStockName.ToUpper()))
                     {
                         RemoveStockFromIndex(index.IndexName, inStockName.ToUpper());
                     }
                 }
                 return;
             }
             else
             {
                 throw new StockExchangeException("Ne postoji dionica s tim imenom");
             }

         }

         public bool StockExists(string inStockName)
         {
             /*if (newStockList.Count == 0)
             {
                 return false;
                 throw new StockExchangeException("Ne postoji nijedna dionica");
             }*/

             foreach (Stock stock in newStockList)
             {
                 if (stock.StockName.ToUpper() == inStockName.ToUpper())
                 {
                     return true;
                 }
             }
             return false;

         }

         public int NumberOfStocks()
         {

             return newStockList.Count;
             //throw new NotImplementedException();
         }

         public void SetStockPrice(string inStockName, DateTime inIimeStamp, decimal inStockValue)
         {
             foreach (Stock stock in newStockList)
             {
                 if (inStockName.ToUpper() == stock.StockName.ToUpper())
                 {
                     stock.TimeStamp = inIimeStamp;
                     stock.Price = inStockValue;
                     stock.timeHistory.Add(inIimeStamp);
                     stock.priceHistory.Add(inStockValue);
                     return;
                 }
             }
             throw new StockExchangeException("Ne postoji");
         }

        public decimal GetStockPrice(string inStockName, DateTime inTimeStamp)
        {
            //int i = 0;
            foreach (Stock stock in newStockList)
            {
                if (stock.StockName.ToUpper() == inStockName.ToUpper())
                {
                    for (int i = 0; i < stock.priceHistory.Count; i++)
                    {
                        if (stock.timeHistory[i] > inTimeStamp)
                        {
                            return stock.priceHistory[i - 1];
                        }

                    }
                    return stock.Price;

                }
            }
            throw new StockExchangeException("Ne postoji dionica s tim imenom");

            
        }

        public decimal GetInitialStockPrice(string inStockName)
         {
             foreach (Stock stock in newStockList)
             {
                 if (stock.StockName.ToUpper() == inStockName.ToUpper())
                 {
                     return stock.InitialPrice;
                 }
             }
             throw new StockExchangeException("Ne postoji dionica s tim imenom");
         }

         public decimal GetLastStockPrice(string inStockName)
         {
             foreach (Stock stock in newStockList)
             {
                 if (stock.StockName.ToUpper() == inStockName.ToUpper())
                 {
                     return stock.Price;
                 }
             }
             throw new StockExchangeException("Ne postoji dionica s tim imenom");
         }

         public void CreateIndex(string inIndexName, IndexTypes inIndexType)
         {
             string name = inIndexName.ToUpper();
             if (!(newIndexNameList.Contains(name)) && ((inIndexType == IndexTypes.AVERAGE) ||
                 (inIndexType == IndexTypes.WEIGHTED)))
             {
                 if (inIndexType == IndexTypes.AVERAGE)
                 {
                     AverageIndex index = new AverageIndex();
                     index.IndexName = inIndexName;
                     newIndexList.Add(index);
                     newIndexNameList.Add(name);
                     return;

                 }
                 else
                 {
                     WeightedIndex index = new WeightedIndex();
                     index.IndexName = inIndexName;
                     newIndexList.Add(index);
                     newIndexNameList.Add(name);
                     return;
                 }
             }
             throw new StockExchangeException("Index s odabranim imenom već postoji ili je unesen ne postojeći tip indexa");

         }

         public void AddStockToIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     if (!index.StockNamesInIndex.Contains(inStockName.ToUpper()))
                     {
                         foreach (Stock stock in newStockList)
                         {
                             if (stock.StockName.ToUpper() == inStockName.ToUpper())
                             {
                                 index.IndexStockList.Add(stock);
                                 index.StockNamesInIndex.Add(inStockName.ToUpper());
                                 return;
                             }
                         }
                     }
                 }
             }

             throw new StockExchangeException("Dionica već postoji u indexu ili dionica ili index s tim imenom ne postoje");
         }

         public void RemoveStockFromIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName)
                 {
                     foreach (Stock stock in index.IndexStockList)
                     {
                         if (stock.StockName.ToUpper() == inStockName)
                         {
                             index.IndexStockList.Remove(stock);
                             
                         }
                     }
                     foreach (string s in index.StockNamesInIndex)
                     {
                         if (s == inStockName.ToUpper())
                         {
                             index.StockNamesInIndex.Remove(s);
                         }
                     }
                     return;
                 }
             }
             throw new StockExchangeException("Neispravni parametri");
         }

         public bool IsStockPartOfIndex(string inIndexName, string inStockName)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     foreach (Stock stock in newStockList)
                     {
                         if (index.StockNamesInIndex.Contains(stock.StockName.ToUpper()))
                         {
                             return true;
                         }
                     }
                 }
             }
             return false;
             //throw new NotImplementedException();
         }

         public decimal GetIndexValue(string inIndexName, DateTime inTimeStamp)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     index.SetIndexValue();
                     return index.indexValue;
                 }
             }
             throw new StockExchangeException("Neispravni parametri");
         }

         public bool IndexExists(string inIndexName)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     return true;
                 }
             }
             return false;
             //throw new NotImplementedException();
         }

         public int NumberOfIndices()
         {
             return newIndexList.Count;
             //throw new NotImplementedException();
         }

         public int NumberOfStocksInIndex(string inIndexName)
         {
             foreach (Index index in newIndexList)
             {
                 if (index.IndexName.ToUpper() == inIndexName.ToUpper())
                 {
                     return index.StockNamesInIndex.Count;
                 }
             }
             throw new StockExchangeException("Ne postoji index s tim imenom");
         }

         public void CreatePortfolio(string inPortfolioID)
         {
             if (!newPortfolioIDList.Contains(inPortfolioID))
             {
                 Portfolio portfolio = new Portfolio(inPortfolioID);
                 newPortfolioIDList.Add(inPortfolioID);
                 newPortfolioList.Add(portfolio);
                 return;
             }
             
             throw new StockExchangeException("Portfolio s tim ID-jem već postoji");
         }

         public void AddStockToPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if ((portfolio.Id == inPortfolioID) && (numberOfShares > 0))
                 {
                     if (portfolio.StockNamesInPortfolio.Contains(inStockName.ToUpper()))
                     {
                         for (int i = 0; i < portfolio.StockNamesInPortfolio.Count; i++)
                         {
                             if (portfolio.StockNamesInPortfolio[i] == inStockName.ToUpper())
                             {
                                 portfolio.SharesInPortfolio[i] += numberOfShares;
                                 foreach (Stock stock in newStockList)
                                 {
                                     if (stock.StockName.ToUpper() == inStockName.ToUpper())
                                     {
                                         stock.StockInPortfolio += numberOfShares;
                                         if (stock.StockInPortfolio < stock.NumberOfShares)
                                         {
                                             return;
                                         }
                                     }
                                 }
                                 
                                 //return;
                             }
                         }
                     }
                     else
                     {
                         foreach (Stock stock in newStockList)
                         {
                             if (stock.StockName.ToUpper() == inStockName.ToUpper())
                             {
                                 portfolio.StocksInPortfolio.Add(stock);
                                 portfolio.StockNamesInPortfolio.Add(inStockName.ToUpper());
                                 portfolio.SharesInPortfolio.Add(numberOfShares);
                                 stock.StockInPortfolio += numberOfShares;
                                 if (stock.StockInPortfolio < stock.NumberOfShares)
                                 {
                                     return;
                                 }

                             }
                         }
                     }
                     //return;
                 }
             }
             throw new StockExchangeException("Ne postoji portfolio s tim ID-jem ili nema dovoljno dionica");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName, int numberOfShares)
         {
             int i = 0;
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     foreach (Stock stock in portfolio.StocksInPortfolio)
                     {
                         if (stock.StockName.ToUpper() == inStockName.ToUpper())
                         {
                             if (portfolio.SharesInPortfolio[i] < numberOfShares)
                             {
                                 
                                 foreach (Stock stock1 in newStockList)
                                 {
                                     if (stock1.StockName.ToUpper() == inStockName.ToUpper())
                                     {
                                         stock1.StockInPortfolio -= portfolio.SharesInPortfolio[i];
                                     }
                                 }
                                 RemoveStockFromPortfolio(inPortfolioID, inStockName);
                             }
                             else
                             {
                                 foreach (Stock stock1 in newStockList)
                                 {
                                     if (stock1.StockName.ToUpper() == inStockName.ToUpper())
                                     {
                                         stock1.StockInPortfolio -= numberOfShares;
                                     }
                                 }
                                 portfolio.SharesInPortfolio[i] -= numberOfShares;
                             }
                             return;
                         }
                         else
                         {
                             i++;
                         }
                     }
                 }
             }
             throw new StockExchangeException("Neispravni parametri");
         }

         public void RemoveStockFromPortfolio(string inPortfolioID, string inStockName)
         {
             int i = 0;
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     if (!portfolio.StockNamesInPortfolio.Contains(inStockName))
                     {
                         throw new StockExchangeException("Ne postoji dionica s tim imenom");
                     }
                     foreach ( Stock stock in portfolio.StocksInPortfolio)
                     {
                         if (stock.StockName.ToUpper() == inStockName.ToUpper())
                         {
                             int IndexInPortfolio = portfolio.SharesInPortfolio[i];
                             portfolio.StocksInPortfolio.Remove(stock);
                             break;
                         }
                         else
                         {
                             i++;
                         }
                         
                     }
                     foreach (string s in portfolio.StockNamesInPortfolio)
                     {
                         if (s.ToUpper() == inStockName.ToUpper())
                         {
                             portfolio.StockNamesInPortfolio.Remove(s);
                             portfolio.SharesInPortfolio.RemoveAt(i);
                             return;
                         }
                     }

                     //return;
                 }
             }
             throw new StockExchangeException("Neispravni parametri");
         }

         public int NumberOfPortfolios()
         {
             return newPortfolioList.Count;
             //throw new NotImplementedException();
         }

         public int NumberOfStocksInPortfolio(string inPortfolioID)
         {
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     return portfolio.StocksInPortfolio.Count;
                 }
             }
             throw new StockExchangeException("Ne postoji portfolio s tim ID-jem");
         }

         public bool PortfolioExists(string inPortfolioID)
         {
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     return true;
                 }
             }
             return false;
         }

         public bool IsStockPartOfPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     foreach (Stock stock in portfolio.StocksInPortfolio)
                     {
                         if (stock.StockName.ToUpper() == inStockName.ToUpper())
                         {
                             return true;
                         }
                     }
                 }
             }
             return false;
             //throw new StockExchangeException("Ne postoji portfolio s tim ID-jem");
         }

         public int NumberOfSharesOfStockInPortfolio(string inPortfolioID, string inStockName)
         {
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     for (int i = 0; i < portfolio.StocksInPortfolio.Count; i++)
                     {
                         if (portfolio.StocksInPortfolio[i].StockName.ToUpper() == inStockName.ToUpper())
                         {
                             return portfolio.SharesInPortfolio[i];
                         }
                     }
                 }
             }
             throw new StockExchangeException("Ne postoji portfolio s tim ID-jem");
         }

         public decimal GetPortfolioValue(string inPortfolioID, DateTime timeStamp)
         {
             Decimal value = 0;
             foreach (Portfolio portfolio in newPortfolioList)
             {
                 if (portfolio.Id == inPortfolioID)
                 {
                     for (int i = 0; i < portfolio.StocksInPortfolio.Count; i++)
                     {
                         value += portfolio.SharesInPortfolio[i]*portfolio.StocksInPortfolio[i].Price;
                     }
                 }
                 return value;
             }
             throw new StockExchangeException("Neispravni parametri");
         }

         public decimal GetPortfolioPercentChangeInValueForMonth(string inPortfolioID, int Year, int Month)
         {
             throw new StockExchangeException("");
         }
     }
}
