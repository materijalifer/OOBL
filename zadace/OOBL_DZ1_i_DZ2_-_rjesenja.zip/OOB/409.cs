﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrvaDomacaZadaca_Kalkulator
{
    public class Factory
    {
        public static ICalculator CreateCalculator()
        {
            // vratiti kalkulator
            return new Kalkulator();
        }
    }

    public class Kalkulator:ICalculator
    {
        private const string NUMBER = "0123456789";
        private const string UNARY_OPERATION = "SKTQRI";
        private const string BINARY_OPERATION = "+-*/";
        private const int MAX_DISPLAY_NUMBERS = 10;

        private string _currentDisplay = "0";
        private string _result;
        private string _memory;
        private List<string> _operandList = new List <string>();
        private List<char> _binaryOperationList = new List<char>();
        private List<char> _lastPressedDigit = new List<char>();
        private bool _operatorPressed = false;
        
        public void Press(char inPressedDigit) 
        {
            _lastPressedDigit.Add(inPressedDigit);

            if (NUMBER.Contains(inPressedDigit))
            {
                if (_currentDisplay == "0" || _currentDisplay == null || _operatorPressed)
                    _currentDisplay = inPressedDigit.ToString();
                
                else if (_currentDisplay.Length < DisplayMaxLength(_currentDisplay))
                    _currentDisplay += inPressedDigit;

                _operatorPressed = false;
            }
            else if (inPressedDigit == 'M') 
            {
               if(_currentDisplay != null)
                    ChangeSign();
               _operatorPressed = false;
            }
            else if (inPressedDigit == ',') 
            {
                _currentDisplay += inPressedDigit;
                _operatorPressed = false;
            }
            else if (UNARY_OPERATION.Contains(inPressedDigit)) 
            {
                _currentDisplay = ResolveUnaryOperation(_currentDisplay,inPressedDigit);
                _operatorPressed = true;
                if(_currentDisplay != "-E-")
                    _currentDisplay = RoundResult(_currentDisplay);

            }
            else if (inPressedDigit == 'C') 
            {
                _currentDisplay = null;
                _operatorPressed = false;
            }
            else if (inPressedDigit == 'P')
            {
                _memory = _currentDisplay;
                _operatorPressed = false;
            }
            else if (inPressedDigit == 'G')
            {
                if (_memory != null)
                    _currentDisplay = _memory;
                else
                    _currentDisplay = "";
                _operatorPressed = false;
            }
            else if (inPressedDigit == 'O')
            {
                _currentDisplay = "0";
                _memory = null;
                _operandList.Clear();
                _binaryOperationList.Clear();
                _result = null;
                _operatorPressed = false;
                _lastPressedDigit.Clear();
            }
            else if (BINARY_OPERATION.Contains(inPressedDigit))
            {
                if(_currentDisplay.Contains(','))
                    _currentDisplay = RemoveZeros(_currentDisplay);

                if ((_binaryOperationList.Count != 0) && BINARY_OPERATION.Contains(_lastPressedDigit[_lastPressedDigit.Count - 2]))
                {   // brisanje viška binarnih operatora kada su zaredom
                    _binaryOperationList.RemoveAt(_binaryOperationList.Count - 1);
                    _binaryOperationList.Add(inPressedDigit);
                }
                else
                {
                    _operandList.Add(_currentDisplay);
                    _binaryOperationList.Add(inPressedDigit);
                }               
                _operatorPressed = true;
                                
            }
            else if (inPressedDigit == '=')
            {
                if (_currentDisplay.Contains(','))
                    _currentDisplay = RemoveZeros(_currentDisplay);
    
                _operandList.Add(_currentDisplay); // zadnji operand
                
                _result = SolveBinaryOperations(_operandList, _binaryOperationList);
                
                if (_result != null)
                {
                    _result = RoundResult(_result);
                    _currentDisplay = _result;
                }
                _operatorPressed = false;
            }
                                
        }

        public string GetCurrentDisplayState()
        {
            return _currentDisplay;
        }

       
        private string RemoveZeros(string number)
        {
            if (number.Contains(','))
            {
                int i = number.Length - 1;
                int index = number.IndexOf(',');
                while (i >= index)
                {
                    if (number[i] == '0' || number[i] == ',')
                    {
                        number = number.Remove(i);
                        i--;
                    }
                    else
                    {
                        break;
                    }
                }

            }

            return number;
        }

        private string RoundResult(string number)
        {
            int numBeforeDecPoint;

            if (number.Contains(','))
            {
                numBeforeDecPoint = number.IndexOf(',');
                if (number.Contains('-'))
                    numBeforeDecPoint -= 1;
            }
            else
                numBeforeDecPoint = number.Length;
            
            if (numBeforeDecPoint > MAX_DISPLAY_NUMBERS)
                number = "-E-";

            else
            {
                int maxLength = DisplayMaxLength(number);

                if (number.Length > maxLength)
                {   // broj koji dođe ovdje sigurno ima dec zarez
                    int roundDigits = maxLength - numBeforeDecPoint - 1;
                    if (number.Contains('-'))
                        roundDigits -= 1;
                    number = Math.Round(Convert.ToDouble(number),roundDigits).ToString();
                }
               
            }
            return number;
                        
        }

                 
        private void ChangeSign()
        {
            if (_currentDisplay != "0")
            {
                if (_currentDisplay.Contains('-'))
                    _currentDisplay = _currentDisplay.Replace("-", "");
                else
                    _currentDisplay = "-" + _currentDisplay;
            }
        }

        private int DisplayMaxLength(string display)
        {
            int maxLength = MAX_DISPLAY_NUMBERS;

            if (display.Contains(',') && display.Contains('-'))
            {
                maxLength = 12;
            }
            else if (display.Contains(',') || display.Contains('-'))
            {
                maxLength = 11;
            }

            return maxLength;
        }

        private string ResolveUnaryOperation(string number, char operation)
        {
            string result = "-E-";

            if (number != null)
            {
                double operand = Convert.ToDouble(number);
                
                switch (operation)
                {
                    case 'S':
                        operand = Math.Sin(operand);
                        result = Convert.ToString(operand);
                        break;

                    case 'K':
                        operand = Math.Cos(operand);
                        result = Convert.ToString(operand);
                        break;

                    case 'T':
                        operand = Math.Tan(operand);
                        result = Convert.ToString(operand);
                        break;

                    case 'Q':
                        operand = Math.Pow(operand, 2);
                        result = Convert.ToString(operand);
                        break;

                    case 'R':
                        if (operand >= 0)
                        {
                            operand = Math.Sqrt(operand);
                            result = Convert.ToString(operand);
                        }
                        break;

                    case 'I':
                        if (operand != 0)
                        {
                            operand = 1 / operand;
                            result = Convert.ToString(operand);
                        }
                        break;

                    default:
                        break;

                }
            }
            return result;
        }

        private string SolveBinaryOperations(List<string> operands, List<char> operations)
        {
            string result;

            while (operations.Count != 0)
            {
                result = ResolveBinaryOperation(operands[0], operands[1], operations[0]);
                operands.RemoveAt(0);
                operands.RemoveAt(0);
                operands.Insert(0, result);
                operations.RemoveAt(0);
            }

            result = operands[0];

            return result;
        }

        private string ResolveBinaryOperation(string operand1, string operand2, char operation)
        {
            string result = "-E-";
        
            if (operand1 != null)
            {
                double firstOperand = Convert.ToDouble(operand1);
                double secondOperand;

                if (operand2 == null)
                    secondOperand = firstOperand;
                else
                    secondOperand = Convert.ToDouble(operand2);

                switch (operation)
                {
                    case '+':
                        result = Convert.ToString(firstOperand + secondOperand);
                        break;

                    case '-':
                        result = Convert.ToString(firstOperand - secondOperand);
                        break;

                    case '*':
                        result = Convert.ToString(firstOperand * secondOperand);
                        break;

                    case '/':
                        if (secondOperand != 0)
                            result = Convert.ToString(firstOperand / secondOperand);
                        break;

                    default:
                        break;
                }
            }
                    return result;
        }
    }


}