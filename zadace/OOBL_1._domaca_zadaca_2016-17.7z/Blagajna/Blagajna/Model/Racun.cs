﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna
{
    [Serializable]
    public class Racun
    {
        public List<Artikl> ListaArtikala { get; set; }
        public DateTime Date { get; set; }
        public double PDV { get; set; }
        
        public Racun()
        {
            ListaArtikala = new List<Artikl>();
            PDV = 0;
        }

        public void addArtikl(Artikl artikl)
        {
            ListaArtikala.Add(artikl);
            this.PDV += artikl.Cijena * artikl.PDV;
        }

        public void Ispis()
        {
            Console.WriteLine();
            Console.WriteLine("Ovaj racun napravljen je:" + this.Date);
            foreach(Artikl artikl in ListaArtikala)
            {
                artikl.Ispis();
            }
            Console.WriteLine("Ukupan iznos PDV-a je:" + this.PDV);
            Console.WriteLine();
        }
        public void SkraceniIspis()
        {
            Console.WriteLine("Vrijeme: "+ Date+ " Broj artikala: "+ListaArtikala.Count+ " iznos racuna: "+ this.price() );
        }

        public double price()
        {
            double suma = 0;
            foreach (Artikl artikl in ListaArtikala)
            {
                suma += artikl.Cijena;
                
            }
            return suma;
        }
    }
}
