﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Blagajna
{
    [Serializable]
    public class Artikl
    {
        public String Naziv { get; set; }
        public double Cijena { get; set; }
        public double PDV { get; set; }

        public Artikl()
        {
            
        }
        public Artikl(String naziv, double cijena, double pdv)
        {
            this.Cijena = cijena;
            this.Naziv = naziv;
            this.PDV = pdv;
        }
        public void Ispis()
        {
            Console.WriteLine("Cijena: "+Cijena + " Naziv: " + Naziv+ " PDV: " + PDV);
        }

        public String Context()
        {
            return ("Cijena: " + Cijena + " Naziv: " + Naziv + " PDV: " + PDV);
        }


    }
}
