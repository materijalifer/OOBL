﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blagajna.Authentication;
using Blagajna.Users;

namespace Blagajna
{
    public class Blagajna
    {
        
        Serializer serializer;
        public Blagajna()
        {
            serializer = new Serializer();
            /*ArtiklService artiklService = new ArtiklService();
            listaArtikala = artiklService.fetchAll();
             */    
        }
        public void Initialize()
        {
            List<Artikl> lista = new List<Artikl>();
            lista.Add( new Artikl("Banana", 10.5, 0.2));
            lista.Add(new Artikl("Kruska", 11.0, 0.2));
            lista.Add(new Artikl("Jabuka", 22.0, 0.3));
            lista.Add(new Artikl("Lubenica", 220.0, 0.3));   

            serializer.Serialize(lista, @"artikl.txt");
        }

        internal void start(Korisnik korisnik)
        {
            korisnik.options();
        }


        




    }
}
