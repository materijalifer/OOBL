﻿using Blagajna.Actions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Users
{
    public class Blagajnik : Korisnik
    {
        protected List<Actions.Akcija> listaAkcija;
        public Blagajnik()
        {
            listaAkcija = new List<Akcija>();
            listaAkcija.Add(new ArtiklReport());
            listaAkcija.Add(new DayReport());
            listaAkcija.Add(new NewRacun());
        }

        public override void options()
        {
            Console.WriteLine("Upišite ključno slovo od ponuđenih opcija:");
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("---------------------------------------");
                foreach (Akcija akcija in listaAkcija)
                {
                    
                    Console.WriteLine(akcija.Key + " -> " + akcija.Name);
                }
                String input=Console.ReadLine();
                input = input.Replace("\n", String.Empty);
                Console.WriteLine("---------------------------------------");
                foreach (Akcija akcija in listaAkcija)
                {
                    akcija.notify(input);
                }
            }
            
        }
    }
}
