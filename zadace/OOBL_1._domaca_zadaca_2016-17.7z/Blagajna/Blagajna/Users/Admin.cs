﻿using Blagajna.Actions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Users
{
    public class Admin : Blagajnik
    {
        public Admin()
        {
            listaAkcija.Add(new NewArtikl());
            listaAkcija.Add(new ChangeRacun());
        }
    }
}
