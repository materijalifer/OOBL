﻿using Blagajna.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Authentication
{
    public class MyConsoleAuthentication : IAuthentication
    {

        public Korisnik Login()
        {
            Serializer serializer = new Serializer();
            String path = @"users.txt";
            List<Account> listAccount = serializer.DeSerialize<List<Account>>(path);
            String username;
            String password;
            Console.WriteLine("Hint: korisnicko ime i lozinka za administratora je slovo 'a', a za blagajnika slovo 'b'(znaci 'a','a' i 'b','b')");
            while (true)
            {
                Console.WriteLine("Upisite korisnicko ime:");
                username=Console.ReadLine();
    
                Console.WriteLine("Upisite lozinku:");
                password = Console.ReadLine();

                foreach(Account acc in listAccount)
                {
                    if(acc.UserName.Equals(username) && acc.Password.Equals(password))
                    {
                        return CreateKorisnik(acc);
                    }
                }
                Console.WriteLine("Login nije uspio. Molimo Vas pokusajte ponovo");
            }
            
            
        }

        public Korisnik CreateKorisnik(Account acc)
        {
            if (acc.Role == Account.Admin) return new Admin();
            else if (acc.Role == Account.Blagajnik) return new Blagajnik();
            return null;
        }
        public void CreateAccounts()
        {
            String path = @"users.txt";
            Serializer serializer = new Serializer();
            List<Account> listAccount = new List<Account>();
            Account account = new Account("a", "a", Account.Admin);
            Account account1 = new Account("b", "b", Account.Blagajnik);
            listAccount.Add(account);
            listAccount.Add(account1);
            serializer.Serialize(listAccount, path);
        }
    }
}
