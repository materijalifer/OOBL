﻿using Blagajna.Authentication;
using Blagajna.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna
{
    public interface IAuthentication
    {
        Korisnik Login();
       
    }
}
