﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Authentication
{
    [Serializable]
    public class Account
    {
        public String UserName { get; set; }
        public String Password { get; set; }
        public String Role { get; set; }

        public static String Admin = "admin";
        public static String Blagajnik = "blagajnik";

        public Account() { }
        public Account(String userName, String password, String role)
        {
            this.Password = password;
            this.UserName = userName;
            this.Role = role;
        }

    }
}
