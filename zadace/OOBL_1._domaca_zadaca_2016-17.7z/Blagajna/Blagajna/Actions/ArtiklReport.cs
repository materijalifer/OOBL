﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    class ArtiklReport : Akcija
    {
        public ArtiklReport()
        {
            this.Key = "I";
            this.Name = "Izvjesce artikala";
        }
        public override void execute()
        {
            /*ArtiklService service = new ArtiklService();
            var artikli = service.fetchAll();
            foreach(Artikl artikl in artikli)
            {
                artikl.Ispis();
            }*/

            RacunService rs = new RacunService();
            var racuni = rs.fetchAll();
            var map = new Dictionary<string, int>();
            foreach (Racun racun in racuni)
            {
                foreach(Artikl artikl in racun.ListaArtikala)
                {
                    try
                    {
                        int puta = map[artikl.Naziv];
                        puta++;
                        map[artikl.Naziv] = puta;
                    }
                    catch
                    {
                        map[artikl.Naziv] = 1;
                    }
                }
            }

            var myList = map.ToList();

            myList.Sort((pair1, pair2) => pair2.Value.CompareTo(pair1.Value));

            foreach(var a in myList)
            {
                Console.WriteLine(a.Value+" "+a.Key);
            }

        }
    }
}
