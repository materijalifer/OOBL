﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    class DayReport : Akcija
    {
        public DayReport()
        {
            this.Key = "D";
            this.Name = "Dnevno izvjesce";
        }
        public override void execute()
        {
            RacunService service = new RacunService();
            List<Racun> racuni = service.fetchAll();
            double duljina = 0;
            double suma = 0;
            foreach(Racun racun in racuni)
            {
                if (racun.Date.Date == DateTime.Today)
                {
                    duljina++;
                    suma += racun.price();
                }
            }
            Console.WriteLine("Broj racuna za danasnji dan: " + duljina + " Ukupna cijena: " + suma);
            foreach (Racun racun in racuni)
            {
                if (racun.Date.Date == DateTime.Today)
                {
                    racun.SkraceniIspis();
                }
            }

        }
    }
}
