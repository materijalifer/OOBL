﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    class NewArtikl : Akcija
    {
        public NewArtikl()
        {
            this.Key = "A";
            this.Name = "Novi Artikl";
        }

        public override void execute()
        {
            try
            {
                Console.WriteLine("Upisite Naziv artikla:");

                String Naziv = Console.ReadLine();
                Naziv = Naziv.Replace("\n", String.Empty);

                Console.WriteLine("Upisite cijenu artikla:");
                String Cijena = Console.ReadLine();
                Cijena = Cijena.Replace("\n", String.Empty);

                Console.WriteLine("Upisite PDV:");
                String PDV = Console.ReadLine();
                PDV = PDV.Replace("\n", String.Empty);
                Artikl artikl = new Artikl(Naziv, Convert.ToDouble(Cijena), Convert.ToDouble(PDV));
                ArtiklService service= new ArtiklService();
                service.AddArtikl(artikl);
                Console.WriteLine("Uspjesno dodan novi artikl:");
                artikl.Ispis();
            }
            catch
            {
                Console.WriteLine("Dodavanje novog artikla nije uspjelo");
                return;
            }
        }
    }
}
