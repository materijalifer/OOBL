﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    class ChangeRacun : Akcija
    {
        public ChangeRacun()
        {
            this.Key = "P";
            this.Name = "Promijeni/izbrisi racun";
        }

        public override void execute()
        {
            Console.WriteLine("Unesite broj računa kojeg želite promijeniti/obrisati:");
            RacunService rs = new RacunService();
            var racuni = rs.fetchAll();
            int i = 0;
            foreach (Racun racun in racuni)
            {
                Console.WriteLine("..........................................................................");
                Console.WriteLine("Broj računa: " + i++);
                racun.Ispis();
            }
            String input=Console.ReadLine();
            Racun r;
            int broj;
            try
            {
                broj = Int32.Parse(input);
                r = racuni[broj];
            }
            catch
            {
                Console.WriteLine("Niste unijeli ispravan broj");
                return;
            }
            while (true)
            {

                Console.WriteLine("..................................................");
                Console.WriteLine("Ako zelite spremiti promjene i izaći upišite slovo 'x'");
                Console.WriteLine("Ako zelite izbrisati cijeli račun upišite slovo 'b'");
                Console.WriteLine("Ako zelite dodati novi artikl u račun upišite slovo 'n'");
                Console.WriteLine("Ako zelite izbrisati artikl iz računa upišite redni broj artikla kojeg želite obrisati");
                Console.WriteLine("Artikli:");
                int j = 0;

                foreach (Artikl artikl in r.ListaArtikala)
                {
                    Console.WriteLine("Redni broj: "+j++ +" -> "+ artikl.Context());
                }
                String slovo=Console.ReadLine();
                slovo = slovo.Replace("\n", String.Empty);
                if (slovo.Equals("x"))
                {
                    rs.RemoveRacun(racuni[broj]);
                    rs.AddRacun(r);
                    return;
                }else if (slovo.Equals("b"))
                {
                    rs.RemoveRacun(racuni[broj]);
                    Console.WriteLine("Uspjesno ste izbrisali racun");
                    return;
                }
                else if (slovo.Equals("n"))
                {
                    ArtiklService service = new ArtiklService();
                    var artikli = service.fetchAll();
                    
                    Console.WriteLine("Odaberite artikl koji zelite dodati u racun");
                    int k = 0;
                    foreach (Artikl artikl in artikli)
                    {
                        Console.WriteLine(k++ + " " + artikl.Context());
                    }
                    String brArtikl = Console.ReadLine();
                    brArtikl = brArtikl.Replace("\n", String.Empty);
                    try
                    {
                        Artikl artikl = artikli[Int32.Parse(brArtikl)];
                        r.addArtikl(artikl);
                    }
                    catch
                    {

                    }


                    
                }
                else
                {
                    try
                    {
                        int brojArtikla = Int32.Parse(slovo);
                        r.ListaArtikala.RemoveAt(brojArtikla);
                    }catch
                    {
                        Console.WriteLine("Niste unijeli ispravnu komandu");
                    }
                }
            }
            

        }
    }
}
