﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    public abstract class Akcija
    {
        public String Key { get; set; }
        public String Name { get; set; }
        public abstract void execute();

        public void notify(String key)
        {
            if (this.Key.Equals(key) || key.ToUpper().Equals(Key)) this.execute();
        }
    }
}
