﻿using Blagajna.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Actions
{
    class NewRacun : Akcija
    {
        public NewRacun()
        {
            this.Key = "R";
            this.Name = "Novi Racun";
        }
        public override void execute()
        {
            Racun racun = new Racun();
            ArtiklService service = new ArtiklService();
            var artikli=service.fetchAll();
            do
            {
                Console.WriteLine("Odaberite artikl koji zelite dodati u racun ili upisite -1 za ispis racuna");
                int i = 0;
                foreach(Artikl artikl in artikli)
                {
                    Console.WriteLine(i++ + " " + artikl.Context());
                }
                String input=Console.ReadLine();
                input = input.Replace("\n", String.Empty);
                if (input.Equals("-1")){
                    racun.Date = DateTime.Now;
                    RacunService rs = new RacunService();
                    rs.AddRacun(racun);
                    racun.Ispis();
                    return;
                }
                try {
                    Artikl artikl = artikli[Int32.Parse(input)];
                    racun.addArtikl(artikl);
                }
                catch
                {

                }


            } while (true);
        }

        
    }
}
