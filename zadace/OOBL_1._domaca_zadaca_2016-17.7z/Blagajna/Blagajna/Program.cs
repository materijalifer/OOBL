﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Threading;
using Blagajna.Authentication;
using Blagajna.Users;

namespace Blagajna
{
    class Program
    {
        static void Main(string[] args)
        {
            
            MyConsoleAuthentication myConsoleAuthentication = new MyConsoleAuthentication();
            myConsoleAuthentication.CreateAccounts();

            IAuthentication auth = myConsoleAuthentication;
            Korisnik korisnik=auth.Login();
            
            Blagajna blagajna = new Blagajna();
            blagajna.Initialize();
            blagajna.start(korisnik);
            





        }
    }
}
