﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Service
{
    class RacunService
    {
        private List<Racun> listaRacuna;
        private Serializer serializer;
        private static String path = @"racuni.txt";
        public RacunService()
        {
            serializer = new Serializer();
            try
            {
                listaRacuna = serializer.DeSerialize<List<Racun>>(path);
            }
            catch
            {
                listaRacuna = new List<Racun>();
            }
        }

        public List<Racun> fetchAll()
        {
            return listaRacuna;
        }
        public void AddRacun(Racun racun)
        {
            listaRacuna.Add(racun);
            serializer.Serialize(listaRacuna, path);
        }
        public void RemoveRacun(Racun racun)
        {
            listaRacuna.Remove(racun);
            serializer.Serialize(listaRacuna, path);
        }
    }
}
