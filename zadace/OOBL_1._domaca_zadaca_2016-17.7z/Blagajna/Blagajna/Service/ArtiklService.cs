﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blagajna.Service
{
    class ArtiklService
    {
        List<Artikl> listaArtikala;
        Serializer serializer;

        private static String path = @"artikl.txt";
        public ArtiklService()
        {
            serializer = new Serializer();
            listaArtikala = serializer.DeSerialize<List<Artikl>>(path);
        }
        public List<Artikl> fetchAll()
        {
            return listaArtikala;
        }
        public void AddArtikl(Artikl artikl)
        {
            listaArtikala.Add(artikl);
            serializer.Serialize(listaArtikala, @"artikl.txt");
        }
    }
}
