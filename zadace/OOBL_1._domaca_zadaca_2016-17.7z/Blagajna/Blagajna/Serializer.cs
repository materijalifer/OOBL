﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Blagajna.Authentication;

namespace Blagajna
{
    class Serializer
    {
        private static String artiklPath =@"artikl.txt";

        public void Serialize<T>(T t)
        {
            XmlSerializer xs = new XmlSerializer(typeof(T));
            using (TextWriter tw = new StreamWriter(artiklPath))
            {
                xs.Serialize(tw, t);
            }
            
        }

        public void Serialize<T>(T t, String path)
        {
            XmlSerializer xs = new XmlSerializer(typeof(T));
            using (TextWriter tw = new StreamWriter(path))
            {
                xs.Serialize(tw, t);
            }

        }

        public T DeSerialize<T>(string path)
        {
            using (var sr = new StreamReader(path))
            {
                XmlSerializer xs = new XmlSerializer(typeof(T));
                return (T)xs.Deserialize(sr);
            }
        }
        public T DeSerialize<T>()
        {
            using (var sr = new StreamReader(artiklPath))
            {
                XmlSerializer xs = new XmlSerializer(typeof(T));
                return (T)xs.Deserialize(sr);
            }
        }

        public Artikl DeSerializeArtikl()
        {
            using (var sr = new StreamReader(artiklPath))
            {
                XmlSerializer xs = new XmlSerializer(typeof(Artikl));
                return (Artikl)xs.Deserialize(sr);
            }
        }

    }
}
